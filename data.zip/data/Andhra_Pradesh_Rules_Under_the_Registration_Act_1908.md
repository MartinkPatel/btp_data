Andhra Pradesh Rules Under the Registration Act, 1908
ANDHRA PRADESH
India
Andhra Pradesh Rules Under the Registration Act,
1908
Rule
ANDHRA-PRADESH-RULES-UNDER-THE-REGISTRATION-ACT-1908
of 1908
Published on 24 December 1959• 
Commenced on 24 December 1959• 
[This is the version of this document from 24 December 1959.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Rules Under the Registration Act, 1908Published in the Andhra Pradesh Gazette
R.S to Part 2, dated 24.12.1959The following rules, which have been made by the Inspector-General
of Registration under Section 69 of the Registration Act, 1908, and which have been approved by the
State Government are published for general information.These rules shall come into force
throughout the State of Andhra Pradesh with effect from the 1st January, 1960 and superseded with
effect from the said date, rules at present in force.
Chapter I
Preliminary
1.
In these rules, unless there is anything repugnant in the subject or context.(a)"the Act" means the
Registration Act, 1908.(b)"Section" means a section of the Act.(c)"Rule" means rule made under the
Act for the time being in force.(d)"Appendix" means an appendix annexed to these
rules.(e)"Registering Officer" includes both a Registrar and a Sub-Registrar.(f)"Government" means
the Government of Andhra Pradesh.(g)[ "Document writer" means and includes one who is engaged
in the profession of preparing and writing of documents to be presented for registration. [Clauses
(g), (h) & (i) added by Registration Rules Supplement published in the Rules Supplement to Part II,
Page 57 of the Andhra Pradesh Gazette, dated 23.2.1961. ](h)"Licence" means a licence granted to a
document writer under these rules.(i)"Licensing authority" means the licensing authority specified
in Rule 206.]Andhra Pradesh Rules Under the Registration Act, 1908

2.
All such documents and maps shall, for the purposes of Sections 43 and 48, be deemed to have been
and to be registered in accordance with the provisions of this Act.
Chapter II
Office Hours and Holidays
3.
The offices of all Registrars and Sub-Registrars shall be open for at least six and half hours daily,
Sundays and holidays excepted. The hours of working shall usually be those fixed by Government,
from time to time. These shall not be altered except with the approval of the Inspector-General. A
notice showing the hours of working of the office shall be affixed in a prominent place in each office
for the information of the public.
4.
A Registering Officer may decline to receive a document for registration if presented after 3.30 P.M.
when he has sufficient work to attend to after that hour in connection with documents previously
admitted to registration.
5.
The holidays to be observed in Registration Offices are the holidays notified by Government.
6.
A document presented for registration or a sealed cover purporting to contain a will presented for
deposit under Section 42 or an application for the withdrawal of such a cover under Section 44 or a
Power of Attorney brought for authentication under Rule 49 shall not be accepted or authenticated
on an authorised general holiday except in a special emergency. When a Sub-Registrar accepts a
document or authenticates a Power of Attorney on such a day, he shall immediately make a report to
the Registrar explaining the circumstances.There is, however, no objection to accept a document for
registration or a sealed cover purporting to contain a will for deposit, authenticate a Power of
Attorney at a private residence on a Sunday or other authorised holiday or to the transcription or
return of documents on such days, should the Registering Officer happen to be in his office.
Chapter III
(Sections 6 and 7)Andhra Pradesh Rules Under the Registration Act, 1908

Registering Officers
7.
A notice stating where the Registering Officer lives shall be affixed outside each Registration Office.
8.
When two or more offices are established in a Sub-District as joint offices, each of the officers
appointed to the charge thereof shall be designated as Joint Sub-Registrar and shall have concurrent
jurisdiction over the whole Sub-District.
9.
(i)When a Joint Sub-Registrar is appointed, either as a temporary or permanent measure, to assist a
Sub-Registrar, he will have no separate office or establishment but will work side by side with the
other permanent Sub-Registrar, the documents registered by both Sub-Registrars being entered in
the same returns and registers and indexed in the same sheets.(ii)In such cases there is no objection
to one Sub-Registrar completing the registration or authenticating the entry of a document admitted
to registration by the other Sub-Registrar when circumstances arise which prevent the latter officer
from performing those duties.(iii)The senior of the two Sub-Registrars shall sign and be designated
as Sub-Registrar and the other as Temporary Sub-Registrar or Joint Sub-Registrar as the case may
be.
Chapter IV
(Section 15)
Seals
10.
(i)The seal shall always remain in the personal custody of the Registering Officer.(ii)It shall be used
in authenticating :(a)the certificates endorsed on a registered instrument under Section
60;(b)power of attorney attested under Section 33;(c)summonses and commissions issued under
Sections 33 and 38;(d)certified copies under Section 57;(e)memoranda and copies forwarded under
Sections 64 to 67 and under Rules 24 and 159 (iv);(f)copies of order of refusal to register granted
under Sections 71 and 76;(g)copies other than those above referred to granted to
parties;(h)certificates and lists granted to applicants under Rule 140;(i)copies of judgments of
Registrars under Sections 72 and 75;(j)reproduced entries of old registers;(k)copies of maps and
plans;(l)decrees drawn up under Section 75 and copies thereof.Andhra Pradesh Rules Under the Registration Act, 1908

11.
Should a Registering Officer find himself temporarily unprovided with the prescribed seal,
registration shall nevertheless proceed as usual and such documents as have been transcribed shall
remain in his custody until the seal can be affixed to the registration certificate.
Chapter V
(Sections 16 and 51)
Books & Forms
12.
(i)The registers shall be in the forms shown in Appendix-I.(ii)Where necessary more than one
volume of the same class may with the previous sanction of the Registrar, be used simultaneously
for the registration of documents.
13.
(i)A file book shall be maintained in each registration office corresponding with Book I. In this the
following shall be filed:(a)copies of maps and plans mentioned in Section 21;(b)copies and
memoranda of registered instruments received under Sections 64 to 67;(c)copies of certificates and
orders received under Section 89;(d)returns of lands acquired under the Land Acquisition
Act;(e)communications received from officers of other Departments intimating the cancellation,
modification or rectification of transactions evidenced by papers previously filed;(f)copies of
instruments of collateral security executed under the Land Improvement Loans Act received from
Revenue Officers.(ii)A separate file shall also be opened for filing copies and translations presented
under Sections 19 and 62 of the Act or under Rule 17(i). The copies and translations placed in this
file shall be connected by cross-reference with the entry in the register.
14.
The registers and file books shall contain such number of pages as the Inspector-General may, from
time to time, prescribe.
15.
Should a Registering Officer who requires a fresh register book have no blank registers in stock,
instruments tendered for registration shall nevertheless, be received as usual, necessary enquiries
shall be held and the prescribed endorsements on the documents shall be entered. As however the
certificate of registration cannot be added until the instrument has been copied into the register
book, the instruments in all such cases shall remain in the custody of the Registering Officer untilAndhra Pradesh Rules Under the Registration Act, 1908

they have been copied into a register book and the process of registration has been completed.
Chapter VI
(Section 19 of the Act)
Languages
16.
The following languages shall be deemed to be languages commonly used in the Districts and
Sub-Districts named thereunder:I-EnglishII-TeluguAll Registration Districts and
Sub-Districts.III-HindiRegistration Districts of Hyderabad, Nizamabad and
Warangal.IV-UrduRegistration Districts of Hyderabad, Nizamabad and Warangal and Sub-Districts
of Jammalamadugu, Proddutur, Budvel, Vempalle, Kamalapuram; Cuddapah, Rayachoti and
Pullapeta in the Registration District of Cuddapah.Sub-District of Guntakal, Hindupur, Kadiri,
Uravakonda, Gooty, Dharmavaram, Penukonda, Madakasira, and Rayadurg in the Registration
District of Anantapur.Sub-Districts of Kodumur, Gudur, Adoni, Yemmiganur, Atmakur, Pattikonda,
Dhone, Nandyal, Banaganapalli, Kolakuntla, and Kurnool in the Registration District of
Kurnool.Sub-Districts of Markapur, Giddalur and Cumbum, in the Registration District of
Narsaraopet.V-TamilChittoor, Satyaveedu, Karvetinagar, and Pisatur in the Sub-Districts of
Kangadi, Pakala, Palmaner, Tirupathi, Puttur, in the Registration District of
Chittoor.VI-OriyaSub-Districts of Ichhapuram, Sompeta, Patapatnam, Mandasa, Kasibugga and
Tekkali in the Registration District of Srikakulam.Sub-Districts of Kurupam and Srungavarapukota
in the Registration District of Visakhapatnam.VII-MarathiSub-Districts of Bhainsa and Mancherial
in the Registration District of Nizamabad.VIII-KannadaSub-Districts of Madakasira and Rayadurg
in the Registration District of Anantapur.Sub-Districts of Alur and Yemmiganur in the Registration
District of Kurnool.Sub-Districts of Medak, Zahirabad, Sangareddy and Siddipet in the Registration
District of Nizamabad.
17.
(i)The stamp vendor's endorsement on a document shall be considered to be a part of the document,
and if it is in a language not commonly used in the District, the Registering Officer shall, if he does
not understand the language, demand of the presentant to file a true translation and also a true
copy. No fee shall be levied for filing such translation under this sub-rule.(ii)When a Power of
Attorney is presented for attestation or when an attested Power of Attorney is produced by an agent
with or in connection with a document presented for registration and the Power of Attorney is
written in a language not commonly used in the District, the Registering Officer may, if he does not
understand the language, demand of the presentant a true translation of the power in English or in a
language commonly used in the District.(iii)The translation and the copy shall be certified to be a
true translation and a true copy and shall be signed by the presentant.(iv)No fee is leviable for filing
a translation if the Power of Attorney is or has been attested by a Registering Officer.Andhra Pradesh Rules Under the Registration Act, 1908

Chapter VII
(Sections 21 and 22 (i) of the Act)
Description of Property
18.
The description of the 'Territorial Division' required by Section 21 of the Act shall, as far as
practicable give the following particulars:(a)the Registration District;(b)the Registration
Sub-District;(c)the taluk;(d)any well-known division of (c) such as a mootah, hoondah, khundum,
firka, magany, amsam; and(e)the village, hamlet or suburb in which the property referred to in a
registrable document is situated.
19.
If property is described in a document by specific reference to an instrument which has been already
registered or which a true copy has been filed under Section 65 or 66 in the Office in which the
document is presented for registration and if that instrument contains the particulars required by
Rule 18 and such a description of the property as is required by the rules in force, the description
need not be repeated in the document.
20.
Whenever any non-testamentary document presented for registration relates to land situate in any
local area in respect of which the Government have issued a rule under Section 22(1) requiring
description by reference to Government map or survey, the Registering Officer shall satisfy himself
that the land comprises of one or more entries in survey fields or sub-divisions the document
specifies number of each field or sub-division and that if the land has no separate number assigned
to it the document specifies the number assigned to the field or sub-division in which the land is
situated and further includes a description of the land sufficient for its identification.
20A. [ Copies of plans accompanying documents under Section 21, except
the plans or maps accompanying copies of notification presented for
registration under Rule 50-A of the rules framed under the Andhra Pradesh
(Andhra Area) Town Planning Act, 1920 (Act VII of 1920) shall not exceed the
size 37.50 cm x 26.67 cm.]
[Added by G.O. Ms. No. 189, dated 26.02.1969. ]Andhra Pradesh Rules Under the Registration Act, 1908

Chapter VIII
(Sections 19,21,22,28,29,32,40 and 52)
Registration and Examination of Document
21.
A Document relating to immovable property which is situate partly within and partly without the
areas to which the Indian Registration Act applies may be registered in the office of any Registering
Officer within whose jurisdiction any portion of the property is situate; but in such a case, the
certificate of registration shall show that the registration has been effected only as regards the
portion of the property which lies within the areas where the Registration Act is applicable.
22.
A Document relating to immovable property situated wholly outside India or outside the tracts to
which the Indian Registration Act applies may be registered by a Registering officer in Book 44 but
the presentant shall be warned by a note below the registration certificate that its registration does
not affect the right in the property itself.
23.
A document required to be registered under any enactment specified below may be registered by a
Registering Officer as any other document required to be registered under the Indian Registration
Act, 1908, but it shall be specified in the Registration Certificate that its registration cannot confer
any title or interest unless duly registered under the relevant enactments specified below:The
Societies Registration Act, 1860 (Central Act XXI of 1860), the Public Societies Registration Act,
1350-F (Hyderabad Act 1 of 1350 F) the Indian Christian Marriage Act, 1872 (Central Act XV of
1872), the Indian Patents and Designs Act, 1911 (Central Act II of 1911), the Indian Trade Unions
Act, 1926, (Central Act XVI of 1926), Trade Marks Act, 1940 (Central Act XXV of 1940), the Special
Marriage Act, 1954 (Central Act XLIII of 1954).
24.
A Registering Officer having jurisdiction to accept a document for registration at the time of its
presentation notwithstanding the fact that the village in which the property affected is situated has
been transferred from his jurisdiction subsequent to the presentation of the document but before
completion of its registration. But when the document affected immovable property memorandum
shall be sent, without levy of any fee, to the officer to whose jurisdiction the village has been
transferred for the purpose of being filed in file on Book I of that Office.When, however, after refusal
to register by a Registering Officer the village in question is transferred, whilst the document is on
appeal or in a suit before a Civil Court, to the jurisdiction of another Sub-Registrar, the document, ifAndhra Pradesh Rules Under the Registration Act, 1908

the Registrar or the Court orders that it shall be registered, shall be represented for registration to
the office to whose Sub-District the village has been transferred.
25.
(i)A document for registration other than a document forwarded under Section 89 shall be
presented in person with the fee payable therefor, direct to the Registering Officer and not to a clerk
or a peon.(ii)A document referred to in Section 89(2) may be presented through a messenger with a
covering letter signed by the Government Officer or other person concerned referred to in Section
88(1).(iii)A document shall not be accepted if transmitted by post.
26.
(i)Every document shall, before acceptance for registration, be examined by the Registering Officer
to ensure that all the requirements prescribed in the Act and in these rules have been complied with,
for instance:(a)that it has been presented in the proper office (Sections 28, 29, and 30);(b)that the
person is entitled to present it (Sections 32 and 40);(c)that if it is a non-testamentary document and
relates to immovable property, it contains a description of property sufficient to identify the same
and fulfils the requirements of Rules 18 to 20:(d)that if it is written in a language not commonly
used in the District and not understood by the Registering Officer it is accompanied by a true
translation into a language commonly used in the District and also by true copy (Section 19);(e)that
if it contains a map or plan, it is accompanied by true copies of such map or plan as required by
Section 21(4);(f)that it contains no unattested interlineations, blanks, erasures or alterations, which
in his opinion require to be attested as required by Section 20 (1);(g)that if the document is one
other than a will it has been presented within the time prescribed by Sections 23 to 26;(h)that it
bears the date of its execution and does not bear a date anterior to the date of purchase of stamp
papers and the document is written on a date subsequent to the date of presentation;(i)that if the
date is written in any document other than a will presented for registration after the death of the
testator according to both the British and the Indian calendars, these dates tally; and.(j)that if the
presentant is not personally known to the Registering Officer, he is accompanied by such identifying
witnesses with whose testimony the Registering Officer may be satisfied;(k)[(i) The registrating
officer shall ensure at the time of presentation for registration of cancellation deeds of previously
registered deed of conveyances on sale before him that such cancellation deeds are executed by all
the executant and claimant parties to the previously registered conveyance on sale and that such
cancellation deed is accompanied by a declaration showing mutual consent or orders of a competent
Civil or High Court or State or Central Government annulling the transaction contained in the
previously registered deed of conveyance on sale;] [Inserted by Notification No. R.R.1/2006,
Published in Andhra Pradesh Gazette R.S. to Part II, Extraordinary No. 18, Dated 29.11.2006.
]Provided that the registering officer shall dispense with the execution of cancellation deeds by
executant and claimant parties to the previously registered deeds of conveyances on sale before him
if the cancellation deed is executed by a Civil Judge or a Government Officer competent to execute
Government orders declaring the properties contained in the previously registered conveyance on
sale to be Government or Assigned or Endowment lands or properties not registerable by any
provision of law.Note: See Govt. Memo RC No. G1/10866/2006 dt.. 14-03-2008.(ii)Save in theAndhra Pradesh Rules Under the Registration Act, 1908

manner provided for above no cancellation deed of a previously registered deed of conveyance on
sale before him shall be accepted for presentation for registration.
27.
Each important interlineation, erasure or alteration occurring in a document shall whenever
possible, be caused to be noted or described at the foot of document and to be signed by the
executant before the document is accepted for registration. This course is however, unnecessary in
respect of a document executed solely by a public functionary as such or of a document received
under Section 89. In such cases it will suffice if the interlineation, erasure or alteration is attested by
the officer concerned.
28.
Every copy of a map or plan accompanying a document shall be certified to be a true copy and shall
be attested by the signature of the person executing the document or his duly authorised agent.
29.
When a document is presented for registration in duplicate, or triplicate Registering Officer shall
treat the duplicate and triplicate as such if they are exact reproductions of the original and bear the
same date. Should any discrepancy be detected, the presentant shall be required to reconcile it
before the document is accepted for registration. If the original contains a map or plan, a copy shall
be annexed to the duplicate and to the triplicate.
30.
(i)A document which relates to a land situated in a district or portion of a district to which the rules
framed by the Government under Section 22(1) have been made applicable shall, before it is
accepted for registration be checked with the survey numbers and sub-division in the subsidiary
indexes maintained under Rule 125 and also when necessary, with the settlement registers in order
that the Registering Officer may cause incorrect or fictitious numbers entered in the document to be
rectified.(ii)If a survey number or sub-division entered in a document is not found in the subsidiary
indexes or settlement registers the Registering Officer shall, if necessary, make a reference to the
Revenue Department.(iii)If the sub-divisions of a field are found in the subsidiary indexes or
settlement registers and the field is described in the document without any reference to any
sub-division, the document may be returned for rectification.
31.
(1)If there are no impediments such as those mentioned to the acceptance of a document for
registration or if the document is presented again after any such impediments have been removed,
the Registering Officer shall endorse on the document the date, the hour and the place ofAndhra Pradesh Rules Under the Registration Act, 1908

presentation and take the signature of the presenting party to such endorsement.(ii)If , however, any
of the impediments referred to above is discovered after the presentation endorsement has been
made on the document, the latter may be returned for correction or amendment, if the party so
desires with an endorsement to that effect. Should the document be presented again, a
representation endorsement shall be made.
32.
(i)If the period prescribed for presentation has elapsed, but the document is still admissible on
payment of a fine, the Registering Officer shall if he is a Sub-Registrar suspend its registration
pending the orders of the Registrar.(ii)If the document is chargeable with duty under the Indian
Stamp Act, 1899, and is not duly stamped, the Registering Officer shall impound it under Section 33
of that Act and forward it to the Collector, registration being suspended.(iii)Pending orders on such
reference to the Registrar or prior to sending a document to the Collector, the Registering Officer
may, however record the admission of the execution and the examination of witnesses, if any.
33.
If the executant of a document is in doubt about the proper stamp and consults a Registering Officer
on the subject before formal presentation, the required information may be given without
impounding the document. It should be explained to the executant at the same time that if he wishes
to obtain authoritative opinion, he must apply to the Collector under Section 31 of the Indian Stamp
Act, 1899.
34.
If a document is dutiable under the Andhra Court Fees and Suits Valuation Act, 1956, and is
unstamped or is insufficiently stamped, it shall be returned to the party presenting it (vide Section 5
of that Act) in order that the stamp duty or the deficiency in the stamp duty may be made
good.Minute Book
35.
Every Registering Officer shall maintain a 'Minute Book' in such a manner as the Inspector-General
may from time to time, prescribe and shall enter in his own hand a brief record of each day's
proceedings in respect of every document on which a presentation endorsement has been made and
which is neither admitted to registration nor refused registration on the day of presentation and also
record therein notes of such other proceedings as the Inspector-General may, from time to time,
prescribe. Such record shall be necessary:(a)when a document is returned for correction under Rule
31 (ii);(b)when a document is put aside pending appearance of parties and witnesses;(c)when a
document is returned not registered at the request of the party presenting it; and(d)when a sealed
cover containing a will is returned on the ground that it is not sealed or that it has not been
superscribed with the name of the testator and that of his agent (if any) and the nature of theAndhra Pradesh Rules Under the Registration Act, 1908

document (Section 42).Proceedings in respect of a will or authority to adopt presented under
Section 41(2) or of a document presented for registration after the death of the executant or the
executant of which dies before admitting execution or of a document impounded for insufficiency of
stamp duty shall be executed.
Chapter IX
[Sections 25 and 34]
Delay in Representation and Appearance
36.
(i)A Registering Officer may require that the date of execution shall be entered in a document
presented for registration wherever it is not found therein.(ii)The date of execution of a document is
the date on which it is signed by the party and the date on which a document bears at its head is not
necessary the date of its execution though it is prima facie so.(iii)The date on which a certificate of
sale by a Civil or Revenue Court was signed by the Court shall be taken as the date of execution for
registration purposes.(iv)An alteration in the date of execution of a document made ostensibly for
the purposes of evading payment of the penalty leviable under Sections 25 and 34 shall not be
recognised and the document shall be treated as having been executed on the date originally entered
therein.(v)If the date of execution is not stated or if it is altered or if the document bears an
impossible date or fictitious date anterior to the date of purchase of stamp on which the document
or any portion of it is written the document shall be refused registration if the correct date cannot be
ascertained:Provided that nothing in this sub-rule shall apply to wills presented after the death of
the testator.
37.
Application for registration on payment of fines under Sections 25 and 34 shall be in writing. A
statement recorded from the party concerned shall be regarded as equivalent to an application
under those sections.
38.
The fines for delays in presentation and appearance under Sections 25 and 34 shall be regulated as
follows:
When the delay does not exceed one week after the expiration of
time allowed for presentation or appearance.A fine equal to the registration
fee.
When the delay exceeds one week but does not exceed one calendar
month.A fine equal to twice the
registration feeAndhra Pradesh Rules Under the Registration Act, 1908

When the delay exceeds one month but does not exceed two
months.A fine equal to five times the
registration fee.
When the delay exceeds two months but does not exceed four
months.A fine equal to ten times the
registration fee.
Explanations: (1) The fine shall be levied in addition to the proper registration fee.(2)The term
registration fee as used in this rule does not include the fee for copying documents and
endorsements thereon or the fee payable for the registration under Section 33 or for filing a
translation under Section 19 or fee for copies and Memoranda of attendance at a private residence
or for the registration of a duplicate or triplicate.
39.
Whenever a fine for delay in appearance is levied on more occasions than one in respect of one and
the same document, the amount of the fine leviable on the second and subsequent occasions shall be
the difference, if any, between the total amount leviable upto the second or subsequent occasions
and the fine previously levied in respect of such document.
40.
(i)Whenever an application under Section 25 or Section 34 is lodged with Sub-Registrar, he shall
forward the same, whether he considers the reason for delay to be satisfactory or not, for the orders
of the Registrar but as laid down in Rule 32 (iii) there is no objection to his recording the admission
of execution on such a document before forwarding the application to the District
Registrar.(ii)When the District Registrar condones the delay either under Section 25(1) or under the
proviso to Section 34(1) and directs either the acceptance of the document for registration or its
registration as the case may be, the Sub-Registrar on receipt of orders to that effect from the District
Registrar shall make an endorsement on the document above the registration certificate in the
following form and close the same with his signature and date:"Acceptance for
registration/admission to registration was directed by the District Registrar o ............. of
.................... in his Order No. ............... dated ............. on payment of the fine of Rs .............. for a
delay of .............. under Section 25, Section 34 of the Indian Registration Act, 1908".Date:Signature
of the Sub-Registrar
Chapter X
[Sections 31, 33 and 38]
Attendance at Private Residence
41.
An application for attendance at a private residence shall be in writing and shall in all possible cases,
be signed by the person on whose behalf attendance is required.Andhra Pradesh Rules Under the Registration Act, 1908

42.
All documents must be presented by a person, entitled to present them, to a Registering Officer and
not to a Commissioner.
43.
A requisition for attendance at a private residence shall be complied with as early as possible. If
compliance would interfere with the regular business of the office or involve the closing of the office
and if the case does not fall under the proviso to Section 31, a Commission should, if practicable, be
issued. All cases of office partially or wholly on a working day in consequence of a private attendance
shall be reported to the Registrar with full statement of facts necessitating such a course.
44.
A District Registrar may attend at a private residence situated within the limits of his district even
though it may not lie within the Sub-District under his immediate charge; but a Sub-Registrar shall
not proceed out of his Sub-District for the purpose.
45.
(i)Persons exempt by law from personal appearance in Court, under the Code of Civil Procedure,
1908 are:(a)who, according to the customs and manners of the country, ought not to be compelled
to appear in public; and(b)persons of rank especially exempted by the Government.(ii)A list of
persons exempted under sub-rule (i) (b) shall be obtained by the Registrar from the High Court or
District Court and communicated to every Sub-Registrar in his District.(iii)When in the course of
attendance at a private residence the Registering Officer is required to record in respect of the same
document the admission of persons not entitled to the concession, the request may be complied
with.
46.
(i)A Commission issued under Section 33 or Section 38 shall be prepared in the form shown in
Appendix II and shall, when the person to be examined resides within the Sub-District, be
addressed ordinarily by the Registering Officer to one of his clerks. When the person to be examined
resides in another Sub-District, whether within the same District or in another District, the
Commission shall be directed to the Sub-Registrar of the latter Sub-District. The Sub-Registrar
receiving a Commission so addressed may, if he cannot attend personally, redirect it to any officer of
his establishment vide also Sections 75 and 76 of the Code of Civil Procedure, 1908.(ii)When the
Commission is for the examination of an executant, and has been executed the Commissioner shall
return the document to the office from which it was issued, endorsed as follows:"Having attended
the ............ at residence of A.B., sons of C.D. at ......... I have this day examined the said A.B. who
have been identified to my satisfaction by E.F.: sons of G.H. etc., residents of .......... and the saidAndhra Pradesh Rules Under the Registration Act, 1908

A.B., admitted (or denied) the execution of this document (or the voluntary execution of this Power
of Attorney).Left thumb-impression of ExecutantFull Signature of Executant Signatures of
Witnesses. Commissioner(iii)Where receipt of consideration is acknowledged before the
Commissioner, he shall add the following clause to this endorsement:"and acknowledged ..............
receipt of Rs. ............... (or goods to be specified) being consideration in whole (or in
part)".(iv)Where consideration is paid in the presence of the Commissioner, he shall add the
following to endorsement."I also certify that........... (or goods to be specified) were paid (or
delivered) in my presence to the said A.B. by ..........".The signature of the payer and payee shall also
be taken below this endorsement, provided in the specimen form in Appendix V"(v)on receiving the
Commissioner's report the Registering Officer shall, if satisfied as the execution of the document,
make the following endorsement below the report:"From the foregoing report I am satisfied that
this Document has been executed.Power of Attorney has been voluntarily executed, by the said
A.B."Date:Signature of Registering Officer.
47.
A Commissioner may examine witnesses in the same manner as a Registering Officer, and persons
who may be required to give evidence before a Commissioner and who refuse to do so shall be
subject to the penalties and punishments which they would incur for the same offence if committed
in a registration office.
48.
A Registering Officer may examine the Commissioner personally in his office touching any of the
circumstances connected with the discharge of his Commission, especially with reference to the
voluntary nature of the admission of execution.
Chapter XI
(Section 33)
Power of Attorney
49.
(i)When a Power of Attorney is executed before a Registering Officer he shall after satisfying himself
of the identity of the party and obtaining when necessary his left thumb impression against his
signature, authenticate it in the following form:"No ............ of ........... 19 ........."Executed in my
presence (at ............. x) this ............. day of .............. 19 .............. by A.B. who is personally known to
me (or whose identity is proved by (signature of) CD (with addition) and (signature of) E.F., (with
addition).SealSignature of Registering OfficerNote:To be filed in, when the execution takes places at
a place other than registration office, e.g. a private residence :(ii)When a Power of Attorney which
has not been executed before a Registering Officer is presented to him for authentication under the
proviso to Section 33 the Registering Officer shall, if he attends himself at the private residence ofAndhra Pradesh Rules Under the Registration Act, 1908

the principal or if the principal appears in the office behind a purda and is examined with the help of
hammamnee or mama; adopt the following form of authentication:"No. ............ of .............. 19
.........."I Certify that I have satisfied myself on examining at ............ this .......... day of ......... 19 .......
(signature of) A.B. (Who is purdanashin) lady with the aid of (signature of) C.D. hammamnee or
mama (with addition) that this power of attorney has been voluntarily executed by the said A.B. who
purports to be the principal and who is personally known to me or whose identity has been proved
by inspection behind the purdah by (signature of ) E.F. (with addition) who is her (relationship if
any to be stated) and (signature of) G.H. (with addition) who is her (relationship if any to be stated)
with whom she does not observe purdah.SealSignature of Registering Officer(iii)When a Power of
Attorney occupied more than one sheet of paper the number of the power of which the sheet forms a
part, the total number of sheets of which the power consists the number of the sheet, and the
signature and seal of the Registering Officer shall be endorsed on each sheet.(iv)Every
interlineation, blank, erasure or alteration in the body of a Power of Attorney which is authenticated
and not registered shall, at the time of authentication, be detailed in a footnote added to the
document below the endorsement of authentication and shall be signed by the Registering Officer
even if the party himself has entered a similar note in the document. If there are no interlineations,
blanks or erasures or alterations, in the body the fact shall be noted.Interlineations, etc., in the
authentication endorsement shall be initialled by the Registering Officer.Note: In entering notes of
interlineations etc., the instructions in Rule 96 (ii) shall apply mutatis mutandis.
50.
(i)If a document is presented for registration under a special Power of Attorney the power shall be
retained and filed in the office with following endorsement:"No. ........ of ........ 19 ......."Presented
with document No .......... of 19.......... of Book Volume ......... Pages ............Date:Signature of
Registering Officer.(ii)If a document is presented for registration under a General Power of
Attorney, the power shall be returned with the following endorsement:Presented with document No
........ of 19 .......... Book ........ volume ..........Date:Signature of Registering Officer(iii)When a
document is presented for registration by a person entitled to present it and execution is admitted
by an agent under Power of Attorney, the following endorsement shall be made on the power, which
shall be retained and filed or returned, according as it is a special or a general power."No ......... of
........ 19 ........... "Presented in connection with document No. ...... of 19 ........ of Book ....... Volume
.......... Pages ............Dated:Signature of Registering OfficerNote: Numbers required only in the case
of a special power.
51.
The endorsements prescribed in Rules 49 and 50 shall be written in English:Provided that such
Sub-Registrars as are specially authorised by the Inspector-General may write the endorsement in
the language commonly used in the Sub-District.Andhra Pradesh Rules Under the Registration Act, 1908

52.
A Power-of-Attorney may be brought to a Registering Officer (1) for authentication or (2) for
registration, or (3) for both authentication and registration. In the first case he shall merely make
the entry prescribed for authentication; in the second case, he shall register the power in the same
manner as any other document, and in the third case, he shall first authenticate the power and then
admit it to registration in the usual manner.
53.
Although a Power of Attorney may be registered like any other instrument, it is not valid for
registration purposes unless authenticated. When a Power of Attorney is brought to a Registering
Officer by a person who does not understand the distinction between authentication and
registration, the Registering Officer should explain the difference to him and give him such
information as may be necessary.
54.
A Registering Officer is authorised to authenticate a Power of Attorney executed for registration
purpose only. He shall refuse to authenticate a power entirely unconnected with registration.
55.
(i)An abstract in the form printed in Appendix-III shall be retained of each Power of Attorney
authenticated by Registering Officer whether such power is General or Special, registered or not
registered. The abstract shall be signed by the Registering Officer; and shall be filed in a separate file
with a serial number along with other powers retained under Rule 50. The notes of interlineation,
blank, erasures and alterations made by the Registering Officer on the original power shall be copied
verbatim in the distinct.(ii)(a)Each Registering Officer shall maintain a register of all revocations of
Powers of Attorney registered in or communicated to it.(b)When notice of a revocation is given to a
Registering Officer he shall send an intimation of the same to such other officers as may be specified
by the person revoking the power.
Chapter XII
[Section 35]
Examination of Parties  Executing Parties
56.
(i)The expression "A person executing a document" shall be held to include;(a)any person who
becomes surety for the repayment of a loan or the fulfilment of a contract and in the capacity affixesAndhra Pradesh Rules Under the Registration Act, 1908

his signature to a document;(b)any person who endorses a negotiable document:(c)any person who
signs a receipt or a discharge endorsed on a document;(d)any person who signs a document as an
executant in token of his assent to the transaction and not merely as a witness, even though may not
be described as an executant in the body of the document.(ii)In the case of a document purporting to
be executed by an attorney, or by a guardian of a minor, or by a legal curator of an idiot or lunatic,
such attorney or guardian or curator shall be held to be a person executing the document for the
purposes of Sections 32, 34, 35 and 58 but for the purposes of Section 55, the principal or minor or
idiot or lunatic as well as the attorney or guardian or curator shall be considered to be the executing
parties.Executing Party: Any person who affixes his signature to a document in token of his assent to
the terms of the document.Enquiry before Registration
57.
As a general rule registration shall take place in public, but the Registering Officer may, on the
application of a party, and if he considers such a course to be called for, exclude the public during
the course of any enquiry.
58.
It forms no part of a Registering Officer's duty to enquire into the validity of a document brought to
him for registration or to attend to any written or verbal protest against the registration of a
document based on the ground that the executing party had no right to execute the document; but
he is bound to consider objections raised on any of the grounds stated below:(a)that the parties
appearing or about to appear before him are not the persons they profess to be;(b)that the document
is forged;(c)that the person appearing as a representative, assign or agent, has no right to appear in
that capacity;(d)that the executing party is not really dead as alleged by the party applying for
registration; or(e)that the executing party is a minor or an idiot or a lunatic.
59.
The term "representative" as used in the Act includes not only the guardian of a minor and the
curator of an idiot or a lunatic but also the executors, administrators and heirs of a deceased person.
Satisfactory proof of the right of a person to appear in any of these capacities shall be adduced
before he is permitted to present a document or to admit or deny its execution.
60.
A Registering Officer should form his own opinion as to whether a party appearing before him as
executant of document is a minor, a lunatic or an idiot. He is not expected to hold an elaborate
enquiry although, if he so desires, he may examine on the point any one present in the office.Andhra Pradesh Rules Under the Registration Act, 1908

61.
When (i) a non-testamentary document is presented for registration after the death of the executant
or (ii) the executant dies after presentation of a document by the claimant or his representative,
assign or agent and before admission of execution, the Registering Officer shall ascertain by
examining the presentant and the witnesses accompanying him who the representatives or assigns
of the executant are and refer, if he considers it necessary, to the village officer for information on
this point. If any of the persons ascertained to be representatives or assigns of the deceased
executant are present in the office at the time of presentation of the document in case (i) or on the
day fixed for the appearance of the executant in case (ii) and if the Registering Officer is satisfied of
their representative character, he shall examine them on that day in regard to the execution of the
document by the deceased. A day shall then be fixed for the appearance of any other persons
claiming to be representatives or assigns for examination in connection with the document and
summons shall be issued to such of the ascertained representatives as have not yet been examined.
A notice of the fact or the intended enquiry shall be posted in the office premises and on the
chavadies of the munsifs of the village in which the deceased resided and of the village or villages
where the property affected by the document is situated and shall be proclaimed by a carrier in
those villages. The cost of the service of the notice shall be levied the person who presented the
document for registration.If the persons already examined as representatives have admitted
execution and if on the notified day the persons summoned appear and admit execution and if any
other person claiming to be a representative or assign who may appear on that day admits
execution, or if persons claiming to be representatives or assigns have already appeared and have
admitted execution and no representatives appear on that day fixed as aforesaid the document shall
be registered as regards the deceased executant. But if some of the representatives admit execution
and other deny it, or if any representative or assign of whose right to appear as such the Registering
Officer is satisfied deny execution or wilfully avoid appearance the document shall, where the
Registering Officer is a Sub-Registrar, be refused registration as regards the deceased executant. A
Registrar in such a case will proceed under Sections 74 to 76.
62.
A document executed by a person who is unable to read shall be read out and if necessary, explained
to him. A document written in a language not understood by the executing party shall, in like
manner be interpreted to him. When a party to be examined is dumb, recourse must be had to the
means by which he makes himself understood.Identification of Parties
63.
(i)A Registering Officer may require any executant, claimant, or identifying or other witness
regarding whose identity he has to satisfy himself but who is not personally known to him to affix in
his presence, whether such person can write his name or not, the impression of bulb of his left
thumb both in the register of thumb impressions maintained in each registration office in the form
shown in Appendix-IV as well as on the document presented for registration.(ii)Such impression
shall invariable be taken in the case of marksman and illiterate females.(iii)A messenger presentingAndhra Pradesh Rules Under the Registration Act, 1908

a document under Rule 25 (ii) shall not be required to prove his identity but shall, unless known
personally to the Registering Officer, be required to sign and affix his thumb impression to the
endorsement of presentation.
64.
If the left thumb does not give a clear impression or is non-existent, the impression of any finger of
the left hand shall be obtained. Failing this, the impression of the right thumb, or if that also is non
existent or deformed of any finger of the right hand, shall be taken. In all cases the digit and the
hand used shall be specified next to each impression taken on the document, and in cases where a
digit other then the left thumb is used the digit form which the impression is taken and the hand
shall be specified below the impression in the thumb impression register with a note explaining why
the impression of that particular digit was taken.
65.
Thumb impression shall be dispensed within the case of a person suffering from leprosy or
contagious disease. In such cases a note should be entered in the register of thumb impression
explaining the circumstances under which it has not been obtained.
66.
The signature of every person shall be taken next to his impression. The Registering Officer himself
shall in the case of a marksman write the name against the mark. He shall add below each signature
or mark his initials and the date which the impression is taken.
67.
The Registering Officer shall add a certificate at the foot of each page of the thumb impression
register to the effect that each impression on the page has been affixed in his presence and under his
supervision by the person whose name is entered next to it. This Certificate shall be signed and
dated by the registering Officer when the page is closed.
68.
In the case of a purdahnashin lady who does not appear before a Registering Officer and whose
examination in connected with the registration of a document or the attestation of a Power of
Attorney is conducted in the officer through a hammamnee or mama the finger impression shall be
taken by the hammamnee or mama who shall be clearly instructed as at altered as show below."Each
impression on this page excepting of which was taken by a hammamnee or mama under my
Instruction, has been affixed in my presence, etc."Andhra Pradesh Rules Under the Registration Act, 1908

69.
A separate register shall be maintained in each registry officer for the thumb impression obtained in
connection with the registration of document at private residence. Neither this register nor the
ordinary register of thumb impression shall be taken with him by a Registering Officer when
attending at a private residence, but thumb impressions at such residences shall be obtained on
separate slips of paper and the slips shall be pasted with the initials and date of the Registering
Officer added to them in the appropriate page in the separate impression register. The slip shall
contain a certificate in the following form :"The impressions on this slip or each impression on this
slip was affixed in my presence and under my personal supervision by the person whose name is
entered next to it."In the case of purdahnashin lady who dose not appear before the registering
Officer, the words "taken under my instructions form" shall be substitution form the words "affixed
in my presence and under my personal supervision by" in this certificate.
Chapter XIII
(Sections 36, 37 and 39)
Enforcement of Appearance of Executants and Witnesses
70.
All District Registrars and sub- Registrars may themselves issue processes in compliance with
requisitions for summons made to them.
Chapter XIV
(Sections 40 and 41 of the Act)
Wills and Authorities to Adopt
71.
When a will or an authority to adopt is presented for registration after the death of the testator or
the donor, the Registering Officer shall fix a day for the enquiry contemplated by Section 41(2) and
shall cause notice of the enquiry (a) to be served on the persons to whom in his opinion special
notice should be given, (b) to be pasted in a conspicuous part of registration office, and (c) to be
published (i) in a daily newspaper, published in the principal language of the District and having
wide circulation in the District in which the testator or donor lived (ii) in such a daily newspaper
having vide circulation in the District in which the property of the deceased is situated and (iii) in
the villages where the testator or donor lived, where interested parties may reside and where the
property of the deceased is situated.[The cost of the service of the notice and of its publication in the
concerned village shall be levied in advance from the person who presents the document for
registration. The intended notice of enquiry shall be prepared in the registration office concernedAndhra Pradesh Rules Under the Registration Act, 1908

and entrusted to the presentation of the will for getting it published in the concerned daily
newspaper and for filing a copy thereof after publication.][Amended by G.O.Ms.No. 1214, Revenue,
dated 10.08.1965. Published in Andhra Pradesh Gazette and G.O.Ms.No. 1044, Revenue, dated
02.09.1966. ]Registration of Wills etc.
72.
If a person presenting a will or an authority to adopt, or a person who objects to registration of such
a document on the ground that it was not executed by the testator or donor or that the testator or
donor is not dead or that the person presenting the document is not entitled to present the same
under Section 40, desires the witnesses should be summoned, the request shall be complied with
and the procedure prescribed in Chapter XIII shall be followed.
73.
(i)As each person is examined his signature shall be obtained on the document below the
endorsement of presentation in the following form:The witnesses whose signatures are affixed
below have been examined under Clause (2) of Section 41 of the Indian Registration Act, 1908, in
reference to the document:(Impression)Signature of E.F. with addition.(Impression)Signature of
G.H. with addition.(Impression)Signature of I.J. with addition.
27th. January, 19 ............
Signature of Registering Officer(Impression)Signature of K.L. with addition.(Impression)Signature
of M.N. with addition.(Impression)Signature of O.P. with addition.
28th. January, 19 ......
Signature of Registering Officer.(Impression)Signature of Q.R. with addition.(Impression)Signature
of S.T. with addition.
6th. February, 19 ......
Signature of Registering Officer.(ii)If, after the conclusion of the examination of the witnesses, the
Registering Officer should decide to register the document, an endorsement in the following form
shall be made on it and its registration shall be completed:I am satisfied from the witnesses whose
signatures appear above:(a)That the will (or authority to adopt) was executed by the testator (or
donor).(b)That the testator (or donor) is dead; and(c)That the person presenting the will (or
authority to adopt) is entitled to present the same.Date:Signature of Returning Officer.(iii)Should
the Registering Officer decide to refuse registration, the usual endorsement of refusal shall be
entered on the document.Andhra Pradesh Rules Under the Registration Act, 1908

74.
(i)A Registering Officer when enquiring under Section 41 (2) into the execution of a will or of an
authority to adopt shall invariably, before registering the document or refusing registration prepare
and place on record a memorandum containing a summary of the evidence and the reasons for
registration or refusal, as the case may be. A copy of any such memorandum prepared by a
Sub-Registrar shall be submitted to the District Registrar forthwith.(ii)When a will or an authority
to adopt is refused registration the refusal order to be entered in Book 2 shall be a reproduction of
the memorandum.
75.
A will or an authority to adopt presented for registration after the death of the testator or donor may
be returned to the presentant unregistered, if he so desires, unless it appears that the document is
forged.
76.
A revocation or cancellation of a will or of an authority to adopt shall be treated as a document of
testamentary character and shall be registered in Book 3.
77.
(i)Wills registered or refused in sub-Registrar's Office which remain unclaimed for a period of over
two years shall be forwarded to the Registrar's Office for safe custody, a note to that effect being
entered against the original entry in the office returns.(ii)If the person entitled to claim the return of
a will applies to a Sub-Registrar for it return after the document has been transmitted to the
Registrar's Office, should be advised to obtain it from the Registrar direct. If he is unwilling to do so,
the will should be obtained from the Registrar by the Sub-Registrar and returned to the person and
a note of its receipt from the Registrar's Office and return to the person shall be entered in the office
returns.
Chapter XV
(Sections 42 to 46 of the Act)
Sealed Covers containing Wills
78.
(i)Every entry made under Section 43 in Book 5 shall be dated and signed by the Registrar:(ii)When
a sealed cover is withdrawn under Section 44, the entry relating to the withdrawal shall be signed by
the person by whom the withdrawal is made as well as by the Registrar.Andhra Pradesh Rules Under the Registration Act, 1908

79.
When a will executed by two persons jointly is deposited under Section 42 by both of them in a
sealed cover, a request by one of the testators for withdrawal, of the sealed cover, after the death of
the other testator shall not be complied with. The Registrar may, however after procuring
satisfactory evidence as to the fact of the death, require the applicant to present an application
under Section 45 for the opening of the cover and the copying, at the applicant's expense, of the will
in Book 3. He may then grant the applicant a copy of the will, if the applicant so desires.
80.
(i)Wills sent by post to a Registering Officer are not presented for registration or deposited within
the meaning of the Act and Sections 42 to 46 are therefore inapplicable to them.(ii)If a cover
purporting to contain a will reaches a Registrar by post, he shall return it unopened. Should the
cover however be retained in the office because the address of the person to whom it should be
returned is unknown, the Registrar shall record upon the cover of the date of receipt and the facts
that it was received by post and that it has not been secured under the Act as the terms thereof have
not been complied with.(iii)A will so received shall not be delivered to applicant unless the Registrar
is satisfied that such applicant is duly authorised to receive it, nor shall the cover be opened on an
application under Section 45, as it has been deposited according to the provisions of Section
42.(iv)A cover purporting to contain a will which may reach a Sub-Registrar by post shall be
returned to the sender or, if the address of the sender is not known, shall be forwarded with full
particulars to the Registrar who shall deal with under Clause (ii) of this rule.(v)A register shall be
maintained in each Registrar's office showing the sealed covers received, withdrawn, opened, and
sent to be received from court from time to time. In it shall also be entered wills received by post by
District Registrar and retained in the office under Clause (ii), wills forwarded by Sub-Registrars
under Clause (iv) and under Rule 77 (i) and wills registered or refused registration in the Registrar's
Office and lying unclaimed for over two years.(vi)An officer assuming charge of a Registrar's Office,
either permanently or temporarily, shall compare the sealed covers and wills with the entries in
Book 5 and in the register prescribed in Clause (v) and shall report to the Inspector-General whether
they are correct and whether the covers are preserved properly.
81.
(i)When a sealed cover containing a will is opened under Section 45, the following endorsement,
shall be made on the will:"Having satisfied myself that the testator thereof is dead, the sealed cover
containing this will is opened on the application and in the presence of (Signature and addition) this
.......... day of ........... 19 ................Signature of RegistrarThis will had been copied in Book 3 as No
.......... of 19 ............. Volume .......... Pages ........
Date: Seal Signature of Registrar.
(ii)When a sealed cover containing a will is opened under an order of a Court and copied in Register
Book 3 under Section 46, the fact shall be noted in Register Book 5 in the column headed "numberAndhra Pradesh Rules Under the Registration Act, 1908

of documents in Book 3" and the following endorsement shall be made on the will itself:Opened and
copied in Book 3 as No. of ...... 19 ....... Volume ..... Page ....... and forwarded to the Court, pursuant
to the order of the Court dated 19 ..........
Date: Seal Signature of Registrar.
82.
When a will is opened and forwarded to the Court it shall be accompanied by a memorandum
intimating the fee payable for opening the cover and the charges for copying it, so that these may be
collected by the Court and remitted to the Registrar. An acknowledgement of the receipt by the
Court of the cover or will shall also be obtained and filed in the office.
83.
When a citation is issued by a Court to produce or forward a will deposited with the Registrar under
Section 43 it shall be sent either through a clerk in a sealed cover, provided that no payment of
travelling allowance to the clerk is involved, or be forwarded by registered post insured for not less
than Rs. 1,000 addressed to the officer presiding over the Court or to the Registrar's Office on the
original side of the High Court of Judicature, at Hyderabad, as the case may be.
84.
When a sealed cover containing a will is opened, the cover which contains the depositor's
superscriptions and the Registrar's endorsements shall be preserved carefully or a record
maintained as to its disposal.
Chapter XVI
(Sections 52, 58, 59 and 60)
Endorsements and Certificates
85.
(1)The endorsement prescribed by Sections 52 and 58 and the certificate prescribed by Section 60
shall be written by the Registering Officer himself in the form prescribed in Appendix V or as near
thereto as circumstances permit, unless he has been specially authorised by the Inspector-General to
use an endorsement stamp.(ii)The executant and the witnesses may be required to write their
additions themselves in the endorsements made on documents, when they are able to do so.(iii)The
name and addition of a party who is required to sign in the endorsements but who is not able to do
so shall be written by the Registering Officer himself. Where the addition is entered by the party
himself (Clause ii) the Registering Officer shall satisfy himself that the addition as entered is
complete and that it corresponds with the statement made by the party.(iv)The blank spaces in the
endorsement stamps referred to in Clause (i) shall be filled in and the endorsements and certificatesAndhra Pradesh Rules Under the Registration Act, 1908

shall be signed by the Registering Officer in his own hand.
86.
An executing party shall be required to use the same language in signing the endorsement of
admission of execution as he had used in signing the instrument.
87.
All Registering Officers in the State shall write the endorsements and certificates in Telugu whether
a document presented for registration be in Telugu or in a language of the State.
88.
If there is no sufficient blank space in the instrument for the endorsements and certificates, they
may be entered on a separate slip or sheet of paper which shall be attached to the document and a
note of the fact shall be made on the document itself and signed by the Registering Officer.
89.
When a document occupied more than one sheet of paper the number of documents of which the
sheet forms a part, the total number of sheets of which the document consists, the number of the
sheets and the seal and signature of the Registering Officer shall be endorsed on each sheet.
90.
The entry 'identified by' shall be made by the Registering Officer above the signature of witnesses
examined for purposes of identification, and the entry witnesses who are examined above the
signatures of witnesses who are examined for any other purposes, when an executant is a
purdahnashin lady and is examined through a Hammamnee or Mama, a special form of
endorsement as shown below shall be made by the Registering Officer and the signature of
Hammamnee or Mama shall be obtained on the document as a witness after the Registering Officer
has recorded a deposition from her with reference to the duty she has performed."Identified, by
inspection behind the purdah, by A.B. (signature with additions) who is her (relationship to be
stated) and by C.D. (signature with additions..........)"
91.
When a document is executed by a person as a guardian or agent he shall be described as such in the
registration endorsement.Andhra Pradesh Rules Under the Registration Act, 1908

92.
(i)When a person executes a document both for himself and as agent or guardian of a minor, and an
idiot or a lunatic, the registration endorsement shall contain two distinct signatures, one for
admission of execution by the person himself and other for admission as agent or guardian.(ii)When
there are more persons than one under the guardianship of a single person the registration
endorsement need contain only one signature on behalf of all such persons, but all their names shall
be specified.
93.
(i)When the presentation and admission of execution of a document are made by an agent under a
Power of Attorney reference to the authority under which the Agent acts shall be given in the
endorsement of admission of execution, the fact that the presenting party is an agent being entered
after his signature below the endorsement of presentation.Where, however, the presentation alone
is made by such an agent, such reference shall be given in the endorsement of presentation
itself.(ii)The endorsement of presentation made on a document, presented under Rule 25 (ii) shall
mention the number and date of the covering letter with which it is presented and the designation of
the Government Officer or other person concerned.
94.
(i)When the amount of consideration mentioned in a document presented for registration is paid
before the Registering Officer the signatures of the payer and of the payee shall be obtained below
the endorsement of payment.(ii)When consideration is paid before the Registering Officer in
currency notes or Bank draft or cheque and any party to the transaction desires that the numbers of
such notes, draft or cheque shall be noted in the endorsement, the request shall be complied
with.(iii)When money is paid on behalf of the claimant by his agent, messenger or servant, the
words "on behalf of the claimant" with the name of the claimant shall be added after the name of the
payer in the endorsement.
95.
The certificate of registration shall be added by the Registering Officer only after the document has
been copied and the entry compared.
96.
(i)In the case of a document presented for registration in duplicate or triplicate, the duplicate and
triplicate shall be examined with the original and shall bear the following additional
endorsement:Duplicate (or triplicate)Difference between the original and the duplicate(or
triplicate)blanks, alterations and erasures in this.Compared byReaderExaminerDate :SignatureA
note shall be entered below the Certificate of Registration on the original as regards the number ofAndhra Pradesh Rules Under the Registration Act, 1908

copies registered with the original and signed by the Registering Officer.(ii)In entering notes of
interlineations, blanks, alterations and erasures on the duplicate and triplicate, the particular letter
or word or figure interlineated, altered or erased shall be specified, e.g. in line 12, the word
'currency' interlineated "letter 'a' or figure '2' altered in line 10 the word 'money' erased and so
on.When an erased letter or word cannot be deciphered, the note shall run as follows:"A word
occurring after 'the' in line 5 erased"(iii)Each duplicate or triplicate of a document presented for
registration shall bear the same endorsement as the original document and the same registration
number. The certificate of registration on the original and on the duplicate or triplicate shall
mention all the pages of the volume occupied by the entries which relate to the original and the
duplicate.
97.
(i)A document which is partially registered as regards some of its executants and refused as regards
others shall have two distinct endorsements the one of admission signed by such of the executants
as admit execution, and the other refusal being written below the seal and signature affixed to the
certificate or partial registration and signed and dated by the Registering Officer.(ii)Similarly a
document affecting property wholly situated within the areas to which the Indian Registration Act,
1908 applies but registered as regards a portion only of such property and refused as regards the
other portion shall bear two distinct endorsements one of registration and the other of refusal in the
form shown in Appendix-V.
98.
The signatures of witnesses examined in the course of an enquiry before a Registrar under Section
74 whether in reference to an appeal case or as regards a document, the execution of which has been
denied before him, need not be endorsed on the document in respect of which the enquiry is made.
99.
When a document is registered by a Registrar after enquiry under Section 74, the following note
shall be endorsed on it, in lieu of the endorsement of admission of execution:I am satisfied from the
evidence adduced in the enquiry held under Section 74 of the Registration Act that the document
was executed by A.B.Date :Signature of Registrar:
100.
An endorsement made on a document presented for registration under an order of Registrar or a
Court shall quote the number and date of the order under which it is represented.Andhra Pradesh Rules Under the Registration Act, 1908

100A.
The Registering Officers shall use sakea era dates along with the Gregorian Calendar dates in the
endorsements and certificates required to be added by them under the provisions of the Indian
Registration Act, 1908 and the rules made thereunder.
Chapter XVII
(Sections 53 and 61)
Receipts for Documents and for Fees and Return of Documents
101.
(i)A receipt shall be granted for each document presented for registration, for each Power of
Attorney presented for authentication and for each sealed cover deposited and for every fee or fine
levied by a Registering Officer.(ii)An application for transfer of revenue registry presented with a
document shall be acknowledged in the receipt, for the document.(iii)When the fees consist of
several items, each item, shall be separately entered both in the receipt and in the counterfoil so as
to admit of any overcharge being traced. In the case of copying fees the number of words shall be
entered and in the case of mileage, the number of miles.
102.
The receipt for a document shall be handed over to the person presenting the document or to his
nominee, after obtaining in the counterfoil the signature of presentant, if he is literate or thumb
impression if he is illiterate to the endorsement of nomination, and also the signature of the
nominee, if he can write, or his thumb impression if he is illiterate, for the purpose of comparison
when the nominee appears to take back the document.
103.
(i)If a document is ready for transcription on the day of its presentation, the day and hour when it
will be ready for return shall be endorsed on the receipt In the case of a document retained pending
an enquiry or a reference, the day and hour shall be communicated to the presentant or his nominee
by a separate notice issued on the day when the document becomes ready for transcription. If,
however in the latter case receipt is produced on the day when the document is ready for transaction
and the document cannot be returned on that day, the information may be endorsed on the receipt
itself.(ii)When a document is not ready for return on the date entered on the receipt or in the notice,
the entry of that day shall if the receipt or notice is produced before the Registering Officer, be
cancelled and the probable later date on which the document will be ready shall be entered under
the initials of the Registering Officer.(iii)Corresponding entries and corrections shall be made in
counterfoil.Andhra Pradesh Rules Under the Registration Act, 1908

104.
A document shall, if possible, be returned on the date of its admission to registration.
105.
In order to obtain delivery of a document the person entitled to claim back the same shall produce
the receipt, and the Registering Officer shall thereupon obtain his signature or thumb impression, as
the case may be to the acknowledgement in the counterfoil and return both document and the
receipt after endorsing on the date of its return and initiating this entry. A person entitled to claim
back a document who is known to the Registering Officer may obtain the return of a document by
sending the receipt to the Registering Officer through a messenger with a requisition endorsed on
the receipt and signed by himself for the delivery of the document to the messenger. The specimen
signature of the messenger shall be affixed to such endorsement and attested by the said person.
The document may then be handed over to the messenger after his acknowledgment and thumb
impression have been taken in the counterfoil of the receipt, the receipt being retained in the Office
and pasted on the counterfoil.
106.
In the event of a receipt being lost, the person who should have produced it may receive the
document on making and signing on the counterfoil, a declaration of the loss and, if required by the
registering officer, affixing his thumb-impression thereto.
107.
When a nominee fails to take back a document within seven days from the date of the receipt as that
on which it will be ready for delivery the nomination may be revoked by the person by whom it was
made by an entry signed by him to that effect in the counterfoil.
108.
When a party to a document objects to its being returned to a person in whose favour the receipt has
been drawn up, the objection shall not be allowed to prevail unless such party can satisfy the
Registering Officer that he has applied to competent Court for an injunction to restrain the
Registering Officer from returning the document.
109.
When an impounded document is received back from the Collector after adjudication of the stamp
duty, the Registering Officer shall immediately give notice in writing to the presentant or to the
person authorised by the presentant to take delivery of the document either to take steps to
complete the registration of the document or to take delivery of the document.Andhra Pradesh Rules Under the Registration Act, 1908

110.
When proceeding to attend at a private residence the receipt book shall not be taken by the
Registering Officer, but the requisite receipt may be detached from the counter-foil for issue to the
party concerned, the entries in the counter-foil being made after return of the Registering Officer to
his office. In such a case any nomination to take delivery of a document shall be obtained on a slip
which shall be initialled and dated by the Registering Officer and pasted on the counter-foil.
111.
These rules do not contemplate the return of a document by post, but a document may be so
returned if a presentant or his nominee desires this course to be followed, and at his own risk,
subject to the conditions mentioned below:(i)The presentant or his nominee shall sign an
endorsement on the counter-foil of the receipt authorising the return of the document or documents
by registered post to an address to be specified and shall deposit therefor, (a) the actual cost or
postage, the postal registration fee, and the fee for obtaining the acknowledgement of the addressee
and (b) a fixed sum of ten naya paise to meet the incidental charges such as stationery for the covers
used, etc.(ii)The amount paid shall be included in the receipt granted to the party;(iii)When
registration has been completed, the Registering Officer shall despatch the document or documents
in a sealed cover under registered service postage to the address specified and shall note the fact on
the counter-foil of the receipt;(iv)The acknowledgement of the addressee shall be pasted to the
counter-foil.
Chapter XVIII
(Section 52)
Register Books
112.
The registers shall be maintained in accordance with such instructions as the Inspector-General of
Registration may from time to time prescribe, provided that no erasure shall be permitted and that
every page shall contain a uniform number of lines.
113.
Every entry of a registered document shall be an exact copy of the original.
114.
When a document is presented for registration in duplicate or triplicate, it shall not be necessary to
enter the document more than once in the register book.Andhra Pradesh Rules Under the Registration Act, 1908

115.
[(i) With the previous sanction of the Inspector General a special volume of Register Book-I or of
Book-4 in the form of a file book, with numbered butts, may be opened in any office, for the
registration of documents which are prepared on forms printed on such paper and in such form, as
may be approved by the Inspector General:Provided that the Inspector General may cause
standardisation of forms for any class of documents and prescribe, the price from time to time at
which they shall be supplied.][Substituted by G.O. Ms. No. 381, Revenue (Registration-I) Dated
1995, w.e.f. 2-8-1995. Published on Andhra Pradesh Gazette No. 4 of RS to Part - I, Dated
31.8.1995.](ii)The copy of each document shall be made by the registering staff by filling in the
blanks in a spare copy of the printed form, and on this spare copy the endorsement and the
certificate of registration entered on the original document shall be copied and the prescribed
footnotes shall be added.(iii)The copy thus prepared shall be duly examined in the manner in which
copies made by hand in the ordinary register books are required to be examined and shall be filed in
the file book mentioned in sub-rule (j).When a map or plan is attached to a document a copy of the
map or plan shall be filed in the same files as the document.(iv)After it has been so filed, the
Registering Officer shall authenticate the copy by his signature, with date and shall also affix to it
the seal of his office. He shall write his signature and affix the seal in such a manner that the
signature and the impression of the seal shall appear partly upon the butt and partly upon the sheet
pasted thereto;(v)When a copy consists of more than one sheet each sheet shall be pasted to a
separate butt and the Registering Officer shall endorse on it the number of the sheet and the
number of the document of which it forms part and shall affix his signature, with date and the seal
of his office to such endorsement in the manner laid down in sub-rule (iv) the seal being dispensed
with in the case of the sheet on which the authentication seal has already been
affixed.(vi)Documents registrable in Book 1 and Book 4 shall be filled in separate file
books.(vii)Each file book shall be assigned a serial number in the series assigned to ordinary
volumes of register books.(viii)Every document accepted for registration under sub-rule (i) shall be
numbered in the same series as documents copied in the ordinary register books.(ix)When a
document is registered under this rule a note of its registration in the file book shall be entered in
the register book in which it would otherwise have been registered thus : Note: Filed in file book,
Volume ..........(x)The file books shall be kept in the personal custody of the Registering Officer until
they are completely filled when they shall be placed among other completed volumes of register
books.
116.
No document shall be returned to a party before the entry of it in the register has been authenticated
by the Registering Officer.
117.
A rectification deed or a cancellation shall be registered in the same class of register book as that in
which the original document which it cancels or rectifies has been registered.Andhra Pradesh Rules Under the Registration Act, 1908

118.
(a)On the registration of a document which revokes, or cancels or rectifies an error in, or modifies
the terms of, a document previously registered in the same class of register book or of lands
acquired under the Land Acquisition Act or of a document received and filed under Section 89 (vide
Rule 13 supra), or on the receipt of a communication from a Revenue Officer or from a court which
intimates a similar revocation cancellation, rectification or modification, a note shall be entered at
foot of the entry of the later document or communication as under:
This documentrevokes (cancels, rectifies or modifies)Communication
 Document No. if copied the document filedat pagesthereturn filed
Volume Book of file Book
 File Book I
and at foot of the previous entry of the document previously registered or filed a note shall be
entered as shown below:
This Document
 Documenthas been revoked - cancelledreturn
 rectifies or modifies by theDocument No.documentfiled copiedthe return filed
Volume Bookof File Book
 File Book I
(b)When the revocation, cancellation, rectification or modification is of a document relating to
immovable property, a corresponding note shall also be entered in Index No. II and when it relates
to the rectification of any particulars entered in Indexes I, II, III or IV, a note of rectification shall
also be entered in the respective index as against the particular item rectified.
119.
If a registered document is declared by a Court to be a forgery or to have been registered under an
admission made by a person who falsely personated the executant, a note calling attention to the
fact shall be entered at the foot of the entry in the register and when practicable on the document.
Chapter XIX
(Sections 54 to 56)
Preparation of Indexes
120.
Indexes Nos. I, II, III and IV, shall be prepared on loose sheets lettered alphabetically and shall
contain the particulars shown in Appendix VI-a fresh set of sheets being used for each calendar year.
In Registrar's offices and Sub-Offices situated at the head-quarters of a District, they shall beAndhra Pradesh Rules Under the Registration Act, 1908

prepared in English. In other Sub-Offices they shall be prepared in the language of the Sub-District
unless the previous sanction of the Inspector-General has been obtained for their preparation in
another language or in English. No alteration in the language shall be made during the course of a
calendar year.
121.
The names of all persons executing documents shall be entered in one column and the names of all
persons claiming under documents in another column. In indentures, deeds of partition and similar
instruments, the fact that the party claiming under the document is also an executing party shall be
indicated by writing the name across both these columns.
122.
The column "Nature and Value of Transaction" shall also contain:(a)Information regarding the
movable property to which a document relates;(b)the shares assigned to each party to a
partition-deed;(c)concise details in the case of a document such as a release, Maintenance Deed, or
Rectification Deed; and(d)in the case of a mortgage the rate of interest, if any, and the term.
123.
When a loan order is received with a security bond under sub-sections (1) and (3) of Section 89, the
order and the bond shall be indexed as separate documents, although the property specified in both
may be the same.
124.
Registering Officers on registering non-testamentary documents relating to immovable properties
situated in cantonments shall forward to cantonment authorities the necessary information in
English in the form prescribed for the purpose.Subsidiary index
125.
In districts and sub-districts to which a rule made by the Government under Section 22 (i) is
applicable, Registering Officers shall maintain a subsidiary index to Index No. II in the form printed
in Appendix-VI, in order to show at a glance all transactions affecting each survey number or
sub-division.Indexes to Book - 5
126.
An alphabetical index to the names of the persons purporting to be executants of documents entered
in Book 5 shall be affixed to that register book.Andhra Pradesh Rules Under the Registration Act, 1908

Chapter XX
(Section 57)
Searches
127.
Every application to a Registering Officer for an inspection, or search, or a copy shall be made in
writing.
128.
An application for a search or for a copy of an entry in Books 1 to 4 may be received and complied
with through the medium of the post, the postage charges being borne by the applicant. In such
cases special care shall be taken to ensure that the provisions of sub-sections (2) and (3) of Section
57 are satisfied, and the title of the applicant to have the copies shall be proved to the satisfaction of
the Registering Officer.
129.
An application for a search in respect of property situated in more sub-districts than one or in a
village which has been transferred from one sub-district to another may be presented at any of the
sub-registry offices in which the property or any portion of it is situated or to which the village is or
has been attached. In such cases, the procedure prescribed in Rule 130(ii) may be followed if the
party so desires.
130.
(i)An application for a search or for a copy of any entry contained in a book which has been
transferred to the office of a District Registrar may be made to such District Registrar either direct
or through the Sub-Registrar in whose office the entry was originally made.(ii)When such
application is made to a Sub-Registrar it shall be accompanied by the requisite stamp and other
papers and by a deposit of money sufficient to cover the prescribed search fee and the postage and
sum of rupees two as an advance for copying charges. The Sub-Registrar shall cause a search to be
made in the indexes, shall endorse on the application the number and year of the document, the
particulars of the volume and the pages thereof containing the copy of the document and shall
forward a copy of the application so endorsed with the stamp and other papers to the Registrar
concerned. The latter shall cause the copy to be prepared and furnished to the Sub-Registrar with a
bill for the copying charges. On receipt of the copy and the bill, the Sub-Registrar shall deliver or
transmit the former to the party after refunding to, or collecting from him, any surplus or deficiency
on the amount deposited. Any money collected under this rule shall be brought to account in the
office of the Sub-Registrar to whom the original application was made.(iii)When an applicant hasAndhra Pradesh Rules Under the Registration Act, 1908

paid the prescribed fees for search in the indexes of a Sub-Registrar's office in respect of a document
which has been registered in another office or in a book transferred to the Registrar's Office, no
further search fee shall be levied when he applies to the other office or to the Registrar for a search
or copy of the same document:Provided that the applicant produces before that Officer the receipt
for the fee granted to him by the Sub-Registrar.
131.
Fees for searches shall be payable in advance, but in the following cases the fees may be adjusted in
the Treasury accounts:(i)Searches for Encumbrances:(a)On property pledged as security for loans
under the Loans Acts, and(b)On property pledged as security for the due performance of their duties
by public servants, andNote: The term "Public Servant" in this sub-rule should be interpreted to
mean "an officer serving directly under Government".(ii)Requisitions from a Public Officer for a
certificate of encumbrance in his official capacity.
132.
In complying with a requisition from a Court which involves a search or the preparation of a copy of
any document, the Registering Officer shall forward to the Court a memorandum of the fees payable
so that the amount may be collected by the Court and remitted to the Registering Officer.
133.
The fee for a search shall entitle the applicant to read the entry for the finding of which the fee has
been paid or to have it or read to him; but it shall not entitle him to take a copy of the entry. If a
search proves fruitless the fees shall not be refunded, but the applicant may if he so desires, be
granted a certificate stating that the entry sought for has not been found in the books.
134.
With reference to Note (3) to Article 12 of the Table of Registration Fee, a search fee shall not be
levied for the grant of copy of document.(a)admitted to registration but not transcribed into the
register;(b)presented but not yet admitted to registration ; or(c)the registration of which has been
refused.
135.
Only one search fee shall be levied(i)for making a search in respect of a single document or in
respect of acts and encumbrances on one and the same property in two or more offices because of
the transfer of a village from one sub-district to another;(ii)for making a general search in respect of
one and the same property in the records of an office, which was once in existence, was abolished
and then revived;(iii)for making a search for acts and encumbrances in respect of one and the same
property when owing to the splitting up or grouping together of villages, or as the result of surveyAndhra Pradesh Rules Under the Registration Act, 1908

and settlement operations, the search has to be made in the indexes of more than one village.
136.
When a search is made in respect of more than one entry or more than one document executed by or
in favour of one and the same individual, search fees shall be levied separately for each office in
which the nominal indexes have to be searched.
137.
(i)When an application for a search is presented and the requisite fees have been paid, the
Registering Officer shall enquire whether the applicant will himself make the search or desires that
it should be made by the office establishment. When a clerk is deputed to make or verify the search,
the name of the clerk deputed shall be noted on the application. As soon as the search and
verification are completed, the result, or a reference to the certificates of encumbrance showing the
result shall be noted on the application by the person who made the search and signed by the person
who made and verified the search.(ii)Whenever an entry found on search is read out to an applicant
under Rule 133, a note shall be made on the application to the effect that has been done and, when
the applicant does not require a copy of such entry, this fact shall also be noted on the application
and the signature of the applicant obtained thereto.
138.
All inspections and searches of books and indexes shall take place in the presence of the Registering
Officer.
139.
A copy of an entry shall not be made from any book until the Registering Officer has scrutinized the
entry generally.Certificate of Encumbrance
140.
When an application is made for a search for encumbrance in respect of any immovable property or
for a list of documents executed by, or in favour of a single individual, and the applicant desires that
a certificate of encumbrance or a list of documents found in the course of such search should be
furnished to him by the Registering Officer, the request shall be complied with, the certificate or list
being in the form printed in Appendix VII.
141.
In the case of searches for a list of documents executed by, or in favour of, a particular individual,
the list shall show the number date, nature, and value of the several documents found, as well as theAndhra Pradesh Rules Under the Registration Act, 1908

names of the parties and the village in which property affected, if any, is situated, but no description
of the properties affected by the document should be given as in the case of encumbrance certificates
on properties. The list shall not include particulars of documents registered in Register Books 3 and
4 unless the applicant is entitled to copies of the entries (Section 57).
142.
A certificate of encumbrance granted by a Registrar or by a Sub-Registrar shall be in the language in
which the indexes of his office are prepared. If the indexes are not in English but the party requires
the certificate to be prepared in English the request may be complied with.
143.
A certificate of encumbrance shall contain a complete list of all acts and encumbrances affecting the
property in question.
144.
In the case of a search made in the records of more than one office the various certificates prepared
in the different offices shall be granted to the party and not a consolidated certificate by the officer
to whom the application was made in the first instance. An Officer who makes a search at the
request of another Officer shall therefore furnish a certificate in duplicate.
145.
(i)Searches for certificates of encumbrances shall, as a rule, be made by two persons independently
of each other, so that the results obtained by one may be compared and verified with those obtained
by the other.(ii)When a party himself makes the search he should be required to furnish a signed
note of the results of the search and the results should be verified by a member of the office
establishment.
146.
A copy shall be retained of each encumbrance certificate issued from an office and shall be filled in a
separate file book in which the various certificates will be numbered consecutively in a separate
series for each calendar year.
147.
The notes furnished by parties containing the results of searches conducted by themselves and the
duplicate of the certificate received from other officer under Rule 144 shall be filed in the above file
with necessary cross reference.Production of Register Books in CourtAndhra Pradesh Rules Under the Registration Act, 1908

148.
When a requisition is received from a Court for the production of a register book other than Book 3
or Book 4 or a register of thumb impressions, the Registering Officer shall ascertain whether it is
absolutely necessary that the book itself should be produced or whether a certified copy of the entry
required in evidence will not suffice. When it is absolutely necessary to produce the book itself, or
when the requisition is for the production of Register Book 3 or Register Book 4, or a register of
thumb impressions, the book shall be forwarded in a sealed packet, through a clerk, with
instructions to bring the packet back to the office unless the Court considers its detention to be
necessary. When a copy is forwarded to Court, it shall be sent in a sealed cover addressed by name
to the officer, presiding over the Court.
Chapter XXI
(Section 63)
Record of Substance of Statements
149.
Evidence required by a Registering Officer shall be taken by himself or by some one appointed
under a Commission.
150.
The oath or affirmation to be made before a Registering Officer by a deponent shall at his option be
in any of the following forms:A"The evidence which 1 shall give shall be the truth, the whole truth,
and nothing but the truth. So help me God".B"I solemnly affirm in the presence of Almighty God
that what I shall state shall be the truth, the whole truth, and nothing but the truth".C"I affirm that
what I shall state shall be the truth, the whole truth and nothing but the truth".
151.
(i)When execution is admitted and the endorsement is signed by the party admitting execution, and
when witnesses are examined merely with reference to the identification of the parties appearing,
the prescribed endorsement is in itself a sufficient record. A record of the substances of the
statements shall, however, be made in the following cases:(a)When an execution is denied;(b)When
a person admitting execution refuses to sign the endorsement;(c)When a person refuses to affix his
thumb impression when required by the Registering Officer;(d)When a person admits execution on
protest or with a reservation;(e)When an enquiry is held as to the alleged death of an executing
party;(f)When an enquiry is held as to the right of a person to appear as the executor, administrator,
or heir of a deceased person or as the guardian of an infant, or as the curator of an idiot or a
lunatic.(g)When any person is examined as to the age of a party who appears to be a minor as to theAndhra Pradesh Rules Under the Registration Act, 1908

sanity of a party who appears to be an idiot or a lunatic;(h)When an explanation is taken regarding
the cause of delay in the presentation of a document or in the appearance of parties;(i)When the
addition of any person, or the description of a property has to be ascertained owing to the addition
or the description not appearing either in the document or in the endorsement.(j)When an enquiry
is held under Section 41 (a) in respect of a will or any authority to adopt presented for registration
after the death of the testator or the donor, as the case may be;(k)When an enquiry is held under
Section 74 as to the fact of the execution of a document; and(l)Generally in all cases in which a
record may seem necessary.(ii)All such statements with the exception of those under (j) and (k),
which shall be kept on the record of the enquiry shall be recorded in a book known as the
"Deposition Book" maintained in each registration office.(iii)Deposition taken by a Registrar or by a
Sub-Registrar empowered to exercise any of the powers of a Registrar, shall be recorded in English
and by the other Sub-Registrars in the language of the Sub-District or in the language used by the
deponent.(iv)Each witness or party shall be examined separately. The deposition shall usually be
recorded in the first person and when so recorded, the signature of the person who makes it shall be
obtained. A certificate shall be appended to each deposition to the effect that it has been read over or
interpreted to the deponent and acknowledged by him to be correct.(v)At the head of each
deposition the document to which it pertains together with the book, volume and year shall when
practicable, be noted.(vi)The deposition book shall not be carried when a Registering Officer attends
private residence. Any statements or depositions which a Registering Officer may find it necessary
to take when attending at private residence shall be recorded by him in a separate book and on his
return to the office be copied in the deposition book. The copy may be made by a clerk and examined
by another clerk, but shall be authenticated by the Registering Officer with date.
Chapter XXII
(Sections 64 to 67)
Transmission of Memoranda and Copies
152.
Memoranda of the registered documents required for transmission under the provisions of Sections
64 to 67 shall be prepared in the form printed to Appendix-VIII.
153.
The total number of copies or memoranda required shall be made in the office of original
registration, at the expense of the party presenting the document for registration. They shall be
forwarded with an intimation form which shall be returned duly receipted by the Officer to whom it
is addressed.Andhra Pradesh Rules Under the Registration Act, 1908

154.
The copies and memoranda and translations received in a Registration Office shall not be given a
document number in that office but shall be pasted into file Book I or in the file of translation as the
case may be and indexed with reference to the page of the volume in which they are filed.
155.
When a document is registered in duplicate or triplicate no memorandum or copy is required to be
forwarded under Sections 64 to 67 in respect of the duplicate, but the number of copies registered
with the original shall be noted in the column headed "document" in the memorandum prepared
from the original.
156.
A memorandum of a registered document transmitted under Sections 64 to 67 shall be prepared in
the language of the sub-district which issues the Memorandum when that language is recognised to
the sub-district to which the Memorandum is forwarded. When this is not the case, the
Memorandum shall be prepared in English.
157.
When a Registering Officer finds that a correction is necessary in a copy or memorandum of a
document forwarded by him to another Registering Officer, he shall send an erratum to the latter,
who shall file it in the Book No. 1, carry out the correction and add a note on the original explaining
the circumstances under which the correction is made. A reference to the page and volume of the file
book in which the erratum has been filed shall be entered on the original memorandum or a copy,
and the indexes shall also be corrected accordingly.
Chapter XXIII
(Sections 68 & 69)
Errors in Registration
158.
(i)In the event of a document being registered in a wrong register book, the registration shall stand
but the Registrar will direct that the requisite particulars regarding the document should be entered
in the appropriate place in the indexes relating to the proper book in which a reference to the
volume and page of the book in which the document has been copied.(ii)Corresponding note shall
also be entered in the entry in the wrong book as well as in the indexes relating thereto.(iii)In cases
in which copies and memorandum under Sections 64 to 66 had been forwarded at the time ofAndhra Pradesh Rules Under the Registration Act, 1908

registration in the wrong book and in cases in which the forwarding of such copies and memoranda
becomes necessary for rectifying the error, the requisite notice of the error in the former and the
requisite copies and memoranda in the letter shall be forwarded free of cost.
159.
(i)Where by inadvertence a document is registered in a wrong office, the Registering Officer shall
inform the executing and claiming parties of the fact and advise them to apply to the registrar for a
direction under Section 68 for its registration afresh in the proper office.(ii)Where the proper office
of registration is situated, in a district other than that in which the office of wrong registration is
situated, the application shall be made to the Registrar of that other district.(iii)When a direction is
so issued to a Sub-Registrar, he shall register the document without the levy of any fee and in the
endorsement of representation shall refer to the orders of the Registrar.(iv)The Registering Officer
in whose office the document was originally registered shall in any case forward to the proper office,
free of charge, a copy of a memorandum of the document in accordance with the procedure
prescribed by Sections 64 to 66 and the receiving officer shall file the copy of Memorandum in his
file Book 1.
160.
(i)A Registering Officer will be held liable for any loss to Government which may arise from neglect
on his part in the registration of a document, the making of a search, or the grant of a copy of a
document.(ii)If before a document is returned to the party, the Registering Officer detects that the
fee was deficitly levied on such document, he may collect from the party the amount required to
make up the deficiency. A report of every such collection shall forthwith be submitted to the
Registrar of the District.
Chapter XXIV
(Sections 71 & 76)
Refusal Register
161.
(i)When registration is refused the reasons for refusal shall be at once recorded in Book 2. They will
usually come under one or more of the heads mentioned below:I. Section 19: That the document is
written in a language which the Registering Officer does not understand and which is not commonly
used in the District, and that it is unaccompanied by a true translation and a true copy.II. Section
20: That it contains unattested interlineations, blanks, erasures, or alterations which in the opinion
of the Registering Officer require to be attested.III. Section 21(1) to (3) & Section 22: That the
description of the property is insufficient to identify it or does not contain the information required
by Rule 20.IV. Section 21(4): That the document is unaccompanied by a copy or copies of any map
or plan which it contains.V. Section 36: That the date of execution is not stated in the document orAndhra Pradesh Rules Under the Registration Act, 1908

that the correct date is not ascertainable.VI. Sections 23, 24, 25, 26, 72, 75 & 77: That it is presented
after the prescribed time.VII. Sections 32, 33, 40 & 43: That it is presented by a person who has no
right to present it.VIII. Section 34: That the executing parties or their representatives, assigns or
agents have failed to appear within the prescribed time.IX. Sections 34 & 43: That the Registering
Officer is not satisfied as to the identity of a person appearing before him who alleges, that he
executed the document.X. Sections 34 & 40: That the Registering Officer is not satisfied as to the
right of a person appearing as a representative, assign, or agent so to appear.XI. Section 35: That
execution is denied by any person purporting to be an executing party or by his agent.XII. Section
35: That the person purporting to have executed the document is a minor, an idiot or a lunatic.XIII.
Section 35: That execution is denied by the representatives or assign of a deceased person by whom
the document purports to have been executed.Note: When some of the representatives of a deceased
executant admit and others deny execution, the registration of the document shall be refused to the
persons interested being left to apply to the Registrar for an enquiry into the fact of execution.XIV.
Sections 35 to 41: The alleged death of a person by whom the document purports to have been
executed has not been proved.XV. Section 41: The Registering Officer is not satisfied as to the fact of
execution in case of will or of an authority to adopt presented after the death of the testator or
donor.XVI. Sections 25, 34 and 80: That the prescribed fee or fine has not been paid.
162.
When the executants of a document appear at different times the order of registration or refusal
shall be passed after all the executants have appeared and admitted or denied execution, as the case
may be, unless the maximum time allowed for appearance by the Act has expired or unless the
presentant applies for the return of the document unregistered as regards the executants who failed
to appear.Note: This rule refers to documents by several executants at the same time and not to
documents executed by several persons at different times under Section 24.
163.
When a document is partially registered and partially refused registration, the refusal shall be
endorsed after the document is registered.
164.
A Sub-Registrar is not authorised by law to refuse to register a document which has been executed
by himself or in his own favour or because he is a party interested, remotely or indirectly, in the
transaction to which such document relates; nor is he authorised to refuse to authenticate a Power
of Attorney granted for registration of such document but he shall always advise the parties to
present such document or Power of Attorney at some other office. If the document falls within the
category of documents mentioned in Section 28 such other office of the Registrar of the District who
will, as provided in the Table of Fees, register such document without charging the usual extra fee
under Section 30. If the parties, after being advised as above, insist on the Sub-Registrar's
registering a document or authenticating a power in which he is interested, he shall do so but shall
immediately report the fact for information of the Registrar to whom he is subordinate.Note: ThisAndhra Pradesh Rules Under the Registration Act, 1908

should not be understood as authorising a registering Officer to attest Power of Attorney executed
by himself.
Chapter XXV
(Sections 41 (2) and 72 to 76)
Appeals and enquiries
165.
(i)An appeal under Section 72 or an application under Section 73 shall be presented in writing to the
Registrar of the District, or to the Officer-in-charge of the Registrar's Office accompanied by copy of
the refusal order appealed against and the original document in respect of which the order was
passed.(ii)When the document is stated to be in the possession of some person other than the
appellant and the latter desires time to obtain and produce it or issue of a summons for its
production, the request may be complied with and the application be admitted pending receipt of
the document.
166.
(i)An appeal under Section 72 shall be presented either by the appellant or by a certified pleader
duly authorised on his behalf by a vakalat attested in the manner prescribed in the Civil Rules of
Practice applicable to Muffasil Civil Courts or by an agent holding a Power of Attorney authenticated
as laid down in Section 33.(ii)An application under Section 73 shall be presented in person by the
party or by an agent holding a Power-of-Attorney authenticated as aforesaid.(iii)An appeal or an
application shall not be accepted or acted upon if sent by post.
167.
In a enquiry connected with a will or an authority to adopt under Section 41(2) or an appeal under
Section 72 or an application under Section 73 or in original enquiry under Section 74, private vakils
or persons not qualified under the Legal Practitioners Act shall not be allowed to appear. Such
persons are not, however, debarred from acting as agents, if authorised by a duly authenticated
Power of Attorney.
168.
An application under Section 73 presented by any of the persons mentioned therein within the
prescribed period but without the requisite verification may be returned in view to its being verified
and presented against within a stated time.Andhra Pradesh Rules Under the Registration Act, 1908

169.
An appeal under Section 72 or an application under Section 73 may, when the Registrar is on a tour
of inspection in his district, be posted for hearing at any Sub-Registrar's station convenient to the
parties.
170.
(i)An applicant in this rule shall mean an appellant under Section 72 or party at whose instance an
enquiry under Section 74 is commenced and shall include subject to provisions of Rule 166 also an
agent or a vakil.(ii)On the presentation of an appeal under Sec. 72 or an application under Section
73 and in the case of original enquiry under Section 74, a date shall be fixed for the hearing of the
appeal or application or for the enquiry.(iii)Such date shall be notified to the applicant and also
published on the notice board of the Registrar's Office.(iv)Within one week of the date of such
publication the applicant shall pay the process fee necessary for the issue of notice to the opposite
party (hereinafter called the Respondent) and for summonses for securing the attendance of
witnesses, provided that the Registrar may extend the time for such payment, from time to time, on
sufficient cause being shown.(v)If on the date of hearing:(a)neither party appears, or(b)the
applicant does not appear and the Respondent appears and contests the registration of the
document, or(c)the Respondent does not appear and it is found that notice has not been served
upon him in consequence of the failure of the applicant to pay the requisite fee for such service.The
Registrar shall make an order refusing to direct registration of the document:Provided that it shall
be open to the Registrar to adjourn the enquiry from time to time for sufficient cause.(vi)An order
refusing to direct registration under this rule shall be recorded in Book 2.
171.
An order on an appeal under Section 72 or on application under Section 73 directing or refusing
registration shall not be endorsed on the document itself but shall, when registration is ordered, be
recorded separately and filed in a separate file book, and when registration is refused, be recorded in
Book 2. In either case a brief abstract of the order shall be endorsed on the petition, appeal or
application which will be kept with the records of the case.
172.
An appeal or application against an order of refusal to register a will presented for registration after
the death of the testator may be presented by any executor appointed under the will. The Registrar
may, after the perusal of the records connected with the refusal, call for fresh evidence or issue
summons to witness or remand the case to the Sub-Registrar for further enquiry.Andhra Pradesh Rules Under the Registration Act, 1908

173.
Where a refusal order is based on the ground that the executant is purposely keeping out of the way
in order to evade registration or has gone to distant place and is not likely to return to admit
execution and the non-appearance is treated as tantamount to denial of execution, the application
may be accepted by a Registrar under Section 73, and the fact of execution enquired into as if
execution had been specifically denied.
174.
(i)All orders passed by a Registrar under Sections 72, 75 and 76 shall be communicated without
delay to the Sub-Registrar concerned.(ii)When the office in which a document is ordered to be
registered is different from the office in which its registration was refused a copy of the order
directing registration shall be sent to both offices.
175.
When a document refused registration is ordered to be registered either by a Registrar or by a Court,
a note to the following effect shall be entered in Book 2 under the order originally passed by the
Sub-Registrar refusing registration at the foot of the copy of Registrar's order or decree of Court
:"Registered under the orders of Registrar/Court as No. ................... of 19 ............ Book ....... volume
.......... P"
176.
When a Registrar refuses to direct the registration of document under Section 72 or Section 75, the
order passed by him may be copied in Book 2 by a clerk, the copy so made being treated as the
original and signed by the Registrar himself without the addition of the words, "true copy". The
Registrar's draft from which copy is made shall be filed in the file of appeal, orders and judgment.
177.
When an alleged executant appears after the expiry of the first four months from the date of
execution and denies execution, no appeal lies under Section 72, but an application may be made to
the Registrar under Section 73 on the ground of denial of execution.
178.
In cases where the refusal order of a Sub-Registrar is based on the ground that the executant did not
appear even after the expiry of the full time allowed:(i)If the presentant had taken no steps to
enforce the appearance of the executant, the latter cannot constructively be held to deny execution
and the refusal order falls under sub-section(1) of Section 34 and the appeals under Section 72.(ii)If,
however, such steps have been taken and processes issued although abortively, the non-appearanceAndhra Pradesh Rules Under the Registration Act, 1908

is tantamount to denial of execution the refusal order falls under sub-section (3) of Section 35 and
no appeal lies under Section 72, although an application may be made under Section 73.
179.
No appeal lies to a Registrar in respect of a document which is not refused registration by a
Sub-Registrar but is withdrawn from registration by the presentant, i.e., returned to him at his
request.
180.
The Registrar may direct by whom the whole or any part of the costs of an appeal under Section 72
shall be paid and such costs shall be recoverable as if they had been awarded in suit under the Code
of Civil Procedure, 1908.
181.
The Inspector-General shall have power, where he is satisfied that there are grounds for so doing, to
transfer from the file of one Sub-Registrar to that of another, any enquiry under Section 41(2); from
the file of one District Registrar to that of another any appeal under Section 72 or application under
Section 73 or enquiry under Section 74 and from the files of one Sub-Registrar exercising powers
conferred under the second proviso to Section 35(3) to that of the District Registrar to whom such
Sub-Registrar is subordinate any enquiry under Section 74.
Chapter XXVI
Fees and fines
182.
It is for the Registering Officer, who is responsible for levying the fee to determine in the first
instance what fee should be paid. After it has been paid the presenting party may, if he is
dissatisfied, refer the question to the Registrar who shall, if he thinks there has been an over-charge,
order the Sub-Registrar to refund any excess. If the decision is adverse to the party, he may make a
further reference to the Inspector-General. Such application to the Registrar or the
Inspector-General shall be made within 30 days from the date of payment of fees or the date of
making of the Registrar's order, as the case may be.
183.
In the event of registration being refused, any fee or fine which may have been levied shall be
refunded except fees, commissions, summonses attendances and travelling allowances where such
fees and allowances have been earned. Such refund shall be made out of the permanent advance ofAndhra Pradesh Rules Under the Registration Act, 1908

the Registering Officer and a bill in detail for the adjustment of the refund shall be submitted in the
usual manner.
184.
Every application for the remission or refund of a fine or a fee shall be lodged in the first instance
with the Registering Officer who levies it for submission to the sanctioning authority through the
proper channel.
185.
District Registrars may themselves dispose of applications for refund of fees or fines collected in
excess or for work not performed by the Department.
186.
Whether a document is admitted to registration or not, all fees and fines shall be at once brought to
account.
187.
(i)At stations where there is a treasury and the treasury is open the collections shall be remitted
daily to the treasury:Provided that a remittance need not be made on any day when the total
collections to be remitted do not exceed Rs. 5.(ii)At stations where there is no treasury the fees shall
be remitted to the nearest treasury at such intervals as may, from time to time, be prescribed by the
Inspector-General.(iii)A remittance to the treasury shall be accompanied by the challan duly filled
up in duplicate in view to one copy of each challan being returned duly signed by the Treasury
Officer.
Chapter XXVII
(Section 83)
Prosecutions
188.
A Sub-Registrar, may with the previous sanction of the Registrar lay a criminal complaint against a
person who makes, in the process of registering a document an intentionally false statement, when
however, execution is denied he shall not proceed to take evidence regarding execution and
prosecute the executants for making false statement but merely refuse registration and leave the
party concerned to bring the matter to an issue by applying to the Registrar under Section 73 for an
enquiry into the fact of execution.Andhra Pradesh Rules Under the Registration Act, 1908

189.
A refusal to sign a registration endorsement or a statement made to a Registering Officer, does not
constitute an offence under the Indian Penal Code or under the Registration Act. A Registering
Officer is no more competent to require a party to sign than he is to require him to register; his duty
is merely to carry out the voluntary wishes of parties who appear before him.
190.
A Sub-Registrar, shall before instituting a prosecution, forward a full report of the case to the
Registrar and obtain his approval to the prosecution. If, however, the circumstances demand
immediate prosecution, a report shall be made by the Sub-Registrar to the Registrar within 24 hours
of the institution of the prosecution. A Registrar who institutes a prosecution or approves of the
institution of a prosecution by a Sub-Registrar or receives intimation that a prosecution has been
instituted by a Sub-Registrar shall report that fact to the Inspector-General.
Chapter XXVIII
(Section 88)
Documents Executed by the Government Officers and other Public Functionaries
191.
The exemption from personal appearance contemplated by Section 88 shall be held to apply also
to:(i)A Government officer who is an ex-officio President or Chairman of local body;(ii)an agent to
Court of Wards(iii)an Official Receiver;(iv)Officers of Government whose services are lent to local
bodies or who perform other duties retaining a lien on Government posts such as Commissioner of
Municipalities, Liquidators of Co-operative Societies and Managers of Estates under the
superintendence of the Court of Wards;(v)Commissioners of Municipalities whether holding lien on
Government posts or not; and(vi)Commissioners of Municipal Corporations of Hyderabad and
Secunderabad.
Chapter XXIX
Preservation of Records
192.
The following books and files shall be preserved permanently:Book 1: Register of non-testamentary
or any documents relating to immovable property.Book 2: Record of reasons for refusal to
register.Book 3: Register of wills and authorities to adoptBook 4: Miscellaneous Register.Book
5: Register of deposits of Wills.Indexes Nos. I, II, III and IV and subsidiary indexes.Register of
Thumb-impressions.File of translations.Files of appeals, orders and judgments of Courts.DepositionAndhra Pradesh Rules Under the Registration Act, 1908

Book.
193.
All other books and records shall be preserved or destroyed under such orders as may be issued
from time to time by the Inspector-General provided that the disposal of such books and records as
are maintained under the Registration Act or the Rules framed thereunder shall be regulated by the
rules made by the Inspector-General under the Destruction of Records Act, 1917.
194.
(i)In all Registration Offices two registers of records shall be maintained, one relating to the
permanent records, and the other to the temporary records, and in these registers separate pages
shall be allotted for each series of books, indices and records.(ii)All records in an office shall be
brought to account in one or other of these registers according to the instructions issued from time
to time as to the classification of records. A record shall not be omitted from its appropriate register
on the ground that it has been completed or has not been bound: for instance, when a volume of
register books or a new register of thumb-impressions is brought into use, it shall be entered in the
register of permanent records on the day the first document is copied in the volume or the first
impression taken; similarly the index of a particular year shall be entered in the record register even
though it may at the starting be maintained in loose sheets.(iii)The date of destruction and the
number and date of the order, if any, sanctioning the same shall be noted in the record register
against the entry of true record destroyed, each such note being attested and dated by the
Registering Officer.
195.
The completed volumes of the under-mentioned books belonging to the office of a Sub-Registrar or
of a Joint Sub-Registrar situated at the headquarters station of a district may, with the sanction of
the Inspector-General, be transferred at the end of each calendar year to the office of the Registrar.
The records of a Joint Sub-Registrar may similarly be transferred to the Chief Joint Registrar's
office:Register Books 1,2,3 and 4 and the indexes relating thereto.Register of thumb-impressionsFile
books of Power of AttorneyFile books of translationsFile books of appeals, orders and
judgmentsDeposition booksMinute books
196.
(i)When a page in a register book shows signs of crumbling or an entry, signs of fading, the page or
entry shall, with the previous sanction of the District Registrar, be recopied.(ii)The sheets
containing the reproduced entries shall be preserved in a cover under the seal and signature of the
Registering Officer, with a slip pasted over the cover to show its contents.(iii)When an entry is
recopied a not of the fact shall be made at the foot of the entry in the original register. When an
entire volume is recopied a note to that effect shall be entered in red ink on the label on the back ofAndhra Pradesh Rules Under the Registration Act, 1908

the original volume as well as the title page, and on the back of the volume containing the
reproduced entries a label shall be pasted showing in red ink its contents.(iv)The original shall be
faithfully reproduced as it is found in the register and any missing or undecipherable letters, words
or figures shall not be filled up by guessing from the context. A note shall be made as regards
portions not legible or visible.(v)The entries as copied shall be compared and authenticated as a true
copy by the Registering Officer with date and seal.(vi)The signatures of the clerk who recopies each
entry and of the clerk who examines it shall be affixed above the signature of the Registering Officer
authenticating the copy.(vii)Uninitialled interlineations, etc., in the original shall be noted above the
signatures of the clerks who copy and compare, and these notes shall be attested by the Registering
Officer.(viii)The interlineations etc., in the copies of the entries shall be noted by the copying clerk
and shall be initialled by the Registering Officer.
197.
Register books, papers, documents, indices, etc. may with the approval of the State Government, be
transferred from one registration office to another for safe custody. Sealed covers deposited under
Section 42 may likewise be transferred from one Registrar's office to another for safe custody.
Chapter XXX
System of copying documents by Photography
198.
(i)The copying of documents admitted to registration may be made by means of the photography
instead of by hand.(ii)When a document is presented for registration the Registering Officer shall
first see whether it is fit to be accepted for registration with reference to the provisions of the Act,
Rules and Standing Orders. In addition, he should satisfy himself that the writing is legible and not
faint, indistinct or unnaturally crowded or in pale blue ink. If it is so badly drawn up as not be
capable of being photographed, the parties should be asked to get a fresh deed executed, getting a
refund of the value of the stamp, but they should not be compelled to do this if the document is
legible. If the Sub-Registrar is in doubt as to whether a document is fit for photography or not he
might send it for opinion to the Photo Office established for the purpose. If it has to be accepted in a
condition unfit for photography, it will then be copied in manuscript(iii)If there be no objection on
any of the above grounds to the acceptance of the document, the presentation endorsement should
be written or impressed in black ink on the face of the document in the usual form and the
presentant's signature taken below it. The Registering Officer shall then sign the
endorsement.(iv)The enquiry prescribed in Section 35 shall then be proceeded with and the
endorsement and certificates prescribed in Sections 58 to 60 shall be made from time to time. As
soon as registration is completed the registration certificate should be endorsed and the office seal
impressed below it. The registration certificates shall not contain the page and volume.(v)The
indices shall immediately be prepared.(vi)The document shall be carefully marked with an
identification stamp and the number assigned to the document noted on every page.(vii)When all
such requirements are satisfied, the document should be sent to the Photo Office in a sealed packetAndhra Pradesh Rules Under the Registration Act, 1908

accurately weighed and the weight marked on the packet. In order to avoid omissions in despatch
and receipt, all the documents received for registration shall be sent to the Photo Office on the next
day in one packet (and not in separate packets), together with a carbon duplicate list of such
documents, the original list being retained by the Sub-Registrar. Care should be taken that the
documents are not folded, as folded documents are rather inconvenient for being photographed.
The documents should be in a suitable pad as far as possible. With the list should also be sent
envelopes duly stamped (together with yellow receipts), and correctly addressed for the documents
to be returned by post. All documents or copies which the parties to be returned to themselves by
post will be so sent direct from the Photo Office and the Sub-Registrars should be careful to note
post (..) in the last column of the list. When the documents are also despatched by post the white
receipt obtained by the photo office will be forwarded to the Sub-Registrar concerned, who will also
watch for the arrival of the yellow receipts.(viii)The officer-in-charge of the Photo Office shall, as
soon as the packet is received, see whether the seal on the packet is intact and then check the weight
of the packet marked on it. He will then open the packet and check the contents with the list, and
send an acknowledgement by postcard to the Sub-Registrar ("List-, dated-, contents received exactly
advised"). He will not return the list but will file it in his office.(ix)In case any discrepancy in the
contents of the packets when compared with the advise list is noticed, the officer-in-charge of the
Photo Office should at once refer the matter to the Sub-Registrar who shall account for it without
the least delay. If the Sub-Registrar cannot explain and if a document seems to have been lost, then
the fullest enquiry must be made at once and report made to the District Registrar
immediately.(x)The Officer-in-charge of the Photo Office shall then arrange for the photographing
of the documents. A single photo copy of each document shall ordinarily be taken. This number is
fixed for ordinary cases of documents which affects property in one sub-district. As regards
documents which relate to property situate in more than one district, since no manuscript copy is to
be sent under Sections 65 to 67, extra photo copies shall be sent in their stead. In such a case the
Registering Officer sending the documents to the Photo Office shall note in the duplicate list to be
forwarded with the document the additional number of copies required, and the officer-in-charge of
the Photo Office shall prepare so many additional copies. If an application is made to the
Sub-Registrar for a copy of any deed it is sent to the Photo Office, requisition for such copy shall also
be similarly noted on the list and the copy will be sent with the documents to the Sub-Registrar or to
any other address given. The Photo Officer shall affix his signature and seal to all copies of
documents photographed in token of the exact correspondence of the copies to the original
documents.(xi)When all the photo copies are ready, the pages of each shall be carefully checked with
the original documents which should be restiched before despatch as early as possible in the original
condition, if it has been necessary to unfasten the pages for photograph.Rules for Licensing of
Document Writers
Chapter XXXI
Licensing of Document WritersAndhra Pradesh Rules Under the Registration Act, 1908

199.
Subject to provisions of these rules, a licence may be granted to:(i)any person who possesses a
degree in law of a University in the State or any other equivalent qualification or who was enrolled
as an advocate under the Advocates Act, 1961 (Act 25 of 1961):(ii)any retired officer of or above the
rank of a clerk who passed tests prescribed for the post of a Sub-Registrar in the Registration
Department of Andhra Pradesh ; except a pass in the second class language test (full test).(iii)any
person who has passed the Writer's Licensing Test; and(iv)any other person who proves to the
satisfaction of the licensing authority that he is well conversant with the preparation of deeds of
conveyance, etc. and has been in continuous practice as document writer in the territories of the
State of Andhra Pradesh for a period of not less than five years immediately preceding the date on
which these rules come into force subject, however to the condition that he secures a pass in the
Document Writers Licensing Test prescribed in the Rule 210 (i) within a period of two years from
the date of issue of a licence to him :Provided that the Inspector-General of Registration and stamps
may in appropriate cases and on the recommendation of District Registrar exempt any person or
class of persons from the provisions of this rule.
200.
[x x x][Omitted by G.O.Ms.No. 108, Rev., Dated 21.2.2001.]
201.
A licence shall not be granted to a person.(a)if he is a minor;(b)if he has been declared by a
competent court to be of unsound mind;(c)if he is an undischarged insolvent, or being a discharged
insolvent, has not obtained from the court, which adjudged him as insolvent a certificate that his
insolvency was caused by misfortune, any misconduct on his part.(d)if he is an advocate or pleader
who has been dismissed or is under suspension from practising as such by an order of any
competent court;(e)if he has been convicted by a Criminal Court for an offence involving moral
turpitude;(f)if he is a person suffering, from leprosy:(g)if his retirement (in the case of a retired
officer) had been the result of misconduct;(h)if his licence has at any time been cancelled and the
order cancelling the licence has not been quashed by competent authority;(i)if for any other reason
to be recorded in writing the licensing authority considers it not desirable to issue a licence.
202.
(1)An application for a licence shall be in Form 'A' in Appendix IX and shall either be presented to
the licensing authority, in person or be sent by post with necessary fees.(2)Application for renewal
shall be in form '13' in Appendix-IX and made two months prior to the date of expiry of the licence
through the Sub-Registrar to whom a majority of the documents prepared by the applicant are
presented for registration or through the Registrar of the District in which the applicant primarily
works in respect of the licence for more than one district. The Sub-Registrar or the Registrar as the
case may shall forward the said application to the licensing authority with hisAndhra Pradesh Rules Under the Registration Act, 1908

recommendation.(3)Fees prescribed under these rules, for grant of a licence or its renewal shall be
remitted into the treasury to the Departmental head and the challan therefor enclosed to the
applications:Provided that the fee remitted shall be refunded to the applicant if the licence for the
renewal applied for is refused.Fees
203.
[(a) "Fees at the following rates shall be levied for the grant of licence and for its yearly
renewal.][Clause (a) Substituted by G.O.Ms.No. 831, Rev. (Reg-1), dated 27.8.1993, Published in
Andhra Pradesh Gazette, Part-I, Extraordinary No. 39, dated 30.9.1993.]
 For the first of any part of a
calendar yearFor renewal in he second or any
part of the succeeding calendar
year
1 2 3
 Rs. Rs.
Fee for more than one zone 1200 400
Fee for more than one District in
the zone900 300
Fee for one District 600 225
Fee for one Sub-District 450 150
Fee for any one Village 225 75
(b)If a licence is lost or destroyed a duplicate may, on adequate proof of such loss or destruction, be
issued to the licensee on payment of Rs. 10.00(c)The fees for the extension of the area of a licence
during the year for which the licence was originally granted, shall be the difference between the fees
payable under clause (a) of this rule for the grant of a licence for such extended area and the fees
already paid for the grant of the said licence.(d)The fees for the extension of the area of licence
during subsequent year shall be in addition to the fees payable under clause (c) of this rule,
difference between the fees payable under clause (a) of this rule of the renewal of licence for such
extended area and the fees already paid for the years with effect from which the extension is applied
for.Explanation: (i) In this rule, a sub-district shall be deemed to include all the Registration Offices
whether principal, additional, temporary or joint having if any, collateral jurisdiction over the entire
area of the sub-district;(ii)Documents to be registered by a 'Registrar' under Section 30 of the Act
may be prepared and written by licensees attached to the headquarters, sub-district of a district.
204.
The following shall be the conditions of a licensee, namely:(a)that the licensee shall abide by these
rules for the time being in force;(b)that he shall maintain the registers, receipt books and other
records in the manner prescribed by these rules;(c)that he shall not levy more than the fee
prescribed in Appendix-X;(d)that he shall not demand or receive any sum from parties in the name
of any person connected with the Registration Office;(e)that he shall not abet or participate in anyAndhra Pradesh Rules Under the Registration Act, 1908

illegal transaction or dealings with the staff attached to the Registration Office;(f)that he shall
render the true and correct amount of the moneys received from the parties and produce the records
maintained by him for inspection at any time before such officer as may be authorised to inspect
them by the licensing authority or the Inspector-General of Registration;(g)that he shall prepare and
write documents neatly and legibly in clear and unambiguous terms and in accordance with the
instructions that may be issued, from time to time, by the licensing authority or the
Inspector-General of Registration;(h)that he shall instruct the parties or their duly authorised
agents to present documents and to pay the fees in person direct to the Registering Officers and not
through any other agency.(i)that he shall obey any directions that may, from time to time, be issued
by the licensing authority or the Inspector-General of Registration regarding the preparation of
documents;(j)that he shall set forth fully and truly the consideration or the value and all other facts
and circumstances affecting the chargeability of any instrument with duty or the amount of duty
with which it is chargeable;(k)that he shall not act as a tout;(l)that he shall not appear as an
identifying witness of anybody connected with the registration of any document, and(m)that he
shall not take delivery of any registered document from the Registering Officer or present any
application for a single or general search or for a certified copy or extract;(n)that if he is Village
Officer, he shall not leave the charge of village or villages as the case may be, in connection with his
work as a document writer to the detriment of Government work:Provided that the Registering
Officer may in his discretion, exempt any licensee under these rules, from the operation of this rule,
if he is satisfied that the licensee is personally interested in the matter.
205.
Every non-testamentary document written by a licensee shall be attested by him in the following
manner, namely:"Prepared and written by (name in full with licence number of the licensee and
signature)".
206.
(a)Licensing authority shall be:(i)the District Registrar in respect of licencee authorised to prepare
and write documents within a village or a sub-district or district; and(a)[The Deputy Inspector
General of Registration and Stamps in respect of licensees authorised to prepare and write
documents in more than one district of the concerned zone; and [Substituted by G.O.Ms.No. 831,
Rev. (Reg-1), dated 27.08.1993.](b)The Inspector General of Registration and Stamps in respect of
licensees authorised to prepare and write documents in more than one zone.]
207.
(1)The licensing authority shall maintain registers in Form-C and shall issue licences in Form-D in
Appendix-IX.(2)Licences granted or renewed by the Licensing Authority shall be issued through the
Registering Officer in whose jurisdiction the licensee concerned resides.Andhra Pradesh Rules Under the Registration Act, 1908

208.
A licence issued under these rules, shall be in force upto and inclusive of the last day of the calendar
year for which it was granted. It can be renewed from year to year on an application being made in
Form-B prescribed in Appendix-IX within the time and in the manner prescribed in Rule 202
(b):Provided that the licensing authority may if it is satisfied that the delay in applying for the
renewal was due to unavoidable causes, condone the delay and renew the licence on payment of a
fine as prescribed below:(i)When the delay does not exceed two calendar months - A fine equal to
the renewal fee.(ii)When the delay exceeds two months but does not exceed four months  A fine
equal to double the renewal fee.(iii)When the delay exceeds four months but does not exceed six
months - A fine equal to five times the renewal fees.[Provided further that the Government by
publishing a notification in the Andhra Pradesh Gazette may order the non-renewal of document
writer licences either permanently or for specified periods, in respect of any class, category of
persons or areas of operation in the State of Andhra Pradesh either before or on the dates, these
renewals fall due, from the date of issue of such notification restricting the renewal of the licences
notwithstanding procedure for renewal contained in Registration Rules, 202 and 208.][Added by
G.O.Ms.No. 1082, Rev. (Regn. II), Dated 10.12.2002, w.e.f. 13-12-2002, Published in Andhra
Pradesh Gazette RS to Part I Extraordinary No. 60, Dated 13.12.2002.][Provided further not
withstanding any of the provisions in the Rules for renewal of licenses, the Government may at any
time, in its discretion, direct that all or any of the licenses issued under these rules, shall not be
renewed permanently or for such period and in such areas of operation in the State as may be
specified from time to time.][Added by G.O.Ms.No. 134, Rev. (Regn. I), Dated 1.2.2003, Published
in Andhra Pradesh Gazette Part I, Extraordinary No. 2, Dated 4.2.2003.]
209.
Notwithstanding anything contained in these rules, a person whose licence is not renewed within a
period of six calendar months after the expiry of the calendar year for which it was granted shall
apply for a fresh licence under Rule 202.
210.
(1)An examination to be called "The Document Writer's Licensing Test" shall be conducted by the
Inspector-General of Registration. The time and place of the examination and the language in which
the candidates will be examined and fees payable therefor, shall be notified by the
Inspector-General, from time to time, in the Andhra Pradesh Gazette.The Inspector-General shall
prescribe, by order, from time to time, the maximum marks of each test, the maximum marks to be
secured for a pass, the examiners for the test, the class of persons that may be admitted to it and all
other matters which are ancillary to the proper conduct of the test and declaration of results.(2)The
test shall consist of an examination in:(i)the Indian Registration Act, 1908 and the rules and the
table of fees thereunder.(ii)the Indian Stamp Act, 1899, and the Rules thereunder.(iii)the Transfer of
Property Act, 1882 and(iv)a standard book on drafting documents.(3)The list of the successful
candidates of each examination shall be published in the Andhra Pradesh Gazette.Andhra Pradesh Rules Under the Registration Act, 1908

211.
A study upto the S.S.L. C examination or its equivalent shall be the minimum qualification for
admission to the licensing test:Provided that this rule shall not apply to the persons specified in
Clause (iv) of Rule 199.
212.
The names of the licensees for more than one district for the whole district or the sub-district and
for villages of the sub-district concerned together with their licence numbers shall be published on
the Notice Board of each Sub-Registrar's Office.
213.
(a)A licensee shall maintain:(i)a register in Form 'E' of Appendix-IX.(ii)a receipt book in Form 'F' of
Appendix-IX, and(iii)shall issue receipts for all moneys received on account of the work connected
with every document written by him.(b)The completed registers and receipt books maintained
under this rule, shall be surrendered to the licensing authority at the end of each calendar
year:Provided that if the licensee should die or his licence expires or be revoked or suspended the
registers, and receipt books shall be surrendered within 15 days from the date of such death, expiry,
revocation or suspension by the representative in the case of the deceased licensee and by the
licensee in other cases.
214.
(a)A licence granted under these rules, may be suspended if the licensee:(i)fails to maintain the
registers and to issue receipts prescribed under these rules regularly and correctly,(ii)collects more
than scheduled fees specified in Appendix-X,(iii)contravenes any of these rules or any of the
conditions of his licence or is found guilty of disobedience to any lawful order passed under these
rules,(iv)if found guilty or any abetment of or participation in any illegal transaction or dealings
with the staff attached to the registration offices, or(v)if he has acted as a tout.(b)A licence granted
under these rules may be cancelled if,(i)the licensee has been suspended three times.(ii)he becomes
disqualified on any of the grounds specified in Rule 201 and covered by Rule 209.(iii)he has
furnished false or incorrect information or particulars in the application for licence.
215.
The licensing authority or any higher authority may suspend any licence granted under these rules
for any period or may cancel such licence.Andhra Pradesh Rules Under the Registration Act, 1908

216.
An appeal from the order of suspension or cancellation of a licence under these rules passed by an
authority shall lie to the next higher authority.
217.
Every licensee preferring an appeal shall do so separately and in his own name.
218.
Every appeal preferred under these rules shall contain all material statements and arguments relied
on by the appellant, and shall contain no disrespectful or improper language and be complete in
itself.
219.
An appeal may be summarily rejected by an authority not lower in rank than that from whose order
it is preferred to if.(i)it is a repetition of a previous appeal and is made to the same appellate
authority by which such appeal has been decided and no new facts or circumstances are adduced
which afford grounds for a reconsideration of the case.(ii)it is addressed to the authority to which no
appeal lies under these rules.(iii)it is not preferred within two months from the date on which the
applicant was informed of the order appealed against and no reasonable cause is shown for the
delay, and(iv)it does not comply with the provisions of Rule 218.
220.
The appellate authority shall consider:(a)whether the facts on which the order of suspension or
cancellation is based and established.(b)whether the facts established afford sufficient ground for
taking action; and(c)whether the penalty imposed is excessive, adequate or inadequate and after
such consideration shall pass such order, as it thinks just and equitable having regard to all the
circumstances of the case.[CHAPTER XXXII] [Inserted by G.O.Ms.No. 722, Revenue, (Regn. I),
dated 8.10.1999.] Registration of Documents through Card
221. Definitions
 In this Chapter, unless the context otherwise requires, the following words and expressions shall
have the meaning assigned to them, namely:(i)'Archival' means capturing data, including images, on
to electronic storage media like the CD, the tape, the hard disk and the like, with the intention of
preserving the same for long periods and for retrieving when required and includes
re-archival;(ii)'Card' or 'Computer-aided Administration of Registration Department' means the
process of performing the various functions associated with the act of registration, through
electronic devices like computers and scanners, to ensure an efficient, accurate and transparentAndhra Pradesh Rules Under the Registration Act, 1908

delivery of services to the registering public;(iii)'CD' or 'Compact Disk' means an electronic storage
device on which data, including images, can be stored in an electronic digital form;(iv)'CD Writer'
means an electronic device used to copy data available in digital form on an electronic storage device
on to a CD;(v)'Hardware' includes the electronic devices like computers, scanners; printers, CD
writers which are used to capture, store and process data in a digital form;(vi)'Imaging' means the
process of scanning the documents and managing the storage, classification and retrieval of the
electronic digital images so generated;(vii)'Scanner' means an electronic device used in conjunction
with a computer and a suitable software, to convert documents on paper into electronic digital
images to be stored on electronic media and retrieved when required, and the words 'scanning' and
'scanner' shall be construed accordingly;(viii)'Software' includes a set of computer programmes or
coded instructions given to the computer systems to make the latter perform different,
predetermined functions and to generate the desired output.
222. Responsibility of the Inspector General
 (1) The Inspector General of Registrations shall be responsible for administration of CARD and for
ensuring substantial compliance with the provisions of this chapter. For this purpose the Inspector
General may issue suitable circular instructions and such instructions have the force of standing
orders for strict compliance by all the registering officers.(2)For the purposes of the sub-rule(1), the
Inspector General shall specify, from time to time, the configuration of hardware and the software to
be used in different categories of registration offices as may be required.(3)The Inspector General
shall also cause supply of the hardware and the software specified in sub-rule (2) at all the
registering offices, in respect of which a notification has been issued by the Government under
Section 70-B of the Act.(4)It shall be the basic responsibility of the registering officers to ensure that
the hardware and software so supplied is always kept in a good state to ensure the continued
availability of the card services. The registering officers shall, at all times, use only the software
notified and certified by the Inspector General and no other software.(5)The Inspector General shall
make adequate arrangements, including maintenance of the required stand by systems and spares
and retention of the services of technical personnel, as may be required to enable the registering
officers to comply with sub-rule(4)
223. Procedure to be followed
 The registering officers shall follow the provisions of the Act and rules in all matters other than
those covered by this chapter. In case of a conflict between any provision of this chapter and any
other rule, the provision of this chapter shall prevail in relation to any computerized process
specified in this chapter.
224. Presentation of Documents
 (1) When a document is presented to him, the registering officer shall satisfy himself that it is fit to
be accepted for registration with reference to all the provisions of the Act, rules and the Standing
Orders. In addition, he shall satisfy himself that the writing is legible and not faint or indistinct and
that the document is written and signed in dark black ink such as is fit for being scannedAndhra Pradesh Rules Under the Registration Act, 1908

properly.(2)All documents presented for registration under Computer Aided Administration of
Registration Department, shall be accompanied by an input form in the proforma given in Appendix
Xl. The registering officer may arrange to provide such assistance to the registering public as may be
required to enable them to fill up the input forms and to avail the various services offered by the
department without any difficulty.(3)Upon satisfying himself that the provisions of the sub-rules(1)
and (2) are complied with, the registering officer shall affix his signature on the input form
indicating the date and time of presentation.(4)The registering officer shall thereupon cause the
presentation endorsement to be impressed in black ink or to be printed by the Computer Aided
Administration of Registration Department system as specified in Rule 52(1) (a) on the reverse of
the first stamp paper used for writing the document.(5)The procedure required under Section 35 of
the Act shall then be followed with regard to the admission of execution.(6)The registering officer
shall then send the document together with the input form to the computer section for further
process under the CARD system.
225. Registration Checkslip
 (1) The details of the executants, claimants, nature of the document, description of the property
together with its boundaries shall be entered in the computer and a checkslip printed and handed
over to the person presenting the document under an acknowledgement. The Checkslip shall be in
the format shown in the Appendix XII.(2)The mistakes in spelling or in the description of the
property or its boundaries, pointed by the party, in writing and under signature after verification of
the checkslip, shall be corrected in the computer and a revised checkslip shall be printed and
handed over to the party.
226. Issue of Receipt
 (1) The deficit stamp duty, if any, and the registration fee and other amounts indicated in the
registration checkslip, shall then be collected and a receipt printed by the computer shall be issued
to the party. The receipt shall be in the format shown in the Appendix XIII.(2)On payment of the
deficit stamp duty, registration fee and other amounts, the document together with the input form,
the registration checkslip and the receipt shall be sent to the registering officer for verification.
227. Verification by the registering officer
 The details of the registration checkslip and the receipt shall be verified by the registering officer
with reference to the original document to satisfy himself as to the-compliance with the Act, rules
and the standing orders and the adequacy of the stamp duty paid.
228. Registration of the Document
: (1) After completion of the procedure prescribed in the Rules 223 to 227, the registering officer
shall admit the document to registration in terms of the provisions of Sections 58 and 59.(2)The
registering officer shall then assign a regular number to the document and mark it in dark ink on allAndhra Pradesh Rules Under the Registration Act, 1908

the sheets of the document.
229. Endorsements and certificates
: (1) The endorsements and certificates required to be made under Sections 58 and 59 and the
relevant Registration Rules, shall be made on the document in accordance with the procedure
prescribed.(2)The certificate of registration required to be made under Section 60 of the Act, shall
be made in the format shown below in respect of the documents registered under the Computer
aided Administration of Registration Department system:Registered as No ......... of ............. of
books 1 ............... day of .......... 200/ ........... S.E.Signature of Registering Officer.(3)The
endorsements may be made by using any or a combination of the following methods:(i)by writing in
hand using black ink;(ii)by impressing a rubber stamp using black ink;(iii)by getting the
endorsements and certificates printed suitably on the reverse of the stamp papers using the feature
provided for the purpose in the Computer-aided Administration of Registration Department
system.(4)The endorsements and certificates, however so made as above, shall be authenticated by
registering officer.
230. Scanning of the documents
 (1) After the process of affixing the endorsements and certificates is completed, the document shall
be scanned, on both the sides of all the sheets including the maps and plans accompanying the
document, using the scanner and the imaging software provided.(2)The registering officer shall
satisfy himself that the document has been properly scanned following the procedure laid down by
the Inspector General in this behalf. Thereupon, the following certificate shall be affixed on the
reverse of the stamp paper used for writing the document, below the certificate of
registration:Certificate of ScanningThe document has been scanned with the Identification Number
..........Signature of Registering Officer(3)The documents presented for registration and registered
alone should be scanned and copies of documents should not be scanned.
231. Return of the Document
 (1) After satisfying himself that the procedures prescribed in the Rules 223 to 230 are complied
with, and especially that the document has been properly scanned the registering officer shall return
the document to the person authorized to receive the same, duly obtaining an acknowledgement
therefor.(2)For the purpose of monitoring and recording the receipt and return of the document, the
registering officer shall maintain a "Document Register" in the format shown in the Appendix XIV,
entries in the columns(1) to (8) shall be made at the time of presentation, in the column (9) while
assigning a regular number to the document and in columns (10) to (14) while returning the
document to the authorised person.
232. Archiving of the images
: (1) The images of the scanned documents together with the data relating thereto shall be archivedAndhra Pradesh Rules Under the Registration Act, 1908

on to CDs or tapes suitably labelled, using the CD writer and the computer under the
Computer-aided Administration of Registration department system, as soon as the documents are
scanned.(2)CD or tape after it is completely filled with images of scanned documents, duplicate and
triplicate copies of such a CD or tape shall be generated, following such procedure as may be
specified by the Inspector General in this behalf.(3)The duplicate copy of CD or tape shall be
suitably labelled and sealed and shall be sent to District Registrar within three days from the date of
generation.(4)The duplicate copies of CDs and Tapes shall be preserved with District Registrar and
shall be used for being produced as evidence whenever summoned by Courts. The triplicate copies
of CDs and Tapes shall be sent to Inspector General of Registration and Stamps in the first week of
January, April, July and October every year for preservation.(5)The CDs and the tapes shall be
preserved in such conditions and taking such precautions as may be specified by the Inspector
General in this behalf.(6)The CDs and the tapes shall be recopied or re-archived at such periodic
intervals as the Inspector General may specify.(7)[ A Complete working set of Card hardware
system, with a set of instructions to install the same shall be preserved in the Central Archival Room
to cover the risk against technological obsolescence, whenever major hardware architectural
changes occur. One set of the new hardware should be preserved in the Central Archival Room for
further use.][Added by G.O.Ms.No. 338, Rev. (Reg. 1) Dated 24.5.2001, w.e.f. 5.2.1999, Published in
Andhra Pradesh Gazette, RS Part I (extraordinary) No. 24, Dated 28.5.2001.]
233. Documents registered manually
 (1) Certain documents will have to be registered manually under the following
circumstances:(i)Categories of documents not notified by the Government under Section 70-B of the
Act for Registration under the Computer Aided Administration of Registration Department
System;(ii)Documents presented for registration when the Computer aided Administration of
Registration Department system is out of order;(iii)Documents which, in the opinion of the
registering officer can not be registered under the Computer Aided Administration of Registration
Department system.(2)The registering officer shall register the documents described in sub-rule (1)
(iii) using the manual system, duly recording the reasons for resorting to manual system in the
minute book.(3)The details of the documents registered in Book I manually shall be posted to the
computers before the close of official business in respect of the categories (i) and (iii) mentioned in
sub-rule(1) and as soon as the Computer-aided Administration of Registration Department system
is restored in respect of the documents mentioned at (ii) of the sub-rule(1). This is required to
ensure that the index particulars are complete in all respects irrespective of whether certain
documents are registered manually.(4)[ To deal with the situation arising on account of:][Added by
G.O.Ms.No. 338, Rev. (Reg. 1) Dated 24.5.2001, w.e.f. 5.2.1999, Published in Andhra Pradesh
Gazette, RS Part I (extraordinary) No. 24, Dated 28.5.2001.](a)documents missing in CDs., soft
copy not found in the system i.e., hard disk;(b)documents scanned and archived with poor quality
image;(c)Image of documents are missing;(d)documents scanned and archived in irregular order;
and(e)documents scanned and archived with wrong documents.[Note: A special volume shall be
opened by obtaining permission of the District Registrar in writing and all such documents
mentioned in sub-rule (iv) above shall be 'Rescanned' or transcribed manually from the original
document (duly recording the reasons in the minute book) by making a note at foot of the entry
concerned.][Substituted by G.O.Ms.No. 407, Rev. (Reg. I), Dated 5.7.2002, Published in AndhraAndhra Pradesh Rules Under the Registration Act, 1908

Pradesh Gazette RS to Part I, ext. No. 34, Dated 12.7.2002.]
234. Indexing
 (1) The Computer-aided Administration of Registration Department system maintains the Indexes
I and II, specified in Chapter XIX, automatically in respect of all documents registered under the
Computer-aided Administration of Registration Department system and also the documents
registered manually but whose details are posted into the computer in pursuance of the sub-rule (3)
of Rule 233.(2)Copies of the digital data of the Indexes may be maintained in such manner and in
such number of copies and at such places as the Inspector General may specify.
235. Encumbrance certificates
 (1) Encumbrance certificates may be generated and issued under the Computer-aided
Administration of Registration Department system conducting the search of the database
electronically.(2)The result of search shall be preserved electronically for a period of twelve years.
236. Revocation, cancellation and rectification of deeds already registered
 (1) When a deed purporting to revoke, cancel or rectify a deed previously registered under the
manual system, is presented for registration, such deed may be registered following the procedure
prescribed in this Chapter and the foot-notes specified under Rule 118, shall be made on the copy of
the document in the respective volume.(2)When a deed purporting to revoke, cancel or rectify a
deed previously registered under the Computer-aided Administration of Registration Department
system is presented for registration, such deed may be registered following the procedure prescribed
in this chapter and contra entries posted to the record relating to the original deed and a memo in
the nature of a foot-note shall be appended to such record so that the foot-note is printed invariably
when the original document is sought to be printed.
237. Security
 (1) Adequate security systems shall be developed and implemented to ensure that the data and
images of the documents registered under the Computer-aided Administration of Registration
Department system are preserved without any scope for loss, corruption or unauthorized
access.(2)It shall be the responsibility of the registering officer and all the employees authorized to
handle the systems to ensure that the security measures prescribed are strictly adhered to and that
the passwords and access devices are maintained confidentially at all times.(3)The Inspector
General shall review the security plan periodically, at least once a year, to ensure that the security
standards of the highest order are always maintained.Appendix I(Rule 12)Book 1: Register of
non-testamentary documents relating to immovable property.Book 2: Record of reasons for refusal
to register.Book 3: Register of wills and authorities to adoptBook 4: Miscellaneous register.
Copy of document Copy of endorsement and certificatesAndhra Pradesh Rules Under the Registration Act, 1908

DocumentNo.....(1) No.of......19... Stamp(2)
Name and additions of the Presentant.(3) Name
and additions of executants.(4) Name and
additions of persons examined.(5) Abstract of
document together, with the names of all
claimants and all attesting witnessesof......19 .....Date of dated and Hour of Document
Presentation.Reasons For Refusal(Note:-When a
document is refused registration on appeal,
ordered to be registered or when the refusal is
confirmed a note of the fact shall be entered at the
foot of this column.)
Date :Signature of Registering OfficerNote: If the document is partially registered, it will suffice to
enter under this, the number of the document with the volume and page.Note: Columns (2) to (5)
need not be filled up in the case of refusals by the Registrar in appeal. But number and year of
appeal and the names of the appellant and respondent shall be entered at the top of the column
"Reasons for refusal".Book 5: Register of Deposits of Wills.
1. Number of 19
2. Date & hour of presentation.
3. Name and addition of Testator.
4. Name and addition of Agent, if any.
5. Superscription on sealed cover.
6. Number of seals.
7. Inscription on the seal.
8. Names and addresses of persons testifying to the identity of the depositor.
Date : Signature of Registrarwith date
9. Date of application to withdraw sealed cover.
10. Names and addresses of persons testifying as to the identity of applicant.
11. Date of delivery of sealed cover to applicant.
Signature of ApplicantSignature of Registrar with date
12. Number of document in Book 3.Andhra Pradesh Rules Under the Registration Act, 1908

13. Whether opened after the death of the testator or on requisition from
Court.
(a)Date of requisition of Court.(b)Date of its return, when returned.Appendix II(Rule
46)Commission under Section 33 or Section 38 of the Indian Registration Act.To XY.Whereas the
accompanying power of attorney (document dated the ....... and purporting to have been executed by
A.B. has been presented for attestation (registration) in this office and whereas it is necessary it
should be ascertained whether it has been voluntary that ........ son of........ executed by the person by
whom it purports, to have been .......... executed, residing at .......... in your Sub-District .......... should
be examined, in connection therewith. You are requested to take/order ...... the examination of .......
upon the interrogatories hereunto attached and to return this commission with the examination of
the said ....... to this office on or before the .......... day of ........Given under My Hand and seal this
.......... day of ........... 19 ................(Seal)Signature of Registering OfficerAppendix III(Rule
55)Abstract of Power of Attorney
Consec. Number
StampsDate of Execution Date of attestation
1. ............... of 19 ..........  
2.Name of the principal executing the
power with addition. 
3. Name of attorney with addition.  
4.Names of persons if any, who
identified the principal,
withaddition. 
5. Nature of Power.  
6.Notes of interlineations, etc. under
Rule 49. 
7. How attested—On the execution of the power before the
Registering Officer.On the Registering
Officer's personal examination.On the
Commission's report.
8. If also Registered of. Registered as No. .... of 19... Book Vol. pp.
Note: When a power is attested and registered at the same time Columns 4 to 6 need not be filled
up.Office :Date :Signature of the Registering Officer.Appendix IV(Rule 63)Register of Thumb
Impression
Signature and impression of the
left thumb of the Executant of
Document with date and initials
of the Registering OfficerNumber Book
and year of
documentSignature and impressions of
the left thumb of the Executant
with date and initials of the
Registering OfficerNo. Book and
year of
document
1 2 3 4
Note: (1) When an impression has been obtained from a person other than the executant or when a
finger other than the left thumb has been used in affixing impression, the fact should be noted underAndhra Pradesh Rules Under the Registration Act, 1908

the impression.(2)When an impression is not clear and second or third impression is therefore
taken the indistinct impressions shall not be cancelled, but shall be noted as "first" impression,
second impression and so on; all the impressions being bracketed together."Each impression on this
page has been affixed in my presence and under my supervision by the person whose name is
entered next to it".Date :Signature of the Registering OfficerAppendix V(Rule 85)Sample Forms of
Endorsements and Certificates under Sections 52, 58, 59 & 60(Section 52)Presented in the Office of
the (Sub) Registrar of ........... and fee of Rs. .......... paid between the hours of and ........ on the
............. 19 ... by ..........Signature (A.B).(Executant or his representative or assign or the agent of
such Executant or representative or assign or claimant or his representative or assign or the agent of
such claimant or representative or assign.Identified by the (First, Second Etc.) ExecutantIdentified
bySignature of C.D. with additionSignature of E.F. with additionDate :Signature of Registering
OfficerNote: (1) When a document is presented for registration at a private residence, the word "at
a private residence of ........... in village (or at No. .......... Street)" shall be substituted for the words
"in the office of (Sub) Registrar of ................(2)When a document is refused registration by a
Sub-Registrar but ordered to be registered by the Registrar or the Court on appeal or suit is
represented to Registrar or the Court on appeal or suit is re-registered by the Registrar or the Court
on appeal or suit is re-presented to Registering Officer for registration. the words "presented again"
in the office of the Sub-Registrar of .......... under the order/decree of the Registrar/Court of ............
dated ......... passed in Appeal/Suit No. .......... of and fee of Rs. ........... paid between the hours of on
the ............ 19 .......... by..........." shall be substituted for words "presented in the Office of the (Sub)
Registrar ......... of .......... and fee of Rs. ............ paid between the hours of........... and on the 19 .........
by ............."(3)The form "identified by the (first, second etc.,) Executant" shall be used when a
document is presented by a person other than the executant and the presentant is identified by the
executant, and the form, "identified by signature C.D. with addition, signature E.F. with addition"
shall be used when a document is presented by a person other than the executant and the presentant
is identified by a person who is not the executant.(4)When a document is presented by a messenger
under Rule 25(ii) the following endorsement shall be made thereon."Presented in the office of the
(Sub) Registrar of and fee of Rs. .......... paid between the hours of ............ and ....... on the ........... 19
........ with letter No. dated ........ from ....... by .............Left Thumb Impression and Signature(5)When
a document is presented by a person other than the executant or his representative or assign or the
agent of such executant or representative or assign the impression of the presentant shall also be
taken unless he is personally known to the Registering Officer".(6)When presentation alone is made
by an agent under a Power of Attorney reference to the Power of Attorney shall be given in the
endorsement.Section 58Execution (and receipt of Rs. ........... being consideration in whole or in
part) admitted by .............Signature of C.D. with additionsKnown Personally to the (Sub)
Registrar.(Impression)Left thumb.Signature E.F. with addition, representative or assign of G.H.
(Impression) Left middle finger.Signature of A.B. with Addition (Agent of I.J)Under a general (or
special) power of attorney, dated ....... and authenticated by the Sub-Registrar of ......Identified by
:Signature M.N. with additionSignature C.D. with additionWitness examined: Signature
WX(Hammamnee)with additionRupees ........ were paid (or jewels described in the instrument were
delivered) in my presence by ........... toDate :Signature of Payer (or deliverer)Signature of Payee (or
recipient)Signature of Registering OfficerNote: (1) When executant C.D. admits execution of the
document but declines to affix his signature thereto, the words "Execution admitted by C.D. (with
addition) who however declines to affix his signature to the endorsement" shall be substituted forAndhra Pradesh Rules Under the Registration Act, 1908

"Execution admitted by "Signature C.D. with addition".(2)When execution is admitted at a private
residence the words "at the private residence of ......... in ......... village "admitted" and "by" (or at No
............. Street)", shall be inserted between the words "admitted" and "by".(3)When a document is
executed by an Officer of Government or any of the public functionaries mentioned in sub-section
(i) of Section 88, the Registering Officer on being satisfied of the execution thereof shall make the
endorsements in the following form instead of the endorsement or execution admitted by":"I have
satisfied myself as to the execution of the instrument by........ who is exempted from personal
appearance under sub-section (i) of Section 88 of the Indian Registration Act".(Section
60)Registered as No ......... of 19 ........... of Book ........... Volume ............ Page ...............Date
:SealSignature of Registering Officer,(when registration is partially effected in the first
instance)Registered as No. .............. of Book ......... volume ............. page as regards E.F. with
addition (or as regards property to be described in brief).Date :SealSignature of Registering
Officer,Registration refused as regards G.H. (with addition) or as regards property to be described in
brief.Date :SealSignature of Registering Officer.(When a document refused registration by a
registering officer is registered under the orders of the Registrar of the Court)Registered as No
.......... of 19 ............. of Book ............. volume ........... page as regards G.H. (with addition).Date
:SealSignature of Registering Officer,Appendix VI(Rule 120)Index No. I
19. ................
Name of
executantClaimant AdditionVillage or place
where property
is situatedOffice of original
RegistrationVolumeFirst
page of
entryNo. of
Documents
1 2 3 4 5 6 7 8
Index No. 2
Village
or place
in which
property
is
situatedName and
description
of propertyExecutive Presentation RegistrationNature and
value of
TransactionExecutants ClaimantsOfficer of
Original
RegistrationVolumeFirst
page
of
entryNumber of
documents
1 2 3 4 5 6 7 8 9 10 11 12
Subsidiary Index(Rule 125)
Survey Number and Sub-Division Number and year of Documents registered
1  
2-A.  
2-B.  
3  
4-A. (1)  
4-A. (2)  
Index Nos. III and IV(Rule 120)
Name of Executant Claimant Addition Volume First page of entry Nature of DocumentAndhra Pradesh Rules Under the Registration Act, 1908

1 2 3 4 5 6
Appendix VII(Rules 140 and 141)Certificate of Encumbrance on propertyCertificate No. ............ of
19Application No. ............. of 19Having applied to me for a certificate giving particulars of registered
acts and encumbrances, if any, in respect of undermentioned property :(To be stated and described
as given in the application)I hereby certify that a search has been made in Book I and in the indexes
relating thereto ........ years from the ........ day of 19 ............. to, the ....... day of 19 ......... for acts and
encumbrances affecting the said property, and that on such search the following acts and
encumbrances appear :
Sl. No.(a) Description of
propertydated of
Exeution(b) Nature and value
of documentsNames of
PartiesReference to
document entry
Executant Claimantvolume No.
and year
1 2 3 4 5 6 7
(a)Enter the description as given in the document found.(b)(1) In the case of a mortgage-deed enter
rate of interest and period of payment, if stated therein.(2)In the case of leases enter term of lease
and annual rental.I also certify that save the aforesaid acts and encumbrances no other acts and
encumbrances affecting the said property have been found.Search made and certificate prepared
by(Signature)(Designation)Search verified and certificate examined
by(Signature)(Designation)Office:Date :(Seal)Signature of Registering OfficerNote: (1) The acts
and encumbrances shown in the certificate are those discovered with reference to the description of
properties furnished by the Applicant. If the same properties have been described in registered
documents in a manner different from the way in which the applicant has described them,
transactions evidenced by such documents will not be included in the Certificate.(2)Under Section
57 of the Registration Act and Rule 137(i), persons desiring to inspect entries in the registers and
indices, or requiring copies thereof or requiring certificates of encumbrances on specified properties
should make the search themselves, when the registers and indices will be placed before them on
payment of the prescribed fees.(a)But, as in the present case, the applicant has not undertaken the
search himself, the requisite search has been made as carefully as possible by the Office, but the
Department will not, on any account, hold itself responsible for any errors in the results of the
search embodied in the Certificate.(b)And, as in the present case, the applicant has made, the
requisite search himself and as the acts and encumbrances discovered by him are shown in the
Certificate after verification the Department will not on any account, hold itself responsible for the
omissions in it of any other acts and encumbrances affecting the said properties not discovered by
the Applicant.Nil Certificate of Encumbrance on PropertyCertificate No. ......... of 19Application No.
............. of 19Having applied to me for a certificate giving particulars of registered acts and
encumbrances, if any, in respect of undermentioned property:(To be stated and described as given
in the application)I hereby certify that search has been made in Book I and in the indices relating
thereto for ........ years from ....... the ........ day of ........... 19 .......... to the ....... day of 19 ... for acts and
encumbrances affecting the said property and that on such search no act or encumbrance affecting
the said property has been found.Search made and Certificate prepared by
:(Signature)(Designation)Search verified and certificate examined by
:(Signature)(Designation)OfficeDate :(Seal)Signature of Registering Officer.Note: (1) If the
property has been described in registered Documents in manner different from the way in which theAndhra Pradesh Rules Under the Registration Act, 1908

applicant has described them in the application the transactions evidenced by such documents will
not be included in the Certificate.(2)Under Section 57 of the Registration Act and Rule 137(i),
persons desiring to inspect entries in the registers and indexes, or requiring copies thereof, of
certificate of encumbrances of specified properties should make the search themselves, when the
registers and indexes will be placed before them on payment of the prescribed fees.(a)But as in the
present case the applicant has not undertaken the search himself, the requisite search has been
made as carefully as possible by the office; but the Department will not on any account, hold itself
responsible for any errors in the results of the search embodied in this certificate.(b)And, as in the
present case, the applicant has made the requisite search himself and as its result shown in the
certificate after verification, the Department will not, on any account, hold itself responsible for the
omissions in it of any acts and encumbrances affecting the said property, not discovered by the
applicant.Certificate showing list of Documents executed by or in favour of a personCertificate No.
......... of 19Application No. .......... of 19Having applied to me for a certificate giving particulars of
registered documents executed by or in favour of ...........I hereby certify that a search has been made
for such documents in Books 1, 3 and 4 and in the indexes relating thereto for .......... years from the
day of ......... 19 ............ and that on such search the following appear:
Serial No.Name of Village in
which the property
affected by the
document is situatedDate of
ExecutionNature and
Value of
DocumentsName of
PartiesReference to
Documentary
entry
Executant Claimant Book Volume Page No. Year
1 2 3 4 5 6 78910
I also certify that save the aforesaid documents no others have been found.Documents registered in
Book 3 or Book 4 copies of which the applicant is not entitled to obtain under provisions of Section
57 of the Indian Registration Act are not covered by this Certificate. Search made and certificate
prepared by.(Signature)(Designation)Search verified and certificate examined
by(Signature)(Designation)Office :Date :(Seal)Signature of Registering Officer.Notes: (1) The
documents shown in the certificate are those discovered with reference to the description of the
person furnished by the applicant. If the same has been described in registered documents in a
manner different from the way in which applicant has described it, transactions evidenced by such
document will not be included in the Certificate.(2)Under Section 57 of the Registration Act and
Rule 137 (1) persons desiring to inspect entries in the registers and indexes, or requiring copies
thereof, or requiring certificates, list of documents executed by or in favour of a person should make
the search themselves, when the registers and indexes except Book Nos. 3 and 4 and the indexes
relating thereto will be placed before them on payment of the prescribed fees.(a)But, as in present
case, the applicant has not undertaken the search himself, the requisite search has been made as
carefully as possible by the office ; but the Department will not on any account hold itself
responsible for any errors in the result of the search embodied in the Certificate.(b)And as in the
present case, the requisite search for entries in Book Nos. 3 and 4 has been made by the Registering
Officer as carefully as possible and by the applicant himself in regard to entries relating to Book 1
and as documents so discovered are shown in the certificate after the verification, the Department
will not on any account hold itself responsible for any errors in the results of the search embodied in
the certificate.Appendix VIII(Rule 152)Memorandum Under Sections 64, 65, 66 & 67Andhra Pradesh Rules Under the Registration Act, 1908

Office of Original Registration Volume First page Entry No. and Year of Document
1 2 3 4
1.   
2. Previous registration :  
3. Date of execution :  
4. Date of Registration  
5. Names and additions of Executants:  
6. Names and additions of Executants:  
7. Names and additions of Claimants:  
8. Nature and value of transaction :  
9.Village or Place and Sub-District in which property issituated and
the name and description of property.: 
 Prepared by (Signature) Designation
 Examined by (Signature) Designation (Reader)
 (Signature) Designation (Examiner)
 
Date
:SealSignature of
Registration Officer
Note: A detailed description of property lying in a sub-district other than that to which the
Memorandum is sent need not be entered in column 9, but, instead, the names of the villages in
which the properties of those sub-districts are situated shall be shown separately.Appendix IXForm
A(Rule 202)Application for Document Writer's Licence
1. Full name with father's/husband's name :
2. Permanent address, local address :
3. Age and date of birth :
4. Nationality :
5. Educational qualifications if any whether he has passed the Document
Writer's Licensing test :
6. Service as Document Writer with approximate number of documents
prepared and presented for registration during the past one year:Andhra Pradesh Rules Under the Registration Act, 1908

7. (a) if possessing a Degree in Law or Pleadership certificate:
(i)particulars with length of service at the Bar if any,(ii)whether dismissed or suspended at any time
from practising by any order of a competent court :(b)if retired from Government Service in
Registration Department(i)the post held immediately before retirement,(ii)whether passed the tests
prescribed for Sub-Registrar's post,(iii)whether dismissed or compulsorily retired for misconduct :
8. Nature of licence applied for whether it is for a village (name of the village
with sub-district in which it is situated to be named) or for a sub-district (to
be named) or for a district (to be named) or for the whole State
9. State here the amount, number, date of challan receipt and the name of the
treasury. :
10. Has an application for licence ever been refused ? If so when and for
what reason, give particulars :
DeclarationI (here enter name in full) do hereby solemnly declare that I am not suffering from
Leprosy, that I have not been declared to be of unsound mind or convicted for any offence, involving
moral turpitude or adjudged as insolvent by any court of competent jurisdiction and the information
and particulars furnished herein are true and correct to the best of my knowledge and belief and the
licence for which I hereby apply be used only by myself.I am a Village Officer of ........................
Village/Villages and undertake not to leave my charge village or villages, in connection with my
work as a document writer to the detriment of Government work.To be struck off wherever not
applicable. Place :Date :SignatureEnclosure: Challan ReceiptNote: (1) The licence issued on the
strength of this application is liable to suspension or cancellation at any time if it is found that any
information or particulars furnished in the application are false or not true or incorrect.(2)The
application shall be accompanied with a true extract of his name with other particulars published in
the Andhra Pradesh Gazette in token of securing a pass in the Document Writers' Licensing Test or a
true copy of the degree in law or pleadership certificate as the case may be duly attested by a
Government Officer of not lower than the rank of Sub-Registrar or a member of the State
Legislature or Parliament or the President of a Panchayat.(3)The duplicate of the Challan issued by
the Treasury or Bank shall be also enclosed.Form B(Rule 202)Application for Renewal of Document
Writer's Licence
1. Full name with father's/husband's name :
2. Address, permanent home address Local address with full details :Andhra Pradesh Rules Under the Registration Act, 1908

3. Changes in Local address :
4. Details of previous licence number :
5. Period for which renewal is sought :
6. Date of last renewal :
7. Amount, number, date and name of treasury of challan receipt :
DeclarationI (full name) do hereby solemnly declare that I have not been declared to be of unsound
mind or convicted for any offence involving moral turpitude or adjudged as an insolvent by any
court of competent jurisdiction during the past ......... years.I am a Village Officer of .............
Village/Villages, and undertake not to leave my charge village or villages, in connection with my
work as a document writer to the detriment of Government work.To be struck off wherever not
applicable.Place :Date :SignatureEnclosure: Challan receipts and licence in original.Note: (1) The
renewal made on the strength of this application is liable to suspension or cancellation at any time if
it is found that any information or particulars furnished in the application are false, or not true or
incorrect.(2)The duplicate of the challan issued by the treasury or Bank shall be enclosed to the
application.Form C(See Rule 207)Register of Document Writer's Licence
Amount
paid(..........)Licence
valid
for(...........)
Serial
NumberLicence
NumberDateName of
LicensesAddressDate of
PaymentChallan
No.Sub-
treasury
at which
remittedWhole
StateDistrict
with
nameSub-District
or village
with nameDate of
issue of
licence
or
renewalRemarks
1 2 3 4 5 6 7 8 9 10 11 12 13
Form D(Rule 207)Document Writer's LicenceNumber of licence :Name of Document Writer
:Addressof : Village (sub-district)District/StateThe aforesaid .......... having paid the necessary fees
and having made the necessary declaration is hereby authorised to practise as a document writer to
the village of .......... in the Sub-District of ........ at document writer attached of the Sub-Registry
office in.........Dated :Office of the Licensing AuthoritySignature of the Licence Holder(to be made as
soon as the licence is received)Conditions(a)The licensee shall abide by the rules relating to the
licensing of document writers.(b)He shall maintain the register, receipt books and other records
prescribed by the rules to be maintained or that may be required to be maintained by the licensing
authority.(c)He shall surrender to the licensing authority registers and receipt books at the end of
each calendar year or if his licence is expired, revoked or suspended within 15 days from the date of
such expiry or revocation.(d)He shall not demand or accept any sum from parties in the name of any
Person or persons connected with the Registration office.(e)He shall render true and correct account
of the moneys, he received from parties and produce records maintained by him for inspection asAndhra Pradesh Rules Under the Registration Act, 1908

such time before such officer as may be authorised to inspect them by the licensing authority or the
Inspector-General of Registration.(f)He shall write or cause to be written documents neatly, legibly
in clear and unambiguous terms and in accordance with, the instructions that may be issued from
time to time by the Inspector-General of Registration.(g)He shall instruct the parties their duly
authorised agents to present documents or petitions, and to pay the fees in person direct to the
Registering Officer and not through any other agency.(h)He shall obey any directions that may from
time to time be issued by the Inspector-General of Registration regarding the preparation of deeds
for registration.(i)He shall not levy more than the fee prescribed in Appendix-X.(j)He shall not abet
or participate in any illegal transaction or dealings with the staff attached to the Registration
Offices.(k)He shall set forth fully and truly the consideration of the value and all other facts and
circumstances affecting the chargeability with duty or the amount of duty with which it is
chargeable.(l)He shall not act as tout.(m)He shall not appear as an identifying witness of any one
connected with the registration of any document.(n)He shall not take delivery of any registered
document from the Registering Officer or present any application for a single or general search or
for a certified copy of extract unless he is personally interested in the matter.(o)If the licensee is a
Village Officer, he shall not leave his charge village or villages in connection with his work as a
document writer to the detriment of Government work.Note: The Licence will be liable to
suspension or cancellation for a breach of any of the above conditions.Form E(Rule 213)Register of
DocumentsName of Document Writer .......... attached to the ............ Holder of Licence Number
........ Office of ...................
Serial
No.DateName of
party (
executant
or claimant
of the
deep)Nature of
documentValue of
document
considerationNumber of
stamps
produced
together
with valueName of the
sub-Registry
Officer of
registrationSignature of
the party in
token of
reception of
document
with dateRemarks
1 2 3 4 5 6 7 8 9
Note: Alterations, erasures and interlineations should be attested by the Document Writer
concerned with initials.Form F(Rule 213)CounterfoilNo ............Station ..............Date
..................Received from .................. the sum of Rs. .............. (in words) ............ It has been dealt
with as shown hereunder:
(a) Value of (i) Stamp Paper If purchased through him :
 (ii) other paper Rs. P.
(b) Fee for drafting :   
 Total :  
Sd/-Document Writer.Excess amount returned to party :Received the document and the excess
amount of Rs. ....(Signature of the party)Note: In the case of illiterate party, his thumb impression
should be obtained.Appendix X [Substituted by G.O.Ms.No. 732, Rev. (Regn. I), dated 03.09.1997,
Published in Andhra Pradesh Gazette, Part I, Dated 25.09.1997.](Sub-rule (c) of Rule 204)Andhra Pradesh Rules Under the Registration Act, 1908

of fee for preparation of Drafts and documents
Sl.
No.Value of the Document or
considerationFees for drafting or preparation of
document including the
preparations of all the forms,
statements and annexures repaired
for completing for registration of
such documentsFees for drafting or
preparation of
documetns alone
without preparation of
forms, annexures etc.
1 2 3 4
1.When the value or consideration
(whichever is higher) does not
exceed Rs. 500/-.10.00 8.00
2.When the value or consideration
(whichever is higher) exceeds
Rs. 500/- but does not exceed
Rs. 1,000/-.20.00 16.00
3.(i) When the value exceeds Rs.
1,000/- for the first Rs. 1,000/-
as under SI. No. 2 and for every
Rs. 500/- or part thereof in
excess of Rs. 1,000/-.4.00 3.00
 (ii) Subject to a maximum of 100.00 80.00
4.When the document is not
susceptible to money valuation
or if no value or consideration is
expressed.50.00 50.00
5. Special power of Attorney 10.00 10.00
6.General Power of Attorney or
Deed of Divorce.20.00 20.00
Transfer Duty [Source : Diary 2012 Issued by the Andhara Pradesh Sub-Registrars' Association,
Recognised by the Govt. of Andhara Pradesh (Regd. No. 169/1965).]
1. The Duty on transfers of property has been fixed at 3% in respect of
Panchayats from 1.7.2005 (vide Notification-I of G.O.Ms.No. 239 Panchayat
Raj and Rural Development (PTS III) DePart Dated 30.6.2005.
2. The Duty on transfers of property has been fixed at 2% in respect of Flats /
Apartments in Panchayats areas from 1.7.2005 (vide Notification-III of
GO.Ms.No.239, Panchayat Raj and Rural Development (PTS.III) Dept. Dated
30.6.2005.Andhra Pradesh Rules Under the Registration Act, 1908

3. Tax on Transfer of property in all the Municipal Corporation areas has
been fixed at 2% without any deduction towards collection charges w.e.f.
1.7.05 vide G.O.Ms.No.622, Mpl.Admn. & Urban Development (TC.I)
Department, Dated 27.6.05.
4. Duty on Transfer of property in all Selection/Special Grade Municipalities
has been fixed at 2% without any deduction towards collection charges w.e.f.
1.7.05 vide G.O.Ms.No. 623 Mpl. Admn. & Urban Development (TC.I)
Department, Dated 27.6.05.
5. Duty on Transfers of property in Municipalities other than Selection or
Special Grade Municipalities has been fixed at 3% without any deduction
towards collection charges w.e.f. 1.7.05. vide G.O.Ms.624, Mpl.Admn. & Urban
Development (TC.I) DePart Dated 27.6.05.
6. Tax on transfer of property in Municipal Corporations has been fixed at 2%
without any deduction towards collection charges on all the sale deeds of
flats/apartments w.e.f. 1.7.05 vide Notification I of GO.Ms. No. 625, Mpl.
Admn. & Urban Development (TC.I) dePart, Dated 27.6.05.
7. Duty on transfer of property in municipal areas of the State has been fixed
at 2% without any deduction towards collection charges on all sale deeds of
flats/apartments w.e.f. 1.7.05 vide Notification-II of G.O.Ms.No. 625,
Mpl.Admn. & Urban Development (TC.I) Dept. Dated 27.6.05.
Transfer Duty At Glance [Source : Diary 2012 Issued by the Andhara Pradesh Sub-Registrars'
Association, Recognised by the Govt. of Andhara Pradesh (Regd. No. 169/1965).]
Sl. No. Name of the Local Body Rate of Transfer Duty Collection Charges
(1) Municipal Corporation of Hyd.
 (a) Flats 2% No Deduction
 (b) Others 2% No Deduction
(2) Municipal Corporations
 (a) Flats 2% No Deduction
 (b) Others 2% No Deduction
(3) Spl/Selection GR Municipalities
 (a) Flats 2% No Deduction
 (b) Others 2% No DeductionAndhra Pradesh Rules Under the Registration Act, 1908

(4) Other Municipalities (other than above)
 (a) Flats 2% No Deduction
 (b) Others 3% No Deduction
(5) Panchayats
 (a) Flats 2% Deduct @ 5%
 (b) Others 3% Deduct @ 5%Andhra Pradesh Rules Under the Registration Act, 1908

