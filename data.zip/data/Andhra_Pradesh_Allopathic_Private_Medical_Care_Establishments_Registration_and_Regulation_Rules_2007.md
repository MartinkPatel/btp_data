Andhra Pradesh Allopathic Private Medical Care Establishments
(Registration and Regulation) Rules, 2007
ANDHRA PRADESH
India
Andhra Pradesh Allopathic Private Medical Care
Establishments (Registration and Regulation) Rules,
2007
Rule
ANDHRA-PRADESH-ALLOPATHIC-PRIVATE-MEDICAL-CARE-ESTABLISHMENTS-REGISTRATION-AND-REGULATION-RULES-2007
of 2007
Published on 28 April 2007• 
Commenced on 28 April 2007• 
[This is the version of this document from 28 April 2007.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation)
Rules, 2007Published vide Notification No. G.O. Ms. No. 135, Health, Medical and Family Welfare
(K2), dated 28.04.2007Last Updated 19th September, 2019No. G.O. Ms. No. 135. - In exercise of the
powers conferred under Section 18 of Andhra Pradesh Allopathic Private Medical Care
Establishments (Registration and Regulation) Act 2002 (Act 13 of 2002) the Governor of Andhra
Pradesh hereby makes the following rules for the registration and regulation of the Allopathic
private medical care establishments: -
1. Short Title, extent and commencement.
(1)These rules may be called the Andhra Pradesh Allopathic Private Medical Care Establishments
(Registration and Regulation) Rules, 2007.(2)These rules extend to the whole of the State of Andhra
Pradesh and are applicable to all the Allopathic Private Medical Care Establishments in the State of
Andhra Pradesh(3)These rules shall come into force on the date of their publication in the Andhra
Pradesh Gazette.
2. Definitions.
- In these Rules, unless the context otherwise requires: -(a)'Act' means the Andhra Pradesh
Allopathic Private Medical Care Establishments (Registration and Regulation) Act, 2002.(b)Rules'Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

means the Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and
Regulation) Rules, 2007(c)'State Level Advisory Committee' means the Committee constituted
under Section 5A of the Act.(d)'District Level Advisory Committee' means the Committee
constituted under Section 5C of the Act.(e)'Establishment' means Allopathic Private Medical Care
Establishment(f)The words and expressions used herein and not defined but defined in the Act,
shall have the same meanings respectively assigned to them in the Act.
3. Authorities.
(1)The composition of following Authorities shall be notified by Government from time to time for a
period of 3 (three) years: -(a)A.P. Allopathic Private Medical Care Establishment Registering
Authority (APMCERA)(b)State Level Advisory Committees (SLAC)(c)District Level Advisory
Committees (DLAC)(d)State Level Appellate Board (SLAB)(e)District Registering Authority
(DRA)(2)The Committees shall meet at least twice in a year and the gap between the two meetings
shall not exceed 6 (six) months.(3)The Member - Convener shall send notice of the proposed
meeting to the members of the Committees concerned at least 15 days in advance, indicating time,
dated and place of the meeting.(4)The Member Convener shall attend such functions and duties as
may be assigned to him/her by the Chairman from time to time.(5)The Chairman of the District
Registering Authority i.e. DM and HO shall receive the application in the prescribed Form-I
annexed to these rules from - the Establishments for registration along with the fees prescribed in
Rule 15.
4. Registration.
(a)The Allopathic Private Medical Care Establishment shall submit the application in the prescribed
in Form-I (in duplicate) to District Registering Authority i.e. DM and HO of the District concerned
for registration of Private Medical Care Establishments along with the fees prescribed in Rule
14.(b)If a private medical care establishment is offering services in more than one category as
specified in the table given below, the establishment shall apply for separate registration for each
type of category: -
Category No. Description of Establishment
1. Clinics/consultation rooms (Solo Practitioners)
2. Poly Clinics (Group Practitioners)
3. Hospitals/Nursing Homes less than 20 beds
4. Hospitals/Nursing Homes with 21 to 50 beds
5. Hospitals/Nursing Homes with 51 to 100 beds
6. Hospitals/Nursing Homes with 101 to 200 beds
7. Hospitals/Nursing Homes with more than 200 beds
8. Diagnostic Centers (Basic Lab facilities)
9. Diagnostic Centres with Hi-end equipment (CT etc.)
10. Physiotherapy UnitsAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

11. Dental Clinics/Hospitals
(c)If a diagnostic center is a part of a hospital, no separate registration is required...(d)The
Chairman of the District Registration Authority or any person in his office authorized in this behalf,
shall acknowledge the receipt of the application for registration immediately in the
acknowledgement slip prescribed in Form II annexed to these rules if delivered at the office of the
Authority, or not later than the next working day if received by post.(e)The fee shall be paid by a
demand draft from any Nationalised Bank drawn in favour of the District Registering Authority of
the District concerned.(f)As soon as an application is filed, a temporary registration certificate in
Form-Ill annexed to these rules shall be issued for a period of ninety days from the date of issue to
the Applicant-Establishment.(g)On receipt of an application for registration, the Registering
Authority shall conduct an inspection of the establishment within ten days by a team of two doctors,
one of whom shall be a Member of either the District Registration Authority or the District Level
Advisory Committee.(h)The inspection Team so, constituted by the Registering Authority shall
inspect and submit a report with reference to the availability of minimum standards prescribed in
Appendix-I and also detailing the specific deficiencies to be corrected, if any.(i)Copy of the
inspection report pointing out the deficiencies, if any, shall be communicated to the
Applicant-Establishment within seven days from the date of receipt of inspection report with a
direction to rectify the deficiencies pointed out and inform the Registering Authority within a period
of two months.(j)The Applicant-Establishment shall cooperate and provide all the relevant
information and necessary assistance to the inspection team for satisfactory completion of the
inspection formalities. Refusal of entry of inspection teams to the Applicant-Establishment and
non-cooperation during inspection is liable for rejection of the application for registration.(k)If the
applicant-establishment does not comply with the direction to rectify the deficiencies pointed out in
the inspection report within a period of two months, the defaulting applicant - establishment may be
given extension of a further period of one month by imposing 50% of the registration fee as
penalty.(l)If the defaulting applicant-establishment does not comply with the direction to rectify the
deficiencies pointed out in the inspection report, even after the expiry of the extended period of one
month, the temporary registration granted to Establishment shall be cancelled, under provisions of
Section-9.
5. Certificate of Registration.
(a)Based on inspection reports, the Registering Authority shall grant the applicant- establishment a
certificate of registration ( in duplicate), in the prescribed Form-IV annexed to these rules, after
satisfying itself that the applicant has complied with all the requirements, criteria, facilities, etc
prescribed in the Appendix-II(1)Infrastructure including buildings(2)Essential medical
equipment.(3)Equipment for protection from radiation.(4)Facility for disposal of bio-medical
waste.(5)Effective maintenance of Sanitation and Hygienic Standards(6)Qualified
Doctors.(7)Qualified paramedical staff.(8)Other essential staff.(9)Previous audit reports evidencing
financial capability.(b)One copy' of the Certificate of Registration shall be displayed prominently at
the reception/ entrance of the Establishment. The Authority shall clearly specify in the certificate
the category under which the Establishment is registered.(c)If, after detailed enquiry and due
opportunity to the applicant the Establishment does not satisfy the standards prescribed for
registration, the registering Authority shall, for reasons to be recorded in writing, reject theAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

application for registration duly cancelling the temporary registration granted earlier. Such rejection
shall be communicated to the applicant in Form V annexed to these rules within a period of ninety
days from the date of receipt of application for registration.(d)The Certificate of Registration shall
be non-transferable.(e)In the event of any change of ownership, management or name of the
establishment, the Registering Authority shall be intimated before such change and the Certificate of
Registration shall be surrendered to the Registering Authority the so as to issue a revised certificate
of Registration after the inspection incorporated the changes.(f)On ceasing to function as a
Establishment, or in case there is a change of category or change in address, both copies of the
certificate of registration shall be surrendered to the Registering Authority and fresh registration
shall be obtained after following the prescribed procedure.(g)The Certificate of Registration shall be
valid for a period of five (5) years from the date of issue, subject to the conditions of review.
6. Renewal.
- The Establishment shall apply for renewal in Form VI, annexed to these rules, along with payment
of the fees prescribed in the Rule 15(a), three (3) months before expiry of the registration period of
five (5) years. The Renewal shall be granted by the Registering Authority within 3 months from the
date of receipt of the application failing which it will be deemed to have been renewed. The renewal
of the registration of certificate shall be granted in Form VII annexed to these rules
7. Suspension or Cancellation of Registration.
(a)The Registering Authority on receipt of reliable information that the applicant for registration
has been convicted or has been censured by any judicial or competent authority in relation to
his/her professional character or has been guilty or any misconduct or on a written complaint that a
Private medical care establishment has violated any of the terms and conditions of the registration
or any of the given directions it was given or has contravened any of the provisions of the Act or
these Rules, the Registration Authority after making enquiries there to and after written explanation
is called for from Establishment on the allegations levelled against Establishment may order
suspension of the certificate of registration for such a period as it may think fit, if the Registering
Authority is satisfied that a prima facie case has been made out.(b)The Registering Authority,
immediately after suspending the Certificate of Registration shall send a registered notice to
Establishment in writing in Form VIII informing the time, date and place at which the case will be
heard by the Registering Authority. The registered notice shall be sent to the Establishment at least
by giving 15 days time for hearing. The Registering Authority shall also direct the establishment to
surrender their Certificate of Registration on or before date of hearing.(c)The establishment shall be
entitled to be represented either an authorized person or a legal practitioner.(d)If the establishment
dies not represent either by authorized person or a legal practitioner, the Registering Authority may
proceed with the documentary evidence available with it and determine the case and order
cancellation of Certificate of Registration or revoke the suspension of the Certificate of Registration
by recording the reasons. The said order has to be communicated to the Establishment within three
days from the date of such order in the prescribed Form IX annexed to these rules.Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

8. Appeal.
(a)The Appellate Board constituted by the Government with the following Members shall receive
and adjudicate the appeals preferred against the decision of the Registering Authority:
(i) PrincipalSecretary, to Government HM and FW Department -Chairman
(ii) Director of Medical Education, A.P., Hyderabad -Member-Convener
(iii) Director of Health, A.P., Hyderabad -Member.
(iv) Commissioner, APWP, Hyderabad -Member,
(v) One member from IMA nominated by the Governmentafter duly
consulting IMA-Member,
(vi) One member from APNA nominated by Governmentafter duly consulting
the APNA-Member.
(b)Any Establishment, if aggrieved by the order of the Registering Authority, may prefer an appeal
in the prescribed form (Form X) annexed to these rules, to the Appellate Board within thirty (30)
days from the date of receipt of such order.(c)After receipt of the appeal, the Appellate Board shall
fix the time and date for hearing and inform the same to the appellant and others concerned by a
registered letter giving at least 15 days time for hearing of the case.(d)The appellant may represent
by himself or authorized person or a Legal practitioner and submit the relevant documentary
material if any in support of the appeal(e)The Appellate Board, shall hear all the concerned, receive
the relevant oral/ documentary evidence submitted by them, consider the appeal and communicate
its decision preferably within 90 days from the date of filing the Appeal in the prescribed
Form-XI(f)If the Appellate Board considers that an interim order is necessary in the matter, it may
pass such order, pending final disposal of the appeal.(g)The decision of Appellate Board shall be
final and binding.(h)If no appeal is filed against the decision of the Registering Authority in the
prescribed period (i.e) within 30 days from the date of receipt of the order, the orders of the
Registering Authority stands final.
9. Display of rates.
(a)The Establishment shall display the rates charged for each type of service provided by them, for
the benefit of the patients at the reception counter in both the local and English language. The list of
minimum services for which rates are to be displayed are given in Appendix - III.(b)A copy of such
list shall be sent to the Registering Authority by 1st of June every year for record.(c)The details of
services and rates shall be explained to the patients or their attendants at the time of admission
without any ambiguity.
10. Display of Registration number etc.
(a)The establishment shall display the names of the doctors at the reception counter working or
associated with it.(b)The establishment shall indicate the name and registration number allotted to
Doctors by the State Medical Council/Medical Council of India in all the Prescriptions, CertificatesAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

given to the patients.(c)Every Doctor shall display the registration number allotted to by the State
Medical Council/Medical Council of India in clinic and in all prescriptions, certificates, money
receipts etc. given to patients.
11. Fund of Registering Authority.
(a)The fees payable to Registering Authority/State Appellate Board shall constitute the fund of the
Registering Authority.(b)The Chairman of the District Registering Authority i.e. DM and HO shall
receive the moneys/fees through Demand Draft. Only. He shall open an account in a nationalized
bank in the name of the Registering Authority and remit the same into the account.(c)The amount
so collected shall be utilised by the Authority for the activities connected with the implementation of
the provisions of the Act and these rules, viz, payments to professionals, legal counsels, honorarium
to the Members of the Committees who attend meeting. Members of Inspection Teams etc.(d)The
Chairman of the District Registering Authority is the custodian of the fund and he shall operate the
fund.(e)The cheques of the Authority shall be signed by the Chairman and another authorized
member of Registering Authority.(f)The Chairman shall maintain general cash book and enter
therein all the amounts received and spent immediately.(g)The Chairman of the Registering
Authority shall keep a sum of Rs. 2000/- (Rupees two thousand only) as office imp rest for the
maintenance of day to day expenditure.(h)All the fees shall be paid by a Demand. Draft drawn on a
nationalised bank at headquarters of the District concerned in favour of "DRA and DM and
HO"(i)The Accounts shall be maintained properly, audited by engaging an approved Chartered
Accountant for every financial year.s
12. Annual Accounts.
- The annual accounts of the authority shall be audited, and certified by the Approved Chartered
Accountants appointed by the Registering Authority and forwarded to the Government along with
the annual report, for placing it before the Legislature
13. Fees payable to the Authority.
(a)Fees for Registration or Renewal:
SI.No. Description of Establishment Annual Fee (Rs.)
1. Clinics/consultation rooms (Solo Practitioners) 250
2. Poly Clinics (Group Practitioners) 500
3. Hospitals/Nursing Homes less than 20 beds 750
4. Hospitals/Nursing Homes with 21 to 50 beds 1500
5. Hospitals/Nursing Homes with 51 to 100 beds 2000
6. Hospitals/Nursing Homes with 101 to 200 beds 3000
7. Hospitals/Nursing Homes with more than 200 beds 7500
8. Diagnostic Centers (Basic Lab facilities) 500Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

9. Diagnostic Centres with Hi-end equipment (CT etc.) 2000
10. Physiotherapy Units 750
(b)For filing an appeal before the State Appellate Board: Rs.500/- (Rupees Five hundred only)
14. Medical Records.
- The establishments shall maintain medical records of the patients treated by it and health
information in respect of national programmes and furnish to authorities as and when they are
required. The minimum medical records to be maintained by the Establishments are prescribed in
Appendix-IV, V and VI.
15. Medical Audit.
- All Establishments shall formulate' appropriate mechanism for constant review of hospital
procedures to assess the cause of death and to explore better preventive measures and effective
treatment.
16. Offences and Penalties.
- If the Registering Authority comes to a conclusion based on any enquiry report that any offence
against any of the provisions under Sections 11, 12, 13 and 15 of this Act or these Rules has been
committed by Establishment and there is over whelming evidence that the offence has been
committed with the consent or connivance of, or is attributable to any neglect on the part of any
Director, Manager, Doctor or any other Officer of the said Establishment, a case shall be filed either
by Registering Authority or by an Officer authorized by it before the First Class Judicial Magistrate
or a Metropolitan Magistrate, as the case may be, for trial.
17. Interpretation of the Rules.
- If there is any doubt or dispute regarding the application or the interpretation of the Rules, the
decision of the Government thereon shall be final.Appendix - I(See Rule 4 (h))Minimum Standards
For The Registration of Private Medical Care FacilitiesPart - I I. Background and Rationale of setting
minimum standards. - In terms of the provisions of the Andhra Pradesh Allopathic Private Medical
CareEstablishments (Registration and Regulation) Act 2002, and in order to have successful
Legislation, these minimum standards are prescribed for the different types of the Private Medical
Care Establishments for the effective implementation of the Act. These standards may be modified
by the State Authority from time to time and shall be maintained by the Private Medical Care
Establishments for getting the necessary registration of the facility as per the Act.These minimum
standards have been prepared with discussions held with various health care professionals and also
with the active involvement of the representatives of A.P. Private Hospitals and Nursing Homes
Association, Indian Medical Association, Indian Medical Council, and various Government
Functionaries etc. The minimum standards are set for different types of medical care establishments
and comprise of general requirements and specific requirements, and include physical standards ofAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

space requirements and hygiene, equipment requirements for delivering specific services, and the
man power requirements and their qualifications.These minimum standards explain about the
obligations of the Private Medical Care Establishment to wards the patient, society, and staff
engaged (See Part IV). The standards also specify the minimum list of services for which the medical
care establishments need to display the charges levied for the benefit of the patient information.
(See Part VIII).The minimum standards also specify the medical records and other records to be
maintained to be made available to the patients, records that need to be made available to the
inspection authorities, and filing of minimum data returns to the appropriate authorities e.g., data
on notifiable diseases, detailed births and death records, and patient and treatment data etc. (See
Part VIII).II. Classification of the Private Medial Care Establishments. - In the context of working
out the minimum standards, the private medical care establishments in the state of Andhra Pradesh,
the following classification is made depending up on the services offered by these facilities and also
on the physical infrastructure available with them.A. Classification Based on the Services offered by
the facilities. - (1) Establishments offering Medical and Surgical Treatment. Clinics and Consultation
rooms (Dispensaries)(i)Hospitals or Nursing Homes offering Basic Services and Family Medicine
(Primary)(ii)Hospitals or Nursing Homes Offering Basic Speciality Care Services
(Secondary)(iii)Hospitals offering Super Speciality Services (Tertiary)(iv)Physiotherapy
Centers(v)Dental ServicesThe services offered by these facilities are described in the following
paras:(i)Clinics and Consultation rooms (Dispensaries). - The Clinics and Consultation rooms are
facilities run by a Solo qualified allopathic doctor, either with M.B.B.S degree or with higher
professional qualifications. These facilities offer "out-patient" treatment and drug prescriptions
based on the investigation support sourced either from in-house labs or from out side lab facilities.
The range of treatment offered by these clinics depends upon the qualifications of the medical
practitioner. There are Poly Clinics which are operated by a group of two or more practitioners.
These two types of facilities refer cases requiring hospitalization and for any surgical interventions
to a hospital for further treatment. The poly clinics usually have attached medical laboratories
(Clinical laboratories and Radiological and Imaging facilities) to cater to the needs of the doctors
working in the clinics. The physical requirements of the Clinics are given in the Part II.(ii)Hospitals
offering Basic Services and Family Medicine (Primary care). - These facilities are basically manned
by one or more qualified medical practitioners (M.B.B.S doctors) and offer basic level services to the
patients irrespective of the bed strength, as described in the Part VI. These may also have an
attached medical laboratory to cater to the investigation support needed for the clinical
interventions. In addition to the wide range of out-patient services these hospital provide in-patient
facilities. The physical requirements including space, equipment and man power needed for these
facilities depending on the bed strength of the hospital are given in the Part II.(iii)Hospitals or
Nursing Homes Offering Basic Speciality Services (Secondary care). - These hospitals provide
specialist care needed for the treatment of health conditions through the concerned specialist
doctors with higher level qualifications in the following specializations, irrespective of the bed
strength:* General Medicine (Medical care)* General Surgery (Surgical Care)* Obstetrics and
Gynecology (Maternal Care)* Pediatrics (Child Care)* Orthopedics (Accidents and Trauma Care)*
ENT* Ophthalmology (Eye care)* Radio-diagnosis and Radiotherapy (Cancer Care)* Physiotherapy*
Dental Care ServicesThese hospitals to have functional areas such as Operation theaters, post
operative wards, Intensive care units, general wards, and also other treatment areas needed for
facilitating the surgical interventions of the concerned Speciality care. These may have attachedAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

medical laboratories including Clinical laboratories and Radiological and Imaging facilities to cater
to the investigation needs of the specialists working in these facilities or the services may be taken
from out side diagnostic centers. Some of the facilities may have multi-specialty care services. The
hospitals offering multi speciality treatment services should have the complete range of equipment
and facilities suitable to the area of specialization. The physical requirements including space,
equipment and man power needed for these facilities depending on the bed strength of the hospital
are given in the Part II.(iv)Hospital offering Super Speciality Services (Tertiary) - These hospitals
provide super specialist care needed for the treatment of health conditions through the concerned
super specialist doctors in the following specializations, and hospital may have different bed
strength based on the range of services offered:* Cardiology and Cardiothoracic Surgery* Neurology
and Neuro-surgery* Nephrology and Urology* Gastroenterology and Surgical Gastroenterology*
Surgical Oncology* Neonatology and Pediatric Surgery* Chest Diseases and Respiratory Medicine*
Plastic SurgeryTo facilitate the above services, the hospitals should have full set of functional areas
and special types of equipment suitable to the needs of the Super-speciality services offered through
the facility. The hospitals shall have Intensive care units, Ambulatory support, Blood Bank facilities,
Communication network etc. equipped to meet the demands of an emergency case. In addition the
hospitals need to engage well qualified staff with proper training to handle the specialist care
required for the patients admitted to. The physical requirements including space, equipment and
man power needed for these facilities depending on the bed strength of the hospital are given in the
Part II.(v)Physiotherapy Units. - The Physiotherapy units function as support units to the
Orthopedic Care Specialist centers or the facilities may function independently. These units need to
be managed by qualified physiotherapists and to be equipped with a whole range of physiotherapy
and rehabilitation equipment. The physical requirements including space, equipment and man
power needed for these facilities depending on the bed strength of the hospital are given in the Part
II.(vi)Dental Care Services. - The Dental Services are offered as outpatient services through Clinics
from basic dental services to multispecialty dental treatments. The minimum requirements
including space, equipment and man power needed for these facilities is given in the Part II.
2. Establishments offering Diagnostic Support. - The diagnostics services are
offered by various laboratories
(i)Clinical Biochemistry Labs and Pathology Labs(ii)Haemotology Labs(iii)Microbiology and
Serology Labs(iv)Histopathology Labs and Cyto-pathology Labs(v)Cytogenetics
Labs(vi)Immunology Labs(vii)Radio Immune Assays Labs(viii)Radiology and Imaging
Services(i)Clinical Laboratories. - The laboratories may be comprehensive, performing tests related
to several laboratory disciplines such as clinical biochemistry', clinical pathology, microbiology and
serology, histopathology (anatomical pathology hematology, cyto-pathology, cy to-genetics,
immunology, or may be limited its scope to a few disciplines.The type and extent of laboratory
facility to be available for a nursing home would depend on the functional programme of the nursing
home. But provisions shall be made for the following minimum procedures to be performed on site
or at a nearby facility: Blood counts, urinalysis, blood glucose, blood urea and nitrogen, coagulation
profile (bleeding time, clotting time, prothrombin time), Blood grouping, typing and cross matching,
serum electrolytes, serum amylaseThe physical requirements including space, equipment and man
power needed for these facilities depending on the bed strength of the hospital are given in the PartAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

II.(ii)Radiology and Imaging Centers. - The radiology and Imaging centers may be comprehensive,
performing tests related X-ray imaging, Ultrasound imaging, Computer Tomography, Magnetic
Resonance Imaging etc. or may be limited its scope to a few disciplines. Equipment and space for
these centers would have to be planned according to the equipment services planned. In the
minimum following X-rays should be possible: X-ray chest, abdomen, and pelvis in the basic X-ray
units. In Big centers attached to any hospital providing emergency surgical facilities, the X-ray
machine should be installed within the nursing home premises. In smaller facilities, it should be
possible to have access to such X-ray facilities within one hour. Portable ECG facilities should be
available in all nursing homes round the clock. The Ultra Sound Scanning facilities are also may be
comprehensive providing services in Colour Doppler Imaging, Basic Abdominal Scanning facilities,
and Obstetrics scanning facilities and in some centers may offer Ultrasound Guided Biopsy of the
tumors for Cytology testing.
Part II – General Requirements
Most of the private medical care establishments located in the state are general hospitals or nursing
homes, set up to deal with the full range of medical conditions most people require treatment for.
But there are other hospitals specialized in a particular disease or condition (Heart care, Cancer
care, Orthopedic care, ENT care, Ophthalmic care etc.) or in one type of patient (woman, children,
the elderly, etc.). The specialized hospitals provide latest specialized treatments for every disorder in
the concerned specialized area. The service mix of various hospitals is given at Part VI.(A)Functional
Program. - The Hospital and Nursing Home should have the following functional areas namely: Out
Patient Department with general waiting and reception areas, and clinics for each speciality care
services offered with required equipment and furniture, Wards for general inpatients and individual
rooms for the patients with necessary ancillaries, fully equipped Operation theatres for the type of
speciality service delivered, Central Sterilization and Supply Department, Blood Bank, Accident and
Emergency Department (Casualty), Pathology Department, Radiology Department, Laundry Unit,
Hospital Store, Medical Records Department, Work shop and engineering Services and Transport
Services, Mortuary and Community Services.As per the physical standards, certain basic facilities
need to be provided by thehospitals irrespective of the services being offered such as:(1)Emergency
First Aid. - Emergency first aid is care provided initially to stabilise a victim's condition and to
minimise potential for further injury during transport to an appropriate service. At minimum each
nursing home shall have provisions for emergency first aid treatment for staff as well as for persons
who may be unaware of or unable to immediately reach services in other facilities. This is not only
for minor incidents that may require minimal care but also for persons with severe injuries or in
grave condition who must receive immediate first aid and assistance for transport to other
facilities.Emergency first aid includes facilities for intubating, vene Part, thorough cleaning/
dressing of wounds, ligation's of bleeding vessels, insertion of inter-costal drainage tube, application
of Thomas Traction, starting of nasal 02, bladder catheterization, stomach wash, establishing an
intravenous line in case of patients in shock, controlling of convulsions, controlling of acute attacks
of breathlessness etc.(2)General Medical Care Services. - The medical care services do not require
any special infrastructural input. It is mainly a question of medical skill and hence medical patients
are normally admitted to hospitals or nursing homes, which provide care in other disciplines. All
hospitals or nursing homes providing medical facilities should be able to provide Clinical diagnosisAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

for infectious diseases, diabetes, hypertension, auto-immune disorders etc. Treatment and follow-up
care for a majority of these conditions would also be possible by a physician. Medical personnel
manning such a facility should be able to take a decision regarding cases which require higher
medical skills or which may eventually need transfer to a better equipped facility (intensive care,
surgical facility with ventilators, haemodialysis machine, cardiac monitors etc.) and accordingly
transfer such patients at the earliest.(3)General Surgery services - A general surgery care facility
should be able to provide elective general surgery services for benign anal conditions, inguinal
hernia, hydrocele, varicose veins, testicular tumours and abscesses, vasectomy and splenectomy.
Elective surgery for uncomplicated urolithiasis, gall bladder conditions and closed reduction of
fractures can be performed, if portable X-ray facility is available. The emergency care for cases of
acute abdomen, strangulated hernia, torsion testis, etc. can be provided, subject to condition that
the facility have X-ray facilities within the hospital and access to Blood Bank and Ultra-Sonography
facilities are available within half an hour.(4)Pathology. - There should be provisions in hospitals or
nearby location for minimum pathological tests to be performed on site or at a nearby
facility.(5)Power Supply. - For the running of a hospital the availability of power supply is of utmost
importance. Those with nonavailability of continuous power supply, a generator should be
available.(6)Water. - The hospitals should make arrangements for drinking water for regular usage
either from the municipal/ gram panchayat authority and should have storage facility either
underground or in an overhead tank.(7)Transportation and Communication facilities. -
Communication and transport facilities should be a prerequisite for the functioning of a hospital as
the time for providing any intervention is often critical. It should be the responsibility of the hospital
to provide proper transportation facilities to the patients especially when they are referred by the
hospitals. The hospitals should have the facility of a telephone in case of an emergency and to have a
communication between the doctor and the supportive services and with patients.(8)Fire fighting. -
Fire fighting equipment should be available as per the requirements of the building
spaces.(9)Facilities and Space. - A hospital should have certain basic facilities in terms of various
zones for the provision of treatment. These arc the waiting room, dispensary/pharmacy counter,
bathrooms, consulting room, dispensary/pharmacy counter, toilets, bathrooms, wards among
others. Those providing surgical services and maternity services should have a operation theatre,
labour room, sterilisation room, changing room etc.(10)Waiting Room. - The waiting and consultant
room are the first entry points of a patient visiting the hospital. Certain basic facilities need to be
provided for the comfort of a patient during his waiting. The environment of the waiting room
should be such that it is pleasing and not congested. Various types of information need to be
provided. The doctors qualification, registration in the council and schedule of fees should be
displayed in the waiting room prominently. There should be a proper system of entry to the doctors
chambers. Enough space should be provided for the patients and their relatives to sit in the waiting
room.(11)Consultancy Room. - Adequate with an examination table with mattress a revolving stool.
The privacy of the patient is of utmost importance, especially for women. There should be either a
screen with curtain or a separate room for examination of women patients. It is imperative that
there is a wash basin and sufficient water in the consulting room, as the doctors examine different
types of patients.(12)Wards. - The wards should be separate for male and female patients, infectious
and non-infectious diseases. There should be a floor.area of 50-90 Sq ft per bed, a minimum
distance of 2.2sq ft between centres of two beds, and the beds should be laid out in such a way as to
make the patient accessible for treatment from either side.(13)Operation Theatre (OT)/LabourAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Room. - Hospitals providing surgical services should have a facility of an operation theatre. The
hospitals providing Obstetrics and Gynaecology services exclusively and others in addition to
medical and surgical services, should have an OT and a labour room.(14)Equipment and
instruments. - The equipment and instruments standards are given in the Part VII in detail inclusive
of minor and major instruments and their number. The availability of equipment and instrument is
of vital concern. They should be available in sufficient numbers and be in a working condition. They
should be well maintained.B. Location and Design of the Buildings. - A medical care establishment
should be accessible to the patients and the environment and landscape should meet the minimum
standards of hygiene.The buildings should have standardised architectural design, Interiors and
exteriors are to be so designed to suit the purposes of providing quality medical care services.The
materials used for construction shall be of good quality, and in accordance with the available Indian
Standards.(a)All Private Medical Care Establishments shall maintain the basic and adequate
provisions for Toilets and Clean Drinking water as required for the patients, visitors and as well as
their own staff working in the establishment. Efforts shall be made for water conservation and rain
water harvesting methods in its premises. (Please see Part V)(b)All the rooms/ward should be
properly ventilated and have adequate Lighting facilities.(c)All rooms, wards, operation theaters,
labour room, special care areas, outpatient departments and diagnostic departments should be
easily approachable by a stretcher and a wheel chair.(d)It should ensure that the required privacy is
provided to the patient.(e)The duty staff room should be centrally located in the hospital and there
must be a provision for every patient in the hospital to seek the attention of the duty staff
immediately.(f)The special care areas of a hospital like the operation theaters, labour room,
postoperative wards and intensive care units should be located close to each other for functional and
administrative ease.(g)The outpatient and diagnostic services should be located away from the
inpatient services.(h)Facilities to isolate an infected case should be available.(i)A telephone is a must
for every hospital.C. Essential Equipment. - The list of equipment given below is the minimum
requirement for all the Private medical care establishments:(a)Cots-It is essential to have patient
cots with a hard base because it facilitates cardiopulmonary resuscitation when the need
arises.(b)Adequate linen-linen should be clean and changed at regular intervals.(c)Examination
Table(d)Emergency Light(e)Stethoscopes and B.P. apparatus(f)Ophthalmoscope(g)Knee
hammer(h)Measuring tape (i) Torch light(j)Weighing machine-adult and paediatric (k) I.V. stands
(1) Wheel chair (m) Oxygen cylinders (at least two) with flow meter and mask or nasal prongs (n)
Laryngoscope set and Endo-tracheal tubes (o) Suction apparatus (p) Resuscitation bag (Ambu
bag)(q)Steriliser(r)Drums to carry sterile dressing and instruments (s) Bed side toilet equipment
(urinals, bed pans, etc,)(t)Bed side screens (u) Thermometer (v) Tongue depressorsD. Essential
Drugs And Consumables. - The list of essential drugs that should be available at any point of
time.(a)Adrenaline(b)Atropine(c)Aminophyline(d)Cholorphenaramine(e)Hydrocortisone and
Dexamethasone(f)Furesemide(g)Soda bicorbonate(h)Dopamine(i)Mephentine(j)Calcium gluconate
(k) Pentazocine/pethidine or any other analgesics (1) Diazepam (m) Hemostyptics like ethamsylate,
styptochrome and botropase (n) I.V. Fluids-Dextrose 5%, 10%, 25%, Dextrose saline, Normal saline,
Electrolyte solution (Adult and Paediatric) and Plasma expanders (Hemaccel)(o)I.V. Sets and I.V.
Cannula - (Adult and Paediatric)(p)Scalp vein sets of different sizes (q) Syringes-2, 5, 10, 20cc,
disposable or sterilized (r) I.V. Mannitol 10%, 20%(s)Anti septic solutions - Dettol, savolon, spirit,
betadine etc.(t)Plaster and BandagesE. Operation Theatre. - Operation theatre is the nucleus of any
hospital and deserves special care and attention. There should be no compromise on the followingAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

aspects in a operation theatre:(a)A clean and spacious room (minimum of 120-200 sft) sealed off
from the surroundings(b)Complete Asepsis should be maintained(c)Adjustable theatre table for
different manipulations either Hydrualic or Manual(d)Over head theatre light or Mobile Shadowless
light(e)Electro Surgical Unit(f)Suction apparatus(g)Anaesthesia machine (no surgery including
under regional anaesthesia should be performed in the absence of an anaesthesia
machine)(h)Adequate supplies of gases specially oxygen(i)Ambu resuscitation bag(j)A high pressure
autoclave(k)Linen and instruments depending on the nature of surgery(l)Laryngoscope with adult
and paediatric blades(m)Paediatric anaesthesia circuit(n)Endo tracheal tubes of different
sizes(o)Spinal anaesthesia sets - it is advocated to use disposable spinal needles and syringes, as
they are reasonably cheap now and will go a long way in preventing some of the dreaded
complications such as infections.(p)Stretcher with trolley for shifting patients(q)I.V. Stand with I.V
administration facilities(r)In hospitals performing caesarean Parts, it is essential to have the
neonatal resusciatation kits as mentioned in the maternity services item.(s)Drugs - adrenaline,
neostigmine, aminophyline. pentathol sodium, succinlycholine, gallamine, pavulon, pentazocine,
diazepam, xylocard, xylocaine 5, 2, 1%, hydrocortisone, chlorphenaramine, dexamethasone,
dopamine, mcphentine, frusemide, mannitol, ether, halothane, soda bicarbonate, deriphyllin,
metoclopromide, promethazine, I.V. Cannula, I.V. Sets, scalp vein tubes, Xylocaine zelly, antiseptic
solutions, I.V. Fluids, hemaccel and airways.(t)Proper facilities should be available for
scrubbing.(u)Air conditionedF. Labour Room. - This is one of the most vital areas in a hospital
providing maternity services and there should be no compromise on the following aspects of the
labour room:(a)A floor area of a minimum of 120 sq. ft(b)All precautions for asepsis must be
taken(c)Good illumination with overhead O.T light(d)Electrical Cautry and Suction
apparatus(e)Stethoscope, B.P Apparatus and Weighing machines-Adult and
Paediatric(f)Resuscitation equipment and Paediatric resuscitation equipment (Paediatric
resuscitation bag, endo tracheal tune (2 No.) Laryngoscope with neonatal blade, stomach tube
(infant feeding tube etc.(g)Oxygen cylinders with connections and masks(h)Delivery table with basic
manipulations(i)Autoclave(j)All emergency drugs (as in para D above)(k)IV stand and intravenous
fluid administration facilities(l)Stretcher with trolley for shifting patients.(m)Forceps for deliveryG.
Important Zoning requirements of the Different Functional Areas. - (i) Ambulatory ZoneThe
ambulatory zone will have the following functional areas:
1. Medical clinic (consultation and examination room) with waiting area
2. Surgical Clinic (consultation and examination room) with waiting area
3. Casualty and emergency care (optional)
4. Treatment and dressing and 5. Injection room
Obstetric and Gynaecological Clinic. - In case of maternity home providing obstetrics and
gynaecological services to have the clinic as described below:The clinic should include a separate
registration, consulting - cum - examination room and toilet in order to ensure privacy. The clinic
should be planned close to inpatients ward units to enable them to make use of the clinics at timesAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

for ante and post natal care. The clinic should also be at a convenient distance from other clinics in
the Outpatient Patient Department.(ii)Critical Zone. - This zone is required in surgical and
maternity homes. This zone consists of the Operation Theater and Delivery Suite.This is technically
a therapeutic aid in which a team of surgeons, anaesthetists, nurses, gynaecologists and sometimes
pathologist/s and radiologist/s operate upon or care for the patient. The critical zone shall be
located and arranged to prevent non-related traffic through the suites. When delivery and operating
rooms in the same suite, access and service arrangements should be such that neither staff nor
patients need to travel through one area to reach the other.(iii)Operation Theatre.Protective Zone. -
Consisting of Nursing station with storage facility, changing rooms, staff arrive through this Zone
and proceed via changing areas dressed for their task.Clean Zone. - This includes the recovery room.
It is principally the corridor linking the transfer bay to the theatre suite. Patients are brought from
the ward and should not cross this zone in their ward - clothing which is a great source of infection.
Changeover of trolley should be affected just before the clean zone.Aseptic or sterile zone. - It
consists of operation theatres, sterilisation; theatre pack preparation and sterile storage, scrub up
and gowning rooms.Disposal zone. - Also erroneously called the dirty zone. Soiled instruments and
dressings are transacted through this area for washing and sterilisation or disposal.(iv)Delivery
suite. - (Required for nursing homes providing maternity facilities)All maternity homes and all
nursing homes offering maternity services shall make provisions for a delivery suite over and above
the aforementioned facilities necessary for an operating suite. In maternity homes an arrangement
must be possible to isolate a patient of eclampsia. Two labour rooms should be provided for every 10
maternity beds or part thereof. These rooms may be constructed preferably in the form of cubicles.
They should be close by to the delivery room. In case combined with the "Examination and
Preparation room," the area standards should be maintained. This room should ideally be suited
close to the operation theatre(v)Nursery for New Born. - All nursing homes providing maternity
facilities must also provide for a nursery for normal babies.H. Other Facilities. - There are three very
important facilities that the patient requires. They are; Pharmacy, laboratory, X-Ray and E.C.G.
These are a must for every hospital it would be ideal to have them within the premises of the
hospital or in close proximity. Other facilities such as ambulance services, Hitech diagnostic and
monitoring facilities are to be considered as optional under the existing condition in our country.I.
Special Care Units. - The special care units dealt with are: -* Post-operative wards* Intensive care
units* Intensive Care Unit providing speciality care.(1)Post - Operative Wards. - The immediate
post-operative period is as the intra-operative period in determining the final outcome of any
operative procedure. A number of studies have clearly indicated that this is one of the factors
contributing to post-operative morbidity and mortality. The essential requirements are:(a)All
facilities and drugs mentioned earlier under General requirements.(b)Monitors. - Monitoring is the
basic purpose of post-operative wards. The basic parameters like - pulse rate, blood pressures,
respiratory rate and urine output should be monitored and this dies not require any additional
equipment. However, it is essential for every post-operative ward to have a pulse taximeter and an
ECO monitor with a defibrillator. The big centers in addition may have capnography, ventilators,
infusion pumps, NABP, temperature monitoring devices and arterial blood pressure monitoring.
Oxygen delivery systems. There should be always be a crash cart available with emergency drugs and
equipment as described in the Part 3 of General conditions.(c)Staff. - The most vital necessity of a
post-operative ward is the presence of specially trained staff. The staff should have adequate
knowledge of the possible post-operative complications and should be able to recognize them earlyAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

and call for the concerned doctor.(2)Intensive Care Units.(a)Design Considerations. - he beds in an
ICU should be laid out in such a way as to permit observation of every patient from the nursing
station. The beds should have a firm base to permit cardio-pulmonary resuscitation and should be
movable easily. Provision must be there to alter height of the head and foot ends of the patient and
the plank at the head end must be detachable to facilitate endo-tracheal intubation when required.
There should be adequate moving and working space around the beds. These units should be
declared as restricted areas and attenders should be kept away. Adequate attention should be paid
towards asepsis.(b)Staff. - A minimum of one Trained/ qualified nursing staff for 5 beds round the
clock and a Duty doctor should be available round the clock. The staff nurses posted shall be well
versed with the different equipment operation and should be trained to handle critical situations. An
anaesthetist by virtue of his training in emergency care and being the best to maintain two vital body
functions (Circulation and respiration) is the choice to manage the Intensive Care Units with the
help and guidance from the concerned consultants.(c)Materials and Supplies. - All the necessary
emergency drugs as detailed in Part-I: General requirements should be made available. In addition
to the essential equipment, the additional equipment required are: a Pulse Oximeter, ventilator,
infusion pumps, ophthalmoscopes, glucometer and the resuscitation equipment viz i. Laryngoscope,
ii. Endo-tracheal tubes of different sizes and connectors, iii. Oxygen cylinders, masks and
connections, iv. Ambu bag etc. Preferably a Generator should be installed, as an alternate power
supply requirement. Round the clock laboratory support in necessary.(3)Speciality Specific
Intensive Care Units. - Intensive care units dealing with a single speciality (neuro-care units,
coronary care units, respiratory care units and trauma care units) are the best way to provide the
Intensive care services. The basic requirements are the same as general intensive care unit and each
speciality care units need to have additional facilities specific to the speciality such as temporary
pacing, critical Equipment such as Cardiac monitors and defibrillators for ICCUs, Incubators and
warmers for NICUs.J. Hospital Staff. - A hospital or a nursing home is just as good and safe as its
staff is. It is desirable that every staff member should be adequately qualified and possess a
qualification certificate from a recognized teaching institute. However, it is vital that every staff
member is adequately trained and works under the correct supervision of a doctor.(1)The staff of a
hospital or a nursing home may be classified in the following categories:* Specialists or Consultants*
Duty Medical Officers* Nursing Staff* Helpers* Administrative staff* Maintenance staff* Other
staff(i)Specialists or Consultants. - Consultants are specialists in different fields of medicine who
provide expert medical care are services to the patients in a hospital. The number and type of
consultants required by a hospital depends on the nature of services provided by each individual
institution.(a)Physician. - M.D. degree from a university or equivalent from a local recognised body
OR diploma from Diplomate of National Board or equivalent from a local recognised
body.(b)Surgeon. - M.S. degree from a university OR Diploma from Diplomate of National Board or
equivalent from a local recognized body.(c)Obstetrician and Gynaecologist. - M.D. degree from a
university or equivalent from a local recognized body OR diploma from Diplomate of National
Board or local recognised bodies (like C.P.S) or university or equivalent from a local recognised
body.(d)Anaesthetist. - M.D. degree from a university or equivalent from a local recognised body OR
diploma from Diplomate of National Board or local recognised bodies (like C.P.S) or university or
equivalent from a local recognized body.(e)Paediatrician. - M.D. degree in Pediatrics from university
or equivalent from a local recognised body OR diploma from Diplomate of National Board or local
recognised bodies or university or equivalent from a local recognised body.Details of otherAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

specialists or consultants are given in Part III.(ii)Duty medical Officers. - It is a must for every
hospital to have a doctor within the premises of the hospital round the clock. These doctors should
be well oriented to the working of the hospital and should posses adequate skill to handle the
emergencies, till the services of a consultant are available. There should be one duty medical officer
available for every 20 inpatient beds or part thereof in every eight hour shift. A qualified doctor is a
must for proper care to be provided to the patient. The practise of doctors trained in other systems
of medicine providing care in Allopathy system of medicine is not permitted.(iii)Nursing Staff. -
There should be one trained/qualified nurse on duty round the clock for every 10 beds in the regular
wards and for every 3 beds in a special care areas need additional training and care should be taken
not to post untrained staff into these critical areas.(iv)Helpers. - The ratio of this category of staff to
the number of beds remains the same as for the nursing staff and it is once again emphasised that
only specially trained staff should be posted in labour rooms, operation theatres and intensive care
areas.(v)Administrative Staff. -This category of staff includes - Managers, receptionists, accountants,
supervisors, security personnel etc. The requirement of this category of staff depends solely on the
type of a hospital and its size. As the size of a hospital increases the need for this category of staff
also increase proportionately.(vi)Maintenance Staff. - The secret behind any successful organization
is a foolproof maintenance mechanism, and today the emphasis is on preventive maintenance the
maintenance staff include an electrician a plumber and a carpenter, and for the maintenance of
medical equipment a smaller hospital could enter in to yearly service contract and a bigger hospital
may find it more convenient to have a full fledged bio-medical engineering department in addition
to AMC (annual maintenance contract).(vii)Other Staff. - As the size of a hospital increases so do the
facilities at the hospital and the requirement of other grades of Staff for example : a pharmacist is
required when there is a pharmacy, a laboratory technician is required when there is a pathological
laboratory and an X-ray technician is required for each X-ray plant.(2)Availability of Personnel. - As
soon as a patient arrives at a nursing home, (in emergencies) he or she should immediately be seen
by a Duty Medical Officer. A consultant should see the patient within half an hour.A nursing home
providing Medical facilities should have a physician available on call round the clock.A nursing
home providing Surgical facilities should have a surgeon and anaesthetist available on call. In case
Emergency Surgical Facilities are also provided then a surgeon and anaesthetist should be available
on call round the clock.A nursing home providing Maternity facilities should have an Obstetrician
and Gynaecologist, and anaesthetist, a surgeon and a neonatologist available on call round the
clock(3)Minimum requirement of personnel.(a)Duty Medical Officer. - * One duty medical officer
for every 20 inpatient beds or part thereof in every eight hour shift.* Two duty medical officers to
function as O.T. assistants during routine O.T. hours (8 hours) and one each for the next two shifts
in those facilities providing emergency surgical care and obstetrics care (nurses could be trained to
perform this function).* One duty medical officer for the labour ward in every eight hour shift
(Optional). This function may be performed by the O.T. assistant or a trained nurse.(b)Nursing staff.
- * One nurse for every 10 beds if on same floor on every eight hour shift and if on different floors
then in same proportion on different floors. Here one nurse undergoing training may be posted
along with a qualified nurse.* Two qualified operation theatre nurses for routine surgery. For
nursing homes offering maternity facilities and emergency surgical facilities two more operation
theatre nurses will be required on shifts. (In practise the number of Nurses posted specifically for
this area would depend on the patient load there.)* Four qualified nurses for labour room. One in
each eight hour shift. They may also function as O.T nurses when required.* One nurse should beAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

kept available for emergency patients on every eight hour shift.* During regular OPD hours one
more nurse should be kept available for OPD block.(c)Nursing Orderly. - * One Female Nursing
Orderly or one Male Nursing Orderly for every 8 beds for every eight hour shift.* One Female
Nursing Orderly for Obstetrics and Gynaecology OPD.* One Male Nursing Orderly for Surgical and
Medical OPD* One Female Nursing Orderly for Labour room* One Female or Male Nursing Orderly
for Operation Theater* One sweeper per eight beds for wards in ever 8 hour shift* One sweeper for
Operation theatre and Labour room.Check List of Appendix - IObstetrics And Gynaecology:
Standard Services Recommended For Each Level
SI.No. Condition/Procedure Basic Level Services Specialist Care ServicesSuper
Speciality
Services
1 Deliveries Normal DeliveriesAll deliveries including
complicated deliveries 
2Threatened of incomplete
abortionConservative
management D and
CTreatment  
3 Family Planning Tubectomy IUDBasic Level services +
Laproscopic tubectomy 
4Lower abdominal pain and
ectopic pregnancyStabilise and Refer Exploratory tubectomy  
5 Vaginal diseaseDiagnosis and
ManagementExam under anaesthesia  
6 High risk pregnancyEarly diagnosis and
timely referralInvestigate initiate
management 
7 PIDDiagnosis and
TherapyDiagnosis and Therapy  
8 Menstrual irregularities ReferDiagnosis and
Management 
9 Infertility ReferDiagnosis and
Management 
10 Cervical erosion Refer PAP Smear and Bio spy Cader Surgery
11 Malignancies Refer DiagnosisSurgery
radiotherapy
Inspection Report (Under Rule 4(h))Performa of Inspection Report for Granting Licence to Private
Medical Care Establishments under the Act
Name and Address of the Medical Care Establishment (MCE)  
Name and Address of the Company/Director  
Location of the MCE  
(Urban/Municipal/Rural/Tribal)  
Is the MCE attached to any Medical College/Research Institution  Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Name of Medical Director/Superintendent  
Is the accommodation owned by the Company? Or is it on lease? Ifit is on lease what
is the period and conditions of lease(Evidence to be enclosed) 
State whether the above said accommodation suitable for runningMedical Care
establishment 
One set of Photographs of the MCE with its functional facilities  
The names of the Specialists/Consultants working in the MCE  
The Equipment and Furniture available in the MCE (List to beenclosed)  
Passport size photos of Director/Medical Superintendent to beattached  
Application No.:Application
date
Application Fee Particulars  
Date of Inspection (Enclosed Inspection format to be filled)  
Inspection done by  
Details of the major specialities offered in the Medical care Establishment with beds allotted
General Emergency Speciality-wise beds, pl. specify Total
    
ActivityDate of Previous
Years
Total Out Patients (Old + New)   
Total Inpatients   
Total No. of Major operations   
Total No. of Deaths   
Deaths after 48 hours of admission   
Bed Occupancy rate   
Financial Accounts   
Total Hospital Fee Collection. (Audited   
Financial Statements to be enclosed)   
Total reimbursements claimed from   
Government towards the treatment of referred patients, if any   
Flow of funds towards their Activities (External Aids/ Public/Private
contributions, pl. specify)  
Inspection Proforma to be filled by the Inspection Team(Relevant to the Inspection of 100 beds and
more Hospitals)Index
No Item Page No
(1) Out Patient Department Services 1
(2) Emergency Services Department 2
(3) Intensive Care Unit 3Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(4) Clinical Laboratory 4
(5) Blood Bank 5
(6) Radiology Department 5
(7) Operation Theatre 7
(8) Central Sterile Supply Department 8
(9) Labour Room 9
(10) Wards 10
(11) Diet and Kitchen Facility 11
(12) Linen and Laundry Services 11
(13) Medical and Non Medical Stores 12
(14) Medical Records 12
(15) Training, C M E and I E C Activities 12
(16) Ambulatory Services and Telecommunications 12
(17) Commitments to National Health Programmes 12
(18) Environment Sanitation and Water Supply 13
(19) Patient Attendant facilities 13
(20) Research activities 13
(21) Administrative Department 14
(22) Mortuary 14
(23) Important hints for computing Hospital Performance 14
Important Hints For
Computing Various
HospitalActivity
Indicators
1 Bed Occupancy Rate:  Total In Patientbed-days-----------------------X 100 = ----- BedCapacity
2 Average Length of Stay
= Total In Patientbed-days during 12 months-----------------------=
--------------------Discharge + Deaths during 12 months
3 Turnover rate (interval)
= (Annual Bed Capacity- IP Bed –
days)----------------------------------------------(Discharge + Deaths
during 12 months)
4 Case Flow Rate =  Total Discharges +Deaths during 12
months----------------------------------------------Total Beds existing in
the Hospital.
5 Gross Death Rate :  Ratio of total deaths to total discharges. InGeneral Hospitals it should
be about 3-5 per cent.
6 Net Death Rate
(Institutional Deaths): No. of deathsoccurring 48 hours or more after admission, should not
usually2.5 percentNo. of deaths due
toanaesthesia---------------------------------------X 100
7 Anaesthetic Death Rate:  No. of patients anaesthetized during the periodAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

8 Post Operative Death
rate Post operative deaths---------------------------------------XI00Total
operations during a given period
9 Maternal Death Rate:  Total deaths of obstetric clients----------------------------------------XI00
  Total dischargesincluding deaths of Obst....Ward
No. FacilitiesAvailability
(Yes/No)Remarks,
if not
satisfied
(1) Out Patient Department (OPD)   
(b) Reception Counter:   
(i)Posting of knowledgeable staff as a Receptionistwith a board"May i
help You?"  
(ii)All sections of the OPD numbered and depicted onflow chart near
reception counter.  
(iii)Boards indicting days of Special Services andHospital timings near
reception counter  
(b) Registration:   
(i)Separate registration windows with railingarrangements for
Male/Female, Old/New, Freedom Fighters andGovernment
Servants:  
(ii)Board indicating hospital fees for variousservices provided for OPD,
IPD and Surgical Procedures  
(c) OPD Sections:   
(i)Every OPD section should have : separateregister for diagnosis,
Complete examination tray with BPApparatus, torch and hammer,
x-ray view box, examination tablewith foot steps, writing table, stool
for patients wash basin,adequate sitting arrangement for waiting
OPD patients,appropriate Health Education material displayed.  
(ii) in addition to above.   
 Medical OPD:   
 CNS examination tray, tuning fork, ECG Machine,   
 Surgical OPD:   
 PR examination tray with proctoscope and gloves,Kidney trays,
Tongue depresser  
 Gynaec. OPD:   
 PS and Pv examination Tray, iUD tray, Kidneytray, Weighing
machine, pap smear tray, exam table with lithotomyfacility, table
lamp.  
 Pediatric OPD:   
 Paed. Weighing machine, Measure tape, Height andWeight Scale.   
 Opthalmic OPD:   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

 Near and Distant vision charts, Refraction setOpthalmoscope, Dark
room facilities for Retinoscopy.  
 Ear, Nose and Throat OPD:   
 Head light mirror, indirect laryngoscopes,tounge depresser, Nasal
and ear speculum, electric steriliser,tuning fork, audiometry,
diagnostic ENT set, audiometry, waxsyringe etc.,  
 Dental OPD:Dental unit, Dental motor,Dental x-ray, Continuos
water supply, denture preparation(prosthesis), Bio-safety measures
adopted etc.  
 Orthopedic OPD:Emanination table, footsteps, x-ray view box,
patella hammer etc.  
(d) Dressing Room.   
(i) Separate dressing rooms for male and femalepatients.   
(ii) Autoclaved/Disposable material used.   
(iii) Dressing table, sink for hand washing available.   
(iv)Dresser wears Plastic apron, Face mask, glovesetc. while doing
dressing.  
(v)Antiseptic lotions and dressing materials andfoot operated dustbins
or adequately available  
(e) injection room   
(i) Separate rooms for male and female available.   
(ii) Staff nurse is trained in management ofinjection reactions   
(iii)Updated emergency drug tray and Availability ofOxygen Cylinder
with accessories, Suction Machine (Electric andfoot operated), Cot
and mattresses with arrangements for head lowposition, venesection
tray, chart of management of Anaphylacticreaction, Availability of
Wash basin, Bio-safety measuresadopted, inventory maintained.  
(iv)Sufficient No. of Disposable/Sterile syringesand needles depending
upon OPD load.  
(f) Pharmacy   
(i)Availability of male and female windowsseparately with railing
arrangements  
(ii) Daily accounting of drugs kept? (Any proof ofchecking of inventory)   
(iii) Surprise check by inspector for actualdispensing against prescription   
(iv) Drugs are dispensed in paper packets   
(v) Morbidity statistics kept up to date (verify therecord)   
(g) Physiotherapy   
(i)Availability of short wave diathermy, infraredfacilities etc. for
Myalagia  
(ii) Availability of Lumbar/Cervical traction forSpondylitis.   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(iii) Shoulder mobilization wheels, walking barsavailable   
(iv) Wax bath and Muscle stimulator available   
(h) Minor Operation Theatre and Plaster Room   
(i)Availability of Anaesthetic apparatus,shadowless lamp, operation
table suction apparatus (electric andfoot operated), fumigation
apparatus,  
(ii) Availability for wash basin, cap, mask, gown,sleepers, etc.   
(iii)Availability of autoclaved/sterile linenmaterial, dressing drums,
minor surgery instruments, life savingdrugs and anaesthetic agents
etc.  
(iv)Availability of plaster room, plaster materialand plaster cutting saw
etc.,  
(v) i) Maintenance of records and registers ofminor OT etc.,   
(i) Safe Drinking Water Facilities:   
(i) Water coolers available with adequate number oftaps for OPD   
(ii)Water samples are tested for potability. verifythe register and
actions taken on unsatisfactory reports.  
(j) Sanitary Unit   
(i)Separate will-maintained arrangements of toiletfor male and female
patients and their attendants  
(ii) Separate toilets and wash basins for staffmembers?   
(k) vehicle parking   
(i) Separate stand for staff/public vehicles   
(l) R.M.O. Office   
(i) Availability of telephone for RMO and public   
(ii) Film show arrangements made for OPD patients,verify the register.   
(iii)Suggestion book in OPD. Action taken, if any,for valid suggestions
made.  
(iv)Availability of RMO during entire OPD period andmusters of
interns, class iii and para medicals are available inRMO's chamber  
(v)Availability of wheel chairs and stretchers forshifting Pts. From OPD
to Ward.  
(m)verifications of adequacy of treatment(Minimum 5 case
sheets/prescription notes should be checked)  
(i) Clinical notes, Diagnosis, investigations andLegible hand writing   
(ii) Proper prescription of drugs with dose schedule   
(iii) views of the patients regarding treatment andtheir satisfaction   
(2) Emergency Service Department (Casualty)   
(i) Separate Medical Officer (CMO) available roundthe clock   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(ii) Continuous availability of D.M.O (indoor M 0)during night hours.   
(iii) Board displaying doctors on call, Specialist andother staff on duty   
(iv) Glow sign board indicating 'Emergency ServicesDepartment'   
(v)Casualty Department annexed with Emergency wardwith adequate
number of beds and attached toilets facilities.  
(vi)Ward well equipped with Fowler's bed, OxygenCylinder With
Accessories, Suction apparatus electric - footoperated, Emergency
tray with essential drugs with Catheter tray,Rules' tubes/stomach
tube, flatus tube, venesection tray,tracheotomy set, L P tray,
Suturing tray, Ambu bag, Laryngoscope,Tourniquet, Splints -
Thomus splint, Bowler's splint, Crammerwire splints Emergency
light/ Generator, BP Apparatus, Torch,Thermometer, weighing
machine, hammer, Refrigerator, stationaryand forms  
(vii) Trained staff posted in Emergency department   
(viii)Boards displayed regarding management of Snakebite, Common
poisoning, Anaphylactic reaction, Cardio respiratoryarrest etc.  
(ix) Availability of ARV services 24 hours. Boarddisplayed accordingly.   
(x)Knowledge of M Os in classification of dog bitewounds and their
management, training in giving ARV.  
(xi) Proper documentation of treatment card andrecords/registers.   
(xii) Uninterrupted Stock of ARv. Check the stockbook.   
(xiii)Medico legal register in prescribed formateither central or
individual. 1  
(xiv)Call book is in prescribed format and calls areattended promptly.
verify  
(xv)Availability of Disaster Management Plan anddisaster drill
conducted regularly. (verify the record and stock)  
(xvi)Retiring room for MO with attached toiletlockers, Cooler, fan, and
drinking water arrangements.  
(xvii)Night super nurse on duty should be available inemergency ward
after night rounds.  
(xviii)Treatment room cum minor operation theatre withall necessary
instruments, equipment, trolleys, tables and trays.  
(xix)Availability of separate telephone for CasualtyDepartment as well as
for public  
(xx) Store room with sufficient stock of essentialand life saving drugs   
(xxi)Availability of sufficient number of wheelchairs and stretcher
trolleys.  
(xxii) Availability of transport facilities (Ambulance)round the clock.   
(3) intensive Cardiac Care Unit   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(i)Existence of i C U with AC, bedside monitor,central monitors,
defibrillators, ventilators, fowlers beds etc.and round the clock
availability of qualified and trained staff.  
(ii) Equipment in working condition and history bookmaintained   
(iii) Space availability, cleanliness, generatorfacilities etc.   
(iv) Adequate No. of trained Medical Officer andNursing Staff.   
(v) Record keeping of patients treated so far.   
(vi) Availability of central oxygen, suction machineand life saving drugs.   
(4) Clinical Laboratories   
(i)Qualified Pathologist available, if not effortsmade for getting the
post filled in or suitable alternativearrangements made.  
(ii)Examination of special tests like Widal, serumbilirubin, LFT, VDRL,
BS for M.P., stool examinations, semenanalysis, electrolyte study,
blood gas analysis, kidney functiontests, CSF examination etc  
(iii)Accuracy or reports, monthly abstract drawn andverified by
Pathologist.  
(iv) Availability of round the clock laboratoryservices   
(v) Use of aprons by laboratory technicians   
(vi) Availability of sufficient wash basins, sinksfor staining   
(vii) Proper dispose off of the soiled containersafter decontamination.   
(viii) Use of only autoclaves syringes andneedles/Disposable needles.   
(ix) Appropriate tests carried out as per indication.   
(x) Observance of bio safety measures   
(xi)Regular availability of staining material andtheir inventory
maintenance.  
(5) Blood Bank   
(i) Availability of infrastructure as per GOilicensing norms   
(ii) Round the clock availability of trained staffand services   
(iii) Checking of cross matching   
(iv) Proper maintenance of cold room andrefrigerators   
(v)Australia antigen vDRL, Malaria parasite and H iv tests are carried
out on every blood bottle of donor. verifythe record  
(vi) incidence of deaths due to non-availability ofblood any time in a year   
(vii) issue of donor cards, certificate ofappreciation (verify the records)   
(viii) Proper documentation and examination of donors   
(ix)Exhibition of posters and health educationmaterials in the blood
bank  
(x) Availability of adequate quantity of Sera andAnti sera reagents   
(xi) Adequate stock of blood bags and transfusionsets   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(xii) Renewal of blood bank License as per GOi Rulesand Records   
(xiii)Disposal of Hiv positive blood bags andBio-safety measures
undertaken  
(xiv)Transfusion of feed back, and record maintenanceof untoward
incidences  
(xv)Maintenance of inventory of various sera,reagent and consumables.
verify.  
(6) Radiology Department   
(i)Radiologist is available, if not efforts madefor getting the post filled
in or any suitable alternativearrangement made for day to day
supervision  
(ii) Status of x-Ray machine available.   
(iii)Availability of dark room safe light, filmdrying cabinet x-ray
illuminators etc.  
(iv)Used of dosimeter and are they regularly sent toBARC for checking
and steps taken on reports  
(v)Special investigations like ivP, barium swallowor barium studies,
Hystosalphingography etc.  
(vi)Availability of necessary contrast media forSpecial investigations
(verify)  
(vii) Round the clock x-ray services by making x-rayTechnicians available   
(viii)Availability of all life saving drugs, oxygencylinder, suction
apparatus etc. to tackle the Anaphylacticreactopm.  
(ix)Separate x-ray register for MLC and recording ofsignature of thumb
impressions along with identification marketc.  
(x)Accurate records, register and inventory,checked by Radiologist or
RMO  
(xi) x-ray films and hypo solutions are preserved/Disposed as per rules.   
(xli)Availability and use of protection devices likelead apron, lead gloves,
goggles, badges and doismeter etc. bythe staff working in Radiology
department.  
(xiii)x-ray diagnosis entered in the register andchecked/ reported by
Radiologist.  
(xiv) Availability of Sanitary block in x-raydepartment.   
(xv) Availability of dental x-ray facilities.   
(xvi)Availability of Ultra Sound Scan facility &trained
Radiologist/Gynaecologist posted.  
(xvii)Compliance to the provisions of PNDT Act., incase a US Scanner is
available. PL verify  
(7) Operation Theatre:   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(i) Availability of staff in O.T. as per norms.   
(ii)Concept of clean, neutral and sterile zonefollowed by providing
various self closing double doors or aircurtain etc.  
(iii)Dimensions of operation theatre are measured anddoes of potassium
permanganate (KMno 4) and formaldehydecalculated for doing
fumigation on fixed day or as and whenindicated. verify the record.  
(iv)Availability of separate OTs for septic andinfected cases and also
different specialities.  
(v)Swabs from OT are sent for culture and actiontaken on unfavourable
report. verify the documents.  
(vi) Preoperative waiting room with toilet facilitiesavailable.   
(vii)Availability of well equipped post operativeward (Recovery room)
with adequate No. of beds and resuscitationmeasures.  
(viii)Up to date maintenance of O.T. records like O.T.registers,
emergency OT, monthly abstract etc. Maintenance ofoperation
postponement register.  
(ix)Proper steps taken for disposal of OT waste asper Biomedical Waste
Management Rules (operated specimens etc.)  
(x) Emergency light or generator facilities providedto OT. (verify)   
(xi) OT staff nurses available round the clock   
(xii) Housekeeping and biosafety measures adopted inOT   
(xiii)Availability of Boyle's Apparatus, Hydraulic OTtable, Shadowless
lamp, Suction apparatus, Air Conditioner,Electric cautery,
Refrigerator, Electric sterilizers, Autoclaves  
(xvi)Availability of portable mobile x-ray machinesin OT along with dark
room.  
(xv) Check list attached to the patient posted foroperation   
(xvi) Arrangement of transport of patient from OT toward   
(xvii)Availability of separate changing room fordoctors, nurses with
attached toilet and locker facility andentrie staff use OT attire.  
(xviii) Availability of fire fighting equipments andknowledge to use them.   
(8) Central Sterile Supply Department   
(i) Availability of HP Horizontal Serilizers (H P HS)   
(ii)Trained OT Attendant under supervision of OTstaff nurse performs
the autoclaving (interrogate and confirmknowledge and procedure)  
(iii) A detail chart showing how to operate H P H Sdisplayed   
(iv)Wall clock made available for noting the timeduring autoclaving
process  
(v) All autoclave tape should be preserved andpasted on register date
wise which is to be signed by Staff Nurseand checked by Anaesthetist  Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(verify the register)
vi) Anaesthetist/Pathologist should be in charge ofC S S D   
vii)Knowledge of staff nurse for disinfection offibre optic scopes, rubber
catheter, linen, sharp instruments,etc.  
(9) Labour Room   
(i)Separate Labour Room with automatic double doorfor clean and
septic cases available.  
(ii)Minimum 2 labour tables in Clean labour roomwith plastic curtain
partition.  
(iii)Facilities available such as: Wall Clock, babyweighing machine,
facility for head low position, babyresuscitation kit, mucus aspirator,
suction apparatus (electricor foot operated) along with set of
catheter, oxygen cylinderwith accessories for baby and mother,
emergency light/generatorconnection, exhaust fan, coolers/fan,
episiotomy tray andvenesection tray, shadowless lamp, forceps low,
foetal monitor,vacuum extractor, B P apparatus, instrument
sterilizer, plasticaprons, sleepers, cap, mask, apron, foam mattress
on table, Kitof all life saving drugs  
(iv)Same discipline as that of O T is also to befollowed for labour room
i.e., use of gown, cap, mask, etc.before entering in labour room  
(v)Availability of deep freeze or wooden box withlock and key for
preservation of still born, Placenta, till theyare disposed off.  
(vi)Enough No. of aluminium/plastic badges foridentification of baby
and mother.  
(vii) Regular washing and fortnightly fumigation oflabour room   
(viii) Observance of proper housekeeping.   
(ix)Proper writing of delivery notes including thefoot prints of baby,
thumb impression of mother with attestationof nurse conducting
delivery.  
(x)Maintenance of call book in prescribed formatand attendance of
calls in time  
(xi)interview of 5 mothers delivered recently abouttheir experience
regarding facilities, behaviour of staff andsanitation in labour room  
(xii) Availability of attached toilet facility nearlabour room.   
(xiii) Arrangement to resuscitate newborn and to keepbaby warm   
(xiv)Availability of well equipped premature babyunit with minimum 6
beds.  
(xv)Availability of separate incubators for hospitaldelivery cases and
home delivery referred newborns  
(xvi) Staff trained in premature baby care.   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(xvii) Arrangement for prevention of Hypothermia.   
(xviii) Availability of Phototherapy unit, Oxygen hoods   
(xix) Proper maintenance of record, registers ofnewborns.   
(xx)Precautionary measures adopted to prevent sepsislike barrier
nursing, change of cloths by staff  
(xxi) Written instructions about operation ofincubator displayed   
(10) Wards   
1. Satisfactory cleanliness of the wards.   
2. Satisfactory condition of the sanitary blocks   
3. if, floor beds in the wards present, analyze thereason   
4.Satisfactory upkeepment of Cots, Mattresses,Bedside lockers, Lenin
etc.  
5. Use of hospital uniforms by all patients.   
6.Availability of Suction apparatus (electric andfoot operated), oxygen
cylinders with accessories, venesectiontray, emergency tray
emergency light, BP apparatus, equipmentsfor sterilization, wheel
chair-es, stretcher troll andstationaries, forms etc  
7. Suggestion book in wards and cognizance taken   
8.Concept of progressive patient care i.e. seriouspatients on fowlers
bed with all essential equipments and drugsnear Nursing Station.  
9. Display of name at head end of patients   
10. Adequacy and working of fans and tubes   
11. Availability of geysers in working conditions   
12.Srutinize 4 inpatient case sheets and ascertainadequacy of notes,
prescriptions, provisional and finaldiagnosis, operation and
aesthesia notes, documentation ofinvestigations, information to
relatives about seriousness of thepatient. Evidence of cases seen by
Specialist doctors. Patientsand relatives satisfaction.  
13.Satisfaction of patients about type of diet,quality and quality, if
provided by the facility  
(11) Diet and Kitchen Facility   
(i) Availability of different types of diets   
(ii) Physical verification of dietary articles doneany time. verify   
(iii) Availability of diet charts for adult,paediatric and special diet   
(iv) Arrangements for washing vegetable and vegetablecutting platform   
(v) Satisfactory cleanliness of kitchen   
(vi) Satisfactory arrangements for preventing ratnuisance   
(vii)Availability of modern gadgets like mixergrinder, chapatti puffer, hot
case, tea urns, bulk cooker,refrigerators, atta needing machines.  Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(viii) Availability of stainless steel with copperbased utensils for cooking   
(ix) Satisfactory arrangements for washing theutensils   
(x) Satisfactory arrangements for storing the foodgrains   
(xi) Regular medical check up of food handlers.(verify the records)   
(xii) Regular organization of diet committee meeting(very the minutes)   
(xiii) Availability of food testing register andremarks   
(xiv)Sending of samples of dietary articles for PAFstudies and action
taken on results  
(xv)Availability of lactometer measuring unit,weighing machine and
weights  
(xvi) Action taken on substandard supply of dietaryarticles   
(12) Linen and Laundry services   
(i) Availability of Linen Keeper/satisfactoryalternative arrangements.   
(ii) Availability of linen as per norms.   
(iii) Availability of buffer stock of linen to faceDisaster Emergencies   
(iv) Upkeep of linen register   
(v) Hospital linen stamped by Dhobi ink   
(vi) Regular disposal of condemned linen materials   
(vii)Services of tailor utilized adequately formaking new OT wears eye
shade and mending the torn cloths etc.  
(viii)A practise of Dirty/spoiled linen aredecontaminated/ washed and
given to Dhobi, is followed  
(ix) Whether Linen is kept separately and washedseparately   
(x) Use of aprons by Doctors   
(xi) Paramedical Uniforms   
(xii) Class iv Uniforms   
(xiii) Concept of Central Linen System implemented   
(13) Medical/Non Medical Stores   
(i)Suitability of location for all sections ofHospital and adequate space
for medical store  
(ii)Staff knowledge in materials management, systemof FiFo, bin card,
lead time, buffer stock reorder level arefollowed  
(iii)Availability of vital, essential and desirabledrugs sufficient to last for
at least three months.  
(iv) Upkeep of expiry date register and its regularinspection by RMO   
(v)Proper arrangements of the drugs as perABC/v.E.D. category and
storage or running stocks as perguidelines.  
(vi)Knowledge of minimum levels for each drug tostore keeper by bin
card system  Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(vii) All ampoule's are stamped with hospital name   
(viii)Satisfactory storage drugs with reference totemperature, sunlight,
protection from moisture, availability ofrefrigerators and exhaust
fans.  
(ix)Sending of samples of chemical laboratory tocheck it as per
specification and standard and action takenthereon  
(x)Maintenance of separate Register for the batchesdeclared unfit for
use  
(xi) Availability of licenses for spirit, morphine,opium   
(xii) Availability of Fire Fighting equipment's andknowledge to operate.   
(14) Medical Records   
(i)Availability of Medical Record Room with enoughnumber of racks
and cupboard etc.  
(ii) Knowledge of staff in keeping the medicalrecords in desired fashion   
(iii)Regular reporting of births and deaths to theappropriate authority
(verify)  
(iv) Regular WHO (ICD 10)classification of diseases.   
(v)Quarterly submission of the morbidity, mortalityreports (Check the
report of the last month to assess thecorrectness)  
(vi)Monthly Death audit Meetings held and minutes ofmeeting recorded
/ reported  
(vii)Organization of Hospital infection ControlCommittee meetings.
Action taken on minutes and investigationdone if any. (verify)  
(viii)Organization of Clinical Meetings and recordingof Minutes.
involvement of iMA or Professional associations etc.  
(15) Training, C M E,ICE and Social Actives   
(i)Establishment of Hospital Training Team andorganization of regular
clinical meetings, journal clubs andinvolvement of iMA  
(ii) Hospital Library with latest journals and basictext books.   
(iii) Services of qualified staff made available inOPD for iEC Activities.   
(iv) Posters and Banners displayed in OPD, Wards andpremises   
(v) Annual social gathering arranged for the staff.   
(16) Ambulatory Services and Telecommunication   
(a) vehicles   
(i) Status of Ambulances   
(ii) Availability of Garages   
(b) Telecommunication   
(i) Availability of PBx and Telephone Operator   
(ii) Availability of Public phone facility inCasualty and OPD   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(iii)Availability of Telephone directory andtelephone numbers of
Collector, Police Superintendent, FireBrigade, Water supply, other
ambulances., Electricity board andother private nursing homes to be
contacted in case of emergencyreferral  
(17) Commitment to National Health Programmes   
(a) Family Welfare, MCH and MTP Programme   
(i) Completion of proportional target ofSterilization   
(ii) Completion of proportionate iUD target   
(iii)Maintenance of - iLR, Refrigerator or walk incooler is satisfactory
with break down of cold chain less than 2%  
(iv)Up to date para wise, religion wise breakup oftotal deliveries taking
place in the institution month wise.  
(v)Organization of diagnostic camps, adoption ofPrimary Health
Centres/Rural Hospitals for providing specialityservices, training of
staff and officers in field.  
(vi) Organization of MTP training (verify therecords)   
(b) National Malaria Eradication Programme:   
(i) Blood Smear Collection (15% to new OPD)   
(ii)Blood smear examination done in Lab. On same dayand treatment
given as malaria clinic  
(iii)Knowledge of M.Os about presumptive and radicaltreatment of Pv
and PF  
(c) National Tuberculosis Control Programme;   
(i)Sputum Collection 25% of total new OPD at DTCDisposal of Sputum
Cups by burning or burial  
(ii)    
(d) National Programme for Control of Blindness:   
(i) Completion of prop, target of Cataract cases forHospital   
(ii) Follow up study done for restoration of visionafter operation   
(e) National Leprosy Eradication Programme:   
(i) Awareness of M.Os about M.D.T. Lepra reactionmanagement   
(ii) Reconstructive surgery camps organised   
(iii) Sanitation and management of temporary hospitalward   
(f) STD/AIDS Control Programme   
(i) Training of Medical Officers and Paramedicals inSTD/ Hiv/AiDS   
(ii) VDRL Screening of all STD cases done   
(iii) ANC Screening for vDRL done.   
(iv) Syndromic approach as per guidelines followed   
(v) Condom distribution to STD cases   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(vi) Drugs used as per National guidelines   
(vii) Attempt made for partner notification andappropriate steps   
(viii) Reports sent regularly in precribed format   
(ix) Bio-safety measures followed in regards toprevent Hiv .infection   
(g) Cancer Control Programme   
(i)Availability of pap smears facilities and followup study of positive
cases (verify the records)  
(ii)Training of qualified Pathologist orCynecologist and Technicians in
papsmear materials  
(iii)Availability of adequate equipments anduninterrupted supply of
staining materials  
(iv)Availability of adequate reagents and chemicalsfor pap smear at
clinic  
(v)Organization of diagnostic camps for cancercervix tobacco related
cancers in the tribe; and difficult areaof District with the help of
NGOs  
(18) Environment Sanitation and Water Supply   
(i)Condition of General sanitation of hospitalpremises and placement
of Dust bins at various places etc.  
(ii)Efforts made to prevent nuisance of strayanimals like pigs, donkeys,
cows, goats in the premises byproviding compound wall and cattle
trap etc. at Entrance andExist.  
(iii)Arrangements for regular lifting of garbage withthe help of
Municipality/Corporation  
(iv)Arrangements made for the safe disposal of theBiomedical Waste
generated in the hospital as per the BiomedicalWaste Management
and Handling Rules 2000.  
(v)Anti smoking, Spitting boards and other HealthEducation boards
depicted at prominent places in Hospital Campus  
(vi) Cleanliness inside and outside Canteen   
(vii)Arrangements of sufficient illuminationarrangements in Hospital
premises by Street light etc.  
(viii) Provision of Public latrines/toilets etc.   
(ix)Source of water supply is adequate, if not, thenefforts made to
augment it by Bore well or dug well etc.  
(x)Sanitation, Cleaning and general Condition ofoverhead tank/sump
well verify reports of OT test done bySanitary inspectors. Cross
check done by RMO (OR)  
(19) Patient Attendant facilities   
(i) Availability of patient Attendant facilities   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(ii)if available a) Whether adequate rooms availablewith kitchen, plate
form, condition of sanitary blockssatisfactory, and electric
tubes/bulbs, fans are provided in allrooms and halls.  
(20) Research Studies   
(i)Operational Research study undertaken such asExit interviews of
discharged patients, study undertaken toreduce patients waiting
time efforts made to investigate sourcesof material, infant mortality
in hospital and remedy suggestedbased on the results etc or Paper
presentation in various Stateand National level conferences.  
Part-III Minimum Standards for Equipment and FurnitureFor Hospitals and Nursing Homes
(Norms are Bed Strength Based)
Name ≥100 bedded 50-100 bedded ≤50 bedded
O.T Equipment    
Operating Table, Ordinary 3 2 1
Operating Table, Hydraulic 3 2 1
Autoclave, HP, Horizontal 3 2 0
Autoclave, HP, Vertical 2 1 1
Autoclave, Electrical with Burners, 2-Bin 0 1 1
Shadowless Lamp, OT, Mobile 4 3 2
OT Lights, Ceiling (Shadowless) 3 2 1
Focusing Lights, OT(Mobile) 3 2 1
Suction Apparatus (High Vacume MTP) 4 2 1
Suction Apparatus, Electrical 15 4 2
Foot Suction Apparatus 2 1 1
Vacuum Extractor 2 1 1
Steriliser Instrument 25 10 5
Electro-Surgery Machine 2 1 0
Cautery Set, Electric(Gynae) 3 2 1
Auto-mist (OT Fumigator) 3 2 1
Short-Wave Diathermy 1 1 0
Ventilator, Adult 1 0 0
Anesthetic M/C (Boyle's with Flotec) 2 1 1
Pulse Oximeter 1 1 0
E.C.G. Machine (12-Lead) 3 2 1
Cardiac Monitor 2 1 0
Defibrillator 2 1 0
Phototherapy Unit 2 1 0
Radiant Heater, 4KW 1 1 0Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Incubators 2 1  
Open Care Units 1 1  
Neonatal Resuscitation Unit 2 1  
General Equipment    
Refrigerator, 165/300 Litres 8 5 2
Air Conditioners 8 5 1
Water Cooler, 60/120 Litres 3 2 1
Generator, 15 KVA 0 1 0
Generator, 50 KVA 1 0 0
Intercom (15 Lines) 0 1 0
Intercom (40 Lines) 1 0 0
Fax Machine 1 0 0
Telephone Lines 12 6 2
Vehicles 1 0 0
Ambulance 2 1 1
Minor Equipment    
B.P. Machine 24 12 6
Weighing Scale, Adult 12 4 2
Weighing Scale, Infant 4 2 1
Oxygen Cylinders 40 20 10
Nitrous Oxide Cylinders 20 10 5
Regulator and Flow meters 16 8 4
Hot Plate, Domestic 6 3 1
Emergency Lamp 16 8 4
Fire Extinguishers (Various Types) Each 8 4 2
Laryngoscope's 4 2 2
Otoscope 2 1 0
Resuscitation Equipment 2 1 0
Hospital Furniture    
Examination Table 30 15 5
Labour Table 6 4 2
Foot Steps 30 15 5
Bedside Screens 40 20 10
Revolving Stool 40 20 10
Saline Stands 50 25 10
Wheel Chairs 12 4 1
Emergency/Recovery Trolley- 4 2 1Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Stretcher on Trolley 12 4 2
Oxygen Cylinder Stands 16 8 3
Iron Cot As per bed strength As per bed strengthAs per bed
strength
Side Rails 10 4 2
Baby Cot 12 6 4
Bedside Locker As per bed strength As per bed strengthAs per bed
strength
Dressing Trolley 12 4 2
Mayo’s Trolley 4 2 1
Surgical Instrument Cabinet 8 4 2
Medicine Cabinet 10 4 1
Instrument Trolley 8 4 2
Linen Trolley 8 4 2
Kick Bucket 16 8 4
Bucket (Galvanised) 20 8 4
Bed Pans and Urinals 20 8 4
Attendant Stool As per bed strength As per bed strengthAs per bed
strength
Wash Basin Stands 40 20 10
Instrument/Medicine Tray with Cover 24 12 4
Bowls and Kidney Trays 40 20 8
Chair (Doctors, Nurses) 50 24 12
Swab Rack (OT) 4 2 1
Fracture Table (POP) 2 1 0
Mattress and Pillows strength As per bed strength As per bed strengthper bed As
strength
Benches Numbers Adequate Numbers Adequate NumbersAdequate
Numbers
Height Measuring Stand 4 2 1
Arm Board (Child and Adult) 60 40 20
Jar, Cheater forceps 20 10 4
Patella Hammer 8 4 2
Tongue Depresser 20 12 6
Oxygen Masks with Regulator 8 4 2
Torch Light 12 8 2
B. Equipment For Diagonistic Centers    
Radiology and Imaging Units    Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

500 MA/300 MA/100 MA X-Ray System    
60 MA Mobile X-Ray System    
Ultrasonic Scanner, General Purpose    
Ultrasonic Scanner, Obstetrics purposes    
High-End Diagnostic Centers    
C.T Scanner with Image Processors
Mammography   
500 MA X-Ray Unit with IITV    
All other Imaging Equipment    
Bio-Chemistry and Pathology Centers    
Microscope, Binocular with Lamp    
Photo-Electric Calorimeter    
Spectrophotometer    
Micro Pippette    
Water Bath    
Hot Air Oven, 2 Levels    
Incubator, Laboratory    
Water Still, 4 Litres    
Centrifuge (Electrical)    
Centrifuge (Haematocrit)    
Hot Plate, Laboratory    
Rotor/Shaker (Laboratory)    
Counting Chamber (Haemocytometer)    
Ph Meter    
Glucometer (in OPD)    
Haemoglobin Meter Microtome    
Oven, Wax-Embedding    
Tissue Processor    
Blood-Gas Analyser    
Timer Stopwatch and Alarm Clock    
Appendix-II(See Rule 5 (a))Part - I Physical Requirements of Medical Care EstablishmentsA. Clinics
and consultation rooms. - (1) Floor area of 100 sq. ft and to have separate waiting
area(2)Examination table(3)Stethoscope(4)BP apparatus(5)Knee hammer and Torch
light(6)Weighing machine and Measuring tape(7)Adequate illumination(8)Thermometer and
Tongue depressor(9)A small refrigeratorOther ancillary examination equipment depending on
speciality practised, feotoscope for obstetrician's magnifying glass for dermatologists, loupe and
Snellen's charts, trips sets, ophthalmoscope, slit lamp for ophthalmologists, dental chair and Lamp
for dental surgeons. 50 beddedB. General Hospital with bed strength of 20 or less. - (1) Floor area
for each bed in the inpatient areas - a minimum of 50-60 sq. ft for each bed. This area is in additionAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

the essential functional areas, and common areas like halls, consultation rooms, toilets, bathrooms
and corridors.(2)Staff pattern: Trained/qualified nursing staff should be available round the clock.
The doctor should be available round the clock. In case of short term non-availability of the doctor
alternate arrangements should be made.(3)If surgery is to be performed, an operation theatre
should be provided as per the General Requirements and in accordance with the following specific
features:(a)A floor area of a minimum 120 sq. ft.(b)Operation table with basic manipulation
facilities(c)Surgical Instruments needed for the individual surgical procedure to be performed(d)A
Small Generator should be installed.(e)Post-Operative Ward as described in the General
Requirements(f)The Zoning requirements as given in the General Requirements shall be strictly
followed.(4)If the nursing home is run as a maternity and nursing home, it should have a labour
room as per the General Requirements, and facilities for neonatal care, resuscitation and referral
facilities.(5)If the nursing home or hospital is providing any specialist care, it should have the
requirements as given in the Part III for the speciality concerned.C. General Hospital with bed
strength of 21 to 50. - (1) Floor area for each bed in the inpatient areas - a minimum of 60 sq.ft for
each bed. This area is in addition to the essential functional areas, and common areas like halls,
consultation rooms, toilets, bathrooms and corridors.(2)Staff pattern: Trained/qualified nursing
staff should be available round the clock. The doctor should be available round the clock. In case of
short term non-availability of the doctor alternate arrangements should be made.(3)If surgery is to
be performed, an operation theatre should be provided with the following specifications and over
and above other general features mentioned in the Para E of the General Requirements:(a)Floor
area of a minimum of 200 sq. ft preferably away from public movement.(b)Hydraulic Operation
Table(c)O.T Ceiling Light(d)Surgical Instruments needed for the surgical procedures to be
performed in good condition.(e)Pulse-oxymeter(f)A small Generator should be
installed.(g)Post-Operative Ward as described in the General Requirements(h)The Zoning
requirements as given in the General Requirements shall be strictly followed.(4)If the nursing home
is run as a maternity and nursing home, it should have a labour room with the specifications as
given in the General requirements and to have an operation theater as per the requirements, and
facilities for neonatal care, resuscitation and referral facilities.(5)If the nursing home or hospital is
providing any specialist care, it should have the requirements as given in the Part III for the
speciality concerned.D. General Hospital with bed strength of 51 to 100. - (1) Floor area for each bed
in the inpatient areas - a minimum of 75 sq.ft for each bed. This area is in addition the essential
functional areas, and common areas like halls, consultation rooms, toilets, bathrooms and
corridors.(2)Staff pattern: Trained/qualified nursing staff should be available round the clock. The
doctor should be available round the clock. In case of short term non-availability of the doctor
alternate arrangements should be made.(3)If surgery is to be performed, operation theatre should
have the following specifications and other general features mentioned in the Para E of the General
Requirements:(a)Floor area of a minimum of 200 sq. ft preferably away from public
movement.(b)Surgical Instruments needed for the surgical procedures to be performed in good
condition.(c)One additional Operation table with basic manipulation facilities for Minor
O.T.(d)Pulse-oxymeter(e)Cardiac monitor with defibrillator(f)For Un-interrupted power supply a
suitable Generator should be installed.(g)Air conditioning should be provided.(h)Post Operative
Unit Should be maintained as given in the General Requirements(4)If the nursing home is run as a
maternity and nursing home, it should have a labour room with the specifications as given in the
Para F of the General requirements and to have an operation theater. The additional requirementsAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

for the labour room include:Space Requirements:(i)Ante-natal ward(ii)Post-natal ward(iii)Neonatal
Care facilitiesEquipment Requirements:(1)Foetal monitor(2)Radiant warmer and(3)Phototherapy
unit(4)If the nursing home is also offering speciality care services, then the specific requirements as
Given in the Part III as applicable to the speciality concerned shall be made available.E. General or
Speciality Hospital with d strength of 100 to 200. - (1) Floor area for each bed in the inpatient areas
- a minimum of 81 sq. ft for each bed. This area is in addition the essential functional areas, and
common areas like halls, consultation rooms, toilets, bathrooms and corridors. In all a total built up
area of 45 Sq. M per bed shall be provided. All the functional areas required as per the Standards
shall be provided.(2)Staff pattern: Trained/qualified nursing staff should be available round the
clock. The staff to the bed ratio should be a minimum of 1 for 10 beds during working hours. The
doctor should be available round the clock. In case of short term non-availability of the doctor
alternate arrangements should be made.(3)If surgery, is to be performed, Two (2) operation theatres
should be provided: one theater to be reserved for minor/ trauma/septic cases. The main operation
theater should have the following specifications and other general features mentioned in the Para E
of the General Requirements:(a)Floor area of a minimum of 200 sq. ft preferably away from public
movement.(b)Surgical Instrument needed for the surgical procedures to be performed in good
condition.(c)Pulse-oxymeter(d)Cardiac monitor with defibrillator(e)For un-interrupted power
supply s suitable Generator should be installed.(f)Post Operative Unit and Intensive Care Units
should be maintained as given in the General Requirements(g)It is ideal to have a separate minor
operation theatre to perform smaller surgeries and to deal with infected cases hereby promoting
greater, asepsis in the major theater.(4)If the nursing home is run as a maternity and nursing home,
it should have a labour 'room with the specifications as given in the Para F of the General
requirements, and facilities for neonatal care, resuscitation and referral facilities.(5)If the nursing
home or hospital is also offering speciality care services, then the specific requirements as given in
the Part III as applicable to the speciality concerned shall be made available.F. Speciality Hospital
with bed strength more than 200. - (1) Floor area for each bed in the inpatient areas-a minimum of
90 sq.ft for each bed. This area is in addition the essential functional areas, and common areas like
halls, consultation rooms, toilets, bathrooms and corridors. In all a total built up area of 55 Sq. M
per bed shall be provided. All the functional areas required as per the Standards shall be
provided.(2)Staff pattern: Trained/qualified nursing staff should be available round the clock. The
staff to the bed ratio should be a minimum of 1 for 10 beds during working hours. The doctor should
be available round the clock. In case of short term non-availability of the doctor alternate
arrangements should be made.(3)If surgery is to be performed in various specialities accordingly
operation theatres should be provided with minimum two operation heaters: one theater to be
reserved for minor/ trauma/septic cases. The main operation theater should have the following
specifications and other general features mentioned in the Para E of the General
Requirements:(a)Floor area of a minimum of 200 sq. ft preferably away from public
movement.(b)Surgical Instrument needed for the surgical procedures to be performed in good
condition.(c)Pulse-oxymeter(d)Cardiac monitor with defibrillator(e)For un-interrupted power
supply a suitable Generator should be installed.(f)Post Operative Unit and Intensive Care Units
should be maintained as given in the General Requirements(g)It is ideal to have a separate minor
operation theatre to perform smaller surgeries and to deal with infected cases thereby promoting
greater asepsis in the major theater.(4)If the nursing home is run as a maternity and nursing home,
it should have a labour room with the specifications as given in the Para F of the GeneralAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

requirements, and facilities for neonatal care, resuscitation and referral.(5)If the nursing home is
also offering speciality care services, then the specific requirements applicable shall be made
available.G. Physiotherapy unit.(1)Man Power Needed. - (a) Physiotherapists - Qualified Degree
B.P.T or B.Sc. (P.T) or M.P.T. or M.Sc. (PT) are equally qualified.(b)Physiotherapy Diplorpa
Holders/ Technicians - Trained for 1 year to 2 years with Certificate holders or Trained personal of
Physiotherapy as Assistants to Physiotherapists.(c)Attenders-cum-Ward boys for mobilization of
patients(d)Sweepers(e)Receptionist-cum-Office bearer and Administrative In charge(2)Instruments
Needed.(a)Electro Therapy. - Muscle Stimulators, S.W.D., U.S. Therapy, I.F.T/Tens, Traction Unit,
Wax Therapy and CRYO Therapy(b)GYM Instruments. - Adults:(i)Parallel
BarsChildren:(ii)Shoulder Wheel, Quadriceps table, Static Cycle, Wobble board Exerciser,
Suspension - cum -Spring Exercising unit with accessories, Wheel chairs, Walkers, Crutches,
Medicine Balls etc, Accessories(3)Required Premises. - Center needs easy approachability and
transportability with sufficient parking space, since most of the patients are brought by means of
transport.(4)Unit Requirements. - Needful total area around 2000 sq.ft + 500 sq. ft (in-built area)
for 20-30 patients for 8 hours of work of a day.(a)Reception (Registration)(b)Office-cum-Manager's
room(c)Waiting room for patients and Attenders(d)Examination-cum-Assessing com(e)Hall for
Exercising (GYM) with suspension therapy unit(f)Electro therapy unity with No. of curtain cabins
with Cots and machines(g)Attached toilets(5)End Note. - To make a full fledged Physical
Rehabilitation Centre with inpatients facility. We need to add up space and qualified personal
like(a)Occupational therapist(b)Speech therapist as part time(c)Orthotic and prosthetic
Engineer(d)Medical Social Worker(6)As on Call, Doctors Like. - (a) Neuro Surgeons and Neuro
Physicians(b)Orthopaedic Surgeons and Plastic Surgeons(c)General PhysiciansH. Dental Clinic. - A
Dental Clinic is to be established and run by a qualified Dental Surgeon with minimum B.D.S.
Degree from a dental college recognized by Dental Council of India.The Dental Clinic should have
with the following minimum equipment and trained staff:(1)A Dental Chair with spittoon, Halogen
Light, Suction Apparatus, Aerator, micro-motor and 3 way syringe(2)Ultrasonic Scalar(3)Light Cure
equipment(4)Sterilizer(5)Extraction Forceps, Scalars, Diagnostic and filling
instruments(6)Emergency Drugs like Xylocaine, Stypitice corticosteroids, Mephetine, Nikethemide
and other emergency drugs should be available all the time.(7)All consumable dental materials,
Oxygen cylinder with ambu bag, resuscitation equipment etc.(8)A qualified dental assistant or an
experienced assistant should be employed.(9)Intra-oral X-ray Machine may be attached
(optional)(10)A Dental Laboratory may be attached (Optional)(11)Clinic Board should be according
to rules of the State Dental council Manual.(12)A medical doctor on call to attend any
emergency.(13)A register should be maintained for OP patients and surgery done with
details.(14)Provision for Bio-Medical waste should be arranged.(15)Record for MLC cases, surgeries
and OP Tickets with summery sheet in a standard draft should be kept ready in
clinic.(16)Consultation fee, surgery charges, investigation charges, O.T. Charges etc should be
displayed along with estimation before treatment be provided to the patients.I. Clinical
Laboratories. - (1) Note: Provision of the Drug and cosmetics Act, 1997 shall be
applicable.(a)Attached Laboratory. - For a laboratory attached to a medical establishment the
medical superintendent or doctor in charge will be signatory to reports and responsible for the
results.(b)Small Laboratory. - The laboratory performing routine tests in the field of hematology,
fluids and excretions and biochemistry up to 100 tests per day be manual or semi automated
techniques and should be manned by qualified doctors/or Lab technician with a minimumAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

qualification of M.Sc., with 5 years experience in Laboratory machine.(c)Medium Laboratory. - The
laboratory performing the above mentioned tests and special tests in the above-mentioned
specialities or the other laboratory disciplines (such as histopathology, cyto-pathology etc.,) and
doing 101 - 500 tests per day.(d)Large Laboratory. - The laboratory doing the above mentioned tests
with a higher load than 500 tests per day and/.or sophisticated instruments such as automated
Analysers, ELISA readers, fluorescent microscopes, etc.(e)Super-Speciality Laboratory. - The
laboratory is restricting its activity to one or two disciplines of laboratory medicine.(2)Staff and
Education.(a)Supervisory personnel. - The large and super-speciality, laboratory shall be manned by
a medical person with post -graduate qualification in pathology or microbiology or
Biochemistry.Allopathic doctor must man and supervise small and medium laboratories. Such a
doctor shall be a full time employee, and is not allowed to run a separate similar establishment
elsewhere.Any laboratory that performs histo-pathological, cyto-pathological and special
haematological tests must be manned by Post Graduate or in the speciality
concerned.Multi-disciplinary laboratories shall identify a group leader for each of the areas that who
have specific qualification.(b)Technical Personnel. - The technical person performing the tests and
reporting the results should be qualified personnel from an institution recognized by the
Government.A laboratory may employ up to 25% of the staff without qualification but with
experience of at least 5 years in a recognized laboratory.(3)Facilities. - The space required by the
laboratory shall be commensurate with the type and range of tests performed, the level of
automation available, degree of computerization, workload and manpower. Adequate space should
be provided to enable efficient maintenance of equipment.Each laboratory however must ensure
adequate provision of space for the following:- Sample collection and Sample analysis -Storage of
samples, reagents, chemicals, spares, stationary and records -Washing- Media preparation and
autoclaving (applicable to microbiology laboratory) Storage of slides, tissue blocks, grossing
(applicable to histopathology laboratory)- Toilets- Fire safety- Laboratory' must be well lighted and
ventilated to provide healthy environment. Many tests and equipment require regulated
temperature and therefore wherever necessary effective air conditioning and uninterrupted power
supply must be available as per the manufactures recommendations. It is however understood that
the laboratory performing simple tests need not have all the facilities.Note. - The laboratory shall
limit and restrict entry to authorized personnel to testing areas to ensure confidentiality and safety
of patients and visitors.- Microhaematocrit tunes sealing compound(f)Bacteriological and
Biochemical Apparatus. - Nickle-chromiumally (Nichrome) wire, 1mm diameter loop holders.
Bunsen burner for use with butane gas.(g)For Laboratories Performing Specialised
Tests(i)Immunology- Water bath, temperature controlled- Elisa reader- Autoclaving facility-
Laminar flow(ii)Cyto genetics.-Sterilization Equipment- Tissue culture facility- Provision for special
stains- Provision for Video camera monitor- Staining facility- Photo microscopy- Fluorescent
microscope- Co2 Incubator(iii)CytopathologyFacility for stains in PAP, H and E Micro tome, water
bath, tissue floating bath(7)Laboratory Records and Reports. - Should be maintained for at least 1
month. H.P. - Slides for 6 months and Blocks for 3 months.(8)Subcontracting of Testing. - (a)
Where a laboratory subcontracts any part of the testing, this work shall be placed with a laboratory
complying with the minimum criteria. The laboratory shall ensure and be able to demonstrate that
its subcontractors are competent to perform the activities in question and complies with the same
criteria of the competence as the laboratory in respect of the work being subcontracted.The
laboratory shall advice the patient in writing of its intention to subcontract any portion of testing toAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

another center.(b)The laboratory shall record and retain details of its investigation of the
competence and compliance of its subcontractors and maintain a register of all
subcontracting.(9)Explanatory Remarks. - Laboratories must document their policy and procedure
for subcontracting in any case the laboratory remains fully responsible for the subcontracted work,
it shall ensure that the work is performed in accordance with criteria in this document.
Preferentially only those laboratories should be selected that are accredited by an organization that
are adequately equipped for such purpose and are manned by qualified and experienced
professional. In all circumstances the patient must be informed of subcontracting or must approve
of the subcontracting in writing.J. Genetic Centres. - The minimum standards as specified in the
PNDT Act (Central Government Act) will apply for the genetic centers.(4)Safety and
Environment.(a)Sample Collection, Handling And Pre-Analytical Storage. - All specimens received
by the laboratory should be treated as potential infectious or hazardous. Universal precautions
should therefore, observed in handling and transport of these specimens in conformity with
National and International guidelines.(b)Disposal of Samples and Related Materials. - The
laboratory shall dispose contaminated waste such as microbiology, Cultures, organs and tissues,
blood and body fluids, contaminated swab tissue papers, towels, pipettes tips, storage vials,
glassware, needles other sharps by dis-infections with chemicals or autoclaving before appropriate
disposal such as through incineration, or transmitted to authorized waste disposal agency or secure
land fills, meeting environmental regulations in force. Chemicals, auto calving or irradiation before
washing shall disinfect reusable Chemical dis infections are carried out in a suitable receptacle kept
at the workstation. Commonly used disinfectants are sodium hypochlorite, formaldehyde,
glutasraldehyde, phenol and hydrogen peroxide.The laboratory shall maintain the records of all
patient results for a minimum period of ONE month or a maximum of THREE months. Speciality
work like Histopathology, cytology for 1 year. Blocks for 3 months and slides for 6 months.(5)Ethical
Practises. - The laboratory shall maintain the highest standards of integrity and maintain utmost
confidentiality with regard to the findings on the specimens sent to the laboratory.(6)List of
Apparatus Needed. - (a) Laboratory Instruments:(1)The Microscope (Essential)(2)The
Centrifuge(3)Refrigerators(4)A Thermostatically controlled water bath (37c-56c)(5)A Rotating
machine for VDRL tests(6)A Differential counter(7)A Photometer or calorimeter(b)Additional
Items. - Not essential but useful(1)The Autoclave, The Hot air oven, Balance, and deionizer or a still
for making distilled water(c)Equipments for Collection of Specimens. - Syringes, Needles, Cotton,
Glassware (Beakers, Tubes, Flasks, Slides, Cover slips) Pippettes, Capillary tubes, Measuring
Cylinders, graduated, with stopper, glass bottles(d)Haemotological Apparatus. - Pipettes, Sahli,
0.02ml. Rubber tubing Pipettes blood 0.05ml.(e)Counting chamber.-Improved Neubauer (bright
line if possible)-Fuchs Rosenthal-Cover glasses optically plane for counting chambers-Tally
counter-Tubes, Westergrcen for ESR-Stands for Westcgren tubes
Computer forprinting of reports and accounting purpose50 - 60
Sq.ft
Emergency drugs, oxygen cylinder, ambu's bag,Suction apparatus and Emergency - cum -
observation bed withmonitor should be provided.60 -
100
Sq.ft
(c)Radiological Equipments and Area required for large Hospitals:
Diagnostic Medical X-ray Unit 300/500/800 MA withIITV at 125 KVP 260-320 Sq.ft
(25-30Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Sq.mtrs)
Cath lab with DSA 1000 MA - 1250 MA 300-400 Sq.ft
Diagnostic Medical X-ray Unit with Odeleca facility300 MA X-ray unit 260 Sq.ft
Ultra sound unit (B and W) with linear / Convex /sector 7 endocavitary probe /
Multi-frequently probe with multiformat camera / thermal photo paper printer.100 Sq.ft
Colour Doppler with echo facility ultra sound unitwith convex, Micro-convex, linear,
endo-cavitary probe withbiopsy attachment, multi frequency probe with multi
format cameraboth for colour and B and W prints and computer assisted
reportformat. Video recorder / camera for slide making facility.100 Sq.ft
Mammography with all accessories including specialcassettes, intensifying screens,
viewing Boxes with magnifyingglass, paddling device, FNAC Biopsy Needle facilities
must beavailable. (Lady x-ray technologist is preferred)100 Sq.ft
Whole body C.T. Conventional scanner with cameraand console should be outside in
a separate room (site Planattached)400 Sq.ft
Spiral CT Scanner with work station and LaserCamera MR1 up to with 0.3 tesla
permanent magnet with LaserCamera, UPS, RF coils (5x7 mtrs = 35 mtrs)600 Sq.ft
Magnetic field leakage 5 Gauze line should bemeasured from center for magnet
length - wise (3.0 (X, Y) x 4.7(Z) Over and above 1.5 Tesla supercon MR1 will need
furtherbigger Area according to specification of manufacturer.100 Sq.ft
Drying area for images and X-ray films 100 Sq.ft
Dark room with accessories  
Automatic films processor unit 100 Sq.ft
Computer with reporting facilities and storage  
Emergency trolley with drugs, suction pump 150 Sq.ft
Two emergency cum observations bed with monitorshould be provided for patients
Gamma Camera with Speck 
Planning and Radioactive pharmaceutical materialpreparation 400 Sq.ft
Treatment room with 2 beds 200 Sq.ft
Storage and decontamination 200 Sq.ft
Nuclear Cardiac Stress Lab 200 Sq.ft
Note. - Apart from above, patient waiting area, with proper facilities and toilets, reporting room,
storage room and library should be provided in the Radiology Department.K. Infertility Centres . -
The infertility centers shall have the following: -(1)Qualified personnel with adequate
experiences(2)Adequate laboratory facilities for conducting tests(3)Services of a trained
Embryologist(4)Laminar flow equipment(5)Inverted fluorescent microscope(6)Deep-freezing
facilities(7)Operation theater as per general requirements(8)Sample collection
facilities(9)Consultation and waiting areas(10)SteriliSation equipmentL. Radiology And Imaging
Centres. - Equipment and space for the department would have to be planned according to the
program functions. In the minimum following X-rays should be possible: X-ray chest, abdomen,
pelvis, femur and skill. For this an X-ray machine 300 m A capacity is needed. In nursing homes
providing emergency surgical facilities and those with more than twenty beds, the X-ray machineAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

should be installed within the nursing home premises. In smaller facilities, it should be possible to
have access to such X-ray facilities within one hour.Standard precautions should be taken in the
construction of the radiology room like constructing the walls with barium impregnancy bricks. The
AERB guidelines provide the minimum requirements for the Radiation safety.In radiological
facilities where procedures like IVU are carried out, separate facilities should be provided for
disposal of urine.In case radiotherapy, nuclear medicine facilities are to be provided guidelines by
local statutory bodies should be followed.Basic minimum requirements for x-ray department and
equipment concerned and area required for small, medium and large diagnostic centres, hospitals
and nursing homes in city, districts and taluka levels.(a)Radiological Equipments and Area required
for small Hospitals.
 Area
Required
Diagnostic Medical X.-ray unit - 60/100/300 MA180-260
sq.ft
Dark room with accessories60-100
sq.ft
Emergency drugs and Oxygen cylinder or Ambu's bag and Suctionapparatus must be
provided in Radiography room 
(b)Radiological Equipments and Area required for Medium Hospitals
DiagnosticMedical X-ray Unit - 200/300/500 MA at 100/125 KVP260 Sq.ft. (25
Sq.mtrs)
Diagnostic Medical X-ray Unit - 500 MA/800 MA(Adjacent patients toilet
facility) with IITV260 to 300 Sq.ft.
(25 to 30 Sqmtr)
Ultra sound Unit (B and W) with linear / convex/ sector / endovavitary probe /
multi - frequently probe withmulti-format camera / thermal photo photo
paper printer100 Sq.ft
Dart room with accessories 80-100 Sq.ft
Portable / mobile x-ray unit /portable ultrasound/ ECG unit 80-100 Sq.ft
Check List of Part - 1 of Appendix - IIMedical: Standard Services Recommended for each Level
SI.
No.ConditionProcedure BasicLevel ServicesSpecialistCare
ServicesSuper Speciality
Services
1. ConvulsionsSymptomatictreatment and
referInvestigate,initiate,
L.P, manage and referCT scan,
advanced
neurological
treatment
2.Lossof
consciousness/comaSymptomaticand
supportiveInitiatetreatment,
manage and referCT scan,
advanced
neurological
treatment
3. En-cephalities,mcningities
CNS infectionsSymptomatictreatment and
referManage,Support and CT scan,
advanced,
neurologicalAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

treatment
4. Headinjuries FirstAid, referManage,stabilise,
refer for advanced
managementAdvanced
management
with altered
sensorium with
fracture
5. Respiratory Initiate,manage and referpHchange, severe
distress-
6. AsthmaSymptomatic,manage and
referSevereCondition
(status)-
7. C.O.P.DSymptomatictreatment and
referInvestigate,manage,
followup-
8. Earinfection Manageand Refer Treatment -
9.Cardio-vascularproblems
hypertensionMildmoderate:manageAcceleratedand
severe conditions-
10. C.V.A.Symptomaticmanagement,
referManageand follow up -
11. Angina,infractionsSymptomaticmanagement,
referInvestigate,manage
refer, follow upComplications
12. C.H.FSymptomaticmanagement,
referComplicated,follow
up-
13.Rheumaticfever and
Rheumatic heartSymptomaticmanagement,
referInvestigate,manage
refer, follow upComplications
14.GIbleeding, ulcers,
DiseasesSymptomaticEndoscopicinvestigation,
treatmentComplications
15. G.E.Managemild, moderate
referTreat -
16. Hepatitis SymptomatictreatmentConfirmdiagnosis,
manage-
17. Cirrhosis SymptomaticInvestigate,manage,
follow upComplications
18. RenalUTI Symptomatic,refer diagnosis,manage -
19. AcuteRenal failure SymptomaticreferInvestigate,management,
referDialysis and
advanced
management
20. Musculoskeletal Symptomaticrefer ManageRecurrent:
further
evaluation,
complications
21. Anaemia Managemoderate Managesevere -Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

22. Tetanus Symptomatic,initiate Manage -
23. Malaria Manage Severe -
24. AIDS  Diagnosis,initiate
managementDiagnose and
manage
25. Psychiatric Symptomaticmanagement  Severe
26. Psychiatricdisorder Managemild, Moderate  Severe
27. Poioning Initiate,Manage, refer Investigate,manage -
28. Neonatalrescusciatation Initiateand refer Manage -
29.Neonatalcardio
pulmonary defectsInitiateand referInvestigate,manage,
followupComplications
30. Diabetes Diagnosis,initiate Complications -
31. Snakebite and dog bite Manage Complications -
32. Skindisorders Refer Manage -
33. S.T.Ds. Manage Diagnoseand Treat -
Part II – Speciality Services and its Requirements
A. Basic Speciality Services.
1. Orthopedic and Trauma Care. - A hospital or nursing home irrespective of
the bed strength offering Orthopedic surgical care and trauma care services
should have the following equipment and facilities:
(a)Basic instrumentation sets for fractures, large fragment and small fragment external fixators,
Portable X-ray machine, C-arm image intensifier (Optional), Arthroscope (Optional), Plaster room
equipment with plaster table, Operation room equipment and instrument sets, and attached
Physiotherapy and occupational therapy facilities.(b)Trauma Care centers: In addition to the
orthopedic surgery equipment, the hospital should have a CT scan equipment, Resuscitation ward
Post Operative ward, Intensive Care Unit, Full fledged Operation Theatre, Blood Bank, and Full
fledged Clinical lab support and Radiology and Imaging support, ambulatory and communication
equipment support.Specialist Qualifications. - The Orthopedic Specialist should have M.S. (Ortho)
degree from a university or equivalent from a local recognised body OR diploma from Diplomate of
National Board or local recognised bodies or university or equivalent from a local recognized body.
2. ENT care. - A hospital offering the ENT speciality treatment basically to
have the following equipment:
(a)Basic Equipment: - Nasal Speculum, Tongue depressor, Laryngel mirrors, Nasopharyngeal
mirrors, Aural speculum, Ear suction, Nasal suction, Suction apparatus, Seigles speculum, Tuning
fork, Otoscope, Bulls lamp, Head lamp, ENT examination chair, Sterilizer, B.P. Apparatus, and
Stethoscope(b)O.T. Instruments: - Tonsillectomy and Adenoidectomy sets, Sets for nasal bone
fracture, Septoplasty set, Antrostomy set, Tracheostomy set, FESS set, Direct laryngoscope set,Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Microlaryngoscopy set, Tympanoplasty set, Mastoidectomy set, Staoedectomy set, Oesophagoscopy
set, and Bronchoscopy set(c)O.T. Equipment: - Operating Microscope, Pure Tone audiometer,
Impedance Audiometer, Temporal bone lab microscope, Mastoid Set, and Micro motor with
Drill,Specialist Qualifications. - The ENT Specialist should have M.B.B.S, D.L.O or M.S. (ENT)
degree from a university or equivalent from a local recognised body OR diploma from Diplomate of
National Board or local recognised bodies or university or equivalent from a local recognized body.
3.
, Eye (Ophthalmic) Care. - A hospital offering Ophthalmic care facilities should have the following
equipment and facilities:(a)Basic Equipment: - Snellen's Chart or Drum, Trail Set with frame, Near
vision charts with different languages, 3 Cell torch, Ophthalmoscope and, Retinoscope, Slit Lamp,
Applanation tonometer, Kerato meter, Indirect ophthalmoscope, and a Gonioscope(b)O.T.
Equipment: - Operating microscope, Cryo unit, Cataract set, Glaucoma set, Entropian set,
Enucleation set, Squint set, O.T. Table, and O.T LightSpecialist Qualifications. - The Ophthalmic
Specialist should have M.B.B.S, D.O or M.S. (Ophth) degree from a university or equivalent from a
local recognised body OR diploma from Diplomate of National Board or local recognised bodies or
university or equivalent from a local recognized body.
4. Obstetric and Gynaecology Care facilities. - The maternity care facilities
should provide basic obstetric services and neonatal care services. All
maternity homes should be able to carry out procedures like suction and
evacuation, dilatation and curettage. Lower Segment Cesarean Section and
Hysterectomy on an emergency basis. Blood transfusion facilities should be
available within half to one hour. Also ultrasonography facilities should be
available within half to one hour. A hospital or nursing home offering
Obstetrics and Gynaecology care services should have the following
facilities:
(a)Basic O.T Equipment: O.T Table, O.T Light, High Suction Apparatus, vacuum extractor etc.,
Resuscitation tray, Cervical biopsy set, MTP set, D and C' set, and Delivery sets and Episiotomy set
and feuotal Doppler, Ophthalmoscope and Pulse Oxymeter.(b)Surgical Instrument sets: -
Abdominal Hysterectomy set, Vaginal Hysterectomy set, Tuboplasty set, Myomectomy set,
Diagnostic Laparoscopy set, Operating Laparoscopy set (Optional), Hysteroscopy set (Optional),
and Rectoscope (Optional)(c)Support Equipment: - Electrocautery, Multi channel monitors
(Optional), C.T.G machine, Ultrasound Machine (Optional), and Supported by Lab facilities for
investigationsSpecialist Qualifications. - The Specialist should have M.B.B.S, D.G.O or M.D. (Ob and
Gy) degree from a university or equivalent from a local recognised body OR diploma from
Diplomate of National board or local recognised bodies or university or equivalent from a local
recognized body.Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

5. Cancer Treatment Facilities. - A hospital offering radiotherapy services for
the treatment of cancer should have the following facilities:
(a)Radio-diagnostic facilities: - Conventional X-ray Unit, Mobile X-ray Units, Computer
Tomography, Magnetic Resonance Imaging (Optional), and Mammography(b)Radiotherapy
facilities: - Treatment Planning and Mould room including: Computerized treatment planning
system, Simulator, Immobilization Cast making system, Brachytherapy set-up, Teletherapy set-up,
Dosimetry system, Radiation Protection Set-up, and Linear Accelerator (Desirable)Specialist
Qualifications. - The Specialist should have M.D. Radiotherapy or M.S, M.Ch (Surgical Oncology)
degree from a university or equivalent from a local recognised body OR diploma from Diplomate of
National Board or local recognised bodies or university or equivalent from a local recognized
body.B. Super Speciality Services. - (a) Cardiology and Cardiothoracic Surgery facility: - A hospital
or nursing home which claims to provide Emergency Cardiology Services should possess intensive
care facilities. A Super Speciality Hospital offering treatment in this area should have the following
minimum facilities:(b)Diagnostic and Support Services: - Radiology services including C.T., MRI,
Angiography facilities, Stress test, echo-cardiography, and Full fledged clinical laboratory, well
equipped operation theatres of high aseptic conditions, Intensive Coronary Care units, Acute medial
care units, Heart Lung machines, Intra-arotic balloon pumps, Catheterization equipment, Infusion
pumps, angioplasty equipment, blood gas and electrolyte analyzers, blood bank facilities etc.
6. Specialist Qualifications. - (i) The Specialist for providing cardiology
services should have M.D. D.M (Cardiology) degree from a university or
equivalent from a local recognised body OR diploma from Diplomate of
National Board or local recognised bodies or university or equivalent from a
local recognized body.
(ii)The Specialist to provide C.T Surgery should have M.S, M.Ch (C T Surgery) degree from a
university or equivalent from a local recognised body OR diploma from Diplomate of National
Board or local recognised bodies or university or equivalent from a local recognized body.
7. Urology and Nephrology care facilities. - The facilities offering these
services should have full fledged Operation theatre facilities, Intensive care
units, Full-fledged Dialysis units with dialysis machines and Complete renal
replacement therapy machines (CRRT), Renal lab with facilities for Renal
function tests, well set clinical lab support, and radiology and imaging
support.
(i)The Specialist for providing Urology services should have M.S. D.Ch (Urology) degree from a
university or equivalent from a local recognised body OR diploma from Diplomate of National
Board or local recognised bodies or university or equivalent from a local recognized body.(ii)The
Specialist to provide Nephrology care should have M.D., D.M (Nephrology) degree from a university
or equivalent from a local recognised body OR diploma from Diplomate of National board or localAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

recognised bodies or university or equivalent from a local recognized body.
8. Neurology and Neuro-surgery. - The neurology treatment facilities should
have EEG machines, evoked potentials, C.T and MRI facilities, in addition to
the hi-end diagnostic facilities, the hospitals to have operation theatres,
Intensive care units, and Micro-Surgical Instrument sets.
(i)The Specialist for providing Neurology services should have M.D. D.M (Neurology) degree from a
university or equivalent from a local recognised body OR diploma from Diplomate of National board
or local recognised bodies or university or equivalent from a local recognized body.(ii)The Specialist
to provide Neuro Surgery should have M.S, M.Ch (Neurosurgery) degree from a university or
equivalent from a local recognised body OR diploma from Diplomate of National board or local
recognised bodies or university or equivalent from a local recognized body.
9. Neonatology and Paediatric Surgery facilities. - A hospital or nursing home
offering Neonatology and Pediatric surgery services should have the
following facilities: -
(a)Basic O.T Equipment: - Basic resuscitation equipment, Nebuliser, Incubators, Phototherapy
units, Open Care system, Infusion pumps, CPAP and Ventilator facilities, O.T Table, O.T Light,
Suction Apparatus, Cysto-scope, Rigid bronchoscope, Oesophagal dialators, and padiatric
sigmoidoscope and Special Intensive Care Unit(b)Support Equipment: - Lab facilities for
investigations(i)The Specialist for providing Neonatology services should have M.D. D.M
(Neonatology) degree from a university or equivalent from a local recognised body OR diploma from
Diplomate of National Board or local recognised bodies or university or equivalent from a local
recognized body.(ii)The specialist offering Paediatric Surgery services should have M.S. M.Ch
(Paediatric Surgery) degree from a university or equivalent from a local recognised body OR
diploma from Diplomate of National Board or local recognised bodies or university or equivalent
from a local recognized body.
10. Plastic Surgery facilities. - A hospital or nursing home offering Plastic
surgery services should have the following facilities: -
(a)Basic O.T Equipment: Basic O.T equipment such as O.T Table, O.T Light, Suction Apparatus, and
Anaesthesia machine etc.(b)Other Equipment: - Operating Microscope, Skin grafting machines,
Skin cutters and whole range of microsurgery instrumentation.(c)Support Equipment: - Lab
facilities for investigationsSpecialist Qualifications. - The Specialist should have M.S. M.Ch (Plastic
Surgery) degree from a university or equivalent from a local recognised body OR diploma from
Diplomate of National Board or local recognised bodies or university or equivalent from a lodal
recognized body.Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

11. Chest Diseases and Respiratory Medicine. - A Hospital or a facility
offering treatment for the chest diseases and respiratory medicine should
have the following facilities: -
(a)Peak flow meters, Nebulizers, Intercostal drainage facility, Plueral biopsy needles, pulse
oximeters, Fibre optic bronchoscopes and rigid bronchoscopes, Pulmonary function test machine
with facility for spirometry, lung volume and diffusion capacity and Blood gas machine and O.T
support with Ventilator.(b)Support Equipment:- Lab facilities for investigationsSpecialist
Qualifications. - The Specialist should have M.D. (Chest Physician) degree from a university or
equivalent from a local recognised body OR diploma from Diplomate of National Board or local
recognised bodies or university or equivalent from a local recognized body.
12. Gastroenterology and Surgical Gastroenterology care facilities. - The
facilities offering these services should have full fledged Operation theatre
facilities, Intensive care units, Full-fledged Endoscopy equipment, well set
clinical lab support, and radiology and imaging support. The Endoscopy
equipment include Upper G.I Endoscope, Colono Scope, Surgical Endoscope
etc.
(i)The Specialist for providing Gastroenterology services should have M.D D.M (Gastroenterology)
degree from a university or equivalent from a local recognised body OR diploma from Diplomate of
National Board or local recognised bodies or university or equivalent from a local recognized
body.(ii)The Specialist to provide Surgical Gastroenterology care should have M.S., M.Ch
(Gastroenterology) degree from a university or equivalent from a local recognised body OR diploma
from Diplomate of National Board or local recognised bodies or university or equivalent from a local
recognized body.Check List of Part - II of Appendix-IISurgical: Standard Services Recommended for
each Level
SI.
No.Condition/
ProcedureBasicLevel
ServicesSpecialist Care ServicesSuper Speciality
Services
1. Basic techniquesIncisionand
Drainage Wound
debridementsSplitskin graft Biopsy of skin  
2.Trauma and Life
SupportResuscitate,stabilise
and referBasiclevel care + Securing airway;
circulatory support, stabilisationof
fractures, Investigate and manage,
Follow-upSevere head injuries
and injuries of
spinal cord
3. EyeRemovalof
foreign bodiesManagementof corneal abrasion,
ulcer, cataract and glaucoma surgeryCorneal grafting
Retinal diseases
Vitreous surgery
Intra-ocularforeign
bodiesAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

4.Ear Nose and
ThroatRemovalof
foreign bodies
Epistaxis controlIand D of peri tonsillar and retro
pharyngeal abscesses,tonsillectomy,
Laryngoscopic
removal of FB and
drainage ofmastoid
abscess All requiring
microsurgery
5. ChestResuscitateand
referBasicServices + stabilise and refer
mediastinal Injuries
Tracheostomy,ThoracocentensisMediastinal Injuries
and tumours. Heart
and lungsurgery
6. Gastrointestinal N/A Allsurgical proceduresAbdominal
malignancies.
Hepatic surgery
7. GenitourinaryAcuteurinary
retention,
hydrocoele,
circumcision and.
vasectomyBasicLevel Services + urethral
dilition, management of
rupturedbladder and urethra,
Urolithiasis and prostatectomyGU malignancies
8. MuscloskeletalClosedreduction
of uncomplicated
fractures, POP,
tractionOpenreduction of fractures Spinal
fractures Joint reconstructionSpinal fractures,
Joint
reconstructions.
Part III – Obligations of The Private Medical Care
Establishments.
Any establishment of medical care delivery system would need to be based on a universally accepted
set of core values, such as compassion, concern for the strict adherence to ethical norms and an
unflinching commitment to patients well being, and the following guiding principles:* Accountable
to the health and well being of the community it serves;* Responsible to the patient who receives
treatment and care in dignity, fairness, without discrimination and in consonance with the basic
tenets of a patients charter;* Accessible at all times and at all facilities - that is, none being denied
care on grounds of time, distance or place of residence;* Participatory-provide leadership in
bringing about behaviour change for adoption of healthy lifestyles and practises that promote
well-being and good health values; and* Recognising the special value of mother, children and
senior citizens in society.
1. Obligations of The Medical Care. - First and fore most obligation of any
private medical care establishment is to actively participate in the
implementation of all National and State Health programs in such manner as
the state Government may specify from time to time; and to furnish
periodical reports thereon to the concerned authorities. Every establishment
should accept its share of responsibility for achieving the health goals.Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Every Medical Care Establishment shall:(i)Administer necessary first aid and take other life saving
or establishing emergency measures in all medico legal or potentially medico-legal cases such as
victims of road accidents, accidental or induced burns or poisoning or criminal assaults and the like
which patient themselves at the establishment.(ii)Ensure proper comprehensive treatment and
provide with postoperative treatment precautions to the discharged Patient - Dos and Dont's(iii)If
the doctor is not qualified for a particular speciality but the hospital has the facilities to manage the
case, the patient should be admitted and the concerned consultant called for. The doctor should
start treatment by the time the consultant arrives.(iv)If the doctor is qualified for a particular
speciality but the hospital does not have the facilities, and also when there are inadequate facilities
and the doctor is not qualified to handle the case then the patient should be shifted to another
hospital where facilities are available.(v)Maintain proper medical records in the forms prescribed in
Appendix-I to VI; perform statutory duties in respect of communicable diseases to prevent the
spread of the disease to other persons and report the same to the concerned public health
authorities immediately(vi)Establishment shall be under obligation to inform the details of charges
to be levied and any miscellaneous amounts charged shall not exceed 5% of the total bill.
2. Responsibilities Towards a Patient. - Every patient should be treated with
care, compassion, respect and dignity without any discrimination. The
hospital staff should explain the health condition to the patients and their
responsible attenders and obtain their written consent. The following
information need to be made available to the patient:
(a)Credentials of the Doctors (Training and qualification) to be made available to Patients.(b)Skill
and experience of the doctors treating patient should be informed to the patients.(c)List of Facilities,
Equipment, and treatment protocols to be followed to be given to the patient(d)Ethical practises to
be followed in respect of patients right for information
3. Obligation Towards Their Own Staff and Staff Training. - The Staff training
is another important obligation of a hospital. The staff training apart from the
regular technical aspects should include:
(a)All the medical staff should follow the Medical Council of India regulations on Professional
conduct, Etiquette and Ethics.(b)To maintain the honour and sanctity of the profession(c)To
discharge their duties honestly, sincerely and humanly(d)They should be told of the vital need for
absolute asepsis in the medical care establishment(e)They should also discharge their duties
towards the society by educating the patients and their attenders about the importance of
cleanliness, breast-feeding, Immunization and family planning
Part IV – Engineering And Environmental StandardsAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

1. Ceilings. - The finishes of all exposed ceiling and structure in areas
normally occupied by patients or staff, and those in food preparation or food
storage areas shall be readily cleanable with routine housekeeping
equipment. Ceiling and walls in operating and delivery rooms shall be free of
fissures, open joints, or crevices that may retain on permit passing or dirt
particles. Ceiling should be R.C.C.
2. Floor and walls. - The architectural finishes in hospital shall be of high
quality in view of maintenance of good hygienic conditions. All wards should
have dado to height of 1.2m. The walls should be impervious with oil paint.
Floors should be covered with good quality mosaic tiles in the minimum. The
aim being that floor materials shall be readily cleanable and appropriately
wear-resistant. In all areas subject to the cleaning, floor materials shall not
be physically affected by liquid germicidal and cleaning solution. Floors
should be smooth so as to allow smooth passage of wheelchairs and
trolleys.
Wall finishes shall be washable and, in the proximity of plumbing fixtures, shall be smooth and
moisture resistant. Wall bases in areas that are frequently subject to wet cleaning shall be covered
with the floor; tightly sealed within the wall; and constructed without voids.Floor and wall areas
penetrated by pipes, ducts, and conduits shall be tightly sealed to minimise entity of rodents and
insects. Joints of structural elements shall be similarly sealed.Operating rooms/Labour
room/Delivery room should be made dust proof and moisture-proof. Corners and junctions of walls,
floors and ceiling should be rounded to prevent accumulation of dust and to facilitate cleaning.
Walls of operation theatre, delivery room, recovery room scrub room should be fully covered with
dado tiles. In other areas of critical zone, tiling should be provided up to a height of 1.2 m
3. Water supply, Plumbing and other piping system. - Arrangement shall be
made to supply 350 litre of potable water per day, per bed to meet all
requirements (including laundry), except fire fighting storage capacity for
two days requirement should be made on the basis of above consumption.
System should be designed to supply water at sufficient pressure to operate
all fixtures and equipment during maximum demand. Separate reserve
emergency overhead tank shall be provided for operation theatre.
Hot water supply to wards and departments of the general hospital shall be provided by means of
electric storage type water hearts or centralised hot water system of capacity depending upon the
need of hot water consumption.Filtered and soft water supply is needed in pathology laboratories
and shall be supplied as required. Cold water supply is needed for processing tanks in film
development room and shall be supplied as required. Within the operation theatre there should notAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

be any drains.The material used for plumbing fixtures shall be non-absorptive and acid-resistant. In
so far as possible, drainage piping shall not be installed within the ceiling or exposed in operating
and delivery rooms, nurseries, food preparation centres, food serving facilities and other sensitive
areas. Where exposed, overhead drain piping is unavoidable, special provision shall be made to
project the space below from leakage, condensation or dust particles.
4. Fire-fighting system. - Appropriate and. efficient fire fighting systems
should be installed in every nursing home. The fire fighting equipment fitted
shall be as per Indian Standards and different types of fire fighting
equipment are available in the market for the different nature of fires.
5. Requirements for sanitary fitments in nursing homes for patients. -
A. Inpatient Wards And Nursing Units.
i. Water closets1 for every 8 beds or part thereof (Male) 1 for every 6 beds
orpart thereof (female)
ii. Ablution taps1 for each water closet plus one water tap with
drainingarrangement in the vicinity of water closets.
iii. Urinals 1 for every 12 beds or pat thereof (males only)
iv. Wash basin 1 for every 12 beds or part thereof
v. Baths 1 bath with shower for every 12 beds or part thereof
vi Bed pan washing sinks 1 for each ward in dirty utility and sluice room
vii Cleaners sinks and sink/slab for
cleaning mackintosh1 for each ward
B. Outpatient Block. - For the OPD Block separate toilets are to be provided for the use of males and
females. The same toilets may be used by the staff also. The pathology department must maintain a
separate toilet. The radiology department must have following special toilet facilities in case it
carries out procedures like IVP.
 For Males For females
i. Water
closes1for every 40 persons or part thereof2 for every 50 or part thereof with draining
arrangements watercloset and urinals per
ii. Ablution
taps1in each water closet + 1 water tap shall
be provided in thevicinity of lavatory
block. 
iii. Urinals 1for every 25 persons or part thereof  
iv. Wash
basin1for every 50 persons or part thereof  Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

6. Bio Medical Waste Management. - All private medical care establishments
shall follow the Bio Medical, Waste (Management and Handling) Rules, 1998
or as may be amended/notified under the Environment Protection Act, of
1986. The medical care establishment shall discourage the use of plastics.
Safe Environment and infection control measures may be taken for the safety
of all employees. It is the duty of the Medical Care establishment owners to
ensure that the biomedical waste is handled without any adverse effect to
human health and environment.
All the biomedical waste shall be treated and disposed of in compliance to the rules mentioned
above. The establishment shall maintain records related to generation, collection, reception, storage,
transportation, disposal and/or any form of handling of biomedical wastes in accordance with the
rules issued.Depending up on the size of the nursing home or hospital and the management plan
adopted by the facility appropriate final disposal options to be engaged i.e., either by contracting out
the disposal to Common Waste Facility operator or disposal through in-house mechanism.
7. Bio-safety Guidelines. - (1) Entry into any Laboratory and other critical
work areas should be restricted.
(2)Staff should be provided with aprons for working in the laboratory and restricted zones.(3)Work
surfaces should be disinfected when procedures are completed and at the end of each working day,
(o. 1% Hypochlorite solutions is effective for the same)(4)Gloves should be worn for all
manipulations of infectious material. In operation theaters and delivery rooms, cleaning must be
carried out every day. Cleaning with carbolic acid/ phenol has to be carried out every week and
swabs should be sent to laboratory for cultures. Fumigation must be done in case cultures turn out
positive. All horizontal surfaces including floor should be mopped between cases.(5)All Medical
instruments should be soaked for 30 minutes in chemical disinfectant before cleaning. This will give
further protection to the personnel from exposure to HIV during the process of cleaning. The best
form of disinfection is autoclaving. After this comes boiling for 20 minutes.Appendix-III(See Rule 9
(a))(Minimum list of services for which rates are to be displayed)
Name of the Service Type of ServiceCharges
(in Rs.)
Room Charges:(Includes Room/Bed Charges, Nursing
charges Medical utilitiesCharges)General Ward  
 Private rooms:  
 Semi Deluxe - Shared  
 Deluxe with A/C  
Intensive Care Units :(Charges incudes the ICU Bed
Charges Medical Utilities,Monitoring and Nursing
charges)MICU and ICU  Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

 Neuro  
 POW  
 Neonatal ICU  
 Pediatric ICU  
OT Charges   
General Anaesthesia 1/2 hour General Ward  
 Twin/Triple Sharing  
General Anaesthesia 1 hour General Ward  
 Twin/Triple Sharing  
Local Anaesthesia 1/2 hour  
 1 hour  
Surgical Procedure Charges (Package):(Includes
Surgeons charges + Aesthetics charges + Nursing
Homecharges and Inpatient medicines Charges)General Surgical ProceduresOb
and Gy. proceduresOrthopedic
Surgical procedures 
 Cardiac Surgical procedures  
Doctors consultation Charges : OPOther super Speciality improved
procedures 
IP Per Visit  
Emergency Visits Per Visit  
Emergency care Team charges 3 shifts per day  
Diagnostic ChargesCommon diagnostic Tests X-ray per
filmUltra sound, General and Obstetric careAbdomen  
 Female Pelvic  
 KUB  
CT Scan: Brain Plain  
Multi slice/Spiral/CT ScanChest/Abdomen/Neck/ Spine
others 
 Contract  
MRI 0.5/1/1.5 Brain Plain  
(Magnetic Reasonance Imaging)Chest/Abdomen/ Neck/ Spine
others 
ECG/TMT/ECHO/EMG/EEG Contrast  
Upper GI Endoscopy/Lower GI Endoscopy   
Lab Investigations:   
Random Blood Sugar   
Blood Urea   
Serum Creatinine   
CBP/ESR/CUE   Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Blood Group   
Blood for MP   
LFT   
Lipid Profile   
HBSAG/VDRL/HIV   
Electrolytes   
T3, T4, TSH   
Note: - Other Service Charges for Inpatients such as
Drug s andDisposables, investigations and
Concessions, if any shall bedisplayed at appropriate
places for the benefit of the patient.
Appendix: IV(See rule NO. 14)Medical Records
The various medical records to be
maintained by the MedicalCare
Establishments:
(1) Out Patient Data
(2) Inpatient register
(3) Operation theatre register
(4) Labour room register
(5) MTP register
(6) Case sheet
(7) Case sheet for procedure
(8) Case sheet for F.P
(9) Medico - legal certificate in duplicate
(10) Medico - legal register
(11) Laboratory register
(12) Radiology and Imaging register
(13) Discharge summary
(14) Medical certificate in duplicateNotifiable to such medical officers as authorized by
Governmentin such format as prescribed by
Government/State Level
(15) Birth Register
(16) Death Register
(17) Notified diseases Information
(a)Cerebro-spinal fever,(b)Chicken-
pox,(c)Cholera,(d)Diphteria,(e)Leprosy,(f)Measles,(g)Plague,(h)Rabbies,(i)Scarlet
fever,(U)Small-pox,(k)Typhus, or(l)T.B(m)HIV - AIDSAny other disease, which the Government
may from time to time by notification declare to be a notified disease for the purposes.Formats For
Certain Important Medical Records. - This is a very important legal obligation of a hospital which isAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

neglected most often. It is obligatory for all hospitals to maintain the records of every patient
utilising the services of the hospital. One of the easiest methods of maintaining records is as
follows:(a)Maintain a In-Patient Register with the following columns: -
I.P. No. Pt. Name Age Address Date of Admission Date of Discharge Final Diagnosis Bill No
        
(b)The case sheet is the most important document. It should include admission notes, consent,
investigation reports, progress notes of any procedures conducted, condition at time of discharge
and the discharge advice. It is important to record all the happenings during the Patients stay in the
hospital and the consultants, duty doctors and nurses should write notes in the case sheet every time
they visit the patients. The case sheets after the patients discharge should be preserved
carefully.(c)The outpatients Register is another important document which is very often neglected.
An out-patient Register with following columns should be maintained.
Sl.No. Name Age Address Date Diagnosis Advice
       
Today the medical profession is under the constant threat of litigation and it is essential that all
medical records are maintained properly as they form the only evidence which come to the rescue of
a doctor in the court of Law.Consent Form. - As mentioned earlier obtaining written and informed
consent is an important obligation of every medical practitioner. A model of the consent form is
given here:
Patient Name Age Sex Date L.P. No.
     
The following aspects have been explained to us in our spoken language. -(a)The patient is suffering
from ..........and needs............(b)The risk of the above procedure is very high / moderate / regular.
There is a possibility that the patient may move into a higher risk category during the course of
treatment.(c)The possibility of allergic reactions to drugs, I.V. fluids and blood.(d)The possibility of
cardiac arrest, cardiac arrhythmia's, hypotension, Renal Failure, cerebro-vascular accidents,
Respiratory failure and other such severe complications occurring during the course of treatment,
aesthesia, surgery' or post-operative periods.(e)Some of these complications may need prolonged
hospitalization and some are even fatal.We in our full senses having understood all the above
aspects to our satisfaction give our unreserved consent for treatment, blood transfusion, Aesthesia,
surgery, diagnostic procedure or any other medical procedure that may be required for the
patient.The hospital, its staff, Anaesthetist, Surgeon or consultants shall not be held responsible in
case of any adverse outcome during the course of treatment or latter.
Signature: Relationship to Patient:
Name: 2.
Witness  
Appendix - VReporting Format for Laboratory Surveillance (Form L2)(To be filled by in charge of
Laboratories at District level and Private Laborataries)
State Andhra Pradesh District: Block...................... Year 2006
Name ofDoctor/Office-in charge Designation Name of the Reporting Unit (Centre, Hospital)
  
{|Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

ID.No./Unique Identifier
 
 
|
Reporting From {|
 
|
 
|
 
|-| week| to|
 
|
 
|
 
|}|}
Target Disease  InvestigationNo. of Tests
Done 
 Male Female Total
<5yr > 5yr Total < 5Yr > 5Yr Total  
Malaria P.Falciparum P/s for MPRapid TestP/S for MP        
 P. vivax Rapid Test        
Tuberculosis  Sputum for AFB        
Cholera  Stool Culture        
Typhoid  Sidal test        
  Blood Culture        
  Stool Cuture        
  Typhi dot test        
Hepatitis B Rapid Test        
 C Tapid Test        
Dengue  Rapid Strip Test (could be done)        
Leptospirosis  Rapid Dot Test        
HIV  Rapid Test        
Others (Specify)  Elisa        
Date:SignatureAppendix - IVReporting Format for Presumptive Surveillance (Form P)(To be filled
by Medical Officer at PHC/CHC, Government/Non-Government/Private Hospitals, Private
Prectitioners)
State: Andhra Pradesh District: Block.............Year: 2006Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

Name of Doctor:Designation: DM. &
H.O.Name of the Reporting UnitD.M&H.OOffice,
Krishna,Machilipatnam
ID
NO./Uniqueldentifier Report From {|
 
|-||| Week|
 
|}
   To   
acdef ghijklmn
 Case  Deaths
Male Female Total Male Female Total
<5yr >5yr Total <5Yr >5Yr Total <5yr >5yr Total <5yr >5yr Total  
1. Fever
Fever < 7 daysSuspect
Cases
1. Only Fever
2. With Rash
3. With Bleeding
4. With Daze/Semi
consciousness/Unconsciousness/
Fever > 7 days
 Probable
Cases
Measles
Dengue (Epi linked cases)
lapanese Encephalitis
(Epi linked cases)
Typhoid
2. Cough with or without fever
Case of CoughProbable
Cases
< 3 weeks - ARI        
< 3 weeks        
3. Loose Watery Stools of Less
than 2 WeeksDuration
Cases of watery stools of < 2
weeksSuspect
Cases
With Some/Much Dehydration        Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

With no Dehydration        
With Blood in Stool        
 Probable
Cases
Epidemiological linked cases of
Cholera 
4. Jaundice cases of less Than 4
WeeksDuration
Cases of Acute JaundiceSuspect
Cases
        Probable
Cases
Epidemiological Linked        
Cases of Hepatitis A/E        
5. Acute Flacid Paralysis Cases in
Less Than15 Years of Age
Cases of Acute Flacid ParalysisSuspect
Cases
        Probable
Cases
Epidemiological liked cases of
Polio       
6. Unusual Symptoms Leading to
Death orHospitalization not
Conforming to the
AboveSyndromes
Cases of unusual symptoms
leading to death orhospitalization
not
conforming to the above
syndromesSuspect
Cases
        Probable
Cases
Write clinical diagnosis        
Note: Information related to State Specific Diseases (if any) may be added.Date:SignatureForm
I(See rule 4 (a))Application for Registration of Andhra Pradesh Allopathic Private Medical Care
Establishments(to be submitted in Duplicate)Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

1. Name and address of the Allopathic Private Medical Care Establishment
2. Name of Correspondent or any Authorised person for correspondence.
3. Name and Address of the Society/Trust and date on which it was
established: -
4. Whether the accommodation is owned by the Establishment or on
lease/rent. If so, please furnish the period of lease/rent along with the
documentary proof. (Please Enclose the relevant copies)
5. The date of establishment of Medical care establishment
6. Total area of Establishment: (One set of photographs of the premises with
its functional areas to be furnished) (a) Open area b) Constructed area
7. Bed strength
8. Types of Services offered (1) Basic (2) Speciality
 (3) Super Speciality
 (4) Diagnostics
9. Names of Doctors, along with Registration Number Allotted by MCI/APMC
(Please Enclose the details)
10. Names of qualified Nursing Staff, with their of Registration numbers of
NCI/any other board (Please Enclose the details)
11. Names of Para Medical Staff and their Registration numbers (list to be
enclosed)
12. No. of Supporting staff (list to be enclosed)
13. No. of Specialities available (Please Enclose the details)
14. The List of Equipment and Furniture available (Please Enclose the details)
15. Labour room with Paediatric care facilitiesAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

16. Operation theatres
17. Diagnostic Facilities including Clinical Laboratory and Imaging facilities
18. Whether registration is sought for main facility, or branches also, if so
details (separate application shall be submitted for each branch)
19. The financial position of the Hospital/Institute (enclose Audit Report of
the last two years)
20. Any other information relating to Hospital
21. Declaration on Stamp Paper for willingness to comply Yes/No with the
prescribed rules is enclosed
22. Particulars of the Registration fee paid (D.D No., Name f the Bank, and
Date)
I hereby declare that the information furnished above is true to the best of my knowledge and belief
and if it is found that any wrong information is furnished or suppressed the arterial facts, I will take
full responsibility for the consequential action as per law.Place:Dated:(Signature)(Name and
Designation and full address with official seal.)Form II(See rule 4 (d))AcknowledgementThe
application in Form 1 in duplicate for grant/renewal of registration of Allopathic Private Medical
Care Establishment submitted by .......................(Name and address of applicant) has been received
by the Registration Authority .................On.............(date).* The list of enclosures attached to the
application in Form I has been verified with the enclosures submitted and found to be
correct.Or*On verification it is found that the following documents mentioned in the list of
enclosures are not actually enclosed.i.ii.iiii.iv.v.This Acknowledgement does not confer any rights on
the applicant for grant or renewal of registration.(..............................)Signature and Designation of
Registration Authority, or authorized person in the Office of the Appropriate
Authority.Date:Place:SealForm III(See Rule 4 (F))Government of Andhra PradeshHealth Medical
and Family Welfare DepartmentDistrict Registering AuthorityCertificate of Temporary Registration
of Allopathic Private Medical Care Establishments(Valid for 90 days from the date of issue)
1. Application No. and Date:
2. File number of Registration Authority
3. Date of issue:Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

4. Valid till:
5. This is to Certify that M/s.................. located at.....................is hereby
registered temporarily under the provisions of A.P. Allopathic Private Medical
Care Establishments Registration and Regulation) Act, 2002, to provide
following medical care services:
i..............................:.........ii.......................................
6. This temporary registration shall be in force for a period of ninety (90) days
from the date of issue and after which date it cease to valid.
7. This Certificate of temporary Registration is subject to the conditions and
provisions of the A.P Allopathic Private Medical Care Establishments
Registration and Regulat ion Act 2002.
8. This Establishment shall comply with the provisions of A.P. Allopathic
Private Medical Care Establishments Registration and Regulation) Act, 2002)
as amended from time to time and the rules made there under.
9. This Certificate shall be surrendered to the above Registering authority on
the following date of expiry of (90) days.
10. The establishment shall not rent, lend, sell, transfer or otherwise close
down the registered Medical Care Establishment without obtaining prior
permission of the regulatory authority.
Signature of the(Office seal)Form IV(See Rule 5 (A))Government of Andhra Pradesh Health Medical
and Family Welfare DepartmentDistrict Registering AuthorityCertificate of Registration of
Allopathic Private Medical Care Establishments
1. Application No. and Date:
2. Inspection Report No. and Date:
3. File number of Registration AuthorityAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

4. Date of issue:
5. valid up in---------
6. This is to Certify that M/s-------------located at----------------is hereby registered
under the provisions of A.P. Allopathic Private Medical Care Establishments
Registration and Regulation) Act. 2002, to provide following medical care
services:
i. - - -----------ii.-------------
7. This registration shall be in force for a period of 5 (Five) years from the
date of issue.
8. This Certificate shall be produced whenever it is required to the officer
authorised by the Registration authority.
9. The Establishment shall not rent, lend, sell, transfer or otherwise close
down the without obtaining prior permission of the registration authority.
10. Any unauthorized change in personnel, equipment or working conditions
is as mentioned in the application by the Establishment shall constitute a
breach of registration.
11. The Establishment shall not violate the provisions of A.P. Allopathic
Private Medical Care Establishments Registration and Regulation) Act. 2002)
as amended from time to time and the rules made there under.
12. This certificate is subject to the conditions and the provisions of the A.P.
Allopathic Private Medical Care Establishments Registration and Regulation)
Act. 2002.
Signature and name of the District Registering Authority.................District(Office seal)Form - V(See
Rule 5 (C))Government of Andhra PradeshHealth Medical and Family Welfare DepartmentDistrict
Registering Authority............................................................Rejection of Application For
Grant/renewal of RegistrationReference Number and Date:In exercise of the powers conferred
under Section 7 (3) of the Andhra Pradesh Allopathic Private Medical Care Establishments
(Registration and Regulation) Act, 2005. the Registration Authority. Hereby rejects the application
for grant/ renewal of registration submitted by the under-mentioned Private Medical Care
Establishment.Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

(1) Name and address of the Allopathic Private Medical CareEstablishment(2) Reasons for
rejection of application for grant / renewal ofregistration 
Signature, name and designation of the Registration Authority with office seal.* Strike out
whichever is not applicable or necessaryForm - VI(See Rule-6)Application for Renewal of Certificate
of RegistrationToThe Registering AuthoritySir,I request to renew the Certificate of Registration
issued in respect of M/ s.......................for a period of 5 (five) years for which I furnish the following
particulars:(1)Date of issue of Certificate of Registration to be renewed (enclosed the original
Certificate in duplicate)(2)Date of Expiry of Certificate of Registration to be renewed.(3)File number
of the Registering Authority(4)Particulars of Renewal fee paid (D.D.No., Name of the Bank, and
date) (Original D.D. enclosed)(5)I hereby declare that the contents mentioned in this application are
true and correct to the best of the my knowledgePlace:Dated:(Signature)(Name, Designation and
full address with office seal.)Form VII(See Rale 6)Government of Andhra PradeshHealth Medical
and Family Welfare DepartmentDistrict Registering Authority...........................Certificate of
Renewal of Registration of Allopathic Private Medical Care Establishments
1. Application No. and Date-------------
2. Original File number of Registration authority-----------
3. Date of issue of the Certificate of Registration--------------
4. Date of expiry of the Certificate of Registration---------
5. Date of renewal of the Certificate of Registration------------
6. Renewal of Certificate of Registration valid up to-----------------
7. This is to Certify that the Certificate of Registration issued to
M/s-----------------located at----------------is hereby renewed under the provisions of A.P. Allopathic
Private Medical Care Establishments Registration and Regulation) Act, 2002. to provide following
medical care services:i.----------------ii. --------------
8. This Renewal oi Certificate of Registration shall be in force for a period of
5 (Five) years from the date of issue.
9. This Certificate shall be produced whenever it is required to the officer
authorised by the Registration authority,Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

10. The' Establishment shall not rent, lend, sell, transfer or otherwise close
down the without obtaining prior permission of the registration authority.
11. Any unauthorized change in personnel, equipment or working conditions
as mentioned in the application by the Establishment shall constitute a
breach of registration.
12. The Establishment shall not violate the provisions of A.P. Allopathic
Private Medical Care Establishments Registration and Regulation) Act, 2002)
as amended from time to time and the rules made there under.
13. This Certificate is subject to the conditions and the provisions of the A.P
Allopathic Private Medical Care Establishments Registration and Regulation)
Act, 2002.)
Signature and Name of the District Registering Authority(Office deal)Form - VIII(See Rule
7(b)Government of Andhra PradeshHealth Medical and Family Welfare DepartmentDistrict
Registering AuthorityNoticeReference No and date:-----------------ToM/s--------------I hereby give
notice that information and evidence have been placed before the Authority by which the
complainant makes the following charge against you viz., ----------------------- _
----------------------------------------------------------------------------------------.And that in relation
there to have been guilty of infamous conduct in a professional respect.Orthat you were convicted on
the day of at-----------------for the following offence viz.You are hereby required to attend before the
undersigned at-------------on----------before the undersigned to answer in writing to the above
charges to establish any denial or defense along with papers and documents in your possession
relevant to the matter and any person (s) whose evidence you wish to lay before the
undersigned.Your answer which you may desire to make relating to the above mentioned charges or
your defense there to must be addressed to the under signed and transmitted so as to reach him not
less than six days before the day appointed for hearing of the ease.You are entitled to be represented
before the undersigned by a Authorised Person or legal Practitioner and the same must be informed
in written to the undersigned at least six days before the hearing.It is imperative that you should
surrender your certificate of registration to the undersigned before or on the date of hearing.You are
hereby further informed that ii you do not attend as required above, the undersigned will proceed
with the material available with him and decide the matter in your absence.Signature and name of
the District Registering Authority(Office seal)Form IX(See Rule 7 (d))Government of Andhra
PradeshHealth Medical and Family Welfare DepartmentDistrict Registering
AuthorityOrder(1)Reference Number and Date:-------------(2)Registered notice number and
date-------------------(3)File Number of Registering Authority-------------(4)Date of
hearing---------------------(5)Whether Establishment has submitted answer in
writing................................. Yes/No(6)If so, what are the contents and documentary evidence
produced by the Applicant-Establishment(7)Are they
satisfactory.........................Yes/No(8)Additional document (s) submitted by the Complaint, ifAndhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

any------------(9)Are they relevant to case.........................Yes/No(10)Point(s) for consideration in the
case------------(11)Findings of the District Registering Authority-------In exercise of the powers
conferred under Section 9 (1) of the Andhra Pradesh Allopathic Private Medical Care
Establishments (Registration and Regulation) Act, 2005, and also alter perusal of the documentary
evidence produced, the Registration Authority hereby.Cancel the certificate of registration/renewal
of certificate of registration Establishment.Orrevoke the suspension of certificate of
registration/renewal of certificate of registration EstablishmentSignature and name of the District
Registering Authority(Office seal)Form-X(See Rule 8(b))Application for Filing an Appeal Against
the Orders of Registration AuthorityToChairman.Appellate Board and Principal Secretary to
Government,Health, Medical and Family Welfare Department.A.P. Secretariat Hyderabad-22Appeal
filed under Section 10 (1) of the A.P. Private Medical Care Establishment (R and R) Act, 2002
1. Name and address of the appellant:
2. Number, date of the order and address of the authority which passed the
order against which appeal is being made (certified copy of the order to be
attached):
3. Prayer / relief sought in the Appeal
4. Grounds on which the appeal is made:
5. Interim Relief/Prayer, if any sought
6. List of enclosures (other than the order referred in item 2 above)
7. Particulars of the D.D. (number, date and bank) enclosed
8. Declaration that the contents mentioned in appeal are true and correct to
the best of the knowledge of the appellant
Signature and Name(Address of the Allopathic Private Medical Care
Establishment)Place:Date:Form-XI(See Rule-8(e))Government of Andhra PradeshHealth Medical
and Family Welfare DepartmentState Appellate Board, HyderabadOrder
1. Appeal Number and Date:-------------------
2. Registered notice number and date fixing hearing-------------Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

3. File Number of Registering Authority------------------
4. Date of hearing of appeal --------------------------------------------------------------
5. What are the contents and documentary evidence produced bv the
Appellant Establishment
6. Are they relevant and satisfactory................Yes/No
7. Additional document (s) submitted by the Compliant, if any
8. Are they relevant to the Appeal.......................Yes/No
9. Issues framed/Point(s) for consideration in the appeal
10. Findings of the Appellate Board
11. Wheatear any interim order is considered Yes/No
In exercise of the powers conferred under Section 10(1) of the Andhra Pradesh Allopathic Private
Medical Care Establishments (Registration and Regulation) Act. 2002, and after perusal of the order
of the district Registering Authority, hearing the arguments and the documentary' evidence
producer be State Appellate Board hereby Allow the appeal and direct the District Registering
Authority to issue/renewal o certificate of registration Establishment.OrDismiss the appeal and
confirm the order of the District Registering Authority.Signature and name of the Chairman State
Appellate and Principal Secretary to Government.(Office seal)Andhra Pradesh Allopathic Private Medical Care Establishments (Registration and Regulation) Rules, 2007

