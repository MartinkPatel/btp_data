B.K. Pavitra vs Union Of India on 10 May, 2019
Equivalent citations: AIR 2019 SUPREME COURT 2723, AIRONLINE 2019 SC
275, 2019 LAB IC 4074, 2019 (4) AKR 258, (2019) 2 ESC 495, (2019) 2 SERVLJ
198, (2019) 4 KANT LJ 1, 2019 (4) KCCR SN 280 (SC), (2019) 8 SCALE 205,
2019 (9) ADJ 56 NOC, AIR 2019 SC (CIV) 2067
Author: D.Y. Chandrachud
Bench: Dhananjaya Y Chandrachud, Uday Umesh Lalit
                                                                             Reportable
                                  IN THE SUPREME COURT OF INDIA
                         CIVIL APPELLATE/INHERENT/ORIGINAL JURISDICTION
                                        M A No. 1151 of 2018
                                                  In
                                    Civil Appeal No. 2368 of 2011
          B K Pavitra and Ors                                         ...Appellants
                                               Versus
          The Union of India and Ors                                 ...Respondents
                                                With
                              Review Petition (c) Diary No. 7833 of 2017
                                                WithB.K. Pavitra vs Union Of India on 10 May, 2019

                              Review Petition (c) Diary No.10240 of 2017
Signature Not Verified
                                                With
Digitally signed by
CHETAN KUMAR
Date: 2019.05.10
12:09:20 IST
Reason:
                              Review Petition (c) Diary No.10258 of 2017
                                                With
                                                  1
Review Petition (c) Diary No.10859 of 2017
                   With
Review Petition (c) Diary No.12622 of 2017
                   With
Review Petition (c) Diary No.12674 of 2017
                   With
Review Petition (c) Diary No.13047 of 2017
                   With
Review Petition (c) Diary No.14563 of 2017
                   With
Review Petition (c) Diary No.16896 of 2017
                   With
          M A No. 1152 of 2018
                    In
      Civil Appeal No. 2369 of 2011
                   With
     Writ Petition (c) No. 764 of 2018
                   With
     Writ Petition (c) No. 769 of 2018B.K. Pavitra vs Union Of India on 10 May, 2019

                   With
                     2
  Writ Petition No.791 of 2018
              With
Writ Petition (c) No.823 of 2018
              With
Writ Petition (c) No. 827 of 2018
              With
Writ Petition (c) No. 850 of 2018
              With
Writ Petition (c) No.875 of 2018
              With
Writ Petition (c) No. 872 of 2018
              With
Writ Petition (c) No. 901 of 2018
              With
Writ Petition (c) No. 879 of 2018
              And
              With
Writ Petition (c) No. 1209 of 2018B.K. Pavitra vs Union Of India on 10 May, 2019

                3
                                JUDGMENT
Dr Dhananjaya Y Chandrachud, J.
This judgment has been divided into sections to facilitate analysis. They are A The constitutional
challenge B The constitutional backdrop to reservations in Karnataka C Submissions C.I Petitioners
C.2 Submissions for the respondents and intervenors D Assent to the Bill E Does the Reservation
Act 2018 overrule or nullify B K Pavitra I E.I Is the basis of B K Pavitra I cured in enacting the
Reservation Act E.2 The Ratna Prabha Committee report F Substantive versus formal equality F.I
The Constituent Assembly‘s understanding of Article 16 (4) F.2 The Constitution as a transformative
instrument G Efficiency in administration H The issue of creamy layer I Retrospectivity J Over
representation in KPTCL and PWD K Conclusion PART A A The constitutional challenge 1 The
principal challenge in this batch of cases is to the validity of the Karnataka Extension of
Consequential Seniority to Government Servants Promoted on the Basis of Reservation (to the Posts
in the Civil Services of the State) Act 20181. The enactment provides, among other things, for
consequential seniority to persons belonging to the Scheduled Castes2 and Scheduled Tribes3
promoted under the reservation policy of the State of Karnataka. The law protects consequential
seniority from 24 April 1978.
2 The Reservation Act 2018 was preceded in time by the Karnataka Determination of Seniority of
the Government Servants Promoted on the Basis of the Reservation (to the Posts in the Civil
Services of the State) Act 20024. The constitutional validity of the Reservation Act 2002 was
challenged in B K Pavitra v Union of India5, (―B K Pavitra I). A two judge Bench of this Court
(consisting of Justice Adarsh Kumar Goel and Justice U U Lalit) held Sections 3 and 4 of the
Reservation Act 2002 to be ultra vires Articles 14 and 16 of the Constitution on the ground that an
exercise for determining ―inadequacy of representation, ―backwardness and the impact on
―overall efficiency had not preceded the enactment of the law. Such an exercise was held to be
mandated by the decision of a Constitution Bench of this Court in M Nagaraj v Union of India6
(―Nagaraj). Reservation Act 2018 SCs STs Reservation Act 2002 (2017) 4 SCC 620 (2006) 8 SCC
212 PART B In the absence of the State of Karnataka having collected quantifiable data on the above
three parameters, the Reservation Act 2002 was held to be invalid. 3 The legislature in the State of
Karnataka enacted the Reservation Act 2018 after this Court invalidated the Reservation Act 2002
in B K Pavitra I. The grievance of the petitioners is that the state legislature has virtually re-enacted
the earlier legislation without curing its defects. According to the petitioners, it is not open to a
legislative body governed by the parameters of a written constitution to override a judicial decision,
without taking away its basis. On the other hand, the State government has asserted that an exercise
for collecting ―quantifiable data was in fact carried out, consistent with the parameters required by
the decision in Nagaraj. The petitioners question both the process and the outcome of the exercise
carried out by the state for collecting quantifiable data. B The constitutional backdrop to
reservations in Karnataka 4 The present case necessitates that this Court weave through the body of
precedent which forms a part of our constitutional jurisprudence on the issue of reservations. In
many ways, the issues before the Court are unique. For, in the post Nagaraj world which governsB.K. Pavitra vs Union Of India on 10 May, 2019

this body of law, the State government defends its legislation on the ground that it has fulfilled the
constitutional requirement of collecting quantifiable data before it enacted the law. If such an
exercise has been carried out, the Court will need to address itself to the standard of judicial review
by a constitutional court of a legislation enacted by a competent legislature. The extent to which a
data collection exercise by the PART B government, which precedes the enactment of the law, may
be reviewed by the Court is a seminal issue. B K Pavitra I involved a situation where this Court
invalidated a law on the ground that no exercise of data collection was carried out by the State of
Karnataka. In the present batch of cases, (herein referred to as B K Pavitra II), there is a
constitutional challenge to the validity of a law enacted after the State had undertaken the exercise
of collecting quantifiable data. Whether that exercise of data collection and the enactment of the
new law which has emerged on its foundation takes away the basis of or the cause for the
invalidation of the Reservation Act 2002 in B K Pavitra I is an essential question for our
consideration.
In this background, we set out the significant facts, in the chequered history of the present case.
5 In exercise of the power conferred by the proviso to Article 309 of the Constitution, the Governor
of Karnataka framed the Karnataka Government Servant (Seniority Rules) 19577. Rules 2 and 4
provide for seniority on the basis of the period of service in a given cadre. There was no specific rule
governing seniority in respect of roster promotions.
Rule 2 inter alia, provides as follows:
―2. Subject to the provisions hereinafter contained the seniority of a person in a
particular cadre of service or class of post shall be determined as follows:-
(a) Officers appointed substantively in clear vacancies shall be senior to all persons
appointed on officiating or any other basis in the same cadre of service or class of
post;
The Rules 1957 PART B
(b) The seniority inter se of officers who are confirmed shall be determined according to dates of
confirmation, but where the date of confirmation of any two officers is the same, their relative
seniority will be determined by their seniority inter se while officiating in the same post and if not,
by their seniority inter se in the lower grade.
(c) Seniority inter se of persons appointed on temporary basis will be determined by the dates of
their continuous officiation in that grade and where the period of officiation is the same the
seniority inter se in the lower grade shall prevail. Rule 4 provides for the determination of seniority
where promotions are made at the same time on the basis of seniority-cum-merit to a class of posts
or cadre:B.K. Pavitra vs Union Of India on 10 May, 2019

―4. When promotions to a class of post or cadre are made on the basis of
seniority-cum-merit at the same time, the relative seniority shall be determined.-
(i) if promotions are made from any one cadre or class of post, by their seniority inter
se in the lower cadre or class of post;
(ii) if promotions are made from several cadres or classes of posts of the same grade,
by the period of service in those grades;
(iii) if promotions are made from several cadres or classes of posts, the grades of
which are not the same, by the order in which the candidates are arranged by the
authority making the promotion, in consultation with Public Service Commission
where such consultation is necessary, taking into consideration the order in which
promotions are to be made from those several cadres or classes of post. Rule 4-A
provides for the determination of the seniority where promotion is made by selection:
―4-A When promotions to a class of post or cadre are made by selection at the same
time either from several cadres or classes of post or from same cadre or class of post
by the order in which the candidates are arranged in order of merit by the Appointing
Authority making the selection, in consultation with Public Service Commission
where such consultation is necessary.
PART B [Explanation – For purposes of this rule, ―several cadres or classes of post
shall be deemed to include cadres or classes of post of different grades from which
recruitment is made in any specified order of priority in accordance with any special
rules of recruitment.].
6 Reservation for persons belonging to SCs and STs in specified categories of promotional posts was
introduced by a Government Order8 dated 27 April 1978 of the Government of Karnataka.
Reservation in promotional posts for SCs was set at 15 per cent and for STs at 3 per cent in all cadres
up to and inclusive of the lowest category of Class I posts in which there is no element of direct
recruitment or where the direct recruitment does not exceed 662/3 per cent. A 33 point roster was
applicable to each cadre of posts under appointing authorities. Inter-se seniority amongst persons
promoted on any occasion was to be determined in accordance with Rules 4 and 4-A, as the case
may be, of the Rules 1957. It also stipulated that vacancies would not be carried forward. 7 On 1 June
1978, the State government issued an Official Memorandum9 providing guidelines and clarifications
for implementing the Government Order dated 27 April 1978. The Official Memorandum stipulated
that after promotion, seniority among candidates promoted on the basis of seniority-cum-merit
shall, on each occasion, be fixed in accordance with Rule 4 of the Rules 1957. In other words,
seniority would be governed by the inter se seniority in the cadre from which candidates were
promoted. For candidates promoted by selection, seniority would be governed by Rule 4-A : the
ranking would be as assigned in PART B the list of selected candidates by the appointing authority.
The Official Memorandum dated 1 June 1978 thus provided, what can be described as the principle
of consequential seniority to reserved category candidates. 8 By a notification10 dated 1 April 1992,B.K. Pavitra vs Union Of India on 10 May, 2019

a proviso was inserted to Rule 8 of the Karnataka Civil Services (General Recruitment) Rules 197711
which provided that vacancies not filled by SCs and STs would be treated as a backlog and would be
made good in the future. This provision was upheld by a two judge Bench of this Court in Bhakta
Ramegowda v State of Karnataka12 (―Bhakta Ramegowda).
9 On 16 November 1992, a nine judge Bench of this Court delivered judgment in Indra Sawhney v
Union of India13 (―Indra Sawhney). The issue as to whether reservations of promotional posts
were contemplated by Article 16 (4)14 - when it used the expression ‗appointment‘ was among the
issues dealt with. Justice B P Jeevan Reddy speaking for a plurality of four judges held that:
(i) Reservations contemplated by Article 16 (4) of the Constitution should not exceed
50 per cent15. While 50 per cent shall be the rule, ―it is necessary not to put out of
consideration certain extraordinary situations inherent in The Rules 1977 (1997) 2
SCC 661 1992 Supp (3) SCC 217 Clauses (1) and (4) of Article 16 provide:
(1) There shall be equality of opportunity for all citizens in matters relating to
employment or appointment to any office under the State.
… (4) Nothing in this article shall prevent the State from making any provision for the
reservation of appointments or posts in favour of any backward class of citizens
which, in the opinion of the State, is not adequately represented in the services under
the State.
Supra 13, paragraph 809 at page 735 PART B the great diversity of this country and the people 16.
But, any relaxation of the strict rule must be with extreme caution and on a special case being made
out17;
(ii) Reservations under Article 16 (4) could only be provided at the time of entry into government
service but not in matters of promotion. However, this principle would operate only prospectively
and not affect promotions already made. Moreover, reservations already provided in promotions
shall continue in operation for a period of five years from the date of the judgment18;
(iii) The creamy layer can be and must be excluded. Justice B P Jeevan Reddy held :
―792…While we agree that clause (4) aims at group backwardness, we feel that
exclusion of such socially advanced members will make the ‗class‘ a truly backward
class and would more appropriately serve the purpose and object of clause (4). (This
discussion is confined to Other Backward Classes only and has no relevance in the
case of Scheduled Tribes and Scheduled Castes).19
(iv) The adequacy of the representation of a backward class of citizens in services ―is
a matter within the subjective satisfaction of the State 20, since the requirement in
Article 16 (4) is preceded by the words ―in the opinion of the State. The basis of the
standard of judicial review was formulated thus:B.K. Pavitra vs Union Of India on 10 May, 2019

―798…This opinion can be formed by the State on its own, i.e., on the basis of the
material it has in its possession already or it may gather such material through a
Commission/Committee, person or authority. All that is Ibid, paragraph 810 at page
735 Ibid, paragraph 810 at page 735 Ibid, paragraphs 827, 829, 859 (7) and 860(8) at
pages 745, 747, 768 and 771 Ibid at page 725 Ibid, paragraph 798 at page 728 PART B
required is, there must be some material upon which the opinion is formed. Indeed,
in this matter the court should show due deference to the opinion of the State, which
in the present context means the executive. The executive is supposed to know the
existing conditions in the society, drawn as it is from among the representatives of
the people in Parliament/Legislature. It does not, however, mean that the opinion
formed is beyond judicial scrutiny altogether. The scope and reach of judicial scrutiny
in matters within subjective satisfaction of the executive are well and extensively
stated in Barium Chemicals v. Company Law Board [1966 Supp SCR 311 : AIR 1967
SC 295] which need not be repeated here. Suffice it to mention that the said
principles apply equally in the case of a constitutional provision like Article 16(4)
which expressly places the particular fact (inadequate representation) within the
subjective judgment of the State/executive.21
(v) The backward class of citizens cannot be identified only and exclusively with
reference to an economic criterion22. It is permissible to identify a backward class of
citizens with reference to occupation, income as well caste.
10 In view of the decision of this Court in Indra Sawhney, the provisions for reservation in matters
of promotion under the Government Order of 1978, as clarified by the Official Memorandum dated 1
June 1978 were saved for a period of five years from 16 November 1992. Promotions already made
were saved. 11 On 17 June 1995, Parliament acting in its constituent capacity adopted the
seventy-seventh amendment by which clause (4A) was inserted into Article 16 to enable reservations
to be made in promotion in favour of the SCs and STs23. The Ibid at page 728 Ibid, paragraph 799
at page 728 Clause 16 (4A) : Nothing in this article shall prevent the State from making any
provision for reservation in matters of promotion to any class or classes of posts in the services
under the State in favour of the Scheduled PART B amendment came into force on 17 June 1995,
before the expiry of five years from 16 November 1992 (the date on which the decision in Indra
Sawhney was pronounced). As a result of the decision in Indra Sawhney and the seventy- seventh
amendment to the Constitution, the provision for reservations made by the Government of
Karnataka under the Government Order of 1978 stood saved and continued to operate.
12 On 10 February 1995, a Constitution Bench of this Court rendered a judgment in R K Sabharwal v
State of Punjab24 (―Sabharwal) and held that:
(i) Once the prescribed percentage of posts is filled by reserved category candidates
by the operation of the roster, the numerical test of adequacy is satisfied and the
roster would cease to operate25;B.K. Pavitra vs Union Of India on 10 May, 2019

(ii) The percentage of reservation has to be worked out in relation to the number of
posts which form the cadre strength. The concept of vacancy has no relevance in
operating the percentage of reservation26; and
(iii) The interpretation placed on the working of the roster shall operate
prospectively27 from 10 February 1995.
13 On 1 October 1995, a two judge Bench of this Court held in Union of India v Virpal Singh
Chauhan28 (―Virpal Singh) that the state could provide that even if a candidate belonging to the
SC or ST is promoted earlier on the basis of Castes and the Scheduled Tribes which, in the opinion of
the State, are not adequately represented in the services under the State.
(1995) 2 SCC 745 Ibid, paragraph 5 at page 750 Ibid, paragraph 6 at page 751 Ibid, paragraph 11 at
page753 (1995) 6 SCC 684 PART B reservation and on the application of the roster, this would
entitle such a person to seniority over a senior belonging to the general category in the feeder cadre.
However, a senior belonging to the general category who is promoted to a higher post subsequently
would regain seniority over the reserved candidate who was promoted earlier. This rule came to be
known as the catch-up rule. The two judge Bench directed that the above principle would be
followed with effect from the date in the judgment in Sabharwal29.
14 Six months after the decision in Virpal Singh, on 1 March 1996, a three judge Bench of this Court
in Ajit Singh Januja v State of Punjab30 (―Ajit Singh I), adopted the catch-up rule propounded in
Virpal Singh, to the effect that the seniority between reserved category candidates and general
candidates in the promoted category shall continue to be governed by their inter se seniority in the
lower grades. This Court held that a balance has to be maintained so as to avoid ―reverse
discrimination and, a rule or circular which gives seniority to a candidate belonging to the reserved
category promoted on the basis of roster points would violate Articles 14 and 16 of the Constitution.
15 On 24 June 1997, the Government of Karnataka issued a Government Order31 formulating
guidelines in regard to the manner in which backlog vacancies were required to be filled. On 3
February 1999, the Government of 10 February 1995 (1996) 2 SCC 715 PART B Karnataka issued
another Government Order32 pursuant to Article 16 (4A) stipulating a modified policy of
reservation in matters of promotion. The 1999 Order provides for reservation in promotion to the
extent of 15 per cent for SCs and 3 per cent for STs of the posts in a cadre up to and inclusive of the
lowest category of group A posts in each service for which there is no element of direct recruitment
or, where the proportionate of direct recruitment does not exceed 662/3 per cent. While providing
for the continuance of reservations in promotion, the Government Order stipulated that reservation
in favour of persons belonging to the SCs shall continue to operate until their representation in a
cadre reaches 15 per cent. Reservations in promotion for the STs would continue to operate until
their representation in a cadre reaches 3 per cent. Thereafter, reservation in promotion shall
continue only to maintain the representation to the extent of the above percentages for the
respective categories. On 13 April 1999, the Government of Karnataka issued another Government
Order33 modifying the 1999 Order to provide that reservations in promotions in favour of the SCs
and STs shall continue to operate by applying the existing roster to the vacancies till theB.K. Pavitra vs Union Of India on 10 May, 2019

representation of persons belonging to these categories reached 15 per cent or 3 per cent as the case
may be, respectively. Moreover, after the existing backlog was cleared, the representation of persons
belonging to SCs and STs would be maintained to the extent of 15 per cent and 3 per cent of the total
working strength.
Ibid PART B 16 In Jagdish Lal v State of Haryana34, (―Jagdish Lal) a three judge Bench of this
Court took a view contrary to the decision in Ajit Singh I. The decision in Jagdish Lal held that by
virtue of the principle of continuous officiation, a candidate belonging to a reserved category who is
promoted earlier than a general category candidate due to an accelerated promotion would not lose
seniority in the higher cadre. This conflict of decisions was resolved by a Constitution Bench in Ajit
Singh v State of Punjab35 (―Ajit Singh II). The Constitution Bench held that Article 16 (4A) is only
an enabling provision for reservation in promotion. In consequence, roster point promotees
belonging to the reserved categories could not count their seniority in the promoted category from
the date of continuance officiation in the promoted post in relation to general category candidates
who were senior to them in the lower category and who were promoted later. Where a senior general
candidate at the lower level is promoted later than a reserved category candidate, but before the
further promotion of the latter, such a person will have to be treated as senior at the promotional
level in relation to the reserved candidate who was promoted earlier. The Constitution Bench
accordingly applied the catch-up rule for determining the seniority of roster point promotees
vis-à-vis general category candidates. The Court held that any circular, order or rule that was issued
to confer seniority to roster point promotees would be invalid. However, the Constitution Bench
directed that candidates who were promoted contrary to the above principles of law before 1 March
1999 (the date of the decision in Ajit Singh I) need not be reverted.
(1997) 6 SCC 538 (1999) 7 SCC 209 PART B 17 Contending that there was no provision permitting
seniority to be granted in respect of roster point promotees belonging to the reserved categories, the
reservation policy of the State of Karnataka came to be challenged before this Court in M G
Badappanavar v State of Karnataka36 (―Badappanavar). A three judge Bench, relying on the
decisions in Ajit Singh I, Ajit Singh II and Sabharwal reiterated the principle that Article 16 (4A)
does not permit the conferment of seniority to roster point promotees. This Court held that there
was no specific rule in the State of Karnataka permitting seniority to be counted in respect of a
roster promotion. It held thus:
―12…The roster promotions were, it was held, meant only for the limited purpose of
due representation of backward classes at various levels of service. If the rules are to
be interpreted in a manner conferring seniority to the roster-point promotees, who
have not gone through the normal channel where basic seniority or selection process
is involved, then the rules, it was held will be ultra vires Article 14 and Article 16 of
the Constitution of India. Article 16(4-A) cannot also help. Such seniority, if given,
would amount to treating unequals equally, rather, more than equals.37
18 The conferment of seniority to roster point promotees of the reserved categories would, in view of
the court in Badappanavar, violate the equality principle which was part of the basic structure of the
Constitution. The Court directed that the seniority lists and promotions be reviewed in accordanceB.K. Pavitra vs Union Of India on 10 May, 2019

with its directions but those who were promoted before 1 March 1996 on principles contrary to Ajit
Singh II and those who were promoted contrary to Sabharwal before 10 February 1995 need not be
reverted.
(2001) 2 SCC 666 Ibid at page 672 PART B 19 The Constitution (Eighty-fifth Amendment) Act 2001
was enacted with effect from 17 June 1995. Article 16 (4A), as amended, reads thus:
―Nothing in this article shall prevent the State from making any provision for
reservation in matters of promotion, with consequential seniority, to any class or
classes of posts in the services under the State in favour of the Scheduled Castes and
the Scheduled Tribes which, in the opinion of the State, are not adequately
represented in the services under the State. (Emphasis supplied) The purpose of the
amendment was to enable the grant of consequential seniority to reserved categories
promotees. The significance of the date on which the eighty-fifth amendment came
into force – 17 June 1995 – is that it coincides with the coming into force of the
seventy-seventh amendment which enabled reservations in promotions to be made
for the SCs and STs.
20 In 2002, the Karnataka State Legislature enacted the Reservation Act 2002. The law came into
force on 17 June 1995. It provided for consequential seniority to roster point promotees based on the
length of service in a cadre, making the catch-up rule propounded in Ajit Singh II inapplicable. The
earlier decision of this Court in Badappanavar had held that there was no specific rule for the
conferment of seniority to roster point promotees. By the enactment of the Reservation Act 2002
with effect from 17 June 1995, the principle of consequential seniority was statutorily incorporated
as a legislative mandate. 21 The validity of the seventy-seventh and eighty-fifth amendments to the
Constitution and of the legislation enacted in pursuance of those amendments PART B was
challenged before a Constitution Bench of this Court in Nagaraj. The Constitution Bench analysed
whether the replacement of the catch-up rule with consequential seniority violated the basic
structure and equality principle under the Constitution. Upholding the constitutional validity of the
amendments, this Court held that the catch-up rule and consequential seniority are judicially
evolved concepts based on service jurisprudence. Hence, the exercise of the enabling power under
Article 16 (4A) was held not to violate the basic features of the Constitution:
―79. Reading the above judgments, we are of the view that the concept of ―catch-up
rule and ―consequential seniority are judicially evolved concepts to control the
extent of reservation. The source of these concepts is in service jurisprudence. These
concepts cannot be elevated to the status of an axiom like secularism, constitutional
sovereignty, etc. It cannot be said that by insertion of the concept of ―consequential
seniority the structure of Article 16(1) stands destroyed or abrogated. It cannot be
said that ―equality code under Articles 14, 15 and 16 is violated by deletion of the
―catch-up rule. These concepts are based on practices. However, such practices
cannot be elevated to the status of a constitutional principle so as to be beyond the
amending power of Parliament. Principles of service jurisprudence are different from
constitutional limitations. Therefore, in our view neither the ―catch-up rule nor theB.K. Pavitra vs Union Of India on 10 May, 2019

concept of ―consequential seniority is implicit in clauses (1) and (4) of Article 16 as
correctly held in Virpal Singh Chauhan.38
22 The Constitution Bench held that Article 16 (4A) is an enabling provision. The state is not bound
to make reservations for the SCs and STs in promotions. But, if it seeks to do so, it must collect
quantifiable data on three facets:
(i)        The backwardness of the class;
     Supra 6 at page 259
                                                                                        PART B
(ii)       The inadequacy of the representation of that class in public employment;
           and
(iii)      The general efficiency of service as mandated by Article 335 would not be
           effected.
23         The principles governing this approach emerge from the following extracts
from the decision:
―107. …If the State has quantifiable data to show backwardness and inadequacy then the State can
make reservations in promotions keeping in mind maintenance of efficiency which is held to be a
constitutional limitation on the discretion of the State in making reservation as indicated by Article
335. As stated above, the concepts of efficiency, backwardness, inadequacy of representation are
required to be identified and measured…39 … 117… in each case the Court has got to be satisfied that
the State has exercised its opinion in making reservations in promotions for SCs and STs and for
which the State concerned will have to place before the Court the requisite quantifiable data in each
case and satisfy the Court that such reservations became necessary on account of inadequacy of
representation of SCs/STs in a particular class or classes of posts without affecting general efficiency
of service as mandated under Article 335 of the Constitution.40 …
123. … In this regard the State concerned will have to show in each case the existence of the
compelling reasons, namely, backwardness, inadequacy of representation and overall administrative
efficiency before making provision for reservation. As stated above, the impugned provision is an
enabling provision. The State is not bound to make reservation for SCs/STs in matters ofB.K. Pavitra vs Union Of India on 10 May, 2019

promotions. However, if they wish to exercise their discretion and make such provision, the State
has to collect quantifiable data showing backwardness of the class and inadequacy of representation
Ibid at pages 270-271 Ibid at pages 276-277 PART B of that class in public employment in addition
to compliance with Article 335. It is made clear that even if the State has compelling reasons, as
stated above, the State will have to see that its reservation provision does not lead to excessiveness
so as to breach the ceiling limit of 50% or obliterate the creamy layer or extend the reservation
indefinitely.41 The Constitution Bench held that the constitutional amendments do not abrogate
the fundamentals of equality:
―110…the boundaries of the width of the power, namely, the ceiling limit of 50% (the
numerical benchmark), the principle of creamy layer, the compelling reasons,
namely, backwardness, inadequacy of representation and the overall administrative
efficiency are not obliterated by the impugned amendments. At the appropriate time,
we have to consider the law as enacted by various States providing for reservation if
challenged. At that time we have to see whether limitations on the exercise of power
are violated. The State is free to exercise its discretion of providing for reservation
subject to limitation, namely, that there must exist compelling reasons of
backwardness, inadequacy of representation in a class of post(s) keeping in mind the
overall administrative efficiency. It is made clear that even if the State has reasons to
make reservation, as stated above, if the impugned law violates any of the above
substantive limits on the width of the power the same would be liable to be set
aside.42 These observations emphasise the parameters which must be applied
where a law has been enacted to give effect to the provisions of Article 16 (4A). The
legislative power of the state to enact such a law is preserved. The exercise of the
power to legislate is conditioned by the existence of ―compelling reasons namely;
the existence of backwardness, the inadequacy of representation and overall
administrative efficiency. Elsewhere in the decision, the Constitution Bench treated
these three parameters as ―controlling factors for making Ibid at page 278 Ibid at
page 272 PART B reservations in promotions for SCs and STs. They were held to be
constitutional requirements crucial to the preservation of ―the structure of equality of
opportunity in Article 16. The Constitution Bench left the validity of the individual
enactments of the states to be adjudicated upon separately by Benches of this Court.
24 In B K Pavitra I, a two judge Bench of this Court considered a challenge to the
Reservation Act 2002 providing for consequential seniority on the ground that the
exercise which was required to be carried out in Nagaraj had not been undertaken by
the State and there was no provision for the exclusion of the creamy layer. The
validity of the Reservation Act 2002 had been upheld by a Division Bench of the
Karnataka High Court. In B K Pavitra I, this Court struck down Sections 3 and 4 of
the Reservation Act 2002 as ultra vires Articles 14 and
16. The petitioner contended that the law laid down by this Court in Badappanavar,
Ajit Singh II and Virpal Singh remained applicable despite the Constitution
(Eighty-fifth Amendment) Act 2001. Moreover, it was contended that theB.K. Pavitra vs Union Of India on 10 May, 2019

Government of Karnataka had not complied with the tests laid down in Nagaraj and
had failed to provide any material or data to show inadequacy of representation.
Moreover, no consideration was given to the issue of overall administrative efficiency.
The principal challenge was that an exercise for determining ―backwardness,
―inadequacy of representation, and ―overall efficiency in terms of the decision in
Nagaraj had not been carried out.
PART B 25 Relying on the decisions of this Court in Suraj Bhan Meena v State of Rajasthan43, Uttar
Pradesh Power Corporation Ltd v Rajesh Kumar44 and S Panneer Selvam v State of Tamil Nadu45
(―Panneer Selvam), a two judge Bench of this Court affirmed that the exercise laid down in
Nagaraj for determining ―inadequacy of representation, ―backwardness and ―overall efficiency
is necessary for recourse to the enabling power under Article 16 (4A) of the Constitution. The Court
held that the Government of Karnataka had failed to place material on record showing that there
was a compelling necessity for the exercise of the power under Article 16 (4A). Hence, the directions
laid down by this Court in Nagaraj were not followed. Striking down Sections 3 and 4 of the
Reservation Act 2002, this Court held thus:
―29. It is clear from the above discussion in S. Panneer Selvam case that exercise for
determining ―inadequacy of representation, ―backwardness and ―overall
efficiency, is a must for exercise of power under Article 16(4-A). Mere fact that there
is no proportionate representation in promotional posts for the population of SCs
and STs is not by itself enough to grant consequential seniority to promotees who are
otherwise junior and thereby denying seniority to those who are given promotion
later on account of reservation policy. It is for the State to place material on record
that there was compelling necessity for exercise of such power and decision of the
State was based on material including the study that overall efficiency is not
compromised. In the present case, no such exercise has been undertaken. The High
Court erroneously observed that it was for the petitioners to plead and prove that the
overall efficiency was adversely affected by giving consequential seniority to junior
persons who got promotion on account of reservation. Plea that persons promoted at
the same time were allowed to retain their seniority in the lower cadre is untenable
and ignores the fact that a senior person may be promoted later and not at the same
time on account of roster point reservation. Depriving him of his seniority affects his
further chances of promotion. Further plea that seniority was not a fundamental right
is (2011) 1 SCC 467 (2012) 7 SCC 1 (2015) 10 SCC 292 PART B equally without any
merit in the present context. In absence of exercise under Article 16(4-A), it is the
―catch-up rule which fully applies. It is not necessary to go into the question
whether the Corporation concerned had adopted the rule of consequential
seniority.46 The Court clarified that the decision will not affect those who have
already retired and availed of financial benefits. It was further directed that
promotions granted to existing employees based on consequential seniority are liable
to be reviewed and that the seniority list be revised in terms of the decision. Three
months were granted to take further consequential action. Petitions seeking a review
of the decision have been tagged with the present proceedings.B.K. Pavitra vs Union Of India on 10 May, 2019

26 After the decision of this Court in B K Pavitra I, on 22 March 2017, the Government of Karnataka
constituted the Ratna Prabha Committee47 headed by the Additional Chief Secretary to the State of
Karnataka to submit a report on the backwardness and inadequacy of representation of SCs and STs
in the State Civil Services and the impact of reservation on overall administrative efficiency in the
State of Karnataka. The tasks entrusted to the Committee were to:
―1) Collect information on the cadre-wise representation of Scheduled Castes and
Scheduled Tribes in all the Government Departments;
2) Collect information regarding backwardness of Scheduled Castes and Scheduled
Tribes; and
3) Study the effect on the administration due to the provision of reservation in
promotion to the Scheduled Castes and Scheduled Tribes. Supra 6 at page 641 G.O.
No. DPAR 182 SeneNi 2011 PART B
27 On 5 May 2017, the Ratna Prabha Committee submitted a report, titled as the ‗Report on
Backwardness, Inadequacy of Representation and Administrative Efficiency in Karnataka‘48. The
Government of Karnataka, through its Department of Personnel and Administrative Reforms,
submitted the Ratna Prabha Committee report to the Law Commission of Karnataka on 8 June
2017. The Law Commission sought to opine on ‗whether the data collected and reasons assigned by
the Ratna Prabha Committee constitute a valid basis for validating the law‘ and submitted its report
on 27 July 2017. 28 In the meantime, the petitioners filed contempt petitions contending that the
directions of this Court in B K Pavitra I to the State of Karnataka to review the seniority list were not
complied with. The State of Karnataka filed applications for extension of time for compliance. On 20
March 2018, this Court disposed of the petitions rejecting the applications for extension of time for
compliance with the decision in B K Pavitra I and granted one month time to take any consequential
action. The State of Karnataka subsequently filed compliance affidavits before this Court stating that
the exercise directed by the decision in B K Pavitra I had been carried out.
29 On the basis of the Ratna Prabha Committee report, the Government of Karnataka introduced
the Karnataka Extension of Consequential Seniority to Government Servants Promoted on the Basis
of Reservation (to the Posts in the Civil Services of the State) Bill 2017. The Bill was passed by the
Legislative Ratna Prabha Committee report PART B Assembly on 17 November 2017 and by the
Legislative Council on 23 November 2017. On 16 December 2017, the Governor of the Karnataka
reserved the Bill for the consideration of the President of India under Article 200 of the
Constitution. The Bill received the assent of the President on 14 June 2018 and was published in the
official Gazette on 23 June 2018.
30 Sections 3, 4 and 5 of the Reservation Act 2018 provides as follows :
―3. Determination of Seniority of the Government Servants Promoted on the basis of
Reservation.- Notwithstanding anything contained in any other law for the time
being in force, the Government Servants belonging to the Scheduled Castes and theB.K. Pavitra vs Union Of India on 10 May, 2019

Scheduled Tribes promoted in accordance with the policy of reservation in promotion
provided for in the Reservation Order shall be entitled to consequential seniority.
Seniority shall be determined on the basis of the length of service in a cadre:
Provided that the seniority inter-se of the Government Servants belonging to the
Scheduled Castes and the Scheduled Tribes as well as those belonging to the
unreserved category, promoted to a cadre, at the same time by a common order, shall
be determined on the basis of their seniority inter-se, in the lower cadre.
Provided further that where the posts in a cadre, according to the rules of recruitment
applicable to them are required to be filled by promotion from two or more lower
cadres,-
(i) The number of vacancies available in the promotional (higher) cadre for each of
the lower cadres according to the rules of recruitment applicable to it shall be
calculated; and
(ii) The roster shall be applied separately to the number of vacancies so calculated in
respect of each of those lower cadres:
Provided also that the serial numbers of the roster points specified in the Reservation
Order are intended only to facilitate calculation of the number of vacancies reserved
for promotion at a time and such roster points are not intended to determine inter-se
seniority of the Government Servants belonging to the Scheduled Castes and the
Scheduled Tribes vis-a-vis the Government Servants belonging to the unreserved
category promoted at the same time and such PART B inter-se seniority shall be
determined by their seniority inter- se in the cadre from which they are promoted, as
illustrated in the Schedule appended to this Act.
4. Protection of consequential seniority already accorded from 27th April 1978
onwards.- Notwithstanding anything contained in this Act or any other law for the
time being in force, the consequential seniority already accorded to the Government
servants belonging to the Scheduled Castes and the Scheduled Tribes who were
promoted in accordance with the policy of reservation in promotion provided for in
the Reservation Order with effect from the Twenty Seventh Day of April, Nineteen
Hundred and Seventy Eight shall be valid and shall be protected and shall not be
disturbed.
5. Provision for review.- All promotions to the posts belonging to the State Civil
Services shall be within the extent and in accordance with the provisions of the
reservation orders and other rules pertaining to method of recruitment and seniority.
The Appointing Authority shall revise and redraw the existing seniority lists to ensure
that the promotions are made accordingly:B.K. Pavitra vs Union Of India on 10 May, 2019

Provided that subsequent to such a review, wherever it is found that Government
Servants belonging to the Scheduled Castes and Scheduled Tribes were promoted
against reservation and backlog vacancies in excess or contrary to extent of
reservation provided in the reservation orders shall be adjusted and fitted with
reference to the roster points in accordance with the reservation orders issued from
time to time by assigning appropriate dates of eligibility. In case, if persons belonging
to the Scheduled Castes and the Scheduled Tribes who have already been promoted
against reservation or backlog vacancies in excess or contrary to the extent of
reservation provisions cannot get adjusted and fitted against the roster points they
shall be continued against supernumerary posts, to be created by the concerned
administrative department presuming concurrence of Finance Department, in the
cadres in which they are currently working, till they get the date of eligibility for
promotion in that cadre. Section 9 provides for the validation of action taken in
respect of promotions since 27 April 1978:
―9. Validation of action taken under the provisions of this Act.- Notwithstanding
anything contained in any PART B Judgment, Decree or Order of any court, tribunal
or other authority contrary to section 3 and 4 of this Act any action taken or done in
respect of any promotions made or purporting to have been made and any action or
thing taken or done, all proceedings held and any actions purported to have been
done since 27th April, 1978 in relation to promotions as per sections 3 and 4 of this
Act, before the publication of this Act shall be deemed to be valid and effective as if
such promotions or action or thing has been made, taken or done under this Act and
accordingly:- (a) no suit or other proceedings shall be maintained or continued in any
court or any tribunal or before any authority for the review of any such promotions
contrary to the provisions of this Act; and (b) no court shall enforce any decree or
order to direct the review of any such cases contrary to the provisions of this Act.
Section 1 (2) provides that the Reservation Act 2018 came into force with effect from
17 June 1995 (the effective date of the seventy-seventh and eighty-fifth constitutional
amendments).
31 These proceedings were instituted to assail the vires of the Reservation Act 2018. The principal
contention which has been urged is that the Reservation Act 2018 does not take away basis of the
decision of this Court in B K Pavitra I and is ultra vires. All matters have been admitted for hearing
and tagged together.
32 On 27 July 2018, when the batch of cases was listed for hearing, it was suggested by this Court
that the status quo may not be altered pending consideration of the matter. The Advocate General
for the State of Karnataka orally agreed and accepted an order of status quo. The Government of
Karnataka issued a circular on 3 August 2018 with a direction to maintain status quo and not PART
B affect the process of promotion/demotion till further orders from the government. These
directions were issued to all autonomous bodies, universities, public enterprises, commissions,
corporations, boards and to institutions availing aid from the government under their
administrative control. 33 In Jarnail Singh v Lachhmi Narain Gupta49, (―Jarnail) a ConstitutionB.K. Pavitra vs Union Of India on 10 May, 2019

Bench of this Court considered whether the decision in Nagaraj requires to be referred to a larger
Bench since:
(i) It requires the state to collect quantifiable data showing backwardness of the SCs
and STs contrary to the nine judge Bench decision in Indra Sawhney;
(ii) The creamy layer principle was not applied to SCs and STs in Indra Sawhney; and
(iii) In applying the creamy layer principle, Nagaraj conflicts with the decision in E V
Chinnaiah v State of AP50 (―Chinnaiah).
34 In Jarnail, the Constitution Bench held that :
(i) The decision in Chinnaiah holds, in essence, that a state law51 cannot further
sub-divide the SCs into sub categories. Such an exercise would be violative of Article
341(2) since only an Act of Parliament and not the state legislatures can make
changes in the Presidential list. Chinnaiah did not dwell on any aspect on which the
constitutional amendments were upheld 2018 (10) SCC 396 (2005) 1 SCC 394 The
court was considering the provisions of the Andhra Pradesh Scheduled Caste
(Rationalisation of Reservations) Act 2000 PART B in Nagaraj. Hence, it was not
necessary for Nagaraj to advert to the decision in Chinnaiah. Chinnaiah dealt with a
completely different problem and not with the constitutional amendments, which
were dealt with in Nagaraj52;
(ii) The decision of the Constitution Bench in Nagaraj, insofar as it requires the state
to collect quantifiable data on backwardness in relation to the SCs and STs is contrary
to Indra Sawhney and would have to be declared to be bad on this ground53; and
(iii) Constitutional courts, when applying the principle of reservation will be within
their jurisdiction to exclude the creamy layer on a harmonious construction on
Articles 14 and 16 along with Articles 341 and 34254. The creamy layer principle is an
essential aspect of the equality code.
35 On 12 October 2018, the State of Karnataka submitted before this Court that since a legislation
has been enacted by the state legislature and in view of the judgment of the Constitution Bench in
Jarnail, the State would no longer proceed on the oral assurance of the Advocate General and would
not be bound to it. On the other hand, it was urged by learned Counsel appearing for the petitioners
that the intent of the Reservation Act 2018 was only to nullify the effect of the judgment in B K
Pavitra I. Counsel urged that in view of the decisions of this Court including those in Shri Prithvi
Cotton Mills Ltd v Broach Borough Municipality55 (―Prithvi Cotton Mills Ltd) and Madan Mohan
Pathak v Union Supra 49, paragraph 22 at page 422-423 Ibid, paragraph 24 at page 424 Ibid,
paragraph 26 at page 425-426 (1969) 2 SCC 283 PART B of India (―Madan Mohan Pathak)56, it
was not open to the legislature to render a judgment of this Court ineffective without taking away its
basis or foundation. Since the case was of an urgent nature, the proceedings were listed on 23B.K. Pavitra vs Union Of India on 10 May, 2019

October 2018 for commencement of final hearing.
36 On 27 February 2019, the State of Karnataka issued a Government Order57 directing that:
―In the circumstances explained in the preamble, the following instructions are
hereby issued subject to the conditions that the officers/officials, who have been
reverted, shall be reposted to the cadres held by them immediately prior to their
reversion and if vacant posts are not available in those cadres, supernumerary posts
shall be created to accommodate them. It is also ordered that the officers/officials
working at present in those cadres, belonging to any category, shall not be reverted.
The Government Order was made subject to the outcome of these proceedings.
On 1 March 2019, this Court granted a stay on the operation of the Government
Order dated 27 February 2019. This Court observed that since the case was in the
concluding stages of the hearing, it would not be appropriate to alter the present
status when the matter was in seisin of the Court.
     (1978) 2 SCC 50
     G.O. No. DPAR 186 SRS 2018
                                                                        PART C
C     Submissions
C.I   Petitioners
37    In adjudicating upon the challenge to the constitutional validity of the
Reservation Act 2018, we have heard the erudite submissions of Dr Rajeev Dhavan,
learned Senior Counsel appearing on behalf of the Petitioners.
Prefacing his submissions, Dr Rajeev Dhavan has adverted to the following issues which arise for the
determination of this Court:
A Is the Reservation Act 2018 valid?
(a) Does it not peremptorily overrule the decision of this Court in B K Pavitra I without altering the
basis of the decision?B.K. Pavitra vs Union Of India on 10 May, 2019

(b) Does it violate the law laid down by this Court in Badappanavar on seniority?
(c) Does the background to the enactment to the Reservation Act 2018 reveal a manifest intent to
overrule the decision in B K Pavitra I?
(d) Was the reference of the Bill by the Governor of Karnataka to the President under Article 200 of
the Constitution and the subsequent events which took place constitutionally valid? In this context,
could the Bill have been brought into force without the assent of the Governor?
PART C B Is the Reservation Act 2018 compliant with the principles enunciated in the Constitution
Bench decisions in Nagaraj and Jarnail? Does the report of the Ratna Prabha Committee dated 5
May 2017 constituted an adequate and appropriate basis to support the validity of the Act and its
implementation?
C Does the Reservation Act 2018 apply in the present writ petitions (instituted by B K Pavitra and
Shivakumar) to those departments where there is over representation or in public corporations not
covered by the Ratna Prabha report or the legislation? 38 While we will be dealing with the
submissions urged by Dr Dhavan in the course of our analysis, it would be appropriate at this stage
to advert to the salient aspects of the submissions under the following heads:
A     Usurpation of judicial power
39    Dr Dhavan has urged that the Reservation Act 2018 was enacted in a
hurry with no purpose other than to overrule the decision in B K Pavitra I, while the issue of
implementation was still pending. The decision in B K Pavitra I was rendered on 19 February 2017.
On 22 March 2017, a Government Order was issued appointing the Additional Chief Secretary to
submit a report on backwardness, inadequacy of representation and the impact of reservation on
efficiency. The report was submitted on 5 May 2017. On 26 July 2017, the report PART C was
accepted by the State Cabinet which constituted a sub-committee to examine the matter and submit
a draft Bill. The State Law Commission recommended the State to pass a legislation with
retrospective effect by curing the infirmities and factors noticed in the decision in B K Pavitra I. On
4 August 2017, the Cabinet Sub-Committee submitted its decision based on the report. On 7 August
2017, the Cabinet approved the proposed Bill. The Bill was introduced in the Karnataka State
Legislative Assembly on 14 November 2017 and was passed on 17 November 2017. The Bill was
passed by the State Legislative Council on 23 November 2017 and was submitted to the Governor on
6 December 2017. The Bill was reserved by the Governor for the consideration of the President. On
15 February 2018, 9 March 2018 and 18 April 2018, the Union Government in the Ministry of Home
Affairs sought clarifications from the State government which were provided on 16 March 2018 and
23 April 2018. The Bill received the assent of the President on 14 June 2018, and was published in
the official Gazette and came into force on 23 June 2018. 40 On the basis of the above facts, Dr
Dhavan submitted that:B.K. Pavitra vs Union Of India on 10 May, 2019

(i) There was no compelling necessity to overrule B K Pavitra I ―except political
necessities;
(ii) A comparison of the provisions of the Reservation Act 2002 with the Reservation
Act 2018 indicates that:
(a) The Reservation Act 2018 is substantively the same as the Reservation Act 2002;
PART C
(b) The change in the basis of the decision in B K Pavitra I is on the factum of the Ratna Prabha
Committee report;
(c) ―Compelling necessities are mentioned but their existence is not demonstrated;
(d) The title of the Reservation Act 2018 is limited to consequential seniority which is not mentioned
in the law;
(e) Section 5 allows for an unlimited backlog and the creation of supernumerary posts for SCs and
STs;
(f) Section 5 presumes the permission of the Finance Department and visualizes an ―excess, which
will invalidate the law; and
(g) Section 9 brazenly overrules and goes beyond the date of 17 June 1995 and postulates that in
future a review of the cases is forbidden.
B      Violation of the separation of powers
41     Separation of powers postulates a constitutional division between
legislative and judicial functions. In this context, the submission is:
(a) The legislative power is distinct from the judicial power;
(b) The legislature cannot lawfully usurp judicial power by sitting in appeal over any
judicial decision by attempting to overturn it;
(c) Any statute which seeks to overturn a judicial decision must be within the
legislative competence of the legislature under the Seventh Schedule to the
Constitution;
(d) Any such statute must change the basis of the law;B.K. Pavitra vs Union Of India on 10 May, 2019

PART C
(e) The decision of a court will always be binding unless the law or conditions underlying the
legislation which was held to be invalid are so fundamentally altered so that a different result would
enure;
(f) While a legislation may be retroactive, an interim or final direction must be obeyed especially
when rights are conferred;
(g) A new legislation can be challenged on the basis that it violates the fundamental rights; and
(h) Unless the basis of a legislation which is found to be ultra vires has been altered, the mere
enactment of a new legislation would constitute a brazen overruling of the law, which is
impermissible.
42 Dr Dhavan urges that Reservation Act 2018 will not pass muster, when it is assessed in the
context of the principles enunciated by the decisions of this Court in (i) Prithvi Cotton Mills Ltd, (ii)
Madan Mohan Pathak, (iii) S R Bhagwat v State of Mysore58, (iv) Bakhtawar Trust v M D
Narayan59, (v) Delhi Cloth & General Mills Co. Ltd v State of Rajasthan60, (vi) Re Cauvery61, (vii) S
T Sadiq v State of Kerala62 and (viii) Medical Council of India v State of Kerala63. 43 Explaining the
applicability of the above principles on facts, Dr Dhavan urged that after the decision of this Court in
B K Pavitra I, the State Government filed applications for extension of time on 9 May 2017 and 8
September 201764. (1995) 6 SCC 16 (2003) 5 SCC 298 (1996) 2 SCC 449 (1993) Supp (1) SCC 96
(2015) 4 SCC 400 (2018) 11 SCALE 141 M.A. Nos. 730-756 of 2017 PART C This Court extended time
to revise the seniority lists till 30 November 2017 and for consequential actions by 15 January 2018.
On 15 January 2018, the State Government moved before this Court seeking extension of time for
implementing the decision in B K Pavitra I. On 29 January 2018, this Court finally granted time
until 15 March 2018. On 17 March 2018, the State moved before this Court for extension of time and
on 20 March 2018, while disposing of certain contempt petitions and other applications, one
month‘s time was granted to take consequential action. On 25 April 2018, this Court directed the
State to file a further affidavit (by 1 May 2018) indicating that promotions and demotions have been
duly effected. On 9 May 2018, this Court directed the State to file an affidavit to the effect that the
judgment in B K Pavitra I had been fully complied with and the hearing was posted for 4 July 2018.
On 28 June 2018, the State of Karnataka informed this Court that the ―further process have been
stalled because of the enactment of the new legislation and its publication in the Gazette on 23 June
2018. On 7 August 2018, the State of Karnataka filed an interim application seeking permission of
this Court to implement the Reservation Act 2018. It has been urged that contrary to what was
stated by the state Government, there was no compliance of the decision in B K Pavitra I. In this
background, it has been submitted that the state has undertaken an exercise to overrule B K Pavitra
I which constitutes a clear usurpation of judicial power.B.K. Pavitra vs Union Of India on 10 May, 2019

                                                                                       PART C
C         Lack of compliance with Nagaraj and Jarnail
44        Dr Dhavan assails the report of the Ratna Prabha Committee on the
ground that is was not in compliance with Nagaraj and Jarnail. Nagaraj postulates that:
(i) The backlog should not extend beyond three years;
(ii) Excessive reservation would invalidate the exercise of power; and
(iii) There is a theory of guided power under which a failure to follow the above
conditionalities would result in reverse discrimination.
45 According to the submission, the decision in Nagaraj:
(a) Deploys the methodology that the seventy-seventh, eighty-first, eighty-
second and eighty-sixth amendments were only enabling and were valid. The conditionalities for a
valid exercise of the enabling power are two-fold:
(i) The existence of compelling reasons namely, backwardness, inadequacy of
representation and overall administrative efficiency requiring quantifiable data; and
(ii) Excessiveness, which postulates that the ceiling limit of fifty per cent is not
transgressed, the creamy layer is not obliterated and reservation is not extended
indefinitely.
(b) The methodology of Nagaraj was approved both in I R Coelho v State of TN65 and
Jarnail; and (2007) 2 SCC 1 PART C
(c) The decision in Jarnail, while upholding the methodology adopted in Nagaraj held
that there is a constitutional presumption which obviates the need for quantifiable
data on the backwardness of SCs and STs and hence that part of Nagaraj was held to
be contrary to the decision in Indra Sawhney. The application of the creamy layer test
was held to be a requirement for SCs and STs and other principles or applications
enunciated in Nagaraj were held to be valid.
46 In this background, the Ratna Prabha Committee report is assailed on the following grounds:
(i) The chapter on backwardness is not necessary;B.K. Pavitra vs Union Of India on 10 May, 2019

(ii) Inadequacy of representation is examined over 30 pages;
(iii) The data collected is over 32 years in thirty one government departments;
(iv)     No data exists in 1986;
(v)      The data indicates that STs are adequately represented from 1999 to 2015
         but the average of 31 years is 2.70;
(vi)     No data has been collected from public sector undertakings, boards,
corporations, local bodies, grant-in-aid institutions, among others, and it is assumed
that the data is representative in nature;
(vii) The representation in Public Works Department (―PWD) and Karnataka Power
Transport Corporation Limited (―KPTCL) is adequate;
(viii) The data collected is with respect to the availability of vacancies and not posts,
contrary to the requirements laid out in Sabharwals case;
PART C
(ix) The data is on sanctioned posts and not posts which have been filled;
(x) The data is not cadre based but based on grades A, B, C and D even though Jarnail requires the
data to be on the basis of cadre;
(xi) The report erroneously assumed that grades A, B, C and D correspond to cadres;
(xii) The report candidly admits that ―in some departments, corporations like PWD and KPTCL
there may be over representation of the percentage mandated;
(xiii) On administrative efficiency:
(a) The data is based on general considerations such as economic development;
(b) The efficiencies adverted to in matters of administrative, policy and service are
general; and
(c) Reliance which has been placed is on performance reports.
(xiv) The state has followed a strange method of back door entry by filling up
vacancies not by selection but through toppers from universities in various
departments for gazetted grade A and B posts.B.K. Pavitra vs Union Of India on 10 May, 2019

D        Reservation of the Bill to the President
47       Dr Dhavan urged that from the counter affidavit filed by the State
Government, it is evident that:
(i)      The view of the State government was that given the legislative
competence of the state legislature, the ―Bill was not required to be reserved for the
assent of the President;
PART C
(ii) On 6 December 2017, the Governor of Karnataka considered it appropriate to refer the Bill to the
President in view of the decision in B K Pavitra I and the ―importance of the issue and the
constitutional interpretation involved in the matter under Article 200;
(iv) The State government on the Bill being forwarded to the President continued to maintain that
the Bill neither attracted the second proviso to Article 200 nor did it deal with a matter which was
repugnant to a Union law on an entry falling in List III of the Seventh Schedule. Hence, the State
government opined that there did not appear to be any situation warranting the reservation of the
Bill for the consideration of the President. Hence, it has been urged that it may be:
(a) The reference by the Governor on 6 December 2017 to the President simply stated
that since a constitutional interpretation was required, the Bill was reserved for the
President; however no specific issues were referred; and
(b) The State government forwarded the Bill to the President, recording at the same
time that there was no reason to refer.
(v) The Union Government invited reasons for the reference to which responses were
made by the State Government in its clarification;
(vi) The Governor was altogether by-passed in this process; and
(vii) The Governor has the exclusive authority under Article 200 on the reference and
must formulate a specific reference, which was not done.
The Central Government, it was urged, cannot create a reference which has not been made by the
state.
PART C 48 In order to buttress his submissions, Dr Dhavan relied upon the decisions in
Kaiser-I-Hind Pvt Ltd v National Textile Corporation Ltd66, Gram Panchayat of Village Jamalpur vB.K. Pavitra vs Union Of India on 10 May, 2019

Malwinder Singh67 (―Gram Panchayat of Village Jamalpur), Hoechst Pharmaceuticals Ltd v State
of Bihar68 (―Hoechst Pharmaceuticals Ltd) and Nabam Rebia and Bamang Felix v Deputy Speaker
Arunachal Pradesh Legislative Assembly 69 (―Nabam Rebia).
Dr Dhavan urged that:
(i) There was no valid reference by the Governor in the absence of specificity on the
matter of reference;
(ii) The State government consistently indicated that there was no reason to refer the
Bill to the President;
(iii) The Union Government could not have created a reference where none existed;
and
(iv) The reference was unconstitutional and the assent of the Governor was not
obtained.
E Seniority including consequential seniority 49 The submissions of Dr Dhavan are:
(i) Seniority is determined by the Seniority Rules 1957;
(2002) 8 SCC 182 (1985) 3 SCC 661 (1983) 4 SCC 45 (2016) 8 SSC 1 PART C
(ii) The decision in Badappanavar held that there was no specific rule providing for
consequential seniority in the Seniority Rules 1957;
(iii) The amendments in the Seniority Rules 1957 on 18 August 2006 did not effect
any change to unsettle the decision in Badappanavar;
(iv) The Reservation Act 2002 attempted to overrule Badappanavar and was
eventually invalidated in B K Pavitra I;
(v) The Reservation Act 2018 mentions consequential seniority in its title yet Section
5 makes no reference of it and in fact reinforces the Seniority Rules 1957 by
implication. The reference to the Rules in Section 5 can only be in the context of the
Seniority Rules 1957 as amended. The Seniority Rules 1957 will override the
administrative orders of 27 April 1978;
(vi) The Government Order dated 27 April 1978 specifically adverts to Rules 4 or 4-A
(as the case may be) of the Seniority Rules 1957;
(vii) No seniority can be conveyed by filling up of backlog and creating excess or
supernumerary posts; andB.K. Pavitra vs Union Of India on 10 May, 2019

(viii) The proviso to Section 5 would be liable to be struck down for its excessiveness.
50 In substance, Dr Dhavan‘s are as follows:
(i) Every administrative action or legislation has to be Nagaraj compliant as
explained in Jarnail;
PART C
(ii) After the decision in B K Pavitra I, the State of Karnataka hurriedly enacted the Reservation Act
2018 without demonstrating any compelling necessity;
(iii) The Governor of Karnataka reserved the Bill for the President without delineating the exact
reasons for doing so. Even while forwarding the Bill, the State government maintained that there
was no reason to make a reference to the President. The queries exchanged subsequently would not
constitute a valid reference;
(iv) The Ratna Prabha Committee report is flawed and does not establish inadequacy of
representation and impact on administrative efficiency;
(v) The Reservation Act 2018 is similar to the Reservation Act 2002 except for
(i) Section 5 while mandates reservations; and (ii) Section 9 which overrules all decisions of the past
and pre-empts challenges in the future;
(vi) The Seniority Rules 1957 continue not to cover consequential seniority and by the repeal of the
Reservation Act 2002, the decision in Badappanavar continues to be good law;
(vii) The uncontrolled backlog is not valid;
(viii) A proper exercise must be post and not vacancy based, it must be based on cadres and not on
groups A to D;
(ix) The counter affidavit of the State admits the flaws of the process denying curative effect to the
exercise; and
(x) The Reservation Act 2018 has failed to pass muster and its non-compliant with the decisions in
Nagaraj and Jarnail.
PART C 51 Mr Shekhar Naphade, learned Senior Counsel submitted that:
(i) The decision in B K Pavitra I has attained finality and a subsequent change in law
cannot abrogate the principle of res judicata;B.K. Pavitra vs Union Of India on 10 May, 2019

(ii) As held in the decision of this Court in Pandit M S M Sharma v Dr Krishna
Sinha70, whether an earlier judgment is right or wrong is not material to the
applicability of the doctrine of res judicata;
(iii) The subsequent decision in Jarnail is not a ground for review and, in any event, a
review of B K Pavitra I by the state will not lie;
(iv) In view of the explanation to Order XLVII of the CPC, a reversal on a question of
law in a subsequent decision of a superior court is not a ground for review;
(v) An error of law is no ground for review (State of West Bengal v Kamal
Sengupta71);
(vi) The Reservation Act 2018 is based on a report which furnishes factual data: this
could have been furnished in the earlier round. The legislature has taken recourse to
exercise of judicial power;
(vii) The provisions of the Reservation Act 2018 are virtually the same as those of the
Reservation Act 2002;
(viii) The basis of legislative intervention was the collection of data: the attempt is to
place fresh material before the Court to review its decision in B K Pavitra I. There is
no change in law;
(ix) Retrospectivity of the Reservation Act 2018 from 1978 is arbitrary;
AIR 1960 SC 1186 (2008) 8 SCC 612 PART C
(x) There is no change in the basis of the law. The basis is a change in the factual matrix which is not
available as a ground for review;
(xi) The Ratna Prabha Committee report has collected no substantive material on the impact of
reservation in promotion on the efficiency of administration;
(xii) The second proviso to Article 200 and Article 254 (2) of the Constitution are exhaustive of the
constitutional power of the Governor to reserve a Bill for the assent of the President;
(xiii) The Ratna Prabha Committee report does not deal with the aspect of creamy layer which had
been duly considered in Jarnail;
(xiv) The Ratna Prabha Committee dwelt on groups and not on cadres. The data includes direct
recruits as well as promotees, whereas the present case is only about promotion; andB.K. Pavitra vs Union Of India on 10 May, 2019

(xv) Data was collected only from thirty one government departments and not from public sector
undertakings.
52 Supplementing the submissions of Dr Dhavan, Mr Puneet Jain, learned Counsel appearing on the
behalf of the petitioners has adverted to the following issues which arise for the consideration of this
Court:
(i) Section 3 of the Reservation Act 2018 only seeks to extend consequential seniority
retrospectively to vacancy based roster point promotees and is not concerned with
the state exercising its enabling power to provide for reservation in promotions. The
Government Order72 dated 27 April 1978 by PART C which reservation for persons
belonging to SCs and STs in specified categories of promotional posts was introduced
cannot be ―justified by a satisfaction on the basis of the Ratna Prabha Committee
report;
(ii) Article 16 (4A) confers a discretion upon the state to provide for reservations in
promotion with or without consequential seniority. Nagaraj mandates that there have
to exist compelling reasons and the satisfaction of the state before exercise of its
powers under Article 16 (4A). In view of the decision in Panneer Selvam, automatic
conferment of consequential seniority can no longer be sustained; and
(iii) The fact that the eighty-fifth amendment has been made retrospective from 17
June 1995 cannot enable the state to make a provision for the first time by exercising
powers retrospectively and consequently taking away vested rights which legitimately
accrued upon the general category employees.
C.2 Submissions for the respondents and intervenors 53 Appearing for the State of Karnataka, Mr
Basava Prabhu S Patil, learned Senior Counsel submitted thus:
A       The basis of B K Pavitra I has been altered
(i)     The Reservation Act 2018 has taken away the basis of the judgment in B
K Pavitra I and the protection of seniority with retrospective effect which is permissible in law:
PART C
(a) The Reservation Act 2018 does not seek to overrule or nullify simpliciter the
decision in B K Pavitra I. The law was enacted to provide consequential seniority for
roster point promotees after collecting data showing the existence of the compelling
reasons of :B.K. Pavitra vs Union Of India on 10 May, 2019

(i) backwardness; (ii) inadequacy of representation; and (iii) overall efficiency.
Hence, the Reservation Act 2018 removes the basis of the decision in B K Pavitra I;
(b) The state legislature is competent to enact a law with retrospective or retroactive
operation. The legislative competence of the State Legislature to enact law is
traceable to Article 16 (4A). Merely because the legislation confers seniority with
effect from 1978, will not lead to its invalidation (Cheviti Venkanna Yadav v State of
Telangana73 (―Cheviti Venkanna Yadav), Utkal Contractors & Joinery (P) Ltd v
State of Orissa74 (―Utkal Contractors and Joinery (P) Ltd) and State of Himachal
Pradesh v Narain Singh75 (―Narain Singh);
(c) Sections 3 and 4 of the Reservation Act 2018 came into operation on 17 June 1995,
on which date the seventy-seventh and eighty-fifth amendments to the Constitution
came into effect, thereby enabling reservations to be made in promotion together
with consequential seniority. The Reservation Act 2018 protects consequential
seniority accorded from 27 April 1978 (the date of the reservation order) in (2017) 1
SCC 283 (1987) Supp. SCC 751 (2009) 13 SCC 165 PART C light of the data collected
which shows the inadequacy of representation;
(d) In terms of the decision in Virpal Singh, the catch-up rule was to be applied with
effect from 10 February 1995 (i.e. the date of the judgment in Sabharwal). According
to the decision in Ajit Singh II, promotions granted prior to 1 March 1996 without
following the catch-up rule are protected. Badappanavar protects the promotions of
reserved candidates based on consequential seniority which took place before 1
March 1996;
(e) While judicial review allows courts to declare a statute as unconstitutional if it
transgresses constitutional limits, courts are precluded from inquiring into the
propriety or wisdom underlying the exercise of the legislative power. The motives of
the legislature in enacting a law are incapable of being judicially evaluated; and
(f) Seniority is not a vested or an accrued right and hence it is open for the legislature
to enact a law for dealing with it.
(ii) The Reservation Act 2018 is not of the same genre of legislation dealt with in the
decision of Madan Mohan Pathak:
(a) Madan Mohan Pathak involved a challenge by the employees of the Life Insurance
Corporation to the constitutional validity of a Parliamentary law which attempted to
render ineffective a settlement with employees for the payment of bonus. The
judgment does not PART C deal with a case where the basis of the invalidity of a
legislation noticed in a judicial decision is taken away by a subsequent law;
andB.K. Pavitra vs Union Of India on 10 May, 2019

(b) Madan Mohan Pathak in fact, notices that in the case of a declaratory judgment holding an
action to be invalid, validating legislation to remove the defect is permissible.
(iii) The collection of data by the State must demonstrate the presence of compelling reasons
namely, (a) inadequacy of representation; (b) backwardness; and (c) overall administrative
efficiency as enunciated in Nagaraj and B K Pavitra I;
(iv) The decision in Indra Sawhney holds that the question as to whether a backward class of citizens
is not adequately represented in the services under the state is a matter of subjective satisfaction;
(v) Nagaraj also notices the position that there is a presumption that the state is in the best position
to define and measure merit and that there is no fixed yardstick to identify and measure the three
factors on which quantifiable data has to be collected;
(vi) The decision in Jarnail also holds that the test of determining the adequacy of representation in
promotional posts is left wisely to the states; and PART C
(vii) The Reservation Act 2018 was enacted after the State was satisfied about the existence of the
three compelling reasons.
B The Ratna Prabha Committee has dealt with all the three facets constituting the „compelling
reasons:
1 Backwardness
(i) The decision in Jarnail has clarified that there is no requirement of collecting
quantifiable data on the backwardness of SCs and STs. The observation in Nagaraj is
contrary to the larger Bench decision in Indra Sawhney.
(ii) Yet, in any event, the Ratna Prabha Committee considered the backwardness of SCs and STs in
view of the dictum in Nagaraj which then held the field. The Committee after carrying out the
exercise came to the conclusion that the requirement of backwardness is satisfied. 2 Inadequacy of
representation
(i) Chapter II of the Ratna Prabha Committee report considered the inadequacy of representation
and records a summary of its conclusions in paragraphs 2.5 and 2.6;
(ii) It is misleading to assert that the State did not collect cadre wise data.
Para 2.4.1 indicates that the government took into account the data for groups A, B, C and D to draw
a conclusion about the inadequacy of representation;
PART CB.K. Pavitra vs Union Of India on 10 May, 2019

(iii) The decisions in Indra Sawhney and Sabharwal are clear in postulating that persons belonging
to the SCs and STs who are appointed against general category posts/vacancies are not to be
reckoned for ascertaining over representation; and
(iv) It is a matter of common experience that for most of the group D posts such as municipal
sweepers, only persons belonging to SCs and STs apply. Over representation in group D posts which
results from general category candidates keeping away from them is no ground to deny promotion
to group D employees recruited against the reserved category. 3 Administrative efficiency
(i) Para 3.12 of Chapter III of the Ratna Prabha Committee report has considered all relevant
aspects before coming to the conclusion that reservations in promotion do not affect administrative
efficiency;
(ii) Promotions are made on the basis of seniority-cum-merit. [Rule 19(3)(a) of the Rules 1977] Only
those candidates who fulfil the criteria of merit/suitability are promoted based on seniority. Since
this criterion is applicable even in respect of roster promotions, the efficiency of administration is
not adversely impacted; and
(iii) On promotion, a candidate is required to serve a statutory period of officiation before being
confirmed in service. This applies to all candidates including roster point promotees and ensures
that the efficiency of administration is not adversely affected.
PART C C The challenge on the ground that the Reservation Act 2018 does not exclude the benefit of
consequential seniority in respect of the creamy layer in terms of the decision in Jarnail is baseless:
(i) Creamy layer as a concept can be applied only at the entry level or at appointment
and has no application while granting reservations in promotion and allowing for
consequential seniority. The Reservation Act 2018 provides only for consequential
seniority and the extent of reservation granted to SCs and STs at the entry level/ in
appointment is not under challenge;
(ii) Even assuming that the concept of creamy layer can be applied at the stage of
promotion, it is inapplicable to the conferment of consequential seniority.
Consequential seniority is not an additional benefit but a consequence of promotion;
(iii) Appointment to a post or progression in career based on promotion cannot be
treated as acquisition of creamy layer status. In fact, the decision in Jarnail makes it
clear that the concept of creamy layer applies only to the entry stage;
(iv) Nagaraj does not hold that the exclusion of the creamy layer is a pre-
condition for the exercise of the enabling power under Article 16 (4A) for providing promotion or
consequential seniority;B.K. Pavitra vs Union Of India on 10 May, 2019

(v) In the decision in B K Pavitra I, the challenge to the Reservation Act 2002 was accepted on the
ground that the State had not carried out an exercise for determining inadequacy of representation,
backwardness and overall PART C efficiency of administration. B K Pavitra I did not accept the plea
of the applicability of creamy lawyer principle to consequential seniority; and
(vi) Under the Reservation Order 1978, reservations in promotion are restricted up to the lowest
category of class I post. D There is no basis in the challenge that the Reservation Act 2018 does not
meet the proportionality test and results in over representation.
(i) In view of the Reservation Order 1999 providing that reservation in promotion in favour of SCs
and STs shall continue only till their representation reaches 15 per cent and 3 per cent respectively,
it is ensured that there is no over representation; and
(ii) Since the Reservation Act 2018 provides only for consequential seniority and not for reservation
in appointment or promotion, it cannot be asserted that reservation for the purpose of seniority is
vacancy-based and not post- based, contrary to the decision in Sabharwal. Reservations in
promotion are provided by the Government Order 1978 which provides for roster point promotion
and not roster point seniority. The Government Order dated 13 April 1999 provides for making
promotions (after the existing backlog is filled) in favour of SCs and STs by maintaining their
representation to the extent of 15 per cent and 3 per cent of the total working strength (and not
vacancies).
PART C E There was no constitutional infirmity in the Governor of Karnataka having reserved the
Reservation Act 2018 for the consideration of the President.
The Governor in reserving the Bill for consideration of the President acted in pursuance of the
provisions of Article 200 of the Constitution. The Governor may under Article 200 (i) declare assent
to a Bill; or (ii) declare the withholding of assent; or (iii) reserve a Bill for consideration of the
President. The power of the Governor to reserve a Bill for consideration of the President is not
subject to the existence of a repugnancy under Article 254 (2). The action of the Governor is
non-justiciable. (Hoechst Pharmaceuticals Ltd) F The assent of the Governor is not contemplated
once the President has given assent to a Bill.
Neither Article 200 nor Article 201 contemplates that the Bill should be presented again before the
Governor after it has been assented to by the President. Section 5(1)(iv) of the Karnataka General
Clauses Act 1899 postulates that an Act passed by the Karnataka legislature shall come into
operation on the day on which the assent of the Governor or, as the case may be, of the President is
granted and is first published in the Official Gazette. Hence, once the assent of the President is
granted, the necessity of a further assent by the Governor is obviated.
G The submission that in Karnataka Power Transport Corporation Limited, as a consequence of the
reservation in seniority in the cadre of PART C Superintending Engineer and Engineer-in-Chief,
there was over representation for SCs and ST between 2005 and 2016 is erroneous.B.K. Pavitra vs Union Of India on 10 May, 2019

(i) There is no reservation for promotion to the posts of Superintending Engineer and
Engineer-in-Chief in KPTCL. Reservation in promotion and consequential seniority is available only
up to the post of Assistant Executive Engineer. In fact, if consequential seniority were not to be
granted on promotion up to the post of Assistant Executive Engineer, there would be excessive
under-representation of reserved category candidates. The Ratna Prabha Committee report, in
paragraph 2.4, took note of the total number of officials/employees working in thirty one
government departments of the State Government. It noted that 80.35 per cent of the sanctioned
posts are concentrated in six major Government departments namely; Education, Home, Health,
Revenue, Judicial and Finance. The data pertaining to thirty one government departments was
taken in the totality to analyse and assess the adequacy of representation. The data of smaller
departments may not be representative of the State Civil Services as a whole.
On the above grounds, it was urged that the challenge to the Reservation Act 2018 must fail.
54 Ms Indira Jaising76, learned Senior Counsel appearing on behalf of the intervenors (Karnataka
SC/ST Engineer‘s Welfare Association) contended that In I.A. No. 90623 of 2018 in W.P. (C) No.
764 of 2018 PART C the Reservation Act 2018 is constitutionally valid. Ms Jaising urged the
following submissions:
(i) The decisions of this Court in State of Kerala v N M Thomas77 (―N M Thomas)
and Nagaraj affirmed that Article 16 (4) is an emphatic declaration of Article 16 (1).
The principle of ‗proportional equality‘ entails substantive equality which is reflected
in affirmative action to remedy injustice to SCs, STs and Other Backward Classes78.
Social justice is concerned with the distribution of benefits and burdens. The
Reservation Act 2018, in providing for consequential seniority, furthers the vision of
substantive equality and is valid;
(ii) Affirmative action under Article 15 (4) and reservation under Article 16 (4) of the
Constitution are intended to ensure that all sections of the society are represented
equally in services under the state. The Reservation Act 2018 underlies this salient
objective and furthers the promotion of the interests of the SCs, STs and other
weaker sections as stipulated in Article 46 of the Constitution;
(iii) Article 16 (4A) is an enabling provision which empowers the State to frame rules or enact a
legislation granting reservations in promotions with consequential seniority subject to the fulfilment
of the conditions laid down in Nagaraj and modified by Jarnail. Following the decision in Jarnail,
the state is required to show data only on the inadequacy of representation and efficiency of
administration. The State of Karnataka, in exercise of the enabling power under Article 16 (4A)
enacted the Reservation Act 2018 in (1976) 2 SCC 310 OBCs PART C compliance with the conditions
precedent to the exercise of the power stipulated in that Article;
(iv) The decision in Sabharwal lays down that in determining the inadequacy of representation of
SCs and STs in promotional posts, the state may take the total population of a particular class and
its representation in the service. The State has studied the extent of reservation in posts for SCs andB.K. Pavitra vs Union Of India on 10 May, 2019

STs in a ‗group‘ which is a collection of cadres. Hence, it cannot be said that the state failed to
collect quantifiable data on the representation of SCs and STs in promotional posts. Without the
grant of consequential seniority, the percentage of reservation will not reach the prescribed
percentage;
(v) No statistical studies have been provided to show that the grant of consequential seniority has
led to the lowering of efficiency in administration. It cannot be presumed that the appointment of
SCs and STs will lead to a lowering of efficiency as at the individual level, all individuals belonging to
SCs and STs must also achieve the minimum benchmark of ‗good‘;
(vi) The Reservation Act 2002 was struck down on the basis of the failure of the state to collect
quantifiable data. The Reservation Act 2018 has been enacted on the basis of data collected and
studied in the Ratna Prabha Committee report. Hence, the basis of the decision in B K Pavitra I has
been removed. Additionally, no mandamus was issued in B K Pavitra I;
(vii) The collection of data required to be carried out by the State is a matter of social science and is
carried out by experts. Data collection is both PART C qualitative and quantitative. As long as the
methodology adopted by the state is scientifically sound, the assessment of the data collected is the
prerogative of the state. The court may intervene in judicial review only when there is a complete
absence of data or if the data relied on is irrelevant; and
(viii) The principles laid down by this Court in Indra Sawhney on the exclusion of the creamy layer
apply only to OBCs and cannot extend to SCs and STs. No question arose in Nagaraj on the
exclusion of the creamy layer in respect of SCs and STs. Hence, the decision is not an authority for
the principle that the states are bound to exclude the creamy layer in respect of SCs and STs. The
decision of this Court in Jarnail dealt with the competence of Parliament to enact a law in relation to
the creamy layer and did not lay down a general proposition on its exclusion. The concept of creamy
layer, if applicable, can only be applied at the entry level and not in promotions.
55 Mr Dinesh Dwivedi79, learned Senior Counsel appearing on behalf of the intervenor (Karnataka
SC/ST Engineers‘ Welfare Association), urged the following submissions:
(i) The decision in Nagaraj was concerned with whether reservation in promotion as
inserted in Article 16 (4A) by the Constitution (Seventy-
seventh Amendment) Act 1995 and the enabling provision for the grant of consequential seniority
under Article 16 (4A) inserted by the Constitution (Eighty-fifth Amendment) Act 2001 violated the
basic structure of the In I.A. No. 102966 of 2018 in W. P. (C) No. 791 of 2018 PART C Constitution.
The decision in Nagaraj was concerned with reservations in promotion and did not equate
reservation in promotion with the grant of consequential seniority. In this view, the four controlling
factors, namely (i) backwardness; (ii) adequacy of representation; (iii) elimination of the creamy
layer; and (iv) efficiency of administration have relevance only to the exercise of the enabling power
under Article 16 (4A) for making reservation in promotion and not the exercise of the enabling
power to grant consequential seniority;B.K. Pavitra vs Union Of India on 10 May, 2019

(ii) Reservation in promotion was introduced in the State of Karnataka by the Government Order
dated 27 April 1978 and continues to be in operation. The Reservation Act 2018 stipulates the grant
of consequential seniority which is premised on the prior existence and operation of reservation in
promotion. Absent a challenge to the Government Order dated 27 April 1978 in the present
proceedings, the petitioner is precluded from challenging the grant of consequential seniority in the
Reservation Act 2018;
(iii) Consequential seniority is nothing but the normal rule of seniority which accords seniority to
roster point promotees from the date of their substantive promotion. The catch-up rule is an
exception to the normal rule of seniority. Prior to the decision in Indra Sawhney, accelerated
seniority to roster point promotees existed in the State of Karnataka with the application of the
continuous officiation rule. This is supported by Rule 2(b) of the 1957 Rules. Para III (d) of the
Government Order dated 27 April 1978 provided for the application of the catch-up rule only in a
limited PART C manner. Rule 4 is restricted in its application to appointments made on the same
day which implies that in the absence of its application to a given case, consequential seniority must
be granted;
(iv) The decision in Virpal Singh concerned a rule that specifically provided for the application of the
catch-up rule in a departure from the normal rule of seniority. This Court held that a state may
prescribe either consequential seniority based on continuous officiation or the catch-up rule of
seniority in case of roster point promotions. A harmonious reading of Articles 14 and 16(1) of the
Constitution does not stipulate that the catch-up rule must apply in the case of roster point
promotions. Thus, a balancing of Articles 14, 16(1) and 16(4) of the Constitution denotes that the
catch-up rule is not mandatory. The decisions of this Court in Ajit Singh I, Ajit Singh II and
Badappanavar, in holding to the contrary, have been expressly overruled by the seventy-seventh and
the eighty-fifth amendments to the Constitution, following which the principles enunciated in Virpal
Singh continue to govern the field. The eighty-fifth amendment was intended to make consequential
seniority a constitutional principle and revive consequential seniority as the normal rule of
seniority;
(v) The principles enunciated in Virpal Singh are fortified by the decision in Nagaraj which held that
the catch-up rule and consequential seniority are principles of service jurisprudence and cannot be
elevated to a constitutional status. The discretion to choose between consequential seniority and
catch-up vests with the state. The Reservation Act 2018, in PART C stipulating for consequential
seniority, is a valid exercise of discretion by the State; and
(vi) In the alternative, the tests laid down by the four controlling factors in Nagaraj and Jarnail have
been satisfied prior to the enactment of the Reservation Act 2018. The satisfaction of the state in this
regard cannot be subjected to review by this Court.
56 Mr Lakshminarayana, learned Senior Counsel has submitted thus:
(i) The issue as to whether reservation under Article 16 (4A) can be provided by an
executive order was answered in the affirmative in the judgment of Justice BP JeevanB.K. Pavitra vs Union Of India on 10 May, 2019

Ready speaking for a plurality of judges in Indra Sawhney. The word ‗provision‘ in
Article 16 (4) was interpreted in contrast with the word ‗law‘ in clauses (3) and (5) of
Article 16. The word ‗any‘ and the word ‗provision‘ in Article 16 (4) must be given
their due meaning.
Article 16 (4) is exhaustive as a special provision in favour of the backward class of citizens.
Backward classes having been classified by the Constitution as a class deserving special treatment
and the Constitution itself having specified the nature of the special treatment, it should be
presumed that no further classification or special treatment is permissible in their favour outside
Article 16 (4). In light of the decision in Indra Sawhney, it is now a settled principle that a provision
for reservation can be made by the legislature, by statutory rules and by executive orders;
(ii) Provisions for reservation in promotions were introduced in Karnataka by the Government
Order dated 27 April 1978 on the basis of the inadequacy PART C of representation of SCs and STs
in public services under Article 16 (4). After the report on the inadequacy of representation dated 30
August 1979, first and second roster points were reserved for SCs and STs. The principle of
consequential seniority is adopted by clause (vii) of the Government Order dated 27 April 1978 and
clause (d) of the Government Order dated 1 June 1978;
(iii) Clause (vii) of the Government Order dated 27 April 1978 as it originally stood provided that
inter se seniority amongst persons promoted ―on any occasion shall be determined under Rules 4
and 4 (A) of the Seniority Rules 1957;
(iv) The words ―on any occasion in clause (vii) were amended by clause (d) of the Government
Order dated 1 June 1978 so that the determination of seniority among reserved promotees and
general candidates on the basis of seniority-cum-merit shall ―on each occasion be fixed under Rule
4 of the Seniority Rules 1957;
(v) The substitution of the expression ―on any occasion with the expression ―on each occasion
denotes the intention of the government to provide consequential seniority to reserved category
candidates promoted on the basis of roster;
(vi) The legislature enacted provisions pertaining to the policy of reservation in promotion in the
State Civil Services and Public Sector Undertakings as follows :
PART C
(a) The Rules 1977 including the proviso to Rule 8, upheld by this Court in Bhakta
Ramegowda;
(b) The Karnataka Scheduled Castes, Scheduled Tribes and Other Backward Classes
(Reservation of Appointment etc.,) Act 1990;B.K. Pavitra vs Union Of India on 10 May, 2019

(c) The Karnataka Scheduled Castes, Scheduled Tribes and Other Backward Classes
(Reservation of Appointment etc.,) Rules 1992;
and
(d) The Karnataka State Civil Services (Unfilled Vacancies Reserved for the persons belonging to the
Scheduled Castes and the Scheduled Tribes) (Special Recruitment) Rules 2001.
The above provisions were followed by the Reservation Acts of 2002 and 2017.
(vii) With effect from 1 April 1992, the State of Karnataka inserted the proviso to Rule 8 in the Rules
1977 which reads as follows:
―8. Provision for reservation of appointments or posts.-
Appointments or posts shall be reserved for the members of the Scheduled Castes,
Scheduled Tribes, and Other Backward Classes to such extent and in such manner as
may be specified by the government under clause (4) of Article 16 of the Constitution
of India.
Proviso to Rule 8 [Provided that, notwithstanding anything in the rules of
Recruitment specially made in respect of any Service or Post, the backlog vacancies in
the promotional quota shall be determined and implemented with effect from 27th
April,1978.
Note.– The backlog vacancy means the extent of the number of vacancies available
under the roster system up to the level of lowest category in Group-A post calculated
from 27th April, 1978.]. Proviso inserted by GSR 64, dated 01.04.1992 w.e.f.
01.04.1992 PART C The above Rule was upheld in Bhakta Ramegowda;
(viii) The Government Order dated 24 June 1997 provided additional roster points to
cover up backlog promotional roster points, both in promotion and direct
recruitment. Clauses (iv) and (v) of para 8 of the Government Order dated 24 June
1997 reads as follows :
―Clause (IV).
After effecting review of promotion and adjustment and fitment as indicated in item
(iii) above, if some more persons belonging to scheduled castes and scheduled tribes
who have already been promoted against backlog cannot get adjusted due to want of
adequate number of vacancies as per the aforesaid roster points, such persons shall
be adjusted and fitted in accordance with the procedure specified in item
(iii) while effecting promotion in respect of future vacancies.B.K. Pavitra vs Union Of India on 10 May, 2019

Until such time, shall be continued against supernumerary posts to be created by the concerned
Administrative Department. For this purpose, the Secretaries to Government are hereby delegated
the power to create supernumerary posts presuming the concurrence of Finance Department and to
that extent the Government Order No. FD 1 TFP 96, dated 10.07.1996, shall be deemed to have been
modified accordingly.
Clause (V) While adjusting and fitting promote[e]s as indicated in item (iii) and (iv) above, the
inter-se seniority among the General category, the scheduled caste category and the scheduled tribe
category shall be determined in accordance with rule 4 or rule 4 A as the case may be, of the
Karnataka Government Servants Seniority Rules 1957. The roster points are meant only for
calculating the number of vacancies that become available for the different categories on each
occasion and they do not determine the seniority. The above clauses reiterated the purpose of
assessing inter se seniority after promotion of roster promotees in reckoning consequential seniority
among two groups.
PART C
(ix) The State Government is entitled to prescribe the percentage of reservation based on the total
population of a particular backward class and its representation in the services of the State under
Article 16 (4). Once the prescribed percentage of reservations is determined, the numerical test of
adequacy is satisfied. The percentage of reservation is the desired representation of the backward
classes in the state services and is consistent with the demographic estimate, based on the
proportion worked out in relation to their population;
(x) The operation of the roster points and filling of the cadre strength ensures that the reservation
remains within the limit of 50 per cent;
(xi) Reserved candidates who have been appointed or promoted on merit as general candidates
cannot be included in calculating adequacy of representation of backward classes in operating the
roster points. Only reserved candidates promoted against roster points are to be taken into account
in considering the adequacy of representation;
(xii) A cadre includes different grades and reservation can be provided in different grades within the
cadre. The reservation policy contained in the Government Order dated 27 April 1978 has been
re-issued on 17 April 1993 and 11 May 1993 after the decision in Indra Sawhney;
(xiii) Both clauses (1) and (4) of Article 16 operate in the same field. Both are directed towards
achieving equality of opportunity in services under the State. The formation of opinion by the State
on the adequacy of representation is a matter of subjective satisfaction and the test is whether PART
C there was some material before the State to justify its opinion. In the exercise of judicial review,
the court would extend due deference to the judgment and discretion of the executive. Even if there
are some errors on the part of the State Government, that would not in any way result in the
invalidation of the entire exercise;B.K. Pavitra vs Union Of India on 10 May, 2019

(xiv) Efficiency of administration means governance which provides responsive service to the
people. Merit alone is not a component of efficiency. Once an employee is promoted, efficiency is
judged on the basis of the annual confidential reports;
(xv) A curative legislation does not constitute an encroachment on judicial power by the State
Legislature. Similarly, it is open to the legislature to enact a legislation both with retrospective and
prospective effect; (xvi) Judicial review cannot extend to examine the adequacy of the material
available before the President and unless, there is a situation involving a fraud on power or conduct
actuated by oblique motive, the court would not intervene;
(xvii) The principle of creamy layer has no application to in-service candidates;
and (xviii) The State having rectified the lacuna which was pointed out in B K Pavitra I, by carrying
out the exercise of data collection, the opinion formed by the State after analysing the data lies in its
subjective satisfaction. The reservation policy dated 27 April 1978 which introduced provisions for
PART C reservations in promotions for SCs and STs in public services has continued until date
without interruption.
57 Mr Nidhesh Gupta, learned Senior Counsel urged the following submissions:
(i) The phrase ‗in the opinion of the state‘ in Article 16(4) of the Constitution
indicates that the issue with regard to adequacy of representation is within the
subjective satisfaction of the state. The role of the court is limited to examining
whether the opinion formed by the government was on the basis of data available
with it. While the existence of circumstances requiring state action may be reviewed,
the opinion formed is outside the purview of judicial review. These propositions have
been accepted in the decisions of this Court in Indra Sawhney, Barium Chemicals
Ltd. v Company Law Board81 (―Barium Chemicals Ltd.), Rohtas Industries v S D
Agarwal82 and Rustom Cavasjee Cooper v Union of India83;
(ii) The expression ‗to any class or classes of posts‘ in Article 16(4) makes it
abundantly clear that the phrase refers to a ‗class‘ or ‗group‘ and not a cadre. The
use of the word ‗services‘ in the phrase ‗services under the state‘ in Article 16 (4A)
supports this contention. The decisions in Sabharwal and Nagaraj clarify that cadre
strength is to be applied in the operation of the roster. The reference to ‗entire cadre
strength‘ in Sabharwal adverted to the fact that the entire cadre strength should be
taken into account in determining whether reservation up to the quota limit AIR 1967
SC 295 (1969) 1 SCC 325 (1970) 1 SCC 248 PART C has been reached. In this view,
‗entire cadre strength‘ is the reference point to (i) ascertain the position of
representation in the entire service; (ii) determine whether reservation up to the
quota limit has been reached in the application of the roster; and (iii) the cadre
strength has been applied in the operation of the roster. It was urged that if the
percentages were calculated on the basis of vacancies, the actual appointments made
may exceed the prescribed quota. Reliance has been placed on the decisions of thisB.K. Pavitra vs Union Of India on 10 May, 2019

Court in Indra Sawhney, Nagaraj, and Jarnail;
(iii) The decision in Indra Sawhney does not deal with SCs and STs in regard to the
creamy layer principle. In any case, even if the principle applies to SCs and STs, it
would only be applicable at the stage of appointments and not for promotional posts;
and
(iv) The percentages in the PWD which are marginally above the stipulated quota are
by way of including those reserved category candidates who were selected on general
merit. This is contrary to the law laid down by this Court in Sabharwal, Indra
Sawhney and Ritesh Sah v Y L Yamul84.
58 The rival submissions now fall for consideration. 59 Other Counsel, who argued and submitted
their written submissions, have with certain nuances, reiterated similar arguments.
     (1996) 3 SCC 253
                                                                                                      PART D
D        Assent to the Bill
60       Besides the Governor, the legislatures of the States consist of a bicameral
legislature for some States and a unicameral legislature for others.85 61 Article 200 is the provision
which enunciates the power of the Governor to assent to a Bill, withhold assent or reserve a Bill for
considering of the President:
―200. When a Bill has been passed by the Legislative Assembly of a State or, in the
case of a State having a Legislative Council, has been passed by both Houses of the
Legislature of the State, it shall be presented to the Governor and the Governor shall
declare either that he assents to the Bill or that he withholds assent therefrom or that
he reserves the Bill for the consideration of the President:
Provided that the Governor may, as soon as possible after the presentation to him of
the Bill for assent, return the Bill if it is not a Money Bill together with a message
requesting that the House or Houses will reconsider the Bill or any specified
provisions thereof and, in particular, will consider the desirability of introducing any
such amendments as he may recommend in his message and, when a Bill is so
returned, the House or Houses shall reconsider the Bill accordingly, and if the Bill isB.K. Pavitra vs Union Of India on 10 May, 2019

passed again by the House or Houses with or without amendment and presented to
the Governor for assent, the Governor shall not withhold assent therefrom:
Provided further that the Governor shall not assent to, but shall reserve for the
consideration of the President, any Bill which in the opinion of the Governor would, if
it became law, so derogate from the powers of the High Court as to endanger the
position which that Court is by this Constitution designed to fill. Article 168. (1) For
every State there shall be a Legislature which shall consist of the Governor, and—
(a) in the States of [Andhra Pradesh], Bihar, [Madhya Pradesh], [Maharashtra],
[Karnataka], [[Tamil Nadu, Telangana]] [and Uttar Pradesh], two Houses;
(b) in other States, one House.
(2) Where there are two Houses of the Legislature of a State, one shall be known as
the Legislative Council and the other as the Legislative Assembly, and where there is
only one House, it shall be known as the Legislative Assembly.
PART D Article 201 deals with what is to happen when the Governor reserves a Bill for the
consideration of the President.
―201. When a Bill is reserved by a Governor for the consideration of the President, the President
shall declare either that he assents to the Bill or that he withholds assent therefrom:
Provided that, where the Bill is not a Money Bill, the President may direct the
Governor to return the Bill to the House or, as the case may be, the Houses of the
Legislature of the State together with such a message as is mentioned in the first
proviso to article 200 and, when a Bill is so returned, the House or Houses shall
reconsider it accordingly within a period of six months from the date of receipt of
such message and, if it is again passed by the House or Houses with or without
amendment, it shall be presented again to the President for his consideration. Upon
a Bill being passed by the Houses of the legislature (or by the sole House where there
is only a legislative assembly), it has to be presented to the Governor. The Governor
can (i) assent to the Bill; (ii) withhold assent; or (iii) reserve the Bill for the
consideration of the President.
62 Where a Bill is not a Money Bill, the Governor may return the Bill for reconsideration upon
which the House or Houses, as the case may be, will reconsider the desirability of introducing the
amendments which the Governor has recommended. If the Bill is passed again by the House (or
Houses as the case may be), the Governor cannot thereafter withhold assent. The second proviso to
Article 200 stipulates that the Governor must not assent to a Bill but necessarily reserve it for the
consideration of the President if the Bill upon being enacted would derogate from the powers of the
High Court in a manner that PART D endangers its position under the Constitution. Save and except
for Bills falling within the description contained in the second proviso (where the Governor mustB.K. Pavitra vs Union Of India on 10 May, 2019

reserve the Bill for consideration of the President), a discretion is conferred upon the Governor to
follow one of the courses of action enunciated in the substantive part of Article 200. Aside from Bills
which are covered by the second proviso, where the Governor is obliged to reserve the Bill for the
consideration of the President, the substantive part of Article 200 does not indicate specifically, the
circumstances in which the Governor may reserve a Bill for the consideration of the President. The
Constitution has entrusted this discretion to the Governor. The nature and scope of the
discretionary power of the Governor to act independent of, or, contrary to aid and advice of Council
of Ministers under Article 163 was discussed in Nabam Rebia, Justice J S Khehar (as the learned
Chief Justice then was) held thus:
―154. We are, therefore, of the considered view that insofar as the exercise of
discretionary powers vested with the Governor is concerned, the same is limited to
situations, wherein a constitutional provision expressly so provides that the Governor
should act in his own discretion. Additionally, a Governor can exercise his functions
in his own discretion, in situations where an interpretation of the constitutional
provision concerned, could not be construed otherwise…86 Justice Dipak Misra (as
the learned judge then was), observed thus:
―375. …The Governor is expected to function in accordance with the provisions of the
Constitution (and the history behind the enactment of its provisions), the law and the
rules regulating his functions. It is easy to forget that the Governor is a constitutional
or formal head—nevertheless like everybody else, he has to play the game in
accordance with the rules of the game—whether it is in relation to the Supra 69 at
page 159 PART D Executive (aid and advice of the Council of Ministers) or the
Legislature (Rules of Procedure and Conduct of Business of the Arunachal Pradesh
Legislative Assembly). This is not to say that the Governor has no powers—he does,
but these too are delineated by the Constitution either specifically or by necessary
implication…87
63 The framers carefully eschewed defining the circumstances in which the Governor may reserve a
Bill for the consideration of the President. By its very nature the conferment of the power cannot be
confined to specific categories. Exigencies may arise in the working of the Constitution which justify
a recourse to the power of reserving a Bill for the consideration of the President. They cannot be
foreseen with the vision of a soothsayer. The power having been conferred upon a constitutional
functionary, it is conditioned by the expectation that it would be exercised upon careful reflection
and for resolving legitimate concerns in regard to the validity of the legislation. The entrustment of a
constitutional discretion to the Governor is premised on the trust that the exercise of authority
would be governed by constitutional statesmanship. In a federal structure, the conferment of this
constitutional discretion is not intended to thwart democratic federalism. The state legislatures
represent the popular will of those who elect their representatives. They are the collective
embodiments of that will. The act of reserving a Bill for the assent of the President must be
undertaken upon careful reflection, upon a doubt being entertained by the Governor about the
constitutional legitimacy of the Bill which has been passed.B.K. Pavitra vs Union Of India on 10 May, 2019

Ibid at page 244 PART D 64 Dr Dhavan in the course of his submissions, has dwelt at length on the
power which is entrusted to the Governor to reserve a Bill for the consideration of the President
under Article 254 (2). Article 254 (2) deals with a situation where a law which has been enacted by
the legislature of a state on a matter which is enumerated in the Concurrent List of the Seventh
Schedule contains any provision which is repugnant either to an earlier law made by Parliament or
an existing law with respect to that matter. In such an eventuality, the law made by the legislature of
the state can prevail in that state only if it has received the assent of the President on being reserved
for consideration. 65 When the reservation of a Bill for the assent of the President has been
occasioned on the ground of a repugnancy with an existing law or a law enacted by the Parliament,
there are decisions of this Court which hold that the President has to be apprised of the reason why
the assent was sought. In Gram Panchayat of Village Jamalpur, a law enacted by the Punjab
legislature in 1953, extinguished all private interests in Shamlat-deh lands and vested them in the
village Panchayats as a matter of agrarian reform. This Court held that the Punjab enactment had
not been reserved for the assent of the President on the ground that it was repugnant to an earlier
Act enacted by Parliament in 1950 but the assent was sought for a different and a specific purpose.
In this background, the Constitution Bench held that the assent of the President would not avail the
state government to accord precedence to the law enacted by the state legislature over the law made
by Parliament. The Constitution Bench held:
PART D ―12…The assent of the President under Article 254(2) of the Constitution is
not a matter of idle formality. The President has, at least, to be apprised of the reason
why his assent is sought if, there is any special reason for doing so. If the assent is
sought and given in general terms so as to be effective for all purposes, different
considerations may legitimately arise. But if, as in the instant case, the assent of the
President is sought to the Law for a specific purpose, the efficacy of the assent would
be limited to that purpose and cannot be extended beyond it.88
66 A similar principle was adopted in Kaiser-I-Hind Pvt Ltd. The case concerned rent legislation in
Maharashtra and the Public Premises (Eviction of Unauthorized Occupants) Act 1971 enacted by
Parliament. This Court held that where the assent was given after considering the repugnancy
between the Bombay Rent Act, the Transfer of Property Act and the Presidency Small Cause Courts
Act, it was not correct to hold that the state law would prevail over another parliamentary enactment
for which no assent had been sought. In that context, the Court held:
―65… 2. (a) Article 254(2) contemplates ―reservation for consideration of the
President and also ―assent. Reservation for consideration is not an empty
formality. Pointed attention of the President is required to be drawn to the
repugnancy between the earlier law made by Parliament and the contemplated State
legislation and the reasons for having such law despite the enactment by Parliament.
(b) The word ―assent used in clause (2) of Article 254 would in context mean
express agreement of mind to what is proposed by the State.89B.K. Pavitra vs Union Of India on 10 May, 2019

67 These decisions are specifically in the context of Article 254. Article 254(1) postulates inter alia,
that in a matter which is governed by the Concurrent List, a Supra 67 at pages 668-669 Supra 66 at
pages 215-216 PART D law which has been enacted by the legislature of a state shall be void to the
extent of its repugnancy with a law enacted by the Parliament. Clause (2) of Article 254 obviates that
consequence where the law has been reserved for the consideration of the President and has
received assent. Article 254(1) is made subject to Clause (2), thereby emphasizing that the assent of
the President will cure a repugnancy of the state law with a law enacted by the Parliament in a
matter falling in the Concurrent List. It is in this context, that the decisions of this Court hold that
the assent of the President should be sought in relation to a repugnancy with a specific provision
contained in a Parliamentary legislation so as to enable due consideration by the President of the
ground on which assent has been sought. Article 200 contains the source of the constitutional power
which is conferred upon the Governor to reserve a Bill for the consideration of the President. Article
254 (2) is an illustration of the constitutional authority of the Governor to reserve a law enacted by
the state legislature for consideration of the President in a specified situation - where it is repugnant
to an existing law or to a Parliamentary legislation on a matter falling in the Concurrent List. The
eventuality which is specified in Article 254 (2) does not exhaust the ambit of the power entrusted to
the Governor under Article 200 to reserve a Bill for the consideration of the President. Apart from a
repugnancy in matters falling in the Concurrent List between state and Parliamentary legislation, a
Governor may have sound constitutional reasons to reserve a Bill for the consideration of the
President. Article 200, in its second proviso mandates that a Bill which derogates from the powers
of the High Court must be reserved for the consideration of the President. Apart from Bills which
fall within the description set out in the second PART D proviso, the Governor may legitimately
refer a Bill for consideration of the President upon entertaining a legitimate doubt about the validity
of the law. By its very nature, it would not be possible for this Court to reflect upon the situations in
which the power under Article 200 can be exercised. This was noticed in the judgment of this Court
in Hoechst. Excluding it from judicial scrutiny, the Court held:
―86…There may also be a Bill passed by the State Legislature where there may be a
genuine doubt about the applicability of any of the provisions of the Constitution
which require the assent of the President to be given to it in order that it may be
effective as an Act. In such a case, it is for the Governor to exercise his discretion and
to decide whether he should assent to the Bill or should reserve it for consideration of
the President to avoid any future complication. Even if it ultimately turns out that
there was no necessity for the Governor to have reserved a Bill for the consideration
of the President, still he having done so and obtained the assent of the President, the
Act so passed cannot be held to be unconstitutional on the ground of want of proper
assent. This aspect of the matter, as the law now stands, is not open to scrutiny by the
courts. In the instant case, the Finance Bill which ultimately became the Act in
question was a consolidating Act relating to different subjects and perhaps the
Governor felt that it was necessary to reserve it for the assent of the President. We
have no hesitation in holding that the assent of the President is not justiciable, and
we cannot spell out any infirmity arising out of his decision to give such assent.90B.K. Pavitra vs Union Of India on 10 May, 2019

68 Hoechst is an authority for the proposition that the assent of the President is non - justiciable.
Hoechst also lays down that even if, as it turns out, it was not necessary for the Governor to reserve
a Bill for the consideration of the President, yet if it was reserved for and received the assent of the
President, the Supra 68 at pages 100-101 PART D law as enacted cannot be regarded as
unconstitutional for want of ‗proper‘ assent.
69 The above decisions essentially answer the submissions which were urged by Dr Dhavan. The law
as propounded in the line of precedents adverted to above must negate the submissions which were
urged on behalf of the petitioners. Once the Bill (which led to the Reservation Act 2018) was
reserved by the Governor for the consideration of the President, it was for the President to either
grant or withhold assent to the Bill. The President having assented to the Bill, the requirements of
Article 201 were fulfilled. The validity of the assent by the President is non-justiciable. The
Governor, while reserving the Bill in the present case for the consideration of the President on 6
December 2017 observed thus:
―The Supreme Court in the case of BK Pavitra Case, while considering the issue of
grant of promotion to persons belonging to SC and STs has observed the necessity of
applying the test of inadequacy of representation, backwardness and overall
efficiency, for exercise of power under Article 16 (4A) of the Constitution and has
directed the State Government to revise the seniority list within the time frame.
The State Government to overcome the situation which was found fault with by the
Supreme Court in the aforesaid judgment has come out with a Bill, which is now sent
for my assent.
Having regard to the judgment of the Supreme Court in the aforesaid case and
importance of the issue and the Constitutional interpretation involved in the matter,
I deem it appropriate to reserve the matter for the consideration of the President.
Accordingly, the Bill is reserved for the consideration of the President under Article
200 of the Constitution of India. PART E
70 The state government, in the course of its clarifications, was of the view that there was no
necessity of reserving the Bill for the consideration of the President, since in its view, the Governor
had not recorded a finding that it was unconstitutional, or fell afoul of existing central legislation on
the subject or that it was beyond legislative competence or derogated from the fundamental rights.
All procedural requirements under the Constitution were according to the government duly
complied with. This objection of the state government cannot cast doubt upon the grant of assent by
the President. The law having received the assent of the President, the submissions which were
urged on behalf of the petitioners cannot be countenanced.
E Does the Reservation Act 2018 overrule or nullify B K Pavitra I 71 The foundation of the decision
in B K Pavitra I is the principle enunciated in Nagaraj that in order to sustain the exercise of the
enabling power contained in Article 16 (4A), the state is required to demonstrate a ―compelling
necessity by collecting quantifiable data on: (i) inadequacy of representation; (ii) backwardness;B.K. Pavitra vs Union Of India on 10 May, 2019

and (iii) overall efficiency. The judgment in B K Pavitra I held that no such exercise was undertaken
by the State of Karnataka before providing for reservation in promotion and providing for
consequential seniority. On the ground that the state had not collected quantifiable data on the three
parameters enunciated in Nagaraj, the Reservation Act 2002 was held to be unconstitutional. The
Constitution Bench in Nagaraj upheld the validity of Article 16 (4A) on the basis that before taking
recourse to the enabling power the state has to carry out PART E the exercise of collecting
quantifiable data and fulfilling the three parameters noted above. B K Pavitra I essentially held that
there was a failure on the part of the state to undertake this exercise, which was a pre-condition for
the exercise of the enabling power to make reservations in promotions and to provide for
consequential seniority.
72 The decision in B K Pavitra I did not restrain the state from carrying out the exercise of collecting
quantifiable data so as to fulfil the conditionalities for the exercise of the enabling power under
Article 16 (4A). The legislature has the plenary power to enact a law. That power extends to enacting
a legislation both with prospective and retrospective effect. Where a law has been invalidated by the
decision of a constitutional court, the legislature can amend the law retrospectively or enact a law
which removes the cause for invalidation. A legislature cannot overrule a decision of the court on the
ground that it is erroneous or is nullity. But, it is certainly open to the legislature either to amend an
existing law or to enact a law which removes the basis on which a declaration of invalidity was
issued in the exercise of judicial review. Curative legislation is constitutionally permissible. It is not
an encroachment on judicial power. In the present case, state legislature of Karnataka, by enacting
the Reservation Act 2018, has not nullified the judicial decision in B K Pavitra I, but taken care to
remedy the underlying cause which led to a declaration of invalidity in the first place. Such a law is
valid because it removes the basis of the decision. PART E 73 These principles have consistently
been reiterated in a line of precedents emerging from this Court. In Utkal Contractors and Joinery
(P) Ltd, this Court held:
―15. …The legislature may, at any time, in exercise of the plenary power conferred on
it by Articles 245 and 246 of the Constitution render a judicial decision ineffective by
enacting a valid law. There is no prohibition against retrospective legislation. The
power of the legislature to pass a law postulates the power to pass it prospectively as
well as retrospectively. That of course, is subject to the legislative competence and
subject to other constitutional limitations. The rendering ineffective of judgments or
orders of competent courts by changing their basis by legislative enactment is a
well-known pattern of all validating acts. Such validating legislation which removes
the causes of ineffectiveness or invalidity of action or proceedings cannot be
considered as encroachment on judicial power. The legislature, however, cannot by a
bare declaration, without more, directly overrule, reverse or set aside any judicial
decision…91 (See also in this context : Bhubaneshwar Singh v Union of India92,
Indian Aluminium Co v State of Kerala93 (―Indian Aluminium Co), Narain Singh94
and Cheviti Venkanna Yadav).
74 The legislature has the power to validate a law which is found to be invalid by curing the
infirmity. As an incident of the exercise of this power, the legislature may enact a validating law toB.K. Pavitra vs Union Of India on 10 May, 2019

make the provisions of the earlier law effective from the date on which it was enacted (The United
Provinces v Mst Atiqa Begum95 Supra 74 at page 759 (1994) 6 SCC 77 (1996) 7 SCC 637 (2009) 13
SCC 165 AIR 1941 FC 16 PART E and Rai Ramkrishna v State of Bihar96). These principles were
elucidated in the decision of this Court in Prithvi Cotton Mills Ltd. The judgment makes a
distinction between a law which simply declares that a decision of the court will not bind (which is
impermissible for the legislature) and a law which fundamentally alters the basis of an earlier
legislation so that the decision would not have been given in the altered circumstances. This
distinction is elaborated in the following extract:
―4. … Granted legislative competence, it is not sufficient to declare merely that the
decision of the Court shall not bind for that is tantamount to reversing the decision in
exercise of judicial power which the Legislature does not possess or exercise. A
court's decision must always bind unless the conditions on which it is based are so
fundamentally altered that the decision could not have been given in the altered
circumstances. Ordinarily, a court holds a tax to be invalidly imposed because the
power to tax is wanting or the statute or the rules or both are invalid or do not
sufficiently create the jurisdiction. Validation of a tax so declared illegal may be done
only if the grounds of illegality or invalidity are capable of being removed and are in
fact removed and the tax thus made legal.97
75 In State of T N v Arooran Sugars Ltd98, a Constitution Bench of this Court recognized the power
of the legislature to enact a law retrospectively to cure a defect found by the Court. It was held that
in doing so, the legislature did not nullify a writ or encroach upon judicial power. The legislature in
remedying a deficiency in the law acted within the scope of its authority. This Court held:
―16…It is open to the legislature to remove the defect pointed out by the court or to
amend the definition or any other provision of the Act in question retrospectively. In
this process it cannot be said that there has been an encroachment by the (1964) 1
SCR 897 Supra 55 at pages 286-287 (1997) 1 SCC 326 PART E legislature over the
power of the judiciary. A court‘s directive must always bind unless the conditions on
which it is based are so fundamentally altered that under altered circumstances such
decisions could not have been given. This will include removal of the defect in a
statute pointed out in the judgment in question, as well as alteration or substitution
of provisions of the enactment on which such judgment is based, with retrospective
effect.99 The same principle was formulated in the decision of this Court in
Virender Singh Hooda v State of Haryana100:
―59. …vested rights can be taken away by retrospective legislation by removing the
basis of a judgment so long as the amendment does not violate the fundamental
rights. We are unable to accept the broad proposition… that the effect of the writs
issued by the courts cannot be nullified by the legislature by enacting a law with
retrospective effect. The question, in fact, is not of nullifying the effect of writs which
may be issued by the High Court or this Court. The question is of removing the basis
which resulted in issue of such a writ. If the basis is nullified by enactment of a validB.K. Pavitra vs Union Of India on 10 May, 2019

legislation which has the effect of depriving a person of the benefit accrued under a
writ, the denial of such benefit is incidental to the power to enact a legislation with
retrospective effect. Such an exercise of power cannot be held to be usurpation of
judicial power…101
76 A declaration by a court that a law is constitutionally invalid does not fetter the authority of the
legislature to remedy the basis on which the declaration was issued by curing the grounds for
invalidity. While curing the defect, it is essential to understand the reasons underlying the
declaration of invalidity. The reasons constitute the basis of the declaration. The legislature cannot
simply override the declaration of invalidity without remedying the basis on which the law was held
to be ultra vires. A law may have been held to be invalid on the ground that the Ibid at page 340
(2004) 12 SCC 588 Ibid at page 616 PART E legislature which enacted the law had no legislative
competence on the subject matter of the legislation. Obviously, in such a case, a legislature which
has been held to lack legislative competence cannot arrogate to itself competence over a subject
matter over which it has been held to lack legislative competence. However, a legislature which has
the legislative competence to enact a law on the subject can certainly step in and enact a legislation
on a field over which it possesses legislative competence. For instance, where a law has been
invalidated on the ground that the state legislature lacks legislative competence to enact a law on a
particular subject – Parliament being conferred with legislative competence over the same subject –
it is open for the Parliament, following a declaration of the invalidity of the state law, to enact a new
law and to regulate the area. As an incident of its validating exercise, Parliament may validate the
collection of a levy under the earlier law. The collection of a levy under a law which has been held to
be invalid is validated by the enactment of legislation by a legislative body – Parliament in the above
example – which has competence over the subject matter. Apart from legislative competence, a law
may have been declared invalid on the ground that there was a breach of the fundamental rights
contained in Part III of the Constitution. In that situation, if the legislature proceeds to enact a new
law on the subject, the issue in essence is whether the re-enacted law has taken care to remove the
infractions of the fundamental rights on the basis of which the earlier law was held to be invalid. The
true test therefore is whether the legislature has acted within the bounds of its authority to remedy
the basis on which the earlier law was held to suffer from a constitutional infirmity.
PART E 77 The petitioners have placed a considerable degree of reliance on the decision in Madan
Mohan Pathak, where a law – The Life Insurance Corporation (Modification of Settlements) Act
1976 was enacted by Parliament to render ineffective a settlement which was arrived at between LIC
and its employees for the payment of bonus. The law was challenged by the employees. In that case,
there was a judgment of the Calcutta High Court which had given effect to the right of the employees
to an annual cash bonus under an industrial settlement, by the issuance of a writ of mandamus. The
mandamus bound the parties to the dispute. It was in this backdrop that the Constitution Bench
observed that the effect of the mandamus issued by the High Court could not simply be nullified by
enacting a law overriding the industrial settlement. This Court held:
―9...Here the judgment given by the Calcutta High Court, which is relied upon by the
petitioners, is not a mere declaratory judgment holding an impost or tax to be invalid,
so that a validation statute can remove the defect pointed out by the judgmentB.K. Pavitra vs Union Of India on 10 May, 2019

amending the law with retrospective effect and validate such impost or tax. But it is a
judgment giving effect to the right of the petitioners to annual cash bonus under the
Settlement by issuing a writ of mandamus directing the Life Insurance Corporation
to pay the amount of such bonus. If by reason of retrospective alteration of the factual
or legal situation, the judgment is rendered erroneous, the remedy may be by way of
appeal or review, but so long as the judgment stands, it cannot be disregarded or
ignored and it must be obeyed by the Life Insurance Corporation. We are, therefore,
of the view that, in any event, irrespective of whether the impugned Act is
constitutionally valid or not, the Life Insurance Corporation is bound to obey the writ
of mandamus issued by the Calcutta High Court and to pay annual cash bonus for the
year April 1, 1975 to March 31, 1976 to Class III and Class IV employees.102 Supra
56 at page 67 PART E
78 The decision in Madan Mohan Pathak is hence distinguishable from the facts of the present case.
The above observations recognized the constitutional position that in the case of a declaratory
judgment holding an action to be invalid, a validating legislation to remove the defect is permissible.
Applying this principle, it is evident that the decision in B K Pavitra I declared the Reservation Act
2002 to be invalid and consequent upon the declaration of invalidity, certain directions were issued.
If the basis on which Reservation Act 2002 was held to be invalid is cured by a validating legislation,
in this case the Reservation Act 2018, this would constitute a permissible legislative exercise. The
grounds which weighed in Madan Mohan Pathak would hence not be available in the present case.
79 The decision in Madan Mohan Pathak has been adverted to and clarified in several decisions of
this Court rendered subsequently. These include:
(i) Sri Ranga Match Industries v Union of India103, where it was held that:
―14. While appreciating the ratio of the said opinions, it is necessary to bear in mind
the basic fact that the settlement between the Corporation and its employees was not
based upon any statute or statutory provision. Sub-sections (1) and (3) of Section 18
of the Industrial Disputes Act provide merely the binding nature of such settlements;
they do not constitute the basis of the settlements. The settlement between the
parties was directed to be implemented by the High Court. In other words, it was not
a case where the High Court either struck down a statutory provision nor was it a case
where a statutory provision was interpreted in a particular manner or directed to be
implemented. It was also not a case where the statutory provision, on which the
judgment was based, was amended or altered to remove/rectify the defect.104
(Emphasis supplied) 1994 Supp. (2) SCC 726 Ibid at pages 736-737 PART E
(ii) Indian Aluminium Co, where it was held that:
―49. In Madan Mohan Pathak v. Union of India (1978) 2 SCC 50 : 1978 SCC (L&S)
103 : (1978) 3 SCR 334]… From the observations made by Bhagwati, J. per majority,
it is clear that this Court did not intend to lay down that Parliament, under no
circumstance, has power to amend the law removing the vice pointed out by theB.K. Pavitra vs Union Of India on 10 May, 2019

court.
Equally, the observation of Chief Justice Beg is to be understood in the context that as long as the
effect of mandamus issued by the court is not legally and constitutionally made ineffective, the State
is bound to obey the directions. Thus understood, it is unexceptionable. But it does not mean that
the learned Chief Justice intended to lay down the law that mandamus issued by court cannot at all
be made ineffective by a valid law made by the legislature, removing the defect pointed out by the
court.105 (Emphasis supplied)
(iii) Agricultural Income Tax Officer v Goodricke Group Ltd106, where it was held:
―14. We are of the view that Madan Mohan Pathak case [(1978) 2 SCC 50 : 1978 SCC
(L&S) 103 : (1978) 3 SCR 334] would not apply to the facts in the present case for the
simple reason that what has been undone by Section 4-B and Section 78-C is not a
mandamus issued by a superior court. What is undone is the very basis of the
judgment in Buxa Dooars Tea Co. Ltd. case[(1989) 3 SCC 211 : 1989 SCC (Tax) 394]
by retrospectively changing the levy of rural employment cess and education
cess.107 (Emphasis supplied)
80 Madan Mohan Pathak involved a situation where a parliamentary law was enacted to override a
mandamus which was issued by the High Court for the Supra 93 at page 660 (2015) 8 SCC 399 Ibid
at page 407 PART E payment of bonus under an industrial settlement. The case did not involve a
situation where a law was held to be ultra vires and the basis of the declaration of invalidity of the
law was sought to be cured.
81 Dr Dhavan adverted to the legal basis of B K Pavitra I as set out in the following extract from the
conclusion:
―30. In view of the above, we allow these appeals, set aside the impugned judgment
and declare the provisions of the impugned Act to the extent of doing away with the
‗catch-up‘ rule and providing for consequential seniority under Sections 3 and 4 to
persons belonging to SCs and STs on promotion against roster points to be ultra vires
Articles 14 and 16 of the Constitution.108 Dr Dhavan is entirely correct, if we may
say so with respect, in submitting ―that what has to be shown is whether the
Reservation Act 2018 is, in law Articles 14 and 16 compliant. This necessitates an
examination of the constitutionality of the Reservation Act 2018. That would require
this Court to examine the challenge on the ground that there has been a violation of
the equality code contained in Articles 14 and 16.
E.I Is the basis of B K Pavitra I cured in enacting the Reservation Act 82 The Statement of Objects
and Reasons of the Reservation Act 2018 refers to the legislative history preceding its enactment.
The Ratna Prabha Committee Supra 5 at page 641 PART E was constituted after the Reservation Act
2002 was held to be invalid in B K Pavitra I on the ground that no compelling necessity had been
shown by the state to provide for reservation in matters of promotion for SCs and STs by collectingB.K. Pavitra vs Union Of India on 10 May, 2019

and analysing relevant data to satisfy the requirements laid out in Nagaraj. The constitution of the
Ratna Prabha Committee was consequent upon the Reservation Act 2002 having been held to be
invalid in B K Pavitra I. 83 The Statement of Objects and Reasons is extracted below, insofar as it is
material:
―The Hon‘ble Supreme Court of India in its judgment dated:
09.02.2017 in the case of BK Pavitra and others Vs Union of India and others in Civil
Appeal No. 2368 of 2011 and connected matters while dealing with the issue of
consequential seniority provided to the Scheduled Castes and Scheduled Tribes,
having regard to the ratio of the decision of the Constitution Bench in M.Nagaraj in
Writ Petition No. 61 of 2002 has observed that a proper exercise for determining
‗inadequacy of representation‘ ‗backwardness‘ and ‗overall efficiency‘ is a must for
exercise of power under Article 16 (4A). The court held that in the absence of this
exercise under Article 16 (4A) it is the ―catch-up rule that shall be applicable.
Having observed this the Court declared the provisions of Sections 3 and 4 of the Karnataka Act 10
of 2002 to be ultra vires of Articles 14 and 16 of the Constitution. The Hon‘ble Supreme Court
directed that revision of the Seniority lists be undertaken and completed within three months and
further consequential action be taken within the next three months; In order to comply with the
directions of the Hon‘ble Supreme Court in BK Pavitra and others vs Union of India and others in
Civil Appeal No. 2368 of 2011 the Government has issued order vide Government order No. DPAR
182 SRR 2011 dated 06.05.2017 to all appointing authorities to revise the seniority lists;
While in compliance of the Supreme Court order, the Government considering the need and taking
note of the decision of the Constitution Bench in M Nagaraj, in Writ Petition No. 61 of 2002, has
entrusted the task of conducting study and submitting a report on the backwardness of the PART E
Scheduled Castes and Scheduled Tribes in the state, inadequacy of their representation in the State
Civil Services and the effect of reservation in promotion on the State administration, to the
Additional Chief Secretary to Government in Government order No. DPAR 182 SRR 2011 dated
22.03.2017;
The Additional Chief Secretary to Government with the assistance of officers from various
departments has collated the scientific, quantifiable and relevant data collected and having made a
detailed study of quantifiable data has submitted a report on backwardness of Scheduled Castes and
Scheduled Tribes in the state, inadequacy of their representation in the State Civil Services and the
effect of reservation in promotion on the State administration to the State Government;
The report confirms the backwardness of the Scheduled Castes and Scheduled Tribes in the state,
inadequacy of their representation in the State Civil Services and that the overall efficiency of
administration has not been affected or hampered by extending reservation in promotion to the
Scheduled Castes and Scheduled Tribes in the state and continuance of reservation in promotion
within the limits will not affect or hamper overall efficiency of administration; 84 The first
principle of statutory interpretation guides us towards the view that undoubtedly, the Statement ofB.K. Pavitra vs Union Of India on 10 May, 2019

Objects and Reasons:
(i) Cannot be used for restricting the plain meaning of a legislation109;
(ii) Cannot determine whether a provision is valid110; and
(iii) May not be definitive of the circumstances in which it was passed111.
[See in this context Welfare Association v Ranjit112]. Bhaiji v Sub-Divisional Officer, Thandla :
(2003) 1 SCC 692 at page 700, A Manjula Bhashini v A P Monen‘s Coor. Finance Corp. Ltd. : (2009)
8 SCC 431 at paras 34, 40 Kerala State (Electricity) Board v Indian Aluminum : (1976) 1 SCC 466 K S
Paripoornan v State of Kerala : (1994) 5 SCC 593 (2003) 9 SCC 358 PART E 85 The preamble to a
law may be a statutory aid to consider the mischief which the law seeks to address. While it cannot
prevail over the provisions of the statute, it can be an aid to resolve an ambiguity113. 86 In the
course of his submissions, Dr Dhavan has emphasized the ―new provisions contained in the
Reservation Act 2018. These according to him, are:
(i) Section 2 (d) which defines ‗backlog‘;
(ii) Section 5 under which the appointing authority is to revise and redraw the
existing seniority lists;
(iii) Section 7 which deals with the power to remove difficulties;
(iv) Section 8 which provides for the repeal of the Reservation Act 2002; and
(v) Section 9 which is a validating provision.
87 The essential issue which now needs to be addressed by this Court is whether the basis of the
decision in B K Pavitra I has been cured. The decision of the Constitution Bench in Nagaraj
mandates that before the State can take recourse to the enabling power contained in Clauses (4A)
and (4B) of Article 16, it must demonstrate the existence of ―compelling reasons on three facets: (i)
backwardness; (ii) inadequacy of representation; and (iii) overall administrative efficiency. In
Jarnail, the Constitution Bench clarified that the first of the above factors – ―backwardness has no
application in the case of reservations for the SCs and STs. Nagaraj to that extent was held to be
contrary to the decision of the larger Bench in Indra Sawhney.
Burrakur Coal Co. Ltd. v Union of India : AIR 1961 SC 954 at pages 956-957 PART E E.2 The Ratna
Prabha Committee report 88 The decision in B K Pavitra I was rendered on 9 February 2017. The
Ratna Prabha Committee was established on 22 March 2017. Its report was examined by a Cabinet
Sub-Committee on 4 August 2017 and was eventually approved by the Cabinet on 7 August 2017.
The Ratna Prabha Committee report was commissioned to : (i) collect information on cadre wise
representation of SC and ST employees in all government departments; (ii) collect information on
backwardness of SCs and STs; and (iii) study the effect on the administration due to the promotionB.K. Pavitra vs Union Of India on 10 May, 2019

of SCs and STs.
89 Dr Dhavan‘s challenge to the report is basically founded on the following features:
(i) Only thirty one out of sixty two government departments were examined;
(ii) No data was collected for public sector undertakings, boards, corporations, local
bodies, grant-in-aid institutions and autonomous bodies;
(iii) In PWD and KPTCL, the representation is excessive;
(iv) The data is vacancy based and not post based as required by Sabharwal;
(v) The data is on sanctioned posts and not of filled posts;
(vi) The data is based on grades A, B, C and D and not cadre based; and
(vii) On efficiency, there is only a general reference to the economic development of
the State of Karnataka.
90 Based on the above features, the petitioners have invoked the power of judicial review. Dr
Dhavan emphasized that the decision in Nagaraj upheld the constitutional validity of successive
constitutional amendments to Article 16 PART E conditional upon the existence of compelling
reasons which must be demonstrated by the State by collecting and analysing relevant data. It is
submitted that the flaws in the report of the Ratna Prabha Committee would indicate that the
compelling reasons which constitute the foundation for the exercise of the enabling power contained
in Article 16 are absent, which must result in the invalidation of the Reservation Act 2018. 91 Before
we deal with the merits of the attack on the Ratna Prabha Committee report, it is necessary to set
down the parameters on which judicial review can be exercised. Essentially, the exercise which the
petitioners require this Court to undertake is to scrutinize the underlying collection of data by the
State on two facets laid out in Nagaraj, as now clarified by Jarnail: (i) the adequacy of
representation; and (ii) impact on efficiency in administration. Clause (4) of Article 16 contains an
enabling provision to empower the State to make reservations in appointments or posts in favour of
any backward class of citizens ―which, in the opinion of the State, is not adequately represented in
the services under the State. Clause (4A) contains an enabling provision that allows the state to
provide for reservations in promotion with consequential seniority in posts or classes of posts in
services under the State in favour of SCs and STs. Clause (4A) also uses the expression ―which, in
the opinion of the State, are not adequately represented in the services under the State. In Indra
Sawhney, while construing the nature of the satisfaction which has to be arrived at by the State, this
Court held:
PART E ―798….The language of clause (4) makes it clear that the question whether a
backward class of citizens is not adequately represented in the services under the
State is a matter within the subjective satisfaction of the State. This is evident fromB.K. Pavitra vs Union Of India on 10 May, 2019

the fact that the said requirement is preceded by the words ―in the opinion of the
State. This opinion can be formed by the State on its own, i.e., on the basis of the
material it has in its possession already or it may gather such material through a
Commission/Committee, person or authority. All that is required is, there must be
some material upon which the opinion is formed. Indeed, in this matter the court
should show due deference to the opinion of the State, which in the present context
means the executive. The executive is supposed to know the existing conditions in the
society, drawn as it is from among the representatives of the people in
Parliament/Legislature. It does not, however, mean that the opinion formed is
beyond judicial scrutiny altogether. The scope and reach of judicial scrutiny in
matters within subjective satisfaction of the executive are well and extensively stated
in Barium Chemicals v. Company Law Board [1966 Supp SCR 311 : AIR 1967 SC 295]
which need not be repeated here. Suffice it to mention that the said principles apply
equally in the case of a constitutional provision like Article 16 (4) which expressly
places the particular fact (inadequate representation) within the subjective judgment
of the State/executive.114 (Emphasis supplied) The above extract from the decision
in Indra Sawhney presents two mutually complementary and reinforcing principles.
The first principle is that the executive arm of the state is aware of prevailing
conditions. The legislature represents the collective will of the people through their
elected representatives. The presumption of constitutionality of a law enacted by a
competent legislature traces itself to the fundamental doctrine of constitutional
jurisprudence that the legislature is accountable to those who elect their
representatives. Collectively, the executive and the legislature are entrusted with the
constitutional duty to Supra 13 at page 728 PART E protect social welfare. This Court
explained in Amalgamated Tea Estates Co Ltd v State of Kerala115, the rationale for
the principles of constitutionality:
―11.The reason why a statute is presumed to be constitutional is that the Legislature
is the best judge of the local conditions and circumstances and special needs of
various classes of persons. ―(T)he Legislature is the best judge of the needs of
particular classes and to estimate the degree of evil so as to adjust its legislation
according to the exigency found to exist.116 This principle was reiterated in V C
Shukla v State (Delhi Administration)117:
―11…Furthermore, the legislature which is in the best position to understand the
needs and requirements of the people must be given sufficient latitude for making
selection or differentiation and so long as such a selection is not arbitrary and has a
rational basis having regard to the object of the Act, Article 14 would not be attracted.
That is why this Court has laid down that presumption is always in favour of the
constitutionality of an enactment and the onus lies upon the person who attacks the
statute to show that there has been an infraction of the constitutional concept of
equality.118
92 More recently, this was emphasized in State of Himachal Pradesh v Satpal Saini119:B.K. Pavitra vs Union Of India on 10 May, 2019

―12…The duty to formulate policies is entrusted to the executive whose accountability
is to the legislature and, through it, to the people. The peril of adopting an incorrect
policy lies in democratic accountability to the people…120 (1974) 4 SCC 415 Ibid at
page 420 (1980) Supp SCC 249 Ibid at page 259 (2017) 11 SCC 42 Ibid at page 47
PART E
93 The second of the reinforcing principles which emerges from Indra Sawhney is that the opinion
of the government on the adequacy of representation of the SCs and STs in the public services of the
state is a matter which forms a part of the subjective satisfaction of the state. Significantly, the
extract from Indra Sawhney reproduced earlier adverts to the decision in Barium Chemicals Ltd,
which emphasises that when an authority is vested with the power to form an opinion, it is not open
for the court to substitute its own opinion for that of the authority, nor can the opinion of the
authority be challenged on grounds of propriety or sufficiency. In Nagaraj, while dealing with the
parameters governing the assessment of the adequacy of representation or of the impact on
efficiency, the Constitution Bench held:
―45… The basic presumption, however, remains that it is the State who is in the best
position to define and measure merit in whatever ways it consider it to be relevant to
public employment because ultimately it has to bear the costs arising from errors in
defining and measuring merit. Similarly, the concept of ―extent of reservation is not
an absolute concept and like merit it is context-specific.
…
49. Reservation is necessary for transcending caste and not for perpetuating it.
Reservation has to be used in a limited sense otherwise it will perpetuate casteism in
the country.
Reservation is underwritten by a special justification. Equality in Article 16(1) is individual-specific
whereas reservation in Article 16 (4) and Article 16(4A) is enabling. The discretion of the State is,
however, subject to the existence of ―backwardness and ―inadequacy of representation in public
employment. Backwardness has to be based on objective factors whereas inadequacy has to factually
exist. This is where judicial review comes in. However, whether reservation in a given case is
desirable or not, as a policy, is not for us to decide as long as the parameters mentioned in Articles
16 (4) and 16 (4A) are maintained. As stated above, equity, justice and merit (Article PART E
335)/efficiency are variables which can only be identified and measured by the State.
… 102…equity, justice and efficiency are variable factors. These factors are context-specific. There is
no fixed yardstick to identify and measure these three factors, it will depend on the facts and
circumstances of each case.121 (Emphasis supplied) 94 The element of discretion vested in the
state governments to determine adequacy of representation in promotional posts is once again
emphasized in the following extract from the decision in Jarnail:B.K. Pavitra vs Union Of India on 10 May, 2019

―35…According to us, Nagaraj has wisely left the test for determining adequacy of
representation in promotional posts to the States for the simple reason that as the
post gets higher, it may be necessary, even if a proportionality test to the population
as a whole is taken into account, to reduce the number of Scheduled Castes and
Scheduled Tribes in promotional pots, as one goes upwards. This is for the simple
reason that efficiency of administration has to be looked at every time promotions are
made. As has been pointed out by B P Jeevan Reddy, J.‘s judgment in Indra Sawhney,
there may be certain posts right at the top, where reservation is impermissible
altogether. For this reason, we make it clear that Article 16 (4A) has been couched in
language which would leave it to the States to determine adequate representation
depending upon the promotional post that is in question.122 (Emphasis supplied)
95 In dealing with the submissions of the petitioners on this aspect, it is relevant for this Court to
recognize the circumspection with which judicial power must be exercised on matters which pertain
to propriety and sufficiency, in the context of scrutinizing the underlying collection of data by the
State on the adequacy of representation and impact on efficiency. The Court, is above all, Supra 6 at
pages 249-250 Supra 49 at page 430 PART E considering the validity of a law which was enacted by
the State legislature for enforcing the substantive right to equality for the SCs and STs. Judicial
review must hence traverse conventional categories by determining as to whether the Ratna Prabha
Committee report considered material which was irrelevant or extraneous or had drawn a
conclusion which no reasonable body of persons could have adopted. In this area, the fact that an
alternate line of approach was possible or may even appear to be desirable cannot furnish a
foundation for the assumption by the court of a decision making authority which in the legislative
sphere is entrusted to the legislating body and in the administrative sphere to the executive arm of
the government.
96 On the inadequacy of representation, the summary which emerges from the Ratna Prabha
Committee report is as follows:
―2.5: Summary:
1) The analysis of time series data collected for the last 32 years (1984-2016 except
for 1986) across 31 Departments of the State Government provides the rich
information on the inadequacy of representation of SCs and STs employees in various
cadres of Karnataka Civil Services.
2) The total number of sanctioned posts as per the data of 2016 is 7,45,593 of which
70.22 percent or 5,23,574 are filled up across 31 Departments.
3) The vacancies or posts are filled up through Direct Recruitment (DR) and
Promotions including consequential promotion.
4) The overall representation of the SC and ST employees of all 31 Departments in
comparison with total sanctioned posts comprises of 10.65 per cent and 2.92 per centB.K. Pavitra vs Union Of India on 10 May, 2019

respectively. This proves inadequacy of representation of SCs and STs.
5) On an average the representation in Cadre A for SCs is at 12.07 per cent and STs
2.70 per cent which sufficiently proves the inadequacy of representation.
6) The extent of representation in Cadre B is on an average of 9.79 per cent and 2.34 per cent for ST
for all the years of the study period.
PART E
7) It is observed that on an average 3.05 per cent of SC representation is inadequate in the Cadre ‗C‘
whereas, 0.05 per cent excess representation is seen for ST.
8) On an average of 2 per cent and 1 per cent over representation of employees of SCs and STs is
found in Cadre D respectively. However, in the last 5 years, inadequacy of representation of SCs by 3
per cent is found in this cadre.
9) The representation of Scheduled Caste in Cadre A, B and C is on an average 12, 9.79 and 12.04 per
cent respectively whereas in Cadre D it is 16.91.
10) In case of STs in the cadres A and B the representation is 2.70 and 2.34 per cent. However,
excess representation of 0.04 and 0.93 per cent is found in case of Group C and Group D
respectively.
11) Over representation in some years and departments is attributed to either Direct Recruitment or
retirement of employees or filling up of backlog vacancies as the later does not fall under 50 per cent
limitation of reservation. 2.6: Conclusion:
The data clearly shows the inadequacy of representation of SCs and STs in the civil
services in Groups A, B and C and adequate representation in Group D. 97
Collection of data and its analysis are governed by varying and often divergent
approaches in the social sciences. An informative treatise on the subject titled
Empirical Political Analysis – Quantitative and Qualitative Research Methods123
distinguishes between obtaining knowledge and using knowledge. The text seeks to
explain empirical analysis on the one hand and normative analysis on the other hand:
―Social Scientists distinguish between obtaining knowledge and using knowledge.
Dealing with factual realities is termed empirical analysis. Dealing with how we
should use our knowledge of the world is termed normative analysis.
Empirical analysis is concerned with developing and using a common, objective
language to describe and explain reality. It can be quantitative or qualitative.
Quantitative analyses are based on math-based comparisons of the Ninth edition,
Richard C Rich, Craig Leonard Brians, Jarol B Manheim and Lars B Willnat,B.K. Pavitra vs Union Of India on 10 May, 2019

Longman Publishers PART E characteristics of the various objects or events that we
study. Qualitative analyses are based on the researcher‘s informed and contextual
understanding of objects or events.
Normative analysis is concerned with developing and examining subjective values
and ethical rules to guide us in judging and applying what we have learned about
reality. Although the emphasis in this book is on empirical analysis, it seeks to
develop an appreciation of the larger, normative perspective within which knowledge
is acquired, interpreted, and applied through a discussion of the ethics of research.
Normative analysis without an empirical foundation can lead to value judgments that
are out of touch with reality. Empirical analysis in the absence of sensitivity to
normative concerns, on the other hand, can lead to the collection of observations
whose significance we are not prepared to understand fully. The objective in
undertaking political inquiry is to draw upon both types of analysis – empirical and
normative – so as to maximize not only our factual knowledge, but also our ability to
use the facts we discover wisely. 98 In supporting the methodology which has been
adopted by the Ratna Prabha Committee, Ms Indira Jaising, learned Senior Counsel
emphasized that:
(i) Save and except where a national census is proposed to be conducted, data
collection is based on valid sampling methods on which conclusions are drawn;
(ii) Research methodology can be qualitative as well as quantitative – the present
case deals with the collection of quantitative data;
(iii) Quantitative data is also collected on the basis of sample surveys. In this case, the
purpose of the study was to collect data on the adequacy of representation in
promotional posts and the sample which was chosen was a representative sample
from which conclusions were drawn; and PART E
(iv) In the study conducted by the State of Karnataka, statistics of a number of
persons belonging to the SCs and STs in promotional posts were collected group wise.
The groups include cadres. Hence, it stands to reason that if the data is collected in
relation to a group, it will include data pertaining to cadres as well since, every cadre
within the group has been statistically enquired.
99 We find merit in the above submissions. The methodology which was adopted by the Ratna
Prabha Committee has not been demonstrated to be alien to conventional social science
methodologies. We are unable to find that the Committee has based its conclusions on any
extraneous or irrelevant material. In adopting recourse to sampling methodologies, the Committee
cannot be held to have acted arbitrarily. If, as we have held above, sampling is a valid methodology
for collection of data, the necessary consequence is that the exercise cannot be invalidated only on
the ground that data pertaining to a particular department or of some entities was not analysed. TheB.K. Pavitra vs Union Of India on 10 May, 2019

data which was collected pertained to thirty one departments which are representative in character.
The State has analysed the data which is both relevant and representative, before drawing its
conclusions. As we have noted earlier, there are limitations on the power of judicial review in
entering upon a factual arena involving the gathering, collation and analysis of data.
100 Dr Dhavan has painstakingly compiled charts for the purpose of his argument. We may also
note at this stage that Ms Jaising in response to the charts relied upon by Dr Dhavan, also placed on
records charts indicating:
PART E
(i) Current representation after demotion of SC and ST employees in the PWD of
Karnataka;
(ii) Percentage of SCs and STs in the post of Executive Engineer without
consequential seniority in the PWD; and
(iii) Corresponding figures in the post of Executive Engineer without consequential
seniority in the PWD.
101 We are of the view that once an opinion has been formed by the State government on the basis
of the report submitted by an expert committee which collected, collated and analysed relevant data,
it is impossible for the Court to hold that the compelling reasons which Nagaraj requires the State to
demonstrate have not been established. Even if there were to be some errors in data collection, that
will not justify the invalidation of a law which the competent legislature was within its power to
enact. After the decision in B K Pavitra I, the Ratna Prabha Committee was correctly appointed to
carry out the required exercise. Once that exercise has been carried out, the Court must be
circumspect in exercising the power of judicial review to re-evaluate the factual material on record.
102 The adequacy of representation has to be assessed with reference to a benchmark on adequacy.
Conventionally, the State and the Central governments have linked the percentage of reservation for
the SCs and STs to their percentage of population, as a measure of adequacy. The Constitution
Bench noticed this in Sabharwal, where it observed:
PART E ―4. When a percentage of reservation is fixed in respect of a particular cadre
and the roster indicates the reserve points, it has to be taken that the posts shown at
the reserve points are to be filled from amongst the members of reserve categories
and the candidates belonging to the general category are not entitled to be considered
for the reserved posts. On the other hand the reserve category candidates can
compete for the non-reserve posts and in the event of their appointment to the said
posts their number cannot be added and taken into consideration for working out the
percentage of reservation. Article 16 (4) of the Constitution of India permits the State
Government to make any provision for the reservation of appointments or posts in
favour of any Backward Class of citizens which, in the opinion of the State is notB.K. Pavitra vs Union Of India on 10 May, 2019

adequately represented in the Services under the State. It is, therefore, incumbent on
the State Government to reach a conclusion that the Backward Class/Classes for
which the reservation is made is not adequately represented in the State Services.
While doing so the State Government may take the total population of a particular
Backward Class and its representation in the State Services. When the State
Government after doing the necessary exercise makes the reservation and provides
the extent of percentage of posts to be reserved for the said Backward Class then the
percentage has to be followed strictly. The prescribed percentage cannot be varied or
changed simply because some of the members of the Backward Class have already
been appointed/promoted against the general seats. As mentioned above the roster
point which is reserved for a Backward Class has to be filled by way of
appointment/promotion of the member of the said class. No general category
candidate can be appointed against a slot in the roster which is reserved for the
Backward Class…124 Explaining this further, the Constitution Bench held:
―5...Once the prescribed percentage of posts is filled the numerical test of adequacy is
satisfied and thereafter the roster does not survive. The percentage of reservation is
the desired representation of the Backward Classes in the State Services and is
consistent with the demographic estimate based on the proportion worked out in
relation to their population. The numerical quota of posts is not a shifting boundary
but represents a figure with due application of mind. Therefore, the only way to
assure equality of opportunity to the Backward Classes and the general category is to
permit Supra 24 at page 750 PART E the roster to operate till the time the respective
appointees/promotees occupy the posts meant for them in the roster…125
Consequently, it is open to the State to make reservation in promotion for SCs and
STs proportionate to their representation in the general population.
103 One of the submissions which has been urged on behalf of the petitioners is that the quota has
to be reckoned with reference to posts which are actually filled up or the working strength and not
with reference to sanctioned posts. This submission is answered by the decision in Sabharwal, which
holds that the percentage of reservation has to be worked out in relation to the number of posts
which form part of the cadre strength. The Constitution Bench held:
―6. The expressions ‗posts‘ and ‗vacancies‘, often used in the executive instructions
providing for reservations, are rather problematical. The word ‗post‘ means an
appointment, job, office or employment. A position to which a person is appointed.
‗Vacancy‘ means an unoccupied post or office. The plain meaning of the two
expressions make it clear that there must be a ‗post‘ in existence to enable the
‗vacancy‘ to occur. The cadre-strength is always measured by the number of posts
comprising the cadre. Right to be considered for appointment can only be claimed in
respect of a post in a cadre. As a consequence the percentage of reservation has to be
worked out in relation to the number of posts which form the cadre- strength. The
concept of „vacancy has no relevance in operating the percentage of
reservation.126 (Emphasis supplied) Ibid at page 751 Ibid at pages 751-752 PART EB.K. Pavitra vs Union Of India on 10 May, 2019

Similarly, in Nagaraj, the Constitution Bench held:
―83. In our view, the appropriate Government has to apply the cadre strength as a
unit in the operation of the roster in order to ascertain whether a given class/group is
adequately represented in the service. The cadre strength as a unit also ensures that
upper ceiling limit of 50% is not violated. Further, roster has to be post-specific and
not vacancy based.127 Hence, the submission that the quota must be reckoned on
the basis of the posts which are actually filled up and not the sanctioned posts cannot
be accepted.
104 We find no merit in the challenge to the Ratna Prabha Committee report on the ground that the
collection of data was on the basis of groups A, B, C and D as opposed to cadres. For one thing, the
expression ‗cadre‘ has no fixed meaning ascribed to it in service jurisprudence. But that apart,
Nagaraj requires the collection of quantifiable data inter alia, on the inadequacy of representation in
services under the state. Clause 4A of Article 16 specifically refers to the inadequacy of
representation in the services under the state. The collection of data on the basis of groups A to D
does not by its very nature exclude data pertaining to cadres. The state has studied in the present
case the extent of reservation for SCs and STs in groups A to D, consisting of several cadres. Since,
the group includes posts in all the cadres in that group, it can logically be presumed that the state
has collected quantifiable data on the representation of SCs and STs in promotional posts in the
cadres as well.
Supra 6 at page 261 PART F 105 Another facet of the matter is that in the judgment of Justice
Jeevan Reddy in Indra Sawhney, it was observed that reservation under Article 16 (4) does not
operate on communal grounds. Hence, if a member belonging to a reserved category is selected in
the general category, the selection would not count against the quota prescribed for the reserved
category. The decision in Sabharwal also noted that while candidates belonging to the general
category are not entitled to fill reserved posts, reserved category candidates are entitled to compete
for posts in the general category. In several group D posts, such as municipal sweepers, the sobering
experience of administration is that the overwhelmingly large segment of applicants consists of
persons belonging to the SCs and STs. Over representation in group D posts as a result of candidates
belonging to the general category staying away from those posts cannot be a valid or logical basis to
deny promotion to group D employees recruited from the reserved category.
F Substantive versus formal equality 106 The core of the present case is based on the constitutional
content of equality.
107 For equality to be truly effective or substantive, the principle must recognise existing
inequalities in society to overcome them. Reservations are thus not an exception to the rule of
equality of opportunity. They are rather the true fulfilment of effective and substantive equality by
accounting for the PART F structural conditions into which people are born. If Article 16(1) merely
postulates the principle of formal equality of opportunity, then Article 16(4) (by enabling
reservations due to existing inequalities) becomes an exception to the strict rule of formal equality in
Article 16 (1). However, if Article 16 (1) itself sets out the principle of substantive equality (includingB.K. Pavitra vs Union Of India on 10 May, 2019

the recognition of existing inequalities) then Article 16 (4) becomes the enunciation of one particular
facet of the rule of substantive equality set out in Article 16 (1).
F.I The Constituent Assemblys understanding of Article 16 (4) (I) Reservations to overcome
existing inequalities in society
(a) There is substantial evidence that the members of the Constituent Assembly recognised that (i)
Indian society suffered from deep structural inequalities; and (ii) the Constitution would serve as a
transformative document to overcome them. One method of overcoming these inequalities is
reservations for the SCs and STs in the legislatures and state services. Therefore, for the members of
the Constituent Assembly who supported reservations, a key rationale for incorporating reservations
for SCs and STs in the Constitution was the existence of inequalities in society based on
discrimination and prejudice within the caste structure. This is evidenced by the statements in
support of reservations for minorities by members. For example, in the context of legislative
reservations for minorities Monomohan Das noted:
―… Therefore, it is evident from the Report of the Minorities Committee that it is on
account of the extremely low educational and economic conditions of the scheduled
castes and the grievous social disabilities from which they suffer that PART F the
political safeguard of reservation of seats had been granted to them...128
(b) Prof. Yashwant Rai used similar statements to support reservations for backward
communities in employment:
―… Therefore, if you want to give equal status to those communities which are
backward and depressed and on whom injustice has been perpetrated for thousands
of years and if you want to establish Indian unity, so that the country may progress
and so that many parties in the country may not mislead the poor, I would say that
there should be a provision in the constitution under which the educated Harijans
may be provided with employment….129 (Emphasis supplied) (II) Recognition of
the insufficiency of formal equality by the Constituent Assembly
108 During the debates on the principles of equality underlying Article 16 (then draft Article 10),
certain members of the Assembly recognised that in order to give true effect to the principle of
equality of opportunity, the Constitution had to expressly recognise the existing inequalities. For
example, Shri Phool Singh noted:
―… Much has been made of merit in this case; but equal merit pre-supposes equal
opportunity, and I think it goes without saying that the toiling masses are denied all
those opportunities which a few literate people living in big cities enjoy. To ask the
people from the villages to compete with those city people is asking a man on bicycle
to compete with another on a motorcycle, which in itself is (Volume XI) Debate on 25
August 1949.B.K. Pavitra vs Union Of India on 10 May, 2019

(Volume XI) Debate on 23 August 1949.
PART F absurd. Then again, merit should also have some reference to the task to be
discharged…130 (Emphasis supplied) Similarly, P Kakkam stated, ―… If you take
merit alone into account, the Harijans cannot come forward. I say in this house, that
the Government must take special steps for the reservation of appointment for the
Harijans for same years. I expect the government will take the necessary steps to give
more appointments in police and military services also...131 (Emphasis supplied)
109 By recognising that formal equality of opportunity will be insufficient in fulfilling the
transformative goal of the Constitution, these members recognised that the conception of equality of
opportunity must recognise and account for existing societal inequalities. The most revealing
debates as to how the Constituent Assembly understood equality of opportunity under the
Constitution took place on 30 November 1948. Members debated draft article 10 (which would go
on to become Article 16 of the Constitution). In these debates, some members understood
sub-clause (4) (providing for reservations) as an exception to the general rule of formal equality
enunciated in sub-clause (1). Illustratively, an articulation of this position was made by Mohammad
Ismail Khan, who stated, ―… There can be only one of these two things--either there can be clear
equal opportunity or special consideration. Article 10 says there shall be equality of opportunity,
then it emphasises the fact by a negative clause that no citizen shall be discriminated on account of
religion or race. It is quite good, but when no indication is given whether this would override article
296 or article 296 is independent of it, we are certainly left in the lurch. What would be the fate of
the minorities? [Article 296 stated that special (Volume XI) Debate on 23 August 1949.
(Volume VII) Debate on 30 May 1948.
PART F considerations shall be shown to minorities to ensure representation in the services]…132
(Emphasis supplied) 110 Dr B R Ambedkar‘s response summarises the different conceptions of
equality of opportunity that the members of the assembly put forward. Dr Ambedkar argued that the
inclusion of sub-clause (4) was a method of recognising the demand that mere formal equality in
sub-clause (1) would be insufficient, and a balance between formal equality of opportunity and the
needs of the disadvantaged classes of society was needed. Dr Ambedkar presciently observed:
―… If members were to try and exchange their views on this subject, they will find
that there are three points of view which it is necessary for us to reconcile if we are to
produce a workable proposition which will be accepted by all… The first is that there
shall be equality of opportunity for all citizens. It is the desire of many Members of
this House that every individual who is qualified for a particular post should be free
to apply for that post, to sit for examinations and to have his qualifications tested so
as to determine whether he is fit for the post or not and that there ought to be no
limitations… Another view mostly shared by a section of the House is that, if this
principle is to be operative--and it ought to be operative in their judgment to its
fullest extent--there ought to be no reservations of any sort for any class or
community at all… Then we have quite a massive opinion which insists that, althoughB.K. Pavitra vs Union Of India on 10 May, 2019

theoretically it is good to have the principle that there shall be equality of
opportunity, there must at the same time be a provision made for the entry of certain
communities which have so far been outside the administration. As I said, the
Drafting Committee had to produce a formula which would reconcile these three
points of view, firstly, that there shall be equality of opportunity, secondly that there
shall be reservations in favour of certain communities which have not so far had a
`proper look-in' so to say into the administration… (Volume VII) Debate on 30 May
1948.
PART F The view of those who believe and hold that there shall be equality of
opportunity, has been embodied in sub-clause (1) of Article 10. It is a generic
principle. At the same time, as I said, we had to reconcile this formula with the
demand made by certain communities that the administration which has now--for
historical reasons--
been controlled by one community or a few communities, that situation should disappear and that
the others also must have an opportunity of getting into the public services…133 (Emphasis
supplied) F.2 The Constitution as a transformative instrument 111 The Constitution is a
transformative document. The realization of its transformative potential rests ultimately in its
ability to breathe life and meaning into its abstract concepts. For, above all, the Constitution was
intended by its draftspersons to be a significant instrument of bringing about social change in a
caste based feudal society witnessed by centuries of oppression of and discrimination against the
marginalised. As our constitutional jurisprudence has evolved, the realisation of the transformative
potential of the Constitution has been founded on the evolution of equality away from its formal
underpinnings to its substantive potential.
112 In the context of reservations, the decision in T Devadasan v The Union of India134 construed
Article 16 (4) to be a proviso or an exception to Article 16 (1). In a dissent which embodied a vision
statement of the Constitution, Justice Subba Rao held:
―26. Article 14 lays down the general rule of equality. Article 16 is an instance of the
application of the general rule with (Volume VII) Debate on 30 May 1948.
AIR 1964 SC 179 PART F special reference to opportunity of appointments under the State. It says
that there shall be equality of opportunity for all citizens in matters relating to employment or
appointment to any office under the State… Centuries of calculated oppression and habitual
submission reduced a considerable section of our community to a life of serfdom. It would be well
nigh impossible to raise their standards if the doctrine of equal opportunity was strictly enforced in
their case. They would not have any chance if they were made to enter the open field of competition
without adventitious aids till such time when they could stand on their own legs. That is why the
makers of the Constitution introduced clause (4) in Article 16. The expression ―nothing in this
article is a legislative device to express its intention in a most emphatic way that the power
conferred thereunder is not limited in any way by the main provision but falls outside it. It has not
really carved out an exception, but has preserved a power untrammelled by the other provisions ofB.K. Pavitra vs Union Of India on 10 May, 2019

the article. 113 Subsequently, in N M Thomas, the Constitution Bench adopted an interpretation of
Articles 15 and 16 which recognized these provisions as but a facet of the doctrine of equality under
Article 14. Justice K K Mathew observed:
―78…Article 16(4) is capable of being interpreted as an exception to Article 16(1) if
the equality of opportunity visualized in Article 16(1) is a sterile one, geared to the
concept of numerical equality which takes no account of the social, economic,
educational background of the members of Scheduled Castes and Scheduled Tribes.
If equality of opportunity guaranteed under Article 16 (1) means effective material
equality, then Article 16(4) is not an exception to Article 16(1). It is only an emphatic
way of putting the extent to which equality of opportunity could be carried viz., even
up to the point of making reservation.135 In his own distinctive style, Justice
Krishna Iyer observed:
―139. It is platitudinous constitutional law that Articles 14 to 16 are a common code
of guaranteed equality, the first laying down the broad doctrine, the other two
applying it to sensitive Supra 77 at page 347 PART F areas historically important and
politically polemical in a climate of communalism and jobbery.136 This court has
set out this latter understanding in several cases including ABS Sangh (Railways) v
Union of India137.
114 Ultimately, a Bench of nine judges of this Court in Indra Sawhney recognized that Article 16 (4)
is not an exception to but a facet of equality in Article 16 (1). Justice Jeevan Reddy delivering the
judgment of a plurality of four judges observed:
―741…Article 16(4) is not an exception to Article 16(1) but that it is only an emphatic
way of stating the principle inherent in the main provision itself...
In our respectful opinion, the view taken by the majority in Thomas [(1976) 2 SCC
310, 380 : 1976 SCC (L&S) 227 :
(1976) 1 SCR 906] is the correct one. We too believe that Article 16(1) does permit
reasonable classification for ensuring attainment of the equality of opportunity
assured by it.138
115 Justice Mathew in N M Thomas spoke of the need for proportional equality as a means of
achieving justice. Highlighting the notion that equality under the Constitution is based on the
substantive idea of providing equal access to resources and opportunities, learned judge observed:
―73. There is no reason why this Court should not also require the State to adopt a
standard of proportional equality which takes account of the differing conditions and
circumstances of a class of citizens whenever those conditions and Ibid at page 369
(1981) 1 SCC 246 Supra 13 at page 691 PART G circumstances stand in the way of
their equal access to the enjoyment of basic rights or claims.139 Carrying theseB.K. Pavitra vs Union Of India on 10 May, 2019

precepts further Justice S H Kapadia (as the learned judge then was) speaking for the
Constitution Bench in Nagaraj observed:
―51…Therefore, there are three criteria to judge the basis of distribution, namely,
rights, deserts or need. These three criteria can be put under two concepts of
equality— ―formal equality and ―proportional equality. ―Formal equality means
that law treats everyone equal and does not favour anyone either because he belongs
to the advantaged section of the society or to the disadvantaged section of the society.
Concept of ―proportional equality expects the States to take affirmative action in
favour of disadvantaged sections of the society within the framework of liberal
democracy.140 Social justice, in other words, is a matter involving the distribution
of benefits and burdens.
G          Efficiency in administration
116        Critics of affirmative action programs in government services argue that
such programs adversely impact the overall competence or ―efficiency of
government administration. Critics contend that the only method to ensure
―efficiency in the administration of government is to use a ―merit based approach
– whereby candidates that fulfil more, seemingly ―neutral, criteria than others are
given opportunities in government services. The constitutional justification for this
―efficiency argument is centred around Article 335.
Supra 77 at page 346 Supra 6 at page 250 PART G ―335. The claims of the members
of the Scheduled Castes and the Scheduled Tribes shall be taken into consideration,
consistently with the maintenance of efficiency of administration, in the making of
appointments to services and posts in connection with the affairs of the Union or of a
State:
[Provided that nothing in this article shall prevent in making of any provision in
favour of the members of the Scheduled Castes and the Scheduled Tribes for
relaxation in qualifying marks in any examination or lowering the standards of
evaluation, for reservation in matters of promotion to any class or classes of services
or posts in connection with the affairs of the Union or of a State.]. The proviso was
inserted by the Constitution (Eighty-second Amendment) Act 2000.
117 The substantive part of Article 335 contains a mandate : a requirement to take
into consideration the claims of SCs and STs in making appointments to services and
posts in connection with the affairs of the Union or of a State.
Consideration is much broader in its ambit than reservation. The consideration of their claims to
appointment is to be in a manner consistent with maintaining the efficiency of administration. The
proviso specifically protects provisions in favour of the SCs and STs for: (i) relaxing qualifying marksB.K. Pavitra vs Union Of India on 10 May, 2019

in an examination; (ii) lowering the standards of evaluation; or (iii) reservation in matters of
promotion. Reservation is encompassed within the special provision but the universe of the latter is
wider.
118 The proviso recognises that special measures need to be adopted for considering the claims of
SCs and STs in order to bring them to a level playing PART G field. Centuries of discrimination and
prejudice suffered by the SCs and STs in a feudal, caste oriented societal structure poses real
barriers of access to opportunity. The proviso contains a realistic recognition that unless special
measures are adopted for the SCs and STs, the mandate of the Constitution for the consideration of
their claim to appointment will remain illusory. The proviso, in other words, is an aid of fostering
the real and substantive right to equality to the SCs and STs. It protects the authority of the Union
and the States to adopt any of these special measures, to effectuate a realistic (as opposed to a
formal) consideration of their claims to appointment in services and posts under the Union and the
states. The proviso is not a qualification to the substantive part of Article 335 but it embodies a
substantive effort to realise substantive equality. The proviso also emphasises that the need to
maintain the efficiency of administration cannot be construed as a fetter on adopting these special
measures designed to uplift and protect the welfare of the SCs and STs. 119 The Constitution does
not define what the framers meant by the phrase ―efficiency of administration. Article 335 cannot
be construed on the basis of a stereotypical assumption that roster point promotees drawn from the
SCs and STs are not efficient or that efficiency is reduced by appointing them. This is stereotypical
because it masks deep rooted social prejudice. The benchmark for the efficiency of administration is
not some disembodied, abstract ideal measured by the performance of a qualified open category
candidate. Efficiency of administration in the affairs of the Union or of a State must be defined in an
inclusive sense, where diverse segments of society find representation as a true PART G aspiration
of governance by and for the people. If, as we hold, the Constitution mandates realisation of
substantive equality in the engagement of the fundamental rights with the directive principles,
inclusion together with the recognition of the plurality and diversity of the nation constitutes a valid
constitutional basis for defining efficiency. Our benchmarks will define our outcomes. If this
benchmark of efficiency is grounded in exclusion, it will produce a pattern of governance which is
skewed against the marginalised. If this benchmark of efficiency is grounded in equal access, our
outcomes will reflect the commitment of the Constitution to produce a just social order. Otherwise,
our past will haunt the inability of our society to move away from being deeply unequal to one which
is founded on liberty and fraternity. Hence, while interpreting Article 335, it is necessary to liberate
the concept of efficiency from a one sided approach which ignores the need for and the positive
effects of the inclusion of diverse segments of society on the efficiency of administration of the
Union or of a State. Establishing the position of the SCs and STs as worthy participants in affairs of
governance is intrinsic to an equal citizenship. Equal citizenship recognizes governance which is
inclusive but also ensures that those segments of our society which have suffered a history of
prejudice, discrimination and oppression have a real voice in governance. Since inclusion is
inseparable from a well governed society, there is, in our view, no antithesis between maintaining
the efficiency of administration and considering the claims of the SCs and STs to appointments to
services and posts in connection with the affairs of the Union or of a State.B.K. Pavitra vs Union Of India on 10 May, 2019

PART G 120 This part of the philosophy of the Constitution was emphasized in a powerful
exposition contained in the judgment of Justice O Chinnappa Reddy in K C Vasanth Kumar v State
of Karnataka141 (―K C Vasanth Kumar). The learned Judge held:
―35. One of the results of the superior, elitist approach is that the question of
reservation is invariably viewed as the conflict between the meritarian principle and
the compensatory principle. No, it is not so. The real conflict is between the class of
people, who have never been in or who have already moved out of the desert of
poverty, illiteracy and backwardness and are entrenched in the oasis of convenient
living and those who are still in the desert and want to reach the oasis. There is not
enough fruit in the garden and so those who are in, want to keep out those who are
out. The disastrous consequences of the so-called meritarian principle to the vast
majority of the under-nourished, poverty-stricken, barely literate and vulnerable
people of our country are too obvious to be stated. And, what is merit? There is no
merit in a system which brings about such consequences…142 Speaking of
efficiency, the learned Judge held:
―36. Efficiency is very much on the lips of the privileged whenever reservation is
mentioned… One would think that the civil service is a Heavenly Paradise into which
only the archangels, the chosen of the elite, the very best may enter and may be
allowed to go higher up the ladder. But the truth is otherwise. The truth is that the
civil service is no paradise and the upper echelons belonging to the chosen classes are
not necessarily models of efficiency. The underlying assumption that those belonging
to the upper castes and classes, who are appointed to the non-reserved posts will,
because of their presumed merit, ―naturally perform better than those who have
been appointed to the reserved posts and that the clear stream of efficiency will be
polluted by the infiltration of the latter into the sacred precincts is a vicious
assumption, typical of the superior approach of the elitist classes…143 (1985) Supp.
SCC 714 Ibid at pages 737-738 Ibid at page 738 PART G
121 The substantive right to equality is for all segments of society. Articles 15 (4) and 16 (4)
represent the constitutional aspiration to ameliorate the conditions of the SCs and STs. While, we
are conscious of the fact that the decision in Indra Sawhney did not accept K C Vasanth Kumar144
on certain aspects, the observations have been cited by us to explain the substantive relationship
between equal opportunity and merit. It embodies the fundamental philosophy of the Constitution
towards advancing substantive equality. 122 An assumption implicit in the critique of reservations is
that awarding opportunities in government services based on “merit” results in an increase in
administrative efficiency. Firstly, it must be noted that administrative efficiency is an outcome of the
actions taken by officials after they have been appointed or promoted and is not tied to the selection
method itself. The argument that one selection method produces officials capable of taking better
actions than a second method must be empirically proven based on an evaluation of the outcomes
produced by officials selected through both methods. Secondly, arguments that attack reservations
on the grounds of efficiency equate ―merit with candidates who perform better than other
candidates on seemingly ―neutral criteria, e.g. standardised examinations. Thus, candidates whoB.K. Pavitra vs Union Of India on 10 May, 2019

score beyond a particular ―cut-off point are considered ―meritorious and others are
―non-meritorious. However, this is a distorted understanding of the function ―merit plays in
society.
Supra 139 at paragraph 613 PART G 123 As Amartya Sen notes in his chapter on ―Merit and
Justice, 145 the idea of merit is fundamentally derivative of our views of a good society. Sen notes,
―Actions may be rewarded for the good they do, and a system of remunerating the activities that
generate good consequences would, it is presumed, tend to produce a better society. The rationale of
incentive structures may be more complex than this simple statement suggests, but the idea of merit
in this instrumental perspective relates to the motivation of producing better results. In this view,
actions are meritorious in a derivative and contingent way, depending on the good they do, and
more particularly, the good that can be brought about by rewarding them…. …The concept of merit
is deeply contingent on our views of a good society. Indeed, the notion of merit is fundamentally
derivative, and thus cannot be qualified and contingent. There is some elementary tension between
(1) the inclination to see merit in fixed and absolute terms, and (2) the ultimately instrumental
character of merit – its dependence on the concept of “the good” in the relevant society.
This basic contrast is made more intense by the tendency, in practice, to characterise ―merit in
inflexible forms reflecting values and priorities of the past, often in sharp conflict with conceptions
that would be needed for seeing merit in the context of contemporary objectives and concerns…
Even though the typical “objective functions” that are implicitly invoked in most countries to define
and assess what is to count as merit tend to be indifferent to (or negligent of) distributive aspects of
outcomes, there is no necessity to accept that ad hoc characterisation. This is not a matter of a
“natural order” of “merit” that is independent of our value system…. (Emphasis supplied) 124 Once
we understand ―merit as instrumental in achieving goods that we as a society value, we see that the
equation of ―merit with performance at a few narrowly defined criteria is incomplete. A
meritocratic system is one that rewards actions that result in the outcomes that we as a society
value.
Sen A, Merit and Justice, in Arrow, KJ, MERITOCRACY AND ECONOMIC INEQUALITY (Princeton
University Press 2000) (Amartya Sen, Merit and Justice).
PART G 125 For example, performance in standardised examinations (distinguished from
administrative efficiency) now becomes one among many of the actions that the process of
appointments in government services seeks to achieve. Based on the text of Articles 335, Articles 16
(4), and 46, it is evident that the uplifting of the SCs and STs through employment in government
services, and having an inclusive government are other outcomes that the process of appointments
in government services seeks to achieve. Sen gives exactly such an example.
―If, for example, the conceptualisation of a good society includes the absence of serious economic
inequalities, then in the characterisation of instrumental goodness, including the assessment of
what counts as merit, note would have to be taken of the propensity of putative merit to lessen – or
to generate – economic inequality. In this case, the rewarding of merit cannot be done independent
of its distributive consequences.B.K. Pavitra vs Union Of India on 10 May, 2019

… A system of rewarding of merit may well generate inequalities of well-being and of other
advantages. But, as was argued earlier, much would depend on the nature of the consequences that
are sought, on the basis of which merits are to be characterised. If the results desired have a strong
distributive component, with a preference for equality, then in assessing merits (through judging the
generating results, including its distributive aspects), concerns about distribution and inequality
would enter the evaluation.146 (Emphasis supplied) Thus, the providing of reservations for SCs
and the STs is not at odds with the principle of meritocracy. ―Merit must not be limited to narrow
and inflexible criteria such as one‘s rank in a standardised exam, but rather must flow from the
actions a society seeks to reward, including the promotion of equality in society Ibid PART G and
diversity in public administration. In fact, Sen argues that there is a risk to excluding equality from
the outcomes.
―In most versions of modern meritocracy, however, the selected objectives tend to be almost
exclusively oriented towards aggregate achievements (without any preference against inequality),
and sometimes the objectives chosen are even biased (often implicitly) towards the interests of more
fortunate groups (favouring the outcomes that are more preferred by ―talented and ―successful
sections of the population. This can reinforce and augment the tendency towards inequality that
might be present even with an objective function that inter alia, attaches some weight to lower
inequality levels.147 (Emphasis supplied) 126 The Proviso to Article 335 of the Constitution seeks
to mitigate this risk by allowing for provisions to be made for relaxing the marks in qualifying exams
in the case of candidates from the SCs and the STs. If the government‘s sole consideration in
appointments was to appoint individuals who were considered ―talented or ―successful in
standardised examinations, by virtue of the inequality in access to resources and previous
educational training (existing inequalities in society), the stated constitutional goal of uplifting these
sections of society and having a diverse administration would be undermined. Thus, a
―meritorious candidate is not merely one who is ―talented or ―successful but also one whose
appointment fulfils the constitutional goals of uplifting members of the SCs and STs and ensuring a
diverse and representative administration.
Ibid PART G 127 It is well settled that existing inequalities in society can lead to a seemingly
―neutral system discriminating in favour of privileged candidates. As Marc Galanter notes, three
broad kinds of resources are necessary to produce the results in competitive exams that qualify as
indicators of ―merit. These are:
―… (a) economic resources (for prior education, training, materials, freedom from
work etc.); (b) social and cultural resources (networks of contacts, confidence,
guidance and advice, information, etc.); and (c) intrinsic ability and hard work...
148
128 The first two criteria are evidently not the products of a candidate‘s own efforts but rather the
structural conditions into which they are born. By the addition of upliftment of SCs and STs in the
moral compass of merit in government appointments and promotions, the Constitution mitigates
the risk that the lack of the first two criteria will perpetuate the structural inequalities existing in
society.B.K. Pavitra vs Union Of India on 10 May, 2019

129 The Ratna Prabha Committee report considers in Chapter III, the relationship between
reservation in promotion and maintenance of efficiency in administration. Finally, it concludes:
―3.12: Conclusion:
Karnataka has been showing high performance in all the sectors of development viz.,
finance, health, education, industry, services, etc., to support sustainable economic
growth. The analysis on performance of the state in economic development clearly
indicates that reservation in promotions has not affected the overall efficiency of
administration.
Galanter M, Competing Equalities: Law and the Backward Classes in India, (Oxford
University Press, New Delhi 1984), cited by Deshpande S, Inclusion versus
excellence: Caste and the framing of fair access in Indian higher education, 40:1
South African Review of Sociology 127-147.
PART H
130 Moreover, even in a formal legal sense, promotions, including those in respect of roster points,
are made on the basis of seniority-cum-merit and a candidate to be promoted has to meet this
criteria [See in this context Rule 19(3) A and D of the Karnataka Civil Services General Recruitment
Rules 1977 which states that subject to other provisions all appointments by promotion shall be on
an officiating basis for a period of one year and at the end of the period of officiation, if appointing
authority considers the person not suitable for promotion, she/he may be reverted back to the post
held prior to the promotion]. A candidate on promotion has to serve a statutory period of officiation
before being confirmed. This rule applies across the board including to roster point promotees. This
ensures that the efficiency of administration is, in any event, not adversely affected.
H The issue of creamy layer 131 At the outset, we analyse the submission of Ms Indira Jaising,
learned Senior Counsel that the concept of creamy layer is inapplicable to the SCs and STs. This
submission which has been urged by the learned Counsel is founded on two hypotheses which we
have extracted below from the written submissions:
―(i) This Court in Indra Sawhney seems to suggest that the creamy layer should be
excluded, however there was no unanimity for determining what is creamy layer.
Some judges took the view that the criteria for creamy layer exclusion is social
advancement (i.e. based on social basis, educational, and economical basis) and
others took the view that it will be economic basis alone. It is submitted that it must
be kept in mind that the said judgment related only to OBCs; and
(ii) Jarnail is not an authority for the proposition that the creamy layer principle
applies to SCs and STs. It dealt only PART H with the competence of the Parliament
to enact a law in relation to creamy layer without affecting Articles 341 andB.K. Pavitra vs Union Of India on 10 May, 2019

342.
132 Dr Dhavan, learned Senior Counsel in his response has urged that the above submissions are
incorrect because:
(i) Indra Sawhney decided the issue of creamy layer as a principle of equality;
and
(ii) Jarnail affirmed that if Nagaraj is rightly applied, creamy layer is a principle of equality and of
the basic structure.
133 Ms Jaising‘s argument is based on the decision in Chinnaiah that the SCs and STs cannot be
split or bifurcated and the adoption of the creamy layer principle would amount to a spilt in the
homogenous groups of the SCs and STs. This argument according to Dr Dhavan, was rejected in
Jarnail by the Constitution Bench.
134 As a Bench of two judges we are bound by the decision in Indra Sawhney as indeed, we are by
the construction placed on that decision by the Constitution Benches in Nagaraj and Jarnail.
Construing the decision in Indra Sawhney. Nagaraj held:
―120…Concept of egalitarian equality is the concept of proportional equality and it
expects the States to take affirmative action in favour of disadvantaged sections of
society within the framework of democratic polity. In Indra Sawhney [1992 Supp (3)
SCC 217 : 1992 SCC (L&S) Supp 1 : (1992) 22 ATC 385] all the Judges except Pandian,
J. held that the ―means test should be adopted to exclude the PART H creamy layer
from the protected group earmarked for reservation. In Indra Sawhney [1992 Supp
(3) SCC 217 :
1992 SCC (L&S) Supp 1 : (1992) 22 ATC 385] this Court has, therefore, accepted caste
as a determinant of backwardness and yet it has struck a balance with the principle of
secularism which is the basic feature of the Constitution by bringing in the concept of
creamy layer. Views have often been expressed in this Court that caste should not be
the determinant of backwardness and that the economic criteria alone should be the
determinant of backwardness. As stated above, we are bound by the decision in Indra
Sawhney [1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1 : (1992) 22 ATC 385] . The
question as to the ―determinant of backwardness cannot be gone into by us in view
of the binding decision. In addition to the above requirements this Court in Indra
Sawhney [1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1 : (1992) 22 ATC 385] has
evolved numerical benchmarks like ceiling limit of 50% based on post-specific roster
coupled with the concept of replacement to provide immunity against the charge of
discrimination.149 Then again, in paragraphs 121, 122 and 123, the Constitution
Bench held:B.K. Pavitra vs Union Of India on 10 May, 2019

―121. The impugned constitutional amendments by which Articles 16 (4A) and 16
(4B) have been inserted flow from Article 16(4). They do not alter the structure of
Article 16(4). They retain the controlling factors or the compelling reasons, namely,
backwardness and inadequacy of representation which enables the States to provide
for reservation keeping in mind the overall efficiency of the State administration
under Article 335. These impugned amendments are confined only to SCs and STs.
They do not obliterate any of the constitutional requirements, namely, ceiling limit of
50% (quantitative limitation), the concept of creamy layer (qualitative exclusion), the
sub-classification between OBCs on one hand and SCs and STs on the other hand as
held in Indra Sawhney [1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1 : (1992) 22
ATC 385] , the concept of post-based roster with inbuilt concept of replacement as
held in R.K. Sabharwa [(1995) 2 SCC 745 : 1995 SCC (L&S) 548 : (1995) 29 ATC 481] .
122. We reiterate that the ceiling limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
Supra 6 at pages 277-278 PART H administrative efficiency are all constitutional
requirements without which the structure of equality of opportunity in Article 16
would collapse.
123. However, in this case, as stated above, the main issue concerns the ―extent of
reservation. In this regard the State concerned will have to show in each case the
existence of the compelling reasons, namely, backwardness, inadequacy of
representation and overall administrative efficiency before making provision for
reservation. As stated above, the impugned provision is an enabling provision. The
State is not bound to make reservation for SCs/STs in matters of promotions.
However, if they wish to exercise their discretion and make such provision, the State
has to collect quantifiable data showing backwardness of the class and inadequacy of
representation of that class in public employment in addition to compliance with
Article 335. It is made clear that even if the State has compelling reasons, as stated
above, the State will have to see that its reservation provision does not lead to
excessiveness so as to breach the ceiling limit of 50% or obliterate the creamy layer or
extend the reservation indefinitely.150
135 The reference before the Constitution Bench in Jarnail arose out of an initial reference by a two
judge Bench in State of Tripura v Jayanta Chakraborty (―State of Tripura)151 and then by a three
judge Bench in State of Maharashtra v Vijay Ghogre152. The order in State of Tripura states:
―2…However, apart from the clamour for revisit, further questions were also raised
about application of the principle of creamy layer in situations of competing claims
within the same races, communities, groups or parts thereof of SC/STs notified by
the President under Articles 341 and 342 of the Constitution of India.153
136 Before the Constitution Bench in Jarnail, the learned Attorney General specifically raised the
following arguments:B.K. Pavitra vs Union Of India on 10 May, 2019

Ibid at pages 278 -280 (2018) 1 SCC 146 (2018) 15 SCC 64 Supra 149 at pages 147-148
PART H ―3…according to the learned Attorney General, the creamy layer concept has
not been applied in Indra Sawhney (1) [Indra Sawhney v. Union of India, 1992 Supp
(3) SCC 217 : 1992 SCC (L&S) Supp 1] to the Scheduled Castes and the Scheduled
Tribes and Nagaraj [M. Nagaraj v. Union of India, (2006) 8 SCC 212 : (2007) 1 SCC
(L&S) 1013] has misread the aforesaid judgment to apply this concept to the
Scheduled Castes and the Scheduled Tribes. According to the learned Attorney
General, once the Scheduled Castes and the Scheduled Tribes have been set out in the
Presidential List, they shall be deemed to be Scheduled Castes and Scheduled Tribes,
and the said List cannot be altered by anybody except Parliament under Articles 341
and 342. The learned Attorney General also argued that Nagaraj [M. Nagaraj v.
Union of India, (2006) 8 SCC 212 : (2007) 1 SCC (L&S) 1013] does not indicate any
test for determining adequacy of representation in service. According to him, it is
important that we lay down that the test be the test of proportion of Scheduled Castes
and Scheduled Tribes to the population in India at all stages of promotion, and for
this purpose, the roster that has been referred to in R.K. Sabharwal v. State of Punjab
[R.K. Sabharwal v. State of Punjab, (1995) 2 SCC 745 : 1995 SCC (L&S) 548] can be
utilised. Other counsel who argued, apart from the learned Attorney General, have,
with certain nuances, reiterated the same arguments.154 The decision in Jarnail
specifically addressed the issue of creamy layer:
―28. Therefore, when Nagaraj [M. Nagaraj v. Union of India, (2006) 8 SCC 212 :
(2007) 1 SCC (L&S) 1013] applied the creamy layer test to Scheduled Castes and
Scheduled Tribes in exercise of application of the basic structure test to uphold the
constitutional amendments leading to Articles 16 (4A) and 16 (4B), it did not in any
manner interfere with Parliament's power under Article 341 or Article 342. We are,
therefore, clearly of the opinion that this part of the judgment does not need to be
revisited, and consequently, there is no need to refer Nagaraj [M. Nagaraj v. Union of
India, (2006) 8 SCC 212 : (2007) 1 SCC (L&S) 1013] to a seven-Judge Bench. We may
also add at this juncture that Nagaraj [M. Nagaraj v. Union of India, (2006) 8 SCC
212 : (2007) 1 SCC (L&S) 1013] is a unanimous judgment of five learned Judges of
this Court which has held sway since the year 2006. This judgment has been
repeatedly followed and applied…155 Supra 49 at pages 407-408 Ibid at page 426
PART H Justice Rohinton Nariman speaking for the Constitution Bench in Jarnail
explained the reason for applying the creamy layer principle:
―25. However, when it comes to the creamy layer principle, it is important to note
that this principle sounds in Articles 14 and 16 (1), as unequals within the same class
are being treated equally with other members of that class.
137 We are thus unable to subscribe to the submission that Jarnail is not per curium on the issue of
creamy layer. For one thing, Jarnail specifically examined the decision in Indra Sawhney, noticing
that eight of the nine learned Judges applied the creamy layer principle as a facet of the larger
equality principle. In fact, the decision in Indra Sawhney II v Union of India156 (―Indra SawhneyB.K. Pavitra vs Union Of India on 10 May, 2019

II) summarised the judgments in Indra Sawhney I on the aspect of creamy layer. The judgment in
Jarnail approved Indra Sawhney II when it held that the creamy layer principle sounds in Articles 14
and 16 (1):
―12. In para 27 of the said judgment, the three-Judge Bench of this Court clearly held
that the creamy layer principle sounds in Articles 14 and 16(1) as follows: [Indra
Sawhney (2) case [Indra Sawhney (2) v. Union of India, (2000) 1 SCC 168 : 2000 SCC
(L&S) 1] , SCC p. 190, para 27] ―(i) Equals and unequals, twin aspects
27. As the ―creamy layer in the backward class is to be treated ―on a par with the
forward classes and is not entitled to benefits of reservation, it is obvious that if the
―creamy layer is not excluded, there will be discrimination and violation of Articles
14 and 16(1) inasmuch as equals (forwards and creamy layer of Backward Classes)
cannot be treated unequally.
Again, non-exclusion of creamy layer will also be violative of Articles 14, 16(1) and 16(4) of the
Constitution of India since unequals (the creamy layer) cannot be treated as equals, that is to say,
equal to the rest of the backward class… (2000)1 SCC 168 PART H Thus, any executive or legislative
action refusing to exclude the creamy layer from the benefits of reservation will be violative of
Articles 14 and 16(1) and also of Article 16(4). We shall examine the validity of Sections 3, 4 and 6 in
the light of the above principle. (emphasis in original)157 Jarnail discussed the decision in
Chinnaiah and held that it dealt with the lack of legislative competence on the part of the State
legislatures to create sub- categories among the Presidential lists under Articles 341 and 342. The
decision in Jarnail therefore held that Chinnaiah did not deal with any of the aspects on which the
constitutional amendments were upheld in Nagaraj and hence it was not necessary for Nagaraj to
refer to Chinnaiah at all. In this view of the matter, we are clearly of the view that Jarnail, on a
construction of Indra Sawhney holds that the creamy layer principle is a principle of equality. 138
Though, we have not accepted the above submission which was urged by Ms Jaising on behalf of the
intervenors, we will have to decide as to whether the Reservation Act 2018 is unconstitutional. The
challenge in the present case is to the validity of the Reservation Act 2018 which provides for
consequential seniority. In other words, the nature or extent of reservation granted to the SCs and
STs at the entry level in appointment is not under challenge. The Reservation Act 2018 adopts the
principle that consequential seniority is not an additional benefit but a consequence of the
promotion which is granted to the SCs and STs. In protecting consequential seniority as an incident
of promotion, the Reservation Act 2018 constitutes an exercise of the enabling power conferred by
Article 16 (4A). The concept of creamy layer has no relevance to the grant of Supra 49 at page 415
PART H consequential seniority. There is merit in the submission of the State of Karnataka that
progression in a cadre based on promotion cannot be treated as the acquisition of creamy layer
status. The decision in Jarnail rejected the submission that a member of an SC or ST who reaches a
higher post no longer has a taint of untouchability or backwardness. The Constitution Bench
declined to accept the submission on the ground that it related to the validity of Article 16 (4A) and
held thus:B.K. Pavitra vs Union Of India on 10 May, 2019

―34…We may hasten to add that Shri Dwivedi‘s argument cannot be confused with
the concept of ―creamy layer which, as has been pointed out by us hereinabove,
applies to persons within the Scheduled Castes or the Scheduled Tribes who no
longer require reservation, as opposed to posts beyond the entry stage, which may be
occupied by members of the Scheduled Castes or the Scheduled Tribes.158
(Emphasis supplied)
139 In sustaining the validity of Articles 16 (4A) and 16 (4B) against a challenge of violating the basic
structure, Nagaraj applied the test of width and the test of identity. The Constitution Bench ruled
that the catch-up rule and consequential seniority are not constitutional requirements. They were
held not to be implicit in clauses (1) to (4) of Article 16. Nagaraj held that they are not constitutional
limitations or principles but are concepts derived from service jurisprudence. Hence, neither the
obliteration of those concepts nor their insertion would violate the equality code contained in
Articles 14, 15 and 16. The principle postulated in Nagaraj is that consequential seniority is a concept
purely based in service jurisprudence. The incorporation of consequential seniority would hence not
violate the constitutional mandate of equality. This being the true Supra 49 at page 430 PART I
constitutional position, the protection of consequential seniority as an incident of promotion does
not require the application of the creamy layer test. Articles 16 (4A) and 16 (4B) were held to not
obliterate any of the constitutional limitations and to fulfil the width test. In the above view of the
matter, it is evident that the concept of creamy layer has no application in assessing the validity of
the Reservation Act 2018 which is designed to protect consequential seniority upon promotion of
persons belonging to the SCs and STs.
I       Retrospectivity
140     Sections 3 and 4 of the Reservation Act 2018 came into force on 17 June
1995. The other provisions came into force ―at once as provided in Section 1(2). Section 4
stipulates that the consequential seniority already granted to government servants belonging to the
SCs and STs in accordance with the reservation order with effect from 27 April 1978 shall be valid
and shall be protected. In this context, we must note from the earlier decisions of this Court that:
(i) The decision in Virpal Singh held that the catch-up rule would be applied only
from 10 February 1995 which was the date of the judgment in Sabharwal;
(ii) The decision in Ajit Singh II specifically protected the promotions which were
granted before 1 March 1996 without following the catch-up rule; and PART J
(iii) In Badappanavar, promotions of reserved candidates based on consequential
seniority which took place before 1 March 1996 were specifically protected.
141 Since promotions granted prior to 1 March 1996 were protected, it was logical for the legislature
to protect consequential seniority. The object of the Reservation Act 2018 is to accord consequential
seniority to promotees against roster points. In this view of the matter, we find no reason to holdB.K. Pavitra vs Union Of India on 10 May, 2019

that the provisions in regard to retrospectivity in the Ratna Prabha Committee report are either
arbitrary or unconstitutional.
142 The benefit of consequential seniority has been extended from the date of the Reservation Order
1978 under which promotions based on reservation were accorded.
J          Over representation in KPTCL and PWD
143        The Ratna Prabha Committee collected data from thirty one departments
of the State Government of Karnataka. It has been pointed out on behalf of the State that
corporations such as KPTCL and other public sector undertakings fall within the administrative
control of one of the departments of the State government. The position in thirty one departments
was taken as representative of the position in public employment under the State. The over
representation in KPTCL and PWD has been projected by the petitioners with reference to the total
number of posts which have been filled. On the other hand, the quota is fixed and the roster applies
as regards the total sanctioned posts as held in Sabharwal and PART K Nagaraj. On the contrary, the
data submitted by the State of Karnataka indicates that if consequential seniority is not allowed,
there would be under representation of the reserved categories. Finally, it may also be noted that
under the Government Order dated 13 April 1999, reservation in promotion in favour of SC‘s and
ST‘s has been provided until the representation for these categories reaches 15 per cent and 3 per
cent, respectively. The State has informed the Court that the above Government Order is applicable
to KPTCL and PWD, as well.
K Conclusion 144 For the above reasons, we have come to the conclusion that the challenge to the
constitutional validity of the Reservation Act 2018 is lacking in substance. Following the decision in
B K Pavitra I, the State government duly carried out the exercise of collating and analysing data on
the compelling factors adverted to by the Constitution Bench in Nagaraj. The Reservation Act 2018
has cured the deficiency which was noticed by B K Pavitra I in respect of the Reservation Act 2002.
The Reservation Act 2018 does not amount to a usurpation of judicial power by the state legislature.
It is Nagaraj and Jarnail compliant. The Reservation Act 2018 is a valid exercise of the enabling
power conferred by Article 16 (4A) of the Constitution.
145 We therefore find no merit in the batch of writ petitions as the constitutional validity of the
Reservation Act 2018 has been upheld. They shall stand dismissed. Accordingly, the review petitions
and miscellaneous applications shall PART K also stand dismissed in view of the judgment in the
present case. There shall be no order as to costs. All pending applications are disposed of. 146 Before
concluding, the Court records its appreciation of the erudite submissions of the learned Counsel who
have ably assisted the Court. We deeply value the assistance rendered by Dr Rajeev Dhavan and Mr
Shekhar Naphade, learned Senior Counsel and Mr Puneet Jain, learned Counsel who led the
arguments on behalf of the Petitioners. We acknowledge the valuable assistance rendered to the
Court by Ms Indira Jaising, Mr Basava Prabhu S Patil, Mr Dinesh Dwivedi, Mr Nidhesh Gupta and
Mr V Lakshminarayana, learned Senior Counsel.B.K. Pavitra vs Union Of India on 10 May, 2019

…...…..…....…........……………….…........J. [Uday Umesh Lalit] .…….……...…...….......………………........J.
[Dr Dhananjaya Y Chandrachud] New Delhi;
May 10, 2019.B.K. Pavitra vs Union Of India on 10 May, 2019

