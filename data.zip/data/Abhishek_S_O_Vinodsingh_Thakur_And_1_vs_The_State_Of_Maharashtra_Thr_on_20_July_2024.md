Abhishek S/O Vinodsingh Thakur And 1 vs The State Of
Maharashtra Thr. ... on 20 July, 2024
2024:BHC-NAG:7717
                                                                                                                                          253 ba529.24
                                                                                    1
                    IN THE HIGH COURT OF JUDICATURE AT BOMBAY,
                               NAGPUR BENCH, NAGPUR
                            CRIMINAL APPLICATION (BA) NO.529/2024
                              Abhishek s/o Vinodsingh Thakur and anr
                                                ..vs..
               State of Maharashtra, through Investigating Officer, EOW, Crime Branch,
                                             Chandrapur
        ...................................................................................................................................................................................................
        Office Notes, Office Memoranda of Coram,
        appearances, Court orders or directions                                                            Court's or Judge's Order
        and Registrar's orders
        ...................................................................................................................................................................................................
                             Shri Shyam Dewani, Counsel with Shri Nitin Lalwani, Adv. for Applicants.
                             Shri D.V.Chauhan, Public Prosecutor for the State.
                             Shri Kartik Shukul, Counsel with Shri R.A.Bhandarkar, Adv. to Assist the Prosecution.
                             CORAM : URMILA JOSHI-PHALKE, J.
CLOSED ON : 05/07/2024 PRONOUNCED ON : 20/07/2024
1. By this application, being moved under Section 439 of the Code of Criminal Procedure, applicants
seek regular bail in connection with Crime No.937/2023 registered with the non- applicant/police
station for offences punishable under Sections 420, 406, and 409 read with 34 of the Indian Penal
Code.
2. The applicants came to be arrested on 4.4.2024 and since then they are in jail.
3. The applicants are partners of partnership firm namely "Wild Connectivity Solution" (the WCS).
"The Tadoba Andhari Tiger Reserve Foundation" (TATRF) entered into an Agreement with the
.....2/-
253 ba529.24 WCS for OnLine Bookings of "Jungle Safari" on 10.12.2021. As per allegations levelled
by the Divisional Forest Officer of the TATRF in the complaint, the aforesaid Agreement was for
OnLine Bookings for tourists to visit the Tadoba Forest. The applicants contravened terms and
conditions and have not deposited amount and duped the Government Forest Department by not
paying amount of Rs.12,15,50,831/-. It is further alleged that applicants who are partners haveAbhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

accepted OnLine Bookings for tourists for "Jungle Safari", but they did not pay amount to the Forest
Department as per the Agreement. Moreover, they used the name of the TATRF for bookings and for
their personal business. As per the agreement, it is obligatory on the part of applicants to furnish
OnLine Booking Data and other details. However, they have not provided the said information and
also not provided statement of monthly bookings' accounts to the Forest Department and, therefore,
the Forest Department cancelled the Agreement and directed them not to accept any safari
bookings. It is alleged that applicants have siphoned public amount and duped the Government and
thereby committed the offence.
1. Learned counsel Shri Shyam Dewani for applicants, submitted that as per allegations, applicants
have misappropriated .....3/-
253 ba529.24 amount of Rs.12,15,50,831/-. The entire allegations revolve around the agreement.
Thus, it is just a breach of contract. The sole basis of fraud is on the basis of letter issued by Auditor.
He submitted that Audit Report shows Agreement is dated dated 10.8.2020. Whereas, the
Agreement is dated 10.12.2021. The Investigating Officer has not collected earlier Agreement to
show that the Agreement was in existence since 10.8.2020. The applicants have already invoked
arbitration proceedings before the competent court and requested for appointment of an Arbitrator.
The First Information Report is lodged on the basis of incorrect foundation. The dispute between
applicants and the Forest Department is of a civil nature. No offences are made out under Sections
406 and 420 of the Indian Penal Code. Both Sections cannot be attracted together. It is settled law
that bail cannot be denied as a pre-trial punishment nor it is permitted elaborately to deal with
merits and demerits of the case. At this stage, considerations for grant of bail are to be looked into.
Requirements of offences punishable under Sections 406 and 409 of the Indian Penal Code are
contradictory and the said Sections are invoked by the prosecution in the present matter. There is a
serious dispute between parties about respective rights and entitlements of parties for which parties
have invoked mode of arbitration provided for settlement of dispute in accordance with terms of the
Agreement.
.....4/-
253 ba529.24 In view of the said dispute, which is yet to be adjudicated, the prosecution cannot use
machinery for recovery of alleged dues. There are general allegations by the prosecution of
tampering of evidence and no material is available on record to substantiate the same.
2. In addition to merits of the case, learned counsel for applicants submitted that applicants are
suffering from various ailments. Due to atmosphere in the jail, their health is deteriorating day by
day. Thus, on the ground of ill-health also, applicants be released on bail. The applicants are
arrested on 4.4.2024 and since then they are behind the bars.
3. In support of his contentions, learned counsel for applicants placed reliance on following
decisions of this court:Abhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

1. Criminal Application ABA No.752/2023 (Anjali Sumantrao Pant vs. State of Mah.,
thr.PSO, Malkapur City (Economic Offences Wing), district Buldhana) decided on
4.4.2024;
2. Criminal Application BA No.1427/2022 (Priyanka w/o Abhishek Pacchao vs. State
of Maharashtra) decided on 18.1.2024, and
3. Criminal Application BA No.1074/2023 (Atul vs. Arun Meherkure vs. The State of
Maharashtra) decided on 18.1.2024.
.....5/-
253 ba529.24 Learned counsel for applicants further placed reliance on following
decisions:
1. Ranjitsing Brahmajeetsing Sharma vs. State of Mah.
and anr, reported in (2005)5 SCC 294;
2. Uma Shankar Gopalika vs. State of Bihar and anr, reported in (2005)10 SCC 336;
3. Vir Prakash Sharma vs. Anil Kumar Agarwal and anr, reported in (2007)7 SCC 373;
4. Criminal Application APL No.1070/2023 (Sujata Malewar and anr vs. State of Mah., Ganeshpeth
Police Station, Nagpur and ors) decided by the Division Bench of this court on 25.6.2024;
5. Naresh Goyal vs. Enforcement Directorate, reported in 2024 SCC OnLine Bom 1259;
6. Ramesh Kumar vs. State (NCT of Delhi), reported in (2023)7 SCC 461;
7. Bimla Tiwari vs. State of Bihar, reported in 2023 SCC ONLine SC 51, and
8. State of Kerala vs. Raneef, reported in (2011)1 SCC
784.
4. Learned Public Prosecutor Shri D.V.Chauhan for the State, strongly opposed the application on
ground that involvement of applicants is in white collar crime by misusing technology and a huge
Government fund is not only misappropriated but also siphoned. There are various layers revealed
during the investigation and the investigating agency is trying to unlayer the same. The .....6/-
253 ba529.24 investigation still in progress. He submitted that the First Information Report is
lodged on 18.8.2023 and the application under Section 9 of the Arbitration and Conciliation Act was
filed on 7.8.2023. The First Information Report based on Auditor's Report is much prior and yetAbhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

Laptop and mobile phones are to be seized. During investigation, it revealed that applicants have
opened separate accounts. If there was no intention, why separate accounts were opened in the State
of Uttar Pradesh. He submitted that if applicants are released on bail, applicants tampering of
prosecution evidence cannot be ruled out. Applicant No.2 is a computer professional. The
Investigating papers show 171584 transaction entries out of which 83968 transaction entries are
deleted, which revealed from the Forensic Audit. Though Notice under Section 91 of the Code of
Criminal Procedure was issued, there is no cooperation from applicants. Evasive answers are given
by them that laptops and computers are not in their possession and they are unable to produce the
same. The investigation is deeply hampered. He submitted that applicants have cancelled GST
Registration without informing the TATRF. Thus, applicants have not only defrauded the TATRF
but also evaded the tax. The amount alleged to be misappropriated is of a poor strata of the society
i.e. Gypsy Owners and Guides etc.. The amounts of Gypsy Owners and Guides .....7/-
253 ba529.24 were paid by the TATRF. Thus, they have utilized amount Rs.1,52,71,400/-. Still some
amounts remained to be paid. Thus, he submitted that intention of applicants can be gathered from
circumstances and that intention was since inception.
5. In support of his contentions, learned Public Prosecutor for the State placed reliance
Nimmagadda Prasad vs. Central Bureau of Investigation, reported in (2013)7 SCC 466.
6. Learned counsel Shri Kartik Shukul, assisting the prosecution, also placed on record written
statement as well as oral submissions. He submitted that applicants entered into an agreement with
the TATRF for providing user friendly OnLine Booking Services for five years from the date of
entering into the Agreement. They have developed software on the expenses of the TATRF.
Thereafter, applicants opened bank accounts with ICICI Bank at Pratapgarh. The applicants, on the
basis of the said Agreement, have not provided services as per agreed terms and conditions of the
said service agreement regarding many aspects, more particularly, supply of monthly data and
various statements of the bank accounts for the purpose of audit and other Government compliance
and details of payment made to stake holders such as Gypsy Operators and Guides were also not
provided. He submitted .....8/-
253 ba529.24 that the amount alleged to be misappropriated is a public money. Not only this,
applicants have evaded tax to be paid to the Government and the Government is also duped. Thus,
there is a prima facie material against applicants to show their involvement in the alleged offence.
7. Learned counsel assisting the prosecution placed reliance on the decisions of the Honourable
Apex Court in the cases of Lalmuni Devi (Smt) vs. State of Bihar and ors, reported in (2001)2 SCC 17
and P.Swaroopa Rani vs. M.Hari Narayana alias Hari Babu, reported in (2008)5 SCC 765.
8. The applicants are facing charge on an allegation that they entered into an agreement with the
TATRF for OnLine Bookings for tourists to visit Tadoba Forest. They are proprietors of WCS, a
partnership firm, and they duped the Government i.e. the Forest Department by not depositing
amount of Rs.12,15,50,831/-. The applicants were under obligation to pay the amount to the TATRF,
Gypsy Owners and Guide Charges, but they siphoned the amount by depositing the same in differentAbhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

bank accounts.
9. The entire issue revolves around the service agreement.
10. As per submissions of learned counsel for applicants, it .....9/-
253 ba529.24 is only a breach of agreement and not a criminal offence. Whereas, as per submissions
of the learned Public Prosecutor for the State, there was an intention since inception and, therefore,
applicants deleted data which was entered in respect of bookings which is supported by the Forensic
Audit. Learned Public Prosecutor further submitted that it is misuse of technology. Applicant No.2
is a computer professional and having his expertise in computer technology. The investigating
agency is trying to unlayer various aspects as to digital evidence. The entire First Information
Report is based on Auditor's Report. The Laptops and Mobile Phones used in the transactions and
deleted relevant entries are yet to be seized. Despite the notice under Section 91, applicants have not
cooperated with the investigating agency. Thus, prima facie case is made out against them.
11. It reveals from investigation papers that the partnership firm of applicants entered into an
agreement with the TATRF. Clauses of the said agreement are as follows:
Clause (iii):- from August 2013 the TATR entered into service agreement for
providing portal services for online booking and reservation of tickets for Tiger
Reserves and National Parks for the aforesaid purpose with a joint venture known as
Maha Online .....10/-
253 ba529.24 Limited.
Clause (vi):- therefore by adopting Swiss Challenge Purchase System as per the purchase rules
prescribed by the Government, the TATR invited competitive bids and with the approval of Chief
Wildlife Warden, Maharashtra State, Nagpur selected WCS having been found suitable for the
service and having quoted the lowest rate.
Clause (vii):- WCS has assisted TATR in developing an online portal entitled
www.mytadoba.org/.gov and handed over the same to TATR for use as its Portal and the same is
found meeting the expected level of efficiency.
Clause (viii):- TATR has therefore decided online Reservation System and CSC as well as
maintaining and operating the above Portal exclusively through WCS.
Clause (ix):- the MOU by TATR with WCS will be effective till next five years and after that the
concerned Executive Director will decide regarding further extension of MoU. The same shall be
reviewed every year.
Clause 3.4:- to ensure that the services are provided uninterruptedly and that the TATR does not
suffer any disrepute or .....11/-Abhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

253 ba529.24 financial loss due to improper or interrupted services.
Clause 4.6:- WCS will generate Monthly Analytical Report and forward the same to the Field
Director, TATR.
Clause 5.2:- The WCS shall be entitled to charge the Processing Fees of Rs.65/- (Rupees Sixty Five
Only) inclusive of all taxes and service charges.
Clause 5.3:- WCS shall credit, after ten days from the commencement of the entry of the respective
visitors into TATR, the entry fee and all other charges to the bank accounts as under:
Entry Fee per visit to the bank Account of TATR; Gypsy Charges per Gypsy to Gypsy
owner's bank account; and Guide's Charges per Guide to the Guides bank account;
Processing Fees per ticket to WCS bank account; Clause 5.4:- WCS shall retain
Rs.65/- (Rupees Sixty Five Only) per visitor as its Processing Fees of WCS.
12. Thus, in view of the Agreement, the partnership firm WCS of applicants is entitled
to receive Rs.45/- and also under an .....12/-
253 ba529.24 obligation to deposit Gypsy Owners' Charges and Guide Charges in
their respective accounts and remaining amount to the account of the TATRF. The
partnership firm of applicants was under obligation to credit the said amount of entry
fees after ten days from commencement of the said entry.
13. As per the Agreement, it was agreed between the parties that whenever service
falls below identified thresh hold limits, WCS will work with TATRF to resolve service
problems and report progress to the TATRF. Despite joint meeting between them,
there was no improvement. It reveals from the investigation papers that an audit was
conducted by Auditor on 16.8.2023 and it reveals to the Auditor that total amount
received in the bank account of the TATRF against OnLine Bookings from WCS as
per books of account of TATRF for the period starting from September 2023 to
27.4.2023 is Rs.10,65,16,918/- and the same has been derived based on the ledger
accounts and the corresponding entries in the banks statements. The transaction wise
information pertaining to the amounts received against Safari Bookings and other
activities has been provided by payment facilitators Razorpay and Instamojo pay in
excel sheet. These sheets reflect a consolidated amount received and do not
separately reflect various heads against which the .....13/-
253 ba529.24 amounts are collected. The auditor could not verify the amounts paid
by the WCS to guide and gypsy owners. The statements of guides and Gypsy show
that they have not received any amounts from the WCS that is the partnership firm of
applicants. Till 29.6.2023, TATRF had to pay Rs.1,52,71,400/- to various Gypsy
Owners and Guides. The fees to be paid to Gypsy Owners Guides upto 1.2.2024 go to
Rs.3,28,70,900/-. Preliminary analysis was carried out by appointing KND andAbhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

Associates for Digital Forensic Audit. During digital forensic audit, it was found that
data of total 83968 transactions was deleted out of 171584 transactions which took
place in the year 2020-2023. These are preliminary findings by Auditor.
14. On receipt of Auditor's communication to applicants and their partnership firm,
they were called upon to deposit the amount, but there was no compliance. Thus,
applicants not only contravened terms and conditions of the Agreement but also
siphoned the amount collected by them and, therefore, the Agreement was
terminated.
15. The investigation papers further show that the services of the WCS are obtained
for the OnLine Bookings for the safari. The tourists used to book their safaris OnLine
by depositing amount in the accounts of applicants. In view of the agreement,
applicants .....14/-
253 ba529.24 were under obligation to pay charges of safari and Gypsy and Guide by
depositing the same in their respective accounts and applicants to retain only Rs.45/-
per visit and Rs.30/- to be transferred in the account of the TATRF as processing
fees. The applicants were further under obligation to generate monthly analytical
report and forward the same to the Field Director of TATRF, which was not complied
with. The investigation papers further show that applicants have opened another
Safari Booking Account in the name of M.P.Safari. The data of Razorpay and
Instamojo payment gateways is lying with applicants. Despite Notice issued under
Section 91 of the Code, no documents were produced. Moreover, neither data for
verification nor concerned electronic device computers and laptops were produced.
During investigation, applicant No.1 shown his inability to produce his laptop. It is
further revealed from the investigation that total 27 accounts are maintained by
applicants and amounts are transferred to various bank accounts. It is further
revealed that applicants have also opened their accounts in Pusad Urban Cooperative
Bank and transactions are carried out in the said account. Thus, applicants have not
only siphoned amounts collected during bookings but also cancelled the GST Account
Number. The communication from the GST Department shows that applicants have
cancelled their GST Registration. The fake account in the name .....15/-
253 ba529.24 of the TATRF without prior permission of the Forest Department was
also opened in the State of Uttar Pradesh and the investigation agency received the
KYC of the same. Out of total transactions carried out against the TATRF Bookings in
the ICICI Bank Account, Pratapgarh Branch, Rs.63.00 crores are through Razorpay
gateway.
Thus, huge amount is involved in the said transactions. During the investigation, applicant No.1 was
enquired and it revealed that various OTP Numbers are received for transactions and software used
for OnLine Bookings and data are in the laptops, but applicants have shown their inability to show
laptops. The applicants have not produced other gadgets also to the investigating agency even notAbhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

cooperated with the investigating agency to ascertain details regarding the Website used for the
online bookings. Thus, allegation is not only of siphoning of the amounts but also there is an
allegation of fabrication of the electronic record as forensic audit analysis shows that entries 83968
out of 171584 are deleted. The booking amounts are accepted by firms of applicants but the amounts
are not paid to other stakeholders like Gypsy Owners and Guides whose earnings are based upon the
said transaction and OnLine Bookings.
16. Learned counsel for applicants submitted that the offence levelled against applicants is not made
out. The decision in .....16/-
253 ba529.24 the case of Ranjitsing Brahmajeetsing Sharma vs. State of Mah. and anr supra, speaks
about bar under Section 21(4) of the MCOC Act and it is observed that where a case is based on
circumstantial evidence, the court should consider whether all the links in the chain of
circumstances are complete.
17. It is well settled that when the case is based on circumstantial evidence, the chain of
circumstances pointing out guilt of the accused requires to be complete.
18. The investigation, in the present case, is still in progress and not completed. At this stage, it
would not be appropriate to say that the chain is not completed and no offence is made out against
the accused persons.
19. In the case of Uma Shankar Gopalika vs. State of Bihar and anr supra, which is relied upon by
learned counsel for applicants, it is held that every breach of contract would not give rise to an
offence of cheating and only in those cases breach of contract would amount to cheating where there
was any deception played at the very inception.
20. Here, in the present case, applicants have not only breached contract but also they have deleted
entries regarding .....17/-
253 ba529.24 transactions which are supported by Forensic Audit, Opening Parallel Account and
carried out transactions, which is sufficient to show ingredients of the offence.
The same ratio is laid down in the case of Lalit Chaturvedi and ors vs. State of Uttar Pradesh and
anr, reported in 2024 SCC SC 171.
21. Considering facts of the present case, the intention since inception is present and, therefore, the
above judgment is not helpful to applicants for grant of bail.
22. Another ground raised by learned counsel for applicants is, due to incarceration in the jail,
health of applicants is deteriorating and they are taking treatment. The medical report shows that no
abnormality is seen by the Medical Officer when they are examined in jail. Even CT Scan Report of
the brain of applicant No.2 shows that no significant abnormality is detected.Abhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

23. In the case of Naresh Goyal vs. Enforcement Directorate supra, the Division Bench of this court
dealt with words, 'sick' or 'infirm' and it is held that infirmity may arise from a variety of causes.
Infirmity may not necessarily be on account of sickness. The Parliament has, therefore, advisedly
used the words 'sick' or 'infirm' .....18/-
253 ba529.24 disjunctively. The provision is required to be construed in such a manner as to
advance the guarantee of right to life under Article 21.
24. The medical record is not sufficient to hold that applicants are not getting adequate treatment in
jail. The medical papers are not sufficient to show that they need expert treatment and, therefore,
the ground for grant of bail for medical treatment is not available.
25. In the case of of Lalmuni Devi (Smt) vs. State of Bihar and ors supra, as relied by learned counsel
assisting the prosecution, it is observed that there could be no dispute to the proposition that if the
complaint does not make out an offence it can be quashed. However, it is also settled law that facts
may give rise to a civil claim and also amount to an offence. Merely because a civil claim is
maintainable does not mean that the criminal complaint cannot be maintained.
The above said view is expressed by the Honourable Apex Court in the case of P.Swaroopa Rani vs.
M.Hari Narayana alias Hari Babu supra.
26. In the light of the above observations, if facts of the present case are taken into consideration,
involvement of applicants reveals in economic offences. The investigation is still in progress.
.....19/-
253 ba529.24 During the investigation, various facets are unlayered. Still, the electronic gadgets
used in commission of the crime are not seized and the investigation as to digital evidence is still in
progress. The Forensic Audit Analysis shows that entries 83968 out of 171584 are deleted regarding
transactions. The agency of the applicants was engaged for OnLine Bookings. The Bookings'
amounts are accepted by the firm of the applicants, but the amounts are not deposited with the
TATRF. The applicants were under obligation to deposit the amounts to be paid to the Gypsy
Owners and Guides whose services are used by the various tourists by depositing the amounts which
are not paid and the Government has to incur the expenses to the tune of Rs.1,52,71,400/- to the
various Gypsy Owners and Guides. Still, amount Rs.3,28,70,900/- of Gypsy Owners and Guides is to
be paid. The applicants have not only grabbed the amount of these Gypsy Owners and Guides but
also they have duped the Government by not depositing Rs.30/- with the TATRF for each
transaction. However, behind the back of the Forest Department, they cancelled the GST
Registration as well as not paid the Income Tax. The investigation papers further show that the
applicants have entered into transaction and amount Rs.8.00 crores was transferred in Pusad Urban
Cooperative Bank which was hidden account. The various accounts are opened in the names of
family members and the transactions are .....20/-
253 ba529.24 taken place.Abhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

27. Admittedly, involvement of the applicants is an economic offence. Whether economic offence is
to be treated as class of its own or otherwise. The issue has been dealt by the Honourable Apex Court
in the case of P.Chidambaram vs. Directorate of Enforcement reported in (2020)13 SCC 791 wherein
it is held that The gravity of the offence, object of the Special Act, and the attending circumstances
are a few of factors to be taken note of, along with period of sentence. After all, an economic offence
cannot be classified as such, as it may involve various activities and may differ from one case to
another. Paragraph No.23 of the said decision is reproduced:
"Thus, from cumulative perusal of the judgments cited on either side including the
one rendered by the Constitution Bench of this Court, it could be deduced that the
basic jurisprudence relating to bail remains the same inasmuch as the grant of bail is
the rule and refusal is the exception so as to ensure that the accused has the
opportunity of securing fair trial. However, while considering the same the gravity of
the offence is an aspect which is required to be kept in view by the Court. The gravity
for the said purpose will have to be gathered from the facts and circumstances arising
in each case.
.....21/-
253 ba529.24 Keeping in view the consequences that would befall on the society in
cases of financial irregularities, it has been held that even economic offences would
fall under the category of "grave offence" and in such circumstance while considering
the application for bail in such matters, the Court will have to deal with the same,
being sensitive to the nature of allegation made against the accused. One of the
circumstances to consider the gravity of the offence is also the term of sentence that
is prescribed for the offence the accused is alleged to have committed. Such
consideration with regard to the gravity of offence is a factor which is in addition to
the triple test or the tripod test that would be normally applied. In that regard what is
also to be kept in perspective is that even if the allegation is one of grave economic
offence, it is not a rule that bail should be denied in every case since there is no such
bar created in the relevant enactment passed by the legislature nor does the bail
jurisprudence provide so. Therefore, the underlining conclusion is that irrespective of
the nature and gravity of charge, the precedent of another case alone will not be the
basis for either grant or refusal of bail though it may have a bearing on principle. But
ultimately the consideration will have to be on case-to-case basis on the facts
involved therein and securing the presence of the accused to stand trial."
.....22/-
253 ba529.24 It has further been held that we are conscious of the fact that the accused are charged
with economic offences of huge magnitude. We are also conscious of the fact that the offences
alleged, if proved, may jeopardize the economy of the country. At the same time, we cannot lose
sight of the fact that the investigating agency has already completed investigation and the
charge-sheet is already filed before the Special Judge, CBI, New Delhi and, therefore, their presenceAbhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

in the custody may not be necessary for further investigation and released the appellant on bail.
28. Grant or refusal of bail lies with discretion of the court and it can be regulated by facts and
circumstances of that case.
29. Admittedly, involvement of the applicants is in economic offence wherein the investigation is yet
to be completed. Jurisdiction to grant bail has to be exercised having regarding to facts and
circumstances of each case. The factors to be taken into consideration are nature of accusations,
reasonable apprehension of tampering with witnesses, and reasonable possibility of securing
presence of accused.
30. Here, in the present case, electronic gadgets are yet to be seized.
.....23/-
253 ba529.24
31. Learned Public Prosecutor for the State pointed out that if applicants are released on bail, who
are highly professionals in computers, there is an apprehension of tempering with evidence with the
help of technology. The apprehension is substantiated by the fact that initially with the help of
technology, applicants have deleted the entries as regards transactions, which is revealed from the
Forensic Audit.
32. Here, the applicants have not only duped the Forest Department but also they evaded the GST as
well as Income Tax. The amounts to be paid to the persons, who came from the poor strata of the
society, are also siphoned.
33. The Honourable Apex Court, while dealing with offence, involving conspiracy to commit
economic offences of huge magnitude, in the case of Y.S.Jagan Mohan Reddy vs. CBI, reported in
(2013)7 SCC 439 laid down following parameters:
i) economic offences constitute a class apart and need to be visited with a different
approach in the matter of bail. The economic offence having deep rooted conspiracies
and involving huge loss of public funds needs to be viewed seriously and considered
as grave .....24/-
253 ba529.24 offences affecting the economy of the country as a whole and thereby posing serious
threat to the financial health of the country, and
ii) while granting bail, the court has to keep in mind the nature of accusations, the nature of
evidence in support thereof, the severity of the punishment which conviction will entail, the
character of the accused, circumstances which are peculiar to the accused, reasonable possibility of
securing the presence of the accused at the trial, reasonable apprehension of the witnesses being
tampered with, the larger interest of the public/State and other similar considerations.Abhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

34. The Honourable Apex Court, in the case of State of Gujarat vs. Mohan Lal Jitamalji Porwal,
reported in (1987)2 SCC 364 held as follows:
"5. ....The entire community is aggrieved if the economic offenders who ruin the
economy of the State are not brought to book. A murder may be committed in the
heat of moment upon passions being aroused. An economic offence is committed
with cool calculation and deliberate design with an eye on personal profit regardless
of the consequence to the community. A .....25/-
253 ba529.24 disregard for the interest of the community can be manifested only at
the cost of forfeiting the trust and faith of the community in the system to administer
justice in an even-handed manner without fear of criticism from the quarters which
view white collar crimes with a permissive eye unmindful of the damage done to the
national economy and national interest....."
35. Considering the crime having involved enormous and huge amount and siphoned of amount and
fabrication of digital data and investigation revealing manner in which the Forest Department is
duped and the Government money is at stake, the role of applicants is clearly exposed. In the
background of accusations and its gravity and especially when the investigation is yet not
completed, the application deserves to be rejected and the same is rejected.
The application stands disposed of.
(URMILA JOSHI-PHALKE, J.) !! BrWankhede !! Signed by: Mr. B. R. Wankhede Designation: PS
To Honourable Judge ...../- Date: 20/07/2024 16:38:42Abhishek S/O Vinodsingh Thakur And 1 vs The State Of Maharashtra Thr. ... on 20 July, 2024

