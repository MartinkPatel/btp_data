Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26
February, 2007
Equivalent citations: 2007 AIR SCW 1645, 2007 (2) SCC 777, 2007 CRI LJ
(NOC) 744, 2007 (3) AIR BOM R 252, (2007) 2 CRILR(RAJ) 932, (2007) SC CR R
902, (2007) 2 SUPREME 468, (2007) 1 EFR 582, (2007) 2 RECCRIR 180, 2007
ALLMR(CRI) 1144, 2008 BOMCRSUP 168, (2007) 2 CRIMES 192, (2007) 1 JCC
843 (SC), (2007) 2 RAJ CRI C 609, (2007) 1 CURCRIR 556, (2007) 3 SCALE 598,
(2007) 4 RAJ LW 3297, (2007) 2 ALLCRIR 1504, (2007) 3 RAJ LR 125, 2007 (1)
SCC (CRI) 653, (2007) 3 WLC (RAJ) 704
Author: Ar. Lakshmanan
Bench: Ar. Lakshmanan, Altamas Kabir
           CASE NO.:
Writ Petition (crl.)  114 of 2006
PETITIONER:
Alpesh Navinchandra Shah
RESPONDENT:
State of Maharashtra & Ors
DATE OF JUDGMENT: 26/02/2007
BENCH:
Dr. AR. Lakshmanan & Altamas Kabir
JUDGMENT:
J U D G M E N T Dr. AR. Lakshmanan, J.
The above writ petition was filed under Article 32 of the Constitution of India for issuance of a Writ
of Habeas Corpus or any other appropriate writ quashing and setting aside the order of detention
dated 12.01.2005 under COFEPOSA Act, 1974 issued against the petitioner by respondent No.2 -
Principal Secretary (Appeals and Security), Government of Maharashtra, Mumbai.
The petitioner was detained under Section 3(1) of the Conservation of Foreign Exchange and
Prevention of Smuggling Activities Act, 1974 (hereinafter referred to as "COFEPOSA Act") in
pursuance of the impugned order of detention. The petitioner by way of this writ petition is
challenging the legality and validity of the impugned order of detention passed by respondent No.2
at pre-execution stage in the peculiar facts and circumstances of this case. It is stated that two
similar orders of detention dated 12.01.2005 and 31.01.2005 were issued under the COFEPOSA ActAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

by respondent No.2 against the petitioner Alpesh Navinchandra Shah and his brother Kamlesh Shah
respectively. The detention order has already been served upon Kamlesh Shah. The grounds of
detention order and the documents relied upon in the case of the petitioner are identical in content
and material.
The brief facts of the case are mentioned in seriatim as under:
In or about, August, 2004 M/s. Perfect Trading Co. (proprietorship firm of Shri
Rajendra Mamgaim) imported Ball bearings in five containers. On 3.9.2004,
consignments of mis- declared consignments were intercepted by the DRI officials.
The petitioner and his brother were arrested on 4.9.2004 by the Intelligence Officers,
DRI, Mumbai Zonal Unit primarily on the allegations that they have been indulging
in import of high quality and high value Ball Bearing and were clearing the same by
evading duty of custom.
The Addl. Chief Metropolitan Magistrate, 3rd Court, Esplanade, Mumbai vide Order
dated 23.9.2004 directed to release the petitioner and his brother on bail imposing
conditions including their regular attendance in the Department and the imposition
of an embargo not to leave the country without the prior permission of the Court.
Impugned Detention Order bearing No. PSA 1204/21 (2)/ SLP-3(A) dated 12.1.2005
was issued by respondent No.2 for detaining the petitioner ostensibly under the
provisions of COFEPOSA Act 1974. Similar Order No. PSA 1204/21 (1)/SLP-3 (A)
dated 31.1.2005 was also issued to detain Shri Kamlesh Shah, the brother of the
petitioner.
Show Cause Notice dated 23.2.2005 was issued to the petitioner and his brother by the DRI,
Mumbai Zonal Unit. Pursuant to the said show cause notice, the application for settlement under
Section 127 B of the Customs Act, 1962, was filed on 19.4.2005 by M/s Perfect Trading Co. as
Applicant and the petitioner, his brother and others as Co-Applicants before the settlement
Commission, Mumbai.
During the course of the admission hearing of the aforesaid settlement application, the petitioner
came to know that the Order dated 27.12.2005 has been passed by respondent No.2 for detaining
him while invoking section 3 (1) of the COFEPOSA Act, 1974. Accordingly, at the stage of the
admission hearing, the Settlement Commission was urged to make recommendation to the
Detaining Authority for the revocation of the Detention Order.
The Settlement Commission, vide order dated 03.01.2006, rejected the prayer by adopting the
reasoning narrated in the case of Vipul Gor, Proprietor of M/s Sonam Enterprises (Misc. Order
No.12/2005  CUS dated 19.12.2005) wherein it was, inter alia, held that the Commission did not
have any jurisdiction to make a recommendation to the Detaining Authority for revocation of a
Detention order and further held that the petitioner and his brother would be at liberty to take
recourse to any other legal remedy available to it for lifting of the detention order whether by the
sponsoring authority, detaining authority or the courts. However, the Settlement CommissionAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

allowed the application for settlement to be proceeded with.
The case was finally heard by the Settlement Commission on 1.3.2006.
Vide Final Order bearing No.17/CUS/2006 dated 7.3.2006, the Settlement Commission allowed the
Settlement Application and settled the case on payment of Customs Duty of Rs. 1,40,52,959/-. In
terms of sub-section (1) of section 127 H of the Customs Act, 1962, and in view of full and true
disclosure, the Commission granted immunity to all the Applicants including the petitioner from
any penalty that could be levied under the Customs Act and also from the prosecution under the
Customs Act, 1962, as well as under
IPC. It is evident from the Order that a copy of the said Final Order of complete
settlement of the case, was also forwarded to the Detaining Authority by the
Settlement Commission. It is also pertinent to note that though the Settlement
Commission vide Section 127H of the Customs Act, 1962 is empowered to impose
such conditions as it may deem fit for grant of immunities, deemed it fit not to
impose any condition on the petitioner, in spite of the fact that detention Order
having been issued against the petitioner, was before the Commission and granted
full immunities and settled the case giving quietus to all issues.
In spite of complete settlement of all disputes among the petitioner and the Revenue,
after the case was fully settled by the said Final Order dated 7.3.2006 of
'compromise"/"settlement" of the entire case, the officers of DRI apprehended the
Petitioners brother and he was detained under the Detention Order dated 31.1.2005.
The petitioner is also relying upon the copy of order dated 5th May 2005 published in
Gazette of Maharashtra Government at page 56, Page IV-A, inter alia, showing that
the Order No. PSA 1204/21(2)/ SLP-3(A) was issued against the petitioner on 12th
January, 2005 by the respondent. Being aggrieved by the said order of detention
which is based upon the same grounds as reflected in the show cause notice and
which were considered in the proceedings before the Settlement Commission, the
petitioner preferred the above writ petition for quashing of the impugned detention
order. We heard Mr. Vikram Chaudhri, learned counsel for the petitioner and Mr.
Ravindra Keshavrao Adsure, learned counsel for the contesting respondent.
Learned counsel for the petitioner, at the time of hearing, made the following
submissions:-
In the light of the fact that as per provisions of Customs Act, 1962, the case of the
petitioner is 'settled' and he has been granted unconditional immunities by the
Settlement Commission, chasing the petitioner for detaining him under the
COFEPOSA Act would be contrary to the settled proposition of law that:
i. the personal liberty is one of the most cherished freedoms more important than any
other guaranteed under the constitution and in a democracy governed by rule of lawAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

the drastic power to detain a person, without trial, must be strictly construed. ii.
Draconian power of detention must be exercised in rarest of rare cases and only as a
preventive measure and not punitive.
iii. The law pertaining to preventive detention must be meticulously followed with
substantively and procedurally by the detaining authority. iv. Section 3(1) of the Act
allows the detention of a person only if the appropriate detaining authority is
satisfied that with a view to preventing such person from carrying on any of the
offensive activities enumerated therein, it is necessary to detain such person. v. The
satisfaction of the detaining authority is not a subjective one based on the detaining
authority's emotions, beliefs or prejudices. There must be a real likelihood of the
person being able to indulge in such activities, the inference of such likelihood being
drawn form objective data based on surrounding circumstances.
vi. The possibility of prosecution is having a direct bearing on the subjective
satisfaction of the Detaining Authority.
vii. Unsuccessful judicial trial may not operate as a bar to a detention order, but the
discharge cannot be said to be entirely irrelevant and of no significance. viii. The
detention power cannot be used to subvert, supplant or to substitute the punitive law
of penal code.
At the time of hearing, the judgment rendered by this Court in Hira Lal Hari Lal
Bhagwati vs. CBI, New Delhi, 2003 (5) SCC 257 (Brijesh Kumar and Dr. AR.
Lakshmanan, JJ) was also relied on and our attention was invited to paras 44 & 45 of
the said judgment which read as under:
"44. . The declarant could not be dragged and chased in criminal proceedings after
closing the other opening making it a dead end. It is highly unreasonable and
arbitrary to do so and initiation and continuance of such proceedings lack bonafides.
45. In the background given above, there is every reason to legally infer that the
position as it stood, in regard to the criminal prosecution and conviction on the date
the declaration was filed, as conditions precedent to settlement under the Scheme,
would also stand finalized on full and final settlement of the matter under the
Scheme. That is to say the position that no criminal prosecution was pending against
the declarant on the date of filing of the declaration nor he stood convicted for such
an offence in relation to the matter covered under the declaration, it would stand
finalized with acceptance of the declaration and settlement of the matter fully and
finally. Later on, the declarant could not be or continued to be subjected to criminal
prosecution to alter the position as it stood on the relevant date of the submission of
declaration and get him convicted for such offences in respect of which, if he stood
convicted earlier while filing statement he would not have been entitled to seek the
benefit under the Scheme. The appellants virtually foreclosed their right to furtherAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

pursue the proceedings before the authorities or courts of law challenging the
legality, validity or the tax liability in terms of the Scheme. Undoubtedly, if the
appellants' appeal which was pending in this Court against the order of CEGAT
relating to the tax liability, had been allowed it might have affected the criminal
proceeding too on merits. In certain circumstances, it could be put up as a defence by
the declarant, in the criminal case but in terms of the scheme he was bound to
withdraw his appeal. The criminal prosecution could not be allowed to proceed by
putting an end to a possible defence, before hand. It certainly amounts to abuse of
process of law. The appeals thus deserve to be allowed.
Placing reliance on the above judgment, learned counsel for the petitioner urged that
the detention order No. PSA 1204/21(2)/SPL-3(A) issued against the petitioner be
quashed and set aside without insisting the petitioner to undergo detention.
Learned counsel for the petitioner further submitted that the impugned order of
detention is contrary to the spirit of settlement and legislative intent behind the
scheme of settlement enacted under the Customs Act, 1962. i. The Settlement
Commission came into being as a culmination of the report submitted by the
Wanchoo Committee set up for toning up the administration of direct taxes.
Para 2.32 of the Wanchoo Committee's report reads as:
"This however, does not mean that the door for compromise with an errant tax-payer
should forever remain closed. In the administration of fiscal laws, whose primary
objective is to raise revenue, there has to be room for compromise and settlement. A
rigid attitude would not only inhibit one-time tax-evader or an unintending defaulter
from making a clean breast of his affairs, but would also unnecessarily strain the
investigational resources of the Department in cases of doubtful benefit to revenue,
while needlessly proliferating litigation and holding up collections. We would,
therefore, suggest that there should be a provision in the law for a settlement with the
tax-payer at any stage of the proceedings. In the United Kingdom, the 'confession'
method has been in vogue since 1923. In the U.S law also there is a provision for
compromise with the tax payer as to his tax liabilities. A provision of this type
facilitating settlement in individual cases will give this advantage over general
disclosure schemes that misuse thereof will be difficult and the disclosure will not
normally breed further tax evasion. Each individual case can be considered on its
merits and full disclosures not only of the income but of the modus operandi of its
build up can be insisted on, thus sealing off chances of continued evasion through
similar practices."
The recommendation of Wanchoo Committee has been quoted with approval by this Court in the
case of CIT (Central) vs. B.N.Bhattacharjee and Another (1979) 118 ITR 461- SC.Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

On the above basis, in the course of the Budget Speech in 1992, Hon'ble the then Finance Minister
announced as under:-
"A settlement Commission was established in 1976 under the Income Tax Act, 1961. I
propose to set up a Settlement Commission, on similar lines, for dealing with
Customs and Central Excise disputes between the Department and the assesses. I
trust this will help in speedy settlement of tax disputes."
It is submitted that in spite of the above speech of the Finance Minister in 1992, it was only in the
Finance Bill 1998 that provisions were made to insert Chapter XIVA in the Customs Act for creation
of Settlement Commission and the provisions relating to the Settlement Commission came into
effect vide Act 21 of 1998, Section 102 w.e.f. 01.08.1998. In the Finance Bill of 1998, Clause 105
seeks to insert Chapter in the Customs Act, 1962 to provide for setting up of a Customs and Central
Excise Settlement Commission on the lines of a similar commission already working under the
Income Tax Act, 1961.
Learned counsel for the petitioner further submitted that:
i. Since the legislature itself has created Settlement Commission for generating
Revenue and has also made provisions for release of the goods on payment of duty
and has also made provisions for granting immunity from prosecution under the
Customs Act, 1962 under the Indian Penal Code and also under the other Central
Law, it is clear that the intention of the Legislature was more on Revenue aspect
rather than prosecution and punishment aspect or in continuing with multiple
litigations. He submits that it would be unjust unfair and unreasonable if a person is
made to suffer preventive detention mainly after his application for settlement is
allowed to be proceeded with, and after realisation of the Customs duties not only the
goods are ordered to be released, but on considering the co-operation extended by
him in the settlement proceedings, the Settlement Commission has also granted to
him immunity from prosecution under the Customs Act, 1962 as well as under the
IPC. He further submits that this Court in the case of Sadhu Roy has held that, if
there is cast iron case against the person, then he should be prosecuted rather than
detained under the preventive detention law, which is softer measure. He submits
that when under the law the person is immuned from prosecution which is a stronger
deterrent than detention, there is no reason as to why the same person should be
detained preventively under a softer measure.
ii. the act of detaining such person whose Settlement Application under the statutory
provisions of Customs Act, 1962 has been allowed to be proceeded with and
specifically whose case has been settled, would be discriminative and arbitrary as
against the person who does not approach the Settlement Commission and does not
settle their case and thus continue to damage the economy of the country. Learned
counsel submits that for the reason of discrimination and arbitrariness of the
detention order against a person who is willing to or has settled the case against theAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

petitioner, the detention Order is liable to be quashed and set aside because it would
become punitive and how would the punitive Order would survive when the
application for settlement of the case with prayers for immunity from prosecution has
been allowed to be proceeded with and the case has been fully settled?
iii. when the Settlement Commission grants immunity to a person under Section
127H of the Customs Act, 1962, the Settlement Commission regularizes the act of the
person which was supposed to be violative of the provisions of the Customs Act, 1962,
meaning thereby that whatever was alleged to have been committed by the said
person becomes non-est, as if he has not committed any breach of the Customs Act,
1962, the person becomes a person who has not at all committed any act or omission
in respect of the goods under section 111 of the Customs Act, 1962 and therefore in
such a situation where there is no act or omission on the part of the person who
approaches the Settlement Commission and gets immunity from prosecution and
penalty, a Detention Order under any clause of section 3(1) (i) to 3(1) (v) cannot
sustain. Learned counsel for the petitioner, therefore, submits since the petitioner's
application for settlement of the case has been allowed to be proceeded with and his
case has been finally settled, the impugned order of detention against the Petitioner
has become an order which is not sustainable in law.
Our attention to the preamble of COFEPOSA Act, 1974 was invited which reads as
under:
"COFEPOSA Act, 1974, as per its preamble is an Act to provide for preventive
detention in certain cases for the purpose of conservation and augmentation of
foreign exchange and prevention of smuggling activities and for matters connected
therewith because the violations of foreign exchange regulations and smuggling
activities are having an increasingly deleterious effect on the national economy and
thereby a serious adverse effect on the security of the state."
Learned counsel for the petitioner submits that it was clear from the preamble of the COFEPOSA
Act that only in certain cases the preventive detention is provided for conservation and
augmentation of foreign exchange and preventing the smuggling activities which have deleterious
effect on the national economy. He submits that the above objective of the COFEPOSA Act, 1974 is
fulfilled by the Order of the Settlement Commission in as much as when a case is settled on payment
of the Customs duty, there would be no deleterious effect on the national economy, on the contrary,
even if after settlement of case the detention order is allowed to be continued, the legislative intent
in introducing the settlement provision would be defeated which may have adverse and deleterious
effect on the national economy. It is further submitted that the Settlement Commission is a forum of
legal criterion and the powers are drawn from the enacted statutes such as Customs Act, 1962 and
Central Excise Act, 1944 in the case of eligible persons, who in addition to fulfilling the other criteria
admit additional duty liability of a minimum of Rs. 2 lacs, the option of knocking the doors of
Settlement Commission is available, inter alia, in the cases under the Customs Act. According to the
learned counsel, the functional mechanism of the Settlement Commission pertaining to the customsAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

cases can be broadly described as follows:-
On receiving an application, the statutory report is called for by the Settlement
Commission from the jurisdictional Commissioner. The Commission considers the
report and after hearing both the sides decides on the admissibility of the case. Again
after hearing both the sides, the Settlement Commission, after being satisfied that a
true and full disclosure has been made by the applicant, determines the duty liability,
redemption fine in lieu of confiscation and the penalty on the persons. Further, the
question of extending immunity from prosecution under the Customs Act, 1962,
Indian Penal Code and any other Central Acts is also decided by the Commission. The
Commission has got power to reject any application. Further the decisions of the
Settlement are not appealable in the regular course. Above all, once the Commission
admits a case, it is vested with the exclusive powers of all the Customs authorities till
the finalization of the case.
In this regard it is apt to extract Sections 127B to 127J of the Customs Act, 1962 which
are as under: -
"127B. Application for settlement of cases. - (1) Any importer, exporter or any other
person (hereinafter in this Chapter referred to as the applicant) may, at any stage of a
case relating to him make an application in such form and in such manner as may be
specified by rules, and containing a full and true disclosure of his duty liability which
has not been disclosed before the proper officer, the manner in which such liability
has been incurred, the additional amount of customs duty accepted to be payable by
him and such other particulars as may be specified by rules including the particulars
of such dutiable goods in respect of which he admits short levy on account of
misclassification or otherwise of goods, to the Settlement Commission to have the
case settled and such application shall be disposed of in the manner hereinafter
provided :
Provided that no such application shall be made unless -
(a) the applicant has filed a bill of entry, or a shipping bill, in respect of import or
export of goods, as the case may be, and in relation to such bill of entry or shipping
bill or a show cause notice has been issued to him by the proper officer;
(b) the additional amount of duty accepted by the applicant in his application exceeds
two lakh rupees :
Provided further that no application shall be entertained by the Settlement
Commission under this sub-section in cases which are pending in the Appellate
Tribunal or any Court:Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

Provided also that no application under this sub-section shall be made in relation to
goods to which section 123 applies or to goods in relation to which any offence under
the Narcotic Drugs and Psychotropic Substances Act, 1985 (61 of 1985) has been
committed:
Provided also that no application under this sub-section shall be made for the
interpretation of the classification of the goods under the Customs Tariff Act, 1975 (51
of 1975).
(2) Where any dutiable goods, books of account, other documents or any sale
proceeds of the goods have been seized under section 110, the applicant shall not be
entitled to make an application under sub-section (1) before the expiry of one
hundred and eighty days from the date of the seizure.
(3) Every application made under sub-section (1) shall be accompanied by such fees
as may be specified by rules.
(4) An application made under sub-section (1) shall not be allowed to be withdrawn
by the applicant.
127C. Procedure on receipt of application under section 127B. - (1) On receipt of an application
under section 127B, the Settlement Commission shall call for a report from the Commissioner of
Customs having jurisdiction and on the basis of the materials contained in such report and having
regard to the nature and circumstances of the case or the complexity of the investigation involved
therein, the Settlement Commission may, by order, allow the application to be proceeded with or
reject the application :
Provided that an application shall not be rejected under this sub-section, unless an
opportunity has been given to the applicant of being heard :
Provided further that the Commissioner of Customs shall furnish such report within
a period of one month of the receipt of the communication from the Settlement
Commission, failing which it shall be presumed that the Commissioner of Customs
has no objection to such application; but he may raise objections at the time of
hearing fixed by the Settlement Commission for admission of the application and the
date of such hearing shall be communicated by the Settlement Commission to the
applicant and the Commissioner of Customs within a period not exceeding two
months from the date of receipt of such application, unless the presiding officer of the
Bench extends the said period of two months, after recording the reasons in writing.
(2) A copy of every order under sub-section (1) shall be sent to the applicant and to
the Commissioner of Customs having jurisdiction.Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

(3) Subject to the provisions of sub-section (4), the applicant shall, within thirty days
of the receipt of a copy of the order under sub-section (1) allowing the application to
be proceeded with, pay the amount of additional duty admitted by him as payable
and shall furnish proof of such payment to the Settlement Commission.
(4) If the Settlement Commission is satisfied, on an application made under
sub-section (1) that the applicant is unable for good and sufficient reasons to pay the
amount referred to in sub-section (3), within the time specified in that sub-section, it
may extend the time for payment of the amount which remains unpaid or allow
payment thereof by instalments, if the applicant furnishes adequate security for the
payment thereof.
(5) Where the additional amount of customs duty referred to in sub-section (3) is not
paid by the applicant within the time specified or extended period, as the case may
be, the Settlement Commission may direct that the amount which remains unpaid,
together with simple interest at the rate of eighteen per cent. per annum or at the rate
notified by the Board from time to time on the amount remaining unpaid, be
recovered as the sum due to the Central Government by the proper officer having
jurisdiction over the applicant in accordance with the provisions of section 142.
(6) Where an application is allowed to be proceeded with under sub-section (1), the
Settlement Commission may call for the relevant records from the Commissioner of
Customs having jurisdiction and after examination of such records, if the Settlement
Commission is of the opinion that any further enquiry or investigation in the matter
is necessary, it may direct the Commissioner (Investigation) to make or cause to be
made such further enquiry or investigation and furnish a report on the matters
covered by the application and any other matter relating to the case.
(7) After examination of the records and the report of the Commissioner of Customs
received under sub-section (1), and the report, if any, of the Commissioner
(Investigation) of the Settlement Commissioner under sub-section (6), and after
giving an opportunity to the applicant and to the Commissioner of Customs having
jurisdiction to be heard, either in person or through a representative duly authorised
in this behalf, and after examining such further evidence as may be placed before it or
obtained by it, the Settlement Commission may, in accordance with the provisions of
this Act, pass such order as it thinks fit on the matters covered by the application and
any other matter relating to the case not covered by the application, but referred to in
the report of the Commissioner of Customs or the Commissioner (Investigation)
under sub-section (1) or sub-section (6). (8) Subject to the provisions of section 32A
of the Central Excise Act, 1944 (1 of 1944), the materials brought on record before the
Settlement Commission shall be considered by the Members of the concerned Bench
before passing any order under sub-section (7) and, in relation to the passing of such
order the provisions of section 32D of the Central Excise Act, 1944 shall apply.Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

(9) Every order passed under sub-section (7) shall provide for the terms of settlement
including any demand by way of duty, penalty or interest, the manner in which any
sum due under the settlement shall be paid and all other matters to make the
settlement effective and shall also provide that the settlement shall be void if it is
subsequently found by the Settlement Commission that it has been obtained by
fraud, or misrepresentation of facts.
(10) Where any duty payable in pursuance of an order under sub-section (7) is not
paid by the applicant within thirty days of the receipt of a copy of the order by him,
then, whether or not the Settlement Commission has extended the time for payment
of such duty or has allowed payment thereof by instalments, the applicant shall be
liable to pay simple interest at the rate of eighteen per cent. per annum or at such
other rate as notified by the Board on the amount remaining unpaid from the date of
expiry of the period of thirty days aforesaid.
(11) Where a settlement becomes void as provided under sub-section (9) the
proceedings with respect to the matters covered by the settlement shall be deemed to
have been revived from the stage at which the application was allowed to be
proceeded with by the Settlement Commission and proper officer may,
notwithstanding anything contained in any other provision of this Act, complete such
proceedings at any time before the expiry of two years from the date of the receipt of
communication that the settlement became void.
127D. Power of Settlement Commission to order provisional attachment to protect revenue. - (1)
Where, during the pendency of any proceeding before it, the Settlement Commission is of the
opinion that for the purpose of protecting the interests of the revenue it is necessary so to do, it may,
by order, attach provisionally any property belonging to the applicant in such manner as may be
specified by rules.
(2) Every provisional attachment made by the Settlement Commission under sub-section (1) shall
cease to have effect from the date the sums due to the Central Government for which such
attachment is made are discharged by the applicant and evidence to that effect is submitted to the
Settlement Commission.
127E. Power of Settlement Commission to reopen completed proceedings. - If the Settlement
Commission is of the opinion (the reasons for such opinion to be recorded by it in writing) that, for
the proper disposal of the case pending before it, it is necessary or expedient to reopen any
proceeding connected with the case but which has been completed under this Act before application
for settlement under section 127B was made, it may, with the concurrence of the applicant, reopen
such proceeding and pass such order thereon as it thinks fit, as if the case in relation to which the
application for settlement had been made by the applicant under that section covered such
proceeding also :Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

Provided that no proceeding shall be reopened by the Settlement Commission under
this section after the expiry of five years from the date of application under
sub-section (1) of section 127B.
127F. Power and procedure of Settlement Commission. -
(1) In addition to the powers conferred on the Settlement Commission under Chapter
V of the Central Excise Act, 1944 (1 of 1944), it shall have all the powers which are
vested in an officer of the customs under this Act or the rules made thereunder.
(2) Where an application made under section 127B has been allowed to be proceeded
with under section 127C, the Settlement Commission shall, until an order is passed
under sub-section (7) of section 127C, have, subject to the provisions of sub-section
(6) of that section, exclusive jurisdiction to exercise the powers and perform the
functions of any officer of customs or Central Excise Officer as the case may be, under
this Act or in the Central Excise Act, 1944 (1 of 1944), as the case may be, in relation
to the case.
(3) In the absence of any express direction by the Settlement Commission to the
contrary, nothing in this Chapter shall affect the operation of the provisions of this
Act in so far as they relate to any matter other than those before the Settlement
Commission.
(4) The Settlement Commission shall, subject to the provisions of Chapter V of the
Central Excise Act, 1944 (1 of 1944) and this Chapter, have power to regulate its own
procedure and the procedure of Benches thereof in all matters arising out of the
exercise of its powers, or of the discharge of its functions, including the places at
which the Benches shall hold their sittings.
127G. Inspection, etc., of reports. - No person shall be entitled to inspect, or obtain copies of, any
report made by any officer of the Customs to the Settlement Commission; but the Settlement
Commission may, in its discretion, furnish copies thereof to any such person on an application made
to it in this behalf and on payment of such fee as may be specified by rules :
Provided that, for the purpose of enabling any person whose case is under
consideration to rebut any evidence brought on record against him in any such
report, the Settlement Commission shall, on an application made in this behalf, and
on payment by such person of such fee as may be specified by rules, furnish him with
a certified copy of any such report or part thereof relevant for the purpose.
127H. Power of Settlement Commission to grant immunity from prosecution and
penalty. - (1) The Settlement Commission may, if it is satisfied that any person who
made the application for settlement under section 127B has co-operated with the
Settlement Commission in the proceedings before it and has made a full and trueAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

disclosure of his duty liability, grant to such person, subject to such conditions as it
may think fit to impose, immunity from prosecution for any offence under this Act or
under the Indian Penal Code (45 of 1860) or under any other Central Act for the time
being in force and also either wholly or in part from the imposition of any penalty,
fine and interest under this Act, with respect to the case covered by the settlement:
Provided that no such immunity shall be granted by the Settlement Commission in
cases where the proceedings for the prosecution for any such offence have been
instituted before the date of receipt of the application under section 127B.
(2) An immunity granted to a person under sub-section (1) shall stand withdrawn if
such person fails to pay any sum specified in the order of the settlement passed under
sub-
section (7) of section 127C within the time specified in such order or within such further time as may
be allowed by the Settlement Commission, or fails to comply with any other condition subject to
which the immunity was granted and thereupon the provisions of this Act shall apply as if such
immunity had not been granted.
(3) An immunity granted to a person under sub-section (1) may, at any time, be withdrawn by the
Settlement Commission, if it is satisfied that such person had, in the course of the settlement
proceedings, concealed any particulars, material to the settlement or had given false evidence, and
thereupon such person may be tried for the offence with respect to which the immunity was granted
or for any other offence of which he appears to have been guilty in connection with the settlement
and shall also become liable to the imposition of any penalty under this Act to which such person
would have been liable, had no such immunity been granted.
127-I. Power of Settlement Commission to send a case back to the proper officer. - (1) The
Settlement Commission may, if it is of opinion that any person who made an application for
settlement under section 127B has not cooperated with the Settlement Commission in the
proceedings before it, send the case back to the proper officer who shall thereupon dispose of the
case in accordance with the provisions of this Act as if no application under section 127B had been
made.
(2) For the purpose of sub-section (1), the proper officer shall be entitled to use all the materials and
other information produced by the assessee before the Settlement Commission or the results of the
inquiry held or evidence recorded by the Settlement Commission in the course of the proceedings
before it as if such materials, information, inquiry and evidence had been produced before such
proper officer or held or recorded by him in the course of the proceedings before him.
(3) For the purposes of the time limit under section 28 and for the purposes of interest under
section 28AA, in a case referred to in sub-section (1), the period commencing on and from the date
of the application to the Settlement Commission under section 127B and ending with the date of
receipt by the officer of customs of the order of the Settlement Commission sending the case back toAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

the officer of customs shall be excluded.
127 J. Order of settlement to be conclusive. - Every order of settlement passed under sub-section (7)
of section 127C shall be conclusive as to the matters stated therein and no matter covered by such
order shall, save as otherwise provided in this Chapter, be reopened in any proceeding under this
Act or under any other law for the time being in force."
Learned counsel for the petitioner further submits that the Settlement Commission vide final order
dated 07.03.2006 has allowed the settlement application and granted complete immunity to the
petitioner as well as his brother from penalty and prosecution. In these circumstances, the detention
of the petitioner in pursuance to the impugned order of detention would result in blatant
infringement of Article 21 of the Constitution of India as the order has been rendered totally non est
in the eyes of law. It is further submitted that in view of the acceptance of the settlement Application
by the Settlement Commission, all matters stand concluded and settled. In these circumstances, the
execution of the detention order is wholly uncalled for, unwarranted and absolutely illegal, being
based on wrong reasons and the execution would be apparently mala fide. The very constitution of
the Settlement Commission and insertion of the provisions relating to the settlement of the cases
under the Act is to achieve the twin objective of collection of evaded revenue as well as the
prevention of further evasion through similar practices. Necessarily implying thereby that by
making true and full disclosure of his liabilities and settling them, the prejudicial activities of the
evader are put to an end. Therefore, the detention order on the same accusations that have been
considered by the Settlement Commission would be rendered otiose and not worthy of execution.
Learned counsel would further submit that a perusal of section127H would clearly reveal that the
Settlement Commission has to arrive at a complete satisfaction that the Applicant before it has made
a full and true disclosure of his duty liability and while granting the immunity from
prosecution/penalty, the Commission is competent to impose "such conditions as it may think fit".
It is therefore crystal clear that while allowing the settlement of the case, the Settlement
Commission has comprehensively looked into the aspect of sealing the opportunity of any further
indulgence of the Applicants in any such activity of evasion of duty. Section 127J of the Customs Act,
1962, categorically stipulates that any matter that has been settled by the Commission would be
conclusive and the same cannot be re- opened in any proceeding under the Customs Act, 1962, or
"under nay other law for the time being in force". Viewed in this perspective, the detention of the
petitioner on the same grounds that have been considered by the settlement Commission would
tantamount to a gross abuse of the process of law.
Learned counsel further submits that the deterrent effect inflicted by the settlement Commission is
more effective and is foolproof than the method of preventive detention. Law has to select the
method, which is objective, transparent and effective in preference over the method, which is
subjective, unaccountable and ineffective.
Learned counsel further invited our attention to the law that has been enunciated by this Court in
R.K. Garg vs. Union of India, (1981) 4 SCC 675 which read as under:Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

"The Court must always remember that "legislation is directed to practical problems,
that the economic mechanism is highly sensitive and complex, that many problems
are singular and contingent, that laws are not abstract propositions and do not relate
to abstract units and are not to be measured by abstract symmetry". Every
legislation particularly in economic matters is essentially empiric and it is based on
experimentation or what one may call trial and error method and therefore it cannot
provide for all possible situations or anticipate all possible abuses. There, may be
crudities and inequities in complicated experimental economic legislation but on that
account alone it cannot be struck down as invalid. There may even be
possibilities of abuse, but that too cannot of itself be a ground for invalidating the
legislation, because it is not possible for any legislature to anticipate as if by some
divine prescience, distortions and abuses of its legislation which may be made by
those subject to its provisions and to provide against such distortions and abuses."
According to the petitioner's counsel, the case of the petitioner squarely falls with the said
exceptions and thus the impugned detention order deserves to be set aside. He would also further
submit that the case of the petitioner is squarely covered by the ratio laid down by this Court in
Additional Secretary to Government of India & Ors. vs. Smt. Alka Subhash Gadia & anr., 1992 SCC
Supp. (1) 496 wherein this Court, inter alia, has held as under: -
".Thirdly, and this is more important, it is not correct to say that the courts have no
power to entertain grievances against any detention order prior to its execution. The
courts have the necessary power and they have used it in proper cases as has been
pointed out above, although such cases have been few and the grounds on which the
courts have interfered with them at the pre-execution stage are necessarily very
limited in scope and number, viz., where the courts are prima facie satisfied (i) that
the impugned order is not passed under the Act under which it is purported to have
been passed, (ii) that it is sought to be executed against a wrong person, (iii) that it is
passed for a wrong purpose, (iv) that it is passed on vague, extraneous and irrelevant
grounds or (v) that the authority which passed it had no authority to do so"
This Court has further analysed and discussed the ratio laid down in Alka Subhash Gadia (supra) in
the matter of Subhash Muljimal Gandhi vs. L.Himingliana and Anr. reported in 1994 (6) SCC 14
wherein this Court has held as under:-
"11.   Bound as we are by the above judgments, we must hold that the other
contingencies, if any, must be of the same species as of the five contingencies referred
to therein"
Learned counsel submitted that the law has to adopt a progressive approach and when an order of
detention has been rendered infructuous by the supervening circumstances, as in the present case,
permitting the execution of the same would be a draconian measure unacceptable to the settled
tenets of justice, law and equity.Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

Learned counsel cited the case of Pawan Bhartiya vs. Union of India, reported in 2003 (11) SCC 479
wherein this Court has held as under:
"4 the custom duty which was required to be paid was paid by them before the
execution of the detention orders. Despite this fact the detention order passed against
the appellant was not revoked even though he has also paid the custom duty as
demanded "5the fact of payment of duty in the cases detected against these
persons may act as a deterrent against their chance of indulging in similar prejudicial
activities in future since this may adversely affect their financial backbone"
Learned counsel submitted that the ratio of the aforesaid case wherein the detention order was
quashed at the pre- detention stage especially taking into account the need for execution of the order
in view of payment of duties etc. is also applicable to the facts of the present case and in fact the
petitioner is placed in a much better situation as his case has also been settled by the statutory
process and has been granted complete immunities owing to true and full disclosure and full
cooperation in the settlement proceedings. It is further submitted that the factum of settlement of
the matter as well as the consequent grant of immunities had duly been conveyed to the detaining
authority i.e. respondent No.2 by the Settlement Commission. The Detaining Authority was,
therefore, bound to consider the desirability and need for execution of the impugned detention
order in view of the dramatically changed scenario. According to the learned counsel, after the
settlement of the case, the entire controversy stands buried and settled warranting forthwith
termination of the impugned detention order. Arguing further, he submitted that a citizen's right of
personal liberty under Article 21 of the Constitution cannot be deprived of by the arbitrary decision
of the statutory authority and, therefore, the order of detention so made is always subject to judicial
scrutiny and review on the touchstone of relevance and reasonableness, fair play, natural justice,
equality and non-discrimination. Considering the entire factual matrix in juxta position with the
legal issues involved, the only inference according to the petitioner's counsel that can be legitimately
drawn is that the execution of such null and void detention orders would only be punitive and not
preventive in any manner whatsoever. Learned counsel for the petitioner already invited our
attention to the case of Alka Gadia (supra) to the effect that the writ petition at pre-execution stage
is fully maintainable. The relevant observation of the extract of this Court is as under:-
"Thirdly, in the rare cases where the detenu, before being served with them, learns of
the detention order and the grounds on which it is made, and satisfies the Court of
their existence by proper affirmation, the Court does not decline to entertain the writ
petition even at the pre-execution stage, of course, on the very limited grounds stated
above."
It is, therefore, prayed that the detention order be quashed and set aside and directing the
respondents to set the petitioner at liberty forthwith.
Mr. Ravindra Keshavrao Adsure, learned counsel for the second respondent submitted that the
Detaining Authority has exercised their powers conferred by Section 3(1) of COFEPOSA Act and has
issued detention order dated 12.01.2005. It is submitted that the detention order was passed afterAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

carefully considering the entire documents of the proposal sent by the sponsoring authority and
after being subjectively satisfied that it is essential for preventing the detenu from indulging in
prejudicial activities in future and accordingly the order of detention against the petitioner as well as
his brother was passed. Learned counsel also invited our attention to the judgment of this Court in
Naresh Kumar Goyal vs. Union of India reported in 2005 (8) SCC 276 wherein this Court has
observed that Courts have power to entertain grievances against any detention order prior to its
execution only in proper cases and the grounds on which the courts interfere the detention order at
the pre-execution stage are necessarily very limited and in scope and number.
Therefore, when the courts are prima facie satisfied (i) that the impugned order is not passed under
the Act under which it is purported to have been passed (ii) that it is sought to be executed against a
wrong person, (iii) that it is passed for a wrong purpose, (iv) that it is passed on vague, extraneous
and irrelevant grounds, or (v) that the authority which passed it had no authority to do so.
Therefore, the impugned order does not suffer from any infirmity as stated above and accordingly,
the present writ petition at pre-execution stage of detention order is not maintainable. Hence, the
present writ petition is required to be dismissed.
Learned counsel for the respondent further submitted that the admittance of the case and
imposition/condonation of fine and/or penalty is the prerogative of the Settlement Commission and
application praying immunity from fine, penalty and prosecution matters pertain to the jurisdiction
of Settlement Commission. But, revocation of the detention order issued in respect of the detenue is
different issue and not governed by provisions of section 127F (2) of the Customs Act. It was
submitted that in a representation made before Settlement Commission in Shri Vipul Gor vs. Sonam
Enterprises, the Settlement Commission in its order dated 15.12.2005 rejected the plea of the
applicant therein, for making suitable recommendations to the Detaining Authority for revocation of
his detention order. In the present case the petitioner relied upon the case of Hiralal Harilal
Bhagvati vs. C.B.I (supra). The said relied upon case was a case of duty evasion and the appellant
therein was booked by Customs Department and thereafter, custom duty was paid under Kar Vivad
Samadhan Scheme (K.V.S.S) and further in the criminal proceedings under Section 120B and 420 of
I.P.C initiated by C.B.I was quashed by this Court. The above cited case is different from the present
case, as in the case in hand, the detention order was issued under COFEPOSA Act against the
petitioner with objective to prevent the nefarious activities in future. Therefore the immunity is
granted by Settlement Commission from fine, penalty and prosecution under the provisions of
Customs Act, 1962 and I.P.C have no bearing on the order issued by the Detaining Authority which
is very much legal and the same needs to be upheld.
We have carefully considered the rival submissions with reference to the entire pleadings and the
provisions of Section 127B-127J of the Customs Act and the provisions of the COFEPOSA Act.
We have also perused the annexures and records filed along with the writ petition. In our opinion,
the argument advanced by learned counsel for the respondent merit acceptance. As rightly pointed
out by learned counsel for the respondent that the admittance of the case and
imposition/condonation of fine or penalty is the prerogative of the Settlement Commission and
application praying immunity from fine/penalty and prosecution are matters pertains to theAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

jurisdiction of the Settlement Commission but the revocation of the detention order issued in
respect of the detenu is different issue and not governed by the provisions of Section 127F(2) of the
Customs Act.
At the time of hearing, learned counsel for the petitioner relied upon the case of Hiralal Harilal
Bhagwati vs. C.B.I (supra). According to learned counsel for the respondent the said relied upon
case was a case of duty evasion and appellant therein was booked by customs authority and
therefore, customs duty was paid under KVSS and further in the criminal proceedings under Section
120B and 420 IPC initiated by CBI was quashed by this Court. Therefore, it is admitted that the
above cited case is different from the present case as in the case in hand the detention order was
issued under the COFEPOSA Act against the petitioner with objective to prevent to the nefarious
activities in future. Therefore, the immunity granted by the Settlement Commission from fine,
penalty and prosecution under the provisions of the Customs Act and IPC have no bearing on the
order of detention passed under the COFEPOSA Act. Therefore, it is contended that the detention
order issued by the Detaining Authority is very much legal and the same needs to be upheld.
The Settlement Commission was constituted with the aim and objective of settling the tax evasion
issues and by virtue of disclosure by tax offender; they gain immunity from fine/penalty which is
otherwise mandatory under the provisions of tax laws. But, such opportunity is only extended to one
tax offender but not available to habitual smugglers. For the persons involved in smuggling
activities, other than the provisions made for the prosecution under the Customs Act, 1962, an equal
deterrent is emphasized under the provisions of the COFEPOSA Act, 1974 i.e. provisions for
preventive detention. Such preventive detention prohibits smugglers from indulging in further
smuggling activities. In the present case the investigation reveals the consistent involvement of the
petitioner detenue and his brother Kamlesh Navinchandra Shah in smuggling activities, therefore,
the Detaining Authority on the basis of evidence placed before him felt it necessary to issue the
detention orders in respect of both the detenues in order to prevent them from pre-judicial activities
in future. Accordingly the impugned order is justifiable in the eyes of law and present Writ Petition
deserves to be dismissed.
It is submitted that the orders of detention under COFEPOSA Act was issued in respect of the
petitioner and his brother vide orders dated 12.1.2005 and 31.1.2005 respectively whereas they had
made an application before the settlement Commission under section 127B of the Customs Act, 1962
on 19.4.2005. At the time of issue of the said Detention Orders, the Detaining Authority was not
aware of the detentues' intention of approaching the Settlement Commission. The immunity from
prosecution was granted to the petitioner and his brother by virtue of final order dated 8.3.2006 of
Settlement Commission. Since the Settlement Commission is an authority to settle the duty liability
with the discretion to grant immunity in respect of fine, penalty and prosecution, it cannot be
construed that anybody approaching the Settlement Commission, ceases to take up Settlement
Commission and the detention order under COFEPOSA Act both are distinctly different and
objectives of both the orders are also different. Therefore, it is wrongly construed by the petitioner
that once the Settlement Commission has granted unconditional immunities, the present detention
order is contrary to the settled position of law.Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

Nowhere it is stated in the provisions of Section 127H of the Customs Act, 1962 and in the order of
the Settlement Commission dated 08.03.2006 that the opportunity of further indulgence in
smuggling activities is sealed or plugged. In our view, the Settlement Commissioner's order only
dealt with true and full disclosure of the disputed duty and acceptance of the entire duty, liability by
the petitioner and his brother. Nowhere it is mentioned in the Settlement Commission's order that
the petitioner would not indulge in smuggling of goods in future. Therefore, in order to prevent the
detenu from indulging in smuggling activities, the said detention order was passed and there is no
illegality in the detention order. In the instant case, the customs duty of Rs.1.4 crores was sought to
be evaded by the petitioner and his brother was accepted in full by them. This acceptance of entire
duty demanded in the impugned show cause notice was interpreted as full and true disclosure by the
Settlement Commission and as such the petitioner and the co-applicants were directed to pay the
said amount of duty during the Settlement Commission proceedings. The said customs duty of
Rs.1.4 crores was expected to be paid by the petitioner and others at the time of import of the
impugned consignments during September, 2004. However, the said amount of evaded customs
duty was ordered to be paid in the month of March, 2006 by the Settlement Commission. The
Settlement Commission, while extending the benefits as envisaged in the true spirit of settlement,
have granted immunity from fine, penalty and prosecution under the Customs Act, 1962 and IPC.
The final order of the Settlement Commission has, by no means, undermined the surroundings of
the offence committed by the petitioner and his brother. In the admission order
No.36/Customs/2005 of the Settlement Commission dated 03.01.2006, the Commission also
distinctly demarcated the area of jurisdiction of the Settlement Commission and the matter of
COFEPOSA. The Settlement Commission adhered strictly to the aspect of levy of customs duty and
on the basis of the full and true disclosure by the petitioner and others, in that respect, settled the
case by directing full payment of customs duty and having done so, extended the benefit of
immunity from fine, penalty and prosecution. Thus the matters of Settlement Commission and the
COFEPOSA are altogether different issues, the orders of the respective authorities should not and
cannot be binding or influencing each other. As such the outcome of the Settlement Commission
order should not have any bearing on the detention order. Concluding his argument, learned
counsel for the respondent submitted that the preventive detention under COFEPOSA is distinctly
different from the prosecution under the Customs Act, 1962 and IPC, the sanctity of the detention
order issued by the second respondent as the Detaining Authority, should be upheld and the same
should be ordered to be served upon the petitioner in the interest of justice.
Though the matter was argued by learned counsel for the respondent on merits, learned counsel for
the respondent at the time of hearing in fairness placed before us the reported opinion dated
05.06.2006 of the Advisory Board constituted under the COFEPOSA Act, 1974 in respect of the
detenu Kamlesh Navinchandra Shah, the brother of the petitioner. Para 6 of the order dated
04.05.2006 of the Advisory Board constituted under Section 8(a) of the Act 52 of 74 by the
Government of Maharashtra was placed before us. We have perused the said order. In para 6, the
Advisory Board has observed as under:
"After the final order passed by the Settlement Commission of Customs and Central
Excise, the detention order has been executed. The detenue and his brother had
extended full co- operation and full customs duty as demanded by the Revenue hasAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

been paid and the case finally settled. The Commission had given unconditional
immunity from prosecution as well as penalty. A copy of the order has been
forwarded by the Commission to the Detaining Authority and yet the detention order
was executed on his brother i.e. detenue Kamlesh Shah. He further stated that he
challenged the order of his detention at pre-execution stage in the Supreme Court
and Supreme Court has given Interim stay of the operation of impugned order."
It is thus seen that the Settlement Commission has, in its order, under the head 'penalty' and
'prosecution' granted immunity from penalty and prosecution to the co-applicant and in these
circumstances the Advisory Board was of the opinion that there was no sufficient cause for the
continued detention. Learned counsel for the respondent has also placed before us the opinion of
the Advisory Board which reads thus:
"The Advisory Board is of the opinion that there is no sufficient cause for the
detention of abovenamed detenue under section 3(1) of COFEPOSA Act, 1974.
The consequential communication dated 05.06.2006 and the order dated
05.06.2006 were also placed before us which read thus:-
"The Advisory Board has reported that there is no sufficient cause for the detention of
Shri Kamlesh Navinchandra Shah. The government has accordingly revoked the
detention order issued against him. The revocation order (in triplicate) is enclosed
herewith. One copy of revocation order should be served on the detenue concerned
and the duplicate copy of the same alongwith signature of the detenue with date
should be returned immediately to the undersigned. Third copy should be retained
for your record."
"ORDER Whereas, an order No. PSA-1204/21(1)/SPL-3(A), dated the 31st January
2005, has been passed by the Principal Secretary (Appeals and Security) to the
Government of Maharashtra, home Department and Detaining Authority under
section 3(1) of the Conservation of Foreign Exchange and Prevention of Smuggling
Activities Act, 1974 (52 of 1974) for the detention of Shri Kamlesh Navinchandra
Shah, Whereas, the case of Shri Kamlesh Navinchandra Shah was placed before the
Advisory Board, which is of the opinion that there is no sufficient cause for his
detention; and Whereas, the Government of Maharashtra has fully considered the
report of the Advisory Board and material on record;
Now, therefore, in exercise of the powers conferred by Section 8(f) of the aforesaid
Act, the Government of Maharashtra hereby revokes the aforesaid Detention Order
and further directs that said Shri Kamlesh Navinchandra Shah be released forthwith
on receipt of this order."
Another decision cited by learned counsel for the petitioner in V.C.Mohan vs. Union of India
reported in 2002 (3) SCC 451 and the observations made thereunder can also be usefully applied toAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

the facts of this case. In the case of Pawan Bhartiya vs. Union of India and Another, 2003 (11) SCC
479, the appellant challenged the detention order dated 30.07.1996 passed under Section 3(1) of the
COFEPOSA Act, 1974 before the High Court of Delhi. That petition was rejected by the High Court
by holding that it is not a fit case where any interference is called for before the execution of the
order of detention. At the time of hearing, learned counsel for the appellant pointed out that similar
detention orders were passed against 6 persons during the period from 07.12.1995 to 12.08.1996
and further pointed out that 5 out of 6 detention orders were revoked by the competent authority on
the ground that the customs duty which was required to be paid was paid by them before the
execution of the detention orders. Despite this fact the detention order passed against the appellant
was not revoked even though he has also paid the customs duty as demanded. It has also been
pointed out that the sponsoring authority submitted its report before the Detaining Authority to
revoke the detention order which was passed against the appellant. The Joint Secretary to the
Government of India, Ministry of Finance has filed an affidavit in this case wherein it is submitted
that similar 5 detention orders were revoked. This Court (M.B. Shah and Brijesh Kumar, JJ) in para
6 & 7 observed as under:-
"6. In our view, there is no reason to discriminate the appellant and the reason given
by the authority in not revoking the detention order could hardly be justified. It is
true that normally before the execution of the detention order the same is not
required to be quashed and set aside. However, considering the peculiar facts and
circumstances of the case, in our view, no purpose will be served by continuing the
detention order. It is pointed out that the appellant has ceased his activities in the
field of import or export. He has already paid the tax with penalty as demanded by
the authority. There is nothing on record that since the last five years the appellant
has indulged in any such activity. It is to be noted that the purpose of passing the
detention order is to prevent the detenu from continuing his prejudicial activity but
not to punish him.
7. Hence, in view of the facts and circumstances of the present case, the impugned
order dated 30-7-1996 passed by the Joint Secretary to the Government of India
under Section 3(1) of COFEPOSA is quashed and set aside. The appeal is allowed
accordingly."
The above judgment, in our view, squarely applies to the facts and circumstances of the case on
hand. In the instant case, the petitioner's brother has already been released on the ground there was
no sufficient cause for the detention of the detenu under Section 3(1) of the Act. The Government
also accordingly revoked the detention order issued against him and the Government of
Maharashtra, after considering the report of the Advisory Board and the material on record and in
exercise of the powers conferred by Section 8(f) of the COFEPOSA Act revoked the aforesaid
detention order and further directed that Kamlesh Navinchandra Shah be released forthwith on
receipt of the said order dated 05.06.2006. In our opinion, the petitioner before us who is also
similarly placed and who has also paid the customs duty etc. pursuant to the order of the Settlement
Commission and got the unconditional immunity by the Settlement Commission is entitled to the
same treatment. At the time of hearing, it is pointed out that the petitioner has ceased his activitiesAlpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

in the field of import or export and has already paid the tax with penalty as demanded by the
authority and there is nothing on record that the appellant has indulged in any such activity in the
recent past. It is settled by law that the purpose of passing the detention order is to prevent the
detenu from continuing his prejudicial activity but not to punish him. Considering the peculiar facts
and circumstances of the case, no purpose will be served by continuing the detention order and we,
therefore, allow the writ petition and quash and set aside the detention order bearing No. PSA
1204/21(2)/SPL-3(A) dated 12.01.2005.
The writ petition is ordered accordingly.Alpesh Navinchandra Shah vs State Of Maharashtra & Ors on 26 February, 2007

