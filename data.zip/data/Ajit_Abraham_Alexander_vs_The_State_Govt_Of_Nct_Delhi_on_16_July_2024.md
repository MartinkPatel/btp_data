Ajit Abraham Alexander vs The State Govt. Of Nct Delhi on 16
July, 2024
Author: Neena Bansal Krishna
Bench: Neena Bansal Krishna
                                    $~49
                                    *           IN THE HIGH COURT OF DELHI AT NEW DELHI
                                    +           BAIL APPLN. 2428/2024, CRL.M.A.20454/2024
                                                AJIT ABRAHAM ALEXANDER                                                              .....Petitioner
                                                                                      Through:                 Mr. Tanveer Ahmed Mir, Mohd.
                                                                                                               Shahrukh Ali, Ms. Anushka Khaitan
                                                                                                               and Mr. Avineesh Jha, Advocates.
                                                                                      versus
                                                THE STATE GOVT. OF NCT DELHI                .....Respondent
                                                             Through: Mr. Amit Ahlawat, APP for the State
                                                                       with SI Atul Yadav, SHO/Inspector
                                                                       Kuldeep Singh, PS Cyber SED.
                                                                       Mr. Vijay Aggarwal, Mr. Mukul
                                                                       Malik, Mr. Rachit Bansal and Mr.
                                                                       Kshitiz   Garg,    Advocates     for
                                                                       complainant.
                                                CORAM:
                                                HON'BLE MS. JUSTICE NEENA BANSAL KRISHNA
                                                                                      ORDER
% 16.07.2024
1. A Bail Application under Section 438 Cr.P.C has been filed on behalf of the petitioner seeking
Anticipatory Bail in respect of FIR No.42/2024 dated 24.05.2024 registered at Cyber Police Station,
South-East under Section 406/411 IPC and Section 43 of IT Act, 2000.
2. It is submitted that the petitioner/accused Ajit Abraham Alexander a highly educated Global
professional, was employed as Chief Growth Officer by M/s BLS/the Complainant Company vide
Appointment Letter dated 10.07.2021 and he started working in the concerned Department of the
Complainant's Company. The petitioner in order to enable and facilitate This is a digitally signed
order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:40
himself to work from home, emailed relevant documents pertaining to the Project that the petitioner
was working on, using his office ID to his personal ID which he could access from his residence. It is
submitted that this practice was followed not just by the petitioner but by other employees alsoAjit Abraham Alexander vs The State Govt. Of Nct Delhi on 16 July, 2024

working in the Complainant's Company.
3. On 23.12.2023, the petitioner received an offer letter from M/s Atlys to join as its Head Business
to Government. Due to the petitioner's ongoing commitments with M/s BLS, he did not accept the
offer of M/s Atlys immediately, and joined the Company as a Consultant and was duly remunerated
for the same. It is submitted that the petitioner was not involved in any manner in any of the
Projects/Tenders wherein M/s BLS competed with M/s Atlys. The petitioner tendered his
resignation to M/s BLS on 09.05.2024 by sending an email and thereafter, took necessary steps to
get onboard as a full time employee of M/s Atlys.
4. Thereafter, the petitioner came to know that M/s BLS, the complainant filed a Complaint against
him on 13.05.2024 on the grounds that the petitioner had shared confidential price-sensitive
information with M/s Atlys by mailing certain work documents from his Office ID to his personal ID
and that the petitioner had forged authorization in order to gain access to classified information.
5. On 15.05.2024, the petitioner was called upon by the Police of Police Station Badarpur to
participate in the Preliminary Enquiry and was also asked to bring his laptop and sim card
belonging to the complainant Company. On 16.05.2024, the petitioner participated in the
preliminary inquiry and handed over the official Laptop and sim card to the Police. Despite fully
cooperating with the preliminary enquiry, FIR No.42/2024 was This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:40
registered by the PS Cyber Police Station, South East on 24.05.2024.
6. On the apprehension of arrest by the Police, the petitioner filed an application for grant of
Aniticipatory Bail before learned ASJ (FTC), South- East District, Saket Courts. Vide Interim Order
dated 07.06.2024 the learned ASJ (FTC) directed the petitioner to join the investigations as per the
instructions of the I.O and the Police was also directed not to take coercive action against the
petitioner.
7. On 10.07.2024 the learned District & Sessions Judge (South-East), Saket Courts dismissed the
application seeking anticipatory bail by the petitioner. The petitioner has thus, filed the present
application for grant of Anticipatory bail.
8. Learned counsel for the petitioner has submitted that the only allegations made against the
petitioner are of theft of Company data, but even the prima facie allegations are not sustainable.
Essentially, the allegations of the prosecution are that the petitioner is not joining investigations and
has failed to hand over his Laptop, however, he had joined the investigation on 16.05.2024 and
handed over his Laptop, Sim card and Mobile Phone. He was thereafter, served with a Notice under
Section 91 Cr.P.C on 12.06.2024 to which he gave his detailed reply in writing giving information
about all the queries that were put to him. He also surrendered his Laptop and the Mobile Phone to
Inspector Kuldeep Singh in the presence of SI Manjoor Alam who seized it vide Memo dated
19.06.2024.Ajit Abraham Alexander vs The State Govt. Of Nct Delhi on 16 July, 2024

9. The only claim of the prosecution is that they need the Laptop and the Mobile Phone to ascertain
whether any Data was indeed transferred. However, the Laptop has already been handed over and
there is nothing This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:40
more to be handed over by the petitioner. It is further argued that according to the prosecution it is
a case of data theft, which was essentially effected by the petitioner through the emails. All the
details of the emails of the petitioner have already been given in writing and the passwords have also
been disclosed for the I.O to conduct a thorough investigations. Furthermore, there are no prima
facie case of 406 and 409 of IPC is made out against the petitioner.
10. Realizing that they have no case against the petitioner, the complainant has made specious
allegations of fake hotel bills of 2022 having been submitted by the petitioner while the petitioner
was in the employment of the Company. It is stated that there is no custodial interrogation of the
petitioner required. The Laptops and the Mobile Phone and the requisite data has already been
made available to the I.O. The petitioner has, therefore sought Anticipatory Bail.
11. Learned counsel for petitioner has relied upon the judgment of Thomas Klaus Eschner vs. The
State of Maharashtra and Anr. Anticipatory Bail Appl.No.3270 of 2023 decided by High Court of
Judicator at Bombay decided on 01.07.2024 to argue that in the similar facts of data theft by an
employee, it was observed by the Bombay High Court that the implication of the petitioner for the
offence punishable under Section 408 IPC appeared contestable as the applicant cannot be said to
be entrusted with data since he had parted ways with the Company much prior to the date when the
dispute arose between the members of the family owning the Company. In a situation of this nature,
whether there were elements of deceit coupled with injury so as to constitute an offence of cheating
under Section 420 qua the petitioner also appears debatable.
This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:40
12. The learned counsel for the petitioner aside from various other judgments had also relied upon
the judgment of Sushila Aggarwal and Ors. Vs. State (NCT) of Delhi and Anr. (2020)5 SCC 1 ,
wherein a reference was made to the judgment of Gurbaksh Singh Sibbia vs. State of Punjab (1980)
2 SCC 565, wherein the Apex Court had observed that when a person complains of apprehension of
arrest and approaches the Courts, the application should be based on concrete facts and not vague
and general allegations relatable to one or other specific offence. The Application seeking
Anticipatory Bail should contain essential facts relating to the offence and why the applicant
reasonably apprehends arrest as well his side of the story. It was also observed that even while
considering limited interim anticipatory bail application, it is advisable for the Court depending
upon the seriousness of the threat (of arrest), to issue Notice to the Public Prosecutor and obtain
facts. Further, an order of Anticipatory bail does not in any manner restrict or limit the right or theAjit Abraham Alexander vs The State Govt. Of Nct Delhi on 16 July, 2024

duties of the police to investigate into the charges against a person, who seeks and is granted
pre-arrest bail.
13. Learned Prosecutor on behalf of the State has argued that there is recovery of laptop and other
material to be effected from the petitioner, in order to establish the data theft. The petitioner has not
been cooperative during investigations and has been evasive in his endeavours. There are serious
allegations of forgery, data theft and of breach of trust and of unauthorized access to the date of the
Company for which custodial interrogation is imperative and the petitioner cannot be granted
Anticipatory Bail.
14. Learned counsel for the Complainant has vehemently argued that This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:40
there are serious allegations of breach of the trust punishable under Section 406 and 409 IPC. The
petitioner while being in the employment of the complainant Company has taken the appointment
in another Company namely M/s Atlys surreptitiously without disclosing this fact to the
complainant Company. There was serious data in regard to Tenders to which the petitioner had an
access and has been transferred from office ID to personal ID and has been probably disclosed to the
subsequent employer leading to serious financial loss to the complainant Company. There were
malafides on the part of the petitioner that he has worked under a scheme of things, is evident from
the fact that once he had taken up a job with another Company, there was no reason for him to not
disclose this fact for three months to the complainant Company. The only inference that can be
drawn is that he had a mala fide intent to transfer the data which is the "life line" of the complainant
Company, to the subsequent employer and thereby cause loss to the complainant Company.
15. It is also vehemently argued that the petitioner was getting Rs.7 lakhs per annum in this
Company but has joined the subsequent Company on a substantial increase of salary of Rs.17 lakhs
per annum which is more than the double of his earlier salary. The very fact that he has joined on
double the salary, can only lead to the inference that he has suddenly become of immense use to his
subsequent employer and that can be only because of all the data of the complainant Company
which has been stolen, has been made available to the subsequent Company.
16. Learned counsel for the Complainant has relied upon the Judgment of Ramandeep Singh @
Ramandeep Singh Aulakh & Anr. Vs. State of Punjab Crl. Misc.29553 and 30630 of 2020 decided on
17.03.2021 wherein it was This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:41
observed that "where cyber crime is involved and the complainant accuses its former manager of
stealing its software data a and a case is registered under I.T Act, anticipatory bail ought not be
allowed". Reliance has also been placed on State (NCT of Delhi) vs. Sanjay (2014) 9 SCC 772,
wherein the Apex Court observed that "In contravention of terms and conditions of lease by
dishonestly removing the property of the State, out of the State's possession without the consent,Ajit Abraham Alexander vs The State Govt. Of Nct Delhi on 16 July, 2024

constitute an offence of theft".
17. Learned counsel for the complainant has vehemently submitted that the judgment of Thomas
Klaus Eschner (Supra) relied upon by the petitioner is totally misplaced in so much as in the said
case the dispute had arisen about transfer of data after the accused had left the job, while in the
present case the data theft has happened when the petitioner was in the active employment of the
complainant Company.
18. Submissions heard.
19. In today's era of digital world, where all the data of a Compnay is essentially stored digitally, its
theft by its employees has become extremely easy because of its ease of access and transferability.
Here are serious allegations made against the complainant that while he was in the employment of
the Complainant Company and had access to the entire Company data, had surreptitiously
transferred it with the sole objective of transferring it to his subsequent employer and thereby
caused huge loss to the Complainant Company. Prima facie it is also evident that he has gained
unlawfully in getting the next employment on more than double the salary without showing his
expertise which entailed such a huge jump.
20. Prima facie, as has been argued on behalf of the State these circumstances lead to the inference
of there being a huge data transfer of the This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:41
Complainant Company to the prospective employer. Furthermore, it is stated that the detailed
further enquiry is required to establish how the Tender information which is of extreme value to the
Complainant Company, has been passed on to the other Company is much to the detriment of the
Complainant Company.
21. Considering the amorphous nature of the investigations which required specialized techniques of
investigation and considering the surrounding circumstances, as discussed above, it is not a fit case
for grant of Anticipatory Bail.
22. The application is hereby dismissed.
NEENA BANSAL KRISHNA, J JULY 16, 2024 va This is a digitally signed order.
The authenticity of the order can be re-verified from Delhi High Court Order Portal by scanning the
QR code shown above. The Order is downloaded from the DHC Server on 17/07/2024 at 21:50:41Ajit Abraham Alexander vs The State Govt. Of Nct Delhi on 16 July, 2024

