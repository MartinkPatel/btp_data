Gagan Harsh Sharma And Anr vs The State Of Maharashtra And
Anr on 26 October, 2018
Equivalent citations: AIRONLINE 2018 BOM 1385
Author: Bharati H. Dangre
Bench: Ranjit More, Bharati H. Dangre
                                                    jud-917-wp-4361-2018
        IN THE HIGH COURT OF JUDICATURE AT BOMBAY
              CRIMINAL APPELLATE JURISDICTION
                 CRIMINAL WRIT PETITION NO.4361 OF 2018
                                 WITH 
                  CRIMINAL APPLICATION NO.403 OF 2018
                                   IN
                 CRIMINAL WRIT PETITION NO.4361 OF 2018
 1.       Gagan Harsh Sharma
          R/at : 1001/02, Y-Wing,
          Callalily, Nahar Amrit Shakti,
          Chandivali, Saki Vihar Road,
          Andheri East, Mumbai-400072
 2.       Shagun Sharma
          S/o Shiv Kumar Sharma
          R/at B-49, Old Roshanpura,
          Najafgarh, New Delhi-110043                    ...Petitioners
                      V/s.
 1.       The State of Maharashtra
          Through Sr. Police Inspector,
          Shahupuri Police Station,
          Kolhapur, Maharashtra
 2.    Shadab Abdul Shaikh
       Administration and Human Resource Head
       Manorama Infosolutions Pvt. Ltd.
       B/1A/12, Flat No.F-1,4,5
       5th Floor, DC Plaza, Nagala Park,
       Kolhapur Maharashtra-416003                    ...Respondents
                                   ----
 Mr.Vikram   Choudhari,   Senior   Counsel   a/w   Dr.Sujay   Kantawala,
 Neha Ahuja, Aishwarya Kantawala, Sangeeta Narayanan i/b Sebin
 Michael Joseph for the Petitioners in WP No.4361 of 2018.Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

 Mr.S.D.  Shinde,   APP  for   the   Respondent-State   in   WP  No.4361  of
 2018.
        N.S. Kamble                                                 page 1 of 45
::: Uploaded on - 01/11/2018                   ::: Downloaded on - 01/11/2018 23:22:09 :::
                                                          jud-917-wp-4361-2018
 Mr.Shirish Gupte, Senior Counsel a/w N.S. Mundargi, Pandit Kasar,
 Rohit Mangsule, Harish Khedkar i/b Mr.Vis Legis Law Practice for
 Respondent No.2 in WP No.4361 of 2018.
                                ----
                                  CORAM : RANJIT MORE &
                                            SMT.BHARATI H. DANGRE, JJ.
                                  RESERVED ON : 19th OCTOBER 2018
                                  PRONOUNCED ON : 26th OCTOBER 2018
 JUDGMENT :
(Per Smt.Bharati H. Dangre,J)
1. The principle question that arise in the present Criminal Writ Petition is whether the invocation
and application of the provisions of the Indian Penal Code can be sustained in the facts and
circumstances of the case when the offences committed by the petitioners are also sought to be
brought within the purview of the Information Technology Act, 2000, in light of the judgment of the
Hon'ble Apex Court in the case of Sharat Babu Digumarti V/s. Government (NCT of Delhi)1 In order
to appreciate the controversy involved in the petition it would be necessary to refer to the basic facts
involved in the matter. The petitioners before us are two brothers. The petitioner No.1 is an
Electronic Engineer employed as Vice President-Strategy and Business Development of M/s.Bliss
GVS 1 (2017) 2 SCC 18.
        N.S. Kamble                                                      page 2 of 45
                                                           jud-917-wp-4361-2018
Pharma Ltd., India, a Pharmaceuticals Company engaged in the business of manufacturing,
distribution and marketing of pharmaceuticals products across the globe. The petitioner No.2 is a
Graduate in Information Technology and a software developer undertaking activity of softwareGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

development for use in the healthcare industry. The two petitioners are arraigned as accused in
Crime No.0346 of 2017 registered with Shahupuri Police Station on 27.08.2017. The First
Information Report alleges that they have indulged themselves in offences punishable under
Sections 408, 420 of the Indian Penal Code and also offences under Sections 43, 65 and 66 of the
Information Technology Act, 2000. The FIR is registered on a complaint filed by one Shadab Abdul
Shaikh, an employee of M/s.Manorama Infosolutions Pvt. Ltd., Kolhapur in the capacity as Human
Resources Head. It is alleged in the said complaint that M/s.Manorama Infosolutions Pvt. Ltd.,
Kolhapur, is a company engaged in the activity of developing healthcare softwares for Hospital
management and is involved in development and distribution of the said software. It is alleged that
the company has engaged 171 employees. Every employee at the time of his recruitment is duty
bound to submit an undertaking/bond to the company that he will not disclose any details of the
work of the company, source code or any information about software to any N.S. Kamble page 3 of
45 jud-917-wp-4361-2018 other company while in service or after service in relation to the health
care software development. The complainant who is entrusted with the supervision of the employees
work is duty bound to ensure that there is no violation of the bond/undertaking given by the
employees and it is alleged that while he was scrutinizing the profile of one Suraj Mahajan, it is
revealed that he has developed his own software and also distributed the same. The complainant
suspected theft of data and software of the company and checked the details of Suraj Mahajan and
also informed the Director that Suraj Mahajan was involved in stealing software namely Cleave
Track with the help of Gururaj Janardhan Nimbargi who is the Head of the company. On inquiry, it
is revealed that the software was developed by the company and not by Suraj Mahajan in his
personal capacity and the server access of the company was given to Suraj Mahajan as an employee
of the company.
2. On the basis of the said complaint the FIR was registered and Suraj Mahajan came to be arrested.
Thereafter, one Anand Sanmani was also arraigned as accused No.2 and came to be arrested in
relation to the said crime. During the course of the investigation, it is revealed that M/s.Manorama
Infosolutions Pvt. Ltd. had entered a deal with M/s.Bliss, in Kenya, ERP software for N.S. Kamble
page 4 of 45 jud-917-wp-4361-2018 healthcare division operating in Kenya and it developed the said
software. The demonstration in relation to the said software was given by various employees which
included Anand Sanmani. The investigation further reveal that this Anand Sanmani was
manipulated and he joined the petitioners who intended to sell the said software in the Continent of
Africa. It is also revealed that the employees of M/s.Manorama Infosolutions Pvt. Ltd. were directed
to use the knowledge bank, resourses and the source code of M/s.Manorama Infosolutions Pvt. Ltd.,
resultantly all necessary financial aid and the company data of the company was transferred to the
petitioners and their new company namely RiteSource Pharma Solutions Pvt. Ltd.
3. In the backdrop of these facts the petitioners have approached this Court through the present
petition praying for the relief sought in the petition.
The learned Senior Counsel Shri.Vikram Chaudhary arguing on behalf of the petitioners would rely
on a judgment of the Hon'ble Apex Court in the case of Sharat Babu Digumarti V/s. Government
(NCT of Delhi) (Supra) and it is his submission that the criminal proceedings against the petitioners
are misconceived. He would submit that Section 43 of the Information Technology Act, N.S. KambleGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

page 5 of 45 jud-917-wp-4361-2018 2000 read with Section 66 is sufficient to take care of the acts
alleged against the present petitioners. It is the submission of the learned Senior Counsel
Shri.Chaudhary that the offences under the Information Technology Act are compoundable and
bailable. He would invite our attention to Section 77A and 77B of the Act of 2000. His precise
submission is that by invoking and applying the provisions of the Indian Penal Code, attempt is
made to deprive them of benefit of bail and compounding, which is available under the I.T. Act,
2000. The learned senior counsel would submit that in light of the binding precedent laid down by
the Hon'ble Apex Court in the aforesaid judgment (Supra), the provisions of the Information
Technology Act has been given an overriding effect to cover criminal acts contained in the Indian
Penal Code and this law which is a special law must prevail over the general law and therefore
invocation of provisions of Indian Penal Code against the petitioners in the facts of the case is ex
facie, erroneous and without jurisdiction. As per Shri.Chaudhary, the continuation of the
proceedings against the petitioner under the provisions of the Indian Penal Code is nothing but
abuse of process of law and therefore he would pray for quashing of the criminal proceedings in the
impugned C.R. 0346 of 2017 qua the petitioners only to the extent of invocation and application of
the offences punishable under the N.S. Kamble page 6 of 45 jud-917-wp-4361-2018 Indian Penal
Code.
4. We have heard the learned APP appearing for the Respondent-State and Shri.Shirish Gupte,
learned Senior Counsel representing the respondent No.2. According to Shri.Gupte, the petitioners
are the main accused and the master mind behind the offence with which they are charged and in
connivance and by inducing the co-accused, the employees of the M/s.Manorama Infosolutions Pvt.
Ltd., they have committed the offence and caused financial loss to the company. Submission of
Shri.Gupte, is that the company had developed software namely Lifeline E Clinic Enterprises and
Lifeline E Claims for M/s.Bliss GVS Healthcare and a team was constituted in October 2015 to visit
Kenya. The petitioner No.1 was introduced to the remaining team of the company and he was the
key person in this project as the team of the said company would submit the daily report to the
petitioner No.1. It is the specific submission of the learned Senior Counsel that the petitioner No.1
called for E-Claims source code and Database company from Mr.Sanmani and directed him to
transfer the source code to him and to his team at Delhi. It is further alleged that Mr.Sanmani
assisted the petitioner to redefine the existing functionality E-claims for future sale of E-claims
application and on instructions of the N.S. Kamble page 7 of 45 jud-917-wp-4361-2018 petitioner
No.1, Mr.Sanmani asked Mr.Suraj Mahajan to transfer the Code of E-Claims and E-Claims Database
from the companies' server to the petitioner No.1,2 and their team. It is in this backdrop according
to the learned Senior Counsel the judgment of the Hon'ble Apex Court would have to be read.
Shri.Gupte relied on the latest judgment of the Hon'ble Apex Court in Criminal Appeal No.1195 of
2018 in case of The State of Maharashtra and Anr. V/s. Sayyed Hassan Sayyad Subhan and Ors
delivered on 20th September 2018. His submission is that the Hon'ble Apex Court has held that
there is no bar in prosecuting the persons under the Penal Code where the offences committed are
cognizable offences and merely because the provisions in the Food Safety and Security Act
constitute an offence, there is no bar to prosecute them under the Indian Penal Code. In backdrop of
the said judgment he would pray for dismissal of the Writ Petition.Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

5. During the course of the hearing of the matter, the learned counsel for the petitioner has placed
on record, copy of the order passed by the Hon'ble Apex Court on 03.10.2018 in Special Leave to
Appeal (CRL) 8274 of 2018 in case of the petitioner No.1 who had approached it being aggrieved by
the rejection of his Anticipatory Bail. We have perused the said order. The Hon'ble N.S. Kamble
page 8 of 45 jud-917-wp-4361-2018 Apex Court, in the backdrop of the factum of Writ Petition
No.4361 of 2018 being filed by the petitioners before the Bombay High Court for quashing the
provisions of the Indian Penal Code, has observed that since the matter was examined by the High
Court whether the case is primarily under the Information Technology Act and whether Sections
408 and 420 of Indian Penal Code can be applied, made the following observations :-
"Having regard to the aforesaid development, since the matter is now being
examined by the High Court in the aforesaid context namely, whether the case is
primarily under Sections 43,65 and 66 and no case can be filed under Sections 408
and 420 of the IPC and also the petitioner has been given interim protection therein,
it is not necessary to deal with the subject matter of this petition. We may record that
this petition is filed against the order of the High Court rejecting the anticipatory bail
of the petitioner. Suffice is to state that in the aforesaid criminal proceedings the
High Court shall examine the matter without being influenced by any observations
made by the High Court in the impugned order. We may also clarify that this Court
has not expressed any opinion on the merits of the case."
6. In light of the facts referred to above we have heard the respective Senior Counsels and perused
the material placed before N.S. Kamble page 9 of 45 jud-917-wp-4361-2018 us.
The Information Technology Act, 2000 is a legislation to provide legal recognition for transactions
carried out by means of electronic data inter change and other means of electronic communication,
commonly referred to as "electronic commerce"
which involve the use of alternatives to paper-based methods of communication and
storage of information, to facilitate electronic filing of documents with the
Government Agencies and further to amend the Indian Penal Code, the Indian
Finance Act, 1872 etc. The said Act has been brought into force from 17 th October
2000.
The introduction of new communication system and digital technology has
necessitated the said enactment with a view to facilitate Electronic Governance. With
proliferation of information technology enabled services such as e-governance,
e-commerce and e-transactions, protection of personal data and information and
implementations of security practices and procedures relating to these applications of
electronic communications have assumed great importance and the Enactment was
necessitated in the backdrop of the security of the nation, economy, public health and
safety.Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

7. Perusal of the said provisions of the I.T. Act, 2000 would reveal that it provides complete
mechanism for protection of N.S. Kamble page 10 of 45 jud-917-wp-4361-2018 data in a computer
system or a computer network. The computer system is intended to cover a device or collection of
devices, including input and output support devices capable of being used in conjunction with
external files, containing computer programs, electronic instructions, input and output data, data
storage and retrieval. The said enactment is a complete code which deals with electronic governance
and confers a legal recognition on electronic records and the manner in which such records can be
secured. The said Act of 2000 makes certain acts punishable in Chapter-IX and Chapter-XI of the
said act which enumerates the offences related to the computer including the source documents.
Thus, the said enactment is a complete Code in itself and deals with various aspects of electronic
data and computer system.
Section 43 of Information Technology Act, 2000 prescribes penalty and compensation for damage
to computer and computer system needs a reproduction:-
43 [Penalty and compensation] for damage to computer, computer system, etc. -If
any person without permission of the owner or any other person who is incharge of a
computer, computer system or computer network,-
(a) accesses or secures access to such computer, computer system or computer
network [or computer resource];
      N.S. Kamble                                                            page 11 of 45
                                                                 jud-917-wp-4361-2018
(b) downloads, copies or extracts any data, computer data base or information from
such computer, computer system or computer network including information or data
held or stored in any removable storage medium;
(c) introduces or causes to be introduced any computer contaminant or computer
virus into any computer, computer system or computer network;
(d) damages or causes to be damaged any computer, computer system or computer
network, data, computer data base or any other programmes residing in such
computer, computer system or computer network;
(e) disrupts or causes disruption of any computer, computer system or computer
network;
(f) denies or causes the denial of access to any person authorised to access anyGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

computer, computer system or computer network by any means;
(g) provides any assistance to any person to facilitate access to a computer, computer
system or computer network in contravention of the provisions of this Act, rules or
regulations made thereunder;
(h) charges the services availed of by a person to the account of another person by
tampering with or manipulating any computer, computer system, or computer
network,
(i) destroys, deletes or alters any information residing in a computer resource or
diminishes its value or utility or affects it injuriously by any means;]
(j) steal, conceals, destroys or alters or causes any person N.S. Kamble page 12 of 45
jud-917-wp-4361-2018 to steal, conceal, destroy or alter any computer source code
used for a computer resource with an intention to cause damage;] [he shall be liable
to pay damages by way of compensation to the person so affected]. Explanation.- For
the purposes of this section,-
(i) "computer contaminant" means any set of computer instructions that are
designed-
(a) to modify, destroy, record, transmit data or programme residing within a
computer, computer system or computer network; or
(b) by any means to usurp the normal operation of the computer, computer system,
or computer network;
(ii) "computer database" means a representation of information, knowledge, facts,
concepts or instructions in text, image, audio, video that are being prepared or have
been prepared in a formalised manner or have been produced by a computer,
computer system or computer network and are intended for use in a computer,
computer system or computer network;
(iii) "computer virus" means any computer instruction, information, data or
programme that destroys, damages, degrades or adversely affects the performance of
a computer resource or attaches itself to another computer resource and operates
when a programme, data or instruction is executed or some other event takes place in
that computer resource;
      N.S. Kamble                                                              page 13 of 45Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

                                                                jud-917-wp-4361-2018
(iv) "damage" means to destroy, alter, delete, add, modify or rearrange any computer
resource by any means;
(v) "computer source code" means the listing of programmes, computer commands,
design and layout and programme analysis of computer resource in any form.] It is
apposite to refer Section 65 and 66 which reads thus :-
"65. Tampering with computer source documents:-
Whoever knowingly or intentionally conceals, destroys or alters or intentionally or
knowingly causes another to conceal, destroy or alter any computer source code used
for a computer, computer programme, computer system or computer network when
the computer source code is required to be kept or maintained by law for the time
being in force, shall be punishable with imprisonment up to three years, or with fine
which may extend upto two lakh rupees, or with both.
Explanation-For the purposes of this section, computer source code" means the
listing of programmes, computer commands, design and layout and programme
analysis of computer resource in any form."
66. Computer related offences:- If any person, dishonestly or fraudulently, does any act referred to
in Section 43, he shall be punishable with imprisonment for a term which may extend to three years
or with fine which may extend to five lakhs rupees or with both.
      N.S. Kamble                                                            page 14 of 45
                                                              jud-917-wp-4361-2018
Explanation-For the purposes of this section-
(a) the word "dishonestly" shall have the meaning assigned to it in Section 24 of the
Indian Penal Code (45 of 1860).
(b) the word "fraudulently" shall have the meaning assigned to it in Section 25 of the
Indian Penal Code (45 of 1860)".
8. The distinction between Section 43 and 66 is very succinct. All the acts which are covered within
the purview of Section 43 if committed dishonestly and fraudulently are made punishable under
Section 66 with an imprisonment for a term which may extend to three years or with fine. It isGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

relevant to note that the word "dishonestly" and "fraudulently" is assigned the same meaning as in
Section 24 and 25 of the Indian Penal Code respectively. The offences under the Information
Technology Act, 2000 are compoundable and the offences which are punishable with imprisonment
of three years and above are bailable and cognizable. Another important provision contained in the
said enactment is Section 81 which reads thus :-
"81. Act to have overriding effect :-The provisions of this Act shall have effect
notwithstanding anything inconsistent therewith contained in any other law for the
time being in force:
      N.S. Kamble                                                          page 15 of 45
                                                                jud-917-wp-4361-2018
Provided that nothing contained in this Act shall restrict any person from exercising
any right conferred under the Copyright Act, 1957 (14 of 1957) or the Patents Act,
1970 (39 of 1970)."
9. In the backdrop of the scheme of the enactment the claim of the rival parties will have to be
examined.
10. The Hon'ble Apex Court in case of Sharat Babu Digumarti (Supra) had in great detail dealt with
the offences punishable under the Information Technology Act and at the same time punishable
under the relevant provisions of the Indian Penal Code. In the said case, an FIR was filed against the
appellant and on investigation, chargesheet came to be filed before the Magistrate who took
cognizance of the offences punishable under Section 292 and 294 of the Indian Penal Code and also
Section 67 of the Information Technology Act. In a petition before the High Court seeking
quashment, he was discharged of the offences under Section 292 and 294 but the prosecution under
Section 67 of the Information Technology Act continued. The appellant approached the Apex Court
and on the ground that the company was not arraigned as a party and the Director could not have
been liable of the offences punishable under Section 85 of the Information N.S. Kamble page 16 of
45 jud-917-wp-4361-2018 Technology Act and the proceeding came to be quashed. Subsequently an
application came to be filed before the Trial Court to drop the proceedings and the Trial Court
refused to drop the proceedings under Section 292 of Indian Penal Code and framed the charge.
With this issue he approached the Apex Court and the question for consideration before the Hon'ble
Apex Court was whether the appellant who has been discharged under Section 67 of the Information
Technology Act could be proceeded under Section 292 of the Indian Penal Code. The Hon'ble Apex
Court also examined whether an activity emanating from electronic form which may be obscene
would be punishable under Section 292 of the Indian Penal Code or 67 of the Information
Technology Act or both or any other provision of the Information Technology Act. In the backdrop
of the said facts the Hon'ble Apex Court observed thus :-Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

30. In this regard, we may reproduce Section 81 of the IT Act, which is as follows:-
"81. Act to have overriding effect.- The provisions of this Act shall have effect
notwithstanding anything inconsistent therewith contained in any other law for the
time being in force.
Provided that nothing contained in this Act shall restrict any person from exercising
any right conferred under the Copyright Act 1957 or the Patents Act 1970."
The proviso has been inserted by Act 10 of 2009 w.e.f.
      N.S. Kamble                                                            page 17 of 45
                                                                 jud-917-wp-4361-2018
                    27.10.2009. 
31. Having noted the provisions, it has to be recapitulated that Section 67 clearly stipulates
punishment for publishing, transmitting obscene materials in electronic form. The said provision
read with Section 67-A and 67-B is a complete code relating to the offences that are covered under
the IT Act. Section 79, as has been interpreted, is an exemption provision conferring protection to
the individuals. However, the said protection has been expanded in the dictum of Sherya Singhal
and we concur with the same.
32. Section 81 of the IT Act also specifically provides that the provisions of the Act shall have effect
notwithstanding anything inconsistent therewith contained in any other law for the time being in
force. All provisions will have their play and significance, if the alleged offence pertains to offence of
electronic record. It has to be borne in mind that IT Act is a special enactment. It has special
provisions. Section 292 of the IPC makes offence sale of obscene books, etc. but once the offence has
a nexus or connection with the electronic record the protection and effect of Section 79 cannot be
ignored and negated. We are inclined to think so as it is a special provision for a specific purpose
and the Act has to be given effect to so as to make the protection effective and true to the legislative
intent. This is the mandate behind Section 81 of the IT Act. The additional protection granted by the
IT Act would apply.
      N.S. Kamble                                                             page 18 of 45
                                                                  jud-917-wp-4361-2018Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

37. The aforesaid passage clearly shows that if legislative intendment is discernible that a latter
enactment shall prevail, the same is to be interpreted in accord with the said intention. We have
already referred to the scheme of the IT Act and how obscenity pertaining to electronic record falls
under the scheme of the Act. We have also referred to Sections 79 and 81 of the IT Act. Once the
special provisions having the overriding effect do cover a criminal act and the offender, he gets out
of the net of the IPC and in this case, Section 292. It is apt to note here that electronic forms of
transmission is covered by the IT Act, which is a special law. It is settled position in law that a
special law shall prevail over the general and prior laws. When the Act in various provisions deals
with obscenity in electronic form, it covers the offence under Section 292 IPC.
39. In view of the aforesaid analysis and the authorities referred to hereinabove, we are of the
considered opinion that the High Court has fallen into error that though charge has not been made
out under Section 67 of the IT Act, yet the appellant could be proceeded under Section 292 IPC.
11. Reading of the said judgment, makes is clear that the Hon'ble Apex Court had considered the
effect of the overriding provisions contained in the Information Technology Act and has observed
that all the provisions in the enactment are of significance N.S. Kamble page 19 of 45
jud-917-wp-4361-2018 particularly if the alleged offences pertains to electronic record. By observing
that the Information Technology Act is a special enactment and it contain special provision, the
Hon'ble Apex Court has also considered the effect of Section 79 contained in the Information
Technology Act which is enacted for a specific purpose and has observed that the mandate behind
Section 81 of the Information Technology Act needs to be understood in its proper perspective. It
referred to the earlier precedents on the point where a special statute is pitted against a General
enactment and thereafter has concluded by making reference Section 79 and 81 that once the special
provisions are accorded overriding effect to cover a criminal Act, the offender gets out of the net of
the Indian Penal Code and in the case in hand of Section 292.
12. It is well known principle of law that a prior general Act may be effected by a subsequent
particular or a special Act. In the principles of statutory interpretation by justice G.P. Singh 13 th
Edition 2012 the aforesaid principle is culled out in the following manner:-
"A prior general Act may be effected by a subsequent particular or a Special Act, if the
special matter of particular Act prior to its enforcement was being N.S. Kamble page
20 of 45 jud-917-wp-4361-2018 governed by the general provision of the earlier Act.
In such a case the operation of the particular Act may have the effected of parallel
rebelling the general Act or curtailing its operation or added conditions to its
operation for the particular cases.
A general Act operation may be curtailed by a latter special Act even if the general Act
contained a non- obstante clause. The curtailment of the general Act will be more
readily inferred with the latter special Act also containing an overriding non-obstante
provision.Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

13. The well know principle of 'generalia specialibus general non-derogant' which is to be invoked in
case of conflict between a specific provision and general provision and which gives the specific
provision an overriding effect over the general provision has been described in Craies on statute law
at page 206, Sixth Edition Rommaly, MR referred the rule as "The rule is that whenever there is a
particular enactment and a general enactment in the same statute and the latter, taken in its most
comprehensive sense would override, particular enactment must be inactive and the general
enactment must be taken to effect only the over parts of the statute to which it may properly apply.
In case of Belsund Sugar Co. Ltd. V/s. The State of Bihar 2, the Hon'ble Apex Court was required to
deal with one such special statute by Section 4 of the 2 AIR 1999 SC 3125 N.S. Kamble page 21 of 45
jud-917-wp-4361-2018 Bihar Finance Act (Act 5 of 1981), provision was made for levy of purchase
tax on goods in general. Provision was also made for levy of purchase tax on sugarcane later by
section 49 of the Bihar Sugarcane (Regulation of Supply and Purchase) Act (Act 37 of 1982) which
was a special Act for the control of the activities of production, supply and regulation of sugarcane
including the levy of purchase tax. In so far as the activity of levy of purchase tax on sugarcane was
concerned both the Acts operated in the same field. As the Sugarcane Act was a special Act the rule
that 'general provision should yield to special provision' was applied and it was held that purchase
tax on sugarcane could be levied only under the sugarcane Act and not under the Finance Act. On
the same principle it was also held in another case that dealings in sugarcane were exclusively
regulated by the Sugarcane Act and its provisions excluded the operation of the Bihar Agricultural
Produce Markets Act, 1980 which was a general Act for regulating sale and purchase of all types of
agricultural produce.
14. In case of Ratanlal Adukia V/s. Union of India AIR- 1990-SCC-104, where the facts involved
reveal that Section 80 of the Railways Act 1890 substituted in 1961 provides for forum where a suit
for compensation for loss of life, or personal injury too, a N.S. Kamble page 22 of 45
jud-917-wp-4361-2018 passenger or for loss, destruction, damage, deterioration and non delivery of
the animals or goods against the railway administration may be brought. It was held that the said
section was a self contained code and that impliedly repealed the provision in respect of suits
covered by Section 20 of the Code of Civil Procedure, 1908. The principle which is deducible in the
aforesaid judgment is to the effect that the subsequent legislation which is a Code in itself exclude
the general law on the subject.
15. In case of Allahabad Bank V/s. Canara bank AIR- 2000-SCC-1535, provisions of the recovery of
debts due to Banks and Financial Institutions Act, 1993 ('RDB' Act) was given an overriding effect
over the provisions of the Companies Act 1956. The RDB Act constitutes a tribunal and by Section 17
and 18 confers upon the tribunal exclusive jurisdiction to entertain and decide applications from the
banks and the financial institutions for recovery of debts. The Act also laid down procedure of
recovery of debt as per certificate issued by the tribunal. The said enactment being a special
enactment, would prevail over Section 442, 446, 537 and other section of the Companies Act which
is a general Act, more so because Section 34 of the RDB Act gives overriding effect to that Act by
providing that the provisions of this Act shall have effect N.S. Kamble page 23 of 45
jud-917-wp-4361-2018 notwithstanding anything inconsistent therein containing in other law for
the time being in force.Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

16. Further in case of Yakub Abdul Razak Memon V/s. State of Maharashtra3 the Hon'ble Apex
Court while dealing with an 'overriding effect' clause in the Terrorist and Disruptive Activities
(Prevention) Act, 1987 (for short 'TADA'), while examining its effect on the Juvenile Justice Act,
2000 made the following observations:-
1517. Where two statutes provide for overriding effect on the other law for the time
being in force and the court has to examine which one of them must prevail, the court
has to examine the issue considering the following two basic principles of statutory
interpretation:
1. Leges posteriores priores contrarias abrogant (later laws abrogate earlier contrary
laws).
2. Generalia specialibus non derogant (a general provision does not derogate from a
special one.) 1518. The principle that the latter Act would prevail the earlier Act has
consistently been held to be subject to the exception that a general provision does not
derogate from a special one. It means that where the literal meaning of the general
enactment covers a situation for which specific provision is made by another
enactment contained in the earlier Act, it would be 3 (2013) 13-SCC-1 N.S. Kamble
page 24 of 45 jud-917-wp-4361-2018 presumed that the situation was intended to
continue to be dealt with by the specific provision rather than the later general one.
1519. The basic rule that a general provisions should yield to the specific provisions is based on the
principle that if two directions are issued by the competent authority, one covering a large number
of matters in general and another to only some of them, his intention is that these latter directions
should prevail as regards these while as regards all the rest the earlier directions must be given effect
to.
1520. It is a settled legal proposition that while passing a special Act, the legislature devotes its
entire consideration to a peculiar subject. Therefore, when a general Act is subsequently passed, it is
logical to presume that the legislature has not repealed or modified the former special Act unless an
inference may be drawn from the language of the special Act itself.
1521. In order to determine whether a statute is special or general one, the court has to take into
consideration the principal subject-matter of the statute and the particular perspective for the
reason that for certain purposes an Act may be general and for certain other purposes it may be
special and such a distinction cannot be blurred.
      N.S. Kamble                                                             page 25 of 45
                                                                    jud-917-wp-4361-2018Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

1522. Thus, where there is inconsistency between the provisions of two statutes and both can be
regarded as special in nature, the conflict has to be resolved by reference to the purpose and policy
underlying the two enactments and the clear intendment of the legislature conveyed by the language
of the relevant provisions therein. (Vide Ram Narain v. Simla Banking and Industrial Co. Ltd.[AIR
1956 SC 614] ,J.K. Cotton Spg. & Wvg. Mills Co. Ltd. v. State of U.P. [AIR 1961 SC 1170] ,Kumaon
Motor Owners' Union Ltd. v. State of U.P.[AIR 1966 SC 785], Sarwan Singh v. Kasturi Lal [(1977) 1
SCC 750], U.P. SEB v. Hari Shankar Jain [(1978) 4 SCC 16 : 1978 SCC (L&S) 481], LIC v. D.J.
Bahadur [(1981) 1 SCC 315 : 1981 SCC (L&S) 111], Ashoka Mktg. Ltd. v. Punjab National Bank
[(1990) 4 SCC 406 : AIR 1991 SC 855] and T.M.A. Pai Foundation v. State of Karnataka [(2002) 8
SCC 481] .)
17. Further, in case of Jeevan Kumar Raut and Another V/s. Central Bureau of Investigation 4, on
which reliance has been placed by the Hon'ble Apex Court in case of Sharat Babu Digumarti (Supra),
the Court was called upon to deal with a special act namely the Transplantation of the Human
Organs Act, 1994. The FIR registered disclosed not only commission of offence under TOHO but
also the Indian Penal Code. The officer in-charge 4 2009-7-SCC-526, N.S. Kamble page 26 of 45
jud-917-wp-4361-2018 of the Police Station being not authorized to deal with the matter in relation
to TOHO, the investigation of the complaint was handed over to CBI. When the question arose
about the procedure to be followed while investigating the said offence under the special enactment,
the Hon'ble Apex Court observed thus :-
"19. TOHO is a special Act. It deals with the subjects mentioned therein, viz. offences
relating to removal of human organs, etc. Having regard to the importance of the
subject only, enactment of the said regulatory statute was imperative.
20. TOHO provides for appointment of an appropriate authority to deal with the
matters specified in sub-section (3) of Section 13 thereof. By reason of the
aforementioned provision, an appropriate authority has specifically been authorised
inter alia to investigate any complaint of the breach of any of the provisions of TOHO
or any of the rules made thereunder and take appropriate action. The appropriate
authority, subject to exceptions provided for in TOHO, thus, is only authorised to
investigate cases of breach of any of the provisions thereof, whether penal or
otherwise.
22. TOHO being a special statute, Section 4 of the Code, which ordinarily would be applicable for
investigation into a cognizable offence or the other N.S. Kamble page 27 of 45
jud-917-wp-4361-2018 provisions, may not be applicable. Section 4 provides for investigation,
inquiry, trial, etc. according to the provisions of the Code. Sub-section (2) of Section 4, however,
specifically provides that offences under any other law shall be investigated, inquired into, tried and
otherwise dealt with according to the same provisions, but subject to any enactment for the time
being in force regulating the manner or place of investigating, inquiring into, tried or otherwise
dealing with such offences.Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

26. It is a well-settled principle of law that if a special statute lays down procedures, the ones laid
down under the general statutes shall not be followed. In a situation of this nature, the respondent
could carry out investigations in exercise of its authorisation under Section 13(3)(iv) of TOHO.
While doing so, it could exercise such powers which are otherwise vested in it. But, as it could not
file a police report but a complaint petition only; sub-section (2) of Section 167 of the Code may not
be applicable.
27. The provisions of the Code, thus, for all intent and purport, would apply only to an extent till
conflict arises between the provisions of the Code and TOHO and as soon as the area of conflict
reaches, TOHO shall prevail over the Code. Ordinarily, thus, although in terms of the Code, the
respondent upon completion of investigation and upon obtaining remand of the accused from time
to N.S. Kamble page 28 of 45 jud-917-wp-4361-2018 time, was required to file a police report, it was
precluded from doing so by reason of the provisions contained in Section 22 of TOHO."
18. In a recent judgment in case of Independent Thought V/s. Union of India5, where the question
posed before the Apex Court was about the exception 2 to Section 375 and as to whether a man
committing sexual intercourse or acts with his wife aged between 15 and 18 years is exempted from
offence of rape, their lordships also decided whether the provisions of Juvenile Justice Act would
prevail against the POSCO Act, the Hon'ble Apex Court construed that both the enactment are
traceable to Article 15(3) of the Constitution which enable Parliament to make a special provision for
the benefit of the children. As regards whether the statute would be construed as general or special
one, the Apex Court observed thus :-
95. Whatever be the explanation, given the context and purpose of their enactment,
primacy must be given to pro- child statutes over IPC as provided for in Sections 5
and 41 IPC. There are several reasons for this including the absence of any rationale
in creating an artificial distinction, in relation to sexual offences, between a married
girl child and an unmarried girl child. Statutes 5 2017-10-SCC-800 N.S. Kamble page
29 of 45 jud-917-wp-4361-2018 concerning the rights of children are special laws
concerning a special subject of legislation and therefore the provisions of such
subject-specific legislations must prevail and take precedence over the provisions of a
general law such as IPC. It must also be remembered that the provisions of the JJ Act
as well as the provisions of the POCSO Act are traceable to Article 15(3) of the
Constitution which enables Parliament to make special provisions for the benefit of
children. We have already adverted to some decisions relating to the interpretation of
Article 15(3) of the Constitution in a manner that is affirmative, in favour of children
and for children and we have also adverted to the discussion in the Constituent
Assembly in this regard. There can therefore be no other opinion regarding the
pro-child slant of the JJ Act as well as the POCSO Act.
100. Prima facie it might appear that since rape is an offence under IPC (subject to
Exception 2 to Section 375) while penetrative sexual assault or aggravated
penetrative sexual assault is an offence under the POCSO Act and both are distinct
and separate statutes, therefore there is no inconsistency between the provisions ofGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

IPC and the provisions of the POCSO Act. However the fact is that there is no real
distinction between the definition of "rape" under IPC and the definition of
"penetrative sexual assault" under the POCSO Act. There is also no real distinction
between the rape of a married girl child and N.S. Kamble page 30 of 45
jud-917-wp-4361-2018 aggravated penetrative sexual assault punishable under
Section 6 of the POCSO Act. Additionally, the punishment for the respective offences
is the same, except that the marital rape of a girl child between 15 and 18 years of age
is not rape in view of Exception 2 to Section 375 IPC.
In sum, marital rape of a girl child is effectively nothing but aggravated penetrative sexual assault
and there is no reason why it should not be punishable under the provisions of IPC. Therefore, it
does appear that only a notional or linguistic distinction is sought to be made between rape and
penetrative sexual assault and rape of a married girl child and aggravated penetrative sexual assault.
There is no rationale for this distinction and it is nothing but a completely arbitrary and
discriminatory distinction.
19. In light of the aforesaid authorative pronouncements it can very will be seen that the statute and
its provisions must be construed by keeping in mind the object behind the enactment of such a
statute. The Hon'ble Apex Court in case of RBI V/s. Peerless General Insurance Finance and
Investment Company Ltd. 6 has made observations to the following effect :-
"33. If a statue is looked at, in the context of the enactment, with the glasses of the
statute makes and provided by such context, its scene, the sections, clauses, 6
2014-8-SCC-319 N.S. Kamble page 31 of 45 jud-917-wp-4361-2018 phrases and
words may take colour and appear different that when the statute is looked at without
the glasses provided by the context. With these glasses we must look at the set as a
whole and discover what each section, each clause, each phrase, each word is meant
and designed to say as to fit into the scheme of the entire Act."
20. It is also a settled principle of statutory interpretation that a clause or a Section beginning with
'notwithstanding anything contained in this Act or some particular provision in the Act or in any law
for the time being in force', 'is sometimes appended in a Section or is included in an enactment
which would give the provision or the Act an overriding effect over the provision or the Act
mentioned in the non-obstante clause. The non-obstante clause may be used as legislative device to
modify the ambit of the provision or law mentioned in the non-obstante laws or to override in
specified circumstances. The phrase 'notwithstanding anything in' is used in contradiction to the
phrase 'subject to', the latter conveying the idea of the provision yielding placed to another provision
or other provisions to which it is made subject to.
21. Keeping the aforesaid authoritative pronouncements in mind, if the scheme of the Information
Technology Act will have to N.S. Kamble page 32 of 45 jud-917-wp-4361-2018 be examined and
given effect too. The said Act which is a special enactment so as to give fillip to the growth of
electronic based transactions, and to provide legal recognition for E-commerce and, to facilitate
E-Governance and to Ensure Security Practice and Procedures in the context of the use ofGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

Information Technology Worldwide. The said enactment contains a full fledge mechanism for
penalising certain acts which are committed without permission of the owner or any other persons
who is in charge of a computer, computer system, or computer network and those acts are
enumerated in Section 43. The said enactment also makes certain acts punishable and Chapter-XI of
the Information Technology Act 2000 enumerates such acts. The same acts which are enumerated
in Section 43 of the enactment which would invite penalty and compensation for accessing or
securing any information as contemplated in Section 43, would amount to an offence under Section
66 if any person, dishonestly, fraudulently commits such an act. The said Section has an explanation
appended to it to the effect that the word "dishonestly" and "fraudulently" used in the said Section
will be assigned the same meaning as under the Indian Penal Code. In such circumstances when the
Information Technology Act, 2000 specifically provides a mechanism for dealing with an act
covered in Section 43(a) and (j):-
      N.S. Kamble                                                        page 33 of 45
                                                               jud-917-wp-4361-2018
                     "Section 43(a)        Accesses   or   secures   access   to   such
computer, computer system or computer network (or computer resource);
43(j) Steel, conceals, destroys or alters or causes any person to steal, conceal, destroy or alter any
computer source code used for a computer resource with an intention to cause damage."
and if this is done with a fraudulent or dishonest intention, it becomes an offence under Section 66
of the Information Technology Act. Since, the Information Technology Act deals with the use of
means of electronic communication and has evolved a complete mechanism in itself to deal with the
offences in the use of electronic transactions, and in the backdrop of the specific facts of the case in
hand, Section 66 would be attracted and in view of the mechanism contained in the said section, the
invocation of the provisions of the Indian Penal Code is highly unwarranted. This view has already
been authored by their lordships in case of Sharat Babu Digumarti (Supra).
22. The reliance placed by the learned counsel Shri.Gupte judgment in case of The State of
Maharashtra & Anr. V/s. Sayyad Hassan Sayyed Subhan & Ors7, in our view it is not applicable to
the present case in light of the direct pronouncement of the Hon'ble 7 Criminal Appeal No.1195 of
2018 of SCC delivered on 20-09-2018 N.S. Kamble page 34 of 45 jud-917-wp-4361-2018 Apex Court
in case of Sharat Babu Digumarti (Supra). In the case relied upon by the learned Senior Counsel the
issue involved was whether an act or omission can constitute an offence under the Indian Penal
Code and at the same time under any other law and in the said case under the Food and Safety
Standards Act, 2006.
The facts involved revealed that a notification was issued on 18.07.2013 by the Commissioner Food
Safety and Drug Administration, Government of Maharashtra under Section 30 prohibitingGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

manufacture, storage, distribution or sale of tobacco Areca nut and gutka/panmasala etc. The facts
of the said case would reveal that First Information was registered for transportation and sale of
gutka and panmasala and thereby invoking offences punishable under Section 26 and 30 of the FSS
Act and also Section 188, 272, 273, 328 of Indian Penal Code. A Criminal Writ Petition was filed for
quashing of the FIR's and the High Court framed two questions for consideration, namely :- a)
Whether food Safety Officer can lodged complaint for offences punishable under Section IPC. b)
Whether Acts complaint amounted to offence punishable under IPC. The High Court quashed the
proceedings on the ground that the Food Safety Officers can proceed against the accused under the
provisions of Chapter-X of the FSS Act. The High Court noted that the notification issued by the
Commissioner is not an order N.S. Kamble page 35 of 45 jud-917-wp-4361-2018 contemplated
under Chapter-X of the Indian Penal Code and there was a specific provision contained in Section 55
of the FSS Act which is a special enactment and therefore it had held that Section 188 of the Indian
Penal Code is not applicable. Being aggrieved, the State of Maharashtra approached the Hon'ble
Apex Court.
23. In the backdrop of this peculiar facts the Hon'ble Apex Court had disagreed with the conclusion
of the High Court and was pleased to observed that the High Court has erred in holding that the
action can be initiated against the defaulters only under Section 55 of the FSS Act and to the
exclusion of Section 188. The Hon'ble Apex Court observed that Section 188 of Indian Penal Code is
wider in scope and did not cover only breach of law and order but it was also attracted in cases
where the act complained of causes or tends to cause danger to human life, healthy or safety as well.
By comparatively anyalizing the scope of Section 53 of the FSS Act and Section 188 of the Indian
Penal Code, the Hon'ble Apex Court held as under:-
"7. There is no bar to a trial or conviction of an offender under two different
enactments, but the bar is only to the punishment of the offender twice for the
offence. Where an act or an omission constitutes an offence under two enactments,
the offender may be N.S. Kamble page 36 of 45 jud-917-wp-4361-2018 prosecuted
and punished under either or both enactments but shall not be liable to be punished
twice for the same offence. The same set of facts, in conceivable cases, can constitute
offences under two different laws. An act or an omission can amount to and
constitute an offence under the IPC and at the same time, an offence under any law."
24. The aforesaid judgment of the Hon'ble Apex Court is therefore clearly distinguishable on facts
but even the said judgment of the Hon'ble Apex Court reiterates the settled position of law that
where an act or an omission constitutes for an offence under two enactments the offender may be
punished under either or both enactment but was not liable to be punished twice for the same
offence. It is always possible that the same set of facts can constitute offence under two different
laws but a person cannot be punished twice for the said act which would constitute an offence.
25. The rule against double jeopardy is a significant basic rule of criminal law that no man shall be
put in jeopardy twice for one and the same offence. The manifestation of the said rule no doubt finds
place in Section 26 of the general clauses Act, 1897 which reads thus :-Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

"Provision as to offences punishable under two or more N.S. Kamble page 37 of 45
jud-917-wp-4361-2018 enactments-where an act of omission constitutes of offences
under two or more enactments, offender shall be liable to be prosecuted and punish
under either or any of these enactments that he shall not be liable to be punished
twice in the said enactment'.
Article 20(2) of the Constitution provides that no person shall be prosecuted and
punished for the same offence more than once. To attract the applicability of the
Article 20(2) there may be second prosecution and punishment of the same offence
for which the accused has been prosecuted and punish previously. A subsequent trial
or prosecution and the punishment however is not barred if the ingredients of the
two offences are distinct.
26. In order to attract Section 26, what is required is to ascertain whether the ingredients of offence
have been same or distinct. In case of State (NCT) of Delhi V/s. Sanjay8, the Hon'ble Apex Court
while dealing with the phrase 'same offence' was called upon to decide the question as to whether
illegal mining of sand from river beds under Mines and Minerals (Development and Regulations)
Act of 1957 would oust the invocation and application of provisions of Section 378 read with 379 of
Indian Penal Code, observed that the mining of sand from riverbed without licenses or 8
2014-9-SCC-772 N.S. Kamble page 38 of 45 jud-917-wp-4361-2018 permit is prohibited under the
MMDR Act. However, it would also constitute an offence under the provisions of the Indian Penal
Code as natural resources belongs to the public and State being its trustee, the police is empowered
and duty bound to lodged a FIR in Indian Penal Code and to investigate and file chargesheet
irrespective of the procedure under the MMDR Act. However, the Hon'ble Apex Court observed that
this is permissible and would not have hit by the principle of double jeopardy in view of the fact that
ingredients of both offence are distinct and different. The following observations by the Hon'ble
Apex Court are relevant paragraphs :-
26. Broadly speaking, a protection against a second or multiple punishment for the
same offence, technical complexities aside, includes a protection against
re-prosecution after acquittal, a protection against re-prosecution after conviction
and a protection against double or multiple punishment for the same offence. These
protections have since received constitutional guarantee under Article 20(2). But
difficulties arise in the application of the principle in the context of what is meant by
'same offence'. The principle in American law is stated thus:
'The proliferation of technically different offences encompassed in a single instance of
crime behaviour has increased the N.S. Kamble page 39 of 45 jud-917-wp-4361-2018
importance of defining the scope of the offence that controls for purposes of the
double jeopardy guarantee.
Distinct statutory provisions will be treated as involving separate offences for double
jeopardy purposes only if "each provision requires proof of an additional fact which
the other does not" (Blockburger v. United States [76 L Ed 306 : 284 US 299 (1932)]Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

). Where the same evidence suffices to prove both crimes, they are the same for
double jeopardy purposes, and the clause forbids successive trials and cumulative
punishments for the two crimes. The offences must be joined in one indictment and
tried together unless the defendant requests that they be tried separately. (Jeffers v.
United States [53 L Ed 2d 168 : 432 US 137 (1977)] .)'
27. The expressions 'the same offence', 'substantially the same offence', 'in effect the
same offence' or 'practically the same', have not done much to lessen the difficulty in
applying the tests to identify the legal common denominators of 'same offence'.
Friedland in Double Jeopardy (Oxford 1969) says at p. 108:
'The trouble with this approach is that it is vague and hazy and conceals the thought
N.S. Kamble page 40 of 45 jud-917-wp-4361-2018 processes of the court. Such an
inexact test must depend upon the individual impressions of the Judges and can give
little guidance for future decisions. A more serious consequence is the fact that a
decision in one case that two offences are "substantially the same" may compel the
same result in another case involving the same two offences where the circumstances
may be such that a second prosecution should be permissible....' Further in case of in
State of Rajasthan v. Hat Singh [(2003) 2 SCC 152 : 2003 SCC (Cri) 451] , a person
was prosecuted for violation of prohibitory order issued by the Collector under
Sections 5 and 6 of the Rajasthan Sati (Prevention) Ordinance, 1987. Against the said
Ordinance, mass rally took place which led to the registration of FIRs against various
persons for violation of prohibitory order under Sections 5 and 6 of the Act. Persons,
who were arrested, moved a petition challenging the vires of the Ordinance and the
Act. The High Court upholding the vires of the Ordinance/Act held that the
provisions of Sections 5 and 6 overlapped each other and that a person could be
found guilty only of the offence of contravening a prohibitory order under either
Section 6(1) or Section 6(2) of the Act.
      N.S. Kamble                                                       page 41 of 45
                                                                     jud-917-wp-4361-2018
                     The Apex Court held as under:-
"14. We are, therefore, of the opinion that in a given case, same set of facts may give
rise to an offence punishable under Section 5 and Section 6(3) both. There is nothing
unconstitutional or illegal about it. So also an act which is alleged to be an offence
under Section 6(3) of the Act and if for any reason prosecution under Section 6(3)
does not end in conviction, if the ingredients of offence under Section 5 are made out,
may still be liable to be punished under Section 5 of the Act. We, therefore, do not
agree with the High Court to the extent to which it has been held that once a
prohibitory order under sub-section (1) or (2) has been issued, then a criminal actGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

done after the promulgation of the prohibitory order can be punished only under
Section 6(3) and in spite of prosecution under Section 6(3) failing, on the same set of
facts the person proceeded against cannot be held punishable under Section 5 of the
Act although the ingredients of Section 5 are fully made out."
27. Applying the aforesaid principles to the facts involved in the case, perusal of the
complaint would reveal that the allegations relate to the use of the data code by the
employees of the complainant company by accessing the Code and stealing the said
N.S. Kamble page 42 of 45 jud-917-wp-4361-2018 data by using the computer source
code. The Act of accessing or securing access to computer/computer system or
computer network or computer resources by any person without permission of the
owner or any person who is in charge of the computer, computer system, computer
network or downloading of any such data or information from computer in a similar
manner falls within the purview of Section 43 of the Information Technology
Act,2000.
When such Act is done dishonestly and fraudulently it would attract the punishment under Section
66 of the Information Technology Act, such Act being held to be an offence. The ingredients of
dishonesty and fraudulently are the same which are present if the person is charged with Section
420 of the Indian Penal Code. The offence of Section 379 in terms of technology is also covered
under Section 43. Further, as far as Section 408 is concerned which relates to criminal breach of
trust, by a clerk or servant who is entrusted in such capacity with the property or with any dominion
over property, would also fall within the purview of Section 43 would intents to cover any act of
accessing a computer by a person without permission of the owner or a person in charge of
computer and/or stealing of any data, computer data base or any information from such computer
or a computer system including information or data held or stored in any removable storage
medium and if it is N.S. Kamble page 43 of 45 jud-917-wp-4361-2018 done with fraudulent and
dishonest intention then it amounts to an offence. The ingredients of an offences under which are
attracted by invoking and applying the Section 420, 408, 379 of the Indian Penal Code are covered
by Section 66 of the Information Technology Act, 2000 and prosecuting the petitioners under the
both Indian Penal Code and Information Technology Act would be a brazen violation of protection
against double jeopardy.
28. In such circumstances if the special enactment in form of the Information Technology Act
contains a special mechanism to deal with the offences falling within the purview of Information
Technology Act, then the invocation and application of the provisions of the Indian Penal Code
being applicable to the same set of facts is totally uncalled for. Though the learned APP as well as
Shri.Gupte has vehemently argued that the prosecution under the provisions of the Indian Penal
Code can be continued and at the time of taking cognizance the Competent Court can determine the
provisions of which enactments are attracted and it is too premature to exclude the investigation in
the offences constituted under the Indian Penal Code, we are not ready to accept the said contention
of the learned Senior Counsel, specifically in the light of the observations of the Hon'ble Apex Court
in the case of Sharat Babu Digumarti N.S. Kamble page 44 of 45 jud-917-wp-4361-2018 (Supra). We
are of the specific opinion that it is not permissible to merely undergo the rigmarole of investigationGagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

although it is not open for the Investigating Officer to invoke and apply the provisions of the Indian
Penal Code, in light of the specific provisions contained in the Information Technology Act, 2000
and leave it to the discretion of the Police Authorities to decide in which direction the investigation
is to be proceeded. The Information Technology Act, 2000 being a special enactment, it requires an
able investigation keeping in mind the purpose of the enactment and to nab the new venturing of
crimes with the assistance of the Technology.
29. In such circumstances we are inclined to allow the Writ Petition in terms of prayer clause (a) and
quash and set aside the subject FIR insofar as the investigation into the offences punishable under
the Indian Penal Code.
30. In light of the aforesaid decision, the Criminal Application No. 403 of 2018 does not survive and
stands disposed of.
 (SMT.BHARATI H. DANGRE, J.)                               (RANJIT MORE, J.)
       N.S. Kamble                                                          page 45 of 45Gagan Harsh Sharma And Anr vs The State Of Maharashtra And Anr on 26 October, 2018

