Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana &
Ors on 19 November, 2010
Author: B.Sudershan Reddy
Bench: B. Sudershan Reddy, Surinder Singh Nijjar
                                                                 1
                                           REPORTABLE
           IN THE SUPREME COURT OF INDIA
            CIVIL APPELLATE JURISDICTION
            CIVIL APPEAL NO. 550 OF 2003
DLF UNIVERSAL LTD. & ANR.             Appellant (s)
           VERSUS
DIRECTOR, T.&C. PLANNING
HARYANA & ORS.                      Respondent(s)
                          WITH
            CIVIL APPEAL NO. 551 of 2003
M/s. ANSAL PROPERTIES &
Industries LTD.                      Appellant (s)
           VERSUS
DIRECTOR, T.&C. PLANNING
HARYANA & Anr.                       Respondent(s)
                          WITH
           CIVIL APPEAL NO. 1611 of 2003
M/s.Ajay ENTERPRISES LTD. &
ORS.                                  Appellant (s)
           VERSUS
STATE OF HARYANA & ORS.            Respondent(s)
                          WITH
                                                            2Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

CONTEMPT PETITION(C) No. 215/2005 in CIVIL
APPEAL No.550/2003 and CONTEMPT PETITION
(C)No.106/2006 IN CIVIL APPEAL No.550/2003
                    JUDGMENT
B.SUDERSHAN REDDY,J :
These appeals are directed against the orders of Punjab and Haryana High Court
dismissing the Writ Petitions filed by the appellants herein challenging the impugned
order dated 05.05.1999 passed by the Director, Town and Country Planning,
Chandigarh, Haryana. The High Court upheld the validity of the impugned memo
and accordingly dismissed the Writ Petitions. The same is challenged in these appeals
on various grounds.
2. We have heard the learned senior counsel Shri Harish Salve, Shri S. Ganesh, Shri Harish
Malhotra and the learned counsel Shri Rajiv Vermani for the appellants and Shri U.U. Lalit, learned
senior counsel for the respondents. We have also heard the learned counsel appearing on behalf of
the interveners-applicants.
3. The central question that arises for our consideration in this group of appeals is whether the
Director, Town and Country Planning, is empowered to pass the impugned order? Whether the
impugned order is ultra vires?
4. By the impugned memo the Director had purported to give the following directions:
(a) the provision in the agreement between the appellant and the plot/flat buyers
regarding extension fee and maintenance fee should be deleted from the agreement
as the same is not permissible under the law;
(b) further directed to stop charging of extension fee and maintenance fee from the
plot/flat holders henceforth and the charges recovered on account of both from the
plot/flat holders "may be refunded to the Government immediately."
(c) stop allowing the transfer of plots after obtaining full payment for the same and to
ensure immediate registration of Conveyance Deed "where the full payments of the
plot/flats have been received."
5. In order to consider the question as to the validity of the impugned memo few relevant facts may
have to be noticed. BACKGROUND FACTS :Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

6. The appellants were granted licence under the provisions of Haryana Development and
Regulation of Urban Areas Act, 1975 (for short `the Act') and the Rules framed thereunder, i.e.
Haryana Development and Regulation of Urban Area Rules, 1976 (for short `the Rules') for setting
up residential colonies. The appellants entered into required agreements with the Governor of
Haryana acting through Director Town and Country Planning, Haryana. The appellants acting
under the licence so granted and the agreements commenced setting up colonies by dividing the
land into plots. The plots were sold to various buyers. The plot buyers are required to make
construction on such plots to be used for the purpose for which the lay out was approved. The
appellants have also allotted flats to various persons and have entered into agreements. Mutual
rights and obligations between the appellants and the plot/flat buyers is structured by the
agreements voluntarily entered into by them and all terms and conditions, covenants were mutually
agreed by and between the parties. In respect of certain areas even completion certificates were
granted as early as in the year 1991-92. The Director all of a sudden without any notice whatsoever
to any of the appellants issued the impugned directions which were challenged on various grounds
in the High Court.
7. In order to consider the central question as to whether the impugned order is void and
unenforceable, it is just and necessary to notice the relevant provisions of the Act. SCHEME OF THE
ACT :
8. The Act intends to regulate the use of land in order to prevent ill planned and haphazard
urbanization in or around towns in the State of Haryana. The Act applies to all urban areas in the
State of Haryana. We shall notice the relevant provisions of the Act and the Rules which are as
under :
" Section 2. Definitions
(a) .............................. (aa).............................
(b) ..............................
(c) "colony" means an area of land divided or proposed to be divided into plots or
flats for residential, commercial, industrial, cyber city or cyber park purposes or for
the construction of flats in the form of group housing or for the construction of
integrated commercial complexes, but an area of land divided or proposed to be
divided--
     (i)    for the purpose of agriculture ; or
(ii)      as a result of family partition, inheritance,
succession or partition of joint holding not with the motive of earning profit ; orDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

(iii) in furtherance of any scheme sanction under any other law; or
(iv) by the owner of a factory for setting up of a housing colony for the labourers or
the employees working in the factory; provided there is no profit motive ; or
(v) when it does not exceed one thousand square metres or such less area as may be
decided from time to time in an urban area to be notified by Government for the
purposes of this sub-clause.
shall not be a colony ,
(d) "colonizer" means an individual, company or association or body of individuals, whether
incorporated or not, owning land for converting it into a colony and to whom a licence has been
granted under this Act ;
(dd) "cyber city" means self contained intelligent city with high quality of infrastructure, attractive
surrounding and high speed communication access to be developed for nucleating the Information
Technology concept germination of medium and large software companies and Information
Technology enabled services, wherein no manufaturing units shall be permitted ; (ddd) "cyber park"
means an area developed exclusively for locating software development activities and Information
Technology Enabled Services, wherein no manufacturing of any kind (including assembling
activities) shall be permitted ;
(e) "development works" means internal and external development works ;
(f) ............................
(g) "external development works" include water supply, sewerage, drains, necessary provisions of
treatment and disposal of sewage, sullage and storm water, roads, electrical works, solid waste
management and disposal, slaughter houses, colleges, hospitals, stadium/sports complex, fire
stations, grid sub- stations etc. and any other work which the Director may specify to be executed in
the periphery of or outside colony/area for the benefit of the colony/area;
(gg) "flat" means a part of any property, intended to be used for residential purposes, including one
or more rooms with enclosed spaces located on one or more floors, with direct exit to a public street
or road or to a common area leading to such streets or road and includes any garage or room
whether or not adjacent to the building in which such flat is located provided by the coloniser/owner
of such property for use by the owner of such flat for parking any vehicle or for residence of any
person employed in such flat, as the case may be ;
(h) ..........................
(i) "internal development works" mean--Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

(i) metalling of roads and paving of footpaths;
(ii) turfing and plantation with trees of open spaces;
(iii) street lighting ;
(iv) adequate and wholesome water-supply ;
(v) sewers and drains both for storm and sullage water and necessary provision for their treatment
and disposal ; and
(vi) any other work that the Director may think necessary in the interest of proper development of a
colony ;
(j)    ........................
k)      "owner" includes a person in whose favour a lease
of land in an urban area for a period of not less than ninety nine years has been granted ;
(l) ..................................
(m) "plot/flat holder" means a person in whose favour a plot/flat in a colony has been transferred or
agreed to be transferred by the coloniser ;
(n) . ..................
(o) .....................
Section 3 Application for licence :
(1) Any owner desiring to convert his land into a colony shall, unless exempted under section 9,
make an application to the Director, for the grant of a licence to develop a colony in the prescribed
from and pay for it such fee and conversion charges as may be prescribed. The application shall be
accompanied by an income- tax clearance certificate :
Provided that if the conversion charges have already been paid under the provisions
of the Punjab Scheduled Roads and Controlled Areas Restriction of Unregulated
Development Act, 1963 (41 of 1963), no such charges shall be payable under this
section.] (2) On receipt of the application under sub-section (1), the Director shall,
among other things, enquire into the following matters, namely :--
(a) title to the land ;
(b) extent and situation of the land ;Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

(c) capacity to develop a colony ;
(d) the layout of a colony ;
(e) plan regarding the development works to be executed in a colony ; and
(f) conformity of the development schemes of the colony land to those of the
neighbouring areas (3) After the enquiry under sub-section (2), the Director, by an
order in writing, shall--
(a) grant a licence in the prescribed form, after the applicant has furnished to the
Director a bank guarantee equal to twenty-five per centum of the estimated cost of
development works in case of area of land divided or proposed to be divided into
plots or flats for residential, commercial or industrial purposes and a bank guarantee
equal to thirty-
seven and a half per centum of the estimated cost of development works in case of cyber city or
cyber park purposes as certified by the Director and has undertaken--
(i) to enter into an agreement in the prescribed form for carrying out and completion of
development works in accordance with the licence granted ;
(ii) to pay proportionate development charges in the external development works as defined in
clause(g) of section 2 are to be carried out by the government or any other local authority. The
proportion in which and the time within which, such payment is to be made shall be determined by
the Director ;
(iii) the responsibility for the maintenance and upkeep of all roads, open spaces, public parks and
public health services for a period of five years from the date of issue of the completion certificate
unless earlier relieved of this responsibility and thereupon to transfer all such roads, open spaces,
public parks and public health services free of cost to the Government or the local authority, as the
case may be ;
(iv) to construct at his own cost, or get constructed by any other institution or individual at its cost,
schools, hospitals, community centres and other community buildings on the lands set apart for this
purpose, or to transfer to the Government at any time, if so desired by the Government, free of cost
the land set apart for schools, hospitals, community centres and community buildings, in which case
the Government shall be at liberty to transfer such land to any person or institutions including a
local authority on such terms and conditions as it may deem fit ;
(v) to permit the Director or any other officer uthorized by him to inspect the execution of the layout
and the development works in the colony and to carry out all directions issued by him for ensuring
due compliance of the execution of the layout and development works in accordance with the licence
granted :Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

(4) The licence so granted shall be for a period of 2 years an will be renewable from
time to time for a period of one years, on payment of prescribed fee.
Provided that the Director, having regard to the amenities which exit or are proposed to be provided
in the locality, is of the opinion that it is not necessary or possible to provide one or more such
amenities, may exempt the licencee from providing such amenities either wholly or in part ;
(b) refuse to grant a licence, by means of a speaking order, after affording the applicant an
opportunity of being heard.
[Provided that in the licensed colony permitted as a special project by the Government, the licence
shall be valid for a maximum period of five years and shall be renewable for a period as decided by
the Government.] (5) A separate licence shall be required for each colony.
3-A . Establishment of Fund (1) Any colonizer whom a licence has been given under this Act shall
deposit as service charges a sum [at such rate as may be prescribed by the Government from time to
time, per square metre of the gross area and of the covered area of all the floors in case of flats
proposed to be developed by him into a colony] in two equal instalments. The first instalment shall
be deposited within 60 days from the date of the grant of the licence and the second instalment to be
deposited within six months from the date of grant of the licence.
(2) The Haryana Urban Development Authority local authorities, firms, undertakings of
Government and other authorities involved in land development shall also be liable to deposit the
service charges and shall be deemed to be colonizers for this purpose only. The date of first inviting
applications for sale of plots in any colony by it shall be deemed to be the date of granting of licence
under this Act for the purpose of deposit of service charges.
(3) The service charges shall be deposited by the colonizer with such officer or person as may be
appointed by the Government in this behalf. (4) The colonizer shall in turn be entitled to pass on the
service charges paid by him to the plot holder.
(5) The amount of service charges if not paid within the prescribed period shall be recoverable as
arrears of land revenue.
(6) The amount of service charges so deposited by the colonizer shall constitute a fund called the
Haryana Urban Development Fund (hereinafter referred to as the Fund) which shall vest in the
State Government.
(7) The Fund shall be administered by such officers of the State Government as may be appointed by
it for this purpose.
(8) The amount of service charges deposited by the colonizers and grants from the Government or
the local authority shall be credited to the Fund. (9) The Fund shall be utilized by the State
Government for the benefit of the urban development and for creation and improvement of urbanDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

infrastructure in the State of Haryana. The Fund may also be utilized to meet the cost of
administering the Fund.
(10) The Government shall publish annually in the Official Gazette the report of the activities
financed from the fund and the statement of accounts.
Section 3 ................
Section 4..................
Section 5. Cost of Development Works (1) The colonizer shall deposit thirty per centum of the
amount realised, from time to time, by him, from the plot-holders within a period of ten days of its
realisation in a separate account to be maintained in a scheduled bank. This amount shall only be
utilised by him towards meeting the cost of internal development works in the colony. After the
internal development works of the colony have been completed to the satisfaction of the Director,
the coloniser shall be at liberty to withdraw the balance amount. The remaining seventy per centum
of the said amount shall be deemed to have been retained by the coloniser, inter alia, to meet the
cost of land and external development works.
(2) The colonizer shall maintain accounts of the amount kept in the scheduled bank, in such manner
as may be prescribed :
Provided that where the licence under section 3 is granted for setting up a colony for
cyber city or cyber park purposes, the provisions of sub- sections (1) and (2) shall not
be applicable.
------------------------------------------------------------------------ Rule 2. Definitions
(a) ........................
(b) "amenity" includes roads, water supply, street lighting, drainage, sewerage, public
parks, schools, play grounds, hospitals, community centers and other community
buildings , horticulture, land scaping and any other public utility service;
Rule 3..............
Rule 4 ..............
Rule 5. Development works to be provided in colony [Section 3(3)]--
The designs and specifications of the development works to be provided in a colony shall include--
(a) metalling of roads and paving of footpaths;Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

(b) turfing and plantation of trees in open spaces;
(c) street lighting;
(d) adequate and wholesome water supply;
(e) sewers and drains both for storm and sullage water and necessary provision for their treatment
and disposal; and
(f) any other works that the Director may think necessary in the interest of proper development of
the colony.
11. Conditions required to be fulfilled by applicant [Section 3 (3)]--
(1) the applicant shall--
(a)     furnish to the Director a bank guarantee
        equal to twenty five percent of           the
estimated cost of the development works as certified by the Director and enter into an agreement in
form LC-IV for carrying out and completion of development works in accordance with the licence
finally granted;
(b) undertake to deposit fifty percent of the amount to be realized by him from the plot- holders,
from time to time, within ten days of its realization in a separate account to be maintained in a
scheduled bank and this amount shall only be utilized towards meeting the cost of internal
development works in the colony;
(c) undertake to pay proportionate development charges if the main lines of roads, drainage,
sewerage, water supply and electricity are to be laid out and constructed by the Government or any
other local authority. The proportion in which and the time within which such payment is to be
made shall be determined by the Director;
(d) undertake responsibility for the maintenance and upkeep of all roads, open spaces, public parks
and public health services for a period of five years from the date of issue of the completion
certificate under rule 16 unless earlier relieved of this responsibility and there upon to transfer all
such roads, open spaces, public parks and public health services free of cost to the Government or
the local authority, as the case may be;
(e) undertake to construct at his own cost or get constructed by any other institution or individual at
its cost, schools, hospitals, community centers and other community buildings on the land set apart
for this purpose, or undertake to transfer to the government at any time, if so desired by the
Government free of cost, the land set apart for schools, hospitals, community centers and
community buildings, in which case the Government shall be at liberty to transfer such land to anyDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

person or institution including a local authority on such terms and conditions as it may deem fit;
and
(f) undertake to permit the Director or any other officer authorized by him to inspect the execution
of the layout and the development works in the colony and to carry out all directions issued by him
for ensuring due compliance of the execution of the layout and development works in accordance
with the licence granted.
(2) If the Director, having regard to the amenities which exist or are proposed to be provided in the
locality, decides that it is not necessary or possible to provide such amenity or amenities, the
applicant will be informed thereof and clauses (c), (d) and (e) of sub-rule (1) shall be deemed to have
been modified to that extent.
12. Grant of licence [ Section 3 (3) and (4)]--
(1)After the applicant has fulfilled all the conditions laid down in rule 11 to the satisfaction of the
Director , the Director shall grant the licence in form LC-V. (2)The licence granted under sub-rule
(1) shall be valid for a period of two years from the date of its grant during which period all
development works in the colony shall be completed and certificate of completion obtained from the
Director as provided in rule 16.
16. Completion certificate/Part Completion Certificate [Section 24]--
(1)After the colony has been laid out according to approved layout plans and development works
have been executed according to the approved designs and specifications the colonizer shall make an
application to the Director in form LC-VIII.
(2)After such (scrutiny), as may be necessary, the Director may issue a completion certificate/part
completion certificate in form LC-IX or refuse to issue such certificate stating the reasons for such
refusal;
Provided that the colonizer shall be afforded an opportunity of being heard before such refusal.
18. Cancellation of licence [Section 8(1)]-- (1) If the Director determines at any time that the
execution of the layout plans and the construction or other works is not proceeding according to the
licence granted under rule 12 or is below specification or is in violation of the provisions of these
rules or of any law or rules for the time being in force, he shall by notice in form LC-X require the
colonizer to remove the various defects within the time specified in the notice. (2) If the colonizer
fails to comply with the requirements detailed in the notice issued under sub-rule (1), the Director
shall issue him a further notice in form LC-XI to afford him an opportunity to show cause within a
period of one month why the licence granted should not be cancelled.
(3) After hearing the colonizer and considering such representation as he may make the Director
may either cancel the licence or grant him further time for complying with the requirements of theDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

notice issued under sub- rule (1). If, however, the colonizer does not comply with the said
requirements within such extended period, the Director shall cancel the licence and thereafter,
within one month, shall cause a proclamation made in the locality about the cancellation of the
licence by beat of drum within thirty days of cancellation of licence.
(4) On cancellation of the licence, no further work shall be undertaken or carried out by the
colonizer, [(5) Deleted.]
20. Release of Bank guarantee [Section 24]--
After the layout and development works or part thereof in respect of the colony or part thereof have
been completed and a completion certificate in respect thereof issued, the Director may, on an
application in this behalf from the colonizer, release bank guarantee or part thereof as the case may
be;
Provided that if the completion of the colony is taken in parts only , the part of the bank guarantee
corresponding to the part to the colony completed shall be released;
Provided further that the bank guarantee equivalent to 1/15th amount thereof shall be kept
unreleased to ensure upkeep and maintenance of the colony or part thereof, as the case may be, for a
period of five years from the date of issue of the completion certificate under rule 16 or earlier, in
case the colonizer is relieved of the responsibilities in this behalf.
21...........................
22................................
23.................................
24.................................
25....................................
26. maintenance and submission of accounts [Section 5 and 6]--
(1) The colonizer shall--
(i) issue regular receipts to the plot holders in respect of the money received by him and maintain
counterfoils of the receipts so issued;
(ii) maintain separate ledger account of each plot-holder;
(iii) maintain a register containing authenticated copies of each of the agreements entered into
between him and each of the plot holders; andDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

(iv) maintain accounts books showing details of expenses incurred by him on various development
works in the colony.
(2) The colonizer shall within a period of three months after the close of every financial year, submit
to the director through registered post with acknowledgement due a statement of accounts
indicating the amount realized from each plot-holders, the expenditure incurred on internal and
external development works separately of the colony with details thereof together with the amount
due from each plot holder indicating their postal address. This statement should be duly audited,
certified and signed by a chartered accountant.
9. The validity of the impugned memo is required to be decided with reference to the scheme of the
Act, Rules and the Regulations framed thereunder.
10. The agreement with the Governor required to be entered by owners of land intending to set up a
colony is structured and regulated by Rule 11 of the Rules. The terms and conditions of the
agreement and the obligations of the owner of land and covenants thereof are prescribed by
Statutory Rules. The contract between the owner of land and its buyers, unlike the agreement
entered by the owner of the land with the government, is not required to be in any statutory form. It
is a contract between the two willing contracting parties whereunder the terms and conditions are
mutually agreed upon. The covenants decide the mutual obligations between the owner of the land
and the buyers thereof.
Interpretation of Contract:
11. It is settled principle in law that a contract is interpreted according to its purpose. The purpose of
a contract is the interests, objectives, values, policy that the contract is designed to actualize. It
comprises joint intent of the parties. Every such contract expresses the autonomy of the contractual
parties' private will. It creates reasonable, legally protected expectations between the parties and
reliance on its results. Consistent with the character of purposive interpretation, the court is
required to determine the ultimate purpose of a contract primarily by the joint intent of the parties
at the time the contract so formed. It is not the intent of a single party; it is the joint intent of both
parties and the joint intent of the parties is to be discovered from the entirety of the contract and the
circumstances surrounding its formation. As is stated in Anson's Law of Contract, "a basic principle
of the Common Law of Contract is that the parties are free to determine for themselves what
primary obligations they will accept....Today, the position is seen in a different light. Freedom of
contract is generally regarded as a reasonable, social, ideal only to the extent that equality of
bargaining power between the contracting parties can be assumed and no injury is done to the
interests of the community at large." The Court assumes "that the parties to the contract are
reasonable persons who seek to achieve reasonable results, fairness and efficiency.... In a contract
between the joint intent of the parties and the intent of the reasonable person, joint intent trumps,
and the Judge should interpret the contract accordingly. A party who claims otherwise, violates the
principle of good faith. [ See Purposive Interpretation in Law by Aharon Barak : 2005 Princeton
University Press].Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

Extension Fee:
12. Whether the Director is empowered to issue any direction, directing the appellants not to collect
the extension fee with further direction to delete the relevant clauses from the agreement?
13. The agreement entered into by the owners and purchasers inter-alia provides that the purchaser
shall, after approval of his building plans from the competent authority, "be bound to commence
construction of the house on the plot not later than three years from the date the sale deed is
executed in his favour....in case the purchaser fails to commence construction within the stipulated
period, the seller shall be entitled to resume the plot, refund the amount paid by the purchaser and
to resell the plot to somebody else provided that the seller in its sole discretion may extend the
aforesaid period of construction "provided the purchaser pays additional charges to the owner." It
was mutually agreed that a provision to this effect may have to be incorporated in the sale deed and
the purchaser "shall be bound by the same." This clause enables the owner to charge additional
amount for the non completion of the construction by the purchaser within the period stipulated in
the agreement. There is nothing in the Act, the Rules and Regulations prohibiting the owner of the
land to collect such charges from the buyer. The said provision for payment of "extension fee"
has been provided for in the agreement, according to the appellants, only in the
interest of speedy development of each colony, and also in order to prevent purchase
of plots by speculators who may keep the plot vacant without making any
construction with the only object to earn profit by selling the same at a future date
and such an act may prove detrimental to other purchasers as such acts obstruct the
all round development of the area which is pre-eminently/ predominantly in the
public interest. It is not necessary for us to express any firm opinion with regard to
the plea so taken by the appellants in this proceeding. It may altogether be a different
matter if the purchasers raise objection as regards the very covenants incorporated
into the agreement entered into by and between the parties in a properly constituted
proceedings on such grounds as may be available to them in law.
14. The question that arises for our consideration is whether the Director was justified in issuing
directions asking the licensee/owner to virtually amend the clauses/covenants in the agreement?
Whether the statute confers any authority or jurisdiction upon the Director to meddle with the
terms of agreement entered into by and between the owners and the purchasers of plots/flats?
15. The Director's functions and duties are well structured by the Act and the Rules. There is no
provision in the Act or the Rules empowering the Director to sit in judgment on the perceived
fairness of any clauses incorporated in the agreement entered by the parties. The terms and
conditions in the licence granted by the Director do not prohibit incorporation of such a clause in
the agreement to be entered between the owners and the purchasers. Nor there is any clause in the
agreement entered by the owner with the Governor through the Director empowering the Director
to sit in appeal over the agreement entered by the owners with the purchasers of the plots. There is
no explanation forthcoming as to the source of power under which the Director could have issued
the impugned directions directing the owner to delete such clauses from the agreement entered withDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

the purchasers.
16. Whether Section 5 of the Act and Rule 11B read with Rule 26(2) of the Rules in any manner
prohibit collection of additional charges characterized as `extension fee' by the owner/colonizer?
17. Section 5 of the Act merely requires the colonizer to deposit 30% of the amount realised, from
time to time, from the plot holders in a separate account to be maintained in a scheduled bank and
the said amount is to be utilised by him only for meeting the cost of internal development works in
the colony. After the completion of the internal development works to the satisfaction of the
Director, the colonizer is entitled to withdraw the balance amount. The remaining 70% of the said
amount shall be deemed to have been retained by the colonizer to meet the cost of the land and the
external development works. There is no doubt that accounts are required to be maintained by the
colonizer in the prescribed manner.
Rule 11(b) merely reiterates as to what has been provided for in Section 5 of the Act.
Rule 26 obligates the colonizer to issue regular receipts to the plot holders in respect of the money
received by him and maintain counterfoils of the receipts so issued; maintain separate ledger of each
plot holder, maintain a Register containing authenticated copies of each of the agreements entered
into between him and each of the plot holders; and maintain account books showing details of
expenses incurred on various developmental works in the colony. We fail to appreciate as to how
and in what manner these provisions restrain or prohibit the colonizer/owner to insist buyers of the
plots to complete construction in time bound manner and charge extra amounts as may be agreed
between the parties for failure to do so. It shall always be open for the Director to insist the
colonizer/owner to submit a statement of accounts indicating the amount realized from each plot
holders, the expenditure incurred on internal and external development works. We do not find
anything in these provisions empowering the Director to issue the impugned directions prohibiting
the owners to collect the extension fee for the delayed construction of buildings by the purchasers of
the plots. We are essentially dealing with the question as to the authority of the Director and as to
whether he is empowered to pass such an order and not with regard to the question as to whether
the clauses dealing with this aspect of the matter suffer from any infirmity. The dispute, if any,
between the parties to the agreement, may have to be resolved in a properly constituted proceeding
in private law domain. Transfer Fee:
18. Whether the owner/colonizer in law after obtaining full payments from the allottees is
prohibited from transferring the plots to the nominees of the allottees? Whether the allottees' right
to nominate another person as purchaser of the property can be denied by the colonizer?
19. The prevailing practice of permitting transfer of plots before registration of conveyance deed to
the allottee is not contrary to the provisions of the Act or the Rules. The only justification sought to
be given by the respondent in this regard is that the State would like a separate set of stamp duty
paid to it in respect of each transaction, even though there is no conveyance deed executed as yet in
respect of the land in question. This argument is wholly devoid of any merit. Section 17 (1)(b) of the
Registration Act requires that where the Conveyance Deed has been prepared for effecting theDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

transfer of a plot or other immovable property, such deed should be registered within a period of 4
months after its execution. It does not, however, contain any provision whatsoever requiring that a
Conveyance Deed should be executed within any period of time after the execution of sale
agreement between the buyer and the seller. Nor there is any provision whatsoever in the Stamp Act
or Registration Act imposing any restriction on the assignment or transfer of rights under a
sale/purchase agreement by the purchaser to a third party, before the execution of any conveyance
deed in respect of any immovable property. The parties in the agreement had agreed for the
substitution of the name of allottees at the sole discretion of the owner. The conveyance deed
executed by the owner is the one which is executed either in favour of the allottee or his nominee as
the case may be on which a proper stamp duty and registration fee is required to be paid. In any
event the Director has no power under the Act or the Rules to issue any such direction altogether
prohibiting such nomination of another person thereby substituting the allottee.
MAINTENANCE FEE:
20. The crucial question that arises for our consideration is whether the Director of Country and
Town Planning is empowered to issue any directions, directing the appellants to stop charging
maintenance fee from the plot/flat holders and also "delete the relevant clauses from the agreement"
and refund the amounts so far collected to the Government immediately. Whether
the Act imposes any obligation upon the colonizers or owners to incur maintenance
charges out of their own resources? Whether the colonizers/owners are prohibited
from recovering the amounts spent towards the maintenance charges from the
plots/flats buyers? Whether the clause incorporated in the sale agreement enabling
the owners to collect the maintenance charges is void?
21. The Act no doubt imposes certain obligations upon the colonizers/owners and specifies certain
items of expenses to be borne by them. Section 3(3)(a)(ii) of the Act requires the colonizer/owner to
pay proportionate development charges if the external development works as defined under Section
2
(g) of the Act are to be carried out by the Government or any other local authority. Similarly Section
3 (3) (a) (iv) requires the owner to construct at his own cost schools, hospitals, community centres
and other community buildings on the lands set apart for the said purposes. Further Section 5 of the
Act read with Rule 11 (1) (b) imposes obligation and requires the owner to meet the cost of internal
development works as defined in Section 2 (i) of the Act.
22. It is no doubt true that Section 3 (3) (a) (iii) imposes responsibility for the maintenance and
upkeep of all roads, open spaces, public parks and public health services for a period of five years
from the date of issue of the completion certificate unless earlier relieved of this responsibility and
thereupon to transfer all such roads, open spaces, public parks and public health services free of cost
to the Government or the authority, as the case may be. That a bare reading of the provisions does
not suggest that the owner is required to provide the said maintenance services free of cost. On the
other hand, the latter part of Section 3 (3) (a) (iii) provides that on the expiry of the said period ofDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

five years the owner is required to transfer all such roads, open spaces etc. free of cost to the
government or the local authority, as the case may be.
23. The learned senior counsel for the respondents relying on Section 2 (i) (vi) contended that
maintenance expenses are covered by the said provisions and, therefore, they are required to be
borne by the owner/colonizer. Let us test the submission so made by the learned senior counsel. The
question that requires to be considered whether providing services of the kind by the
owner/colonizer for which maintenance charges are imposed is a "work" of "internal development"
which has to be carried out within the colony. Section 2 (i) defines "Internal Development Works" as
under:
(a) metalling of roads and paving of footpaths;
(b) turfing and plantation of trees in open spaces;
  (c)        street lighting;
  (d)        adequate and wholesome water supply;
  (e)        sewers and drains both for storm and sullage water
and necessary provision for their treatment and disposal; and
(f) any other works that the Director may think necessary in the interest of proper
development of the colony.
24. There is no dispute whatsoever that any maintenance fee or charges are being collected by the
owners/colonizers in respect of any of the internal development works mentioned in Section 2 (i). It
is not disputed that the appellants are rendering the following additional services, which are not in
any manner whatsoever covered by Section 3 (3) (a) (iii) or any provisions of the Act or the Rules.
        a)     Round the clock security
        b)     Electricity consumption of street lights, which shall
include replacement of bulbs, tubes etc., maintenance of electrical system and its upgradation.
c) Reparing and strengthening of boundary walls and fencing.
d) Conservancy and general upkeep, which shall include sweeping of roads, door to door garbage
collection and its disposal, clearing of unwanted growth of plants in vacant plots,
repair/replacement/painting of signages, guide maps and gates etc.
e) Upgradation of Roads/parks.Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

f) Establishment/administrative charges for rendering the aforesaid services, which shall include
salaries of staff, rent of the building, telephone, printing, stationery, electricity, computer expenses
etc. incurred in running complaint centre in DLF City.
25. In our considered opinion the maintenance fee/charges levied and collected are clearly not in
respect of any of the internal development works defined under clause (i) to (v) of Section 2 (i).
Perhaps, the learned senior counsel conscious of the difficulty to bring it under Section 2 (i) (i) to (v)
urged that maintenance expenses can be considered to be covered by Section 2 (i) (vi), which refers
to "any other work that the Director may think necessary in the interest of proper development of a
colony". We find no merit in the submission. Clause (i) to (v) of Section 2 (i) refers to "Works" which
are erected within the colony as an integral part of the internal development of the colony. The
residuary clause (vi) of Section 2 (i) also refers to "work" which means and implies activities akin to
that of which constitute an `internal development of the colony'. We have already noticed that
providing services of the kind for which the maintenance charges/fee are collected, are in no manner
in respect of a "work" of "internal development" which is required to be carried out within the
licenced area. The expression "work" in Section (i) (vi) cannot be interpreted in isolation ignoring
the clauses (i) to (v) in Section 2 (i). Such a construction is impermissible in law.
26. It is, therefore, clear that Director has no authority or power under the Act to issue any
directions directing the owners/colonizers to incur maintenance expenses, by deeming the same to
be part of the internal development works covered by Section 2 (i). It is needless to reiterate that the
maintenance of services specifies in Section 3 (3) (a) (iii) cannot be considered to be part of the
internal development works as defined by Section 2 (i).
27. Be it noted that this plea has not been taken by the Director in the High Court nor any such point
is urged on his behalf in these appeals before us. On the other hand the material available on record
suggests that the Director has never considered the maintenance expenses to be part of internal
development works as specified in Section 2 (i). Section 3 (3) (a) of the Act mandates the
colonizer/owner to furnish a bank guarantee equal to 25% of the estimated cost of the development
works. It is an admitted case that the Director has not taken into consideration the said
maintenance expenses for the purpose of computing the amount of the bank guarantee, which is
25% of the total cost of the internal development works.
28. Whether the amount of maintenance service charges was already included in the sale price of the
plots/flats?
29. There is no price fixation formula devised under the provisions of the Act, Rules and Regulations
framed thereunder. The Statutory Authorities have no role to play in the fixation of price and costs
of land and rate at which the plots/flats are to be sold. The price charged by the owner for the plot is
fixed and covered by clauses (1) and (2) of plot sale agreement entered into by and between the
parties. The agreed sale price of the plot includes external development charges. The payment of
maintenance charges by the plot buyer is provided for in clause (14) of the said agreement. The sale
price charged by the owner from the plot buyers includes maintenance of service charges at the most
could be a bonafide contention between the owners/colonizers and the purchasers of plots/flats. TheDlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

Act, Rules and the Regulations framed thereunder do not provide for any approval or ratification of
the agreements so entered into by and between the owners/colonizers. The Director of the Country
and Town Planning is not required to put his seal of approval on the agreements so entered. The
Director is not authorized or empowered to review or evaluate the terms of contract and resolve the
disputes, if any, between the owners/colonizers and the purchasers of plots/flats.
30. The sale price charged by the owner from the buyers for the sale of the plots/flats is a market
driven sale price and is not based on any particular figure of cost. The provisions of the Act or the
Rules in no manner impose any price control directly or indirectly in respect of plots/flats sold by
the colonizer/owner. The sale and purchase of the plots/flats is between a willing vendor and a
willing vendee. The Director is not empowered to meddle with the transactions and put any
restriction on the rights of the owner/colonizer in the matter of sale and purchase of plots/flats.
31. Now what remains for our consideration is whether a direction could have been issued by the
Director to delete the clause or relevant clauses from the agreements mutually entered by and
between the parties. The agreement by and between the owners/colonizers, agreed terms and
conditions and covenant therein are purely under private law domain.
32. Let us now examine what are the functions and duties of the Director and the power conferred
upon him under the provisions of the Act and Rules. Section 3(1) of the Act provides that any owner
of land desirous of setting up a colony shall make an application in writing to the Director in the
prescribed Form LC-I alongwith the required particulars mentioned therein which are not required
to be noticed in detail. Section 3 (3) (a) provides that after making a proper enquiry under
sub-section (2), the Director, by an order in writing, shall grant a licence in the prescribed form,
after the application is furnished to the Director, a bank guarantee equal to 25 per centum of the
estimated cost of development works in case of area of land divided or proposed to be divided into
the plots or flats for residential, commercial or industrial purpose and a bank guarantee equal to
thirty-seven and a half per centum of the estimated cost of development works in case of cyber city
or cyber park. The owner is required to enter into an agreement in the prescribed form for carrying
out and for the completion of development works in accordance with the licence granted. Section
3(3)(a)(v) permits the Director or any other officer authorized by him to inspect the execution of the
layout and the development works in the colony and to carry out all the directions issued by him for
ensuring due compliance of the execution of the layout and development works in accordance with
the licence granted. It is thus clear that the Director is entitled to inspect the execution of the lay out
and internal and external development works in the colony and to issue appropriate directions
which he may consider necessary and proper for ensuring due compliance of the execution of the
layout and development works in accordance with the licence granted. This is to be read along with
the condition of licence which requires "that the colony is laid out to conform to the approved layout
plans and development works are executed according to the designs and specifications shown in the
approved plan accompanying the licence." The Director thus is empowered to issue appropriate
directions in order to ensure strict compliance of the terms and conditions of licence subject to
which the colony is to be set up by the owner or colonizer. Rule 5 provides that the designs and
specifications of the development works to be provided in a colony which is nothing but
reproduction of Section 2 (i) which we have noticed in the preceding paragraphs.Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

33. Section 8 speaks about cancellation of licence by the Director if the colonizer contravenes any of
the conditions of the licence or the provisions of the Act or the Rules made thereunder; provided
that before such cancellation the colonizer shall be given an opportunity of being heard.
34. It further provides for the consequences that may flow after the cancellation of the licence.
35. From a fair analysis of these provisions, it becomes clear that the Director's functions and duties
and as well as power is completely structured by the statute and the Rules. He undoubtedly plays a
vital role and is authorised to issue appropriate directions from time to time concerning the
execution of layout and development works in the colony and every such directions issued are
required to be complied with by the licensee.
36. In our considered opinion the Director is not authorized to interfere with agreements voluntarily
entered into by and between the owner/colonizer and the purchasers of plots/flats. The agreed
terms and conditions by and between the parties do not require the approval or ratification by the
Director nor is the Director authorized to issue any direction to amend, modify or alter any of the
clauses in the agreement entered into by and between the parties.
37. It is thus clear that there is no provision in the Act, Rules or in the licence that empowers the
Director to fix the sale price of the plots or the cost of flats. The impugned directions issued by the
Director are beyond the limits provided by the empowering Act. The directions so issued by the
Director suffer from lack of power. It needs no restatement that any order which is ultra vires or
outside jurisdiction is void in law, i.e. deprived of its legal effect. An order which is not within the
powers given by the empowering Act, it has no legal leg to stand on. Order which is ultra vires is a
nullity, utterly without existence or effect in law.
38. In Khargram Panchayat Samiti and another vs. State of W.B. and others [(1987) 3 SCC 82] upon
which reliance has been placed by the leaned senior counsel for the second respondent in no manner
supports the impugned directions issued by the Director. The only issue which arose was, whether,
in the absence of any specific statutory provision, the authority conferred with a statutory power to
issue licence for holding "hats" or "fairs" also possessed any incidental powers to fix the date on
which the `hat' or `fair' would take place. It was held that such power to fix the date was necessarily
incidental to the power of the grant of the licence, in the absence of any provision in the statute. In
the very nature of things this court came to the conclusion that it is impossible to separate the power
to grant a licence to hold the "fairs" from that of the fixation of the date thereof, because the two are
inseparably and intrinsically interconnected. The provisions of the 1975 Act and the Rules
enumerates in detail the powers of Director and arms him with jurisdiction to issue appropriate
directions from time to time for ensuring due compliance in the execution of the layout and the
development works in accordance with the licence granted. The impugned directions issued result in
far-reaching consequences and they cannot be considered to be incidental or ancillary to the power
conferred under the Act and Rules. The submission made in this regard is totally devoid of merit.
39. In D.L.F. Qutab Enclave Complex Educational Charitable Trust vs. State of Haryana and others
[(2003) 5 SCC 622 ], it is held by this court :Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

"38. A regulatory Act must be construed having regard to the purpose it seeks to
achieve. The State as a statutory authority cannot ask for something which is not
contemplated under the Act."
40. Thus while Act and Rules may impose many restrictions on profit percentages etc. time limit on
construction and handing over of such construction, such power does not encompass within itself
the right to exercise power in manner that inhibits terms and contracts and freedom granted
therein.
LIMIT OF 15% PROFIT :
41. The question as to whether appellants made any profit over and above 15% would arise for
consideration only after the grant of final completion certificate in respect of the entire
colony/development. The application for grant of final completion certificate remained pending
with the authorities since long time. The complete accounts are to be finalized to determine whether
the 15% limit on the profit has been exceeded and whether the colonizers/owners made profits over
and above that. Further steps may have to be taken in accordance with law only thereafter. It would
be appropriate to direct the authorities to decide the application so filed by the
developers/colonizers for grant of final completion certificate as expeditiously as possible preferably
within six months. In case if it is found that the owners had exceeded the said 15% limit on the
profit, it shall always be open to the authorities to take appropriate action in accordance with law.
42. For the aforesaid reasons, we find it difficult to sustain the impugned memo of the Director and
the same is set aside. But this order of ours shall not preclude owners of plots/flats to avail such
remedies as may be available to them in law and raise any dispute that had arisen or may arise and
for the enforcement of contractual terms and conditions in which event the matters have to be
decided on its own merits uninfluenced by the observation, if any, made in the order of the High
Court of Punjab and Haryana and in this order. The question as to whether the cost of the plot
includes the maintenance charges may have to be decided on a proper interpretation of the terms
and conditions of the agreement. The court in a public law remedy cannot undertake the task of
resolving disputes arising out of a contract for such disputes as they essentially lie in the private law
domain.
43. In the circumstances, we find it very difficult to sustain the view taken by the High Court for
upholding the impugned memo issued by the Director, Town and Country Planning. The judgment
of the High court is, accordingly, set aside. The appeals are, accordingly, allowed subject to the
observations made hereinabove.
44. All interlocutory applications and contempt cases are, accordingly, disposed of in terms of this
order.
----------------------------J. [B.SUDERSHAN REDDY]
----------------------------j.Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

[SURINDER SINGH NIJJAR] New Delhi, November 19, 2010Dlf Universal Ltd. & Anr vs Director, T.&C.; Planning Haryana & Ors on 19 November, 2010

