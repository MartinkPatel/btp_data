Arunachal Pradesh Goods Tax Act, 2005
ARUNACHAL PRADESH
India
Arunachal Pradesh Goods Tax Act, 2005
Act 3 of 2005
Published on 10 March 2005• 
Commenced on 10 March 2005• 
[This is the version of this document from 10 March 2005.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Arunachal Pradesh Goods Tax Act, 2005(Act No. 3 of 2005)Last Updated 19th February,
2020[Dated 10.3.2005.]An Act To Levy consumption tax on goods consumed in the State of
Arunachal Pradesh through a combination of tax on entry of goods in local area of Arunachal
Pradesh and value added sales tax on the business in the State.Be it enacted by the Legislative
Assembly of Arunachal Pradesh in the Fifty-Sixth Year of the Republic of India as follows:-Chapter-
I Preliminary
1. Short title, extent and commencement.
(1)This Act may be called the Arunachal Pradesh Goods Tax Act, 2005.(2)It extends to the whole of
the Arunachal Pradesh.(3)It shall come into force on such date as the Government may, by
notification in the Official Gazette, appoint.Provided that different dates may be appointed for
different provisions of this Act and any reference in any such provision to the commencement of this
Act shall be construed as a reference to the coming into force of that provision.(4)Upon coming into
force of this Act, the Act applies to every sale of goods and the import of goods into Arunachal
Pradesh in the manner provided in Section 13.
2. Definitions.
- In this Act, unless the context otherwise requires:(a)"Accountant" means-(i)a Chartered
Accountant within the meaning of the Chartered Accountants Act, 1949;(ii)a person who by virtue of
the provisions of section 226(2) of the Companies Act, 1956, is entitled to be appointed to act as an
auditor of Companies registered; or(iii)a person referred to in Section 619 of the Companies Act,
1956.(b)"Appellate Tribunal" means the Appellate Tribunal constituted under section 74 of this
Act.(c)"Approved Road Transporter" means an Approved Road Transporter as described in Section
26.(d)"Approved Warehouse" means a warehouse operated by a person permitted to do so pursuant
to Section 26.(e)"adequate proof" means such documents, testimony or other evidence as may be
prescribed.(f)"business" includes:(i)the provision of such services, as may be prescribed (andArunachal Pradesh Goods Tax Act, 2005

excludes services provided by an employee);(ii)any trade, commerce or manufacture;(iii)any
adventure or concern in the nature of trade, commerce or manufacture;(iv)any agricultural or
horticultural activity to produce outputs taxable under the Act.(v)any transaction in connection
with, or incidental or ancillary to, such trade, commerce, manufacture, adventure or concern;
and(vi)any occasional transaction in the nature of such service, trade, commerce, manufacture,
adventure or concern whether or not there is volume, frequency, continuity or regularity of such
transaction;whether or not such service, trade, commerce, manufacture, adventure or concern is
carried on with a motive to make gain or profit and whether or not any gain or profit accrues from
such service, trade, commerce, manufacture, adventure or concern.Explanation. - For the purpose of
this clause -(i)any transaction of sale or purchase of capital assets pertaining to such service, trade,
commerce, manufacture, adventure or concern shall be deemed to be business.(ii)purchase of any
goods, the price of which is debited to the business and sale of any goods, the proceeds of which are
credited to the business shall be deemed to be business.(g)"business premises" means any building
or place used by a person for the conduct of his business, but does not include any building or the
part of any building that is used principally as a residence.(h)"capital goods" means plant,
machinery and equipment used in the process of business.(i)"casual trader" means a person who,
whether as principal, agent or in any other capacity undertakes occasional transactions in the nature
of business involving buying, selling, supply or distribution of goods or conducting any
exhibition-cum-sale in Arunachal Pradesh whether for cash, deferred payment, commission,
remuneration or other valuable consideration.(j)"Commissioner" means the Commissioner of Goods
Tax.(k)"in the course of" includes activities done for the purposes of, in connection with or
incidental to and includes activities done as part of the preparation for the activity and in the
termination of the activity.(l)"dealer" means -(i)many person who, for the purposes of or in
connection with or incidental to or in the course of his business buys, sells, supplies or distributes
goods directly or otherwise, whether for cash or for deferred payment or for commission,
remuneration or other valuable consideration;(ii)each department of the Central Government or a
State Government, a local Authority, Panchayat, Municipality, Development Authority, Cantonment
Board and each autonomous or statutory body or an industrial, commercial, banking, insurance or
trading undertaking whether or not of the Central Government or any of the State Governments or
of a local authority, if it sells, supplies or distributes goods, in the course of specified activities which
may be prescribed from time to time;(iii)a factor, commission agent, broker, del credere agent, or
any other mercantile agent by whatever name called, who carries on the business of buying, selling,
supplying or distributing goods on behalf of any principal, whether disclosed or not;(iv)an agent of a
non-resident (where such nonresident is a dealer under any other sub-clause of this
definition);(v)local branch of a firm or company or association of persons, outside Arunachal
Pradesh (where such firm, company, association of persons is a dealer under any other sub-clause of
this definition);(vi)a club, association, society, trust, or cooperative society, whether incorporated or
unincorporated, which buys goods from or sells goods to its members for price, fee or subscription,
whether or not in the course of business;(vii)an auctioneer, who sells or auctions goods belonging to
any principal, whether disclosed or not and whether the offer of the intending purchaser is accepted
by him or by the principal or a nominee of the principal;(viii)a casual trader; or(ix)any person who,
for the purposes of or in connection with or incidental to or in the course of his business disposes of
any goods as unclaimed or confiscated, or unserviceable or scrap, surplus, old, obsolete or as
discarded material or waste products by way of sale.(m)"entry of goods into Arunachal Pradesh"Arunachal Pradesh Goods Tax Act, 2005

means taking, receiving, bringing, carrying, transporting, or causing to bring or receive goods into
the local area of Arunachal Pradesh from any place outside Arunachal Pradesh. In the case of goods
arriving in Arunachal Pradesh from a foreign country through Customs, the import of the goods
occurs at the place where the goods are cleared by Customs for home consumption.(n)"fair market
value" means the value at which goods of like kind and quality are sold or would be sold in the same
quantities between unrelated parties in the open market in Arunachal Pradesh.(o)"goods" means
every kind of movable property (other than newspapers, actionable claims, stocks, shares and
securities) and includes:(i)livestock, all materials, commodities, grass or things attached to or
forming part of the earth which are agreed to be severed before sale or under a contract of sale;
and(ii)property in goods (whether as goods or in some other form) involved in the execution of a
works contract, lease or hire-purchase or those to be used in the fitting out, improvement or repair
of movable property.(p)"goods vehicle" means a motor vehicle, vessel, boat, animal, railway
carriage, aircraft, and any other form of conveyance used for carrying goods.(q)"import" means
causing entry of goods into local area of Arunachal Pradesh.(r)"importer" means:(i)a person who
brings their own goods into Arunachal Pradesh; or(ii)a person on whose behalf another person
brings goods into Arunachal Pradesh; or(iii)in the case of a sale occurring in the circumstances
referred to in section 6(2) of the Central Sales Tax Act, 1956 (74 of 1956), the person in Arunachal
Pradesh to whom the goods are delivered.(s)"input tax" -(i)in relation to the purchase of goods,
means the proportion of the price paid by the buyer for the goods which represents tax for which the
selling dealer is liable;(ii)in relation to an import of goods, means the amount of tax for which the
importer is liable under this Act in respect of the import.(t)"Local area of Arunachal Pradesh" means
the area falling within the jurisdiction of the State of Arunachal Pradesh.(u)"notified date" means
the date notified by the Governor under sub-section (3) of Section 1.(v)"net tax" means the amount
calculated for a tax period under section 11 of this Act.(w)"non-creditable goods" means the goods
listed in the Seventh Schedule.(x)"non-taxable import" means the goods listed in the Eighth
Schedule.(y)"non-resident" means a person who has no fixed place of business or residence in
Arunachal Pradesh.(z)"notified" means notified by the Commissioner in the Official
Gazette.(za)"Official Gazette" means the Arunachal Pradesh Gazette.(zb)"prescribed" means
prescribed in the Rules made under this Act.(zc)"registered dealer" means a dealer registered under
this Act.(zd)a person is "related" to another person (referred to in this definition as a "dealer") if the
person:(i)is a relative of the dealer:(ii)is a partnership of which the dealer is a member, or a partner
in that partnership;(iii)is a company in which the dealer (either alone or in conjunction with another
person who is or persons who are related to the dealer under another paragraph of this definition)
directly or indirectly holds 40% or more of outstanding voting stock or shares;(iv)is a person who
(either alone or in conjunction with another reason who is, or other persons who are, related to the
person under another paragraph of this definition) directly or indirectly owns 40% or more of
outstanding voting stock or shares of the dealer;(v)is a company in which 40% or more of
outstanding voting stock is held directly or indirectly by a person (either alone or in conjunction
with another person who is, or other persons who are, related to the person under another
paragraph of this definition) who also holds 40% or more of the outstanding voting stock or shares
of the dealer; or(vi)is controlled by the dealer, a person whom the dealer controls, or is a person who
is controlled by the same person who controls the dealer.(ze)"relative" means a relative as defined in
section 2(41) of the Companies Act, 1956.(zf)"sale" with its grammatical variations and cognate
expression means any transfer of property in goods by one person to another for cash or for deferredArunachal Pradesh Goods Tax Act, 2005

payment or for other valuable consideration (not including a grant or subvention payment paid by
one Government agency or department to another) and includes:(i)a transfer of property in goods
on hire purchase or other system of payment by instalments, but does not include a mortgage or
hypothecation of or a charge or pledge on goods;(ii)supply of goods by a society (including a
co-operative society), club, firm, or any Association to its members for cash or for deferred payment
or for commission, remuneration or other valuable consideration, whether or not in the course of
business;(iii)transfer of property in goods by an auctioneer referred to in sub-clause (vii) of clause
(I) of this section, or sale of goods in the course of any other activity in the nature of banking,
insurance who in the course of their main activity also sell goods repossessed or
re-claimed;(iv)transfer, otherwise than in pursuance of a contract, of property in any goods for cash,
deferred payment or other valuable consideration;(v)transfer of property in goods (whether as
goods or in some other form) involved in the execution of a works contract;(vi)transfer of the right
to use any goods for any purpose (whether or not for a specified period) for cash, deferred payment
or other valuable consideration;(vii)supply, by way of or as part of any service or in any other
manner whatsoever, of goods, being food or any other article for human consumption or any drink
(whether or not intoxicating), where such supply or service is for cash, deferred payment or other
valuable consideration;(viii)every disposal of goods referred to in sub-clause (ix) of clause (I) of this
section; and the words "sell", "buy" and "purchase" wherever appearing with all their grammatical
variations and cognate expressions, shall be construed accordingly.(zg)"sale price" means the
amount paid or payable as valuable consideration for any sale, including:(a)the amount of tax if any
for which the dealer is liable under section 3 of this Act;(b)the amount of tax if any for which the
dealer is liable under the Central Sales Tax Act, 1956 (74 of 1956);(c)in relation to the delivery of
goods on hire purchase or any system of payment by instalments, the amount of valuable
consideration payable to a person for such delivery including hire charges, interest and other
charges incidental to such transaction;(d)in relation to transfer of the right to use any goods for any
purpose (whether or not for a specified period) the valuable consideration or hiring charges received
or receivable for such transfer;(e)any sum charged for anything done by the dealer in respect of
goods at the time of or before the delivery thereof:,(f)amount of duties levied or leviable on the
goods under the Central Excise Act, .1944 or the Customs Act, 1962, or Arunachal Pradesh Excise
Act, 1993 whether such duties are payable by the seller or any other person; and(g)amount received
or receivable by the seller by way of deposit (whether refundable or not) which has been received or
is receivable whether by way of separate agreement or not, in connection with or incidental to or
ancillary to the sale of goods; less:(i)any sum allowed as discount which goes to reduce the sale price
according to the practice normally prevailing in trade;(ii)the cost of freight or delivery or the cost of
installation in cases where such cost is separately charged, and the words "purchase price" with all
their grammatical variations and cognate expressions, shall be construed accordingly.Explanation. -
A dealer's sale price always includes the tax payable by it on making the sale, if any.(zh)"tax" means
tax payable under this Act.(zi)"taxable quantum" means the amount defined in section 19.(zj)"tax
invoice" means the documents defined in section 51.(zk)"tax period" means the period prescribed in
the rules.(zI)"tax fraction" means the fraction calculated in accordance with formula,r / (r+100)
where `r.' is the percentage rate of tax applicable to the sale.(zm)"transporter" means any person
who, for the purposes of or in connection with or incidental to or in the course of his business
transports or causes to transport goods, and includes any person whose business consists of or
includes operating a railway, shipping company, air cargo terminal, inland container depot,Arunachal Pradesh Goods Tax Act, 2005

container freight station, courier service, postal service or airline.(zn)"turnover of purchases" means
the aggregate of the amounts of purchase price paid or payable by a person in any tax period,
including any input tax.(zo)"turnover" means the aggregate of the amounts of sale price received or
receivable by the person in any tax period, reduced by any tax for which the person is liable under
section 3(1)(a) of this Act.(zp)"value of goods" means the fair market value of the goods at that time
including insurance charges, excise duties, countervailing duties, tax paid or payable under the
Central Sales Tax Act, 1956 (74 of 1956) in respect of the sale, transport charges, freight charges and
all other charges incidental to the transaction of the goods.(zq)"works contract" includes any
agreement for carrying out for cash or for deferred payment or for valuable consideration, the
building construction, manufacture, processing, fabrication, erection, installation, fitting out,
improvement, repair or commissioning of any movable or immovable property.(zr)"year" means the
financial year from 1 April to 31 March.(zs)"manufacture" with all its grammatical variations and
cognate expressions, means producing, making, extracting, altering, ornamenting, blending,
finishing or otherwise processing, treating or adopting any goods.Chapter- II Imposition of Tax
3. Imposition of tax.
(1)Imposition on persons who are dealers and importers. Subject to other provisions of this Act,
every person who is -(a)a dealer and is -(i)registered under this Act; or(ii)required to be registered
under this Act; or(b)an importer of goods;shall be liable to pay tax calculated in accordance with this
Act, at the time and in the manner provided in this Act.(2)Imposed on sale and entry of goods. Every
person who -(a)is dealer, shall be liable to pay tax on every sale of goods effected by him -(i)while he
is a registered dealer under this Act; and(ii)on and from the day on which he was required to be
registered under this Act;(b)is an importer, shall be liable to pay tax on every entry effected by or for
him of goods for consumption, use or sale in local area of Arunachal Pradesh other than a
non-taxable import.(3)Amount of tax. The amount of tax payable under this Act by a person(a)in
respect of the sale of any goods, is the person's net tax for the tax period calculated under section 11
of this Act; and(b)in respect of the import of any goods, is the amount calculated by applying the
rate stipulated in section 4 to -(i)the value of the goods at the time of their import into Arunachal
Pradesh; or(ii)in the case of the import of goods which had previously left Arunachal Pradesh for
repair, re-engineering, reconditioning, assembly or processing, the value of any goods purchased
outside Arunachal Pradesh incorporated into the goods.(4)Time at which payment of net tax is due.
The net tax of a dealer shall be paid within 28 days of the conclusion of the dealer's tax
period.Explanation. - The net tax of a dealer (which is the dealer's tax reduced by tax credits and
with adjustments) shall be paid at the same time as furnishing a return, but the obligation to pay
arises by virtue of this provision and is not dependent on furnishing a return, nor on the issue of a
notice of assessment to the dealer.(5)Time at which payment of tax on entry of goods is due. The tax
due on the entry of goods shall be paid -(a)except as provided in (b),(i)if the goods enter Arunachal
Pradesh in the possession of an Approved Road Transporter and the conditions in sub-section (12)
are satisfied, at the earlier of -(A)the time at which the goods are delivered by the Approved Road
Transporter to another person, or(B)15 days after the goods are brought into Arunachal
Pradesh;(ii)if the goods enter Arunachal Pradesh in the possession of a transporter, by air or rail, at
the time that the goods are delivered by the transporter to another person in Arunachal
Pradesh;(iii)if goods, which have been deposited directly into an Approved Warehouse insideArunachal Pradesh Goods Tax Act, 2005

Arunachal Pradesh, are sold in Arunachal Pradesh or are delivered to a person in Arunachal
Pradesh, or are otherwise used or consumed in Arunachal Pradesh, at the time of such sale, or
removal, use or consumption whichever is the earliest; and(iv)in any other case, when the goods are
imported into Arunachal Pradesh;(b)in the case of the import of a motor vehicle [excluding light
motor vehicle including three and two whellers for personal use] [Inserted by 2006 And Act (Act no
11 of 2006) section 2] which is not registered in Arunachal Pradesh under the Motor Vehicles Act,
1988, at the time that the motor vehicle is so registered.(c)[ in the case of liquor (both imported or
locally manufactured) tax shall be levied at single point i.e., first point.] [Inserted by 2007 and Act
(Act no 13 of 2007) section 2](6)Manner of payment of tax. Tax shall be paid either:(a)in the
manner specified in section 38; or(b)to an authorised officer at a check-post established under
section 102.(7)Continuation of liability: Every dealer who has become liable to pay tax under this
Act on sales of goods shall continue to be so liable unless his taxable turnover during the prior
twelve months (and such further period as may be prescribed) has remained below the taxable
quantum and on the expiry of such further period his liability to pay tax shall cease.Any dealer
whose liability to pay tax under this Act ceases for any other reason may apply for earlier the
cancellation of his registration, and on such cancellation, his liability to pay tax shall cease.Provided
that a dealer shall remain liable to pay tax until the date on which his registration is
cancelled.(8)Re-commencement of liability : Every dealer whose liability to pay tax under this Act
has ceased or whose registration has been cancelled, shall, if his turnover calculated from the
commencement of any year, including the year in which the registration has been cancelled, again
exceeds the taxable quantum on any day within such year be liable to pay such tax on and from the
date on which his turnover again exceeds the taxable quantum, on all sales effected by him on and
after that day.(9)Where it is found that any person registered as a dealer ought not to have been so
registered, then notwithstanding anything contained in this Act, such person shall be liable to pay
tax for the period during which he was registered.(10)For the purposes of this section, where goods
are:(a)imported into Arunachal Pradesh;(b)deposited directly into an Approved Warehouse inside
Arunachal Pradesh; and(c)the conditions in section 26(6) are satisfied;the goods shall be deemed
not to be for consumption, use or sale in Arunachal Pradesh.(11)Payment of tax by transporters or
agents: Any tax which has not been paid by an importer may be paid by a transporter or other agent
on the importer's behalf and where a transporter or agent has made such a payment:(a)it shall be
treated for the purposes of this Act as a payment of tax made by the importer, and(b)is thereupon a
debt owed by the importer to the transporter or agent.(12)For the purposes of sub-section (5), the
conditions with which an Approved Road Transporter must comply are:(a)the person must be an
Approved Road Transporter at the time that the goods are imported into Arunachal Pradesh and
must carry and produce on demand evidence of this status;(b)the Approved Road Transporter must
hold and produce on demand documents in the prescribed form which describe in detail the goods,
the value of the goods and the identity of the recipient in Arunachal Pradesh; and(c)either the goods
must be for delivery to a registered dealer in Arunachal Pradesh or the Approved Road Transporter
is a registered dealer.(13)Presumption of ownership or importer. If any person who transports goods
or holds goods in custody for delivery to or on behalf of any person, on being required by the
Commissioner so to do, fails -(a)to furnish any information in his possession in respect of the goods;
or(b)fails to permit inspection thereof;then without prejudice to any other action which may be
taken against such person, a presumption may be raised that the goods in respect of which he has
failed to furnish information or permit inspection,(i)were imported by him on his own behalf;Arunachal Pradesh Goods Tax Act, 2005

or(ii)are owned by him and are held by him for sale in Arunachal Pradesh;and the provisions of this
Act shall apply accordingly.
4. Rates of tax.
(1)The rates of tax payable under the Act shall be -(a)in respect of goods specified in the Second
Schedule, at the rate of one paise in the rupee;(b)in respect of goods specified in the Third Schedule,
at the rate of four paise in the rupee;(c)in respect of goods specified in the Fourth Schedule, at the
rate of twenty paise in the rupee;(d)in the case of [Works Contract, Leases and] [Inserted by Act No.
4 of 2010, dated 20.4.2005.] any other goods, at the rate of twelve and half paise in the
rupee;Provided that the rate of tax on packing materials or containers shall be the same as the rate
at which the goods sold are chargeable to tax.(2)The Government may, if he deems it necessary,
reduce the rates of tax as prescribed in subsection (1), by a notification to that effect in the Official
Gazette.
5. Taxable turnover.
(1)For the purposes of this Act, taxable turnover means that part of dealer's turnover arising during
the tax period which remains after deducting therefrom:(a)the turnover of sales not subject to tax
under section 7 of this Act; and(b)the turnover of sales of goods declared exempt under section 6 of
this Act.(c)(2) In the case of turnover arising from the execution of a works contract, the amount
included in taxable turnover is so much of the dealer's turnover from the works contract as
represents the charges towards goods, subject to such conditions as may be prescribed.(d)Provided
that in the cases where the amount of charges towards goods in such contract is not ascertainable
from the terms and conditions of the contract, the amount of such charges shall be calculated as the
sale price stipulated in the contract reduced by the prescribed percentage.
6. Sales exempt from tax.
(1)The sale or import of goods listed in the First Schedule shall be exempt from tax subject to the
conditions and exceptions set out therein.(2)The dealers or class of dealers as may be notified and
specified from time to time in the fifth schedule shall be exempted from payment of tax on all sales
of goods affected by them subject to such condition as may be prescribed.Explanation. - This
exemption does not extend to the import of any goods made by the dealer.(3)Exemption for goods
used exclusively in making non-taxed sales. Where a dealer sells goods that it has used since the
time of purchase exclusively for purposes other than making sales of goods, and has not claimed a
tax credit in respect of those goods under section 9, the sale of those goods shall be exempt from tax.
6A. [ [Added by Act No. 4 of 2010, dated 20.4.2005.]
Subject to such conditions as may be prescribed, the Government may, if it is necessary so to do, in
the public interest, by notification in the Official Gazette, exempt by way of appropriate Schemes or
otherwise, in conformity with the provisions of this Act, any sales or purchases made to or by a classArunachal Pradesh Goods Tax Act, 2005

of dealers or persons specified in the said notification, from payment of the whole or part of any tax
payable under the provisions of this Act and any notification issued from this section shall take
effect from the date of publication of the notification in the Official Gazette or such other earlier or
later date as may be mentioned therein:Provided that, the Government may withdraw such
exemption at any time as it may think fit and proper:Provided further, that when exemption is
granted in the form of industrial incentive, the dealer shall be entitled to retain the part or whole of
tax collected by way of subsidy from the Government subject to maximum permissible monetary
limit and/or time limit whichever is expedient as may be prescribed in the appropriate
scheme:Provided also that the Government may, if it is necessary so to do in the public interest, by
notification in the official Gazette, exempt a part of sale price specified in the said notification from
payment of tax payable under the provisions, of the Act].
7. Certain sales not liable to tax.
(1)Nothing contained in this Act or the rules made thereunder shall be deemed to impose, or
authorise, the imposition of tax on any sale of goods when such sale takes place:(a)in the course of
inter-state trade or commerce; or(b)outside Arunachal Pradesh; or(c)in the course of import of the
goods into or export of the goods out of the territory of India.Explanation 1. - Sections 3, 4 and 5 of
the Central Sales Tax Act, 1956 (74 of 1956) shall apply for determining whether or not a particular
sale takes place in the manner indicated in clause (a), clause (b) and clause (c) of this
section.Explanation 2. - This section does not prohibit the levy of tax on the import of these
goods.(2)For the purposes of sub-section (1), a sale of goods made for foreign currency by a
duty-free store in the arrival or departure hall of the International airport terminal, shall be treated
as a sale made in the course of the export of goods out of the territory of India.
8. Adjustments to tax.
(1)This section shall apply where, in relation to the sale of goods by any dealer -(a)that sale has been
cancelled;(b)the nature of that sale has been fundamentally varied or altered;(c)the previously
agreed consideration for that sale has been altered by agreement with the recipient, whether due to
the offer of a discount or for any other reason;(d)the goods or part of the goods sold have been
returned to the dealer; or(e)the whole or part of the price owed by. the buyer for the purchase of the
goods has been written-off by the dealer as a bad debt;and the dealer has -(i)provided a tax invoice
in relation to that sale and the amount shown therein as tax charged on that sale is not the tax
properly chargeable on that sale; or(ii)furnished a return in relation to a tax period in respect of
which tax on that sale is attributable, and has accounted for an amount of tax on that sale that is not
the amount properly chargeable on that sale.(2)Where a dealer has accounted for an incorrect
amount of tax as contemplated in sub-section (1), that dealer shall make an adjustment in
calculating the tax payable by that dealer in the return for the tax period during which it has become
apparent that the tax is incorrect, and if -(a)the tax payable in relation to that sale exceeds the tax
actually accounted for by the dealer, the amount of that excess shall be deemed to arise in the tax
period in which the adjustment is made, and shall not be attributable to any prior tax period;
or(b)the tax actually accounted for exceeds the tax payable in relation to the sale, the amount of that
deficiency shall be subtracted from the tax payable by the dealer in the tax period in which theArunachal Pradesh Goods Tax Act, 2005

adjustment is made, and shall not be attributable to any prior tax period.(3)Adjustment to tax for
goods used for mixed purposes: Where a dealer sells goods that have been used in part for
making:(a)sales that are subject to tax under this Act or sales that are not liable to tax under section
7; and(b)partly for other purposes, the amount of tax on the sale of the goods shall be the greater
of:(i)A - (A x B / C); or(ii)A - B.Where:A =The tax for which the dealer would be liable in respect of
the sale apart from this section.B =The amount by which the tax credit of the dealer in respect of the
goods was reduced under section 9(3).C =The amount of the tax credit
9. Tax credit.
(1)Entitlement to tax credit. Subject to subsection (2), a dealer who is registered or is required to be
registered shall be entitled to a tax credit on the turnover of purchases arising during the tax period
and for all imports of goods made during the tax period in the course of his activities as a dealer
which are to be used directly or indirectly by him for the purpose of making:(a)sales which are liable
to tax under section 3 of this Act; and(b)sales which are not liable to tax under section
7.Explanation. - Sales which are not liable to tax under section 7 involve exports from Arunachal
Pradesh whether to other States or Union Territories, or to foreign countries.(2)No tax credit shall
be allowed -(a)in the case of the purchase of goods, for goods purchased from a person who is not a
registered dealer;(b)for the purchase or import of non-creditable goods;(c)for the purchase or
import of goods which are to be incorporated into the structure of a building;(d)for goods purchased
from a registered dealer who has elected to use a simplified accounting method; or(e)to the dealers
or class of dealers specified in the Fifth Schedule.(3)Amount of tax credit. The amount of the tax
credit to which a dealer is entitled in respect of the purchase or import of goods and for which a
credit is allowed under sub-section (1) is the amount of input tax arising in the tax period reduced in
the manner described in sub-sections (4) and (6).(4)Where a dealer has purchased or imported
goods and the goods are to be used partly for the purpose of making the sales referred to in
sub-section (1) and partly for other purposes, the amount of the tax credit shall be reduced
proportionately.(5)The method used by a dealer to determine the extent to which the goods are used
in the manner specified in sub-section (4), shall be fair and reasonable in the circumstances. The
Commissioner may:(a)prescribe methods for calculating the amount of tax credit or the amount of
any adjustment or reduction of a tax credit in certain instances; and(b)after giving reasons in
writing, reject the method adopted by the dealer and calculate the amount of tax credit.Explanation.
- A person may object in the manner referred to in section 75 to a decision of the Commissioner to
reject a method of calculating a tax credit.(6)Where-(a)a dealer has purchased or imported goods for
which a tax credit arises under sub-section (1);(b)the goods are to be exported from Arunachal
Pradesh by way of transfer to a -(i)non-resident consignment agent; or(ii)non-resident branch of the
dealer; and(c)the transfer will not be by way of a sale made in Arunachal Pradesh; the amount of the
tax credit shall be reduced by the prescribed percentage.(7)For the removal of doubt, no tax credit
shall be allowed for:(a)purchases of goods from an unregistered dealer;(b)purchases of goods made
in the course of interstate trade and commerce; or(c)purchases or imports of goods which are used
exclusively for the manufacture, processing or packing of goods specified in the First
Schedule.(8)Time for claiming tax credit. The tax credit may be claimed by a dealer only if the dealer
holds a tax invoice at the time that the prescribed return for the tax period is furnished.Arunachal Pradesh Goods Tax Act, 2005

10. Adjustment to tax credit.
(1)Adjustment to tax credit for change of price, etc. Where any purchaser has been issued with a
credit note or debit note in terms of section 52 or if he returns or rejects goods purchased, as a
consequence of which, the tax credit claimed by him in any tax period in respect of which the
purchase of goods relates, becomes short or excess, he shall compensate such short or excess by
adjusting the amount of the tax credit allowed to him in respect of the tax period in which the credit
note or debit note has been issued or goods are returned.(2)Adjustment to tax credit for change of
use, etc. If goods which have been purchased or imported were:(a)intended to be used for the
purposes specified under section 9(1) and are subsequently used, fully or partly, for purposes other
than those specified under the said sub-section, or(b)intended for purposes other than those
specified under section 9(1), and are subsequently used, fully or partly, for the purposes specified in
the said sub-section, or the tax credit claimed in respect of such purchase import shall be reduced or
increased (as the case may be) for the tax period during which the said utilization otherwise has
taken place.(3)Where-(a)goods were purchased or imported by a dealer,(b)the dealer claimed a tax
credit in respect of the goods, and did not reduce the tax credit by the prescribed percentage;
and(c)the goods are exported from Arunachal Pradesh, other than by way of a sale, to a branch of
the registered dealer or to a consignment agent, the dealer shall reduce the amount of tax credit
originally claimed by the prescribed proportion.(4)If goods which have been purchased or imported
by a dealer were -(a)intended to be used for the purposes specified under section 9(1), and are
subsequently incorporated into the structure of a building, the tax credit claimed in respect of such
purchase or import shall be reduced in the tax period during which such incorporation takes place.
11. Net tax.
(1)The net tax payable by a dealer for a tax period shall be determined by the formula:Net Tax = 0 - I
- CWhere:
0.
= the amount of tax payable by the person at the rates stipulated in section 5 in respect of the
taxable turnover arising in the tax period, adjusted to take into account any adjustments to the tax
payable required by section 8.I = the amount of the tax credit arising in the tax period to which the
person is entitled under section 9, adjusted to take into account any adjustments to the tax credit
required by section 10.C= the amount, if any, brought forward from the previous tax period under
sub-section (2).(2)Where the net tax of a dealer calculated under sub-section (1) is a negative value,
the dealer shall be entitled to claim a refund of the amount and the Commissioner shall deal with
the refund claim in the manner described in section 40.Explanation. - The Commissioner shall be
entitled to apply the refund against other amounts owed under this Act and the Central Sales Tax
Act, to withhold the refund in certain cases and to seek security for a cash refund. The dealer may
elect to apply the refund as a tax credit in the next tax period.Arunachal Pradesh Goods Tax Act, 2005

12. Time at which turnover, turnover of purchases and adjustments arise.
(1)Subject to sub-sections (2), (3) and (4), the amount of the turnover and the turnover of purchases
of a dealer which arises during any tax period shall be the amount recorded in the accounts of the
dealer where those accounts are regularly and systematically prepared and maintained, give a true
and fair view of the taxpayer's dealings, and are employed by the dealer in determining the turnover
of the dealer's business for commercial or income tax purposes.(2)The Commissioner may by
notification -(a)permit certain classes of dealer to record turnover based on amounts paid or
received; and(b)require certain classes of dealer to record turnover based on amounts payable or
receivable.(3)Where a dealer wishes to change the method of determining the turnover and turnover
of purchases, he may only make the change with the consent of the Commissioner and on such
terms and conditions as the Commissioner may impose.(4)The Commissioner may by notification
prescribe the time at which a dealer shall treat the -(a)turnover;(b)turnover of purchases;
and(c)adjustment of tax or adjustment to a tax credit; as arising for a class of transaction.
13. Application to sales, purchases and imports.
(1)The tax imposed by section 3 applies to every:(a)sale, including an instalment sale and hire
purchase of goods, made on and after the notified date;(b)sale in the form of the transfer of a right
to use goods, to the extent that the right to use goods is exercised after the notified date;
and(c)import of goods into Arunachal Pradesh made on and after the notified date.(2)Tax credits
arising under section 9 shall be allowed only for -(a)a purchase, including a purchase under an
instalment sale and hire purchase of goods, made on and after the notified date;(b)a purchase
occurring in the form of the acquisition of a right to use goods, to the extent that the right to use
goods is exercised after the notified date; and(c)the import of goods into Arunachal Pradesh made
on and after the notified date.Explanation. - This provision does not prevent the person claiming the
special tax credit allowed under section 15.(4)Where an amount is paid or received prior to the
notified date in respect of a sale or purchase occurring after the notified date, and the person
calculates his turnover or turnover of purchases based on amounts paid and received, the amount
shall be treated as forming part of the person's turnover or turnover of purchases in the tax period in
which the sale occurs.
Chapter III
Special Regimes
14. Priority.
- Where a provision in this Chapter is inconsistent with a provision in Chapter II, the provision in
this Chapter shall, to the extent of the inconsistency, prevail.Arunachal Pradesh Goods Tax Act, 2005

15. Treatment of stock brought forward during transition.
(1)Deemed input credit. Within a period of four months of commencement of this Act, all registered
dealers wishing to claim the credit referred to in sub- section (2), shall furnish to the Commissioner
a statement of their trading stock, raw materials and packaging materials for trading stock (in this
section referred to as "opening stock") which -(a)is held on the date of commencement of this
Act;(b)is in Arunachal Pradesh on the date of commencement of this Act; and(c)was purchased by
the dealer after 1 April 2004; in such form as may be prescribed.(2)if-(a)the dealer has furnished the
statement referred to in sub-section (1);(b)the opening stock has suffered tax under the Arunachal
Pradesh Sales Tax Act 1999 at the point specified by the Government under section 5 of the said Act;
and(c)if the opening stock had been purchased by the dealer after the commencement of this Act
from another registered dealer, the dealer would have been entitled to a tax credit under section
9(1), the amount of tax suffered under the Arunachal Pradesh Sales Tax Act 1999 on such opening
stock, determined in such manner and subject to such conditions and restrictions and up to the
extent as may be prescribed, shall be credited to the registered dealer as if a tax credit under section
9;Provided that no tax credit under this section shall be allowed unless the dealer has In his
possession, invoices issued by a dealer registered under the Arunachal Pradesh Sales Tax Act 1999
in respect of the purchases of the said goods;Provided further that the dealer must claim the entire
amount of credit to which he is entitled in a single statement, which accompanies a return furnished
under this Act.(3)For the avoidance of doubt, no tax credit under sub-section (2) can be
claimed:(a)for finished goods or capital goods;(b)for any goods that were taxable at last point under
the Arunachal Pradesh Sales Tax Act 1999 held at the time of commencement of this Act;(c)in a
statement furnished more than 4 months after the commencement of this Act; or(d)for opening
stock which is held outside Arunachal Pradesh.(4)Audit certificate. Every dealer wishing to claim a
tax credit for opening stock in excess of Rupees one hundred thousand must furnish with the
statement a certificate signed by an Accountant in the prescribed form certifying that the net refund
claim made is true and correct.(5)Tax on transition stock. Notwithstanding section 3, if -(a)a person
was registered as a dealer under the Arunachal Pradesh Sales Tax Act, 1999 (Act 5 of 1999); |(b)the
person is not registered as a dealer under this Act pursuant to section 25, and the person has not
applied to be registered as a dealer within one month of the date of commencement of this Act;
and(c)on the date of commencement of this Act, the dealer held opening stock or finished goods
which had not suffered tax under the Arunachal Pradesh Sales Tax Act 1999; and the person shall be
liable to pay tax under this Act at the rates specified in section 4 on the fair market value of the
opening stock held on the date of commencement of this Act.(6)[ The tax due under sub-section (5)
shall be paid in four equal instalments, alongwith the quarterly returns. The dealers are allowed to
avail credit of tax paid on Opening Stock in the corresponding four quarters.] [Substituted by 2006
and Act (Act no 7 of 2006) section 2]
16. Second-hand goods.
(1)This section applies where -(a)are registered dealer sells second-hand goods;(b)the dealer has
purchased goods from a resident seller who was not registered under this Act;(c)the goods were
purchased either as trading stock for re-sale in an unmodified form, or as raw materials for
incorporation or division into trading stock;(d)the dealer will be liable to tax under section 3 on theArunachal Pradesh Goods Tax Act, 2005

sale of the goods or the goods into which they were incorporated as the case may be;and(e)the dealer
has adequate proof of the amount paid for the goods.(2)Where this section applies, the registered
dealer will be entitled to a tax credit for the purposes of section 9 of the least of -(a)the input tax
borne by the resident seller when he purchased the goods;(b)the tax fraction of the original cost of
the goods to the resident seller;(c)the tax fraction of the fair market value of the goods at the time of
their purchase by the registered dealer; or(d)the tax fraction of the consideration paid by the
registered dealer for the goods.(3)Where the amount paid by the registered dealer for the goods
exceeds Rupees two thousand, the tax credit shall be allowed in the tax period when the goods are
sold by the registered dealer or the goods into which they have been incorporated are sold by the
registered dealer.
17. Simplified accounting methods for retailers.
(1)The regulations may prescribe optional simplified accounting methods for determining the net
tax of prescribed classes of dealers.(2)Where a dealer chooses to use a simplified accounting
method, the dealers net tax shall be the amount determined under the simplified accounting
method instead of the net tax computed under section 11.(3)A dealer may only elect to use a
simplified accounting method if:(a)the dealer sells goods predominantly by retail in Arunachal
Pradesh;(b)the dealer is within the prescribed class of dealers;(c)the dealer's turnover has not
exceeded [Rupees Fifty Lakhs] [Substituted by 2006 and Act (Act no 7 of 2006)section 3] in the
current year and in the two prior years;[Provided that the works contractors shall be allowed to vail
the scheme irrespective of turnover limit] [Substituted by 2006 and Act (Act no 7 of 2006)section
3],and(d)the dealer continues to hold and retain tax invoices and retail invoices for all of its
purchases and imports of goods.
18. Transactions between related parties.
(a)a registered dealer sells or gives goods to a related person;(b)the terms or conditions of the
transaction have been influenced by the relationship; and(c)if the related person had purchased the
goods, the related person would not be entitled to a tax credit for the purchase, or the amount of the
tax credit would be reduced under section 9(3);the transaction shall be deemed to be a sale made by
the registered dealer and the sale price of the goods shall be deemed to be their fair market value.
Chapter IV
Registration, Approvals and Security
19. Mandatory and voluntary registration.
(1)Mandatory registration: Every dealer is required to apply for registration and to be registered
under this Act if:(a)the dealers turnover in the year preceding the commencement of this Act
exceeded the taxable quantum; or(b)the dealers turnover in the current year exceeds the taxable
quantum;Provided that a dealer dealing exclusively in goods mentioned in First Schedule shall not
be required to register.(2)Taxable Quantum: For the purposes of this Act, taxable quantum" of aArunachal Pradesh Goods Tax Act, 2005

dealer is such amount, not exceeding Rupees five lakh, as may be prescribed.Explanation. - For the
purpose of computation of taxable quantum, the turnover of sales effected by a dealer shall be taken
into account irrespective of whether such sales are taxable under this Act or not or occur inside
Arunachal Pradesh.(3)The taxable quantum of a dealer shall not include turnover from: .(a)sales of
capital assets;(b)sales made in the course of winding up the dealers activities; and (c) sales made as
part of the permanent diminution of the dealers activities.(4)Voluntary registration: Any person
who is not required by sub-section (1) to be registered but who:(a)is a dealer; or(b)intends from a
particular date to undertake activities which would make him a dealer, may apply for registration.
20. Registration.
(1)An application for registration shall be in the prescribed form, containing such particulars and
information and accompanied by such fee, security and other documents as may be
prescribed.Explanation. - The Commissioner may specify certain classes of persons who may not be
required to furnish a security.(2)Where -(a)an applicant furnishes a security in the prescribed form
and for the prescribed amount, and |(b)all other forms and evidence required by and prescribed
under this Act are complete and in order, the Commissioner shall register the applicant.(3)Where
the Commissioner has not registered the person within 15 days from the date on which the
application is made, the Commissioner shall after conducting such inquiries as it deems fit, either
-(a)register the person forthwith as a registered dealer; or(b)issue a notice to the applicant clearly
stating the grounds on which his application is proposed to be rejected and permitting him to show
cause in writing, within 15 further days, why his applicant should not be rejected;Provided, where
the Commissioner has not registered the person or issued a notice by the required date, the
applicant shall be deemed to be registered for the purposes of this Act, and the Commissioner shall '
issue a certificate of registration to such person.(4)Where, pursuant to section 20(3)(b), an
applicant furnishes information why the application should not be rejected, the Commissioner may,
either accept the application and register the person, or reject the application for reasons to be
recorded in writing.(5)If the applicant fails to respond to the notice issued under section 20(3)(b)
within the stipulated time, the application for registration shall stand rejected.(6)Where a registered
dealer has furnished a security as a condition of registration, such security Shall be required for the
continuance in effect of registration, unless the otherwise provided by the
Commissioner.Explanation. - A decision of the Commissioner not to register a person may be the
subject of an objection under section 75.
21. Consequences of registration.
(1)This section sets out the tax consequences arising if an unregistered dealer is registered after the
commencement of this Act.(2)If at the time at which the dealer's registration takes effect -(a)the
dealer holds trading stock for the purpose of sale, or for use as raw materials for the production of
trading stock;(b)the dealer has borne input tax on the purchase or import of the trading stock or raw
materials:(c)the dealer furnishes a statement of its trading Stock and raw materials in the prescribed
form to the Commissioner: and(d)the dealer holds adequate proof of the amount of input tax in
respect of the purchases or imports; the dealer shall be entitled to a tax credit for the trading stock
or raw materials held by the dealer on the date that the dealer's registration takes effect.ProvidedArunachal Pradesh Goods Tax Act, 2005

that the dealer must claim the entire amount of tax credit to which he is entitled in a single claim,
which accompanies the first return furnished by the dealer under this Act.Explanation. - This
section applies where goods have borne tax imposed after the commencement of this Act; section 15
deals with goods which have borne sales tax prior to the commencement of this Act.(3)For the
purposes of section 9(3), the amount of the tax credit shall be the least of:(a)the amount of input tax
disclosed in the proof referred to in sub-section (2);(b)the tax fraction of the cost of the goods;(c)the
tax fraction of the fair market value of the goods at the time of registration; or(d)such amount as
may be prescribed.(4)Where the registered dealer accounts for turnover on the basis of amounts
received and amounts paid, he shall exclude from his turnover:(a)any amount received after he is
registered in respect of sales made while he was unregistered; and(b)any amount paid after he is
registered in respect of purchases made while he was unregistered.
22. Amendment of registration.
(1)A registered dealer shall inform the Commissioner in the prescribed manner within one month, if
he:(a)sells or otherwise disposes of his business or any part of his business or any place of business,
or effects or comes to know of any other change in the ownership of the business;(b)discontinues his
business or changes his place of business or warehouse, or opens a new place of business, or closes
the business for a period of more than one month;(c)changes the name, style, constitution or nature
of his business; or (d) enters into partnership or other association in regard to his business or adds,
deletes or changes the particulars of the persons having interest in business; and if any such
registered dealer dies, his legal representative shall in like manner inform the said authority.(2)The
Commissioner may, after considering any information furnished under this Act or otherwise
received and after making such inquiry as he may deem fit, amend from time to time any
registration.(3)An amendment of the registration made under sub- section (1) shall take effect from
the date of contingency which necessitates the amendment whether or not information in that
behalf is furnished within the time prescribed under sub-section (1).(4)Any amendment of a
registration under this section shall be without prejudice to any liability for tax or penalty imposable
or for any prosecution for an offence under this Act.(5)For the removal of doubts it is hereby
declared that where a registered dealer:(a)effects a change to the nature of the goods ordinarily
sold;(b)is affirm and there is a change in the constitution of the firm without dissolution thereof:
or(c)is a trustee of a trust and there is a change in the trustees thereof: or(d)is a Hindu undivided
family and the business of such family is converted into a partnership business with all or any of the
family members as partners thereof: or(e)is a firm or a company or a trust or other organization,
and a change occurs in the management of the organization, then merely by reason of the
circumstances aforesaid,it shall not be necessary for the registered dealer to seek an amendment to
the registration.
23. Cancellation of registration.
(1)Involuntary cancellation : Where -(a)a registered dealer who is required to furnish security under
the provisions of this Act has failed to furnish or maintain such security;(b)a registered dealer has
ceased to carry on any activity which would entitle him to be registered as a dealer under this
Act;(c)an incorporated body is closed down or otherwise ceases to exist;(d)the owner of aArunachal Pradesh Goods Tax Act, 2005

proprietorship business dies leaving no successor to carry on the business;(e)in case of a firm or
association of persons, it is dissolved;(f)registered dealer has ceased to be liable to pay tax under
this Act;(g)a registered dealer knowingly furnishes a return which is misleading or deceptive in a
material particular;(h)a registered dealer has committed one or more offences or contravened the
provisions of this Act and the offence or contravention is, in the opinion of the Commissioner of
sufficient magnitude that it is necessary to do so; or(i)the Commissioner, after conducting proper
inquiries, is of the view that it is necessary to do so, the Commissioner may, after service of a notice
in the prescribed form, cancel the registration of the dealer with effect from the date specified by the
Commissioner in the notice.(2)Mandatory cancellation: Where -(a)a registered dealer has ceased to
Carry on any activity which would entitle him to be registered as a dealer under this Act;(b)an
incorporated body is closed down or otherwise ceases to exist;(c)the owner of a proprietorship
business dies leaving no successor to carry on business;(d)in case of a firm or association of persons,
it is dissolved; or (e) registered dealer has ceased to be liable to pay" tax under this Act; the
registered dealer shall apply for cancellation of his registration to the Commissioner in the manner
and within the time prescribed.(3)On receipt of such application, if the Commissioner is satisfied
that the dealer has ceased to be entitled to be registered, he may cancel the registration.(4)If a
registered dealer ceases to be registered, the Commissioner shall cancel the dealers registration
with effect from a specified date.(5)If a dealers registration which has been cancelled under this
section is reinstated as a result of an appeal or other proceeding under this Act, the registration of
the dealer shall be restored and he shall be liable to pay tax as if his registration had never been
cancelled.(6)If any registered dealer whose registration has been restored under sub-section (5)
satisfies the Commissioner that excess tax has been paid by him during the period his registration
was inoperative which but for the cancellation of his registration he would not have paid, then the
amount of such tax shall be adjusted or refunded in such manner as may be prescribed.(7)Every
registered dealer who applies for cancellation of his registration shall surrender with his application
the certificate of registration granted to him and every registered dealer whose registration is
cancelled otherwise than on the basis of his application shall surrender the certificate of registration
within seven days of the date of communication to him of the date of the cancellation.(9)The
Commissioner shall, at intervals not exceeding three months, publish in the Official Gazette such
particulars as may be prescribed of registered dealers whose registration has been cancelled.(10)The
cancellation of registration shall not affect the liability of any person to pay tax due for any period
and unpaid as on the date of such cancellation or which is assessed thereafter notwithstanding that
he is not otherwise liable to pay tax under this Act.
24. Consequences of de-registration.
(1)This section sets out the tax consequences arising if the registration of a registered dealer is
cancelled.(2)Every person whose registration is cancelled shall pay in respect of all goods held on
the date of cancellation an amount equal to the higher of -(a)the tax that would be payable in respect
of those goods if the goods were sold at their fair market value on that date; or(b)the tax credit
previously claimed in respect of those goods.(3)Where the dealer has accounted for turnover on the
basis of amounts received and amounts paid, he shall include in the turnover of his final
return:(a)any amount not yet received in respect of sales made while he was registered; and(b)any
amount not yet paid in respect of purchases made while he was registered.Arunachal Pradesh Goods Tax Act, 2005

25. Registration during transition.
- Every dealer who is -(a)registered under the Arunachal Pradesh Sales Tax Act 1999 at the time of
commencement of this Act; and(b)whose turnover in the year preceding the commencement of this
Act exceeds the taxable quantum, :is registered under this Act with effect from the notified date.
26. Approved road transporters and approved warehouses.
(1)Approved Road Transporter : Any person may apply to the Commissioner to be an Approved
Road Transporter for the purposes of this Act if:(a)the person carries on a business and the business
is or includes the transportation of goods by road; and(b)the value of goods transported (whether on
his own behalf or on behalf of others) during a year is or is likely to exceed Rupees five lakh.(2)The
approval may be given subject to such conditions as the Commissioner thinks fit.(3)The
Commissioner may for reasons to be given in writing, withdraw or suspend the status of an
Approved Road Transporter or impose conditions upon the continued approval of the
person.(4)Obligations of transporters: If-(a)an Approved Road Transporter brings goods into
Arunachal Pradesh, or any other transporter brings goods into Arunachal Pradesh by air or rail and
tax is payable by the importer on the import of those goods, the Approved Road Transporter or
other transporter must not release the goods into the possession of another person unless it receives
adequate proof:(i)of payment of the tax;(ii)that the goods are to be deposited directly into the
Approved Warehouse; or(iii)that the goods are for delivery to a person outside Arunachal
Pradesh;(b)a transporter (not referred to in paragraph (a) attempts to bring goods into Arunachal
Pradesh on which tax is payable but has not been paid, it shall not bring the goods into Arunachal
Pradesh.(5)Approved warehouses Any person may apply to the Commissioner for permission to
operate an Approved Warehouse, at a site specified in the application, for the purposes of this Act
if:(a)the person carries on business and the business < is or includes the storage of goods; and(b)the
value of goods stored (whether on his own behalf or on behalf of others) during the year is or is
likely to exceed Rupees five lakh. The permission may be given subject to such conditions as the
Commissioner thinks fit.(6)The operator of the Approved Warehouse shall:(a)accept into the
warehouse only goods which have entered Arunachal Pradesh no more than 12 hours before their
deposit into the Warehouse;(b)keep such records as may be prescribed concerning the origin,
nature, value, quantity and ownership of the goods received into the Warehouse;(c)keep such
records as may be prescribed concerning the destination of goods removed from the
Warehouse;(d)not permit goods to remain in the Approved Warehouse for longer than one month;
and(e)observe all other conditions imposed on the operation of an Approved Warehouse that may
be prescribed and are required by the Commissioner under sub-section (5).(7)The Commissioner
may for reasons to be given in writing withdraw or suspend the authority of a person to operate an
Approved Warehouse or impose conditions upon the continued operation of the Approved
Warehouse.(8)Notification of changes of status. A person who is the operator of an Approved
Warehouse or who is an Approved Road Transporter shall inform the Commissioner within one
month, if he:(a)sells or otherwise disposes of his business or any part of his business or any place of
business;(b)discontinues his business or changes his place of business or warehouse, or opens a new
place of business;(c)changes the nature of his business; or(d)enters into partnership or other
association in regard to his business or adds, deletes or changes the particulars of the personsArunachal Pradesh Goods Tax Act, 2005

having interest in business; and if any such person dies, his legal representative shall in like manner
inform the said authority.(9)Mandatory cancellation: Where -(a)a person has ceased to carry on any
activity which would entitle him to be approved as a Road Transporter or be permitted to operate an
Approved Warehouse under this Act;(b)an incorporated body is closed down or otherwise ceases to
exist;(c)the owner of a proprietorship business dies leaving no successor to carry on business:(d)in
case of a firm or association of persons, it is dissolved; or the person shall apply to the
Commissioner for cancellation of his approval or permission in the manner and within the time
prescribed.(10)Where a person who is currently an Approved Road Transporter or who has
permission to operate an Approved Warehouse applies for the termination of that approval or
permission, the Commissioner shall terminate the approval and withdraw the permission subject to
such conditions as he deems fit.
27.
Security from certain class of dealers, transporters, warehouses and other persons(1)The
Commissioner may as a condition of:(a)registering a person as a dealer;(b)approving a person as an
Approved Road Transporter;(c)permitting a person to operate an Approved Warehouse;
or(d)making a refund under section 40; require a person or prescribed class of persons to furnish
security for the proper performance of their responsibilities under this Act in the prescribed
amount, in the prescribed manner and within such time as may be prescribed.(2)Notwithstanding
sub-section (1), the Commissioner may increase, vary, reduce or waive the prescribed amount of the
security, having regard to -(a)the nature and size of the activities of the person;(b)the amount of any
tax, interest or penalty for which the person may be or is likely to become liable at any time under
this Act;(c)the creditworthiness of the person;(d)the nature of the security; and(e)any other matter
which the Commissioner considers relevant.(3)Where the security or additional security furnished
by a person is in the form of a surety bond and the surety dies or becomes insolvent, the person shall
within one month of the occurrence of such event, inform the authority granting the Commissioner
and shall within three months of such occurrence, execute a fresh surety bond.(4)Where the surety
bond has been executed by another registered dealer and the dealers registration is either
cancelled or he has closed down his business, the person shall furnish a fresh security as may be
prescribed or in the manner as stated in sub-section (3).(5)The Commissioner may, for good and
sufficient cause, order the forfeiture of the whole or any part of the security furnished by a
person.(6)Where the security furnished by any person is forfeited in whole or is rendered
insufficient, he shall furnish a fresh security of the requisite amount or, as the case may be, shall
make up the deficiency in such manner and within such period as may be
specified.[Exceptions:-(a)The Government Departments, CSD Canteens of Military and Para
Military forces and 100% Government owned Corporations, Societies and autonomous bodies are
exempted from furnishing of security.(b)The dealers that were registered under Arunachal Pradesh
Sales Tax Act, 1999, whose turnover exceeded Rs. 5.00 lakhs need not furnish additional security.]
Chapter V
ReturnsArunachal Pradesh Goods Tax Act, 2005

28. Periodical payment of tax and furnishing of returns.
(1)Dealers' returns: Every dealer who is liable to pay tax under this Act shall furnish Commissioner
with such returns for each tax period, by such dates as may be prescribed and in the prescribed
form.(2)importers returns: Every importer shall furnish the Commissioner with such returns for
each import liable to tax under section 3 by such dates as may be prescribed and in the prescribed
form.(3)Exception returns : Every transporter, importer, operator of an Approved Warehouse or
other person who is liable to pay a penalty under section 26 shall furnish the Commissioner with a
return in the prescribed form within 7 days of the occurrence of the event triggering the liability to
pay the penalty.
29. Power to require other returns.
- In addition to the returns specified in section 28 of this Act, the Commissioner may require any
person, whether a registered dealer or not, to furnish (whether on that person's own behalf or as an
agent or trustee) him with such other returns in the prescribed form as, and when, the
Commissioner requires.
30. Correction of deficiencies.
(1)If, within 4 years of the making of an assessment, any person discovers a mistake or error in any
return furnished by him under this Act, and he has a result of the mistake or error paid less tax than
was due under the Act, he shall, within one month after the discovery furnish a revised return and
pay the tax owed and interest thereon.(2)If, within 4 years of the making of an assessment, any
person discovers a mistake or error in any return furnished by him under this Act, and he has a
result of the mistake or error paid more tax than was due under the Act, he may lodge an objection
against the assessment in the manner and subject to the conditions stipulated in section 75.
31. Signing returns.
(1)Every return under this Chapter shall be signed and verified -(a)in the case of an individual, by
the individual himself, and where the individual is absent from India either by the individual or by
some person duly authorised by him in this behalf and where the individual is mentally
incapacitated from attending to his affairs, by his guardian or by any other person competent to act
on this behalf;(b)in the case of a Hindu undivided family, by a Karta and where the Karta is absent
from India or is mentally incapacitated from attending to his affairs, by any other adult member of
such family;(c)in the case of a company or local authority, by the principal officer thereof ;(d)in the
case of a firm, by any partner there of not being a minor;(e)in the case of any other association, by
any member of the association or persons; and(f)in the case of a trust, by the trustee or any trustee;
add(g)in the case of any person, by some person competent to act on his behalf.(2)For the purposes
of sub-section (1) the expression "principal office' shall have the meaning assigned to it under
section 2(35) of the income Tax Act, 1961 (5 of 1961).(3)For the purposes of this Act, any return
signed by a person who is not authorized under sub-section (1) shall be treated as if no return hasArunachal Pradesh Goods Tax Act, 2005

been furnished.
Chapter VI
Assessment and Payment Of Tax, Interest And Penalties And
Making Refunds
32. Assessment of tax, interest or penalty No claim may be made by the
Commissioner for the payment by a person of an amount of tax, interest or
penalty or other amount in the nature of tax, interest or penalty due under
this Act except by the making of an assessment for the amount.
33. Self assessment.
(1)Where a return is furnished by a person as required under sections 28 or 29 which contains the
prescribed information and complies with the requirements of this Act and the rules -(a)the
Commissioner is taken to have made, on the day on which the return is furnished, an assessment of
the tax payable of the amount specified in the return;(b)the return is deemed to be a notice of the
assessment and to be under the hand of the Commissioner; and(c)the notice referred to in
paragraph (b) is deemed to have been served on the person on the day on which the Commissioner
is deemed to have made the assessment.(2)No assessment shall arise under sub-section (1), if the
Commissioner has already made an assessment of tax in respect of the same tax period under
another section of this Act.
34. Commissioner assessment of tax payable.
(1)if any person -(a)has not furnished returns required under this Act by the prescribed date;(b)has
furnished incomplete or incorrect returns; or(c)has furnished a return which does not comply with
the requirements of this Act;Or for any other reason the Commissioner is not satisfied with the
return furnished by a person, the Commissioner may assess or re-assess to the best of his judgment
-(a)the amount of net tax due for a tax period; and(b)the amount of tax due for the import of
goods.(2)Where the Commissioner has made an assessment under this section, the Commissioner
shall forthwith serve on that person a notice of assessment of the amount of any additional tax due
for that tax period nor n respect of the import of any goods.(3)Where the Commissioner has made
an assessment under this section and further tax is assessed as owed, the amount of further tax
assessed b due and payable on the same date as the date on which -(a)the net tax for the tax period
was due; and(b)the amount of tax in respect of the import of the goods was due.Explanation. - This
section ensures that interest accrues on the unpaid amount from the time when the deficiency arose,
rather than the date of making the assessment or re-assessment.Arunachal Pradesh Goods Tax Act, 2005

35. Assessment of penalty.
(1)Where the Commissioner has reason to believe that a liability to pay an administrative penalty
under this Act has arisen, the Commissioner shall make and serve on the person an assessment of
the penalty that is due under this Act.(2)The amount of any penalty assessed under this section is
due and payable on the date on which the notice of assessment is served by the
Commissioner.(3)Any assessment made under this section shall be without prejudice to prosecution
for any offence under this Act.
36. Limitation on assessment and reassessment.
- (l) Unless the Commissioner has reason to believe that tax was not paid by reason of fraud or
evasion on the part of the person, no assessment or re-assessment shall be made by the
Commissioner after the expiry of four years from -(a)the date that the person furnished a return
under section 28; or(b)the date on which the Commissioner made an assessment of tax for the tax
period or in respect of the import of goods, whichever is the earlier.(2)Notwithstanding sub-section
(1 ), the Commissioner may make an assessment of tax within one year after the date of any decision
of the Appellate Tribunal or court where the assessment is required to be made in consequence of,
or to give effect to, a decision of the Appellate Tribunal or court which requires the re-assessment of
the person.
37. Delay to collection of assessed tax and penalties.
(1)Subject to sub-sections (2) and (4), where an amount of tax or penalty has been assessed under
sections 34 or 35, the Commissioner may not proceed to enforce payment of the amount assessed
until one month after the date of service of the notice of assessment.(2)Where a person has made an
objection to an assessment or part of an assessment in the manner provided in section 75, the
Commissioner may not enforce the payment of any amount in dispute under that assessment until
the objection is resolved by the Commissioner.(3)Nothing in this section shall stay any proceedings
by the Commissioner or before a court for the recovery of -(a)any amounts due under this Act that
are not the subject of a dispute before the Commissioner; or(b)any amounts due under this Act
where the person has made an appeal to the Appellate Tribunal.(5)Notwithstanding sub-section (1),
where an amount of tax or penalty has been assessed by the Commissioner and the Commissioner is
of the opinion that there is a real likelihood that it may not be possible to recover the amount
assessed if collection is delayed, the Commissioner may specify a date in the notice of assessment as
the date on which collection of the amounts due and payable may commence which is earlier than
one month after the date of service of the notice of assessment.
38. Manner of payment of tax, penalties and interest.
- Every person liable to pay tax, interest, a penalty or any other amount under this Act shall pay the
amount to the Government Treasury of Arunachal Pradesh at a branch in Arunachal Pradesh of the
Reserve Bank of India, a branch in Arunachal Pradesh of a bank prescribed under the rules, at aArunachal Pradesh Goods Tax Act, 2005

border check-post set up under the Act, or at such other place as may be prescribed.
39. Order of application of payments.
- Where a person owes to the Commissioner tax, interest, or penalty and the person pays to the
Commissioner or the Commissioner recovers some but not all of the amounts owed by the person,
the amounts shall be treated as reducing the person's obligations to pay
-(a)interest;(b)penalty;(c)tax owed under this Act;(d)interest, penalty and tax owed under the
Central Sales Tax Act, 1956 (74 of 1956) ;in that order.
40. Refunds.
(1)Subject to the other provisions of this section and the rules, the Commissioner shall refund to a
person the amount of tax, penalty and interest, if any, paid by such person in excess of the amount
due from him.(2)Before making any refund, the Commissioner shall first apply such excess towards
the recovery of any other amount due under this Act or under the Central Sales Tax Act, 1956 (74 of
1956).(3)Subject to sub-section (4), any amount remaining after the application referred to in
sub-section (2) shall be at the election of the dealer, either -(a)refunded to the person within one
month after the date on which the return was furnished or claim was made for the refund;
or(b)carried forward to the next tax period as a tax credit in that period.(4)Where the Commissioner
has issued a notice to the person under section 59 advising him that an audit, investigation or
inquiry into his affairs will bounder taken, the amount must be carried forward to the next tax
period as a tax credit in that period.(5)The Commissioner may, as a condition of the payment of a
refund, demand security from the person pursuant to the powers conferred in section
27.(6)Notwithstanding anything contained in this section, where -(a)a registered dealer has sold
goods to an unregistered person; and(b)the price charged for the goods includes an amount of tax
payable under this Act;(c)the dealer is seeking the refund of this amount or to apply this amount
under sub-section (3)(b); no amount shall be refunded to the dealer or may be applied by the dealer
under sub-section (3Xb) unless the Commissioner is satisfied that the dealer has 'refunded the
amount to the purchaser.(7)For the avoidance of doubt, where -(a)a registered dealer has sold goods
to another registered dealer;or(b)the price charged for the goods is expressed not to include an
amount of tax payable under this Act; the amount may be refunded to the seller or may be applied
by the dealer under sub-section (3)(b) without the dealer being required to refund an amount to the
purchaser.Explanation. - Where the goods have been sold to another registered dealer, the
Commissioner may reassess the buyer to deny the amount of the excess tax credit claimed,
consequent upon a refund of tax made to a seller. Where the seller has not sought to pass on the tax
to the buyer, a refund may be made.
41. Power to withhold refund in certain cases.
(1)Where any proceeding under this Act is pending which would, if successful entitle the person to a
refund, and the Commissioner is of the opinion that payment of such refund is likely to adversely
affect the revenue and that it may not be possible to recover the amount later the Commissioner
may withhold the refund until the proceedings or the audit have been concluded.(2)Where a refundArunachal Pradesh Goods Tax Act, 2005

is withheld under sub-section (1), the person shall be entitled to interest as provided under
sub-section (1) of section 44 it as a result of the appeal or further proceeding, or any other
proceeding he becomes entitled to the refund.
42. Collection of tax only by registered dealers.
(1)No person who is not a registered dealer shall collect in respect of any sale of goods by him in
Arunachal Pradesh any amount by way of tax under this Act and no registered dealer shall make any
such collection except in accordance with this Act and the rules made there under and at the rates
specified under this Act.(2)Tax collected by a person who is not a registered dealer shall not be
refunded and shall stand forfeited.
43. Refund of tax for embassies, officials, international and public
organizations.
(1)The bodies to be listed in the Sixth Schedule shall be entitled to claim a refund of input tax on
goods purchased in Arunachal Pradesh or imported into Arunachal Pradesh, subject to such
restrictions and conditions as may be prescribed.(2)Any person entitled to a refund under
sub-section (1) may apply to the Commissioner in the manner and within the time prescribed.
44. Interest.
(1)A person entitled to a refund under this Act, shall be entitled to receive, in addition to the refund,
simple interest at a rate not less than 6 per cent per annum and not exceeding 12 per cent per
annum, as may be notified from time to time, computed ort a daily basis from the later of -(a)the
date that the refund was due to be paid to the person; or(b)the date that the overpaid amount was
paid by the person, until the date on which the refund is given. The interest shall be calculated on
the amount of refund due after deducting there from any tax, interest, penalty or any other dues
under this Act or under the Central Sales Tax Act, 1956 (74 of 1956). If, the amount of such refund is
enhanced or reduced, as the case may be, such interest shall be enhanced or reduced
accordingly.Explanation. - If the delay in granting the refund is attributable to the said person,
whether wholly or in part, the period of the delay attributable to him shall be excluded from the
period for which the interest is payable.(2)When a person is in default in making the payment of any
tax, penalty or other amount due under this Act, he shall in addition to the amount assessed, be
liable to pay simple interest on such amount at a rate not less than 12 per cent per annum and not
exceeding 24 per cent per annum, as may be notified from time to time, computed on a daily basis,
from the date of such default for so long as the continues to make default in the payment of the said
amount.(3)Where the amount of tax including any penalty due is wholly reduced, the amount of
interest, if any, paid shall be refunded, or if such amount is varied, the interest due shall be
calculated accordingly.(4)Where the collection of any amount is stayed by the order of the Appellate
Tribunal or any court and or authority and the order is subsequently vacated, interest shall be
payable for any period during which such order remained in operation.(5)The interest payable by a
person under this Act may be collected as tax due under this Act and shall be due and payable onceArunachal Pradesh Goods Tax Act, 2005

the obligation to pay interest has arisen.
Chapter VII
Recovery Of Tax, Interest and Penalties
45. Recovery of tax.
(1)The amount of any tax, interest, penalty or other amount due under this Act shall be paid by the
person liable therefore in the manner prescribed in section 38 and a notice of assessment served on
the person for such an amount shall constitute a final demand for payment of the amount stated in
the assessment by the time stipulated in the assessment.(2)Any amount of a tax, interest or penalty,
composition money or other amount due under this Act which remains unpaid, shall be recoverable
as arrears of land revenue.(3)Where security, other than in the form of surety bond, has been
furnished under the Act the Commissioner may, for reasons to be recorded in writing, recover any
amount of tax, interest, penalty, composition money or other amount due or part thereof by
ordering the forfeiture of the whole or any part of the security.(4)Where any security tendered for
the purposes of this Act is to be sold, it shall be sold in the manner stipulated in section 64.
46. Continuation of certain recovery proceedings.
- Where an assessment or notice of demand in respect of any tax, penalty or other amount payable
under this Act (hereinafter in this section referred to as "government dues") is served upon any
person and any objection or appeal is initiated by the person against the assessment or demand for
such government dues then -(a)if the objection or appeal is disallowed in whole or in part, any
recovery proceedings taken for the recovery of such government dues before the making of the
objection or appeal, may, without the service of any fresh assessment or notice of demand, be
continued from the stage at which such recovery proceedings stood immediately before the person
made the objection or appeal; and(b)where such government dues are reduced in any objection or
appeal-(i)it shall not be necessary for the Commissioner to serve upon the person a fresh assessment
or notice of demand; and(ii)the Commissioner shall give intimation of such reduction to him and to
the person with whom recovery proceedings are pending.
47. Special mode of recovery.
(1)Notwithstanding anything contained in any law or contract to the contrary, the Commissioner
may, at any time or from time to time, by notice in writing, a copy of which shall be forwarded to the
person at his last known address, require,(a)any person from whom any amount of money is due, or
may become due, to the person (in this section called "the taxpayer") liable to pay tax, interest or
penalties under this Act on whom notice has been served under section 45(1), or(b)any person who
holds or may subsequently hold money for or on account of the taxpayer, to pay to the
Commissioner, either forthwith upon the money becoming due or being held or within the time
specified in the first mentioned notice (but not before the money becomes due or is held as
aforesaid) so much of the money as is sufficient to pay the amount due by the taxpayer in respect ofArunachal Pradesh Goods Tax Act, 2005

the arrears of tax, interest and penalty under this Act, or the whole of the money when it is equal to
or less than that amount.Explanation. - For the purposes of this sub-section, the amount of money
due to a taxpayer from, or money held for or on account of a taxpayer by any person, shall be
calculated by the Commissioner after deducting there from such claims, if any, lawfully subsisting,
as may have fallen due for payment by such taxpayer to such person.(2)The Commissioner may
amend or revoke any such notice or extend the time for making any payment in pursuance of the
notice.(3)Any person making any payment in compliance with a notice under this section shall be
deemed to have made the payment under the authority of the taxpayer, and the receipt thereof by
the Commissioner shall constitute a good and sufficient discharge of the liability of such person to
the extent of the amount specified in the receipt.(4)Any person discharging any liability to the
taxpayer after receipt of the notice referred to in this section, shall be personally liable to the
Commissioner to the extent of the liability discharged or to the extent of the liability of the dealer for
tax and penalty, whichever is less.(5)Where a person to whom a notice under this section is sent,
proves to the satisfaction of the Commissioner that the sum demanded or any part thereof is not due
to the taxpayer or that he does not hold any money for or on account of the taxpayer, then, nothing
contained in this section shall be deemed to require such person to pay any such sum or part
thereof, as the case may be, to the Commissioner.(6)Any amount of money which the aforesaid
person is required to pay to the Commissioner, or for which he is personally liable to the
Commissioner under this section shall, if it remains unpaid, be recoverable as if arrears of land
revenue.(7)The Commissioner may apply to the court in whose custody there is money belonging to
the taxpayer for payment to him of the entire amount of such money or if it is more than the tax,
interest and penalty, if any, due, an amount sufficient to discharge such tax and the penalty.
47A. [ [Inserted by 2007 And Act (Act no 3 of 2007)section 3.]
(1)(a)Every person other than an individual, a Hindu Undivided Family, a firm or a company not
under the control of the Government, responsible for making any payment of discharging any
liability on account of any amount purporting to be full or part payment of sales price or
consideration for the transfer of property in goods (whether as goods or in some other form)
involved in the execution of a works contract shall, deduct at the time of credit to the account of or
payment to the dealer (hereinafter referred to as "contractor") of such amount in cash, by cheque, by
adjustment or in any other manner, an amount calculated at the rate of twelve and half paise in the
rupee, from such sum towards part or, as the case may be full satisfaction of the tax payable under
this Act on account of [taxable turnover] [Inserted by 2006 And Act (Act no 7 of 2006) section 4] of
such works contract.(b)Where on an application being made by any contractor in this behalf , the
Prescribed Authority is satisfied that any works contract under reference is separable and involves
only labour and services and accordingly, justifies deduction of tax on a part of the sum payable in
respect of any works contractor, as the case may be, justifies no deduction of tax at all, he shall, after
giving the contractor a reasonable opportunity of being heard, grant him such certificate as may be
appropriate.(c)Any person entering into any contract with any contractor for transfer of property in
goods (whether as goods or in some other form) involved in the execution of works contract shall
furnish within fifteen days from the date of signing of the contract such information as may be
prescribed to the Prescribed Authority under whose jurisdiction the contractor's place of business is
situated. Failure to do so shall entail a penalty not exceeding five hundred rupees per day of defaultArunachal Pradesh Goods Tax Act, 2005

after affording such person a reasonable opportunity of being heard.(2)Every person responsible for
paying sale price or consideration or any amount purporting to be the full or part payment of sale
price or consideration in respect of any sale or supply of goods liable to tax under this Act to the
Government or Corporation, Board, Authority, Undertaking or any other body by whatever name
called, owned, financed or controlled wholly or substantially by the Government, at the time of
credit to the account of or payment to the payee of such amount in cash, by cheque, by adjustment
or in any other manner, whatsoever, shall deduct an amount calculated at the rate as may be
specified in the Schedule from such sum towards full satisfaction of the tax payable under this Act
on account of total sale price of such sale or supply.(3)Notwithstanding anything contained in any
other Law for the time being in fs;6s, every person mentioned in sub-section (1) and sub-section (2)
responsible for paying sale price in respect of any works contract or sale or supply of goods shall not
enter into such transaction unless the contractor, or seller or supplier, as the case may be, produces
an authenticated copy of the certificate of registration under this Act or furnishes an undertaking for
getting himself registered and any such contractor, or seller or supplier who is not so registered
under this Act shall not be paid by the said responsible person any amount in respect of the sale or
supply, before he gets himself registered under this Act and submits an authenticated copy of
certificate of registration.(4)Any tax deducted under this section shall be paid into the Government
account within such time and in such manner accompanied with such documents and statements of
accounts as may be prescribed.(5)The person making any deduction of tax under this section and
paying it into the Government account shall issue to the payee a certificate of tax deduction and
payment in such form and manner and within such time as may be prescribed.(6)Any deduction
made in accordance with the provisions of this section and credited into the Government account,
shall be treated as payment of tax on behalf of the person from whose bills and invoices, the
deduction has been made and credit shall be given to him for the amount of tax finally assessed or
determined as being payable by the concerned person in the assessment for the relevant assessment
year and any amount deducted in excess of the tax so assessed or determined shall be refundable in
accordance with the provisions of this Act.(7)The person responsible for deduction of tax shall
within the prescribed time after the end of each year, file a return in the prescribed form to the
Prescribed Authority.(8)No interest or penalty shall be imposed or no recovery proceedings against
the dealer or payee shall be initiated in respect of deduction of tax under this section.(9)Where the
amount has not been deposited after deduction, such amount and any other sum which may be
payable under this section shall be charged upon, all the assets of the person concerned who made
the deduction or who is liable to pay other amount and shall be recoverable from him as arrears of
land revenue :Provided that no recovery proceedings shall be drawn up by the Prescribed Authority
having jurisdiction over the person concerned without prior approval of the Commissioner.(10)If
any person as referred to in sub-section (1), or sub-section (2) fails to make the deduction or after
making the deduction fails to deposit the amount so deducted into the Government account, the
Prescribed Authority may, after giving such person a reasonable opportunity of being heard, by an
order in writing, direct that such person shall pay, by way of penalty, a sum not exceeding twice the
amount deductible under this section besides tax deductible but not so deducted and, if deducted,
not so deposited into the Government account.]Arunachal Pradesh Goods Tax Act, 2005

48. Transfer of assets during pendency of proceedings void.
- Where, during the pendency of any proceedings under this Act, any person creates a charge on or
parts with the possession by way of sale, mortgage, gift or exchange or any other mode of transfer
whatsoever, any of his assets in favour of any other person for less than full consideration, such
charge or transfer shall be void as against any claim in respect of any tax or any other sum payable
by such person as a result of the completion of the said proceedings.
48A. [ [Added by Act No. 4 of 2010, dated 20.04.2010.]
(1)Subject to other provisions of this Act, an applicant shall be eligible to make an application under
this Act for all his outstanding dues in respect of amounts assessed or levied against him but not in
dispute.(2)(a)An application for the purpose of sub-section (1) of this section shall be made to the
Commissioner in the prescribed form and manner alongwith the receipt copy of the designated bank
Challan for the payable amount according to the prescribed formula in the Schedule attached to the
Act and by the prescribed dateline as may be notified from time to time;(b)A separate application
shall be made by an applicant for the applicable different assessment periods.(3)(a)The
Commissioner shall, ordinarily within sixty days from the date of receipt of an application referred
t6 in sub-section (1) of this section, verify the correctness of the particulars furnished in such
application.(b)Where the Commissioner is satisfied about the correctness of the particulars set forth
in the application made by an applicant, he shall determine, by an order in writing, the amount
payable by the applicant as well as the amount entitled for waiver for the concerned assessment
period under the applicable provision according to the formula specified in the Schedule attached to
this Act.:Provided that while determining the amount payable by the applicant as determined under
this sub-section shall be rounded off to the nearest rupee and for this purpose, where such amount
contains a part of a rupee, then, if such part is fifty paise or more, it shall be rounded off to a rupee,
and if such part is less than fifty paise, it shall be ignored.(c)An applicant shall deposit the balance
payable amount, if any, pursuant to the determination completed by the Commissioner upon his
application made under this Act.(d)In case the outstanding dues of arrear tax, penalty and interest is
under recovery or bakijai proceeding before an authority other than the Commissioner, the later
shall immediately notify such other authority about the status of the arrear certificate initially sent
by him after receipt of a valid application and shall withdraw the same as soon as proceedings under
sub-section (b) of this section are finalized and the payable amount thereon is deposited in full by an
applicant.(4)Consequent upon determination of the amount under sub-section (3) of this section
and payment in full of such determined amount, an applicant shall stand discharged from the
liability in respect of such dues subject to other provision of the Act.(5)The Commissioner may, at
any time Within ninety days from the date of an order passed by him under this Act, rectify any
arithmetical mistake or other mistakes of a factual nature apparent from the record of the
case:Provided that no such rectification adversely affecting the applicant shall be passed without
allowing him a reasonable opportunity of being heard.(6)Where it appears to the Commissioner that
an applicant has obtained the benefit of waiver under this Act by suppressing any material
information or particulars or by furnishing any incorrect or false information or particulars, such
assessing authority may, for reasons to be recorded in writing and after giving the applicant a
reasonable opportunity of being heard, revoke any order passed under sub-section (3) (b).(7)AnyArunachal Pradesh Goods Tax Act, 2005

amount paid by an applicant within the meaning of any proVision under this Act shall not be
refundable under any circumstances.
Schedule
(See Section 48A (3))
Sl.
No.Description of the
outstanding duesAmount to be paid for filing application toavail benefit under
this Act.
(1) (2) (3)
1Amount of total outstanding
dues100% of arrear tax. 25% of the total arrearinterest and 50% of
the total arrear penalty.]
Chapter VIII
Accounts and Records
49. Records and accounts.
(1)Every-(a)dealer;(b)person on whom a notice has been served to furnish returns under section
29;(c)transporter; and(d)operator of a warehouse; shall prepare and retain sufficient records to
allow the Commissioner to readily ascertain the amount of tax due under this Act, and to explain all
transactions, events and other acts engaged in by the person that are relevant for any purpose of this
Act.(2)Not with standing the generality of sub-section(a)every dealer shall preserve a copy of all tax
invoices issued by him;(b)every dealer shall preserve the original of all tax invoices received by him;
and(c)every person who has paid an amount of tax, interest, penalty or other amount owed under
this Act, shall preserve a copy of the challan evidencing the making of the payment.(3)The
Commissioner may prescribe the manner and form in which accounts and records are to be
prepared.(4)If the Commissioner considers that such records are not sufficiently clear and
intelligible to enable him to make a proper check of the obligations required of the person under this
Act, he may require such person by notice in writing to keep such accounts (including records of
purchase and sales) as may be specified therein.(5)The Commissioner may, by notification in the
official Gazette, direct any class of dealers, transporters or operators of warehouses to keep such
accounts (including records of purchases and sales) as may be specified in the notification.(6)Every
person required to prepare or preserve records and accounts shall retain the required records and
accounts for at least five years after the conclusion of the events or transactions which they record.
50. Accounts to be audited in certain cases.
- If in respect of any particular year, the gross turnover of a dealer exceeds Rupees fifty lakh or such
other amount' as may be prescribed, then such dealer shall get his accounts in respect of such yea(
audited by an accountant within six months from the end of that year and obtain within that period
a report of such audit in the prescribed form duly signed and verified by such accountant and setting
forth such particulars as may be prescribed. A true copy of such report shall be furnished by suchArunachal Pradesh Goods Tax Act, 2005

dealer to the Commissioner by the date prescribed.
51. Tax invoices.
(1)Tax invoice for sales.A registered dealer making a sale liable to tax under this Act shall, at the
request of the purchaser, provide the purchaser at the time of sale with a tax invoice containing the
particulars specified in sub-section (2) and retain a copy thereof ;Provided that a tax invoice shall
not be issued by a dealer who -(a)is specified in Fifth Schedule;(b)elects to use a simplified
accounting method; or(c)is making the sale in the course of interstate trade or commerce or
export;Provided further that not more than one tax invoice shall be issued for each sale.Provided
further that if an invoice has been issued under the provisions of Central Excise Tariff Act, 1985 (5 of
1986), it shall be deemed to be a tax invoice if it contains the particulars specified in sub-section
(2).(2)The tax invoice issued under sub-section (1) shall contain the following particulars on the
original as well as copies thereof -(a)the words 'Tax invoice  in a prominent place;(b)the name,
address and registration number of the selling registered dealer;(c)the name and address of the
purchaser;(d)an individual pre-printed number and the date on which the tax invoice is
issued;(e)description, quantity, volume and value of goods sold and services provided and the
amount of tax charged thereon indicated separately;(f)the signature of the selling dealer or his
servant , manager or agent, duly authorized by him; and(g)the name and address of the printer and
first and last serial number of tax invoices printed and supplied by him to the dealer.(2)A tax invoice
in respect of a sale shall be issued in duplicate. The original shall be issued to the purchaser (or the
person taking the delivery as the case may be) and the duplicate shall be retained by the selling
dealer.(3)Tax invoice for imports. in the case of the import of goods, the tax invoice is a receipt in
the prescribed form evidencing payment of the tax due under sub-section (1)(b) of section
3.(4)Retail invoice: Except when a tax invoice is issued under sub-section (1), if a dealer sells any
goods exceeding such amount in value as may be prescribed, in any one transaction to any person,
he shall issue to the purchaser a retail invoice, containing the particulars specified in sub-section (5),
and retain a copy thereof .(5)The retail invoice issued under sub-section (4) shall contain the
following particulars on the original as well as copies thereof *(a)the words 'Retail invoice' or 'Cash
Memorandum' or' Bill' in a prominent place;(b)the name, address and registration number of the
selling dealer;(c)in case the sale is in the course of interstate trade or commerce, the name,
registration number and address of the purchasing dealer and type of statutory form, if any, against
which the sale has been made;(d)an individual serialized number and the date on which the retail
invoice is issued;(e)description, quantity, volume and value of goods sold and services provided,
inclusive of amount of tax charged thereon; and(f)the signature of the selling dealer or his servant,
manager or agent, duly authorized by him.(6)Retail invoice shall be issued in duplicate. The original
shall be issued to the purchaser and the copy shall be retained by the selling dealer.(7)The
Commissioner may, by notification in the Official Gazette, specify the manner and form in which the
particulars on a tax invoice or retail invoice are to be recorded.(8)If a purchaser claims to have lost
the original tax invoice, the selling dealer may, subject to such conditions and restrictions as may be
prescribed, provide a copy clearly marked as a duplicate.Arunachal Pradesh Goods Tax Act, 2005

52. Credit and debit notes.
- Where a tax invoice has been issued in respect of a sale and -(a)the amount shown as tax in that tax
invoice exceeds the tax payable in respect of the sale, the dealer shall provide the purchaser with a
Credit Note, containing such particulars as may be prescribed; or(b)the tax payable in respect of the
sale exceeds the amount shown as tax on the tax invoice, the dealer shall provide the purchaser with
a Debit Note, containing such particulars as may be prescribed.
Chapter IX
Liability In Special Cases
53. Liability in case of transfer of business.
(1)Where a dealer liable to pay tax under this Act transfers his business in whole or in part, by sale,
gift, lease, leave or license, hire or in any other manner whatsoever, the dealer and the person to
whom the business is so transferred shall jointly and severally be liable to pay the tax (including any
penalty) due from the dealer up to the time of such transfer, whether such tax (including any
penalty) has been assessed before such transfer, but has remained unpaid or is assessed
thereafter.(2)Where the transferee or the lessee of a business referred to in sub-section ('1) carries
on such business either in his own name or in some other name, he shall be liable to pay tax on the
sale of goods effected by him with effect from the date of such transfer and shall, if he is registered
as a dealer, apply within the time specified in section 22for amendment of his registration.
54. Liability in case of company in liquidation.
(1)Every person -(a)who is liquidator of any being wound up, whether under the orders of a court or
otherwise; or(b)who has been appointed the receiver of any assets of a company (hereinafter
referred to as the "liquidator"), shall, within one month after he has become such liquidator, give
notice of his appointment as such to the Commissioner.(2)The Commissioner shall, after making
such inquiries or calling for such information as he may deem fit, notify the liquidator within three
months from the date on which he received notice of the appointment of the liquidator, the amount
which in the opinion of the Commissioner would be sufficient to provide for any tax (including any
penalty) which is then, or is likely thereafter, to become payable by the company.(3)The liquidator
shall not part with any of the assets of the company or the properties in his hand until he has been
notified by the Commissioner under sub-section (2) and on being so notified, the liquidator shall set
aside an amount equal to the amount notified and, until he so sets aside such amount, he shall not
part with any of the assets of the company or the properties in his hand.Provided that nothing
contained in this sub-section shall debar the liquidator from parting with such assets or properties
in compliance with any order of a court or for the purpose of the payment of the tax and penalty, if
any, payable by the company under this Act or for making any payment to secured creditors whose
debts are entitled under law to priority of payments over debts due to government on the date of
liquidation or for meeting such costs and expenses of the winding up of the company as are in the
opinion of the Commissioner reasonable.(4)If the liquidator fails to give notice in accordance withArunachal Pradesh Goods Tax Act, 2005

sub-section (1) or fails to set aside the amount as required by sub-section (3) or parts with any assets
of the company or the properties in his hand in contravention of the provisions of that sub-section,
he shall be personally liable for the payment of tax and penalty, if any, which the company would be
liable to pay under this Act.Provided that if the amount of tax and penalty, if any, payable by the
company is notified under sub-section (2) the personal liability of the liquidator under this
subsection shall be to the extent of such amount.(5)Where there is more than one liquidator, the
obligations and liabilities attached to a liquidator under this section shall attach to all the liquidators
jointly and severally.(6)When any private company is wound up and any tax and penalty, if any,
assessed under this Act on the company for any period, whether before or in the course of or after its
liquidation, cannot be recovered, then every person who was a director of the private company at
any time during the period for which the tax is due, shall be jointly and severally liable for the
payment of such tax and penalty, if any, unless he proves to the satisfaction of the Commissioner
that non-recovery cannot be attributed to any gross neglect, misfeasance or breach of duty on his
part in relation to the affairs of the company.(7)The provisions of this section shall have effect
notwithstanding anything to the contrary contained in any other law for the time being in
force.(8)For the purposes of this section, the expressions "company" and "private company" shall
have the meanings respectively assigned to them under clauses (i) and (ii) of section 3(1) of the
Companies Act, 1956 (1 of 1956).
55. Liability of partners of firm to pay tax.
- Notwithstanding any contract to the contrary where any firm is liable to pay any tax (including any
penalty) under this Act, the firm and each of the partners of the firm shall be jointly and severally
liable for such payment. Provided that where any such partner retires from the firm, he shall
intimate the date of his retirement to the Commissioner by a notice to that effect in writing and he
shall be liable to pay tax (including any penalty) remaining unpaid at the time of his retirement and
any tax (including any penalty) due up to the date of his retirement though unassisted on that
date.Provided further that if no such intimation is given within fifteen days from the date of
retirement, the liability of the partner under the first proviso shall continue until the date on which
such intimation is received by the Commissioner.
56. Liability of guardians, trustees etc.
- Where the business in respect of which tax is payable under this Act is carried on by, or is in the
charge of any guardian, trustee or agent of a minor or other incapacitated person on his behalf and
for the benefit of such minor or other incapacitated person, the tax (including any penalty) shall be
levied upon and recoverable from such guardian, trustee or agent, as the case may be, in like manner
and to the same extent as it would be assessed upon and recoverable from any such minor or other
incapacitated person, if he were of full age and of sound mind and if he were conducting the
business himself, and all the provisions of this Act shall, so far as may be, apply accordingly.Arunachal Pradesh Goods Tax Act, 2005

57. Liability of Court of Wards etc.
- Where the estate or any portion of the estate of a dealer owning a business in respect of which tax
is payable under this Act is under the control of the Court of Wards, the Administrator-General, the
Official Trustee or any receiver or manager (including any person, whatever be his designation, who
in fact manages the business) appointed by or under any order of a court, the tax (including any
penalty) shall be levied upon and be recoverable from such Court of Wards, Administrator General,
Official Trustee, receiver or manager in like manner and to the same extent as it would be assessable
upon and be recoverable from the dealer if he were conducting the business himself, and all the
provisions of this Act shall, so far as may be, apply accordingly.
58. Liability in other cases.
(1)Where a dealer is a firm or an association of persons or a Hindu Undivided Family, and such
firm, association or family has discontinued business -(a)the tax payable under this Act, by such
firm, association or family up to the date of such discontinuance may be assessed as if no such
discontinuance had taken place; and(b)every person who was at the time of such discontinuance a
partner of such firm, or a member of such association or family, shall, notwithstanding such
discontinuance be liable, jointly and severally, for the payment of tax assessed and penalty imposed
and payable by such firm, association or family, whether such tax (including any penalty) has been
assessed prior to or after such discontinuance, and subject as aforesaid, the provisions of this Act,
shall, so far as may be, apply as if every such person or partner or member were himself a
dealer.Provided that where the partner of a firm liable to pay such tax (including any penalty) dies,
the provisions of sub-section (4) shall, so far as may be, apply.(2)Where a change has occurred in
the constitution of a firm or an association of partners, the partners or members of the firm or
association as it existed before and as it exists after its reconstitution, shall, without prejudice to the
provisions of section 58, jointly and severally be liable to pay tax (including any penalty) due from
such firm or association for any period before its reconstitution.(3)The provisions of sub-section (1)
shall, so far as may be, apply where the dealer, being affirm or association of persons is dissolved or
where the dealer, being a Hindu undivided family, has effected partition with respect to the business
carried on by it and accordingly references in that sub-section to discontinuance shall be construed
as reference to dissolution or, as the case may be, to partition.(4)Where a dealer liable to pay tax
under this Act dies, then -(a)if a business carried on by the dealer is continued after his death by his
legal representative or any other person, such legal representative or other person, shall be liable to
pay the tax (including any penalty) due from the dealer under this Act, whether such tax (including
any penalty) has been assessed before his death but has remained unpaid, or is assessed after his
death,(b)if the business carried on by the dealer is discontinued after his death, his legal
representative shall be liable to pay out of the estate of the deceased, to the extent the estate is
capable of meeting the charge, the tax (including any penalty) due from the dealer under this Act,
whether such tax (including any penalty) has been assessed before his death but has remained
unpaid, or is assessed after his death, and the provisions of this Act shall, so far as may be, apply to
such legal representative or other person as if he were the dealer himself.Explanation. - For the
purposes of this section "legal representative" has the meaning assigned to it in section 2(11) of the
Code of Civil Procedure, 1908 (5 of 1908).Arunachal Pradesh Goods Tax Act, 2005

Chapter X
Powers Of Investigation And Enforcement
59. Audit.
(1)The Commissioner may serve on any person in the prescribed manner a notice informing him
that an audit of his affairs shall be performed, and, where applicable, that an assessment already
concluded under this Act may be reopened.Explanation. A notice may be served notwithstanding the
fact that the person may already have been assessed under sections 33, 34 or 35.(2)A notice served
under this sub-section may require the person on whom it is served to appear on a date and place
specified therein, which may be at his business premises or at a place specified in the notice, to
either attend and produce or cause to be produced the books of accounts and all evidence on which
the dealer relies in support of his returns (including Tax ln voices, if any), or to produce such
evidence as is specified in the notice.(3)The person on whom a notice is served under sub-section (1)
shall provide all cooperation and reasonable assistance to the Commissioner as may be required to
conduct the proceedings under this section at his business premises.(4)The Commissioner shall,
after considering the return, the evidence furnished with the returns if any, the evidence acquired in
the course of the audit if any or any information otherwise available to him, either -(a)confirm the
assessment under review; or(b)serve a notice of the assessment or reassessment of the amount of
tax, interest and penalty if any pursuant to sections 34 and 35.(5)Any assessment pursuant to an
audit of the person's affairs shall be without prejudice to prosecution for any offence under this Act.
60. Inspection of records.
(1)All records, books of accounts, registers and other documents, maintained by a dealer,
transporter or operator of a warehouse shall at all reasonable times be open to inspection by the
Commissioner.(2)The Commissioner may, for the proper administration of the Act and subject to
such conditions as may be prescribed, require -(a)any dealer; or(b)any other person, including a
banking company, post office, a person who transports goods or holds goods in custody for delivery
to or on behalf of any dealer, who maintains or has in his possession any books of accounts, registers
or documents relating to the business of a dealer, and, in the case of a person which is an
organisation, any officer thereof ; to-(i)produce before him such records, books of account, registers
and other documents;(ii)answer such questions; and(iii)prepare and furnish such additional
information; relating to his activities or to the activities of any other person as the Commissioner
may deem necessary.(3)The Commissioner may require -(a)any documents to be prepared and
provided; and(b)the answer to any question to be verified; in the manner specified by him.(c)The
Commissioner may retain, remove, take copies or extracts, or cause copies or extracts to be made of
the said records, books of account, registers and documents without fee by the person in whose
custody the records, books of account, registers and documents are held.Arunachal Pradesh Goods Tax Act, 2005

61. Power to enter premises and seize records and goods.
(1)All goods kept at any business premises by a dealer, transporter or operator of a warehouse shall
at all reasonable times be open to inspection by the Commissioner.(2)For the proper administration
of the Act and subject to such conditions as may be prescribed, the Commissioner may -(a)enter and
search any business premises;(b)after securing a warrant from a magistrate and in the presence of a
police officer, enter and search any other place or building;(c)break open the lock of any door, box,
locker, safe, almirah or other receptacle for exercising the powers conferred by paragraphs (a) and
(b) where the keys thereof are not readily available;(d)seize and remove any records, books of
account, registers, other documents or goods;(e)place marks of identification on any records, books
of account, registers and other documents or make or cause to be made extracts or copies thereof
without charge;(f)make a note or any inventory of any such money or goods found as a result of such
search or place marks of identification on such goods; and(g)seal the premises including the office,
shop, godown, box, locker, safe, almirah or other receptacle.(3)Where it is not feasible to remove
any records, books of account, registers, other documents or goods, the Commissioner may serve on
the owner and any person who is in immediate possession or control there of, an order that he shall
not remove or part with or other wise deal with them except with the previous permission of the
Commissioner.(4)Where any premises have been sealed under sub-section (2)(g) of this section, or
an order made under sub-section (3), the Commissioner may, on an application made by the owner
or the person in occupation or in charge of such shop, godown, box, locker, safe, almirah or other
receptacle, permit the de-sealing or release thereof (as the case may be) on such terms and
conditions including furnishing of security for such sum in such form and manners as may be
directed.(5)The Commissioner may requisition the services of any police officer or any public
servant, or of both to assist him for all or any of the purposes specified in sub-section (2).(6)Save as
otherwise provided in this section, every search or seizure made under this section shall as far as
possible be carried out in accordance with the provisions of the Code of Criminal Procedure,1973 (2
of 1974) relating to searches or seizures made under that Code.Explanation. - The powers under this
section may be exercised in respect of a dealer or a third party, and may be exercised for the
purposes of undertaking an audit or to assist in recovery.
62. Power to stop, search and detain goods vehicles.
(1)The Commissioner may, at any check-post or barrier or at any other place, require the driver or
person in charge of a goods vehicle to stop the vehicle and keep it stationary so long as may be
required to search the vehicle, examine the contents therein and inspect all records relating to the
goods carried, which are in the possession of such driver or person in charge.(2)The owner or
person in charge of a goods vehicle shall carry with him such records as may be prescribed in respect
of the goods carried in the goods vehicle and produce the same to the Commissioner on
demand.(3)The driver or person in charge of the goods vehicle shall, if required, inform the
Commissioner of -(a)his name and address;(b)the name and address of the owner of the
vehicle;(c)the name and address of the consignor of the goods; and(d)the name and address of the
consignee of the goods; and(4)If on an examination of the contents of a goods vehicle or the
inspection of documents relating to the goods carried, the Commissioner has reason to believe that
the owner or person in charge of such goods vehicle is not carrying the documents as required byArunachal Pradesh Goods Tax Act, 2005

sub-section (2) or is not carrying proper and genuine documents or is attempting to evade payment
of tax due under this Act, he may, for reasons to be recorded in writing, do any one or more of the
following:(a)refuse to allow the goods or the goods vehicle to enter Arunachal Pradesh ;(b)seize the
goods and any documents relating to the goods; and(c)seize the goods vehicle and any documents
relating to the goods vehicle.(5)Where the owner or the person in charge of the goods vehicle
-(a)requests time to adduce evidence of payment of tax in respect of goods to be detained or
impounded; and(b)furnishes security to the satisfaction of the officer in such form and in such
manner as may be prescribed tor the prescribed amount; the goods vehicle, the goods and the
documents so seized may be released.(6)The Commissioner may permit the owner or person in
charge of goods vehicle to remove any goods or goods vehicle seized under sub-section (4) subject to
an undertaking(a)that the goods and goods vehicle shall be kept in the office, godown or other place
within Arunachal Pradesh, belonging to the owner of the goods vehicle and in the custody of such
owner; and(b)that the goods shall not be delivered to the consignor, consignee or any other person
without the approval in writing of the Commissioner, and for this purpose the person in charge of
the goods vehicle shall furnish an authorization from the owner of the goods vehicle authorizing him
to give such undertaking on his behalf.(7)Save as otherwise provided in this section, every search or
seizure made under this section shall as far as possible be carried out in accordance with the
provisions of the Code of Criminal Procedure, 1973 (2 of 1974) relating to searches or seizures made
under that Code.
63. Custody and release of records.
(1)Where the Commissioner seizes any books of accounts or other documents, he shall give the
dealer or the person present on his behalf, as the case may be, a receipt for the same and obtain
acknowledgement of the receipt so given to him.Provided that if the dealer or person from whose
custody the books of accounts or other documents are seized refuses to give an acknowledgement,
the Commissioner may leave the receipt at the premises and record this fact.(2)The Commissioner
shall keep in his custody the books of accounts, registers, other documents seized under section 61
for such period as he considers necessary, and thereafter shall return the same to the dealer or
person from whose custody or power they were seized;Provided that the Commissioner may, before
returning the books of accounts and other documents, require the dealer or the person, as the case
may be, to give a written undertaking that the books of accounts and other documents shall be
presented whenever required by the Commissioner for any proceedings under this Act.Provided
further that the Commissioner shall, when requested, allow the person whose books of accounts,
registers and documents have been seized, reasonable access to the books of accounts, registers and
documents for the purpose of inspection and shall allow the person the opportunity to make copies
thereof at the person's own expense.
64. Custody, return and disposal of goods, goods vehicle and security.
(1)Where the Commissioner seizes any goods or goods vehicle, he shall give the dealer, person in
charge of the goods vehicle or a person present on his behalf , as the case may be, a receipt for the
same and obtain acknowledgement of the receipt so given to him.Provided that if person from
whose custody the goods or goods vehicle are seized refuses to give an acknowledgement, theArunachal Pradesh Goods Tax Act, 2005

Commissioner may leave the receipt in his presence and record this fact.(2)The Commissioner
-(a)shall keep any goods or goods vehicle seized under section 62 in his custody;(b)may retain them
for such time as he considers Reasonable ;and(c)subject to sub-section (3), shall return the goods or
goods vehicle to the dealer or other person from whose custody or power they were
seized.(3)Where(a)the Commissioner has seized any goods;(b)the Commissioner has seized a goods
vehicle; or(c)the Commissioner holds any goods as security for the performance of an obligation
under this Act, the Commissioner may not sooner than one month after service of notice on(i)the
person from whom the goods were seized;(ii)the person from whom the goods vehicle was
seized;(iii)the person for whom the security was given; and(iv)any person against whom the security
is to be enforced; as the case may be, of his intention to sell the goods, direct the auction of such
goods to meet any arrears of tax, interest or penalty owed under this Act. (a) An auction of goods or
a goods vehicle shall be carried out in the manner prescribed for the disposal of goods.
65. Detention of goods pending disclosure.
(1)If any person on being required by the Commissioner, fails to give any information in respect of
any goods in his possession or fails to permit the inspection thereof the Commissioner may seize any
goods in his custody or possession in respect of which the default is committed.(2)The seizure shall
remain in force until it is revoked or the person concerned furnishes the information required or
makes proper arrangements for the inspection of the goods, whichever occurs first.
66. Obligation to provide reasonable assistance.
- Every person shall provide all cooperation and reasonable assistance to the Commissioner as may
be required to conduct the Commissioner's activities under this Act.
Chapter XI
Goods Tax Authorities And Appellate Tribunal
67. Goods Tax Authorities.
(1)For carrying out the purposes of this Act, the Government shall appoint a person to be
Commissioner of Goods Tax.(2)To assist the Commissioner in the administration of this Act -(a)the
Government may appoint as many Additional Commissioners of Goods Tax as the Government
thinks necessary; and(b)the Commissioner may engage and procure the engagement of other
persons to assist him in the performance of his duties; (in this Act referred to as "Goods Tax
authorities").(3)The Commissioner and the Goods Tax authorities shall exercise such powers as may
be conferred, and perform such duties as may be required, by or under this Act.(a)The powers
exercised by the Goods Tax authorities for the making of assessments of tax, the computation and
imposition of penalties, the computation of interest due or owed, the computation of the entitlement
and the amount of any refund, and the conduct of audits or investigations are administrative
powers.Arunachal Pradesh Goods Tax Act, 2005

68. Powers and responsibilities of the Commissioner.
(1)The Commissioner shall have responsibility for the due and proper administration of the Act and
shall have jurisdiction over the whole of Arunachal Pradesh.(2)Subject to sub-section (3), the
Commissioner may from time to time issue such orders, instructions and directions to any Goods
Tax authorities as he thinks fit for the due and proper administration of this Act, and all such
persons engaged in the administration of this Act shall observe and follow such orders, instructions
and directions of the Commissioner.(3)No order, instruction or direction may be issued by the
Commissioner to a person exercising the power to determine -(a)a particular objection made or to
be made under section 75; or(b)a particular question under section 85; so as to require the person to
determine the objection or answer the question of a particular person in a particular
manner.(4)Nothing in sub-section (3) shall prevent the Commissioner issuing general orders,
instructions and directions to any person who determines objections under section 75 or answers
questions under section 85 about the manner of determining classes of objections or answering
classes of questions.
69. Delegation of Commissioner's powers.
(1)Subject to such restrictions and conditions as may be prescribed, the Commissioner may delegate
any of his powers under this Act to any Goods Tax authorities, except the power conferred by this
section.(2)Where the Commissioner delegates his powers under Chapter X, the delegation shall be
in writing and the delegates shall carry and produce on demand evidence in the prescribed form of
the delegation of these powers when exercising the powers.(3)Supervision of delegate. Where the
Commissioner has delegated a power to a person, the Commissioner may supervise, review and
rectify any decision made or action taken by the person.Explanation. - The exercise of this power of
supervision, review or rectification may not lead to the issue of an assessment or re-assessment after
the expiry of the time referred to in section 36.(4)Objections to decisions of the superior authorities.
Notwithstanding any law or doctrine to the contrary, the power delegated by the Commissioner to a
person to determine an objection under section 75 may be exercised by that person, even though the
person determining the objection is lower in rank than the person whose decision is under
objection.
70. Change of an incumbent of an office.
- Whenever in respect of any proceeding under this Act the Commissioner or any Goods Tax
authority is succeeded by another person,(a)no delegation of power made by the former incumbent
shall be revoked by virtue of the succession; and(b)the person so succeeding may continue the
proceeding from the stage at which the proceeding was left by his predecessor.
71. Power of Commissioner to make notifications.
(1)The Commissioner may notify and publish any forms which may be necessary for the reporting of
information to the Goods Tax authorities.(2)Where the Commissioner has notified a form for aArunachal Pradesh Goods Tax Act, 2005

particular purpose, all persons shall be required to report the information using the form.(3)Where
in his opinion it is necessary or convenient to do so, the Commissioner may issue notifications for
carrying out the purposes of this Act;Provided any notification shall not be inconsistent with this Act
or any rules or regulations made pursuant to it.(4)ln particular and without prejudice to the
generality of the foregoing power, a notification issued by the Commissioner may stipulate all or any
of the matters which in the opinion of the Commissioner are necessary or convenient for the proper
administration of this Act.(5)Failure to comply with a requirement in a notification may be
punishable with fine provided that the amount of the fine cannot exceed Rupees five hundred or
such other amount as may be prescribed.(6)Every notification issued by the Commissioner under
this Act shall be published in the Official Gazette, and shall not have any effect prior to such
publication.
72. Persons to be public servants.
- The Commissioner, all Goods Tax authorities and all members of Appellate Tribunal shall be
deemed to be public servants within the meaning of section 21 of Indian Penal Code.
73. immunity from civil suit.
- No suit shall be brought in any civil court against the Government, the Commissioner, any Goods
Tax authorities, or member of the Appellate Tribunal for anything done or intended to be done in
good faith under this Act or the rules made there under.
74. Appellate Tribunal.
(1)The Government shall, as soon as may be convenient after the commencement of this Act,
constitute an Appellate Tribunal consisting of one or more members, as he thinks fit, to exercise the
powers and discharge the functions conferred on the Appellate Tribunal by or under this
Act.Provided that where the Appellate Tribunal consists of one member, that member shall be a
person who has held a civil judicial post for at least ten years or who has been a member of the
Indian Legal Service (not below Grade III) for at least three years or who has been in practice as an
advocate for at least ten years, and where the Appellate Tribunal consists of more than one member,
one such member shall be a person qualified as aforesaid.(2)Where the number of members of the
Appellate Tribunal is more than one, the Government shall appoint one of those members to be the
Chairperson of the Appellate Tribunal.(3)Subject to the provisions of sub-section (1), the
qualifications and other conditions of service of the member or members constituting the Appellate
Tribunal and the period for which such member or members shall hold office, shall be such as may
be determined by the Government.(4)Any vacancy in the membership of the Appellate Tribunal
shall be filled up by the Government as soon as practicable.(5)Where the number of members of the
Appellate Tribunal is more than one and if the members differ in opinion on any point, the point
shall be decided according to the opinion of the majority, if there is a majority, but if the members
are equally divided, the decision of the Chairman of the Appellate Tribunal thereon shall be
final.(6)Subject to the previous sanction of the Government, the Appellate Tribunal shall, for the
purpose of regulating its procedure and disposal of its business, make regulations consistent withArunachal Pradesh Goods Tax Act, 2005

the provisions of this Act and the rules made there-under.(7)The regulations made under
sub-section (6) shall be published in the Official Gazette.(8)The Appellate Tribunal shall, for the
purpose of discharging its functions, have all the powers which are vested in the Commissioner
under section 76 and any proceeding before the Appellate Tribunal shall be deemed to be a judicial
proceeding within the meaning of sections 193 and 228, and for the purposes of section 196 of the
Indian Penal Code, 1860 (45 of 1860) and the Appellate Tribunal shall be deemed to be a Civil Court
for all the purposes of section 195 and Chapter XXVI of the Code of Criminal Procedure, 1973 (2
of1974).
Chapter XII
Objections, Appeals, Disputes And Questions
75. Making an objection to the Commissioner.
(1)Any person who is dissatisfied with -(a)an assessment made by the Commissioner (including an
assessment under section 35); or(b)any other determination, notice, order or decision made by the
Commissioner; (in this section called the "Commissioner's determination") may make an objection
against the Commissioner's determination with the Commissioner.Provided that no objection may
be made against a non appealable order as defined in section 80.Provided further that no objection
against an assessment shall be entertained by the Commissioner unless the objection is
accompanied by satisfactory proof of the payment of any amount of tax, interest or penalty assessed
that is not in dispute.Provided further that only one objection may be made by the person against
any assessment or decision made by the Commissioner.Provided further that in the case of an
objection to an amended assessment, determination, notice, order, or decision, an objection may be
made only to the portion amended.(2)A person who is aggrieved by the failure of the Commissioner
to make a determination, reach a decision, to issue any assessment, order or notice, or to undertake
any other procedure under this Act, within six months after a request in writing was served on the
Commissioner to do so, may make an objection against the Commissioner's failure.(3)An objection
shall be in writing in the prescribed form and shall state fully and in detail the grounds upon which
the objection is made.(4)The objection must be made by the person to the Commissioner -(a)in the
case of an objection made under subsection (1), within two months of the date on which the
Commissioner served or notified the person of the Commissioner's determination; or(b)in the case
of an objection made under subsection (2), no sooner than six months and no later than eight
months after the written request under sub-section (2) was served on the Commissioner;Provided
that where the Commissioner is satisfied that the person was prevented for sufficient cause from
lodging the objection within the time specified, the Commissioner may accept an objection within a
further period of two months.(5)The Commissioner shall conduct its proceedings by an examination
of the Commissioner's determination, the Commissioner's statement of reasons (if any) and the
objection;Provided that where the person aggrieved requests a hearing in person, the person shall
be afforded an opportunity to be heard in person.(6)Where a person has requested a hearing under
sub-section (5)and the person fails to attend the hearing at the time and place stipulated, the
Commissioner shall proceed and determine the objection in the absence of the person.(7)Within
three months after the receipt of the objection, the Commissioner shall either:(a)accept theArunachal Pradesh Goods Tax Act, 2005

objection in whole or in part and take appropriate action to give effect to the acceptance (including
the remission of any penalty assessed either in whole or in part); or(b)refuse the objection or the
remainder of the objection (as the case may be);and in either case, serve on the person objecting a
notice in writing of the decision and the reasons for it, including a statement of the evidence on
which it is based.Provided that where the Commissioner within three months of the making of the
objection notifies the person in writing, the Commissioner may continue to consider the objection
for a further period of two months.Provided also that the person may in writing request the
Commissioner to delay considering the objection for a period of up to three months for the proper
preparation of its position, in which case the period of the adjournment shall not be counted toward
the period by which the Commissioner must reach its decision.(8)Where the Commissioner has not
notified the person of its decision within the time specified under sub-section (7), the person may
serve on the Commissioner a written notice requiring the Commissioner to make a decision within
seven days.(9)If the Commissioner has not made a decision by the end of the period of seven days
after being given the notice referred to in sub-section (B), then, at the end of that period, the
Commissioner shall be deemed to have allowed the objection.(10)Transition. Where on the date of
commencement of this Act a dispute under the Arunachal Pradesh Sales Tax Act, 1999 has been
pending before an appellate authority for more than three years, the dispute shall be disposed of
within a period of two years from the date commencement of this Act.(11)Where the dispute referred
to in sub-section (10) has not been decided within the time required, the dispute shall be deemed to
have been resolved in favour of the dealer.
76. Power of Commissioner and other authorities to take evidence on oath,
etc.
(1)The Commissioner or any person determining objections under section 75,for the purposes of this
Act, have the same powers as are vested in a court under the Code of Civil Procedure 1908 (5 of
1908) when trying a suit, in respect of the following matters,namely -(a)enforcing the attendance of
any person and examining him on oath or affirmation;(b)compelling the production of accounts and
documents; and(c)issuing commissions for the examination of witnesses, and any proceeding under
this Act before the Commissioner or person determining objections under section 75 shall be
deemed to be a judicial proceeding within the meaning of sections 1 93 and 228 and for the purposes
of section 196 of the Indian Penal Code, (45 of 1860).(2)Subject to any rules made in this behalf, the
Commissioner or any person determining objections under section 75 may impound and retain in
its custody, any books of accounts or other documents produced before it in any proceedings under
this Act until such proceedings are concluded ;Provided that the Commissioner or the person
determining an objection under section 75 shall not impound any books of accounts or other
documents without recording in writing his reasons for so doing.
77. Appeals to Appellate Tribunal.
(1)Any person aggrieved by a decision made by the Commissioner under section 75 may appeal to
the Appellate Tribunal against such decision;Provided that no appeal may be made against a
non-appealable order under section 8Explanation. - The Commissioner does not appeal to the
Appellate Tribunal. The Commissioner may make a further assessment of tax where he is of theArunachal Pradesh Goods Tax Act, 2005

opinion that further tax is owed.(2)Subject to the provisions of section 78, no appeal shall be
entertained unless it is made within two months from the date of service of the decision appealed
against.(3)Every appeal made under this section shall be in the prescribed form, verified in the
prescribed manner and shall be accompanied by such fee as may be prescribed.(4)No appeal against
an assessment shall be entertained by the Appellate Tribunal unless the appeal is accompanied by
satisfactory proof of the payment of the amount in dispute and any other amount assessed as due
from the person.Provided that the Appellate Tribunal may, if it thinks fit, for reasons to be recorded
in writing, entertain an appeal against such order without payment of some or all of the amount in
dispute, on the appellant furnishing in the prescribed manner security for such amount as it may
direct.Provided further that no appeal shall be entertained by the Appellate Tribunal unless it is
satisfied that such amount as the appellant admits to be due from him has been paid.(5)ln
proceedings before the Appellate Tribunal -(a)the person aggrieved shall be limited to disputing
only those matters stated in the objection;(b)the person aggrieved shall be limited to arguing only
those grounds stated in the Objection; and(c)the person may adduce evidence not presented to the
Commissioner.(6)The Appellate Tribunal shall-(a)in the case of an assessment, confirm, reduce, or
annul the assessment (including any penalty and interest imposed);(b)in the case of any other
decision of the Commissioner, affirm or reject the decision;or(c)pass such other order for the
determination of the issue as it thinks fit.The Appellate Tribunal shall give reasons in writing for its
decision. Those reasons must include its findings on material questions of fact and the evidence or
other material on which those findings were based.(7)The Appellate Tribunal shall use its best
endeavours to make a final resolution of the matter before it and for this purpose may make a
decision in substitution for the order in dispute, including the exercise or re-exercise of any
discretion or power vested in the Commissioner.(8)The Appellate Tribunal shall not set aside an
assessment and remit the matter to the Commissioner for a further assessment, unless it has first
-(a)advised the aggrieved person of the proposed order;(b)offered the person the opportunity to
adduce such further evidence before it as might assist the Appellate Tribunal to reach a final
determination.(9)Where the Appellate Tribunal sets aside an assessment and remits the matter to
the Commissioner for a further assessment, the Appellate Tribunal shall at the same time order the
Commissioner to refund to the person some or all of the amount in dispute. Where no order is
made, it shall be presumed that the Appellate Tribunal has ordered the refund of the amount in
dispute.(10)Where a person has failed to attend the hearing at the time and place stipulated, the
Appellate Tribunal may adjourn the proceedings, strike out the appeal or proceed to make an order
determining the objection in the absence of the person.(11 ) Save as provided in section 82 and
sub-section(12), an order passed by the Appellate Tribunal on an appeal shall be final.(12)The
Appellate Tribunal may rectify any mistake or error apparent from the record of its proceedings.
78. Extension of period of limitation in certain cases.
(1)The Appellate Tribunal may admit an appeal under section 77 after the period of limitation laid
down in that section, if the appellant satisfies the Appellate Tribunal that he had sufficient cause for
not preferring the appeal within such period.(2)ln computing the period laid down under sections 77
and 82, the provisions of sections 4 and 12 of the Limitation Act, 1963 (36 of 1963), shall, so far as
may be, apply.(3)ln computing the period of limitation prescribed ,), or under any provision of this
Act, or the rules made There under, other than sections 77 or 82,any period during which anyArunachal Pradesh Goods Tax Act, 2005

proceeding is stayed by an order or injunction of any court shall be excluded.
79. Burden of proof.
- The burden of proving any matter in issue in proceedings under section 75, or before the Appellate
Tribunal which touches the liability to pay or any amount under this Act shall lie on the person
alleged to be liable to pay the amount.Explanation. - The burden of proof in criminal prosecutions is
unaffected by this rule.
80. Non-appealable orders.
(1)No objection or appeal shall lie against -(a)a decision of the Commissioner to make an
assessment of tax or penalty;(b)a notice requiring a person to furnish a return;(c)a notice issued
under section 59 of this Act;(d)a decision of the Commissioner to notify any matter;(e)a notice
asking a dealer to show cause as to why he should not be prosecuted for an offence under this
Act;(f)a decision relating the seizure or retention of books of accounts, register and other
documents;(g)a decision sanctioning a prosecution under this Act;(h)an interim decision made in
the course of any proceedings;(i)a decision of the Commissioner touching on the internal
administration of the Goods Tax authorities;(j)a determination or ruling of the Commissioner under
section 85 or section 86; or(k)an assessment issued by the Commissioner to give effect to an order of
The Appellate Tribunal or a court.(2)Except as provided in paragraph (k), nothing in sub-section (1)
shall prevent the person objecting to the amount or the obligation to pay any amount assessed by
the Commissioner.
81. Assessment proceedings etc. not to be invalid on certain grounds.
(1)No assessment including a re-assessment, notice, summons or other proceedings made or issued
or taken or purported to have been made or issued or taken in pursuance of any of the provisions of
this Act or under the earlier law shall be invalid or shall be deemed to be invalid merely by reason of
any mistake, defect or omission in such assessment, notice, summons or other proceedings, if such
assessment, notice, summons or other proceedings are in substance and effect in conformity with or
according to the intent and purposes of this Act or any earlier law.(2)The service of any notice, order
or communication shall not be called in question if the said notice, order or communication, as the
case may be, has already been acted upon by the dealer or person to whom it is issued or which
service has not been called in question at or in the earliest proceedings commenced, continued or
finalized pursuant to such notice, order or communication.(3)No assessment or re-assessment made
under this Act shall be invalid merely on the ground that the action could also have been taken by
any other authority under any other provisions of this Act.
82. Statement of case to the High Court.
(1)Within two months from the date of an order passed by the Appellate Tribunal under sub-section
(6) of section 77, a person aggrieved or the Commissioner may, by application in writing, andArunachal Pradesh Goods Tax Act, 2005

accompanied by such fee as may be prescribed, require the@ to refer to the High Court any question
of law arising out of such order, and, subject to the other provisions contained in this section, the
Appellate Tribunal shall, within four months of the receipt of such application draw up a statement
of the case and refer it to the High Court.Provided that the Appellate Tribunal may, if it is satisfied
that the person or the Commissioner was prevented by sufficient cause from presenting the
application within the period hereinbefore specified, allow it to be presented within a further period
not exceeding one month.(2)If the Appellate Tribunal refuses to state the case which it has been
required to do, on the ground that no question of law arises, the person or the Commissioner, as the
case may be, may, within one month of the communication of such refusal either withdraw his
application (and if he does so, any fee paid shall be refunded), or apply to the High Court against
such refusal.(3)If upon receipt of an application under subsection (2), the High Court is not satisfied
as to the correctness of the refusal of the Appellate Tribunal, it may require the Appellate Tribunal
to state the case and refer it, and on receipt of such requisition, the Appellate Tribunal shall state the
case and refer it accordingly.(4)If the High Court is not satisfied that the statement in a case referred
to it is sufficient to enable it to determine; the question so raised thereby, the court may refer the
case back to the Appellate Tribunal for the purpose of making such additions thereto or alterations
therein as it may direct in that behalf.(5)The High Court upon the hearing of any such case shall
decide the question of law raised thereby, and shall deliver its judgment thereon containing the
grounds in which such decision is founded, and shall send to the Appellate Tribunal a copy of such
judgment under the seal of the court and the signature of the Registrar, and the Appellate Tribunal
shall dispose of the case accordingly.(6)Where a reference is made to the High Court under this
section, the cost (which shall not include the fee referred to in sub-section (1)) shall be in the
discretion of the court.(7)The payment of the amount of tax, interest or penalty, if any, due in
accordance with the order of the Appellate Tribunal in respect of which an application has been
made under sub-section (1) shall not be stayed pending the disposal of such application or any
reference made in consequence thereof but if such amount is reduced as a result of such reference,
the excess tax paid shall be refunded in accordance with the provisions of section 40.
83. Appearance before any authority in proceedings.
(1)Any person, who is entitled or required to attend before any authority in connection with any
proceedings under this Act, may attend -(a)by a person authorised by him in writing in this behalf,
being a relative or a person regularly employed by him; or(b)by a legal practitioner or chartered
accountant who is not disqualified by or under sub-section (2); or(c)by a goods tax practitioner who
possesses the prescribed qualifications and is entered in the list, which the Commissioner shall
maintain in that behalf, and who is not disqualified by or under sub-section (2).(2)The
Commissioner may, for reasons to be recorded in writing, disqualify for a period from appearing
before any such authority, any legal practitioner, chartered accountant or goods tax
practitioner-(a)who has been removed or dismissed from government service; or(b)who being a
goods tax practitioner or chartered accountant is found guilty of misconduct in connection with any
proceedings under this Act by an authority empowered to take disciplinary action against the
members of the profession to which he belongs; or(c)who being a legal practitioner is found guilty of
such misconduct by the Commissioner.(4)Any person who is disqualified under this section may,
within one month of the date of disqualification, appeal to the Government to have theArunachal Pradesh Goods Tax Act, 2005

disqualification cancelled.(5)The decision of the Commissioner shall not take effect until one month
of the making thereof or when an appeal is preferred, until the appeal is decided.(6)The
Commissioner may at any time suo motu or on an application made to him in this behalf, revoke any
decision made against any person under subsection (2) and thereupon such person shall cease to be
disqualified.Explanation. - A decision made by the Commissioner under this section may also be the
subject of an objection under section 75.
84. Bar of suits in civil courts.
- No suit shall be brought in any civil court to set aside or modify any assessment made or any order
passed under this Act or the rules made thereunder.
85. Determination of specific questions.
(1)If any determinable question arises, otherwise than in proceedings before a court, a person may
apply in the prescribed manner to the Commissioner for the determination of that
question.(2)Subject to sub-section (3), an application for the determination of a determinable
question may be made in respect of a proposed transaction, a transaction that is being undertaken,
or a transaction has been concluded.(3)An application for the determination of a determinable
question may not be made after the Commissioner commenced the audit of the person pursuant to
section 59.Explanation. - For the purposes of this sub-section, the Commissioner shall be deemed to
have commenced the audit of a person under section 59 when the Commissioner serves a notice to
this effect.(4)For the purposes of this section, the following shall be determinable
questions:(a)whether any person, society, club or association or any firm or any branch or
department of any firm is or would be a dealer;(b)whether any dealer is or would be required to be
registered under this Act;(c)the amount of the taxable quantum of a dealer for a period;(d)whether a
transaction is or would be a sale, or requires an adjustment to be made under section I arising out of
a sale;(e)whether a transaction is or would be in the nature of works contract, or transfer of right to
use any goods;(f)whether a sale is not liable to tax under section 7;(g)whether a sale is exempt from
tax under section 6;(h)the sale price of a transaction;(i)the proportion of the turnover or turnover of
purchases of a dealer which arises in a tax period, and the time at which an adjustment to tax or tax
credit arises;(j)whether any transaction is or would be the import of goods;(k)the value of any goods
imported into Arunachal Pradesh;(l)the rate of tax that is payable on a sale or import of goods and
the classification of the goods under the Schedules to the Act;(m)whether a transaction is the
purchase of goods, or requires an adjustment to be made under section 10 arising out of a
purchase;(n)the amount of any tax credit to which the dealer is entitled in respect of a purchase or
import of goods;(o)the amount of any tax credit in respect of any used goods purchased by a
dealer;(p)the location of any sale or purchase;(q)the application of h simplified accounting method
in the circumstances of the dealer; or(r)the tax period of a dealer.(5)The Commissioner shall make
the determination within such period as may be prescribed.(6)The Commissioner may -(a)direct
that the determination shall not affect the liability of any person under this Act with respect to any
transaction effected prior to the determination;(b)limit the period for which the determination will
apply;(c)limit the transactions to which the determination will apply; and(d)impose such other
limitations or restrictions on the determination as seem appropriate.(7)If any such question arisesArunachal Pradesh Goods Tax Act, 2005

from any order already passed under this Act or under the Arunachal Pradesh Sales Tax Act, 1999,
(5 of 1999), as then in force in Arunachal Pradesh, no such question shall be entertained for
determination under this section but such question may be raised in an objection or appeal against
such order.(8)A determination made by the Commissioner under this section may not be the subject
of an objection under section 75.Explanation. - A person who is dissatisfied with a determination
has the right to object to an assessment made in consequence of the determination.(9)Where -(a)the
Commissioner has issued to a person a determination in respect of a particular transaction;
and(b)the person implements the transaction in reliance on the determination issued to him under
this section and in the manner described in the application; no assessment may be raised by the
Commissioner against that person which is inconsistent with the determination and no penalty may
be imposed on the person if the determination is later held incorrect.(10)The Commissioner may by
notice served on the person, withdraw or qualify a determination issued under this section but such
withdrawal or qualification shall not affect the entitlement of any person to rely on the
determination with respect to any transaction or action which he has commenced or which he has
completed prior to the withdrawal or qualification.
86. Ruling on general questions.
(1)The Commissioner may by notice in the Official Gazette publish his ruling on the answer to any
question involving the interpretation of this Act or application of this Act to a class of persons or
class of transactions.(2)A ruling issued by the Commissioner under this section may be issued
subject to such restrictions and conditions as the Commissioner may deem fit.(3)The ruling shall be
treated as coming into effect on the date stated in the ruling (which may be a date prior to the
publication of the ruling) or, if no date is stated in the ruling. on the date of publication of the
Official Gazette.(4)Where -(a)the Commissioner has published a ruling in respect of a class of
persons or transactions;(b)a person implements a transaction or undertakes any action in reliance
on the ruling;(c)the ruling has, at the time of implementing the transaction or undertaking the
action, not been withdrawn by the Commissioner; and(d)according to the terms of the ruling, the
ruling purports to applies to the transaction or action undertaken by the person; no assessment may
be raised by the Commissioner against that person which is inconsistent with the ruling and no
penalty may be imposed on the person if the ruling is later held incorrect.Explanation.- A person
may rely on the Commissioner's ruling or on the determination made under section 84.(5)The
Commissioner may by notice published in the Official Gazette withdraw or qualify a ruling already
issued under this section but such withdrawal or qualification shall not affect the entitlement of any
person to rely on the ruling with respect to any transaction or action commenced or completed by
him prior to the withdrawal or qualification.
Chapter XIII
Administrative Penalties and OffencesArunachal Pradesh Goods Tax Act, 2005

87. Administrative penalties.
(1)ln this section "tax deficiency" means the difference between the tax properly payable by the
person in accordance with the provisions of this Act and the amount of tax paid by the person in
respect of a tax period or the import of goods into Arunachal Pradesh.(2)Power to prescribe new
penalty amounts. The Government may from time to time, if he deems it necessary, vary the amount
of any penalty due under this section by a notification to that effect in the Official Gazette.Provided
that any penalty which is increased under this section shall have effect only for offences or failures
occurring after the date of notification.(3)Multiple administrative penalties. Where two or more
administrative penalties arise under this Act in respect of the same conduct of a person, the person
is liable to pay only the greater penalty.Registration(4)Failure to register.Where a person who is
required to be registered under this Act has failed to apply for registration within one month from
the day on which the requirement arose, the person is liable to pay, by way of penalty, 3p amount
equal to Rupees one thousand per day, from the day on which the requirement arose until the
person makes an application for registration in the prescribed form, containing such particulars and
information and accompanied by such fee, security and other documents as may be
prescribed;Provided that the amount of penalty payable under this sub-section shall not exceed
Rupees one lakh.(5)Failure to notify change of registration details.If, a registered dealer fails to
comply with the provisions of sub-section (1) of section 22,The person shall be liable to pay by way
of penalty, a sum of Rupees one hundred per day of default subject to a maximum of Rupees five
thousand.(6)Failure to apply for cancellation of registration. If a registered dealer-(a)fails to comply
with the provisions of sub-section (2) of section 23; or(b)fails to surrender his certificate of
registration as provided in sub-section (7) of section 23; the registered dealer shall be liable to pay
by way of penalty a sum equal to Rupees one hundred for every day of default subject to a maximum
of Rupees five thousand.(7)Falsely represent status. - If any person falsely represents that he is
registered as a dealer under this Act, he shall be liable to a penalty equal to the amount of tax
wrongly collected or Rupees one lakh, whichever is the greater.(8)Failure to comply with
registration requirements. Where a person -(a)has applied for registration under section
19(4);(b)has been registered; and(c)either -(i)has failed to under take activities which would make
the person a dealer within the period specified in his application; or(ii)has failed to comply with any
of the restrictions or conditions subject to which such registration was granted, the person shall be
liable to pay a penalty of Rupees ten thousand.Returns(9)Failure to furnish returns, complete
returns or revised returns. If a person required to furnish a return under Chapter V -(a)fails to
furnish any return by the due date; or(b)fails to furnish with a return any other document that is
required to be furnished with the return; or(c)being required to revise a return already furnished,
fails to furnish the revised return by the due date; the person is liable to pay by way of penalty a sum
of Rupees one hundred per day from the day on which the requirement arose until the failure is
rectified;Provided that the amount of penalty payable under this sub-section shall not exceed
Rupees ten thousand.(10)False, misleading or deceptive returns.Any person who -(a)furnishes a
return under this Act which is false, misleading or deceptive in a material particular; or(b)omits
from a return furnished under this Act any matter or thing without which the return is false,
misleading or deceptive in a material particular; shall be liable to pay by way of penalty a sum of
Rupees one lakh or the amount of the tax deficiency, whichever is the greater.Payment of incorrect
amount of tax(11)Transition stock credit. Any dealer who -(a)has claimed tax credit under section 15Arunachal Pradesh Goods Tax Act, 2005

to which he is not entitled; or(b)has claimed a greater tax credit under section 15 than is allowed; is
liable to pay by way of penalty an amount equal to the amount of tax credit so claimed or Rupees ten
thousand, whichever is the greater.(12)Failure to pay proper amount of tax. Where a tax deficiency
arises in relation to a person, the person shall be liable to pay by way of penalty:(a)100% of the
deficiency, where the deficiency resulted from the intentional disregard of the law by the
person;(b)50% of the deficiency, where the deficiency resulted from careless disregard of the law by
the person;(c)10% of the deficiency, where the deficiency resulted from an honest and reasonable
mistake made by the person;(d)20% of the deficiency, in any other case. Records, accounts and
invoices(13)Failure to prepare or retain required records and accounts. Where a person is required
under this Act to -(a)prepare records or accounts;(b)prepare records or accounts in a prescribed
manner;(c)retain records or accounts; or and the person -(i)fails to prepare the required records and
accounts;(ii)fails to prepare records and accounts in the prescribed manner; or(iii)fails to retain the
records and accounts for the prescribed period; the person is liable to pay by way of penalty a sum of
Rupees fifty thousand or twenty per cent of the tax deficiency, whichever is the greater.(14)Failure to
produce requested information. Any person who fails to comply with a requirement made of the
person by the Commissioner under section 60(2)or 60(3) shall be liable to pay by way of penalty
Rupees fifty thousand.(15)Preparing accounts that are false, misleading or deceptive. Where a
person who is required to prepare records and accounts under this Act r prepares records and
accounts in a manner that is false, misleading or deceptive, the person is liable to pay by way of
penalty a sum of Rupees one lakh or the amount of the tax deficiency whichever is the
greater.(16)Tax invoices. Where a person -(a)has issued a tax invoice or retail invoice with
incomplete or incorrect particulars; or(b)having issued a tax invoice or retail invoice, has failed to
account correctly it in his books of account; the person shall be liable to pay by way of penalty an
amount of Rupees fifty thousand or twenty per cent of the tax deficiency, whichever is the
greater.(17)Unauthorised issue of tax invoice. Where a person who is not authorised under this Act
to issue a tax invoice has issued a tax invoice for a sale the person shall be liable to pay by way of
penalty an amount of Rupees one lakh or the tax deficiency, whichever is the greater.(18)Failure to
have accounts audited. If any dealer liable to have his accounts audited under section 50 fails to
furnish a true copy of such report within the time as aforesaid the person shall be liable to pay by
way of penalty an amount equal to Rupees ten thousand.Penalties on the import of
goods(19)Penalties on Approved Road Transporter.Where -(a)tax on goods imported into Arunachal
Pradesh by an Approved Road Transporter has not been paid by the due date for payment of the tax,
and(b)the goods are in Arunachal Pradesh and not in an Approved Warehouse at that time, the
Approved Road Transporter shall be liable to pay to the Commissioner a penalty equal to the
amount of tax owed on the goods.(20)Penalties on transporters: Any person who fails to comply
with section 26(4) shall be liable to-a penalty equal to the amount of tax unpaid.(21)Penalties on
operators of Approved Warehouses: Where,(a)tax has not been paid on the import of goods into
Arunachal Pradesh ;(b)the goods have been deposited into an Approved Warehouse; and(c)either
-(i)the goods are removed from the Approved Warehouse for delivery to a person in Arunachal
Pradesh, or(ii)the goods remain in the Approved Warehouse more than one month after their
deposit, the operator of the Approved Warehouse shall be liable to pay to the Commissioner a
penalty equal to the amount of tax owed on the goods.(22)Tax and penalties on importers of goods
removed from Approved Warehouses : Where -(a)tax has not been paid on the import of goods into
Arunachal Pradesh,(b)the goods have been deposited into an Approved Warehouse, and(c)the goodsArunachal Pradesh Goods Tax Act, 2005

are sold to a person in Arunachal Pradesh, are delivered to a person in Arunachal Pradesh or are
otherwise used or consumed in Arunachal Pradesh, the goods shall be treated as being for
consumption, use or sale in Arunachal Pradesh at that time and the importer shall be liable to pay to
the Commissioner the amount of tax unpaid on the goods and a penalty equal to the amount of tax
owed on the goods.(23)Misrepresent destination or status of goods at check-post. Where the person
in charge of a goods vehicle has represented whether orally or by conduct taken at a check-post or
barrier set up under this Act that -(a)tax has been paid on the goods in the vehicle and the person in
charge does not tender on demand proof in the prescribed form of the payment;(b)the person is an
Approved Road Transporter and the person is not;(c)the goods in the goods vehicle are for delivery
to registered dealer and the documents carried by the person disclose that the goods are for delivery
to a person other than a registered dealer; or(d)the goods in the goods vehicle are for delivery to an
Approved Warehouse and the documents carried by the person disclose that the goods are for
delivery to a person other than an Approved Warehouse; he shall be liable to a penalty equal to
Rupees ten thousand.(24)Where goods are being carried by a transporter without the documents or
without proper and genuine documents or without being properly accounted for in the documents
referred to in section 62(2),the transporter shall be liable to a penalty equal to the amount of tax
payable on such goods.General Administration(25)Obstruct or hinder tax officials. Any person who
intentionally hinders, impedes or obstructs the Commissioner in the performance of any functions
under This Act shall be liable to pay by way of penalty a sum of Rupees one lakh.(26)False,
misleading or deceptive statements. Any person who -(a)makes a statement to the Commissioner
which is false, misleading or deceptive in a material particular; or(b)omits from a statement made to
the Commissioner any matter or thing without which the statement is false, misleading or deceptive
in a material particular; the person shall be liable to pay by way of penalty a sum of Rupees one lakh
or the amount of the tax deficiency, whichever is the greater.Explanation. - The liability to pay a
penalty and the amount of the penalty may be the subject of an objection under section 75.
88. Automatic mitigation and increase of penalties.
(1)Where as a result of any proceedings the amount of tax with respect to which a penalty was levied
has been wholly reduced, the penalty levied shall be cancelled and if the penalty has been paid, it
shall be refunded.(2)Voluntary disclosure prior to audit, If -(a)a person is liable to pay a penalty
under subsections 87(121(b), (c) or (d); and(b)the person voluntarily discloses to the Commissioner
in writing the existence of the tax deficiency before the Commissioner informs the person that an
audit of the person's tax obligations is to be carried out; a the amount of the penalty otherwise due
shall be reduced by 80% of the penalty.(3)Voluntary disclosure during audit, If -(a)a person is liable
to pay a penalty under subsections 87(12Xb), (c) or (d); and(b)the person voluntarily discloses to the
Commissioner in writing the existence of the tax deficiency after the Commissioner informs the
person that an audit of the person's tax obligations is to be carried out; the amount of the penalty
otherwise due shall be reduced by 50% of the penalty.(4)Reliance on advice, If -(a)a person is liable
to pay a penalty under subsections 87(12\ (b),(c) or (d);(b)the tax deficiency arose because the
person treated this Act as applying to the person in a particular way; and(c)the decision to adopt
that treatment was made by the person relying on a determination given to the person by the
Commissioner under section 85 or a ruling issued by the Commissioner under section 86; the
amount of the penalty otherwise due shall be reduced to nil.(5)Repeat offences. Where -(a)anArunachal Pradesh Goods Tax Act, 2005

administrative penalty under this Act has been assessed;(b)the penalty has not been remitted in full
after objection; and(c)the person is subsequently assessed to a further administrative penalty in
respect of the same or a substantially similar failure occurring on another occasion (in this section
called the "subsequent offence") ; the penalty otherwise due under this Act shall be increased by
-(i)in the case of the first subsequent offence, 25% of the penalty otherwise provided; and(ii)in the
case of the second and any further subsequent offence , 100"/" of the penalty otherwise provided.
89. Relationship to assessment; No impact on criminal penalties.
(1)The administrative penalties specified under this Act are owed notwithstanding that no
assessment of tax owed under this Act has been made.(2)Any administrative penalty imposed under
this Act shall be without prejudice to any prosecution for any offence under this Chapter.
90. Offences and criminal penalties.
(1)Whoever, not being a registered dealer, falsely represents that he is or was a registered dealer at
the time when he sells or buys goods shall, on conviction, be punished with rigorous imprisonment
for a term which shall not be less than six months but which may extend to three years and with a
fine.(2)Whoever, knowingly furnishes a false return shall, on conviction, be punished -(a)in case
where the amount of tax which could have been evaded if the false return had been accepted as true
exceeds Rupees ten thousand, with rigorous imprisonment for a term which shall not be less than
six months but which may extend to three years and with a fine; and(b)in any other case, with
rigorous imprisonment for a term, which shall not be less than three months but which may extend
to one year and with a fine.(3)Whoever, knowingly produces before the Commissioner, false bill,
cash-memorandum, voucher, declaration, certificate, tax invoice or other document for claiming
deduction on tax credit, shall, on conviction, be punished -(a)in case where the amount of tax which
could have been evaded, if the documents referred to above had been accepted as true, exceeds
Rupees fifty thousand during the period of a year, with rigorous imprisonment for a term which
shall not be less than six months but which may extend to three years and with a fine; and(b)in any
other case, with rigorous imprisonment for a term which shall not be less than three months but
which may extend to one year and with a fine.(c)Whoever knowingly keeps false account or does not
keep the account of the value of the goods bought or sold by him in contravention of section 49,
shall, on conviction, be punished with rigorous imprisonment for a term which shall not be less than
three months but which may extend to one year and with a fine.(5)Whoever, knowingly produces
false accounts, registers or documents or knowingly furnishes false information, shall, on
conviction, be punished -(a)in case where the amount of tax which could have been evaded, if the
accounts, registers or documents or information referred to above had been accepted as true,
exceeds Rupees fifty thousand during the period of a year, with rigorous imprisonment for a term
which shall not be less than six months but which may extend to three years and with a fine;
and(b)in any other case, with rigorous imprisonment for a term which shall not be less than three
months but which may extend to one year and with a fine.(6)Whoever issues to any person a false
invoice, bill, cash-memorandum, voucher or other document which he knows or has reason to
believe to be false, shall, on conviction, be punished with rigorous imprisonment for a term which
shall not be less than six months but which may extend to three years and with a fine.(7)Whoever,Arunachal Pradesh Goods Tax Act, 2005

will fully attempts, in any manner whatsoever, to evade any payment of any tax, penalty or interest
or all of them under this Act, shall, on conviction, be liable -(a)in any case where the amount
involved exceeds rupees fifty thousand during the period of a year, with rigorous imprisonment for a
term which shall not be less than six months but which may extend to three years and with a fine;
and(b)in any other case, with rigorous imprisonment for a term which shall not be less than three
months but which may extend to one year and with a fine.(8)Whoever-(a)carries on business as a
dealer without being registered in will full contravention of section 19(1);(b)fails without sufficient
cause to furnish any information required by section 22;(c)fails to surrender his certificate of
registration as provided in section 23(7);(d)fails without sufficient cause to furnish any returns as
required by section 28 by the date and in the manner prescribed;(e)without reasonable cause,
contravenes any of the provisions of section 42;(f)without sufficient cause fails to issue invoice as
required under section 51 ;(g)fails without sufficient cause, when directed so to do under section 49
to keep any accounts or record, in accordance with the directions;(h)fails without sufficient cause, to
comply with any requirements made of him under section 60, or obstructs any officer making
inspection or search or seizure under sections 61 and 62;(i)obstructs or prevents any officer
performing any function under section 102;(j)being owner in charge of a goods vehicle fails, neglects
or refuses to comply with any of the requirements contained in section 85; or(k)deliberately
interferes with or obstructs the Commissioner or any officer exercising any other power conferred
under this Act, shall, on conviction, be punished with imprisonment for a term which may extend to
one year and with a fine.(9)Whoever aids or abets any person in commission of any act specified in
sub-sections (1) to (7) shall, on conviction, be punished with rigorous imprisonment which shall not
be less than three months but which may extend to one year and with a fine.(10)Whoever commits
any of the acts specified in sub-sections (1) to (9) and the offence is a continuing one under any of
the provisions of these sub-sections, shall, on conviction, be punished with a fine of not less than
Rupees one hundred per day during the period of the continuance of the offence, in addition to the
punishments provided under this section.(11)Notwithstanding anything contained in subsections (1)
to (9), no person shall be proceeded against these sub-sections for the acts referred to therein if the
total amount of tax evaded or attempted to be evaded is less than Rupees two hundred during the
period of a year.(12)Where a dealer is accused of an offence specified in sub-sections (1), (2), (3), (4),
(5), (6), or (7) or in clauses (a), (b), (c), (d), (e), (f), (g), (h) and (i) of sub-section (8), or sub section
(10)the person deemed to be the manager of the business of such dealer under section 96 shall also
be deemed to be guilty of such offence, unless he proves that the offence was committed without his
knowledge or that he exercised all due diligence to prevent the commission thereof.
91. Offences by companies.
(1)Where an offence under this Act or the rules has been committed by a company, every person
who at the time the offence was committed, was in charge of, and was responsible to the company
for the conduct of the business of the company, as well as the company shall be deemed to be guilty
of the offence and shall be liable to be proceeded against and punished accordingly.Provided that,
nothing contained in this sub-section shall render any such person liable to any punishment
provided in this Act if he proves that the offence was committed without his knowledge or that he
exercised all due diligence to prevent the commission of such offence.(2)Notwithstanding anything
contained in subsection (1), where an offence under this Act has been committed by a company andArunachal Pradesh Goods Tax Act, 2005

it is proved that the offence has been committed with the consent or connivance of, or is attributable
to any neglect on the pad of any director, manager, secretary or other officer of the company, such
director, manager, secretary or other officer shall also be deemed to be guilty of that offence and
shall be liable to be proceeded against and punished accordingly.Explanation. - For the purpose of
this section -(a)"company" means a body corporate, and includes a firm or other association of
individuals; and(b)"director" in relation to a firm means a partner in the firm.(3)Where an offence
under this Act has been committed by a Hindu Undivided Family, the Karta thereof shall be deemed
to be guilty of the offence and shall be liable to be proceeded against and punished
accordingly.Provided that nothing contained in this sub-section shall render the Karta liable to any
punishment if he proves that the offence was committed without his knowledge or that he had
exercised all due diligence to prevent the commission of such offence.Provided further that, where
an offence under this Act has been committed by a Hindu Undivided family and it is proved that the
offence has been committed with the consent or connivance of or is attributable to any neglect on
the part of any adult member of the Hindu Undivided family, such member shall also be deemed to
be guilty of that offence and shall be liable to be proceeded against and punished accordingly.
92. Cognizance of offences.
(1)No court shall take cognizance of any offence under this Act or rules made thereunder except with
the previous sanction of the Commissioner, and no court inferior to that of a Judicial Magistrate 1't
Class shall try any such offence.(2)Notwithstanding anything contained in the Code of Criminal
Procedure, 1 973(2 of 1973) all offences punishable under this Act or the rules made thereunder
shall be cognizable and bailable.
93. investigation of offences.
(1)Subject to such conditions as may be prescribed, the Commissioner may authorise either
generally or in respect of a particular case or class of cases any officer or person subordinate to him
to investigate all or any of the offences punishable under this Act.(2)Every officer so authorised
shall, in the conduct of such investigation, exercise the powers conferred by the Code of Criminal
Procedure, 1973 upon an officer in charge of a police station for the investigation of a cognizable
offence.
94. Compounding of offences.
(1)The Commissioner may, either before or after the institution of proceedings for any offence
punishable under section 90 or under any rules made under this Act, accept from any person
charged with such offence by way of composition of offence a sum not exceeding five thousand
rupees or where the offence charged is under sub-sections (1), (2), (3), (4), (5), (6), or (7), or clauses
(b), (e), or (f) of sub-section (8) of section 90 not exceeding double the amount of tax which would
have been payable on the sale or purchase turnover to which the said offence relates, whichever is
greater.(2)On payment of such sum as may be determined by the Commissioner under sub-section
(1), no further proceedings shall be taken against the accused person in respect of the same offence
and any proceedings, if already taken, shall stand abated.Arunachal Pradesh Goods Tax Act, 2005

95. Chapter XXXVI of the Code of Criminal Procedure, 1973, not to apply to
certain offences.
- Nothing in Chapter XXXVI, of the Code of Criminal Procedure, 1973 (2 of 1974) shall apply to
-(a)any offence punishable under this Act; or(b)any other offence which under the provisions of that
Code may be tried along with such offence; and every offence referred to in clause (a) or clause (b)
may be taken cognizance of by the court having jurisdiction under this Act as if the provisions of that
Chapter were not enacted.
Chapter XIV
Miscellaneous
96. Dealer to declare the name of manager of business.
- Every dealer, who is liable to pay tax under this Act, and who is a Hindu Undivided Family, or an
association of persons, club or society or firm or company, or who is engaged in business as the
guardian or trustee or otherwise on behalf of another person, shall within the period prescribed,
furnish a declaration in the manner prescribed, stating the name of the person or persons who shall
be deemed to be the manager or managers of such person's business for the purposes of this Act.
Such declaration shall be revised from time to time as required.
97. Service of notice when family is disrupted or firm is dissolved.
(1)Where a Hindu Undivided Family has been partitioned, notices under this Act shall be served on
the person who was the last manager of the Hindu Undivided Family, or if such person cannot be
found, then on all adults who were members of the Hindu Undivided Family, immediately before
the partition.(2)Where a firm or an association of persons is dissolved, notices under this Act may
be served on any person who was a partner (not being a minor) of the firm, or member of the
association, as the case may be, immediately before its dissolution.
98. Service of notice in the case of discontinued business.
- Where an assessment is to be made in respect of business which has been discontinued, a notice
under this Act shall be served in the case of a firm or an association of persons or any person who
was a member of such firm or association at the time of its discontinuance or in the case of a
company on the principal officer thereof.
99. Returns, etc. to be confidential.
(1)All particulars contained in any statement made, return furnished or accounts or documents
produced in accordance with this Act, or in any record of evidence given in the course of any
proceedings under this Act, other than proceedings before a criminal court, shall, save as providedArunachal Pradesh Goods Tax Act, 2005

in sub-section (3), be treated as confidential, and notwithstanding anything contained in the Indian
Evidence Act, 1 872 (1 of 1872), no court shall, save as aforesaid, be entitled to require any servant of
the Government to produce before it any such statement, return, account, document or record or
any part thereof, or to give evidence before it in respect thereof .(2)If, save as provided in
sub-section (3), any servant of the Government discloses any of the particulars referred to in
sub-section (1), he shall be punishable with imprisonment which may extend to six months, and
shall also be liable to a fine.(3)Nothing in this section shall apply to the disclosure -(a)of any of the
particulars referred to in sub-section (1) for the purposes of investigation or prosecution under this
Act or the Indian Penal Code 1860 (45 of 1860) or any other enactment for the time being in
force;(b)of such facts to an officer of the Central Government or any State Government as may be
necessary for verification of such facts or for the purposes of enabling that Government to levy or
realise any tax imposed by it;(c)of any such particulars where such disclosure 5 occasioned by the
lawful employment under this Act of any process for the service of any notice or the recovery of any
demand;(d)of any such particulars to a civil court in any suit or proceeding to which the
Government or any goods tax authority is a party and which relates to any matter arising out of any
proceeding under this Act or under any other law for the time being in force authorising any goods
tax authority to exercise any powers thereunder;(e)of any such particulars by any public servant
where the disclosure is occasioned by the law full exercise by him of his powers under the Indian
Stamp Act, 1899 (2 of 1899) to impound an insufficiently stamped document;(f)of any such
particulars to the Reserve Bank of India as are required by that Bank to enable it to compile
financial statistics of international investment and balance of payment;(g)of any such particulars to
any officer appointed by the Comptroller and Auditor-General of India for purpose of audit of tax
receipts or refunds;(h)of any such particulars relevant to any inquiry into a charge of misconduct in
connection with income-tax proceedings against a legal practitioner or chartered accountant, to the
authority empowered to take disciplinary action against members of the profession to which he
belongs;(i)of such particulars to the officers of the Central Government or any State Government for
such other purposes, as the Government may by general or special order direct; or(j)of any
information relating to a class of dealers or class of transactions, if in the opinion of the
Commissioner, it is desirable in the public interest, to publish such information.
100. Publication and disclosure of information in respect of dealers and other
persons in public interest.
(1)Notwithstanding anything contained in this Act, if the Government is of the opinion that it is
necessary or expedient in the public interest to publish or disclose the names of any dealers or other
persons and any other particulars relating to any proceedings under this Act in respect of such
dealers and persons, it may publish to disclose or cause to be published or disclosed such names and
particulars in such manner as it thinks fit.(2)No publication or disclosure under this section shall be
made in relation to any tax levied or penalty imposed or interest levied or any conviction for any
offence connected with any proceeding under this Act, until the time for presenting an appeal to the
appropriate appellate body has expired without an appeal having been presented or the appeal, if
presented has been disposed of.Explanation. - ln the case of a firm, company or other association of
persons, the names of the partners of the firm, the directors, managing agents, secretaries,
treasurers or managers of the company or the members of the association, as the case may be, mayArunachal Pradesh Goods Tax Act, 2005

also be published or disclosed, if, in the opinion of the Government, the circumstances of the case
justify it.
101. Power to collect statistics.
(1)If the Commissioner considers that for the purposes of the better administration of this Act it is
necessary so to do, he may by notification in the Official Gazette, direct that statistics be collected
relating to any matter dealt with, by or in connection with this Act.(2)Upon such direction being
made, the Commissioner or any person or persons authorised by him in this behalf may call upon all
dealers or any class of dealers or persons to furnish such information or statements as may be stated
therein relating to any matter in respect of which statistics are to be collected. The call for
information may be made by notification in the Official Gazette, by notice in newspapers or in such
other manner as in the opinion of the Commissioner or the said person, is best calculated to bring to
the attention of dealers and other persons. The form in which the persons to whom or, the
authorities to which, such information or returns should be furnished, the particulars which they
should contain, and the intervals in which such information or returns should be furnished, shall be
such as may be prescribed.(3)Without prejudice to the generality of the foregoing provisions, the
Government may by rules provide that every dealer or, as the case may be, any class of dealer shall
furnish such statements as may be prescribed, with the self assessment, and different provisions
may be made for different classes of dealers.
102. Setting up of check-posts and barriers.
- The Government may, by notification in the Official Gazette, set up check-posts or barriers, or
both, at any place in Arunachal Pradesh with a view to preventing evasion of tax and other dues
payable under this Act.
103. Power to make rules.
(1)The Government may, by notification, make rules, with prospective or retrospective effect, for
carrying out the purposes of this Act.(2)ln particular and without prejudice to the generality of the
foregoing power, such rules may provide for all or any of the matters which under any provision of
this Act are required to be prescribed or to be provided for by the rules.(3)ln making any rules under
this section, the Government may direct that a breach thereof shall be punishable with fine not
exceeding five hundred rupees and, when the offence is a continuing one, with a daily fine not
exceeding twenty-five rupees during the continuance of such offence.(4)Every, rule made under this
Act shall be laid, as soon as may be after it is made, before the Legislative Assembly of the Arunachal
Pradesh, while it is session, for a total period of one month which may be comprised in one session
or in two or more successive sessions, and if, before the expiry of the session immediately following
the session or the successive sessions aforesaid, the House agrees in making any modification in the
rule or the House agrees that the rule should not be made, the rule shall have effect only in such
modified form or be of no affect, as the case may be; so, however, that any such modification or
annulment shall be without prejudice to the validity of anything previously done under that rule.Arunachal Pradesh Goods Tax Act, 2005

104. Power to amend Schedules.
(1)If the Government is of opinion that it is expedient in the interest of general public so to do, he
may, by notification in the Official Gazette, add to, or omit from, or otherwise amend, the First, the
Second, the Third, the Fourth, the Fifth, the Sixth, the Seventh, or the Eighth schedules,
prospectively, and thereupon the said schedules shall be deemed to have been amended
accordingly.(2)The Government may amend the said schedules retrospectively if such amendment
does not pre-judicially affect the interest of any dealer and it does not violate the principles of
equity.
105. Power to remove difficulties.
(1)If any difficulty arises in giving effect to the provisions of this Act, the Government may, by
general or special order published in the Official Gazette, make such provisions not inconsistent
with the provisions of this Act as appear to it to be necessary or expedient for the removal of the
difficulty.Provided that no such order shall be made after the expiration of one year from the
commencement of this Act.(2)Every order made under sub-section (1) shall be laid, as soon as may
be after it is made, before Legislative Assembly of Arunachal Pradesh, while it is in session, for a
total period of one month which may be comprised in one session or in two or more successive
sessions, and if, before the expiry of the session immediately following the session or the successive
sessions aforesaid, the House agrees in making any modification in the order or the House agrees
that the order should not be made, the order shall there after have effect only in such modified form
or be of no effect, as the case may be, so, however, that any such modification or annulment shall be
without prejudice to the validity of anything previously done under that order.
106. Repeal and savings.
(1)The Arunachal Pradesh Sales Tax Act, 1 999 (Act 5 of 1999), as in force in Arunachal Pradesh
(referred to in this section as the "said Act"), are hereby repealed.(2)Notwithstanding sub-section
(1), such repeal shall not affect the previous operation of the said Acts or any right, title, entitlement,
obligation or liability already acquired, accrued or incurred thereunder.(3)For the purposes of
sub-section (2), anything done or any action taken including any appointment, notification, notice,
order, rule, form or certificate in the exercise of any powers conferred by or under the said Acts shall
be deemed to have been done or taken in the exercise of the powers conferred by or under this Act,
as if this Act were in force on the date on which such thing was done or action was taken, and all
arrears of tax and other amounts due at the commencement of this Act may be recovered as if they
had accrued under this Act.First Schedule(List of exempted goods)(Section 6(1))Sl. No.
1. Agricultural implements manually operated or animal drivenArunachal Pradesh Goods Tax Act, 2005

2. Aids & implements used by handicapped persons
3. Aquatic feed, poultry feed & cattle feed, including grass, hay, etc
4. Betal leaves
5. Books and periodicals & journals.
6. Charcoal
7. Coarse grains other than paddy, rice and wheat
8. Condoms and contraceptives
9. Cotton & silk yarn in hank
10. Charkha, Amber Charkha, Handlooms, Handloom fabrics and Gandhi Topi
11. Curd, Lussi, butter milk & separated milk.
12. Electrical energy
13. Earthen pot
14. Fire wood
15. Fresh milk and pasteurised milk
16. Fresh plants, saplings and fresh flowers
17. Fishnet & Fishnet fabrics
18. Fresh vegetables & fruits
19. Garlic & ginger
20. Glass BanglesArunachal Pradesh Goods Tax Act, 2005

21. Human Blood & blood plasma
22. Indigeneous handmade musical instruments
23. Kumkum, Bindi, Alta & Sindur
24. Meat, fish, prawn & other aquatic products when not cured or frozen,
eggs and livestock and animal hair.
25. National Flag
26. Organic manure
27. Non-judicial stamp paper sold by Govt. Treasuries, postal items like
envelope, postcard etc. sold by Govt., rupee note & cheques
28. Raw wool
29. Semen including frozen semen
30. Slate and slate pencils
31. Silk worm laying, cocoon & raw silk.
32. Tender green coconut
33. Toddy, Neera and Arak
34. Unbranded bread
35. Unprocessed and unbranded salt
36. Water other than aerated, mineral, distilled, medicinal, ionic, battery,
de-mineralised and water sold in sealed container.
37. Unprocessed Cereals, pulses, including rice and wheat.Arunachal Pradesh Goods Tax Act, 2005

38. Fabrics as specified under sub-section (iia), (vii) and (x) of section 14of
Central Sales Tax Act 1956.
39. Sugar as specified under sub-section (viii) of section 14 of Central Sales
Tax Act 1956.
40. Tobacco as specified under sub-section (ix) of section 14 of Central Sales
Tax Act 1956.
41. [ Gur and Jaggery. [Inserted by 2006 Amd Act (Act no 7of 2006) section 5]
42. Flour, Atta, Maida, Suji, Besan when produced by Chakki situated in
Arunachal Pradesh.
43. Bread, when produced by a bakery situated in Arunachal Pradesh.
44. Bamboo and Cane.]
45. [ Life saving drugs (to be specified by the authority) from time to time.]
[Inserted by 2006 and Act (Act no 11 of 2006)section 3]
Second Schedule(List of goods taxable at 1%)(Section a(1)(a))
1. Gold and articles made of gold jewellery
2. Silver and articles made of silver, rolled gold and imitation gold.
3. Precious stone, emerald, rubies, gems, diamond, sapphires, real cultured
or artificial precious stone
Third Schedule(List of goods taxable at 4"/o)(Section 4(1Xb))
1. Agricultural implements not operated manually or not driven by animal
2. All intangible goods like copyright, patent, rep. license etc.
3. All kinds of bricks including brickbats, jhama, fly ash bricks, refractory
bricks & asphaltic roofing earthern tiles.Arunachal Pradesh Goods Tax Act, 2005

4. All types of yarn other than cotton & silk yarn in hank & sewingth read
5. Aluminium utensils and enamelled utensils.
6. Are canut powder and betel nut
7. Bamboo
8. Bearings
9. Beedi leaves
10. Beltings of all varieties and descriptions
11. Bicycles, tricycles, cycle rickshaws & parts
12. Bitumen
13. Bone meal
14. Branded bread
15. Bulk drugs
16. Castings
17. Centrigugal & monobolic & submersible pumps & parts
18. Coffee beans & seeds, cocoa pod, green tea leaf & chicory
19. Chemical fertilizers, pesticides, weedicides, insecticides
20. Coir & Coir products excluding coir mattresses
21. Cotton & cotton waste
22. CruciblesArunachal Pradesh Goods Tax Act, 2005

23. Drugs and medicines [excluding life saving drugs] [Inserted by 2006 Amd
Act (Act no 11 of 2006)section 3(2)]
24. Edible oils, oil cake & de-oiled cake
25. Electrodes
26. Exercise book, graph book, & laboratory note book
27. Ferrous & non-ferrous metals & alloys, non-metals, aluminium, copper,
zinc & extrusions of those.
28. Fibres of all types and fibre waste.
29. Flour, Atta, Maida, Suji, besan
30. Fried grams
31. Gur, jaggery & edible variety of rub gur
32. Hand pumps parts and fittings.
33. Herb, bark, dry plant, dry root, commonly known as jari booti and dry
flower.
34. Hose pipes
35. Hosiery goods
36. Husk and bran of cereals
37. lce
38. lncence sticks commonly known as agarbati, dhupkathi or dhupbati.
39. industrial cables (High voltage cables, XLPE Cables, jelly filled cables,
optical fibres)Arunachal Pradesh Goods Tax Act, 2005

40. industrial inputs & packing materials as specified in this Schedule.
41. information Technology products as specified in this schedule.
42. Kerosene oil sold through PDS
43.
Leaf plates and cups
44. Lubricants, lubricating oil, engine oil, brake oil and grease.
45. Liquid product of cellulose, commonly known as L.P.C., and. liquir
product of earthen waste commonly known as L.P.E.
46. Newars
47. Napa Slabs (Rough flooring stones)
48. Ores and minerals
49. Paper and newsprint
50. Pipes of all varieties including G.l. pipes, C.l. pipes, ductile pipes, PVC
etc.
51. Plastic footwear
52. Plant and Machinery used in industry.
53. Printed materials including diary, calendar etc.
54. Printing ink excluding toner and cartridges.
55. Processed & branded salt
56. Pulp of bamboo, wood and paperArunachal Pradesh Goods Tax Act, 2005

57. Railcoaches engines & wagons
58. Readymade garments
59. Renewable energy devices & spare parts
60. Safety matches
61. Seeds
62. Sewing machine
63. Ship & other water vessels
64. Skimmed milk powder
65. Solvant oils other than organic solvent oil.
66. Spices of all varieties and forms including cumin seed, niseed, turmeric &
dry chillies.
67. Sports goods excluding apparels and footwear
68. Starch
69. Khandasari
70. Tamarind
71. Tractors, Threshers, harvesters & attachments & parts thereof.
72. Transmission towers
73. Umbrella except garden umbrella
74. Vanaspati (Hydrogeneted Vegetable Oil)Arunachal Pradesh Goods Tax Act, 2005

75. Vegetable oil including gingili oil and bran oil
76. Writing instruments
77. Declared Goods ( Goods specified under the Section 14 of Central Sales
Tax Act, 1956), that are not specified in Schedule l or Schedule ll.
Industrial Inputs(See Enter No-40)
1. Animal including fish fats, oils, crude, refined or purified
2. Glycerol, crude, glycerol waters and glycerol lyes
3. Vegetable waxes, bees wax etc.
4. Animal or vegetable fats boiled, oxidised, dehydrated etc.
5. Liquid glucose (non-medicinal), Dextrose syrup
6. Denatured ethyl alcohol of any strength
7. Manganese ores and concentrates
8. Copper ores and concentrates
9. Nickel ores and concentrates
10. Cobalt ores and concentrates
11. Aluminium ores and concentrates
12. Lead ores and concentrates
13. Zinc ores and concentrates
14. Tin ores and concentrates
15. Chromium ores and concentratesArunachal Pradesh Goods Tax Act, 2005

16. Tungsten ores and concentrates
17. Uranium or thorium ores and concentrates
18. Molybdenum ores and concentrates
19. Titanium ores and concentrates
20. Niobium, tantalum, vanadium orzirconium ores and concentrates
21. Precious metal ores and concentrates
22. Other ores and concentrates
23. Granulated slag (slag sand) from mfg. Of iron or steel
24. Benzole
25. Toluole
26. Xylole
27. Napthalene
28. Phenols
29. Creosole oils
30. Normal Paraffin
31. Butadine
32. Bitumen
33. Flurine, chlorine, bromine and iodine.
34. Sulphur, sublimed or precipitated, colloidal sulphurArunachal Pradesh Goods Tax Act, 2005

35. Carbon (carbon blacks & other forms of carbon)
36. Hydrogen, rare gases & other non-metals.
37. Alkali or alkaline earth metals
38. Hydrogen chloride
39. Sulphuric acid and anhydrides
40. Nitric acid, sulphonitric acids
41. Diphosphorous penataoxide, phosphoric acid etc.
42. Oxides of boron, boric acids
43. Halides and halide oxides of non-metals
44. Sulphides of non-metals
45. Ammonia, anhydrous
46. Sodium hydroxide (caustic soda), Potassium hydroxide (caustic potash)
47. Hydroxide and peroxide of magnesium.
48. Aluminiumhydroxide
49. Chromium oxides and hydroxides.
50. Manganese oxides.
51. lron oxides and hydroxides .
52. Cobalt oxides and hydroxides
53. Titanium oxides.Arunachal Pradesh Goods Tax Act, 2005

54. Hydrazine & hydroxylamine and their inorganic salts.
55. Flurides, fluorosilicates, etc.
56. Chlorides, chloride oxides
57. Chlorates and perchlorates, Bromates etc.
58. Sulphides, Polysulphides.
59. Dithionitesandsulphoxylates.
60. Sulphites,thiosulphates
61. Copper sulphate
62. Nitrites, nitrates
63. Phosphinates, phosphonates,etc.
64. Carbonates, peroxocarbonates.
65. Cyanides, cyanide oxides.
66. Fulminates, cyanates and th'iocyanates.
67. Borates, peroxoborates
68. Sodiumdischromate.
69. Potassium dischromate.
70. Radioactive chemical elements.
71. lsotopes and compounds.
72. Compounds, inorganic or organic of ratre earth metals.Arunachal Pradesh Goods Tax Act, 2005

73. Phosphides,whether or not chemically defined.
74. Calcium carbides.
75. Ethylene, Propylene.
76. Cyclic Hydrocarbons.
77. Halogenated derivatives of Hydrocarbons.
78. Sulphonated, nitrated or nitrosated derivatives of hydrocarbons.
79. Methanol
80. Dl-Ethylene Glycol, Mono-Ethylene Glycol
81. Cyclic alcohols
82. Halogenated, sulphonated derivatives of products.
83. Ethers, ether-alcohols, ether-phenols etc.
84. Expoxides, epoxy alcohols, epoxyethers.
85. Ethylene Oxide
86. Acetals and hemiacetals.
87. Aldehydes whether or not with other oxygen function.
88. Halogenated, sulphonated, nitrated derivatives of phenols alcohols.
89. Saturated acyclic monocarboxylic acids.
90. Unsaturated acyclic monocarboxylic acids.
91. Polycarboxylic acids.Arunachal Pradesh Goods Tax Act, 2005

92. Carboxylic acids.
93. Phosphoric ester and their salts.
94. Esters of other inorganic acids.
95. Amine-f unction compounds.
96. Oxygen - function amino-compounds.
97. Quaternary ammonium salts and hydroxides.
98. Carboxyamide function compounds.
99. Carboxyamide function compounds including saccharin and its salts.
100. N itri le-function compounds.
101. Diazo-, Azo- or azoxy-compounds.
102. Organic derivatives of hydrazine or of hydroxylamine.
103. Organo-sulphur compounds.
104. Ethylene Diamine Tetra Acetic Acid.
105. Heterocyclic compounds with oxygen heteroatom(s) only.
106. Heterocyclic compounds with nitrogen heteroatom(s) only.
107. Nucleic acids and their salts.
108. Sulphonamides.
109. Glycosides, natural or reproduced by synthesis and their salts
110. Vegetable alkaloids,natural or reproduced by synthesis and their saltsArunachal Pradesh Goods Tax Act, 2005

111. Tanning extracts of vegetable origin.
112. Synthetic organic tanning substances.
113. Colouring matter of vegetable or animal origin.
114. Synthetic organic colouring matter.
115. Colour lakes.
116. Glass frit and other glass.
117. Other
118. Printed driers.
119. Printing ink whether concentrated or solid.
120. Casein, Caseinates.
121. Enzymes, Prepared enzymes.
122. Artificial graphite.
123. Activated carbon.
124. Residual lyes from mfg. Of wood pulp.
125. Rosin and resin acids and derivatives.
126. Wood tar, wood tar oils.
127. Finishing agents, fixing of dye-stuffs.
128. Prepared rubber accelerators.
129. Reducers and blanket wash/roller wash.Arunachal Pradesh Goods Tax Act, 2005

130. Reaction initiators, reaction accelerators.
131. Mixed alkylbenzenes.
132. Chemical elements doped.
133. industrial monocarboxylic fatty acids.
134. Retarders.
135. LLDPULDPE
136. HDPE
137. Polymers of propylene.
138. PVC
139. Acrylic polymers.
140. Polyacetals.
141. Polythene chips
142. Polyamides.
143. Amino-resins, polyphenylene oxide.
144. Silicons.
145. Petroleum resins.
146. Cellulose and its chemical derivatives.
147. Natural polymers.
148. lon-exchangers based on polymers.Arunachal Pradesh Goods Tax Act, 2005

149. Self-adhesive plates, sheets, film, strip of plastics.
150. Flexible plain films.
151. Articles for conveyance or packing of goods of plastics.
152. Natural rubber, balata, gutta percha.
153. Synthetic rubber and factice derived from oils.
154. Reclaimed rubber.
155. Compounded rubber, un-vulcanised.
156. Mechanical wood pulp, chemical wood pulp, semi-chemical wood pulp
157. Cartons, Boxes.
158. Paper printed labels, paperboard printed labels.
159. Paper self-adhesive tape.
160. Partially oriented yarn, polyester textured yarn.
161. Polyester Staple Fibre & Polyester Staple Fibre Fill.
162. Polyester Staple Fibre waste.
163. Sacks and bags, of a kind used for packing of goods
164. Carboys, bottles, jars, phials of glass.
165. Stoppers, caps and lids.
Information Technology Products (See Entry No. 41)
1. Word processing machines, Electronic typewritersArunachal Pradesh Goods Tax Act, 2005

2. Microphones, multimedia speakers, headphones etc.
3. Telephone answering machines
4. Prepared unrecorded media for sound recording
5. Prepared unrecorded media for sound recording
6. IT software or any media.
7. Transmission apparatus other than apparatus for radio or T.V.
broadcasting
8. Radio communication receivers, Radio Pagers
9. Aerials, antennas and parts
10. LCD Panels, LED panels and parts.
11. . Electrical capacitors, fixed, variable and parts
12. Electronic calculators
13. Electrical resistors
14. Printed Circuits
15. Switches, Connectors, Relays for up to 5 amps
16. DATA/Graphic Display tubes, other than Picture tubes and parts
17. Diodes, transistors & similar semi-conductor devices
18. Electronic integrated Circuits and Micro-assemblies
19. Signal Generators and partsArunachal Pradesh Goods Tax Act, 2005

20. Optical fibre-cables
21. Optical fibre and optical fibre bundles, cables
22. Liquid Crystal devices, flat panel display devices and parts
23. Computer systems and peripherals, Electronic diaries
24. Cathode ray oscilloscopes, Spectrum analysers, Signal analysers.
25. Parts and Accessories of HSN 84.69,84.70 &84.71
26. D C Micro motors, Stepper motors of 37.5 watts.
27. Parts of HSN 85.01
28. Uninterrupted power supply
29. Permanent magnets and articles
30. Electrical apparatus for line telephony or line telegraphy.
Fourth Schedule(List of goods taxable at 20%)(Section 4(t)(c))
1. (a) Motor spirit use as fuel for Air craft including aviation turbine fuel
(b)Other motor spirits (except Kerosene, Diesel oil and internal combustion oils) including
Petrol(c)Petroleum gas and natural gas (excluding cooking gas (LPG)(d)All other products obtained
as derivatives of petroleum and/ or natural gas
2. Non-potable Liquor, ie.
(a)Rectified spirit(b)Denatured spirit(c)Methyl Alcohol(d)Absolute Alcohol(e)Any other alcohol
which the State Govt. by notification in the official gazette declared to be non-potable for the
purpose of entry
3. Liquor including Foreign Liquor, IMFL and Country LiquorArunachal Pradesh Goods Tax Act, 2005

4. Molasses
5. Narcotics
Fifth Schedule(List of Dealers exempted from paying tax on sales of goods)(Section 6(2))(To be
notified from time to time)Sixth Schedule(List of Organizations who can claim refunds)(Section
43(1))(To be notified from time to time)Seventh Schedule(List of non-creditable goods)(Section
2(w))(1)Subject to clauses (2) and (3), the following goods are "non-creditable goods" for the
purposes of this Act:
1. Motor vehicles designed for transporting fewer than 8 passengers; motor
cycles, motor scooters and other motorised two-wheeled vehicles
2. Fuels in the form of petrol, diesel and kerosene, LPG, CNG, coal
3. Conventional clothing, ornaments, footwear and clothing fabrics
4. Food for human consumption
5. Beverages for human consumption
6. Goods designed, and used predominantly for, the provision of
entertainment including television receivers, video cassette players, radios,
stereo systems, audio cassette player, CD players, DVD players, computer
game consoles and computer games, cameras of any kind
7. Tobacco in any form and tobacco products
(2)Any item in clause 1 is not to be treated as non-creditable goods if the item is purchased for the
purpose of re-sale in an unmodified form by a registered dealer in the ordinary course of his
activities.(3)Fuel & clothing fabrics (ltem 2 &3 of clause 1) is not to be treated as non-creditable
goods if the importer or purchaser is a dealer in products and purchases the items in commercial
quantities for use as a raw material input to manufacturing process.Eighth Schedule(List of
non-taxable imports)(Section 2(X))The following goods shall be non-taxable imports.
1. Schedule 1 goods: Any goods listed in Schedule One to this Act.
2. Temporary imports: Goods which are imported into Arunachal Pradesh
and are to be removed from Arunachal Pradesh within 12 hours.Arunachal Pradesh Goods Tax Act, 2005

3. Temporary exports and re-imports: Goods (not being cars and motor
vehicles) which have been exported from Arunachal Pradesh within the
previous 14 days.
4. Vehicles registered in Arunachal Pradesh: Cars and other vehicles
registered in Arunachal Pradesh under the Motor Vehicles Act, 1988.
5. Low value items: Any goods brought into Arunachal Pradesh as a single
consignment where the total value of the consignment at the time of import
is less than Rs 10,000, unless the goods are imported in commercial
quantities.
6. Low value items imported by courier: Goods which would have been free
from customs duty under the Customs Act, 1962 (if the goods had been
imported into Arunachal Pradesh from a foreign country) pursuant to the
Courier imports and Exports (Clearance) Regulations, 1998.
7. Low value items imported by post: Goods which would have been exempt
from customs duty under the Customs Act, 1962 (if the goods had been
imported into Arunachal Pradesh from a foreign country) pursuant to the
Rules Regarding Postal Parcels and Letter Packets from Foreign parts in and
out of lndia.
8. Personal effects, household items and accompanied baggage: Goods
which could have been imported free of duty under the Customs Act, 1962
(assuming the goods had been imported into Arunachal Pradesh from a
foreign country) pursuant to the Baggage Rules, 1998 (assuming the entry in
Column 1 of Appendix F referred only to "used personal and household
articles").
9. Transfer of residence: Used household items, personal effects and motor
cars which are brought into Arunachal Pradesh because of the transfer of the
residence of the importer, provided that the importer furnishes to the
Commissioner such evidence as may be prescribed of the transfer of his
residence.Arunachal Pradesh Goods Tax Act, 2005

10. Goods re-imported into Arunachal Pradesh for repair or other processing:
Goods and parts of goods which have been sold in Arunachal Pradesh or
which have been subject to tax in Arunachal Pradesh which could be
re-imported free of customs duty under the Customs Act, 1962 (if the goods
had been re-imported into Arunachal Pradesh from a foreign country)
pursuant to Notification No 158/95 - CUS (November 14, 1995).
11. . Goods imported for warranty replacements: Goods imported for the
repair of other goods under warranty (where the price of the warranty was
not separately identified at the time of purchaseArunachal Pradesh Goods Tax Act, 2005

