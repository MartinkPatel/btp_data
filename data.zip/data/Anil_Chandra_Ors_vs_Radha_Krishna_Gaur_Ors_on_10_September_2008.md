Anil Chandra & Ors vs Radha Krishna Gaur & Ors on 10
September, 2008
Bench: Tarun Chatterjee, V.S. Sirpurkar
                                                                               1
                        REPORTABLE
              IN THE SUPREME COURT OF INDIA
               CIVIL APPELLATE JURISDICTION
                 CIVIL APPEAL NO.6187 OF 2009
            (Arising out of SLP (C) No.13913 of 2008)
ANIL CHANDRA & ORS.
-------Appellants
VERSUS
RADHA KRISHNA GAUR & ORS.                                 -------
Respondents
                           WITH
                 CIVIL APPEAL NO.6188 OF 2009
                (Arising out of SLP)No.14794 of 2008)
                         JUDGMENT
TARUN CHATERJEE, J.
1. Leave granted.
2. These two appeals are directed against an interim order dated 4th of December, 2007 passed in
Writ Petition No. 1496(S/B) of 2007 by a Division Bench of the High Court of Allahabad, Lucknow
Bench, Lucknow whereby the High Court directed the aforesaid writ petition to be tagged with Writ
Petition No. 1389 (SB) of 2007 pending in the High Court, following the interim order passed in the
aforesaid Writ Petition No. 1389 (SB) of 2007 directing that the seniority of the respondents as
existing prior to the enforcement of the U.P. Government Servants Seniority (3rd Amendment)
Rules, 2007 shall not be disturbed in pursuance of the Rules by way of the aforesaid impugned
order.
3. The relevant facts leading to the filing of these appeals may be summarized as under: -Anil Chandra & Ors vs Radha Krishna Gaur & Ors on 10 September, 2008

In the year 1973, the Government Orders providing reservation in the matter of
promotion for the Scheduled Castes and Scheduled Tribes were issued. Subsequently,
the U.P. Jal Nigam adopted the U.P. Government Servants Seniority Rules 1991. The
aforesaid rules were notified by the State Government vide Notification dated 20th of
March, 1991 which consisted of provisions of the aforesaid Rules of 1991. The
respondent no. 2, namely, U.P. Jal Nigam is a Statutory Corporation created under
the U.P. Water Supply and Sewerage Act, 1975 and the service conditions of the
employees of the Nigam are governed by the U.P. Jal Nigam (Public Health Branch)
Service Regulations, 1978. The aforesaid regulations were made in exercise of power
conferred on the U.P. Jal Nigam under Sections 97(2) and 98(1) of the U.P. Water
Supply and Sewerage Act, 1975 with the prior approval of the State Government.
4. Subsequently, in the year 1994, the Uttar Pradesh Public Services (Reservation for Schedule
Caste, Schedule Tribes and other Backward Classes) Act, 1994 was promulgated and Section 3 (7) of
the said Act of 1994 says that if on the date of the commencement of this Act, reservation was in
force under Government orders for appointment to posts to be filled up by promotion, such
Government orders shall continue to be applicable till they are modified or revoked. Further, on
10th of October, 1994 the percentage of reservation in the matter of Schedule Castes was enhanced
from 18% to 21% by means of Government order referring to section 3(7) of the aforesaid Act of
1994.
5. Article 16(4-A) was introduced by an amendment of the Constitution on 17th of June, 1995, which
reads as under :-
"Nothing in this article shall prevent the State from making any provision for
reservation in the matters of promotion, with consequential seniority, to any class or
class of posts in the services under the State in favour of the scheduled castes and the
scheduled tribes which in the opinion of the State are not adequately represented in
the services under the State"
6. Article 16(4-A) of the Constitution, which was inserted in the Constitution on 17th of June, 1995,
as noted herein earlier, was incorporated by the Constitution (77th Amendment) Act, 1995, thereby
introducing an enabling provision for providing reservation in the matter of promotion.
7. However, this Court in its Judgment dated 16th of November, 1992, in the case of Indira Sawhney
vs. Union of India [AIR 1993 SC 447], observed that reservation of appointments or posts under
Article 16 of the Constitution is confined to the initial appointment and cannot extend to reservation
in the matter of promotion.
8. Further in the year 2002, the U.P. Government Servants Seniority (1st Amendment) Rules, 2002,
were issued by which Rule 8 (A) was inserted in the Seniority Rules, 1991 providing consequential
Seniority to the scheduled Castes and scheduled tribes from the date of their promotion and in the
meantime the validity of Article 16(4-A) of the Constitution as also the Rules and Enactments of
various states granting consequential seniority to the scheduled castes and scheduled tribes in theAnil Chandra & Ors vs Radha Krishna Gaur & Ors on 10 September, 2008

matter of promotion was assailed in a bunch of writ petitions which were filed before this Court
under Article 32 of the Constitution of India and the said matters were referred to a Constitution
Bench.
9. Further in the year 2005, the U.P. Government Servants Seniority (2nd Amendment) Rules, 2005
were introduced by which Rule 8(A) referred to above was omitted.
10. On 19th of October, 2006, the aforesaid reference was decided by the Constitution Bench in
M.Nagaraj & Ors. Vs. Union of India & Ors. [(2006) 8 SCC 212] and the Constitution Bench held in
that decision that the provision contained in Article 16(4-A) of the Constitution is an enabling
provision and the State is not bound to make reservation for SCs/STs in the matter of promotion.
However, if they wish to exercise their discretion and make such provision, the State has to collect
quantifiable data showing backwardness of the class and inadequacy of representation of that class
in public employment in addition to compliance of Article 335 of the Constitution of India. It is clear
that even if the State has compelling reasons, as stated above, the State will have to see that its
reservation provision does not lead to excessiveness so as to breach the ceiling-limit of 50% or
obliterate the creamy layer or extend the reservation indefinitely.
11. Further, after the passing of aforesaid judgment by the Constitution Bench, the U.P. Government
issued a Notification on 14th of September, 2007 by which the U. P. Government Servants Seniority
(3rd Amendment) Rules, 2007, were issued which runs as under :
"Rule 8-A :- Entitlement of consequential seniority to a person belonging to
scheduled castes and scheduled tribes :
Notwithstanding anything contained in Rules 6, 7 or 8 of these rules, a person
belonging to the SC or ST shall, on his promotion by virtue of rule of
reservation/roster, be entitled to consequential seniority also from 17.6.1995 in the
seniority rules, 1991 and also provided for consequential seniority to the scheduled
Castes and scheduled tribes from the date of their promotion as per the Roster/rule
of reservation".
12. After the issuance of the aforesaid notification, the State Government vide letter dated 3rd of
October, 2007 directed the various Development Authorities including the appellants to take
necessary action in accordance with the Notification dated 14th of September, 2007 and according
to Section 92 of the U. P. Avas Evam Vikas parishad Adhiniyam, 1965, the State Government will
have control over the Board and other Local authorities and the State Government may give the
board such directions which in its opinion are necessary or expedient for carrying out the purpose of
the Act, and it shall be the duty of the Board to comply with such directions.
13. On 17th of October, 2007, the State Government issued another order, wherein it was directed
that as a result of the aforesaid Amendment in the Seniority Rules 1991, necessary amendments
should be made in the Seniority List by adopting the procedure in accordance with the seniority
Rules. But before making any such provision, it was the Constitutional obligation and duty of theAnil Chandra & Ors vs Radha Krishna Gaur & Ors on 10 September, 2008

State Government to see in each case the existence of the compelling reason, namely, backwardness,
inadequacy of representation and overall administrative inefficiency on the basis of qualified data
collected but in the present case, no such exercise has been undertaken by the State of U.P.
14. The aforesaid Notification dated 14th of September, 2007 was adopted vide order dated 19th
October, 2007 by the Chairman of Jal Nigam and was given immediate effect thereto. Thereafter,
the U.P.Jal Nigam issued the tentative joint seniority list of Chief Engineer Level-1, Chief Engineer
Level-II (Civil) and Superintending Engineer (Civil) and the tentative Seniority List of the Executive
Engineers of U.P. Jal Nigam dated 3rd of November, 2007 in furtherance of the aforesaid
notification dated 14th of September, 2007.
15. On 6th of November, 2007, the validity of the aforesaid Rule 8(A) of Uttar Pradesh Government
Servants' Seniority (3rd Amendment) Rules, 2007 was challenged by the Engineers of the Irrigation
Department by way of a Writ Petition No. 1389 of 2007 before the High Court of Allahabad,
Lucknow Bench, Lucknow. In the said writ petition, the Division Bench of the High Court of
Allahabad, Lucknow Bench after hearing the Parties, has issued a notice to the Advocate General of
the State vide order dated 6th of November, 2007. The High Court, in the meantime, passed an
interim order by which the seniority of the petitioners in that writ Petition and other Promoted
officers, as was existing prior to the enforcement of the aforesaid Uttar Pradesh Government
Servants' Seniority (3rd Amendment) Rules, 2007 shall not be disturbed in pursuance of these Rules
and no reversion shall be effected.
16. Respondents who were working on the post of Superintending Engineers, Executive Engineers
and Assistant Engineers in U.P. Jal Nigam, aggrieved by the aforesaid Seniority List, filed a Writ
Petition assailing the validity of the U. P. Government Servants Seniority (3rd Amendment) Rules,
2007, by which Rule 8-A has been inserted in the U. P. Government Servants Seniority Rules, 1991
and by virtue of the aforesaid Rules, the Government Servants belonging to Scheduled Castes and
Scheduled Tribes would be entitled to consequential seniority on accelerated promotion given to
them through roster/rule of reservation. In the aforesaid Writ Petition, the respondents further
assailed the validity of the Notification dated 14th of September, 2007 of the U.P. Government
Servants Seniority (3rd Amendment) Rules, 2007 made effective from 17th of June, 1995. They also
challenged the order dated 19th of October, 2007 by which the aforesaid Notification dated 14th of
September, 2007 was adopted. The respondents also challenged the aforesaid tentative Seniority
List dated 3rd of November, 2007: issued by the U.P. Jal Nigam in furtherance of the Notification.
17.The aforesaid Writ Petition No.- 1496 (S/B) of 2007 came up for hearing before a Division Bench
of the High Court of Allahabad, Lucknow Bench, Lucknow. The High Court directed the aforesaid
Writ Petition to be tagged with Writ Petition No. 1389 (SB) of 2007 pending in the High Court.
However, the Division Bench, following the reasons mentioned in the order passed in Writ Petition
No. 1389(S/B) of 2007, by an interim order, directed that the seniority of the respondents as
existing prior to the enforcement of the U.P. Government Servants Seniority (3rd Amendment)
Rules, 2007 shall not be disturbed in pursuance of the Rules.Anil Chandra & Ors vs Radha Krishna Gaur & Ors on 10 September, 2008

18. Further in the meantime, some of the Executive Engineers also filed a Writ Petition No.81/2008
thereby challenging the consequential validity of Rule 8-A of the U.P. Government Servants
Seniority (3rd Amendment) Rules, 2007. In the present writ petition, the Division Bench of the High
Court, relying upon the order passed by the High Court in the earlier writ petition No.1389 (SB) of
2007, issued notice and granted relief and provided that the seniority of the appellants therein as
existing prior to the enforcement of the U.P. Government Servants Seniority (3rd Amendment)
Rules, 2007, shall not be disturbed in pursuance of these rules. Subsequently, the U.P. Avas Evam
Vikas parishad, Lucknow, which was a party in the aforesaid writ petition, aggrieved by the
aforesaid interim order dated 17th of January, 2008, filed a Special Leave Petition (c) No. 3097 of
2008 before this Court challenging the aforesaid interim order of the High Court. This Court, vide
order dated 22nd of February, 2008, granted leave and allowed the aforesaid appeal filed by the
Parishad to the extent that the interim order passed by the High Court was set aside and requested
the High Court to dispose of the writ petition preferably within two months from the date of the
communication of the order. The appellants, on coming to know about the passing of the aforesaid
order, filed an application for impleadment and the said application was numbered as
C.M.Application No.189180 of 2008. In the said application, it was contended that the appellants
were necessary and affected parties and yet they were not arrayed as respondents in the aforesaid
writ petition. It was also contended that any order passed in the aforesaid writ petition was going to
affect the rights of the present appellants. Accordingly, they prayed to be impleaded as respondent
Nos. 4 to 8 in the array of the parties. Further on 5th of March, 2008, the aforesaid impleadment
application came up for hearing before the High Court and the High Court on that date allowed the
impleadment application filed by the appellants. Hence, on 3rd of April, 2008, the present special
leave petition was filed.
19. In the present case and in the facts and circumstances stated herein earlier, we are of the view
that it was the constitutional obligation of the State, at the time of providing reservation in the
matter of promotion to identify the class or classes of posts in the service for which reservation is
required, however, neither any effort has been made to identify the class or classes of posts for
which reservation is to be provided in promotion nor any exercise has been done to quantify the
extent of reservation. Adequate reservation does not mean proportional representation. Rule 8(A)
has been inserted mechanically without taking into consideration the perquisites for making such a
provision as required under Article l6 (4-A) of the Constitution of India. The ceiling- limit of 50%,
the concept of creamy layer and the compelling reasons, namely, backwardness, inadequacy of
representation and overall administrative efficiency are all constitutional requirements without
which, the structure of equality of opportunity in Article 16 would collapse. However, in this case, as
stated, the main issue concerns the "extent of reservation" and in this regard, the State should have
shown the existence of the compelling reasons, namely, backwardness, inadequacy of representation
and overall administrative efficiency before making provision for reservation. As observed in M.
Nagaraj and Ors. Vs. Union of India & Ors.(Supra), it has been held that the State is not bound to
make reservation for SC/ST in matter of promotions. However, if they wish to exercise their
discretion and make such provision, the State has to collect quantifiable data showing backwardness
of the class and inadequacy of representation of that class in public employment in addition to
compliance of Article 335 of the Constitution. It is clear that even if the State has compelling
reasons, as stated above, the State will have to see that its reservation provision does not lead toAnil Chandra & Ors vs Radha Krishna Gaur & Ors on 10 September, 2008

excessiveness so as to breach the ceiling-limit of 50% or obliterate the creamy layer or extend the
reservation indefinitely.
20.The rules pertaining to the reservation and promotion list is prospective in nature and thereby
cannot disturb the promotion list of the appellants by virtue of this rule further, if a
rule/notification/circular claims to be retrospective in nature, has to expressly specify, as per the
rules of interpretation of statutes in the instant petition, the appellants have failed to establish the
nature with regard to retrospective effect of the notification/rules.
21.In the light of the reasons above-mentioned, we are of the view that the High Court was fully
justified in granted the present interim order and there is no infirmity in the same.
22.Since the interim order passed by the High Court, which has not been interfered with by us in
this judgment, we make it clear that the grant of interim order and any observation made by the
High Court while granting interim order and any observations made by us in this order shall not
influence the High Court to decide the writ petition on merits and the High Court shall not be
influenced by any of the observations made by us in this order.
23.There is one another aspect of this matter. These appeals have been filed, as noted herein earlier,
against an interim order passed by the High Court. It appears that the main writ petition, with
which the present writ application has been tagged by the High Court, has already been taken up for
hearing, which is already heard in part. Such being the position at this stage, it would not be
appropriate for us to interfere with the impugned order passed by the High Court at this stage when
the writ petition itself can be decided within a very short time.
24.Considering the importance of the present dispute between the parties, we are of the view that
the High Court shall take efforts to decide the writ petitions at an early date and dispose of the same
within six months from the date of supply of a copy of this order to it.
25.The appeals are thus dismissed. There will be no order as to costs.
................................... J.
[Tarun Chaterjee] ....................................J. New Delhi; [V.S.Sirpurkar] September 10, 2009.Anil Chandra & Ors vs Radha Krishna Gaur & Ors on 10 September, 2008

