Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26
February, 2020
Equivalent citations: AIRONLINE 2020 SC 279, (2020) 4 SCALE 310
Author: Dinesh Maheshwari
Bench: Dinesh Maheshwari, A.M.Khanwilkar
                           CIVIL APPEAL NOS. 8512-8527 OF 2019 and connected cases
                                         INDEX OF JUDGMENT
           Sl. No.                            Contents                       Page
              1.                Introductory                                  1-3
              2.                Brief Outline and the Issues Involved         3-5
              3.                Parties and their respective roles and        6-7
                                interest in the matter
                      4.        The transactions in question               8-11
                      5.        The relevant factual and background        11-18
                                aspects
                      6.        The      Application     by    Interim     18-24
                                Resolution Professional and the
                                order passed by NCLT
                      7.        Appeals before NCLAT: the impugned         24-29
                                order
                      8.        The relevant provisions                    29-37
          WHETHER THE                   TRANSACTIONS         IN   QUESTION    ARE
          PREFERENTIAL:
                      9.        Broad features of rival contentions        38-54
                                and submissions
                      10.       Insolvency and Bankruptcy Code,            54-58
                                2016: historical background, objects,
                                scheme and structure of the relevant
                                parts
                      11.       Preferential transaction at a relevant     58-64
                                time: concept and connotations
                      12.       Analysing Section 43 of the Code           64-74
                      13.       Whether impugned transactions are          74-80
                                preferential, falling within the ambit
                                of sub-section (2) of Section 43 IBC
                      14.       The requirements of sub-section (4) of     80-89
                                Section 43 IBC - related party and look-
                                back period
Signature Not Verified15.       Ordinary course of business or             90-98
                                financial affairs
Digitally signed by
DEEPAK SINGHAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

Date: 2020.02.26
18:20:08 IST
Reason:
                      16.       The concern expressed by lenders of        99-100
                                JAL is legally untenable
                                                       (i)
  17.   Summation: The transactions in               100
        question are hit by Section 43 IBC
  18.   Search    and     commandeering        of   101-104
        preference at a relevant time
  19.   Other aspects of the application            104-107
        made by IRP – allegations of
        transactions being undervalued and
        fraudulent
WHETHER LENDERS OF JAL COULD BE CATEGORISED AS
FINANCIAL CREDITORS OF JIL
  20.   Preliminary and background                  107-109
  21.   Reasoning and Findings of NCLT              110-114
  22.   Rival submissions                           114-130
  23.   Unique    position   of   financial         130-134
        creditor- as explained in Swiss
        Ribbons
  24.   Financial debt - ratio of Pioneer           134-147
        Urban
  25.   The     expressions    “means     and       147-152
        includes” in the definition clauses -
        effect
  26.   The essentials for financial debt and       152-158
        financial creditor
  27.   The respondent mortgagees are not           158-171
        the financial creditors of corporate
        debtor JIL
  28.   Summation on second issue                     171
  29.   Conclusion                                  171-172
        Acknowledgment                              172
                              (ii)
                                                     1Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

                                                                              REPORTABLE
                              IN THE SUPREME COURT OF INDIA
                               CIVIL APPELLATE JURISDICTION
                            CIVIL APPEAL NOS. 8512-8527 OF 2019
ANUJ JAIN INTERIM RESOLUTION
PROFESSIONAL FOR JAYPEE
INFRATECH LIMITED                                                   ……. Appellant(s)
                                   Versus
AXIS BANK LIMITED ETC. ETC.                                         ……. Respondent(s)
WITH
CIVIL APPEAL NOS. 6777-6797 OF 2019
CIVIL APPEAL NOS. 9357-77 OF 2019
(ARISING OUT OF DIARY NO. 32881 OF 2019)
                                          JUDGMENT
Dinesh Maheshwari, J.
Introductory
1. These appeals are essentially directed against the common order dated 01.08.2019 as passed by
the National Company Law Appellate Tribunal, New Delhi1 in a batch of appeals preferred by
various banks and financial institutions whereby, the Appellate Tribunal set aside the order dated
16.05.2018, passed by the Adjudicating Authority, the National Company Law 1 Hereinafter also
referred to as ‘the Appellate Tribunal’ or ‘NCLAT’ Tribunal, Allahabad Bench2 on the application
moved by the Interim Resolution Professional3 in the Corporate Insolvency Resolution Process4
concerning the Corporate Debtor Company viz., Jaypee Infratech Limited5 seeking avoidance of
certain transactions, whereby the corporate debtor had mortgaged its properties as collateral
securities for the loans and advances made by the lender banks and financial institutions to
Jaiprakash Associates Limited 6, the holding company of JIL, as being preferential, undervalued
and fraudulent, in terms of Sections 43, 45 and 66 of the Insolvency and Bankruptcy Code, 20167.
1.1. It may be noticed at the outset that the batch of appeals decided by the impugned common order
dated 01.08.2019 also comprised of two appeals filed by the lenders of JAL, being Comp. App (AT)
(Ins) No. 353 of 2018 and Comp. App (AT) (Ins) No. 301 of 2018 that were preferred against theAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

orders passed by NCLT on 09.05.2018 and 15.05.2018 respectively, whereby NCLT approved the
decision of IRP rejecting the claims of such lenders of JAL to be recognized as financial creditors of
the corporate debtor JIL on the strength of the mortgage created by the corporate debtor, as
collateral security of the debt of its holding company JAL. These two appeals also came to be
allowed as per the result recorded in the impugned order dated 01.08.2019, though the 2
Hereinafter also referred to as ‘the Tribunal’ or ‘NCLT’ or ‘the Adjudicating Authority’. 3 ‘IRP’ for
short.
4 ‘CIRP’ for short.
5 ‘JIL’ for short; also referred to as ‘the corporate debtor’. 6 ‘JAL’ for short.
7 Hereinafter also referred to as ‘the Code’ or ‘IBC’.
entire discussion and the final conclusion therein had only been in relation to the order dated
16.05.2018 that was passed by NCLT on the application for avoidance filed by IRP. The appellant of
Civil Appeal D. No. 32881 of 2019 8, IIFCL, apart from raising other contentions, has also
questioned this aspect of the order impugned that the aforesaid two appeals, involving the question
as to whether the lenders of JAL could be categorised as financial creditors of JIL for the purpose of
IBC, have been allowed by NCLAT without recording any findings and without any discussion in
that regard.
Brief Outline and the Issues Involved
2. Before proceeding further, we may draw up a brief outline of the subject- matter and the issues
involved in these appeals.
2.1. As shall be noticed hereafter later, the CIRP concerning the corporate debtor JIL has already
undergone several rounds and circles of proceedings in NCLT, NCLAT and at least twice over in this
Court.
2.2. For what has been indicated in the introduction, it is evident that two major issues would arise
in these appeals. One, as to whether the transactions in question deserve to be avoided as being
preferential, undervalued and fraudulent, in terms of Sections 43, 45 and 66 of the Code; and
second, as to whether the respondents (lender of JAL) could be recognized as financial creditors of
the corporate debtor JIL on the strength of the mortgage created 8 Now numbered as Civil Appeal
Nos. 009357-77 of 2019 by the corporate debtor, as collateral security of the debt of its holding
company JAL.
2.3. For a preliminary insight into the first issue, suffice would be to notice that during CIRP, the
Interim Resolution Professional preferred an application before the Adjudicating Authority seeking
orders for avoidance of the impugned transactions, whereby several parcels of land were put under
mortgage with the lenders of JAL, the holding company of JIL. The contention of IRP, that the
transactions in question were preferential, undervalued and fraudulent within the meaning ofAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

Sections 43, 45 and 66 of the Code, were accepted in part by the Adjudicating Authority, the NCLT,
in its order dated 16.05.2018 and necessary directions were issued for avoidance of at least six of
such transactions. In other words, in relation to such six transactions, the security interest was
ordered to be discharged and the properties involved therein were vested in the corporate debtor,
with release of encumbrances. The NCLAT, however, took an entirely opposite view of the matter
and upturned the order so passed by NCLT, while holding that the transactions in question do not
fall within the mischief of being preferential or undervalued or fraudulent; and that the lenders in
question (the lenders of JAL) were entitled to exercise their rights under the Code. Aggrieved, the
IRP, one of the creditors of the corporate debtor JIL and the associations of home buyers, who have
invested in the proposed projects of JIL and JAL, have preferred these appeals.
2.4. As regards the second issue, noticeable it is that during CIRP, two of the respondent banks
namely, ICICI Bank Limited and Axis Bank Limited, sought inclusion in the category of financial
creditors of JIL but IRP did not agree and declined to recognize them as such. Being aggrieved by
the decisions so taken by IRP, the said banks preferred separate applications under Section 60(5) of
the Code before NCLT while asserting their claim to be recognized as financial creditors of the
corporate debtor JIL, on account of the securities provided by JIL for the facilities granted to JAL.
The NCLT rejected the applications so filed by the said banks, by way of its orders dated 09.05.2018
and 15.05.2018 respectively, while concluding that on the strength of the mortgage created by the
corporate debtor JIL, as collateral security of the debt of its holding company JAL, the lenders of
JAL could not be categorised as financial creditors of JIL for the purpose of the Code. As already
noticed, the appeals against the said orders dated 09.05.2018 and 15.05.2018 are purportedly
allowed as per the result recorded in the impugned order dated 01.08.2019, but without any
discussion in that regard. Aggrieved, one of the lenders of the corporate debtor JIL, IIFCL (appellant
of Civil Appeal D. No. 32881 of 2019) has also questioned this aspect of the order impugned while
asserting that such mortgagees cannot be taken as financial creditors of the corporate debtor JIL.
Parties and their respective roles and interest in the matter
3. In view of the issues arising for determination in these appeals, with several parties carrying
different roles, status and interests, worthwhile it would be to narrate at the outset, in brief, the
relevant particulars of the key parties involved as follows:
3.1. Jaypee Infratech Limited (JIL):
It is the corporate debtor company in whose relation CIRP is pending;
and the mortgage transactions concerning its properties were questioned in the
application filed by the Interim Resolution Professional. Such transactions form the
subject-matter of these appeals.
3.2. Jaiprakash Associates Limited (JAL):Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

It is the holding company of JIL; it had approximately 71.64% equity shareholding in
JIL as on 31.03.2017. The impugned mortgage transactions were entered into in
favour of its lenders.
3.3. Shri Anuj Jain:
He is the Interim Resolution Professional in CIRP concerning JIL who moved the
application for avoidance of the transactions in question. He is the appellant in Civil
Appeal Nos. 8512-27 of 2019.
3.4. Jaypee Greens Krescent Home Buyers Welfare Association; Jaypee Kasa Isles
Welfare Association; Jaypee Kensington Boulevard Apartments Welfare Association;
Garden Isle Welfare Association; Jaypee Klassic Apartment Welfare Association;
Jaypee Kube Buyers Welfare Association;
Wish Town Property Owners Welfare Society; KRH Buyers Association ABL Workplace:
They are the associations of home buyers who have invested in the projects of JIL
and JAL. They are the appellants in Civil Appeal Nos. 6777-97 of 2019; and they also
support the assertion of IRP that the transactions in question cannot be
countenanced.
3.5 India Infrastructure Finance Company Limited:
It is the financial creditor of the corporate debtor JIL and has filed Civil Appeal in
Diary No. 32881 of 2019 while asserting that the transactions in question need to be
avoided; and that the lenders of JAL related with such transactions cannot be the
financial creditors of JIL for the purpose of CIRP in question.
3.6 Axis Bank Limited; Standard Chartered Bank Limited; ICICI Bank Limited; State
Bank of India; United Bank of India; UCO Bank; The Karur Vyasa Bank (P) Limited;
L&T Infrastructure Finance Company Limited; Central Bank of India; Canara Bank;
Karnataka Bank Limited; IFCI Limited; Allahabad Bank; Jammu & Kashmir Bank;
South Indian Bank Limited; Bank of Maharashtra and other banks and financial
institutions:
They are the lenders of JAL in whose favour the properties of JIL were put under
mortgage by way of the impugned transactions. They oppose the assertions of
appellants while maintaining that the transactions in question are not avoidable and
are valid, investing them with the capacity of financial creditors of JIL. They are the
principal contesting respondents in these appeals.
The transactions in questionAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

4. Having taken note of the principal contesting parties and their respective interests, it would also
be worthwhile to take note of the relevant particulars of the properties and the transactions involved
in this dispute. It may be usefully noticed that out of seven transactions that were questioned by
IRP, the Adjudicating Authority held that six of them were preferential, undervalued and fraudulent
and passed the orders for their avoidance while accepting the contentions of IRP. It may also be
observed that five out of these six transactions were preceded by previous mortgage transactions for
securing the loans/facilities to JAL. The transactions in question, with previous transactions and
flow thereof, as given out during the course of submissions, could be comprehensively viewed as
under: -
4.1. The transactions in favour of the Consortium of Banks and Financial Institutions:
Property/transaction in question Previous transaction/s and flow thereof Mortgage
deed dated 29.12.2016 for Initial mortgage deed dated 167.229 acres of land situated
at Village 24.02.2015 released on 15.09.2015 Chhalesar and Chaugan, Tehsil and
re-mortgaged on 15.09.2015 Etmadpur, District Agra, Uttar Pradesh (changing
facility amount from Rs.
executed by JIL in favour of Axis Trustee 3250 crores (appx.) to Rs. 24109 Services Ltd. to provide
an additional crores); thereafter released on security for term loans of Rs. 21081.5 29.12.2016 and
again re-mortgaged crores sanctioned as a consortium to on 29.12.2016 (changing facility JAL.9
amount from Rs. 24109 crores to Rs.
23491 crores).
9 Hereinafter also referred to as ‘Property No. 1’ Mortgage deed dated 29.12.2016 for Initial
mortgage deed dated 167.9615 acres of land situated at 24.02.2015 released on 15.09.2015 Village
Tappal, Kansera and Jahangarh, and re-mortgaged on 15.09.2015 Tehsil Khair, District Aligarh,
Uttar (changing facility amount from Rs. Pradesh executed by JIL in favour of 3250 crores (appx.)
to Rs. 24109 Axis Trustee Services Ltd. to provide as crores); thereafter released on an additional
security for term loans of 29.12.2016 and again re-mortgaged Rs.21081.5 crores sanctioned by the
on 29.12.2016 (changing facility consortium to JAL.10 amount from Rs. 24109 crores to Rs.
23491 crores).
4.2. The exclusive mortgage transactions in favour of ICICI Bank Limited:
Property/transaction in question Previous transaction/s and flow thereof Mortgage
deed dated 07.03.2017 for Initial mortgage deed dated 158.1739 acres situated at
Village 12.05.2014 for 433.35 acres of land, Jaganpur and Aurangpur, Uttar followed
by release of land Pradesh, executed by JIL in favour of admeasuring 240 acres vide
release IDBI Trustee-ship Services Limited in deed dated 30.12.2015 along with the
capacity of security trustee for term release of land admeasuring 35.03 loan of
Rs.1200 crores granted by ICICI acres vide release deed dated Bank Limited to JALAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

against the facility 24.06.2016. Further release of agreement dated 25.05.2015.11
158.1739 acres of land vide release deed dated 07.03.2017 and thereafter
re-mortgaged on 07.03.2017.
Mortgage deed dated 07.03.2017 for Initial mortgage deed dated 151.0063 acres
situated at Village 12.05.2014 released on 07.03.2017 Jikarpur, Tehsil Khair, District
Aligarh, and re-mortgaged on 07.03.2017.
Uttar Pradesh, executed by JIL in favour of IDBI Trustee-ship Services Limited in the capacity of
security trustee for term loan of Rs.1200 crores 10 Hereinafter also referred to as ‘Property No. 2’ 11
Hereinafter also referred to as ‘Property No. 3’ granted by ICICI Bank Limited to JAL against the
facility agreement dated 25.05.2015.12 4.3. The exclusive mortgage transaction in favour of the
Standard Chartered Bank Limited:
Property/transaction in question Previous transaction/s and flow thereof Mortgage
deed dated 24.05.2016 for Initial mortgage deed dated 25.0040 acres of land situated
at Village 24.06.2009, extended by mortgage Sultanpur, Sector-128, Noida, District
deed dated 27.11.2012 (for Gautam Budh Nagar, Uttar Pradesh increased facility
amount of Rs. 1300 executed by JIL in favour of IDBI Trustee- crores as compared to
Rs. 900 ship Services Ltd, as additional security, crores earlier). against the facility
agreement dated Vide mortgage on 23.03.2013, 29.08.2012 between Standard
Chartered additional land admeasuring 25.0040 Bank and JAL of Rs.400 crores. The
acres was added in the original land security was further extended for facility II
parcel to secure increased facility for Rs.450 crores on 27.12.2012; for amount of Rs.
1750 crores as facility III for Rs.538.16 crores on compared to Rs. 1300 crores earlier
29.04.2015; for facility IV for Rs.81.84 against the facility agreement dated crores on
29.04.2015 and for working 29.08.2012 for an amount of Rs. 400 capital facility
Rs.297 crores on crores. Security further extended for 29.08.2012.13 Facilities II, III
and IV as mentioned in Column 1.
The extended mortgage deed dated 23.03.2013 was released vide release deed dated
04.11.2015 (changing facility amount from Rs.1750 crores to Rs. 1470 crores) and
re-mortgaged on 24.05.2016 (increasing facility amount from 1470 crores to Rs. 1767
crores).
12 Hereinafter also referred to as ‘Property No. 4’ 13 Hereinafter also referred to as
‘Property No. 5’ 4.4. The sixth transaction in question had been the exclusive
mortgage transaction in favour of State Bank of India that was not preceded by any
earlier transaction; the same had been as under:-
Mortgage deed dated 04.03.2016 for 90 acres of land situated at Village Chaugan
Tehsil Elmadpur, District Agra, Uttar Pradesh, executed by JIL in favour of State
Bank of India against the facility agreement dated 26.03.2015 granting Short Term
Loan Facility to JAL of Rs.1000 crores.14 4.5. Yet another transaction was questionedAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

by IRP as being avoidable but the Adjudicating Authority held the same to be not
falling within the relevant time as provided under Section 43 of the Code. The
particulars of this transaction are as follows:
Mortgage deed dated 12.05.2014 for 100 acres of land situated at Village Tappal,
Tehsil Khair, District Aligarh, Uttar Pradesh executed by JIL in favour of ICICI Bank
Limited against the facility agreement dated 12.12.2013 granting Term Loan of Rs.
1500 crores and overdraft amount of Rs. 175 crores to JAL.15 The relevant factual
and background aspects
5. Having taken note of the principal parties to the dispute and the transactions/properties involved,
but before dilating on the issues, we may briefly narrate the background in which the present CIRP
is underway as also the orders passed by this Court, for ensuring its completion in accordance with
law and towards the larger benefit of stakeholders.
14 Hereinafter also referred to as ‘Property No. 6’ 15 Hereinafter also referred to as ‘Property No. 7’
(As regards this description, it is pointed out on behalf of the respondent ICICI Bank that it had
been of ‘Term Loan of Rs. 1500 crores under the Corporate Rupee Loan Facility agreement and
General Conditions dated 12.12.2013 and mortgage deed was dated 10.03.2014’)
6. JAL is stated to be a public listed company with more than 5 lakh individual shareholders. In the
year 2003, JAL was awarded the rights for construction of an expressway from Noida to Agra. A
concession agreement was entered into with the Yamuna Expressway Industrial Development
Authority. Coming on the heels of this project, JIL was set up as a special purpose vehicle. Finance
was obtained from a consortium of banks against the partial mortgage of land acquired and a pledge
of 51% of the shareholding held by JAL. Housing plans were envisaged for the construction of real
estate projects in two locations of the land acquired, one in Wish Town, Noida and another in
Mirzapur. Several other aspects of the dealings by these companies, their creditors and other
stakeholders need not be dilated for the present purpose.
6.1. The crucial and relevant part of the matter is that IDBI Bank Limited instituted a petition under
Section 7 of the Code before the NCLT, seeking initiation of Corporate Insolvency Resolution
Process against JIL, while alleging that JIL had committed a default in repayment of its dues to the
tune of Rs. 526.11 crores. JIL filed its objections to the petition but later on, withdrew the objections
and furnished consent for resolution plan under the provisions of the Code. On 09.08.2017, NCLT
initiated the CIRP in respect of JIL. An order of moratorium was issued under Section 14 by which,
the institution of suits and continuation of pending proceedings, including execution proceedings
were prohibited and an Interim Resolution Professional was appointed. On 14.08.2017, IRP, in
pursuance of the order of NCLT, called for submissions of claims by financial creditors in Form-C,
by operational creditors in Form-B, by the workmen and employees in Form-E and by other
creditors in Form-F. On 16.08.2017, the Insolvency and Bankruptcy Board of India made an
amendment to its regulations and Regulation 9(a) was inserted to include the claims by other
creditors. On 18.08.2017, the Board released a press note that the home buyers could fill in Form-F
as they could not be treated at par with financial and operational creditors. 6.2. The aforesaidAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

position led to the proceedings in this Court that were dealt with in a batch of petitions led by Writ
Petition (Civil) No. 744 of 2017:
Chitra Sharma and Ors. v. Union of India and Ors. Several orders were passed by this
Court in the said batch of petitions from time to time, inter alia, to the effect that IRP
was permitted to take over management of JIL and was directed to ensure that
necessary provisions were made to protect the interests of home buyers. Various
orders were also made with directions to JAL, as holding company of JIL, for making
deposits in the Court, particularly looking to the claim of refund being made by some
of the home buyers. This Court also took note of the facts that CIRP commenced on
09.08.2017; the statutory period of 180 days for concluding the CIRP had come to an
end; and even the extended statutory period of 90 days also ended on 12.05.2018 but
then, by way of the Amendment Ordinance, 2018, the home buyers were accorded the
statutory recognition as financial creditors w.e.f. 06.06.2018.
While finally disposing of the matters on 09.08.2018, this Court took note of the
interest of home buyers as also the creditors of JIL and JAL, the status of proceedings
and the statutory provisions as then obtaining and ultimately issued the following
directions: -
“(i) In exercise of the power vested in this Court under Article 142 of the Constitution,
we direct that the initial period of 180 days for the conclusion of the CIRP in respect
of JIL shall commence from the date of this order. If it becomes necessary to apply
for a further extension of 90 days, we permit the NCLT to pass appropriate orders in
accordance with the provisions of the IBC;
(ii) We direct that a CoC shall be constituted afresh in accordance with the provisions of the
Insolvency and Bankruptcy (Amendment) Ordinance, 2018, more particularly the amended
definition of the expression “financial creditors”;
(iii) We permit the IRP to invite fresh expressions of interest for the submission of resolution plans
by applicants, in addition to the three short-listed bidders whose bids or, as the case may be, revised
bids may also be considered;
(iv) JIL/JAL and their promoters shall be ineligible to participate in the CIRP by virtue of the
provisions of Section 29A;
(v) RBI is allowed, in terms of its application to this Court to direct the banks to initiate corporate
insolvency resolution proceedings against JAL under the IBC;
(vi) The amount of Rs 750 crores which has been deposited in this Court by JAL/JIL shall together
with the interest accrued thereon be transferred to the NCLT and continue to remain invested and
shall abide by such directions as may be issued by the NCLT.” 6.3. It had been during pendency of
the aforesaid proceedings that the application leading to present appeals came to be filed by IRP onAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

06.02.2018, complaining against the transactions in question. However, before taking note of the
matters involved in such application filed by IRP and, for completion of the narration about the
orders passed by this Court, we may also point out that during the CIRP of JIL, an application came
to be made by IDBI bank, for excluding the period of pendency of the application for clarification
regarding the manner of counting of the votes of the concerned financial creditors, for the purpose
of the period of 270 days for completion of corporate insolvency resolution process but, during the
pendency of such application, NCLT, by its order dated 06.05.2019, called upon the authorities and
the representatives of allottees and others to file reply on the necessity to proceed further with CIRP
for considering the resolution plan received from the concerned bidder. The IDBI Bank assailed this
order of NCLT by way of an appeal before the NCLAT that came to be decided on 30.07.2019
whereby, NCLAT granted relief to exclude the period from 17.09.2018 to 04.06.2019 for the purpose
of counting 270 days of CIRP period and issued consequential directions. This led to further appeals
in this Court16, which were considered and decided on 06.11.2019.
6.3.1. In the order dated 06.11.2019, we took note of the fact that CIRP in relation to JIL stood
revived in view of the directions in Chitra Sharma (supra) as also the amendments brought about in
IBC. In the peculiar, rather extraordinary, situation obtaining in the matter, we passed the orders
under the plenary powers so as to ensure that an attempt was made for revival of the corporate
debtor JIL, lest it was exposed to liquidation process while taking 16 Being Civil Appeal No. 8437 of
2019 [@ D No. 27229 of 2019]: Jaiprakash Associates Ltd. & Anr. v. IDBI Bank Ltd. and connected
case note of the unanimity amongst the parties that liquidation of JIL must be eschewed; and while
also taking note of the time limit for completion of Insolvency Resolution Process as per third
proviso to Section 12(3), which came into effect from 16.08.2019. In the given circumstances, we
passed the following order for the purpose of substantial and complete justice to the parties and in
the interest of all the stakeholders:
“i) We direct the IRP to complete the CIRP within 90 days from today. In the first 45
days, it will be open to the IRP to invite revised resolution plan only from Suraksha
Realty and NBCC respectively, who were the final bidders and had submitted
resolution plan on the earlier occasion and place the revised plan(s) before the CoC, if
so required, after negotiations and submit report to the adjudicating authority NCLT
within such time. In the second phase of 45 days commencing from 21st December,
2019, margin is provided for removing any difficulty and to pass appropriate orders
thereon by the Adjudicating Authority.
ii) The pendency of any other application before the NCLT or NCLAT, as the case may
be, including any interim direction given therein shall be no impediment for the IRP
to receive and process the revised resolution plan from the abovenamed two bidders
and take it to its logical end as per the provisions of the I & B Code within the
extended timeline prescribed in terms of this order.
iii) We direct that the IRP shall not entertain any expression of interest (improved)
resolution plan individually or jointly or in concert with any other person, much less
ineligible in terms of Section 29A of the I & B Code.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

iv) These directions are issued in exceptional situation in the facts of the present case
and shall not be treated as a precedent.
v) This order may not be construed as having answered the questions of law raised in
both the appeals, including as recognition of the power of the NCLT / NCLAT to issue
direction or order not consistent with the statutory timelines and stipulations
specified in the I & B Code and Regulations framed thereunder.”17
17 It may also be noticed that by another order dated 03.02.2020, while accepting the reasons stated
in an application filed by the IRP pointing out various difficulties and unavoidable circumstances
which
7. Having thus referred to the orders previously passed in relation to the CIRP in question, we may,
for complete narration of the orders passed by this Court, also refer to the fact that in this batch of
appeals, the extensive arguments were finally concluded on 10.12.2019. Even while reserving the
orders, looking to the facts and circumstances of the case, we stayed the operation of the order
passed by NCLAT, insofar relating to the prayer of the lender-banks of JAL for treating them as
financial creditors of JIL. The relevant part of the order dated 10.12.2019 reads as under: -
“Civil Appeal @ Diary No(s). 32881/2019 These appeals take exception to the
decision of the National Company Law Appellate Tribunal allowing the appeal(s)
filed by the lender-Banks of Jayprakash Associates Limited (JAL) claiming to be
financial creditors(s) of Jaypee Infratech Limited (JIL). The National Company Law
Tribunal had rejected that claim but we find that in the impugned judgment, without
dealing with the reasons recorded by the National Company Law Tribunal, the
Appellate Tribunal allowed the appeal(s) filed by the stated lender- Banks(s), who
were claiming to be the financial creditor(s) of JIL.
After fully hearing counsel for the parties, prima facie, we are of view that
lender-Banks of JAL cannot be regarded as financial creditor(s) of JIL. We would
elaborate on this aspect in our final judgment. Be that as it may, it is appropriate that
we must stay the operation of the impugned judgment(s) of the Appellate Tribunal
lest any confusion occurs in the revival process of JIL and the constitution of
Committee of Creditors thereof, in view of the impugned order passed by the
National Company Law Appellate Tribunal. Ordered accordingly.
We clarify that the stay of operation is only in respect of order passed on the
application(s) moved by the lender-Bank(s) of JAL before the National Company Law
Appellate Tribunal for a declaration that they be regarded as financial creditor(s) of
JIL and included in the Committee of Creditors of JIL.” have delayed the culmination
of proposal for approval of resolution plan, though submitted within the time frame
prescribed by this Court, we had extended the time by four weeks for approval of the
resolution plan, in the proceedings now being dealt with by the Principal Bench of
NCLT at New Delhi.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

The Application by Interim Resolution Professional and the order passed by NCLT
8. Having thus referred to the orders already passed in relation to the CIRP in question, we may now
advert to the application filed by IRP forming subject- matter of the first issue involved in these
appeals.
9. The IRP, in terms of his duties under clause (j) of Section 25(2) of the Code18, made the
application under consideration before the Adjudicating Authority stating, inter alia, that the
corporate debtor was itself in dire need of funds; and was facing severe liquidity crunch to complete
the construction of projects and deliver flats to home buyers as well as to honour the payment
obligations to financial creditors, including the Fixed Deposit Holders. It was contended that JIL
could have sold/mortgaged its unencumbered land to raise funds to complete the construction of
flats in a timely manner and fulfil its obligation to its creditors and prevent value deterioration or
erosion or insolvency but then, the mortgages in question were created in a highly questionable
manner and in complete disregard to the interests of the creditors and stakeholders of the corporate
debtor. Also, that the mortgage of land was 18 The relevant parts of Section 25 read as under:
“Duties of resolution professional. - (1) It shall be the duty of the resolution
professional to preserve and protect the assets of the corporate debtor, including the
continued business operations of the corporate debtor.
(2) For the purposes of sub-section (1), the resolution professional shall undertake
the following actions, namely:-
*** *** ***
(j) file application for avoidance of transactions in accordance with Chapter III, if
any;
…” in nature of asset stripping and was entered with intent to defraud the creditors of the corporate
debtor without obtaining the approval of shareholders. 9.1. In opposition to the application, it was
contended that the financial position of the corporate debtor was very strong notwithstanding the
temporary financial crunch; that JAL was helping JIL in various ways and hence, creation of
impugned mortgages was not unusual, but merely reciprocal; and such reciprocal accommodation
cannot be termed without consideration. It was also contended that no transaction which was
permitted by law and entered into transparently could amount to ‘carrying on business for a
fraudulent purpose’. It was further contended that the impugned mortgages had not been created on
account of any antecedent debt liability owed by the corporate debtor; they had been within the
ordinary course of business of corporate debtor and the transferees; and were not within the
statutory period of one year and, therefore, Section 43 of IBC would not apply. It was maintained
that the transactions in question were reciprocal and could not be termed as without consideration
or undervalued. According to the contesting parties, when the essential jurisdictional conditions
were not satisfied, the provisions of Section 66 of IBC were not attracted.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

10. The NCLT, after having heard the parties and having scanned through the record, held that the
transactions in question were to defraud the lenders of the corporate debtor JIL, as 858 acres of
unencumbered land owned by the corporate debtor to secure the debt of the related party JAL was
mortgaged in the midst of the corporate debtor’s immense financial crunch, while continuing with
default towards the home buyers and financial creditors and after it had been declared as Non
Performing Asset19, in utter disregard to fiduciary duties and duty of care to the creditors; and
further that the mortgage of land was created without any counter guarantee from the related party
and with no other consideration being paid to the corporate debtor. The Tribunal was of the view
that at the time when the mortgage was created, the corporate debtor was already in default to its
lenders and it was unlikely that its lenders would have provided no-objection for creation of
mortgages to secure the debt of a related party as that would have compromised not only the
recovery of their dues but also the interests of thousands of home buyers waiting for their homes
with investment of their hard earned money. The Tribunal also observed that even though the
nominees of lenders attended the Board Meeting of the corporate debtor in which decision to
mortgage the land was taken, but that cannot be treated as approval or no-objection of lenders, as
the lenders invariably have covenants in the loan agreement that require their approval for creating
interest in favor of any one of the unencumbered assets of the borrower. Moreover, directors of the
corporate debtor (JIL) and the related party (JAL) were well aware of the fact that the corporate
debtor was in default and had been declared as NPA by several creditors. The Tribunal, thus, formed
the opinion that when the directors of the corporate debtor were fully aware that 19 ‘NPA’ for short
they were in the twilight zone and insolvency was imminent, they ought to have exercised due
diligence in minimizing the potential loss to the creditors but they entered into such transactions
which ex facie gave benefits to the related party JAL, with a clear intent to defraud the creditors of
JIL. The Tribunal further observed that the land in question could have been sold to generate cash
that would have been sufficient to complete the construction of flats and the home buyers are
directly and adversely affected by such a decision.
10.1. With respect to Section 43 of IBC, the NCLT held that the transaction of creating a security
interest by way of mortgage in favour of lenders of the third party (JAL) on the unencumbered land
of the corporate debtor without any consideration or counter guarantee cannot be treated as transfer
in the ordinary course of business or financial affairs of the corporate debtor. Further, it did not
benefit either the business or finances of the corporate debtor in any way and hence, was not
covered under ‘financial affairs’. The Tribunal held that the phrase under consideration cannot be
interpreted to mean that the ordinary course of business also includes the transferee’s ordinary
course of business because transferee can never do the transfer himself; and that the words ‘the
transfer made’ indicate that they relate to the transferor and not the transferee. As regards ‘relevant
time’ for the purpose of sub-section (4) of Section 43 of the Code20, the Tribunal observed that the
Code itself has 20 This “relevant time” for the purpose of avoidance of preferential transactions is
now commonly referred to as “look-back period”.
provided a retrospective effect to the provisions of Section 43(4)(a) wherein it is stated that ‘it is
given to a related party, during two years preceding the insolvency commencement date’. This,
according to NCLT, indicates that the retrospective effect is laid down in the legislation itself and
thus, the look-back period for the transactions was made dependent on the insolvencyAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

commencement date and not on the date when the Insolvency and Bankruptcy Code came into
effect (01.12.2016). The Tribunal, therefore, held that for transactions of a related party, the
look-back period was two years preceding the insolvency commencement date and hence, the
relevant period for examining the transactions in question would be from 10.08.2015 to 09.08.2017
(date of commencement of CIRP).
10.2. The Tribunal made in-depth analysis of the facts of the case, particularly those related with the
transactions in question as also the provisions of law applicable and, while rejecting the contentions
urged on behalf of the opposing parties, including JAL, observed and held as under:
“After the elaborate discussion, we have decided that impugned transactions are
preferential transactions as defined in the subsection (2)(a) of Section 43 of
insolvency and bankruptcy code 2016. We have found that corporate debtor Jaypee
Infratech Ltd (JIL) has by way of mortgage of unencumbered land created security
interest in favour of lenders of the Jaiprakash Associates Ltd. (JAL), which happens
to be the holding company of JIL, without any consideration. We have also found
that the corporate debtor was facing liquidity crunch and their accounts were
declared as NPA and even after formation of Joint Lender Forum, without obtaining
approval from Joint Lender Forum, unencumbered land of the corporate debtor has
been mortgaged in favour of lenders of JAL. There by this transfer has the effect of
putting the JAL, one of the creditors of JIL in a beneficial position than it would have
been in the event of distribution of assets being made by section 53 of the code.
The said mortgage of immovable properties, i.e. of the unencumbered land of the corporate debtor
has been made without any consideration to the corporate debtor. Therefore the said transaction is
covered under the umbrella of Sec 45(1) of the Code and will be treated as an undervalued
transaction as defined under section 45 of the Code.
*** *** *** In this case, we have found that impugned transactions are covered under preferential
transactions as defined in section 43(2)
(a) of the Code. Therefore, it cannot be said that section 45 does not apply for these transactions.
The impugned mortgage of unencumbered land parcels of the Corporate Debtor in favour of lenders
of the JAL to create a security interest are transactions between the Corporate Debtor, lenders of
JAL and JAL, who happens to be an Operational Creditor of the Corporate Debtor.
It is true that the collateral security is common practice in loan transactions. It is on record that in
this case, the Corporate Debtor was under liquidity crunch and its accounts were declared NPA by
LIC and other creditors. The Joint Lender Forum was formed to deal with the situation. But the
Corporate Debtor entered into the transaction even without taking prior approval of Joint Lender
Forum and mortgaged its unencumbered land in favour of the lenders of the JAL.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

In the circumstances stated above it is clear that the impugned preferential transactions are also
undervalued transactions and covered under section 45(1) of the Code. It is also clear that these
transactions are undertaken during the relevant period of 2 years from the date of initiation of
Corporate Insolvency Process as provided under section 46(1)(ii) of the Code. Therefore, this issue is
also decided in positive, in favour of applicant Resolution Professional and against the Corporate
Debtor.
In view of the above, it is clear that the mortgage of land of JIL in favour of lenders of JAL, amounts
to transfer of interest in property of JIL for the benefit of its creditor i.e. JAL and putting it in a
beneficial position vis-à-vis other creditors is a preferential transactions U/s 43(2)(a) & (b).
The transactions were executed within the look back period of two years before the commencement
of Insolvency proceeding and is therefore covered U/s 43(4)(a). Further, transaction cannot be
treated is in ordinary course of business or financial affairs of Corporate Debtor and is not excluded
U/s 43(3).” 10.3. The Tribunal concluded in its order as follows:
“On the above basis, it is clear that the company application filed by the Resolution
Applicant deserves to be allowed. Hence, is allowed.
ORDER The company application filed by the Resolution Professional under Sec. 66,
43 & 45 of the Insolvency and Bankruptcy 2016 is allowed. The impugned
transactions, details of which are given in the schedule of the judgment are declared
as fraudulent, preferential and undervalued transactions as defined under section 66,
43 and 45 of the Code respectively.
Transactions given in the following schedule of property have been found as
preferential, undervalued and fraudulent, therefore, we pass the order for release and
discharge of the security interest created by the Corporate Debtor in favour of lenders
of the Jaiprakash Associates Ltd. under the provision of Section 44(c) of the
Insolvency and Bankruptcy Code 2016. We also pass an order under Section 48(a) of
the Code that the properties mortgaged by way of preferential and undervalued
transactions shall from now on be deemed to be vested in the Corporate Debtor.”21
Appeals before NCLAT: the impugned order
11. Assailing the aforesaid order passed by NCLT accepting the application of IRP in relation to six of
the mortgage transactions, the aggrieved parties filed separate appeals before the Appellate
Tribunal, the NCLAT. The Appellate Tribunal took note of the facts of the case and the rival
contentions and 21 In the schedule to the order aforesaid, NCLT gave out the description of six
transaction with particulars of the properties which were treated as preferential, undervalued and
fraudulent and also gave the description of one transaction that was not coming within the ambit of
‘relevant time’ per Section 43 of the Code. (as fully taken note of in paragraph 4 and its
sub-paragraphs under the heading ‘Transactions in question’ ibid.).
proceeded to upturn the order passed by NCLT on the considerations as indicated infra.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

11.1. As regards the assertion of IRP that the transactions in question were preferential transactions
within the relevant time as envisaged by Section 43 of the Code, the NCLAT observed that the
corporate debtor had created interest over its property, but such interest had not been created in
favour of any creditor or a surety or a guarantor for or on account of an antecedent financial debt or
operational debt or other liabilities owed by the corporate debtor and hence, Section 43(2)(a) of the
Code was not attracted. It was further observed that the mortgages in question were made in the
ordinary course of business and financial affairs of the transferees, ruling out the applicability of
Section 43 as such and hence, the Adjudicating Authority had no power to pass the order under
Section 44 of the Code. The Appellate Tribunal observed and held, inter alia, as follows:
“62. In the present case, the ‘Corporate Debtor’ has created interest on the property
of the ‘Corporate Debtor’, but such interest has not been created in favour of any
creditor or a surety or a guarantor for or on account of an antecedent financial debt
or operational debt or other liabilities owed by the ‘Corporate Debtor’.
63. The aforesaid interest on the property of the ‘Corporate Debtor’ has been created
in all these cases with regard to financial debt given by the Appellants to ‘Jaiprakash
Associates Ltd.’, which is not the ‘Corporate Debtor’.
64. Thus, it is clear that the interest on the property of the ‘Corporate Debtor’ has not
been created in favour of the Appellants- ‘Financial Creditors’ of an antecedent
financial debt of the Appellants owed by the ‘Jaypee Infratech Ltd.’ (‘Corporate
Debtor’). Therefore, we hold that clause (a) of sub-section (2) of Section 43 is not
attracted in any of the case of the Appellants Bank, thereby none of the Appellants
Bank come within the meaning of ‘deemed to have given a preference’, as used in
Section 43. Therefore, the mortgage(s) created in their favour cannot be annulled on
the ground of preferential transaction in terms of Section 43 (2) (a) of the ‘I&B Code’.
65. Clause (b) of sub-section(2) of Section 43 relates to transfer under clause (a) of
sub-section (2) of Section 43, which in effect puts such creditor or a surety or a
guarantor in a beneficial position than it would have been in the event of a
distribution of assets being made in accordance with Section 53. As clause (a) of
sub-section (2) of Section 43 is not attracted, the question of applicability of clause
(b) of sub-section (2) of Section 43 does not arise.
66. Apart from the aforesaid position of law in respect of mortgage, in question, as
per sub-section (3) of Section 43, for the purposes of sub-section (2), “a preference
shall not include the transfer made in the ordinary course of the business or financial
affairs of the ‘Corporate Debtor’ or the transferee”. The mortgages in question which
were made in favour of the Appellants-Banks and Financial Institutions have been
made in ordinary course of business and financial affairs of the transferee, as
apparent from the relevant facts.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

67. Therefore, we hold that Section 43 is not attracted to any of the
transaction/mortgage(s) made in favour of the Appellants.” 11.2. The Appellate
Tribunal further proceeded to hold that the provisions of Section 45 of Code, for
avoidance of undervalued transactions, were not applicable in relation to the
transactions in question while observing as under:-
“71. For holding a transaction undervalued, the ‘Resolution Professional’/‘Liquidator’
is required to examine the transactions which were made during ‘the relevant period’
as prescribed under Section 46, if any of it is undervalued. As per sub-section (2) of
Section 45, the transaction shall be considered ‘undervalued’ ‘where the ‘Corporate
Debtor’ makes a gift to a person or enters into a transaction with a person which
involves the transfer of one or more assets by the ‘Corporate Debtor’ for a
consideration the value of which is significantly less than the value of the
consideration provided by the ‘Corporate Debtor’ and such transaction has not taken
place in the ordinary course of business of the ‘Corporate Debtor’.’
72. In these appeals, we find that the transactions as has been made i.e. mortgage(s)
in favour of the Appellants as and when made against the amount payable by
‘Jaiprakash Associates Limited’ (borrower), the amount is not payable by the
‘Corporate Debtor’. Therefore, clause (a) of sub-section (2) of Section 45 is not
attracted. For the same very reason, clause (b) of sub-section (2) of Section 43 or
Section 45 cannot be made applicable with regard to transaction in question which
are not related to any payment due from the ‘Corporate Debtor’.
73. As Section 44 is not attracted, it is not necessary to notice Section 46 which is not
attracted and, therefore, the Adjudicating Authority has no power to pass any order
under Section 48 of the ‘I&B Code’. ” 11.3. With respect to Section 66 of the Code
dealing with fraudulent trading or wrongful trading, the Appellate Tribunal observed
that the corporate debtor, being one of the group company, like a guarantor, had
executed mortgage deeds in favour of the lender banks and financial institutions; and
the transactions were in the ordinary course of business of the corporate debtor.
Thus, according to NCLAT, in the absence of any contrary evidence to show that they were made to
defraud the creditors of the corporate debtor or for any fraudulent purpose, it was not open to the
Adjudicating Authority to hold that the mortgage deeds in question were made by way of
transactions within the meaning of ‘fraudulent trading’ or ‘wrongful trading’ under Section 66. The
Appellate Tribunal held,-
“76. In the present case, we have noticed that the transactions in question i.e. mortgage(s) were
made in favour of the ‘Banks and Financial Institutions’ by the ‘Corporate Debtor’ (‘Jaypee Infratech
Limited’) in the ordinary course of business of the ‘Corporate Debtor’. The Appellants-Banks and
Financial Institutions have given loans to the holding Company namely-‘Jaiprakash Associates
Limited’. The ‘Corporate Debtor’ being one of the group company, like a guarantor, executed
mortgage deed(s) in favour of the Appellants-‘Banks and Financial Institutions’. We have seen thatAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

none of the transactions were ‘preferential transaction’ or ‘undervalued transaction’. It has not been
alleged that the transactions, in question, were made to defraud the creditors in terms of Section 49
so allegation has been made that such transactions amount to ‘extortionate credit’ as defined under
Section 50. Therefore, the Adjudicating Authority in absence of any such finding is not empowered
to pass order under Section
51. Further, as we have held that the transactions were made in the ordinary course of business in
absence of any contrary evidence to show that they were made to defraud the creditors of the
‘Corporate Debtor’ or for any fraudulent purpose, on mere allegation made by the ‘Resolution
Professional’, it was not open to the Adjudicating Authority to hold that mortgage deeds, in
question, were made by way of transactions which come within the meaning of ‘fraudulent trading’
or ‘wrongful trading’ under Section 66.” 11.4. The Appellate Tribunal, therefore, allowed the appeals
and set aside the impugned order passed by NCLT on 16.05.2018 in so far relating to the lenders in
question in the following:-
“80. For the reasons aforesaid, we set aside the impugned order dated 16th May,
2018 so far it relates to the Appellants. In view of such findings, the Appellants-‘Axis
Bank Ltd’, ‘Standard Chartered Bank’, ‘ICICI Bank Ltd.’, ‘State Bank of India’, ‘Jai
Prakash Associates Ltd.’, ‘Bank of Maharashtra’, ‘United Bank of India’, ‘Central Bank
of India’, ‘UCO Bank’, ‘Karur Vyasa Bank (P) Ltd.’, ‘L&T Infrastructure Finance
Company Ltd.’, ‘Canara Bank’, ‘Karnataka Bank Ltd.’, ‘IFCI Ltd.’, ‘ Allahabad Bank’,
‘Jammu & Kashmir Bank’, and ‘The South Indian Bank Ltd.’ are entitled to exercise
their rights under the ‘I&B Code’.
81. All the appeals are allowed. However, we make it clear that we have not made any
observations with regard to the Promoters or Directors in absence of any appeal
preferred on their behalf. No costs.” The relevant provisions
12. For comprehension of the subject-matter and appropriate dealing with the issues involved,
before proceeding further, suitable it would be to take note of the relevant statutory provisions.
12.1. It may be observed that while generally, the expressions used in the Code are defined in Section
3 thereof but then, the expressions employed for the purpose of Part II of the Code, dealing with
insolvency resolution and liquidation of corporate persons, are defined in Section 5 thereof. The
relevant definitions as occurring in Sections 3 and 5 are as under:-
“Section 3(4): "charge" means an interest or lien created on the property or assets of
any person or any of its undertakings or both, as the case may be, as security and
includes a mortgage; Section 3(6): "claim" means--
(a) a right to payment, whether or not such right is reduced to judgment, fixed,
disputed, undisputed, legal, equitable, secured or unsecured;Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(b) right to remedy for breach of contract under any law for the time being in force, if
such breach gives rise to a right to payment, whether or not such right is reduced to
judgment, fixed, matured, unmatured, disputed, undisputed, secured or unsecured;
Section 3(8): "corporate debtor" means a corporate person who owes a debt to any person;
Section 3(10): "creditor" means any person to whom a debt is owed and includes a financial creditor,
an operational creditor, a secured creditor, an unsecured creditor and a decree-holder; Section
3(11): "debt" means a liability or obligation in respect of a claim which is due from any person and
includes a financial debt and operational debt;
Section 3(12): "default" means non-payment of debt when whole or any part or instalment of the
amount of debt has become due and payable and is not paid by the debtor or the corporate debtor,
as the case may be;
Section 3(30): "secured creditor" means a creditor in favour of whom security interest is created;
Section 3(31): "security interest" means right, title or interest or a claim to property, created in
favour of, or provided for a secured creditor by a transaction which secures payment or performance
of an obligation and includes mortgage, charge, hypothecation, assignment and encumbrance or any
other agreement or arrangement securing payment or performance of any obligation of any person:
Provided that security interest shall not include a performance guarantee;
Section 3(33): "transaction" includes a agreement or arrangement in writing for the
transfer of assets, or funds, goods or services, from or to the corporate debtor;
Section 3(34): "transfer" includes sale, purchase, exchange, mortgage, pledge, gift,
loan or any other form of transfer of right, title, possession or lien;
Section 3(35): "transfer of property" means transfer of any property and includes a
transfer of any interest in the property and creation of any charge upon such
property;
Section 5(5A): "corporate guarantor" means a corporate person who is the surety in a
contract of guarantee to a corporate debtor; Section 5(7): "financial creditor" means
any person to whom a financial debt is owed and includes a person to whom such
debt has been legally assigned or transferred to;
Section 5(8): "financial debt" means a debt alongwith interest, if any, which is
disbursed against the consideration for the time value of money and includes-
(a) money borrowed against the payment of interest;Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(b) any amount raised by acceptance under any acceptance credit facility or its
de-materialised equivalent;
(c) any amount raised pursuant to any note purchase facility or the issue of bonds,
notes, debentures, loan stock or any similar instrument;
(d) the amount of any liability in respect of any lease or hire purchase contract which
is deemed as a finance or capital lease under the Indian Accounting Standards or
such other accounting standards as may be prescribed;
(e) receivables sold or discounted other than any receivables sold on non-recourse
basis;
(f) any amount raised under any other transaction, including any forward sale or
purchase agreement, having the commercial effect of a borrowing;
Explanation.-- For the purposes of this sub-clause,--
(i) any amount raised from an allottee under a real estate project shall be deemed to
be an amount having the commercial effect of a borrowing; and
(ii) the expressions, "allottee" and "real estate project" shall have the meanings
respectively assigned to them in clauses (d) and (zn) of section 2 of the Real Estate
(Regulation and Development) Act, 2016 (16 of 2016);22
(g) any derivative transaction entered into in connection with protection against or
benefit from fluctuation in any rate or price and for calculating the value of any
derivative transaction, only the market value of such transaction shall be taken into
account;
(h) any counter-indemnity obligation in respect of a guarantee, indemnity, bond,
documentary letter of credit or any other instrument issued by a bank or financial
institution;
(i) the amount of any liability in respect of any of the guarantee or indemnity for any
of the items referred to in sub-clauses (a) to
(h) of this clause;
Section 5(20): “operational creditor” means a person to whom an operational debt is owed and
includes any person to whom such debt has been legally assigned or transferred;
Section 5(21): “operational debt” means a claim in respect of the provision of goods or services
including employment or a debt in respect of the payment of dues arising under any law for the timeAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

being in force and payable to the Central Government, any State Government or any local authority;
Section 5(24): “related party”, in relation to a corporate debtor, means – 22 This explanation was
inserted w.e.f. 06.06.2018.
(a) a director or partner of the corporate debtor or a relative of a director or partner of the corporate
debtor;
(b) a key managerial personnel of the corporate debtor or a relative of a key managerial personnel of
the corporate debtor;
(c) a limited liability partnership or a partnership firm in which a director, partner, or manager of
the corporate debtor or his relative is a partner;
(d) a private company in which a director, partner or manager of the corporate debtor is a director
and holds along with his relatives, more than two per cent of its share capital;
(e) a public company in which a director, partner or manager of the corporate debtor is a director
and holds along with relatives, more than two per cent of its paid-up share capital;
(f) anybody corporate whose board of directors, managing director or manager, in the ordinary
course of business, acts on the advice, directions or instructions of a director, partner or manager of
the corporate debtor;
(g) any limited liability partnership or a partnership firm whose partners or employees in the
ordinary course of business, acts on the advice, directions or instructions of a director, partner or
manager of the corporate debtor;
(h) any person on whose advice, directions or instructions, a director, partner or manager of the
corporate debtor is accustomed to act;
(i) a body corporate which is a holding, subsidiary or an associate company of the corporate debtor,
or a subsidiary of a holding company to which the corporate debtor is a subsidiary;
(j) any person who controls more than twenty per cent of voting rights in the corporate debtor on
account of ownership or a voting agreement;
(k) any person in whom the corporate debtor controls more than twenty per cent of voting rights on
account of ownership or a voting agreement;
(l) any person who can control the composition of the board of directors or corresponding governing
body of the corporate debtor;
(m) any person who is associated with the corporate debtor on account of ---Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(i) participation in policy making process of the corporate debtor; or
(ii) having more than two directors in common between the corporate debtor and such person; or
(iii) interchange of managerial personnel between the corporate debtor and such person; or
(iv) provision of essential technical information to, or from, the corporate debtor;” 12.2. The concept
and consequences of preferential transactions at a relevant time are provided in Sections 43 and 44
of the Code, which may also be usefully extracted as follows:-
“Section 43. Preferential transactions and relevant time.-
(1) Where the liquidator or the resolution professional, as the case may be, is of the
opinion that the corporate debtor has at a relevant time given a preference in such
transactions and in such manner as laid down in sub-section (2) to any persons as
referred to in sub-section (4), he shall apply to the Adjudicating Authority for
avoidance of preferential transactions and for, one or more of the orders referred to
in section 44.
(2) A corporate debtor shall be deemed to have given a preference, if—
(a) there is a transfer of property or an interest thereof of the corporate debtor for the
benefit of a creditor or a surety or a guarantor for or on account of an antecedent
financial debt or operational debt or other liabilities owed by the corporate debtor;
and
(b) the transfer under clause (a) has the effect of putting such creditor or a surety or a
guarantor in a beneficial position than it would have been in the event of a
distribution of assets being made in accordance with section 53.
(3) For the purposes of sub-section (2), a preference shall not include the following
transfers—
(a) transfer made in the ordinary course of the business or financial affairs of the
corporate debtor or the transferee;
(b) any transfer creating a security interest in property acquired by the corporate
debtor to the extent that—
(i) such security interest secures new value and was given at the time of or after the
signing of a security agreement that contains a description of such property as
security interest, and was used by corporate debtor to acquire such property; andAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(ii) such transfer was registered with an information utility on or before thirty days
after the corporate debtor receives possession of such property:
Provided that any transfer made in pursuance of the order of a court shall not,
preclude such transfer to be deemed as giving of preference by the corporate debtor.
Explanation.—For the purpose of sub-section (3) of this section, "new value" means
money or its worth in goods, services, or new credit, or release by the transferee of
property previously transferred to such transferee in a transaction that is neither void
nor voidable by the liquidator or the resolution professional under this Code,
including proceeds of such property, but does not include a financial debt or
operational debt substituted for existing financial debt or operational debt.
(4) A preference shall be deemed to be given at a relevant time, if —
(a) It is given to a related party (other than by reason only of being an employee),
during the period of two years preceding the insolvency commencement date; or
(b) a preference is given to a person other than a related party during the period of
one year preceding the insolvency commencement date.
Section 44. Orders in case of preferential transactions.- (1) The Adjudicating
Authority, may, on an application made by the resolution professional or liquidator
under sub-section (1) of section 43, by an order:
(a) require any property transferred in connection with the giving of the preference to
be vested in the corporate debtor;
(b) require any property to be so vested if it represents the application either of the
proceeds of sale of property so transferred or of money so transferred;
(c) release or discharge (in whole or in part) of any security interest created by the
corporate debtor;
(d) require any person to pay such sums in respect of benefits received by him from
the corporate debtor, such sums to the liquidator or the resolution professional, as
the Adjudicating Authority may direct;
(e) direct any guarantor, whose financial debts or operational debts owed to any
person were released or discharged (in whole or in part) by the giving of the
preference, to be under such new or revived financial debts or operational debts to
that person as the Adjudicating Authority deems appropriate;Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(f) direct for providing security or charge on any property for the discharge of any
financial debt or operational debt under the order, and such security or charge to
have the same priority as a security or charge released or discharged wholly or in part
by the giving of the preference; and
(g) direct for providing the extent to which any person whose property is so vested in
the corporate debtor, or on whom financial debts or operational debts are imposed by
the order, are to be proved in the liquidation or the corporate insolvency resolution
process for financial debts or operational debts which arose from, or were released or
discharged wholly or in part by the giving of the preference:
Provided that an order under this section shall not—
(a) affect any interest in property which was acquired from a person other than the
corporate debtor or any interest derived from such interest and was acquired in good
faith and for value;
(b) require a person, who received a benefit from the preferential transaction in good
faith and for value to pay a sum to the liquidator or the resolution professional.
Explanation I.-For the purpose of this section, it is clarified that where a person, who has acquired
an interest in property from another person other than the corporate debtor, or who has received a
benefit from the preference or such another person to whom the corporate debtor gave the
preference, —
(i) had sufficient information of the initiation or commencement of insolvency resolution process of
the corporate debtor;
(ii) is a related party, it shall be presumed that the interest was acquired or the benefit was received
otherwise than in good faith unless the contrary is shown.
Explanation II.-A person shall be deemed to have sufficient information or opportunity to avail such
information if a public announcement regarding the corporate insolvency resolution process has
been made under section 13.” 12.3. As the transactions in question are the mortgage(s) of the assets
of corporate debtor JIL, the concept and connotations of mortgage, as occurring in Section 58 of the
Transfer of Property Act, 188223, could also be usefully noticed as under:-
23 Hereinafter also referred to as ’the Transfer of Property Act’.
“58. “Mortgage”, “mortgagor”, “mortgagee”, “mortgage- money” and “mortgage-deed” defined.-
(a) A mortgage is the transfer of an interest in specific immoveable property for the purpose of
securing the payment of money advanced or to be advanced by way of loan, an existing or future
debt, or the performance of an engagement which may give rise to a pecuniary liability.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

The transferor is called a mortgagor, the transferee a mortgagee; the principal money and interest of
which payment is secured for the time being are called the mortgage-money, and the instrument (if
any) by which the transfer is effected is called a mortgage- deed.
(b) Simple mortgage.-Where, without delivering possession of the mortgaged property, the
mortgagor binds himself personally to pay the mortgage-money, and agrees, expressly or impliedly,
that, in the event of his failing to pay according to his contract, the mortgagee shall have a right to
cause the mortgaged property to be sold and the proceeds of sale to be applied, so far as may be
necessary, in payment of the mortgage-money, the transaction is called a simple mortgage and the
mortgagee a simple mortgagee.
(c) Mortgage by conditional sale.-Where, the mortgagor ostensibly sells the mortgaged property-
on condition that on default of payment of the mortgage- money on a certain date the sale shall
become absolute, or on condition that on such payment being made the sale shall become void, or
on condition that on such payment being made the buyer shall transfer the property to the seller, the
transaction is called a mortgage by conditional sale and the mortgagee a mortgagee by conditional
sale:
Provided that no such transaction shall be deemed to be a mortgage, unless the
condition is embodied in the document which effects or purports to effect the sale.
(d) Usufructuary mortgage.-Where the mortgagor delivers possession or expressly or
by implication binds himself to deliver possession of the mortgaged property to the
mortgagee, and authorises him to retain such possession until payment of the
mortgage-money, and to receive the rents and profits accruing from the property or
any part of such rents and profits and to appropriate the same in lieu of interest, or in
payment of the mortgage-money, or partly in lieu of interest or partly in payment of
the mortgage-money, the transaction is called an usufructuary mortgage and the
mortgagee an usufructuary mortgagee.
(e) English mortgage.-Where the mortgagor binds himself to repay the
mortgage-money on a certain date, and transfers the mortgaged property absolutely
to the mortgagee, but subject to a proviso that he will re-transfer it to the mortgagor
upon payment of the mortgage-money as agreed, the transaction is called an English
mortgage.
(f) Mortgage by deposit of title-deeds.-Where a person in any of the following towns,
namely, the towns of Calcutta, Madras, and Bombay, and in any other town which the
State Government concerned may, by notification in the Official Gazette, specify in
this behalf, delivers to a creditor or his agent documents of title to immoveable
property, with intent to create a security thereon, the transaction is called a mortgage
by deposit of title-deeds.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(g) Anomalous mortgage.- A mortgage which is not a simple mortgage, a mortgage by
conditional sale, an usufructuary mortgage, an English mortgage or a mortgage by
deposit of title-
deeds within the meaning of this section is called an anomalous mortgage.” 12.4. The provisions
contained in Sections 124, 126 and 127 of the Indian Contract Act, 187224 shall also have bearing on
the issues at hand and hence, the same may also be noted as follows:-
“124. “Contract of indemnity” defined.- A contract by which one party promises to
save the other from loss caused to him by the conduct of the promisor himself, or by
the conduct of any other person, is called a “contract of indemnity.”
126. ‘Contract of guarantee’, ‘surety’, ‘principal debtor’ and ‘creditor’ – A ‘contract of
guarantee’ is a contract to perform the promise, or discharge the liability, of a third
person in case of his default. The person who gives the guarantee is called the
‘surety’;
the person in respect of whose default the guarantee is given is called the ‘principal debtor’, and the
person to whom the guarantee is given is called the ‘creditor’. A guarantee may be either oral or
written.
127. Consideration for guarantee.- Anything done, or any promise made, for the benefit of the
principal debtor, may be a sufficient consideration to the surety for giving the guarantee.” 24
Hereinafter also referred to as ‘the Contract Act’.
WHETHER THE TRANSACTIONS IN QUESTION ARE PREFERENTIAL Broad features of rival
contentions and submissions
13. As noticed, being aggrieved by the order so passed by NCLAT, three sets of parties have
preferred these appeals. Multidimensional and wide- ranging submissions have been made by
learned counsel for the respective parties, raising the issues as to whether the transactions in
question could be said to be preferential and/or undervalued and/or fraudulent, essentially within
the meaning of Sections 43, 45, 49 and 66 of the Code. Elaborate submissions have also been made
raising the issue as to whether the lenders of JAL, in whose favour the security interest by way of
impugned transactions were created, would fall in the category of ‘financial creditors’ of the
corporate debtor JIL.
14. Having regard to the overall circumstances, appropriate it would be to deal, at the first, with the
contentions related with the issue as to whether the transactions in question are preferential
transactions within the meaning of Section 43 of the Code. We may briefly summarize the
contentions of the appellants, with particular focus on this issue as infra:
Interim Resolution Professional for Jaypee Infratech Limited – the appellant In C.A.
No. 8512-8527 of 2019 14.1. It has been contended on behalf of the appellant InterimAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

Resolution Professional, who moved the application for avoidance of the transactions
in question, that the impugned transactions have the effect of putting JAL, which is
an equity shareholder and an operational creditor (for an amount of Rs.
261.77 crores) of the corporate debtor JIL, in a beneficial position than it would have
been in the event of distribution of assets under Section 53 of the Code vis-à-vis other
creditors; and that if the transactions are held to be valid, the liability of JAL towards
its own creditors gets secured and becomes realisable from the value of the
mortgaged properties whereby, JAL’s liabilities are reduced and JAL gets benefitted
in exclusion of creditors of the corporate debtor JIL. It is submitted that, in the event
of distribution of assets in terms of Section 53 of IBC, for the sake of argument, even
if JAL is to get full value of its shares (Rs. 995 crores), such amount is significantly
less than the value of assets which have been mortgaged by way of impugned
transactions for satisfaction of debts owed by JAL to its lenders.
14.1.1. It is submitted on behalf of the appellant Interim Resolution Profession that
the assets in question were released from the earlier mortgages and fresh mortgages
were created during the look-back period with increased/enhanced amount of
facilities as provided under each individual transaction. The said so-
called re-mortgage essentially amounts to a fresh mortgage within the relevant time of two years
before the date of commencement of CIRP and was not done in the ordinary course of business of
JIL and hence, is hit by Section 43 of the Code.
14.1.2. It is further urged that in the exclusionary clause under Section 43(3)
(a), which pertains to the transfer being made in the ordinary course of the business or financial
affairs of the corporate debtor or the transferee, the expression “or” will have to be read
conjunctively and not in the alternative. That is to say, the word “or” will have to be read as “and”.
This is because if “or” is read textually, it would mean that an overwhelming majority of transactions
like the present one, whereby banks who would accept the security interest over properties
belonging to a third party, after disbursing financial facilities to its loan, would get out of the net of
“preferential transactions”, even if the transfer in question is not made in the ordinary course of
business of the corporate debtor. It is submitted that the intention of legislature behind enacting a
provision like Section 43 is that preferential transactions are avoided so that such assets would be
available either with the resolution professional or with the liquidator, as the case may be, to put the
corporate debtor back on its wheels or if that is not possible, to ensure that the creditors of the
corporate debtor get a fair deal. With reference to the decisions of this Court in State of Bombay v.
R.M.D. Chamarbaugwala and Anr.: 1957 SCR 874 and Mazagaon Dock Ltd v. Commissioner of
Income-Tax and Excess Profits Tax: 1959 SCR 848, it is submitted that on the well-known cannons
of interpretation, “or” could be read as “and” if it is warranted to bring the provision in question in
sync with the intention of the legislature which is to be discerned.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

14.1.3.It is contended that Section 43 ought to be read keeping in mind the intention of the
legislature in introducing such provision, which had been to protect the creditors against siphoning
away of corporate assets by the management of the company, who have special knowledge of the
company’s financial troubles by virtue of its position.
India Infrastructure Finance Company Limited – the appellant in C.A.@ D No. 32881 of 2019.
14.2. This appellant is one of the entities who has advanced loan to JIL and has preferred appeal
with permission, assailing the order passed by NCLAT and maintaining, inter alia, that in any case,
the lenders of JAL cannot be taken as ‘financial creditors’ of JIL. While referring to the theory
behind the provisions for avoidance of certain transactions, it is submitted on behalf of this
appellant that the Court should consider substance rather than legal form in evaluating the true
economic effect of a transaction or a set of transactions in applying the relevant provisions. On
behalf of this appellant, the following submissions have been made in regard to the relevant
expressions and phrases occurring in the provisions under consideration:
Ordinary Course of Business 14.2.1. It is submitted that mortgages could not have
been made in the ordinary course of business of the corporate debtor JIL, as it is
difficult to fathom why a subsidiary would furnish security to its parent company in
the ordinary course and, on the contrary, it is the parent company which at times
furnishes security on behalf of its subsidiary since it derives economic value from the
subsidiary. According to the appellant, it is difficult to appreciate that when the
corporate debtor JIL was itself reeling under financial stress, why it would routinely
undertake to secure the indebtedness of JAL by furnishing such high valued
securities and that too when the amount of debt secured by way of mortgaging the
assets of the corporate debtor increased from Rs. 3,000 crores to approximately Rs.
24,000 crores and the number of creditors also went up from 2 to 24 with respect to
the consortium mortgage. It is submitted that even though creation of third party
security is a normal practice, the creation of every third party security cannot be
always deemed to have been done in the ordinary course of business; that such
‘ordinary course’ has to be determined under the circumstances when such
transactions were entered into; and, considering that JIL was declared NPA and had
defaulted on its indebtedness to some of its lenders, securing of JAL’s indebtedness
under such circumstances cannot be construed to have been done in the ordinary
course of business of the corporate debtor JIL. The learned counsel for the appellant
has referred, inter alia, to the decision in Downs Distributing Co Pty Ltd v. Associated
Blue Star Stores Pty Ltd (in liq): (1948) 76 CLR 463.
Relevant Period and Related Party 14.2.2.It is further submitted that the term ‘transaction’ under
the Code includes an agreement or arrangement in writing for the transfer of assets, or funds, goods
or services from or to the corporate debtor. The use of the word ‘include’ would signify its natural
import and is to be given a wide interpretation. It is submitted that as JAL was not only ad idem to
the terms of the transaction but was also the beneficiary thereof, it cannot be said that the
transaction was only between the corporate debtor and the lenders of JAL; rather, the transactionAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

was with a ‘related party’ and the look-back period would be two years.
Home buyers – the appellants in C.A. No. 6777-97/2019 14.3. On behalf of the home buyers, who
have invested in the projects of the corporate debtor and whose interests would be diluted if the
impugned transactions are upheld, the flow of transactions in question has been referred and
essentially, the same contentions have been urged with respect to Section 43 of the Code, with
reliance on the decision in Downs Distributing Co (supra), that the impugned transactions were not
made in the ordinary course of business of the corporate debtor JIL; and had been preferential
transactions, putting JAL in a beneficial position at the cost of bona fide creditors of JIL, including
the home buyers. We are not re-narrating all their contentions to avoid repetition. However, we may
observe that to substantiate their arguments with respect to Section 43 of the Code, on behalf of
these appellants, reliance is also placed on the interim report of the Bankruptcy Law Reforms
Committee (February 2015) and the decision of this Court in Macquarie Bank Ltd. v. Shilpi Cable
Technologies Ltd.: (2018) 2 SCC
674. The respondents
15. The contesting respondents have refuted the contentions of the appellants with essentially
similar submissions that the transactions in question cannot be termed as preferential transactions
within the meaning of Section 43 of the Code.
15.1. The respondents, particularly the lenders of JAL, while maintaining a consistent stand that the
transactions in question are not preferential and do not fall under Section 43 of the Code, have
submitted that they being the bankers and financial institutions, are regularly engaged in the
business of extending loans and other facilities which form the backbone of economic growth; and
taking of such securities, including third party security, is one of the normal and ordinary feature of
their business and dealings, particularly that of corporate money lending. According to these
respondents, if at all such third party securities are avoided on the allegation of being preferential, it
is likely to have a devastating effect on the entire economy because the bankers and financial
institutions would then be left high and dry; and for future dealings, they shall have no alternative
but to restrict their activities only to the direct party securities which would, in turn, result in
retardation and regression. It is submitted that in a given case, the borrower may not be able to offer
matching security to secure the entire advance requisite for its business and growth; and legally it is
not impermissible between the related companies that one may provide security towards the
loan/advance/facility obtained by the other. According to the respondents, the scheme of the Code,
and particularly its Part II, has never been to allow the processes of insolvency resolution or
liquidation to operate detrimental to the interests of the financers like themselves (lenders of JAL).
It is contended that on the true scope of the provisions contained under Section 43 of the Code, with
reference to the intent and object, the transactions in question, representing the security and
guarantee extended by the corporate debtor JIL, cannot be construed as preferential, particularly
when they were entered into in the ordinary course of business and financial affairs of the corporate
debtor as also the transferees. 15.2. Apart from expressing such concerns about likely prejudice to
themselves and to the economy if the transactions in question are held preferential, a variety of
contentions have been advanced on behalf of the respondents, while refuting those of the appellants.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

We may briefly summarize the leading contentions on behalf of the contesting respondents while
omitting repetitions.
Axis Bank 15.3. While maintaining that the impugned transactions cannot be considered as
preferential within the meaning of Section 43 of the Code, the principal contentions on behalf of this
respondent are as under: -
a. The transactions did not occur within the ‘relevant time’.
15.3.1. It is contended that the ‘relevant time’ in the present circumstances could be
only one year as the transfer of property interest was to this respondent, which is a
Bank and an unrelated party. It is further contended that, in any event, the land
parcels were mortgaged on 24.02.2015, which is beyond even the two years
formulation, the relevant time being from 10.08.2015 to 09.08.2017. The subsequent
re-execution of the mortgage deeds on 15.09.2015 and then again on 29.12.2016
cannot be considered to be a substantive event since the nature and identity of the
security remained the same and no fresh encumbrances were created. The
re-mortgage was done to reflect the increase in the amount of facilities and number
of members in the consortium. It is not the case that the existing facilities were paid,
the mortgage satisfied, and fresh facilities were created for which a fresh mortgage
was required.
b. Without prejudice to the above, the ingredients of Section 43(2) are not met. 15.3.2. It is further
submitted that Sections 43/44 of the Code are expropriating provisions as they affect concluded
transactions and have the potential to render void the transfers of property done through the
transactions which are otherwise legitimate and hence, such provisions must be strictly construed.
The decisions of this Court in Devinder Singh & Ors v. State of Punjab & Ors: (2008) 1 SCC 728 and
Nareshbhai v. Union of India : (2019) SCC Online SC 1027 have been relied upon.
15.3.3. It is submitted that the requirements set out under Section 43(2) must be strictly construed
and in the instant case, the two prongs under Section 43(2) have not been satisfied. With reference
to UNCITRAL Legislative Guide on Insolvency Law at para 177, it is submitted that as per Section
43(2)(a), a preference could only be given to an existing creditor such that he is preferred over other
creditors but in this matter, the security was provided for the benefit of the respondent bank, which
did not have a pre-existing creditor-debtor relationship with the corporate debtor. Further, the
security was provided on account of the debt obligations of JAL, and not any antecedent debt
obligations of the corporate debtor.
15.3.4. It is further submitted, without prejudice to the above, that even if JAL is taken to be a
creditor within the meaning of Section 43(2)(a), then the requirements of Section 43(2)(b), the
second prong of the two-fold requirement for a transaction to be a preference, are not met. It is
submitted that the transfer in the instant case has no effect whatsoever on the relative position of
JAL in the distribution waterfall – it remains an operational creditor without any security interest.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

c. Without prejudice to the above, security was provided in the ordinary course of business.
15.3.5. While pointing out that Section 43(3)(a) carves out exception for the transactions made in
the ordinary course of business or financial affairs of either the corporate debtor or the transferee, it
is contended that no material particulars/evidence have been produced to show that the provision of
the security was not in the ordinary course of business of the corporate debtor. On the contrary,
according to the respondent, (i) creation of third party security is an established commercial
business practice; (ii) the corporate debtor has continuously disclosed details of the security in its
annual reports beginning from the financial year ending 31.03.2015 and thus, creation of security
was known to all and disclosed in public documents; and (iii) no evidence of dissent from any
existing creditor of the corporate debtor has been shown at the time of creation of the security. The
transaction in question, according to the respondent, had been in the ordinary course of business of
the corporate debtor and remains unexceptionable.
15.3.6. It is further contended that the provision of security was also in the ordinary course of
business of the respondent who is a scheduled commercial bank and is duly authorized by statute to
carry out the business of commercial lending on a secured basis [per Section 6(1)(a) of the Banking
Regulation Act, 1949]; and is statutorily entitled to seek credit enhancement on account of
outstanding debts by way of creation of security interests by borrowers or their related entities. For
this reason too, with the transaction being in the ordinary course of business of the transferee i.e.,
the respondent, it cannot be termed as a preferential transaction.
15.3.7. It is yet further submitted that the contention of IRP that the corporate debtor ought not to
have given the security as its accounts had turned NPA with certain banks is fallacious as it conflates
the concepts of ‘NPA’ and ‘willful defaulter’ and ignores that the security was given to the
respondent even before the account turned NPA qua certain banks. With reference to the interim
report of the Bankruptcy Law Reforms Committee issued in February 2015, it is submitted that as
per the said report, avoidance transactions relate to ‘willful defaulters’ and not ‘NPAs’. It is further
argued that the distinctive position of a willful defaulter and an NPA is also indicated in Section 29A
of Code, where Section 29A(b) provides that a willful defaulter can never be a resolution applicant
whereas, Section 29A(c) provides that a company whose account has become non-performing may
only be disqualified if the account has remained non-performing for a period of one year. It is
submitted that RBI Master Circular on asset classification issued in July 2015 and June 2019 set out
that an account may turn NPA qua a particular bank if the debts are not being serviced regularly but
this does not mean that a particular company’s accounts would have turned non-performing qua all
its lenders. It is also submitted that the other account of corporate debtor with this respondent
turned NPA only in 2017, i.e., much after the creation of security in question. It is further contended
that a company’s account may easily become standard if, inter alia, the company regularizes its
payment timelines or if lenders decide to revise the company’s repayment obligations. Reliance is
placed on the decisions of this Court in Keshavlal Khemchand & Sons Pvt. Ltd. & Ors v. Union of
India & Ors: (2015) 4 SCC 770 and State Bank of India v. Jah Developers Pvt. Ltd. & Ors.: (2019) 6
SCC 787.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

d. Section 44 does not come into operation unless a transaction is made out to be preferential under
Section 43.
15.3.8. It is further submitted that the jurisdictional condition of exercising power under Section 44
is the finding that a transaction is preferential under Section 43, as is evident from the heading of
Section 44 i.e., ‘Orders in cases of preferential transactions’; and, for the transaction in question
being not preferential under Section 43, no orders could be made under Section 44. Standard
Chartered Bank 15.4. Most of the contentions urged on behalf of this respondent are analogous to
the contentions noticed in the preceding paragraphs and, therefore, we are not repeating the same.
It is maintained on behalf of this respondent that in whatever way the relevant time is reckoned for
the purpose of Section 43 of the Code, its transactions would not fall therein because the initial
mortgage in favour of this respondent was made in the year 2012, which is beyond the two years
formulation. The further submission is that the subsequent conversion of registered mortgage into
an equitable mortgage on 04.11.2015 and thereafter, re-conversion from equitable mortgage to
registered mortgage on 24.05.2016, in relation to the same subject property as a security, cannot be
considered as a fresh creation of mortgage and hence, the transaction in question does not fall
within relevant time. ICICI Bank 15.5. Again, for most of the contentions on behalf of this
respondent being similar in nature, we are not repeating the same. However, we may notice that
with reference to Section 43(4) of the Code, it has been contended that since this respondent bank is
an unrelated party to both the corporate debtor and JAL, the relevant look-back period would be
one year and not two years. It is submitted that the mortgages were created on 15.09.2015 and the
same property was re-mortgaged on 29.12.2016, which is much before the look-back period of one
year and thereby, this transaction could not be challenged as being preferential. The decisions of the
Bombay High Court in Monarch Enterprises v. Kishan Tulpule & Ors : (1992) 74 Comp Case 89
(Bom) and that of Madras High Court in IDBI Bank Ltd. v. The Administrator, Kothari Orient
Finance Ltd., the Official Liquidator & S. Ramaiah : (2009) 152 Comp Case 282 (Mad) have been
referred while submitting that a mere transfer of the assets within the look-back period would not
make the transaction preferential except when it is coupled with the intent to prefer one creditor
over the other. Further, for contending that the impugned transactions were made in the ordinary
course of business of both the respondent Bank and the corporate debtor, the Annual Reports of
corporate debtor JIL have been referred with the submissions that the mortgaged properties were
disclosed as ‘inventories’ for the corporate debtor being a real estate company; and hence, dealing
with the ‘inventories’/‘stock-in-trade’ is in the ordinary course of business.
15.5.1. It is further submitted that there is no relation between the financial position of the corporate
debtor and the impugned transaction for another reason that as on the date of commencement of
insolvency proceedings, the corporate debtor had 740 acres of unencumbered land, which could
have been used to create security for the creditors of corporate debtor. While pointing out that 11 out
of 13 lenders of the corporate debtor JIL are also a part of the consortium of JAL lenders whose
loans were secured by mortgages made by the corporate debtor, it is submitted that prior to
15.09.2015, when the questioned Consortium of Mortgages was created, only Jammu and Kashmir
Bank had declared the corporate debtor as NPA, which was followed by the other lenders declaring
the corporate debtor as NPA. It is contended that prior to the said declaration, the transactions with
this respondent had been made as also the mortgages created on 15.09.2015, which had also securedAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

the interests of Jammu and Kashmir Bank and, therefore, the impugned transactions could not be
said to be preferential. Other respondent-lenders 15.6. Broadly speaking, similar submissions as
noted above have been made on behalf of other respondent-lenders while maintaining that the
impugned transactions are covered by the exclusion clause under Section 43 inasmuch as the
transfers had been made in the ordinary course of business of the corporate debtor as also the
transferees; and that for the purpose of Section 43 of the Code, the relationship between the
respondent-lenders and JIL ought to be looked into rather than assuming JAL to be the primary
transferee. It has also been argued, while relying on the decision of this Court in Purbanchal Cables
& Conductors Pvt. Ltd. & Ors v. Assam State Electricity Board & Ors : (2012) 7 SCC 462, that the
provisions of Section 43 of the Code, by their very nature, would come into operation at least one
year after the enactment of the Code i.e., it would have only the prospective effect and cannot be
given retrospective effect so as to operate over any period prior to the enactment.
Jaiprakash Associates Ltd. (JAL) 15.7. As noticed, this respondent JAL is the holding company of
corporate debtor JIL; and the transactions in question had been for securing the loans/facilities
obtained by this respondent. Even while broadly adopting the contentions advanced by other
respondents, further submissions have been made on behalf of this respondent to assert on the
credence of the transactions in question. With reference to its relationship with JIL, it is contended
on behalf of this respondent that being the holding company, JAL had been providing financial,
technical and strategic support to JIL in various ways being: (i) Investment made in 99,50,00,000
shares of JIL (paid up value Rs. 995 crores) at its very nascent stage, which means contribution of
substantial funds for the business of JIL without interest; (ii) Pledge of its 70,83,56,087 equity
shares held in JIL in favour of the lender of JIL; (iii) Promoter Support Agreement to meet the Debt
Service Reserve Account (DSRA) obligation of JIL towards its lenders; and (iv) Bank Guarantees of
Rs. 212 crores in aggregate to meet the DSRA obligation of JIL for the financial assistance obtained
by JIL. It is submitted that such dealings/transactions by JAL in favour of JIL depict the nature of
business relationship between JAL and JIL and makes it amply clear that the impugned
transactions were done in the ordinary course of business and financial affairs of JIL. It is further
submitted that the mortgage of 858 acres of land made in favour of lenders of JAL fall within the
ambit of Section 186 of Companies Act, 2013 25 and is not unauthorized.
15.7.1. It is contended that avoidance of preferential transactions applies to a case where the
company’s accounts has become stressed and there is a strong likelihood of it going into liquidation
but in the present case, it is a matter of record that the accounts of JIL had been categorised as NPA
only to an extent of 29.04% whereas the remaining accounts were still ‘standard’. According to the
respondent JAL, this fact was specifically pleaded at the stage of opposing the application filed
before the NCLT for initiating CIRP against JIL but JIL gave its consent for CIRP on the bona fide
belief that it would be able to restructure its loans and get back the management of JIL. The
submission is that, in the given economic scenario, JIL was not in any such stress or problem that it
could not have continued with the existing mortgages for securing the facilities advanced to JAL by
the lender banks and financial institutions.
Insolvency and Bankruptcy Code, 2016: historical background, objects, scheme and structure of the
relevant partsAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

16. The basic issue raised in the matter being related with the effect and operation of Section 43 of
the Code, concerning ‘Preferential transactions 25 Hereinafter also referred to as ‘the Act of 2013’.
and relevant time’, appropriate it shall be to comprehend the principles underlying the concept of
‘preferential transactions’. A little insight into the objects sought to be achieved by the Insolvency
and Bankruptcy Code, 2016 and its historical background shall be apposite.
16.1. As noticed from Preamble, the Code came to be enacted to consolidate and amend the laws
relating to reorganisation and insolvency resolution of corporate persons and even of partnership
firms and individuals in a time bound manner; the objectives, inter alia, being for maximisation of
value of assets of such persons and balance of interest of all the stakeholders. 16.1.1. In the case of
Swiss Ribbons Private Limited and Anr. v. Union of India and Ors.: (2019) 4 SCC 1726, this Court
had the occasion to traverse through the historical background and scheme of the Code in the wake
of challenge to the constitutional validity of various provisions therein. One part of such challenge
had also been founded on the ground that classification between ‘financial creditor’ and ‘operational
creditor’ was discriminatory and violative of Article 14 of the Constitution of India. 27 This ground
as also several other grounds pertaining to various provisions of the Code were rejected by this
Court after elaborate dilation on the vast variety of rival contentions and the provisions so contained
in the Code were upheld as valid. In the course of 26 Hereinafter also referred to as the case of
‘Swiss Ribbons’. 27 The law declared by this Court in this case of Swiss Ribbons, while rejecting the
contentions that the classification between ‘financial creditor’ and ‘operational creditor’ was
discriminatory and violative of Article 14, shall have some bearing on the issues at hand, particularly
in relation to the second issue on the claim of the respondent-lenders for being treated a financial
creditors of JIL, as shall be noticed hereafter later.
such distillation, this Court took note, inter alia, of the pre-existing state of law as also the objects
and reasons for enactment of the Code. While observing that the focus of the Code was to ensure
revival and continuation of the corporate debtor, where liquidation is to be availed of only as a last
resort, this Court pointed out that on its scheme and frame work, the Code was a beneficial
legislation to put the corporate debtor on its feet, and not a mere recovery legislation for the
creditors. This Court said,-
“27. As is discernible, the Preamble gives an insight into what is sought to be achieved by the Code.
The Code is first and foremost, a Code for reorganisation and insolvency resolution of corporate
debtors. Unless such reorganisation is effected in a time-bound manner, the value of the assets of
such persons will deplete. Therefore, maximisation of value of the assets of such persons so that they
are efficiently run as going concerns is another very important objective of the Code. This, in turn,
will promote entrepreneurship as the persons in management of the corporate debtor are removed
and replaced by entrepreneurs. When, therefore, a resolution plan takes off and the corporate
debtor is brought back into the economic mainstream, it is able to repay its debts, which, in turn,
enhances the viability of credit in the hands of banks and financial institutions. Above all,
ultimately, the interests of all stakeholders are looked after as the corporate debtor itself becomes a
beneficiary of the resolution scheme— workers are paid, the creditors in the long run will be repaid
in full, and shareholders/investors are able to maximise their investment. Timely resolution of aAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

corporate debtor who is in the red, by an effective legal framework, would go a long way to support
the development of credit markets. Since more investment can be made with funds that have come
back into the economy, business then eases up, which leads, overall, to higher economic growth and
development of the Indian economy. What is interesting to note is that the Preamble does not, in
any manner, refer to liquidation, which is only availed of as a last resort if there is either no
resolution plan or the resolution plans submitted are not up to the mark. Even in liquidation, the
liquidator can sell the business of the corporate debtor as a going concern. (See ArcelorMittal28 at
para 83, fn 3)
28. It can thus be seen that the primary focus of the legislation is to ensure revival and continuation
of the corporate debtor by protecting the corporate debtor from its own management and from a
corporate death by liquidation. The Code is thus a beneficial legislation which puts the corporate
debtor back on its feet, not being a mere recovery legislation for creditors. The interests of the
corporate debtor have, therefore, been bifurcated and separated from that of its promoters/those
who are in management. Thus, the resolution process is not adversarial to the corporate debtor but,
in fact, protective of its interests. The moratorium imposed by Section 14 is in the interest of the
corporate debtor itself, thereby preserving the assets of the corporate debtor during the resolution
process. The timelines within which the resolution process is to take place again protects the
corporate debtor’s assets from further dilution, and also protects all its creditors and workers by
seeing that the resolution process goes through as fast as possible so that another management can,
through its entrepreneurial skills, resuscitate the corporate debtor to achieve all these ends.” 16.2.
Keeping in view the objectives, discernible from the Preamble as also from the Statement of Objects
and Reasons of the Code and the observations of this Court, we may now take an overview of the
scheme and structure of the relevant parts of the Code. Part I thereof contains the provisions
regarding title, extent, commencement and application of the Code as also defines various
expressions used and employed in the Code. Different provisions have come into force on different
dates, as permissible under proviso to sub-section (3) of Section 1. Part II of the Code deals with
insolvency resolution and liquidation for corporate persons. Chapter I of Part II makes provision for
its applicability and also defines various expressions used in this Part (Sections 4 28 ArcelorMittal
India (P) Ltd. v. Satish Kumar Gupta & Ors: (2019) 2 SCC 1 and 5). Chapter II of Part II contains the
provisions for corporate insolvency resolution process in Sections 6 to 32 whereas Chapter III of this
Part II contains the provisions for liquidation process in Sections 33 to 5429. 16.3. Though the
provisions relating to ‘preferential transactions and relevant time’ (in Section 43 of the Code) occur
in Chapter III of Part II, relating to liquidation process, but such provisions being for avoidance of
certain transactions and having bearing on the resolution process too, by their very nature, equally
operate over the corporate insolvency resolution process, and hence, the resolution professional is
obligated, by virtue of clause (j) of sub- section (2) of Section 25 of the Code, to file application for
avoidance of the stated transactions in accordance with Chapter III. That being the position, Section
43 of the Code comes into full effect in CIRP too. Preferential transaction at a relevant time: concept
and connotations
17. Having regard to the questions involved, a brief insight into the theory relating to avoidance of
certain transactions as being preferential would be pertinent at this stage.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

17.1.The basic concept of ‘preference’ as per the law dictionaries and lexicons is the act of ‘paying or
securing to one or more of his creditors, by an insolvent debtor, the whole or part of their claims, to
the exclusion of the rest’.30 We may 29 Sections 4 to 33 came into force on 01.12.2016 whereas
Section 33 to 54 came into force on 15.12.2016.
30 P. Ramanatha Aiyar’s Advanced Law Lexicon (5th Ed.-Vol 3, p.4002) usefully take note of the
meaning, definition and basic ingredients of ‘preference’ and ‘preferential transfer’, as defined in
Black’s Law Dictionary31:
“preference. (15c) 1. The favouring of one person or thing over another. 2. The person
or thing so favoured. 3. The quality, state, or condition of treating some persons or
things more advantageously than others. 4. Priority of payment given to one or more
creditors by a debtor; a creditor’s right to receive such priority. 5. Bankruptcy.
PREFERENTIAL TRANSFER.
 insider preference. (1981) A transfer of property by a bankruptcy debtor to an
insider more than 90 days before but within one year after the filing of the
bankruptcy petition.  liquidation preference. (1936) A preferred shareholder’s right,
once the corporation is liquidated, to receive a specified distribution before common
shareholders receive anything.
 voidable preference . See PREFERENTIAL TRANSFER” *** *** *** “preferential
transfer. (1874) Bankruptcy. A prebankruptcy transfer made by an insolvent debtor
to or for the benefit of a creditor, thereby allowing the creditor to receive more than
its proportionate share of the debtor’s assets; specif., an insolvent debtor’s transfer of
a property interest for the benefit of a creditor who is owed on an earlier debt, when
the transfer occurs no more than 90 days before the date when the bankruptcy
petition is filed or (if the creditor is an insider) within one year of the filing, so that
the creditor receives more than it would otherwise receive through the distribution of
the bankruptcy estate.
Under the circumstances described in 11 USCA §547, the bankruptcy trustee may, for
the estate’s benefit, recover a preferential transfer from the transferee. – Also termed
preference; voidable preference; voidable transfer; preferential assignment;
preferential debt payment….” 17.2. It could be readily noticed that as far back as from
15 th century, the concept of ‘preference’ has been taken note of and the principles
relating to avoidance of certain preferences have evolved, particularly in the fields of
31 10th Edition – pp. 1369 and 1370 mercantile laws and more particularly in the laws governing
insolvency and bankruptcy32; and definitively from 1874, various jurisdictions have defined,
described and dealt with ‘preferential transfer’ as being the transaction where an insolvent debtor
makes transfer to or for the benefit of a creditor so that such beneficiary would receive more than
what it would have otherwise received through the distribution of bankruptcy estate. Section 547 of
US Bankruptcy Code provides for the circumstances in which a bankruptcy trustee may, for theAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

benefit of the estate in question, recover a preferential transfer from the transferee. Section 239 of
the UK Insolvency Act, 1986 also provides for the same measures for avoidance of preference given
to any person at the relevant time. The time factor also plays a crucial role in such measures of
avoidance. This ‘relevant time’ for the purpose of avoidance of preferential transactions is now
commonly referred to as the ‘look-back’ period. Significantly, when the preferential transaction is
with an unconnected party, the look-back period is comparatively lesser than that of the transaction
with a connected party, who is referred to as ‘insider’ or ‘related party’33. 32 It may in the passing be
observed that ‘an insolvency’ essentially refers to financial distress, i.e., financial state in which a
person or entity is unable to pay its dues or meet with other akin obligations. Insolvency may be
temporary in character. ‘A bankruptcy’, on the other hand, essentially refers to the legal process to
regulate as to how an insolvent entity shall pay off his dues.
As noticed, the primary focus of IBC is ‘to ensure revival and continuation of the corporate debtor by
protecting the corporate debtor from its own management and from a corporate death by
liquidation’. In other words, insolvency resolution is the main object; and liquidation with
bankruptcy is the last resort.
33 We may also indicate that any attempt by an insolvent, of alienating or encumbering the assets in
favour of one person so as to cause harm to the interest of a bona fide creditor had been sternly dealt
with by the legislature even in relation to the individuals, as could be readily noticed from the
provisions contained in the erstwhile Presidency - Towns Insolvency Act, 1909 and Provincial 17.3.
Coming now to the corporate personalities, it is elementary that by the very nature and legal
implications of incorporation, ordinarily, several individuals and entities are involved in the affairs
of a corporate person; and impact of the activities of a corporate person reaches far and wide, with
the creditors being one of the important set of stakeholders. If the corporate person is in crisis,
where either insolvency resolution is to take place or liquidation is imminent; and the transactions
by such corporate person are under scanner, any such transaction, which has an adverse bearing on
the financial health of the distressed corporate person or turns the scales in favour Insolvency Act,
1920. These enactments stand repealed by IBC but the relevant provisions therein give an insight
into the concepts. Section 56 of the Act of 1909 provided thus:
“56.Avoidance of preference in certain cases. - (1) Every transfer of property, every
payment made, every obligation incurred, and every judicial proceeding taken or
suffered by any person unable to pay his debts as they became due from his own
money in favour of any creditor, with a view of giving that creditor a preference over
the other creditors, shall, if such person is adjudged insolvent on a petition presented
within three months after the date thereof, be deemed fraudulent and void as against
the official assignee.
(2) This section shall not affect the rights of any person making title in good faith and
for valuable consideration through or under a creditor of the insolvent.” The relevant
part of Section 69 of the Act of 1920 had been as under:Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

“69. Offences by debtors. – If a debtor, whether before or after the making of an
order of adjudication, -
*** *** ***
(c) fraudulently with intent to diminish the sum to be divided among his creditors or
to give an undue preference to any of his creditors, -
(i) has discharged or concealed any debt due to or from him, or
(ii) has made away with, charged, mortgaged or concealed any part of his property of
any kind whatsoever, he shall be punishable on conviction with imprisonment which
may extend to one year.” of one or a few of its creditors or third parties, at the cost of
the other stakeholders, has always been viewed with considerable disfavour34.
17.4. Noteworthy distinctive features, in the scheme of the Companies Act, 2013 and Insolvency and
Bankruptcy Code, 2016, as regards preferences in relation to the corporate personalities, are that
while Section 328 of the Act of 2013 deals with fraudulent preference and Section 329 thereof deals
with transfers not in good faith but, on the other hand, in the Code, separate provisions are made as
regards the transactions intended at defrauding the creditors (Section 49 IBC) as also for fraudulent
trading or wrongful trading (Section 66 IBC). The provisions contained in Section 43 of the Code,
however, indicate the intention of legislature that when a transaction falls within the coordinates
defined therein, the same shall be deemed to be a preference given at a relevant time and shall not
be countenanced. Therefore, intent may not be of a defence or support of any preferential
transaction that falls within the ambit of Section 43 of the Code.
34 In relation to the corporate personalities, the concept of ‘fraudulent preference’, earlier embodied
in Section 531 of the Companies Act, 1956 now occurs in its modified form in Sections 328 and 329
of the Companies Act, 2013. Tersely put, fraudulent preference means parting with assets of the
corporate person in favour of one or a few of its creditors, which has the effect of defeating the claim
of other creditors. Per Section 329 of the Act of 2013, any transfer of property by a company, other
than that in the ordinary course of business, if made within a period of one year before presentation
of a petition for winding up by the Tribunal and not in good faith and for valuable consideration, is
regarded as void against the liquidator. Per Section 328 of the Act of 2013, if a company has given
preference to one of its creditors or a surety or a guarantor for any of the debts or other liabilities
and the company does or suffers anything which has the effect of putting that person in a better
position in the event of company going into liquidation than the position he would have been in but
for such preference prior to six months of making winding up application, the Tribunal, on being
satisfied that the transaction was of a fraudulent preference, may order for restoring the position to
what it would have been if the preference had not been given. More particularly, as regards transfer
of property, it is provided in sub-section (2) of Section 328 that if the transaction is made six
months before winding up application, the Tribunal may declare such transaction invalid and
restore the position. 17.5. At this juncture, we may usefully refer to paragraph 177 of UNCITRAL
Legislative Guide on Insolvency Law, as referred to and relied upon by learned counsel for theAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

respondent as also paragraphs 178 and 179 thereof, to indicate the basic theory and principles
governing the provisions under consideration. In the said Guide, while dealing with the topic of
treatment of assets on commencement of insolvency proceedings, it is stated broadly on the theory
of avoidance of preferential transactions as follows:
“(c) Preferential transactions
(i) Criteria
177. Preferential transactions may be subject to avoidance where:
(a) the transaction took place within the specified suspect period;
(b) the transaction involved a transfer to a creditor on account of a pre-existing debt;
and (c) as a result of the transaction, the creditor received a larger percentage of its
claim from the debtor’s assets than other creditors of the same rank or class (in other
words, a preference). Many insolvency laws also require that the debtor was insolvent
or close to insolvent when the transaction took place and some further require that
the debtor have an intention to create a preference. The rationale for including these
types of transaction within the scope of avoidance provisions is that, when they occur
very close to the commencement of proceedings, a state of insolvency is likely to exist
and they breach the key objective of equitable treatment of similarly situated
creditors by giving one member of a class more than they would otherwise legally be
entitled to receive.
178. Examples of preferential transactions may include payment or set-off of debts not yet due;
performance of acts that the debtor was under no obligation to perform; granting of a security
interest to secure existing unsecured debts; unusual methods of payment, for example, other than in
money, of debts that are due; payment of a debt of considerable size in comparison to the assets of
the debtor; and, in some circumstances, payment of debts in response to extreme pressure from a
creditor, such as litigation or attachment, where that pressure has a doubtful basis. A set-off, while
not avoidable as such, may be considered prejudicial when it occurs within a short period of time
before the application for commencement of the insolvency proceedings and has the effect of
altering the balance of the debt between the parties in such a way as to create a preference or where
it involves transfer or assignment of claims between creditors to build up set-offs. A set- off may also
be subject to avoidance where it occurs in irregular circumstances, such as where there is no
contract between the parties to the set-off.
(ii) Defences
179. One defence to an allegation that a transaction was preferential may be to show that, although
containing the elements of a preference, the transaction was in fact consistent with normal
commercial practice and, in particular, with the ordinary course of business between the parties to
the transaction. For example, a payment made on receipt of goods that are regularly delivered andAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

paid for may not be preferential, even if made within proximity to the commencement of insolvency
proceedings. This approach encourages suppliers of goods and services to continue to do business
with a debtor that may be having financial problems, but which is still potentially viable. Other
defences available under insolvency laws include that the counterparty extended credit to the debtor
after the transaction and that credit has not been paid (the defence is limited to the amount of the
new credit); that the counterparty gave new value for which it was not granted a security interest;
the counterparty can show that it did not know a preference would be created; that the counterparty
did not know or could not have known that the debtor was insolvent at the time of the transaction;
or that the debtor’s assets exceeded its liabilities at the time of the transaction. Some of these latter
defences, in particular those involving the intent of the parties to the transaction, suffer from the
disadvantage of being difficult to prove and may make avoidance proceedings complex,
unpredictable and lengthy.” Analysing Section 43 of the Code
18. In the backdrop of the foregoing, we may now scrutinise Sections 43 and 44 of the Code. Section
44 provides for the consequences of an offending35 preferential transaction i.e., when the
preference is given at a relevant time. Under Section 44, the Adjudicating Authority may pass such
orders as to reverse the effect of an offending preferential transaction. Amongst others, the
Adjudicating Authority may require any property transferred in connection with giving of preference
to be vested in the corporate debtor; it may also release or discharge (wholly or in part) any security
interest created by the corporate debtor. The consequences of offending preferential transaction are,
obviously, drastic and practically operate towards annulling the effect of such transaction. Looking
to the contents, context and consequences, we are at one with the contentions urged on behalf of the
respondents with reference to the decisions in Devinder Singh (supra) and other cited cases, that
these provisions need to be strictly construed. However, even if we proceed on strict construction of
Section 43 of the Code, the underlying principles and the object cannot be lost sight of. In other
words, the construction has to be such that leads towards achieving the object of these provisions.
18.1. Looking at the broad features of Section 43 of the Code, it is noticed that as per sub-section (1)
thereof, when the liquidator or the resolution professional, as the case may be, is of the opinion that
the corporate debtor has, at a relevant time, given a preference in such transactions and in such
manner as specified in sub-section (2), to any person/persons as referred to in 35 Note: Here the
expression ‘offending’ is only to denote the unacceptability of such transaction and not any
criminality.
sub-section (4), he is required to apply to the Adjudicating Authority for avoidance of preferential
transactions and for one or more of the orders referred to in Section 44. If twin conditions specified
in sub-section (2) of Section 43 are satisfied, the transaction would be deemed to be of preference.
As per clause (a) of sub-section (2) of Section 43, the transaction, of transfer of property or an
interest thereof of the corporate debtor, ought to be for the benefit36 of a creditor or a surety or a
guarantor for or on account of an antecedent financial debt or operational debt or other liabilities
owed by the corporate debtor; and as per clause (b) thereof, such transfer ought to be of the effect of
putting such creditor or surety or guarantor in beneficial position than it would have been in the
event of distribution of assets under Section 53.37 18.2. However, merely giving of the preference
and putting the beneficiary in a better position is not enough. For a preference to become anAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

offending one for the purpose of Section 43 of the Code, another essential and rather prime
requirement is to be satisfied that such event, of giving preference, ought to have happened within
and during the specified time, referred to as “relevant time”. The relevant time is reckoned, as per
sub-section (4) of Section 43 of the Code, in two ways: (a) if the preference is given to a related party
(other than an employee), the relevant time is a period of two years preceding the 36 It may be
intended benefit or may even be unintended benefit 37 Section 53 IBC makes provision for
distribution of the proceeds from sale of the liquidation assets, in case of liquidation of the corporate
debtor.
insolvency commencement date; and (b) if the preference is given to a person other than a related
party, the relevant time is a period of one year preceding such commencement date. In other words,
for a transaction to fall within the mischief sought to be remedied by Sections 43 and 44 of the Code,
it ought to be a preferential one answering to the requirements of sub-section (2) of Section 43; and
the preference ought to have been given at a relevant time, as specified in sub-section (4) of Section
43.
18.3. However, even if a transaction of transfer otherwise answers to and comes within the scope of
sub-sections (4) and (2) of Section 43 of the Code, it may yet remain outside the ambit of
sub-section (2) because of the exclusion provided in sub-section (3) of Section 43.
18.4. Sub-section (3) of Section 43 specifically excludes some of the transfers from the ambit of
sub-section (2). Such exclusion is provided to: (a) a transfer made in the ordinary course of business
or financial affairs of the corporate debtor or transferee38; (b) a transfer creating security interest in
a property acquired by the corporate debtor to the extent that such security interest secures new
value and was given at the time specified in sub-clause (i) of clause (b) of Section 43(3) and subject
to fulfilment of other requirements of sub-clause (ii) thereof. The meaning of the expression “new
value” has also been explained in this provision.
38 Whether the expression “or”, as occurring in between the expressions ‘corporate debtor’ and
‘transferee’ in clause (a) of sub-section (3) of Section 43, is to be read as “and” has been one of the
significant questions raised in this matter and shall be dealt with hereafter later. Indicting parts –
deemed preference at a relevant time
19. In order to understand and imbibe the provisions concerning preference at a relevant time, it is
necessary to notice that as per the charging parts of Section 43 of the Code i.e., sub-sections (4) and
(2) thereof, a corporate debtor shall be deemed to have given preference at a relevant time if the
twin requirements of clauses (a) and (b) of sub-section (2) coupled with the applicable requirements
of either clause (a) or clause (b) of sub-section (4), as the case may be, are satisfied.
19.1. To put it more explicit, the sum total of sub-sections (2) and (4) is that a corporate debtor shall
be deemed to have given a preference at a relevant time if: (i) the transaction is of transfer of
property or the interest thereof of the corporate debtor, for the benefit of a creditor or surety or
guarantor for or on account of an antecedent financial debt or operational debt or other liability; (ii)
such transfer has the effect of putting such creditor or surety or guarantor in a beneficial positionAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

than it would have been in the event of distribution of assets in accordance with Section 53; and (iii)
preference is given, either during the period of two years preceding the insolvency commencement
date when the beneficiary is a related party (other than an employee), or during the period of one
year preceding the insolvency commencement date when the beneficiary is an unrelated party.
19.2. By way of these statutory provisions, legal fictions are created whereby preference is deemed to
have been given; and is deemed to have been given at a relevant time, if the stated requirements are
satisfied. Variegated features of a deeming provision have been discussed by this Court in the case of
Pioneer Urban (supra) with reference to several of the past decisions, albeit in the context of such
deeming expression occurring in the Explanation added to sub-clause (f) of Section 5(8) of the Code
39. We may usefully extract some of the relevant passages from the said decision in Pioneer Urban
as follows:
19.2.1. As regards construction of a deeming fiction, this Court pointed out the basic
and settled principles in the following:
“88. In every case in which a deeming fiction is to be construed, the observations of
Lord Asquith in a concurring judgment in East End Dwellings Co. Ltd. v. Finsbury
Borough Council: 1952 AC 109 (HL) are cited. These observations read as follows:
(AC pp. 132-133) “If you are bidden to treat an imaginary state of affairs as real, you
must surely, unless prohibited from doing so, also imagine as real the consequences
and incidents which, if the putative state of affairs had in fact existed, must inevitably
have flowed from or accompanied it.... The statute says that you must imagine a
certain state of affairs. It does not say that, having done so, you must cause or permit
your imagination to boggle when it comes to the inevitable corollaries of that state of
affairs.” These observations have been followed time out of number by the decisions
of this Court. (See, for example, M. Venugopal v. Divisional Manager, LIC: (1994) 2
SCC 323 at page 329).
*** *** ***
94. Although a deeming provision is to deem what is not there in reality, thereby
requiring the subject-matter to be treated as if it were 39 Such discussion in Pioneer
Urban essentially led to this Court holding that the said deeming provision was
clarificatory of the true legal position as it already obtained; and was to put beyond
the pale of doubt the fact that allottees are to be regarded as financial creditors within
the meaning of the enacting part contained in Section 5(8)(f) of the Code. The crucial
aspects relating to Section 5(8) of the Code shall be dilated hereafter during the
discussion on the second issue involved in these matters.
real, yet several authorities and judgments show that a deeming fiction can also be used to put
beyond doubt a particular construction that might otherwise be uncertain. Thus, Stroud's Judicial
Dictionary of Words and Phrases (7th Edition, 2008), defines "deemed" as follows:Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

"Deemed"- as used in statutory definitions "to extend the denotation of the defined
term to things it would not in ordinary parlance denote”, is often a convenient device
for reducing the verbiage or an enactment, but that does not mean that wherever it is
used it has that effect; to deem means simply to judge or reach a conclusion about
something, and the words “deem” and “deemed” when used in a statute thus simply
state the effect or meaning which some matter or things has-the way in which it is to
be adjudged; this need not import artificiality or fiction; it may simply be the
statement of an indisputable conclusion."
19.2.2. In Pioneer Urban, this Court further extracted extensively from the decision in Hindustan
Cooperative Housing Building Society Limited v. Registrar, Cooperative Societies and Anr.: (2009)
14 SCC 302 on various features of the processes of construction of different deeming provisions in
different contexts. Some of the relevant parts of such extraction (as occurring in paragraph 95 of
Pioneer Urban) read as follows (in SCC at pp. 524):
“ ‘… The word “deemed” is used a great deal in modern legislation. Sometimes it is
used to impose for the purposes of a statute an artificial construction of a word or
phrase that would not otherwise prevail. Sometimes it is used to put beyond doubt a
particular construction that might otherwise be uncertain. Sometimes it is used to
give a comprehensive description that includes what is obvious, what is uncertain
and what is, in the ordinary sense, impossible.’ (Per Lord Radcliffe in St. Aubyn v.
Attorney General:1952 AC 15 (HL), AC p. 53)
14. ‘Deemed’, as used in statutory definitions [is meant] ‘to extend the denotation of
the defined term to things it would not in ordinary parlance denote, is often a
convenient devise for reducing the verbiage of an enactment, but that does not mean
that wherever it is used it has that effect; to deem means simply to judge or reach a
conclusion about something, and the words “deem” and “deemed” when used in a
statute thus simply state the effect or meaning which some matter or thing has — the
way in which it is to be adjudged;
this need not import artificiality or fiction; it may simply be the statement of an undisputable
conclusion.’ (Per Windener, J. in Hunter Douglas Australia Pty. v. Perma Blinds:
(1970) 44 Aust LJ R 257)
15. When a thing is to be “deemed” something else, it is to be treated as that
something else with the attendant consequences, but it is not that something else
(per Cave, J., in R. v. Norfolk County Court: (1891) 60 LJ QB 379).
‘When a statute gives a definition and then adds that certain things shall be “deemed” to be covered
by the definition, it matters not whether without that addition the definition would have covered
them or not.’ (Per Lord President Cooper in Ferguson v. McMillan :Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

1954 SLT 109 (Scot))
16. Whether the word “deemed” when used in a statute established a conclusive or a
rebuttable presumption depended upon the context (see St. Leon Village
Consolidated School District v.
Ronceray: (1960) 23 DLR (2d) 32 (Can)).
‘…. I … regard its primary function as to bring in something which would otherwise be excluded.’
(Per Viscount Simonds in Barclays Bank Ltd. v. IRC: 1961 AC 509 at AC p. 523.) ‘ “Deems” means “is
of opinion” or “considers” or “decides” and there is no implication of steps to be taken before the
opinion is formed or the decision is taken.’ [See R. v. Brixton Prison (Governor), ex p Soblen: (1963)
2 QB 243 at QB p. 315.]’” 19.3. On a conspectus of the principles so enunciated, it is clear that
although the word ‘deemed’ is employed for different purposes in different contexts but one of its
principal purpose, in essence, is to deem what may or may not be in reality, thereby requiring the
subject-matter to be treated as if real. Applying the principles to the provision at hand i.e., Section
43 of the Code, it could reasonably be concluded that any transaction that answers to the
descriptions contained in sub-sections (4) and (2) is presumed to be a preferential transaction at a
relevant time, even though it may not be so in reality. In other words, since sub-sections (4) and (2)
are deeming provisions, upon existence of the ingredients stated therein, the legal fiction would
come into play; and such transaction entered into by a corporate debtor would be regarded as
preferential transaction with the attendant consequences as per Section 44 of the Code, irrespective
whether the transaction was in fact intended or even anticipated to be so.
Exclusion part 19.4. Even when the above-stated indicting parts of Section 43 as occurring in
sub-sections (4) and (2) are satisfied and the corporate debtor is deemed to have given preference at
a relevant time to a related party or unrelated party, as the case may be, such deemed preference
may yet not be an offending preference, if it falls into any or both of the exclusions provided by
sub-section (3) i.e., having been entered into during the ordinary course of business of the corporate
debtor or40 transferee or resulting in acquisition of new value for the corporate debtor.
40 As noticed, whether this expression “or”, as occurring in between the expressions ‘corporate
debtor’ and ‘transferee’ in clause (a) of sub-section (3) of Section 43, is to be read as “and” remains a
question to be dealt with.
Net concentrate of Section 43 19.5. Thus, the net concentrate of Section 43 is that if a transaction
entered into by a corporate debtor is not falling in either of the exceptions provided by sub-section
(3) and satisfies the three-fold requirements of sub-sections (4) and (2), it would be deemed to be a
preference during a relevant time, whether or not in fact it were so; and whether or not it were
intended or anticipated to be so.
20. The analysis foregoing leads to the position that in order to find as to whether a transaction, of
transfer of property or an interest thereof of the corporate debtor, falls squarely within the ambit of
Section 43 of the Code, ordinarily, the following questions shall have to be examined in a given case:Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(i). As to whether such transfer is for the benefit of a creditor or a surety or a
guarantor?
(ii). As to whether such transfer is for or on account of an antecedent financial debt or
operational debt or other liabilities owed by the corporate debtor?
(iii). As to whether such transfer has the effect of putting such creditor or surety or
guarantor in a beneficial position than it would have been in the event of distribution
of assets being made in accordance with Section 53?
(iv). If such transfer had been for the benefit of a related party (other than an
employee), as to whether the same was made during the period of two years
preceding the insolvency commencement date; and if such transfer had been for the
benefit of an unrelated party, as to whether the same was made during the period of
one year preceding the insolvency commencement date?
(v) As to whether such transfer is not an excluded transaction in terms of sub-section
(3) of Section 43?
21. Having taken note of the salient features of Section 43 of the Code and the questions germane for
its applicability over any transaction, we may now examine the questions calling for determination
in these appeals. Obviously, if the transactions in question are to fall squarely within the mischief of
Section 43, they must satisfy all the specifications and ingredients of sub-sections (2) and (4) of
Section 43 and ought not to be within the exclusion provided in sub- section (3) thereof.
Whether impugned transactions are preferential, falling within the ambit of sub-section (2) of
Section 43 IBC
22. For the purpose of dealing with the crucial question as to whether the impugned transactions are
preferential and fall within the prescription of sub- section (2) of Section 43 of the Code, appropriate
it shall be to recapitulate and summarize the overall scenario of this case.
22.1. The fact that JAL, a public listed company with more than 5 lakh individual shareholders, is
the holding company of the corporate debtor JIL is neither of any doubt nor of any dispute. As on
31.03.2017, JAL owned 71.64% of shares of JIL, having a value of Rupees 995 crores. The
background had been that when in the year 2003, JAL was awarded the rights for construction of an
expressway and a concession agreement was entered into with the Yamuna Expressway Industrial
Development Authority, JIL was set up as a special purpose vehicle. Finance was obtained from a
consortium of banks against partial mortgage of land acquired and pledge of 51% of the
shareholding of JAL. Housing plans were envisaged for construction of real estate projects in two
locations of the land acquired, one in Wish Town, Noida and another in Mirzapur.
22.1.1. Shorn of other details which may not be necessary for the present purpose, relevant it is to
notice that JIL was declared NPA by Life Insurance Corporation of India on 30.09.2015 and byAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

some of its other lenders on 31.03.2016. Then, IDBI Bank Limited instituted a petition under
Section 7 of the Code before NCLT, seeking initiation of Corporate Insolvency Resolution Process
against JIL, while alleging that JIL had committed a default to the tune of Rs. 526.11 crores in
repayment of its dues. On 09.08.2017, NCLT passed an order under Section 7 of the Code and
appointed an Interim Resolution Professional41-42. The IRP made an application on 06.02.2018,
seeking directions that the transactions entered into by the directors and promoters of corporate
debtor creating mortgages of 858 acres of immovable property 41 CIRP in relation to JIL is
underway by virtue of the orders passed by this Court on 09.08.2018 and 06.11.2019 (as referred to
in paragraphs 6.2 and 6.3.1 - supra) 42 This date i.e., 09.08.2017 is the “insolvency commencement
date” for the purpose of the questions under consideration owned by it to secure the debts of JAL
are preferential, undervalued, wrongful, and fraudulent; and hence, the security interest created by
corporate debtor JIL in favour of the lenders of JAL be discharged and such properties be deemed to
be vested in corporate debtor. The NCLT allowed the said application on 16.05.2018 with respect to
six of the impugned transactions covering about 758 acres of land. On the appeals filed by lenders of
JAL, NCLAT, by its impugned order dated 01.08.2019, set aside the order passed by NCLT and held
that such lenders of JAL were entitled to exercise their rights under the Code.
22.2. At this juncture, we may again take note of the transactions that were questioned by IRP for
the purpose of the application for avoidance, which had been the following: 1. Mortgage deed dated
29.12.2016 for 167.229 acres of land (Property No. 1) executed by JIL in favour of Axis Trustee
Services Limited to provide an additional security for term loans of Rs. 21081.5 crores sanctioned as
a consortium to JAL; 2. Mortgage deed dated 29.12.2016 for 167.9615 acres of land (Property No. 2),
again executed by JIL in favour of Axis Trustee Services Limited to provide an additional security for
term loans of Rs.21081.5 crores sanctioned by the consortium to JAL; 3. Mortgage deed dated
07.03.2017 for 158.1739 acres of land (Property No. 3) executed by JIL in favour of IDBI
Trustee-ship Services Limited for term loan of Rs.1200 crores granted by ICICI Bank to JAL; 4.
Mortgage deed dated 07.03.2017 for 151.0063 acres of land (Property No. 4), again executed by JIL
in favour of IDBI Trustee-ship Services Limited for term loan of Rs.1200 crores granted by ICICI
Bank to JAL; 5. Mortgage deed dated 24.05.2016 for 25.0040 acres of land (Property No. 5)
executed by JIL in favour of IDBI Trustee-ship Services Limited, as additional security against the
facility agreement dated 29.08.2012 between Standard Chartered Bank and JAL for Rs.400 crores
and other facilities, respectively for Rs.450 crores, Rs.538.16 crores and Rs.81.84 crores as also for
working capital facility of Rs.297 crores; and 6. Mortgage deed dated 04.03.2016 for 90 acres of
land (Property No. 6), executed by JIL in favour of State Bank of India for Short Term Loan Facility
to JAL to the tune of Rs.1000 crores.
22.2.1. As noticed, 09.08.2017 is the insolvency commencement date in this case. The transactions
in question, even if of putting the concerned properties under mortgage with the lenders, carry the
ultimate effect of working towards the benefit and advantage of the borrower i.e., JAL who obtained
loans and finances by virtue of such transactions. It is true that there had not been any
creditor-debtor relationship between the lender banks and corporate debtor JIL but that will not be
decisive of the question of the ultimate beneficiary of these transactions. The mortgage deeds in
question, entered by the corporate debtor JIL to secure the debts of JAL, obviously, amount to
creation of security interest to the benefit of JAL.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

22.2.2. Now, the capacity of JAL is admittedly that of the holding company of JIL as its largest
equity shareholder ( with approximately 71.64 % shareholding). Moreover, JAL had admittedly been
the operational creditor of JIL, for an amount of approximately Rs. 261.77 crores. JAL itself
maintains that it had been providing financial, technical and strategic support to JIL in various
ways. It is the assertion that apart from making investment in terms of equity shareholding to the
tune of Rs. 995 crores, JAL had pledged its 70,83,56,087 equity shares held in JIL in favour of the
lenders of JIL; had also entered into Promoter Support Agreement to the lenders of JIL to meet the
DSRA obligation of JIL towards its lenders; and had further extended Bank Guarantees of Rs. 212
crores to meet the DSRA obligation of JIL. These assertions, in our view, put JAL in such capacity
that it is a related party to JIL and is a creditor as also surety of JIL. In other words, the corporate
debtor JIL owed antecedent financial debts as also operational debts and other liabilities towards
JAL.
22.3. In the scenario taken into comprehension hereinabove, there is nothing to doubt that the
corporate debtor JIL has given a preference by way of the mortgage transactions in question for the
benefit of its related person JAL (who has been the creditor as also surety for JIL) for and on
account of antecedent financial debts, operational debts and other liabilities owed to such related
person. In the given fact situation, it is plain and clear that the transactions in question meet with all
the requirements of clause (a) of sub-section (2) of Section 43.
22.4. It is also not far to seek that in the given scenario, the requirements of clause (b) of sub-section
(2) of Section 43 are also met fair and square. On behalf of the respondents, emphasis is laid on the
fact that in the distribution waterfall in case of liquidation (per Section 53 of the Code), JAL, as an
operational creditor, stands much lower in priority than the other creditors and stakeholders. Such
submissions, in our view, only strengthen the position that by way of the impugned transfers, JAL is
put in a much beneficial position than it would have been in the absence of such transfers. It has
rightly been contended on behalf of the appellants that with the transactions in question, JAL has
been put in an advantageous position vis-à-vis other creditors on the counts that: a) JAL received a
huge working capital (approx. Rupees 30000 crores), by way of loans and facilities extended to it by
the respondent-lenders; and b) by way of the transactions in question, JAL’s liability towards its
own creditors shall be reduced, in so far as the value of the mortgaged properties is concerned,
which is said to be approximately Rs. 6000 crores. As a necessary corollary of the beneficial and
advantageous position of the related party JAL with creation of such security interest over the
properties of JIL, in the eventuality of distribution of assets under Section 53, the other creditors
and stakeholders of JIL shall have to bear the brunt of the corresponding disadvantage because such
heavily encumbered assets will not form the part of available estate of the corporate debtor.
Obviously, JAL stands dearly benefited and has derived such benefits at the cost, and in exclusion,
of the other creditors and stakeholders of the corporate debtor JIL. The applicability of clauses (a)
and (b) of sub-section (2) of Section 43 of the Code is clear and complete in relation to the impugned
six transactions. 22.5. Therefore, in relation to the present case, the answers to questions (i),
(ii) and (iii) as referred in paragraph 20 are that: the impugned transactions had been of transfers
for the benefit of JAL, who is a related party of the corporate debtor JIL and is its creditor and
surety by virtue of antecedent operational debts as also other facilities extended by it; and theAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

impugned transactions have the effect of putting JAL in a beneficial position than it would have
been in the event of distribution of assets being made in accordance with Section 53 of the Code.
Thus, the corporate debtor JIL has given a preference in the manner laid down in sub-section (2) of
Section 43 of the Code. The requirements of sub-section (4) of Section 43 IBC - related party and
look-back period
23. Even when all the requirements of sub-section (2) of Section 43 of the Code are satisfied, in
order to fall within the mischief sought to be remedied by Section 43, the questioned preference
ought to have been given at a relevant time. In other words, for a preference to become an avoidable
one, it ought to have been given within the period specified in sub-section (4) of Section 43. The
extent of ‘relevant time’ is different with reference to the relationship of the beneficiary with the
corporate debtor inasmuch as, for the persons falling within the expression ‘related party’ within the
meaning of Section 5 (24) of the Code, such period is of two years before the insolvency
commencement date whereas it is one year in relation to the person other than a related party. The
conceptions of, and rationale behind, such provisions could be noticed in the excerpts from the
interim report of Law Reforms Committee, as referred on behalf of the appellants. We may usefully
extract the same as under: -
“c. TRANSACTIONS WITH RELATED PARTIES The law on avoidance in the UK
provides for close scrutiny of transactions entered into with persons connected with
the company (other than employees) by incorporating longer time periods in relation
to which such transactions can be challenged. Thus, while the relevant time period
for avoiding preferences is six months prior to the onset of insolvency, the time
period is increased to two years in the case of persons connected with the company.
Similarly, for late floating charges other than for new value, the vulnerability period
for non-connected persons is twelve months while it is two years in the case of
connected persons. The avoidance provisions under the CA 2013 does not provide for
longer time periods in case the transactions are with connected persons. It is
submitted that providing for longer time periods for vulnerability would be
significant in improving the efficacy of these provisions. This is because a wider range
of transactions diminishing creditor wealth entered into with insiders occur not in
the ‘zone of insolvency’ but as soon as early signals of trouble are visible. Such
insiders have superior information of the company’s deteriorating financial position
and may raid corporate assets knowing that the company may become insolvent.
These provisions are of special significance in the Indian context where even the
larger corporates are often promoter/family controlled with such insiders often
enjoying significant informational advantages over even well-advised secured
lenders.” 23.1. Before examining as to whether the questioned preferences were given
at the relevant time as specified in sub-section (4) of Section 43, we may deal with
one part of the submissions made on behalf of some of the respondents that in view
of the look-back periods provided in sub-section (4), the provisions of Section 43 of
the Code, by their very nature, would come into operation at least one year after the
enactment of the Code and else, it would be giving retrospective effect to these
provisions which is not permissible. The submissions, in our view, remain bereft ofAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

substance.
23.1.1. The scheme of IBC is to disapprove and disregard such preferential
transaction which falls within the ambit of Section 43 and to ensure that any property
likely to have been lost due to such transaction is brought back to the corporate
debtor; and if any encumbrance is created, to remove such encumbrance so as to
bring the corporate debtor back on its wheels or in other event (of liquidation), to
ensure pro rata, equitable and just distribution of its assets. Such provisions as
contained in Sections 43 and 44 came into operation as the comprehensive scheme of
corporate insolvency resolution and liquidation from the date of being made
effective; and merely because look-back period is envisaged, for the purpose of
finding ‘relevant time’, it cannot be said that the provision itself is retrospective in
operation. Reference to the decision of this Court in the case of Purbanchal Cables
(supra) is entirely inapt. In the said case, by virtue of the enactment in question, i.e.,
Interest on Delayed Payments to Small Scale and Ancillary Industrial Undertakings
Act, 1993, a new liability of high rate of interest was created against the buyer in
displacement of the general principles of Section 34 of the Code of Civil Procedure.
Hence, this Court found that the enactment creating new liability would only be
prospective in operation. As noticed, fraudulent preferences in the affairs of
corporate persons had been dealt with by the legislature in the Companies Act, 1956
and have also been dealt with in the Act of 2013. Though therein, essentially, the
fraudulent preferences and transfers not in good faith are dealt with whereas, in the
scheme of IBC, separate provisions are made as regards the transactions intended at
defrauding the creditors (Section 49 IBC) as also for fraudulent trading or wrongful
trading (Section 66 IBC). The provisions contained in Section 43, however, indicate
the intention of legislature that when a preference is given at a relevant time and
thereby, the beneficiary of preference acquires unwarranted better position in the
event of distribution of assets, the same may not be countenanced. Looking to the
scheme of IBC and the principles applicable for the conduct of the affairs of a
corporate person, it cannot be said that anything of a new liability has been imposed
or a new right has been created. Maximisation of value of assets of corporate persons
and balancing the interests of all the stakeholders being the objectives of the Code,
the provisions therein need to be given fuller effect in conformity with the intention
of the legislature.
23.1.2. We may also observe that if the contentions urged on behalf of the
respondents were to be accepted, the result would be of postponing the effective date
of operation of sub-section (4) of Section 43 by two years in the case of related party
and to one year in the case of unrelated party, and thereby, effectively postponing the
application of entire Section 43 for a period of two years! That cannot be and had
never been the intention of legislature. It is also noteworthy that by virtue of proviso
to sub-section (3) of Section 1 of the Code, different dates can be provided for
enforcement of different provisions of the Code; and in fact, different provisions have
been brought into effect on different dates. However, after coming into force of theAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

provisions, if a look-back period is provided for the purpose of any particular
enquiry, it cannot be said that the operation of the provision itself would remain in
hibernation until such look-back period from the date of commencement of the
provision comes to an end. There is nothing in the Code to indicate that any provision
in Chapter II or Chapter III be taken out and put in operation at a later date than the
date notified. Such contentions being totally devoid of substance, deserve to be, and
are, rejected.
24. We may now take up the question as to which of the transactions in question
would entail in giving preference at a relevant time or otherwise. As noticed, the
preference is given to JAL who is a related party of JIL. Hence, the look-back period
is two years preceding insolvency commencement date i.e., 09.08.2017 per clause (a)
of sub-section (4) of Section 43; and accordingly, the point of enquiry would be as to
whether the preference had been given during the period of two years preceding
09.08.2017. Therefore, the transactions commencing from 10.08.2015 until the date
of insolvency commencement shall fall under the scanner. As noticed, it has been one
of the major contentions of the respondents that most of the impugned transactions
were not of creation of any new encumbrance by JIL and in fact, most of the
properties in question had already been under mortgage with the respective lenders
much before the period under consideration i.e., much before 10.08.2015.
24.1. It may at once be noticed that the transaction that was clearly falling beyond the period under
consideration was, in fact, kept out of the purview of Section 43 of the Code by NCLT itself, being
that relating to Property No. 7 (as mentioned in paragraph 4.5 hereinbefore).
24.2. So far as the transaction relating to Property No. 6 is concerned, being the mortgage deed
dated 04.03.2016, towards Short-Term Loan Facility to JAL of Rs. 1000 crores by State Bank of
India, the same obviously falls within the look-back period. Even if JAL had allegedly entered into
the facility agreement with this lender bank on 26.03.2015, this date is hardly of any bearing so far
as transaction by the corporate debtor JIL is concerned, which was made only on 04.03.2016.
24.3. In relation to the transactions concerning Property No. 1 and Property No. 2, for securing
loans by the Consortium to JAL, it is submitted that there had been initial mortgage dated
24.02.2015 that was released on 15.09.2015 and a so-called re-mortgage was made on 15.09.2015
and thereafter, this was also released on 29.12.2016 and again the so-called re-mortgage was made
on 29.12.2016. It is sought to be asserted that it had not been a case of creation of a fresh mortgage.
Similarly, in relation to the transactions concerning Property No. 3, it is alleged that there had been
initial mortgage dated 12.05.2014 for 433.35 acres of land of which, 240 acres was released on
30.12.2015, 35.05 acres was released on 24.06.2016 and the remaining 158.1739 acres of land was
also released on 07.03.2017 but was re- mortgaged on this very date 07.03.2017. As regards
Property No. 4, it is alleged that the same was put under mortgage initially on 12.05.2014, was
released on 07.03.2017 and was re-mortgaged on this very date 07.03.2017. As regards Property No.
5, it is alleged that the same was put under mortgage initially on 24.06.2009, the mortgage was
extended on 27.11.2012 and on 23.03.2013; it was released on 04.11.2015 and was re-mortgaged onAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

24.05.2016.
24.3.1. It has been one of the major contentions of the respondents that most of the impugned
transactions were not of creation of any new encumbrance by JIL and in fact, most of the properties
in question had already been under mortgage with the respective lenders. The submissions of
respondents in relation to the aforesaid five transactions, that they had been of so-called re-
mortgage/s, carry their own shortcomings and cannot be accepted. In the first place, we are clearly
of the view that on release by the mortgagee, the mortgage ceases to exist and it is difficult to
countenance the concept of a so- called re-mortgage. The so-called re-mortgage, on all its legal
effects and connotations, could only be regarded as a fresh mortgage; and it obviously befalls on the
mortgagor to consider at the time of creating any fresh mortgage as whether such a transaction is
expedient and whether it should be entered into at all. Noticeable it is that in relation to Property
No. 1 and 2, even if the initial mortgage had been dated 24.02.2015 falling beyond the look-back
period, it was released on 15.09.2015 and this date (15.09.2015) falls within the look-back period.
Even if the same property has been again mortgaged with the same lender/s on the same day of
release, the same cannot be countenanced for the transaction operates towards extending
unwarranted preference to JAL by the corporate debtor JIL. Significant it is to notice that while
making this mortgage dated 15.09.2015, the facility amount being obtained by JAL got swelled from
Rs. 3250 crores to a whopping Rs. 24109 crores and the number of creditors went up from 2 to 24.
Such a transaction, in our view, had only been of a fresh mortgage to secure extra facilities obtained
by JAL and thereby, extending unwarranted advantage to JAL at the cost of the estate of JIL. In the
other transaction dated 29.12.2016, by which the properties in question were again put under
mortgage with the lender/s, the facility amount was shown as Rs. 23491 crores. The transactions on
15.09.2015 and 29.12.2016 cannot be given credence with reference to the previous mortgage deed
dated 24.02.2015. Similar is the case in relation to Property No. 3. Even when the previous
mortgage was given on 12.05.2014 i.e., beyond the look-back period, there had been release deeds
on 30.12.2015 and 26.06.2016 as regards certain parcels of land. So far the release of land to JIL is
concerned, the same causes no problem and only works to the benefit of JIL and its stakeholders.
However, when the remaining land was also released on 07.03.2017, its fresh mortgage, even if on
the same date, cannot be countenanced and is hit by Section 43, being a deemed preference. The
very same considerations apply in relation to the Property No. 4 too. As regards Property No. 5, even
if there had been certain previous mortgage transactions falling beyond the look-back period, the
property got released on 04.11.2015; and thereafter, the fresh mortgage on 24.05.2016, with
increased facility amount from Rs. 1470 crores to Rs. 1767 crores, suffers from the same vice, of
being a deemed preference to a related party during the period of two years preceding the insolvency
commencement date. 24.4. For what has been discussed hereinabove, the conclusion is inevitable
that the impugned preference was given to a related party during a relevant time. However, before
concluding on this part of discussion, we may also observe that reference to the decisions of Madras
and Bombay High Courts in the case of IDBI Bank Ltd and Monarch Enterprises respectively, is
neither apposite nor advances the cause of the respondents for the reason that the said decisions
had essentially been on the question/s as to whether the impugned transactions were of fraudulent
preference per Section 531 or lacking in good faith per Section 531A of the Companies Act, 1956. In
fact, in the case of IDBI Bank (supra) the corporate debtor attempted to transfer one of its property
to the appellant bank, who was one of its creditors and in that regard, certain transactions likeAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

agreement for sale and handing over possession were suggested and it was alleged that the contract
for sale was partly performed about one year and four months prior to the winding-up proceedings;
and such being beyond the look-back period of six months as envisaged by Section 531 of the
Companies Act, 1956, it was argued that it had not been a fraudulent transfer. The contentions were
not accepted by the Single Judge and by the Division Bench of the High Court for the reason that
mere handing over of possession or documents did not complete the sale; rather the Court was of
the view that such documents were created only in order to avoid the transaction being called a
fraudulent preference. Apart that the element of fraud is not the essential ingredient of Section 43 of
the Code, the said decision in IDBI Bank, on the approach of the Courts towards corporate
transactions makes it clear that any transaction favouring one stakeholder at the cost of the other is
viewed with disfavour and is disapproved, particularly if it takes place during the prescribed
look-back period.
24.5. For what has been discussed hereinabove, the answer to question (iv) as referred in paragraph
20 is that the transactions in question had been of deemed preference to related party JAL by the
corporate debtor JIL during the look-back period of two years and have rightly been held covered
within the period envisaged by sub-section (4) of Section 43 of the Code. Ordinary course of
business or financial affairs
25. Even when it is held that the impugned transactions answer to the requirements of sub-section
(2) of Section 43 and fall within the period specified in sub-section (4) thereof, the question still
remains as to whether the impugned transactions do or do not fall within the exclusion provided by
sub- section (3) of Section 43 of the Code? As noticed, two types of transfers, as specified in clauses
(a) and (b) of sub-section (3) of Section 43, are not to be treated as preference for the purpose of
sub-section (2). It has been the mainstay of respondent-lenders that, in any case, the transfers in
question were made in the ordinary course of their business and hence, fall within clause (a) of
Section 43(3) that excludes the transfer made in the ordinary course of business or financial affairs
of the corporate debtor or the transferee. It has been forcefully argued that the lenders of JAL are
the transferees in the transactions in question and their ordinary course of business being of
providing financial support with loans and advances, such transfers are not included in sub-section
(2) of Section 43 by virtue of the exclusion provided in sub-section (3) thereof. On the other hand,
the main plank of submissions on behalf of the appellants has been that the expression “or”
occurring in clause
(a) of sub-section (3) of Section 43, seemingly disjunctive of corporate debtor on one hand and
transferee on the other, is required to be read as “and” so as to be conjunctive and covering only the
transfers made in the ordinary course of business or financial affairs of the corporate debtor and the
transferee. It is submitted on behalf of the appellants that such mortgage transactions had neither
been in the ordinary course of business or financial affairs of the corporate debtor JIL nor secure
new value in the property acquired by the corporate debtor and hence, are not excepted transactions
within the meaning of sub-section (3) of Section 43 of the Code.
25.1. Having taken into comprehension the scheme of the Code and the purpose and purport of the
provisions contained in Section 43, we find force and substance in the submissions made on behalfAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

of the appellants. 25.2. As noticed, in the scheme of such provisions in the Code, the underlying
concept is to disregard and practically annul such transactions which appear, in the course of
insolvency resolution or liquidation, to be preferential so as to minimise the potential loss to other
stakeholders in the affairs of the corporate debtor, particularly its creditors. What is to be examined
for the purpose of Section 43 is the conduct and affairs of the corporate debtor. If the beneficiary of
the transaction in question is a related party of the corporate debtor, the period of enquiry is
enlarged to two years whereas this period is one year in other cases. During such scanning, by virtue
of sub-section (3) of Section 43, two types of transfers are kept out of the purview of sub-section (2),
which would not be treated as preference. Though in the present case, we are concerned only with
the phraseology occurring in clause (a) of sub-section (3) but, we may usefully refer to clause (b)
thereof, for an insight into the underlying concept for providing exception in regard to certain
transfers and keeping them out of the purview of ‘preference’.
25.2.1. By virtue of clause (b) of sub-section (3) [read with Explanation thereto], any transfer
creating a security interest in the property ‘acquired’ by the corporate debtor is not to be treated as
preference to the extent that such security interest secures new value in monetary terms or in terms
of goods, services or new credit or in release of a previously transferred property. Any micro
dissection of clause (b) of sub-section (3) of Section 43 is not required in the present case. Suffice it
to notice that even a bare look at the provision brings forth the concept that value enhancement or
strengthening of the corporate debtor ought to be the result of a transfer, if it is to remain out of the
ambit of sub-section (2) and not to fall within the mischief of being preferential. 25.2.2. Another
feature of vital importance is that the matter is examined with reference to the dealing and conduct
of the corporate debtor; and qua the health and prospects of the corporate debtor. Applying the
well-known principles of noscitur a sociis, whereunder the questionable meaning of a doubtful word
could be derived and understood from its associates and context; and usefully recapping that the
scheme of Section 43 of the Code is essentially of scanning through the affairs of the corporate
debtor and to discredit and disregard such transaction by the corporate debtor which tends to give
unwarranted benefit to one of its creditor/surety/guarantor over others, in our view, the purport of
clause (a) of sub-section (3) of Section 43 is also principally directed towards the corporate debtor’s
dealings. In other words, the whole of conspectus of sub-section (3) is that only if any transfer is
found to have been made by the corporate debtor, either in the ordinary course of its business or
financial affairs or in the process of acquiring any enhancement in its value or worth, that might be
considered as having been done without any tinge of favour to any person in preference to others
and thus, might stand excluded from the purview of being preferential, subject to fulfilment of other
requirements of sub-section (3) of Section 43.
25.3. Needless to reiterate that if the transfer is examined with reference to the ordinary course of
business or financial affairs of the transferee alone, it may conveniently get excluded from the rigour
of sub-section (2) of Section 43, even if not standing within the scope of ordinary course of business
or financial affairs of the corporate debtor. Such had never been the scheme of the Code nor the
intent of Section 43 thereof. It has rightly been contended on behalf of the appellants that for the
purpose of exception under clause (a) of sub-section (3) of Section 43, the intent of legislature is
required to be kept in view. If the ordinary course of business or financial affairs of the transferee
(lenders of JAL in the present case) would itself be decisive for exclusion, almost every transferAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

made to the transferees like the lender-banks/financial institutions would be taken out of the net,
which would practically result in frustrating the provision itself.
25.4. It remains trite that an interpretation that defeats the scheme, intent and object of the
statutory provision is to be eschewed and for that matter, if necessary, by applying the principles of
purposive interpretation rather than literal. In the case of R.M.D. Chamarbaugwala (supra), the
Constitution Bench of this Court has held that well known cannons of construction of statutes
permit the Court to read the word “or” as “and” after looking at the clear intention of the legislature.
In the case of Mazagaon Dock Ltd (supra), when the expression “or” occurring in sub-section (2) of
Section 42 of the Income Tax Act, 1922 did appear bringing out the result which could not have been
intended, the same was read in the context as meaning “and”. This Court said:
“10. The word “or” in the clause would appear to be rather inappropriate, as it is
susceptible of the interpretation that when some profits are made but they are less
than normal profits, tax could only be imposed either on the one or on the other, and
that accordingly a tax on the actual profits earned would bar the imposition of tax on
profits which might have been received. Obviously, that could not have been
intended, and the word “or” would have to be read in the context as meaning
“and”….” 25.5. Looking to the scheme and intent of the provisions in question and
applying the principles aforesaid, we have no hesitation in accepting the submissions
made on behalf of the appellants that the said contents of clause
(a) of sub-section (3) of Section 43 call for purposive interpretation so as to ensure
that the provision operates in sync with the intention of legislature and achieves the
avowed objectives. Therefore, the expression “or”, appearing as disjunctive between
the expressions “corporate debtor” and “transferee”, ought to be read as “and”; so as
to be conjunctive of the two expressions i.e., “corporate debtor” and “transferee”.
Thus read, clause (a) of sub-section (3) of Section 43 shall mean that, for the
purposes of sub-section (2), a preference shall not include the transfer made in the
ordinary course of the business or financial affairs of the corporate debtor and the
transferee. Only by way of such reading of “or” as “and”, it could be ensured that the
principal focus of the enquiry on dealings and affairs of the corporate debtor is not
distracted and remains on its trajectory, so as to reach to the final answer of the core
question as to whether corporate debtor has done anything which falls foul of its
corporate responsibilities.
25.6. The result of discussion in the foregoing paragraphs is that the transfers in question could be
considered outside the purview of sub-section (2) of Section 43 of the Code only if it could be shown
that same were made in the ‘ordinary course of business or financial affairs’ of the corporate debtor
JIL and the transferees. Even if transferees submit that such transfers had been in the ordinary
course of their business, the question would still remain if the transfers were made in the ordinary
course of business or financial affairs of the corporate debtor JIL so as to fall within the exception
provided by clauseAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

(a) of sub-section (3) of Section 43 of the Code.
25.6.1. Thus, the enquiry now boils down to the question as to whether the impugned transfers were
made in the ordinary course of business or financial affairs of the corporate debtor JIL. It remains
trite that an activity could be regarded as ‘business’ if there is a course of dealings,which are either
actually continued or contemplated to be continued with a profit motive.43 As regards the meaning
and essence of the expression ‘ordinary course of business’, reference made by the appellants to the
decision of the High Court of Australia in Downs Distributing Co (supra), could be usefully
recounted as under:-
“As was pointed out in Burns v. McFarlane the issues in sub-s. 2(b) of s. 95 of the
Bankruptcy Act 1924-1933 are “(1) good faith; (2) valuable consideration; and (3)
ordinary course of business.” This last expression it was said “does not require an
investigation of the course pursued in any particular trade or vocation and it does not
refer to what is normal or usual in the business of the debtor or that of the creditor.”
It is an additional requirement and is cumulative upon good faith and valuable
consideration. It is, therefore, not so much a question of fairness and absence of
symptoms of bankruptcy as of the everyday usual or normal character of the
transaction. The provision does not require that the transaction shall be in the course
of any particular trade, vocation or business. It speaks of the course of business in
general. But it does suppose that according to the ordinary and common flow of
transactions in affairs of business there is a course, an ordinary course. It means that
the transaction must fall into place as part of the undistinguished common flow of
business done, that it should form part of the ordinary course of business as carried
on, calling for no remark and arising out of no special or particular situation.”
(emphasis supplied) 25.6.2. Taking up the transactions in question, we are clearly of
the view that even when furnishing a security may be one of normal business
practices, it would become a part of ‘ordinary course of business’ of a particular
corporate entity only if it falls in place as part of ‘the undistinguished common flow of
business done’; and is not arising out of ‘any special or particular situation’, as rightly
expressed in Downs Distributing Co (supra). Though we may assume 43 vide State of
Andhra Pradesh v. H. Abdul Bakshi and Bros.: 1964 STC 644 (at p. 647).
that the transactions in question were entered in the ordinary course of business of bankers and
financial institutions like the present respondents but on the given set of facts, we have not an iota
of doubt that the impugned transactions do not fall within the ordinary course of business of the
corporate debtor JIL. As noticed, the corporate debtor has been promoted as a special purpose
vehicle by JAL for construction and operation of Yamuna Expressway and for development of the
parcels of land along with the expressway for residential, commercial and other use. It is difficult to
even surmise that the business of JIL, of ensuring execution of the works assigned to its holding
company and for execution of housing/building projects, in its ordinary course, had inflated itself to
the extent of routinely mortgaging its assets and/or inventories to secure the debts of its holding
company. It had also not been the ordinary course of financial affairs of JIL that it would create
encumbrances over its properties to secure the debts of its holding company. In other words, we areAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

clearly of the view that the ordinary course of business or financial affairs of the corporate debtor
JIL cannot be taken to be that of providing mortgages to secure the loans and facilities obtained by
its holding company; and that too at the cost of its own financial health. As noticed, JIL was already
reeling under debts with its accounts with some of the lenders having been declared NPA; and it was
also under heavy pressure to honour its commitment to the home buyers. In the given
circumstances, we have no hesitation in concluding that the transfers in questions were not made in
ordinary course of business or financial affairs of the corporate debtor JIL. 25.7. The submissions
that security was disclosed in the Annual Reports or that none of the creditors expressed dissent are
of no effect because such disclosure or want of objection by creditors, by themselves, do not operate
as estoppel against anybody nor would take the transaction out of the purview of the legal fiction
predicated in Section 43, if it is otherwise of a preference at a relevant time. Similarly, the
distinction between ‘NPA’ and ‘wilful default’; the submission that NPA could be regularised; and
further the submission that the mortgages were created before JIL was declared NPA, are hardly of
any bearing on the question as to whether the impugned transactions had been in the ordinary
course of business or financial affairs of JIL. Thus, reference to the decisions like that in Keshavlal
Khemchand and Jah Developers (supra) is not of any consequence and need not be dilated upon.
The answer to this question, in our view, could only be in the negative. That is to say that the
impugned transactions had not been in the ordinary course of business or financial affairs of JIL.
25.8. Therefore, the answer to question (v) as referred in paragraph 20 is that the impugned
transactions are not of excepted transfers in terms of sub- section (3) of Section 43 of the Code.
The concern expressed by lenders of JAL is legally untenable
26. The argument of lenders, that holding the transactions in question as preferential would result
in impacting large number of transactions undertaken by the bankers/financial institutions, of
financing in the ordinary course of their business; and the consequences may be devastating and
irreversible on the economy, has only been noted to be rejected.
26.1. It needs hardly any emphasis that in the ordinary course of their business, when the bankers or
financial institutions examine any proposal for loan or advance or akin facility, they are supposed to,
and they indeed, take up the exercise commonly termed as ‘due diligence’ 44 so as to study the
viability of the proposed enterprise as also to ensure, inter alia, that the security against such
loan/advance/facility is genuine and adequate; and would be available for enforcement at any point
of time. Given the nature of transaction, the lenders must prefer a clean security to justify the
transaction as being in the ordinary course of their business. In the same exercise, in the ordinary
course of their business, if they are at all entering into a transaction whereby a third party security,
including that of a subsidiary company, is to be taken as collateral, they are obliged to undertake
further due diligence so as to ensure 44 As regards the present context, the term ‘due diligence’ is
explained in P. Ramanatha Aiyar’s Advanced Law Lexicon (5th Ed.-Vol 2, p.1654) in the following:
“The detailed review of the borrower/issuer’s overall position, which is supposed to
be undertaken by the lead manager of a new financing in conjunction with the
preparation of legal documentation.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

Analysis of the financial status and prospects of company before it receives a major
investment of capital. It is usually carried out by an independent accountant.” that
such third party security is a prudent and viable one and is not likely to be hit by any
law. In that sequence, they remain under obligation to assure themselves that such
third party whose security is being taken, is not already indebted or in red and is not
likely to fail in dealing with its own indebtedness.
In the context of IBC, such requirement is moreover imperative on a bare look at the
provisions contained in Part II thereof. Interesting it is to notice on the facts of the
present case that in fact, several of the respondent lenders are shown to be the direct
creditors of JIL too, to the extent of the advances made to JIL. They and the
co-respondents cannot plead ignorance about the actual state of affairs and financial
position of JIL. Despite such knowledge, if they chose to take the business risk of
accepting security from JIL and that too, for securing the loans/advances/facilities
made over to JAL, who was a directly related party of JIL for being its holding
company, they themselves remain responsible for present legal consequences.
Summation: The transactions in question are hit by Section 43 IBC
27. For what has been discussed hereinabove, we are clearly of the view that the
transactions in question are hit by Section 43 of the Code and the Adjudicating
Authority, having rightly held so, had been justified in issuing necessary directions in
terms of Section 44 of the Code in relation to the transactions concerning Property
Nos. 1 to 6. NCLAT, in our view, had not been right in interfering with the
well-considered and justified order passed by NCLT in this regard.
Search and commandeering of preference at a relevant time
28. Although we have analysed the transactions in question on the anvil of Section 43 with reference
to the submissions made and the facts of the present case but, before moving on to other aspects, we
deem it appropriate to point out the manner in which the provisions concerning preference at a
relevant time are expected to be applied, particularly by the resolution professional, in a given case.
It could be readily recapitulated that as per the charging parts of Section 43 i.e., sub-sections (4) and
(2) thereof, a corporate debtor shall be deemed to have given preference at a relevant time if the
twin requirements of clauses (a) and (b) of sub-section (2) coupled with the applicable requirements
of either clause (a) or clause (b) of sub-section (4), as the case may be, are satisfied. However, even if
the requirements of sub- sections (4) and (2) are satisfied, a transaction may not be regarded as an
offending preference if it falls in either or both of the exceptions provided by sub-section (3) of
Section 43.
28.1. Looking to the legal fictions created by Section 43 and looking to the duties and
responsibilities per Section 25, in our view, for the purpose of application of Section 43 of the Code
in any insolvency resolution process, what a resolution professional is ordinarily required to do
could be illustrated as follows:Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

1. In the first place, the resolution professional shall have to take two major but
distinct steps. One shall be of sifting through the entire cargo of transactions relating
to the property or an interest thereof of the corporate debtor backwards from the date
of commencement of insolvency and up to the preceding two years. The other distinct
step shall be of identifying the persons involved in such transactions and of putting
them in two categories; one being of the persons who fall within the definition of
‘related party’ in terms of Section 5(24) of the Code and another of the remaining
persons.
2. In the next step, the resolution professional ought to identify as to in which of the
said transactions of preceding two years, the beneficiary is a related party of the
corporate debtor and in which the beneficiary is not a related party. It would lead to
bifurcation of the identified transactions into two sub-sets: One concerning related
party/parties and other concerning unrelated party/parties with each sub-set
requiring different analysis. The sub-set concerning unrelated party/parties shall
further be trimmed to include only the transactions of preceding one year from the
date of commencement of insolvency.
3. Having thus obtained two sub-sets of transactions to scan, the steps thereafter
would be to examine every transaction in each of these sub-sets to find: (i) as to
whether the transaction is of transfer of property or an interest thereof of the
corporate debtor; and (ii) as to whether the beneficiary involved in the transaction
stands in the capacity of creditor or surety or guarantor qua the corporate debtor.
These steps shall lead to shortlisting of such transactions which carry the potential of
being preferential.
4. In the next step, the said shortlisted transactions would be scrutinised to find if the
transfer in question is made for or on account of an antecedent financial debt or
operational debt or other liability owed by the corporate debtor. The transactions
which are so found would be answering to clause (a) of sub-section (2) of Section 43.
5. In yet further step, such of the scanned and scrutinised transactions that are found
covered by clause (a) of sub-section (2) of Section 43 shall have to be examined on
another touchstone as to whether the transfer in question has the effect of putting
such creditor or surety or guarantor in a beneficial position than it would have been
in the event of distribution of assets per Section 53 of the Code. If answer to this
question is in the affirmative, the transaction under examination shall be deemed to
be of preference within a relevant time, provided it does not fall within the exclusion
provided by sub-section (3) of Section
43.
6. In the next and equally necessary step, the transaction which otherwise is to be of
deemed preference, will have to pass through another filtration to find if it does notAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

answer to either of the clauses (a) and (b) of sub-section (3) of Section 43.
7. After the resolution professional has carried out the aforesaid volumetric as also
gravimetric analysis of the transactions on the defined coordinates, he shall be
required to apply to the Adjudicating Authority for necessary order/s in relation to
the transaction/s that had passed through all the positive tests of sub-section (4) and
sub-section (2) as also negative test of sub-section (3).
28.2. On a motion made by the resolution professional after and in terms of the exercise aforesaid,
the Adjudicating Authority, in its turn, shall have to examine if the referred transaction answers to
all the descriptions noted above and shall then decide as to what order is required to be passed, for
avoidance of the impugned transaction or otherwise.
28.3. In our view, looking to the legal fictions created by Section 43 and looking to the duties and
responsibilities of the resolution professional and the Adjudicating Authority, ordinarily an
adherence to the process illustrated hereinabove shall ensure reasonable clarity and less confusion;
and would aid in optimum utilization of time in any insolvency resolution process. Other aspects of
the application made by IRP – allegations of transactions being undervalued and fraudulent
29. Having found that the transactions in question cannot be countenanced, for being of preference
during a relevant time to a related party; and having approved the order passed by NCLT in that
regard, we do not consider it necessary to deal with the other length of arguments advanced by the
learned counsel for parties on the questions as to whether the transactions are undervalued and/or
fraudulent too. In the totality of circumstances, we would prefer leaving the said questions at that
only, while also leaving all the related questions of law open; to be examined in an appropriate case.
29.1. However, we are impelled to make one comment as regards the application made by IRP. It is
noticed that in the present case, the IRP moved one composite application purportedly under
Sections 43, 45 and 66 of the Code while alleging that the transactions in question were preferential
as also undervalued and fraudulent. In our view, in the scheme of the Code, the parameters and the
requisite enquiries as also the consequences in relation to these aspects are different and such
difference is explicit in the related provisions. As noticed, the question of intent is not involved in
Section 43 and by virtue of legal fiction, upon existence of the given ingredients, a transaction is
deemed to be of giving preference at a relevant time. However, whether a transaction is undervalued
requires a different enquiry as per Sections 45 and 46 of the Code and significantly, such application
can also be made by the creditor under Section 47 of the Code. The consequences of undervaluation
are contained in Sections 48 and 49. Per Section 49, if the undervalued transaction is referable to
sub-section (2) of Section 45, the Adjudicating Authority may look at the intent to examine if such
undervaluation was to defraud the creditors. On the other hand, the provisions of Section 66 related
to fraudulent trading and wrongful trading entail the liabilities on the persons responsible therefor.
We are not elaborating on all these aspects for being not necessary as the transactions in question
are already held preferential and hence, the order for their avoidance is required to be approved; but
it appears expedient to observe that the arena and scope of the requisite enquiries, to find if the
transaction is undervalued or is intended to defraud the creditors or had been of
wrongful/fraudulent trading are entirely different. Specific material facts are required to be pleadedAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

if a transaction is sought to be brought under the mischief sought to be remedied by Sections
45/46/47 or Section 66 of the Code. As noticed, the scope of enquiry in relation to the questions as
to whether a transaction is of giving preference at a relevant time, is entirely different. Hence, it
would be expected of any resolution professional to keep such requirements in view while making a
motion to the Adjudicating Authority. 29.2. In the present case, it is noticed that NCLT in its
detailed and considered order essentially dealt with the features of the transaction in question being
preferential at a relevant time but recorded combined findings on all these three aspects that the
impugned transactions were preferential, undervalued and fraudulent. Appropriate it would have
been to deal with all these aspects separately and distinctively.
29.3. We are conscious of the fact that IBC is comparatively a new legislation and various aspects
expected therein are in the progression of taking proper shape, particularly in the adjudicatory
processes envisaged. Having said so, we would leave this aspect at that only, while expecting all the
concerned to be more attentive to the scheme, object and requirements of the provisions contained
in the Code.
SECOND       ISSUE:      WHETHER       LENDERS       OF    JAL     COULD     BE
CATEGORISED AS FINANCIAL CREDITORS OF JIL
Preliminary and background
30. The discussion and summation in the foregoing paragraphs and conclusion on the first issue
itself would have been the end of the matter because the transactions in question stand disapproved
as being preferential. However, there remains another significant issue to be adjudicated herein,
which, though not adverted to by NCLAT, is indeed involved in these matters. 30.1. The issue is as to
whether the lenders of JAL could be categorised as financial creditors of JIL for the purpose of IBC?
31. The issue aforesaid was raised before NCLT by two of the respondent banks namely, ICICI Bank
Limited and Axis Bank Limited by way of separate applications under Section 60(5) of the Code,
seeking to question the decision of IRP rejecting their claims to be recognized as financial creditors
of the corporate debtor JIL on account of the securities provided by JIL for the facilities granted to
JAL. The NCLT rejected the applications so filed, by way of its orders dated 09.05.2018 and
15.05.2018 respectively, while concluding that on the strength of the mortgages created by the
corporate debtor JIL, as collateral security of the debts of its holding company JAL, the applicants
cannot be treated as financial creditors of the corporate debtor JIL. 31.1. The aforesaid orders dated
09.05.2018 and 15.05.2018 were questioned before NCLAT by the said lenders of JAL in Comp. App
(AT) (Ins) No. 353 of 2018 and Comp. App (AT) (Ins) No. 301 of 2018 respectively. These appeals
formed part of the bunch of appeals decided by NCLAT by way of the impugned common order
dated 01.08.2019 and, as per the final result recorded therein, these two appeals also stand allowed.
However, fact of the matter remains that nothing has been discussed by NCLAT in the impugned
order dated 01.08.2019 as regards the subject-matter of these two appeals i.e., as to whether the said
lenders of JAL could be categorised as financial creditors of JIL or not; and the entire discussion in
the impugned order and the final conclusion therein had only been in relation to the order dated
16.05.2018 that was passed by NCLT on the application for avoidance filed by IRP. 31.2. TheAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

appellant of Civil Appeal D. No. 32881 of 2019, IIFCL, apart from raising other contentions, has also
questioned this aspect of the order impugned that the aforesaid two appeals, involving the issue as
to whether the mortgagees of the corporate debtor could be taken as financial creditors, have been
allowed by NCLAT without recording any findings and without any discussion in that regard.
31.3. Though, ordinarily, such omission in the impugned order dated 01.08.2019 might have
resulted in the matter being remitted to the Appellate Tribunal for appropriate consideration and
finding but, as aforesaid, in the entire process, adherence to the time limit is also of significance;
and in view of the fact that learned counsel for the respective parties have advanced elaborate
submissions on the merits of the issue as to whether such lenders of JAL could be treated as
financial creditors of the corporate debtor JIL and have invited the decision of this Court, we deem
it just, proper and expedient to finally decide the relevant questions in this regard. 31.4. We may, of
course, reiterate that in view of the conclusion that we have reached in relation to the principal
issue, the transactions in question are denuded of their value and worth, per the force of the order
by NCLT under Section 44 of the Code, which has been approved by us. To be more specific, the
security interests created by the corporate debtor JIL over the properties in question stand
discharged in whole. Therefore, the respondent-lenders cannot claim any status as creditors of the
corporate debtor JIL and there could arise no question of their making any claim to be treated as
financial creditors as such. However, for its relevance, we deem it appropriate to determine the issue
as to whether the lenders of JAL, because of creation of the mortgages in question, could be treated
as financial creditors of JIL, independent of the finding that the transactions in question are hit by
Section 43 of the Code.
32. Before proceeding further, apposite it would be to take note of the reasons assigned by NCLT in
its impugned orders for rejecting the claim of two of the lender banks to be treated as financial
creditors of JIL. Reasoning and Findings of NCLT
33. The Adjudicating Authority, NCLT, in its order dated 09.05.2018 as passed on the application
moved by ICICI Bank Limited, with reference to the nature of transaction in question, whereby JIL
had extended collateral security towards the facility extended to its holding company JAL as also
with reference to the definition and connotations of the expressions ‘financial debt’ and ‘financial
creditor’ as occurring in IBC, essentially proceeded to find that in such a transaction, as regards the
corporate debtor JIL, no consideration for time value for money was involved; and hence, the
transaction in question did not qualify as ‘financial debt’ qua the corporate debtor JIL. The NCLT,
inter alia, observed as under:-
“9. In the present case undisputedly corporate debtor has mortgaged its property for
creating collateral security for the debt of its holding company JAL. The Corporate
debtor is not a borrower, it has created a mortgage in favour of financial institutions
for creating collateral security for the money borrowed by its holding company JAL.
In the said transaction time value of money is not involved. The corporate debtor’s
liability is not regarding the debt owed by its holding company JAL. In case of default
in making payment by the principal borrower, for which security interest has been
created by the corporate debtor by mortgaging its property in favour of ApplicantAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

bank, the debt amount can be realized from the sale of the mortgaged property but
not from the corporate debtor, i.e. Jaypee Infratech Ltd.
*** *** *** 9.2 In this case, the applicant has not disbursed the debt along with
interest against the consideration for the time value of money. It is also not the case
of the applicant that the corporate debtor has borrowed money against payment of
interest from the applicant. It is also not the case that the corporate debtor has raised
any amount from the applicant under any credit facility. It is not the case of the
applicant that there is any liability towards the corporate debtor in respect of any
lease or higher purchase contract. It is further not the case of an applicant that any
receivables been sold or discounted. It is further not the case of the applicant that any
amount has been raised for the corporate debtor under any other transaction having
the commercial effect of borrowing to the corporate debtor. It is not the case of the
applicant that any derivative transaction has been entered with the corporate debtor.
It is also not the case of the applicant that any counter indemnity obligation in
respect of a guarantee, indemnity, bond, documentary, letter of credit or any other
instrument issued by a bank or a financial institution for the corporate debtor.
Further, no amount of any liability in respect of any of the guarantee or indemnity for
any of the items referred to above has been issued by the corporate debtor.” 33.1. The
NCLT also distinguished the decision of this Court in the case of Rajkumari
Kaushalya Devi v. Bawa Pritam Singh & Anr.: AIR 1960 SC 1030, as relied upon by
the learned counsel for the applicant, while pointing out the distinct context of the
said decision and while observing that the connotations of the expressions ‘debt’,
‘financial debt’, ‘financial creditor’ and ‘creditor’ in the present context would be
limited to the definitions given in the Code. The NCLT further distinguished the
decision of Gujarat High Court in the case of State Bank of India v. Smt. Kusum
Vallabhdas Thakkar: 1991 SCC Online Guj 14, while again pointing out that in the
present case, the corporate debtor has created a mortgage of its property in favour of
third party without any consideration for time value of money.
33.2. Yet further, the NCLT rejected the contentions that the transaction in question
could be termed as either ‘guarantee’ or ‘indemnity’ while observing, inter alia, as
under:-
“13. The contention of the applicant that mortgage created by the corporate debtor
can be termed as either a guarantee or indemnity is not tenable. In terms of the
mortgage deeds the corporate debtor has created a mortgage over its immovable
properties, which is either money borrowed against payment of interest nor
indemnity or a guarantee as claimed by the applicant and therefore, the same does
not fall within the definition of the financial debt in terms of Sec. 5 (8) of IBC. It is
stated that the corporate debtor has neither issued any guarantee nor has provided
an indemnity to the applicant in respect of the financial assistance granted to JAL.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

14. The Resolution Professional further submitted that the mortgage deed shows that
the corporate debtor has only agreed to create a mortgage in favour of the applicant
towards the financial assistance granted to its holding company, i.e. JAL. On perusal
of mortgage it is clear that the corporate debtor has neither given any guarantee to
repay or any indemnity qua the repayment of the loans granted by the applicant to
JAL. The definition of Mortgage Debt as per the mortgage deed dated 7 th March
2017 is as under : -
“Mortgage debt shall mean the principal amount of the facility, all interest therein
additional interest, default interest, liquidated damages, fees, costs, charges,
expenses, any other amounts due and payable to secured parties under the
transaction documents, premia on prepayment, costs, charges, and expenses and
other monies whatsoever stipulated in or payable together with other debts and
liabilities of JAL to lender under the transaction document and/or these presents.” It
is important to point out that sec. 124 of the Indian Contract Act defines a “Contract
of Indemnity” as being a contract by which one party promises to save the other from
loss caused to him by the conduct of the promisor himself or by the conduct of any
other person. In the instant case, as per the Mortgage deed the repayment obligation
of the loan granted to JAL by the applicant is upon JAL as stated above and therefore,
no contract of indemnity as claimed by the applicant has been entered even by
conduct of the corporate debtor, and therefore, the contention of the applicant that
the applicant is a financial creditor of the corporate debtor is completely untenable in
law.” 33.3. While observing that in the scheme of the Code and CIRP Regulations
thereunder, the claims are invited from the creditors of the corporate debtor i.e.,
financial creditors, operational creditors and other creditors, and not from any
person or creditors of the holding company of the corporate debtor; and while further
observing that the resolution professional had righty observed that the mortgages in
questions were not like guarantee or indemnity, NCLT observed that the basic
ingredient of financial debt i.e., ‘debt alongwith interest disbursed against time value
of money’ was lacking in the impugned transactions. NCLT also referred to the
interpretation of the expression ‘financial creditors’ by NCLAT in the case of Nikhil
Mehta and Sons v. AMR Infrastructure Ltd. Company: Appeal (AT) (Insolvency) No.
07 of 2017 and endorsed the decision of IRP while holding that,-
“15. ….On the above basis, we are of the view that The Resolution Professional has correctly rejected
the claim of the applicant on the ground that the Applicant is not a financial creditor of the
corporate debtor concerning the Mortgages and the Mortgaged Debt. The resolution professional
has rightly observed that guarantee and indemnity are distinct documents under the relevant laws
and the mortgages executed by the corporate debtor are not like guarantee and indemnity. The basic
ingredient of the financial debt as defined under the Code is that debt along with interest disbursed
against time value of money lacks in the impugned transaction….” 33.4. Accordingly, NCLT rejected
the application of ICICI Bank Limited by way of its order dated 09.05.2018, while concluding as
under:-Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

“…Therefore, by the mortgage created by the corporate debtor, as collateral security
by the debt of its holding company, i.e. Jaiprakash Associates Ltd. (“JAL”) in favour
of the Applicant i.e. ICICI Bank, the applicant cannot be treated as Financial Creditor
of the Corporate Debtor. Therefore in our view, Resolution Professional has rightly
rejected the claim of the applicant, which was filed by the Applicant in the capacity of
Financial Creditors of the corporate debtor, i.e. Jaypee Infratech Ltd. (“JIL”)”.
33.4.1. Thereafter, the other application filed by Axis Bank Limited was rejected by
NCLT on 15.05.2018, while following the earlier order dated 09.05.2018.
34. As noticed, the aforesaid orders dated 09.05.2018 and 15.05.2018 were questioned in two
appeals before NCLAT by the said lenders of JAL; and the said appeals stand allowed in the
impugned order dated 01.08.2019 without any discussion as regards the issue involved therein. We
have heard learned counsel for the parties at length in relation to this issue too, and, in the
circumstances of the case, as noticed, we had indicated prima facie view in the order dated
10.12.201945, that such lenders of JAL cannot be categorised as financial creditors of JIL and had
stayed the operation of impugned order to that extent.
Rival submissions
35. Having noticed the relevant background, we may now take note of the contentions of learned
counsel for the parties in regard to the issue under consideration.
45 Reproduced in paragraph 7 hereinbefore.
Submissions on behalf of the appellant
36. It has essentially been argued on behalf of the appellant IIFCL that as per sub-section (7) of
Section 5 of the Code, only such creditor could be the ‘financial creditor’ of the corporate debtor to
whom a ‘financial debt’ is owed by the corporate debtor; and, as per sub-section (8) of Section 5 of
the Code, the key requirement of a financial debt is ‘disbursal against the consideration for the time
value of money’, which includes the events or modes of disbursement as enumerated in sub-clauses
(a) to (i) of Section 5(8). It is submitted that in the present case, the lenders of JAL having not
disbursed any debt against the consideration for the time value of money to the corporate debtor
JIL, the corporate debtor does not owe any ‘financial debt’ to such lenders; and the transactions in
question do not fall within the brackets of ‘financial debt’ only for the reason that the corporate
debtor JIL created mortgages as collateral security in favour of lender banks for the money
borrowed by JAL. Concisely put, the submission is that in the said mortgage transactions, disbursal
against the consideration for the time value of money qua the corporate debtor JIL being not
involved, the lenders of JAL are not the ‘financial creditors’ of JIL and cannot be included in the
Committee of Creditors 46, as to be constituted per Section 21 of the Code.
36.1. It is further submitted that the said lenders of JAL have no right to demand the mortgage
money from the corporate debtor nor is the corporate 46 ‘CoC’ for short debtor JIL under anyAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

liability to pay the same; and mere holding of security interest, which too had not been extended for
direct disbursement of any credit to JIL, cannot make the JAL lenders as financial creditors of JIL
within the meaning of IBC. Learned counsel for the appellant has referred to the judgment and
order dated 22.12.2017 by the NCLAT in Dr. B.V.S. Lakshmi v. Geometrix Laser Solutions (P) Ltd.:
Company Appeal (AT) (Insolvency) No. 38 of 2017, to substantiate this submission.
36.2. It is contended on behalf of the appellant that though the definition of ‘financial debt’ extends
to include various types of transactions, yet it does not include a mortgage, as could be gathered
from a plain and simple reading of the said provision. The counsel for the appellant has further
relied on the judgment of this Court in Swiss Ribbons (supra), wherein the concept of ‘financial
creditor’ has been explicated to mean and include a person who has direct engagement in the
functioning of corporate debtor right from the beginning, while assessing the viability of corporate
debtor; and who would also engage in restructuring of debts and reorganising the corporate
business in case of financial stress. With reference to the case at hand, it is submitted that mere
holding of security interest, not meant for direct disbursement of any credit to corporate debtor JIL,
cannot convert the lenders of JAL into the financial creditors of JIL.
36.2.1. It is also contended that the respondents, the lenders of JAL to whom mortgages were
extended by the corporate debtor JIL, could at best be construed as plain creditors, who are entitled
to file Form F and to specify their security in column 8 thereof; and in any case, they cannot become
financial creditors of JIL.
36.2.2. It is further contended that a secured creditor under the Code can be a financial creditor
under two circumstances i.e., (i) when corporate debtor directly avails a debt from the creditor and
such a debt is a secured debt; and
(ii) if corporate debtor furnishes a guarantee to any person. Learned counsel for the appellant
submits that a mortgagee, who has not disbursed any debt to the corporate debtor, may be a secured
creditor because of the corporate debtor creating a security to secure the payment of a third party
but cannot be a financial creditor of the corporate debtor within the meaning of Section 5(8) of the
Code.
36.3. Elaborating on the submissions relating to the nature of transactions, learned counsel for the
appellant has strenuously argued that ‘mortgage’ is not included within the framework of Section
5(8) of the Code and its sub-clauses
(a) to (i); and that ‘financial debt’ is limited only to the transactions enumerated thereunder and its
coverage cannot be enlarged while interpreting the provision. It is also argued that ‘mortgage’
cannot be deemed to mean ‘guarantee’, for a mortgagor has no intentions to undertake to discharge
the liability of a third person in case of his default in repayment of debts. In other words, only where
the debtor and the mortgagor are the same person that the mortgagor would be liable to pay his
debts and else, the mortgage itself does not create a pecuniary liability. Moreover, in the present
case, when there is a tri-partite contract wherein, the mortgagor and debtor are different, the
impugned transactions do not satisfy the ingredients of Section 126 of the Contract Act, as JIL hasAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

not undertaken specifically to discharge the liability of JAL nor has entered into a ‘contract of
guarantee’ with the lenders of JAL nor has provided any indemnity; and therefore, the corporate
debtor JIL is not bound by any liabilities and obligations incurred by JAL. To support the contention
that liability always flows from debt and not from the security created under the mortgage, learned
counsel for the appellant has also relied on several decisions including that in Ramchand Sur v.
Ishwar Chandra Giri:
61 Ind Cases 539.
36.4. It is submitted that a general reference to the transaction documents would not
be sufficient to fasten liability for JIL to pay any outstanding debt of JAL because any
payment obligation has to be unequivocal and ought to be of specific undertaking to
discharge such obligations; and that general words of incorporation or general
covenant in some mortgage deeds cannot bind JIL to all the terms and conditions of
the documents, particularly any liability to incur JAL’s indebtedness by fastening
payment obligations. It is further submitted that when the intention of parties is
ascertained with reference to the terms of documents and all the surrounding factors,
it cannot be inferred that JIL undertook the liability to discharge the indebtedness of
JAL when it was itself reeling under financial stress, was declared NPA and had
surmounting liabilities towards home buyers and its own lenders. With reference to
the financial statements of JIL, it is pointed out that therein, it was specifically
disclosed that the mortgages had been provided as a security for the financial
assistance availed by JAL but such mortgages were not declared either as contingent
or as direct liability. It is also submitted that the common loan agreement between
JIL and its lenders, including the appellant, contained negative covenants prohibiting
JIL from creating, assuming or incurring any additional indebtedness or from
encumbering any property or creating any security on the assets of JIL. The sum and
substance of such submissions had been that the corporate debtor JIL could have
neither incurred a liability to discharge the indebtedness of JAL nor it had done so
under the mortgages in question.
36.5. As regards the decision of this Court in Committee of Creditors of Essar Steel
India Limited through Authorised Signatory v. Satish Kumar Gupta : 2019 SCC
OnLine SC 1478 47, as relied upon by the respondents, learned counsel for the
appellant has submitted that the generalised assertion on the part of the respondents,
that per the force of the said decision, a secured creditor ipso facto becomes financial
creditor, is not a correct appreciation of the ratio thereof. It is submitted that in the
scheme of the Code, a secured creditor could also be a financial creditor under two
circumstances:
First, when the corporate debtor directly avails a debt from the creditor and 47
Hereinafter also referred to as the case of ‘Essar Steel’.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

such debt is secured by a security interest like in the form of a charge or mortgage or hypothecation;
and such a creditor, the secured one, is regarded as financial creditor because of direct disbursement
of debt to the corporate debtor; and secondly, when the corporate debtor furnishes guarantee to any
person, such person would also become a financial creditor and a secured creditor by virtue of
sub-clause (i) of Section 5(8) of the Code, of course, such guarantee may even be to secure the debt
obligation of a third party. However, according to the counsel for the appellant, when the corporate
debtor creates mortgage to secure payment obligation of a third party, without disbursement of any
debt to itself (the corporate debtor), the mortgagee, even if becoming a secured creditor because of
creation of mortgage, could only be described as ‘indirect secured creditor’ and cannot be treated as
a ‘direct secured creditor’ so as to become a ‘financial creditor’ because, the mortgage transaction is
not envisaged to be a ‘financial debt’ in Section 5(8) with its sub- clauses (a) to (i).
36.5.1. It is submitted that Essar Steel judgment envisages the position and priorities of secured
creditors, mainly in the context of a creditor who has disbursed direct debt to the corporate debtor
and has secured its debt by a security interest, who should have priority over unsecured creditors of
the corporate debtor. However, the said decision, according to the learned counsel, cannot be read
to the effect that even the indirect secured creditor be also necessarily construed as financial
creditor. It is submitted that the crux of the said decision is that creditors not similarly situated
cannot be at par; that the arrangements of the corporate debtor with its creditors must be taken into
consideration; and that the aim of equitable treatment is based on the notion that creditors with
similar legal rights should be treated evenly while receiving distribution in accordance with their
relative ranking and interest. It is submitted that Essar Steel cannot be read as laying down the law
that even the lenders of third party, who hold mortgages from the corporate debtor, be also treated
as such secured creditors who would fall within the sect of ‘financial creditors’.
36.6. Learned counsel for the appellant would further submit that existence of a security interest is
not relevant while construing whether a creditor is financial creditor or not because, in the
composition of CoC, even a non- secured creditor could also be a financial creditor, if the ingredients
of Section 5(8) of the Code are satisfied. It is also argued that the financial facilities availed by JAL
from the respondents were not utilized for any business operation of JIL and hence, the respondents
cannot be construed as financial creditors of JIL.
Submissions on behalf of respondents
37. Learned counsel for the contesting respondents have made elaborate submissions in support of
the counter-assertion that on account of security provided by the corporate debtor JIL, the
respective lenders have become financial creditors of JIL for the purpose of proceedings under the
Code. We may briefly summarise the principal facets of the contentions urged on behalf of the main
contesting respondents in this regard as infra. Axis Bank 37.1. It has been strenuously argued on
behalf of this respondent that the nature and character of a ‘mortgage’ is such that it secures a debt;
and in the present case, the mortgage in question, as made by JIL, had been to secure the debt
obligations of its holding company JAL. With reference to Section 58 of the Transfer of Property Act
and the decision of this Court in Prithvi Nath Singh & Ors. v. Suraj Ahir & Ors. : (1963) 3 SCR 302 as
also the decision of Mysore High Court in Dassappa & Ors v. Jogaiah & Ors : (1964) ILR 545, it isAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

submitted that the purpose of ‘mortgage’ is to secure a debt; and with reference to the decision in
Manik Chand Raut v. Baldeo Chaudhary & Ors:
(1949) SCCOnline Pat 64, it is also contended that mortgage, by its very nature,
presupposes existence of a debt and the transaction by which a debt is extinguished is
not a mortgage but a sale. Further, with reference to the aforementioned decision of
this Court in case of Rajkumari Kaushalya Devi v. Bawa Pritam Singh & Anr: AIR
1960 SC 1030, it is contended that a mortgage debt creates pecuniary liability upon
the mortgagor; and that a mortgagor who transfers an interest in immovable
property so as to secure a debt, incurs a mortgage debt. With reference to the
decision of Delhi High Court in the case of State Bank of India v. Samneel
Engineering Co. & Ors:
1995 (35) DRJ 485, it is further submitted that a mortgage is both a promise by a
debtor to repay the loan as well as a real property right; of course, the right being
intended to secure the due payment of the debt; and a suit on a mortgage is
essentially a suit for recovery of a debt.
37.1.1. With reference to principles aforesaid, it is contended that a mortgage debt is a
‘debt’ within the meaning of Section 3(11) of the Code; that a debt can be classified to
be a debt due from ‘any person’ and not necessarily restricted to the borrower alone.
The aforementioned decision of Gujarat High Court in State Bank of India v. Smt.
Kusum Vallabhdas Thakkar: 1991 SCCOnline GUJ 14 has again been referred to
submit that Indian Law recognizes that a person, other than the borrower, can also
execute a mortgage to secure the debt of the borrower. In this context, learned
counsel for the respondent has also relied upon the provisions contained in Section
126 of the Contract Act, to contend that JIL stands in the position of a guarantor for
the debts owed by JAL. The learned counsel has also referred to an order dated
13.03.2019 in M.A. No. 1584/2019 in CP No. 402 of 2018 as passed by NCLT
(Mumbai Bench) in the case of SREI Infrastructure Finance Limited v. Sterling
International Enterprises Ltd., wherein it is held that a third party mortgagor, who
mortgages the property to secure the financial obligation of another party, stands in
the position of a guarantor; and the mortgagee is a financial creditor of the third
party mortgagor. In the case at hand, it is submitted, the corporate debtor JIL stands
in the position of a guarantor with respect to the security provided to this respondent
and hence, the impugned mortgage transactions are covered within the meaning of
Section 5(8)(i) of the Code.
37.1.2. It is also submitted that looking to the nature of transaction in question, the
question whether JAL has defaulted on repayment and consequently, the security is
to be invoked is irrelevant for the purposes of the issue at hand; and whether JAL
committed default or not is not decisive of the question as to whether the mortgage
debt in question is financial debt or not.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

37.1.3. It is further submitted that in the present case, the mortgage transactions
were executed to secure the payment of debts/liabilities of JAL;
and that such creation of mortgage undoubtedly is a ‘security interest’ as defined in Section 3(31) of
the Code inasmuch as, a security interest includes any creation of right/title/interest/claim in
property for the purpose of securing the payment or performance of an obligation; and also includes
a mortgage. Hence it is contended that the respondent bank comes within the ambit of ‘secured
creditor’ per Section 3(30) of the Code.
37.1.4. It is emphasised by learned counsel for this respondent that a mortgage debt constitutes a
‘financial debt’ within the meaning of Section 5(8) of the Code even if no amount is directly
disbursed to the corporate debtor. While relying on the decision of this Court in Pioneer Urban Land
and Infrastructure Ltd. & Anr. v. Union of India & Ors.: (2019) 8 SCC 41648, it is contended that the
definition of ‘financial debt’ under Section 5(8) of Code 48 Hereinafter also referred to as the case of
‘Pioneer Urban’ has been given an extended meaning so as to include the situations which may not
directly involve disbursal against the consideration for time value money.
37.1.5.Further, with reference to the aforementioned UNCITRAL Legislative Guide on Insolvency
Law and the decisions of this Court in the cases of Essar Steel and Swiss Ribbons, it is submitted
that a holistic interpretation of the Code would support the position that the respondent, being a
secured creditor and a financial creditor, should be included in CoC so as to protect its security
interest.
37.2. The submissions and contentions made on behalf of this respondent largely cover the stand of
other respondents too. Hence, we may only notice, in brief, the other or additional part of major
submissions on behalf of other respondents, while avoiding repetition.
Standard Chartered Bank 37.3. It is submitted on behalf of this respondent that the terms envisaged
in the mortgage deed dated 24.05.2016 make it abundantly clear that the corporate debtor JIL had
unequivocally promised to pay to this respondent the debts/liabilities owed by JAL in accordance
with the terms and conditions of the secured financing documents executed between this
respondent and JAL49. Hence, it is contended that though the claim of this respondent is limited 49
Clause B & B(a) of the Mortgage Deed produced as Annexure-1 at Pg. 8-43 to the extent of the value
of the properties mentioned in the Schedule to the Mortgage Deed but, to that extent, it remains a
financial creditor of JIL. 37.3.1.As regards similar arguments with respect to Section 58 of the
Transfer of Property Act, that a mortgage presupposes the subsistence of a debt and hence it is a
secured debt, apart from above referred decisions, learned counsel has also referred to the decision
in Pomal Khanji Govindji & Ors. v. Brajlal Karsandas Purohit & Ors: (1989) 1 SCC 458.
37.3.2.It is contended that when the objective of the Code is to revive the corporate debtor, the
resolution plan ought to contain all claims against the corporate debtor, whether matured or not, so
that if the liability again creeps in, the Company may be prevented from being dragged into
insolvency or liquidation proceedings. It is further submitted that this respondent, who is holding
public money, ought to be a part of CoC; and its absence in CoC would be defeating the very object ofAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

the Code because the resolution plan may provide for various measures which might take away the
security interest created in favor of this respondent; and without its participation, the entire process
would be prejudicial to the interest of this respondent. It is submitted that as per the ratio in K.
Sashidhar v. Indian Overseas Bank and Ors. :
2019 SCC OnLine SC 257 read with the decision in the case of Essar Steel, once a
resolution plan is approved by the wisdom of the CoC, the same cannot be challenged
and looking to the scheme of the Code, presence of the mortgagees like this
respondent in the CoC of JIL is necessary and is rather unavoidable.
ICICI Bank 37.4. On behalf of this respondent, it is maintained that in view of Section
5(8)
(i) read with Section 5(8)(a) of the Code, the creation of impugned mortgage had
resulted in creation of a ‘financial debt’ as defined under the Code, for the transaction
being akin to that of a ‘guarantee’ as defined under Section 126 of the Contract Act.
Again, with reference to the decision in Smt. Kusum (supra), it is submitted that even
a third party mortgage leads to creation of an implied guarantee with an obligation to
pay the mortgage debt. In other words, since the definition of ‘financial debt’ is not
exhaustive, any transaction which is akin to creation of a guarantee would come
under the purview of the definition of ‘financial debt’ and as such, the mortgage
provided by the corporate debtor JIL, being akin to the guarantee, would be squarely
within the definition of ‘financial debt’. It is further submitted that in the given
scenario, this respondent takes on the role of a ‘financial creditor’ of the corporate
debtor JIL within the meaning of Section 5(8)(i) of the Code and hence, ought to be
admitted as a member of the CoC.
37.4.1.It is submitted on behalf of this respondent that on a holistic reading of the mortgage deeds, it
is clear that ‘exclusive mortgages’ were executed in favour of this respondent with express clauses
whereby, the corporate debtor JIL had undertaken to either discharge the debt or to ensure
repayment of facilities extended to JAL and in the event of default, this respondent shall have the
right to sell the mortgaged properties. Such stipulations, it is contended, clearly put the respondent
in the category of ‘financial creditors’. 37.4.2.With reference to the duties of IRP as laid out in the
Code, and with analysis of the definition of ‘claim’ as found in Section 3(6) of the Code, it is
submitted that the definition of ‘claim’ is wide enough to include all stakeholders of the corporate
debtor, even if a claim had not matured on the date of insolvency commencement. The Report of
Banking Law Reform Committee has also been referred in this regard.
37.4.3.It is further submitted that Regulations 12, 13 and 14 of the Insolvency and Bankruptcy Board
of India (Insolvency Resolution Process for Corporate Persons) Regulations, 2016 require the IRP to
admit all claims, including contingent claims, as on the insolvency commencement date; that as per
Section 29 of the Code, the IRP ought to prepare an information memorandum for formulating a
resolution plan; that as per Regulation 37 of CIRP Regulations, the insolvency resolution of the
corporate debtor should include sale of all or part of the assets, irrespective of whether they areAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

subject to security interest and satisfaction or modification of any security interest; and that
sub-section (4) of Section 30 of the Insolvency and Bankruptcy (Amendment) Act, 2019 clarifies
that priority of secured creditors has to be considered. With reference to the processes so envisaged
by the Code, it is contended that the secured creditors like the respondent cannot be kept away from
the class of financial creditors.
Central Bank of India 37.5. Apart from the submissions carrying essentially the substance as above-
noted, it is also contended that this respondent, being a secured creditor, would be entitled to
enforce its security interest in the mortgaged property upon vacation of the order of moratorium in
terms of the Securitisation and Reconstruction Of Financial Assets and Enforcement of Security
Interest Act, 200250; and that the resolution plan, without including the secured creditors, would
be unenforceable, as the secured creditors will then seek enforcement against mortgage property
under the SARFAESI Act. It is, therefore, contended that the secured creditor, like the respondent,
needs to be recognized as financial creditor, and thereby a participant in CoC of the corporate debtor
JIL.
Bank of Maharashtra 37.6. While going in tandem with the submissions aforesaid, it is asserted on
behalf of this respondent that the corporate debtor JIL is under a pecuniary obligation to discharge
the liability in view of the Indenture of Mortgage (IOM) dated 29.12.2016, which is a contract of
guarantee and, therefore, the relationship between the parties cannot be classified merely as that of
mortgagor and mortgagee, but is also of a guarantor and guarantee which, in 50 Hereinafter also
referred to as ‘the SARFAESI Act’ turn, is covered under Section 5(8) of the Code and thereby, this
respondent is a ‘financial creditor’ within the meaning of Section 5(7) of the Code. Unique position
of financial creditor- as explained in Swiss Ribbons
38. Having taken note of the rival contentions on the issue as to whether the lenders of JAL could be
categorised as ‘financial creditors’ of JIL for the purpose of CIRP in question, gist of the matter is as
to whether the subject transactions could be categorised as ‘financial debts’ within the meaning of
Section 5(8) of the Code so as to confer the status of ‘financial creditors’ upon the respondents,
lenders of JAL.
38.1. The expressions “financial creditor” and “financial debt” as occurring in the Code have come
up for consideration before this Court in several decisions, including those in the above-mentioned
cases of Swiss Ribbons (decided on 25.01.2019), Pioneer Urban (decided on 09.08.2019) and Essar
Steel (decided on 15.11.2019), which have been referred to and relied upon by learned counsel for
the parties for one proposition or another. In fact, the observations as occurring in the last of the
said decisions, in the case of Essar Steel, as relied upon by the learned counsel for the respondents,
are based on those occurring in the decision in Swiss Ribbons51.
51 We have referred to the case of Swiss Ribbons in paragraph 16.1.1 hereinbefore while pointing out
that in Swiss Ribbons, this Court had traversed through the historical background and scheme of the
Code in the wake of challenge to the constitutional validity of various provisions of the Code and
while rejecting such challenge, this Court had observed that the focus of the Code was to ensure
revival and continuation of the corporate debtor, where liquidation is to be availed of only as a lastAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

resort; and that the Code was a beneficial legislation to put the corporate debtor on its feet, and not
a mere recovery legislation for the creditors.
39. As indicated hereinbefore, the law declared by this Court in the case of Swiss Ribbons, while
rejecting the contentions that classification between financial creditor and operational creditor was
discriminatory and violative of Article 14, shall have some bearing on the claim of the
respondent-lenders for being treated as financial creditors of JIL. Having regard to the submissions
made, it shall now be pertinent to take note of the relevant aspects from the said decision in
requisite details.
39.1. The broad features of the expressions used in Sections 5(7) and 5(8) of the Code in defining the
terms “financial creditor” and “financial debt” were indicated by this Court in the case of Swiss
Ribbons in the following:
“42. A perusal of the definition of “financial creditor” and “financial debt” makes it
clear that a financial debt is a debt together with interest, if any, which is disbursed
against the consideration for time value of money. It may further be money that is
borrowed or raised in any of the manners prescribed in Section 5(8) or otherwise, as
Section 5(8) is an inclusive definition. On the other hand, an “operational debt”
would include a claim in respect of the provision of goods or services, including
employment, or a debt in respect of payment of dues arising under any law and
payable to the Government or any local authority.” 39.2. The unique position
assigned to a ‘financial creditor’, who plays a crucial role in insolvency resolution
process as against the role of other creditors, has been extensively explained by this
Court in the case of Swiss Ribbons, albeit in the context of its differentiation with the
category of ‘operational creditor’, in the following:
“50. According to us, it is clear that most financial creditors, particularly banks and
financial institutions, are secured creditors whereas most operational creditors are
unsecured, payments for goods and services as well as payments to workers not being
secured by mortgaged documents and the like. The distinction between secured and
unsecured creditors is a distinction which has obtained since the earliest of the
Companies Acts both in the United Kingdom and in this country. Apart from the
above, the nature of loan agreements with financial creditors is different from
contracts with operational creditors for supplying goods and services. Financial
creditors generally lend finance on a term loan or for working capital that enables the
corporate debtor to either set up and/or operate its business. On the other hand,
contracts with operational creditors are relatable to supply of goods and services in
the operation of business. Financial contracts generally involve large sums of money.
By way of contrast, operational contracts have dues whose quantum is generally less.
In the running of a business, operational creditors can be many as opposed to
financial creditors, who lend finance for the set-up or working of business. Also,
financial creditors have specified repayment schedules, and defaults entitle financial
creditors to recall a loan in totality. Contracts with operational creditors do not haveAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

any such stipulations. Also, the forum in which dispute resolution takes place is
completely different. Contracts with operational creditors can and do have
arbitration clauses where dispute resolution is done privately. Operational debts also
tend to be recurring in nature and the possibility of genuine disputes in case of
operational debts is much higher when compared to financial debts. A simple
example will suffice. Goods that are supplied may be substandard. Services that are
provided may be substandard. Goods may not have been supplied at all. All these qua
operational debts are matters to be proved in arbitration or in the courts of law. On
the other hand, financial debts made to banks and financial institutions are well
documented and defaults made are easily verifiable.
51. Most importantly, financial creditors are, from the very beginning, involved with
assessing the viability of the corporate debtor. They can, and therefore do, engage in
restructuring of the loan as well as reorganisation of the corporate debtor’s business
when there is financial stress, which are things operational creditors do not and
cannot do. Thus, preserving the corporate debtor as a going concern, while ensuring
maximum recovery for all creditors being the objective of the Code, financial
creditors are clearly different from operational creditors and therefore, there is
obviously an intelligible differentia between the two which has a direct relation to the
objects sought to be achieved by the Code.
*** *** ***
75. Since the financial creditors are in the business of moneylending, banks and
financial institutions are best equipped to assess viability and feasibility of the
business of the corporate debtor. Even at the time of granting loans, these banks and
financial institutions undertake a detailed market study which includes a
techno-economic valuation report, evaluation of business, financial projection, etc.
Since this detailed study has already been undertaken before sanctioning a loan, and
since financial creditors have trained employees to assess viability and feasibility,
they are in a good position to evaluate the contents of a resolution plan. On the other
hand, operational creditors, who provide goods and services, are involved only in
recovering amounts that are paid for such goods and services, and are typically
unable to assess viability and feasibility of business. The BLRC Report, already
quoted above, makes this abundantly clear.” (emphasis supplied) 39.3. The
enunciation aforementioned illuminates the reasons as to why at all a financial
creditor is conferred with a major, rather pivotal, role in the processes contemplated
by Part II of the Code. It is the financial creditor who lends finance on a term loan or
for working capital that enables the corporate debtor to set up and/or operate its
business; and who has specified repayment schedules with default consequences. The
most important feature, as this Court has said, is that a financial creditor is, from the
very beginning, involved in assessing the viability of the corporate debtor who can,
and indeed, engage in restructuring of the loan as well as reorganisation of the
corporate debtor’s business when there is financial stress. Hence, a financial creditorAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

is not only about in terrorem clauses for repayment of dues; it has the unique
parental and nursing roles too. In short, the financial creditor is the one whose stakes
are intrinsically inter-woven with the well-being of the corporate debtor.
Financial debt - ratio of Pioneer Urban
40. Having imbibed the basic features associated with a ‘financial creditor’, we need to examine as to
who could at all fall in this category. In order to address this core question, delving into the finer
connotations of the expression “financial debt”, as defined in Section 5(8) of the Code is, obviously,
necessary. As noticed, while defining ‘financial creditor’ and ‘financial debt’ in Section 5(7) and
Section 5(8) of the Code, both the expressions “means” and “includes” have been used. As per the
definition, while “financial creditor” means a person to whom a “financial debt” is owed, it also
includes a person to whom such debt has been legally assigned or transferred to. Obviously, a
comprehension of this definition of “financial creditor” cannot be complete without taking into
account as to what is the meaning assigned to the expression “financial debt”. Again, the term
“financial debt” has also been defined with the expressions “means” and “includes”. A “financial
debt” means a debt along with interest, if any, which is disbursed against the consideration for the
time value of money; and it includes the money borrowed or raised or protected in any of the
manners prescribed in sub-clauses (a) to (i) of Section 5(8).
41. The larger parts of the expressions employed in the definition of “financial debt” in sub-section
(8) of Section 5 of the Code with their connotations were explicated in Pioneer Urban by a
three-Judge Bench of this Court; and, in view of the contentions urged, it would be appropriate to
take a deeper look into the exposition of law by this Court, while also keeping in view the plain basic
principle that a decision of the Court is required to be understood in the context of the facts and
issues involved therein. 41.1. In the case of Pioneer Urban, this Court was concerned with the
challenge to the constitutional validity of amendments made to the Code pursuant to a report dated
26.03.2018 prepared by the Insolvency and Bankruptcy Law Committee. The amendments were
essentially to the effect of putting the allottees of real estate projects into the sect of ‘financial
creditors’ and thereby investing them with the rights and entitlement to trigger the proceedings
under Section 7 of the Code against the real estate developers and to be represented in the
Committee of Creditors. In the background of such amendments had been certain important
decisions/orders by NCLAT and by this Court. One had been the order dated 21.07.2017 by the
NCLAT in the case of Nikhil Mehta and Sons (HUF) v. AMR Infrastructure Limited:
(2017) SCC Online NCLAT 859, where it was held that the amount raised by the
developers had the commercial effect of a borrowing and the allottees of such
developers were financial creditors within the meaning of Section 5(7) of the Code.
The other one had been the order dated 11.09.2017 passed by this Court in Chitra
Sharma (supra) whereby, a representative of the home buyers was appointed to
participate in the meetings of the Committee of Creditors for protection of their
interests. Yet another order was passed by this Court on 22.11.2017, on practically the
same lines, qua another group of builders in the case of Bikram Chatterjee v. Union of
India: 2019 (8) SCC 527. In the wake of such orders, the Insolvency CommitteeAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

Report suggested for amendment to the Code that ultimately culminated into the
Insolvency and Bankruptcy (Second Amendment) Act, 2018. The amendments were
made, inter alia, with insertion of Explanation to sub-clause (f) of Section 5(8) of the
Code and with the co-related insertion of sub-section (6A) to Section 21 as also with
further insertion of Section 25-A in the Code. These amendments were under
challenge in Pioneer Urban. Several contentions were urged before this Court
questioning the treatment of allottees as financial creditors. In this context and in the
wake of such issues this Court dealt with the contentions related with Section 5(8),
particularly sub-clause (f) thereof. The relevant part of the consideration of this Court
in Pioneer Urban under the heading ‘Interpretation of Section 5(8)(f) of the Code’
needs to be noticed and is extracted as under:-
“66. Section 5(8)(f) of the Code has been set out in the beginning of this judgment.
What has been argued by learned counsel on behalf of the petitioners is that Section
5(8)(f), as it originally stood, is an exhaustive provision which must be read noscitur
a sociis, and if so read, sub-clause (f) must take colour from the other clauses of the
provision, all of which show that the sine qua non of a “financial debt” is a loan of
money made with or without interest, which must then be returned as money. This,
according to the learned counsel for the petitioners, is clear from even a cursory
reading of Section 5(8). Secondly, according to learned counsel for the petitioners, by
no stretch of imagination, could an allottee under a real estate project fall within
Section 5(8)(f), as it originally stood and the Explanation must then be read
prospectively i.e. only on and from the date of the Amendment Act. Several
sub-arguments were made on the effect of deeming fictions generally and on the
functions of an explanation to a section. Let us address all of these arguments.
*** *** ***
68. Thus, in order to be a “debt”, there ought to be a liability or obligation in respect
of a “claim” which is due from any person.
“Claim” then means either a right to payment or a right to payment arising out of breach of contract,
and this claim can be made whether or not such right to payment is reduced to judgment. Then
comes “default”, which in turn refers to non-payment of debt when whole or any part of the debt has
become due and payable and is not paid by the corporate debtor. Learned counsel for the petitioners
relied upon the judgment in Union of India v. Raman Iron Foundry : (1974) 2 SCC 231, and, in
particular relied strongly upon the sentence reading: (SCC p.243, para 11) “11....Now the law is well
settled that a claim for unliquidated damages does not give rise to a debt until the liability is
adjudicated and damages assessed by a decree or order of a court or other adjudicatory authority.”
69. It is precisely to do away with judgments such as Raman Iron Foundry (supra) that “claim” is
defined to mean a right to payment or a right to remedy for breach of contract whether or not such
right is reduced to judgment. What is clear, therefore, is that a debt is a liability or obligation in
respect of a right to payment, even if it arises out of breach of contract, which is due from anyAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

person, notwithstanding that there is no adjudication of the said breach, followed by a judgment or
decree or order. The expression “payment” is again an expression which is elastic enough to include
“recompense”, and includes repayment. For this purpose, see H.P. Housing and Urban Development
Authority v. Ranjit Singh Rana : (2012) 4 SCC 505 (at paragraphs 13 and 14 therein), where the
Webster’s Comprehensive Dictionary (International Edn.) Vol. 2 and the Law Lexicon by P.
Ramanatha Aiyar (2nd Edn., Reprint) are quoted.
70. The definition of “financial debt” in Section 5(8) then goes on to state that a “debt” must be
“disbursed” against the consideration for time value of money. “Disbursement” is defined in Black’s
Law Dictionary (10th Edn.) to mean:
“1. The act of paying out money, commonly from a fund or in settlement of a debt or
account payable. 2. The money so paid; an amount of money given for a particular
purpose.”
71. In the present context, it is clear that the expression “disburse” would refer to the payment of
instalments by the allottee to the real estate developer for the particular purpose of funding the real
estate project in which the allottee is to be allotted a flat/apartment. The expression “disbursed”
refers to money which has been paid against consideration for the “time value of money”. In short,
the “disbursal” must be money and must be against consideration for the “time value of money”,
meaning thereby, the fact that such money is now no longer with the lender, but is with the
borrower, who then utilises the money. Thus far, it is clear that an allottee “disburses” money in the
form of advance payments made towards construction of the real estate project. We were shown the
Dictionary of Banking Terms (2nd Edn.) by Thomas P. Fitch in which “time value for money” was
defined thus:
“present value: today’s value of a payment or a stream of payment amount due and
payable at some specified future date, discounted by a compound interest rate of
DISCOUNT RATE. Also called the time value of money. Today’s value of a stream of
cash flows is worth less than the sum of the cash flows to be received or saved over
time. Present value accounting is widely used in DISCOUNTED CASH FLOW
analysis.” (emphasis supplied) That this is against consideration for the time value of
money is also clear as the money that is “disbursed” is no longer with the allottee,
but, as has just been stated, is with the real estate developer who is legally obliged to
give money’s equivalent back to the allottee, having used it in the construction of the
project, and being at a discounted value so far as the allottee is concerned (in the
sense of the allottee having to pay less by way of instalments than he would if he were
to pay for the ultimate price of the flat/apartment).
*** *** ***
74. What is clear from what Shri Venugopal has read to us is that a wide range of
transactions are subsumed by para (f) and that the precise scope of para (f) is
uncertain. Equally, para (f) seems to be a “catch all” provision which is reallyAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

residuary in nature, and which would subsume within it transactions which do not, in
fact, fall under any of the other sub-clauses of Section 5(8).
75. And now to the precise language of Section 5(8)(f). First and foremost, the
sub-clause does appear to be a residuary provision which is “catch all” in nature. This
is clear from the words “any amount” and “any other transaction” which means that
amounts that are “raised” under “transactions” not covered by any of the other
clauses, would amount to a financial debt if they had the commercial effect of a
borrowing. The expression “transaction” is defined by Section 3(33) of the Code as
follows:
3.(33) “transaction” includes an agreement or arrangement in writing for the transfer
of assets, or funds, goods or services, from or to the corporate debtor;
As correctly argued by the learned Additional Solicitor General, the expression “any other
transaction” would include an arrangement in writing for the transfer of funds to the corporate
debtor and would thus clearly include the kind of financing arrangement by allottees to real estate
developers when they pay instalments at various stages of construction, so that they themselves then
fund the project either partially or completely.
76. Sub-clause (f) Section 5(8) thus read would subsume within it amounts raised under
transactions which are not necessarily loan transactions, so long as they have the commercial effect
of a borrowing. We were referred to Collins English Dictionary & Thesaurus (2nd Edn., 2000) for
the meaning of the expression “borrow” and the meaning of the expression “commercial”. They are
set out hereinbelow:
“borrow-vb 1. to obtain or receive (something, such as money) on loan for temporary
use, intending to give it, or something equivalent back to the lender. 2. to adopt
(ideas, words, etc.) from another source; appropriate. 3. Not standard. to lend. 4.
(intr) Golf. To putt the ball uphill of the direct path to the hole:
make sure you borrow enough.” *** *** *** “commercial. -adj. 1. of or engaged in
commerce. 2. sponsored or paid for by an advertiser: commercial television. 3. having
profit as the main aim: commercial music. 4. (of chemicals, etc.) unrefined and
produced in bulk for use in industry. 5. a commercially sponsored advertisement on
radio or television.”
77. A perusal of these definitions would show that even though the petitioners may be right in
stating that a “borrowing” is a loan of money for temporary use, they are not necessarily right in
stating that the transaction must culminate in money being given back to the lender. The expression
“borrow” is wide enough to include an advance given by the homebuyers to a real estate developer
for “temporary use” i.e. for use in the construction project so long as it is intended by the agreement
to give “something equivalent” to money back to the homebuyers. The “something equivalent” in
these matters is obviously the flat/apartment. Also of importance is the expression “commercialAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

effect”. “Commercial” would generally involve transactions having profit as their main aim. Piecing
the threads together, therefore, so long as an amount is “raised” under a real estate agreement,
which is done with profit as the main aim, such amount would be subsumed within Section 5(8)(f)
as the sale agreement between developer and home buyer would have the “commercial effect” of a
borrowing, in that, money is paid in advance for temporary use so that a flat/apartment is given
back to the lender. Both parties have “commercial” interests in the same – the real estate developer
seeking to make a profit on the sale of the apartment, and the flat/apartment purchaser profiting by
the sale of the apartment. Thus construed, there can be no difficulty in stating that the amounts
raised from allottees under real estate projects would, in fact, be subsumed within Section 5(8)(f)
even without adverting to the explanation introduced by the Amendment Act.
*** *** ***
79. That this amendment is in fact clarificatory is also made clear by the Insolvency Committee
Report, which expressly uses the word “clarify”, indicating that the Insolvency Law Committee also
thought that since there were differing judgments and doubts raised on whether homebuyers would
or would not be included within Section 5(8)(f), it was best to set these doubts at rest by explicitly
stating that they would be so covered by adding an explanation to Section 5(8)(f). Incidentally, the
Insolvency Law Committee itself had no doubt that given the “financing” of the project by the
allottees, they would fall within Section 5(8)(f) of the Code as originally enacted.” 41.1.1. It is,
therefore, evident that this Court, even while interpreting sub- clause (f) of Section 5(8) on the
question as to whether an allottee under a real estate project could fall thereunder, analysed the
gamut of the relevant expressions of ‘disbursement’, ‘borrowing’ and ‘time value of money’, being
the root ingredients of ‘financial debt’ within the meaning of the Code. 41.1.2. It is significant to
notice that in the case of Pioneer Urban, one line of arguments on behalf of the petitioners, who led
challenge to the amendments, had been that the use of expression “means and includes” in Section
5(8) was indicative that the provision was exhaustive and in that position, alien subject- matter such
as home buyers could not have been inserted therein. The decision of this Court in the case of P.
Kasilingam & Ors. v. P.S.G. College of Technology & Ors : (1995) Suppl. 2 SCC 348 was relied upon
by the petitioners wherein, this Court had rejected an argument that the expression “means and
includes” indicated that the definition was inclusive in nature and would also cover the categories
which were not mentioned therein. In P. Kasilingam, this Court had said that the use of the word
‘means’ indicates that the definition is a hard and fast definition and no other meaning could be
assigned to the expression than is put down in the definition. As regards the word ‘includes’, this
Court said that it enlarges the meaning of the expression defined so as to comprehend not only such
things as they signify according to their natural import but also those things which the clause
declares that they shall include. Further, this Court said that the words 'means and includes', on the
other hand, indicate ‘an exhaustive explanation’ of the meaning which, for the purposes of the Act,
must invariably be attached to these words or expressions. On the other hand, another decision of
this Court in Krishi Utapadan Mandi Samiti & Anr v. M/s Shankar Industries & Ors: 1993 Suppl. (3)
SCC 361 was referred on behalf of the respondents wherein, the Court had considered a definition
clause whereby the expression “agricultural produce” was defined to mean such items of produce of
agriculture, horticulture, viticulture, apiculture, sericulture, pisciculture, animal husbandry, or
forest as specified in the Schedule and then, the definition included therein admixture of two orAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

more of such items, and further included any such item in processed form and yet further included
specific items like gur, rub, shakkar, khandsari and jaggery. While examining such definition in
Krishi Utapadan Mandi Samiti, the Court proceeded to say that under the rules of interpretation,
when the words ‘means and includes’ are used in a definition, they are to be given a wider meaning
and are not exhaustive or restricted to the items contained therein. This statement of law in Krishi
Utapadan Mandi Samiti was held by the three-Judge Bench of this Court in Pioneer Urban to be not
that of good law for it ignored the earlier precedents of larger and coordinate Benches and was also
out of sync with the later decisions on the same point. However, and at the same time, the
arguments on behalf of the petitioners, that sub- clauses (a) to (i) of Section 5(8) of the Code must
necessarily reflect the fact that the financial debt could only be a debt disbursed against the
consideration for the time value of money and which permeates sub-clauses (a) to (i), was also not
accepted as a matter of statutory interpretation while observing that the expression “and includes”
speaks of the subject matter which may not necessarily be reflected in the main part of the
definition. These observations of the Court, after reproduction of the relevant extracts from the
referred decisions, read as under:
“82. This statement of the law, as can be seen from the quotation hereinabove, is
without citation of any authority. In fact, in Jagir Singh. v. State of Bihar.: (1976) 2
SCC 942 at paras 11 and 19 to 21 and Mahalakshmi Oil Mills v. State of A.P.: (1989) 1
SCC 164, at paras 8 and 11 (which has been cited in P. Kasilingam : 1995 Supp (2)
SCC 348) this Court set out definition sections where the expression "means" was
followed by some words, after which came the expression "and includes" followed by
other words, just as in the Krishi Utpadan Mandi Samiti case : 1993 Supp (3) SCC 361
(2). In two other recent judgments, Bharat Coop. Bank (Mumbai) Ltd. v. Employees
Union: (2007) 4 SCC 685, at paras 12 and 23 and State of W.B. v. Associated
Contractors : (2015) 1 SCC 32 at para 14, this Court has held that wherever the
expression "means" is followed by the expression "and includes"
whether with or without additional words separating "means" from "includes", these
expressions indicate that the definition provision is exhaustive as a matter of
statutory interpretation. It has also been held that the expression "and includes" is an
expression which extends the definition contained in words which follow the
expression "means". From this discussion, two things follow. Krishi Utpadan Mandi
Samiti cannot be said to be good law insofar as its exposition on "means" and
"includes" is concerned, as it ignores earlier precedents of larger and coordinate
Benches and is out of sync with later decisions on the same point. Equally, Dr.
Singhvi's argument that clauses (a) to
(i) of Section 5(8) of the Code must all necessarily reflect the fact that a financial debt
can only be a debt which is disbursed against the consideration for the time value of
money, and which permeates clauses (a) to (i), cannot be accepted as a matter of
statutory interpretation, as the expression "and includes" speaks of subject-matters
which may not necessarily be reflected in the main part of the definition.” (emphasis
supplied) 41.1.3. In the end, however, this Court rejected the contentions urged onAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

behalf of the petitioners while accepting other line of submissions on behalf of the
respondents that the legislature is not precluded by way of amendment from
inserting words into what may even be an exhaustive definition and while observing
that an exhaustive definition is exhaustive only for the purposes of interpretation of a
statute by the Courts. This Court said,-
“83. In any event, as was correctly argued by learned Additional Solicitor General Mrs. Madhavi
Divan, the legislature is not precluded by way of amendment from inserting words into what may
even be an exhaustive definition. What is an exhaustive definition is exhaustive for purposes of
interpretation of a statute by the courts, which cannot bind the legislature when it adds something
to the statute by way of amendment. On this score also, there is no substance in the aforesaid
argument.” 41.1.4. This Court ultimately found that the Explanation was added by the Amendment
Act only to clarify the doubt that had arisen as to whether home buyers/allottees were subsumed
within Section 5(8)(f) of the Code. In essence, the amendment in question was interpreted to be
clarificatory in nature so as to put beyond doubt that allottees are to be regarded as financial
creditors within the enacting part of Section 5(8)(f) of the Code. The Amendment Act was upheld
with this Court holding as under:
“96. In the present case, it is clear that the deeming fiction that is used by the
Explanation is to put beyond doubt the fact that allottees are to be regarded as
financial creditors within the enacting part contained in Section 5(8)(f) of the Code.
97. It was also argued that an explanation does not enlarge the scope of the original
section and for this purpose S. Sundaram Pillai : (1985) 1 SCC 591 was relied upon.
This very judgment recognises, in para 46, that an explanation does not ordinarily
enlarge the scope of the original section. But if it does, effect must be given to the
legislative intent notwithstanding the fact that the legislature has named a provision
as an explanation. [See Hiralal Ratanlal v. State of U.P.: (1973) 1 SCC 216 at p. 225,
followed in para 51 of Sundram Pillai]. In any case, it has been found by us that the
Explanation was added by the Amendment Act only to clarify doubts that had arisen
as to whether homebuyers/allottees were subsumed within Section 5(8)(f).
The Explanation added to Section 5(8)(f) of the Code by the Amendment Act does not in fact enlarge
the scope of the original section as homebuyers/allottees would be subsumed within Section 5(8)(f)
as it originally stood as has been held by us hereinabove. As a matter of statutory interpretation, that
interpretation, which accords with the objects of the statute in question, particularly when we are
dealing with a beneficial legislation, is always the better interpretation or the "creative
interpretation" which is the modern trend of authority, and which is reflected in the concurring
judgment of Eera v. State (NCT of Delhi) : (2017) 15 SCC 133 paras 122 and 127. This argument
must, therefore, also be rejected.
98. We, therefore, hold that allottees/homebuyers were included in the main provision, i.e. Section
5(8)(f) with effect from the inception of the Code, the explanation being added in 2018 merely to
clarify doubts that had arisen.” (emphasis supplied) 41.1.5. For taking into comprehension the ratioAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

of Pioneer Urban (supra) and for its application to the question at hand, appropriate it would be to
recount the basic principles expounded and explained by a three-Judge Bench in the case of
Haryana Financial Corporation and Anr. v. Jagdamba Oil Mills and Anr.: (2002) 3 SCC 496 that the
observations of the Court in a judgment are always required to be read in the context in which they
appear. This Court has said,-
“19. Courts should not place reliance on decisions without discussing as to how the factual situation
fits in with the fact situation of the decision on which reliance is placed. Observations of courts are
not to be read as Euclid’s theorems nor as provisions of the statute. These observations must be read
in the context in which they appear. Judgments of courts are not to be construed as statutes. To
interpret words, phrases and provisions of a statute, it may become necessary for Judges to embark
upon lengthy discussions but the discussion is meant to explain and not to define. Judges interpret
statutes, they do not interpret judgments. They interpret words of statutes, their words are not to be
interpreted as statutes. In London Graving Dock Co. Ltd. v. Horton : 1951 AC 737 (at p. 761) Lord
MacDermot observed: (All ER p. 14C-D) “The matter cannot, of course, be settled merely by treating
the ipsissima verba of Willes, J., as though they were part of an Act of Parliament and applying the
rules of interpretation appropriate thereto. This is not to detract from the great weight to be given to
the language actually used by that most distinguished Judge.”
20. In Home Office v. Dorset Yacht Co. : (1970) 2 All ER 294 Lord Reid said (at All ER p. 297g-h),
“Lord Atkin’s speech … is not to be treated as if it were a statutory definition. It will require
qualification in new circumstances”. Megarry, J. in (1971) 1 WLR 1062 observed: “One must not, of
course, construe even a reserved judgment of even Russell, L.J. as if it were an Act of Parliament.”
And, in Herrington v. British Railways Board: (1972) 2 WLR 537 Lord Morris said: (All ER p. 761c)
“There is always peril in treating the words of a speech or a judgment as though they were words in a
legislative enactment, and it is to be remembered that judicial utterances are made in the setting of
the facts of a particular case.”
21. Circumstantial flexibility, one additional or different fact may make a world of difference
between conclusions in two cases. Disposal of cases by blindly placing reliance on a decision is not
proper.” 41.1.6. Read as a whole and with reference to its context, it is but clear that in Pioneer
Urban this Court has not enunciated that the scope of the expression ‘financial debt’ be read as if to
encompass any debt of whatsoever nature. Rather, a submission made therein, with reference to the
decision in Krishi Utapadan Mandi Samiti, that ‘and includes’ part in a definition may lead to it
being extensive, was rejected by this Court while holding that the said decision was not a good law.
However, the other extreme of submissions, seeking restrictive interpretation with reference to
‘means’ part of the definition, was also not accepted and, in that context, the Court observed that the
expression ‘and includes’ speaks of subject-matters which may not necessarily be reflected in the
main part of the definition. Obviously, there could be several subject-matters which may not, as
such, be found squarely manifested in the expressions employed in the ‘means’ part of a definition
and could be reasonably found in the ‘includes’ part. However, it has not been laid down as a rule of
statutory interpretation that the ‘includes’ part could stand alone, disjunct from and totally alien to
the ‘means’ part.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

The expressions “means and includes” in the definition clauses - effect
42. Looking to the frame of the Code, where the significant expressions “financial creditor” and
“financial debt” have been defined with the words “means” and “includes”, we may further refer to
the principles of construction of such a definition clause in a statute. Tersely put, the law remains
settled that where a word is defined to ‘mean’ something, the definition is prime facie restrictive and
exhaustive. On the other hand, where the word defined is declared to ‘include’ something more, the
definition is prima facie extensive. However, a little difficulty arises when the definition contains
both the words ‘means’ and ‘includes’52. 42.1. As noticed, in the case of Pioneer Urban, a suggestion
made on behalf of the respondents with reference to the decision in Krishi Utapadan Mandi Samiti,
that when the words ‘means and includes’ are used in a definition, they are to be given a wider
meaning and are not exhaustive or restricted to the items contained therein, was not accepted by
this Court; and the statement of law in Krishi Utapadan Mandi Samiti was held to be not that of
good law for it ignored the earlier precedents of larger and coordinate Benches and was also out of
sync with the later decisions on the same point. However, the other extreme of interpretation, as
canvassed by the petitioners, that a financial debt could only be a debt which is disbursed against
the consideration for the time value of money, and such requirement pervades all sub-clauses (a) to
(i), was also not accepted as a matter of statutory interpretation by this Court while observing that
the expression ‘and includes’ speaks of subject matters which may not necessarily be reflected in the
main part of the definition. Thus, it is evident that this Court did not accept either of the extremities
suggested by the parties in Pioneer Urban for interpretation and implication of the expressions
‘means and includes’ in a definition clause of the statute. Significantly, in 52 Craise on Statue Law (
Seventh Ed.-Indian reprint 1999 page 213) has stated this feature as follows:
There are two forms of interpretation clause. In one, where the word defined is
declared to “mean” so and so, the definition is explanatory and prima facie
restrictive. In the other, where the word defined is declared to ”include” so and so,
the definition is extensive, e.g. “sheriff” includes “under- sheriff”. Sometimes the
definition contains the words “mean and include”,” which inevitably raises a doubt as
to interpretation.
Pioneer Urban, none of the extremities had any bearing on the conclusion because,
eventually, the amendment in question was held to be only clarificatory in nature;
and this Court held that the Explanation added to Section 5(8)(f) of the Code by the
Amendment Act did not enlarge the scope of the original Section.
42.2. Various features of the process of interpretation while dealing with such
definition clauses were explained by this Court in the case of Delhi Development
Authority v. Bhola Nath Sharma (Dead) by LRs & Ors:
(2011) 2 SCC 54 in the following:
“25. The definition of the expressions “local authority” and “person interested” are
inclusive and not exhaustive. The difference between exhaustive and inclusiveAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

definitions has been explained in P. Kasilingam v. P.S.G. College of Technology : 1995
Supp (2) SCC 348 in the following words: (SCC p. 356, para 19) “19. … A particular
expression is often defined by the legislature by using the word ‘means’ or the word
‘includes’. Sometimes the words ‘means and includes’ are used. The use of the word
‘means’ indicates that ‘definition is a hard- and-fast definition, and no other meaning
can be assigned to the expression than is put down in definition’. (See Gough v.
Gough : (1891) 2 QB 665 (CA); Punjab Land Development and Reclamation Corpn.
Ltd. v. Labour Court : (1990) 3 SCC 682, SCC p. 717, para 72.) The word ‘includes’
when used, enlarges the meaning of the expression defined so as to comprehend not
only such things as they signify according to their natural import but also those
things which the clause declares that they shall include. The words ‘means and
includes’, on the other hand, indicate ‘an exhaustive explanation of the meaning
which, for the purposes of the Act, must invariably be attached to these words or
expressions’. [See Dilworth v. Commr. of Stamps : 1899 AC 99 (Lord Watson);
Mahalakshmi Oil Mills v. State of A.P. :
(1989) 1 SCC 164, SCC p. 170, para 11.] The use of the words ‘means and includes’ in
Rule 2(b) would, therefore, suggest that the definition of ‘college’ is intended to be
exhaustive and not extensive and would cover only the educational institutions falling
in the categories specified in Rule 2(b) and other educational institutions are not
comprehended. Insofar as engineering colleges are concerned, their exclusion may be
for the reason that the opening and running of the private engineering colleges are
controlled through the Board of Technical Education and Training and the Director
of Technical Education in accordance with the directions issued by the AICTE from
time to time.”
26. In Bharat Coop. Bank (Mumbai) Ltd. v. Employees Union :
(2007) 4 SCC 685 this Court again considered the difference between the inclusive
and exhaustive definitions and observed:
(SCC p. 695, para 23) “23. … when in the definition clause given in any statute the
word ‘means’ is used, what follows is intended to speak exhaustively. When the word
‘means’ is used in the definition … it is a ‘hard-and-fast’ definition and no meaning
other than that which is put in the definition can be assigned to the same. … On the
other hand, when the word ‘includes’ is used in the definition, the legislature does not
intend to restrict the definition: it makes the definition enumerative but not
exhaustive. That is to say, the term defined will retain its ordinary meaning but its
scope would be extended to bring within it matters, which in its ordinary meaning
may or may not comprise. Therefore, the use of the word ‘means’ followed by the
word ‘includes’ in [the definition of ‘banking company’ in] Section 2(bb) of the ID Act
is clearly indicative of the legislative intent to make the definition exhaustive and
would cover only those banking companies which fall within the purview of the
definition and no other.”Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

27. In N.D.P. Namboodripad v. Union of India : (2007) 4 SCC 502 the Court
observed: (SCC p. 509, para 18) “18. The word ‘includes’ has different meanings in
different contexts. Standard dictionaries assign more than one meaning to the word
‘include’. Webster’s Dictionary defines the word ‘include’ as synonymous with
‘comprise’ or ‘contain’.
Illustrated Oxford Dictionary defines the word ‘include’ as: (i) comprise or reckon in as a part of a
whole; (ii) treat or regard as so included. Collins Dictionary of English Language defines the word
‘includes’ as: (i) to have as contents or part of the contents; be made up of or contain; (ii) to add as
part of something else; put in as part of a set, group or a category;
(iii) to contain as a secondary or minor ingredient or element. It is no doubt true that generally
when the word ‘include’ is used in a definition clause, it is used as a word of enlargement, that is to
make the definition extensive and not restrictive. But the word ‘includes’ is also used to connote a
specific meaning, that is, as ‘means and includes’ or ‘comprises’ or ‘consists of’.” (emphasis in
original)
28. In Hamdard (Wakf) Laboratories v. Labour Commr. : (2007) 5 SCC 281 it was held as under:
(SCC p. 294, para 33) “33. When an interpretation clause uses the word ‘includes’, it is prima facie
extensive. When it uses the word ‘means and includes’, it will afford an exhaustive explanation to
the meaning which for the purposes of the Act must invariably be attached to the word or
expression.” 42.3. In the case of Black Diamond Beverages & Anr. v. Commercial Tax Office, Central
Section, Assessment Wing, Calcutta & Ors.: (1998) 1 SCC 458, while examining a definition that
carried both ‘means’ and ‘includes’ expressions, this Court pointed out that the natural meaning of
the ‘means’ part of the definition is not narrowed down by the ‘includes’ part. This Court extracted
the definition in question and said,-
“5. The 1954 Act generally provides for levy of a single-point tax at the first stage on commodities
notified under Section 25 of that Act. On the other hand, the 1941 Act is a general statute providing
for multipoint levy of sales tax on commodities not covered by the 1954 Act. Sub-clause (d) of
Section 2 of the 1954 Act reads as follows:
“2. (d) ‘sale-price’ used in relation to a dealer means the amount of the money
consideration for the sale of notified commodities manufactured, made or processed
by him in West Bengal, or brought by him into West Bengal from any place outside
West Bengal, for the purpose of sale in West Bengal, less any sum allowed as cash
discount according to trade practice, but includes any sum charged for containers or
other materials for the packaging of notified commodities;” (emphasis supplied)
6. We shall first deal with the contention of the appellants’ counsel based upon the
non-inclusion of “freight charges” in the definition of sale price in Section 2(d) of the
1954 Act.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

7. It is clear that the definition of “sale price” in Section 2(d) uses the words “means”
and “includes”. The first part of the definition defines the meaning of the word “sale
price” and must, in our view, be given its ordinary, popular or natural meaning. The
interpretation thereof is in no way controlled or affected by the second part which
“includes” certain other things in the definition.
This is a well-settled principle of construction. Craies on Statute Law (7th Edn., 1.214) says:
“An interpretation clause which extends the meaning of a word does not take away its
ordinary meaning….
Lord Selborne said in Robinson v. Barton-Eccles Local Board : (1883) 8 AC 798, AC
at p. 801:
‘An interpretation clause of this kind is not meant to prevent the word receiving its
ordinary, popular, and natural sense whenever that would be properly applicable, but
to enable the word as used in the Act … to be applied to something to which it would
not ordinarily be applicable.’ ” (emphasis supplied) Therefore, the inclusive part of
the definition cannot prevent the main provision from receiving its natural meaning.”
The essentials for financial debt and financial creditor
43. Applying the aforementioned fundamental principles to the definition occurring in Section 5(8)
of the Code, we have not an iota of doubt that for a debt to become ‘financial debt’ for the purpose of
Part II of the Code, the basic elements are that it ought to be a disbursal against the consideration
for time value of money. It may include any of the methods for raising money or incurring liability
by the modes prescribed in sub-clauses (a) to (f) of Section 5(8); it may also include any derivative
transaction or counter-indemnity obligation as per sub-clauses (g) and (h) of Section 5(8); and it
may also be the amount of any liability in respect of any of the guarantee or indemnity for any of the
items referred to in sub-clauses (a) to (h). The requirement of existence of a debt, which is disbursed
against the consideration for the time value of money, in our view, remains an essential part even in
respect of any of the transactions/dealings stated in sub-clauses (a) to (i) of Section 5(8), even if it is
not necessarily stated therein. In any case, the definition, by its very frame, cannot be read so
expansive, rather infinitely wide, that the root requirements of ‘disbursement’ against ‘the
consideration for the time value of money’ could be forsaken in the manner that any transaction
could stand alone to become a financial debt. In other words, any of the transactions stated in the
said sub- clauses (a) to (i) of Section 5(8) would be falling within the ambit of ‘financial debt’ only if
it carries the essential elements stated in the principal clause or at least has the features which could
be traced to such essential elements in the principal clause. In yet other words, the essential element
of disbursal, and that too against the consideration for time value of money, needs to be found in the
genesis of any debt before it may be treated as ‘financial debt’ within the meaning of Section 5(8) of
the Code. This debt may be of any nature but a part of it is always required to be carrying, or
corresponding to, or at least having some traces of disbursal against consideration for the time value
of money.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

44. As noticed, the root requirement for a creditor to become financial creditor for the purpose of
Part II of the Code, there must be a financial debt which is owed to that person. He may be the
principal creditor to whom the financial debt is owed or he may be an assignee in terms of extended
meaning of this definition but, and nevertheless, the requirement of existence of a debt being owed
is not forsaken.
45. It is also evident that what is being dealt with and described in Section 5(7) and in Section 5(8) is
the transaction vis-à-vis the corporate debtor. Therefore, for a person to be designated as a financial
creditor of the corporate debtor, it has to be shown that the corporate debtor owes a financial debt to
such person. Understood this way, it becomes clear that a third party to whom the corporate debtor
does not owe a financial debt cannot become its financial creditor for the purpose of Part II of the
Code.
46. Expounding yet further, in our view, the peculiar elements of these expressions “financial
creditor” and “ financial debt”, as occurring in Sections 5(7) and 5(8), when visualised and
compared with the generic expressions “creditor” and “debt” respectively, as occurring in Sections
3(10) and 3(11) of the Code, the scheme of things envisaged by the Code becomes clearer. The
generic term “creditor” is defined to mean any person to whom the debt is owed and then, it has also
been made clear that it includes a ‘financial creditor’, a ‘secured creditor’, an ‘unsecured creditor’, an
‘operational creditor’, and a ‘decree-holder’. Similarly, a “debt” means a liability or obligation in
respect of a claim which is due from any person and this expression has also been given an extended
meaning to include a ‘financial debt’ and an ‘operational debt’.
46.1. The use of the expression “means and includes” in these clauses, on the very same principles of
interpretation as indicated above, makes it clear that for a person to become a creditor, there has to
be a debt i.e., a liability or obligation in respect of a claim which may be due from any person. A
“secured creditor” in terms of Section 3(30) means a creditor in whose favour a security interest is
created; and “security interest”, in terms of Section 3(31), means a right, title or interest or claim of
property created in favour of or provided for a secured creditor by a transaction which secures
payment for the purpose of an obligation and it includes, amongst others, a mortgage. Thus, any
mortgage created in favour of a creditor leads to a security interest being created and thereby, the
creditor becomes a secured creditor. However, when all the defining clauses are read together and
harmoniously, it is clear that the legislature has maintained a distinction amongst the expressions
‘financial creditor’, ‘operational creditor’, ‘secured creditor’ and ‘unsecured creditor’. Every secured
creditor would be a creditor; and every financial creditor would also be a creditor but every secured
creditor may not be a financial creditor. As noticed, the expressions “financial debt” and “financial
creditor”, having their specific and distinct connotations and roles in insolvency and liquidation
process of corporate persons, have only been defined in Part II whereas the expressions “secured
creditor” and “security interest” are defined in Part I.
47. A conjoint reading of the statutory provisions with the enunciation of this Court in Swiss
Ribbons (supra), leaves nothing to doubt that in the scheme of the IBC, what is intended by the
expression ‘financial creditor’ is a person who has direct engagement in the functioning of the
corporate debtor; who is involved right from the beginning while assessing the viability of theAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

corporate debtor; who would engage in restructuring of the loan as well as in reorganisation of the
corporate debtor’s business when there is financial stress. In other words, the financial creditor, by
its own direct involvement in a functional existence of corporate debtor, acquires unique position,
who could be entrusted with the task of ensuring the sustenance and growth of the corporate debtor,
akin to that of a guardian. In the context of insolvency resolution process, this class of stakeholders
namely, financial creditors, is entrusted by the legislature with such a role that it would look forward
to ensure that the corporate debtor is rejuvenated and gets back to its wheels with reasonable
capacity of repaying its debts and to attend on its other obligations. Protection of the rights of all
other stakeholders, including other creditors, would obviously be concomitant of such resurgence of
the corporate debtor.
47.1. Keeping the objectives of the Code in view, the position and role of a person having only
security interest over the assets of the corporate debtor could easily be contrasted with the role of a
financial creditor because the former shall have only the interest of realising the value of its security
(there being no other stakes involved and least any stake in the corporate debtor’s growth or
equitable liquidation) while the latter would, apart from looking at safeguards of its own interests,
would also and simultaneously be interested in rejuvenation, revival and growth of the corporate
debtor. Thus understood, it is clear that if the former i.e., a person having only security interest over
the assets of the corporate debtor is also included as a financial creditor and thereby allowed to have
its say in the processes contemplated by Part II of the Code, the growth and revival of the corporate
debtor may be the casualty. Such result would defeat the very objective and purpose of the Code,
particularly of the provisions aimed at corporate insolvency resolution. 47.2. Therefore, we have no
hesitation in saying that a person having only security interest over the assets of corporate debtor
(like the instant third party securities), even if falling within the description of ‘secured creditor’ by
virtue of collateral security extended by the corporate debtor, would nevertheless stand outside the
sect of ‘financial creditors’ as per the definitions contained in sub- sections (7) and (8) of Section 5
of the Code. Differently put, if a corporate debtor has given its property in mortgage to secure the
debts of a third party, it may lead to a mortgage debt and, therefore, it may fall within the definition
of ‘debt’ under Section 3(10) of the Code. However, it would remain a debt alone and cannot partake
the character of a ‘financial debt’ within the meaning of Section 5(8) of the Code.
The respondent mortgagees are not the financial creditors of corporate debtor JIL
48. Indisputably, the debts in question are in the form of third party security; said to have been
given by the corporate debtor JIL so as to secure the loans/advances/facilities obtained by JAL from
the respondent-lenders. Such a ‘debt’ is not and cannot be a ‘financial debt’ within the meaning of
Section 5(8) of the Code; and hence, the respondent-lenders, the mortgagees, are not the ‘financial
creditors’ of the corporate debtor JIL.
49. Though several decisions have been cited on behalf of the respondent- lenders to contend that
they do fall within the definition of ‘financial creditor’ but for what has been discussed hereinabove,
it does not appear necessary to dilate upon all of them. However, it would be appropriate to take
note of the relevant decisions strongly relied upon by the respondents as infra.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

50. Much emphasis is laid on behalf of the respondents on the observations occurring in another
three-Judge Bench decision of this Court in the case of Essar Steel and predominantly on the
observation therein, that “secured creditors as a class are subsumed in the class of financial
creditors”. Again, the decisions of the Court are required to be understood with reference to the
context. In the case of Essar Steel, the questions before the Court related to the roles of resolution
applicant, resolution professional and Committee of Creditors constituted under the Code and the
jurisdiction of Adjudicating Authority as also the Appellate Tribunal in questioning the resolution
plans. The constitutional validity of the Insolvency and Bankruptcy (Amendment) Act, 2019 was
also under challenge. The problem arose essentially with the decision of NCLAT holding that in a
resolution plan, there could be no difference amongst the creditors in that, a financial creditor and
operational creditor deserve equal treatment under a resolution plan. It was in the setup of such
background that in Essar Steel, this Court made the observations relied upon by the respondents.
50.1. The referred observations in the case of Essar Steel are essentially based on the earlier
observations occurring in the case of Swiss Ribbons. As noticed, the decision in Swiss Ribbons was
rendered by this Court when constitutional validity of various provisions of the Code was put to
challenge. In Essar Steel, this Court reiterated the enunciations in Swiss Ribbons in paragraph 55 in
the following:
“55. Financial creditors are in the business of lending money. The RBI report on
Trend and Progress of Banking in India, 2017-2018 reflects that the net interest
margin of Indian banks for the financial year 2017-2018 is averaged at 2.5%.
Likewise, the global trend for net interest margin was at 3.3% for banks in the USA
and 1.6% for banks in the UK in the year 2016, as per the data published on the
website of the bank. Thus, it is clear that financial creditors earn profit by earning
interest on money lent with low margins, generally being between 1 to 4%. Also,
financial creditors are capital providers for companies, who in turn are able to
purchase assets and provide a working capital to enable such companies to run their
business operation, whereas operational creditors are beneficiaries of amounts lent
by financial creditors which are then used as working capital, and often get paid for
goods and services provided by them to the corporate debtor, out of such working
capital. On the other hand, market research carried out by India Brand Equity
Foundation, a trust established by the Ministry of Commerce and Industry, as
regards the Oil and Gas sector, has stated that the business risk of operational
creditors who operate with higher profit margins and shorter cyclical repayments
must needs be higher. Also, operational creditors have an immediate exit option, by
stopping supply to the corporate debtor, once corporate debtors start defaulting in
payment. Financial creditors may exit on their long-term loans, either upon
repayment of the full amount or upon default, by recalling the entire loan facility
and/or enforcing the security interest which is a time consuming and lengthy process
which usually involves litigation. Financial creditors are also part of a regulated
banking system which involves not merely declaring defaulters as non-performing
assets but also involves restructuring such loans which often results in foregoing
unpaid amounts of interest either wholly or partially. All these differences betweenAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

financial and operational creditors have been reflected, albeit differently, in the
judgment of Swiss Ribbons (supra)…..” 50.2. In the relevant part, the Court found
that NCLAT had fallen in grave error in reading paragraph 77 in Swiss Ribbons de
hors the earlier paragraphs. In that context this Court said,-
“56. By reading paragraph 77 de hors the earlier paragraphs, the Appellate Tribunal has fallen into
grave error. Paragraph 76 clearly refers to the UNCITRAL Legislative Guide which makes it clear
beyond any doubt that equitable treatment is only of similarly situated creditors. This being so, the
observation in paragraph 77 cannot be read to mean that financial and operational creditors must be
paid the same amounts in any resolution plan before it can pass muster. On the contrary, paragraph
77 itself makes it clear that there is a difference in payment of the debts of financial and operational
creditors, operational creditors having to receive a minimum payment, being not less than
liquidation value, which does not apply to financial creditors. The amended Regulation 38 set out in
paragraph 77 again does not lead to the conclusion that financial and operational creditors, or
secured and unsecured creditors, must be paid the same amounts, percentage wise, under the
resolution plan before it can pass muster. Fair and equitable dealing of operational creditors’ rights
under the said Regulation involves the resolution plan stating as to how it has dealt with the
interests of operational creditors, which is not the same thing as saying that they must be paid the
same amount of their debt proportionately. Also, the fact that the operational creditors are given
priority in payment over all financial creditors does not lead to the conclusion that such payment
must necessarily be the same recovery percentage as financial creditors. So long as the provisions of
the Code and the Regulations have been met, it is the commercial wisdom of the requisite majority
of the Committee of Creditors which is to negotiate and accept a resolution plan, which may involve
differential payment to different classes of creditors, together with negotiating with a prospective
resolution applicant for better or different terms which may also involve differences in distribution
of amounts between different classes of creditors.
57. Indeed, by vesting the Committee of Creditors with the discretion of accepting resolution plans
only with financial creditors, operational creditors having no vote, the Code itself differentiates
between the two types of creditors for the reasons given above. Further, as has been reflected in
Swiss Ribbons (supra), most financial creditors are secured creditors, whose security interests must
be protected in order that they do not go ahead and realise their security in legal proceedings, but
instead are incentivised to act within the framework of the Code as persons who will resolve stressed
assets and bring a corporate debtor back to its feet. Shri Sibal’s argument that the expression
“secured creditor” does not find mention in Chapter II of the Code, which deals with the resolution
process, and is only found in Chapter III, which deals with liquidation, is for the reason that secured
creditors as a class are subsumed in the class of financial creditors, as has been held in Swiss
Ribbons (supra). Indeed, Regulation 13(1) of the 2016 Regulations mandates that when the
resolution professional verifies claims, the security interest of secured creditors is also looked at and
gets taken care of….” 50.3. While strongly relying upon one of the observations occurring in Essar
Steel, that secured creditors as a class are subsumed in the class of financial creditors, learned
counsel for the respondents would assert that secured creditors do become financial creditors. The
submission remains untenable for more than one reason. First, the submission itself proceeds on
the same shortcoming as was existing in the NCLAT’s decision that was disapproved by this Court inAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

Essar Steel i.e., reading of a line in a judgment disjunct from the context. Secondly, in the decisions
above-referred, this Court has never expanded the scope of ‘financial debt’ as envisaged by Section
5(8) of the Code. Thirdly, the case of an indirect secured creditor i.e., the person having in its hand
only the security interest over the property of the corporate debtor but with no corresponding
involvement in the finances and growth of the corporate debtor, was never under consideration in
the said decisions. 50.4. We may usefully elaborate a little. On a contextual reading of the
expositions in Essar Steel and Swiss Ribbons, it is but clear that the Court had examined the status
of direct secured creditor of the corporate debtor and there had not been any occasion to examine
the features related with an indirect secured creditor, who is neither involved in assessing the
viability of the corporate debtor nor in lending finances to the corporate debtor for setting up the
business. As noticed, the prime, rather only, area of interest of such indirect secured creditor is in
recovery of its debt and not in reorganization of the corporate debtor’s business. Thus understood, it
is absolutely clear that the class of secured creditors indicated by this Court in Essar Steel and Swiss
Ribbons, as being subsumed in financial creditors, is only that of such secured creditors who are
directly engaged in advancing credit to the corporate debtor and not the indirect creditors who had
extended any loan or facility to a third party but had taken a security from the corporate debtor,
whose resolution is under consideration.
50.5. Hence, we are undoubtedly of the view that the decisions in Swiss Ribbons and Essar Steel do
not enure to the benefit of the respondents; rather on the principles enunciated therein, they only
operate against the respondents.
51. The case of Smt. Kusum (supra) has also been repeatedly referred by the respondents in support
of their contentions that because of the transactions of mortgage, the corporate debtor JIL owes
them the mortgage debt as a guarantee obligation and hence, it falls within the ambit of ‘financial
debt’ within the meaning of Section 5(8) of the Code.
51.1. We may have a close look at the relevant background aspects of the said case of Smt. Kusum.
Therein, the appellant-bank had advanced a loan to the firm of which, husband of the respondent
was the proprietor. The respondent had executed an agreement in favour of the appellant-bank to
the effect that so long as her husband’s firm was indebted to the bank, she would execute, by way of
collateral security, a legal mortgage of the immoveable property, being a flat belonging to her, with
or without possession, in favour of the bank within 14 days of issuance of written requisition for
such execution. Later on, when the bank called upon the respondent to execute the mortgage as per
the agreement, she declined to do so and hence, a suit for specific performance and in the
alternative for damages was filed by the appellant- bank. The Trial Court, however, dismissed the
suit while holding, inter alia, that the agreement in question was without consideration. The suit was
dismissed on certain other grounds too with which we are not concerned herein. 51.2. In appeal by
the bank, the High Court, while holding that the agreement to create a mortgage was specifically
enforceable, proceeded to examine the question as to whether the promise to create mortgage, if
given by a third party and not by the borrower, is for consideration and is valid. The High Court held
that by making the promise, the respondent had agreed to provide collateral security and thereby to
discharge the liability to a third party in case of his default. The Court observed that such guarantee
was limited to the security offered and no personal liability by the promisor; and thus, the promisorAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

became a surety and referred to Sections 126, 127 and 128 of the Contract Act.
51.3. With reference to Section 128 of the Contract Act, the Court pointed out that the liability of a
surety is ordinarily coextensive with that of the debtor but in the case at hand, such liability of the
surety was as otherwise provided by the contract; and such liability of the respondent was to the
extent of securing the dues by creation of mortgage. The Court said that as the principal debtor
could create a mortgage of his immoveable property, a third person could also agree to create a
mortgage so as to secure the dues of the principal debtor. As regards the consideration, the Court
said that though no direct consideration had flowed from the appellant to the respondent but, in
such tripartite agreement, anything done for the benefit of the principal debtor is sufficient
consideration to the surety for giving guarantee. For their relevance, we may notice the relevant
parts of paragraphs 12,13,14,17 and 21 of the said decision in Smt. Kusum as follows:-
“12. The next question that arises is whether such promise to create a mortgage, if
given by a third party and not by the borrower or the principle debtor, is for
consideration and is valid. The learned trial Judge has held that for creating
mortgage, the mortgagor must be a debtor and must have right to redeem mortgage
on payment of the debt and since the present defendant was not the debtor, she could
not create a mortgage in respect of that debt and that the mortgagor should be a
debtor and there must be a relationship of debtor and creditor, the mortgage being a
security for the debt. The learned trial Judge has also held that there was no
consideration for giving this promise of executing the mortgage. Both these aspects
are interrelated. By making the promise by Ex. 20, defendant has agreed to provide
collateral security of a legal mortgage to secure repayment of all the moneys due from
Nitin Pharmaceuticals. Thus, the defendant has promised to discharge the liability of
a third person (the debtor) in case of his default. This guarantee is limited to the
security offered by the promisor, namely, the mortgage and no further personal
liability is taken by the promisor. Thus, the promisor has became a surety and this
would be an agreement to offer security for due performance of that promise and to
that extent. Sections 126, 127 and 128 of the Contract Act read as follows:
*** *** ***
13. The liability of the surety is co-extensive with that of - the debtors. However, in
the present case, the liability of the surety is as otherwise provided by the contract Ex.
20. Therefore, the liability of the defendant is as provided in the agreement and to
that extent of securing dues by a creation of mortgage, no personal liability is
accepted by the surety. It is, therefore, fallacious to say that the defendant is not a
debtor and, therefore, the defendant could not have created a mortgage in favour of
the creditor. The defendant has rendered himself liable to the dues of Nitin
Pharmaceuticals by agreeing to provide security in the form of mortgage for the dues.
Just as the principal debtor can create a mortgage of his immovable properties, a
third person can also agree to create a mortgage so as to secure the dues of the
principal debtor. In that manner, he becomes a surety to the extent of the security orAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

the mortgage. If that were not so, the present commercial and banking transactions
would not be possible and would be hampered to a great extent. In the present day
world of commerce, a person may not have sufficient security to offer for obtaining
advances from financial institutions even though satisfying the requirements. In such
cases, he draws upon resources of others by asking them to give guarantee and also
security for the performance of that guarantee and it is a perfectly legitimated and
legal way of conducting such commercial transactions. In fact, Chapter VIII of the
Contract Act deals with indemnity and guarantee and provides for this kind of
tripartite arrangement.
14. As regards consideration, it is true that no direct consideration has flowed from
the plaintiff to the defendant who has made the promise to create a mortgage. But in
such tripartite arrangement, anything done for the benefit of the principal debtor is a
sufficient consideration to the survey for giving guarantee as expressly provided in
Section 127 of the Contract Act. Thus, even though there is no consideration to the
third party-surety for mortgages, the consideration of having done anything for the
benefit of the principal debtor is a sufficient consideration.
*** *** *** ***
17. In the present case, the consideration that anything done for the benefit of the
principal debtor is a sufficient consideration to the surety. Anything done in the
present case is that the loans advanced to the principal debtor who is the husband of
the present defendant. She has agreed to give collateral security to secure the dues in
default of payment by her husband. Apart from the close relationship of husband and
wife, there is substantial consideration by having advanced the loan.
*** *** *** ***
21. Thus, the plaintiff not enforcing the claim against the principal debtor or even the
third person may be sufficient consideration by the debtor or third person to give
security for the debt and the consideration for such promise is that by such
forbearance, the creditor is delayed and the debtor or third party is benefited. It is
also seen that even in absence of express promise to forbear, a simple forbearance
from enforcing the claim can be held to have been implied in the present case. This
promise and agreement was given in 1975 and it is clear that thereafter for two years,
the claim was not pressed which shows that there is actual forbearance against the
principal debtor after this Ex. 20 was executed. Thus, even under the English Law,
this consideration is held to be good and sufficient consideration. Under Indian Law,
which is significantly different from English Law of Contract, past consideration or
the consideration towards third person is statutorily held to be good consideration as
defined in Section 2(d) and as mentioned in Section 127 of the Contract Act. The
observation of the learned trial Judge that as the husband of the defendant had to pay
Rs. 5 lacs to the plaintiff, the writing Ex. 20 which is subsequently obtained is withoutAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

consideration, is patently erroneous. In the present case, it is amply clear that the
principal debtor was a defaulter in meeting his financial obligations to the bank and
the bank had noticed the irregularities in his accounts and the, bank could have
proceeded against the principal debtor to effect recovery. At that stage, at the
instance of the principal debtor-husband, wife comes forward and agrees to give
collateral security obviously to secure forbearance against the principal debtor. Thus,
at the desire of the promisor (defendant) the bank has abstained from enforcing its
claim against the principal debtor and has forborne itself from suing the husband.
Such forbearance is sufficient and valid consideration for the promise made by the
defendant to agree to create mortgage and give collateral security. The learned Trial
Judge is in error in observing that "an act done at the desire of third party is not a
consideration." It must, therefore, be held that the suit agreement Ex. 20 is for
sufficient and valid consideration and is valid and enforceable.” 51.4. The said
decision in Smt. Kusum, at best, leads to the position that a promise to create a
mortgage, even if given by a third party and not by the borrower would be deemed to
be for consideration; that even if no direct consideration had flown from the plaintiff
to the defendant who made the promise to create the mortgage, anything done for the
benefit of the principal debtor would be sufficient consideration to the surety for
giving guarantee as provided under Section 127 of the Contract Act. When the
creditor abstained from enforcing the claim against the principal debtor because of
such promise to create mortgage by the defendant, such forbearance was held to be
sufficient and valid consideration. It is difficult to stretch the ratio of the said
decision so as to be applied to the issue at hand concerning the definition of
“financial debt” under Section 5(8) of the Code, which conspicuously omits mortgage;
and which requires “disbursement” against “the consideration for the time value of
money” as the lead elements. As said, the respondent-
lenders of JAL, while holding the mortgages in their hands, as said to have been executed by the
corporate debtor JIL, may be carrying a security interest and may be the creditors who may claim to
be falling within the terminology ‘secured creditors’, yet cannot become ‘financial creditors’ of the
corporate debtor JIL who is not owing any ‘financial debt’ to them. The decision in Smt. Kusum does
not make out a case in favour of the respondents, the lenders of JAL.
52. Another decision forming the mainstay of the respondents had been that in the case of
Rajkumari Kaushalya Devi (supra). The relevant background aspects of the said case had been that
the appellant had executed two usufructuary mortgages with respect to the two properties situated
in Feroozepore city in favour of the respondent while also taking the same property on lease on the
very same date in 1946. On default in effecting payments by the appellant, the respondents filed an
application under Section 13 of the Displaced Persons (Debts Adjustment) Act 70 of 1951 53 seeking
recovery of the principal amount together with arrears of rental. While omitting other aspects which
may not be relevant, noticeable it is for the present purpose that one of the points for consideration
in the case had been as to whether the liability created under the said mortgage was a ‘debt’ within
the meaning of Section 2(6) of the Act 70 of 1951. It was contended on behalf of the appellant that
such liability under the mortgage was not a pecuniary liability and, therefore, Section 2(6) did notAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

apply to a mortgage debt. 52.1. The argument aforesaid was rejected by this Court after taking note
of the definition of ‘debt’ as occurring in the said enactment. The principal part of the said
definition, relevant for the present purpose read as under:-
“ ‘Debt’ means any pecuniary liability, whether payable presently or in future, or
under a decree or order of civil or revenue court or otherwise, or whether ascertained
or to be ascertained, which — *** *** ***” 52.2. This Court, inter alia, observed, with
reference to the definition aforesaid as occurring in Act 70 of 1951 and the definition
of ‘mortgage’ as occurring in the Transfer of Property Act, as under:
“3….The main contention of the appellant in this connection is that a mortgage debt
is not a pecuniary liability and therefore does not fall within the definition of debt at
all. We are of opinion that there is no force in this contention. The words “pecuniary
liability” will cover any liability which is of a monetary nature. Now the definition of a
mortgage in Section 58 of the Transfer of Property Act 4 of 1882, shows that though it
is the transfer of an
53 ‘Act 70 of 1951’ for short interest in specific immovable property, the purpose of the transfer is to
secure the payment of money advanced or to be advanced by way of loan or to secure an existing or
future debt or the performance of an engagement which may give rise to a pecuniary liability. The
money advanced by way of loan, for example, which is secured by a mortgage, obviously creates a
pecuniary liability. It is true that a mortgage in addition to creating the pecuniary liability also
transfers interest in the specific immovable property to secure that liability; none the less the loan or
debt to secure which the mortgage is created will remain a pecuniary liability of the person creating
the mortgage. Therefore a mortgage debt would create a pecuniary liability upon the mortgagor and
would be covered by the definition of the word “debt” in Section 2(6)….” 52.3. The proposition
aforesaid, being related with the definition of ‘debt’ as occurring in the said enactment (Act 70 of
1951), cannot have a direct application in the present case. In any event, the said decision cannot be
taken as an authority governing the transaction where there is no direct debt of the mortgagor
himself.
53. The other citations, on various terminologies related with mercantile law and mortgage
transactions, do not advance the cause of the respondents because of distinct and rather peculiar
requirements of Section 5(8) of the Code. Of course, the decision of NCLAT in SREI Infrastructure
Finance Limited (supra) stands disapproved for what we have held hereinabove. Equally, the other
submissions about the contents of the documents in question as also the entitlement of
respondent-lenders to invoke the security or to take up the proceedings under SARFAESI Act etc. do
not, in any event, make the transactions in question ‘financial debts’ within the meaning of Section
5(8) of the Code. Such submissions have only been noted to be rejected.
Summation on second issue
54. For what has been discussed hereinabove, on the issue as to whether lenders of JAL could be
treated as financial creditors, we hold that such lenders of JAL, on the strength of the mortgages inAnuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

question, may fall in the category of secured creditors, but such mortgages being neither towards
any loan, facility or advance to the corporate debtor nor towards protecting any facility or security of
the corporate debtor, it cannot be said that the corporate debtor owes them any ‘financial debt’
within the meaning of Section 5(8) of the Code; and hence, such lenders of JAL do not fall in the
category of the ‘financial creditors’ of the corporate debtor JIL.
Conclusion
55. Accordingly, and in view of the above, these appeals are allowed to the extent and in the manner
that:
1) The impugned order dated 01.08.2019 as passed by NCLAT in the batch of appeals
is reversed and is set aside.
2) The appeals preferred before NCLAT against the order dated 16.05.2018, as passed
by NCLT on the application filed by IRP, are dismissed;
and consequently, the order dated 16.05.2018 so passed by NCLT is upheld in regard to the findings
that the transactions in question are preferential within the meaning of Section 43 of the Code. The
directions by NCLT for avoidance of such transactions are also upheld accordingly.
3) The appeals preferred before NCLAT against the orders passed by NCLT dated 09.05.2018 and
15.05.2018 on the applications filed by the lender banks are also dismissed and the respective orders
passed by NCLT are restored with the findings that the applicants are not the financial creditors of
the corporate debtor Jaypee Infratech Limited.
Acknowledgement
56. While closing on these appeals, we put on record our thanks and compliments to the learned
counsel for the respective parties as also their associates and researchers for erudite and scholarly
presentation of their respective view-points, in oral as also in written submissions and in rendering
invaluable assistance to the Court in dealing with the vast variety of questions involved in these
matters.
………………….….J. (A.M.Khanwilkar) ………………….….J. (Dinesh Maheshwari) New Delhi, Dated:
26th February, 2020.Anuj Jain Interim Resolution ... vs Axis Bank Limited on 26 February, 2020

