Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors.
on 23 October, 2020
Author: Jayant Nath
Bench: Jayant Nath
$~J-
*    IN THE HIGH COURT OF DELHI AT NEW DELHI
%                                          Date of Decision: 23.10.2020
+     CS(COMM) 434/2017
      BENNETT COLEMAN & CO. LTD.                 ..... Plaintiff
                  Through    Mr.Hemant Singh, Mr.Vipul Tiwary
                  and Ms.Shipra Alisha Philip, Advs.
                         Versus
      ARG OUTLIER MEDIA PVT LTD & ORS          ...... Defendants
                   Through Mr.Sandeep Sethi, Sr. Adv. with
                   Ms.Malvika Trivedi, Mr.Mrinal Ojha, Mr.Harshul
                   Singh,Mr.Debarshi Dutta and Mr.Rajat Pradhan,
                   Advs.
      CORAM:
      HON'BLE MR. JUSTICE JAYANT NATH
JAYANT NATH, J.
1. The aforesaid suit is filed by the plaintiff seeking a decree of permanent injunction in favour of the
plaintiff and against the defendants, etc. from using the trade mark/title/tagline NEWSHOUR or
any other such mark/title/tagline comprising NEWSHOUR as a part thereof amounting to
infringement of the plaintiff's registered mark. A decree of permanent injunction is also sought to
restrain the defendants from adopting or using the trademarks/titles/taglines NATION WANTS TO
KNOW or any other trade mark/title/tagline either by itself or comprising NATION WANTS TO
KNOW or any derivatives or combinations thereof. Other connected reliefs are also sought.
2. IA No. 7306/2017 is filed by the plaintiff under Order 39 Rules 1 & 2 CPC seeking an interim
injunction to restrain the defendants from adopting and using the trademarks/titles/taglines
NEWSHOUR and NATION WANTS TO KNOW or any other trade mark/title/tagline comprising
NEWSHOUR as a part thereof amounting to infringement of the plaintiff's registered trade mark as
well as dilution or acts of passing off.
3. I may only note that when this matter came up for hearing on 05.07.2017, this court noted the
submission of learned senior counsel for the plaintiff that he does not wish to press for an interimBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

order at that stage. This court also directed that till the present suit is pending, none of the parties to
the suit will report or publish any news with regard to it except reproducing the court order and the
order was not to operate against third party publication or news channels or social media.
4. The plaintiff Company is said to be the flagship Company of the Times Group carrying on print
media business since 1838. The key business of the plaintiff Company is television broadcasting and
its distribution services. The television division of the Times Group is under the plaintiff Company.
'Times Now' is a news channel operated by the plaintiff having several segments of programmes.
One of such programmes, it is stated, which was launched in 2006 titled as THE NEWSHOUR
pertained to discussions, panel discussions and debates on current topics. This programme THE
NEWSHOUR was launched by Times Now on 31.01.2006. It is stated that the title of the said
programme THE NEWSHOUR is the plaintiff's registered trade mark and has been in continuous
use since 2006 having been developed in various forms and derivatives including word and label
marks. It is claimed that the mark THE NEWSHOUR has attained distinct identity to differentiate
the programme amongst other programmes in the industry. The plaintiff gives the details of the
registration of the trade mark THE NEWSHOUR under Classes 16, 35 and 38, the registration being
dated 15.05.2014 with the user claimed since 31.01.2006. Hence, it is claimed that the plaintiff being
the proprietor of the trade mark THE NEWSHOUR has a statutory right to the exclusive use thereof
in India. The plaintiff has also applied for registration of the mark NEWSHOUR in Classes 9 and 41
and the same are pending registration before the Trade Mark Registry.
It is also claimed that every month the plaintiff releases multiple advertisements for its publication
through e-mails, newspaper ads, etc. It is claimed that the Television Audience Measurement (TAM)
and Broadcast Audience Research Council (BARC) Reports for the year 2010 suggest that the
plaintiff's Channel Times Now and the programmes aired on the channels have gathered maximum
number of eye balls/viewership in comparison to competitor channels and programmes.
5. It is further stated that in order to popularize the said programme 'THE NEWSHOUR', the
plaintiff invested its resources to generate strategies, concepts, implement segments and formulate
catch lines/titles. During such creative efforts by the plaintiff the catch line/tagline/title NATION
WANTS TO KNOW was created for and on behalf of the plaintiff. It is pleaded that this tagline was
coined and developed by the then editorial and marketing team of the plaintiff as key words to be
used during the discussions and debates conducted on the NEWSHOUR programme. It is stated
that on account of usage of the tagline primarily as a part of the programme, the same has acquired
goodwill and distinctiveness indicative of the programme originating from the plaintiff in the eyes of
the viewers of the channel. The tagline NATION WANTS TO KNOW is a coined mark and is
inherently creative. Keeping in mind the goodwill and popularity generated by the tagline NATION
WANTS TO KNOW, the plaintiff has applied for registration of the trade mark- word mark and logo
of the said tagline in Classes 38 and 41 which covers broadcasting and entertainment services
respectively. The applications have been filed on 17.12.2016. It is stated in the plaint that initially the
applications were filed for registration of the mark NATION WANTS TO KNOW as "proposed to be
used" on account of inadvertence and oversight. The plaintiff has thereafter filed an application for
amendment of the word mark applications by mentioning the user date as 31.01.2006.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

6. It is reiterated that the plaintiff is the proprietor of the trademarks/titles/taglines THE
NEWSHOUR and THE NATION WANTS TO KNOW. The plaintiff has been using the mark/title
The NEWSHOUR continuously since the launch of Times Now i.e. since 2006 and the tagline THE
NATION WANTS TO KNOW has been closely associated and used with THE NEWSHOUR for over
several years. It is claimed that the plaintiff has for the said mark/title/tagline continuously
expended huge sums of money and time in creation, production, advertisement, marketing and
publicity of the brand and its channel. The details of the marketing spends have been stated in the
plaint.
7. Regarding the defendants, it is stated that defendants No. 1 and 3 are companies. Defendant No. 1
is the company which has filed the impugned trade mark applications which are subject matter of
the present dispute.
Defendant No. 2 is said to be the Managing Director of defendant No. 3 company and is said to be
involved in the same business of media and broadcasting as that of the plaintiff. Defendant No. 2 is a
journalist and an ex-employee of the plaintiff Company. He resigned from the post of
Editor-in-Chief of the plaintiff's channel w.e.f. 18.11.2016. On 06.05.2017, he launched a news
channel 'Republic TV' as well as a website www.republicworld.com. The defendants have also filed
trade mark applications for registration of the mark NATION WANTS TO KNOW, ARNAB
GOSWAMI NEWSHOUR, GOSWAMI NEWSHOUR SUNDAY, etc. claiming proprietary rights. The
applications have been filed in class 38 on 27.01.2017 for some of the marks/device. The user for the
mark NATION WANTS TO KNOW is claimed since 20.11.2016 and for other marks, the applications
mention 'proposed to be used'.
8. It is stated that on coming to know that the defendants propose to adopt and use the aforesaid
infringing trade mark/title/tagline, the plaintiff issued cease and desist notices dated 01.04.2017
and 13.04.2017 to the defendants to desist from adopting and using the infringing
marks/titles/taglines THE NEWSHOUR and THE NATION WANTS TO KNOW respectively. It is
stated that no reply was received. However, on 24.06.2017, the defendants commenced use of the
tagline NATION WANTS TO KNOW on their news channel.
9. It is stated that defendant No. 2 had joined the plaintiff's company Times Global Broadcasting
Company Limited in 2004/2005 well before the launch of the plaintiff's Times Now Channel. He
was playing a very vital role in the plaintiff's channel as Editor-in-Chief. He was privy to utmost
confidential information. It is stated that as per the employment agreement and other terms of the
employment of defendant No. 2 with the plaintiff, all intellectual property rights in everything and
anything created, made, developed or written during defendant No. 2's employment are the sole and
the exclusive property of the plaintiff to the exclusion of the entire world including the defendants. It
is pleaded that defendant No. 2 is trying to take undue advantage of his past services with the
plaintiff and popularity of the plaintiff's programme under the said trade mark/title/tagline.
Reliance is placed on clause 4 of the letter of appointment dated 31.05.2005. It is reiterated that any
brand image which may have accrued to defendant No. 2 over the period of time on account of being
an anchor of the plaintiff's show was due to the investment made by the plaintiff and defendant No.
2 represented the plaintiff and hence, all goodwill and proprietary rights created during such periodBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

belong to the plaintiff.
10. It is further stated that defendant No. 2 and Ms. Prema Sridevi, an ex- employee of the plaintiff
committed breach of the contract and misappropriated the plaintiff's confidential data and
proprietary content pertaining to news stories and committed appropriate offences. The plaintiff
hence filed a complaint with respect to the same before the police. The plaintiff also filed a suit being
CS(COMM) 370/2017 before this court. The said suit is said to be pending. Vide order dated
26.05.2017 in CS(COMM) 370/2017 , a statement was recorded on behalf of the defendants that
clause 4 of defendant No.2's appointment letter dated 31.03.2005 and clause 6 of defendant No.3's
letter dated 16.06.2005 have not been violated and that the said defendants have no intention of
violating the aforesaid clauses. It is pleaded that the defendants are not only guilty of committing
infringement and passing off but are also guilty of violating the undertaking given to the court on
26.05.2017 in CS(COMM) 370/2017.
11. It is reiterated that the defendants have wholly and identically incorporated and usurped the
most dominant feature of the registered mark NEWSHOUR and are infringing the trade
mark/title/tagline as originating from the plaintiff. The plaintiff has used various combinations like
THE NEWSHOUR, THE NEWSHOUR DEBATE, NEWSHOUR WITH ARNAB GOSWAMI,
NEWSHOUR WITH ARNAB GOSWAMI 9, NEWSHOUR WITH ARNAB GOSWAMI 10, etc.
12. It is further pleaded that the plaintiff's tagline/trade mark THE NATION WANTS TO KNOW has
also been copied ad verbum. It is reiterated that the words NEWSHOUR and NATION WANTS TO
KNOW are well known marks associated with the Times Group considering its scale, business,
reputation and goodwill. It is pleaded that the defendants have misled and continued to mislead and
misguide public at large which already associates or is most likely to associate the impugned
trademarks/titles/taglines with the plaint iff Company. It stated that the acts of the defendants also
tentamount to passing off on account of confusion and deception. It is also stated that the acts of the
defendants are causing irreparable injury, damage and prejudice to the plaintiff.
13. I may note that on 23.04.2018, this court while dealing with IA No. 12323/2017 filed under
Order I Rule 10 CPC for deletion of defendant No. 1 noted that the name of defendant No. 1 has been
changed to defendant No.
3. Learned senior counsel for the defendants also undertook that any order passed against
defendant No. 3 shall be binding on defendant No. 1.
Recording the said undertaking, defendant No. 1 was deleted from the array of parties.
14. Defendant No. 2 has filed his written statement. In the written statement it is pleaded that
viewers of news channels belonging to the plaintiff and defendant No. 3 are well informed, literate
and can never associate or confuse between the shows or programmes aired on the respective news
channels. The plaintiff's animosity with the defendants is well known and publicized and hence,
there is no question of any passing off in such circumstances. It is stated that the present
proceedings have been initiated in the form of vendetta litigation and merely in a purported attemptBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

to harass and arm-twist the defendants. The present suit is devoid of any merits.
15. It is further stated that the suit is not maintainable and is barred by the doctrine of Res Sub
Judice. The plaintiff on 17.05.2017 had instituted a suit being CS(COMM) No. 370/2017 alleging
infringement of its alleged intellectual property by defendants No. 2 and 3 and one Ms.Prema
Sridevi. Defendants No. 2 was impleaded as a defendant in the aforesaid suit. The plaintiff in the
said suit alleged infringement of intellectual property but failed and/or deliberately omitted to sue
the claims that have been made in the present suit even though no new facts have come to light
subsequent to filing of the earlier suit. In the absence of any leave from this court under Order II
Rule 2 CPC, the present suit is not maintainable and should be rejected at the very threshold. The
plaintiff, it is pleaded, cannot vex and harass defendant No. 2 twice in respect of the same matter in
issue. The plaintiff was well aware that the defendants were desirous to use the title NEWSHOUR
and other words and tagline as a logo even before filing of the previous suit CS (COMM) No.
370/2017.
16. The claim of the plaintiff to the proprietary rights in the mark NEWSHOUR has been denied. It
is stated that THE NEWSHOUR comprises of words which are generic in nature and are widely used
by different news channels and websites in simple and non-distinct combinations in India and
abroad. The word is descriptive in nature and is widely and commonly perceived as being used by
news channels. Reliance is placed on various widely broadcast items which are watched in the name
and style of NEWSHOUR. The details of such services are given in the written statement. It is
further stated that the registration of the trade mark THE NEWSHOUR in favour of the plaintiff is
not valid since the mark lacks distinctiveness and the same was wrongly granted in favour of the
plaintiff. The defendants have reserved their rights to challenge the validity of the registration
granted in favour of the plaintiff of the mark THE NEWSHOUR.
17. On the tagline NATION WANTS TO KNOW, it is stated that defendant No. 2 as a news anchor
used the tagline frequently and consistently in continuation with the past usage. Defendant No. 2
has been using the tagline till date. The same tagline was used by defendant No. 2 during his tenure
with the plaintiff merely as words of common speech. The words were used as common speech while
anchoring the programme and no other news anchors or journalists who were employed with the
plaintiff use the same as the same was descriptive in nature. The same was neither scripted nor
pre-planned in any manner and the same was used in the form of extempore speech by defendant
No.2. The tagline is synonyms with defendant No. 2. It cannot be conceived as a work over which the
plaintiff can claim proprietary right in any manner. There is no intellectual property right which
enured to the benefits of the plaintiff as words in common speech cannot be considered as
intellectual rights. It is reiterated that the tagline THE NATION WANTS TO KNOW is synonyms
with defendant No. 2 and the same is evident by a simple search on any popular online search
engines where if the words THE NATION WANTS TO KNOW are typed, all of them refer to
defendant No. 2. The said tagline is specific and inseparable from defendant No. 2. The tagline has
become an integral part of the image and individuality of defendant No. 2 and is incapable of being
appropriated or imitated by any other person or entity.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

18. Defendant No. 2 after leaving the employment of the plaintiff came to know about the
applications filed by the plaintiff for registering the tagline as words per se and as a device. It is
pleaded that the plaintiff in both the applications alleged the tagline as "proposed to be used". Later
on, as an afterthought the plaintiff sought to amend the said usage stating it to be a "clerical error".
It is pleaded that the plaintiff cannot pre-pone the date of usage of the tagline by simplicitor filing of
a form in the Registry as the same substantially alters the applications and is impermissible in law.
It is pleaded that filing the applications with the stated usage "proposed to be use" is an indicative of
the fact that the plaintiff had accepted that it had no intellectual property rights in the said tagline
when defendant No. 2 was employed with the plaintiff. The subsequent volte face of changing the
date of user is misconceived and illegal. It is stated that defendant No. 3 has filed applications to
register the tagline NATION WANTS TO KNOW on 27.01.2017. The said application claims user
since November 2016. After resignation of defendant No. 2 from the services of the plaintiff in or
around March 2017, defendant No. 2 got the tagline extensively advertised on various hoardings and
boards which were erected to announce the launch of the new TV channel, namely, Republic TV.
Since January 2017, the defendants have been extensively promoting the tagline to be used through
a device in graphical form more particularly with defendant No.2.
19. Defendant No. 3 has also filed its written statement. It is stated that the present suit has been
instituted as the channel launched by the defendants within a short span of time has stolen a march
over the plaintiff's channel both in popularity and viewership. It is pleaded that the plaintiff has not
sought any specific relief against defendant No. 2. The contentions and averments raised by
defendant No. 2 in his written statement have been reiterated by defendant No. 3.
20. I have heard learned counsel for the plaintiff and learned senior counsel for the defendants. The
parties have also filed their written submissions.
21. Learned counsel for the plaintiff has made the following submissions:
(i) It is pleaded that THE NEWSHOUR is a registered trade mark of the plaintiff in
Class 35, Class 38 and Class 41 all dated 15.05.2014 in relation to programme
title/news broadcast. It is pleaded that registration of the said trade mark THE
NEWSHOUR and its THE NEWS HOUR formative trademarks is prima facie
evidence of its validity under Section 31 of the Trade Marks Act, 1999. It is further
stressed that no application for cancellation of the plaintiff's trade mark registration
has been filed.
Therefore, it is pleaded that an injunction restraining the defendants from using the trade mark
NEWS HOUR per se or in combination with other words ought to be granted in favour of the
plaintiff. It is further pleaded that the plaintiff has been using the trade mark THE NEWS HOUR as
the title of its shows since 2006.
(ii) It is pleaded that in March 2017, the plaintiff came across the trade mark applications for the
mark "ARNAB GOSWAMI'S NEWSHOUR", "ARNAB GOSWAMI'S NEWSHOUR 9", etc. The trade
mark applications were filed by defendant No. 3 for the said trademarks on 20.03.2017 in Class 38Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

on a "proposed to be used" basis. It is stated that the trade mark ARNAB GOSWAMI'S NEWSHOUR
contains the whole of the plaintiff's registered trade mark NEWSHOUR and that it is an established
test of infringement that elements/matter added to a registered trade mark will not prevent its
infringement. It is reiterated that the trade mark "NEWSHOUR" being a registered trade mark, in
view of Sections 28 and 29 of the Trade Marks Act, it would follow that the defendants cannot use
the said trade mark. The plaintiff relies upon the judgments of the Supreme Court in the case of Kavi
Raj Pandit Durga Dutt Sharma vs. N.P. Laboratories, AIR 1965 SC 980 and the judgment of a
Coordinate Bench of this court in the case of Procter & Gamble Co. Vs. Joy Creators & ors., 2011( 45)
PTC 541 (Del.)
(iii) It is further pleaded that the plaintiff's trade mark/tagline NATION WANTS TO KNOW
(hereinafter referred to as NWTK) is based on distinctiveness, goodwill and reputation of the
plaintiff on account of its use since 2006 for goods/services in relation to television broadcast. It is
pleaded that defendant No.2 in its written statement admits that NWTK mark has acquired
immense goodwill and reputation. The claim of the defendants is that the said goodwill and
reputation is associated with him and not the plaintiff. It is pleaded that this contention is
misconceived. Defendant No. 2 was only an anchor while the entire show was a team work involving
a team of editors, researchers, production control team, creative team and script writers. In fact in
the programmes, the anchors' dialogues/comments are based on a script and promps are provided
by the team working behind the camera through a teleprompter and an ear phone which is placed in
the anchor's ear. Defendant No. 2 cannot claim credit for the said mark/tagline.
(iv) It is pleaded that there is likelihood of confusion and deception, if the defendants are permitted
to use the tagline/trademark NWTK. It is pleaded that the defendants admit that NWTK mark is
being used as a tagline. It is pleaded that the tagline is also a mark. Reliance is placed on the
judgment of this court in the case of Procter & Gamble Manufacturing (Tianjin) Co. Ltd. vs. Anchor
Health & Beauty Care Pvt. Ltd., 2014 (59) PTC 421 (Del.)(DB).
(v) It is further pleaded that as per the employment contract signed between defendant No. 2 and
the plaintiff all intellectual property created, developed and used by defendant No. 2 in or on the
channel including in relation to such programme exclusively belongs to the plaintiff. Accordingly, all
intellectual property rights, goodwill and reputation in the trade mark/title/tagline in the
NEWSHOUR and the NWTK belong to the plaintiff and the defendants cannot claim any right over
it. Reliance is placed on clause 5 of employment agreement dated 31.05.2004 and clause 4 of the
employment agreement dated 31.03.2005.
(vi) It is pleaded that the defendants plea that the trade mark/title NEWSHOUR and the tagline
NWTK are generic and descriptive in nature is a misplaced plea. It is pleaded that the trade
mark/title/tagline have acquired a high degree of distinctiveness and secondary meaning on account
of their long and continuous usage, aggressive promotion and marketing on various media and
enormous goodwill and reputation acquired by the plaintiff. It is also pleaded that the tagline/trade
mark NWTK does not indicate the kind, quality or characteristics of the services it is used for i.e.
television broadcast and therefore, it cannot be said to be descriptive. Reliance is again placed on
the judgment of the Division Bench of this court in the case of Procter & Gamble ManufacturingBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

(Tianjin) Co. Ltd. vs. Anchor Health & Beauty Care Pvt. Ltd., (supra).
(vii) It is further pleaded that the defendants cannot be permitted to approbate and reprobate. The
defendants themselves have claimed proprietary rights in the subject trade mark/title/tagline
NEWSHOUR and NWTK by filing trade mark applications. The defendants cannot be permitted to
approbate and reprobate before the courts of law. They are precluded from alleging that the subject
marks are generic or descriptive.
(viii) Regarding the plea of the defendants that that this suit is barred on account of the doctrine of
Res Sub Judice, it has been pleaded that the previous suit being CS(COMM) 370/2017 is a suit for
breach of the contract of employment as the defendants during employment of the plaintiff had
taken away stories/material in the form of audio conversations/recordings without knowledge and
consent of the plaintiff and was dishonestly converting it for his own use on the channel "The
Republic TV". The present suit in contrast is a suit for infringement of trade mark/passing
off/dilution/blurring, etc. Therefore, the subject matter of the present suit is different from the
previous suit. Further, the cause of action for filing of the previous suit as well as the present suit are
on different footings. It is reiterated that in the earlier suit, defendant No. 2 had made a statement
that he has no intentions of violating the employment agreement. It is pleaded that defendant No. 2
has breached the said undertaking given to the court.
22. Learned senior counsel for the defendants has pleaded as follows:-
(i) He has strenuously urged that the present suit is barred by the principles of Res
Sub Judice. It is pleaded that the matter in issue in the present suit is also directly
and substantially an issue in the previous suit filed by the plaintiff being CS(COMM)
370/2017 that was instituted on 17.05.2017. The plaintiff was aware of the trade mark
applications filed by the defendants in March 2017 and omitted to sue/relinquished
the claims deliberately in the previous suit. In the absence of any leave of this court
under Order II Rule 2 CPC is attracted and the present suit is not maintainable.
(ii) It is further pleaded that the viewers of the plaintiff's and the defendants' news channels are well
informed and literate persons and can never confuse between the shows aired on the respective
channels of the plaintiff and defendants. Reliance is placed on the judgment of the Division Bench of
this court in the case of Cadila Healthcare Limited v. Gujarat Co- operative Milk Marketing
Federation Ltd., ILR (2010) II Delhi 85.
(iii) It is also pleaded that THE NEWSHOUR mark comprises of generic words and is widely used by
news channels and websites in India and abroad. It has been urged that NEWSHOUR is descriptive
in the news industry being a common term and its likening to news is unmistakable. There is
nothing inherent in it. It is alleged that everybody uses the said mark NEWSHOUR. Reliance is
placed on Section 9 and 11 of the Trade Marks Act. Learned senior counsel relied upon various
examples pertaining to use of the mark "THE NEWSHOUR". It is also pleaded that BBC also uses
NEWSHOUR. Hence, there cannot be any passing off of the mark NEWSHOUR.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

(iv) It is further stated that the defendants' mark with addition of prefixes or suffixes with
NEWSHOUR is not deceptively similar to the alleged registered mark of the plaintiff. The plaintiff's
mark lacks distinctiveness and has been wrongly registered. Liberty is sought to challenge the said
registered mark in the written statement filed. The defendants seek to use the combination of
NEWSHOUR-Arnab Goswami's Newshour, Arnab Goswami's Newshour 9, Arnab Goswami's
Newshour 10, Arnab Goswami's Newshour Sunday, etc.
(v) It is pleaded that the expression NWTK and the tagline is not registered in favour of the plaintiff.
The relief against alleged infringement is hence not sustainable. Claim for passing off is also
untenable as there is no misrepresentation by the defendants to its viewers which is calculated to
injure the plaintiff's business/goodwill and no damage has been caused to the plaintiff.
(vi) It is further stated that the tagline NWTK has become synonyms and exclusive to defendant No.
2 due to it standalone and past usage. It was a distinctive tool of news dispensation used by
defendant No. 2. The tagline is an integral part of defendant No.2's image and inseparable from his
individuality. The said tagline was never associated with the plaintiff. It was associated with
defendant No. 2 and its personality. It has been pointed out that if one were to do a search on google
search, yahoo search, facebook or twitter, the tagline NWTK is referred only to defendant No. 2.
Reliance is also placed on a book written by Mr.Rajdeep Sardesai titled as "2014 The Election that
changed India' which refers to Arnab's NWTK. It is reiterated that the plaintiff has not filed any
material to show that it has acquired goodwill or reputation in relation to the tagline. There is
nothing on record which would even remotely suggest that people associate the tagline with the
plaintiff.
(vii) It is further pleaded that the use of the tagline by defendant No.2 was never
pre-planned/scripted. It was used as words of common speech for which there is no intellectual
property rights which enured to the plaintiff. It is a spontaneous and creative expression coined by
defendant No.2. It is reiterated that the tagline NWTK is not a trade mark and only a part of the
speech. Reliance is placed on Section 2(1)(z)(b) of the Trade Marks Act to state this NWTK is not a
trade mark.
(viii) It is further stated that defendant No. 2 after resigning from the plaintiff's employment on
18.11.2016 filed the trade mark applications on 27.01.2017 seeking registration of the tagline as a
device wherein usage was claimed from November 2016. Defendant No. 2 decided to nurture the
said tagline by advertising it on hoardings and filing above applications and commencing a show in
its name on 24.06.2017.
(ix) It is also pointed out that the plaintiff filed a trade mark application on 17.12.2016 for the usage
of NWTK on a "proposed to be used" basis. It is clear that the plaintiff accepted that there were no
intellectual property rights which subsisted in the tagline. Later on, the applications were amended
by changing the date of usage to 31.01.2006 as an afterthought to better its claim. It is stated that
there is nothing on record to show that the plaintiff was using the tagline since 31.01.2006. The
amendment to the application seeking change of date of user is illegal and hit by Rule 37 of the
Trade Marks Rules 2017.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

(x) It is further pleaded that none of the documents adduced by the plaint iff ind icate a connection
to any goods or services/plaintiff's news channel. The phrase was used only to pose questions during
interviews or while presenting news.
(xi) It is further pleaded that the tagline NWTK and the mark NEWHOUR are not governed by the
employment contract between the plaintiff and defendant No. 2. These are not trademarks to which
the plaintiff has any right.
23. I may first deal with the preliminary objection raised by the defendants that the present suit is
barred by the principle of Res Sub Judice. This plea has been taken stating that the matter in the
present suit is directly and substantially in issue in the previous suit filed by the plaintiff being CS
(COMM) 370/2017.
24. I may have a look at the earlier suit filed by the plaintiff. The earlier suit being CS(COMM)
370/2017 has been filed as a suit for permanent and mandatory injunction. The reliefs prayed in the
said suit are as follows:-
"a. Pass a decree of permanent injunction in favour of the Plaintiff and against the
Defendants, its employees, assigns, nominees, etc. restraining the Defendants, its
employees, assigns, nominees, etc. all other persons acting on its behalf from using or
causing to use intellectual properties of the Plaintiff, disclosing/using the confidential
information of the Plaintiff and broadcasting or causing to broadcast such intellectual
properties, confidential information and/or confidential/secret audio and video
recordings pertaining to the Plaintiff, its management, senior officers, Directors,
and/or other employees;
b. Pass a decree of mandatory injunction in favour of the Plaintiff and against the
Defendants, its employees, assigns, nominees, etc. directing the Defendants, its
employees, assigns, nominees, etc. all other persons acting on its behalf to handover
intellectual properties of the Plaintiff, the confidential information of the Plaintiff,
confidential/secret audio and video recordings pertaining to the Plaintiff, its
management, senior officers, Directors, and/or other employees;"
25. The present suit is filed seeking the following reliefs:-
"(a) Pass a decree of permanent injunction in favour of the Plaintiff and against the
Defendants permanently restraining the Defendants, their directors, agents, officers,
employees, cable operators, multi system operators, direct to home operators and all
such other persons associated with the Defendants from adopting and using the trade
mark/title/tagline NEWSHOUR or any other trade marks/titles/taglines either by
itself or comprising "NEWSHOUR" as a part thereof amounting to infringement of
Plaintiff's registered trade mark as enumerated above in the plaint including dilution;Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

(b) Pass a decree of permanent injunction in favour of the Plaintiff and against the
Defendants permanently restraining the Defendants, their directors, agents, officers,
employees, cable operators, multi system operators, direct to home operators and all
such other persons associated with the Defendants from adopting and using the trade
marks/titles/taglines NEWSHOUR, NATION WANTS TO KNOW or any other trade
marks/titles/taglines either by itself or comprising of NEWSHOUR, NATION
WANTS TO KNOW or any derivatives or combinations thereof or any other
deceptively similar trade marks/titles/taglines of the Plaintiff and its channel Times
Now on their television channel Republic TV, its website, i.e. www.republicworld.com
or on any other website/medium or channel in any manner whatsoever amounting to
passing off of the Defendants' business/services for those of the Plaintiff;
(c) Pass a decree of delivery up in favour of the Plaintiff and against the Defendants
directing the Defendants to deliver up all the impugned articles and items that have
upon it, mark that is identical/deceptively similar to that of the Plaintiffs' trade
marks/ titles/taglines or any other material infringing the rights of the Plaintiffs,
lying in the possession of the Defendants and their principal officers, directors,
agents, franchisees, servants etc.;
(d) Pass a decree of rendition of accounts in favour of the Plaintiff and against the
Defendants directing the Defendants to render all accounts of profits illegally earned
by the Defendants on account of their infringing activities and a decree for the
amount ascertained by this Hon'ble Court be passed against the Defendants and in
favour of the Plaintiffs; and/or
(e) Pass a decree directing the Defendants to pay a sum of Rs.1,00,00,000/- towards
damages to the Plaintiffs;"
26. What clearly follows is that the earlier suit being CS(COMM) 370/2017 is filed by the plaintiff
seeking the relief of injunction to restrain the defendants from using the intellectual properties of
the plaintiff. The grievance was that defendant No. 2 herein and other defendants have wilfully and
deliberately converted for their own use and for airing on Republic TV, the intellectual property of
the plaintiff channel. In contrast, as is apparent from the prayer clause of the present suit, the
present suit is filed to restrain the defendants from infringing the registered trade mark of the
plaintiff 'NEWS HOUR and to restrain the defendants from using the mark/title/tagline 'NATION
WANTS TO KNOW' in a manner which tentamounts to passing off of the defendants business
/services as those of the plaintiff.
27. Order 2 Rule 2 CPC reads as follow:-
"2. Suit to include the whole claim.--
(1) Every suit shall include the whole of the claim which the plaintiff is entitled to
make in respect of the cause of action; but a plaintiff may relinquish any portion ofBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

his claim in order to bring the suit within the jurisdiction of any Court.
(2) Relinquishment of part of claim.--Where a plaintiff omits to sue in respect of, or
intentionally relinquishes, any portion of his claim, he shall not afterwards sue in
respect of the portion so omitted or relinquished.
(3) Omission to sue for one of several reliefs.--A person entitled to more than one
relief in respect of the same cause of action may sue for all or any of such reliefs; but
if he omits, except with the leave of the Court, to sue for all such reliefs, he shall not
afterwards sue for any relief so omitted."
28. Hence, a plaintiff is bound to include the whole of the claim which he is entitled to make in
respect of the "cause of action". Where a plaintiff omits to sue in respect of any portion of his claim,
he shall not claim thereafter for the portion so omitted and relinquished.
29. What is a cause of action? The Supreme Court in the judgment which was cited by the
defendants i.e. Virgo. Industries (Eng.) P. Ltd. vs. Venturetech Solutions P. Ltd., 2013 (1) SCC 625
defined a "cause of action" as follows:-
"11. The cardinal requirement for application of the provisions contained in Order 2
Rules 2(2) and (3), therefore, is that the cause of action in the later suit must be the
same as in the first suit. It will be wholly unnecessary to enter into any discourse on
the true meaning of the said expression i.e. cause of action, particularly, in view of the
clear enunciation in a recent judgment of this Court in Church of Christ Charitable
Trust and Educational Charitable Society v. Ponniamman Educational Trust [(2012)
8 SCC 706 : (2012) 4 SCC (Civ) 612] . The huge number of opinions rendered on the
issue including the judicial pronouncements available does not fundamentally detract
from what is stated in Halsbury's Laws of England (4th Edn.). The following
reference from the above work would, therefore, be apt for being extracted
hereinbelow:
Cause of action' has been defined as meaning simply a factual situation existence of
which entitles one person to obtain from the Court a remedy against another person.
The phrase has been held from the earliest time to include every fact which is
material to be proved to entitle the plaintiff to succeed, and every fact which a
defendant would have a right to traverse. 'Cause of action' has also been taken to
mean that particular action on the part of the defendant which gives the plaintiff his
cause of complaint, or the subject-matter of grievance founding the action, not
merely the technical cause of action."
30. A cause of action includes every fact which is material to be proved to entitle the plaintiff to
succeed.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

31. As noted above, prima facie the earlier suit filed is based on the cause of action of infringement
of intellectual property right whereas the present suit is based on infringement of trade mark and
seeking appropriate relief pertaining to passing off of the trademark/tagline NATION WANTS TO
KNOW. The facts that the plaintiff has to prove for relief in the first suit are prima facie different
from the facts that are to be proved in the second suit. Prima facie, it is not possible to conclude that
the present suit is barred by the principle of Res Sub Judice.
32. I will now deal with the first relief sought by the plaintiff, namely, an interim injunction to
restrain the defendants from adopting or using the trade mark/title 'NEWS HOUR'. The plaintiff
states that the programme 'THE NEWS HOUR' which pertains to discussions, panel discussions,
debates on current topics was launched in 2006. It is a registered trade mark and has been in
continuous use since 2006. The said trade mark has been registered under Classes 16, 35, 38 and 41
on 15.05.2014 with user claimed since 31.01.2006. Hence, as per the plaintiff being the proprietor of
the trade mark NEWS HOUR it has a statutory right to exclusive use thereof in India.
33. The defendants, it is pleaded by the plaintiff, have filed the trade mark application for
registration of the mark ARNAB GOSWAMI'S NEWS HOUR, ARNAB GOSWAMI'S NEW HOUR
SUNDAY, etc. It is stated that the application to register the mark NEWS HOUR with its prefixes
and suffixes has been made on a proposed to be used basis. It is claimed by the plaintiff that the
defendants have sought to incorporate and usurp the most dominating feature of the registered
mark of the plaintiff NEWSHOUR and are using various combinations like THE NEWSHOUR, THE
NEWSHOUR DEBATE, NEWSHOUR WITH ARNAB GOSWAMI, NEWSHOUR WITH ARNAB
GOSWAMI 9, etc. It is pleaded that the said acts of the defendants tentamount to infringement of
the trade mark of the plaintiff. They also amount to passing off of the said trademarks on account of
the confusion and deception.
34. In contrast the defendants plead that the mark NEWS HOUR is a generic word and is widely
used by different news channels and websites in India and abroad. It is pleaded that NEWS HOUR
is descriptive in the news industry being a common term. Reliance is placed on Sections 9 and 11 of
the Trade Marks Act, 1999 to plead that it is a descriptive word and does not deserve any protection
from this court. The defendants have relied upon the judgment of this court in the case of Cadila
Healthcare Limited v. Gujarat Co-operative Milk Marketing Federation Ltd. (supra).
35. The undisputed facts show that the mark NEWS HOUR is a registered trade mark prima facie
used by the plaintiff since 2006.
36. I may first deal with the plea of the defendants that the said mark is generic and is widely used
by news channels and websites in India and abroad.
37. The defendants have relied on the judgment of the Division Bench of this court in the case of
Cadila Healthcare Limited v. Gujarat Co-operative Milk Marketing Federation Ltd., (supra). That
was a case where the plaintiff had filed a suit for injunction to restrain the defendants from using the
trade mark 'Sugar Free'. On the facts, the Division Bench of this court had held as follows:-Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

"14. In consonance with the above view we are also not in a position to agree with the
appellant that the word Sugar Free' has become so distinctive of the sugar substitute
and has acquired such a secondary meaning in the sugar substitute market that it
cannot refer to any other food product except the appellant's sugar substituted
product labelled Sugar Free'. There cannot be any doubt that the word sugar free is
not inherently distinctive and is clearly descriptive in nature. In fact, the word Sugar
Free in essence clearly only describes the characteristics of the appellant's product
and therefore, cannot afford it the protection sought in the plaint by restraining the
respondent from using the phrase sugar free'. Sugar Free', prima facie has not
attained any distinctiveness, as alleged by the appellant outside the field of sugar
substitute artificial sweeteners and the appellant would not be entitled to exclusively
claim the user of the expression sugar free' in respect of any product beyond its range
of products and the respondent cannot be restrained from absolutely using the
expression Sugar Free', particularly in the descriptive sense. A mere descriptive usage
of the expression Sugar Free' by the respondent may thus blunt the edge of claim of
distinctiveness by the appellant. However, we make it clear that if any party enters
into the domain of artificial sweeteners with the trademark Sugar Free' the appellant
may have a just cause in seeking restraint."
38. Hence, it was in those facts of the case regarding an action for passing off that the court came to
a conclusion that the word 'Sugar Free' only describes the characteristics of the product and the
mark is not inherently distinctive and is clearly descriptive and cannot afford it protection as is
sought. The said judgment was on the facts of the case and does not help the case of the defendants.
39. I may look at some of the other judgments also in this regard. Reference may be had to a
judgment of this court in the case of Living Media India Ltd. & Anr. Vs. Alpha Dealcom Pvt. Ltd. &
Ors., (2016) 227 DLT 681. That was a case in which the plaintiff was the publisher and owner of the
news magazine 'India Today'. The defendant's impugned mark was 'National Today'. The plaintiff's
trade mark 'India Today' was a registered mark. The court held as follows:-
"19. The law demands closer scrutiny, when it comes to the use of common words
(such as TODAY), that are descriptive (or semi-descriptive) of the services or goods
offered by the service provider or trader. This reluctance was best described in
Joseph Crosfield & Sons Ltd., In re [(1910) 1 Ch 130] "Wealthy traders are habitually
eager to enclose part of the great common of the English language and to exclude the
general public of the present day and of the future from access to the inclosure."
Again, in Mars GB Ltd. v. Cadbury Ltd. [1987 RPC 387] it was held that:
"Where the trade mark allegedly used by the defendant comprises ordinary English
words (such as 'Page Three', considered by Slade J. in News Group Newspapers Ltd.
v. Rocket Record Co. Ltd. [1981 FSR 89] ) then, as this decision illustrates, that
circumstance may be taken into account by the court in the process of reasoning."Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

The burden of establishing that what are descriptive of the commercial activity and can be protected
particularly when the plaintiff is not directly using it in the same field, but using it in combination
with another or other words is heavy, as expressed in My Kinda Town Ltd. v. Soll [1983 RPC 407. A
similar reasoning was adopted in British Diabetic Assn. v. Diabetic Society Ltd.(1995) 4 All ER 812.
Earlier, in Office Cleaning Services Ltd. v. Westminster Window & General Cleaners Ltd.(1946) 63
RPC 39 it was held that: '...the Courts will not readily assume that the use by a trader as part of his
trade name of descriptive words already used by another trader as part of his trade name is likely to
cause confusion and will easily accept small differences as adequate to avoid it. It is otherwise where
a fancy word has been chosen as part of the name.'] (the Chicago Pizza case):
"It has to be borne in mind always that the burden of proving the case that he has
elected to make is on the plaintiff and it is therefore important to consider the quality
of the evidence which he calls, what it actually establishes, and whether it discharges
that burden. In the ordinary case, this does not call for any very profound analysis for
the question normally is simply whether damaging confusion has arisen or is likely to
arise from similarity of get-up or description. But where it is inherent in the factual
situation in which the parties are operating that there is some risk of confusion in any
event from the mere fact that the parties are conducting the same trade and using in
it descriptive titles of which neither can claim any legitimate monopoly -- as, for
instance, in the Office Cleaning case -- a closer analysis is essential, for the simple
fact of confusion does not, by itself, prove the plaintiff's case for him: it becomes an
extraordinarily difficult question to answer where there is already a substantial
potentiality for confusion of the two businesses simply by reason of their being
engaged in the same trade. That does not mean, of course, that a defendant is
legitimately entitled to build on and increase that potentiality in such a way that
confusion becomes worse confounded, but it does mean that where evidence of actual
confusion is tendered it has to be approached -- as indeed it was here by the learned
Judge with the caveat that there may well be reasons why it occurs which involve no
question of legal liability at all."
Holding that the words LEISURE NEWS were incapable of protection given the fact that the activity
was newly launched, it was held in Marcus Publishing Plc. v. Hutton-Wild Communications Ltd.
[1990 RPC 576. Also in Baywatch Production Co. Inc. v. Home Video Channel1997 FSR 22
injunction was refused to the plaintiff, producer of the series Baywatch, even though the defendant
was using the title "Babewatch" for its serial, having regard to all the surrounding circumstances.]
that:
"But there is the further difficulty that the words Leisure News are merely descriptive
words in the English language, descriptive of the nature of the publication. Of course
descriptive words can come by use to acquire a special meaning as referable, in a
particular field, like the field of magazines, to the product of one particular publisher.
The name Country Life would seem to be a fairly simple example of that. But it is well
established that it is not at all easy to establish goodwill in a name which merely
consists of descriptive words: see Office Cleaning Services Ltd. v. WestminsterBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

Window & General Cleaners Ltd. [(1946) 63 RPC 39] . The law is reluctant to allow
ordinary descriptive words in the English language to be fenced off so as to become
the private preserve of one particular publisher or tradesman."
40. The court in the facts of the case took the view that the rights of the plaintiff do not crystallise
into a right to prevent others from using a common word 'TODAY' in respect of news channel
services.
41. Reference may also be had to the judgment of the Supreme Court in the case of Skyline
Education Institute (India) Pvt. Ltd. vs. S.L. Vaswani & Anr., 2010 (2) SCC 142. In that case, the
respondents were running an educational institute with the name 'Skyline Institute of Engineering
and Technology'. The appellant objected to the use of the word 'Skyline' on the ground that they
were already using this word and had already applied for its registration as a trade mark. The
appellant institute was not a recognised institute. The Supreme Court held as follows:-
"26. In our opinion, the findings recorded by the learned Single Judge and the
Division Bench on the crucial factors like prima facie case, balance of convenience
and equity are based on a correct and balanced consideration of various facets of the
case and it is not possible to find any fault with the conclusions recorded by them that
it is not a fit case for restraining the respondents from using the word "Skyline" in the
name of the institute established by them. It has not been disputed on behalf of the
appellant that the word "Skyline" is being used as trade name by various
companies/organisations/business concerns and also for describing different types of
institutes/institutions. The voluminous record produced by the respondents before
this Court shows that in India as many as 117 companies including computer and
software companies and institutions are operating by using the word "Skyline" as
part of their name/nomenclature. In the United States of America, at least 10
educational/training institutions are operating with different names using "Skyline"
as the first word. In the United Kingdom also two such institutions are operating. In
view of this, it is not possible to agree with the learned counsel for the appellant that
Skyline is not a generic word but is a specific word and his client has right to use that
word to the exclusion of others."
42. Reference in this context may also be had to the judgment of a Coordinate Bench of this court in
the case of Bling Telecom Pvt. Ltd. vs. Micromax Informatics Ltd., MANU/DE/3301/2010. That was
a case in which the plaintiff had filed a suit to restrain the defendants from using BLING as a trade
mark or corporate name wherein this court held as follows:-
"17. As far as word marks go, in Biswaroop Roy Choudhary v. Karan Johar 136 (2006)
DLT 458 this Court propounded a rule of caution in the following terms:
Where words or phrases in common parlance are sought to be used with exclusivity,
the Court should take care to determine which of the parties has ended its journey or
traversed appreciably longer way in the use of such words as a trademark or as a title.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

Normally, proprietary or exclusive use of a common word should not be given jural
imprimatur.
There is undoubtedly some body of authority supporting protection for word marks,
or combination of common words. Globe Super Parts v. Blue Super Flame AIR 1986
Delhi. 245, was a case where the two common words "Super" and "Flame" joined
together were declared as coined words and protection was granted. In Reddaway v.
Banham (13) 1896 RPC 218 "Camel Hair" was concerned with a trademark in relation
to belts made out of Camel hairs. Though both are common words yet they were
construed as descriptive of the article, denoting the goods of a particular
manufacturer, entitling him to restrain others from using them as to deceive
purchasers. In Lakshmikant v. Patel v. Chetanbhat Shah and Anr.
MANU/SC/0763/2001 : AIR 2002 SC 275, the trade mark of the plaintiff was Mukta
Jeevan Colour Lab whereas the defendant adopted the mark QSS Mukta Jeevan. The
plaintiff's claim to distinctiveness of the mark, and allegation of deception by the
defendant, was upheld.
18. On the other hand, W.N. Sharpe LD v. Solomon Bros. LD 1915 RPC 15 held that
certain words such as "good", "best", "superfine" are incapable of adoption. They
cannot have a secondary meaning and are not capable of registration. Parsons Bros.
& Co. v. John Gillespie & Co. 1898 15 RPC 57 is a case where the Court held that the
"Flaked Oatmeal" must be shown by the plaintiff not to be a part of the common
stock of language or the plaintiff must show that the term being originally descriptive
of the articles has now come to denote the goods made by the plaintiff. In Standard
Ideal Co. v. Standard Sanitary Mfg. Co. 1910 RPC 789 , 'Standard' was held not to be a
valid trade mark. Thus, the test in such cases is always subjective to every case and
the Court has to determine whether common words having no nexus to the goods or
services for which a given mark are used, acquire such a reputation, distinctiveness or
secondary meaning as to denote a source specific association. The product, the length
of time of its visibility and the length of time of its association with the mark, its
association or dissociation with generic terms, etc are all pointers; relevant for
judicial determination.
19. Foratrader (or manufacturer) in an action for passing off to secure injunctive
protection, it is necessary to establish what is now known as the classical trademark
"trinity" - a term first used by the House of Lords in Reckitt and Colman Products
Ltd. v. Borden Inc and Ors. [1990] 1 All ER 873. The three elements cited to be
established for passing off were summarized as the plaintiff establishing (in relation
to the mark) (1) a goodwill or reputation;
(2) demonstration, that the use (trademark use by defendant) will lead the public to believe that the
goods or services offered by him are goods and services of the plaintiff; and (3) that he suffers or is
likely to suffer damage by reason of the erroneous belief engendered by the defendant's
misrepresentation that the source of his (the defendant's) goods or services is the same as the sourceBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

of those offered by the plaintiff."
43. It was noted that the test in such cases is always subjective to every case. Usually exclusive use of
a common word would not be given. However, protection of a combination of words can be given.
44. The controversy in question as raised by the defendants gets settled by the judgment of the
Division Bench of this court in the case of Procter & Gamble Manufacturing (Tianjin) Co. Ltd. vs.
Anchor Health & Beauty Care Pvt. Ltd.,(supra). That was a case in which the respondent/plaintiff
had sought an injunction to restrain the appellant/defendant during the pendency of the suit from
using the trade mark 'All Round Protection' / 'All Rounder' or any other mark deceptively similar to
the same. The respondent/plaintiff had applied for registration of the trade mark 'All Round' which
was granted under the Trade Marks Act. The appellant/defendant took a strong plea that the trade
mark 'All Round' is inherently an invalid trade mark being completely a descriptive expression and
incapable of having characteristics of a trade mark. It is not capable of distinguishing goods of one
person from those of another and could not have been registered in view of the embargo contained
in Section 9 of the Trade Marks Act. The Division Bench of this court repelled the above plea of the
appellant/defendant holding as follows:-
"10. We have weighed the rival contentions aforesaid and do not find any merit in
this appeal for the following reasons:-
(i) Neither the Registrar of Trademarks nor anyone else, at the time when the
respondent/plaintiff applied for registration of the trademark "ALLROUND"
objected thereto on any of the grounds mentioned in Section 9 of the Act;
(ii) .....
(iii) Not only the Registrar of Trademarks in India but even the Registrar of
Trademarks in US did not consider that the trademark "ALLROUND" in relation to
toothpaste was devoid of any distinctive character or was not capable of
distinguishing the said goods or was descriptive;
(iv) Even if it were to be held that others interested in opposing the registration of
such a trademark were not vigilant, it is primarily the duty of the Registrar of
Trademarks to ensure that the trademarks which are not distinctive and which are
devoid of any distinctive character are not registered; the factum of the Registrar of
Trademarks in India and in US, at neither of the aforesaid times having raised any
such objection, will have weightage at least at this stage of grant of interim relief, to
hold that the said marks are prima facie not considered by the authorities having
expertise in the matter as being descriptive of the said goods and being incapable of
distinguishing such goods of one from another;
......"Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

45. I may also note that an SLP filed against the aforesaid judgment of the Division Bench was
dismissed by the Supreme Court on 03.02.2014. The aforesaid judgment, in my opinion, squarely
applies to the facts of this case. The pleas of the defendants that the trade mark NEWS HOUR is
descriptive and incapable of being registered are pleas which did not find favour when the plaintiff
had applied for registration of the trade mark. There were no objections received on the ground of
applicability of Section 9 of the Act. The marks were not prima facie considered by the authorities
having expertise in the matter as being descriptive of the goods, etc. or incapable of distinguishing
the goods or services of one from another.
46. I also cannot help noticing that a plea has been raised by the defendants that they propose to
challenge the registration of the said trade mark by the Registry. No such challenge appears to have
been made so far. Clearly, there is prima facie no merit in the plea of the defendants that the mark in
question is generic and incapable of being protected as a trade mark.
47. Another plea that was raised by the defendants was that the defendants' mark is with addition of
prefixes and suffixes with NEWS HOUR and cannot be said to be deceptively similar to the alleged
mark of the plaintiff. The defendants seek to use combination of NEWS HOUR as ARNAB
GOSWAMI's NEWSHOUR, ARNAB GOSWAMI's NEWSHOUR 9, ARNAB GOSWAMI's
NEWSHOUR 10, ARNAB GOSWAMI's NEWSHOUR SUNDAY, etc. In this context reference may be
had to the judgment of the Supreme Court in the case of Kaviraj Pandit Durga Dutt Sharma vs.
Navaratna Pharmaceutical Laboratories, (supra) where the Supreme Court held as follows:-
"28. The other ground of objection that the findings are inconsistent really proceeds
on an error in appreciating the basic differences between the causes of action and
right to relief in suits for passing off and for infringement of a registered trade mark
and in equating the essentials of a passing off action with those in respect of an action
complaining of an infringement of a registered trade mark. We have already pointed
out that the suit by the respondent complained both of an invasion of a statutory
right under Section 21 in respect of a registered trade mark and also of a passing off
by the use of the same mark. The finding in favour of the appellant to which the
learned counsel drew our attention was based upon dissimilarity of the packing in
which the goods of the two parties were vended, the difference in the physical
appearance of the two packets by reason of the variation in the colour and other
features and their general get-up together with the circumstance that the name and
address of the manufactory of the appellant was prominently displayed on his
packets and these features were all set out for negativing the respondent's claim that
the appellant had passed off his goods as those of the respondent. These matters
which are of the essence of the cause of action for relief on the ground of passing off
play but a limited role in an action for infringement of a registered trade mark by the
registered proprietor who has a statutory right to that mark and who has a statutory
remedy for the event of the use by another of that mark or a colourable imitation
thereof. While an action for passing off is a Common Law remedy being in substance
an action for deceit, that is, a passing off by a person of his own goods as those of
another, that is not the gist of an action for infringement. The action for infringementBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

is a statutory remedy conferred on the registered proprietor of a registered trade
mark for the vindication of the exclusive right to the use of the trade mark in relation
to those goods" (Vide Section 21 of the Act). The use by the defendant of the trade
mark of the plaintiff is not essential in an action for passing off, but is the sine qua
non in the case of an action for infringement. No doubt, where the evidence in respect
of passing off consists merely of the colourable use of a registered trade mark, the
essential features of both the actions might coincide in the sense that what would be a
colourable imitation of a trade mark in a passing off action would also be such in an
action for infringement of the same trade mark. But there the correspondence
between the two ceases. In an action for infringement, the plaintiff must, no doubt,
make out that the use of the defendant's mark is likely to deceive, but where the
similarity between the plaintiff's and the defendant's mark is so close either visually,
phonetically or otherwise and the court reaches the conclusion that there is an
imitation, no further evidence is required to establish that the plaintiff's rights are
violated. Expressed in another way, if the essential features of the trade mark of the
plaintiff have been adopted by the defendant, the fact that the get-up, packing and
other writing or marks on the goods or on the packets in which he offers his goods for
sale show marked differences, or indicate clearly a trade origin different from that of
the registered proprietor of the mark would be immaterial; whereas in the case of
passing off, the defendant may escape liability if he can show that the added matter is
sufficient to distinguish his goods from those of the plaintiff."
48. Reference may also be had to the judgment of the Supreme Court in the case of Ruston &
Hornsby Ltd. Vs. Zamindara Engineering Co., AIR 1970 SC 1649 where the Court held as follows:-
"8. In the present case the High Court has found that there is a deceptive
resemblance between the word "RUSTON" and the word "RUSTAM" and therefore
the use of the bare word "RUSTAM" constituted infringement of the plaintiff's trade
mark "RUSTON". The respondent has not brought an appeal against the judgment of
the High Court on this point and it is, therefore, not open to him to challenge that
finding. If the respondent's trade mark is deceptively similar to that of the appellant
the fact that the word "INDIA" is added to the respondent's trade mark is of no
consequence and the appellant is entitled to succeed in its action for infringement of
its trade mark."
49. What follows from the above judgments is that if the defendants' trade mark is deceptively
similar to that of the plaintiff, mere addition of a word by the defendants to the trade mark is of no
consequence and the plaintiff is entitled to succeed in its action for infringement of its trade mark.
50. In the facts of this case, in my view, merely adding some prefixes or suffixes to the trade mark
NEWS HOUR, in my opinion does not help the defendants to claim that the mark which is being
used by the defendants is not deceptively similar to that of the plaintiff.Bennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

51. The marks which are being used by the defendants, namely, ARNAB GOSWAMI's NEWSHOUR,
ARNAB GOSWAMI's NEWSHOUR 9, etc. prima facie would be deceptively similar to the mark of
the plaintiff THE NEWS HOUR. The plaintiff is entitled to relief on this account.
52. I will now deal with the second relief sought in the present application, namely, to restrain the
defendants from adopting the trade mark/title/tagline 'NATION WANTS TO KNOW'. It is the case
of the plaintiff that the trade mark/tagline 'NATION WANTS TO KNOW' (NWTK) is based on
distinctiveness, goodwill and reputation of the plaintiff on account of its use since 2006 for
goods/services in relation to television broadcast. It is pleaded that in case the defendants are
permitted to use the trade mark/tagline NWTK, it would create confusion and deception. It is
further the case of the plaintiff that as per the employment contract signed between the plaintiff and
defendant No2, all intellectual property created, developed and used by defendant No. 2 in or on the
channel including in relation to the programme exclusively belongs to the plaintiff. It is stated that
defendant No. 2 cannot claim any right on NWTK.
53. On the other hand, the defendants plead that NWTK is not a registered tagline or mark of the
plaintiff. Hence, the plaintiff has to, at best, make out a case for passing off. It is pleaded that the
plaintiff has failed to show any goodwill in the stated tagline/mark NWTK. It is further stated that
there is no misrepresentation by the defendants to its viewers which is calculated to injure the
plaintiff's business or goodwill. No case for passing off is hence made out. Further, the viewers of the
plaintiff and the defendant news channels are well informed and literate persons and can never get
confused between shows aired by the respective channels of the plaintiff and the defendants.
It is further pleaded that NWTK was a distinctive tool of news dispensation used by defendant No. 2.
It is a word of common speech and was not used as a tagline.
It is also stated that the said phrase has no connection to any goods/services/plaintiff's news
channel. The phrase was used only to pose questions during interviews.
NWTK has never been associated with the plaintiff. It is associated with defendant No. 2 and his
personality.
54. Reference in this context may be had to the judgment of the Supreme Court in the case of Cadila
Health Care Ltd. vs. Cadila Pharmaceuticals Ltd., 2001 (5) SCC 73. That was a case in which the
appellant had filed a suit seeking injunction against the respondent from using the trade mark
'Falcitab' as it was claimed that the same would be passed off as the appellant's drug 'Falcigo' for
treatment of the same disease. The Supreme Court held as follows:-
"10. Under Section 28 of the Trade and Merchandise Marks Act on the registration of
a trade mark in Part A or B of the register, a registered proprietor gets an exclusive
right to use the trade mark in relation to the goods in respect of which the trade mark
is registered and to obtain relief in respect of infringement of the trade mark in the
manner provided by the Act. In the case of an unregistered trade mark, Section 27(1)
provides that no person shall be entitled to institute any proceeding to prevent, or toBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

recover damages for, the infringement of an unregistered trade mark. Sub-section (2)
of Section 27 provides that the Act shall not be deemed to affect rights of action
against any person for passing off goods as the goods of another person or the
remedies in respect thereof. In other words in the case of unregistered trade marks, a
passing-off action is maintainable. The passing-off action depends upon the principle
that nobody has a right to represent his goods as the goods of somebody. In other
words a man is not to sell his goods or services under the pretence that they are those
of another person. As per Lord Diplock in Erven Warnink BV v. J. Townend & Sons
[(1979) 2 All ER 927] the modern tort of passing off has five elements i.e. (1) a
misrepresentation, (2) made by a trader in the course of trade, (3) to prospective
customers of his or ultimate consumers of goods or services supplied by him, (4)
which is calculated to injure the business or goodwill of another trader (in the sense
that this is a reasonably foreseeable consequence), and (5) which causes actual
damage to a business or goodwill of the trader by whom the action is brought or (in a
quia timet action) will probably do so."
Hence, the court concluded that a passing off action depends upon the principle that nobody has a
right to represent his goods as goods of somebody else. The court noted five elements of passing off,
namely, (i) misrepresentations, (ii) to prospective customers, (iii) made by a trader, (iv) which are
calculated to injure the business and goodwill of another trader and (v) which causes actual damage
to the business or goodwill of the trader by whom the action is brought.
55. I may also reiterate the observations of the Supreme Court in the case of Kaviraj Pandit Durga
Dutt Sharma vs. Navaratna Pharmaceutical Laboratories (supra), as noted above where the
Supreme Court had noted that passing off is a common law remedy being in substance an action for
deceit i.e. that is a passing off by a person of his own goods as those of another.
56. Hence, the issue that arises is that do the defendants by use of the mark/tagline NWTK seek to
misrepresent to prospective customers of news channels which misrepresentation would cause
damage to the business and goodwill of the plaintiff. Both the sides have filed large number of
documents relying upon various print outs and screenshots, etc. of facebook, twitter and of various
search engines like google to plead that the tagline/trade mark NWTK is associated with the
respective parties only.
57. The plaintiff claims that it has been using the tagline/trade mark NWTK since 2006 for
goods/services in relation to television broadcast. It has acquired goodwill and reputation due to the
time effort, financial and human resources expanded by the plaintiff. Reliance is placed on various
documents to support its aforesaid contention of user since 2006. The plaintiff has filed print outs of
screenshots of facebook from 20013 to 2017, screenshots from various online platforms including
twitter, facebook and youtube claiming use of NWTK. Reliance is also placed on some news
reports/articles allegedly showing goodwill and reputation of the plaintiff on the trade mark NWTK.
Based on these documents, it is urged that the plaintiff has a strong reputation and goodwill for the
tagline NWTK in news dispensation/news channel to warrant an interim order in favour of the
plaintiff. In my opinion both sides seek to reply on screen shots from various search engines. TheBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

screen shots/other documents placed on record require a more detailed examination which can only
be done after parties have led evidence.
58. There is another reason as to why, in my opinion, the above documents require a detailed
examination after evidence is lead by the parties. The plaintiff has applied for registration of the said
tagline NWTK in Class 38 and 41 on 17.12.2016. The application when it was filed was filed on
"proposed to be used" basis. Hence, it was the own case of the plaintiff at the time of the filing of the
application for registration of the said tagline that the plaintiff is yet to commence user of the same
as a trade mark. No doubt, the plaintiff has later on filed an amendment application claiming that
the said user stated in the original application was on account of inadvertence and oversight. The
plaintiff now claims user since 31.01.2006. The defendants have strongly relied upon the original
application to claim that it was the own case of the plaintiff that the said tagline NWTK is "proposed
to be used" in 2016 and there was no prior user. They have objected to the amendment application
filed by the plaintiff. In my opinion, for the purpose of deciding the present application, the conduct
of the plaintiff in filing the application in the Trade Mark Registry stating the user as "proposed to
be used" has relevance. These are issues which would have to be gone into after the parties have led
their evidence. The date of user of the tagline NWTK can only be decided appropriately after the
parties have led their evidence. Based on these documents/screen shots of twitter and other posts,
etc., a prima facie case is not made out In these facts and circumstances, prima facie it is not
possible, at this stage without leading of evidence, to come to a conclusion that the defendants seek
to mislead the consumers of the news channel or that the action of the defendants in using the said
tagline would cause damage to the plaintiff as claimed
59. Another plea strongly urged by the plaintiff relying upon the employment agreements is that the
said trademarks/tagline is the proprietary right of the plaintiff. Reliance is placed on Clause 5 of the
employment agreement dated 31.05.2004 and Clause 4 of the employment agreement dated
31.03.2005 which state that all intellectual property rights relating to the work done or created by
defendant No.2, etc in the course of the contract with the plaintiff company shall solely and
exclusively belong to the Company i.e. the plaintiff. Clause 4 of the agreement dated 31.03.2005
read as follows:-
"4. That all intellectual property rights relating to the work done or created by you
including all literary, dramatic or artistic work done in the course of your contract
with the company solely and exclusively to the company in perpetuity and the
company shall have the sole and exclusive right to utilize any such material including
text, photographs, illustrations, graphics, film, articles, stories, features, cartoons,
books, audio video, logos, brand names, other items, etc. created, written, made by
you. The right in these works that are created, written or made shall continue to vest
with the company even after the termination/discontinuation or end of the contract
period."
60. The defendants have however denied the stand of the plaintiff. It has been stated that the tagline
was never pre-planned/scripted. It was used as a word of common speech for which there is no
intellectual property which enures to the plaintiff. It has been denied that it was the result of anyBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

significant creative effort with respect to the formatting of the plaintiff's show.
61. Whether NWTK was used as a trade mark, as claimed by the plaintiff is an aspect that is
appropriately to be gone into after evidence is completed between the parties.
62. A plea strongly urged by the defendants is that the tagline in question was used as a common
speech for which there is no intellectual property which enures to the plaintiff. It was spontaneous
and creative expression used by defendant No. 2 which was not used as a trade mark. It has also
been pleaded by the defendants that none of the documents adduced by the plaintiff indicate a
connection of the mark NWTK to any goods or services or to the plaintiff's news channel.
63. I may note that learned counsel for the plaintiff on the last date of hearing on 01.10.2020 had
clarified that they have no objection in case defendant No. 2 were to use the said phrase NWTK in
the course of speech or presentation of a programme. The grievance of the plaintiff is the fact that
the defendants have also applied for registration of the same as a tagline/trademark with the Trade
Mark Registry which is not permissible. It was also stated by the learned counsel for the plaintiff
that the application of the defendants for the registration of the said tagline with the Trade Mark
Registry has been rejected.
64. In my opinion, it is only after evidence has been led that it can be ascertained as to whether the
plaintiff was using the aforesaid mark as a trade mark or it was merely being used as a form of
speech in the course of conducting the news channel or in the course of carrying on
interviews/presentations by defendant No. 2. These are aspects on which, prima facie, no view can
be made at this stage based on the documents placed on record, namely, screen shots of various sites
of Twitter, Facebook, etc.
65. In view of the above, I partly allow the present application. An interim injunction is passed in
favour of the plaintiff and against the defendants retraining them from using the trade mark 'NEWS
HOUR' or any other mark which is deceptively similar to the trade mark 'NEWS HOUR' of the
plaintiff.
66. Regarding the tagline NATION WANTS TO KNOW, no interim order is passed at this stage in
favour of the plaintiff. As submitted by the learned counsel for the plaintiff, defendant No. 2 is free
to use the same as part of his speech/presentation of any news channel, etc. However, if the
defendants choose to use the same as a trade mark with respect to any of their goods/services, the
said defendants will maintain accounts for such usage. Such accounts shall be filed in court regularly
on an affidavit of one of the directors of defendant No. 3 once in every six months.
67. The application is disposed of with the above directions.
JAYANT NATH, J OCTOBER 23, 2020 rbBennett Coleman & Co. Ltd. vs Arg Outlier Media Pvt Ltd & Ors. on 23 October, 2020

