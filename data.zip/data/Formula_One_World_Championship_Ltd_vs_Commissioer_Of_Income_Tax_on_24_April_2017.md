Formula One World Championship Ltd vs Commissioer Of
Income Tax, ... on 24 April, 2017
Equivalent citations: AIR 2018 SC (SUPP) 556, 2017 (15) SCC 602, (2017) 4
MAD LJ 405, (2017) 5 SCALE 228
Author: A.K. Sikri
Bench: Ashok Bhushan, A.K. Sikri
                                                                              REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                        CIVIL APPELLATE JURISDICTION
                        CIVIL APPEAL NO. 3849 OF 2017
|FORMULA ONE WORLD CHAMPIONSHIP LTD.              |…..APPELLANT(S)       |
|                                                 |                      |
|                                                 |                      |
|VERSUS                                           |                      |
|                                                 |                      |
|COMMISSIONER OF INCOME TAX,                      |                      |
|INTERNATIONAL TAXATION – 3,                      |                      |
|DELHI & ANR.                                     |…..RESPONDENT(S)      |
                                   W I T H
                        CIVIL APPEAL NO. 3850 OF 2017
                                    A N D
                        CIVIL APPEAL NO. 3851 OF 2017
                               J U D G M E N T
A.K. SIKRI, J.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

INTRODUCTION These appeals are filed by Formula One World Championship Limited
(hereinafter referred to as 'FOWC'), Jaypee Sports International Limited (for short, 'Jaypee') and
Union of India (hereinafter referred to as the 'Revenue'). In all these appeals, challenge is laid to the
judgment dated November 30, 2016 passed by the High Court of Delhi whereby three writ petitions
preferred by FOWC, Jaypee and Revenue have been decided.
The matter originated from filing of applications by FOWC and Jaypee before the Authority for
Advance Ruling (AAR). FOWC had entered into a 'Race Promotion Contract' (RPC) dated
September 13, 2011 with Jaypee, granting Jaypee the right to host, stage and promote the Formula
One Grand Prix of India event for a consideration of US$ 40 million. Some other agreements were
also entered into between FOWC and Jaypee as well as group companies of FOWC and Jaypee,
particulars whereby would be mentioned later at an appropriate stage. In the applications filed by
FOWC and Jaypee before the AAR, advance ruling of AAR was solicited on two main
questions/queries:
whether the payment of consideration receivable by FOWC in terms of the said RPC
from Jaypee was or was not royalty as defined in Article 13 of the 'Double Taxation
Avoidance Agreement' (DTAA) entered into between the Government of United
Kingdom and the Republic of India?; and
(ii) whether FOWC was having any 'Permanent Establishment' (PE) in India in terms
of Article 5 of DTAA?
Another related question was also raised, viz.,
(iii)whether any part of the consideration received or receivable by FOWC from
Jaypee outside India was subject to tax at source under Section 195 of the Indian
Income Tax Act, 1961 (hereinafter after referred to as the 'Act').
AAR answered the first question holding that the consideration paid or payable by Jaypee to FOWC
amounted to ‘Royalty’ under the DTAA. Second question was answered in favour of FOWC holding
that it did not have any PE in India. As far as the question of subjecting the payments to tax at
source under Section 195 of the Act is concerned, AAR ruled that since the amount
received/receivable by FOWC was income in the nature of Royalty and it was liable to pay tax there
on to the Income Tax Department in India, it was incumbent upon Jaypee to deduct the tax at
source on the payments made to FOWC. FOWC and Jaypee challenged the ruling on the first issue
by filing writ petitions in the High Court contending that the payment would not constitute Royalty
under Article 13 of the DTAA. Revenue also filed the writ petition challenging the answer of the AAR
on the second issue by taking the stand that FOWC had PE in India in terms of Article 5 of the DTAA
and, therefore, tax was payable accordingly.
As mentioned above, all these three writ petitions have been decided by the High Court vide
common judgment dated November 30, 2016. Interestingly, the High Court has reversed the
findings of the AAR on both the issues. Whereas it has held that the amount paid/payable underFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

RPC by Jaypee to FOWC would not be treated as Royalty, as per the High Court FOWC had the PE
in India and, therefore, taxable in India. While deciding this question, the High Court has not
accepted the plea of the Revenue that it was not a dependent PE. The High Court has also held, as
the sequitur, that Jaypee is bound to make appropriate deductions from the amount payable to
FOWC under Section 195 of the Act. It is for this reason all the three parties are again before us.
As per FOWC and Jaypee, no tax is payable in India on the consideration paid under RPC as it is
neither Royalty nor FOWC has any PE in India. It is pertinent to mention that the Revenue has not
challenged the findings of the High Court that the amount paid under RPC does not constitute
royalty. Therefore, that aspect of the matter has attained finality. The main question in the appeals,
therefore, pertains to PE.
FACTUAL MATRIX In order to decide this question, following facts, having bearing on the matter,
need a recapitulation:
Federation Internationale de I' Automobile (for short, 'FIA'), a non-profit association,
is established as the Association Internationale des Automobile Clubs Reconnus to
represent the interests of motoring organizations and motor car users globally. FIA,
as the federation of the world’s leading motoring organizations and the governing
body for motorsports worldwide, consists of 213 national member organizations in
125 countries internationally. FIA is the principal body for establishing the rules and
regulations for all major international four-wheel motorsport events. FIA is a
regulatory body; it regulates the FIA Formula One World Championship
('Championship') which has been the premier form of motor racing since its
inception in 1950. This Championship is established and run every year subsequently
since. The Championship is an annual series of motor races, conducted in the name
and style of the Grand Prix over a three day duration at purpose-built circuits, and in
some cases, across public roads, in different countries around the world. The
Championship is considered the most prestigious motor sport series in the world.
'Formula One' (F-1) refers to the rules and regulations that define the characteristics
of the race, as opposed to any other form of motor race. Thus, 'the formula', is with
reference to a set of rules that all participants’ cars must conform to. F-1 seasons
consist of a series of races, known as Grand Prix (from French, meaning grand
prizes), held across the world on specially designed and built F-1 circuits across 26
different locales.
F-1 Grand Prix events are held under the aegis of the FIA Formula One World
Championship’s competition – in which F-1 racing cars, assembled and
manufactured strictly in terms of the F-1 technical regulations, compete against each
other, under F1 Sporting Regulations and the F-1 International Sporting Code framed
and made effective by the FIA. F-1 drivers across the world have the ability,
competence and skill to drive an F-1 car and participate in F-1 racing events. About 12
to 15 teams typically compete in these Championship in any one annual racing
season. Some celebrated and well-known participating teams are the Ferrari,Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

McLaren, Red Bull etc. The teams assemble and construct their vehicles, which
comply with defined technical specifications, and engage drivers who can successfully
manoeuvre the F-1 cars in the racing events.
FOWC is incorporated under the laws of the United Kingdom, and is a tax resident of
the United Kingdom. It is the Commercial Rights Holder (CRH) in respect of the
Championship with effect from January 01, 2011. FOWC has entered into an
agreement with the FIA and Formula One Asset Management Limited (‘FOAM’).
Under these agreements, FOAM licensed all commercial rights in the FIA Formula
One World Championship (hereinafter referred to as ‘F1 Championship’) to FOWC
for 100 year term effective from January 01, 2011. As mentioned above, the teams
which participate in F1 World Championship Competitions have to strictly comply
with the terms and conditions set out for such competitions as per Sporting
Regulations and Sporting Code. For this purpose, all these teams, known as
‘Constructors’, enter into a contract, known as the 'Concorde Agreement', with FOWC
and the FIA. In these agreements, they undertake to participate to the best of their
ability, in every F-1 event included in the official annual F-1 racing calendar. They
also bind themselves to an unequivocal negative covenant with FOWC that they
would not participate in any other similar motor racing event whatsoever nor would
they promote in any manner any other rival event. The F-1 racing teams exclusively
participate in about 19 to 21 listed F-1 annual racing events on the official racing
calendar, set by the FIA. This is, in effect, a closed circuit event since no team other
than those bound by contract with FOWC are permitted participation.
Thus, on the one hand, participating teams enter into Concorde Agreement. Likewise, promoters are
also chosen for holding these F-1 racing events. Every F-1 racing event is hosted, promoted and
staged by a promoter with whom FOWC as the right holder, enters into contract and whose event is
nominated by the CRH (i.e. Commercial Right Holder, which is in effect, FOWC) to the FIA for
inclusion in the official F-1 racing calendar. In other words, FOWC is the exclusive nominating body
at whose instance the event promoter is permitted participation. The points scored by each F- 1
racing team in every event is listed in the official racing calendar and it counts towards the
Constructor's Championship and the Driver’s Championship for the racing season as a whole. Any
team’s position in these Championships at the end of the season determines, together with certain
other factors which are elaborately dealt with in the Concorde Agreements (which in the present
instance, was latest in the series of Concorde Agreements the last being the one of 2009 i.e. August
05, 2009), the prize money payable to the teams for their participation during the season. Grant of a
right to host, stage and promote the F-1 racing event, therefore, carries with it a covenant or
representation that F-1 racing teams with their cars, drivers and other auxiliary and supporting staff
will participate in the motor racing event hosted at the promoter’s motor racing circuit displaying
the highest levels of technical skill achievement etc. in the fields of construction of single seat
motorcars to attain the highest levels of performance in the world. These teams and the FOWC also
represent that the highest levels of skill in racing management and maintenance of the cars would
be on display in the event. All these are a part of the relevant contractual provisions, embodied in
RPC 2011. In this manner, FOWC has acquired all commercial rights in respect of the F-1Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

Championship wherever such tournaments take place, i.e. with the permission of FOWC.
Jaypee was interested to acquire this right for hosting, staging and promoting the F-1 Grand Prix of
India event. In order to do so, it entered into agreement with FOWC dated September 13, 2011
which is known as ‘Race Promotion Contract’ (RPC). By this agreement, FOWC granted Jaypee the
right to host, stage and promote F-1 Grand Prix of India event for a consideration of US$ 40
millions. Another agreement known as ‘Artwork License Agreement’ (‘ALA’) was entered into
between FOWC and Jaypee on the same day whereby FOWC permitted Jaypee to use certain marks
and intellectual property belonging to FOWC for a consideration of US$ 1 million. Prior to this RPC
of 2011, another RPC of October 25, 2007 had been entered into between FOA and Jaypee which
was replaced by agreement dated September 13, 2011 between FOWC and Jaypee. Pursuant thereto,
races were held in India in 2011, 2012 and 2013.
After entering into the aforesaid arrangement for hosting F-1 Grand Prix in India, both FOWC and
Jaypee approached AAR seeking its advance ruling on the two questions, the nature of which,
including the opinion of AAR thereupon, is already mentioned above.
As pointed out earlier, first question was as to whether considerations received/receivable under the
RPC by FOWC from Jaypee Sports was in the nature of business income and ‘Royalty’ as defined
under the Act as well as DTAA. Plea of FOWC and Jaypee was that what was granted to Jaypee by
FOWC was a commercial right to use the event, i.e., a hosting right and the consideration
received/receivable therefrom by FOWC was not for the use of trademark, copyright, equipment etc.
and hence was not in the nature of ‘Royalty’. It was also stated by them that there was a limited
permitted use of Formula One (‘F-1’) Mark which was only to enable the promoter (Jaypee) to
advertise the Indian Grand Prix and reproduction of names of the sports events was routine and
customary in business parlance. For this purpose, ALA was executed to enable Jaypee to use F-1
Marks in a limited way and to prevent it from using the Marks for any commercial exploitation.
Revenue had opposed the aforesaid plea of FOWC and Jaypee on the ground that the consideration
comprised not only of hosting rights but also permission to use F-1 Marks and, therefore, entire
consideration of US$ 40 million was attributable to the usage of F-1 Marks in terms of ALA.
According to the Revenue, RPC and ALA had to be read together for a comprehensive view of the
matter, particularly, whey they were executed on the same day.
The AAR accepted the argument of the Revenue holding that the consideration received by FOWC
amounted to royalty and was to be, accordingly, taxed under the Indian Income Act. However, this
view is reversed by the High Court by the impugned judgment after detailed discussion on this issue
and in the opinion of the High Court the consideration received under the Agreement cannot be
termed as royalty. As mentioned above, Revenue has accepted the judgment of the High Court on
this issue and, therefore, it is not necessary to discuss in detail the reasons given by the High Court
for coming to the aforesaid conclusion. This fact is mentioned only for the sake of completeness of
the issues raised and their outcome.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

The bone of contention before this Court pertains to the issue of existence of a PE of FOWC in India.
We may say at the outset that the arguments advanced by both the parties before us were virtually
the same arguments which were advanced before the High Court as well. Therefore, spelling out the
submissions of the parties before the High Court may not be necessary as it would be duplicating
and repetitive. At this stage, we would, therefore, record the arguments which were presented before
us and in the process mention the basis of the conclusion arrived at by the High Court for the
purpose of forming an opinion as to whether the view of the High Court is correct and justified in
law.
RELEVANT STATUTORY PROVISIONS & DTAA REGIME Before adverting to the question at
hand, it would be appropriate to take note of the scheme of the Act as well as relevant provisions of
DTAA on this subject. The Act provides two modes of taxation, namely, resident based and source
based. Any person who is a resident of India is subjected to the Act and liable to pay income tax on
the ‘total income’ earned by such a resident, after getting various deductions therefrom as
admissible under different provisions of the Act. Charging section is Section 4 which, inter alia,
stipulates that income tax shall be charged for any Assessment Year in respect of total income of the
previous year of every of such person. Section 5 contains the scope of total income of a resident and
includes all income from whatever source derived by a person who is resident which is received or
deemed to be received in India, accrues or arises or is deemed to accrue or arise to him in India or
accrues or arises to him outside India during such year. Thus, a resident is supposed to pay income
tax on all incomes so earned whether in India or outside India.
On the other hand, those persons who are not ordinarily residents of India (which term is defined
under sub-section (6) of Section 6) are not liable to pay income tax on any income which accrues or
arises to such non- resident outside India. However, in the case of non-resident persons, if the
income is derived from a business controlled in or a profession set up in India, these non-residents
are subjected to pay tax for such an income earned in India. In their case, all such incomes from
whatever source derived which is received or is deemed to be received in India in such a year by or
on behalf of such person or accrues or arises or is deemed to accrue or arise to them in India during
that year, is taxable in India. In this sense, the income tax on non-resident is source based, i.e.,
source of such income is India and, therefore, even a non-resident is liable to pay tax on incomes
earned in India. ‘Resident in India’ and ‘Not-ordinarily Resident in India’ are covered by the
provisions contained in Section 6.
In the present case, we are concerned with the consideration received by FOWC as a result of
Agreement signed with Jaypee Sports. FOWC, being a UK Company, is admittedly the non-resident
in India. Since the question is whether the aforesaid consideration/income earned by FOWC is
subject to tax in India or not, it is to be decided as to whether that income accrued or arose in India.
For this purpose, relevant provision is Section 9 of the Act. This section contains varied situations
where income is deemed to accrue or arise in India and it is not necessary to spell out each of such
contingencies. Insofar as income by way of royalty earned by a non- resident is concerned, that is
mentioned in clause (vi) of Section 9(1) of the Act. As the consideration of US$ 40 million received
by FOWC from Jaypee is held as ‘no income by way of royalty’, we may conveniently skip that
provision.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

Clause (i) of sub-section (1) of Section 9 of the Act mentions certain kinds of income which are
deemed to accrue or arise in India. This clause is reproduced below:
“(i) all income accruing or arising, whether directly or indirectly, through or from any
business connection in India, or through or from any property in India, or through or
from any asset or source of income in India, or through the transfer of a capital asset
situate in India:” It is clear from the reading of the said clause that it includes all
those incomes, whether directly or indirectly, which are accruing or arising through
or from any business connection in India. It is, thus, clear that an income which is
earned directly or indirectly, i.e. even indirectly, is to be deemed to accrue or earned
in India. Further, such an income should have some business connection in India.
Explanation (1) for the purpose of this clause provides five explanations from clauses
(a) to (e). Clause (a) stipulates that where all the business operations are not carried
in India and only some such operations of business are carried in India, the income of
the business deemed under this clause to accrue or arise in India shall be only such
part of the income as is reasonably attributable to the operations carried in India. We
are not concerned with clauses (b) to (e). Explanation (2) provides certain exceptions
in respect of ‘business connection’ and reads as under:
“Explanation 2. – For the removal of doubts, it is hereby declared that “business
connection” shall include any business activity carried out through a person who,
acting on behalf of the non-resident, – has and habitually exercises in India, an
authority to conclude contracts on behalf of the non-resident, unless his activities are
limited to the purchase of gods or merchandise for the non-resident; or has no such
authority, but habitually maintains in India a stock of gods or merchandise from
which he regularly delivers goods or merchandise on behalf of the non-resident; or
habitually secures orders in India, mainly or wholly for the non- resident or for that
non-resident and other non-residents controlling, controlled by, or subject to the
same common control, as that non-resident:
Provided that such business connection shall not include any business activity carried
out through a broker, general commission agent or any other agent having an
independent status, if such broker, general commission agent or any other agent
having an independent status is acting in the ordinary course of his business:
Provided further that where such broker, general commission agent or any other
agent works mainly or wholly on behalf of a non-resident (hereafter in this proviso
referred to as the principal non-resident) or on behalf of such non-resident and other
non-residents which are controlled by the principal non-resident or have a
controlling interest in the principal non- resident or are subject to the same common
control as the principal non- resident, he shall not be deemed to be a broker, general
commission agent or an agent of an independent status.” This exception, thus,
clarifies and declares that even when business activity is carried 'through' a person
who is acting on behalf of the non- resident (which means agent of the non-resident),Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

it will be treated that the non-resident is having business connection in India. The
meaning of the expression ‘through’ is again clarified in Explanation (4), which reads
as under:
“Explanation 4. – For the removal of doubts, it is hereby clarified that the expression
“through” shall mean and include and shall be deemed to have always meant and
included “by means of”, “in consequence of” or “by reason of”.” If a non-resident has
a PE in India, then business connection in India stands established. Section 92F of
the Act contains definitions of certain terms, though those definitions have relevance
for the purposes of computation of arms length price, etc. Clause (3) thereof defines
‘enterprise’ and such an enterprise includes a PE of a person. PE is defined in clause
(iiia) in the following manner:
“(iiia) “permanent establishment”, referred to in clause (iii), includes a fixed place of
business through which the business of the enterprise is wholly or partly carried on;”
At this juncture, we would also like to point out that Article 5 of DTAA between India
and United Kingdom lays down as to what would constitute a PE. It reads as under:
“ARTICLE 5 PERMANENT ESTABLISHMENT
1. For the purposes of this Convention, the term “permanent establishment” means a
fixed place of business through which the business of an enterprise is wholly or partly
carried on.
2. The term “permanent establishment” shall include especially:
a place of management;
a branch;
an office;
a factory;
a workshop;
premises used as a sales outlet or for receiving or soliciting orders;
a warehouse in relation to a person providing store facilities for others;
a mine, an oil or gas well, quarry on other place of extraction of natural resources;
an installation or structure used for the exploration or exploitation of natural
resources;Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

a building site or construction, installation or assembly project or supervisory
activities in connection therewith, where such site, project or supervisory activity
continues for a period of more than six months, or where such project or supervisory
activity, being incidental to the sale or machinery or equipment, continues for a
period not exceeding six months and the charges payable for the project or
supervisory activity exceed 10 per cent of the sale price of the machinery and
equipment;
the furnishing of services including managerial services, other than those taxable
under Article 13 (Royalties and fees for technical services), within a Contracting State
by an enterprise through employees or other personnel, but only if:
activities of that nature continue within that State for a period or periods aggregating
more than 90 days within any twelve-month period; or services are performed within
that State for an enterprise within the meaning of paragraph 1 of Article 10
(Associated enterprises) and continue for a period or periods aggregating more than
30 days within any twelve- month period;
Provided that for the purposes of this paragraph an enterprise shall be deemed to
have a permanent establishment in a Contracting State and to carry on business
through that permanent establishment if it provides services or facilities in
connection with, or supplies plant and machinery on hire used or to be used in, the
prospecting for, or extraction or production of mineral oils in that State.
3. The term “permanent establishment” shall not be deemed to include:
the use of facilities solely for the purpose of storage or display of gods or merchandise
belonging to the enterprise;
the maintenance of a stock of goods or merchandise belonging to the enterprise solely
for the purpose of storage or display;
the maintenance of a stock of goods or merchandise belonging to the enterprise solely
for the purpose of processing by another enterprise;
the maintenance of a fixed place of business solely for the purpose of purchasing
goods or merchandise, or for collecting information, for the enterprise;
the maintenance of a fixed place of business solely for the purpose of advertising, for
the supply of information or for scientific research, being activities solely of a
preparatory or auxiliary character in the trade of business of the enterprise. However,
this provision shall not be applicable where the enterprise maintains any other fixed
place of business in the other Contracting State for any purpose or purposes other
than the purposes specified in this paragraph;Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

the maintenance of a fixed place of businesses solely for any combination of activities
mentioned in sub-paragraphs (a) to (e) of the paragraph, provided that the overall
activity of the fixed place of business resulting from this combination is of a
preparatory or auxiliary character.
4. A person acting in a Contracting State for or on behalf of an enterprise of the other
contracting State – other than an agent of an independent status to whom paragraph
(5) of this Article applies, shall be deemed to be a permanent establishment of that
enterprise in the first mentioned State if:
he has, and habitually exercises in that State, an authority to negotiate and enter into
contracts for or on behalf of the enterprise, unless his activities are limited to the
purchase of gods or merchandise for the enterprise; or he habitually maintains in the
first-mentioned Contracting State a stock of gods or merchandise from which he
regularly delivers goods or merchandise for or on behalf of the enterprise; or he
habitually secures orders in the first-mentioned State, wholly or almost wholly for the
enterprise itself or for the enterprise and the enterprises controlling, controlled by, or
subject to the same common control, as that enterprise.
5. An enterprise of a Contracting State shall not be deemed to have a permanent
establishment in the other Contracting State merely because it carries on business in
that other State through a broker, general commission agent or any other agent of an
independent status, where such persons are acting in the ordinary course of their
business. However, if the activities of such an agent are carried out wholly or almost
wholly for the enterprise (or for the enterprise and other enterprises which are
controlled by it or have a controlling interest in it or are subject to same common
control) he shall not be considered to be an agent of an independent status for the
purposes of this paragraph.
6. The fact that a company which is a resident of a Contracting State controls or is
controlled by a company which is a resident of the other Contracting State, or which
carries on business in that other State (whether through a permanent establishment
or otherwise), shall not of itself constitute either company a permanent
establishment of the other.
7. For the purposes of this Article the term “control”, in relation to a company, means
the ability to exercise control over the company’s affairs by means of the direct or
indirect holding of the greater part of the issued share capital or voting power in the
company.” As per sub-clause (1) of Article 5, a fixed place of business through which
the business of an enterprise is wholly or partly carried on, is known as ‘permanent
establishment’. It requires that there has to be a fixed place of business. It also
requires that from such a place business of an enterprise (FOWC in the instant case)
is carried on, whether wholly or partly. Sub-clause (2) gives the illustrations of
certain places which will be treated as PEs. Likewise, sub-clause (3) excludes certainFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

kinds of places from the term PE. Sub-clause (4) enumerates the circumstances
under which a person is to be treated as acting on behalf of non-resident enterprise.
Likewise, sub-clause (5) excludes certain kinds of agents of enterprise, namely,
broker, general commission agent or agent of an independent status, by clarifying
that if the business is carried on through these persons, the enterprise shall not be
deemed to be a PE.
However, one exception thereto is carved out, namely, if the activities of such an agent are carried
out wholly or almost wholly for the enterprise, or for the enterprise and other enterprises which are
controlled by it or have a controlling interest in it or are subject to same common control, then, such
an agent will be treated as an agent of an independent status. It means that if the business is carried
out with such a kind of agent, the enterprise will be deemed to have a PE in India.
THE LEGAL COMMENTARIES AND CASE LAW It is an undisputed fact that Article 5 of DTAA
between India and the United Kingdom follows the Organisation for Economic Cooperation and
Development’s (OECD) Model of Double Taxation Convention. There are various commentaries on
Double Taxation Conventions. Celebrated among those are: “A Manual on the OECD Model Tax
Convention on Income and on Capital” by Philip Baker Q.C., and Klaus Vogel on "Double Taxation
Conventions". OECD has also given its ‘condensed version’ on "Model Tax Convention on Income
and on Capital". What constitutes PE under various circumstances has also been the subject matter
of judicial verdicts in India as well as in other countries. For better understanding of what may
constitute a PE, it would be imperative to refer to these commentaries and judicial decisions. This
discussion would disclose the principles enunciated to determine the existence of a PE, application
whereof to the given facts would facilitate in answering the surging debate.
Philip Baker explains that the concept of PE is important for several Articles of the Conventions; the
concept, or its cognate, also appears in the domestic law of some countries. According to him, the
concept marks the dividing line for businesses between merely trading with a country and trading in
that country; if an enterprise has a PE, its presence in a country is sufficiently substantial that it is
trading in the country. He has quoted the following passage from the judgment of the Andhra
Pradesh High Court, authored by Justice (Retd.) Jagannadha Rao (as His Lordship’s then was, later
Judge of this Court) in Commissioner of Income Tax, A.P.-I v. Visakhapatnam Port Trust[1]:
“The words ‘permanent establishment’ postulate the existence of a substantial
element of an enduring or permanent nature of a foreign enterprise in another
country which can be attributed to a fixed place of business in that country. It should
be of such a nature that it would amount to a virtual projection of the foreign
enterprise of one country into the soil of another country.” Emphasising that as a
creature of international tax law, the concept of PE has a particularly strong claim to
a uniform international meaning, Philip Baker discerns two types of PEs
contemplated under Article 5 of OECD Model. First, an establishment which is part
of the same enterprise under common ownership and control – an office, branch,
etc., to which he gives his own description as an ‘associated permanent
establishment’. The second type is an agent, though legally separate from theFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

enterprise, nevertheless who is dependent on the enterprise to the point of forming a
PE. Such PE is given the nomenclature of ‘unassociated permanent establishment’ by
Baker. He, however, pointed out that there is a possibility of a third type of PE, i.e. a
construction or installation site may be regarded as PE under certain circumstances.
In the first type of PE, i.e. associated permanent establishments, primary
requirement is that there must be a fixed place of business through which the
business of an enterprise is wholly or partly carried on. It entails two requirements
which need to be fulfilled: (a) there must be a business of an enterprise of a
Contracting State (FOWC in the instant case); and (b) PE must be a fixed place of
business, i.e. a place which is at the disposal of the enterprise. It is universally
accepted that for ascertaining whether there is a fixed place or not, PE must have
three characteristics: stability, productivity and dependence. Further, fixed place of
business connotes existence of a physical location which is at the disposal of the
enterprise through which the business is carried on.
Some of the examples of fixed place of business given by Baker are the following: The
place of business must be fixed and permanent. Thus, a shed which had been rented
for thirteen years for storing and preparing hides was held to constitute a PE[2].
Similarly, a writer’s study has been held to constitute a PE[3]. A stand at a trade fair,
occupied regularly for three weeks a year, through which the enterprise obtained
contracts for a significant part of its annual sales, has also been held to constitute a
PE[4]. A temporary restaurant operated in a mirror tent at a Dutch flower show for a
period of seven months was held to constitute a PE[5]. An office, workshop and
storeroom for the maintenance of aircraft, which were leased out by the enterprise,
has been held to constitute a PE[6].
On the other hand, possession of a mailing address in a state – without an office,
telephone listing or bank account – has been held not to constitute a PE[7]. The mere
supply of skilled labour to work in a country did not give rise to a PE of the company
supplying the labour[8]. A drilling rig which, although anchored while in operation,
was moved to a new site every few months, has been held not to constitute a PE[9].
Similarly, a remotely operated vessel which was used to inspect and repair submarine
pipelines was held not to constitute a PE because a moving vessel is not a fixed place
of business[10].
The principal test, in order to ascertain as to whether an establishment has a fixed
place of business or not, is that such physically located premises have to be ‘at the
disposal’ of the enterprise. For this purpose, it is not necessary that the premises are
owned or even rented by the enterprise. It will be sufficient if the premises are put at
the disposal of the enterprise. However, merely giving access to such a place to the
enterprise for the purposes of the project would not suffice. The place would be
treated as ‘at the disposal’ of the enterprise when the enterprise has right to use the
said place and has control thereupon.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

Some of the illustrative cases decided by courts of different jurisdictions given by
Baker in his commentary are contained in the following passages from that book:
In the Canadian case of William Dudney v. R[11], the taxpayer was a resident of the
United States who was contracted to supply training to employees of a Canadian
company. For the purposes of the training contract, the taxpayer was given various
offices at the premises of the Canadian company, which he was only allowed to enter
at normal office hours. He was allowed to use the client’s telephone only on client’s
business. He spent 300 days in one tax year and 40 in the subsequent year at the
premises. The Tax Court of Canada and the Federal Court of Appeal confirmed that
he had no fixed base – which was treated as having the same meaning as PE – at the
premises since he had no right to use the premises as the base for the operation of his
own business.
In a case generally referred to as Hotel Manager[12], the Bundesfinanzhof held that a
UK hotel management company had a PE in Germany when it entered into a 20 year
contract with a limited partnership which owned a hotel. The agreement required the
UK company to supply a general manager: the general manager’s office constituted
the PE (and not the entire hotel) since the UK company had a secured right to use
this office for the purposes of the agreement.
A Swiss company was held not to have a PE when it contracted with a German
company to produce salad dressings in the name of and in accordance with the recipe
of the Swiss company. No employees of the Swiss company were present at the
production facility to supervise production[13]. The Bundestinanzhof has also held
that a scene painter who was commissioned to carry out a work in France for six
weeks, and given special rooms for the purpose, did not have a fixed base at those
premises.
The Administrative Court of Appeal of Paris has held that a German travel agency did
not have a PE in France[14]. A travel agency in Paris had made an office available to
the German company from time to time, and the manager of the German company
had a flat in Paris; the Court held that the German company had no PE at its disposal
in France.
The Brussels Court of Appeal has held that a German resident engaged in the
transportation of vehicles had a PE in Belgium[15]. The taxpayer had an office 3m by
6m at his disposal on the premises of his principal supplier in Belgium, together with
telephone and telex, where the taxpayer and four of his staff worked.
According to Philip Baker, the aforesaid illustrations confirm that the fixed place of
business need not be owned or leased by the foreign enterprise, provided that is at
the disposal of the enterprise in the sense of having some right to use the premises
for the purposes of its business and not solely for the purposes of the projectFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

undertaken on behalf of the owner of the premises.
Interpreting the OECD Article 5 pertaining to PE, Klaus Vogel has remarked that
insofar as the term ‘business’ is concerned, it is broad, vague and of little relevance
for the PE definition. According to him, the crucial element is the term ‘place’.
Importance of the term ‘place’ is explained by him in the following manner:
“In conjunction with the attribute ‘fixed’, the requirement of a place reflects the
strong link between the land and the taxing powers of the State. This territorial link
serves as the basis not only for the distributive rules which are tied to the existence of
PE but also for a considerable number of other distributive rules and, above all, for
the assignment of a person to either Contracting State on the basis of residence
(Article 1, read in conjunction with Article 4 OECD and UN MC).” We would also like
to extract below the definition to the expression ‘place’ by Vogel, which is as under:
“A place is a certain amount of space within the soil or on the soil. This
understanding of place as a three-dimensional zone rather than a single point on the
earth can be derived from the French Version (‘installation fixe’) as well as the term
‘establishment’. As a rule, this zone is based on a certain area in, on, or above the
surface of the earth. Rooms or technical equipment above the soil may quality as a PE
only if they are fixed on the soil. This requirement, however, stems from the term
‘fixed’ rather than the term ‘place’, given that a place (or space) does not necessarily
consist of a piece of land. On the contrary, the term ‘establishment’ makes clear that
it is not the soil as such which is the PE but that the PE is constituted by a tangible
facility as distinct from the soil. This is particularly evident from the French version
of Article 5(1) OECD MC which uses the term ‘installation’ instead of ‘place’.
The term ‘place’ is used to define the term ‘establishment’. Therefore, ‘place’ includes
all tangible assets used for carrying on the business, but one such tangible asset can
be sufficient. The characterization of such assets under private law as real property
rather than personal property (in common law countries) or immovable rather than
movable property (in civil law countries) is not authoritative. It is rather the context
(including, above all, the terms ‘fixed’/’fixe’), as well as the object and purpose of
Article 5 OECD and UN MC itself, in the light of which the term ‘place’ needs to be
interpreted. This approach, which follows from the general rules on treaty
interpretation, gives a certain leeway for including movable property in the
understanding of ‘place’ and, therefore, the assume a PE once such property has been
‘fixed’ to the soil.
For example, a work bench in a caravan, restaurants on permanently anchored river
boats, steady oil rigs, or a transformator or generator on board a former railway
wagon qualify as places (and may also be ‘fixed’).Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

In contrast, purely intangible property cannot qualify in any case. In particular, rights
such a participations in a corporation, claims, bundles of claims (like bank accounts),
any other type of intangible property (patents, software, trademarks etc.) or
intangible economic assets (a regular clientele or the goodwill of an enterprise) do
not in themselves constitute a PE. They can only form part of PE constituted
otherwise. Likewise, an internet website (being a combination of software and other
electronic data) does not constitute tangible property and, therefore, does not
constitute a PE.
Neither does the mere incorporation of a company in a Contracting State in itself
constitute a PE of the company in that State. Where a company has its seat, according
to its by-laws and/or registration, in State A while the POEM is situated in State B,
this company will usually be liable to tax on the basis of its worldwide income in both
Contracting States under their respective domestic tax law. Under the A-B treaty,
however, the company will be regarded as a resident of State B only (Article 4(3)
OECD and UN MC). In the absence of both actual facilities and a dependent agent in
State A, income of this company will be taxable only in State B under the 1st sentence
of Article 7(1) OECD and UN MC.
There is no minimum size of the piece of land. Where the qualifying business
activities consist (in full or in part) of human activities by the taxpayer, his employees
or representatives, the mere space needed for the physical presence of these
individuals is not sufficient (if it were sufficient, Article 5(5) OECD MC and Article
5(5)(a) UN MC and the notion of agent PEs were superfluous). This can be illustrated
by the example of a salesman who regularly visits a major customer to take orders,
and conducts meetings in the purchasing director’s office. The OECD MC Comm. has
convincingly denied the existence of a PE, based on the implicit understanding that
the relevant geographical unit is not just the chair where the salesman sits, but the
entire office of the customer, and the office is not at the disposal of the enterprise for
which the salesman is working.” Taking cue from the word ‘through’ in the Article,
Vogel has also emphasised that the place of business qualifies only if the place is ‘at
the disposal’ of the enterprise. According to him, the enterprise will not be able to use
the place of business as an instrument for carrying on its business unless it controls
the place of business to a considerable extent. He hastens to add that there are no
absolute standards for the modalities and intensity of control. Rather, the standards
depend on the type of business activity at issue. According to him, ‘disposal’ is the
power (or a certain fraction thereof) to use the place of business directly. Some of the
instances given by Vogel in this behalf, of relative standards of control, are as under:
“The degree of control depends on the type of business activity that the taxpayer
carries on. It is therefore not necessary that the taxpayer is able to exclude others
from entering or using the POB.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

The painter example in the OECD MC Comm. (no. 4.5 OECD MC Comm. on Article
5) (however questionable it might be with regard to the functional integration test)
suggests that the type and extent of control need not exceed the level of what is
required for the specific type of activity which is determined by the concrete business.
By contrast, in the case of a self-employed engineer who had free access to his
customer’s premises to perform the services required by his contract, the Canadian
Federal Court of Appeal ruled that the engineer had no control because he had access
only during the customer’s regular office hours and was not entitled to carry on
businesses of his own on the premises.
Similarly, a Special Bench of Delhi’s Income Tax Appellate Tribunal denied the
existence of a PE in the case of Ericsson. The Tribunal held that it was not sufficient
that Ericsson’s employees had access to the premises of Indian mobile phone
providers to deliver the hardware, software and know-how required for operating a
network. By contrast, in the case of a competing enterprise, the Bench did assume an
Indian PE because the employees of that enterprise (unlike Ericsson’s) had exercised
other businesses of their employer.
The OECD view can hardly be reconciled with the two court cases. All three examples
do indeed shed some light onto the method how the relative standards for the control
threshold should be designed. While the OECD MC Comm. suggests that it is
sufficient to require not more than the type and extent of control necessary for the
specific business activity which the taxpayer wants to exercise in the source State, the
Canadian and Indian decisions advocate for stricter standards for the control
threshold.
The OECD MC shows a paramount tendency (though no strict rule) that PEs should
be treated like subsidiaries (cf. Article 24(3) OECD and UN MC), and that facilities of
a subsidiary would rarely been unusable outside the office hours of one of its
customers (i.e. a third person), the view of the two courts is still more convincing.
Along these lines, a POB will usually exist only where the taxpayer is free to use the
POB:
at any time of his own choice;
for work relating to more than one customer; and for his internal administrative and
bureaucratic work.
In all, the taxpayer will usually be regarded as controlling the POB only where he can
employ it at his discretion. This does not imply that the standards of the control test
should not be flexible and adaptive. Generally, the less invasive the activities are, and
the more they allow a parallel use of the same POB by other persons, the lower areFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

the requirements under the control test. There are, however, a number of traditional
PEs which by their nature require an exclusive use of the POB by only one taxpayer
and/or his personnel. A small workshop (cf. Article 5(2)(e) OECD and UN MC) of 10
or 12 square meters can hardly be used by more than one person. The same holds
true for a room where the taxpayer runs a noisy machine.” OECD commentary on
Model Tax Convention mentions that a general definition of the term ‘PE’ brings out
its essential characteristics, i.e. a distinct “situs”, a “fixed place of business”. This
definition, therefore, contains the following conditions:
the existence of a “place of business”, i.e. a facility such as premises or, in certain
instances, machinery or equipment.
this place of business must be “fixed”, i.e. it must be established at a distinct place
with a certain degree of permanence;
the carrying on of the business of the enterprise through this fixed place of business.
This means usually that persons who, in one way or another, are dependent on the
enterprise (personnel) conduct the business of the enterprise in the State in which
the fixed place is situated.
The term “place of business” is explained as covering any premises, facilities or
installations used for carrying on the business of the enterprise whether or not they
are used exclusively for that purpose. It is clarified that a place of business may also
exist where no premises are available or required for carrying on the business of the
enterprise and it simply has a certain amount of space at its disposal. Further, it is
immaterial whether the premises, facilities or installations are owned or rented by or
are otherwise at the disposal of the enterprise. A certain amount of space at the
disposal of the enterprise which is used for business activities is sufficient to
constitute a place of business. No formal legal right to use that place is required.
Thus, where an enterprise illegally occupies a certain location where it carries on its
business, that would also constitute a PE. Some of the examples where premises are
treated at the disposal of the enterprise and, therefore, constitute PE are: a place of
business may thus be constituted by a pitch in a market place, or by a certain
permanently used area in a customs depot (e.g. for the storage of dutiable goods).
Again the place of business may be situated in the business facilities of another
enterprise. This may be the case for instance where the foreign enterprise has at its
constant disposal certain premises or a part thereof owned by the other enterprise. At
the same time, it is also clarified that the mere presence of an enterprise at a
particular location does not necessarily mean that the location is at the disposal of
that enterprise.
The OECD commentary gives as many as four examples where location will not be
treated at the disposal of the enterprise. These are:Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

The first example is that of a salesman who regularly visits a major customer to take
orders and meets the purchasing director in his office to do so. In that case, the
customer's premises are not at the disposal of the enterprise for which the salesman
is working and therefore do not constitute a fixed place of business through which the
business of that enterprise is carried on (depending on the circumstances, however,
paragraph 5 could apply to deem a permanent establishment to exist). Second
example is that of an employee of a company who, for a long period of time, is
allowed to use an office in the headquarters of another company (e.g. a newly
acquired subsidiary) in order to ensure that the latter company complies with its
obligations under contracts concluded with the former company. In that case, the
employee is carrying on activities related to the business of the former company and
the office that is at his disposal at the headquarters of the other company will
constitute a permanent establishment of his employer, provided that the office is at
his disposal for a sufficiently long period of time so as to constitute a "fixed place of
business" (see paragraphs 6 to 6.3) and that the activities that are performed there go
beyond the activities referred to in paragraph 4 of the Article.
The third example is that of a road transportation enterprise which would use a delivery dock at a
customer's warehouse every day for a number of years for the purpose of delivering goods purchased
by that customer. In that case, the presence of the road transportation enterprise at the delivery
dock would be so limited that that enterprise could not consider that place as being at its disposal so
as to constitute a permanent establishment of that enterprise.
Fourth example is that of a painter, who, for two years, spends three days a week in the large office
building of its main client. In that case, the presence of the painter in that office building where he is
performing the most important functions of his business (i.e. painting) constitute a permanent
establishment of that painter.
It also states that the words ‘through which’ must be given a wide meaning so as to apply to any
situation where business activities are carried on at a particular location which is at the disposal of
the enterprise for that purpose. For this reason, an enterprise engaged in paving a road will be
considered to be carrying on its business ‘through’ the location where this activity takes place.
THE AGREEMENTS Having got a fair idea of what would constitute a PE, we may advert to the
discussion in that part of the impugned judgment where the High Court has given its reasons to
conclude that FOWC had a PE in India in the relevant Assessment Year. However, before that, it
would be necessary to refer to the salient provisions of the relevant agreements between the parties,
not only between FOWC and Jaypee, but some agreements which were entered into by the group
companies of FOWC with Jaypee.
We have already mentioned above that there is an Agreement between FIA and FOAM which is
dated April 24, 2001 whereby FIA has parted with the commercial rights in favour of FOAM making
FOAM exclusive CRH. Thereafter, vide the aforesaid agreement FOAM transferred the commercial
rights in favour of FOWC with effect from 2011 for a period of 10 years. Insofar as ConcordeFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

Agreement which is signed between FIA, FOWC and teams is concerned, that is of the year 2009.
It is relevant to mention that before RPC dated September 13, 2011 was entered into between FOWC
and Jaypee, one Organisation Agreement (OA) dated January 20, 2011 was signed between
FIA/FMSCI and Jaypee. As per this agreement, Jaypee was to organise the event. Thereafter,
another agreement known as ‘Title Sponsorship Agreement’ dated August 16, 2011 was signed
between Beta Prema 2 (an associated company of FOWC) and Bharti Airtel, as per which Beta
Prema 2 transferred title sponsorship rights to Bharti Airtel for US$ 8 million in respect of the race
which was conducted on October 29, 2011. It is thereafter that RPC dated September 13, 2011 was
signed by FOWC and Jaypee. That was one month before the scheduled date of race, which was
fixed as October 29, 2011. Under this agreement, right to host, stage and promote the event was
given to Jaypee by FOWC. As per the Revenue, FOWC carried on business in India through a fixed
place of business, namely, the Buddh International Circuit. Salient features of this Agreement,
which is the most vital document, are as follows:
"WHEREAS (A) The Federation Internationale de l’Automobile (FIA) is the
governing body of world motor sport. The FIA is responsible for the sporting
organization and regulation of the FIA Formula One World Championship (the
Championship), and has the right to supervise the sporting organization of individual
rounds of the Championship (B) Pursuant to various agreements between the FIA,
POWC and its Affiliates (as defined in Clause I(p) etc. FOWC has the exclusive right
to exploit the commercial rights in the Championship, including the exclusive right to
propose the Championship calendar and to award, to promoters the right to host,
stage and promote Formula One Grand Prix events that count towards the
Championship, exclusive media rights (including all use of audio-visual material and
data in the media space).
(C) FOWC has the exclusive right to enter into contracts solely for the hosting,
standing and promotion of Formula One Grand Prix events entered on the FIA
International Sporting Calendar and counting towards the Championship, it being
understood that such a contract will govern exclusively the commercial and financial
management of the Event (as defined in Clause 3.1 (xx not legible)).
(D) The Promoter is the owner of a motor racing circuit in the National Capital
Region of India which is capable of hosting various motor racing events. The
Promoter wishes to host various motor racing events at such circuit, to include the
hosting of Formula One Grand Prix events. The Promoter had secured the privilege to
host such events and is no executing this agreement with FOWC to set out the terms
and conditions on which it will host, stage and promote Formula One Grand Prix
events at such circuit.
XXXXXX XXXXXX XXXXXX Definitions and Interpretation
1. In this Agreement unless the context requires otherwise:Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

XXXXXX XXXXXX XXXXXX
(q) Circuit shall mean a motor racing circuit suitable in every respect for the staging
of the Event (including permanent buildings, permanent infrastructure, track layout,
amenities, spectator viewing facilities, the pit/paddock, building, media centre, car
parks, helipads, garages, race control and administration, office administration, fuel
and tyre storage, utilities (including back up power supplies), concrete based areas
suitable to host the Competitors and sponsors, vending and exhibition areas,
international TV compounds, host and broadcast facilities and medical centre);
XXXXXX XXXXXX XXXXXX
(t) Event shall mean the FORMULA 1 GRAND PRIX OF INDIA (including all support events therein
and peripheral entertainment), designated and endorsed as a round of the FIA Formula One World
Championship, which shall commence at the Circuit at the time scheduled by the FIA for
Scrutinizing and Sporting Checks and including all Practice and the Race itself and ending at the
later of the time for the lodging of a Protest under the terms of the Sporting Code and the time when
a technical or sporting verification has been carried out under the terms of the Sporting Code; and
XXXXXX XXXXXX XXXXXX Conditions Precedent 2.1 The grant of rights by FOWC to the
Promoter under this Agreement is conditional on the Conditions having been fulfilled or waived in
accordance with this Agreement and the Promoter shall use its best endeavour to satisfy the
Conditions in accordance with this Clause 2.
XXXXXX XXXXXX XXXXXX Term 3.1 This Agreement shall commence and become operative
when it is signed by the parties and dated.
3.2 Subject to Clause 2 the rights granted to the Promoter under this Agreement shall be exercisable
from the Unconditional Date. Accordingly, the initial term of this Agreement (the Initial Term) shall
begin on the Unconditional Date and shall expire on 31 December 2015 and shall apply to the
Championship for the calendar years 2011 to 2015 (inclusive).
3.3 On or before 30 June 2015, FOWC shall in its absolute discretion be entitled to give notice to the
Promoter which, if given, shall be effective to extend the Term for a further period of up to five
calendar years (the Extended Term). The terms of this Agreement shall apply to the Extended Term
save for this Clause 3.3.
3.4 The term of this Agreement as prescribed in this Clause 3 shall be referred to as the Term and
shall include the initial Term and (if applicable) the Extended Term.
3.5 Subject to the performance by FOWC of its obligations contained in Clause 4, the Promoter
agrees to host, stage and promote the Event as the FORMULA 1 GRAND PRIX OF INDIA or [Year]
GRAND PRIX OF INDIA in accordance with this Agreement once in every calendar year of the Term
commencing 2011 at the Circuit on the date approved and announced by the FIA on and subject to
the terms of the Regulations and the Sporting Code.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

FOWC’s Obligations and Warranties XXXXXX XXXXXX XXXXXX Promoter’s Warranties
(e) On the area of land, the outer perimeter of which is edged in red, depicted on the document
attached to this Agreement as the Annex and initialed by the Parties for identification, the Circuit
shall be constructed, laid out and prepared in accordance with this Agreement, in a form and
manner approved by both FOWC and the FIA, meeting all requirements of the Regulations
(including as to timing of inspections) and completed in good time for final inspection by the FIA
not later than 12 October 2011;
XXXXXX XXXXXX XXXXXX Access to Circuit Prior to Event
11. The Promoter shall take whatever action is necessary to ensure that the pit and paddock
buildings and surrounding areas within Circuit and the Land are open to receive the competitors,
FOWC, Affiliates of FOWC, FOWC’s contractors and licensees and their respective personnel and
equipment (if any) at all times during the period commencing fourteen days before the day of the
race and ending seven days after the Race (the Access Period) and the security of the paddock and
garage area is properly safeguarded at all times during the Access Period.
XXXXXX XXXXXX XXXXXX Competitor/Media Facilities 13.1 The Promoter will in so far as the
same is practicable provide an entrance for the Competitor personnel and for Officials separate from
the public entrance to the Circuit.
13.2 The Promoter will provide free of charge a zone measuring whichever is the greater of that
which has last been provided in respect of a round of the FIA Formula One World Championship at
that Circuit and 140 metres by 100 metres or 15,0000 square metres within or adjoining the
paddock for the promotional facilities of the Competitors and/or their sponsors.
13.3 The Promoter undertakes to set up a media compound and telephones and facsimile
equipment, Press Room plus the installations and premises necessary for national and international
television commentators and journalists (such premises and installations to meet the prestige of a
World Championship) and to grant professional accredited journalists use of all facilities for the
exercise of their profession as well as the organization of a Press Conference with the winner of the
Race immediately after the Podium Ceremony.
13.4 Upon the arrival of the Formula One cars and their spares and ancillary equipment at nearest
suitable International airport (as such is determined by FOWC) (the Landing) the Promoter will
transport them free of charge from the Landing to the Circuit and from the Circuit back to the
Landing. The Promoter shall procure that transportation from the Circuit to the Landing shall take
place on the day following the Race. All ancillary costs including airport taxes customs clearance
handling, loading and unloading both at the Landing and at the Circuit shall be paid by the
Promoter. The Parties agree to liaise with each other throughout the Term with a view to discussing
and implementing all reasonable measures which may reduce such ancillary cots.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

13.5 The Promoter undertakes to provide all such other facilities as specified in the Circuit General
Specifications Manual.
Access to Restricted Areas
14. The Promoter undertakes to ensure that:
(a) only Passes and tabards issued by FOWC under the authorization of the FIA will
authorize access to parts of the Circuit not open to the paying public;
(b) notwithstanding Clause 14(a) above, the public do not have access to the cars in
any of the places where any Competitor’s mechanics may be called upon to work on
them and without prejudice to the generality of the foregoing there is at no time any
obstruction to the free passage of the cars and Competitor personnel in the paddock
or pit area;
(c) the validity of any Passes and tabards issued by FOWC under the authorization of
the FIA is upheld; and
(d) the necessary steps are taken to ensure that all police and Circuit officials are
familiar with the Passes and tabards and uphold their validity.
Insurance 15.1 The Promoter shall provide at its expense third party liability insurance (in a form
approved by FOWC and the FIA insuring FOWC and all its Affiliates, Beta Prema 2 Limited and all
its Affiliates, the Competitors, Drivers and guests of any of the above mentioned parties (such
parties to include where relevant all directors, officers, employees, agents and contractors) and such
other persons involved in the organization of the Event (including officials, marshals, rescue and
medical staff) as the FIA or FOWC may from time to time advise the Promoter (the Insured Parties)
against all risks (including death of or bodily or mental injury to any person) relating to (i) the event
(ii) support races and (iii) peripheral entertainment organized as part of the Event, for the Access
Period. If such insurance is not permitted under the law of the country in which the Event takes
place or the FIA is satisfied that such insurance is not commercially viable then the insurance shall
be the maximum permitted by that law or the market conditions. The insurers must be a company
recognized by Standard and Poor’s and/or AM. Best and must be of first class international standing
with sufficient resources to honour and discharge in full the insurance requirements prescribed in
this agreement. A copy of the relevant policy will be given to FOWC by the Promoter at least 60 days
before the start of the first practice session (with the exception of the year 2011, when such copy will
be given to FOWC at least 30 days before the start of the first Practice session of the Event in 2011).
If the language of the relevant policy is in a language other than English, FOWC shall obtain a
translation of the policy at the expense of the Promoter.
XXXXXX XXXXXX XXXXXX Filming/Recording at the Event 18.1 Save with the prior written
consent of the FOWC and save for the Promoter’s obligation in Clause 18.3, throughout the Term
during the Access Period (and any test session held at the Circuit in which more than oneFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

Competitor is participating (Non-Private F1 Test Series) the Promoter shall not (nor shall the
Promoter permit, enable, assist, procure or encourage others to) make, create, store, record or
transmit an kind of sound recording or visual or audio-visual footage (Recording) whatsoever,
whether for broadcast or any other purpose.
(a) of at or pertaining to the Event (including cars, Drivers, Competitors), any Non-Private F1 Test
Session or any aspect of them; or
(b) within the confines of the Circuit or the Land (or any other part of its surroundings over which
the Promoter has control).
18.2 Without prejudice to the generality of Clause 18.1, the Promoter shall ensure that the terms of
sale of tickets giving admittance to an Event include acceptance by a ticket holder:
(a) that he shall not make, create, store, record or transmit any Recording of the
Event (including cars, Drivers, Competitors) or any aspect of it, and shall not take
into the Circuit any equipment that may enable him to do the aforementioned acts
(other than mobile telephones use of which is subject to this Clause 18 and Clause
19.1 below);
(b) that as a spectator he may be filmed and sound made by him may be recorded for
broadcast (or similar transmission); and
(c) of such other terms and conditions as FOWC(acting reasonably) may request the
Promoter to include from time to time provided that the Promoter is notified in due
time and that such terms and conditions are compatible with applicable local laws.
18.3 The Promoter shall engage a third party (the Identity of which shall be approved by FOWC in
its sole discretion) to carry out and perform on behalf of the Promoter all services relating to the
origination of the international television feed and host broadcasting for each Event during the
Term as are specified in guidelines published annually by FOWC and provided to the Promoter from
time to time.
Intellectual Property XXXXXX XXXXXX XXXXXX 19.2 The Promoter hereby irrevocably and
unconditionally:-
(a) assigns to FOWC with full title guarantee all copyright and other intellectual
property rights and all other rights, titles and interests (if any) which it may now or in
the future have in any Image or Recording or any other representation or recording
in any media whether now known or hereafter invented or developed in, of or
pertaining to the Event, any NonPrivate F1 Test Session or any aspect of them
(irrespective of who originated the same)for the duration of those rights (including all
renewals, extensions, reversions and revivals thereof); andFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

(b) gives its consent (if such consent should be required) for FOWC to deal in such
rights in any way it may see fit.
Accreditation for Filming/recording 20.1 The Promoter shall ensure that persons accredited and
authorized by FOWC are permitted to enter upon the Circuit to make sound, television or other
recordings or transmissions or to make films or other moving picture and use the facilities
throughout the Access Period and the Promoter shall accord all such persons the help and facilities
that they or FOWC may reasonably require for such purposes, including assistance with obtaining
any necessary consents, permissions or authorizations with any local authority.
20.2 The Promoter undertakes to Notify FOWC of the dates of any test sessions which are proposed
to be held at the Circuit.
Circuit Advertising
21. The Promoter shall not cause, permit, enable, assist, procure or encourage the display of any
advertising (other than the advertising normally displayed on any Competitor’s cars, Drivers or
personnel) or other displays on, near or which can be seen from the Circuit and/or the Land which
might (in the opinion of FOWC which shall be final and binding upon the Parties) Prevent the lawful
transmission of Images or Recordings of the Events or any part of it in any country."
JUDGMENT OF THE HIGH COURT Taking note of this agreement, the High Court went ahead to
decide the following aspects, which revolved around the question of PE:
Whether FOWC had control over the Buddh International Circuit and that the circuit
could be constituted as a fixed place of business? Whether FOWC carried on
business? IF so, they did carry on business and commercial activity in India.
Whether FOWC carried on business through its agents under Article 5(4) or Article
5(5) of the DTAA?
Answering the first question, the High Court discerned that for the duration of the
event as well as two weeks prior to it and a week succeeding it, FOWC had full access
through its personnel, the team contracted to it, both racing as well as spectator
teams to the said Buddh International Circuit. It could also dictate who was
authorised to enter the areas reserved for it. As per the High Court, though Jaypee
was designated as the promoter or the host of the event in terms of RPC, when the
matter was to be examined in a correct perspective by seeking through the other
terms contained in the agreement as well as terms of agreements between JP and
Allsports, Beta Prema 2 as well as FOA, it was clear that Jaypee’s capacity to act was
extremely restricted. At all material times, FOWC had exclusive access to the circuit
and all the places where the teams were located. The High Court was also conscious
of the fact that such an access or right to access was not permanent in the sense of its
being everlasting. However, having regard to the model of commercial transactions,Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

such an access for a period up to six weeks at a time during the F-1 Championship
season was sufficient for the purposes of Article 5(1) of DTAA. Further, as the tenure
of RPC was five years, it meant that such an access for the period in question was of
repetitive nature. Moreover, FOWC was entitled to two years payment of the assured
consideration of US$ 40 million in the event of termination of RPC.
While discussing the second question, the High Court took note of agreement between FIA and
FOWC under which FOWC became CRH. It also pointed out that the Concorde Agreement assured
the participating teams that the FIA had exclusive rights in the F-1 Championship and was entitled
to the grant of CRH, the exclusive right to exploit the commercial rights in the F-1 Championship.
Subject to these conditions, each team undertook to participate in the FIA F-1 Championship each
year for several events and make cars available. In fact, every team undertook to participate in each
event with two cars. Taking note of the aforesaid arrangement and other clauses of these
agreements, the High Court concluded that FOWC carried on business in India within the meaning
of expression under Article 5(1) of the DTAA.
The High Court was conscious of the fact that after its finding to the effect that FOWC had PE in
India, the issue as to whether FOWC carried on business through its agents or not, became
academic. Notwithstanding the same, it chose to discuss that issue as well so that the judgment had
the coverage of all the questions that had arisen before it. This aspect has been discussed in the light
of sub-articles (4) and (5) of Article 5 of DTAA. It is pertinent to mention that argument of the
Revenue was that since FOWC had to exploit commercial rights arising from races and this business
is carried on through exploitation of these commercial rights either by itself or through anyone or
more members of CRH group, as mentioned in the Conorde Agreement, FOWC is obliged to propose
consolidated accounts incorporating profits of all entities forming part of CRH group. The Revenue
had relied on the Events right from the time when commercial rights were originally owned by FIA
and thereafter transferred to SLEC Holding Company (parent company of FOWC) for a
consideration, then given to FOAM and with effect from January 01, 2011 transferred to FOWC. It
was also pointed out that FOWC’s three affiliates, i.e. Formula One Management Ltd. (‘FOM’),
Allsports Management SA and Beta Prema 2 Ltd. were its agents who carried on its business and on
its behalf, through the fixed place.
AAR had rejected this submission of the Revenue holding that the theory of Revenue that all the
three entities were acting on behalf of FOWC was unfounded as there was no evidence to this effect
and all arrangements and agreements in relation to activities performed by three entities were
sham. The High Court approved the aforesaid approach of AAR in the following manner:
“64. Article 5(5) has certain preconditions if an entity has to be treated as dependent
agent. The agent must have the authority to conclude contracts, which bind the
represented enterprise, and it must habitually exercise such authority. If these
positive preconditions are met, then only an enterprise shall be deemed to have a PE
in that state in respect of any activities, which that person undertakes for the
enterprise. The contention that because the three entities were subsidiaries of FOWC,
they acted on its behalf and thus become dependent agents is insubstantial. The mereFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

circumstance that the three subsidiaries had a connection with FOWC was not
enough; what is to be shown is that the contracts they entered into and the businesses
they were engaged in, was for and on behalf of FOWC. Each of the three agreements
independently entered into by them with Jaypee contains no pointers to this fact.”
THE ARGUMENTS Mr. Ganesh, opened the case of FOWC, whereafter M/s. Arvind
P. Datar and Dushant Dave, learned senior advocates, made their submissions on
behalf of Jaypee. Mr. Mukul Rohatgi, learned Attorney General for India, argued on
behalf of the Revenue and countered those submissions. He also argued the appeal of
Union of India insofar as it challenges the findings of the High Court interpreting
Article 5(4) and (5) and holding that the other companies of FOWC group did not act
as agents of FOWC in India. M/s. S. Ganesh and Arvind P. Datar made their
submissions in rejoinder and also refuted the arguments of Mr. Mukul Rohatgi
advanced in the appeal of Union of India, to which Mr. Rohatgi made his submissions
in rejoinder.
After referring to the important dates and events, Article 5 of DTAA and the
commentaries of OECD, Philip Baker and Klaus Vogel thereon, salient features
whereof have already been reproduced by us, emphasis in the submission of Mr.
Ganesh was that in order to constitute a PE, condition which was necessary to satisfy
was that the particular ‘fixed place’ is ‘at the disposal’ of FOWC and further that from
the said ‘fixed place’ FOWC was doing its business activity. Submission of Mr. Ganesh
was that both the ingredients were missing in the instant case. For this purpose, he
referred to the agreement of 2009 which was entered into between FIA and Jaypee
and pointed out that FOWC was not party to the said agreement and contended that
this agreement clearly evinced that it is the FIA which had control over the manner in
which the Championship was to be conducted. This agreement further reflected that
it is Jaypee who was responsible for conducting races and had complete control of the
Event in question. All obligations for conduct of the Championship were to be
discharged by Jaypee as organisers. For this purpose, he referred to the counter
affidavit filed by Jaypee in SLP(Civil) No. 3112 of 2017 wherein the role of Jaypee in
organising these Events is stated. From there, it was pointed out that the track was
constructed by Jaypee; for this purpose they had their own engineers, architects etc.;
entire expenditure for this purpose was borne by Jaypee. It was also stated that this
circuit was owned by Jaypee and control thereon was that of Jaypee on which not
only Championship in question was organised, but Jaypee was utilising this track for
many other events which are organised on regular basis, all year round.
Mr. Ganesh also drew the attention of this Court to Organisation Agreement dated
January 20, 2011 signed between FIA, Jaypee and Federation of Motors Sports Clubs
of India wherein Jaypee is described as the ‘Organiser’ and given the responsibility to
organise the Event. It specifically delineates various responsibilities of Jaypee as
organisers which have already been taken note of above. In nutshell, he submitted
that right from construction/laying down the contract for the motor races people till
the conclusion of the Events/Championship, all acts and obligations were to beFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

performed by Jaypee, with no role of FOWC therein. According to him, in contrast, it
could be seen from the Agreement dated September 13, 2011 between FOWC and
Jaypee that FOWC had simply given permission to host the Event as a round of the
Championship, since it is the FOWC, who has the exclusive right to exploit the
commercial rights in the Championship, including exclusive right to propose the
Championship calendar. Condition precedent from entering into this Agreement, as
mentioned in the Agreement itself, was that Jaypee (as promoter) had entered into a
valid and binding agreement with such third party in accordance with Clause 18.3
(Service Agreement). Referring to the clause pertaining to obligations and warranties
of FOWC, Mr. Ganesh submitted that the role of FOWC was primarily that of
advising, assisting and consulting with the promoter in relation to the Event in such
manner as FOWC shall consider necessary and/or appropriate for the staging and
promotion of the Event to the mutual benefit of the parties. On the other hand,
Jaypee was given exclusive right to act as the promoter of the Event, to construct the
circuit which was to be laid out and prepared in accordance with that agreement in a
form and manner approved both by FOWC and FIA. Thus, construction was to be
carried out by Jaypee; albeit, in the form and the manner approved by FOWC and
FIA to ensure that the track meets all requirements of the Regulations. Otherwise, all
those rights which were necessary for the purposes of hosting and staging the Event
at the circuit were that of Jaypee exclusively.
On the basis of the aforesaid documents and clauses and terms therein, Mr. Ganesh
submitted that the circuit was not under the control or at the disposal of FOWC. As
regards 4500 seats in paddock space given to FOWC in that circuit is concerned,
explanation of Mr. Ganesh was that it is Allsports which was in-charge of paddock
and the same was taken from Allsports by FOWC in the year 2006 and, therefore, it
would not make any difference.
His further submission was that no business was conducted by the FOWC from the
said site as well. According to him, since FOWC was commercial rights holder of
these events, main business of FOWC was to exploit these rights. including
intellectual property rights. According to him, the exploitation of these commercial
rights yields two revenue streams – first, the consideration received from the
Promoter/Organizer of the Event, to whom FOWC has granted the necessary right to
host, stage and promote the Event; secondly, FOWC exploits the TV feed in respect of
the Event, which is made available to it by the Promoter/Organiser, at his cost.
FOWC grants screening, exhibition, telecasting and media rights arising out of and
relating to this TV feed to a number of parties around the world, by entering into
contracts with them at London. It is for this reason that insofar as holding of the
Event is concerned, FOWC was not responsible therefor and for this reason it was
necessary for Jaypee as promoter to enter into a valid and binding agreement with a
third party (FIA in the present case). He also pointed out that insofar as sale of
advertisement rights during the Event is concerned that was also to be given to Beta
Prema 2 Ltd. which was again an independent company and taken over by FOWC inFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

the year 2006.
Mr. Ganesh, extensively referred to the findings of AAR on this issue wherein the case
of FOWC and Jaypee on this aspect was accepted by AAR and pleaded that the
aforesaid findings be accepted and restored by this Court. Referring to the judgment
of the High Court, his submission was that the Organisation Agreement entered into
between FIA and Jaypee was not even discussed and the conclusions given in
paragraphs 52 and 53 of the said judgment were erroneous. He also relied upon
certain observations of this Court in Union of India & Anr. Vs. Azadi Bachao Andolan
& Anr.[16] in respect of his submission that transactions could not be treated as
sham.
Mr. Datar, learned senior counsel appearing for Jaypee, supplemented the aforesaid
submissions of Mr. Ganesh on the issue of the PE. He argued that the judgment of
the High Court was flawed in its approach as it had gone by inductive logic instead of
deductive logic. According to him, the first question which has to be focused upon
was as to what is the business of FOWC. His submission was that since in this case
business of FOWC was not to organise these races, the question of its PE in India,
that too in the form of circuit where the race is to be held, could not be PE of FOWC.
He also submitted that even after going through all the clauses of the agreement
between FOWC and Jaypee with a toothcomb, it would be found that FOWC had no
physical control over the said circuit. In this behalf, he emphasised the test laid down
by Andhra Pradesh High Court in Visakhapatnam Port Trust, which is recognised by
Philip Baker in his commentary. He also argued that entire Formula One Event was a
temporary model for three days in a year only and even if it is accepted that the
FOWC had control over this place for those three days, possession of the site for three
days in a year cannot be termed as PE. He also emphasised the fact that since FOWC
was a UK resident company, it had been paying taxes in its own country. For a
non-resident to pay taxes in other country, as in India in the instant case, threshold
has to be very high and the issue of PE had to be examined with this focus in mind.
He submitted that this was precisely the reason that such sports events held in other
countries are never taxed in those countries.
His alternate submission was that the agreement in question was signed in UK under
which consideration of US$ 40 million was paid and, therefore, this income accrued
in UK. Thus, such income was taxable in UK. He argued that insofar as rights to hold
the events are concerned they were granted in UK and it is the grant of rights which
was the determinative test and implementation of those rights took place in India. In
support of this proposition, he relied on the judgment of this Court in the case of
Commissioner of Income Tax, Andhra Pradesh v. M/s. Toshoku Ltd., Guntur &
Ors.[17] where the law is discussed in the following manner:
“12. The second aspect of the same question is whether the commission amounts
credited in the books of the statutory agent can be treated as incomes accrued, arisen,Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

or deemed to have accrued or arisen in India to the non-resident assessees during the
relevant year. This takes us to Section 9 of the Act. It is urged that the commission
amounts should be treated as incomes deemed to have accrued or arisen in India as
they, according to the Department, had either accrued or arisen through and from the
business connection in India that existed between the non-resident assessees and the
statutory agent. This contention overlooks the effect of clause (a) of the Explanation
to clause (i) of sub-section (1) of Section 9 of the Act which provides that in the case
of business of which all the operations are not carried out in India, the income of the
business deemed under that clause to accrue or arise in India shall be only such part
of the income as is reasonably attributable to the operations carried out in India. If all
such operations are carried out in India, the entire income accruing therefrom shall
be deemed to have accrued in India. If, however, all the operations are not carried out
in the taxable territories, the profits and gains of business deemed to accrue in India
through and from business connection in India shall be only such profits and gains as
are reasonably attributable to that part of the operations carried out in the taxable
territories. If no operations of business are carried out in the taxable territories, it
follows that the income accruing or arising abroad through or from any business
connection in India cannot be deemed to accrue or arise in India. [See CIT v. R.D.
Aggarwal & Co. [AIR 1965 SC 1526 : (1964) 1 SCR 234, 247 : 56 ITR 20]
and Carborandum Co. v. CIT[(1977) 2 SCC 862 : 1977 SCC (Tax) 391 : (1977) 3 SCR
475 : (1977) 108 ITR 335] which are decided on the basis of Section 42 of the Indian
Income Tax Act, 1922, which corresponds to Section 9(1)(i) of the Act.]” Another
submission of Mr. Ganesh was that the High Court did not have jurisdiction, in
exercise of its powers under Article 226 of the Constitution, to go into the 'findings' of
AAR on the issue of ‘fixed place’. He argued that under Article 226 of the
Constitution, the High Court exercised Certiorari jurisdiction and in exercise of such
a jurisdiction, findings of facts recorded by the Tribunal, which are the subject matter
of judicial review, cannot be gone into.
Without prejudice to the aforesaid submissions, next argument of Mr. Datar was that having regard
to the facts of this case, no interest should be held payable under Section 201 of the Act. Referring to
the scheme of Chapter XXIX-B which pertains to advance rulings, he submitted that the parties had
shown their bona fides in having the question raised before the AAR, and it was specifically agreed
to between FOWC and Jaypee in Clause 24.6 of the Agreement that the parties should approach
AAR for determination of the questions which were referred. He pointed out that once an
application was made before the AAR, procedure that is contained in Section 245R, on receipt of
such applications, had to be followed by AAR and in that event Section 245 RR mandates that no
income tax authority or the appellate tribunal shall proceed to decide any issue in respect of which
an application has been made by the applicant, being a resident, under Section 245QQ for advance
ruling. Once advance ruling is pronounced by AAR, it was binding on the applicant who had sought
the same in respect of a particular transaction as well as on the Principal Commissioner and
Commissioner of Income Tax Authorities subordinate to him. According to him, in such a scenario,
it should not be considered that Jaypee had failed to deduct tax at source from the amounts paid to
FOWC and as a consequence of failure to deduct, it should be fastened with the liability to payFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

interest under Section 201. In support, paragraph 12 of GE India Technology Centre Private Limited
v. Commissioner of Income Tax & Anr.[18] was pressed into service which reads as follows:
“12. Reference to ITO(TDS) under Section 195(2) or Section 195(3) either by the
non-resident or by the resident payer is to avoid any future hassles for both the
resident as well as the non-resident. In our view, Sections 195(2) and 195(3) are
safeguards. The said provisions are of practical importance. This reasoning of ours is
based on the decision of this Court in Transmission Corpn. [(1999) 7 SCC 266 :
(1999) 239 ITR 587] in which this Court has observed that the provision of Section
195(2) is a safeguard. From this it follows that where a person responsible for
deduction is fairly certain then he can make his own determination as to whether the
tax was deductible at source and, if so, what should be the amount thereof.” Last
submission of Mr. Datar was that in any case it was yet to be determined as to how
much of US$ 40 million fee paid by Jaypee to FOWC could be attributed to PE,
inasmuch as it is only that portion of income that is relatable to PE which is liable for
tax in India. This has not happened so far.
Mr. Dushant Dave, learned senior counsel, again appearing for Jaypee, made an
additional submission to the effect that international treaties which are signed
between the two sovereign countries have to be given adequate and due respect which
they command. He exhorted the Court to keep this fundamental principle in mind
while interpreting clause 5 of DTAA and submitted that such an approach has been
commanded by this Court time and again. By way of example, he cited the
judgements in the cases of Azadi Bachao Andolan and Maganbhai Ishwarbhai Patel
Etc. v. Union of India and Another[19]. He also referred to paragraph 6 of the UK
judgment in the case of Sepet v. Secretary of State for the Home Department[20]
wherein it was pressed that single autonomous meaning was required to be given to
the treaties which are living instruments whose meaning does not change over time
but application will.
From Azadi Bachao Andolan following passages were relied upon:
“17. Every country seeks to tax the income generated within its territory on the basis
of one or more connecting factors such as location of the source, residence of the
taxable entity, maintenance of a permanent establishment, and so on. A country
might choose to emphasise one or the other of the aforesaid factors for exercising
fiscal jurisdiction to tax the entity. Depending on which of the factors is considered to
be the connecting factor in different countries, the same income of the same entity
might become liable to taxation in different countries. This would give rise to harsh
consequences and impair economic development. In order to avoid such an
anomalous and incongruous situation, the Governments of different countries enter
into bilateral treaties, conventions or agreements for granting relief against double
taxation. Such treaties, conventions or agreements are called Double Taxation
Avoidance Treaties, Conventions or Agreements.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

xx xx xx
130. The principles adopted in interpretation of treaties are not the same as those in
interpretation of a statutory legislation. While commenting on the interpretation of a
treaty imported into a municipal law, Francis Bennion observes:
“With indirect enactment, instead of the substantive legislation taking the
well-known form of an Act of Parliament, it has the form of a treaty. In other words,
the form and language found suitable for embodying an international agreement
become, at the stroke of a pen, also the form and language of a municipal legislative
instrument. It is rather like saying that, by Act of Parliament, a woman shall be a
man. Inconveniences may ensue. One inconvenience is that the interpreter is likely to
be required to cope with disorganised composition instead of precision drafting. The
drafting of treaties is notoriously sloppy usually for a very good reason. To get
agreement, politic uncertainty is called for.
… The interpretation of a treaty imported into municipal law by indirect enactment
was described by Lord Wilberforce as being ‘unconstrained by technical rules of
English law, or by English legal precedent, but conducted on broad principles of
general acceptation. This echoes the optimistic dictum of Lord Widgery, C.J. that the
words ‘are to be given their general meaning, general to lawyer and layman alike …
the meaning of the diplomat rather than the lawyer’. [Francis Bennion: Statutory
Interpretation, p. 461 [Butterworths, 1992 (2nd Edn.)].]” xx xx xx
131. An important principle which needs to be kept in mind in the interpretation of
the provisions of an international treaty, including one for double taxation relief, is
that treaties are negotiated and entered into at a political level and have several
considerations as their bases.
Commenting on this aspect of the matter, David R. Davis in Principles of International Double
Taxation Relief  [David R. Davis: Principles of International Double Taxation Relief, p. 4 (London,
Sweet & Maxwell, 1985)], points out that the main function of a Double Taxation Avoidance Treaty
should be seen in the context of aiding commercial relations between treaty partners and as being
essentially a bargain between two treaty countries as to the division of tax revenues between them in
respect of income falling to be taxed in both jurisdictions. It is observed (vide paragraph 1.06):
“The benefits and detriments of a double tax treaty will probably only be truly
reciprocal where the flow of trade and investment between treaty partners is
generally in balance. Where this is not the case, the benefits of the treaty may be
weighed more in favour of one treaty partner than the other, even though the
provisions of the treaty are expressed in reciprocal terms. This has been identified as
occurring in relation to tax treaties between developed and developing countries,
where the flow of trade and investment is largely one-way.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

Because treaty negotiations are largely a bargaining process with each side seeking
concessions from the other, the final agreement will often represent a number of
compromises, and it may be uncertain as to whether a full and sufficient quid pro
quo is obtained by both sides.” And, finally, in paragraph 1.08:
“Apart from the allocation of tax between the treaty partners, tax treaties can also
help to resolve problems and can obtain benefits which cannot be achieved
unilaterally.” xx xx xx
134. Developing countries need foreign investments, and the treaty-shopping
opportunities can be an additional factor to attract them. The use of Cyprus as a
treaty haven has helped capital inflows into eastern Europe.
Madeira (Portugal) is attractive for investments into the European Union. Singapore is developing
itself as a base for investments in South-East Asia and China. Mauritius today provides a suitable
treaty conduit for South Asia and South Africa. In recent years, India has been the beneficiary of
significant foreign funds through the “Mauritius conduit”. Although Indian economic reforms since
1991 permitted such capital transfers, the amount would have been much lower without the
India-Mauritius Tax Treaty
135. Overall, countries need to take, and do take, a holistic view. Developing countries allow treaty
shopping to encourage capital and technology inflows, which developed countries are keen to
provide to them. The loss of tax revenues could be insignificant compared to the other non- tax
benefits to their economy. Many of them do not appear to be too concerned unless the revenue
losses are significant compared to the other tax and non-tax benefits from the treaty, or the treaty
shopping leads to other tax abuses.” Mr. Mukul Rohtagi, learned Attorney General, came out with
strong refutation to the aforesaid submissions. Responding in an equally salubrious style, he
demonstrated the 'flow of commercial rights' in relation to these events, under various agreements
executed between different stakeholders from time to time and the manner in which such rights are
ultimately exploited by FOWC and its other group companies in respect of the F-1 race organized in
India. For this purpose, he referred to eleven agreements between different parties highlighting
certain features and aspects in the following manner:
|Agreement between FIA and FOAM dated April 24, 2001 – FIA parts | |with
commercial rights in favour of FOAM. FOAM becomes the | |exclusive Commercial
Rights Holder (CRH). | | | | |Agreement between FOAM and FOWC dated April 24,
2001 – FOAM | |transfers the commercial rights in favour of FOWC with effect |
|from 2011 for a period of 100 years. | | | | |RPC dated October 25, 2007 between
FOWC and Jaypee: | |Building of the circuit was started in terms of this RPC. |
|FOWC was granted only the right to promote the event (clause | |4(1). | |FOM was
declared the business manager and agent of FOWC (Recital| |D). | |This agreement
was signed by FOM on behalf of FOWC. | |No condition precedent clause obligating
Jaypee to enter into | |any agreements with FOWC group entities. | |No clause
obligating Jaypee to enter into an agreement with FOM | |for generation of televisionFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

feed. | |Agreement in the same template as Schedule IV to the Concorde |
|Agreement. | | | | |Concorde Agreement (2009) between FIA, FOWC and teams: |
|FOWC becomes the exclusive CRH. | |FOWC could exploit the commercial rights
directly or through its| |affiliates only. | |‘F1 business’ defined to mean exploitation of
various rights, | |including media rights, hospitality rights, title sponsorship, | |etc. |
|Revenue of FOWC and its affiliates to be taken for distributing | |the prize money to
the teams under Schedule X | | | | |Organisation Agreement dated January 20, 2011
between FIA/FMSCI | |and Jaypee: | |Jaypee to organise the event. | |As of this date,
Jaypee has entered into an agreement with the | |CRH (Recital B). | |Template of the
agreement contained in Schedule VI of the | |Concorde Agreement. | | | | |Title
Sponsorship Agreement dated August 16, 2011 between Beta | |Prema 2 and Bharti
Airtel: | |Transfer of title sponsorship rights by Beta to Bharti Airtel | |for US$ 8
million. | |This agreement is one month before the agreement between Beta | |Prema
2 and Jaypee through which Beta Prema 2 allegedly acquired| |this right. | | | | |RPC
dated September 13, 2011 between FOWC and Jaypee: | |Agreement entered one
month before the race. | |Fresh RPC entered without rescinding the RPC of 2007. |
|Right to host, stage and promote the event allegedly given to | |Jaypee by FOWC,
unlike the previous RPC which only gave the | |right to promote. | |Conditions
precedent binding Jaypee to transfer the rights back | |to the affiliates of FOWC. |
|Clause 18.3 binding Jaypee to engage FOM for generating | |television feed
introduced in this RPC. | |Recital D of the previous RPC which declared FOM the
business | |manager and agent removed. | | | | |Agreements between JP and the three
affiliates (September 13, | |2011) | |Agreements entered on the same day as RPC, i.e.
September 13, | |2011. | |Rights allegedly given to Jaypee are transferred back to the |
|FOWC affiliates. Beta Prema 2 acquires circuit rights (mainly | |media and title
sponsorship) and Allsports gets paddock rights. | |FOM engaged to generation
television feed. | |Agreement provides that all revenues from the rights would flow |
|to the affiliates and not Jaypee (clause 11). | |Agreement provides that there does not
exist an agency | |relationship between the affiliates and Jaypee (clause 26). | | | |
|Service Agreement dated October 28, 2011 between FOWC and FOM: | |Agreement
entered into on October 28, 2011, on the day of race. | |FOM engaged by FOWC to
provide various services – liaison and | |supervision of other parties at the event,
travel, transport and| |data support services. | | | | |Director’s report of financial
statements of FOWC for the year | |2011: | |Defines the business of FOWC as ‘The
company’s principal | |activity during the year was the organisation, management
and | |administration of motorsport conducted principally through the | |exploitation
of the commercial rights to the FIA Formula One | |World Championship”. | From
the features described above, it was submitted by the learned Attorney General that
clear manifestation of the aforesaid agreements was that FOWC and its subsidiaries
had taken total control over the event that took place in India which, according to
him, was to be kept in mind for proper examination of the issues in their right
perspective. Mr. Rohtagi argued that Section 5(2)(b) of the Act, which applies in the
instant case, specifically includes ‘income’ of a non-resident from ‘whatever source
derived’, if this income accrues or arises or is deemed to accrue or arise to him inFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

India during such year. Referring to Section 9 of the Act, which specifies the
circumstances under which income shall be deemed to accrue or arise in India, he
pointed out that it covers all income, ‘whether directly or indirectly’, that accrues or
arises, if it is through or from any ‘business connection in India’. Therefore, if
business connection is established, then all incomes, whether earned directly or
indirectly, would come within the net of taxability of such incomes in India. Referring
to explanation (2) to Section 9(1)(i), he laid stress on the submission that ‘business
connection’ shall include any business activity ‘through’ a person who acts on behalf
of the non-resident. The expression ‘through’ is clarified in explanation (4) thereof to
mean and include and shall be deemed to have always meant and include ‘by means
of’, ‘in consequence of’ or ‘by reason of’. He submitted that these deeming provisions
are of very vide import and when the facts of this case are examined keeping in view
the aforesaid provisions, the High Court rightly concluded that FOWC had PE in
India. He also argued that Jaypee was only to host the event, whereas total access at
the time of construction as well as at the time of event was that of FOWC. According
to him, at the most, it was in the nature of Jaypee and FOWC as partners in the
business.
Mr. Rohatgi also submitted that comparisons of first Agreement of 2007 with the
second Agreement dated September 13, 2011 clearly demonstrates that the second
agreement was totally subterfuge to avoid payment of tax in India. He pointed out
that in the Agreement dated October 25, 2007, FOWC was granted only the right to
'promote' the event (Clause 4(1)), whereas in the Agreement dated September 13,
2011, right to 'host, stage and promote' the event was allegedly given to Jaypee by
FOWC. According to him, right to host and stage the event was conferred upon
Jaypee only on paper to give it a semblance as if Jaypee was in real control of the
affairs, which was not actually so. Therefore, in any case, it would not make any
difference when in reality the rights of hosting and staging the competition were with
FOWC.
Referring to the Agreement dated September 13, 2011 between Jaypee and three
affiliates of FOWC, the argument of Mr. Rohatgi was that the so- called rights given
to Jaypee were transferred back to FOWC affiliates inasmuch as Beta Prema 2
acquired circuit rights, mainly media and title sponsorship, whereas Allsports was
given paddock rights. His submission was that business was carried from the circuit,
paddock, etc. and, therefore, it cannot be said that no business activity was carried
from this place. He also pointed out how FOWC granted rights to FOAM to provide
various services in case FOWC had no control over the race. It also showed physical
management of the business as well.
Coming to the issue of dependent PEs, submission of the learned Attorney General
was that in view of the flowchart depicting commercial rights with FOWC and its
affiliates, this issue was virtually an academic issue once it is found that FOWC and
its affiliates are one conglomerate, the commercial rights of different nature, viz. theFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

CRH bouquet was with the group companies under the control of same management
which exploited all these rights. These companies had pooled all the profits and
sharing thereof was in the ratio of 50:50 between the teams and CRH companies.
As far as power of the High Court under Article 226 of the Constitution of India to go
into the issue is concerned, Mr. Rohatgi drew the attention of the Court to its earlier
judgment in Columbia Sportswear Company v. Director of Income Tax,
Bangalore[21] wherein this Court had impressed that from the rulings of AAR the
aggrieved person was required to approach the High Court in the first instance. He,
thus, submitted that it was the first forum of judicial review of the opinion given by
the AAR and, therefore, the High Court was very well within its power to revisit the
issue; albeit within the scope of jurisdiction of Article 226 of the Constitution of
India, and decide the same. According to him, the High Court had not exceeded its
jurisdiction while deciding the aforesaid issues in the writ petitions filed by the
appellants themselves.
Refuting the arguments of Mr. Datar predicated on Section 195 of the Act, Mr.
Rohatgi referred to the judgment of this Court in GE India Technology Centre Private
Limited v. Commissioner of Income Tax & Anr.[22] wherein following principle is
laid down in paragraph 18:
“18. If the contention of the Department that any person making payment to a
non-resident is necessarily required to deduct TAS then the consequence would be
that the Department would be entitled to appropriate the monies deposited by the
payer even if the sum paid is not chargeable to tax because there is no provision in
the IT Act by which a payer can obtain refund. Section 237 read with Section 199
implies that only the recipient of the sum i.e. the payee could seek a refund. It must
therefore follow, if the Department is right, that the law requires tax to be deducted
on all payments. The payer, therefore, has to deduct and pay tax, even if the so- called
deduction comes out of his own pocket and he has no remedy whatsoever, even
where the sum paid by him is not a sum chargeable under the Act. The interpretation
of the Department, therefore, not only requires the words “chargeable under the
provisions of the Act” to be omitted, it also leads to an absurd consequence. The
interpretation placed by the Department would result in a situation where even when
the income has no territorial nexus with India or is not chargeable in India, the
Government would nonetheless collect tax. In our view, Section 195(2) provides a
remedy by which a person may seek a determination of the “appropriate proportion
of such sum so chargeable” where a proportion of the sum so chargeable is liable to
tax.” He, thus, submitted that if there was any breach of the said provision, the
Income Tax Department was well within its right to charge interest and/or impose
penalty.
In rejoinder, M/s. Ganesh and Datar gave their answers to the aforesaid submissions,
but it may not be necessary to reproduce the same at this stage as we would like toFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

take note of the same while dealing with the respective submissions.
ANALYSIS, FINDINGS & CONCLUSION We have pondered over the aforesaid
submissions of the learned counsel for the parties with all seriousness and sincerity
they deserve. We have also minutely gone through the material placed on record. We
have kept in mind the governing law that has already been stated in detail. We are
also conscious of the approach that is needed to examine these kinds of issues, as
discussed in the judgments referred to by Mr. Dave. Likewise, we have also
microscopically examined the judgment of the High Court which is under challenge.
As per Article 5 of the DTAA, the PE has to be a fixed place of business ‘through’
which business of an enterprise is wholly or partly carried on. Some examples of fixed
place are given in Article 5(2), by way of an inclusion. Article 5(3), on the other hand,
excludes certain places which would not be treated as PE, i.e. what is mentioned in
clauses (a) to (f) as the ‘negative list’. A combined reading of sub-articles (1), (2) and
(3) of Article 5 would clearly show that only certain forms of establishment are
excluded as mentioned in Article 5(3), which would not be PEs. Otherwise,
sub-article (2) uses the word ‘include’ which means that not only the places specified
therein are to be treated as PEs, the list of such PEs is not exhaustive. In order to
bring any other establishment which is not specifically mentioned, the requirements
laid down in sub- article (1) are to be satisfied. Twin conditions which need to be
satisfied are: (i) existence of a fixed place of business; and (b) through that place
business of an enterprise is wholly or partly carried out.
We are of the firm opinion, and it cannot be denied, that Buddh International Circuit
is a fixed place. From this circuit different races, including the Grand Prix is
conducted, which is undoubtedly an economic/business activity. The core question is
as to whether this was put at the disposal of FOWC? Whether this was a fixed place of
business of FOWC is the next question. We would like to start our discussion on a
crucial parameter viz. the manner in which commercial rights, which are held by
FOWC and its affiliates, have been exploited in the instant case. For this purpose
entire arrangement between FOWC and its associates on the one hand and Jaypee on
the other hand, is to be kept in mind. Various agreements cannot be looked into by
isolating them from each other. Their wholesome reading would bring out the real
transaction between the parties. Such an approach is essentially required to find out
as to who is having real and dominant control over the Event, thereby providing an
answer to the question as to whether Buddh International Circuit was at the disposal
of FOWC and whether it carried out any business therefrom or not. There is an
inalienable relevance of witnessing the wholesome arrangement in order to have
complete picture of the relationship between FOWC and Jaypee. That would enable
us to capture the real essence of FOWC's role.
A mere running of the eye over the flowchart of these commercial rights, produced by
the Revenue, bring about the following material factors, evidently discernible:Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

FIA had assigned commercial rights in favour of FOAM vide agreement dated April
24, 2001 and on the same day another agreement was signed between FOAM and
FOWC vide which these rights were transferred to FOWC. Vide another agreement of
2011, these rights stand transferred in favour of FOWC for a period of 100 years. Vide
Concorde Agreement of 2009, FOWC is authorised to exploit the commercial rights
directly or through its affiliates only. Significantly, this agreement defines ‘F-1
Business’ to mean exploitation of various rights, including media rights, hospitality
rights, title sponsorship, etc. Armed with the aforesaid rights, FOWC signed first
agreement with Jaypee on October 25, 2007 whereby it granted right to promote the
event to Jaypee. This is replaced by RPC dated September 13, 2011. Under this
agreement, right to host, stage and promote the event are given by FOWC to Jaypee
for a consideration of US$ 40 million. On the same day, another agreement is signed
between Jaypee and three affiliates of FOWC whereby Jaypee gives back circuit
rights, mainly media and title sponsorship, to Beta Prema 2 and paddock rights to
Allsports. FOAM is engaged to generate TV Feed. All the revenues from the aforesaid
activities are to go to the said companies, namely, Beta Prema 2, Allsports and FOAM
respectively. These three companies are admittedly affiliates to FOWC.
Though Beta Prema 2 is given media rights, etc., on September 13, 2011, it had
entered into title sponsorship agreement dated August 16, 2011 with Bharti Airtel (i.e.
more than a month before getting these rights from Jaypee) whereby it transferred
those rights to Bharti Airtel for a consideration of US$ 8 million.
Service agreement is signed between FOWC and FOAM on October 28, 2011 (i.e. on
the date of the race) whereby FOAM engaged FOWC to provide various services like
licensing and supervision of other parties at the event, travel and transport and data
support services. The aforesaid arrangement clearly demonstrates that the entire
event is taken over and controlled by FOWC and its affiliates. There cannot be any
race without participating/ competing teams, a circuit and a paddock. All these are
controlled by FOWC and its affiliates. Event has taken place by conduct of race
physically in India. Entire income is generated from the conduct of this event in
India. Thus, commercial rights are with FOWC which are exploited with actual
conduct of race in India.
Even the physical control of the circuit was with FOWC and its affiliates from the
inception, i.e. inclusion of event in a circuit till the conclusion of the event.
Omnipresence of FOWC and its stamp over the event is loud, clear and firm. Mr.
Rohatgi is right in his submission that the undisputed facts were that race was
physically conducted in India and from this race income was generated in India.
Therefore, a commonsense and plain thinking of the entire situation would lead to
the conclusion that FOWC had made their earning in India through the said track
over which they had complete control during the period of race. The appellants are
trying to trivialize the issue by harping on the fact that duration of the event was
three days and, therefore, control, if at all, would be for that period only. His replyFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

was that the duration of the agreement was five years, which was extendable to
another five years. The question of the PE has to be examined keeping in mind that
the aforesaid race was to be conducted only for three days in a year and for the entire
period of race the control was with FOWC.
Even when we examine the matter by examining the RPC agreement itself, it points
towards the same conclusion. The High Court in its judgment has reproduced
relevant clauses of the agreement which we have already reproduced above.
This agreement is analysed by the High Court. Therefore, we are spared of doing a
diagnostic of sorts, which exercise is accomplished by the High Court itself in a
flawless manner:
“(a) The Buddh International Circuit, is defined in Clause 1(q), as one suitable in
every respect for the staging of the event, including permanent buildings, permanent
structure, track laid-out, amenities, spectator viewing facilities, paddock building,
media centre, car parks, helipads, garages, race control and administration, office
administration, fuel and storage, tyre store, utilities, including backup power
supplies, concrete- based areas suitable to host competitors and sponsor, vending
and exhibition areas, international TV compounds etc. These specifications are more
elaborately spelt out in Clause 5(e) which states that a circuit shall be constructed,
laid out and prepared in accordance with the agreement, i.e. RPC, "in a form and
manner approved by the FOWC and the FIA".
(b) The inclusion of the event is through the FOWC's actions. In terms of its
arrangement with the FIA, it is the exclusive agency through which any particular
circuit is introduced for an event in a given calendar year.
(c) The term of the RPC is 5 years according to Clauses 3.3 and 3.4.
(d) In terms of Clause 11, Jaypee is obliged to take all action necessary to ensure that
the pit, paddock buildings and surrounding areas within the circuit and land are open
to receive the competitors, FOWC, affiliates of FOWC, FOWC's contractors and
licensees, other personnel and equipment at all times during the period commencing
14 days before the race and ending 7 days after the race. It also has to assure security
to these areas.
(e) Under Clause 14, the promoter is obliged to authorize access to parts of the circuit
not open to the main public only through passes issued by the FOWC. Under Clause
14(b), the public cannot have access to the cars in any of the places where the
competitor's mechanics may be called upon to work on them and under Clause 14(c),
the validity of passes issued by FOWC is unquestionable.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

(f) Under Clause 18.1, throughout the term during the access period, from the test
session held at the circuit till the end of the event, the promoter, i.e. Jaypee cannot
permit, access, enable, procure or in any manner encourage others to make, create,
store, record or transmit any sound recording or visual or audio-visual footage
whatsoever, for broadcast or any other purpose, of any of at or pertaining to the
event, including cars, drivers, competitors etc. and in fact cannot make any such
recording etc. within the confines of the circuit or the land over which Jaypee itself
has control.
Under Clause 18.2, Jaypee has to ensure that the terms of the ticket sale, giving admittance to the
event include a condition imposed on the ticket holder not to make any kind of recording or take any
recording device that can store or transmit any part of the event and that the ticket holder as a
spectator could be filmed and a sound made by him could be recorded for broadcast or any other
such item that the FOWC could impose on Jaypee.
Jaypee is obliged to engage a third party approved by FOWC to carry out and perform on its behalf
all service relating to the origination of the international television feed and host broadcasting for
each event during the term specified in the guidelines published by FOWC and provided to Jaypee.
Jaypee unconditionally and irrevocably under Clause 19.2 assigned to FOWC all copyright and other
intellectual property rights, titles and interest which it may now or may in future possess, in any
image or recording or other presentation or recording in any image/form whatsoever for the
duration of the rights and also give consent to FOWC to deal with such rights as it pleased.
Clause 20.1 obliged Jaypee to ensure that those accredited and authorized by FOWC were permitted
to enter upon the premises to make sound, television or recordings or transmissions or make films
or other pictures and use the facilities throughout the access period and also undertook to accord to
such personnel all help and facilities that FOWC would require, including assistance for consent,
permission or authorization with any local authority.
Under Clause 21, Jaypee was prohibited from causing, permitting, enabling assisting or in any
manner encouraging display of any advertisement (other than the normal advertisement displayed
on any competitor's cars) or other displays on, near or which could be seen from the circuit or the
land which, in the opinion of the FOWC, could prevent lawful transmission of images or recordings
of the event. FOWC's say in this regard was final.
In the Director?s report of FOWC, the company significantly mentioned that its current company
had entered into an agreement with FIA as a result of which FOWC acquired commercial interests in
the championship which became operative from 01.11.2011 and that in exploitation of such
commercial rights in the championship, the total revenues generated was US$ 1205 million. There is
an express advertence of the Indian part of the turn-over – inasmuch as the report said that the
company paid US$ 127 million to FOM in return of provision of services.” We are in agreement with
the aforesaid analysis which correctly captures the substance of the relevant clauses of the
agreement.Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

We are also of the opinion that the High Court has rightly concluded that having regard to the
duration of the event, which was for limited days, and for the entire duration FOWC had full access
through its personnel, number of days for which the access was there would not make any
difference. This aspect is discussed by the High Court in the following manner, and rightly so:
“52. It is evident that for the duration of the event as well as two weeks prior to it and
a week succeeding it, FOWC had full access through its personnel, the team
contracted to it, both racing as well as spectator teams and could also dictate who
were authorized to enter the areas reserved for it. No doubt, in terms of the
agreement, i.e. RPC, Jaypee was designated as the promoter or the event host. A look
at the RPC and its terms as well as the other terms contained in the agreement
between the Jaypee on the one hand and Allsports, Beta Prema 2 as well as FOAM
show that Jaypee's capacity to act - though it promoted the event, was extremely
restricted. At all material times, FOWC had access - exclusively, to the circuit, and all
the spaces where the teams were located. Jaypee created the circuit for the purposes
of the event and other events; yet, during the event, i.e. the F1 Championship, no
other event was possible.
53. Having regard to the nature of the preceding discussion, it is evident that though
FOWC's access or right to access was not permanent, in the sense of its being
everlasting, at the same time, the model of commercial transactions it chose is such
that its exclusive circuit access - to the team and its personnel or those contracted by
it, was for up-to six weeks at a time during the F1 Championship season. This nature
of activity, i.e racing and exploitation of all the bundle of rights the FOWC had as
CRH, meant that it was a shifting or moving presence: the teams competed in the
race in a given place and after its conclusion, moved on to another locale where a
similar race is conducted. Now with this kind of activity, although there may not be
substantiality in an absolute sense with regard to the time period, both the exclusive
nature of the access and the period for which it is accessed, in the opinion of the
Court, makes the presence of a kind contemplated under Article 5(1), i.e. it is fixed. In
other words, the presence is neither ephemeral or fleeting, or sporadic. The fact that
RPC-
2011's tenure is of five years, meant that there was a repetition; furthermore, FOWC was entitled
even in the event of a termination, to two years' payment of the assured consideration of US$ 40
million (Clause 24 of the RPC). Having regard to the OECD commentary and Klaus Vogel's
commentary on the general principles applicable that as long as the presence is in a physically
defined geographical area, permanence in such fixed place could be relative having regard to the
nature of the business, it is hereby held that the circuit itself constituted a fixed place of business.
A stand at a trade fair, occupied regularly for three weeks a year, through which an enterprise
obtained contracts for a significant part of its annual sales, was held to constitute a PE[23].
Likewise, a temporary restaurant operated in a mirror tent at a Dutch flower show for a period of
seven months was held to constitute a PE[24].Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

The High Court has also referred to some of the judgments which are of relevance. We would like to
take note of those judgments as we had agreed with the conclusions of the High Court on this issue:
In Universal Furniture Ind. AB v. Government of Norway[25], a Swedish company
sold furniture abroad that was assembled in Sweden. It hired an individual tax
resident of Norway to look after its sales in Norway, including sales to a Swedish
company, which used to compensate him for use of a phone and other facilities.
Later, the company discontinued such payments and increased his salary. The
Norwegian tax authorities said that the Swedish company had its place of business in
Norway. The Norwegian court agreed, holding that the salesman’s house amounted
to a place of business: it was sufficient that the Swedish Company had a place at its
disposal, i.e the Norwegian individual’s home, which could be regarded as ‘fixed’.
In Joseph Fowler v. Her Majesty the Queen[26], the issue was whether a United
States tax resident individual who used to visit and sell his wares in a camper trailer,
in fairs, for a number of years had a fixed place of business in Canada. The fairs used
to be once a year, approximately for three weeks each. The court observed that the
nature of the individual’s business was such that he held sales in similar fares, for
duration of two or three weeks, in two other locales in the United States. The court
held that conceptually, the place was one of business, notwithstanding the short
duration, because it amounted to a place of management or a branch having regard to
peculiarities of the business.
Coming to the second aspect of the issue, namely, whether FOWC carried on any
business and commercial activity in India or not, substantial part of this aspect has
already been discussed and taken care of above. Without being repetitive and
pleonastic or tautologous, we may only add that FOWC is the Commercial Right
Holder (CRH). These rights can be exploited with the conduct of F-1 Championship,
which is organised in various countries. It was decided to have this championship in
India as well. In order to undertake conducting of such races, the first requirement is
to have a track for this purpose. Then, teams are needed who would participate in the
competition. Another requirement is to have the public/viewers who would be
interested in witnessing such races from the places built around the track. Again, for
augmenting the earnings in these events, there would be advertisements, media
rights, etc. as well. It is FOWC and its affiliates which have been responsible for all
the aforesaid activities. The Concorde Agreement is signed between FIA, FOA and
FOWC whereby not only FOWC became Commercial Rights Holder for 100 years,
this agreement further enabled participation of the teams who agreed for such
participation in the FIA Championship each year for every event and undertook to
participate in each event with two cars. FIA undertook to ensure that events were
held and FOWC, as CRH, undertook to enter into contracts with event promoters and
host such events. All possible commercial rights, including advertisement, media
rights, etc. and even right to sell paddock seats, were assumed by FOWC and its
associates. Thus, as a part of its business, FOWC (as well as its affiliates) undertookFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

the aforesaid commercial activities in India. Without explaining this aspect further,
our purpose would be served by reproducing the following discussion, so starkly put
in the judgment of the High Court:
“55. If the terms of the Concorde Agreement are read conjointly with the RPC-2011, it
is apparent that the CRH, which is the FOWC, only and none else has the right to
include a venue in any FIA annual calendar. FIA is bound to accord permission for
such inclusion; FOWC is the exclusive commercial rights holder of a host of rights
(evident from the recital in the Concorde Agreement that FIA, FOWC and other
members of the CRH group had entered into such contracts to enable commercial
exploitation of the rights for a 100 year period). Under the RPC-2011, only FOWC has
exclusive rights towards making sound, television and other recordings and
exploitation of its media rights. FOWC has copyright over databases and all related
information, etc. generated, during the event, including practice sessions etc. (Clause
22, RPC-2011). Only those accredited by FOWC can enter the promoter's premises
and circuit to make sound and television recordings, etc.
56. It is quite apparent that save a limited class of rights (those relating to paddock
entry, ticketing, hospitality at the venue and a restricted class of advertising), all
commercial exploitation rights vest exclusively with FOWC. FOWC did accept them
and was entitled to charge fees or such other consideration as it deemed appropriate
for the recording, telecasting, broadcasting and creation of internet and media rights,
including data transmission, and all other such commercially exploitable rights. In
addition, FOWC charged, by Clause 24 of RPC-2011, a fee of US$ 40 million annually
from Jaypee, in relation to the race event or FIA F1 Championship event conducted
on the circuit in India.
57. It is also noteworthy that by virtue of the Concorde Agreement, the teams have
undertaken to engage in every race - with the added condition that each team would
involve two cars for every race in any circuit chosen by FOWC. RPC-2011 also assured
that the FOWC would ensure that such team did in fact participate in the event in the
Budh Circuit. This is an important fact- which shows that the entire event, i.e. F1 FIA
Championship in the circuit was organized and controlled in every sense of the term
by FOWC. The peculiarity of this activity is such that FOWC's dominant role is
evident; it is the moving spirit with all pervasive presence and control through the
teams, which are contracted to participate in the event. In fact, it creates the event,
i.e. the race. Each actor, such the promoter/Jaypee, the racing teams, the
constructing teams and the other affiliates, plays a part in the event. FOWC's
participation and the undertakings given to it by each of these actors, who are
responsible for the event as a whole, brings out its central and dominant role. If
Jaypee is the event promoter, which owns the title to the circuit in the sense that it
owns the land, FOWC is the commercial rights owner of the event, by virtue of the
Concorde Agreement. FIA parted with all its rights over each commercial right it
possessed to FOWC. The bulk of the revenue earned is through media, television andFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

other related rights. The terms or the basis of those rights is the event. The
conceptualization of the event and the right to include it in any particular circuit,
such as Buddh Circuit is that of the FOWC; it decides the venue and the participating
teams are bound to it to compete in the race in the terms agreed with the FOWC. All
these, in the opinion of the Court, unequivocally, show that the FOWC carried on
business in India for the duration of the race (and for two weeks before the race and a
week thereafter). Every right, which it possessed was monetized; the US$ 40 million
which Jaypee paid was only a part of that commercial exploitation by the FOWC.
58. Consequently, the Court concludes that the FOWC carried on business in India
within the meaning of expression under Article 5(1) of the DTAA. It is consequently
held that the AAR fell into error of law in holding that FOWC did not function
through a PE/carry on business through a fixed place of business in India.” In view of
the above, it is difficult to accept the arguments of the appellants that it is Jaypee who
was responsible for conducting races and had complete control over the Event in
question. Mere construction of the track by Jaypee at its expense will be of no
consequence. Its ownership or organising other events by Jaypee is also immaterial.
Our examination is limited to the conduct of the F-1 Championship and control over
the track during that period. Specific arrangement between the parties relating to the
aforesaid, which is elaborated above and which FOWC and Jaypee unsuccessfully
endeavoured to ignore, has in fact turned the table against them. It is also difficult to
accept their submission that FOWC had no role in the conduct of the Championship
and its role came to an end with granting permission to host the Event as a round of
the championship. We also reject the argument of the appellants that the Buddh
International Circuit was not under the control and at the disposal of FOWC.
No doubt, FOWC, as CRH of these events, is in the business of exploiting these rights, including
intellectual property rights. However, these became possible, in the instant case, only with the actual
conduct of these races and active participation of FOWC in the said races, with access and control
over the circuit.
We are of the opinion that the test laid down by the Andhra Pradesh High Court in Visakhapatnam
Port Trust case fully stands satisfied. Not only the Buddh International Circuit is a fixed place where
the commercial/economic activity of conducting F-1 Championship was carried out, one could
clearly discern that it was a virtual projection of the foreign enterprise, namely, Formula-1 (i.e.
FOWC) on the soil of this country. It is already noted above that as per Philip Baker[27], a PE must
have three characteristics: stability, productivity and dependence. All characteristics are present in
this case. Fixed place of business in the form of physical location, i.e. Buddh International Circuit,
was at the disposal of FOWC through which it conducted business. Aesthetics of law and taxation
jurisprudence leave no doubt in our mind that taxable event has taken place in India and
non-resident FOWC is liable to pay tax in India on the income it has earned on this soil.
We are now left with two other incidental issues which were raised by Mr. Datar. First was on the
interpretation of Section 195 of the Act. It cannot be disputed that a person who makes the paymentFormula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

to a non-resident is under an obligation to deduct tax under Section 195 of the Act on such
payments. Mr. Rohatgi had submitted, and rightly so, that this issue is covered by the judgment in
the case of GE India Technology Centre Private Limited[28]. Precisely this very judgment is taken
note of and relied upon by the High Court also in holding that since payments made by Jaypee to
FOWC under the RPC were business income of the FOWC through PE at the Buddh International
Circuit, and, therefore, chargeable to tax, Jaypee was bound to make appropriate deductions from
the amounts paid under Section 195 of the Act.
We are, however, inclined to accept the submission of Mr. Datar that only that portion of the income
of FOWC, which is attributable to the said PE, would be treated as business income of FOWC and
only that part of income deduction was required to be made under Section 195 of the Act. In GE
India Technology Centre Private Limited[29], this Court has clarified that though there is an
obligation to deduct tax, the obligation is limited to the appropriate portion of income which is
chargeable to tax in India and in respect of other payments where no tax is payable, recourse is to be
made under Section 195(2) of the Act. It would be for the Assessing Officer to adjudicate upon the
aforesaid aspects while passing the Assessment Order, namely, how much business income of
FOWC is attributable to PE in India, which is chargeable to tax. At that stage, Jaypee can also press
its argument that penalty etc. be not charged as the move on the part of Jaypee in not deducting tax
at source was bona fide. We make it clear that we have not expressed any opinion either way.
Insofar as the argument of Mr. Datar on the powers of the High Court under Article 226 of the
Constitution of India is concerned, we are not impressed by the said argument. It is Jaypee itself
which had filed the writ petition (and for that matter FOWC as well) and they had challenged the
orders of AAR on certain aspects. The High Court has examined legal issues while delivering the
impugned judgment, of course having regard to the facts which were culled out from the documents
on record.
In view of the foregoing, the appeals preferred by the FOWC and Jaypee are dismissed, subject to
observations as made above.
Insofar as the appeal filed by the Commissioner of Income Tax is concerned, it was submitted by Mr.
Rohatgi himself that the issue of dependent PE had become academic. Therefore, we need not
examine this issue and dispose of the appeal of the Revenue accordingly.
No costs.
.................J. (A.K. SIKRI) ................J. (ASHOK BHUSHAN) NEW DELHI;
APRIL 24, 2017.
-----------------------
[1] (1983) 144 ITR 146 [2] Transvaal Associated Hide & Skin Merchants (Pty) Ltd. (1967) 29 S.A.T.C.
97 (Court of Appeal, Botswana).Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

[3] Georges Simenon (1965) 44 T.C. (US) 820 (US Tax Court) [4] Joseph Fowler v. M.N.R. (1990)
90 D.T.C. 1834; (1990) 2 C.T.C. 2351 (Tax Court of Canada) [5] Antwerp Court of Appeal, decision of
February 6, 2001, noted in 2001 WTD 106-11 [6] Income Tax Appeals Nos. 759/KB to 761/KB of
1997-98 (Tarom SA), (1998) PTD (Trib.) 3749 (Income-tax Appellate Tribunal, Pakistan) [7]
Consolidated Premium Iron Ores Ltd. (1959) 265 F 2d. 320 [8] Tekniskil (Sendirian) Bhd. v.
Commissioner of Income Tax, (1996) 222 I.T.R. 551 (Authority for Advance Rulings, India) [9]
Lower Tax Court of the Hague, September 10, 1990, noted in (1991) Tax Notes Intl. 161 [10] Deputy
Commissioner of Income Tax v. Subsea Offshore Ltd. (1998) 66 I.T.D. 296 (Income Tax Appellate
Tribunal, Mumbai), noted in 17 Tax Notes Intl. 1795 [11] (1999) 99 DTC 147 [12] Bundersfinanzhof,
February 3, 1993, IR 80-81/91, IStR 1993, p. 226, (1993) BStBl., II, 462.
[13] Decision of the Lower Tax Court of Baden-Wurttemberg, May 11, 1992, decision No. 3K 309/91,
RIW 1993, 81, IStR 1992, p. 104 [14] Decision of November 10, 1998, (199) Revue de Droit Fiscal,
No. 25, comm.. 503, reported with translation in (1998) 1 ITLR 857 [15] Cour de Cassation of
February 15, 1980 (1980) J1. De Droit Fiscal 321.
[16]    2004 (10) SCC 1 = 2003 (262) ITR 706
[17]    (1980) Supp SCC 614 = 1981 AIR 148
[18]    (2010) 10 SCC 29
[19]    1970 (3) SCC 400
[20]    2003 (3) AllER 304
[21]        (2012) 11 SCC 224
[22]        (2010) 10 SCC 29
[23]        Refer Footnote 4
[24]  Refer Footnote 5
[25]        (Stavanger Court, Case No. 99-00421, dated  19-12-1999  referred
to in Principles of International Taxation by Anghard Miller and Lyn Oates, 2012) [26] 1990 (2) CTC
2351 [27] A Manual on the OECD Model Tax Convention on Income and on Capital [28] Refer
Footnote 23 [29] Refer Footnote 23Formula One World Championship Ltd vs Commissioer Of Income Tax, ... on 24 April, 2017

