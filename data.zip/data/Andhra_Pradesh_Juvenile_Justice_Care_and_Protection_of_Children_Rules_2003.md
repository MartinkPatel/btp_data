Andhra Pradesh Juvenile Justice (Care and Protection of
Children) Rules, 2003
ANDHRA PRADESH
India
Andhra Pradesh Juvenile Justice (Care and
Protection of Children) Rules, 2003
Rule
ANDHRA-PRADESH-JUVENILE-JUSTICE-CARE-AND-PROTECTION-OF-CHILDREN-RULES-2003
of 2003
Published on 29 April 2003• 
Commenced on 29 April 2003• 
[This is the version of this document from 29 April 2003.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003Published vide
Notification No. G.O. Ms. No. 21, Women Development, Child Welfare and Disabled Welfare (JJ),
dated 29.04.2003Last Updated 13th August, 2019G.O. Ms. No. 21. - In exercise of the powers
conferred by sub-section (1) of Section 68 of the Juvenile Justice (Care and Protection of Children)
Act, 2000 (Central Act No.56 of 2000) and in supersession of the Rules issued in G.O.Ms. No. 441,
Home (Prisons-D) Department dated the 26th September, 1987 and published in Rules Supplement
to Part-I Extraordinary of the Andhra Pradesh Gazette, dated the 2nd October, 1987 the Governor of
Andhra Pradesh hereby makes the following Rules.
Chapter I
1. Short title and commencement.
(1)These Rules may be called the Andhra Pradesh Juvenile Justice (Care and Protection of Children)
Rules, 2003.(2)These Rules shall come into force on the date of publication in the Official Gazette.
2. Definitions.
- In these Rules, unless the context otherwise requires -(1)'Act' means the Juvenile Justice (Care and
Protection of Children) Act, 2000 (Central Act 56 of 2000).(2)'Adoption' means taking the child into
the family of the adoptive parent/ parents as their child, for all purposes, with all the rights of a
natural born child in the adoptive family.(3)'Co-management' means the joint management of theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

Institutions under the Act by the Government and the voluntary sector in all aspects, to achieve the
objects of the Act.(4)'Commissioner' means the head of the department of Juvenile Welfare,
Correctional Services and Welfare of Street Children.(5)'Form' means the form annexed to these
Rules.(6)'Home Committee', 'Working Committee' and 'Executive Committee' are the various
Committees constituted under Rule 38 for implementing co-management.(7)'Institution' for the
purpose of these Rules, means an Observation Home or a Special Home or a Children's Home set up
under Sections 8, 9 and 34 of the Act.(8)'NGO' means a Non Governmental
Organisation.(9)'Principles' mean the principles shown in Schedule I, which are fundament-to the
development of strategies, interpretation and implementation of the Act and the
Rules.(10)'Secondary Victimisation' means and refers to behaviour and attitudes of persons in the
Juvenile Justice System, which further traumatises victims who are within the Juvenile Justice
System.(11)'Section' means a Section of the Act.(12)'Superintendent' means a person appointed for
the control and management of an institution, certified or recognised as such under the Act.(13)All
words and expressions defined In the Act, but not defined in these Rules, shall have the same
meaning as assigned to them in the Act.
Chapter II
Children in Conflict With Law
3. Juvenile Justice Board.
(1)The Juvenile Justice Board shall consist of the following members:(a)a Metropolitan Magistrate
or a Judicial Magistrate of the First Class called the Principal Magistrate, and(b)two social workers,
of whom at least one shall be a woman, with the qualifications prescribed under Section 4 of the
Act.(2)(a)Magistrates with the necessary aptitude and special knowledge/ training in child
psychology or child welfare shall be appointed as Principal Magistrates of the Juvenile Justice
Boards by the State Government in Consultation with the High Court (b) In case, a Principal
Magistrate with such special knowledge and training is not available, the State Government shall
provide for suitable short-term training.(3)The Social Worker Members of the Board shall be
appointed by the State Government on selection by the Selection Committee under Rule 49.(4)The
Members shall have a tenure of three years.(5)The Board shall hold its sittings in the premises of the
Observation Home and shall meet on all the working days of a week. The working hours shall be
fixed by the Board, as per the work load.(6)A Member may resign at any time by giving one month's
notice in writing or may be removed from office as provided under Section 4 (5) of the Act.(7)Social
Worker members of the Juvenile Justice Board shall be paid such travelling and meeting allowance
or honorarium as the State Government may fix from time to time.
4. Procedure to be followed by Juvenile Justice Board in holding inquiries.
(1)In all cases under the Act, the proceedings shall be conducted in as simple a manner as possible.
There shall be no raised dais, witness box etc. Care shall be taken to ensure that the child against
whom the proceedings have been instituted is given a home-like atmosphere during the
proceedings. The procedure prescribed under Section 5(2), (3) and (4) of the Act shall be followedAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

by the Board.(2)When witnesses are produced for examination, the Board shall make free use of the
power conferred on it by Section 165 of the Indian Evidence Act, 1872, to so question them as to
bring out any point that may go in favour of the child.(3)In examining a child, the Board shall put
the child at ease and elicit the facts, not only in respect of the offence of which the child is accused,
but also in respect of the home, social surroundings, the influences to which the child has been
subjected to and the conditions under which the offence has been committed and pass appropriate
orders in the light of the enquiry and the alternatives indicated in Section 15(1), in the best interests
of the child. The record of the examination shall be in such form as the Board may consider
suitable.(4)In case the Board orders a child to be sent to a Special Home, the Board shall record its
reasons in its Judgment as to why the other alternatives in Section 15(1) are not in the best interests
of the child.(5)In accordance with Sub-section (2) of Section 15, the Board shall order a Probation
Officer, or other person to conduct a social investigation and report on the character and
antecedents of the child to enable it to pass appropriate orders in the case. The order of the Board
shall as far as possible be in Form 1.(6)The Board shall maintain a list of experts in the field of
psychology, counselling and guidance, psychiatric institutions etc., who are willing to provide such
services to the Board. This list shall be prepared in consultation with the Commissioner, the
Department of. Health and Academic Institutions. When the Board feels that a child requires
psychological/psychiatric evaluation, the child shall be referred to these experts, for their opinion,
which shall be duly considered by the Board, in disposing of the case.(7)The State Government shall
recognise registered voluntary organisations, which can provide the services of probation and
counselling to submit periodical reports as directed by the Board regarding the orders passed under
Section 15.(8)In every case concerning a child, the Board shall obtain a birth certificate, if any, or
medical opinion regarding his or her age and his or her physical and mental conditions or such
other evidence and when passing orders in such case shall, after taking into consideration the
evidence available, record a finding in respect of the child's age.(9)When a child is placed under the
care of a parent or a guardian and the Board deems it expedient to place the child under the
supervision of a probation officer, it shall issue a supervision order in Form II.(10)Whenever a child
is ordered to be released on probation or for doing community service or to participate in group
counselling or similar activities, the Board shall direct the Probation Officer to monitor the child's
activities and report the same to the Board, regularly. The probation conditions shall be specific and
not general.(11)The Board shall maintain a list of NGOs, Fit Persons and Fit Institutions for the
purpose of providing care and supervision during the period of bail, probation or on community
service.(12)Whenever the Board orders a child to be kept in an Institution, it shall forward to the
Superintendent of the Institution a copy of its order in Form III with such particulars of the home
and parents or guardian and previous record of the child as are available.(13)Whenever the Board
orders the transfer of a child, the Superintendent of the Institute where the child is staying, shall
provide the necessary escort for the child without any delay.(14)The child should be lodged in the
Institution closest to the place he/she belongs to.(15)In case the Board orders the payment of any
fine, the same shall be deposited in the Government Treasury.
5. Special Juvenile Police Unit and Child Welfare Officer.
(1)The State Government shall appoint Special Juvenile Police Units at the district level and a Child
Welfare Officer shall be designated in terms of Section 63 of the Act at the level of policeAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

station.(2)The Special Juvenile Police Unit shall function under a Police Officer, with necessary
aptitude and training, of the rank of Inspector of Police and two social workers of whom one shall be
a woman and another preferably a person having a good track record of working with children. The
Social Workers shall be paid such honorarium as the State Government may fix from time to
time.(3)The Special Juvenile Police Unit/Child Welfare Officer shall be assisted by recognised
voluntary organisations, which will help them in identifying the children and help the children in
conflict with law.
6. Production of a child.
(1)When a child in conflict with law is apprehended by the Police, the police shall immediately place
the child under the charge of the Special Juvenile Police unit or the designated police officer. The
jurisdiction and powers of the police shall be limited to placing the child under the charge of Special
Juvenile Police unit or the Child Welfare Officer, who will in turn take up the investigation.(2)The
Special Juvenile Police unit/the Child Welfare Officer to whom the child is brought, shall inform the
probation officer concerned of the same and obtain information regarding the antecedents and
family background of the child and other material circumstances likely to be of assistance to the
Board for making the inquiry. Such information shall be placed before the Board at the time of
enquiry by the Board. The Special Juvenile Police unit/the Child Welfare Officer shall try to contact
the parent/guardian of the child and inform them of the apprehension of the child and that they can
be present before the Board, where the child is due to appear and inform them of the time, date and
venue of the hearing.(3)The Special Juvenile Police Unit or the Child Welfare Officer shall produce
the child before the Magistrate or a Member of the Board as early as possible, but not later than 24
hours of his/her apprehension (excluding the time taken to bring the child from the police
station/place of safety to the Board).(4)Prior to production of a child before the Board, the child
may be placed in a 'Place of safety' or a safe place within the Police Station (which shall not be a
lockup).(5)The State Government shall recognise only such voluntary organisations which can
provide the services of probation, counselling, case work, a place of safety and also associate with
the Special Juvenile Police Unit, for the purpose of producing a child before the Board under Section
10(2).(6)The recognised voluntary organisation shall prepare a report narrating the circumstances
of apprehending the child and the offence alleged to have been committed by the child and produce
the child before the Board along with the report, within 24 hours of being apprehended, excluding
journey time.(7)When a child is produced before an individual member of the Board, the order given
by the member shall be subject to its ratification in the next meeting of the Board.(8)The police /
recognised voluntary organisation shall be responsible for the safety and providing basic amenities
to the child apprehended or kept under their charge during such period of keeping the child under
their charge.(9)While dealing with children under the provisions of the Act or these Rules, except at
the time of apprehending the child, the Police Officers shall wear plain clothes and not the police
uniform.(10)The Board shall satisfy itself that the child has not been subject to any ill treatment by
the police or by any other person and take corrective steps in case of such ill treatment.(11)No child
shall be handcuffed or fettered.(12)Any police officer found guilty, after due enquiry, of torturing a
child, mentally or physically, shall be liable to be removed from service, besides being prosecuted for
the offence.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

7.
To augment the existing probation services, probation officers may be temporarily appointed from
voluntary organisations and social workers found fit for the purpose by the Competent Authority/
Commissioner and paid such honorarium as the State Government may fix from time to time.
Chapter III
Child Welfare Committee
8. Objectives and Procedures in relation to the Committee.
(1)Restoration of the child to the child's parent/guardian/Fit person/Fit Institution, as the case may
be, and protection to the child shall be the prime objective of the Child Welfare Committee.(2)The
Child Welfare Committee shall consist of five Members as prescribed under Section 29.(3)The
Qualifications of the Members of the Committee shall be as prescribed in Rule 50.(4)The Committee
shall hold its sittings in the premise of a Children's Home and shall meet at least twice a
week.(5)The Proceedings shall be conducted in as simple manner as possible. There shall be no
raised dais, witness box etc. Care shall be taken to ensure that the child is put at ease and given a
home like atmosphere during the sittings.(6)The Committee shall satisfy itself that the Child has not
been subjected to any ill treatment by the police or by any other person and take corrective steps in
case of such ill treatment.(7)When a child is brought before the Committee, the Committee shall
assign the case to a social worker/case worker/child welfare officer/ Superintendent, as the case
may be, of the Home or any appropriate recognised agency for conducting inquiry.(8)The direction
for the inquiry under sub-rule (5) above, must be in the prescribed Form I.(9)The final disposal of a
case shall be by the order of at least two members of the Committee. The Committee shall take into
consideration the age, physical and mental health, opinion of the child and the recommendation of
the caseworker, prior to such disposal.(10)After completion of the inquiry, if the child is under
orders to continue in the Children's Home, the Committee shall carry out a half-yearly review of the
progress of the child in the Home and continue the efforts to trace the parent/ guardian of the child.
9. Production of a child before the Committee.
(1)When any person/organisation authorised under Section 32 receives a child in need of care and
protection, he/she/they may also produce the child before the Committee with the report of the
circumstances under which the child came to their notice.(2)In case the Committee is not sitting, the
child may be produced before any member or kept in a place of safety and provided with all basic
facilities and adequate protection. Every possible effort shall be made to trace and associate the
family and assistance of recognised voluntary organisation/ child line may also be taken.(3)In case,
a recognised voluntary organisation takes a child to the Committee, they shall submit a report on the
circumstances under which the child came to their notice, and efforts shall be made by them for
tracing the family.(4)The Committee shall make arrangements to send the child to the designated
place of safety, with appropriate facilities considering the age and sex of the child, pending
inquiry.(5)The child may be escorted by the police officer, representative of the voluntaryAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

organisation or by any other arrangement deemed appropriate by the Committee.(6)Names and
addresses of all recognised Children's Homes along with their capacities and facilities should be
listed with the Committee.(7)A child should be lodged in a Home closest to where he/she belongs.
10. Transfer.
(1)During the enquiry, if it is found that a child hails from a place out side the jurisdiction of the
Committee, the Committee shall order the transfer of the child to the Competent Authority having
jurisdiction over the place of residence of the child. The Committee instead of transferring the child,
may however exercise its discretion under Section 50 and Rule 11.(2)No transfer shall ordinarily be
proposed on the ground that the child has created problems or is difficult to be managed in the
existing institution.(3)On receipt of transfer order from the Competent Authority, the
Superintendent shall promptly arrange to escort the child at Government cost to the place/person as
specified in the order. The Superintendent shall send the child's case file and records along with the
child, while retaining a copy of the same.
11. Procedure for sending a child outside the jurisdiction of the competent
authority.
(1)In the case of a child, whose ordinary place of residence lies outside the jurisdiction of the
competent authority and if the competent authority deems it necessary to take action under Section
50 it shall direct a Probation Officer to make enquiries as to the fitness and willingness of the
relative or other person to receive the child at the ordinary place of residence and whether such
relative or other fit person can exercise proper care and control over the child.(2)On being satisfied,
on the report of the Probation Officer/Case Worker/Child Welfare Officer as the case may be, the
competent authority may send the child, if necessary on execution of a bond by the child as early as
possible in Form V to the said relative or fit person. The said relative or fit person shall give an
undertaking in Form VI.(3)A copy of the order passed by the competent authority under Section 50
shall be sent to:(a)the Probation Officer who was directed to submit a report under sub-rule
(1)(b)the Probation Officer, if any, having jurisdiction over the place where the child is to be
sent.(c)the competent authority having jurisdiction over the place where the child is to be sent
and(d)the relative or the persons who is to receive the child.(4)Any breach of a bond or undertaking
or of both given under sub-rule (2) above shall render the child liable to be brought before the
competent authority, who may make an order directing the child to be sent to the concerned
institution.(5)In the case of child where the competent authority deems it expedient to send the
child back to his/her ordinary place of residence under Section 50, the competent authority shall
inform the relative or the fit person who is to receive the child accordingly and shall invite the said
relative or fit person to come to the Home to take charge of the child on such date as maybe
specified by the competent authority.(6)The competent authority inviting the said relatives or fit
person under sub-rule (5) may also direct, if necessary, the payment to be made by the
Superintendent of the Home of the actual expenses of the relative or fit person's journey both ways
by the appropriate class and the child's journey from the Home to his/her ordinary place of
residence at the time of sending the child.(7)If the relative or the fit person fails to come to take
charge of the child on the specified date, the escort shall take the child to his/her ordinary place ofAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

residence. In the case of a girl, at least one escort shall be a female.(8)Any child who is a foreign
national and who has lost contact with the family shall be repatriated at the earliest to the child's
country in co-ordination with the Ministry of External Affairs and the respective Embassy or High
Commission through the Commissioner, on the direction of the Competent Authority.
Chapter IV
Institutions Under the Act
12. Duties and Responsibilities of the Staff.
(1)All the staff of the Institution shall work for the all-round development and well being of the
children. The staff shall so conduct themselves that they are good role models for the
children.(2)The staff should strive to help the children to be an asset to the Nation.(3)The staff
should treat the children humanely and not with contempt. Any staff member contravening this
sub-rule will be liable for a major penalty.(4)In addition to the above duties, the other duties of each
category of staff, are prescribed in Schedule-3.
13. Observation Homes-Establishment, Management, Procedures, Services.
(1)The objectives of the Observation Home, to which children undergoing trial are sent are:(a)to
counsel the child and the parent or guardian, to help the child to grow up as a good citizen;(b)to
provide and facilitate useful skills including education and vocational training in the Observation
Home;(c)to provide for the child continuing the education, vocational training etc., after leaving the
Observation Home by networking with other Agencies, Fit Institutions, Fit Persons, the community
etc:(d)to inculcate self discipline and emotional stability in the child and(e)to help in the all round
development of the child.(2)The child shall initially be accommodated in a reception unit and later
segregated as per age, as required under Section 8(4) and separated from old acquaintances and bad
influences.(3)In respect of newly admitted children, the name and address of the parent/ guardian
of the child shall be ascertained and they shall immediately be informed of the detention of the
child.(4)The procedure prescribed in Schedule 4 shall be followed in respect of newly admitted
children.(5)A schedule of orientation for the newly admitted child shall be followed
for:(a)Counselling the child and parent/ guardian.(b)Self-improvement opportunities, short-term
vocational training, academic education and a library.(c)Institutional discipline, standards of
behaviour, respect for elders, teachers etc.,(d)Health, sanitation, hygiene.(6)A case history of the
child admitted to an institution shall be maintained continuously which may give information
collected through available sources, including home, parents or guardians, employer, school, friends
and community. The educational level a vocational aptitude of the child may also be assessed. The
appropriate linkages may also be established with outside specialists and community based welfare
agencies, psychologist, psychiatrist, child guidance clinic hospital and local doctors, open school,
Jan Shikshana Samasthan etc. Acare and rehabilitation plan for each child shall be drawn by the
case Worker and placed before the Monitoring and Evaluation Committee.(7)All residents in the
Observation Home shall be given work like:(a)Self-help in maintaining their own
establishment:(b)Cleaning of open spaces and gardening(c)Preliminary operations for crafts.(8)TheAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

Superintendent shall supervise, advise and ensure control over the above issues and record the same
in the Daily Journal
14. Special Home-Establishment, Management and Service.
(1)The objectives of the Special Home are:(a)to provide and facilitate academic education and
vocational training to the child;(b)to inculcate self discipline and emotional stability in the
child;(c)to help in the all round development of the child:(d)to ensure that the child becomes self
reliant on his or her discharge from the Special Home.(e)to provide for the child continuing the
education, vocational training etc., after leaving the Observation Home by networking with other
Agencies, Fit Institutions, Fit Persons, the community etc;(2)The State Government/Voluntary
Organisations shall set up separate Homes for children in conflict with law in the manner prescribed
below:(a)While children of both sexes below 10 years may be kept in the same Home, separate
facilities shall be maintained for boys and girls above 7 years of age.(b)Separate Special Homes
should be set up for boys and girls in the age group of 10-18 years.(c)The procedure prescribed in
Schedule-4 shall be followed in respect of newly admitted children.(3)Each Special Home shall be a
comprehensive child-care centre. The centre should promote an integrated approach to child-care
by involving the community and local NGOs. The activities of the centre should include establishing
linkages with organisations and individuals who can provide support services to children. These
centres should encourage volunteers to provide for various services for children and their
families.(4)Each Special Home shall have the facilities as prescribed in Schedule - 5.(5)The Special
Home shall provide:(a)Education. - The Home shall provide education to all children according to
the age and ability, either both inside the Home or outside, as per the requirement.(b)Vocational
Training. - Each Home shall facilitate useful vocational training under the guidance of trained
instructors. The Home shall develop networking with Institute of Technical Instruction (ITI), Jan
Shikshan Sansthan, Community Polytechnic schemes, Government and private organisation/
enterprises, agencies/NGOs with expertise, or placement agencies.(c)Counselling. - Each Home
shall have the services of a trained Counsellor. Services of Child Guidance Centre, Psychology and
Psychiatric Departments or similar agency may also be availed of.(d)Recreation facilities. - It must
include indoor and outdoor games, music, news papers, picnics and outings, cultural programmes
etc., on a regular basis.(6)Visitors are allowed to visit Observation Homes and Special Homes with
the permission of the Commissioner/ Superintendent of the Home/Home Committees.
15. Children's Home - For Children In Need of Care and Protection
-Establishment, Management and Services.
(1)The objective of the Children's Home is to restore the child to the parent/ guardian. The child and
parent/ guardian shall be appropriately counselled for the effective reintegration of the child with
the family. Where it is not practicable to restore the child to the parent/ guardian, the child shall be
provided all facilities for the child's all-round development, education, vocational training and
inculcating self-discipline and emotional stability in the child, to make the child self-reliant on
leaving the children's Home. The emphasis in the Children's Home shall be on the reintegration of
the child with the family and the all-round development of the child and not on the child's detention
in the Home. The Home shall also net work with other agencies to help in the child's education,Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

vocational training etc.(2)As soon as a child in need of care and protection is brought to a Children's
Home, every effort should be made to ascertain the name and address of the parent/guardian of the
child. The Case Worker and the NGOs working with the children should try to contact the
parent/guardian of the child directly, or through the local networks, police, child line as well as
through the District Probation Officer and the intake procedure in sub-rule (5) (c) of Rule 14 be
followed. The child should be counselled to rejoin the parent or the guardian. During the
interregnum, the newly admitted child should be placed in a reception unit and should be given
short-term vocational training as well as academic education appropriate to the child's age.(3)The
State Government/Voluntary Organisations shall set up separate Homes for children in need of care
and protection, in the manner prescribed below:(a)While children of both sexes below 10 years may
be kept in the same Home, separate facilities shall be maintained for boys and girls above 5 years of
age.(b)Separate Children's Homes should be set up for boys and girls in the age group of 10-18
years.(4)Each Children's Home should be a comprehensive child care centre. The Home should
promote an integrated approach to child care by involving the community and local NGOs. The
activities of the centre should include:(a)family based services such as foster family care, adoption
and sponsorship;(b)linking up with Integrated Child Development Services (ICDS) to cater to the
needs of children below 6 years.(c)to establish linkages with organisations and individuals who can
provide support services to children.(5)The procedure to be followed and the facilities to be
provided in the Children's Homes.(a)Physical Infrastructure. - It should include separate facilities
for children in the age group of 0-5 years with appropriate facilities for the infants. Separate
facilities for children in the above age of 5 years and below the age of 10 years having different
dormitories for boys and girls. The standard of accommodation as prescribed in Rule 24 shall apply.
There should be adequate lighting, ventilation, heating and cooling arrangements, drinking water
and toilets.(b)The Children's Home shall also have the facilities prescribed in Schedule - 5 and
under Rule 14(5)(c)Intake Procedure. - Every new child who is brought to the Home, shall
immediately be taken charge of by the counsellor/child welfare officer/designated officer/Home
Committee, as the case may be. The child shall be received with due care. A brief orientation shall be
given to the child on induction to remove any inhibition from the mind of the child. The child shall
immediately be given bath, clothing, food etc., and medically examined. The name of the child shall
be entered in the Admission Register and appropriate accommodation be allocated to be child. The
further procedure prescribed in Schedule 4 shall be followed.(d)Visitors are allowed to visit the
Home with the permission of the Commissioner/Superintendent of the Home/Home
Committees.(e)The Superintendent/Project Manager shall maintain a Visitors' Book. The remarks
of the visitors shall be considered by the Home Committees.(f)While visiting an institution, the
visitors will not say or do anything which undermines the authority of the Superintendent/Project
Manager or is in contravention of any law or rule or impinges on the dignity of the child.(g)The
Children's Home, being a child care centre looking after children who are not accused of any offence,
should not be treated as a custodial institution. In the event of a child leaving the Home without
permission, no proceedings of the nature of suspension shall be automatically initiated against the
staff of the Home; however, an enquiry shall be conducted to ascertain whether the staff have acted
in good faith and disciplinary action shall be initiated only when lack of good faith is established.
The information about the child leaving the Home without permission shall be sent to the family of
the child, if their address is known and to the police. The detailed report along with the efforts to
trace the child shall be sent to the Committee for information in the subsequent siting of theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

Committee.
16. Institutional Maintenance and Programme.
(1)Case Worker services shall be provided in all institutions to deal with the individual problems of
the children. The institution shall establish linkage with child guidance clinics, counselling and
guidance centres, psychiatric departments or similar agencies in the community by appointment on
part time/full time basis as per requirement.(2)Educational programme shall be developed as an
integral part of the Institution, emphasising on the academic, health, social, moral and ethical
aspects. The children shall be provided facilities of specialised education in the community on an
elective basis. The educational programme shall be organised under the supervision of trained
staff.(3)A diversified programme of vocational training shall be organised in all Children and Special
Homes with special reference to employment opportunities available in the community so as to
facilitate their rehabilitation. Trained vocational instructors shall be appointed for the purpose.
Vocational training facilities in the community shall also be availed of for the children on a selective
basis by providing linkages with welfare institutions, placement agencies and industrial and other
production units.(4)Each, institution shall provide for physical exercise and recreational facilities.
The recreational facilities may include the provision of radio, television, library, music, games,
computer, (indoor and outdoor activities) etc.(5)The children should be consulted in all matters
concerning them.(6)The Discipline in the Institution should be maintained in a child friendly
manner.(7)The children shall be protected from secondary victimisation.(8)A well rounded
programme of prerelease planning and follow up of children discharged from the Children's Home
and Special Home shall be organised in all institutions in close collaboration with voluntary welfare
organisations.(9)The Superintendent shall conduct, at least once a month, interactive sessions
among the staff, children, and NGOs to develop a team spirit among them for the effective
implementation of the Act and the Rules in letter and spirit.(10)All the staff and the NGOs working
in the Institution shall submit self assessment reports, quarterly, for evaluation by the
Commissioner or any person or agency nominated by him. The Bench Mark for the self-assessment
shall be the principles contained in Schedule 1 and the duties contained in these Rules.
17. Monitoring and Evaluation Committee.
(1)The Home Committee shall also be the monitoring and evaluation committee.(2)The Monitoring
and Evaluation Committee will also make a comprehensive plan for outreach channels between the
Home and local communities and agencies for various services (education, training, etc.,) and
celebration of special days.(3)This committee shall meet once in a month to consider, review and
formulate programmes and activities concerning:(a)Custodial Care, housing, place of work, area of
activity and type of supervision required;(b)Individual problems of children, family contacts and
adjustment, economic problems, and institutional adjustment etc.;(c)Education;(d)Vocational
training and opportunities for employment;(e)Social adjustment, recreation, group work activities,
guidance and counselling;(f)Special instructions, collecting moral information and special
precautions to be taken;(g)Review of progress and adjusting institutional programmes to the needs
of the child;(h)Planning post-release, rehabilitation programme and follow up for a period of two
years in collaboration with aftercare service;(i)Pre-release preparation;(j)Release, and(k)Any otherAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

matter which the committee may wish to consider.(4)A monthly progress report on the above shall
be sent to the Head of Department (Commissioner) by the 5th of every month.(5)Quarterly Review
of each child shall be done by the Home Committee. Where the Home Committee finds, after due
enquiry, that any child may be discharged or released to live with its parents or guardians or any
authorised person willing to receive and take charge of the child to educate and train the child for
the child's rehabilitation, a report shall be sent to the Competent Authority for appropriate orders
under Sections 56 or 59 of the Act.
18. Procedure of Inspection of Schools in the Institutions.
- The District Education Officer shall periodically inspect the schools in the institutions with a view
to improve the quality of education. The Superintendent and the Head Master shall ensure that the
directives issued by the District Education Officer are complied with promptly.
19. Maintenance of case File.
- The Case File of each child shall be maintained in the institution containing the following
information as applicable:(1)report of the person/agency who produced the child before the
Board;(2)probation officer's report;(3)information from previous institution, if any;(4)initial
interview material, information from family members, relatives, community, friends and
miscellaneous information;(5)Source of further information;(6)observation reports from staff
members;(7)reports from Medical Officer, I.Q testing, aptitude testing, educational/ vocational
tests;(8)social history;(9)summary and analysis by Superintendent;(10)initial classification
sheet;(11)instruction regarding training and treatment programme and about special precautions to
be taken;(12)leave and other privileges granted;s(13)special achievements;(14)violation of Rules and
Regulations;(15)quarterly progress report from various sections;(16)review sheet;(17)M.C. Report
(in case of girls);(18)pre-release programme;(19)final progress report (Educational/ vocational
training, Health and other personal details in a summarised form);(20)leave of absence/release on
license;(21)final discharge (include the pre-release report/rehabilitation plan proposed for the
individual);(22)follow up reports;(23)central index number;(24)annual
photograph;(25)remarks;Note. - All the case files maintained by the institutions and the Competent
Authorities should be computerised and networked so that the data is centrally available. The
reports of the Probation Officer or Social Worker shall be confidential, as provided under Section 51
of the Act.
20. Daily Routine.
(1)Each institution shall have a well regulated daily routine for the children, which should be
displayed on a Notice Board and at a prominent place and should provide, among other aspects, for
a disciplined life, personal hygiene and cleanliness, physical exercise, educational classes, vocational
training, organised recreation and games, moral education, group activities, community singing.
The Home Committee shall design a creative programme for recreation and relaxation of the
children of Sundays and holidays.(2)The Daily Routine shall be drawn according to the season, as
per Schedule 6. The exact schedule for each month, with minor variations, if necessary, shall beAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

drawn by the Superintendent. All the morning activities, like Waking up. Nature calls,Personal
Cleaning, Premises cleaning, Bathing and Washing of clothes shall be completed by 8.30 a.m. The
breakfast shall be completed before 9.00 a.m.
21. Diet Scale.
- All the resident children shall have diet in accordance with the scale specified in Schedule-7.
22. Issue of clothing, bedding, toiletry and other articles.
- Minimum standards shall be followed on the issue of clothing, bedding, toileteries and other
articles for the children as per Schedule - 8.
23. Health, Sanitation and hygiene.
- Each institution shall as far as possible, have the following facilities:(1)Sufficient and treated
drinking water.(2)Sufficient water for bathing and washing clothes, maintenance of cleanliness on
the premises and for flushing out latrines.(3)Proper drainage system.(4)Arrangements for disposal
of garbage.(5)Protection from mosquitoes(6)Sufficient number of latrines in proportion of at least
one for every ten children(7)Sufficient number of bathrooms in proportion of one bath room for ten
children(8)Sufficient number of urinals(9)Sufficient number of washing places(10)Arrangements
for getting the entire premises and buildings of the institution thoroughly cleaned at least once a
day.(11)Cleanliness in the kitchen(12)Fly-proof kitchen(13)Arrangements for boiling clothes once a
week, arrangements for washing of clothes everyday(14)Sunning of bedding and clothing twice a
week(15)Scrupulous cleanliness in the hospital.
24. Accommodation for institutions.
- The minimum standard of accommodation shall, as far possible be, as follows:
(1) DormitoryClass
RoomWorkshopPlayground40 Sq.ft.per Child300 Sq.ft.700 Sq.ft.Sufficient playground
area with volley-ball, football, Basketball courts etc., should
be provided in each institution according to the total
number of Children in the institution. In case of the
Observation Home, which is a Short Stay Home, the
requirement of a football field shall not be insisted on.
(2) The dormitories, classrooms and
workshops shall have sufficient cross
ventilation and sufficient light.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

25. Medical care for institutions.
- Each of the institutions under Sections 8,9,34.37, and 44 of the Act shall provide for the necessary
medical staff and ensure that (a) regular facilities are available for the medical treatment of children
(b) arrangements are made for the immunisation coverage: and (c) a system is evolved for the
removal of serious cases to the nearest civil hospital or treatment centres.
26. Rewards and Earnings.
(1)Rewards to the children at such rates as may be fixed by the Commissioner from time to time may
be granted by the Superintendent as an encouragement for excellence in studies, skill learning,
steady work and good behaviour.(2)The amount earned by the child shall be deposited in his/her
name/personal account and the account book shall be kept with the Superintendent. The children
may be given some pocket money for purchase of articles such as sweets, books, toys etc., as per his/
her choice on fixed days of the week.(3)When the child is discharged on the expiry of the period of
his/her stay ordered by the competent authority the money deposited in his/her name shall be
withdrawn by the Superintendent and handed over personally after obtaining a proper receipt from
the parent/guardian, if any or in their absence from the child.
27. Visitors and Communications to/ for the children.
(1)A child may receive visitors during his or her stay in the Institution. The Superintendent shall fix
the days and hours at which interviews shall ordinarily be allowed and no interviews shall be
allowed at any other time except with the permission of the Superintendent. A notice of the hours of
interview shall be placed outside the institution. The privilege of receiving visitors may be refused
on the orders of the Superintendent if the visit is used to introduce any prohibited articles into the
institution by any parent, guardian, relative or friends, or is likely to have, in the opinion of the
Superintendent, a bad influence, the Superintendent shall record his reasons for such refusal in the
case history sheet maintained by the case worker, who shall record each such interviews received
and rejected in the appropriate columns.(2)The allocated days and hours for the visits may be
followed strictly in the case of local residents. In the case of parents, guardians, relatives or friends
coming from out station, this condition maybe relaxed by the Superintendent, to avoid any
inconvenience to such visitors. The interviews shall however not be allowed after 6 p.m, except in an
emergency.(3)The receipt of letters by the children shall not be restricted and they have the freedom
to write as many letters as they like at all reasonable times. The Institution shall ensure that at least
one letter is written by the child every week for which the postage shall be provided.(4)If the address
of the parents or guardians or relatives is known, they shall be given notice of any serious illness of
the children and the Superintendent, shall answer any reasonable enquires made by the parents or
the relatives in this connection.
28. Visitors Book.
- A visitors Book shall be maintained in which the persons visiting the Home shall record the datesAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

of their visits with remarks or suggestions, which they may think proper. The Superintendent shall
forward a copy of every such entry to the Commissioner with such remarks as he may desire to offer
in explanation or otherwise and the Commissioner shall pass such order thereon as he deems
necessary.
29. Leave of absence.
(1)A Child may be permitted by the Competent Authority to go on leave of absence to appear for
examinations or in case of emergencies or special occasions like marriage in the family etc.(2)The
parents or guardian of the child shall submit an application to the Competent Authority, requesting
for leave for the child, stating clearly the purpose for the leave and the period of leave. If the
Competent Authority, on the basis of the report of the Probation Officer or otherwise, deems it fit to
sanction the leave, he shall clearly mention the period of leave and the conditions attached to the
leave order. If any of these conditions are violated during the leave period, the child may be recalled
to the institution.(3)The parent or guardian shall arrange to escort the child from and to the
institution and bear the travelling expenses. In exceptional cases or during an emergency, the
Superintendent may arrange to escort the child to the place of the family and back at State expense,
after obtaining orders from the Commissioner.(4)If the child runs away from his/her home during
the leave period, the parent or guardian shall inform the Competent Authority and the
Superintendent of the institution immediately and try to trace the child and if found, escort him to
the institution. If the parent or guardian do not take proper care of the child during the leave period
or do not bring him back to the institution within the stipulated period, leave maybe refused on later
occasions. If the child does not return to the institution on expiry of the sanctioned leave, the case
shall be referred to the Competent Authority for necessary orders. In case of the children from
Special Home or Observation Home, the Police shall be informed immediately for tracing the child
and bringing him to the Institution.(5)In the case of children of the Special Home, the period of such
leave shall be deemed to be part of the period of his/ her detention in the institution. The time which
elapses after the failure of a child to return to the institution within the stipulated period shall be
excluded in computing the period of his/her detention in the institution.
30. Release.
(1)The Superintendent of the Special Home shall maintain a roster of the cases to be released on the
expiry of the period of stay as ordered by the Board. Each case shall be placed before the Home
Committee for proper mainstreaming. With regard to cases in which the child is kept for the
maximum period, action shall be initiated six months before they attain the age of 18
years.(2)Timely information of the release of a child and of the probable date of release shall be
given to the parent or guardian and the parent or the guardian shall be invited to come to the
institution to take charge of the child on the date. If necessary, the actual expenses of the parent or
the guardian's journey, both ways and of the child's journey from the institution shall be paid to the
parent or guardian by the Superintendent at the time of the release of the child. If the parent or
guardian as the case may be, fails to come to take charge of the child on the appointed date, the child
shall be taken by the escort of the institution. A female escort shall escort girls.(3)At the time of
release or discharge a child may be provided with a set of summer/winter clothing as the case mayAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

be, if the Superintendent deems it necessary.(4)If the child has no parent or guardian, he may be
sent to an after care organisation or in the event of employment to the person who has undertaken
to employ the child.(5)The Superintendent of a girls' institution, subject to the approval of the
designated authority, may get suitable girls above the age of 18 years married according to the
procedure laid down by the Commissioner, from time to time.(6)The Superintendent shall order the
discharge of any child, the period of whose detention has expired and inform the competent
authority within 7 days of the action taken. If the date of release falls on a Sunday or another public
holiday, the child may be released on the preceding day, entry to that effect, being made in the
register of discharge. The Superintendent shall in appropriate cases, order the payment of
subsistence allowance at such rates as may be fixed from time to time and the railway and road, or
both, fare, as the case may be.(7)In deserving cases, the Superintendent may provide the child with
such small tools, as may be necessary, to start a business subject to such maximum cost as may be
fixed by the Commissioner.(8)The Superintendent may allow at their own request such boys/girls as
have no place to go to enable to appear for exams, medical requirements etc., to stay in the
institution not exceeding 30 days and for stay beyond 30 days, with the permission of the
Commissioner after the period of their detention, till some other suitable arrangements are made.
31. Discharge or release.
(1)Any person seeking discharge or release of a child under Section 56 or Section 59 (1) of the Act as
the case may be, may make an application to the competent authority who shall send the copies of
the application to the concerned Probation Officer where the applicant is residing and to the Home
Committee of the Institution where the child is staying and call for their reports. An application can
also be made directly to the Home Committee, where the child is residing seeking the child's
discharge or release. Where the Home Committee, on due enquiry finds that the child may be
discharged or released, a report shall be sent to the competent authority for appropriate orders. The
Home Committee shall make the enquiry by itself or through the Probation Officer or through any
other qualified agency and submit its report to the Competent Authority, expeditiously.(2)The
Competent Authority shall pass orders on the application made under sub-rule (1) or under sub-rule
(5) of Rule 17 within one month of receiving the reports. If no such order is passed with in the period
of one month it shall be deemed that the Competent Authority has no objection to the
recommendations made in the report of the Home Committee and the child shall be discharged or
released as per the report of the Home Committee.
32. Prohibited Articles.
- No person shall bring into the institution the following prohibited articles:(1)Firearms or other
weapons, where requiring licence or not (like lathi, spear, swords etc.,)(2)Alcohol and spirit of every
description.(3)Bhang, ganja, opium and other narcotic/psychotropic substances.(4)Tobacco
(cigarettes, bidi, gutka etc.,)(5)Any inciting/obscene/prohibited literature/Books and provocative
material etc.(6)Any other article specified in this behalf by the State Government by general or
special order.Such articles will be seized and destroyed or disposed of in accordance with the
procedure described in Schedule 9. Firearms and other weapons shall be dealt with under the Arms
Act.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

33. Disposal of Articles.
- The property other than money or valuables belonging to a child received or detained in an
institution shall be disposed of as per the procedure laid down in Schedule-9.
34. Disposal of records/documents.
(1)The records pertaining to the conviction of a child shall removed and destroyed by the orders of
the Board after one year of the pronouncement of the Orders by the Board under Section 15.(2)The
other records/documents in respect of a child should be kept in a safe place for a period of 10 years
after the release of the child and thereafter destroyed with intimation to the Commissioner.
35. Emergencies.
(1)On the occurrence of any case of death or suicide, the procedure to be adopted is as under:(a)If a
child dies within 24 hours of his/her admission to the institution an inquest and post-mortem
examination shall be held.(b)Whenever a sudden or violent death or death from suicide or accident
takes place, immediate notice shall be sent to the Superintendent and the Medial Officer and the
body shall be left in the position in which it was found, pending inspection by the officers concerned.
In case a child dies due to causes other than natural causes or if the cause of death is not known or if
the death has occurred due to suicide or violence or accident or whenever there is any doubt or
complaint or question concerning the cause of death of any child, the Superintendent shall inform
the same to the officer in-charge of the Police Station having jurisdiction. The Superintendent shall
immediately give intimation to the nearest Magistrate empowered to hold inquests.(c)In case of
death due to suicide, accident, violence and sudden death, etc., both inquest and postmortem shall
be held.(d)Where the death has occurred due to violent or unnatural causes, the Superintendent
shall at once send a brief report to the authorities concerned including the Commissioner/Deputy
Director.(e)The Superintendent shall then make a detailed investigation of all the circumstances
connected with the cause and forward the same without delay along with inquest report to the
authorities concerned.(f)The Medical Officer shall report to the Superintendent about the
happening of the unnatural death of a child and see that the body is decently removed to the
mortuary.(g)In every case of illness, which ends fatally, the Medical Officer shall examine the body
of the child and shall record full particulars of the cause of death in relevant registers,(h)In case of
natural death of a child the Superintendent shall obtain a report of the Medical Officer stating the
cause of death. A written intimation about the death shall be given immediately to the nearest Police
Station, the Civil Surgeon and the District Magistrate, Superintendent of Police and the authorities
under the Act.(i)The parents or guardians of the deceased child shall be contacted and the
Superintendent shall wait for twenty-four hours for the arrival or of any intimation from the
relatives. After the inquest is held, the body should be disposed of in accordance with the religion of
the child as far as it maybe ascertained,(j)Upon the occurrence of any case of suicide, the
Superintendent shall give immediate information thereof to the nearest Magistrate empowered to
hold inquests in order that an inquest and post-mortem may be held on the body. A full report on
the whole circumstances connected with the case shall be promptly submitted by the
Superintendent to the authorities concerned after the inquest.(k)in the event of the SuperintendentAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

or the Home Committee, coming to know of any custodial rape or sexual abuse of a child, the
Superintendent/Home Committee shall immediately conduct a preliminary enquiry and if a prima
facie case exists of the commission of such an offence, the same shall immediately be reported to the
police. The entire record of the preliminary enquiry of the Superintendent/Home Committee shall
be placed, before the Competent Authority for its examination. In the case of Civil Servants,
appropriate disciplinary proceedings shall also be initiated, apart from prosecution for the offence.
The Home Committee, after enquiry into the matter, shall take remedial action to prevent the
recurrence of such incidents.(2)In the event of any other crime committed in respect of children, the
Competent Authority will take cognisance and arrange for necessary investigation to be carried out
by Special Juvenile Police Unit/Police.(3)In the event of an escape of a child from the Special Home
or Observation Home, the action to be taken is as follows:(a)The Superintendent shall immediately
send the guards in search of the child at places like railway station, bus stand, the child's home and
other places where the child is likely to go;(b)The parents or guardians, whose addresses are known,
shall be informed immediately about such escape:(c)A report shall be sent to the police station along
with the detailed description of the child with identification marks and a photograph:(d)The
Superintendent shall hold an enquiry about each escape and send his report to the competent
authority and the Commissioner;(e)On the restoration of a child after escape, the period at large,
shall be calculated by excluding the day of escape and the day of restoration. The period at large
shall then be added to his/her period of detention and the revised date of discharge calculated by
adding the number of days to the date of discharge (in case of children in the Special Home);(f)The
caseworker should try to analyse the reasons for the escape and report his findings to the
Superintendent suggesting a suitable programme for avoiding of the reoccurence of such
incidents,(g)In the event of a child leaving the Children's Home without permission, the Child
Welfare Committee shall immediately be informed of the same for necessary orders.
36. Mode of dealing with child suffering from dangerous diseases or mental
complaint.
(1)When a child kept in the Home under the provisions of the Act or placed under the care of a Fit
Person or Fit Institution is found to be suffering from a disease requiring prolonged medical
treatment or physical or mental complaint that will respond to treatment or is found addicted to a
narcotic drug or psychotropic substance, the child may be removed by an order of the
Superintendent to an approved place set up for such purposes for the reminder of the term for
which he has to be kept in custody under the order of the Competent Authority or for such period as
may be certified by the Medical Officer to be necessary for the proper treatment of the child. The
Superintendent shall seek ratification of his order passed under this sub rule from the Competent
Authority as early as possible, but not later than seven days of passing the order. The Competent
Authority shall enquire into the matter and pass appropriate orders.(2)Where it appears to the
authority ordering the removal of the child under sub-rule (1) above that the child is cured of the
disease or physical or mental complained he may, if the child is still liable to be kept in custody, call
upon the person having charge to send child to the Home or Fit Person/Fit Institution, from which
or from whom he was removed or if the child is no longer liable to be kept in the Home, order him to
be discharged.(3)Where action has been taken under sub-rule (1) in the case of a child suffering
from an infectious or contagious disease, the Superintendent, before restoring the said child to theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

guardian, conduct and enquiry by himself or through another agency whether it is in the best
interest of the child and submit a report to the Competent Authority for appropriate orders
regarding the custody of the child.(4)If there is no organisation either within the jurisdiction of the
competent authority or nearby State for sending the child suffering from dangerous diseases as
required in Section 58 of the Act, necessary organisation shall be set up by the State Government at
such places as may be deemed fit by it.(5)A code of conduct regarding HIV/AIDS issues that
translate human rights principles and medical ethics into codes of professional responsibility and
practise, with the mechanism to implement and enforce these codes shall be evolved by the
Monitoring and Evaluation Committee. Institutional authorities shall also provide children and
institutional staff with access to HIV related prevention information and education. Facilities for
voluntary testing and counselling, means of prevention, treatment and care shall be provided.
Confidentiality should be assured and segregation and denial of access to facilities and privileges
prohibited. Compassionate early release or referral of residents living with AIDS should be
considered.
37. Linkages and Co-ordination with Government and Non-Governmental
Agencies.
- The Superintendent of the Homes and the Home Committees shall mobilise resources from the
various governmental, nongovernmental, corporate, and other community agencies with close
coordination with the district administration and plan individual as well as group programmes for
the purposes outlined in the Act for facilitating the rehabilitation and social integration of the child.
Chapter V
Co-Management
38. Co-management.
(1)All the State-run institutions under the Act shall be jointly managed by the Government and
Non-Governmental Organisations, as expeditiously as possible. The NGOs with a good track record
of working with children and having experienced staff shall be involved in all aspects of managing
the institution along with the Government to achieve the objects of the Act and in particular as
provided in Sections 34, 40 and 45.(2)Co-management shall be implemented through the Home
Committee, Working Committee and Executive Committee. The Home Committee shall be
responsible for managing the institution in all aspects. The Home Committee is a representative
body of the officials of the Department and the NGOs. The objective of establishment of the Home
Committee is to ensure optimum care and protection of children through co-operative efforts, all
round development of the personality of the children and realisation of their rights and
transparency and accountability of the Institution.(3)The Home Committee will be constituted with
the following members:
S.No. Name DesignationAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

1.2.3.4.5.6.7.SuperintendentNon-GovernmentalOrganisationNon-GovernmentalOrganisationDeputy
SuperintendentCivil
AssistantSurgeonCase
WorkerHouse Mother/FatherConvenorMember (Nodal Agency)Member
(SupportingAgency),
OptionalMemberMemberMemberMember
(4)Functions and role of Home Committees:The Home Committee shall:(a)Prepare the micro-plans
for the institution including projection and utilisation of required budgets for administering the
Home and implementing requisite programmes for all round development of the children;(b)work
on the standardisation of the education system including vocational training, in the Home, to
provide quality education.(c)provide for retraining of present teachers/instructors, deputation of
new teachers/instructors, from other Departments or engage suitable instructors from other sources
on contract basis where required, procurement of study material and raw material;(d)Introduce
bridge schools for older children who had little or no formal education.(e)impart life skills education
in terms of leadership and personality development as an integral part of the child's education and
reintegration;(f)impart livelihoods training for children with a focus on productivity to motivate the
child to learn new skills and to attend certification programmes;(g)provide counselling with trained
and competent counsellors, who are qualified in social work, Psychology, Sociology or Home
Science.(h)take care of the children day and night.(5)The criterion for selection of NGOs, who will
be part of the Home Committee shall be as per the guidelines laid down in Schedule -2.(6)The
Working Committee in respect of the Institutions in the city of Hyderabad shall consist of the
following:
S.No. Name and Address Designation
1.2.3.4.5.6.7.8.9.Commissioner,Juvenile Welfare, Correction Services &
Welfare of StreetChildrenJoint Director/DeputyDirector of
Correctional Services (Admin) O/o the CommissionerJWCS
& WSCNGO Participants inthe
Co-managementCommissioner ofEducation/his
representativeDeputy Director ofCorrectional Services (Pig.)
O/o the Commissioner JWCS & WSCUNICEF,
ProgrammeOfficerCommissioner ofSocial Welfare or his
representativeThe Superintendentsof the concerned
HomesAny other persons as a special invitees to
benominated by Commissioner, JWCSChairpersonConvenorMembersMemberMemberMemberMemberMembersSpecial
invitees
The Working Committee will meet quarterly, by rotation, in different regions. The Superintendents
and the concerned NGOs of the region shall attend the quarterly meetings as members.(7)The
working Committee shall(a)implement in the Homes, the programmes approved by the Executive
Committee(b)review the functioning of the Homes at least once in every three months and more
often as required.(c)submit half yearly review report to the Executive Committee and make
suggestions regarding more effective implementation of programmes.(d)monitor and direct the
functionaries in the Homes through the respective Home Committee.(e)review and direct the
functioning of the Home Committee and issue appropriate guidelines for the effective
co-management of the Homes.(f)implement such decisions as are entrusted to it by the Executive
Committee for mobilisation of resources, initiation of collaboration etc.(g)help Executive Committee
draw up the Budget Estimates and Annual General Report of the functioning of the
Homes.(h)ensure that the aims and objectives of the Juvenile welfare programme is achievedAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

through proper implementation, monitoring and review of programmes and personnel.(8)The
Executive Committee shall consist of:
S.No.Name and
AddressDesignation
1.2.3.4.5.6.7.8.9.10.11. Principal
SecretaryWoman
Development,
Child Welfare
and Disabled
Welfare
DepartmentCommissioner,Juvenile
Welfare,
Correctional
Services and
Welfare of
StreetChildrenCommissioner
ofEducationNGO
participants
inthe
Co-management
(Three per
region, on
rotation basis, to
benominated by
the
Chairperson)The
PrincipalMagistrates
of the Board and
the Chairpersons
of the
ChildWelfare
CommitteeDeputy
Director
ofCorrectional
Services (Admn.)
O/o of the JWCS
and WSCDeputy
Director
ofCorrectional
Services (Pig.)
O/o the
Commissioner
JWSC &
WSCUNICEF,ChairpersonConvenorMemberMembersMembersMemberMemberMemberMemberMembersMembersAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

ProgrammeOfficerManaging
Director,A.P.
Co-operative
Finance
CorporationTwo
nominees of
theChair
PersonsSuperintendents
of the
Institutions
(9)The Executive Committee:(a)shall be responsible for the implementation and monitoring of the
child welfare programme. It shall function according to the polices and guidelines of the
Government and the State Advisory Board.(b)shall take such measures as may be necessary for
realising the goals and objectives of the Child Welfare Programme.(c)shall receive and review
periodic reports from the working committee regarding implementation and impact of such
measures on the general working of the Homes and issue suitable directions to the Working
Committee.(d)shall have the responsibility to prepare the annual budget estimates and have it
approved by competent authorities.(e)shall mobilise funds and resources.(f)shall approve the
expenditure covering all aspects of the programme.(g)shall in view utilisation of funds, activities and
implementation of programmes in the Homes.(h)shall submit a consolidate annual report to the
State Advisory Board about all its programmes and about the Co-management system.(i)shall meet
at least once in every four months and more often, if necessary.
Chapter VI
Shelter Homes and After Care Organisations
39. Shelter Homes-set up, management and functions.
(1)For the children in urgent need of care and protection, such as destitute, street children,
run-away children etc., the Government shall support creation of the requisite number of shelter
Homes/Drop-in Centres through voluntary organisations.(2)Such Homes/ Centres should have the
minimum facilities of boarding and lodging besides the provision for fulfilment of basic needs in
terms of clothing, food, health care and nutrition etc. Such children in crisis situations may live in
short-stay homes, which shall have adequate facilities for education, vocational training and
recreation as well. The minimum requirement of space in the dormitories shall be 40 sqft. per child
and one toilet for every ten children. The premises should be kept clean. There should be adequate
provision for potable drinking water and water for sanitary purposes.(3)The services of
Superintendent and Social Worker shall be provided for the proper care, protection, development,
rehabilitation and reintegration needs of such children.(4)No child shall ordinarily stay in the
Home/Drop-in-Centre for more than a year, increase of Government funding.(5)Transparency shall
be maintained in running these Homes. Visitors are allowed. However, while visiting an institution,
the visitors shall not say or do anything which undermines the authority of the Superintendent/
Project Manager or do anything which is in contravention of any law or rule or impinges on theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

dignity of the child.
40. After Care-Establishment of after care Home.
(1)The Objective of After Care Organisations is to enable the children to be reintegrated into the
society. During their stay in these transitional homes, the children should be encouraged to move
away from an institution-based life to a normal one. The stay in the Home is extendable up to three
years, but not beyond the youth attaining the age of 20 years or till rehabilitation, whichever is
earlier.(2)The key components of the model include setting up of temporary homes for a group of
youth, who can be encouraged to learn a trade and contribute towards the rent as well as the
running of the Home. There should also be provision for a peer counsellor. This counsellor will be in
regular contact with these youth to discuss their rehabilitation plans and provide creative outlets for
their energy and to tide over crisis periods in their life. The group of youth who would station
separately for their rehabilitation must also have a mentor in addition to the counsellor.(3)One
career counsellor shall be in-charge of a cluster of five Homes. Each Home would house six to eight
youths who could opt to stay together on their own.(4)The pattern of the After Care Home for 40
residents shall be as follows:(1)Placement Officer/Counsellors (in the cadre of DPO
Gr.I)(2)Instructors for skill up-gradation.(3)A typist-cum-clerk can be appointed, depending on the
workload.(4)A peer counsellor and a career counsellor shall also be provided with suitable
honorarium.(5)The programmes under the scheme would include:(a)Continuing of education,
training with sponsorship support till completion of the course:(b)Facilitating employment
generation for these youth would be a key programme. After the youth has saved a sufficient
amount, she/he can be encouraged to stay in a place of her/his own and move out of the group
home. Additionally the youth could continue staying in the Home and contribute to the upkeep of
the Home. The youth learning a vocational trade could be given a stipend. This would be stopped
once the-youth gets a job;(c)Loans to these youth to set up entrepreneurial activities could also be
arranged in consultation with local/district administration:(d)A peer counsellor would also be
available for the youth at these homes:(e)The maintenance of the residents of Home will be as in the
case of Children's/Special Homes, as far as feasible. The youth will however be required to prepare
their own food:(f)In the case of children prosecuting professional courses, the State Government
shall meet the expenditure on his or her education, boarding and lodging in the concerned student
hostels. Such stay of the individual may be treated as an extension of the After Care Programme.
Chapter VII
Adoptions, Foster Homes and Sponsorships
41. Adoptions.
(1)Since the family is the best option to provide care and protection for children, adoption is an
alternative for rehabilitation and social reintegration of children who are orphaned, abandoned,
neglected and abused.Or(2)An agency desiring to place children in adoption should have a
certificate of recognition and licence from the Department of Women Development, and Child
Welfare(3)Any child eligible for adoption, residing in an unrecognised home, for the purpose ofAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

adoption, should be transferred to a recognised Home.(4)If an abandoned child, is brought by any
individual or authority the recognised agency shall, within 48 hours, report to the Child Welfare
Committee, and the concerned Project Director Department of Women and Child Welfare Agency
along with the copy of the report filed with the police station in whose jurisdiction the child was
found abandoned.(5)Before declaring the child as abandoned and certifying him/her as legally free
for adoption, the Child Welfare Committee shall conduct due enquiry, including:(a)A through
enquiry by the Probation Officer/case workers/police, as the case may be, who will submit the
report within a maximum period of one month;(b)Declaration by the placement agency stating that
there has been no claimant for the child even after making notification in at least one leading
newspaper including a regional language newspaper, TV and Radio announcement and after waiting
for a period of one month;(c)The Child Welfare Committee shall make a release order declaring the
child legally free for adoption within the period of six weeks from the date of application in the case
of children below the age of two years and three months in the case of children above that age;(d)No
child above seven years who can understand and express her/ his opinion shall be placed in
adoption without her/his consent.(6)Inter-country adoption, i.e., the adoption of Indian children by
foreign nationals, shall be permitted only as a means of last resort. However, this bar will not apply
to the adoptions by persons of Indian Origin.(7)The scrutiny, in case of inter-country adoptions,
shall be done by the Scrutinising Committee. The Scrutinising Committee will examine all available
information and verify the background of the child before making a recommendation to the Board
for adoption of the child by a foreign national.(8)The State Government shall appoint the Members
of the Scrutinising Committee which shall consist of five Members comprising of one representative
of the State Government from the Department of Women Development and Child Welfare, three
persons who are actively involved in health/education/rights of women or children for at least five
years and one Member of the State Legislature. The term of the Committee shall be three years. The
appointment of a Member of the Scrutinising Committee may be terminated in the same manner as
that of a Member of a Child Welfare Committee under Section 29(4) of the Act.(9)The Scrutinising
Committee shall perform the following functions regarding inter-country adoptions:(a)Scrutinise
the following documents:
1. Applications for adoption made on behalf of the prospective adoptive
parents.
2. Home Study Reports.
3. Child Study Reports.
4. Any other documents/certificates attached with the application.
(b)Ensure that the application or copy of the application, as the case may be, has been duly
forwarded by a foreign agency to the State Government.(c)See the child in person and check that the
information given to prospective adoptive parents regarding the child is correct. In case of any
change in the medical/physical status of the child, the Scrutinising Committee shall ensure that the
information of the change is given to the prospective adoptive parents and their consent obtainedAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

before a final order is passed by the Board concerned.(d)Satisfy itself that the prospective adoptive
parents are fit persons for adopting the child.(e)Ensure that the adoption would be in the best
interest of the child.(f)Assist the Board in ascertaining whether the surrender is in accordance with
Rule 42(1)(g)Ensuring and satisfy itself that no one, including Indian as well as foreign agencies
concerned are making any profit out of the adoption.(h)Verify in case of older children, the child's
own views regarding the adoption. This may be reported to the State Government,
immediately.(10)The Members of the Scrutinising Committee shall be paid such honorarium as the
State Government may fix from time to time.
42. Surrender of Children.
(1)Only children who fall within the definition of "Child in need of care and protection" under
Section 2(d) of the Act and in particular, children of unwed mothers, orphans and children of
mentally or physically challenged persons, can be surrendered for the purposes of adoption under
the Act.(2)The cases of surrender of children shall be strictly scrutinised. No document executed by
the "surrendering parent" shall be accepted at its face value. Any person found guilty of offering any
allurement whatsoever for surrendering a child shall be punishable with imprisonment for a term
which may extend up to three years.(3)Not withstanding anything contained in any Rule or
Guideline, no child shall be surrendered to a Private Agency for the purpose of adoption or
guardianship. The surrender shall be made only to the Project Officers of the Department of Women
Development and Child Welfare. Such surrendered children shall be placed in the Children's Homes
or the State Government run Institutions for Orphans.(4)The Project Officers of the Department of
Women Development and Child Welfare shall refer all cases of surrender to the Child Welfare
Committee. The Child Welfare Committee shall examine all cases of surrender of a child and
ascertain whether the surrender is genuine. The Child Welfare Committee shall counsel the parent
of the consequences of surrendering the child and the importance of the biological parent for the
Development of the child. If both parents are living, the surrender shall be by both the parents. In
the case of orphans, the guardian of the child, as recognised by the Child Welfare Committee, can
surrender the child. The Child Welfare Committee shall give two months time for parents/
guardians to reconsider their decision to surrender the child.(5)The enquiry by the Child Welfare
Committee on the genuineness of the surrender shall be made as expeditiously as possible but not
later than three months from the date of the application for surrender of the child.(6)The surrender
of the child shall be valid only after an appropriate order is passed by the Child Welfare Committee.
43. Role of Juvenile Justice Board.
(1)The Board shall undertake a process of enquiry which will include interviewing the prospective
parents, verifying the documents and calling for the scrutiny reports of the Probation Officer or any
other reliable independent agency and examination of the same. If the Board is satisfied that the
placement is in the best interest of the child, it will pass a final order giving permanent custody to
the adoptive parent/parents. An order of adoption shall be signed by the Principal Magistrate beside
one of the two members of the Board.(2)The Board shall give wide publicity, at State expense, to
enable speedy in country adoption of the children produced before it for adoption.(3)The Board
shall fix the date of birth, in the best interest of the child and shall pass order to the appropriateAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

authority to issue a regular birth certificate for the child giving the name(s) of the adoptive parent(s)
as if in the case of natural born children.(4)As far as possible, the time taken for passing an adoption
order shall not exceed three months from the date of filing. The order shall also include provision
for a periodic follow up report either by the Probation Officer/case worker or adoption agency to
ensure the well being of the child. The period of such follow up shall be three years, six monthly in
the first year and annually for the subsequent two years.
44. Foster Care.
(1)The temporary foster care shall be carried out as provided given in Section 42(2) of the Act by the
competent authority under supervision of a Probation Officer/case worker/as the case may be, in a
prescribed Form II. The total period of temporary foster care shall not exceed five years.(2)The
following criteria be applied for selection of families for temporary foster care:(a)Foster parent(s)
should have stable emotional adjustment within the family;(b)Foster parent(s) have an income to
meet their needs and not be dependent on the foster care maintenance payment;(c)Medical reports
of all the members of the family residing in the premises should be obtained including checks on
HIV/TB and Hepatitis B to determine that they are medically fit. An update should be done at
regular intervals of not less than once in a calendar year;(d)The foster mother should have
experience in child caring and the capacity to provide good child care;(e)The foster mother should
physically, mentally and emotionally stable;(f)The Home should have adequate space and physical
facilities;(g)The foster care family should be willing to follow the conditions laid down including
regular visits to paediatrician, maintenance of child health, record etc.;(h)The family should be
willing to sign an agreement and to return the child to the agency whenever called to do so;(i)The
foster mother should be willing to attend training/orientation programmes and(j)The foster
parent(s) should be willing to take the child for regular (at least once a month in the case of infants)
checkups to a paediatrician approved by the agency.(3)There should be regular monitoring and
supervision carried out by the Probation Officer/Child Welfare Officer as the case may be.
45. Sponsorship.
(1)Objectives:(a)The Home shall promote a sponsorship programmes as laid down in Section 43 of
the Act;(b)The Home receiving sponsorship, shall maintain proper and separate accounts of all the
receipts and payment for the programme;(c)Sponsorship services should be considered to
supplement the resources of the child coming under the purview of the Act an$ his or her parent or
guardian so as to support efforts to reintegrate the child into the community and finance his or her
education, vocational training, health care, etc. or to supplement the family income to encourage
parent or guardian to fulfil their responsibility towards the child;(d)The Department of Women and
Child Development shall promote a sponsorship programme;(e)The State shall provide for the
sponsorship of children based on need, when they are discharged from the Reception Unit/Shelter
Home/Children's Home/Special Home/After Care Institution.(2)Management of the scheme. - (a)
The State shall establish a Sponsorship Fund with funds from State Government and other sources
such as individual and corporate sponsors;(b)The Fund shall be administered by a designated,
recognised sponsorship agency/identified NGO at the district level, under the supervision of the
Child Welfare Committee;(c)The payment shall be made through the institution from where theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

child was discharged;(d)The Home receiving sponsorship shall maintain proper and separate
accounts of all receipts and payments for the programme and(e)For residents of state-run/
recognised NGO-run institutions under this Act, sponsorship support shall be routed through a
fund, which supplements the existing budgetary allocation/ grant-in-aid programme.(3)Criteria for
selection of children for sponsorship. - (a) Children reinstated with single Parent/biological
families/Foster Families who are below Poverty line;(b)Disabled and other children in special need
requiring specialised intervention/treatment and referred from any institution or programme under
this Act;(c)Children reintegrated with the family, where the parent is disabled or chronically ill but
is willing and able to take care of the child;(d)Where the child requires sponsorship to complete
his/her ongoing education/vocational training after discharge from the institution, up to a
maximum period of two years;(e)Any other cases after due consideration by the Commissioner
and(f)Orphaned children placed with extended/foster families shall be referred to the foster care
scheme.(4)Duration of the Sponsorship. - Duration of sponsorship support shall be decided on a
case-by-case basis, based on the recommendations of the Caseworker that has been endorsed by the
monitoring and evaluation committee. However, this shall not exceed five years except under
exceptional circumstances.(5)Procedure for sponsorship support. - (a) The social worker of the
respective Reception Unit/Shelter Home/ Children's Home/After-Care Institution shall visit the
Home of the child and verify that the child fulfills the criteria mentioned above;(b)Each institution a
vailing of the sponsorship scheme under this Act, shall entrust a qualified social worker with the
responsibility of undertaking all assessments, home visits, documentation, review and follow up of
sponsored children;(c)Appropriate proof or record of death/divorce/separation/
disability/illness/income of parent or child, shall be verified and attached to the case file and a
report prepared and submitted to the Child Welfare Committee, and the sponsorship
agency;(d)Follow-up of the child under sponsorship to get an update on the family situation shall be
made once in six months and a report submitted to the Child Welfare Committee and the
Sponsorship Agency. Care shall be taken to ensure that the child is free from j abuse and
exploitation and is getting adequate education, nutrition and health care;(e)All sponsored children
shall regularly attend formal schooling/ skill training/vocational training unless under special
instances of disability or illness of the child, which shall be verified by the caseworker;(f)If at any
point of time the child has to be institutionalised, the sponsorship shall be discontinued;(g)The
extent of sponsorship support from other sources shall be taken into consideration while
determining the amount of sponsorship under this scheme;(h)Wherever possible, the child shall be
referred to other existing education schemes and services;(i)Appropriate penal action shall be taken
against persons found to be deliberately misusing the sponsorship amount and(j)The State level
Advisory Board in consultation with other Civil Society Organisations shall work out additional
modalities of the sponsorship programme through a suitable scheme.
Chapter VIII
Fit Persons/Fit InstitutionsAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

46. Recognition of Fit Person or Fit Institution.
(1)Any individual or a suitable place or institution, the occupier or manager of which is willing
temporarily to receive a child in need of care, protection or treatment for so long a period as may be
necessary and own the responsibility of a child, may be recognised by the Competent Authority, as
Fit Person or Fit Institution, on the basis of the report of the Commissioner or his/her
nominee.(2)Any association or body of individuals, whether incorporated or not, established for or
having for its object the reception or protection of children or the prevention of cruelty to child and
which undertakes to bring or to give facilities for bringing up any child entrusted to its care in
conformity with the religion of his/her birth or otherwise, may be included within the meaning of
Fit Institution.(3)Separate list of persons/ Institutions found fit by the Committee and the Board,
respectively, shall be made and kept in the offices of the Committee/ Board, as the case may be and
shall be used as and when necessary.(4)After the Competent Authority sends the child to an
Institution recognised as a Fit Institution with collateral branches, the manager of such institution
may send the child to any of the branches of such Institution after giving intimation to the
Competent Authority under whose orders the child was entrusted to their charge.
47. Certification/Recognition.
(1)I f the management of any organisation desires that its organisation may be certified or
recognised under the Act, the same shall make a written application together with a copy each of the
Registration Certificate of Registrar of Societies, the rules, bye-laws articles of association, list of
members of the society/association running the organisation, office bearers and a statement
showing the status and past record of social or public service of the organisation and the society
running the organisation to the Commissioner, who shall after verifying the provision made in the
organisation for the boarding and lodging, general health, educational facilities, vocational training
and treatment services may grant certification/recognition under Sections 8,9,34, 37 and 44 of the
Act, as the case may be, on the condition that the organisation comply with the standard or services
as laid down under the Act and the Rules, to ensure an all round growth and development of child
placed under its charge. In the case of a Fit institution/fit Person, the recommendations of the
Commissioner, shall be forwarded to the Competent Authority or appropriate orders.(2)The State
Government/Commissioner may, if dissatisfied with the conditions or management of the
organisation certified or recognised under the Act, at any time by notice served on the manager of
the organisation, call upon the organisation to show cause within fifteen days why the certificate or
recognition of the organisation should not be withdrawn and if no explanation is submitted or the
explanation is found to be unsatisfactory, declare that the certification or recognition of the
organisation, as the case may be, has been withdrawn.(3)When an organisation ceases to be an
organisation certified or recognised under Sections 8,9, 34,37 or 44 of the Act, the children kept
therein shall, under orders of the Commissioner, be transferred to some other institution
established, certified or recognised under Sections 8,9,34,37 or 44 of the Act, in accordance with the
provisions of the Act. Intimation of such transfer shall be given to the Competent Authority.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

48. Grant-in-Aid to certified or recognised organisation.
- An organisation or person certified or recognised under Sections 2(h), 2(i), 8,9, 34, 37 or 44 of the
Act may, during the period in which the certification or recognition is in force, apply for grant-in-aid
by the State Government or Government of India for maintenance of children received by them
under the Provisions of the Act and for expenses incurred on their education, treatment, vocational
training, development and rehabilitation. The grant-in-aid may be admissible at such rates, which
shall be able to meet the prescribed norms in such manner and subject to such conditions as may be
mutually agreed upon by both the parties.
Chapter IX
49. Selection Committee.
(1)The Chairperson and members of the Child Welfare Committee, the Social Worker Members of
the Juvenile Justice Board and Members of the Inspection Committees shall be selected by a
Selection Committee set up by the State Government, for the purpose. The Selection Committee
shall consist of the following seven members:(a)A retired Judge of the High Court or a retired
Secretary to the State Government having experience in Social Welfare shall be the Chairperson of
the Selection Committee:(b)Two representatives of reputed Non-Governmental Organisations
working in the area of Child Welfare:(c)A representative from an Academic Body/University
preferably from the faculty of Social Sciences/ Psychology and(d)Three representatives from the
State Government, one each from the Department of Juvenile Welfare, Department of Women
Development and Child Welfare and the Education Department.(2)The Selection Committee shall
take into consideration the panel of names recommended by the concerned Local Authority and
District Collector for selection of members of the Child Welfare Committee, the Social Worker
Members of the Juvenile Justice Board and Members of the Inspection Committees, hereinafter
referred to as the Members, unless the context otherwise requires. The Selection Committee shall
also prepare a list of persons selected to fill in vacancies, which may arise during the tenure of the
Members.
50. Qualifications, terms and other conditions of the Members.
(1)A person to be selected as a Member should be a person having a child-friendly attitude. In
addition, he should be:(a)A person having special knowledge of social work/child psychology/
education/sociology/Home Science or(b)A teacher or a doctor or a retired public servant who has
been involved in work concerning child welfare or(c)A Social Worker of repute who has been
directly engaged in Child Welfare.The Social Worker Members of the Board must have been actively
involved in health, education or welfare activities for at least seven years.(2)The Members of the
Inspection Committee shall include a representative each from the State Government and the Local
Authority. The Inspection Committee shall have at least five members.(3)The Chairperson of the
Child Welfare Committee shall be at least a graduate with one or more of the qualifications given in
sub-rule (1).(4)The Members shall have a tenure of three years.(5)The Members shall be eligible forAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

appointment for a maximum of two terms and shall not be more than 65 years at the time of first
appointment.(6)A Member may resign at any time by giving one month's advance notice in
writing.(7)The appointment of a Member of the Inspection Committee may be terminated in the
same manner as that of a Member of the Child Welfare Committee under Section 29(4).(8)Any
causal vacancy on the Committee may be filled by appointment of another person from the waiting
list/panel, who shall hold officer for the remaining term of the person in whose place the Member
has been appointed.(9)The Members shall be paid such travelling/meeting allowance or honorarium
as the State Government may fix from time to time.(10)No person who has been guilty of an offence
involving moral turpitude shall be appointed as a member by the Selection Committee.
Chapter X
51. State Advisory Board.
(1)The State Government shall constitute a State Advisory Board. The term of the Board shall be for
three years. The Inspection Committees are also the Advisory Boards at the District and City level
under Section 62(3). These Boards shall hold at least two meetings in a year. These Boards shall also
inspect the various Institutions or non-institutional services in their respective jurisdictions, obtain
uninhibited feed back from the Children and make recommendation for the improvement of
Institution/non-institutional services. The recommendations made shall be discussed by the Home
Committees/concerned authorities and appropriate action taken thereon.(2)The State Advisory
Board set up under Section 62 of the Act shall consist the following:
(a) Minister in charge of Juvenile JusticeServices ... Chairman
(b) Secretary in charge of Juvenile JusticeServices ... Member
(c) Secretary, Education ... Member
(d) Secretary, Health ...Member
(e) Secretary, Home ... Member
(f) Secretary, Labour and Employment .... Member
(g) Secretary, Technical Education .... Member
(h) Secretary, Finance .... Member
(i) An Industrialist ... Member
(j) A Journalist ... Member
(k) A Representative of the Bank ... Member
(l) Two Social Workers/Representatives ofVoluntary Organisations ... Member
(m) Director/Commissioner in charge of JuvenileJustice Services ... Member/Secretary
(3)The State Advisory Board shall appoint a Treasurer, from among their members.(4)The functions
of the Advisory Board shall be as follows:(a)To advise State Government on matters relating to the
development of Juvenile Justice Services through various official and community based welfare
agencies.(b)To consider ways and means of mobilising human and material resources to ensure
social justice to children coming in conflict with law and in need of care and protection.(c)To issueAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

guidelines for the development of facilities for education, vocational training and rehabilitation of
various categories of children coming with the purview of the Juvenile Justice System.(d)To serve as
a forum for an effective co-ordination between various sectors of Child Development in dealing with
the problems of children under the Act.(5)The non-official members of the Advisory Board shall be
appointed by the State Government on the recommendation of the Commissioner. The non-official
members shall hold office for a term of three years from the date of appointment and shall be
eligible for reappointment. The tenure of the non-official member may, be terminated by the State
Government, without assigning any reason. Any casual vacancy among the non-official members
shall be filled by the appointment of another non-official member, who shall hold office for the
remaining period.
52. Juvenile Welfare Fund.
(1)The State Government shall create a fund at State level under Section 61, to be called the
"Juvenile Welfare Fund (hereinafter referred to as the Fund) for the welfare and rehabilitation of the
children dealt with under the provisions of the Act. Besides voluntary donations and contributions
to the Fund from the Central Government.(2)The donations made to the Fund shall be exempted
from income tax under Section 80 G of the Income Tax Act, 1961.(3)The fund shall be applied:(a)to
implement programmes for the welfare and rehabilitation of children:(b)to pay grant-in-aid to
non-official organisations;(c)to meet the expenses of State Advisory Board and(d)to do all other
things that are incidental and conducive to the above purposes.(4)The management and
administration of the Fund will be under the control of the State Advisory Board under subsection
(3) of Section 61 of the Act.(5)The assets of the Fund shall include all such grants and contributions,
recurring or non-recurring, from the Central and State Governments or any other statutory or
non-statutory bodies set up by the Central or State Government as well as the voluntary donations
from any individual or organisation.(6)Withdrawal shall be made by cheques or requisitions, as the
case may be, signed by the Treasurer in the case of amounts not exceeding Rs. 1,000 (Rupees one
thousand) and signed duly by the Treasurer and other members of the Board of management to be
nominated by the State Advisory Board, for amounts exceeding Rs. 1,000 (Rupees one
thousand).(7)Regular accounts shall be kept of all money and properties and all incomes and
expenditure of the fund and shall be audited by a notified firm of Chartered Accountants or any
other recognised authority, as may be appointed by the State Advisory Board. All contracts and
other assurances shall be in the name of the State Advisory Board and signed on their behalf by the
Secretary.(8)The State Advisory Board shall invest the proceeds of sale or other disposal of the
property as well as any money or property not immediately required to be used to serve the objective
of the fund in any one or more of the modes of investment for the time being authorised by law for
the investment of trust moneys as the Board of Management may think proper.(9)The State
Advisory Board may delegate to one or more of the members of the Commissioner such of its
powers, which in its opinion are merely procedural.
53. Social Audit.
- The Central or the State Government shall monitor and evaluate the functioning of the Homes
annually with the help of leading organisations working with children and autonomous bodies likeAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

National Institute of Public Co-operation and Child Development, Indian Council for Child Welfare,
Indian Council for Social Institute, Child Line India Foundation, National Institute of Social
Defence, Central and State Level Social Welfare Boards, School of Social Work etc.
54. Training, Seminars, Workshops.
(1)The Commissioner shall ensure that all the Members of the Board and the Child Welfare
Committee are given training/orientation on child psychology, child welfare, child rights, and also a
copy of the Act and the Rules, either prior to or soon after their assuming office.(2)The
Commissioner shall organise at least two workshops/seminars per year, involving the Juvenile
Justice Board, the Child Welfare Committees, experts in the filed of Juvenile Justice/ Childcare and
others working with the children under the Act, to discuss the problems in the effective
implementation of the Act and to take remedial measures.
Chapter XI
Officers and Personnel Organisation
55. Headquarters organisation.
(1)The State Government shall provide for the appointment of staff for the supervision, control and
development of services under the Act.(2)The Headquarters Organisation shall have a separate wing
for the development of education, vocational training and rehabilitation services as well as for the
placement of children leaving the Institutions. Such a wing shall also have a unit for women, with
the specific function of securing for girls opportunities for their integration into the community
through employment, vocational placement, marriage, etc. There shall also be a separate wing for
research and development, supported by good documentation, for the advancement of juvenile
Justice and Child Welfare.(3)One of the main objectives of the headquarters organisation will be the
development of infrastructure in the voluntary sector for providing services under the Juvenile
Justice System.(4)The functions of the headquarters organisation will be as follows:(a)Planning,
directing, co-ordinating, controlling, supervision and guiding the activities in the field of juvenile
Justice;(b)Formulating progressive policies for implementation of Juvenile Justice Services and
placing them before the Government;(c)Implementing Government policies regarding juvenile
justice;(d)Preparing plan and non-plan schemes for the development of the
department;(e)Formulating annual budgets and exercising financial control;(f)Releasing
grant-in-aid for juvenile justice activities;(g)Inspection of juvenile justice
programmes;(h)Departmental audit of Juvenile Justice Institutions and activities;(i)Training of
both Governmental and voluntary functionaries engaged in juvenile justice activities;(j)Preparation
of annual reports and compilation of statistics; and(k)Research and evaluation.(5)In addition to the
duties specified in these Rules and the over all control and supervision over the headquarters
organisation and the other functionaries, the Commissioner shall be responsible for the inspection
of institutions set up or recognised under the Act. His inspection reports shall contain comments
and suggestions on the following items pertaining to the working of the institution:(a)Physical
setting in terms of building, space, requirements, living quarters for children, class rooms, sick roomAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

water supply and sanitary arrangements, play-grounds, quarters on the premises for essential staff,
general cleanliness; etc.(b)Quantity and quality of food given to the children;(c)Clothing and
bedding;(d)Facilities for medical treatment including arrangements for immunisation and
preventive and curative services;(e)Arrangements for education and vocational
training;(f)Maintenance of case files of child in institutions;(g)Arrangements made for recreation,
games, physical training, library etc.,(h)Provision of staff of various categories;(i)Registers and
Accounts;(j)Difficulties and grievances of personnel;(k)Difficulties and grievances of children
and(l)Review of the impact of the institutional programmes.
56. Chief Executive/Commissioner-Chief Inspector of Homes.
- (3) Powers and Functions:All the staff of the Department shall obey the orders, issued from time to
time by the Commissioner in all matters relating to internal economy, discipline and management of
institutions under the Act.(4)Control of Expenditure and other Duties:(a)Subject to the rules and
orders of the Government and to the requirements of the Accountant General, the expenditure of
the Homes shall be controlled by the Commissioner.(b)At the commencement of each financial year,
the Commissioner shall distribute the total budget allotment among the several drawing officers of
the Homes.(c)Adequate provision must be made in the Budget for providing to the children
academic education, vocational training, engaging instructors on contract basis, the necessary
equipment and material, extra-curricular activities including intra-state and inter-state sports and
other competitions and for recreational material.(d)The financial powers of the Commissioner shall
be as set out in Schedule No. 10 to these Rules.(e)The Commissioner is authorised to sanction all
contracts necessary for the due and economic administration of the Homes under his control. Every
contract for the supply of articles required for the institutions or which impose a recurring liability
on the institution, shall be drawn up in Form No. X and duly stamped, except in the case of
contracts with Government departments. No contract or agreement can be considered valid unless
executed by the Commissioner. He may also sanction the institution of civil suits against defaulting
contractors and others. Every case in which notice of suit against the department or against any
officer of the Institution, for acts done in his official capacity is received, the same shall be referred
to the Government for necessary orders in the matter.(5)Inspections:(a)During each inspection, the
Commissioner shall endeavour to personally see every child in the institution, give every child a
reasonable opportunity of making any request or complaint and take appropriate action
thereon.(b)The Commissioner shall inspect the dormitories, workshops,'class rooms, hospitals and
other enclosures. He shall also verify the security, sanitary, conservancy and drinking water supply
arrangements and their availability. Quality and quantity of the food, clothing and bedding shall also
be inspected.(c)The Commissioner shall inspect all registers, documents, books and journals of the
Homes to the extent possible and give the necessary directions.(d)The Commissioner shall submit to
the Government a report on the inspections of the Home embodying his opinion as to the manner in
which the institution is administered and the extend to which the staff appear familiar with their
duties together with any orders or suggestions found necessary for the guidance of the
Superintendent. Copy of the report shall also be sent to Superintendent of the Home for ,
compliance.(e)The Commissioner shall submit annual administration report to the Government
indicating the details of the administration of Homes, children and services with statistical
information from time to time.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

57. Assistant Chief Executive/Joint Director/Assistant Chief Inspector of
Homes.
- The Joint Director shall assist the Commissioner in implementing the Act as well as The Probation
of Offenders Act, 1958 and discharge all the functions which the Commissioner may delegate to him.
He shall:(a)Inspect all the homes under the Act and the Offices of the eight Regional Inspectors of
Probation, at least for ten days in a month.(b)Be responsible for evolving plan Schemes for the
development of Juvenile Institutions and probation services in the State's endeavour to implement
successfully.(c)Supervise the work of Chief Probation Superintendent/ Deputy Director of
Correctional Services and ensure that both the officers perform their duties entrusted to them in an
effective manner.(d)Assist the Commissioner in conducting periodical seminars and conferences
intended to enlist the co-operation of the various Agencies and create public consciousness with
regard to the rehabilitation of persons released on probation or under the Act.
58. Deputy Directors/Inspector of Homes.
(1)The Deputy Directors shall assist the Commissioner and carry out all instructions issued by the
Commissioner from time to time.(2)The Deputy Directors shall inspect the HOmes periodically.
They shall submit the reports to the Commissioner on the inspections carried out by them, marking
a copy to the Superintendent concerned for compliance.
59. Special Officer.
- To deal with the teething problems in the effective implementation of the Act, a Special Officer,
well acquainted with the provisions of the Act and the Rules, in letter and in spirit, and having a
good track record as a Superintendent, shall be appointed for a period of three years, to visit all the
institutions in the State and assist in their effective functioning in accordance with the Act and the
Rules.
60. Home Personnel organisation.
(1)The staff strength of a Home shall be determined with reference to the duty, posts, hours of duty
per day as the base for each category of staff. The institutional organisational set up shall be fixed in
accordance with the size of the Home, the capacity, work load, distribution of functions and
requirements of programmes.(2)The whole time staff in a Home may consist of Superintendent,
Probation Officer (in case of Observation Home/ Special Home), case Workers (in case of Children's
Home/Shelter Home), Child Welfare Officers, Counsellor, Educator, Vocational Training Instructor,
Medical staff. Administrative staff, Care Takers, House Father/House Mother, Store Keeper, Cook,
Helper, Washerman Safai, Karamchari, Gardener as required. A House Mother/House Father shall
be appointed for every 25 children.(3)The part-time staff shall include Psychiatrist, Occupational
Therapist and other professionals as may be required from time to time.(4)The staff of the Home
shall be subject to control and overall supervision of the Superintendent, who by order shall
determine their specific responsibilities and shall keep the concerned authority informed of suchAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

order made by him from time to time. The Superintendent and such other staff who may be required
shall live in the quarters provided for them within the premises of the Home.(5)The specific duties
of each category of staff working in the Institutions are as shown in Schedule - 3. These duties are in
addition to the duties mentioned in the above Rules.
61. Training of personnel.
- To ensure the qualitative implementation of the Act and the Rules, it is essential that the staff of
the Institutions are given specialised training on issues related to child development,
co-management, tracing and reintegration of the child with the family, self-reliance skills for the
children and documentation of the work done. Training Manuals shall be prepared in consultation
with Institutions like the Regional Institute of Correctional Administration (RICA), Vellore; The
State Institution of Correctional Administration (SICA), Hyderabad; The National Institute of Social
Defence (NISD), New Delhi, etc. The State Government shall provide for training of personnel of
each category of staff in keeping with their statutory responsibilities and specific job; requirements.
The Training programme shall include:(1)Refresher training courses for every staff member at least
once an year(2)Staff conferences, seminars, workshops, etc., at various levels of the personnel
organisation periodically and(3)The functionaries of the department shall be sent for necessary
training courses organised by RICA, SICA NISD and other training agencies.
I
The object of the Juvenile Justice (Care and Protection of Children) Act, 2000(Rule 2(9))The object
of the Juvenile Justice (Care And Protection of Children) Act, 2000 is to make effective provision in
law for the children in need of care and protection and children in conflict with law, by providing for
their proper care, protection and treatment, by catering to their development needs, by adopting a
child-friendly approach in the adjudication and disposition of matters in the best interest of children
for their ultimate rehabilitation and ensuring the realisation and fulfillment of the Child Rights
Convention. The success in the realisation of these goals will depend more on the spirit of
implementation of the Act and attitudinal aspect of the personnel involved rather than on
infrastructure and procedures alone. The following principles shall, inter alia, be fundamental to the
development of strategies, interpretation and implementation of the Act.
1. Principle of nurturing a child. - To cherish and nurture the wonder in the
vision of a child. To make use of the great opportunity of working with
children and sharing in the wonder and not destroying it.
2. Principle of no harm, no maltreatment. - At all stages, from the initial
contact till disposition, extreme care shall be taken to avoid any harm to the
sensitivity of the child. The Child who is placed in any institution under the
Act or under any placement cushion shall not be subjected to any harm,
abuse, neglect, maltreatment, corporal punishment or solitary confinement.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

3. Principle of Best Interest. - In all actions concerning children, whether
undertaken by the social welfare institutions, courts of law, administrative
authorities or legislative bodies, the best interest of the child shall be the
primary consideration. The child is entitled to an environment of happiness,
love and understanding. The child shall not be treated as a mere object of
socialisation or control, but as an active partner. The child should be helped
to acquire interest in and to learn various skills appropriate to the child's age,
including academic education and vocational training. The child's respect for
truth shall be nurtured and cherished. The scientific temper should be
encouraged in the child.
4. Principle of Concern. - Concern for all living beings and the environment
shall be promoted in the child.
5. Principle of Family Cushion. - The family, biological, adoptive or foster (in
that order), must be involved in the processes, preferred as placement
cushion and strengthened as the base unit for care protection and
development of the child, unless the best interests of the child dictate
otherwise.
6. Principle of Right to Privacy and Confidentiality. - The child's rights to
privacy and confidentiality shall be protected by all means and through all
stages of the proceedings.
7. Principle of Equality. - There shall be no discrimination against the child
on the ground of place of birth, disability, race, caste, religion or sex.
8. Principle of Non-Waiver of Rights. - No waiver of rights of the child
whether by himself/herself or the competent authority or anyone acting or
claiming to act on behalf of the child is either permissible or valid.
9. Principle of Fresh Start. - The Principle of fresh start promotes a new
beginning for the child by ensuring eraser of the child's past records.
10. Principle of Last Resort. - Institutionalisation of the child will be a step of
the last resort and after reasonable enquiry and that too, for the minimum
possible duration.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

11. Principle of non-stigmatising semantics, decisions and action. - The use
of adversarial or accusatory words, such as, arrest, remand, committal,
accused, charge-sheet, trial, prosecution, warrant, summons, conviction,
child, delinquent, neglected, custody, etc. is to be avoided in the processes
pertaining to the child under the Act.
12. Principle of Repatriation. - Any child who is a foreign national and who
has lost contact with his/her family shall also be eligible for protection under
the Act and he shall be repatriated, at the earliest to his/her country.
Schedule 2
Selection Criterion of NGO's(Rule 38(5))The following criterion should be followed for selection of
NGO partners in Co-management:(1)Registered NGOs with a good track record and having not less
than three years field experience of working with children in difficult circumstances.(2)The NGO
should have necessarily worked on education and other child related issues.(3)The NGO should
have Credible financial management and capacity for financial resources management.(4)The NGO
should have been networking and collaborating with Government and non-Government bodies for
programmes and activities.(5)The NGO should have a strong team of trained personnel working in
the organisation.(6)The NGO shall be willing to commit time, energy and resources (human,
finances) for the implementation of the programme.
Schedule 3
Duties of the Staff(Rule 60(5))
1. Duties of Superintendent:
(1)Superintendent shall attend to the following duties:(a)Attending to the care and welfare
requirement of children:(b)Convening the meetings of the Home Committees and is responsible for
its effective functioning;(c)Proper maintenance of buildings and premises;(d)Proper custody and
handling of tools and equipment;(e)Prompt, firm and considerate handling of all disciplinary
matters;(f)Adequate security measures and periodical inspection thereof;(g)System of good
discipline;(h)Accident preventing measures;(i)Fire fighting equipment at all vulnerable
points;(j)Good environmental and institutional sanitation and hygiene;(k)Proper procedure of
quarantining of newly admitted children;(1)Segregation of children suffering from contagious
diseases;(m)Proper storage and inspection of articles of food stuffs;(n)Observance of the required
minimum standards in kitchen operations, service of food and eatables;(o)Stand-by arrangements
for water storage, power plant, emergency lighting etc.(p)Be responsible for obtaining reports from
Probation Officers for quick disposal of the cases.(2)Maintenance of Office Journal:(a)The
Superintendent shall in his own handwriting maintain an office journal in which he shall record
daily occurrences of important events connected with the management of the institution.(b)AnAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

extract of the Office journal shall be forwarded to the Chief Inspector/Commissioner by the fifth day
of the month following the month to which it relates to and the Chief Inspector/Commissioner shall
immediately return it after perusal with such remarks as he may consider necessary.(3)Office Order
Book: The Superintendent shall maintain an Institution Order Book in which, he shall record all
Standing Orders issued to his subordinates form time to time.(4)Documents to be kept in personal
custody of the Superintendent. The following documents shall be kept in the personal custody of the
Superintendent:(a)Contract deeds(b)Contractor's security deposit receipts(c)Personal files of the
staff members, excepting that of the Deputy Superintendent and Case Worker, which would be in
the personal custody of Deputy Director/ Inspector of Homes.(d)Security deposit furnished by the
staff.(5)Inspection of food by the Superintendent: The Superintendent shall be responsible for the
procurement of approved quality of provisions from approved contractors by the District Level
Committee and in case of local purchase, he shall ascertain himself of the current market rates and
satisfy that the dietary articles are purchased at reasonable rates. He shall ensure that the ration
issued to the cooks is weighed according to the diet scales, he shall inspect the cooked food daily
along with the Institution Doctor and make arrangements for proper distribution among the
children. The result of the Superintendent's inspection of food shall be noted in the Office
Journal.(6)Other duties:(a)The Superintendent shall pay special attention to the ventilation of the.
sleeping wards. In all cases, care shall be taken that there is sufficient lateral as well as roof
ventilation. The Superintendent shall at all seasons and at uncertain intervals visit the institution
along with the institution doctor at night to satisfy themselves that the ventilation arrangements are
adequate, the children are behaving properly and that the guardian staff members are carrying out
their duties properly. The result of these visits, which shall take place at least once a month, shall be
recorded in the Office Journal and reported to the Commissioner.(b)The Superintendent shall see
that the sanitary arrangements of the institution are in every respect thoroughly satisfactory. He
shall also ensure that the instructions of the Institutional Doctor or Medical Officer are carried out
immediately regarding the sick in the hospital.(c)The Superintendent shall be responsible for all the
property of the institution and for all money and stores received.(d)The Superintendent should
scrutinise at the end of every financial year the inventory of valuable stock.(e)The Superintendent
shall be responsible for the timely provision of the educational and vocational training material to
the children(7)Weekly Inspection:(a)On one morning in every week, which shall usually be Monday,
the Superintendent shall hold an inspection parade of all the children at which the Institution
Doctor shall also be present.(b)At each such parade, the Superintendent shall satisfy himself:(1)that
every child is provided with proper clothing and bedding.(2)that they are clean and tidy and(3)that
the rules and orders applicable to the children are being duly carried out.(c)The Superintendent,
shall at every such Parade, hear and enquire into any complaints and the requests that the children
may wish to make. It shall be his duty to hear the complaints and requests of children patiently and
to afford them reasonable facilities for making such complaints and requests. A child who makes
any complaint should not be ill-treated or punished, orally or physically.(d)Nothing in clause (c)
shall prevent a child from making a complaint or request to the Superintendent at any time other
than at the weekly parade and it shall be the duty of every member of the staff to produce before the
Superintendent without delay any child desiring to see him.(8)Report of important occurrences:
Any outbreak of epidemic, unusual sickness, and all accidents, suicides or deaths shall at once be
reported by the Superintendent to the Medical Officer and Commissioner over phone / fax. All
escapes and recaptures shall immediately be reported by the Superintendent to the CommissionerAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

over phone /fax.(9)Physical weighment of all articles: The Superintendent shall physically weigh
and verify the quality and quantity of all articles and commodities received from the institution and
ensure that necessary entries are made in the relevant registers under his attestation. He shall also
conduct physical verification of dietary articles once in a quarter or even earlier if he considers
necessary.(10)Previous sanction to leave Headquarters: Without written sanction of the
Commissioner, the Superintendent of an institution shall on no account absent himself from the
station. Similarly, without the written sanction of the Superintendent, the other members of the
staff and the institution Doctor of a Government institution shall not leave the Headquarters.(11)The
Superintendent shall organise competition in essay writing poetry writing, debates on current
topics, quiz programmes, dramatics, sports and games etc., once a year i.e., on Children's Day (14th
November) /Child Rights Convention Day (20th November) and distribute prizes thereof or;(12)He
should also conduct career guidance to all high school students once a year through university
teachers/reputed social workers.(13)The Superintendent shall maintain in the office such registers,
records, reports etc., as may be prescribed by the Act and Rules to be furnished in following
issues:(a)Monthly reports to be submitted by the Homes.(b)Quarterly and Annual
reports.(c)Disposal of records and registers, properties etc.(d)Transfer of children from one Home
to another.(e)Interstate transfer of children.(f)Short leave/absences of children(g)Releases(h)Public
relations, transparency of records(i)Reports of DPOs are important in enquiry proceedings by the
Child Welfare Committee and Juvenile Justice Boards (They are confidential).(j)Any other record
that may be required.
2. Duties of Medical Officer (institution Doctor) and Medical staff:
(1)Medical Officer:(a)Every institution shall have a full time Civil Assistant Surgeon called 'Medical
Officer'. He/she shall ordinarily attend the institution regularly every day from 8 a.m. to 2 pm on all
working days or at such other timings as may be necessary. He/She shall attend the institution on
holidays also, whenever .(b)The Medical Officer (except in professional matters) shall be a
subordinate to the Superintendent.(c)It shall be the duty of the Medical Officer to attend to the
health and cleanliness of the children, the treatment of the sick, the sanitation of the institution, the
supervision of the food and all other matters connected directly or indirectly with the health of the
children of the institution.(d)The Medical Officer shall set apart sometime, preferably in the
morning, before the normal school hours commence, and examine and treat all minor ailment cases
as out-patients. For such out-patients, he/she shall maintain a separate Register in the Form
prescribed by the Commissioner recording thereon the number and name of the child with
parentage, age, ailment and the medicines prescribed.(e)For every in-patient admitted to the
Institution Hospital, a separate record in the Form prescribed by the Commissioner shall be
maintained, entering therein the nature of illness and the treatment given every day, till such time
the child is cured of the illness and discharged. Any extra or special diet prescribed for him shall also
be recorded.(f)on admission, every child should be weighed and measured and thereafter in the first
week of every month, regularly. The Medical Officer shall be responsible for this and he shall record
such weight in a Register in the form prescribed by the Commissioner. The Medical Officer shall
take special care in respect of children who show loss of weight and in cases of children of poor
physique, he shall also arrange for their periodic inoculations at the appropriate time.(g)The
Medical Officer shall maintain a journal in the form prescribed by the Commissioner in which theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

following shall be recorded:
1. The date and hour at which he entered and left the institution.
2. The number of in-patients in the institution hospital.
3. The number of out-patients examined and treated on that day
4. The areas of the Institutions examined and any advice given on ventilation,
hygiene, sanitation etc.
5. Any defects in the cooked food.
6. Any defects in the water supply, sanitary or other arrangements, which
he/she considers injurious to the health of the children, together with his/her
remedial suggestions.
7. Any marked increase in in-patients or out-patients and the apparent cause
for the same.
8. Any case of malingering on the part of children and
9. Any observation, recommendation or directions regarding individual
children.
10. General or special remarks.
The journal shall be sent immediately on each day to the Superintendent for such orders as the
Superintendent may deem fit.(h)He /She shall be responsible for the proper utilisation of all
medicines and other medical instruments. He / she shall see that they are under proper lock and key
and special care shall be taken in respect of poisonous drugs. He/she shall from time to time,
examine all the medicines kept in the stores to ensure their purity and see that the medicines whose
period has expired are destroyed under proper authority and in his presence. To avoid excess
storage of medicines, sufficient care should be taken at the time of preparation of annual indents
and any quantity over and above the actual quantum required should not be indented for.(i)He/she
shall not communicate with the Director of Medical and Health Services directly, but do so through
the Superintendent of the institution and the Commissioner, (j) He/She shall inspect meat, milk,
vegetables, bread etc., which are purchased daily and if in his opinion, the supply is not up to the
standard, he shall give a report to the Superintendent.(k)He /she shall maintain a separate register
in the Form prescribed by the Commissioner for sick-diet and extra-diet prescribed for the health of
the children.(l)He/She shall attend on all staff members, Home officials and their families at theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

institution premises. He/She shall also record details of the treatment given in separate register,
which shall be periodically examined by the Medical Officer for treatment.(m)He/she shall also
examine all candidates for employment in the institution and shall certify in writing regarding their
physical capacity and state of health.(n)He/she shall also examine any staff members referred to be
the Superintendent and furnish the report required in writing.
1. Medical Staff:
(a)Duties of Pharmacist/ Compounder:(1)The Pharmacist/Compounder shall assist the Medical
Officer. He/she shall obey the lawful orders of the Medical Officer in all matters connected with the
medical work of the institution and of the Superintendent in other matters.(2)The
Pharmacist/Compounder shall help the Medical Officer in the maintenance of the health of the
children and the staff by distributing medicines; by arranging periodical vaccination and inoculation
and weighing children; performing clerical work connected with the institution hospital;
maintaining order and discipline in the institution hospital and to carry out such other duties of a
like-nature as may be entrusted to them by the Medical Officer.(b)Duties of the Nursing Orderly;
1. The Nursing Orderly shall see that the bed-head tickets of in-patients are
maintained regularly and properly and shall put up the same before the
Medical Officer everyday at the time of his checking up the in-patients. The
instructions issued by the Medical Officer in the bed-head tickets should be
scrupulously followed. The bed-head tickets shall be maintained in Form No.
10.
2. The Nursing Orderly when required shall be on night duty to look after the
inpatients who require special attention as per orders of the Medical
Officer/Superintendent, both at institution hospital and also outside hospital.
3. The Male Nursing Orderly, however, need not be assigned night duty in
female wards.
3. Admission of Children in outside Hospitals:
As and when the Medical Officer feels that the admission of a sick child in an outside hospital, for
further observation and treatment, is necessary, he shall report the fact immediately to the
Superintendent. The Superintendent shall arrange for the children to be sent to such outside
hospital along with a brief report from the Medical Officer as to the nature of the disease and
treatment given. He/she shall intimate the parents of the child about such admission.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

4. Duties of Deputy Superintendent:
(a)General supervision of the functioning of the Home, daily routine and assisting the
Superintendent in day-to-day affairs of the Home. He shall make rounds at least once in three hours
to verify that the staff are attending to their duties properly.(b)He shall maintain a daily journal/
report book indicating the important occurrences/events for perusal of the Superintendent.(c)He
shall have control over the executive staff, supervisory staff and the menial staff.(d)All papers except
those of a confidential nature shall ordinarily be routed through him to the Superintendent.(e)He
shall be in charge of maintenance of Civil Stores, sports goods, electrical goods and livestock.(f)He
shall be in charge of raw materials, manufactured articles and supervision of manufacturing section
and passing of indents.(g)He shall have control over issue of ration articles, cooking, maintenance
and distribution of clothing and bedding items.(h)He shall reside in rent-free quarters, if
provided.(i)All mail shall be opened and initialled by the Superintendent/Deputy Superintendent,
who shall allot them to the concerned, under his initials for disposal.(j)Any other duty that may be
assigned to him by the Superintendent for the efficient and proper administration of the
institution.(k)Supervision of petty construction and repairs and proper upkeep of Home buildings
and staff quarters will also come under his purview.
5. Duties of Case Workers/Child Welfare Officer:
The general duties, functions and responsibilities of Case Worker/Child Welfare Officer shall be as
follows:(a)Looking after the children, building a rapport with the children, helping them in gaining
emotional stability and in their all round development.(b)Maintenance of case histories of all
children in the form prescribed by the Commissioner and Case Files under Rule 19.(c)Supervision
and control over Teachers and Instructors.(d)Admission, leave of absence and discharge of
children.(e)Responsible for proper custody of committal warrants.(f)Giving training to the children
and maintenance of proper discipline among them.(g)Regulation of interviews and communications
with children.(h)Supervision over distribution of food to the children.(i)Supervision and control
over organisation of games, drill picnics, outing and all other extra-curricular
activities.(j)Supervision of the library and reading room.(k)His quarterly observations should deal
with amongst others:
1. The child's adjustment to institutional environment.
2. The child's response to the educational or vocational programme.
3. The child's participation in group activities, his/her attitude towards
co-child, staff and others.
4. The child's relationship with his/her parents or guardians, interest shown
in interviews, communications etc.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

5. General progress of the child in respect of conduct, behaviour, attitude
and outlook.
6. At the time of discharge on licence or on expiry of committal period, the
caseworker should rehabilitation programmes to the concerned Probation
Officer.
7. Locating and identifying children who are backward, withdrawing,
quarrelsome, aggressive, violent etc., and try to bring them into the
mainstream of healthy activity.
(l)Guiding the concerned staff members in preparing educational, vocational, health records
etc.,(m)He shall assist the Superintendent in selection of proper educational, vocational and other
programmes to the children.(n)He shall identify children whose parents address is not known and
make special efforts to locate the parents and communicate with them. In case, the parents reside in
other State, he shall take action for interstate transfer.(o)He shall be present, as far as possible, at
the time of interviews, with parents or relatives and elicit information from them as to the behaviour
of the child during home leave. He should also note the attitude of the parents or relatives towards
the children.(p)Any other duties that way be assigned to him by the Superintendent for the efficient
and proper administration of the institution.(q)He shall reside in rent-free quarters, if provided.
6. Duties Of Probation Officers;
(1)On receipt of information from the Officer-in-charge of a police station, Juvenile Police Unit,
Child Welfare Officer or on orders of the Competent Authority, the Probation Officer shall enquire
into the antecedents and family history of the child and such other material circumstances as may be
necessary and submit a preliminary report as nearly as possible in Form IX to the competent
authority as early as may be allowed by the competent authority.(2)Every Probation Officer shall
carry out all directions given to him by a competent authority and the Commissioner and shall
perform the following duties:(a)to make inquiries regarding the home and school conditions,
conduct, character and health of a child under his supervision.(b)to attend regularly the hearings of
the Competent Authorities and to submit the necessary reports promptly.(c)to maintain case files
and such registers as may be prescribed from time to time.(d)to visit regularly the children placed
under his supervision and also place of employment or school attended by such children and to
submit regularly fortnightly reports in Form X.(e)to bring before the competent authority
immediately children who have not been of good behaviour during the period of
supervision.(f)follow up of children after their release from the institutions and extending help and
guidance to them.(g)establishing linkages with voluntary workers and organisations to facilitate
rehabilitation and social reintegration of a child and to ensure the necessary follow up.(3)A
Probation Officer:(a)shall not employ a child under his supervision for his own private purposes or
take any private services from him.(b)He shall ensure that the child's need of food and cloth are met
as per standard by personal enquiries with the child.(c)He shall ensure the cleanliness of theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

premises and maintenance of physical infrastructure including provisions of dress, water, electricity
etc.
7. Duties of Head Master:
(1)The Head Master shall be responsible for the day-to-day administration of the school of the
Home. He shall improve the quality of the academic institution and the maintain discipline among
students.(2)He, along with the Superintendent, shall be responsible for the timely issue of
textbooks, note books, stationery etc., required for the educational purposes of the children,(3)He
shall be in-charge of the library, the stock and issue of library books, magazines periodicals
etc.(4)He shall be responsible for organising and conducting educational training, cultural and other
recreational programmes.(5)He shall prepare the timetable for teachers and instructors and get It
approved by the Superintendent. When any teacher or instructor is on leave, he shall make suitable
arrangements for the teaching of the children of that class.(6)Applications for leave of teachers and
instructors should be routed through the Head Master and Case Worker to the Superintendent.
8. Duties of Senior and Junior House Master/House Mother/House Father:
(1)The House Master/House Father/ House Mother shall help the child to gain emotional stability.
They shall develop a bond with the child and help in their studies as well as other activities and
promote the well being of the child. They shall also be responsible for the discipline, training of
children, supervision of study classes, supervision of children's personal articles, search of
prohibited articles, cleanliness, roll call of children in the morning and in the evening, distribution
of food and other duties if any entrusted by the Superintendent.(2)The House Master shall go on
rounds frequently to check the duties performed by the Head Supervisors, Supervisors and other
Class IV Staff and also see that all children attend to their respective duties without allowing them to
loiter.(3)The Senior House Master shall maintain a daily roll register in Form No. XIII and submit it
daily to the Superintendent through the Case Worker and the Deputy Superintendent along with his
report book.(4)Applications for leave of Supervisors, Head Supervisors and Junior House Master
and menial staff should be routed through the Senior House Master and Deputy Superintendent to
Superintendent.
9. Duties of Head Supervisor/Matron Grade I:
(1)The Head Supervisor shall be in-charge of the Supervisory staff.(2)He/she shall be responsible
for the assignment of duty of Supervisors at various posts and shall get the day and night duty
rosters approved by the Senior House Master, Deputy Superintendent and Superintendent
daily.(3)He/she shall go on rounds frequently and see that the supervisors discharge their duties
promptly and correctly and any dereliction or neglect of duty shall be brought to the notice of the
Superintendent through the Senior House Master and Deputy Superintendent
immediately.(4)He/she shall maintain a report book and such other registers as may be specified by
the Superintendent.(5)He/she shall go on rounds at least once an hour while on night duty and
watch whether the Supervisors are attending to their duties.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

10. Duties of Supervisors and Matron Grade II:
(1)The Supervisors/Matrons shall perform watch and ward duties as per duty assigned to them by
the Superintendent or by any other superior officer. They shall not leave their posts without the
orders of such officer.(2)They shall deal with children with good temper, patience and good
manners.(3)They shall handle the children with love and affection.(4)They shall take proper care
and welfare of the children.(5)They shall maintain discipline in the institution in a child-friendly
manner.(6)They shall maintain sanitation and hygiene.(7)They shall Implement the daily routine in
an effective manner.(8)They shall strictly comply with the orders of superior officers and shall treat
all superior officers at all times with respect.(9)No supervisor shall be absent during the hour fixed
for his attendance without the permission of the Superintendent or the senior
officer-in-charge.(10)They shall be clean in person and dress.(11)When being relieved from any
particular duty or transferred to another part of the institution, they shall point out to their
successors, all matters of special importance connected with their charge and explain any directions
that might have been given to them by their superior officers.(12)Before taking charge, they, along
with the Head Supervisor, shall go through the entire premises, check all doors, windows, bars,
locks, nuts, bolts, etc., check all electrical fittings and bring to the notice of the Head Supervisor then
and there, any defect that is noticed. The Head Supervisor shall report immediately to the House
Master and get the defects rectified.(13)They shall see that no loss is caused to Government
properties.
11. General Duties of all Staff Members:
1. The duties shown in this Schedule are in addition to the duties prescribed
in the main body of the Rules. The staff shall also discharge such other
duties as the Government or the Commissioner may prescribe from time to
time.
2. No staff member shall, while on duty, drink alcohol nor introduce liquor/
tobacco or any other Such prohibited articles into the Institution.
Schedule 4
Procedure to be followed for Newly Admitted Children(Rules 13(4), 14(2)(5)(c) and 15(2))The
following is the procedure to be flowed for newly admitted children:
1. Medical examination and appropriate treatment shall be given at the
earliest, depending on the urgency, but not later than twenty-four hours in
any case. Any child suspected to be suffering from contagious/ infectious
diseases, mental ailments, addiction, etc., shall be immediately segregated in
specially earmarked dormitories or wards or hospitals, as the Medical OfficerAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

deems fit and the same informed to the Competent Authority and recorded in
the Admission Register.
2. On receipt of the orders of the Competent Authority, the Superintendent
shall verify the identification marks, register entries, cash property in the
possession of the child etc., and record the same.
3. The Superintendent shall see that every child received in the institution is
searched, with due regard to sensitivity and decency, that his/her personal
effects are inspected and that any money or valuables found with or on the
person of the child is kept in the safe custody of the Superintendent. Girls
shall be searched by a female member of the staff and with due regard to
decency.
4. In every institution a register of money, valuables and other articles found
with or on the person of a child received therein shall be maintained.
5. On a child being received in the institution, money valuables and other
articles found with him or on his/her person on search and inspection and
taken possession shall be entered in such register, and the entries relating to
him shall be read over to him in the presence of a witness whose signature
shall be obtained in token of the correctness of such entries. All such entries
shall be countersigned by the Superintendent.
6. Entries shall be made in such register and attested by the Superintendent,
showing in respect of every such search and inspection;
(a)The articles, if any, destroyed sold and stored;(b)In the case of articles sold, the amount
realised;(c)The details of any money, valuables or articles to be handed over at the time of release or
otherwise of the concerned admitted child;
7. The Superintendent shall direct the search and personal verification and
record the same.
8. Disinfection and storing of child's personal belongings and other
valuables.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

9. Haircut (unless prohibited by religion) issue of toiletry items and bath.
10. Issue of clean set of clothes, bedding and other outfit and equipment.
11. Attending to immediate and urgent needs of the children like interview
letter to parent(s), telephone call, appearance in examinations, personal
problems etc.
12. Every child shall be photographed and three copies of the photograph
shall be obtained. One photograph shall be kept in the case file of the child,
one shall be fixed with the index card in the third shall be kept in an album
serially. The negative shall be kept in another album.
Schedule 5
Facilities To Be Provided To The Children At The Homes(Rules 14(4) And 15(5)(B))
1. Physical infrastructure. - The standard of accommodation as prescribed in
Rule 24 shall apply. There should be adequate lighting, ventilation, heating
and cooling arrangements, drinking water and toilets, in terms of age and
hygiene.
2. Clothing and Bedding. - According to season and age appropriate as per
scale mentioned in Schedule - 8, shall be provided.
3. Nutrition. - The children shall be provided three meals including breakfast
etc., in a day. The menu shall be prepared with the help of a nutritional
expert/doctor to ensure balanced diet and variety in taste. The children may
be provided special meals on holidays. The normal dietary scale for children
shall be according to scale mentioned in Schedule - 7. Children below 7
years of age shall be given nourishment more frequently, as recommended
by the Medical Officer.
4. Medical. - The Home shall have arrangements for the medical facilities
preferably with a doctor and nurse. All children brought into the Home shall
be medically examined initially within 24 hours of arrival. The routine medical
checkup of the children must be done on monthly basis. The sick children
shall constantly be under medical supervision. In the event of outbreak ofAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

contagious/infectious diseases, segregation must be ensured. The medical
service shall include immunisation facility as prescribed by the National
Immunisation schedule. The Home shall have networking with local
doctors/hospitals for referral cases. The medical record of each child shall be
meticulously maintained in the file of the child. The record shall also include
weight and height record, any sickness and treatment, and other
physical/mental problems if any. In case of emergencies and when regular
Government doctors are not readily available, locally available private
qualified doctors shall be called to attend to the emergency needs of the
children.
5. No surgical treatment shall be carried out on a child without the previous
consent of his or her parent or guardian, unless either the parent or guardian
cannot be found and the condition of the child is such that any delay would
in the opinion of the Medical Officer involve unnecessary suffering or injury
to the health of the child.
6. A health record of each child in the institution shall be maintained on the
basis of quarterly medical check-up.
7. Children with mental illness shall be segregated in the same institution, if
so advised by the Medical Officer or sent to specialised Homes with proper
care for treatment as early as possible.
8. The parent/guardians, where the address is known, should be informed
about all serious illness.
Schedule 6
Daily Routine(Rule 20(2))
Wake up by 5.30 A.M
Attendance by 6.00 A.M.
Ablutions 6.00 A.M to 7.00 A.M.
Cleaning 7.00 A.M. to 7.30 A.M.
Bath 7.30 A.M to 8.00 A.M
Resume of day duty staff 8.00 A.M.
Break fast 8-30 A.M.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

Parade and Physical Drill for 20 Minutes after 9.00 A.M.
Prayer and disperse to classes and workshop 9.30 A.M. to 1.00 P.M.
Lunch 1.00 P.M. to 2.00 P.M.
After Noon classes 2.00 P.M. to 4.00 P.M.
Play Time 4.00 P.M. to 5.00 P.M.
Evening Attendance By Night duty staff 5.00 P.M. to 5.15 P.M.
Wash 5.15 P.M. to 6.00 P.M.
Reading Library, recreation 6.00 P.M. to 7.00 P.M.
Dinner 7.00 P.M. to 8.00 P.M.
Retiring to Dormitories 8.30 P.M.
Note. - The Superintendent may make minor changes in the timings to suit the practical needs like
bathing times according to the season. Retiring to dormitories in the evening may be delayed in
summer months and may be advanced in winter months.
Schedule 7
Diet Chart(Rule 21)
Name of the articles of diet Scale per head per day
(1) Rice500 Gms. 600 Gms
(16-18 yrs age)
(2) Wheat or Ragi or Jawar 100 Gms.
(3)Dal (Toor, Moong and Gramdal to be issued
asper convenience)120 Gms.
(4) Groundnut Oil 25 Gms.
(5) Onion 25 Gms.
(6) Salt 25 Gms.
(7) Turmeric 25 Gms.
(8) Corriandar 05 Gms.
(9) Garlic 05 Gms.
(10) Tamarind 15 Gms.
(11) Milk (at Breakfast) 60 MI
(12) Dry Chillies 05 Gms.
(13) Vegetables: Leaf 100 Gms.
 Hard 130 Gms.
(14) Milk to be converted into Butter milk 100 MI
(15) Chicken once a week or Eggs 4 days in a week 115 Gms.
(16) Jaggery (vegetarian only) (once in a week) 60 Gms.
(17) Ground Nut Seeds (Vegetarian only) (once 60 Gms.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

aweek)
(18) Sugar 40 Gms.
Following items for 50
Children per day
(19) Pepper 25 Gms.
(20) Jeera Seeds 25 Gms.
(21) Black Gramdall 50 Gms.
(22) Mustard seeds 50 Gms.
(23) Ginger 250 Gms.
On Chicken Day for 10 Kg.
of Chicken
(24) Garam Masala 10 Gms.
(25) Kopra 150 Gms.
(26) Khas Khas 150 Gms.
(27) Groundnut Oil 500 Gms.
For Sick Children
(28) Bread 500 Gms.
(29) Milk 500 MI
Other Items
(30) LP Gas for cooking only  
Instructions:(2)Variation in Diet:(a)Three varieties of dal i.e., Toor (Tuvari), Moong (Green Gram)
and Chana (Bengal Gram) may be issued alternatively.(b)Once a week, Chicken may be issued with
115 Gms or 4 Eggs per child per week alternatively. The Superintendent may also arrange to
substitute chicken with fish at his discretion, provided that there is no extra expenditure to
Government.(c)On non-vegetarian days, vegetarian children shall be issued with 60 Gms of Jaggery
and 60 Gms of Groundnut seeds per head in the shape of laddus or any other sweet dish provided
that there is no extra expenditure to Government.(d)Potatoes shall be issued in lieu of vegetables
once in a week.(e)Leafy vegetables such as Agathi, Spinach (Palak), Gongura, Thotakura etc., may
also be issued once in a week. Wherever a kitchen garden is attached to any institution such as leafy
vegetables, in addition to drumstick trees, curry leaves trees, coriander leaves etc., should be grown
and issued. The Superintendent should try to issue variety of and vegetables see that the same
variety of vegetables in not repeated at least within a period of one week.(f)The Superintendent may
make temporary alterations in the scale of diet in individual cases when considered necessary by
him, or on the institution Doctor's advice subject to the condition that the scale laid down is not
exceeded.(3)Meals Timing and Menu:(a)Breakfast after 8.00 a.m.
1. Upma or Chapatis made of Wheat or Ragi or any other dish.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

2. Chutneys from Gongura or fresh curry leave or fresh coriander or Coconut
and Putna dal. In this manner, dal may be issued as a dish.
(b)Lunch at 1-00 p.m. and Dinner after 7-00 p.m.
1. Rice
2. Vegetable Curry
3. Sambar/Pappucharu
4. Butter Milk
(4)Others:(a)Depending on the season, the Superintendent shall have the discretion to alter the
timing for distribution of food on the above lines.(b)On the advice of the Institution Doctor, every
sick child who is prevented from taking regular food, on account of his/her ill-health, may be issued
with medical diet, as indicated in diet scale.(c)Extra diet for nourishment like milk, eggs, sugar and
fruits shall be issued to the children on the advice of the institution Doctor in addition to the regular
diet, to pick up weight or for other health reasons. For the purpose of calculation of the daily ration,
the sick children shall be excluded from the day's strength.(d)On the following national and festival
occasions sweet dishes may be distributed to all the children at the Home at the rate fixed by the
Commissioner, from time to time.(1)Republic Day(2)Independence Day(3)14th November
(Children's day),(4)Child Rights Convention Day (20th November)(5)Ambedkar's birth day (April
14)(6)Mahatma Gandhi's Birth Day (2nd October)(7)Dasara (Vijayadasami)(8)Deepavali(9)Ramzan
(Id-UTFitr.)(10)Bakrid (Id-Uz-Zoha)(11)Christmas(12)Sankranti(13)Ugadi.
Schedule 8
Issue of clothing, bedding, toileteries and other articles(Rule 22)(1)Children shall be issued with the
following:
Clothing and
BeddingScale of supply per head
Boys
(1) Shirt 4 per year
(2) Shorts4 per year (below 14 yrs
age)
(3) Pants4 per year (above 14 yrs
age)
(4) Banyans 4 per year
(5)School Shoes (For Children attending
outsideschools)1 pair per yearAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

(6) Hawaii Chappals 1 pair per year
(7) Towels 4 per year
(8) Cotton Bed Sheets 2 per 2 years
(9) Pillow (Cotton stuffed) 1 per 2 years
(10) Pillow Covers 2 per 2 years
(11) Woolen blankets 1 per 2 years
(12) Cotton Durry 1 per 2 years
Senior Girls
(1) Half saris (21/2Meters) 5 per year
(2) Petticoats (3 Metres each) 5 per year
(3) Panties (1 Metre cloth each) 4 per year
(4) Blouses (11/2Metres) 6 per year
(5) Sanitary Towels 12 Packs per year
Junior Girls
(1) Skirts (21/2Metres each) 5 per year
(2) Blouses (1 Metre each) 6 per year
(3) Banyans (1 Metre each) 6 per year
(4) Panties 4 per year
Note. - (1) Senior/Junior Girls will also be provided with items from 4 to 9 given to boys in addition
to the items specifically provided for them.(2)Senior /Junior Girls will also be provided with items
from 4 to 9 given to boys in addition to the items specifically provided for them.(3)In addition to the
clothing specified above, each child shall be provided, once in three years, with as suit consisting of
one white shirt, one pair of Khaki shorts and one pair of white canvas shoe for use during
ceremonial occasions. In the case of girls it shall be one white half sari, one white skirt and one
white blouse (for senior girls) and one white skirt and one white blouse (for Junior girls) in addition
to a pair of white canvas shoes.(4)The children, who are admitted to out side schools to pursue
higher education, shall be provided with two shirts and two pairs of shorts per academic year, of the
uniform of the particular school. In addition they shall be provided with one pair of chappals and
one school bag for carrying books per year.(2)In every Hospital attached to the institution where
there is provision for in-patient cots, the following scale has to be followed:
 Clothing and Bedding Scale of supply per head
(1)Mattress One per bed per 3 years
(2)Cotton Bed sheets Four per bed per year
(3)Pillows One per bed per two years
(4)Pillow covers Four per bed per year
(5)Woollen blankets One per bed per 2 years
(6)Pyjamas and loose shirts (Hospital type) forboys 3 Pairs per bed per year
(7)Skirts and full sleeved blouses for girls 3 Pairs per bed per year
(8)Cotton durry One per bed per three yearsAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

Note. - 1. When a child is admitted as an in-patient in the Institution Hospital, the Institution
Doctor shall issue the in-patient with hospital clothing, the clothes on body being preserved, duly
washed and handed back, at the time of the child's discharge from the hospital.
2. Each child shall be provided with Kit- Box or a Locker, as per convenience
and necessity.
3. The Superintendent shall make arrangements for two-tier bed system in
place of conventional costs, as per convenience and necessity.
(3)Toiletry: every resident of the Home shall be issued with oil soap and other materials for in
accordance with the following Scales:
Boys
(1) Coconut oil for grooming the hair 100 mgs per month
(2) Toilet soap or carbolic soap 1 soap per month
(3) Tooth powder and Brush 1 Brush per 6 months 50 gms per month
Girls
(1) Coconut oil for grooming the hair 50 gms per week
(2) Toilet soap or carbolic soap 1 soap per month
(3) Tooth powder and Brush 1 Brush per 6 months 50 gms per month
Note. - 1. The children attending school outside the institution may be issued with one additional
bar of washing soap (100 gms) per head per month for washing their school uniform.
2. For washing of cloth and towels, bed-sheets etc., the following scale may
be followed:
(a) Washing soap(b)
Whitening/bleaching agent1 soap for one month (125 gms)To the extent required
only for white clothing
 
Provided, however, that the hospital clothing is not mixed with other clothing at the time of
washing. If necessary, the Superintendent can issue the above items separately for washing of
hospital clothing.(4)The following items shall be provided for maintaining the Homes in a healthy
and sanitary condition:
 Item Scale of Supply
(1)Broom Stick 25 to 40 Nos. per month depending on the areaof the institution.
(2)DDT for spray As per the institution Doctor's advice
(3)Effective bugs killing agent As required
(4)Phenyl and cleaning acid
(daily)Depending on the area of lavatories to becleaned as per institution
Doctor's advice.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

Schedule 9
Procedure for disposal of Prohibited Articles(Rule (32))The property other than money or valuables
belonging to a child received or detained in an institution shall be disposed of in the following
manner:(1)If it consists of obscene pictures or literature, tobacco snuff, opium, drug or liquor or
perishable articles worth Rs.50/- etc., it shall be destroyed;(2)If it consists of perishable articles
worth more than Rs.50/- it shall be sold by auction as soon as possible and the proceeds kept in safe
custody by the Superintendent:(3)The clothing bedding or other articles of such child shall be
destroyed if the Superintendent, considers it essential on hygienic grounds or considers to be
worthless, or if the clothing and bedding is ragged, and the clothing, bedding and other articles of
children found to be suffering from infectious or contagious disease shall be burnt;(4)Clothing,
bedding and other articles not covered by the Provisions of clauses (a), (b) and (c) shall; after being
washed and disinfected if necessary be made into a bundle or bundles and suitably stored. The
Superintendent shall be responsible for their safe custody.(5)No person on the staff of the
institution shall, whether directly or indirectly bid at the auction of or purchase, any property
auctioned under these rules.(6)On the competent authority making an order other than directing
the child to be sent to an institution, his/her money and valuables and such of his/ her articles as are
not destroyed or disposed of, together with the proceeds of such of his/her articles as have been
sold, shall at the time of his/her release be handed over to him in the presence of the
Superintendent. The Superintendent shall take the signature or thumb impression of the parent or
guardian of the child and/or the child in the column provided for the purpose in the register
maintained, in token of his/her having received such money, valuable articles and proceeds. If the
clothing have been destroyed or do not fit the child, he shall be provided with fresh clothing.(7)On
an order made by the competent authority in respect of any child directing the child to be sent to an
institution, the Superintendent shall deposit such child's money together with the sale proceeds in
the manner laid down from time to time in the name of the child and the account book will be kept
with Superintendent. His/her valuables, clothing, bedding and other articles, if any shall be kept in
safe custody.(8)When such child is transferred from one institution to another, all his/her property,
valuables and account book in the custody of the Superintendent shall be sent along with him to the
Superintendent, of the institution to which he has been transferred together with a full and correct
statement of the description and estimated value thereof.(9)At the time of the release of such child,
the property or valuables kept in safe custody and the money deposited in his/her name shall be
handed over to him or to his/her parent or guardian, as the case may be and an entry made in that
behalf in the register. Such entry shall be signed by the Superintendent.(10)When the resident of an
institution dies therein, the property left by the deceased and the money deposited in his/her name
shall be handed over by the Superintendent to any person who established his claim thereto and
executes an indemnity bond. A receipt shall be obtained from such person for having received such
property and the amount. If no claimant appears within a period of six months from the date of
death of such child, the property and amount shall be credited to Government.(11)When a child kept
in an institution escapes therefrom or fails to return thereto after the expiry of the period of absence
permitted to him, the property left by him and the amount deposited in his/her name shall be kept
in safe custody by the Superintendent of such institution for a period of six months from the date of
escape of such child or the date on which such child should have returned thereto as the case may
be. If within the said period such child is not arrested and sent back or does not return to theAndhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

institution, such property and amount shall be credited to Government by drafting a simple
proceedings.Andhra Pradesh Juvenile Justice (Care and Protection of Children) Rules, 2003

