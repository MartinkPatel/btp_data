Bihar Police Act, 2007
BIHAR
India
Bihar Police Act, 2007
Act 1 of 2007
Published on 1 January 2007• 
Commenced on 1 January 2007• 
[This is the version of this document from 1 January 2007.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Police Act, 2007(Bihar Act No. 1 of 2007)Last Updated 17th January, 2020That, promotion
and respect of the human rights of individual and protection of their civil, political, social, economic
and cultural rights is the first responsibility of the law;And, that, it is the constitutional
responsibility of the state to provide an impartial and capable police services for the protection of
the interests of the weaker section of the society including the minorities and respect the democratic
sentiments of the citizens;And, that, for such a purpose it is necessary that the police personnel are
professionally organized, service oriented free from outside influences and accountable to the
law;And, that, keeping in view the challenges emerging before the police and the security of the
state, administration of good governance and the respect of the human rights, it is necessary to
redefine the role of the police, their duties and responsibilities;And, that, it is necessary to
appropriately strengthen the police so that it is capable of working as an efficient, effective, people
friendly and accountable agency;Therefore, to provide for the establishment and management of the
police service, now, it is necessary that a new law is enacted as follows.Be it enacted by Bihar State
Legislature in the Fifty-eighth year of the Republic of India.
Chapter I
Preliminary
1. Short title, extent and commencement.
(a)This Act may be called The Bihar Police Act, 2007(b)It shall come into force on such date as the
state government may, by notification, appoint.(c)It extend to the whole of the state of Bihar
2. Definitions.
(1)In this Act, unless the context otherwise requires, -(a)"Act" means the Bihar Police Act,
2007.(b)"Cattle" means cattle having horns, elephants, camels, horses, mares, ponies, sheep, goats,Bihar Police Act, 2007

and pigs.(c)"Rebel" means armed struggle including any political design against the state by a group
or class of the population with a view to disintegrate any part of India(d)"Internal security" means
protection of sovereignty and integrity of the state from separatists and anti-national elements
within the state;(e)"Militant activity" includes violent activities by any group using explosives
,inflammable materials, fire arms or other deadly weapons or hazardous materials in order to
achieve their political objectives;(f)"Organized Crimes" includes any crime committed by any group
or network of individuals using violent methods or threats or violence with a view to get illegal
benefits;(g)"Terrorist Activities" includes activities by any individual or any group using explosives
or inflammable materials, fire arms or other deadly weapons or hazardous gases or other chemicals
or other kinds of hazardous materials with a view to spread terror in the society or in any class of the
society and to destabilize any legitimate government;(h)"Cyber Crimes" includes offensive activities
relating to information technology, illegal access (unauthorized access) illegal obstruction (illegal
transfer of data to the computer system, there from or therein through technical means)interception
of data( illegal loss, deletion change, hiding of computer data) interception in the system
(interference in the operation of a computer system through the act of insertion, transfer, loss,
deletion, change or hiding of computer data), misuse of instruments, fraud (theft of ID) and
electronic offences.(i)"Moral Turpitude" means involvement in any crime which includes violence,
fraud, deciet peddling of drugs or crime against the state or any crime related to it, wherein a
punishment of three years or more has been specified.(j)"Government" means the State
Government of Bihar.(k)"Chief Secretary" means the chief secretary of the Government.(l)"Place of
public amusement and public entertainment" means the place where people can enter by paying a
fee or without paying the fee and this includes:(1)Picture hall(2)Theater(3)Banquet
hall(4)Stadium(m)"Police district" means the tract notified under section 7 of chapter II of this Act,
which is different from revenue district.(n)"Police officer" means member of Bihar police service
constituted under this Act.(o)"Public place" means such place where people can enter which include
the following:(i)Any public building and monument and their precincts; and(ii)Any place accessible
to the public for drawing water, washing or bathing or for the purpose of recreation.(p)"Regulation"
means regulation made under this Act;(q)"Rule" means rules made under this Act.(r)"Magistrate"
means such executive magistrate as defined in the Code of Criminal Panel code.(s)"District
Magistrate" means District Magistrate appointed for one or more districts by the
Government.(t)"Sub-Divisional Magistrate" means Sub divisional officer appointed for one or more
subdivisions by the government.(u)"District superintendent of Police" includes any Assistant
District Superintendent or any person appointed to perform all or any duty of district
superintendent of police in any district including district of railway, under this Act.(v)"Property"
means any movable or immovable property, bank account, any kind of investment or valuable
securities.(w)"District" means revenue land notified as District under code of civil procedure
1908.(x)"Power of superintendence" means and includes power to direct, guide and power of
instruction in executive and administrative matters relating to investigation and it also includes the
power to repeal, modify, repeal revision of any administrative order issued in such cases by any
officer granted power under provisions of the Code of Criminal Procedure, 1973 (2 of Central Act,
1974).(y)"Post" shall mean and include subordinate post and superintending
post.(z)"Superintending Post" shall mean post of the rank of Deputy/Assistant superintendent of
police and above.(za)"Subordinating Post" means post of the rank of Assistant superintendent of
police or deputy superintendent of police or member of lower rank.(zb)"Prescribed" meansBihar Police Act, 2007

prescribed by the government through rule, order, circular or notification etc.(2)Words and
expressions used in this Act shall have the same meaning as defined in General Clauses Act, 1897,
The Code of Criminal Procedure 1973 and The Indian Penal Code, 1860.
Chapter II
Constitutional and Organisation of Police Service
3. Police Service of the State.
- For the purpose of this Act under the government the whole police organisation shall be treated as
one police service. The members of Police Service may be posted in any branch, including special
branches of the Police Service in the state.
4. Constitution of the Police Service.
- Under the provision of this Act:(i)For the purpose of this Act, the whole police organisation shall
be treated as one Police Service under the government and shall be formally nominated and shall
contain such members of officers and police personnel and police force for special purposes such as
categories of Bihar Armed Police or Anti-riot combined force as required necessary for the control of
Riots etc. and shall be constituted in such a manner as ordered by the Government from time to
time.(ii)The salary, allowances, service conditions of police personnel shall be such as determined
from time to time by the government through rule/notification/order etc.
5. Appointment of Director General, Additional Director General, Inspector
General, Deputy and Assistant Inspector General.
(1)The Government shall appoint Director General of Police who shall exercise such powers and
perform such functions and duty and such responsibilities and power shall be vested in him which
shall be determined.(2)The government may appoint one or more than one Additional Director
Generals and such number of Inspector Generals, Deputy and assistant Inspector Generals as it may
deem fit.
6. Selection and Tenure of Director General of Police.
(1)The Director General of Police shall be appointed from the panel of officers, which include
officers already working at the post of Director General of Police or shall contain such officers who
have been found suitable for promotion to the post of Director General of police by the Committee
under the rule formed under All India service Act, 1951 (61 of The Central Act, 1951).(2)The Tenure
of the Director General of Police appointed in such manner shall normally be of Two Years.However,
the Director General of Police may be transferred from his post before the completion of his Tenure
by the government on the reasons which are as follows:(a)He has been convicted by any court for
any punishable crime or he has been charge sheeted by any court for being involved in any case ofBihar Police Act, 2007

corruption, of moral turpitude; or,(b)If he is incapable due to any physical or mental ailment or due
to any other reason and is not able to discharge the duty of the Director General of Police; or,(c)Such
a posting shall be subject to the consent of the officer promoted on any higher post under the State
or the Union Government.(d)Any other administrative reason, which is in favour of the effective
discharge of the duty.
7. Police District.
- The government through notification may declare any area as a police district. The police
administration of such police district shall be vested in the superintendent of police under the
general control and superintendence of the District magistrate, who shall be assisted by such
Additional Assistant or Deputy Superintendent of Police as deem fit and notified.
8. Police Station.
(1)The government, considering the area status of crime, duty in relation to law and order and the
distance being covered by the public in reaching the police station may by notification setup as many
police stations along with required number of police posts, as it deem expedient.(2)For the purpose
of control and supervision two or more police station may be placed under one police circle.(3)The
head of the police station shall be the Station House Officer, who shall not be below the rank
sub-inspector of police.However, the large police station may be placed under the supervision of the
officer of the rank of Inspector of Police.(4)The number of police personnel deputed in the police
station shall be as much as determined by the government from time to time through the general or
special order.(5)For filing of complaint of crime committed against women and children and for
performing the duty related to the administration of special legislation connected with women and
children there shall be a women and children protecting desk staff in each police station, wherein as
far as possible, women police personnel shall be deputed.(6)Each police station shall clearly display
the guidance issued by the Supreme Court, departmental order connected with arrest and details of
persons arrested and put in lock up, along with relevant information which are required to be made
public.
9. Police Station to prevent atrocities against Scheduled Castes/Scheduled
Tribes.
(1)The Government, through notification, may constitute police stations to prevent atrocities on
scheduled castes/scheduled tribes, as required.(2)Investigation of cases filed in such police station,
shall be conducted by a police officer not below the rank of Deputy Superintendent of Police.
10. Transfer and Posting on Subordinate Posts.
(1)Deputation of Police Officer, from the rank of Inspector to Constable on any special post, shall be
made by the District Superintendent of police within their jurisdiction. Their tenure shall be 6 years
in the district 8 years in range and 10 years in the zone. The transfer from one district to anotherBihar Police Act, 2007

within the range shall be made by the committee constituting Deputy Inspector General of Police
and District Superintendent of Police of the range. The transfer from one range to another shall be
made by the committee constituting Inspector General of Police of the zone and Deputy Inspector
General of Police of all the range of the zone. Transfer from one zone to another zone shall be made
by the committee consisting of the Additional Director General of Police and the Inspector General
of Police of the zone.(2)The tenure of officers posted as the Station House Officer in a Police Station
or in charge of police circle or Sub-Division or Superintendent of Police of the district shall be of
minimum two years. However, any of such officers may be transferred from their posts before expiry
of the tenure of two years or more for the following reasons:(a)On promotion to the higher post
or,(b)On being convicted or charge sheeted for any punishable crime by any court or,(c)On being
incapable of discharging their duties due to incapability due to physical or mental ailment or any
other reason or,(d)Requirement to fill vacancies arising as a result of promotion transfer or
retirement or,(e)Other administrative reason which is in favour of effective discharging of duties.
11. Authority of District Superintendent of Police over Rural Police.
- It will be lawful for the Government to declare that for the purpose of the police, any such
authority or any rural watchman or other rural police, being exercised or may be exercised by the
District Magistrate, shall be exercised by the District Superintendent of Police subject to the general
control of the District Magistrate.
12. District Administration.
(1)In addition to The Code of Criminal Procedure, 1973, and other relevant Act, it shall be necessary
for the District Magistrate to maintain coordination between the functioning of the police and the
District Administration in the following matters:(a)Maintaining law and order.(b)Implementation
of social security law.(c)Control of natural calamities and land reforms.(d)Situation arising as a
result of any internal disturbance.(e)To ensure maintenance of supply of essential
items.(f)Protection of people of lower and weaker sections.(g)Prevention of atrocities on scheduled
castes/tribes(h)Protection of human right, completion of development project of the state and
removal of complaint.(2)For the purpose of such coordination, the District Magistrate may call for
general or special information from the Superintendent of Police and head of other departments,
whenever required. The District Magistrate, considering the situation may issue proper order or
issue written general instructions.(3)The District Magistrate or the Sub-Divisional Magistrate, in
order to maintain law and order, to protect minorities or weaker section for the purpose of election
or other purposes, may order for the deputation of sufficient number of police force. The District
Magistrate shall also ensure that all the department of the district, whose assistance is required for
the effective working of the police, provide full assistance to the Superintendent of Police.
13. Railway Police.
(1)The Government, through notification in official gazette, covering such areas of the state as
specified by the State Government, may create one or more special police district and for each such
special police district, may appoint one Superintendent of Police and one or more Assistant andBihar Police Act, 2007

Deputy Superintendent of Police and other Police Officers in required numbers.(2)Such police
officers shall perform the police work relating to the railway administration under the jurisdiction of
their duty and shall also perform the duty assigned to them from time to time by the State
Government.(3)Any police officer, who has been assigned power to work under this subsection
through general or special order, subject to any order issued by the state government for this
purpose, may exercise the power equivalent to the power of the Station House Officer of any police
station in the concerned special district or in a part thereof. The Police Officer, while exercising
these powers, which shall be subject to any such order mentioned above, shall perform duty
equivalent to that of the Station House Officer of any police station under the jurisdiction of his
Police Station.(4)Subject to any general or special order passed by the State Government for this
purpose, such police officer shall have the powers and privilege in each part of the state under this
Act or other law in effect at that time, and that shall be subject to the responsibilities of the Police
Officer.(5)With the prior permission of the Government, the Superintendent of Police, through this
Act or there under, may, delegate the powers and duties vested in him to any Assistant or Deputy
Superintendent of Police.
14. The State Intelligence and Crime Investigation Department.
(1)In accordance with the provision of this act, to collect, collate analyse and exchange intelligence
there shall be a state Intelligence department and to investigate the inter-state, inter-district and
other specified offences there shall be a Crime investigation department.(2)The government, shall,
appoint an officer equivalent or higher to the rank of the Inspector General of Police as Head of the
above mentioned Departments.(3)In order to dispose of various kinds of offences, on which special
attention is required to be given or special consultation is necessary, there shall be a special wing in
the Crime investigation department. The Head of each wing shall be the officer of the rank of the
Superintendent of Police.(4)The Government, keeping in view the quantum and the nature of work
may appoint sufficient number of officer of different rank to serve in the Crime Investigation
Department and The state intelligence Department.
15. Technology and the assistance Services.
(1)The Government shall, in order to augment the efficiency of the police service, under the overall
control of the Director General of Police, create and maintain an auxiliary technical agency and
service as required.(2)(a)The services so created, shall include required number of Members of the
state level fully equipped forensic science laboratory, Regional forensic science laboratory for each
range and mobile forensic science units equipped with manpower, as required.(b)The Government
shall take all steps to promote the use of science and technology in all aspect of the police
services.(3)The Government, may, for the whole state or part there of appoint one or more Director
of police telecommunication, who shall not be an officer blow the rank of Deputy Inspector General
Of police and in order to assist him, may appoint Superintendent of police and Deputy
Superintendent of police in required number.(4)In the same manner, The Government, may, for the
whole state or part there of appoint one or more Director of police transport, who shall not be an
officer below the rank of Deputy Inspector General Of police and in order to assist him, may appoint
Superintendent of police and Deputy Superintendent of police in required number.Bihar Police Act, 2007

16. The communication department.
- The government shall setup a separate department of communication, which shall have officers
and personnel with required qualifications and experience as decided by the government from time
to time. This department shall be equipped with all modern facilities of communication in order to
update generation, transmission, retrieval, collection and all types of digital, analogue and other
data.
17. Appointment of Directors of State Police Academy and Police Training
Colleges and Schools.
- The state government shall setup a state police academy and other training institutes at the state
level which may be necessary for the training of police personnel of different posts.
18. The oath or Affirmation made by the Police Personnel.
- Each member of the police service registered under this Act, on appointment and completion of
training shall have to take oath or make affirmation in the prescribed manner before the officer
appointed by the superintendent of police or the Director General of Police.
19. Special Police Officer.
(1)Any police officer not below the rank of Deputy superintendent of police, may, at any time for the
period specified in the appointment order in order to assist the police force , request the district
magistrate to appoint any able bodied person between the age of eighteen and fifty as special police
officer.(2)Every Special Police Officer on appointment(a)Take specified training and receive a
certificate in a proforma approved by the state government in this regard; and(b)Have the same
power, privileges and immunities as an ordinary Police officer and be liable to the same duties and
responsibilities and subject to the same authorities as an ordinary police officer.
20. Employment of Additional Police Officer at the cost of person making
request.
- Subject to the general instruction of the district magistrate, it shall be lawful for the Inspector
General of Police or Deputy Inspector General of Police or Assistant Inspector General of Police or
the District Superintendent of Police to depute on the application of any person, such number of
additional police officer to maintain peace at any place in the general police district as deemed fit.
Such a police force shall be subject to the order of the District Superintendent of Police and shall be
employed at the cost of the person making the application.Provided such person upon whose
application such a deployment has been made, may, giving a written notice of one month, request
the Inspector General of Police, Deputy Inspector General of Police or District superintendent of
Police or Assistant Inspector General of Police for the withdrawal of the police officer so deployed
and such person shall be relieved from the cost of such additional police force at the expiration ofBihar Police Act, 2007

such period of notice.
21. Employment of additional police force at Railway and at large work.
- Whenever a work on railway, canal or ant other public work is carried out or any manufacturing or
other commercial business is conducted in any part of the state and it appears to the Director
General of Police that the behaviour or a reasonable apprehension of the behaviour of the persons
employed on such work manufactory or commercial concern, necessitates the employment of
additional police force at such places it shall be lawful for the director General of Police to deploy
additional police force at such place and to keep them employed at such place for so long as its
necessity appears to continue and it shall be legitimate for the Director General of Police issue order
from time to time for the payment of the cost of such additional police force to the person on whose
control or custody lies the fund used for carrying out such work, manufacturing or commercial
business, and thereafter such person shall make the payment accordingly.
Chapter III
Superintendence and Administration of Police Force
22. The superintendence of the state police force to vest in the state
government.
- The overall superintendence and control of the police force shall be vested in the government.
23. The state police Board.
- The government shall, within six months of the implementation of this Act, to discharge the duties
vested under the provisions of this chapter, establish a state police board.
24. Structure of the State Police Board.
- The state police board shall constitute of the following:
1. Chief Secretary- Chairman
2. Director General of Police- Member
3. In charge secretary of department of Home-Member Secretary
25. Functions of the State Police Board.
- The State Police Board shall discharge the following duties:(a)Formation of comprehensive PolicyBihar Police Act, 2007

Guidelines, for making police administration efficient, affective, sensitive and accountable according
to the law.(b)Identification of Performance Indicator for Assessment of the working of police
service,The Performance Indicator inter alia, shall contain the following:-Police Research and
Response, accountability, maximum utilisation of amendments, operative efficiency, public
satisfaction, and satisfaction of the victims in comparison to the compliance of norms of human
rights.(c)Review and assessment of organisational work of district wise police service in the state in
comparison to the Performance Indicator identified and determined and the resources available to
and under the control of the police.
26. Complaint of violation of human rights.
- Complaints against police personnel and officers in connection with the following matter shall be
investigated by the state human rights commission constituted under clause 21 of The Human
Rights Act, 1993, according to the process determined therein:(1)Violation or abetment for violation
of human rights(2)Negligence in prevention of such violations.
27. Power and Responsibilities of the Director General of Police.
- As the Head of the State Police Service, The Director General of Police shall have the following
responsibilities:(a)To implement policies, strategic schemes and the annual plan formulated by the
government.(b)Operation control and supervision of the police service in order to ensure its
efficiency, effectiveness, sensitivity and responsibility.
28. Magisterial power of the Director General of Police.
- The power of a Magistrate shall be vested in the Director General of Police in all general police
district, who shall exercise these powers subject to the extent determined by the Government from
time to time.
29. Provisions of Punishment.
- Subject to the provision to the Article 311 of the constitution and such rule as the government enact
from time to time under this Act, The Director General of Police, Inspector General of Police,
Deputy Inspector General of Police and The District Superintendent of Police ,may, any time
dismiss, suspend or reduce the rank of such police officers of subordinate class any time, who in
their opinion, has abused his duty, has neglected his duty or is unfit for the duty or any such officer
of the subordinate class, who is negligent in discharging his duty or has made himself incapable of
performing his duty due to some work , may award one or more of the following
punishments:(a)Fine, which shall not be more than the salary of a month.(b)Punishment such as
drill, extra guard duty, hard work or other work with or without confinement in quarter, the period
of which may not be more than fifteen days.(c)Deprivation of salary of good behaviour.(d)Removal
from any dignified post or deprivation of any special pay.Bihar Police Act, 2007

30. Transfer and Posting.
(1)Transfer and Posting of police officers and Police Personnel of the supervisory grade shall be
governed by the conduct rule and other rule formulated by the government from time to time.(2)The
tenure of officers shall normally be of two years.However, any of such officers may be transferred
from their posts before expiry of the tenure of two years or more for the following reasons:(a)On
promotion to the higher post.(b)On being convicted or charge sheeted for any punishable crime by
any court.(c)On being incapable of performing their duties due to incapability or due to physical or
mental ailment or any other reason.(d)Requirement to fill vacancies arising as a result of promotion
transfer or retirement.(e)Other administrative reason which is in favour of efficient performance of
duties.
Chapter IV
Role, Function Duties and Responsibilities of Police
31. Role, Function and Duty of Police.
- Role and duty of police shall, mainly be the following:-(a)To follow law and implement them in a
fair manner and protect the life ,liberty, property and the human rights along with the dignity of the
public.(b)To maintain and promote public order.(c)To protect the internal security, prevent and
control terrorist activities, activities breaching communal harmony, activities affecting internal
security and other subversive activities.(d)To protect road, rail, bridges, important infrastructures
and establishments etc. along with public property from riot violence or other kind of attacks.(e)To
prevent crime and reduce the chances of commission of offences by their preventive activities and
steps and assist and cooperate with other relevant agencies in actions to be taken for preventing
offences.(f)To properly file all information sent personally or brought to them by representative of
the individual or received through email or other medium and take immediate follow up action after
giving acknowledgment of the information.(g)To file compoundable offence brought to their
attention through notice and other medium and investigate them and duly provide a copy of the
First Information Report to the person filing FIR and arrest offender whenever deemed proper and
provide required assistance in prosecuting them.(h)To develop sense of confidence in various
societies and maintain them and so far as possible prevent conflict and increase feeling of
brotherhood among them.(i)Taking initiative in providing every possible help to the person affected
by man-made or natural calamities actively, assists other agencies in relief and rehabilitation
work.(j)To help persons having apprehension of physical loss or loss of property and provide
necessary assistance and relief to the victims.(k)To regulate orderly transportation of people and
vehicle and control and regulate traffic on highway.(l)To gather information relating to the matter
connected with public peace and all kind of offence and national security and apart from taking suo
motto action, shares such information with other relevant agencies.(m)To take charge of all
unclaimed property in their possession as police officer discharging their duty and take action for
their secured custody and their disposal as per the prescribed procedure.(n)To provide security to
public servants.(o)To perform all such duties and responsibilities, which have been imposed upon
them by any authority vested with the power to issue such instructions by the government or by theBihar Police Act, 2007

law for the time being in force.(p)To keep record of habitual offenders and organised offences and
display them in the police station.
32. Maintenance of Diary by the Police Officer.
- It shall be the duty of each Station House Officer to maintain the General Diary in the form
prescribed by the government from time to time and record therein all the information and charges
framed, name of all the person arrested, name of informer and offence, details of arms, property or
other items taken in their possession and the name of witness examined. The District Magistrate
shall have the power to call for such diary and inspect them.
33. Social duties of the Police.
- It shall be the duty of each officer(a)To conduct in a dignified and polite manner while dealing with
the member of the public, especially senior citizen, women and children.(b)To guide and assist
member of the public, especially senior citizen, women, children, poor people and destitute,
physically and mentally challenged people, who find themselves helpless or otherwise require
assistance and protection.(c)To provide all possible assistance to victims of offences and road
accidents and ensure that they get immediate medical assistance without any medico-legal
formalities and to assist them in their compensation and other legal claim.(d)To ensure that the
conduct of police are in a fair manner and in accordance with the principles of human rights while
taking special care of the security of minorities along with weaker sections in all circumstances
especially during clash between various communities, classes, castes and political parties.(e)To
prevent torture of women and children from indecent and objectionable behaviour, lewd remarks or
sufferings along with torture in public places and public transport.(f)To provide all possible
assistance to members of the public, especially women, children and poor and the destitute, against
any offence or exploitation by any person or organised group.(g)To provide legally prescribed food
and shelter to each person placed in custody and to provide information of provision of legal
assistance schemes being made available to all such persons and also give intimation to the
concerned authorities in this regard.(h)To follow and discharge any other responsibilities and duties
determined by the government from time to time.
34. Duties in emergent circumstances.
(1)The government shall by publishing notification in the gazette for a specified period declared any
specified service as important service for the community, which may be extended from time to time
by publishing notification as required.(2)Till the declaration made under sub-section (1) remains in
effect, it shall be the duty of each police officer to follow order given by any of his senior officer in
connection with the service specified in the declaration.
35. Discharge of duty of any subordinate officer by the senior police officer.
- The senior police officer may discharge the duties of any of his subordinate officer vested throughBihar Police Act, 2007

law or legal order and shall assist and support in duties of his subordinate officer shall protect the
duties of his subordinate officer or other persons working under his legal command or authority,
whenever it seems urgent or important to make the law completely or accessibly effective.
Chapter V
Effective investigation of offences by using science and
technology in investigation.
36. Constitution of special investigation unit.
- The government shall, constitute special offence investigation unit in crime infested areas, which
shall be headed by police officer not below the rank of police sub-inspector of the states cadre which
shall have assistance by required number of officers and staff for investigation of economic and
heinous offences, except with the written permission of the Director General of Police except in
extraordinary circumstances personnel deputed in this unit shall not be engaged in other work.
37. Selection of officers deputed in special crime investigation units.
- Selection of officers deputed in special crime investigation units shall be made on the basis of their
interest professional efficiency and their faithfulness. Their professional efficiency hall be upgraded
on time to time by providing them special training for using scientific instruments related to
investigation techniques specially investigation and forensic science.
38. Tenure of officers posted in special crime investigation units.
- The tenure of officers posted in special crime investigation units shall normally be of three years
thereafter by turn they shall be engaged in the law and order and other kind of work.
39. Functions of the officers posted in special crime investigation units.
(1)Officers posted in special crime investigation units shall in addition to work assigned specially by
the district superintendent of police investigated cases connected with murder, kidnapping, rape,
dacoity, robbery, offence related to dowry, fraud, misappropriation and other economic offences as
notified by the director general of police.(2)Investigation of all other officers shall be conducted by
other staff posted in such police station.
40. Supervision of investigation of cases of special offence.
- Under the supervision of concerned station house officer, the supervision of investigation of cases
initiated by personnel of special crime investigation unit shall be made by such officer who shall not
be below the rank of additional superintendent of police and shall directly submit the report to the
district superintendent of police. The supervising officer shall be assisted by sufficient number ofBihar Police Act, 2007

officers of the rank of deputy superintendent of police, who shall be specially appointed to ensure
qualitative investigation in this profession.However in small districts, when the quantity of work
does not justify posting of an officer of the rank of additional superintendent of police, officer of the
grade of the deputy superintendent of police shall be posted for this purpose.
41. Creation of special investigation cell.
- In order to investigate economic offences along with offences of serious and other complex nature
one or more special investigation cell shall be created in each district which shall have such number
of officers and staff as the government deems proper. Such cell shall be in control and supervision of
Additional Superintendent of police.
42. Special selection of officers and staff for special investigation cell.
- Officers and staff to be posted in this cell shall be specially selected and trained also.
43. Crime investigation department.
- The crime investigation department of the state shall initiate investigation of inter state, inter
district and other offences of serious nature as notified by the government from time to time or
specially handed over to it by the director general of police in accordance with the prescribed
process and norms.
44. Special investigation skill.
- In crime investigation department there shall be special unit to investigate cyber crimes, organised
crime, cases relating to killing of humans, economic offences and other kind of offences as notified
by the government and for which special investigation skill is required.
45. Selection of officers of crime investigation department.
- Selection of officers posted in the crime investigation department shall be made on the basis of
their interest, professional skill, experience and their sincerity. They shall be given proper training
after their selection and their knowledge and skill shall be upgraded from time to time through
reorientation and special courses.
46. Tenure of officers posted in crime investigation department.
- The tenure of officers posted in crime investigation department shall normally be of three years
and shall not be removed unless it becomes necessary to remove them on one or more of the reasons
to be mentioned.Bihar Police Act, 2007

47. Legal advisor and offence analysts.
- In order to guide, suggest and assist investigation officer, sufficient number of legal advisers and
offence analysts shall be made available in the crime investigation department.
Chapter VI
Training, research and development
48. Training policy.
- The government shall, keeping in mind the present and future requirements of the police system,
prepare training cum education policy for the police. The objective of training policy shall be to
provide information on concerned subjects develop professional skills among police personnel,
create right attitude and promote constitutional and moral values among police personnel.
49. Efficiency and training of police personnel.
- In such training it shall be ensured that the police personnel are sufficiently trained to efficiently
perform their duty. As far a possible the successful participation in the above training program hall
be linked with promotion of police personnel of different rank and various posting by the
government from time to time, through infrastructural method ,as notified by the government from
time to time
50. Creation of basic infrastructure and capacity development for training.
- The government shall create and upgrade basic infrastructure and capacity of the training institute
as per the requirement of overall training of police personnel of various grades.
51. Research and development.
- The government shall set up Police Research and Development Bureau along with provisions for
above personnel, fund and other resources so that research and investigation work is carried out
regularly on those subjects and issues to improve the working and performance of police. The
government may sponsor other famous organisations and institutions to conduct special study and
research on subjects relevant to the police system.
52.
The government shall take sufficient steps to develop technology to investigate and detect offences
and scientific and technological assistance in other work relating to the police system.Bihar Police Act, 2007

53. Functions of State Police Research and Development Bureau.
- The functions of state police research and development bureau shall include the following.(a)To
keep information of modern instruments and techniques successfully used by other police
organisations in the country or abroad and carry out assessment in connection with the adoption of
instruments used by the state police. This shall include such modern products, arms and
ammunitions, riot control instruments, traffic control instruments, police transport and various
scientific and electronic instruments which are useful for research and other work related to the
police systems.(b)To develop liaison and assistance with police research and development bureau of
the government of India, academies, renowned scientific organisation, institutions and laboratories
and private sector undertakings.(c)To study the special and upcoming problems of the police system
of the state so that steps for their solution and remedial measures may be taken.(d)To investigate
the existing system of police organisation and give suggestion regarding infrastructural, institutional
and other necessary changes in the police to make their working more efficient and responsible,
and(e)Concurrent assessment and recording of the effect of modernisation and training policies of
the state police and submit the report of the findings to the Director General of Police and the
government.
Chapter VII
54. Regulation control and discipline.
- Subject to the approval of the state government, The Director General of Police shall enact such
rule, regulation or issue order for the following which shall not be contrary to this Act or any other
Act in effect at any time:-(a)Prevention and investigation of offence.(b)Regulation and inspection of
work performed by the police organisation or Police officer.(c)Distribution of arms, ammunition,
accoutrements, uniforms and other items and decides the quantity.(d)To assign duties to officers of
all ranks and grade and decide the manner and condition subject to which they shall exercise their
power and discharge their duties.(e)To regulate the collection and transmission of intelligence and
information.(f)Determine the record, register and Performa to be maintained and details to be
prepared by various police units and officers.(g)To make police more skillful and prevent abuse of
power and neglect of duty by them.
55. Power to make Rules and Regulations.
- The Government shall make rule for the regulation, control and discipline of police.Provided that
by the time a new Police Law under this Act is enacted, the existing Bihar and Orissa Arms Police
Act, 1933 and Police Law and existing articles, regulations, notifications order and circulars shall
remain in effect as if enacted in this Act.
56. Police Officer always on duty.
- Every officer, not on leave or under suspension, shall, for all purposes of this Act, be deemed to be
always on duty and may be posted to any part of the state at any time.Bihar Police Act, 2007

57. Posting of Police Officer.
- Any police officer, unless properly authorised, shall not leave his duty or place of appointment or
posting.Explanation. - Any officer on being authorised leave does not report on his duty without any
valid reason after completion of such leave, shall, under the meaning of this article, be deemed to
have neglected himself from the duties of his post.
58. Police Officer not to engage in other employment.
- Under this Act, no police officer shall hold any other employment or office of profit other than his
duty.
Chapter VIII
Responsibility of Police
Accountability for conduct
59. District Accountability Authority.
- The Government shall, for the purpose of functions mentioned in Section 60, set up "District
Accountability Authority". The District Magistrate shall be the head of the District Accountability
Authority and the Superintendent of Police shall be the member and the Senior Additional District
Magistrate and The Additional District Collector shall be the Member Secretary.
60. Functions of the District Accountability Authority.
(1)The District Accountability Authority shall perform the following work:(a)Shall monitor the
departmental enquiry or actions related to the complaints of "misbehaviour" against officers below
the rank of Assistant/Deputy Superintendent of Police on the basis of quarterly report received from
time to time from the District Superintendent of police.(b)If the authority is of the view that
unnecessary delay is being made in the conduct of enquiry in any case, it shall give proper advice to
the District Superintendent of Police to speedily complete the enquiry.(2)When a complainant, in
case of undue relay in the process of departmental enquiry in the matter of his complaint on being
dissatisfied by the result of the enquiry as a result of violation of principles of natural justice in
conducting disciplinary enquiry, brings the matter in the knowledge of the Authority, it may call for
the report from the District Superintendent of Police in relation to the complaint of the
"misbehaviour" against any officer below the rank of Assistant/Deputy Superintendent of Police and
may give proper advice for further action or if necessary, may give instruction to the Superintendent
of Police to get enquiry conducted by any other officer.Provided that provisions included in the
above sub-section (1) and (2) shall not be deemed to dilute disciplinary, supervisory or
administrative control of the District Superintendent of Police.Bihar Police Act, 2007

61. Report of the District Accountability Authority.
(1)Every District Accountability Authority shall, before the completion of each calendar year,
prepare an annual report and submit to the Government which inter alia shall include the
following:-(a)The number and nature of cases of "misbehaviour" forwarded by it respectively to the
Government and the District Superintendent of Police during the year.(b)The number and nature of
cases monitored by it during the year.(c)The number and nature of cases of "misbehaviour" sent to
them by the complainants on being dissatisfied by the departmental enquiry of their
complaints.(d)The number and nature of cases mentioned above in (c) wherein advice or
instructions for further actions have been issued to the Police by them and,(e)Recommendations
relating to the steps to enhance the responsibility of Police.
62. Right of the complainant.
(1)The complainant may lodge his complaint in relation to any "misbehaviour" of Police Personnel
with the Departmental Police Authority or the District Accountability Authority.Provided that, if the
content of the complaint is being inquired into by any other commission or any court, no such
complaint shall be considered by the commission or the Authority.(2)The complainant shall have
the right to get information of the development of the enquiry from time to time by the enquiry
officer. On completion of the enquiry or departmental proceedings, the complainant shall be
informed of the findings of the enquiry and the final action taken on the matter, as soon as possible.
63. Protection of action taken in good faith.
- In accordance with the provisions of this Act, in connection with any act performed or to be
performed in good faith, no case or other legal action against the state government, state police
board, its members and staff, any police officer/police accountability authority its member, staff or
any person working under the direction of the Board or Authority or member or staff of District
Accountability Authority, shall be admissible.
64. Deputing additional police in disturbed or turbulent districts.
(1)Through proclamation to be notified in the Gazette and through other manner as directed by the
Government, it shall be lawful for the Government to proclaim for any area under its jurisdiction,
that the situation of disturbance or turbulence has developed in that area as a result of the conduct
of the resident, or any of its class or community of such area, it is expedient that the strength of the
Police may be increased.(2)Thereupon, with the concurrence of the Government, it shall be lawful
for the Director General of Police or other officer authorised by the Government for this purpose
that in the area specified in the above proclamation he depute additional police force from the
strength generally stipulated.(3)Subject to the provisions of sub-clause (5) of this clause, the cost of
such police force shall be borne by the resident of the area mentioned in the proclamation.(4)The
District Magistrate shall, on conducting such enquiry, if he deems fit, apportion such cost among
those resident, who according to above are liable to bear thereof and who have not been grantedBihar Police Act, 2007

relaxation under subsequent clause. Such apportion shall be made on the basis of the individual
means of the residents of such area by the decision of the District Magistrate.(5)It shall be lawful for
the government to grant exemption of any part of such cost to any individual or class or
community.(6)In every proclamation issued under sub-section (1) of this section that period shall be
mentioned during which the proclamation shall remain effective, however this may be withdrawn
any time may be continued for further period or periods or from time to time as the government
deem fit and directs in each case.Explanation. - For purpose of this section, the resident shall
include such persons, self or their agents or servants, who is occupying or holding land or other
immovable property in such area such land owner, self or their agent or servants, who are
recovering rent direct from subjects or occupants irrespective of whether they are really living in
that area or not."Resident" shall include real resident of that area irrespective of whether they are
land owner or not.
65. Providing compensation to the persons suffering from the conduct of the
resident or persons having interest in land.
- 1. In such area, in relation to which proclamation notified under preceding section is given effect, if
any death or grievous hurt or loss or damage to property has taken place as a result of the
misbehaviour or due to the misbehaviour of the residents or any class of society of the area, it shall
be lawful for the resident of the area, who claims to have suffered from such misbehaviour, to apply
for compensation, within one month of the date of such damage, or within a period less than that as
decided, to the District Magistrate or Sub-Divisional Magistrate, under whose jurisdiction such area
is situated.(2)Thereafter, it shall be lawful for the District Magistrate after conducting enquiry as
required, with the permission of the Government, to take the following actions, whether under
preceding sections additional police has been deputed or not in such area:(a)Shall declare the name
of persons who have suffered due to such behaviour or as a result thereof,(b)Shall determine the
amount of compensation to be paid to such persons and the manner of distribution among
them.(c)Shall, different from the application determine the proportion to be paid by such residents
of that area, who have not been granted remission from the responsibility of payment under the next
succeeding sub-section.Provided, that the District Magistrate/Sub-Divisional Magistrate shall not
make any announcements or shall not determine under their sub-section, till he comes to the
opinion that the above damage has been caused due to riot or unlawful assembly in such area and
the person who has suffered damage has been absolved of the incident as a result of which, such a
damage has been caused.(3)It shall be lawful for the Government to issue order to exempt any
person or class or society of such resident from the responsibility of paying any part of such
compensation.(4)Subject to the revision by the commissioner of the Division or the Government,
every declaration or assessment made or order issued under sub-section (2) except the aforesaid,
shall be final.(5)No civil suit, in relation to the compensation adjusted under this section for any of
the damage, shall be liable to be maintained.(6)Explanation. - The word "Resident" shall have the
same meaning as defined in the preceding section.Bihar Police Act, 2007

Chapter IX
Common offence, punishment and responsibilities.
Arrangements in lane and public places.
66. Regulations of public meetings and processions.
- 1. It shall be the duty of the person intending to organise procession on any road, lane or common
road or convene meeting at public place, to give written intimation to the Station House Officer of
the concerned Police Station in this regard.(2)(a)Any officer, at least of the rank of Assistant/Deputy
Superintendent of Police, shall wherever necessary, give directions, for conduct of all meeting,
procession on all public street, lane or common road and shall decide the route and time for the
passage of any of such processions.(b)On being satisfied that any person intends or persons intend
to organise or convene public meeting or procession on any street, lane or common road, which in
the opinion of the District Magistrate or the Sub-Divisional Magistrate may disturb peace, in case it
goes out of control, shall ,through a general or special notice also call upon the person organising or
convening such public meeting or leading or encouraging such procession, to apply for the license
thereof.(c)After application is given, he shall issue a license, which shall contain names of the
concerned license holder and the conditions on which convening such public meeting or procession,
shall be allowed, provided no fee shall be charged for granting such license.(d)He shall also regulate
the limit of the volume of the music to be played in lane on the occasion of music concert or festivals
or other occasions.
67. Assembly and procession violating certain conditions.
(1)Police Officers at least of the rank of Sub inspector authorised for this purpose by any magistrate
or District Superintendent of Police shall prevent or order for dispersal of the public meeting or
procession violating the conditions specified under sub-sections (1) and (2) of section (66).(2)Any
public meeting or procession ignoring or denying to follow any order specified in the above
sub-section (1) shall be treated as illegal meeting under chapter XIII of the Indian Penal Code, 1860.
68. The power to forbid, impose ban, regulate or impose condition on playing
of microphone, etc.
- 1. The District Magistrate or the District Superintendent of Police or Sub-divisional Magistrate or
Magistrate or Sub-Divisional Police Officer or Station House Officer of the police station is of the
opinion that, in order to prevent annoyance of people or any of its class or to prevent the injury to
their health or to maintain peace or tranquility, it is necessary to do so, shall, in the area of its
jurisdiction or in such area, by order, be able to forbid, prohibit or regulate the playing of
microphone, loud speaker or sound amplifier or shall be able to impose condition on their use and
operation.(2)The Government , suo motu or on the representation of any aggrieved person or
persons may modify or change or cancel any order issued under sub-section (1)(3)Police Officer, at
least of the rank of Sub-inspector, in order to ensure the compliance of any order issued underBihar Police Act, 2007

sub-section (1) or any order modified or changed under sub-section (2) may take such measures or
use such force as proper and expedient and may confiscate any microphone, loud speaker or other
instrument being used or operated to violate the order.(4)The police officer impound the
microphone, loud speakers, or other instruments under sub-section (3) may also impound any such
vehicle on which such microphone, loud speaker, or other instrument is being carried, or being
taken or has been installed.Provided , the Police Officer, at least of the rank of sub Inspector of that
police station under the jurisdiction of which the vehicle has been impounded, may release such
vehicle on the bond of an amount not more than rupees five thousand, which he deems proper,
executed in favour of the Government by the owner of the vehicle with the condition that the vehicle
shall be presented at the time of investigation or trial and that the person shall surrender the vehicle
if given instructions to surrender under sub-section (5).(5)If any person, contravening the order of
the District Magistrate, District Superintendent of Police, or Sub-Divisional Magistrate or any
Magistrate or any Sub-Divisional Police Officer or Station House Officer of any police station issued
under sub-section (1) or modified or changed by the Government under sub-section (2), is
convicted, shall be liable to a penalty of up to rupees One Thousand and the court conducting trial of
offence under this section, shall also issue the order to surrender the microphone, loud speaker or
other instrument impounded under sub-section (3) or the vehicle impounded under subsection (4)
and released under the provision thereof.(6)The provision of this section shall be in addition to the
power vested by any other section and shall not be a dilution thereof.
69. Instructions to maintain order on public streets.
- The District Superintendent of Police or any officer authorised by him in this regard, shall, in order
to prevent obstruction, injury or difficulty caused to a person passing through the street, and control
pollution, by general or special order issue proper instructions to maintain order on public street
and lane, common road or any public place.
70. Punishment for contravening orders or instructions.
- The person not complying with the legal orders issued under sections (69) and (71), may be
arrested and on being convicted by the Magistrate, shall be punished with fine which may extend to
Ten Thousand Rupees.
71. The power to resolve a public place and to raise barricades.
- 1. The District Magistrate, through intimation may temporarily reserve any public place for public
purpose and may prohibit the passage of people except under specified conditions.(a)The District
Magistrate for erecting barrier and other necessary structure in street or lane may authorise any
police officer so that checking of vehicle could be conducted or violation of any provisions by the
vehicle owner could be prevented.(b)At the time of issuing such orders, necessary measures for
insuring safety of commuter shall also be determined.(c)Such temporary structures may be removed
after completion of the purpose of its erection.Bihar Police Act, 2007

72. Obstruction in police duty.
- Any person causing obstruction in discharge of duties or obstruction in performance of work of
police officer on conviction shall be punished with fine which may extend to Five Thousand Rupees
or with a simple imprisonment, which may extend to a maximum of three months, or both.
73. Unauthorised use of Police Uniform.
- If any person, not being a member of the Police Force, wears, without the permission of the office
authorised by the Government in this behalf, the Uniform of the Police Force or any dress having the
appearance or bearing any of the distinctive marks of the Police Uniform, shall, on conviction, be
punished with simple imprisonment which may extend to a maximum of six months of simple
imprisonment or fine, which may extend to a maximum of a Thousand Rupees, or both.
74. The charge of unclaimed property shall be taken over by the Police
Officer and shall be disposed off under the order of the Magistrate.
- It shall be the duty of the Police Officer to take charge of the unclaimed properties and submit a list
thereof to the District Magistrate. The Police Officer, in relation to the disposal of such property,
shall be guided by the orders received by the District Magistrate.
75. The District Magistrate may keep the property in his charge and issue
proclamation.
(1)The District Magistrate may keep the property in his charge and issue proclamation wherein he
shall specify the item of the owner and shall require the person making any claim in this regard to
establish his claim within Six Months of the date of proclamation in this regard.(2)Provision of
section 457 of The Code of Criminal Procedure, 1973, (2 of 1974) shall apply in relation to property
specified in this section.
76. Confiscation of property when no claimant comes forward.
(1)If no person within such period establishes his claim on such property or if the same has not
already been sold off under sub-section (2) of previous preceding section and if it is sold, such a sale
shall be made under the order of the District magistrate.(2)The proceeds of property sold under
preceding section and the proceeds of the property sold, whose claim could not be established, shall
be dealt with in such a manner as prescribed by the Government.
77. Refusal to deliver certificate of appointment etc. on ceasing to be a police
officer.
- If a person on ceasing to be a police officer does not deliver his certificate of appointment,Bihar Police Act, 2007

accoutrements, clothing and other necessaries, which have been furnished to him for the
performance of his duties, on conviction by the Magistrate, shall be liable for a fine, which may
extend to Ten Thousand Rupees.
78. Offences committed by police.
- Every police officer, found guilty of dereliction of duty or guilty of neglecting any rule or
regulations of lawful order formulated by the competent authority or withdraws himself from the
duties of his office for a period of two months without prior permission or prior information or on
being on leave fails to report on his duty on completion of such leave without valid reason or is
engaged in any other employment different from his duty without permission or is guilty of
cowardice or guilty of unauthorised personal violence against any person under his custody, shall,
on conviction, be punished with a fine equal to the salary of three months or three months with or
without rigorous imprisonment or both.
79. Offences committed by public.
(1)Any person, committing following offence, causing inconvenience, annoyance to the residents or
commuters on any street or lane or common road within the border of the area specially notified by
the District Magistrate or on the open space in the vicinity, thereof shall, on conviction, be liable to
pay a fine, which may extend to a maximum of Five Thousand Rupees:(a)Negligently let loose any
animal, or allow animal or vehicle, which has to be loaded or unloaded, or has to take up or set down
passengers, to remain there for longer than may be necessary for such purpose or leaving any
vehicle standing in a disorderly manner.(b)Found drunk and creating disturbance.(c)Neglects to
fence in or duly protect any well, tank, pond, or other dangerous place or structure in his control or
occupation, or causes obstruction in any other manner in public place.(d)Without the prior consent
of the owner defaces of affixes any bill or writes slogan on walls, buildings or any other
structure.(e)Willfully enter into any Government building, land or field connected therewith without
any sufficient reasons.(f)Knowingly creates rumours, gives false alarms in order to create confusion
in police. Fire brigade or other necessary services.(g)Knowingly destroys or damages any public
alarm system.(h)Knowingly and willfully causes damage to spread terror in public.(i)Contravenes
notices displayed in the public by competent authority in any Government building.(j)Provided the
police takes cognizance of the offence on the complaint lodged by any authorised officer of the
concerned office.(k)Harassing any women by passing lewd remarks, indecent proposal, or indication
or by following her clandestinely.Provided police takes cognizance of such an offence on complaints
made only by the victim.(2)It shall be lawful for any police officer to arrest such person who
commits any of the offences mentioned under sub-section (1). However, the person so arrested shall
be released on bail of personal bond.
80. Process regarding affixing guidance and public notices.
(1)All the general guidelines, regulations or public notices issued under this chapter hall be
published, by affixing a copy thereof at the office of the District Magistrate, Sub-Divisional,
Divisional/Regional offices, office of the Panchayat, and displaying at a distinctive place in buildingBihar Police Act, 2007

and places connected therewith or by making a declaration of the notice by beating drums or by
giving advertisements thereof in the newspaper and other media or through other means as the
Superintendent of Police deems fit, shall be published.Provided that the Superintendent of Police on
being satisfied that it is in the public interest to implement any regulation with immediate affect
such a direction and regulation may be formulated without prior publication.(2)If any instruction or
regulation formulated under this section is related to any case in connection to which there is a
provision in any corporation or other town or local authority on public health or any law or rule or
sub-rule relating to facility or security of the area. Such a regulation shall be subject to such law, rule
or sub-rule.
81. Prosecution of the police officer.
- When an offender is a police officer, under this Act no court, except on receiving written report by
the Government on the facts of other offence or on prior sanction of any officer authorised by the
State Government, shall take cognizance.
82. Prosecution of offences under other laws.
- Subject to the provisions included in section 300 of the Code of Criminal Procedure, 1973, person
from being prosecuted or tried under any other law made punishable by this Act.
83. Summary disposal of certain cases.
(1)Any Magistrate taking cognizance of an offence punishable under section 72, 77 & 78 may state
upon the summons to be served on the accused person that he may, by a specified date prior to the
hearing of the charge, plead guilty to the charge by registered letter and remit to the court a sum as
the court may specify.(2)Where an accused person pleads guilty and remits the sum specified in
sub-section (1), no further proceedings in respect of the offence shall be taken against him.
84. Recovery of penalties and fine imposed by the Magistrate.
- On conviction by any Magistrate, the provisions of sections 64 to 70 of the Indian Penal Code,
1860 and sections 386 to 389 of the Code of Criminal Procedure, 1973, shall apply in recovery of
penalties and fine imposed under this Act.Provided that any thing being mentioned in section 65 of
the Indian Penal Code, 1860, if a person does not pay the fine imposed under section 73, 78 & 79 of
this chapter, he may be punished with imprisonment of any period which shall not extend for more
than eight days.
85. Extent of the Action.
- No court, after the end of the time period provided in section 468 of the Code of Criminal
Procedure, 1973, shall take cognizance of any of the offence under this chapter. In order to calculate
the time period, provisions of chapter XXXVI of the Code of Criminal Procedure shall apply.Bihar Police Act, 2007

Chapter X
Miscellaneous
86. Disposal of fees, rewards, etc.
- All fees paid for licenses or written permissions issued under this Act, and all sums paid for the
service of processes by Police officers, and all rewards, forfeiture and penalties or share thereof
which are by law payable to police officers as informers, shall, save in so far to any such fees or sums
belong under the provisions of any enactment in force to any local authority, be credited to the
Government.Provided that with the sanction of the Government, or under any rule made by the
Government in that behalf the whole or any portion of such reward, forfeiture or penalty may, for
special services, be paid to a Police officer or be divided amongst two or more Police officers.
87. Method of proving orders and notifications.
- Any order or notification published or issued by the Government or by a Magistrate or officer
under any provision of this Act, and the due publication or issue thereof, may be proved by
production of a copy thereof, in the official Gazette or of a copy thereof signed by such Magistrate or
officer, and by him certified to be a true copy of the original published or issued according to the
provisions of the section of this Act applicable thereto.
88. Procedure of providing certificate to rules and orders.
- No rule, order, direction, adjudication, inquiry or notification made or published, and no act done
under any provision of this Act or of any rule made under this Act, or in substantial conformity to
the same, shall be deemed illegal, void, invalid or insufficient by reason of any defect of form or any
irregularity of procedure.
89. Officers holding charge of, or succeeding to vacancies competent to
exercise powers.
- Whenever in consequence of the office of a Commissioner, or Police officer becoming vacant, any
officer holds charge or additional charge of the post of such Commissioner, or Police officer or
succeeds, either temporarily or permanently to his office, such officer shall be competent to exercise
all the powers and perform all the duties respectively conferred and imposed by this Act on such
Commissioner, or Police officer, as the case may be.
90. Licenses and permissions to specify conditions, etc., and to be signed.
- 1. Any license or written permission granted under the provisions of this Act shall specify the
period and locality for which, and the conditions and the restrictions subject to which, the same is
granted, and shall be given under the signature of the competent authority and such fee shall beBihar Police Act, 2007

charged therefore as is prescribed by any rule under this Act in that behalf.(2)License to be
cancelled. - Any license or written permission granted under this Act may at any time be suspended
or revoked by the competent authority if any of its conditions or restrictions is infringed or evaded
by the person to whom it has been granted if such person is convicted of any offence in any matter to
which such license or permission relates.
3. When license is cancelled the license holder is deemed to be without
license. - When any such license or written permission is suspended or
revoked, or when the period for which the same was granted has expired, the
person to whom the same was granted, shall, for all purposes of this Act, be
deemed to be without a license or written permission, until the order for
suspending or revoking the same is cancelled, or until the same is renewed,
as the case maybe.
4. License holder to produce license and permission when called for. - Every
person to whom any such license or written permission has been granted,
shall, while the same remains in force, at all reasonable times produce the
same, if so required by a Police officer
Explanation. - For the purpose of this section any such infringement or evasion by, or conviction of,
a servant or other agent acting on behalf of the person to whom the license or written permission
has been granted shall be deemed to be infringement, or evasion by or, as the case may be,
conviction of, the person to whom such license or written permission has been granted.
91. Public notices how to be given.
- Any public notice required to be given under any of the provisions of this Act shall be in writing
under the signature of a competent authority and shall be published in the locality to be affected
thereby, affixing copies thereof in conspicuous public places, or by proclaiming the same with beat
of drums, or by advertising the same in such local newspapers, as the said authority may deem fit, or
by any two or more of these means and by any other means it may think suitable.
92. Consent, etc., of a competent authority may be proved by writing under
his signature.
- Whenever under this Act, the doing or the omitting to do anything or the validity of anything
depends upon the consent, approval, declaration, opinion or satisfaction of a competent authority a
written document signed by a competent authority purporting to conveyor set forth such consent,
approval, declaration, opinion or satisfaction shall be sufficient evidence thereof.Bihar Police Act, 2007

93. Signature on notices, etc., may be stamped.
- Every license, written permission, notice or other document, not being a summons or warrant, or
search-warrant, required by this Act, or by any rule there under to bear the signature of the
Commissioner, shall be deemed to be properly signed if it bears a facsimile of his signature stamped
thereon.
94. Power to make rules.
- The Government may make rules for carrying out the purposes of this Act.
95. Power to remove difficulties.
- If any difficulty arises in giving effect to the provision of this Act, the government may, by
notification in the official Gazette, make such provisions as appear to it to be necessary or expedient
to remove difficulty.
96.
Notification of rule and regulations and rule and regulations to be published in the Gazette.(a)Every
rule and regulation framed under this Act shall be published in the Gazette.(b)All rules and
regulations made by the Government under this Act, shall be laid as soon as may be after they are
made, before each House of the State Legislature while it is in session, for a total period of thirty
days, which may be comprised in one session or in two or more successive sessions and if, before the
expiry of any or first session of successive session as the case may be, in which it is so laid , both
Houses agree in making any modification in the rule or regulation or both Houses agree that the
rule or regulation should not be made, the rule shall thereafter have effect only in such modified
form or be of no effect, as the case may be;So however that any such modification or annulment
shall be without prejudice to the validity of anything done under that rule or regulation.
97. Repeal and Saving.
(1)The Police Act, 1861 so far as it relates to the State of Bihar is hereby repealed.(2)The Bengal
Armed Police Act, 1892 (V of 1892), so far as it relates to the State of Bihar is hereby repealed.
However, in spite of such repeal, the existing class and grade of Armed Police Officer under chapter
V of the Act, 1892, shall remain in existence till a new Bihar Armed Police Act is not framed.(3)In
spite of such repeal, any act done or any action taken or any action initiated under this rule shall be
deemed to be the act done or action taken or action initiated under this Act.(4)All the context of any
section of any of the provisions of this Act, which may have been repealed, shall be deemed as the
context of the concerned provisions of this Act.Bihar Police Act, 2007

