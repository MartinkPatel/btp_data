Children's University Act, 2009
GUJARAT
India
Children's University Act, 2009
Act 15 of 2009
Published on 31 July 2009• 
Commenced on 31 July 2009• 
[This is the version of this document from 31 July 2009.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Children's University Act, 2009(Gujarat Act No. 15 of 2009)(First published, after having received
the assent of the Governor, in the "Gujarat Government Gazette," on the 31st July, 2009).An Act to
establish the Children's University for promoting children's education in the light of contemporary
national and international needs of building up a new world that will harmonise the ideals of liberty,
equality and fraternity, and to establish, conduct and promote progressive research and educational
centres related to children's education as also to establish, conduct and promote, training and
extension services that will foster high level care, education and health of the children of today and
tomorrow and for the matters connected therewith or incidental thereto.It is hereby enacted in the
Sixtieth Year of the Republic of India as follows
Chapter I
Preliminary
1. Short title, extent and commencement.
(1)This Act may be called the Children's University Act, 2009.(2)It extends to the whole of the State
of Gujarat.(3)This section shall come into force at once and the remaining provisions shall come into
force on such date as the State Government may, by notification in the Official Gazette, appoint.
2. Definitions.
- In this Act, unless the context otherwise requires, -(a)"Academic Council" means the Academic
Council of the University established under section 23.(b)"Collaboration" means collaborative
academic activity of the University with other Universities, academic institutions (local, regional,
national or international) and other research, educational, teaching, training institutions and
organizations;(c)"Director-General" means the Director-General of the University appointed under
section 15;(d)"Executive Council" means the Executive Council of the University constituted underChildren's University Act, 2009

section 21;(e)"Fee" means collection made by the University from the students for different
purposes under different heads including tuition fee and development charges and the collection
which is non-refund able;(f)"Finance Committee" means the Finance Committee of the University
constituted under section 26;(g)"General Council" means the General Council of the University
constituted under section 19;(h)"Institution" means an institution which is a part of the University
or it is associated with and admitted to the privileges of the University;(i)"prescribed" means
prescribed by Statutes or Ordinances or, as the case may be. Regulations made by or under this
Act;(j)"Regulations" means the Regulations made under sub-section (5) of section 36;(k)"Research
Council" means the Research Council of the University constituted under section 29;(l)"Saptadhara"
activities shall include the activities of quest of knowledge, fine arts, performing arts, debate skills,
communication services, physical education. Scouts and Guides, NCC, NSS and oratory skills, craft,
and appreciation of craft as art, creative writing, poetry, etc.; -(m)"School" means a school of
learning and training maintained by or recognized, affiliated or approved as such by the University
and includes Vidya Niketan School;(n)"Standing Committee" means the Standing Committee
constituted under section 39.(o)"University" means the Children's University established and
incorporated under section 3.
Chapter II
Establishment and Incorporation of University
3. Establishment and incorporation of University.
(1)There shall be established and incorporated a University by the name of the "Children's
University".(2)The Chancellor, the Vice-Chancellor, the Director General, and the members of the
General Council, the Executive Council and the Academic Council, Assistant Director General,
Registrar and all other persons who may hereafter become such officers so long as they' continue to
hold such office or membership, are hereby constitute a body corporate by the name of the
"Children's University".(3)The University shall be a body corporate by the name aforesaid, having
perpetual succession and common seal with power, subject to the provisions of this Act, so acquire
and hold property, to contract and shall, by the said name, sue and be sued.(4)In all suites and other
legal proceedings by or against the University, the pleading shall be signed and verified by the
Registrar and all processes in such suits and proceedings shall be issued to, and served on, the
Registrar.
4. Headqurters of University.
- The headquarters of the University shall be at Gandhinagar or at such other place, as the State
Government may, by notification in the Official Gazette, specify.
5. Objects of University.
- The objects of the University shall be as follows:-(1)to study and undertake research in the works of
pioneering educationists of Gujarat, India as also of other parts of the world, who have underlinedChildren's University Act, 2009

the need for child-centered holistic education so as to derive guidance from the same; ,(2)to
promote the fundamental duties laid down in article 51A of the Constitution of India;(3)to foster in
the University highest purposes of education of the body, life and mind as also of the human spirit in
its integrality;(4)to promote synthesis of scientific realism and artistic creativity;(5)to recover the
lights from lessons of ancient wisdom in the context of modem developments;(6)to establish
facilities, programmes and activities of research, education, training and extension services that
promote all levels of child's development, including at the primary and secondary' levels of
education;(7)to introduce and nurture innovations in the education system so as to reflect India's
spiritual knowledge, robust intellectuality and inexhaustible creativity;(8)to study and derive
lessons from the ongoing experiments of education that are taking place in Gujarat as also elsewhere
and to foster all the valuable innovative work and promote the same for larger expansion and
utilization.
6. Powers and functions of University.
- The powers and functions of the University shall be as follows:-(1)to administer and manage the
University and ensure efficient working of the centres, schools and institutions related to research,
education, training and extension services for the furtherance of the objects of the University;(2)to
regulate conduct and enforce discipline among the employees of the University and to take such
measures as may be deemed necessary-;(3)to prepare guidelines manuals and methodology for
assessing and accrediting educational institutes and to determine paradigms for quality assurance,
processes and mechanisms;(4)to establish, conduct and promote centres, such as-(i)Centre of
Research,(ii)Centre of Education,(iii)Centre of Training,(iv)Centre of Extension Services,
and(v)such other centres and institutions as may be necessary and to provide for facilities, including
those relating to a Centre of Paediatrics and pedagogy for scientific discoveries and inventions,
pedagogy for fine arts, pedagogy for crafts, promotion of NSS and NCC, promotion of Scouts and
Guides, multi-linguistic capacities (Gujarati, Sanskrit, French, English, Hindi, Tamil, Arabic,
Spanish, etc.), development of curricular, co-curricular and extracurricular hobbies, puppetry',
exhibitions, unending education, museum studies, library- and film studios, etc.,(5)to grant
recognition, affiliation and approval to schools or institutions in the State of Gujarat;(6)to confer
and award degrees, diplomas, and certificates and provide for lectures, instruction and training for
students including those of affiliated schools, recognized institutions and approved institutions as
also for those under correspondence and continuing education courses;(7)to confer honorary'
degrees or other academic distinctions;(8)to develop academic relationship with shishu-vatikas,
bal-mandirs, and primary and secondary schools which satisfy the need and standards of the
University and to empower them to receive the benefits of the results of the work of the University,
and gradually to the entire education system of the State;(9)to create in the University campus as
also elsewhere, schools to be called Vidya Niketan Schools for various stages of education which will
embody and crystallise the results of the research conducted by the University or elsewhere, and to
spread benefits of the work of these schools to the entire system of education in the State, and to
provide training to teachers and prepare teaching-learning materials for this purpose for the benefit
of the schools in the campus and also other schools in the State;(10)to set up, conduct and promote,
under the responsibility of the Centre of Research, various councils for research in subjects, as the
follows:-(i)synthesis of child-related knowledge-systems (Physical and medical);(ii)synthesis ofChildren's University Act, 2009

child-related knowledge-systems (Psychological and Cultural);(iii)children's philosophy, children's
psychology, children's science, children's technology;(iv)children's rights, human rights,
fundamental duties, ideal of human unity and futuristic visions;(v)gifted children; physically and
mentally challenged children;(vi)national and international education;(vii)multi-linguistic abilities
in Indian and international languages;(viii)children's literature and films; and(ix)development of
integral personality;(11)to set up, promote and conduct under the control and management of
Centre of Research, several departments of research, instruction and communication in regard to
themes, not so generic as those for the councils of research, but more specific and special as those of
as prenatal education, toddlers' education, kindergarten education, primary' education and
secondary education and to relevant stimulation for admiration for uplifting visions, sublime music,
sublime forest life and beauty of nature, as also relevant as the synthesis to powers of creativity with
those of scientific realism, etc.;(12)to set up, conduct and promote a Department of Research in
testing and evaluation and to support the requirement of creating a new system of testing services
for the following purposes:-(i)removing from the students the fear of the examination so that tests
are available by means of computer technology as and when the students are ready for the them, and
even individually;(ii)replacing the test of memory by the test of comprehension;(iii)organising test
for development of personality, sterling qualities of character, and value oriented and skill oriented
development; and organising tests of physical fitness;(13)to establish, conduct and promote a centre
of extension services;(14)to establish, conduct and promote a centre for continuing education and of
telecasting programmes of social education throughout the State, which will stimulate all-round care
of the child and child education formal, non-formal and informal, including methods of education,
through visits to museums and organization of exhibitions, and publications of brochures,
pamphlets, occasional papers and other materials for the promotion of themes of children's care and
education;(15)to develop a programme of establishment and conduct of Bul Bhavans in cities, towns
and even in groups of villages as also to develop an organization, such as "Little Children's Theatre"
so as to promote dramatic activities for the Children of the State;(16)to undertake, organise and
conduct educational programmes for selected, recognised and affiliated Shishu Valikos.
Bal-mandirs, and primary and secondary schools which shall be known as Vidya Niketan
Schools;(17)to undertake, organise and conduct programmes for the purposes of teachers training
who shall be engaged in the work of teaching in the Vidya Nikelan Schools and in affiliated,
recognised and approved schools, and to provide them a general programme of introduction to
philosophy of children's University and to the philosophy of child-centred holistic education, as also
elementary course related to the lessons of history, with special reference to Indian culture, its
underlying spirituality, robust intellectuality and inexhaustible vitality as also to provide for the
following:(i)specialised courses in nutrition, physical health and development of tender faculties of
early childhood;(ii)new pathways in educational programmes, related to different stages of
education such as infant, kindergarten, angadwadis, primary- education, secondary
education;(iii)new pathways in the pedagogy of fine arts, crafts, vocational courses, physical
education, development of hobbies, puppetry, children's drama, children's poetry, children's stories,
children's music, children's dance, emerging new avenues of children's development,
etc.;(iv)in-service training programmes for candidates who wish to qualify to serve as angadwadi
workers;(18)to undertake, organise and conduct, under the Centre of Education, educational
programmes for the University students engaged in research for M.Phil., Ph.D. and doctoral
programmes relating to child education;(19)to provide for instruction, extension, teaching andChildren's University Act, 2009

training in such branches or learning and course of study as the University may, from time to time,
determine;(20)to create posts of Executive Officers, Director-General, Director, Assistant
Director-General, Professors, Associate Professors and Assistant Professors, and other members of
academic and non-academic stall of equivalent responsibility, teaching or non-teaching academic
posts of the University with the prior approval of the Executive Council and to prescribe the
qualifications in accordance with the guidelines of the University Grants Commission or All India
Council for Technical Education and other national statutory bodies and make appointments
thereto; as well as to create nonteaching skilled, administrative, ministerial and other posts and to
prescribe the qualifications and pay-scales with prior approval of the State Government and to make
appointments thereto;(21)to appoint or recognise persons working in any other University or
organisation as adjunct professors, adjunct associate professors, adjunct assistant professors,
visiting professors of the University for specified periods; and to facilitate mobility of academic
members within the University and to other Universities;(22)to designate a University centre or
institution, to monitor, periodically inspect and evaluate the academic performance of various
Centers, Schools and Institutions for ensuring proper standards of research, education, training,
extension services, teaching and adequate library, laboratory, hostel and other academic facilities, in
accordance with the guidelines, if any, laid down by the University Grants Commission or by the
Executive Council;(23)To make special provisions for the benefit of the University education to be
made available to Socially and Educationally Backward Classes and communities particularly from
rural and tribal areas;(24)to supervise, control and regulate the conduct and discipline and
periodical assessment of the performance of the students and employees;(25)to establish teachers'
education and training institutions of innovative education and to provide for education and
training for implementation of the educational innovations;(26)to endeavour to enrich the present
system of education so as to make it more responsive to the ideals of Indian Nationalism and
Internationalism;(27)to develop new system of education as supplementary or alternative to existing
system of education;(28)to co-operate or collaborate with any other University including foreign
Universities, institution, authority or organisation for research and advisory services to borrow
funds for the purposes of the University on the security of the property of the University, subject to
the prior approval of the State Government;(29)to borrow funds for the purposes of the University
on the security of the property of the University, subject to the prior approval of the State
Government;(30)to receive funds for collaboration programmes from foreign agencies subject to
rules and regulations of the Central Government and State Government in that behalf;(31)to
organise and undertake extra-mural teaching and extension services;(32)to fix, demand and receive
fees and other charges;(33)to supervise, control and regulate admission of students;(34)to establish,
organize, maintain, manage and supervise and control the functioning of centres, departments,
institutions, generally, and in particular, laboratories, libraries, museums, computer centers and
equipments;(35)to implement the national literacy and adult education programme through
teachers and students on voluntary basis in the University system and to evolve measures to give
due emphasis to the efforts and performance of the students in this area in addition to their normal
academic performance, and also to evaluate the performance of the teachers in this area;(36)to hold
and manage trusts and endowments and institute and award fellowships, scholarships, studentship,
medals and prizes for teachers and students of the University;(37)to receive grants, subventions,
subscriptions, donations and gifts for the purpose of the University and consistent with the objects
for which the University is established and to allocate and disburse grants out of the fund toChildren's University Act, 2009

institutions and courses recognized by it for the purpose of developing them so as to promote
children's education;(38)to consult and obtain concurrence of the various bodies in respect of
recognition and accreditation granted by the statutory boards and Universities for the purpose of
arriving at equivalence of the courses, programmes and evaluation system established by it with the
existing standards of education; and(39)to do all such other acts and things as the University may
consider necessary, conducive or incidental to the attainment or promotion of the objects of the
University.
7. Modes of Research.
- The University shall conduct its research programmes by employing various means as may be
prescribed by the Statutes.
8. Jurisdiction of University.
- The territorial jurisdiction of the University shall extend to the whole of the State of Gujarat.
9. University open to all irrespective, race, caste, sex or option.
(1)No person shall be excluded from any office of the University or from membership of any of its
authorities or from admission to any degree, diploma or other academic distinction or course of
study on the grounds only of religion, race, caste, sex. place of birth or political or other
opinion:Provided that the University may. subject to the previous sanction of the State Government,
maintain, affiliate or recognize any college or institution exclusively for women either for education,
instruction or residence, or reserve for women or members of classes and communities which arc
educationally backward, places for the purposes of admission as students in any college or
institution maintained or controlled by the University.(2)It shall not be lawful for the University to
impose on any person any test whatsoever relating to religion, race, caste, sex or political or other
opinion in order to entitle him to be admitted as a teacher or to hold any office in the University or
to qualify for any degree, diploma or other academic distinction or to enjoy or exercise any privileges
of the University or benefaction thereof.
Chapter III
Officers of University
10. Officers of University.
- The following shall be the officers of the University, namely:-(i)The Chancellor,(ii)The
Vice-Chancellor;(iii)The Director-General;(iv)The Registrar;(v)The Finance and Accounts Officer;
and(vi)such other officers as may be declared by the Statutes to be the officers of the University.Children's University Act, 2009

11. Chancellor.
(1)The Governor of Gujarat shall be the Chancellor of the University. He shall, by virtue of his office,
be the head of the University.(2)The Chancellor shall have the following powers and
functions:-(a)The Chancellor, when present, shall preside at the Convocation of the University and
may issue direction to the Vice-Chancellor to convene the meeting of any authority of the University
for specific purposes.(b)The Chancellor, in the interests of the University, may direct the Standing
Committee to look into the matter of disqualification of any member of the University', authority,
body or committee, the conduct of any nominated or appointed or co-opted member if he thinks it is
against the smooth functioning of the University.
12. Vice-Chancellor.
(1)The Vice-Chancellor shall be appointed by the State Government in consultation with the
Chancellor in the manner stated hereunder:-(2)(a)There shall be a Search Committee constituted by
the State Government consisting of three members, to be nominated by the State Government to
recommend suitable names, for appointment of Vice-Chancellor. The members of the Search
Committee shall be from any one or more of the following categories, namely:-(i)an eminent
educationist;(ii)a retired Judge of the High Court of Gujarat;(iii)a retired Chief Secretary/Additional
Chief Secretary of the Government of Gujarat;(iv)former Vice-Chancellor of any University in the
State of Gujarat;The Stale Government shall nominate one of them as the Chairman of the
Committee.(b)The members nominated for the committee shall be the persons who are not
connected with the University or any institution of the University.(3)The committee appointed
under sub-section (2) shall begin the process of recommending the panel of names for the
appointment of the Vice-Chancellor, at least four months, before the probable date of occurrence of
the vacancy of the post of the Vice-Chancellor and shall complete within the time limit as may be
fixed by the Chancellor. The State Government may extend the time limit if in the exigency of the
circumstances, it is necessary so to do:Provided that the period so extended shall not exceed three
months in the aggregate.(4)The committee shall consider and recommend the names of persons
who possess the following qualification for the post of Vice-Chancellor:(a)leadership in any field of
children's education, care and development with the experience of having served in a University or
children's institution for not less than ten years and is renowned for research or creative work as
evidenced through publications or guidance provided to research students of a University or college
or leadership provided to the field of humanities, science, fine-arts and crafts, technology, medicine,
industry; or(b)leadership in the field of administration as evidenced through service of ten years of
experience as a Registrar in a University or as a Principal of a college or in a research academy or a
Research Council under the State or the Central Government:(5)The search committee shall
recommend a panel of three suitable persons for the consideration of the Chancellor for being
appointed as the Vice-Chancellor. The names shall be in alphabetical order without any preference
being indicated. The report may be accompanied by a detailed write-up on suitability for each
person included in the panel.(6)The State Government shall, in consultation with the Chancellor,
appoint one of the persons included in the panel referred to in subsection (5) as the Vice-Chancellor
of the University.Children's University Act, 2009

13. Terms and conditions of appointment of Vice-Chancellor.
(1)The Vice-Chancellor shall hold office for a term of five years from the date he enters upon his
office or till attaining the age of sixty-five years, whichever is earlier and shall not be eligible for
reappointment.(2)(a)During the leave or absence of the Vice-Chancellor, or(b)in the event of a
permanent vacancy in the office of the Vice-Chancellor. until an appointment is made under
sub-section (1) of section 12 to that office, the Director General of the University shall carry on the
current duly of the office of the Vice-Chancellor.(3)The Vice-Chancellor shall be a whole-time
salaried officer of the University and his pay, allowances, emoluments and other terms and
conditions of service shall be such as may be prescribed.(4)The Vice-Chancellor may, by writing
under his signature addressed to the Chancellor, after giving one month's notice, resign his office
and such resignation shall take effect from the date of acceptance of his resignation by the
Chancellor.(5)The Vice-Chancellor may be removed from his office if the Chancellor in consultation
with the State Government, is satisfied that the incumbent, -(a)has become insane and stands so
declared by a competent court;(b)has been convicted by a court for any offence involving moral
turpitude;(c)has become an undischarged insolvent and stands so declared by a competent
court;(d)has been physically unfit and incapable of discharging functions due to protracted illness or
physical disability;(e)has willfully omitted or refused to carry out the provisions of this Act or has
committed breach of any of the terms and conditions of the service as prescribed by the State
Government or has abused the powers vested in him or if the continuance of the Vice-Chancellor in
the office is detrimental to the interests of the University;(f)is a member of, or be otherwise
associated with, any political party or any organisation which takes part in politics, or is taking part
in, or subscribing in aid of, any political movement or activity:Provided that the Vice-Chancellor
shall not be removed from his office unless an opportunity of being heard is given to him.
14. Powers and functions of Vice-Chancellor.
(1)The Vice-Chancellor shall be the principal academic and executive officer of the University
responsible for the efficient functioning and development of academic programmes of the
University. He shall oversee and monitor the administration of the academic programmes and
general administration of the University to ensure efficiency and good order of the University.(2)He
shall be entitled to be present, with the right to speak, at any meeting of any authority or body of the
University, but shall not be entitled to vote thereat, unless he is the Chairman or member of that
authority or body.(3)It shall be the duty of the Vice-Chancellor to ensure that the directives of the
State Government, if any. and the provisions of the Act, the Statutes, the Ordinances and the
Regulations are strictly observed and that the decisions of the authorities, bodies and committees
which arc consistent with the Act, the Statutes, the Ordinances or the Regulations are properly
implemented.(4)The Vice-Chancellor may take suitable action in case of any emergency, in interests
of the University:Provided that, where any such action taken by the Vice-Chancellor affects any
person in the service of the University, such person shall be entitled to prefer, within thirty days
from the date on which he receives notice of such action, an appeal to the Executive Council.(5)The
Vice-Chancellor shall be the appointing and disciplinary authority for Director General, Registrar,
Assistant Director General Finance and Accounts Officer, members of the academic staff of the
University' and officers of the University of the rank of Assistant Registrar and of the rankChildren's University Act, 2009

equivalent thereto and above.(6)The Vice-Chancellor shall place before the Executive Council a
report of the work of the University periodically.(7)The Vice-Chancellor shall have the right to cause
an inspection to be made by such person or persons or body of persons as he may direct, of the
University, its buildings, laboratories, libraries, museums, workshops and equipments, hostels
maintained or recognised by the University, and of any institution of the examinations, teachings
and other work conducted by or on behalf of the University, and to cause an inquiry to be made in a
like manner regarding any matter connected with the administration finance, and academic of the
University'.(8)The Vice-Chancellor shall exercise such other powers and perform such other
functions as may be prescribed by or under the Act.
15. Director General.
(1)The Director General of the University shall be appointed by the Executive Council on the
recommendation of the Standing Committee. 'Hie Director General shall be a person of eminence in
academics, research, public service who shall have put in minimum twenty years of service in such
areas.(2)The salary, emoluments, other perks and allowances, the terms and conditions and the
tenure of service of the Director General shall he such as may be prescribed by Statutes.(3)The
functions of the Director General shall be as follows, namely:-(a)to organise and conduct, subject to
the approval of the Executive Council, a major national or international conference at the suitable
interval, preferably every two years, on any important theme related to the tasks of the
University';(b)shall assist the Vice-Chancellor in the task of co-ordination of the activities of the
different centers and institutions of the University;(c)shall carry out the following
tasks:(i)publications of the University including the research journal of the
University;(ii)supervision and monitoring of the schools or institutions affiliated, recognized and
approved by the University;(iii)submit the report to the Vice-Chancellor of the degree of the
efficiency of the extension services of the University and in accordance with the standards laid down
by the Academic Council;(iv)organize and ensure smooth functioning of innovative testing service of
the University which will free the present examination system and ensure that students are
genuinely tested not merely on the basis of written work but also on the basis of interview,
supported by specially organized progressive report submitted by the students so as to provide
insights into the value-oriented and skill-oriented development of the student as also student's
physical fitness.(4)(a)There shall be not more than four Assistant Director General to assist the
Director General in discharge of his duties and functions.(b)The Assistant Director General shall be
appointed by the Executive Council on the recommendation of the standing committee.(c)The
qualifications, salary, other parks and allowances, terms and conditions and tenure of service shall
be such as may be prescribed by Statutes.
16. Registrar.
(1)The Registrar shall be appointed by the Vice-Chancellor on the recommendations of the standing
committee constituted for the purpose.(2)The qualification, salary, emoluments, other perks and
allowances and the terms and conditions of service of the Registrar shall be such as may be
prescribed by Statutes.(3)The Registrar shall be a full-time salaried officer of the University and
shall work directly under the superintendence, direction and control of theChildren's University Act, 2009

Vice-Chancellor.(4)Appointment of the Registrar shall be for a term of five years and he shall be
eligible for re-appointment for further term of five years.(5)When the post of Registrar remains
vacant for any reason or when the Registrar is, by reason of illness or absence or any other cause,
unable to perform the duties of his office, the Vice-Chancellor shall appoint a senior officer of the
University to officiate as the Registrar until the Registrar resumes duty.(6)The Registrar shall be the
ex-officio Secretary of the General Council, Executive Council and Academic Council.(7)The
Registrar shall be the appointing and the disciplinary authority' of the employees of the University
other than the teachers, non-vacation academic staff and officers of the rank of Assistant Registrar
and other officers holding posts equivalent thereto or above.(8)Subject to the decision of the
authorities of the University, the Registrar shall have the power to enter into agreements, sign
documents and authenticate records on behalf of the University.(9)The Registrar shall be the
custodian of the records, the common seal and such other property of the University as the
Executive Council may commit to his charge.(10)The Registrar shall exercise such other powers and
perform such other duties as prescribed by Statutes or assigned to him, from time to time, by the
Vice-Chancellor.
17. Finance and Accounts Officers.
(1)The Finance and Accounts Officer shall be appointed by the Vice-Chancellor in such manner and
shall exercise such powers and perform such duties, as may be prescribed by Statutes.(2)The
qualification, salary, allowances, emoluments, other perks and facilities and terms and conditions of
service, the tenure of the Finance and Accounts Officer shall be such as may be prescribed by
Statutes(3)When the office of the Finance and Accounts Officer is vacant or when the Finance and
Accounts Officer is, by reasons of illness, absence or any other cause, unable to perform the duties of
his office, the duties of the office shall be performed by such person as the Vice-Chancellor may
appoint for the purpose.(4)The Finance and Accounts Officer shall-(a)exercise general supervision
over the funds of the University and shall advise as regards its financial policy; and(b)perform such
other financial functions as may be assigned to him by the Executive Council.
Chapter IV
Authorities of University
18. Authorities of University.
- The following shall be the authorities of the University, namely:-(i)The General Council(ii)The
Executive Council;(iii)The Academic Council;(iv)The Finance Committee; and(v)such other
authorities of the University as may be declared by the Statutes, to be the authorities of the
University.
19. General Council.
(1)The General Council shall be the apex authority of the University.(2)The General Council shall
consist of the following members, namely: -(i)the Chancellor, who shall be the Chairperson of theChildren's University Act, 2009

General Council;(ii)the Vice-Chancellor;(iii)the Minister-in-charge of Education (Primary,
Secondary, Adult), Higher and Technical Education, Gujarat State;(iv)the Minister-in-charge of
Health and Family Welfare, Gujarat State;(v)the Minister-in-charge of Women and Child Welfare,
Gujarat State;(vi)the Executive Chairperson, Gujarat Educational Innovations Commission;(vii)the
Chairman, University Grants Commission or his nominee;(viii)the Chief Secretary, Government of
Gujarat;(ix)the Secretary to the Government of Gujarat, Education Department or his nominee not
below the rank of Deputy Secretary;(x)the members of Gujarat Educational Innovations
Commission;(xi)the Secretary to the Government of Gujarat, Primary Education or his nominee not
below the rank of Deputy Secretary;(xii)the Secretary to the Government of Gujarat, Women and
Child Development Department or his nominee not below the rank of Deputy Secretary;(xiii)the
Vice-Chancellor, Ayurved University, Jamnagar;(xiv)the Chairman, National Council for Teachers'
Education or his nominee;(xv)the Commissioner of Higher Education, Gujarat State or his nominee
not below the rank of Joint Director;(xvi)the Commissioner of Schools, Gujarat State or his nominee
not below the rank of Joint Director;(xvii)the Commissioner of Health, Gujarat State or his nominee
not below the rank of Joint Director;(xviii)the Director General;(xix)the Director, Gujarat Council of
Educational Research and Training, Gandhinagar;(xx)the Chairman, Gujarat Secondary and Higher
Secondary Education Board, Gandhinagar;(xxi)all directors of the University;(xxii)the
Director-General, NCC Head Quarters, Ahmedabad;(xxiii)the Director of UNICEF, Office of Gujarat,
Gandhinagar;(xxiv)the State Chief Commissioner, Gujarat State, Bharat Scouts and Guides;(xxv)the
Professor and Head, Department of Human Development and Family Welfare, M.S. University of
Baroda;(xxvi)the Professor and Head, Department of Pediatrics, Civil Hospital,
Ahmedabad;(xxvii)two leaders of experimental or innovative Education to be nominated by the
State Government;(xxviii)all members of Executive Council;(xxix)five persons to be nominated by
the State Government, who shall include distinguished educationist, scholars, social workers or
representatives of industry and professions;(xxx)the Registrar shall be the Member-Secretary of the
General Council.(3)The term of members other than the ex-officio members shall be five
years.(4)The General Council shall meet at least once during a calendar year.(5)The quorum shall
not be less than one-third of the total number of members of the General Council.
20. Powers and functions of General Council.
- The General Council shall have the following powers and functions, namely:-(1)to approve and
endorse the University's strategic plan, calendar, and monitor the University's performance
periodically;(2)to prepare and submit annual report to the State Government on the affairs of the
University generally, and in particular on management of the University's resources;(3)to determine
the academic awards, degrees, diplomas, certificates, concessions of fee, awards of Fellowships and
Studentships to be offered by the University in consultation with the Academic Council; and(4)to
exercise such other powers and perform such other functions as may be necessary for the efficient
functioning of the University.
21. Executive Council.
- The Executive Council shall be the chief executive body of the University and shall consist of the
following members, namely:-(i)the Vice-Chancellor, ex-officio Chairperson;(ii)the Secretary to theChildren's University Act, 2009

Government of Gujarat, Higher Education or his nominee not below the rank of Deputy
Secretary;(iii)the Secretary to the Government of Gujarat. Finance Department or his nominee not
below the rank of Deputy Secretary;(iv)the Commissioner of Higher Education. Gujarat State or his
nominee not below the rank of Joint Director;(v)the Director General;(vi)two members of the
Academic Council to be nominated by the Vice-Chancellor;(vii)four members to be nominated by
the State Government from amongst the members of the General Council;(viii)the Finance and
Accounts Officer;(ix)the Registrar shall be the Member-Secretary.
22. Powers and functions of Executive Council.
(1)The Executive Council shall have the following powers and functions, namely:-(a)to enter into,
van-, carry out and cancel contracts on behalf of the University;(b)to determine the form of a
common seal for the University and provide for its custody and use;(c)to accept trusts, bequests,
donations and transfer of any movable or immovable property on behalf of the University;(d)to
transfer by sale, or otherwise, any movable property on behalf of the University;(c)to borrow, lend
or invest funds on behalf of the University on the recommendation of the Finance Committee;(f)to
lay down policy for administering funds at the disposal of the University for specific purposes;(g)to
make provisions for buildings, premises, furniture, apparatus and other means needed for the
conduct of the work of the University;(h)to hold, control and arrange for administration of assets
and properties of the University;(i)to approve the annual accounts and the budget estimates
received from the Finance Committee;(j)to lay down terms and conditions of service and other
guidelines approved by the State Government from lime to time; and lay down the procedure for
appointment of University/college teachers and non-vacation academic staff and fix their
emoluments and norms of workload, conduct and discipline:(k)to create posts of University
teachers, officers, non-vacation academic staff and other employees of the University, subject to
prior approval of the State Government;(l)to exercise such other powers and perform such other
functions as may be necessary for the efficient functioning of the University.
23. Academic Council.
(1)The Academic Council shall consist of the following members, namely:-(i)the Vice-Chancellor,
ex-officio Chairperson;(ii)the Director General;(iii)all the Directors of the University;(iv)all the
Professors of the University or Heads of Institutions of the rank of Professors;(v)all the Assistant
Director Generals of the University;(vi)the I leads of affiliated, recognised and approved schools or
institutions;(vii)all the Scholars nominated in the Councils of Research;(viii)all the Scholars
registered in the University for M.Phil., Ph. D. and Doctoral Research work;(ix)all Fellows of the
University;(x)three Students nominated by the Vice-Chancellor on the basis of their excellence in
regard to their outstanding performance in any of the sapladhara activities in the immediate
preceding year;(xi)the Registrar shall be the Member-Secretary.
24. Powers and functions of Academic Council.
- The Academic Council shall have the following powers and functions, namely:-(1)to recommend to
the Executive Council for the institution of degrees, diplomas, certificates, as also their equivalenceChildren's University Act, 2009

if required, with the degrees, diplomas, certificates of the other Universities, recognised Boards of
Studies and examination and also recommend other academic distinctions;(2)to make proposal to
the Executive Council for the institution of fellowships, travelling fellowships, scholarships,
studentships, medals and prizes and make regulations for their award;(3)to grant affiliation and
recognition to schools or institutions;(4)to accord recognition to institutions of research or
specialised studies on the recommendations of the committees appointed by the General
Council;(5)to advise the University on all academic matters and submit to the Executive Council the
details of the academic calendar and feasibility reports on academic programmes;(6)to determine
research areas as well as promote research in the University;(7)to suggest academic
appointments;(8)to recommend for the visiting professors;(9)to propose, organise special seminars,
conferences and workshops;(10)to implement the resolutions adopted by the Executive Council in
respect of academic and research programmes and other activities;(11)to constitute committees for
specific purposes, in such manner as may be determined by it, and may designate one of its
members as Chairperson of the committee;(12)to consider and adopt the annual report, annual
accounts and audit report and forward them to the Executive Council for approval;(13)to delegate
any of its powers, except the power to make, amend or repeal Ordinances, to such officer or
authority of the University or a committee appointed by it. as it thinks fit;(14)to make
recommendations to the Executive Council with regard to the creation, abolition or classification of
teaching posts in the University and qualifications, emoluments and the duties attached
thereto;(15)to formulaic, modify or revise schemes for the organization of the centers, council and
departments of research, schools, or other organization and specialized institutes, and to assign to
them their respective subjects and also to report to the Executive Council for its approval;(16)to
consider proposals submitted by the departments, centers, councils and other recognized
schools;(17)to make recommendations to the Executive Council in regard to the appointment of
examiners and fixation of their fees, emoluments and travelling and other expenses;(18)to make
arrangements for the conduct of examinations and to fix dates for such examinations;(19)to declare
the results of examinations, or to appoint committees or officers for declaration of such result, and
to make recommendations regarding the conferment or grant of degrees, honours, diplomas,
certificates, titles and marks of honour;(20)to perform, in relation to academic matters, all such
duties and to do all such acts as may be necessary for carrying out the provisions of this Act and the
regulations.
25. Meetings of Academic Council.
(1)The Academic Council shall meet as many times as may be necessary, but at least once in six
months.(2)The Vice-Chancellor, or in his absence, the Director General shall preside at the meeting
of the Academic Council.(3)The Academic Council shall meet at such time and at such place and
with such period of notice and shall observe such rules of procedure in regard to transaction of its
business at its meeting, including the quorum at such meeting as may be prescribed;(4)When any
urgent action is required, the Vice-chancellor may, with the approval of the majority of the members
of the Academic Council, permit the business to be transacted by circulation among the members of
the Academic Council. The action so taken as approved by circulation shall be placed before the next
meeting of the Academic Council.Children's University Act, 2009

26. Finance Committee.
(1)The Finance Committee shall consist of the following members, namely:-(i)The
Vice-Chancellor,(ii)The Director General,(iii)The Registrar,(iv)The Finance and Accounts
officer.(v)One member of the Executive Council, to be nominated by it,(vi)One member, to be
nominated by the State Government.(2)The term of members other than the ex-officio members
shall be of three years.(3)A member shall cease to be a member of the Finance Committee, if he
ceases to be a member of the Executive Council.
27. Powers and function of Finance Committee.
(1)The Finance Committee shall have the following powers and functions, namely:-(a)to examine
and scrutinize the annual budget of the University and to make recommendations on financial
matters to the Executive Council;(b)to consider all proposals for new expenditure and to make
recommendations to the executive council;(c)to consider periodical statement of accounts and to
review the finances of the University from time to time, to consider annual accounts and balance
sheet of the University and audited statements and audit reports, and to make recommendations
thereon to the Executive Council;(d)to advise and to make recommendations to the Executive
Council on any financial matters affecting the University, either on its own motion or on reference
from the Executive Council.(2)The Finance Committee shall meet at least once in every six months.
Three members of the Finance Committee shall form the quorum for a meeting.(3)The
Vice-Chancellor or in his absence, the Director General shall preside at the meetings of the Finance
Committee.(4)The annual report of the University shall be prepared under the direction of the
Finance Committee and shall be submitted alongwith its comments to the Executive Council on or
before such date as may be prescribed and shall be considered by the Executive Council at its annual
meeting.
28. Disqualifications for membership of authorities of University.
(1)A person shall be disqualified for being appointed or for being a member of any of the authorities
of the University, if he-(a)is of unsound mind and stands so declared by a competent court;(b)is an
un discharged insolvent;(c)has been convicted of any offence involving moral turpitude;(d)is
conducting or engaging himself in private tuitions or private coaching classes;(e)has been punished
for indulging in or promoting unfair practices in the conduct of any examination in any
form;(f)discloses or causes to disclose to the public, in any.manner whatsoever, any confidential
matter, in relation to examination, the knowledge of which he has come to be in possession, due to
his official position.
Chapter V
Research Council and Department of ResearchChildren's University Act, 2009

29. Constitution and functions of Research council.
(1)There shall be set up under the control of the centre of research, various Councils for Research as
may be necessary, for an research in the various subjects on child related knowledge and children of
psychology, philosophy and the like nature. 00(2)Each Research Council shall consist of the
Vice-Chancellor as its Chairman, the Director General as its Vice-Chairman and the Director who
shall be of the rank of the professor and shall act as the Member-Secretary.(3)Each Research
Council shall consist of four Scholars nominated by the Chairman, Vice-Chairman and
Member-Secretary and the Dean of the centre of research and approved by the Academic
Council.(4)The Scholars shall be eminent educationists in the subject for which the council is
constituted and their role shall be to bring to the council their expert advice so as to promote
research work of the council.(5)The Scholars in each council shall not be entitled to any salary or
emoluments but shall be entitled to a fee as may be prescribed by the regulations of the University
for attending the meeting as also facilities for travel, transport and accommodation for each of their
visits that they may be required to perform.(6)The Council shall meet at such time and place, and
shall observe such rules of procedure with regard to transaction of its business, at the meeting as
may be deemed necessary by it.(7)For research in the research councils as also in the departments of
research, there shall be a provision of fellowships which shall consist of not more than twenty-five
fellows.(8)The Fellows shall be selected by a committee appointed by the Academic
Council:Provided that twelve of the fellowship shall be awarded for junior research Fellows enrolled
in the University for M.Phil. and Ph.D. research work:Provided further that one Fellow- shall be
awarded a national fellowship to the selected from among eminent educationists and the remaining
twelve fellowships shall be awarded as senior fellowship to eminent educationists of the rank of
Associate Professors and Assistant Professors of the University.(9)Each Fellow shall carry out
research in any subject related to the themes of councils of research and departments of research
and deliver lectures in the University whenever so required.(10)The term of Fellow shall be of two
years within which he shall write a thesis of fellowship on the subject assigned to him:Provided that
the Academic Council may extend the term by one year.(11)The salary and allowances payable to
Fellow shall be such as may be determined by the regulations of the University in accordance with
the scheme of Fellowships of the University Grants Commission.
30. Constitution and functions of Department of Research.
(1)There shall be set up under the control and management of centre of research several
Departments of Research. Each Departments of Research shall have a Professor who shall be the
Director and, it may have not more than two Associate Professors and three Assistant Professors as
the Academic Council may deem necessary.(2)Each Department of Research shall be responsible for
instruction and communication in the Centre of Education and in the Centre of Extension Services
in addition to the task of research.(3)Each academic member of Department of Research shall be
responsible for writing a thesis on the subject assigned to him by the Academic Council. The thesis
shall be presented to the Academic Council at the interval of the period of two years, failing which
note shall be taken in the appraisal programme of the Academic Council.Children's University Act, 2009

Chapter VI
Finance
31. University Fund.
(1)The University shall establish a Fund to be called the University Fund.(2)The following shall form
part of, or be paid into the University Fund-(i)any contribution or grant made by the State
Government Central Government or an agency of the Central Government;(ii)any bequests,
donations, endowments or other grants made by any private individual or institution;(iii)income
received by the University from all the sources including income from fees and charges;
and(iv)amounts received from any other source.(3)The University Fund shall be kept in any
Scheduled Bank as defined in the Reserve Bank of India Act, 1934 or in a Co-operative Bank
approved by the State Government for the purpose.(4)The University Fund shall be utilised for such
purposes of the University and in such manner as may be prescribed by the Statutes.
32. Fund of Sponsored Scheme.
- Notwithstanding anything contained in this Act or the regulations, whenever the University
receives funds from any Government or other agencies sponsoring a scheme to be executed by the
University, -(1)the amount received shall be kept by the University in separate account and shall be
utilised for the purpose of the scheme; and(2)the staff required to execute such scheme shall be
recruited in accordance with the terms and conditions stipulated by the sponsoring organization.
33. Accounts, Audit and Annual Report.
(1)The annual accounts and balance sheet of the University shall be prepared under the direction of
the Executive Council and shall every year, be audited by the auditors appointed by the State
Government.(2)The annual accounts, the balance sheet and the audit report shall be considered by
the Executive Council at its annual meeting and it may, by resolution make recommendations with
reference thereto and communicate the same to the Finance Committee.(3)A copy of the annual
accounts and the balance sheet together with the audit report thereon shall be submitted by the
University to the State Government along with the statement of action taken by the University on
the said report.(4)Any observations made by the State Government on the annual accounts shall be
brought to the notice of the University and the compliance report on such observations shall be
submitted to the State Government.(5)The Executive Council shall also prepare, before such date as
may be prescribed by the Statutes, the financial estimates for the ensuing year. The annual accounts
and financial estimates shall be considered by the General Council at its annual meeting and may be
passed with such modifications as the General Council may deem fit.
Chapter VII
Statutes, Ordinances and RegulationsChildren's University Act, 2009

34. Statutes.
(1)Subject to the provisions of this Act, the Executive Council may make the Statutes to provide for
all or any of the following matters, namely:-(i)conferment and withdrawal of honorary degrees and
other academic distinctions;(ii)holding of convocation to confer degrees and diplomas;(iii)powers
and duties and functions of the officers of the University;(iv)constitution, powers and duties of the
authorities of the University;(v)institution and maintenance by the University, of departments,
institutes of research or specialized studies, post-graduate centers in affiliated colleges and
hostels;(vi)acceptance and management of bequests, donation and endowments;(vii)manner of
utilization of the University Fund;(viii)registration of graduates and maintenance of register of
registered graduates;(ix)manner and rules of procedure in regard to transaction of business at the
meetings including the quorum of the meeting, of the authorities of the University and for the
transaction of business;(x)qualifications of professors, readers, lecturers and teachers in affiliated
colleges and recognized institutions;(xi)the maximum number of students to be admitted in a
college;(xii)suitable and adequate physical facilities such as buildings, laboratory , library' books,
equipments required for teaching and research, hostels;(xiii)to conduct various research
programmes;(xiv)qualification, salary, allowances, emoluments and other terms and conditions of
service of the Director General and Registrar, Assistant Director General and Finance and Accounts
Officer;(xv)manner of appointment of the Registrar and Finance and Accounts
Officer.(xvi)preparation of the financial estimates for the ensuing year;(xvii)all maters which by or
under this Act arc to be or may be prescribed by the Statutes;(2)The Statutes may be made,
amended or repealed by the Executive Council in the manner hereinafter provided.(3)The Executive
Council may take into consideration the draft of a Statutes either of its own motion or on a proposal
by any other authority of the University. The Executive Council, if it thinks necessary may also
obtained the opinion of any officer, authority or body of the University in regard to any draft
Statutes which is before it for consideration:Provided that where any such draft Statutes pertains to
academic matters, the Executive Council shall obtain the opinion of the Academic Council before
considering the same.(4)Every Statutes passed by the Executive Council shall be presented to the
Chancellor who may give or withhold his assent thereto or refer it back to the Executive Council for
reconsideration.(5)No Statutes passed by the Executive Council shall be valid or shall come into
force until assented to by the Chancellor.(6)Notwithstanding anything contained in the foregoing
provisions, the Chancellor, on the advice of the State Government direct the University to make
provisions in the Statutes in respect of any matter specified by him and if the Executive Council fails
to implement such a direction within sixty days of its receipt, the Chancellor may, after considering
the reasons, if any, communicated by the Executive Council for its inability to comply with such
direction, make or amend the Statutes suitably as advised by the Stale Government.
35. Ordinances.
(1)Subject to the provisions of this Act, the Executive Council may make the Ordinances to provide
for all or any of the following matters, namely:-(i)the conditions under which students shall be
admitted to courses of studies for degrees, diplomas, and other academic distinctions;(ii)the
conditions governing the appointment and the duties of examiners;(iii)conduct of
examinations;(iv)recognition of teachers of the University;(v)the conditions of residence, conductChildren's University Act, 2009

and discipline of the students of the University;(vi)the recognition of hostels;(vii)the inspection of
affiliated colleges, recognized institutions, approved institutions and hostels:(viii)rules to be
observed and enforced by colleges and recognized institutions and approved institutions in respect
of transfer of students;(ix)the mode of execution of contracts or agreements for, or on behalf of the
University;(x)ail other maters which, by or under this Act may be required to be provided.(2)The
Executive Council may make, amend or repeal Ordinances in the manner hereinafter
provided.(3)No Ordinance concerning the matters referred to in clauses (i) to (viii) of sub-section
(1). or any other matter connected with the maintenance of the standards of teaching and
examinations within the University, shall be made by the Executive Council unless a draft thereof
has been proposed by the Academic Council.(4)The Executive Council shall not have the power to
amend any draft proposed by the Academic Council under sub-section (3) but may approve the draft
Ordinances or cither reject or return it to the Academic Council for reconsideration, in whole or in
part, together with any amendments which the Executive Council may suggest.(5)All Ordinances
made by the Executive Council shall have effect from such date as it may direct, but every Ordinance
so made shall be submitted to the Chancellor within a period of two weeks. The Chancellor shall
have the power to direct the Executive Council, within four weeks of the receipt of the Ordinances,
to suspend its operation, and he shall, as soon as possible, inform the Executive Council of his
objection to it. He may, after receiving the comments of the Executive Council, cither withdraw the
order suspending the Ordinances or reject the Ordinances, and his decision shall be final.
36. Power to make Regulation.
- Subject to the provisions of this Act. the Executive Council may make Regulations consistent with
the provisions of this Act to provide for all or any of the following matters, namely:-(i)constitution of
committees for specific purposes, and members and Chairperson of such committee under
subsection (11) of section 24;(ii)time, place and period of the meetings of the Academic Council and
rules of procedure for transaction of business at such meetings, including the quorum of the meeting
under sub-section (3) of section 25;(iii)fee for attending the meeting and facilities for travel,
transport and accommodation for visits in discharge of function under sub-section (5) of section
29;(iv)salary, allowances payable to the Fellow, in accordance with the scheme of Fellowships of the
University Grants Commission under sub-section (11) of section 29;(v)all other maters which, by or
under this Act may be required to be provided.
Chapter VIII
Supplementary Provisions
37. Prior approval of State Government.
(1)The University may with the prior approval of the State Government -(a)create any post of a
member of the academic or a non-academic staff of the University and the pay and allowances
thereof;(b)divert the use of any earmarked fund for a purpose other than that for which it was
originally earmarked;(c)transfer any immovable property belonging to it;(2)The University may
incur expenditure from the University Fund and development fund, if any. established by theChildren's University Act, 2009

University for the purpose of -(i)initialing and maintaining any self financed academic course,
and(ii)development work.with the prior approval of the State Government, if such expenditure
imposes financial liability on the State Government.(3)Notwithstanding anything contained in any
Statutes, Ordinances and Regulations, the State Government may laid down a standard code for
recruitment and conditions of service of academic and non-academic staff of the University.
38. Power of State Government to give directions.
(1)Where in the opinion of the State Government, the affairs of the University or institution are
carried on in a manner detrimental to the object of the establishment of a University or to its
finances or to public interest, the State Government may cause to be made a full and complete
investigation into the affairs of the University or institution by appointing a committee for this
purpose.(2)The committee shall, within a period of one month or such period as the State
Government may specify, make a report to the State Government containing recommendations as to
the actions to be taken on the affairs of the University or institution, and steps to prevent carrying
on the affairs in the aforesaid manner.(3)If the State Government is satisfied that it is desirable to
take actions as recommended by the committee, it may issue such directions to the University or
institution as may be appropriate in the circumstances.(4)Where the University or college or
institution fails to carry out any direction given by the State Government, it may withhold the grant
to the University or institution.
39. Standing Committee.
(1)There shall be a standing committee of the University tor the purpose of selection for the post of
professors. Director General or Assistant Director General or such other post as may be
prescribed.(2)The standing committee shall consist of the following members, namely:-(a)a retired
judge of the Supreme Court of India or a retired Chief Justice of the Gujarat High Court or an
eminent leader of Industry or Commerce or Management, to be nominated by the Chancellor of the
University;(b)a retired Chief Secretary, Government of Gujarat, to be nominated by the State
Government;(c)a former Vice-Chancellor of a University in Gujarat, to be nominated by the State
Government;The State Government shall nominate one of them as the Chairperson of the
Committee.(3)For the selection for appointment to the posts of the Professors, Director General, or
Assistant Director General, there shall be a search committee consisting of;(a)the Vice-Chancellor,
ex-officio Chairman; and(b)two members nominated by the Academic Council.(4)The search
committee shall recommend to the standing committee, three names of suitable candidates along
with their bio-data. After scrutinizing the bio-data and if necessary after interview of the concerned
candidates, the standing committee may select one of them and recommend the Executive Council
for appointment on the concerned post.(5)The terms and conditions, the tenure of service and
salary, allowances, perks and other facilities of the members of the committee shall be such as may
be prescribed by or under this Act.Children's University Act, 2009

40. Resignation from membership and filling up of casual vacancy.
(1)A member of any authority, other than an ex-officio member, may resign by writing under his
signature, addressing to the Chancellor. The person shall cease to be a member upon his resignation
being accepted by the Chancellor.(2)A person nominated, appointed or co-opted to any authority or
body remains absent without prior permission of the authority or body for three consecutive
meetings, he shall be deemed to have vacated his membership and shall cease to be a member.
41. Indemnity.
- No suit shall be instituted against or other legal proceedings shall lie against or no damages shall
be claimed from, the University, the authority or officer of the University, in respect of anything
which is in good faith done or purported to have been done in pursuance of this Act or the
regulations.
42. Officers, members of authorities, bodies and employees of University to
be public servant.
- All officers, members of the authorities, committees or bodies, members of the academic stall of
the University and other employees of the University, shall be deemed, when acting or purpoting to
act in pursuance of any of the provision of this Act, to be public servant within the meaning of
section 21 of the Indian Penal Code.
43. Power of State Government to make rules.
(1)The State Government may, by notification in the Official Gazette, make rules for carrying out the
purposes of this Act.(2)In particular and without prejudice to the generality of the foregoing powers,
such rules may provide for all or any of the following matters, namely :-(a)the pay. allowances,
emoluments and other terms and conditions of service of the Vice-Chancellor under sub-section (3)
of section 13;(b)to lay down a standard code for recruitment and conditions of service of academic
and non-academic staff of the University under sub-section (3) of section 37;(c)such other post for
which standing committee of the University shall make selection under sub-section (1) of section
39;(d)the terms and conditions, the tenure of service and salary', allowances, perks and other
facilities of the members of the search committee under sub-section (5) of section 39;(3)All rules
made under this section shall be laid for not less than thirty days before the State Legislature as
soon as may be after they are made and shall be subject to rescission by the State Legislature or to
such modification as the State Legislature may make during the session in which they are so laid or
the session immediately following.
44. Power to remove difficulties.
(1)If any difficulty arises in giving effect to the provisions of this Act, the State Government may, by
order published in the Official Gazette. make such provisions not inconsistent with the provisions ofChildren's University Act, 2009

this Act as appears to it to be necessary or expedient for removing the difficulty:Provided that no
such order shall he made under this section after the expiry of two years from the commencement of
this Act.(2)Every order made under this section shall be laid as soon as may he after it is made,
before the State Legislature.
Chapter IX
Transitory Provisions
45. Appointment of first Vice-Chancellor.
- Notwithstanding anything contained in this Act, the first Vice-Chancellor shall be appointed by the
State Government as soon as practicable after the commencement of this Act for a period not
exceeding three years and on such terms and conditions as the State Government thinks fit.
46. Appointment of first Registrar.
- Notwithstanding anything contained in section 16. the first Registrar shall be appointed by the
Slate Government as soon as practicable after the commencement of this Act for a period of not
exceeding three years and on such terms and conditions as the Slate Government may thinks fit.
47. Transitory powers of first Vice-Chancellor.
(1)It shall be the duty of the first Vice-Chancellor-(a)to give recognition to institutions, if any, as far
as possible consistent with the provisions of the Act; and (b) to make arrangements for constituting
the General Council, the Executive Council, the Academic Council and other authorities of the
University within six months after the date of his appointment or such longer period not exceeding
one year as the State Government may, by notification in the Official Gazette, direct.(2)The first
Vice-Chancellor shall, with the assistance of the Advisory Committee consisting of not more than
fifteen members nominated by the Slate Government for the purposes of this section.-(a)subject to
the provisions of this Act. -(i)make provisional Statutes necessary for constituting the aforesaid
authorities and regulating the procedure at their meetings and the transaction of their
business.(ii)draw up any rules, that may be necessary for regulating the method of constitution of
the aforesaid authorities.(b)frame the first Statutes, Ordinances and Regulations under this Act and
submit them for confirmation to the respective authorities when they commence to exercise their
functions.(3)The authorities constituted under sub-section (1) shall commence to exercise their
functions on such date or dates as the State Government may, by notification in the Official Gazette,
direct.(4)The Statutes, Ordinances and Regulations framed by the first Vice-Chancellor shall, when
confirmed by the respective authorities, be published in the Official Gazette.
48. Extra-ordinary powers of first Vice-Chancellor.
- The first Vice Chancellor appointed under section 45 shall have the following powers until theChildren's University Act, 2009

Executive Council commences to exercise its functions -(a)with the previous approval of the
Chancellor, to make additional Statutes to provide for any matter not provided for by the first
Statutes;(b)to constitute provisional authorities and bodies and on their recommendations to make
rules providing for the conduct of the work of the University;(c)subject to the control of the State
Government, to make such financial arrangements as may be necessary to enable this Act, or any
part thereof, to be brought into force;(d)with the sanction of the Chancellor, to make for a period
not exceeding three years, such appointments as may be necessary to enable this Act or any part
thereof, to be brought into force;(e)to appoint any committee as he may thinks fit, to discharge such
of its functions as he may direct; and(f)generally to exercise all or any of the powers conferred on the
Executive Council by or under the provisions of this Act.
49. First appointment of officers of University.
(1)At any time after the commencement of this Act, until such time as the authorities of the
University shall commence to exercise their functions,-(a)the Vice-Chancellor with the previous
sanction of the State Government may appoint any officer of the University;(b)till the Executive
Council is constituted, the teachers of the University may be appointed by the Advisory Committee
referred to in sub-section (2) of section 47 with the approval of the State Government on the
recommendation of the Selection Committee consisting of the following persons, namely:-(i)the
Vice-Chancellor,(ii)a nominee of the Chancellor,(iii)three experts to be appointed out of a panel of
experts drawn by the Advisory Committee.(2)Any appointment made under sub-section (1) shall be
for such period not exceeding three years and on such terms and conditions as the appointing
authority thinks fit:Provided that no such appointment shall be made until financial provision has
been made therefore.Children's University Act, 2009

