Essar Steel India Limited vs Dakshin Gujarat Vij Company
Limited on 22 January, 2015
Author: Abhilasha Kumari
Bench: Abhilasha Kumari
      C/SCA/5621/2014                                     CAV JUDGMENT
          IN THE HIGH COURT OF GUJARAT AT AHMEDABAD
             SPECIAL CIVIL APPLICATION NO. 5621 of 2014
                                  With
             SPECIAL CIVIL APPLICATION NO. 2859 of 2014
                                  With
             SPECIAL CIVIL APPLICATION NO. 5494 of 2014
FOR APPROVAL AND SIGNATURE:
HONOURABLE SMT. JUSTICE ABHILASHA KUMARI
================================================================
1 Whether Reporters of Local Papers may be allowed to see the judgment ? No 2 To be referred to
the Reporter or not ? No 3 Whether their Lordships wish to see the fair copy of the No judgment ?
4 Whether this case involves a substantial question of law as to the interpretation of the Constitution
of India, 1950 or any order made thereunder ? No 5 Whether it is to be circulated to the civil judge ?
No ================================================================
ESSAR STEEL INDIA LIMITED....Petitioner(s) Versus DAKSHIN GUJARAT VIJ COMPANY
LIMITED....Respondent(s)
================================================================
Appearance:
SCA No.5621/2014 MR.S.N.SHELAT, SENIOR ADVOCATE AND MR MIHIR H.
JOSHI, SENIOR ADVOCATE WITH MR KEYUR GANDHI FOR NANAVATI
ASSOCIATES for the Petitioner No.1 MR MIHIR THAKORE, SENIOR ADVOCATE
WITH MS LILU K BHAYA, ADVOCATE SCA No.2859/2014 MR MIHIR THAKORE,
SENIOR ADVOCATE WITH MS LILU K BHAYA, ADVOCATE MR.S.N.SHELAT,
SENIOR ADVOCATE AND MR MIHIR H. JOSHI, SENIOR ADVOCATE WITH MR
KEYUR GANDHI FOR NANAVATI ASSOCIATES for the Respondent No.1 SCA
No.5494/2014 MR.S.N.SHELAT, SENIOR ADVOCATE AND MR MIHIR H. JOSHI,Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

SENIOR ADVOCATE WITH MR KEYUR GANDHI FOR NANAVATI ASSOCIATES
for the Petitioner No.1 MR MIHIR THAKORE, SENIOR ADVOCATE MS LILU K
BHAYA, ADVOCATE for the
================================================================
CORAM: HONOURABLE SMT. JUSTICE ABHILASHA KUMARI Date : 22 /01/2015
1. Rule   is   issued   in   each   petition.   Ms.Lilu   K.  Bhaya,   learned   advocate  
waives   service   of   notice   of  Rule   for   the   Respondent−Dakshin   Gujarat   Vij  
Company  Limited   in   Special   Civil   Applications   Nos.5621/2014 
and 5494/2014. Mr.Keyur Gandhi, learned advocate for  Nanavati   Associates,  
learned   counsel,   waives   service  of   notice   of   Rule   for   Respondent   No.1−
Essar   Steel  India   Limited   in   Special   Civil   Application  No.2859/2014.   As  
Respondent   No.2   in   Special   Civil  Applications   Nos.5494/2014   and  
2859/2014   is   the  Appellate   Authority   whose   order   is   impugned   in   the 
said petitions, it is not necessary to issue notice of  Rule to the said respondent.
2. Learned   counsel   for   the   respective   parties   have  addressed   final  
arguments,   therefore,   the   petitions  are being heard and decided finally.
3. Special   Civil   Application   No.2859/2014   can   be  said   to   be   the   lead  
matter   and   Special   Civil  Application   No.5494/2014   is   a   cross−petition.   The 
petitioner   in   the   former   petition   is   the   Dakshin 
Gujarat Vij Company Limited ("DGVCL", for short). The 
petition has been preferred under Articles−226 and 227  of   the   Constitution   of  
India,   challenging   the   order  dated 01.11.2013, passed by the Appellate Authority, 
holding   that   the   revised   Supplementary   Bill   dated  25.01.2012   for   an  
amount   of   Rs.192.58   Crores   for 
168.62 Million Units (MU) electricity issued by DGVCL  upon   respondent   No.1−
Essar   Steel   India   Limited  (hereinafter   referred   to   as   "ESIL"   or   "Essar",  
for  convenience) is not justifiable under the provisions  of   Section−126   of   the  
Electricity   Act,   2003   ("the  Act",   for   short),   and   directing  DGVCL  to  revise  
the  said   bill   by   issuing   a   reduced   bill   for   25.23   MU 
electricity at twice the normal tariff   (HTP−1), and  to   refund   the   balance   amount
  to   Essar   along   with  interest and the delayed payment charges thereon.
4. The latter petition is a cross−petition, wherein 
the same order passed by the Appellate Authority has 
been challenged by ESIL to the extent that the appeal 
preferred by ESIL before the Appellate Authority has  been   partially   rejected,   by  
holding   that   ESIL   has  unauthorizedly   used   25.23   MUs   of   power   and  
thereby  holding   it   liable   to   pay   penal   charges   as   provided  under Section−
126 of the Electricity Act, 2003.Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

5. Special   Civil   Application   No.5621/2014   does   not  arise from the above−
mentioned order of the Appellate  Authority   and   does   not   appear   to   have   any  
direct  connection with the dispute involved in the above two 
petitions. The petitioner in this petition is ESIL and 
the petition is filed for quashing and setting aside 
the letters dated 05.04.2014 and 07.04.2014, issued by  the respondent−
DGVCL, by way of which  DGVCL has asked  the   Western   Region   Load   Dispatch  
Centre   (WRLDC)   to  withdraw   the   Open   Access   Permission   granted   to  
ESIL  and   has   demanded   Rs.126.67   Crores   towards   Cross  Subsidy   Sur−
charge   and   electricity   dues.   It   is   the  case   of   ESIL   that   an   amount   of  
Rs.192.58   Crores   is  liable   to   be   refunded   to   it   pursuant   to   the   order 
dated   01.11.2013,   passed   by   the   Appellate   Authority  (impugned   in   Special  
Civil   Application   No.2859/2014) 
and the amount of outstanding dues of ESIL, including  Cross   Subsidy   Surcharge,  
be   deducted   from   the   above  amount.
6. The   factual   background   in   which   Special   Civil  Application   No.2859/2014  
(the   lead   petition)   and  Special   Civil   Application   No.5494/2014   (the   cross−
petition) have been preferred, assumes some importance  for   a  clear  understanding
  of   the  issues   involved   in  the petitions. Culled out from the record, it is being 
briefly recorded as below.
7. The petitioner in the lead petition is DGVCL, a 
company incorporated and registered under the relevant 
provisions of the Companies Act, 1956,  engaged in the  business   of   distribution   of
  electricity   in   the  southern   region   of   the   State   of   Gujarat,   under   the  Act.  
It   is   a   Distribution   Licencee   under   the  provisions of the Act.
8. The petitioner in the cross−petition is ESIL (of  the   Essar   Group   of  
companies),   which   is   a   company  registered   under   the   Companies   Act,  
1956,   and   is  engaged   in   the   business   of   manufacturing   steel   and 
allied steel products. It has set up its factory at  Hazira.
9. ESIL  had  set  up  a  plant  for  the   manufacture  of  Hot   Rolled   Steel   Coils   in  
the   year   1990−91. 
Subsequently, a power plant of 515 MW capacity was set 
up by Essar Power Limited, a group company of ESIL. 
The said power plant commenced operations in the year  1995.   Essar   Power   Limited   agreed   to  
supply   300   MW  power to the erstwhile Gujarat Electricity Board under 
a Power Purchase Agreement dated 30.05.1996. The rest 
of 215 MW of power was to be supplied to ESIL for its 
captive use. In the year 2005, another group company 
of ESIL, that is, Bhander Power Limited, also set up Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

an additional Captive Power Plant of 505 MW capacity  to   cater   to   its   captive   needs.   In  
addition   to   the  plant of Bhander Power Limited, ESIL has its Captive 
Power Plant of 35 MW within the same complex. For the  distribution of the afore−
mentioned 505 MW and 515 MW  capacity of power, ESIL and its group companies have 
set up a Sub−Station, including a Bus−Bar, within its 
premises. DGVCL raised a dispute in the year 2006, for  the   payment  of  wheeling  charges,  on  the
  ground   that  the   Bus   Bar   vested   in   Gujarat   Energy   Transmission 
Corporation ("GETCO", for short) by virtue of the fact 
that electricity flowed from one end of the Bus−Bar to 
another. ESIL filed a writ petition before this Court,  being   Special   Civil   Application  
No.13886/2006.   By  judgment dated 15.01.2007, this Court held that Bus−
Bars are an integral part of the distribution system 
of GETCO, therefore, wheeling charges are payable by  ESIL   to   DGVCL.   Being   aggrieved   by  
the   aforesaid  judgment, ESIL preferred an appeal before the Division 
Bench of this Court, by filing Letters Patent Appeal  No.254/2007,   which   came   to   be   dismissed
  by   judgment  dated   30.08.2011.   ESIL   approached   the   Supreme   Court 
against the judgment of the Division Bench, by filing  Special   Leave   Petition   (Civil)  
Nos.27540/2011   and  28099/2011, wherein the Supreme Court has granted an  order   of   status−
quo,   and   the   matter   is   pending   for  final decision.
10. Subsequently,   ESIL   decided   to   increase   the 
manufacturing capacity of the steel plant on account 
of the growing demand for steel and allied products. 
Accordingly, ESIL and its group companies set up four  additional   units,   namely   (i)   Essar   Steel
  (Hazira)  Limited (ESHL), (ii) Hazira Plate Limited (HPL), (iii) 
Hazira Pipe Mill Limited (HPML) and (iv) Essar Steel  Orissa   Limited   (ESOL).   The   first   three  
units   were  established within the same complex, adjacent to the  main   manufacturing   facility  
and   the   fourth   unit   was  established in the State of Odisha. 
11. Pending   the   hearing   and   final   disposal   of   the  Letters   Patent   Appeals,   ESIL   wanted  
to   resolve   the  issue of wheeling of power from Bhander Power to Essar 
Steel, and for the said purpose, wanted to shift the  Ichchhapor−Sachin   Line.   Power   is   also  
received   by  ESIL, as a consumer, from the distribution Licencee− DGVCL.   It   was   felt  
necessary   that,   in   view   of   the  claim of GETCO for transmission charges and looking to  the  
nature   of   the   distribution   of   electrical   energy 
and consumption of power by units of the Essar Group  from   the   power   plants   situated   within  
the   complex  through   the   common   integrated   line/Bus   Bar,   and   to 
ensure that no power supplied by DGVCL, or any power  incidentally flowing through the Bus−
Bar on account of  it   being   connected   to   the   Sub−Stations   of   the  distribution/transmission  
Licencees   at   both   ends,  should be consumed by any entity other than ESIL, a  consumer   of  
UGVCL,   an   appropriate   resolution   of   the  above issues ought to be worked out.
12. A   meeting   was,   therefore,   held   at   Gandhinagar, 
under the Chairmanship of Shri D.J.Pandian, Principal  Secretary,   Energy   &   Petro   Chemicals  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Department,   on  01.02.2010, to resolve the issues raised by the Essar 
Group. The said meeting was attended by the Managing 
Director of Gujarat Urja Vikas Nigam Limited ("GUVNL",  for   short),   Executive   Director  
(Finance)   of   GUVNL,  Managing Director of GETCO, Chief Electrical Inspector  and  
representatives   of   the   Essar   Group   and   Bhander 
Power Limited, to discuss the issue of the shifting of 
the Ichchhapor line and supply of power to the Essar 
Group companies from Bhander Power Limited. GUVNL is  the   holding   company   of   GETCO  
and   DGVCL.   After  discussions on the issue of ensuring that the supply 
of power to Essar Group companies would only be from 
the power plants located in the complex and that DGVCL 
power is used only by its consumer, namely, ESIL, it 
was suggested that an amicable solution be arrived at,  within   the   framework   of   regulations.  
The   final  solution contemplated was the isolation of a section  of the integrated line/Bus−
Bar in such a manner that  the   incidental   power   flowing   through   the   lines,   on 
account of it being connected at both ends to the Sub− Stations   would   stop,   thereby   ensuring  
appropriate  accounting and metering of the electricity consumption 
of the various units in the complex. Certain decisions  were   taken   by   the   authorities   in   this  
regard   as  recorded   in   the   Minutes   of   the   Meeting   dated 
01.02.2010, principally being that all member units of  the Essar Group (other than the consumer−
ESIL) should  become consumers of the Distribution Licencee - DGVCL 
so that the question of a non−consumer incidentally, 
or inadvertently, availing of power from DGVCL would  not   arise.   Alternatively,   it   was  
suggested   that   all  the   electrical   lines   supplying   power   to   the   member 
units are run in isolation of the integrated line/Bus− Bar   and   also   from   the   DGVCL  
connection   for   the  contracted   demand,   in   order   to   achieve   the   purpose 
that DGVCL power is not consumed, either incidentally  or inadvertently, by non−
consumers in the complex.
13. ESIL   proposed   that   it   would   install   a   reverse 
power flow relay system to ensure that, at no point of  time,  DGVCL  power  would  flow   through  
the   Bus−Bar   to  the member units since, in the event of a flow−back of  energy from the Bus−
Bar to Bhander Power Limited, the  reverse power flow relay would trigger the automatic  opening  
of   the  existing  isolator  on  the   line,   which 
would stop the current from flowing into Bhander Power  Limited.   ESIL   was   directed   that  
meters   should   be  placed on the electrical lines which connected Bhander  Power   Limited   with  
the   Bus−Bar,   which   would   record  electrical   energy   flowing   back   through   the   Bus−Bar 
directly,   or   indirectly,   to   the   electric   lines  supplying   energy   to   the   other   member   units  
of   the  Essar   Group   companies,   which   were   not   consumers   of 
DGVCL. It was further directed that in the event that 
any energy was found so recorded, the power consumed 
would be treated as DGVCL power and would be charged 
at the rate of twelve times, at twice the normal rate.Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

14. Certain steps were directed to be taken by ESIL,  in   line   with   the   decision   of   the  
authority,  inter− alia,   being   that   of   the   two   electrical   lines 
connecting Bhander Power Limited with the Bus−Bar, one 
line would remain connected on which the reverse power 
flow relay and the meter would be installed and the  other line would be disconnected from the Bus−
Bar and  connected to the unit of Essar Steel (Hazira) Limited, 
which was the only other unit utilizing energy at 220  KV.   The   second   line   would   terminate   at
  Essar   Steel  (Hazira) Limited.
15. On 30.06.2010, an event took place which has some  relevance   to   the   dispute   involved   in  
the   petitions.  The High Court sanctioned the Scheme of Amalgamation  between   Essar   Steel  
India   Limited,   Essar   Steel  (Hazira)   Limited,   Hazira   Plate   Limited,   Hazira   Pipe  Mill  
Limited   and   Essar   Steel   Orissa   Limited   by   an 
order of that date. The Scheme was to be effective on 
the date on which the last of the necessary certified 
copies were filed with the Registrar of Companies of  the   respective   States.   The   effective   date  
under   the  Scheme was 05.08.2010.
16. Pursuant   to   the   meeting   dated   01.02.2010,   ESIL 
took steps for the installation of the reverse power 
flow relay. There were two electrical lines connecting  Bhander   Power   Limited   to   the   Bus−Bar.
  On   both   these  lines, four line isolators (two each) had already been 
installed earlier as approved by the Chief Electrical  Inspector.   On   the  first  line   the  reverse  
power   flow  relays   were   installed   in   such   a   manner   that   in   the 
event any power flow was detected from the Bus−Bar to  Bhander   Power   Limited   (reverse   flow),
  it   would  automatically   trigger   the   opening   of   the   line 
isolators, which would forthwith stop the reverse flow 
of power. As far as the second line was concerned, the 
same was diverted from just before the existing line  isolator, close to the Bus−
Bar, by underpass to Essar  Steel  (Hazira)  Limited.  To  ensure   that  there  was   no 
reverse flow from the Bus−Bar on account of the pre− existing   segment   of   the   second   line  
after   the  underpass   connection,   the   line   isolator   on   that 
segment second line was kept open. The modification of  the   second   line   was   duly   approved  
by   the   Chief  Electrical Inspector. In the meanwhile, meetings were  held   on   24.01.2011   and  
27.01.2011,   under   the  Chairmanship of Shri D.J.Pandian, Chairman, GUVNL and  Secretary,  
Energy   and   Petro   Chemicals   Department,  which   were   attended   by   the   Chief   Engineer  
and   In− charge Managing Director of DGVCL, State Load Dispatch  Centre   of   GETCO   and  
representatives   of   the   Essar  Group, with a view to determining the methodology of 
energy accounting in respect of the unit of ESIL (a  consumer   of   DGVCL)   to   be   implemented  
after   the  shifting of the Ichchhapor line. It was recorded that 
the work of shifting of the Ichchhapor line had been 
completed and, therefore, the metering locations would  have   to   be   changed   and   the   metering
  should   be   such  which would accurately record the actual consumption 
of the consumer of the Distribution Licencee, namely,  ESIL,   as   also   the   energy   accounting   of  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Essar   Power  Limited, Bhander Power Limited and the Captive Power  Plants   of   Essar   Steel  
India   Limited.   It   was   decided  that   no   transmission   charges/distribution   charges 
would now be claimed against Essar and a formula was 
derived  for measuring the consumption of Essar Steel  Limited   so   that   the   existing   meters  
would   only   be  utilized   for   the   purpose   of   verification.   It   was  decided   that   no  
transmission   charges   would   be  applicable   on   the   power   scheduled   from   Essar   Power, 
Bhander Power Limited, and the Captive Power Plants to  ESIL.   Similarly,   no   transmission  
losses   would   be  applicable for the power scheduled from Essar Power,  Bhander   Power   Limited
  and   Captive   Power   Plants   to  ESIL,   as   these   losses   of   radial   system   would 
automatically be counted in the drawl of ESIL. Hence,  the   actual   losses   of   the   radial   system  
would  automatically be borne by ESIL. It was further decided  that   ESIL   would   apply   to  
DGVCL   for   the   shifting   of  metering   locations   at   Ichchhapor−Sachin   lines   for 
deriving the consumption of power by ESIL, as per the  above formula.
17. Essar   addressed   a   letter   dated   21.05.2011   to  GETCO,   stating   that   the   Scheme   of  
Amalgamation   had  been   sanctioned   by   the   High   Court   and   has   become  effective   from  
05.08.2010,   therefore,   the  units/companies covered under the Scheme,  inter−alia,  being   Essar
  Steel   (Hazira)   Limited   had   merged   into  Essar   Steel   India   Limited   which   was   an  
existing  consumer of DGVCL and, therefore, the contract demand 
of Essar Steel India Limited would automatically cover 
the supply to the units of the merged entities and the 
reverse power flow relay should be removed. According 
to Essar, there is no company having its units within 
the complex which is not covered under the Scheme of  Amalgamation.
18. By reason of the merger, the power requirement of  Essar   Steel   India   Limited   increased;  
therefore,   it  applied   to   DGVCL   on   01.06.2011,   for  the   increase   in 
the contract demand from 44.5 MVA to 60 MVA.
19. On   04.06.2011,   GETCO   informed   ESIL   that   the  details   of   the   amalgamation   should  
be   submitted   to  DGVCL   for   confirmation,   and   after   the   factum   of  amalgamation   was  
verified,   and   after   personal  inspection   at   the   site   in   order   to   ensure   that   the 
power of DGVCL was not being utilized by other units 
not covered under the amalgamation, the reverse power  flow   relay   could   be   removed   by  
GETCO.   By   a  communication of the same date, GETCO directed DGVCL  to   take   steps   for   the
  removal   of   the   reverse   power  flow relay.
20. Essar addressed a letter to DGVCL for the removal 
of the reverse power flow relay on an urgent basis,  stating   that   there   was   a   problem   of  
frequent   line  tripping and low utilization of the additional power 
of 200 MW purchased from GUVNL, by an Agreement dated  13.05.2011, under open access.
21. In response to the application made by Essar for 
increase in the contract demand on 09.06.2011, DGVCL  directed   ESIL   to   get   the   power  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

boundary   approved.  Accordingly, on 15.06.2011, Essar made an application 
seeking the extension of the power boundary of ESIL, 
so as to include within it, the units of the companies 
which had merged with ESIL and the unit of Essar Heavy 
Engineering Services Limited, as a single consumer of  DGVCL.
22. On 21.06.2011, DGVCL addressed a letter to ESIL  stating   that   the   documents   submitted  
along   with   the  application dated 15.06.2011, for the extension of the  power   boundary,   were  
not   complete   and   all   relevant  documents   be   submitted   in   order   to   process   the 
application.   On   27.06.2011   and   01.07.2011,   Essar  addressed   letters   to   DGVCL,   submitting
  further  documents   and   details   and   seeking   sanction/approval 
for the removal of the underpass arrangement and the  final   proposed   arrangement   for  
restoration   of   the  earlier   position   and   connections   regarding   the   main  receiving Sub−
Stations.
23. On   21.06.2011,   the   officers   of   DGVCL   and   GETCO  conducted   an   inspection  of  the  
premises   of   Essar   in  the   presence   of   its   officers   and   found   that   DGVCL 
power was being taken to the units of the companies  which   had   merged   with   ESIL   vide   the  
order   dated  30.06.2010,   and   the   unit   of   Essar   Heavy   Services 
Limited through the grid, although the said units were 
not the consumers of DGVCL. It was also found by DGVCL 
that the Bhander Power Limited end of the Tie Line−2 
had been disconnected, indicating that no power from 
Bhander Power Limited was being utilized by such units 
and only DGVCL power was being utilized. On retrieval 
of the MRI data of the apex meter, DGVCL was able to  determine   that   DGVCL   power   was  
being   utilized   with  effect from 17:00 hours on 15.06.2011 upto 21.07.2011.
24. DGVCL,   therefore,   issued   a   notice   dated  26.07.2011,   to   ESIL,  inter−alia,   pointing   out  
the  aforesaid facts and stating that this action of Essar  amounted   to   a   clear   breach   of   the  
Agreement   as  recorded in the Minutes of Meeting held on 01.02.2010. 
Essar was asked to clarify, within seven days, why the 
quantum of power imported from the grid should not be 
charged at the rate of twelve times the quantity found 
to have been utilized, at twice the normal rate (HTP−
1)   of   DGVCL.   It   further   asked   ESIL   to   immediately  restore   the   original   position   of   Tie
  Line−2   as  existing prior to 15.06.2011. In response to the said  notice,   Essar   addressed   a  
letter   dated   29.07.2011,  contending,  inter−alia, that as informed earlier, on  account   of   the  
additional   load   on   the   lines   due   to  supply and consumption of additional 200 MW of power 
from GUVNL under open access, it was facing frequent 
tripping of lines which caused black out and damage to 
the plant and, therefore, there was an urgent need to  remove   the   reverse   power   relay.   It   was  
further  contended   that  the   closing  of  the   line  isolator  did Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

not result in any power supplied by DGVCL to flow to 
units which did not stand merged with ESIL, therefore, 
there was no breach of any condition of the Minutes of 
the Meeting dated  01.02.2010, and the demand made by  DGVCL   was   not   justified.   However,  
Essar   agreed   to  restore   the   original   position   prevailing   prior   to 
15.06.2011, and also requested DGVCL to expedite the 
decision on the application for the extension of the  power   boundary   already   made   by   it.   The  
original  position was duly restored by Essar and recorded vide  e−mail dated 30.07.2011.
25. Essar   made   another   representation   to   DGVCL   on  08.09.2011,   contending   that   after  
the   merger   of   the  other companies whose units were within the complex,  their   identities   were
  lost   and   they   had   ceased   to  exist, for all purposes, with effect from 05.08.2010. 
After the merger, the power required by these units is 
actually the power required by ESIL only, which is a 
consumer of DGVCL. There was, therefore, no question 
of any breach of the conditions of the Minutes of the  Meeting dated 01.02.2010.
26. Pursuant to the notice of DGVCL and the reply of 
Essar referred to above, a decision came to be taken 
by DGVCL, rejecting the contentions raised by ESIL and  assessing   the   energy   charges   at  
Rs.2311,02,43,968/−  for 202,09,92,000 KWH (168416000 KWH or 168.42 MV, as 
recorded in the meter into twelve) at twice the rate, 
as per the Minutes of the Meeting dated 01.02.2010, in  respect   of   the   period   between  
15.06.2011   to  30.07.2011.
27. Representations   were   made   by   Essar   to   various  authorities,   including   DGVCL,   against
  what   it  considered as an exorbitant and unjustified demand by  DGVCL.   Pursuant   thereto,   the
  Government   of   Gujarat  constituted a Committee consisting of three members,  being   the  
Managing   Director   of   GETCO,   the   Chief  Electrical Inspector and a Senior Technical Officer, 
to   examine   the   entire   issue   having   regard   to   the 
prevailing provisions of law, Minutes of Meeting and  the   effect   of   the   amalgamation   order   of  
the   High  Court, to suggest a fair solution to the dispute. On 
19.10.2011, Essar wrote to DGVCL requesting that the 
demand under the Supplementary Bills should be kept in  abeyance   pending   the   resolution   of  
the   dispute.   On  25.10.2011, in response to the above letter of Essar,  DGVCL   stated   that   it   was
  not   possible   to   keep   the  Supplementary   Bills   in   abeyance,   or   even   to   process 
the application for extension of the power boundary, 
until the amount of the supplementary bills was paid.
28. The   Committee   constituted   by   the   Government   of 
Gujarat gave its report on 13.12.2011, holding, inter− alia,   that   Essar   had   taken   unilateral  
action   in  changing   the   electrical   connection   and   that   Essar's 
contention that after the shifting of the Ichchhapor  line,   the   Minutes   of   the   Meeting   dated  
01.02.2010  would   not   be   operative   and   the   reverse   power   flow  restriction   would   stand  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

removed,   was   not   acceptable  and the Minutes of the Meeting dated 01.02.2010 would 
stand. It was further held that the total energy of 
168.416 MU on the second electric line would include  power   from   the   power   plants   and   open
  access   and,  therefore, could not be stated to be DGVCL power. The 
Committee finally concluded that there was no theft of 
energy but a unilateral action was taken by Essar to 
overrule the reverse power relay restriction and that 
the whole matter of the supplementary bills rested on 
the fact of the use of unauthorized power outside the 
approved boundary of Essar Steel India Limited on the 
date of detection by DGVCL, as per the Minutes of the  Meeting dated 01.02.2010.
29. On 05.01.2012, the Government of Gujarat wrote a 
letter to DGVCL, stating that upon careful examination 
of the findings and conclusions of the Committee, it  was   found   that   although   Essar   failed   to  
inform   the  Power Utility about the modification made by it, the 
fact remains that there is no theft of electricity and 
full energy is accounted and paid for. Therefore, it  is   viewed   that   while   deciding   the   issue   of  
the  supplementary bills raised by DGVCL, the conclusions  drawn   by   the   Committee  
constituted   for   the   purpose,  the provisions as contained under sub−section (6) of  Section−126  
of   the   Electricity   Act,   2003,   and   the  instructions   issued   by   the   Government   of   India, 
Ministry of Power, vide their letter dated 30.11.2011, 
need to be examined. It was further stated in the said  letter   that   keeping   in   view   the   overall  
industrial  interest of the State, pending the final settlement of  the   claim   by   DGVCL,   it   is   not  
prudent   to   hold  (withhold) open access to Essar. DGVCL was, therefore, 
directed to apply the provisions of sub−section (6) of  Section−
126 of the Act and charge penalty at a rate  equal   to   twice   the   tariff   for   electricity   consumed 
till the case of the total claim was settled.
30. Pursuant   to   the   aforesaid   letter   of   the   State  Government,   DGVCL   issued   two   revised
  supplementary  bills   on   25.01.2012,   for   a   total   amount   of  Rs.192,58,53,664/−
 worked out as per the provisions of  Section−126(6)  of  the   Act,  till   the  total  claim  was 
finally settled.
31. On 12.03.2012, ESIL deposited 50% of the charges  under   the   supplementary   bills,   under  
protest.   The  balance 50% was paid in installments, as recorded vide 
letter dated 28.03.2012. Delayed payment charges, as 
demanded by DGVCL, were also paid by Essar on various  dates.
32. On 17.04.2012, the request for the extension of  the   power   boundary,   made   by   Essar,   was  
approved   by  DGVCL.   On   14.05.2012,   upon   approval   of   the   revised 
power boundary, DGVCL approved, by way of a stop gap  arrangement,   the   same   system  
adopted   by   Essar   on  15.06.2011,   closing   the   line   isolator,   thereby  permitting   reverse  
flow   of   energy   from   the   Bus−Bar  through   part   of   the   second   electric   line   and   then Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

through   the   underpass   to   the   Essar   Steel   (Hazira)  Limited.
33. On   19.11.2012,   Essar   preferred   an   appeal   under  Section−127   of   the   Act,   against   the  
revised  supplementary   bills,   before   the   Appellate   Authority  notified   by   the   Government  
of   Gujarat,   under   the  Appeal   to   the   Appellate   Authority   Rules,   2004,   as 
amended in 2006. On 12.12.2012, preliminary objections  were   raised   by   DGVCL   to   the  
maintainability   of   the  appeal under Section−127 of the Act. On 28.05.2013, a  Written   Statement
  was   filed   by   DGVCL,   whereas   Essar  filed   its   Written   Submissions   on   18.08.2013,  
before  the Appellate Authority.
34. By the impugned order dated 01.11.2013, passed by 
the Appellate Authority, it has been held, inter−alia,  that   during   the   relevant   period   from  
15.06.2011   to  30.07.2011, ESIL had consumed total power of 637.26 MU 
within the authorized and unauthorized premises, out  of   which   its   own   generation   was  
470.52   MU.   Power  totalling   141.51   MU   was   purchased   from   GUVNL   under 
open access and 25.23 MU were supplied by DGVCL as per 
SLDC data. It was held by the Appellate Authority that  the   supplementary   bills   issued   by  
DGVCL   could   be  considered   as   raised   for   unauthorized   use   of  electricity  by  the  
consumer   in   the   area   or   premises  not authorized by the Licencee and the claim raised on  the  
basis   of   unauthorized   use   of   168.42   MU   was  unreasonable,   unjustified   and   contrary   to  
the  provisions   contained   in   Section−126   of   the   Act,   and 
has to be revised to 25.23 MU. Since the consumer had  paid   the  full   amount  of  the  
supplementary  bill,  the  balance amount was liable to be refunded to it. Being 
aggrieved by the aforesaid order, DGVCL has preferred  the   lead  petition  and   ESIL  has  
preferred   the  cross− petition, challenging that portion of the order that  holds   that   25.23   MU  
of   electricity   has   been  unauthorizedly used by it.
35. In   the   above   background,   learned   Senior   Counsel  for   the   respective   parties   have  
made   detailed   and  elaborate submissions, the gist of which is recorded  hereinbelow.
SUBMISSIONS   OF   RESPECTIVE   PARTIES   IN   SCA  No.2859/2014 (lead petition):
36. Mr.Mihir J. Thakore, learned Senior Advocate for  the petitioner−DGVCL has submitted that :
(i) The   appeal   preferred   by   ESIL   against   the  revised   supplementary   bills  
issued   by   DGVCL,  purportedly   under   Section−126   of   the   Act,   is  not  
competent,   as   the   said   bills   were   issued  pursuant   to   the   directive   of   the  
State  Government   and,   therefore,   it   cannot   be 
considered to be a final order under Section−
126 of the Act. The supplementary bills were a  result   of   a   computation   method  
adopted   as   an  ad−hoc   arrangement   and   there   was   no   finality  attached   to  
it.  The   procedure   envisaged  under  Section−
126 of the Act has never been followed  and   there   was   no   provisional   assessment
  or   a  final   order.   As   the   supplementary   bills   were  not   issued   after  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

following   the   provisions   of  Section−126 of the Act, no appeal against them 
is maintainable under Section−127 of Act. Even 
if it is assumed that an appeal could have been  preferred,   and   without   prejudice  
to   the  above  submissions,   such   appeal   is   barred   by  limitation,   on   the   date
  of   its   presentation. 
The provisions of Section−127(1) prescribe that  an   appeal   may   be   filed   within   thirty   days  
of  the order. In the present case, the appeal was  preferred on 19.11.2012, challenging the bills 
dated   25.01.2012,   almost   after   ten   months,  which is much beyond the prescribed period of 
limitation.   This   contention   was   specifically  raised  before   the   Appellate  Authority   but   has 
been   erroneously   rejected   by   the   impugned  order. The Appellate Authority, therefore, had 
no jurisdiction to decide the appeal preferred  by ESIL.
(ii)In support of the above contention, reliance is  placed upon the following judgments :
(i) Chhattisgarh   State   Electricity   Board   Vs.  Central   Electricity   Regulatory  
Commission  and others, reported in (2010) 5 SCC 23.
(ii) Draupadi Devi and others Vs. Union of India 
and others, reported in (2004) 11 SCC 425.
(iii)Kamlesh   Babu   and   others   Vs.   Lajpat   Rai 
Sharma and others, reported in (2008) 12 SCC 
577.
(iii)   Without   prejudice   to   the   above,   the   same 
Chief Electrical Inspector who was appointed on  the   Committee   by   the   State   Government  
has  passed the impugned order, which could not have  been   done   by   him.   There   is   total   lack
  of  jurisdiction   and   competence   in   the   Appellate  Authority,   namely,   the   Chief   Electrical 
Inspector.   For   the   above   reasons,   a   Writ   of  Certiorari would lie to quash and set aside the 
impugned order dated 01.11.2013.
(iv)There   is   a   clear   breach   of   the   Agreement  reached   vide   the   Minutes   of   Meeting  
dated  01.02.2010 by ESIL, entitling DGVCL to recover, 
in terms of the said Agreement, charges for the  period   during   which   the   second   Tie   Line  
was  connected to the grid, allowing power from the  grid  to go  to the other units of Essar Group 
which were not consumers of DGVCL. Pending any  decision   of   making   the   other   units   of  
Essar  Group consumers by revising the power boundary  without   intimation   or   permission,  
Essar   Group  connected   the   second   Tie   Line   to   the   grid   on  15.06.2011.   On   that   very  
day   they   wrote   a  letter   for   revising   the   power   boundary.   The 
other units of Essar Group were not consumers  of   DGVCL   and   only     ESIL   was   a   consumer. Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Therefore,   the   non−consumer   units   were   not  entitled to any power through the grid, whether 
the power was DGVCL power or Open Access power.  It was found by the Field Officer of DGVCL on 
01.07.2011, after scrutinizing MRI data of the  apex   meter   of   the   Tie   Line−2,   that   power  
had  been flowing from the GETCO grid to Tie Line−2 
from 17.00 hours on 15.06.2011. DGVCL addressed  a  letter   dated   26.07.2011   to  ESIL,  
indicating  that there was a clear breach of the Agreement  dated   01.02.2010,   entitling   DGVCL  
to   recover  charges   at   the   rate   of   twelve   times   the 
quantity found to have been utilized at twice  the   normal   rate   (HTP−1)   of   DGVCL,   as   per 
Condition No.2(2) of the Minutes of the Meeting  dated 01.02.2010. It is clearly recorded in the 
said Minutes of the Meeting that in case of any  power   is   found   recorded   in   the   meters   to   be 
placed on both the Tie Lines of Bhander Power  Limited,   the   power   would   be   treated   as  
DGVCL  power.   Accordingly,   a   supplementary   bill 
computed as per the above Agreement with effect  from   15.06.2011   to   30.07.2011,   amounting  
to  Rs.2311   Crores   approximately,   was   rightly  issued   to   ESIL   on   22.09.2011.   The   breach  
has  been   admitted   by   ESIL   in   its   letter   dated  26.09.2011   and   has   also   been   remedied 
thereafter.
(v) The   amalgamation   of   other   units   of   the   Essar  Group   which   were   not   consumers   of  
DGVCL   with  ESIL, which was a consumer, does not result in  all   the   merged   units   becoming  
consumers   of  DGVCL.   The   legal   entity,   even   after   becoming 
one, does not become one consumer as a consumer  has   no   relation   to   the   legal   entity,   but  
has  relation   to   the   premises.   Amalgamation   would 
not result in the premises of the merged units  becoming   the   same.   They   would   continue   to 
remain   separate   premises   with   a   different  connection and meter. Therefore, they cannot be 
construed as being a single consumer after the  merger. It is not a mere case of extension of  power  
boundary,   as   the   other   units   were   not  consumers   of   DGVCL.   Only   the   consumer   is 
entitled   for   the   extension   of   the   power  boundary. Unless they are consumers, the units 
are not entitled to receive power through Open  Access   utilizing   the   transmission   lines   of 
GETCO or the distribution line of DGVCL. Taking   the   Court   through   the   definitions   of 
"consumer",   "Distribution   Licencee",  "Franchisee",   "Licence",   "Licencee",   "supply", 
"transmission   lines"   etc.   as   given   under   the  Act as well as the provisions of Sections−39, 
40 and 42 thereof, it is further submitted by  the learned Senior Counsel that from the above 
provisions it is clear that only a consumer is  entitled   to   receive   power   from  a   Distribution 
Licencee like DGVCL, or even through the Open  Access   through   the   transmission   line   of 
GETCO/DGVCL. The erstwhile unit of ESIL, being  the   consumer,   was   only   entitled   to  
receive  power   not   only   from   DGVCL,   but   also   through  Open   Access,   subject   to   payment
  of   wheeling  charges.   The   other   units   of   the   Essar   Group  were   not   entitled   to   receive  
any   such   power  since they are not the consumers of DGVCL.  That,   in   spite   of   amalgamation,
  reverse   power  relay   was   placed   on   Tie   Line−1   in   July,   2010  and   was   tested   on  
10.07.2010,   which   clearly  shows   that   even   Essar   never   understood   that 
amalgamation would absolve them of laying down  the   reverse   power   relay   on   Tie   Line−1  
and  isolating   Tie   Line−2   from   the   grid   which   was  supplying   power   to   the   other   units  
of   Essar  Group.Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

In   support   of   the   above   submissions,   the   learned  Senior   Counsel   has   relied   upon   the  
judgment   in  the case of  Singer India Ltd. Vs. Chander Mohan 
Chadha, reported in (2004) 7 SCC 1.
(vi) The   present   is   a   clear   case   of   breach   of  Agreement  contained   in  the   Minutes   of 
Meeting  dated   01.02.2010   on   the   part   of   ESIL.   The  recovery   is   sought   in   terms   of   the
  said  Agreement,   therefore,   it   is   a   claim   in  contract. Such a claim is not prohibited under 
the   Electricity   Act,   2003,   as   there   is   no  provision   in   the   Act   indicating   that   such   a 
contract is void. The contract has been entered  into for consideration, which is the benefit of  non−
payment   of   wheeling   charges.   It   is   an  agreed   provision   under   the   contract   for 
liquidated   damages  between   the  parties   and  is  not a provision  in  terrorem. As the agreement 
reflects the intention of the parties and any  breach   of   the   agreement   would   invite   the 
consequences   agreed   upon,   which   is   penal  charges   at   the   rate   of   twelve   times   the 
quantity of power found to have been recorded  at twice the normal rate (HTP−1) of DGVCL. As  it  
is   a   case   of   breach   of   agreement,   the  provisions of Section−126 of the Act could not 
have been resorted to by ESIL.
In support of the above submission, reliance is  placed on the judgment in the case of  Oil and 
Natural Gas Corporation Limited Vs. Saw Pipes  Limited, reported in (2003) 5 SCC 705.
(vii) The   decision   of   the   Committee   of   the   State 
Government and the directives issued by it upon  DGVCL,   to   treat   the   proceedings   as   per  
the  provisions of Section−126 of the Act is only by  way   of   an   interim   arrangement   and   is   not
  a  binding   command   on   DGVCL.   This   is   clear   from  the   letter   dated   05.01.2012   of   the  
State  Government, which states that this arrangement  is   for   the   time   being,   till   the   case   of
  the  total   claim   is   settled.   This   means   that   the  bill   dated   22.09.2011   for   Rs.2311  
Crores  approximately, was not a provisional bill under  Section−126   of   the   Act   and   was   not  
issued   by  any   Assessing   Officer.   No   opportunity   of  hearing   was   given   by   the   Assessing  
Officer  after the issuance of the said bill. This would  further   mean   that   the   revised  
supplementary  bill dated 25.01.2012 is not a final order of  assessment   after   granting   an  
opportunity   of  hearing   to   Essar,   but   is   only   an   interim 
arrangement. All these above aspects have been  overlooked   by   the   Appellate   Authority   while 
passing   the   impugned   order.   Hence,   the   said  order deserves to be quashed and set aside.     
37. Opposing the contentions raised on behalf of the  petitioner,   Mihir   H.   Joshi,   learned   Senior
  Advocate  for respondent No.1−ESIL has submitted as below :
(i) That   the   appeal   preferred   by   DGVCL   against   the  revised   supplementary  
bills   is   maintainable  under Section−127 of the Act, as it is a case  of   unauthorized  
supply   of   electricity   beyond  the power boundary, which would fall under the 
provisions of Section−126 of the Act. It is not 
a mere dispute under the Minutes of the Meeting 
dated 01.02.2010, as what was prohibited in the  said   Minutes   was   the   supply   of
  power   to   an  entity which was not a consumer. On the facts Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

of the case, on account of the amalgamation of  the   units   of   the   Essar   Group,  
there   was   no  other   entity   or   consumer   except   ESIL.   The  Minutes   of   the  
Meeting   dated   01.02.2010,  recorded the decisions taken by the authorities  on   the
  issues   raised   therein.  There   is  sufficient indication in the Minutes of Meeting 
that   the   same   are   to   be   read   in   conjunction  with,   and   in   the   context   of,
  the   statutory  provisions and are not intended to supplant or  substitute   the  
provisions   of   Act.  It   is  mentioned in the Minutes that a solution is to 
be found "within the framework of regulations",  which   indicates   that   the  
Minutes   are   not  outside   the   framework   of   the   Act,   but   aim   at 
finding a solution within the scope and ambit  of the statute.
(ii) In any case, DGVCL is a Distribution Licencee  as contemplated under Part−
IV of the Act, read  with the provisions of the Gujarat Electricity  Regulatory  
Commission   (Distribution   Licence)  Regulation,   2005.   The   provisions   of   the  
Act  read   with   the   Regulations   mandate   that   its 
action must be in compliance of the provisions  of   the   Act.   It   is   impermissible  
for   DGVCL   to  contend that it seeks to exercise power under  the
 Minutes of Meeting,  dehors  the  provisions 
of the Act. DGVCL is "State" within the meaning  of Article−
12 of the Constitution of India. It  has to function under the statute, that is, the 
Electricity   Act,   2003,   and   the   regulations 
framed thereunder. It cannot claim to enforce a  contract that is  dehors 
the provisions of the  statute.   The   provisions   of   the 
statute/regulations would override all existing  contracts.   If   an   Agreement   is
 dehors  the  provisions of the Act, it cannot be enforced, 
except by filing a Civil Suit, which is barred 
under the provisions of the Act. Being "State" 
under Article−12 of the Constitution of India,  the action of DGVCL would have to be tested on  the  
touchstone   of   Article−14.   The   question  would   arise   whether   this   Court,   under   its 
equitable jurisdiction, would uphold the demand  of   DGVCL   much   beyond   the   statute,   which  
is  arbitrary, disproportionate and excessive. In support of this submission, reliance is placed  upon  
the   judgment   in  PTC   India   Limited   Vs.  Central   Electricity   Regulatory   Commission, 
Through   Secretary,  reported   in  (2010)   4   SCC 
603. 
(iii) Explanation−(b)   of   Section−126(6)   of   the   Act  defines   "unauthorized   use   of   electricity"
  and  the   event   of   default   contemplated   under   the 
Minutes of Meeting, namely flow of DGVCL power  through   the   220   KV   integrated   grid   to  
member  units of Bhander  Power  Limited,  is  considered  to   be   unauthorized   use   of   electricity
  and,  therefore, not outside the ambit of Section−126  of   the   Act.   The   disputes   would,  
therefore,  necessarily   have   to   be   determined   and  adjudicated under Sections−126  and 
127 of the  Act, particularly since the jurisdiction of the  Civil Court is barred under Section−Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

145 of the  Act.   The   substance   of   the   dispute,   namely,  whether   there   is   any   unauthorized  
use   of  electricity and the nature of the unauthorized  use,   can   only   be   adjudicated   under   the
  Act.  There is no other mechanism for adjudication of  such   a   dispute   for   unauthorized   use  
of  electricity   and   only   the   statutory   authority  can   determine   the   dispute.   The   Minutes  
of  Meeting   dated   01.02.2010,   in   no   way,   detract  from   this   premise   and   do   not   lay  
down   any  alternative   procedure   for   dispute   resolution.  DGVCL   has   all   along   accepted  
the   State  Government's   interpretation   that   the   dispute  should   be   resolved   under   Section−
126   of   the  Act.   Even   if   the   authority   would   hold   that  there   has   been   an   unauthorized  
use   of  electricity, until the same is contemplated in  the   meeting,   DGVCL   would   not   be  
entitled   to  claim penal rates under the Minutes but would  only   be   entitled   to   claim   an  
amount  contemplated  under  Section−126  of  the  Act.  In  any   event,   the   determination   of  
unauthorized  use   of   electricity   can   only   be   made   under  Sections−126   and   127   of   the  
Act   and   the  consequential   quantification   would   depend   on 
the nature of the unauthorized use for which no  separate   adjudication   would   be   necessary, 
assuming the legality of the penal rate under  the   Minutes.   DGVCL   is   estopped   from   raising 
such a contention as the State Government has  categorically directed that Section−126 applies 
to the facts of the case and such decision is  binding   upon   it.   DGVCL   has,   at   no   point   of 
time, objected to the  application  of  Section− 126 of the Act but has acquiesced in the same  by  
acting   upon   the   directions   of   the   State  Government   and   issuing   the   revised 
supplementary   bills   as   per   Section−126(6)   of  the Act, on 25.01.2012.
(iv) The   contention   of   DGVCL   that   the   procedure  under   Section−126   of   the   Act   has   not
  been  followed   is   misconceived,   since   a   provisional  assessment   was   proposed/made   upon
  ESIL   upon  inspection  of  its premises on 21.07.2011, and  by   the   issuance   of   a   Show   Cause
  Notice   dated  26.07.2011. Objections have been filed by ESIL 
to the same, vide letters dated 29.07.2011 and  08.09.2011 and a final decision has been taken  vide  
order   dated   22.09.2011,   by   issuing   two  revised supplementary bills upon ESIL. This, in 
substance, is the procedure contemplated under  Section−126 of the  Act. Therefore,  the appeal 
preferred by ESIL cannot be said to premature  or not competent.
(v) It is impermissible, unreasonable and inequitable 
for DGVCL to contend that the amount under the  supplementary   bills   is   recoverable   but   the 
remedy   of   appeal   is   not   available   to   the  consumer   and   that   too   on   the   premise   that 
DGVCL,   being   the   Distribution   Licencee,   has  itself not followed the procedure contemplated 
under the Act.
(vi) The   contention   of   DGVCL   that   the   revised  supplementary   bills   are   not   final   bills  
and,  therefore, the appeal under Section−127 of the 
Act is not competent, is without substance. The  revised  supplementary  bills  are  in  respect  of 
the entire quantity of electricity recorded in  the   meter   on   the   second   Tie   Line,   namely   for 
168.42 MU. On the question of unauthorized use  of   electricity   and   its   assessment,   ESIL 
submitted its objections and a final order has  been passed by DGVCL to the effect that there  has,  
in   fact,   been   unauthorized   use   of  electricity, as contemplated under the Minutes 
of Meeting. The decision/ order is final in the  manner contemplated under Section−126(3) of the Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Act.   An   appeal   is   provided   to   the   Appellate  Authority against such a final order, which has 
been   preferred   by   ESIL.   By   deposit   of   the  amount of the revised supplementary bills, the 
condition   of   pre−deposit   under   Section−127(2)  of   the   Act   has   been   complied   with   and  
the  appeal is clearly maintainable.
(vii) Responding   to   the   contention   regarding   the  appeal  being  beyond  the period  of
 limitation,  it   is   submitted   on   behalf   of   ESIL   that   in  Chhattisgarh   State   Electricity  
Board   Vs.  Central  Electricity  Regulatory  Commission  and  others   (Supra.),   relied   upon   by  
DGVCL,   the  Supreme   Court   was   dealing   with   a   case   under  Section−
125 of the Act. Section−125 of the Act  is couched in language different from that of  Section−127(1)  
of   the   Act.   The   language   of  Section−127(1) does not debar the applicability 
of the Limitation Act, as there are no words to  the effect that "no appeal shall be entertained  after  
the   period   of   thirty   days".   Under  Section−125 of the Act, the Limitation Act is  excluded   by  
necessary   implication   which   is  clear from the proviso,  whereas, the language  of Section−
127(1) does not debar the provisions  of   the   Limitation   Act.   The   judgment   cited   on  behalf   of
  DGVCL,   therefore,   cannot   be   made  applicable to the present case.
The   contention   regarding   limitation   was   not  raised before the Appellate Authority which had 
no occasion to deal with the same. Though it is  a   legal   question   and   if   DGVCL   really   had   a 
serious   objection,   it   would   definitely   have  raised   it   before   the   Appellate   Authority   and 
got a determination on this point as well. In support of the above contention, reliance is  placed  
upon   a   judgment   in  Mukri   Gopalan   Vs.  Cheppilat   Puthanpurayil   Aboobacker,  reported 
in (1995) 5 SCC 5.
(viii) Regarding the contention raised on behalf of  DGVCL   that   the   Chief   Electrical   Inspector, 
being a member of the Government Committee has  passed the impugned order, it is submitted that 
the   Committees   have   not   arrived   at   any  conclusions   on   merits   regarding   the 
unauthorized   use   of   electricity   without  extension  of  the  power  boundary, or regarding 
the issue of the merged units being consumers  of   DGVCL,   which   are   the     principal   issues 
involved.   This   objection   was   never   raised  before the Appellate Authority. Even otherwise,  no  
allegation   of   bias   or  malafides  has   been  made against the Appellate Authority. The Chief 
Electrical Inspector has been appointed as the  Appellate   Authority   by   virtue   of   a 
Notification, under the Rules. Malice has to be  specifically pleaded and proved, which has not  been
  done   by   DGVCL.   On   the   contrary,   DGVCL  participated   in   the   proceedings   before   the 
Appellate   Authority   without   raising   any  objections.   Hence,   this   contention   cannot   be 
permitted to stand.
(ix) In   support   of   this   submission,   reliance   has  been  placed upon  a judgment  in  State  
Bank   of  India   Vs.   Ram   Das   and   another,  reported   in  (2003) 12 SCC 474.
(x) The   Scheme   of   Amalgamation,   was   sanctioned   on  30.06.2010   and   became   effective  
with   effect  from 05.08.2010. The consequential legal effect 
would be that Essar Steel (Hazira) Limited, as  the   Transferor   entity,   stood   merged   with   the 
Transferee  entity,  namely  ESIL,  and ceased  to  have   any   legal   existence,   whatsoever. Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Therefore, on the date of the purported event  of default on 15.06.2011, there was no supply 
of DGVCL power to a member unit, since it had  ceased   to   exist   and   stood   merged   with   the 
consumer,   ESIL.   Consequently,   the   event   of  default, as contemplated  under  the  Minutes  of 
the Meeting dated 01.02.2010, cannot be said to  have occurred at all.
(xi) The   contention   that   the   electrical   energy  supplied to the premises of the erstwhile Essar 
Steel (Hariza) Limited, is to a  non−consumer,  thereby triggering the default clause under the 
Minutes, is misplaced and misconceived. In the  first   place,   the   event   of   default   under   the 
Minutes does not cover flowing of DGVCL power  to   ESIL,   but   to   member   units.   Secondly,  
the  erstwhile unit of ESIL has chosen to remain as 
ESIL and within the same complex. Thirdly, this  contention   is   completely   academic   and 
hypothetical   since   subsequently,   DGVCL   has  merely   extended   the   power   boundary   of  
ESIL  covering   the   area   of   the   erstwhile   unit   of  Essar   Steel   (Hazira)   Limited,   and   has  
not  granted   a   separate   connection   for   the   said  premises,   which   completely   belies   the 
contention   being   raised   by   DGVCL.   Therefore,  there   is   no   event   of   default   as  
contemplated  under the Minutes of Meeting.
(xii) In   support   of   the   above   contention,   reliance 
has been placed upon a judgment in the case of  Singer India Limited Vs. Chander Mohan Chadha 
and others, reported in (2004) 7 SCC 1.
(xiii)   DGVCL   is   estopped   from   contending   that   the 
default was anything other than a breach of the  power   boundary.   DGVCL   has   itself   treated  
the  extension   of   the   power   boundary   granted   by  letter   dated   17.04.2012,   as   the  
remedial  measure,   and   approved   the   very   action  undertaken   by   ESIL   on   15.06.2011,  
vide   its  letter   dated   14.05.2012.   The   State   Government  has   concluded   that   the   issue  
related   to   the  breach   of   the   power   boundary,   vide   Report   of 
the Committee dated 13.12.2011. The decision of  the State Government dated 05.01.2012, has been 
accepted by DGVCL vide letter dated 25.01.2012.  The only issue sought to be kept open by DGVCL 
was   in   relation   to   the   quantification   of   the  claim   and   not   the   event   of   default.   Once  
the  event   of   default   is   not   the   one   contemplated 
under the Minutes of  Meeting dated 01.02.2010,  the adjudication of the issue would undoubtedly 
have   to   be   under   the   provisions   of   the   Act,  without   prejudice   to   the   contention   of  
ESIL  that   the   Minutes   cannot   be   read  dehors  the  provisions   of   the   Act   and   even   a  
default  thereunder would have to be adjudicated as per  the provisions of the Act.
(xiv) The default is not the one contemplated under 
the Minutes of Meeting, therefore, DGVCL cannot  take   recourse   of   the   penal   rate   provided  
for  that   purpose   in   the   Minutes.   Even   if   the 
default is considered as one contemplated under  the   Minutes   of   the   Meeting   dated  
01.02.2010,  DGVCL is not entitled to levy any claim, penal  rate   stipulated   in   the   Minutes,   as  
the   Show  Cause Notice dated 26.07.2011 issued by DGVCL, 
expressly permits ESIL to restore the position  prevailing prior to 15.06.2011, failing which a 
quantum of power merged from the grid would be  charged   as   per   the   Minutes   of   the  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Meeting.  ESIL, having forthwith restored the position as  confirmed   by   letter   dated   30.07.2011,
  the  directions   of   DGVCL   stood   complied   with   and  there   being   no   fault   in   compliance,  
DGVCL   on  its   own   proceeded   to   levy   the   penal   rate  submitted in the meeting.
(xv) DGVCL,   by   its   own   inaction,   brought   about   a 
situation in which the respondent was compelled  to undertake the action of removing the reverse 
power relay, essentially to prevent tripping of  electrical   energy   and   consequential   damage   to 
its machinery, which action has not benefitted  ESIl   or   adversely   affected   DGVCL.   ESIL   had 
requested   DGVCL   to   remove   the   reverse   power  relay   in   view   of   subsequent  
developments,  inter−alia,   vide   letters   dated   21.05.2011   and  08.06.2011.   Even   GETCO   had  
directed   DGVCL   to  remove   the   power   flow   relay   on   04.06.2011,  which   was   not   followed
  up   or   acted   upon   by  DGVCL, which is bound to act in accordance with 
the directions of GETCO.
(xvi) That the findings and conclusions arrived at by 
the Appellate Authority in the impugned order,  have   not   been   demonstrated   to   be   converse, 
perverse   or   without   jurisdiction.   Cogent  reasons   have   been   given   by   the   Appellate 
Authority in support of the findings, except to  the extent that the findings that are against  ESIL.  
Hence,   to   the   extent   that   the   impugned  order   is   favourable   to   ESIL,   the   contentions 
raised by DGVCL deserve to be rejected and the  impugned order, to that extent, deserves to be 
confirmed.
38. Mr.S.N.Shelat,   learned   Senior   Advocate   has  appeared for respondent No.1−
ESIL in the main petition  and   has   supplemented   the   submissions   advanced   by 
Mr.Mihir H. Joshi, learned Senior Advocate. 
39. It   is   submitted   by   Mr.Shelat,   learned   Senior 
Advocate, that much reliance is placed by DGVCL upon  the   Minutes   of   Meeting   dated  
01.02.2010,   especially  Clause−2(2)   thereof.   This   clause   is   a   clause  in  terrorem,  inserted  
with   an   intention   to   deter   the  party from committing a breach. In such a situation, 
it is settled law that the Court has jurisdiction to 
determine what can be the penal amount. The Court has 
to find out the real purpose for which the stipulation  was   incorporated   in   the   contract.   By  
reason   of   it  being   burdensome   and   oppressive   in   character,   it  operates  in terrorem 
so as to drive the consumer to  fulfil the contract. 
40. In support of this contention, reliance is placed  upon the judgment in
 K.P.Subbarama Sastri and others  Vs. K.S.Raghavan and others,  reported in AIR 1987 SC  1257. 
41. The   representatives   of   DGVCL   and   ESIL,   in   the  presence   of   Expert   members,   have  
come   to   the  conclusion that the amount under the Agreement cannot 
be dehors the provisions of Section−126 of the Act and  that   DGVCL   should   charge   as   per   the  
computation  provided under the said provision of law. However, it 
is left open to DGVCL to get a final adjudication, if Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

so desired, from the Competent Authority. In view of  the above, the appeal under Section−
127 of the Act is  maintainable   and   DGVCL   has   been   rightly   directed   by 
the Appellate Authority to charge only for the energy  consumed.   After   the   issuance   of   the   bill
  for  Rs.2311,02,43,968/−   on   22.09.2011,   the   State  Government   intervened   and   a   meeting  
of   the  representatives   of   Essar   and   DGVCL   as   well   as 
Technical Expert was convened. The Committee clearly 
concluded that there was no theft of energy and full 
energy charges have been paid. It is not disputed by 
DGVCL that the State Government is competent to give  directions   to   determine   the   matter   as  
per   the  provisions   of   Section−126   of   the   Act.   The   State 
Government has taken a decision on the recommendations 
of the Committee and DGVCL has accepted the decision 
and charged penalty as per the provisions of Section−
126(6) of the Act. It was kept open for DGVCL to get 
the final adjudication as regards the penalty from the 
Competent Authority, but so far it has not invoked any 
provisions of the Act nor instituted any suit, as on 
date. In view of the above, ESIL is justified in law 
in approaching the Appellate Authority under Section− 127 of the Act.
SUBMISSIONS   IN   SCA   No.5494/2014   (Cross− petition):
42. Insofar   as   the   cross−petition   (Special   Civil 
Application No.5494/2014) is concerned, the petitioner  in   this   petition   is   ESIL,   which   has  
challenged   the  order of the Appellate Authority dated 01.11.2013, to 
the extent that it holds that ESIL has unauthorizedly  used   25.23   MU   of   power   and   is   liable  
to   pay   penal  charges   for  the   said  quantity  of  power,   as   provided  under Section−
126 of the Act. 
43. It   is   submitted   by   Mr.Mihir   H.   Joshi,   learned 
Senior Advocate for ESIL that there is no unauthorized 
use of power by ESIL, as the units have merged after 
the order of amalgamation. Even if it is assumed that 
there is an unauthorized use of power, it can be said  that   only   6.63   MU,   which   has   gone   into
  the   merged  units can be stated to be unauthorized. The order of 
the Appellate Authority, to this extent, is required  to   be   interfered   with.   Mr.Mihir   Thakore,  
learned  Senior   Advocate   for   DGVCL   has   maintained   the   same 
stand as adopted by him in the lead matter.
SCA No.5621/2014 :
44. Special   Civil   Application   No.5621/2014   is 
essentially preferred for the amount of refund given 
to the petitioner by the order dated 01.11.2013 passed Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

by the Competent Authority with a view to see that no  coercive  action   be   taken   against  it  in
 matters   that  are   not   specifically   related   to   the   controversy 
involved in the main petition and the cross−petition.  The   fate   of   this   petition   would,  
therefore,   depend  upon   the   decision   in   the   other   two   petitions.   The  submissions   on  
behalf   of   the   learned   Senior   Counsel  for the respective parties are also to this effect. 
EVALUATION OF RIVAL SUBMISSIONS : 
Maintainability of the appeal :
This Court has heard learned Senior Counsel for  the   respective   parties   at   length  
and   examined   the  material on record. 
45. In the above factual and legal background, this 
Court would now proceed to deal with the submissions  advanced by the rival parties.
46. It   has   been   strenuously   urged   by   Mr.Mihir   J.  Thakore,   learned   Senior   Advocate   on  
behalf   of   the  petitioner−DGVCL in the lead matter, that the appeal 
preferred by Essar against the revised supplementary  bills   dated   25.01.2012,   amounting   to 
Rs.192,58,53,664/−,   is   not   competent   or   maintainable  under Sections−
126 and 127 of the Act, for the reason  that   the   revised   supplementary   bills   were   issued   on 
the   directive   of   the  State  Government   and  not   after 
following the procedure envisaged under Section−126 of 
the Act. It has further been contended that the said 
bills cannot be construed to be the result of a final 
order of assessment made by an Assessing officer under  Section−126   of   the   Act,   therefore,   no  
appeal   under  Section−127   of   the   Act   would   lie.   It   is   further  contended   that   even  
assuming   that   the   appeal   is  maintainable,   it   could   not   have   been   entertained   by 
the Appellate Authority, as it has been filed beyond  the prescribed period of limitation.
47. On   the   other   hand,   Mr.Mihir   H.   Joshi,   learned  Senior   Advocate   for   Essar   has  
submitted   that   the  dispute   pertains   to   the   unauthorized   supply   of 
electricity beyond the power boundary and any dispute  regarding   unauthorized   use   of  
electricity,   that   is,  utilization   of   electricity   outside   the   authorized  area,   would   fall   within
  the   ambit   and   scope   of  Section−126   of   the   Act.   Therefore,   the   appeal   under  Section−
127 of the Act is competent and maintainable. 
It is further contended on behalf of ESIL that DGVCL 
has itself issued the revised supplementary bills on  the basis of Section−
126 of the Act, without raising  any objections, whatsoever. Having done so, it cannot 
now contend that no appeal would lie against their own  action, taken under Section−
126 of the statute. 
48. To   examine   the   rival   contentions,   it   would   be  pertinent   to   refer   to   the   Minutes   of  
Meeting   dated  01.02.2010,   the   factual   background,   prevailing Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

situation and surrounding circumstances, within which  the   Minutes   have   been   drawn.   From  
the   material   on  record,   it   is   evident   that   the   Minutes   were  necessitated   on   account   of  
pending   disputes,   the  principal   one   being   the  claim  of  GETCO  for   wheeling  charges. 
49. The   first   issue   in   dispute,   as   recorded   in   the 
Minutes of Meeting dated 01.02.2010, is as under :
"Essar   represented   that   they   wanted   to   resolve 
the issue of wheeling of power through the 220 KV  integrated   network   from  
Bhander   Power   to   Essar   Steel   Limited   with   an   alternative   route   of  
shifting   of   line,   so   that   grid   connectivity   of   GETCO   becomes   isolated   and  
radial   from   Essar   Steel and Bhander Power Ltd. thereby GETCO power  
flow is direct from Ichhpore to Sachin."
This   was   proposed   by   Essar,   to   avoid   wheeling  charges.   After   detailed   discussion,   it  
was   decided  that Essar would give an undertaking to GETCO for the  payment   of   transmission  
charges   as   per   the   final  decision   by   a   Court   of   law   in   the   matter.   It   was 
further decided that GETCO would approve the shifting 
of the Ichchhapor line so that the power would flow  one side of the Bus−
Bar for resolution of the wheeling  issue   and   the   cost   of   shifting   and   the   equipments 
proposed   to   be   installed,   would   be   borne   by   Essar. 
Essar would also give an undertaking for handing over 
the property to GETCO. The decision on the issue of 
shifting of the line, taken in the Minutes of Meeting,  is as follows :
"Without   prejudice   to   the   outcome   of   the   case 
with regard to Transmission Charges pending with  
any judicial authority pertaining to this matter,  Essar,  immediately  upon  signing  
of  this  Minutes  of Meeting will apply for necessary approval to  
GERC on the basis of this Minutes of Meeting and   GUVNL   &   GETCO   will  
support   shifting   of   line  before   GERC   as   permanent   resolution   so   that  
wheeling will not be payable thereafter from the   date   of   actual   completion   of  
the   shifting   of   lines subject to final approval of GERC."
50. The   second   issue   in   dispute   discussed   in   the 
Minutes of Meeting, was regarding the supply of power 
to group companies. Regarding this issue, it is stated  in the Minutes of Meeting as below :
"As   the   issue   is   pending   for   long   time,   the   Principal   Secretary,   Energy  
and   Petrochemicals   Department   suggested   to   arrive   at   amicable  
solution within the frame work of regulation."
51. After   resolving   that   the   Chief   Electrical 
Inspector would approve the electrical drawings to all Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

member units of Essar, it was agreed in Clause−2 of  the Minutes of Meeting as under :
"2. In the second phase all member units want to  
avail Bhander Power. GUVNL and GETCO stated that   all   units   have   to   become  
DGVCL   consumers   or  alternatively all 220 KV and 33 KV connectivity   to   units  
shall   run   in   isolation   of   220   KV  
integrated grid and DGVCL connection of Contract   Demand.  Essar   proposed 
reverse  power  flow  relay  so that at no point of time DGVCL power through  
220 KV integrated grid will flow to member units.   Detailed   modalities   for  
operation   of   Reverse  Power   Relay   and   related   issues   were   discussed   and  
agreed   upon.   GETCO   and   DGVCL   shall   have   a  
discussion with the supplier for sealing, locking 
location and the scheme of operation of reverse   power   relay   arrangement.   Essar  
agreed   for   the   same."
52. In the context of preventing power from flowing 
through the 220 KV integrated grid to member units of 
Essar, which were not the consumers of DGVCL, and as a  penal measure, the following Clause−
2.2 was inserted :
"In   case   any   power   flow/unit   (KwH)   is   found  
recorded in the meters to be placed on both the   tie   lines   of   Bhander   Power   Ltd.
  the   power   consumed will be treated as DGVCL power and the   power   imported  
from   the   grid,   same   will   be   charged at the rate of 12 times quantity found to 
have been utilized at twice the normal rate (HTP−
1) of DGVCL. For this power will be metered at   tie−line."
53. The second issue, therefore, was that of shifting 
of lines and supply of power to Group companies. The  Minutes   of   the   Meeting   are   clear   that  
an   amicable  solution   is   arrived   at  within   the   framework   of  regulations, 
meaning thereby, not  dehors  the statute  and regulations. The penal clause has been inserted in 
the event a default is committed by Essar, if it is  found   that   power   is   flowing   through   the  
220   KV  integrated grid to its non−consumer member units. In  such   an   eventuality,   the   power
  consumed   would   be  treated as DGVCL power, for all intents and purposes.  The   event   of  
default,   therefore,   was   in   respect   of  consumption of power by a member unit, which was not a 
consumer  of  DGVCL.   The   issue   was  thus   discussed  and 
resolved in the Minutes of Meeting dated 01.02.2010. 
54. What constitutes unauthorized use of electricity  can   be   guaged   from   the   provisions   of  
Section−126   of  the Act, which are reproduced hereinbelow :
"126.   Assessment  -   (1)   If   on   an   inspection   of  
any place or premises or after inspection of the   equipments,   gadgets,   machines,  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

devices   found   connected or used, or after inspection of records  maintained  by 
any  person,   the  assessing  officer  comes   to   the   conclusion   that   such   person  
is   indulging in unauthorized use of electricity, he   shall   provisionally   assess   to  
the   best   of   his   judgment the electricity charges payable by such  
person or by any other person benefited by such   use. 
(2) The order of provisional assessment shall be   served   upon   the   person   in  
occupation   or   possession or in charge of the place or premises  
in such manner as may be prescribed.
(3) The person, on whom an order has been served   under sub−
section (2), shall be entitled to file   objections,   if   any,   against   the   provisional  
assessment   before   the   assessing   officer,   who  shall,   after   affording   a  
reasonable   opportunity   of hearing to such person, pass a final order of   assessment
  within   thirty   days   from   the   date   of  
service of such order of provisional assessment,   of   the   electricity   charges  
payable   by   such   person.
(4) Any   person   served   with   the   order   of   provisional   assessment   may,  
accept   such   assessment  and  deposit  the  assessed  amount  with 
the licensee within seven days of service of such 
provisional assessment order upon him. (5) If   the   assessing   officer   reaches   to  
the   conclusion   that   unauthorized   use   of   electricity  
has taken place, the assessment shall be made for 
the entire period during which such unauthorized   use   of   electricity   has   taken  
place   and   if,   however,   the   period   during   which   such   unauthorized  use   of 
electricity   has  taken  place  cannot   be   ascertained,   such   period   shall   be  
limited to a period of twelve months immediately   preceding the date of inspection.
(6) The assessment  under this section  shall be   made   at   a   rate   equal   to   [twice]
  the   tariff   applicable for the relevant category of services   specified in sub−
section (5).
Explanation - For the purpose of this section,−
(a) "assessing   officer"   means   an   officer   of   a   State   Government   or   Board  
or   licensee,   as   the   case   may   be,   designated   as   such   by   the   State  
Government;
(b) "unauthorised use of electricity" means the   usage of electricity −
(i) by any artificial means; or
(ii) by a  means not authorized by  the concerned   person or authority or licensee; orEssar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

(iii) through a tampered meter; or
(iv) for   the   purpose   other   than   for   which   the 
usage of electricity was authorized; or
(v) for the premises or areas other than those   for   which   the   supply   of   electricity
  was   authorized."               (emphasis supplied)
55. Viewed in the context of the above definition of  unauthorized   use   of   electricity   as   clarified  
in   the  explanation  to  Section−126,   it   can   be   said   that  the  event   of   default   contemplated  
under   the   Minutes   of  Meeting,   namely   flow   of   DGVCL   power   through   the  integrated  
grid   to   a   non−consumer   member   unit   of  Bhander   Power   Limited,   is   to   be   considered  
as   an  unauthorized   use   of   electricity;   especially   as   it  pertains   to   premises   or   areas  
other   than   those   for  which   the   supply   of   electricity   was   authorized  [Explanation−(b)(v)].  
This   unauthorized   use   of  electricity   would,   therefore,   fall   within   the   scope 
and ambit of Section−126 of the Act.
56. DGVCL is a Distribution Licencee as contemplated  under   Part−IV   of   the   Act,   read   with  
the   Gujarat  Electricity   Regulatory   Commission   (Distribution  Licence)   Regulations,   2005,  
including   Regulation−32.  It,   therefore,   necessarily   functions   under,   and   in  accordance  
with,   the   provisions   of   the   Act   and   the  Regulations   in   vogue.   All   actions   of   DGVCL,  
as   a  Distribution   Licencee,   would,   therefore,   necessarily 
be governed by the provisions of the statute and the  regulations.   If   any   action  is  to  be  taken
 regarding  unauthorized   use   of   electricity,   it   is   bound   to   be 
taken within the ambit and scope of the statute and  not  dehors  thereof.   The   Minutes   of  
Meeting   dated  01.02.2010 have to be viewed in the context in which  they   were   drawn,   which  
has   already   been   discussed  earlier.   Clause−2.2,   which   can   be   stated   to   be   the 
penal clause in the Minutes, cannot be resorted to  as 
it is, dehors the provisions of the statute by DGVCL.  In   this   context   it   is   necessary   to   take  
into  consideration   subsequent   events,   namely,   the 
directions of the State Government to treat the matter  as per the provisions of sub−
section (6) of Section− 126   and   the   action   of   DGVCL   itself,   in   issuing   the  revised  
supplementary   bills   as   per   the   formula  contained   in   Section−126(6),   without   any  
objection,  protest or murmur.
57. Another   significant   event   that   occurred 
subsequent to the Minutes of Meeting dated 01.02.2010,  was   the   sanctioning   of   the   Scheme  
of   Amalgamation  between   Essar   Steel   Limited,   Essar   Steel   (Hazira)  Limited,   Hazira   Plate
  Limited,   Hazira   Pipe   Mill  Limited   and  Essar  Steel  Orissa   Limited,   by   the   High 
Court, vide order dated 30.06.2010. Essar addressed a 
letter dated 21.05.2011 to GETCO, recording that the 
Scheme of Amalgamation had been sanctioned and become  effective   from   05.08.2010,  
therefore,   the  units/companies   covered   under   the   Scheme,   having 
merged into ESIL, an existing consumer of DGVCL, the Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

contract demand of ESIL would automatically cover the 
supply of power to the units of the merged entities  and   the   reverse   power   flow  relay  should  
be   removed.  Vide letter dated 04.06.2011, GETCO informed ESIL that 
the details of the amalgamation should be submitted to  DGVCL   for   confirmation   and   after  
verification   and  personal   inspection   at   the   site,   the   reverse   power 
flow could be removed. On the same day, GETCO directed  DGVCL   to   take   steps   for   the  
removal   of   the   reverse  power   flow   relay.   Thereafter,   on   08.06.2011,   ESIL  addressed   a  
letter   to   DGVCL   for   the   removal   of   the  reverse   power   flow   relay   as,   according  to  it,  
there  was   a   problem   of   frequent   line   tripping   and   low  utilization   of   the   additional  
power   of   200   MW  purchased   from   GUVNL,  vide  an   Agreement   dated 
13.05.2011 under open access.
58. It   is   an   admitted   fact   that   with   effect   from  15.06.2011,   the   reverse   power   flow  
relay   system   was  unilaterally removed by Essar. A notice was issued by 
DGVCL to ESIL, to the effect that there was a breach  of  condition   No.2.2   of   the  Minutes   of  
Meeting   dated  01.02.2010   and   it   was   proposed   that   an   amount 
calculated at twelve times the quantity of power found 
to have been utilized, at twice the normal rate   of  DGVCL,   should   be   recovered   unless   the  
position  prevailing   before   15.06.2011   was   restored.   Essar  replied   by   letter   dated  
29.07.2011,   agreeing   to  restore the original position prior to 15.06.2011. In  the   meanwhile,   it  
had   also   requested   that   the  application   for   extension   of   the   power   boundary, 
already made by it, be expedited.
59. Pursuant   to   the   notice   of   DGVCL,   a   bill   dated  22.09.2011   was   issued   by   DGVCL  
for   an   amount   of  Rs.2311,02,43,968/−   for   202,09,92,000   units,  calculating   energy  
charges   as   per   the   Minutes   of  Meeting dated 01.02.2010. Pursuant to representations  made  
by   Essar   to   several   authorities,   the   State 
Government constituted a Committee consisting of three 
members, to examine the entire issue, having regard to  the   provisions   of   law,   Minutes   of  
Meeting   and   the  effect of the amalgamation order and to suggest a fair 
resolution of the issue. The Committee held, vide its  report   dated   13.12.2011,   that  there  was   no
  theft   of  energy but a unilateral action had been taken by Essar 
to overrule the restrictions and that the whole matter 
of the supplementary bill rested on the fact of the  use   of  unauthorized   power   outside   the  
approved  boundary of Essar Steel India Limited, on the date of  detection   by   DGVCL   and   as  
per   the   Minutes   of   the  Meeting dated 01.02.2010.
60. On   05.01.2012,   the   State   Government   wrote   a  letter   to   DGVCL,   concluding   that  
upon   careful  examination   of   the   findings   and   conclusions   of   the  Committee,   it   was  
found   that   there   was   no   theft   of  electricity   and   full   energy   was   accounted   and   paid 
for.   It   was   further   stated   that   the   provisions   of  Section−126(6)   of   the   Electricity   Act,  
2003,   would  have to be examined. DGVCL was directed to apply the 
said provisions and charge penalty at a rate equal to 
twice the tariff for the electricity consumed, for the  time   being,   till   the   case   of   the   total  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

claim   was  settled.
61. Accordingly,   on   25.01.2012,   pursuant   to   the  aforesaid   letter,   DGVCL   issued   two  
revised  supplementary bills for a total amount of Rs.192,58,  53,664/−
, worked out as per the formula contained in  sub−section (6) of Section−126 of the Act, till the 
total claim was finally satisfied.
62. From the above action of DGVCL, it is amply clear  that   the   action   of   the   issuance   of   the  
revised  supplementary bills has been consciously taken under  the   provisions   of   Section−126   of
  the   Act,   for   the  unauthorized use of electricity by Essar, outside the 
power boundary. Before, or while, issuing the revised  supplementary   bills,   DGVCL   did   not  
raise   any  objections or register any protest. Having issued the  revised   supplementary   bills  
under   the   provisions   of  Section−126 of the Act, for an admitted, unauthorized  use   of  
electricity   outside   the   power   boundary,   and 
having made the assessment at a rate equal to twice  the   tariff   applicable   as   per   the  provisions
  of   sub− section   (6)   of   Section−126   of   the   Act,   in   the 
considered view of this Court, it does not now lie in  the   mouth   of   DGVCL   to   state   that   the  
provisions   of  Section−126 are not applicable and the assessment as  per Sub−
section (6) of Section−126 is not correct or  final.
63. It may be noted that the provisions of Section− 145   of   the   Act,   bar   the   jurisdiction   of   the
  Civil  Court. The said section is reproduced hereinbelow :
"145.Civil   Court   not  to   have  jurisdiction  -  No 
civil court shall have jurisdiction to entertain  
any suit or proceeding in respect of any matter  
which an assessing officer referred to in section  126   or   an   appellate   authority  
referred   to   in   section 127 or the adjudicating officer appointed 
under this Act is empowered by or under this Act  
to determine and no injunction shall be granted  
by any court or other authority in respect of any 
action taken or to be taken in pursuance of any  
power conferred by or under this Act."
There   is   no   remedy   available   to   the   consumer  against   any   action   for   the   unauthorized  
use   of  electricity   under   Section−126,   except   to   prefer  an appeal under Section−127 of the Act.
64. DGVCL cannot be permitted to blow hot and cold at 
the same time. On one hand, it claims that the dispute  between   it   and   Essar   pertains   to   a  
breach   of   the  agreement arrived at in the Minutes of Meeting and on  the   other   hand   it   has  
itself   issued   the   revised  supplementary bills on the basis of Section−126 of the 
Act. If, as submitted on behalf of DGVCL, the default 
of Essar lies in a breach of contract, then the remedy  would   be   to   file   a   Civil   suit,   which   is  
not  permissible   under   the   Act.   DGVCL   is   a   Distribution Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Licencee, governed in all respects, by the provisions  of   the   statute.   It   cannot   seek   to   enforce  
a   remedy  which is dehors the statute when it is found suitable 
for it, while taking action under the Act, at the same 
time. This amounts to approbation and reprobation in  one   breath   and   such   double   standards  
are   not  permissible in law. 
65. There is no ambiguity regarding the fact that the 
substance of the dispute pertains to the unauthorized 
use of electricity. A dispute of this nature can only 
be adjudicated under the Act. At the best, the case of  DGVCL   can   only   be   that   such  
authorized   use   is  contemplated under the Minutes of Meeting and in the 
event of default, it is entitled to levy penalty as 
decided in the Minutes. Even if it is taken that DGVCL 
is entitled to claim any amount, the manner in which 
such amount is to be worked out would depend upon a  finding   rendered   by   the   Competent  
Authority,   after  considering   the   nature   of   the   unauthorized   use   of  electricity.   If   a
 finding   is   rendered   to   the  effect  that there was an unauthorized use of electricity, the 
assessment can only be made under Section−126 of the 
Act, which is the relevant (and only) provision of law 
in this regard. By submitting that no appeal under the  provisions   of   Sections−126   and   127   of  
the   Act   is  competent,   after   issuing   revised   supplementary   bills  under   Section−126,   itself,  
DGVCL   is,   in   effect,  attempting to obliterate the right of the consumer in  taking   recourse   to   a
  statutory   legal   remedy   which,  incidentally,   is   the   only   remedy   available   to   it. 
DGVCL has not enlightened this Court as to what other  remedy   the   consumer   could   have  
availed   of,   in   the  above   circumstances.   It   cannot   be   expected   that   the  Distribution  
Licencee   will   take   a   stand   that   the  consumer has to submit to its dictates and not avail  of   a  
remedy   in   accordance   with   law.   In   the   view   of  this   Court,   such   a   stand   on   the   part  
of   DGVCL   is  impermissible.
66. The fact remains that DGVCL has acquiesced to the  directives   of   the   State   Government   to  
treat   the  dispute as one under Section−126 of the Act, without a 
whisper of protest. Not only that, it has issued the  revised   supplementary   bills   as   per   the  
formula   of  assessment contained in sub−section (6) of Section−126  of   the   Act.   Having  
acquiesced   in   this   manner,   it  cannot   now   be   permitted   to   take   a   stand   that   the 
provisions   of   Section−126   are   not   applicable, 
especially as DGVCL has failed to satisfy this Court  to the contrary.
 
67. In   this   context,   reference   may   be   made   to   a 
judgment of the Supreme Court in (M/s.) Power Control  Appliances   and   others   Vs.   (M/s.)  
Sumeet   Machines  Private   Limited,  reported   in  1994   (2)   GLH   557, 
relevant extract whereof is reproduced as under: Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

"29. Acquiescence is sitting by, when another is  
invading the rights and spending money on it. It   is   a   course   of   conduct  
inconsistent   with   the   claim for exclusive rights in a trade mark, trade  name, etc.
 It implies positive acts; not merely   silence   or   inaction   such   as   is   involved   in  
laches.  In   Harcourt   v.   White   (28   Beav   303)   Sr.  
John Romily said: "It is important to distinguish  more   negligence   and  
acquiescence."   Therefore,   acquiescence   is   one   facet   of   delay.   If   the   plaintiff
  stood   by   knowingly   and   let   the  defendants build up an important trade until it
  had   become   necessary   to   crush   it,   then   the   plaintiffs   would   be   stopped  
by   their   acquiescence".   If   the   acquiescence   in   the   infringement   amounts   to
  consent,   it   will   be   a   complete defence as was laid down in Mouson & Co.  v.  
Boehm   (1884)   26   Ch   D   406.  The   acquiescence  must   be   such   as   to   lead  
to   the   inference   of   a   licence sufficient to create a new right in the  
defendant as was laid down in Rodgers v. Nowill   (1847)   2   De   GM   &   G   614:  
22   LJ   K   Ch   404." 
(emphasis supplied)
68. The   principles   of   law   enunciated   in   the   above 
judgment squarely apply to the present case, as DGVCL 
has knowingly issued the revised supplementary bills  under  the   provisions  of  Section−126  of  the
  Act   with  full   consent.   This   amounts   to   a   positive   act   by   it 
which cannot be repudiated later.
69. It has been submitted on behalf of DGVCL that the  provisions   of   Section−126   of   the   Act  
have   not   been  followed   while   issuing   the   revised   supplementary 
bills, inasmuch as there was no provisional assessment 
and no final order has been passed. This submission is  not   found   to   be   particularly  
convincing.   It   is   the  spirit   of   the   provisions   of   law   that   has   to   be  followed   and   not  
only   the   letter.   Here,   there   is   a  substantial compliance with both the letter and spirit 
of Section−126 of the Act. The premises of ESIL were  inspected   on   21.07.2011  and   a  Show  
Cause   Notice  was  issued   on   26.07.2011   by   DGVCL,   to   which   objections 
were filed by ESIL, vide letters dated 29.07.2011 and  08.09.2011.   A   final   decision   was   taken  
on   the  objections vide order dated 22.09.2011, which was for 
the issuance of the two revised supplementary bills. 
The said bills are in respect of the entire quantity 
of energy recorded in the meters on the second Tie− LIne   for   168.42   MV.   Moreover,   the  
revised  supplementary bills have been issued on the ground of  unauthorized   use   of   electricity,  
as   contemplated   in  the Minutes of Meeting. This order can be considered  to   be   a   final   order  
as   contemplated   under   Section− 126(3)   of   the   Act.   An   appeal   is   provided   to   the 
Appellate Authority under such a final order. ESIL has  deposited   the   amount   of   the   revised  
supplementary  bills, therefore, the condition of pre−deposit under  Section−
127(2) of the Act has also been complied with. 
The claim of DGVCL for Rs.2311 Crores approximately,  stood   revised   to   Rs.192.58   Crores,   by  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

the   revised  supplementary bills, which is a final claim under the  Act   for   all   intents   and  
purposes.   Taking   into  consideration all the above aspects, the findings of  the   Appellate  
Authority   in   the   impugned   order,   that  the   appeal   is   competent,   cannot   be   faulted   by  
this  Court.
70. Coming   to   the   issue   of   limitation,   it   may   be 
noted that this issue was not at all raised by DGVCL 
before the Appellate Authority. Before this Court, it 
has been argued that the issue of limitation, being a  legal   issue,   can   be   raised   at   any   stage.  
Learned  Senior   Advocate   for   DGVCL   has   relied   upon  Draupadi  Devi   and   others   Vs.  
Union   of   India   and   others  (Supra.) and Kamlesh Babu and others Vs. Lajpat Rai  Sharma   and  
others   (Supra.),  in   support   of   this  contention. However, these two judgments do not appear 
to be relevant in the facts and circumstances of the 
present case, especially taking into consideration the  language of Section−127(1) of the Act. 
71. The   specific   contention   of   the   learned   Senior  Advocate   for   DGVCL   is   that   even  
assuming   that   the  appeal is maintainable, it was filed much beyond the 
prescribed period of limitation. Reliance is placed on  a   judgment   in  Chhattisgarh   State  
Electricity   Board  Vs.   Central   Electricity   Regulatory   Commission   and  others   (Supra.).  This  
judgment   pertains   to   Section− 125   of   the   Electricity   Act,   2003,   particularly   the 
proviso thereto. The language of Section−125 (proviso)  is   totally   different   from   the   language  
of   Section− 127(1). The proviso to Section−125 makes it clear that 
in no event can the period of limitation be extended 
beyond sixty days. This is not so, insofar as Section− 127(1)   is   concerned.   In   Section−125,   by  
necessary  implication, the provisions of the Limitation Act have 
been excluded but the same does not appear to be the  position under Section−
127(1) of the Act. The judgment  in  Chhattisgarh   State   Electricity   Board   Vs.   Central  Electricity
  Regulatory   Commission   and   others  (Supra.),  would, therefore, not be applicable to the 
facts of the present case.
72. On   the   other   hand,   Mr.Mihir   H.   Joshi,   learned 
Senior Advocate for Essar has relied upon the judgment  of the Supreme Court in  Mukri  Gopalan
 Vs.  Cheppilat  Puthanpurayil Aboobacker (Supra.), wherein it is held  as below : 
"8. ***** When the aforesaid well settled tests  
for deciding whether an authority is a court or   not   are   applied   to   the   powers  
and   functions   of   the appellate authority constituted under Section  
18 of the Rent Act, it becomes obvious that all   the   aforesaid   essential   trappings  
to   constitute   such   an   authority   as   a   court   are   found   to   be  
present. In fact, Mr.Nariman, learned counsel for  respondent   also   fairly   stated  
that   these   appellate  authorities  would  be  courts  and  would 
not be persona designata. But in his submission   as   they   are   not   civil   courts  
constituted   and   functioning   under   the   Civil   Procedure   Code   as  
such, they are outside the sweep of Section 29(2)  of   the   Limitation   Act.   It   is,  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

therefore,  necessary   for   us   to   turn   to   the   aforesaid  provision   of   the  
Limitation   Act.   It   reads   as   under :
"S.29(2)   Where   any   special   or   local   law   prescribes   for   any   suit,   appeal   or
  application a period of limitation different  
from the period prescribed by the Schedule,   the provisions of Section 
3 shall apply as   if such period were the period prescribed by   the   Schedule   and  
for   the   purpose   of   determining   any   period   of   limitation   prescribed   for  
any   suit,   appeal   or   application by any special or local law, the   provisions  
contained   in   Sections   4   to   24  (inclusive) shall apply only insofar as, and   to  
the   extent   to   which,   they   are   not   expressly excluded by such special or local  
law."
A mere look at the aforesaid provision shows for   its   applicability   to   the   facts   of   a   given   case
  and for importing the machinery of the provisions 
containing Sections 4 to 24 of the Limitation Act  the   following   two   requirements   have   to   be  
satisfied   by   the   authority   invoking   the   said   provision.
(i) There must be a provision for period of  limitation under any special or local law in   connection  
with   any   suit,   appeal   or  application.
(ii)   The   said   prescription   of   period   of   limitation   under   such   special   or   local   law  
should   be   different   from   the   period  prescribed by the schedule to the Limitation   Act.
9.   If   the   aforesaid   two   requirements   are  satisfied   the   consequences   contemplated   by  
Section   29(2)   would   automatically   follow.   These   consequences are as under :
(i)   In   such   a   case   Section   3   of   the  
Limitation Act would apply as if t6he period   prescribed by  the special  or local 
law was   the period prescribed by the schedule.
(ii) For determining any period of limitation  
prescribed by such special or local law for a   suit,   appeal   or   application   all   the  
provisions   containing   Sections   4   to   24  
(inclusive) would apply insofar as and to the   extent   to   which   they   are   not  
expressly   excluded by such special or local law."
73. By entertaining the appeal preferred by Essar and 
deciding it, the Appellate Authority has, in effect, 
condoned the delay, which aspect was never objected to 
by DGVCL at any point of time during the hearing of  the   appeal.   The   objection   regarding  
limitation   was  available   to   DGVCL,   but   was   abandoned   before   the  Appellate   Authority.  
Hence,   this   objection     at   this  stage, does not merit acceptance. This is especially  so,   as   no  
convincing   legal   arguments   have   been  advanced on behalf of DGVCL to persuade this Court to Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

conclude   that   the   provisions   of   the   Limitation   Act  would not apply to Section−
127(1) of the Act.
Chief Electrical Inspector as Appellate Authority :
74. It has been argued on behalf of the petitioner− DGVCL   that   the   Chief   Electrical   Inspector  
who   was  appointed by the State Government on the Committees as  a   member,   has   passed   the
  impugned   order.   The  submission   is   that   having   been   a   member   of   the 
Committees, he could not have acted as the Appellate 
Authority, therefore, a Writ of Certiorari would lie  to   quash   and   set   aside   the   impugned  
order,   on   this  ground. 
75. It may be noted that DGVCL was very much aware of 
this aspect of the matter when the Appellate Authority  was   hearing   the   appeal   preferred   by  
Essar.   However,  DGVCL did not consider it appropriate or necessary to  raise   this   objection  
before   the   Appellate   Authority  but   actively   participated   in   the   proceedings.   The 
issue involved in the appeal preferred by Essar before 
the Appellate Authority was the revised supplementary  bills issued by DGVCL under Section−
12(6) of the Act.  None of the committees formed by the State Government,  at   any   point   of   time,
  has   adjudicated   upon   this  aspect; obviously, because   the issue had not arisen 
at the relevant point of time when the Committees made 
their reports. Though the Committee, vide its  Report 
dated 13.12.2011, did take the view that the matter of  supplementary   bills   rested   on   the   fact   of
  the  unauthorized   use   of   power   outside   the   approved  boundary,
 it did not enter into any adjudication  of  the   matter,   as   that   was   beyond   its   scope   and 
functioning.   It   is   only   the   Appellate   Authority 
appointed by the State Government under Section−127(1)  of   the   Act,   read   with   the   Appeal   to
  the   Appellate  Authority Rules, 2004, framed under Section−176(2)(u)  of   the   Act,   that   has  
jurisdiction   to   hear   appeals  preferred against a final order passed under Section−
126 of the Act. It is relevant to note that though an 
objection regarding the Appellate Authority has been 
taken by DGVCL at this stage, no allegations of bias  or  malafides  have   been   levelled   against  
the   said  Authority.   Further,   it   has   not   been   submitted   that 
DGVCL has been prejudiced in any manner by the hearing 
of the appeal by the Appellate Authority. When there  are   no   allegations   of   bias   or   malafides  
and   no  averments   as   to   prejudice,  the   objection   is   only   an 
empty one and deserves to be discarded.
76. In  State  Bank of India Vs. Ram Das and another  (Supra.),  relied   upon   by   Mr.Mihir   H.  
Joshi,   learned  Senior Advocate for Essar, the Supreme Court has held  as below : 
"24. We, in this case, are not concerned with any  
act of malice on the part of the umpire. Malice   has   to   be   specifically   pleaded  
and   proved.   Neither there exists any pleading in that behalf   nor   would   it  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

appear   from   the   discussions   made  
hereinafter that at any stage such a contention   has been raised.
25. The   appellant   had   four   opportunities   to  
raise the question of bias. The first opportunity 
was when the umpire filed the award in the court  
for being made rule of the court and appointed a   lawyer   to   prosecute   the   matter.
  It   is   not   disputed,   the   appellant   was   aware   of   the   fact   that   the   umpire  
did   file   the   appeal   himself   in   the   City   Civil   Court   and   appointed   a  
lawyer   to   prosecute   the   proceedings.  Despite   knowledge   of 
the fact of filing objections under Sections 30  
and 33 of the Act it did not raise the question  
of bias against the umpire. The second stage made  available   to   the   appellant  
when   it   filed   an   IA   for setting aside the award on the ground that it  did   not  
contain   reasons   in   view   of   the   said 
amendment in the Act in Section 17 of the Act.   Not   only   this,   the   appellant   had
  third  opportunity when the matter was remitted back to  
the umpire. It is relevant to mention here that   the   appellant   was   cross−examined
  before   the   Additional   Judge,   City   Civil   Court   but   no   question   as   regard  
bias   was   put   to   him.  The  fourth   opportunity   arose   when   the   proceedings  
were remitted back to the umpire and thereto also  the   appellant   did   not   raise  
any   question   as  regards bias.
26. Again, when the aforesaid award was given by   the   umpire   and   same   was  
filed   in   City   Civil  Court,   again   the   appellant   did   not   raise   any   objection  
as   regards   bias   and   the   appellant   happily   participated   in   the   proceedings.
 Yet  again when the award was made rule of the court,   the   appellant   filed   an  
appeal   before   the   High   Court of Judicature at Hyderabad but no ground of 
bias was taken in the memo of appeal or in the   civil revision petition.
27. It was only after the High Court adversely  
commented upon the conduct of the arbitrator in   the   manner   as   noticed  
hereinbefore,   that   the   appellant   became   wiser   and   for   the   first   time  
this objection has been taken before us. It is an  established   view   of   law   that  
where   a   party   despite   knowledge   of   the   defect   in   the 
jurisdiction or bias or malice of an arbitrator  
participated in the proceedings without any kind   of   objection,   by   his   conduct   it
  disentitles   itself   from   raising   such   a   question   in   the  
subsequent proceedings. What we find is that the   appellant   despite   numerous  
opportunities   made   available   to   it,   although   it   was   aware   of   the  
defect in the award of the umpire, at no stage  
made out any case of bias against the umpire. We,  therefore,   find   that   the  
appellant   cannot   be   permitted to raise the question of bias for the  
first time before this Court." Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

                             (emphasis supplied)
77. The   above   observations   of   the   Supreme   Court  fortify   the   view   taken   by   this   Court.  
DGVCL   has  participated in the proceedings before the Appellate  Authority   without   raising   any
  objections   and   only  after   the   conclusion   of   the   proceedings,   which   were 
not in its favour, has it taken this objection for the  first   time.   Such   conduct   of   DGVCL,  
therefore,  disentitles it from raising such an objection at this  stage.
Contention regarding breach of agreement :
78. It has been vehemently submitted by Mr.Mihir J. 
Thakore, learned Senior Advocate on behalf of DGVCL, 
that the dispute arises solely because Essar committed 
a breach of the agreement recorded in the Minutes of  Meeting   dated   01.02.2010.   It   has   further
  been  submitted   that   there   is   nothing   in   the   Electricity 
Act, 2003, that prohibits a contract of this nature; 
therefore, an appeal would not lie under the statute. 
In support of this submission, reliance is placed on a  judgment in  Oil  and  Natural  Gas
 Corporation  Limited  Vs. Saw Pipes Limited (Supra.). 
79. In this judgment, the Supreme Court was dealing 
with a challenge to the arbitral award and the grounds  of   such   challenge.   The   Supreme   Court  
held   that   an  award contrary to the substantive provisions of law or  the   provisions   of   the  
Arbitration   and   Conciliation  Act, 1996, would be patently illegal. Learned Senior 
Advocate for DGVCL laid stress on the observations of  the   Supreme   Court   that   for   the  
construction   of   the  contract,   the   intention   of   the   parties   is   to   be  gathered   from   the  
words   used   in   the   agreement   and  submitted that the penal Clause No.2.2 in the Minutes 
of Meeting dated 01.02.2010, expressed the intention  of   the   parties   and   was   agreed   by  
Essar,   therefore,  they are bound by it. 
80. The  above  judgment  does  not  come  to  the  aid  of 
DGVCL in any manner, as the intention of the parties 
is to be seen in the context of the agreement being 
arrived at, the situation prevailing at that point of  time and the 
 issues in dispute regarding which the  agreement was made. The issues in dispute before the 
Committee   when   the   Minutes   of   Meeting   dated  01.02.2010, were 
 (i) shifting of the lines and (ii)  supply of power to non−consumer Group companies. 
81. There   is   considerable   force   in   the   submissions 
advanced by Mr.S.N.Shelat, learned Senior Advocate for 
Essar, that the penal Clause No.2.2 in the Minutes of  Meeting   dated   01.02.2010   is  in   terrorem
 as,   by   its  oppressive   and   burdensome   nature,   it   would   ensure 
compliance of the agreement. Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

82. The intention of the parties can only be seen in  the   context  of  the   controversy   in   dispute 
for   which  the agreement was made. The scenario has substantially  changed   subsequently,   after  
the   drawing   up   of   the  Minutes of Meeting dated 01.02.2010. The background in 
which the impugned order has been passed pertains to  the revised supplementary bills for
 unauthorized  use  of   power   beyond   the   power   boundary   after   merger   of  the   member  
units   with   ESIL.   This   situation   was   not  contemplated   in   the   Minutes   of   Meeting   dated 
01.02.2010. At that point of time the order of merger 
of the group companies with ESIL had not been passed. 
Therefore, it cannot be said that the intention of the  parties   in   drawing   up   the   penal   clause  
can   be  stretched much beyond the factual scenario which has 
subsequently changed, to cover a different situation  envisaged   after   the   issuance   of   the  
revised  supplementary bills by DGVCL under Section−126(6) of  the Act.
83. As already discussed hereinabove, the Act debars  the   jurisdiction   of   the   Civil   Court,   as  
per   the  provisions   of   Section−145   thereof.   Being   a  Distribution   Licencee,   DGVCL   is  
bound   to   function  under   the   provisions   of   the   Act   and   Rules   and  Regulations   framed  
thereunder.   Had   it   been   the  intention of the legislature to permit adjudication by  Civil   Courts
  in   matters   under   the   Act,   Section−145 
would not have been enacted. The submission on behalf  of   DGVCL   that   nothing   in   the   Act  
debars   a  contract/agreement   of   the   nature   contained   in   the 
Minutes of Meeting carries no weight. Had it been the 
intention of the legislature to permit such a contract  or   agreement   it   would   have   expressly  
stated   so   and  also provided the remedy. The submissions on behalf of 
DGVCL fly in the face of Section−145 of the Act. 
84. A   penalty   for   unauthorized   use   of   electricity 
cannot be worked out dehors the permissible boundaries  of   the   Act.   The   factual   situation  
pursuant   to   the  Minutes   of   Meeting   dated   01.02.2010,   underwent   a  substantive   change.  
When   DGVCL   has   itself,   without  prejudice   or   objection,   treated   the   matter   as   one 
under   Section−126(6)   of   the   Act   and   issued   revised  supplementary   bills   as   per   the  
formula   contained   in  sub−section   (6)   of   Section−126,   it   cannot   now   claim  that   the
 dispute   falls   within  the   realm   of   contract  and   not   under   the   statute.   The   submissions  
of   the  learned Senior Advocate for DGVCL, in this regard are,  therefore, not convincing. 
85. DGVCL is "State" within the meaning of Article−12  of   the   Constitution   of   India.   All   its  
actions   and  functions   as   a   Distribution   Licencee   have   to   be 
carried out within the four corners of the Act, Rules  and Regulations. It cannot devise a procedure
 dehors  the Act, of its own accord, to suit its own fancies. 
Being "State", the actions of DGVCL have to be tested 
on the touchstone of reasonableness. Its actions are 
expected to be free from the taint of arbitrariness. 
DGVCL cannot be permitted to approbate and reprobate, 
at the same time. After having accepted the decision 
of the State Government to treat the dispute as one  under Section−Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

126(6) of the Act, and having actually  issued the revised supplementary bills as per the said 
provisions of law, it cannot now take a stand that the 
statute would not govern the matter which, according 
to it, is contractual in nature. This Court is unable  to  agree  with   the  submissions  advanced  on
 behalf   of  DGVCL in this regard. On the other hand, there is a  considerable   weight   and   force  
in   the   submissions  advanced by Mr.Mihir H. Joshi, learned Senior Advocate 
for Essar, to the contrary.
Effect of amalgamation :
86. At the relevant point of time when the Minutes of  Meeting   dated   01.02.2010   were   drawn  
up   and   an  agreement reached between the parties, only ESIL was a 
consumer of DGVCL. The other units of the Essar Group  were   not   consumers,   even   though  
most   of   them   were  located   in   the   same   complex.   It   was   precisely   to  prevent   the  flow  
of   power   to   the  non−consumer   units  that the mechanism of reverse power relay was agreed 
upon in the Minutes of Meeting. Subsequently, a Scheme 
of Amalgamation was sanctioned by the High Court vide  order   dated   30.06.2010,   which  
became   effective   from  05.08.2010.   The   consequential   legal   effect   thereof,  inter−
alia, was that Essar Steel (Hazira) Limited, the  Transferor   Company,   stood   merged   with   ESIL,
  the  Transferee   Company,   and   ceased   to   have   been   any  independent   legal   existence  
thereafter.   According   to  Essar,   on   the   date   of   the   purported   default   on 
15.06.2011, there was no supply of DGVCL power to a 
member unit, since it had ceased to exist and stood  merged   with   the   consumer.   Therefore,   the
  default  clause   in   the   Minutes   of     Meeting   dated   01.02.2010,  was not triggered.
87. The   stand   of   DGVCL   is   that   the   amalgamation   of  other   units   of   Essar   Group  
which   were   not   the  consumers with ESIL (the consumer), does not mean that 
the merged units would automatically become consumers 
of DGVCL. According to DGVCL, the legal entity, even  after   becoming   a   single   one   after  
merger,   does   not  mean that the merged units becomes a single consumer  as   a   consumer   is   to
  be   seen   in     relation   to   the  premises and not to the legal entity.
88. On behalf of DGVCL, reliance has been placed upon  the judgment of  Singer  India Ltd. Vs.
 Chander  Mohan  Chadha (Supra.), in support of the above submission.
89. The   facts   of   that   case   were   on   a   somewhat  different   footing,   which   have   no  
relevance   to   the  dispute in the present case. The Supreme Court held, 
on the facts of that case, that the provisions under  Section−
14(1) proviso (b) of Delhi Rent Control Act,  1958, for recovery of possession, would be applicable 
upon the occurrence of the factual situation of sub− letting,   assignment   or   otherwise   parting  
with  possession,   whether   by   a   voluntary   act   or   otherwise  and   irrespective   of   the  
reasons   therefor.   In   that  case,   on   amalgamation   of   the   tenant   company   with 
another company, it was held that the former ceased to  exist   and   in   terms   of   the  
Amalgamation   Scheme,   the  latter   company   came   in   possession   and   occupation   of  the  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

demised   premises.   Therefore,   the   amalgamation, 
although effected for complying with RBI's direction  issued   under   Section−29,   FERA,   1973,   to
  the   tenant  foreign   company   to   reduce   its   share   capital   to   the  specified   limit   in   order  
to   carry   on   business   in  India,   attracted   the   provisions   of   Section−14(1) 
proviso (b) of the Delhi Rent Control Act, 1958. The  ratio   of   this   judgment   rests   upon   its  
own   peculiar  facts and would not help the petitioner−DGVCL in the  present case.
90. On   the   other   hand,   Mr.Mihir   H.   Joshi,   learned 
Senior Advocate for Essar has placed reliance upon the  judgment   of   the   Supreme   Court   in
 Singer   India   Ltd.  Vs.   Chander   Mohan   Chadha   (Supra.),  wherein   the 
Supreme Court has held as below :
"7. The provision for facilitating reconstruction  and   amalgamation   of   companies  
is   made   under   Section   394   of   the   Companies   Act.  In   an  amalgamation,  
two   or   more   companies   are   fused   into   one   by   merger   or   by   one   taking  
over   the   other.   Reconstruction   or   amalgamation   has   no  precise   legal  
meaning.   In   Halsbury's   Laws   of   England   (4th   Edn.,   Vol.7),   para   1539,   the
  attributes of amalgamation of companies have been  stated as under :
"Amalgamation is a blending of two or more   existing   undertakings   into   one  
undertaking,  the   shareholders   of   each   blending   company  becoming  
substantially   the   shareholders   in   the company which is to carry on the blended  
undertakings.   There   may   be   amalgamation   either   by   the   transfer   of   two  
or   more   undertakings   to   a   new   company,   or   by   the 
transfer of one or more undertakings to an   existing   company.   Strictly  
"amalgamation" 
does   not,   it   seems,   cover   the   mere   acquisition   by   a   company   of   the   share   capital   of  
other   companies   which   remain   in   existence   and   continue   their   undertakings,   but   the  
context   to   which   the   term   is   used   may show that it is intended to include such  
an acquisition.
The question whether a winding up is for the   purposes   of   reconstruction   or   amalgamation  
depends upon the whole of the circumstances   of the winding up."
8.  In   Saraswati   Industrial   Undertaking   v.   CIT,   (para 6), it has been held that there can be no  
doubt   that   when   two   companies   amalgamate   and  
merge into one, the transferor company loses its   identity   as   it   ceases   to   have   its   business. 
However,   their   respective   rights   or   liabilities  
are determined under the Scheme of Amalgamation,   but   the   corporate   identity   of   the  
transferor   company ceases to exist with effect from the date 
of amalgamation is made effective. Therefore, in   view of the settled legal position, the original  
lessee,   namely,   the   American   Company   ceased   to  
exist with effect from the appointed day i.e. 1− 1−1982 and thereafter the Indian Company came in  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

possession and is in occupation of the premises   in  dispute."                                        (emphasis  
supplied)
91. This judgment is more to the point in the context 
of the present dispute. In light of the principles of  law   enunciated   in   the   above−quoted  
judgment,   there  cannot   be   any   doubt   that,   when   companies   amalgamate 
and merge into one, the Transferor Company loses its 
identity as it ceases to have its business when the  amalgamation is made effective.
92. The record reveals that Essar addressed a letter  to   GETCO   on   21.05.2011,   stating   that   the
  Scheme   of  Amalgamation   has   been   sanctioned   and   had   become  effective   from  
05.08.2010,   therefore,   the  units/companies covered under the said Scheme, inter− alia,   being  
Essar   Steel   (Hazira)   Limited   had   merged  into   ESIL,   which   was  an  existing  consumer  of
 DGVCL.  Consequently,   the   contract   demand   of   ESIL   would  automatically   cover   the  
supply   to   the   units   of   the  merged   entities   and   the   reverse   power   flow   relay  should   be
  removed.   It   was   stated   that   there   is   no 
company having its units within the complex which is  not   covered   under   the   Scheme   of  
Amalgamation.   By  reason of the merger, Essar applied to DGVCL for an 
increase in the contract demand from 44.5 MVA to 60  MVA by a letter dated 01.06.2011.
93. By a letter dated 04.06.2011, GETCO informed ESIL 
that it should submit the details of the amalgamation 
to DGVCL for confirmation; after which a verification 
and personal inspection at the site would take place 
before the reverse power flow relay could be removed 
by GETCO. On 04.06.2011 itself, GETCO directed DGVCL  to   take   steps   for   the   removal   of  
the   reverse   power  flow   relay.   Again,   on   08.06.2011,   Essar   addressed   a 
letter to DGVCL for the removal of the reverse power 
flow relay and requested that urgent action be taken  in   view   of   the   problems   faced   by   it,  
regarding  frequent   line   tripping   and   low   utilization   of   the 
additional power of 200 MW purchased from GUVNL, vide 
agreement dated 13.05.2011, under open access.
94. It is significant to note that in response to the  application   of   Essar   for   increasing   the  
contract  demand, DGVCL, by its letter dated 15.06.2011, itself  directed   ESIL   to   get   the   power  
boundary   approved.  ESIL, therefore, made an application dated 15.06.2011 
for extension of the power boundary, to DGVCL. 
95. According to Essar, since no action was taken by 
DGVCL in spite of the directions of GETCO and as there  was   frequent   tripping   and   under  
utilization   of   the  open   access   power   resulting   in   damage   to   equipments  and   as   an  
emergency,   interim   measure,   the   line  isolator between the connection point of the underpass 
on the second electrical line and Bus−Bar was closed 
by it. The reverse power relay on the first electrical  line   between   Bhander   Power   Limited   and  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

the   Bus−Bar  remained as it is, but power could flow from the Bus−
Bar to the segment of the second electrical line and 
through the underpass to Essar Steel (Hazira) Limited. 
According to Essar, since a meter had been installed 
on the second electrical line at its connection point  to the Bus−
Bar, such electrical energy would be duly  recorded in the meter. 
96. Again, on 01.07.2011, Essar addressed a letter to  DGVCL,   seeking   sanction/approval   for   the
  removal   of  the   underpass   arrangement   and   the   final   proposed  arrangement   for  
restoration   of   the   earlier   position  and   connections   regarding   the   main   receiving   Sub−
Stations.   Accordingly,   on   21.07.2011,   DGVCL   carried 
out an inspection of the premises and found that :
"Observations at BPOL :
1. BPOL   MRSS   line   1   is   in   ON   condition   and   supplying   power   to   MRSS  
(Old)   with   reverse   power relay in circuit.
2. BPOL   MRSS   line   2   is   in   isolated   condition   with   220   KV   breaker   OFF  
and   all   isolators   are opened."
    
97. There   is   no   doubt   regarding   the   fact   that   the  action   taken   by   ESIL   in   unilaterally  
removing   the  reverse power relay system resulted in power flowing 
to the units which were not consumers of DGVCL at the  time   when   the   Minutes   of   the  
Meeting   were  recorded.  They   stood   merged   with   ESIL   only   later,   after   the  sanctioning  
of   the   Scheme   of   Amalgamation.   After 
amalgamation, as per the judgment of the Supreme Court  in  Singer   India   Ltd.   Vs.   Chander  
Mohan   Chadha  (Supra.),  non−member   units   merged   with   ESIL   and  become   fused   into  
one,   and   the   Transferor   Companies  lost   their   separate   identities.   However,   for   the 
utilization   of   power   by   the   erstwhile   non−consumer 
units, it was incumbent that the power boundary should 
be extended to cover the areas of those erstwhile non− member   units   which   had   now   fused  
with   the   original  consumer.  The   power   boundary   was   required   to   be  extended.
98. DGVCL   has   itself   treated   the   extension   of   the 
power boundary as a remedial measure, as is clear from  its   letter   dated   17.04.2012,   addressed  
to   Essar,  directing the extension of the power boundary of ESIL. 
It has, in fact, approved the very action undertaken  by   Essar   on   15.06.2011,   vide   its   letter  
dated  14.05.2012.
99. Moreover,   the   State   Government   has   itself 
concluded (and this conclusion has not been denied by Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

DGVCL) that the issue in dispute refers to the breach 
of the power boundary. This is clearly recorded in the 
Report of the Committee dated 13.12.2011. It is stated  therein   that   "the   whole   matter   of   the  
supplementary   bill   rested   on   the   fact   of   the   use   of   unauthorized   power   outside   the  
approved   boundary   of   Essar   Steel   India Limited on the date of detection by DGVCL and  
as per the Minutes of the Meeting dated 01.02.2010".  (emphasis supplied)
100.   A   document   that   is   highly   relevant   in   this  context   is   the  letter   dated   05.01.2012
 of  the   State  Government to DGVCL, wherein it is clearly stated that 
the fact remains that there is no theft of electricity 
as fully energy is accounted and paid for, therefore,  the   matter   is   required   to   be   considered  
under   the  provisions   of   sub−section   (6)   of   Section−126   of   the 
Act, till the case of total claim is settled. 
101.  It is crystal clear that the unauthorized use of  electricity   by   ESIL,   as   contemplated   under  
Section− 126(6)   of   the   Act,   was   regarding  the   utilization   of  power   outside   the   approved  
power   boundary   and,   in  terms of Explanation−(b)(v) to the said section, for  premises   or   an  
area   other   than   that   for   which   the  supply   of   electricity   was   authorized.  Despite   the 
amalgamation,   Essar   could   not   have   utilized   power  without   the   extension   of   the   power  
boundary.   This,  precisely,   is   the   unauthorized   use   of   electricity  committed   by   it,   inviting
  consequences   under   sub− section (6) of Section−126, as per which the revised 
supplementary bills have been issued. 
102.   The submission of Mr.Mihir J. Thakore, learned 
Senior Advocate for DGVCL, to the effect that it is 
not a mere case of extension of the power boundary, as  other   units   were   not   consumers   of  
DGVCL,   is  unconvincing,   considering   the   factual   and   legal 
position as discussed hereinabove and as highlighted  by the record. 
Whether   the   revised   supplementary   bills   are  final :
103.  It has been forcefully argued on behalf of DGVCL  that   the   revised   supplementary   bills,  
though   issued  under Section−126 of the Act, are not final in nature, 
as the procedure under the said provision of law has 
not been followed by DGVCL. It has been contended that 
there was no provisional assessment, no opportunity of  hearing   was   granted   and   no   final  
decision   of   the  Assessing   Authority   took   place.   It   has   also   been 
pointed out that the State Government, in its letter 
dated 05.01.2012, has stated that the issuance of the  supplementary bills is a stop−
gap arrangement till the  total claim is settled. It is submitted that DGVCL has  issued   the   said  
bills   till   the   total   claim   of  Rs.2311,02,43,968/− is finally settled.
104.   There  is  no  doubt  regarding   the  fact   that  the  original   claim   of   DGVCL   for  
Rs.2311,02,43,968/−   for  202,09,92,000   units,   worked   out   as   per   the   formula  contained  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

in   the   Minutes   of   the   Meeting   dated  01.02.2010, has been revised by DGVCL by issuing the 
revised   supplementary   bills   for   an   amount   of  Rs.192,58,53,664/−   on   25.01.2012.   At   the  
cost   of  repetition,  it  bears  mention   that   DGVCL   has   not,   at 
any point of time, raised any objection regarding the 
issuance of the supplementary bills as per Section−126 
of the Act, to the State Government. Neither has it  refused   to   act  in  accordance   with   the  
provisions   of  Section−126 of the Act in this regard. It is not the  case   of   DGVCL   that   the   said  
provision   of   law   is  inapplicable   in   cases   of   unauthorized   use   of  electricity.   Merely   by  
harping   upon   the   words   "till  the   case   of   total   claim   is   settled",   in   the   letter 
dated 05.01.2012 of the State Government and its own  forwarding   letter   dated   25.01.2012,   vide
  which   the  revised supplementary bills have been issued, it does  not   mean   that   the   consumer
  is   estopped   from   taking  legal recourse against the revised supplementary bills  issued   under  
the   Act,   in   accordance   with   law.   As  already discussed hereinabove, having once treated the 
revised   supplementary   bills   as   being   under   Section− 126(6)   of   the   Act,   DGVCL   cannot  
claim   that   the  requirements of that section are not complied with by  it   and   the   consumer   is  
estopped   from   taking   legal  recourse. 
105.   On 21.07.2011, DGVCL inspected the premises of 
Essar and issued a Show Cause Notice dated 26.07.2011.  Objections   were   filed   by   Essar   vide  
letter   dated  29.07.2011   and   08.09.2011   and   a   final   decision   was 
taken on the objections vide order dated 22.09.2011, 
by issuing the first bill for Rs.2311,02,43,968/−. The  procedure   under   Section−126   has,  
therefore,   be  substantially followed and complied with. The original  amount   has   been   revised  
to   Rs.192,58,53,664/−   after  DGVCL arrived at a conclusion that there has been an  unauthorized  
use   of   power.   This   decision   is   nothing  but a final order in substance, under Section−126 of 
the   Act,   against   which   an   appeal   is   provided   under  Section−127,   to   the   Appellate  
Authority.   The  submissions   advanced   by   the   learned   Senior   Advocate 
for DGVCL to the contrary do not merit acceptance.
Findings of the Appellate Authority on merits :
106.   After holding that the appeal under Section−126 
of the Act is maintainable, which finding is supported  by   ample   reasoning   and  
does   not   require   the  interference   of   this   Court   for   reasons   stated 
hereinabove,   the   Appellate   Authority   has   rendered   a 
finding on the basis of the Report of the Committee 
constituted by the Government of Gujarat to the effect 
that "there is no theft as full energy is accounted  
and paid for but a unilateral decision has been taken   by   Essar   to   overrule   the  
reverse   power   relay   restriction and avail power from their CPP, DGVCL and  
Open Access power from GUVNL. So the whole matter of  supplementary   bill   rests  
on   the   fact   of   use   of   unauthorized power outside approved boundary of Essar  
Steel   on   date   of   detection   by   DGVCL   and   as   per  
Minutes of Meeting 01.02.2010."  Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

107.  The findings of the Appellate Authority are that 
the above Committee was of the view that although the 
method of calculation was stipulated in the Minutes of  Meeting,   the   situation  
created   by   Essar   resulted   in  unauthorized   use   of   electricity   as   explained  
under  Section−126, therefore, the assessment should be made  according   to   the  
provisions   of   that   section   as 
directed by the State Government, instead of using the  formula   of   twelve  times  of
 consumption  at  twice  the  tariff,   as   per  the   Minutes  of  Meeting.  According   to 
the Appellate Authority, the Minutes of Meeting dated  01.02.2010   would   not   have
  an   overriding   effect   upon  the provisions of the Electricity Act, 2003, and the 
Regulations.   Before   this   Court   as   well,   DGVCL   could  not   satisfactorily  
point   out   that   the   Minutes   of  Meeting and the penal clause contained in it 
 would  override the provisions of the statute. This finding  of   the   Appellate  
Authority,   therefore,   cannot   be  faulted.
108.   The   Appellate   Authority   has   further   held   that 
though this Court has approved the merger of the group  companies   with   ESIL,  
however,   the   extension   of   the  power   boundary   was   not   accorded   by  
DGVCL   at   the  relevant   point   of   time.   Hence,   it   was   a   matter   of 
unauthorized use of electricity under Section−126 of 
the Act and was appealable under Section−127. There is 
no doubt regarding the fact that during the relevant  period   of   time   for   which  
the   revised   supplementary  bills have been issued, there was no extension of the 
power   boundary   to   cover   the   merged   units.   Thus,   it 
cannot be disputed that there was an unauthorized use 
of electricity by Essar, to that extent. This has also  been   held   by   the   Committee  
formed   by   the   State  Government and has not denied by DGVCL. In fact, DGVCL 
has   issued   the   revised   supplementary   bills   on   the 
basis of such unauthorized use of electricity, under  Section−126   of   the   Act,  
without   any   protest   or  objection. The Appellate Authority did not agree with  the  
submission   of   Essar   that   after   the   merger,   the  group   companies   also  
became   consumers   and   were  eligible   for   consumption     of   electricity   from  
the  existing connection, holding that corporate merger may 
not necessarily result into automatic physical merger  of   various   undertakings   of  
the   merged   entities.   The  premises   of   the   undertakings   of   the   merged  
entities  would   not   become   eligible   for   usage   of   electricity 
from the existing power connection for the premises of  the   parent   entity  unless  
the   power   boundary   is  extended suitably by the supplier thereby authorizing 
usage of power in the extended premises as well. The 
Appellate Authority further found that all such units 
which were not entitled to draw power under the supply 
contract of ESIL would not automatically be entitled  to   do   so   by   virtue   of   the  
order   of   amalgamation,  unless   authorized   by   the   Distribution   Licencee. Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

Therefore, the consumption of electricity recorded in  the   meter   of   Tie   Line−2   in   this   case,  
has   to   be  construed as an unauthorized use of electricity, not 
only as per the conditions contained in the Minutes of  Meeting, but also as per the provisions of 
 Section− 126 of the Electricity Act, 2003. Having held so, the 
Appellate Authority further goes on to state that the 
assessment of the unauthorized use of electricity is 
required to be made in a way which is just, lawful and 
consistent with the Act. The same view has also been 
taken by the Committee of the State Government in this 
matter. The Appellate Authority has conclusively held  that   the   Minutes   of   the   Meeting,    
cannot   have   an  overriding   effect   on   the   parent   statute   and   the 
subordinate legislature made thereunder.
109.   The   above   findings   of   the   Appellate   Authority  cannot   be   considered   to   be   illegal,  
beyond   its  jurisdiction, perverse or unreasonable, in any manner,  as   the   Act   would   govern  
the   actions,   duties   and  functions   of   the   Distribution   Licencee,   in   all  respects.
110.  The finding that the revised supplementary bills  issued   to   Essar   for   the   unauthorized  
use   of  electricity are virtually under Section−126 of the Act 
cannot be said to be baseless. The Appellate Authority  has   considered   the   actual   supply   of  
electricity   by  DGVCL to Essar and has held that as DGVCL has supplied 
only 25.23 MU of power to Essar during the period from 
15.06.2011 to 30.07.2011, only this quantity of power 
should, at the most, be considered as unauthorizedly 
used. It has been held on the basis of the record, and  not   denied   by   DGVCL,   that   Essar   has  
consumed   total  power   of   637.26   MU   (KWH)   (within   authorized   and  unauthorized  
premises),   out   of   which   its   own  generation   was   470.52   MU,   141.51   MU   were  
purchased  from GUVNL under the Open Access and only 25.23 MU was 
supplied by DGVCL (based on SLDC data). The Appellate 
Authority accepted the contention of Essar that out of 
637.26 MU of power consumed, it had drawn 470.52 from  its   own   generation   and   141.51  MU
 though   Open  Access  facility   and   only   the   remaining   25.23   MU   was   drawn 
from the Grid. Thus, DGVCL has supplied only 25.23 MU  to   ESIL   during   the   period   from  
15.06.2011   to  30.07.2011   which,   at   the   most   can   be   considered   as 
unauthorized use of electricity as per Section−126 of  the   Act.   On   the   basis   of   the   above,   the
  revised  supplementary bills amounting to Rs.192.58 Crores were 
found to be unreasonable and unjustifiable and it has 
been directed by the Appellate Authority that the said  bills be revised for 25.23 MU of power only.
111.   It   has   been   submitted   by   Mr.Mihir   H.   Joshi,  learned   Senior   Advocate   for   Essar,  
which   is   the  petitioner   in   Special   Civil   Application   No.5494/2014 
that even assuming that there is an unauthorized use of 
power by Essar, it can only be to the extent of 6.63 MU 
on the basis of proportionate consumption of power by Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

the merged units. It has been submitted that DGVCL had  supplied   25.23   MU   power   during   the
  period   between  15.06.2011 and 30.07.2011 from where only 6.63 MU power  has   flown   to   the  
merged   entities,   therefore,   the  unauthorized use of power, if any, would only be 6.63  MU   and  
not   the   entire   25.23   MU   of   power   supplied   by  DGVCL.   On   the   basis   of   this  
contention,   it   has   been  submitted that the finding of the Appellate Authority  that   there   is   an  
unauthorized   use   of   power   to   the  extent of 25.23 MU is illegal and bad in law.
112.   After having perused the order of the Appellate  Authority   minutely,   it   is   reflected   that  
this  contention   has   been   raised   before   the   Appellate 
Authority and has been recorded in paragraph−3.6 of the 
impugned order. However, while arriving at a conclusion  that   there   has   been   an   unauthorized
  use   of   power   by  Essar to the extent of 25.23 MU, no finding has been  rendered   on   the  
specific   submission   of   Essar   that  proportionately only 6.63 MU of DGVCL power has flown 
to the merged units.
113.  The Appellate Authority has rendered a finding on 
the basis of specific and official data and material on  record   to   the   extent   that   there   has   been
  an  unauthorized use of power by Essar due to non−extension 
of the power boundary for the relevant period of time.  This   Court   is   in   agreement   with   the  
above   finding.  However, whether the unauthorized use is for 25.23 MU  of   power   or   6.63   MU  
of   power   on   the   basis   of  proportionate consumption of DGVCL power by the member  units  
has   not   been   determined   by   the   Appellate  Authority. 
Conclusion   in   Special   Civil   Application  No.2859/2014 :
114.  The cumulative effect of the above discussion is  that   this   Court   does   not   find   any  
arbitrariness,  perversity or illegality in the impugned order dated  01.11.2013,   passed   by   the  
Appellate   Authority,  directing   the   refund   of   the   excess   amount   paid   by 
Essar pursuant to the revised supplementary bills over 
and above the quantity of unauthorized power used by  Essar. 
115.   Hence,   Special   Civil   Application   No.2859/2014  stands rejected. Rule is discharged.
Conclusion   in   Special   Civil   Application  No.5494/2014 :
116. As discussed hereinabove, the Appellate Authority 
has failed to determine the specific contention raised 
by Essar to the effect that the unauthorized use of  power   by   the   merged   entities   from   the  
period  15.06.2011 to 30.07.2011 would only be to the extent 
of 6.63 MU and not the entire 25.23 MU. No findings 
have been rendered by the Appellate Authority on this 
point in the impugned order. A finding on this issue  would   entail   going   through   the   relevant  
record   and  data   and   other   factual   aspects   and   the   Appellate 
Authority is the appropriate Forum to decide the issue Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

at the first instance, and not this Court. As this has 
not been done, the petition deserves to be remanded to 
the Appellate Authority on this limited ground only.
117.   Consequently,   the   finding   of   the   Appellate 
Authority in the impugned order dated 01.11.2013 that 
unauthorized use of power by Essar is to the extent of  25.23   MU,   is   quashed   and   set   aside.  
The   matter   is  remanded to the Appellate Authority for fresh decision  on   this   point,   after  
hearing   the   parties   on   the  limited issue whether the unauthorized use of power by 
Essar is to the extent of 25.23 MU or 6.63 MU. This be 
done within a period of four weeks from the date of 
the receipt of a copy of this judgment. Apart from the  above,   the   rest   of   the   order   of   the  
Appellate  Authority shall remain as it is. 
118.   The   petition   is   partly−allowed,   to   the   above  extent. Rule is made absolute, accordingly. 
Conclusion   in   Special   Civil   Application  No.5621/2014 :
119.   This petition has not been seriously pressed by 
the learned Senior Counsel for the parties, considering 
the fact that this petition has nothing essentially, or  directly,   to   do   with   the   issue   involved   in
  the   lead  matter and the cross−petition. The prayers made in this  petition   are   more   or   less   in
  the   nature   of   interim  relief pending the decision of the above two petitions. 
It is submitted on behalf of the petitioner−ESIL that  its   fate   would   hang   on   the   decision   in  
the   lead  petition and cross−petition. 
120.  The contention raised in the petition is that an  amount   of   Rs.192.58   Crores   has   been  
paid   by   the  petitioner−ESIL, and as per the order dated 01.11.2013 
passed by the Appellate Authority (impugned in lead and 
cross petitions), a specific amount is directed to be 
refunded to it, therefore, the action proposed against 
ESIL by way of the letters impugned in the petition, be  withheld.   As   both   the   lead   petition  
and   the   cross− petitions have been finally decided by this judgment, 
nothing further survives in this petition.
121.  Accordingly,   it   stands   rejected.  Rule   is  discharged. 
(SMT. ABHILASHA KUMARI, J.) Gaurav+Essar Steel India Limited vs Dakshin Gujarat Vij Company Limited on 22 January, 2015

