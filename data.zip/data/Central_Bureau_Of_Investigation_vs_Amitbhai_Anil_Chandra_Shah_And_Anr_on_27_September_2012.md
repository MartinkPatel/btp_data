Central Bureau Of Investigation vs Amitbhai Anil Chandra Shah
And Anr on 27 September, 2012
Equivalent citations: AIRONLINE 2012 SC 346
Author: Aftab Alam
Bench: Ranjana Prakash Desai, Aftab Alam
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                       CRIMINAL APPELLATE JURISDICTION
                      CRIMINAL APPEAL NO. 1503 OF 2012
               [ARISING OUT OF SLP (CRIMINAL) NO.9003 OF 2010]
Central Bureau of Investigation              … Appellant
                                   Versus
Amitbhai Anil Chandra Shah and Another       … Respondents
                                    WITH
                 TRANSFER PETITION (CRIMINAL) NO.44 OF 2011
Central Bureau of Investigation              … Petitioner
                                   Versus
Dahyaji Gobarji Vanzara & Others             … Respondents
                               J U D G M E N T
Aftab Alam, J.
1. Leave granted.
2. This order deals with an appeal and a transfer petition filed by the Central Bureau of Investigation
(the CBI). The appeal (arising from SLP (Criminal) No.9003 of 2010) is directed against the order
dated October 29, 2010 passed by the Gujarat High Court in Criminal Miscellaneous
No.12240/2010 granting bail to Amitbhai Anil Chandra Shah (respondent no.1 in this appeal and
accused No.16 in the transfer petition) in case No.RC BS1/S/2010/0004 (Criminal Case No.5 ofCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

2010) (“the Sohrabuddin case”), who until his arrest in the case was the minister of State for Home
in the State of Gujarat. In the transfer petition, a prayer is made to transfer the Sohrabuddin case
outside the State of Gujarat for trial. Both the appeal and the transfer petition are the result of the
developments following the orders passed by the Court in Writ Petition (Criminal) No.6 of 2007
(Rubabbuddin Sheikh v. State of Gujarat & Others) seeking a direction for the investigation of the
case concerning the killing of Sohrabuddin and the disappearance of his wife, Kausarbi by the CBI.
In order to put the two issues in context, therefore, it is necessary to slightly go back into the facts of
that case and see how the matter unfolded before it came to the present stage.
3. This Court by order dated January 12, 2010[1] passed in the aforesaid writ petition directed the
CBI to investigate the case relating to the killings of Sohrabuddin and his wife Kausarbi. The order
came to be passed after the proceedings in this Court in regard to those killings had gone on for over
four years, initially on the basis of two letter-petitions and subsequently under the aforesaid writ
petition. At the beginning, the State of Gujarat stoutly and vociferously denied that the encounter in
which Sohrabuddin was killed was stage-managed and it was only later that it came around to
accept that it was actually so and his wife, Kausarbi too was killed while she was in illegal police
custody and her body was disposed of in a manner as to make it untraceable. Some sort of an
investigation was made by the Gujarat Police and a charge-sheet was submitted on July 16, 2007
against thirteen (13) persons who were members of the Anti Terrorist Squad, Gujarat Police and the
Special Task Force, Rajasthan Police. On behalf of the writ-petitioner (Rubabbuddin Sheikh, the
brother of the slain Sohrabuddin), however, it was submitted that the charge-sheet was deceptive
and was designed more to cover up rather than uncover the entire conspiracy behind the murder of
Sohrabuddin and his wife. It was pointed out that the Gujarat Police had completely ignored the
killing of Tulsiram Prajapati in a similar police encounter one year after the killing of Sohrabuddin
who was killed simply because he was a witness to the abduction of Sohrabuddin and his wife by the
police party. On September 30, 2008 the Court was informed that following the submission of the
charge-sheet, even as the matter was under the scrutiny of this Court, the case was hurriedly
committed and the trial court had fixed the hearing on the charge on a day to day basis. The Court
on that date stayed further proceedings in Sessions Case no. 256 of 2007 and directed for the
records of the case to be put in the safe custody of the Registrar General of the Gujarat High Court.
4. In further proceedings before this Court, the State of Gujarat took the stand that all that was
required to be done was done in the matter and there was nothing more for this Court to do. It was
argued on behalf of the State that with the submission of the charge-sheet this Court’s power and
authority to monitor the investigation came to an end and the case came under the exclusive
jurisdiction of the magistrate/trial court who would proceed further on the basis of the charge-sheet
submitted by the police.
5. This Court felt otherwise. It appeared to the Court that there were a number of aspects of the case,
including the killing of Tulsiram Prajapati that were not addressed at all by the Gujarat Police. The
State of Gujarat, however, continued to maintain that the killing of Tulsiram Prajapati in the police
encounter had no connection with the killings of Sohrabuddin and his wife. That being the position
taken by the State it was but natural for the State police not to investigate any linkages between the
killings of Sohrabuddin and his wife on the one hand and the killing of Tulsiram Prajapati on theCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

other.
6. Among the number of reasons that weighed with the Court to ask the CBI to investigate into the
killings of Sohrabuddin and his wife, even after the submission of charge-sheet by the Gujarat Police
was the trenchant refusal by the State of Gujarat and the State police to see any connection between
the killings of Sohrabuddin and his wife and the killing of Tulsiram Prajapati. In the order dated
January 12, 2010 by which the investigation of the case was entrusted to the CBI, the Court
commented upon the persistent effort to disconnect the Prajapati encounter from the killings of
Sohrabuddin and his wife as under:
“From the charge-sheet, it also appears that the third person was ‘sent somewhere’.
However, it appears that the literal translation of the charge-sheet in Gujarati would
mean that he was ‘anyhow made to disappear’. From this, we are also satisfied that an
attempt was made by the investigating agency of the State of Gujarat to mislead the
Court.” (paragraph 63 of the order) “The possibility of the third person being
Tulsiram Prajapati cannot be ruled out, although the police authorities or the State
had made all possible efforts to show that it was not Tulsiram. In our view, the fact
surrounding his death evokes strong suspicion that a deliberate attempt was made to
destroy a human witness.” (paragraph 65 of the order) “No justification can be found
for the Investigating Officer Ms. Johri walking out of the investigation with respect to
Tulsiram Prajapati’s death without even informing this Court.” (paragraph 66 of the
order) (emphasis added)
7. Further, recounting the many deficiencies in the investigation by the Gujarat Police, this Court
also noticed its omission to analyse the call details of the accused. The Court observed:
“So far as the call records are concerned, it would be evident from the same that they
had not been analysed properly, particularly the call data relating to three senior
police officers either in relation to Sohrabuddin’s case or in Prajapati’s case.”
(paragraph 66 of the order)
8. In light of the above and a number of other acts of omission and commission as appearing from
the eight Action Taken Reports (submitted in course of hearing of the writ petition) and the Gujarat
Police charge- sheet, this Court asked the CBI to investigate the killings of Sohrabuddin and his wife
Kausarbi, giving the following directions:
“82. Accordingly, in the facts and circumstances even at this stage the police
authorities of the State are directed to hand over the records of the present case to the
CBI Authorities within a fortnight from this date and thereafter the CBI Authorities
shall take up the investigation and complete the same within six months from the
date of taking over the investigation from the State police authorities. The CBI
Authorities shall investigate all aspects of the case relating to the killing of
Sohrabuddin and his wife Kausarbi including the alleged possibility of a larger
conspiracy. The report of the CBI Authorities shall be filed in this Court when thisCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

Court will pass further necessary orders in accordance with the said report, if
necessary. We expect that the police authorities of Gujarat, Andhra Pradesh and
Rajasthan shall cooperate with the CBI Authorities in conducting the investigation
properly and in an appropriate manner.” (emphasis added)
9. It may here be noted that another writ petition [being Writ Petition (Criminal) No.115 of 2007]
filed by Narmada Bai, the mother of Tulsiram Prajapati, relating to the encounter killing of her son
was till that stage being heard along with the Sohrabuddin case (Writ Petition (Criminal) No.6 of
2007). But in the concluding part of the order, in regard to Prajapati’s case it was directed as
follows:
“Writ Petition (Crl.) No.115 of 2007
84. So far as WP (Crl.) No.115 of 2007 is concerned, let this matter be listed after
eight weeks before an appropriate Bench.”
10. As directed by this Court, the CBI took up the investigation into the Sohrabuddin case after
instituting a fresh FIR on February 1, 2010. In the call records of the accused that had not been
worked out in the hands of Gujarat Police, the CBI claims to have found a valuable source of
important clues. On the basis of the call records, the statements of witnesses and other materials
collected by it, the CBI claims that it has unearthed a conspiracy of much larger proportions. It
submitted a charge-sheet on July 23, 2010 in which, in addition to the thirteen accused named in
the charge- sheet of the Gujarat Police, another 6 persons were also named as accused, being part of
the larger conspiracy. In the charge-sheet submitted by the CBI, one of the accused is Amitbhai
Shah, who till then was the minister of State for Home in the State Government. The accusation
against Amitbhai Shah is that he was the lynchpin of the conspiracy.
11. Following the submission of the charge-sheet by the CBI, on July 25, 2010, Amitbhai Shah was
arrested and was sent to judicial custody.
12. As noted above, this Court had asked the CBI to investigate all aspects of the case relating to the
killings of Sohrabuddin and his wife Kausarbi, including the possibility of a larger conspiracy. The
CBI, therefore, felt that it was both authorized and under the obligation to investigate the Prajapati
case as well, as it prima facie appeared to be integrally connected with the Sohrabuddin case. The
Gujarat Police, however, would neither hand over the records of the Prajapati case to the CBI nor
allow it to make any independent investigation in the Prajapati case. On the contrary, the Gujarat
Police purported to complete its investigation and, like the case of Sohrabuddin, rather hurriedly
filed the charge-sheet in the case on July 30, 2010, followed by a supplementary charge-sheet on
July 31, 2010, before the Judicial Magistrate, First Class, Danta, Banaskantha District. The
magistrate, equally quickly committed the case to the court of Sessions in two days’ time on August
2, 2010 even without a proper compliance with the provisions of section 207 of the Code of Criminal
Procedure.Central Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

13. According to the charge-sheet, Prajapati was indeed killed in a fake encounter but there was
nothing more to it than that. There was no attempt to investigate any larger conspiracy or to try to
connect it with the Sohrabuddin case. On the other hand, the whole effort was to present it as a
separate case, quite unconnected with the case of Sohrabuddin.
14. In the meanwhile, Amitbhai Shah was granted bail by the Gujarat High Court, by order dated
October 29, 2010 passed in Criminal Miscellaneous Application No.12240 of 2010. Against the
order passed by the High Court, the CBI immediately came to this Court in SLP (Crl.) No.9003 of
2010, giving rise to the present appeal seeking cancellation of bail granted to Amitbhai Shah. On
October 30, 2010, notices were issued to respondent nos.1 and 2, i.e. Amitbhai Shah and the State of
Gujarat. At the time of issuance of notice, on the prayer made on behalf of the CBI to stay the
operation of the bail order passed by the High Court on the ground that once released on bail the
accused would tamper with prosecution evidence, it was stated on behalf of respondent no.1 that he
would leave Gujarat the following morning and would stay out of the State till further orders that
may be passed by this Court.
15. On November 25, 2010, the CBI submitted a copy of its final report before this Court, copies of
which were directed to be given to the parties.
16. On December 14, 2010, it was brought to the notice of the Court that the Prajapati case had so far
not been listed before the Bench to which it was assigned and, consequently, no order was passed in
that case by the Court. Nevertheless, the trial court was proceeding to start the trial of the accused
on the basis of the charge-sheet submitted by the Gujarat Police. A grievance was made that in case
the trial court was allowed to proceed, it might be too late by the time any order is passed by this
Court in the Prajapati case. At that stage, Mr. Tushar Mehta, Sr. AAG appearing for the State of
Gujarat fairly stated that no further proceeding would take place in the case arising from the
charge-sheet submitted by the Gujarat Police in the Prajapati case until this Court passed some
orders on the status report submitted by the CBI in this case and the Writ Petition (Crl.) No.115 of
2007 was taken up by the Court.
17. On January 13, 2011, the CBI filed the present transfer petition (Transfer Petition (Criminal)
No.44 of 2011) for transfer of the Sohrabuddin case bearing Special Case No.5 of 2010 pending in
the court of Additional Chief Metropolitan Magistrate, CBI, Mirzapur Ahmedabad, titled “CBI v.
D.G. Vanzara & Ors” to the CBI court in Mumbai or any other State and for a further direction for
the constitution of a special court. This, in short, is about the proceedings of the Sohrabuddin case
before this Court.
18. At this point, we may also take a brief look at the Prajapati case, Writ Petition (Criminal) No.115
of 2007 before this Court. It is interesting to note that in the first counter affidavit filed in the
Prajapati case, the State took the stand that the petition filed under Article 32 of the Constitution
was not maintainable because a case was already registered with the police according to which the
son of the writ petitioner was killed in a police encounter. It was contended that the writ petition
filed in the Sohrabuddin case was for a writ of habeas corpus and it was for that reason alone that it
was entertained by this Court. There was no such angle in the present case. In the counter affidavit itCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

was further stated that Tulsiram Prajapati was a dreaded criminal, involved in 21 criminal cases. As
to the manner of his death, the counter affidavit reiterated and fully supported the police version as
stated in the two FIRs relating to his alleged escape from the police custody while being taken back
after court remand and his death in a police encounter on the following day. It was pointedly denied
that Tulsiram Prajapati was a witness in the Sohrabuddin case. It was asserted that there was no
connection in the two cases.
19. However, by the time the writ petition came up for hearing, another affidavit was filed on behalf
of State of Gujarat on August 19, 2010. In this affidavit it was conceded that Tulsiram Prajapati was
killed in a fake encounter. It was, however, submitted that the State, CID (Crime) had already filed a
charge-sheet in the case. It was further the stand of the State that the encounter killing of Tulsiram
Prajapati had nothing to do with the killings of Sohrabuddin and Kausarbi.
20. It is, thus, to be seen that the Prajapati case also followed exactly the same pattern as the case of
Sohrabuddin. Initially, there was a complete denial by the State that he was killed in any kind of a
fake encounter. But, when it became impossible to deny that the story of the encounter was false, an
investigation was swiftly made by the Gujarat Police and charge-sheet was submitted. On the basis
of the charge-sheet, on the one hand an attempt was made to proceed with and conclude the trial
proceedings as quickly as possible and on the other hand this Court was told that after the
submission of the charge-sheet it was denuded of the authority to direct any further investigation.
There was, thus, clearly an attempt not to allow the full facts to come to light in connection with the
two cases.
21. Further, in the Prajapati case the State insisted till the end that though he too was killed in a fake
encounter there was no connection between his killing and the killings of Sohrabuddin and his wife,
Kausarbi.
22. The Prajapati case came up before the Court and it was allowed by judgment and order dated
April 8, 2011[2]. The Court debunked the contention that there was no connection between the
killings of Sohrabuddin and Kausarbi and the killing of Tulsiram Prajapati (see paragraphs 47 to 60
of the judgment) and also rejected the claim of the State Government that the investigation made in
his case was complete and satisfactory. It directed the State Government to handover the
investigation of the Prajapati case as well, to the CBI.
23. In pursuance of the Court’s direction, the CBI investigated the Prajapati case and even as the
hearing on the present appeal and the transfer petition was underway submitted the charge-sheet on
September 4, 2012. In the Prajapati charge-sheet Amitbhai Shah and a number of very senior police
officers of the State are cited as accused.
24. The facts and circumstances noted above, very briefly, provide the background in which the case
of the CBI for cancelling the bail granted to Amitbhai Shah (accused No.16 in transfer petition and
respondent No.1 in criminal appeal) in Sohrabuddin case and transferring that case for trial outside
Gujarat is to be considered.Central Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

25. Mr. Tankha, senior advocate, appearing for the CBI made a strong plea for cancelling the bail of
Amitbhai Shah and transferring the Sohrabuddin case outside Gujarat. Mr. Ram Jethmalani,
learned senior advocate, appearing on behalf of Amitbhai Shah with equal vehemence opposed the
prayer for cancellation of his bail. However, insofar as the transfer of the case is concerned, at the
end of the hearing he stated that Amitbhai Shah was prepared to face the trial anywhere and he
would, therefore, accept the transfer of the case without demur. The transfer petition was, however,
opposed by the State and the other accused, namely, Dahyaji Gobarji Vanzara (respondent No.1 in
the transfer petition), Rajkumar Pandyan (respondent No.2 in the transfer petition), Naransinh
Harisinh Dabhi (respondent No.5 in the transfer petition) Balkrishan Lalkrishna Chaubey
(respondent No.6 in the transfer petition) and Narendra Kantilal Amin (respondent No.12 in the
transfer petition) and their respective counsel were heard by the Court at length.
26. The submissions made by the CBI in support of the prayer for the cancellation of bail and the
transfer of the case were substantially the same. It was submitted on its behalf that Amitbhai Shah
presided over an extortion racket. In his capacity as the minister for Home, he was in a position to
place his henchmen, top ranking policemen at positions where they could sub-serve and safeguard
his interests. He was part of the larger conspiracy to kill Sohrabuddin and later on his wife and
finally Tulsiram Prajapati, as he was a witness to the abduction of Sohrabuddin and his wife by the
police party. Taking advantage of his position as the minister, he constantly obstructed any proper
investigation into the killings of Sohrabuddin and Kausarbi even when the matter came to the notice
of this Court and this Court issued directions for a thorough investigation into their killings. It was
at his behest and under his pressure that the top ranking police officers tried to cover up all signs of
his involvement in the killings of Sohrabuddin, Kausarbi and Tulsiram Prajapati and systematically
suppressed any honest investigation into those cases and even tried to mislead this Court. Even after
the investigation was handed over to the CBI, he made things very difficult for them and the CBI was
able to do the investigation against great odds. It is further submitted that the phone records
pertaining to the periods when Sohrabuddin and his wife were abducted, Sohrabuddin was killed
and his wife was killed and her body was disposed of by burning and of the later period at the time
of killing of Prajapati showed Amitbhai Shah in regular touch with the policemen, accused in the
case, who were actually executing the killings and the other allied offences. There was no reason for
the minister for State of Home to speak directly on phone to police officers, far below him in the
chain of command and the explanation given on his behalf in regard to those phone calls was on the
face of it false and unacceptable. Apart from the phone records, there were many other materials
and incontrovertible circumstances to establish the charges against Amitbhai Shah.
27. It was submitted that his release on bail and permission to freely stay in Gujarat would greatly
jeopardize the efforts of the CBI to bring home the charges against him. Even after his arrest and
while in jail, he had sufficient resources and influence to tamper with the evidence and to intimidate
the prosecution witnesses. It was contended that allowing the appellant to enjoy the privilege of bail
and further to let him stay in Gujarat would have a very debilitating effect on the prosecution case. It
was further contended that apart from Amitbhai Shah, some of the other accused in the case were
senior police officers with great clout and resourcefulness and they were fully capable of subverting
a fair trial in Gujarat.Central Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

28. Mr. Ram Jethmalani, senior advocate appearing for Amitbhai Shah submitted, with equal force,
that the allegations made by the CBI against his client were no more than a pack of lies. He
submitted that the direction of this Court handing over the investigation of the Sohrabuddin case to
the CBI gave a handle to the Central Government to wreck political vendetta on the democratically
elected Government in Gujarat. He further submitted that the CBI was being used in this case to
frame up his client in a completely false case. He contended that the Gujarat Police had made a
proper investigation but the CBI put the charge-sheet submitted by the Gujarat Police in this case
upside-down. It forged and fabricated evidences against Amitbhai Shah and set-up an entirely false
case against him. He also submitted that the High Court had rightly granted bail to Amitbhai Shah
and there was no reason for this Court to cancel it.
29. At this stage, we do not wish to express any opinion on the submissions made from the two sides
lest any remark made in the order might cause prejudice to either the accused or the prosecution in
the trial. However, on hearing Mr. Tankha for the CBI, Mr. Ram Jethmalani, senior advocate for
Amitbhai Shah, Mr. Huzefa Ahmadi, for the writ petitioner Rubabbuddin Sheikh and Mr. Gopal
Subramanium, learned Amicus Curiae, we are not inclined to cancel the bail granted to Amitbhai
Shah about two years ago. Had it been an application for grant of bail to Amitbhai Shah, it is hard to
say what view the Court might have taken but the considerations for cancellation of bail granted by
the High Court are materially different and in this case we feel reluctant to deprive Amitbhai Shah of
the privilege granted to him by the High Court.
30. However, the apprehension expressed by the CBI that Amitbhai Shah may misuse the freedom
and try to subvert the prosecution cannot be lightly brushed aside. We, accordingly, direct that
Amitbhai Shah (respondent No.1 in criminal appeal) shall give an undertaking in writing to the trial
court that he would not commit any breach of the conditions of the bail bond and would not try to
influence any witnesses or tamper with the prosecution evidence in any manner. We further direct
that Amitbhai Shah will report to the CBI office every alternate Saturday at 11.00 AM. It is further
made clear that the grant of bail to Amitbhai Shah in the Sohrabuddin case shall have no effect in
the Prajapati case and in that case whether Amitbhai Shah is to be kept in judicial custody or
granted bail would be decided by the court on the basis of the materials on record of that case and
without taking into consideration the grant of bail to him in the Sohrabuddin case.
31. The grant of bail to Amitbhai Shah in Sohrabuddin case shall be no consideration for grant of
bail to the other accused in that case and the prayer for bail by the other accused in the Sohrabuddin
case shall be considered on its own merits.
32. In case Amitbhai Shah commits any breach of the conditions of the bail bond or the undertaking
given to the court, as directed above, it will be open to the CBI to move the trial court for
cancellation of his bail. In that case, if the allegations pertain to the period posterior to this order,
the trial court shall examine the matter carefully and take an independent decision without being
influenced by this order declining to cancel the bail granted to him.
33. Coming now to the question of transferring the case outside Gujarat, the manner in which the
Sohrabuddin case has proceeded before this Court in itself, without anything else, makes out aCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

strong case for transferring the trial of the case outside the State. It is also noted above that Mr.
Jethmalani made the declaration that his client is prepared to face the trial at any place and
wherever the trial is held he would expose the falsity of the CBI case. However, the State and a
number of other accused were strongly opposed to the transfer of the case outside the State for trial.
On behalf of CBI, on the other hand, it was contended that there was hardly any hope of any fair trial
of the case in that State.
34. At this stage, we may note an episode in the proceedings before the magistrate that is cited by
the CBI as one of the grounds in support of its prayer for the transfer of the case outside the State.
On July 26, 2010, one of the accused N.K. Amin filed a petition before the ACJM under section 306
of the Code of Criminal Procedure for grant of pardon and for being considered as an approver. In
the application he stated that he desired to give statement/evidence about the facts within his
knowledge concerning the offence for which he was being prosecuted and further that he was ready
and willing to give his statement under section 164(2) [sic (5)] so as to become an approver in the
case. The magistrate did not pass any order on that application but strangely gave its notice to other
accused in the case. The other accused took time to file their responses until the magistrate referred
the matter to the High Court under section 395 of the Code of Criminal Procedure after almost five
weeks of the filing of the petition. The reference was eventually dismissed by the High Court as
incompetent. In the meanwhile, on August 21, 2010, Smt. Jayshree Amin, the wife of N.K. Amin
filed a complaint to the CBI alleging threats to her husband’s life in Sabarmati jail. The CBI duly
forwarded the letter received from Smt. Jayshree Amin to the ACJM but no action was taken on that
letter. N.K. Amin finally filed a petition on January 18, 2011 requesting the ACJM not to pass any
order on his application under section 306(Exh.8) and section 164(5) (Ex.49). In this petition, he
made the complaint that on his application under section 306 the court did not pass any order but
delayed the matter by giving the other accused time for filing their objection. As a result there was
grave threat to his life in the jail. In any event, after he received a copy of the charge-sheet filed by
the CBI and found that in that charge-sheet three other policemen (namely, Ajay Parmar, Santaram
Chandrabhan Sharma and Vijay Arjunbhai Rathod) were not arrayed as accused, he had, for the
time being, decided not to make any statement before the court keeping his options open after the
case is committed to the court of sessions.
35. On behalf of the CBI, it is submitted that on receiving the application from N.K. Amin the
learned magistrate adopted a procedure unknown to law but that gave sufficient time to the other
accused to win back N.K. Amin over to their side by giving him intimidations and/or inducements.
36. In the counter affidavit filed on behalf of the State and N.K. Amin a number of accusations are
made against the CBI on this issue. It is evident that since filing the application for being made an
approver in the case, N. K. Amin has changed his mind (to which he is fully entitled). But the fact of
the matter is that both the petitions dated July 26, 2010 and January 18, 2011 filed by him before
the ACJM and the orders passed by the learned magistrate on those petitions are part of the judicial
record and cannot be simply denied away.
37. Besides the above there are other instances as would appear from the proceedings in the
Sohrabuddin case when this Court had reasons not to feel entirely happy at the way the courts belowCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

dealt with the matter.
38. On hearing Mr. Tankha, appearing for the CBI, Mr. Ahmadi representing the writ petitioner, Mr.
Tushar Mehta appearing on behalf of the State of Gujarat, and the counsel appearing for the
different accused and Mr. Subramanium, the learned amicus, and on a careful consideration of all
the material facts and circumstances as also having regard to the past experience in the
Sohrabuddin matter, we are convinced that in order to preserve the integrity of the trial it is
necessary to shift it outside the State.
39. The decision to transfer the case is not a reflection on the State judiciary and it is made clear that
this Court reposes full trust in the judiciary of the State. As a matter of fact, the decision to transfer
the case outside the State is intended to save the trial court in the State from undue stress and to
avoid any possible misgivings in the minds of the ordinary people about the case getting a fair trial
in the State.
40. In Nahar Singh Yadav and another v. Union of India and others[3], this Court on a
consideration of the earlier decisions laid down certain conditions which may require a case to be
transferred outside the State. In paragraph 29 of the decision it observed as follows-
“Thus, although no rigid and inflexible rule or test could be laid down to decide whether or not
power under Section 406 CrPC should be exercised, it is manifest from a bare reading of
sub-sections (2) and (3) of the said section and on an analysis of the decisions of this Court that an
order of transfer of trial is not to be passed as a matter of routine or merely because an interested
party has expressed some apprehension about the proper conduct of a trial. This power has to be
exercised cautiously and in exceptional situations, where it becomes necessary to do so to provide
credibility to the trial. Some of the broad factors which could be kept in mind while considering an
application for transfer of the trial are:
(i) when it appears that the State machinery or prosecution is acting hand in glove
with the accused, and there is likelihood of miscarriage of justice due to the
lackadaisical attitude of the prosecution;
(ii) when there is material to show that the accused may influence the prosecution
witnesses or cause physical harm to the complainant;
(iii) comparative inconvenience and hardships likely to be caused to the accused, the
complainant/the prosecution and the witnesses, besides the burden to be borne by
the State exchequer in making payment of traveling and other expenses of the official
and non-
official witnesses;
(iv) a communally surcharged atmosphere, indicating some proof of inability of holding fair and
impartial trial because of the accusations made and the nature of the crime committed by theCentral Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

accused; and
(v) existence of some material from which it can be inferred that some persons are so hostile that
they are interfering or are likely to interfere either directly or indirectly with the course of justice.”
We find that the conditions at serial numbers (1), (2), (3) and (5) are squarely attracted in this case.
41. In another decision in Ravindra Pal Singh v. Santosh Kumar Jaiswal and others[4], this Court
directed for transfer of the case outside State because some of the accused in a case of fake
encounter were policemen. The case in hand has far more stronger reasons for being transferred
outside the State. We, accordingly, direct for the transfer of Special Case No.05/2010 pending in the
court of Additional Chief Metropolitan Magistrate, CBI, Court Room No.2, Mirzapur, Ahmedabad
titled CBI versus D.G. Vanzara & Others to the court of CBI, Bombay. The Registrar General of the
Gujarat High Court is directed to collect the entire record of the case from the court of Additional
Chief Metropolitan Magistrate, CBI, Room No.2, Mirzapur, Ahmedabad and to transmit it to the
Registry of the Bombay High Court from where it would be sent to a CBI court as may be decided by
the Administrative Committee of the High Court. The Administrative Committee would assign the
case to a court where the trial may be concluded judiciously, in accordance with law, and without
any delay. The Administrative Committee would also ensure that the trial should be conducted from
beginning to end by the same officer.
42. On behalf of the CBI, it was stated that they need six weeks’ further time to complete the
investigation. They are directed to positively complete the investigation within six weeks and submit
the final charge- sheet before the transferee court in Mumbai.
43. The Sohrabuddin case stands transferred to Mumbai by this order. It is the case of the CBI that
the case of Sohrabuddin and the case of Tulsiram Prajapati are closely connected and in order to
avoid any miscarriage of justice, both the cases can only be tried before the same court. It will,
therefore, be open to the CBI to make an application for transfer of the Tulsiram Prajapati case also
to the same court where the Sohrabuddin case is transferred. In case, such an application is filed,
the court will pass appropriate orders, in accordance with law, after hearing all concerned.
44. In the result, the appeal is dismissed but the transfer petition is allowed.
…………………………….J. (Aftab Alam) …………………………….J. (Ranjana Prakash Desai) New Delhi;
September 27, 2012.
-----------------------
[1]    (2010) 2 SCC 200
[2]    (2011) 5 SCC 79
[3]    (2011) 1 SCC 307
[4]    (2011) 4 SCC 746
-----------------------Central Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

Central Bureau Of Investigation vs Amitbhai Anil Chandra Shah And Anr on 27 September, 2012

