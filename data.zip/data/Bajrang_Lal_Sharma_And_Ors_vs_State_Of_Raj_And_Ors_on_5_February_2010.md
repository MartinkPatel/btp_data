Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5
February, 2010
 IN THE HIGH COURT OF JUDICATURE FOR RAJASTHAN
AT JAIPUR BENCH, JAIPUR
::J U D G M E N T::
1. D.B. CIVIL SPECIAL APPEAL (WRIT) No.618/2009
  (State of Rajasthan & Anr.Vs.Bajrang Lal                                                            Sharma & Ors.)
2. D.B. CIVIL SPECIAL APPEAL (WRIT)No.3/2010
  (Suraj Bhan Meena Vs.Bajrang Lal Sharma & Ors.)
3. D.B. CIVIL SPECIAL APPEAL (WRIT) No.611/2009
  (State of Rajasthan Vs. Gyan Prakash Shukla)
4. D.B. CIVIL SPECIAL APPEAL (WRIT) NO.610/2009
  (State of Rajasthan Vs. M.M. Joshi)
5. D.B. CIVIL WRIT PETITION No.8104/2008
  (Bajrang Lal Sharma & Ors.Vs.State of Raj.& Ors.)
6. D.B. CIVIL WRIT PETITION No.6241/2008
 (Gyan Prakash Shukla & Anr.Vs.State of Raj.&                                                                   Ors.)
7. D.B. CIVIL WRIT PETITION NO.7775/2009
  (M.M. Joshi Vs. State of Rajasthan & Ors.)
Date of Judgment    ::     05th February, 2010.
P R E S E N T
HON'BLE MR.JUSTICE NARENDRA KUMAR JAIN
 HON'BLE MR.JUSTICE RAGHUVENDRA S. RATHORE
Mr.Sanjeev Prakash Sharma with
Mr.Shobhit Tiwari for Bajrang Lal Sharma & Others.
Mr. Ashok Gaur for Suraj Bhan Meena.
Mr. R.C. Joshi for M.M. Joshi.
Mr. S.C. Gupta for Gyan Prakash Shukla & Anr.
Mr. H.P. Verma for Sriram Choradia.
Mr. G.S. Bapna, Advocate General,
Mr. S.N. Kumawat, Additional Advocate General for the State of Rajasthan.
Mr. Sushil Sharma for the Union of India.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Mr. Sanjay Pareek for the UPSC.
***
By the Court : (Per N.K. Jain,J.)
Reportable
1. D.B. Civil Special Appeal (Writ) No.618/2008, State of Rajasthan & Anr. Vs. Bajrang Lal Sharma
& Ors. is directed against the order dated 09.07.2009 passed by the learned Single Judge on two
applications under Article 226(3) of the Constitution of India i.e.S.B. Civil Misc. Applications
No.8046/2009 and 6550/2009 in S.B. Civil Writ Petition No.8104/2008, whereby both the
applications were dismissed and the ad-interim ex-parte stay order dated 22.8.2008 was confirmed
till the disposal of the writ petition.
2. On 27.7.2009, the said special appeal was listed before the Division Bench presided by the then
Hon'ble Acting Chief Justice, and it was directed that appeal be listed on 29.7.2009 alongwith the
appeals No.05313/2009, 610/2009, 611/2009 & 612/2009 and writ petition 8157/2009. The above
cases were listed on 20.10.2009 and the Division Bench passed an order that, as suggested and
agreed by both the parties, the registry is directed to list the writ petitions as well as the special
appeals (14 in number), as mentioned in the order. Again on 26.10.2009, the Division Bench passed
an order to list the cases alongwith the connected matters, as mentioned in the order. Thereafter,
the matters were listed on 4.12.2009, and on that date, one of the member of Division Bench made
an exception, therefore, the matters were put up before Hon'ble the Chief Justice on 17.12.2009,
who constituted this Bench for hearing the above matters as well as other connected matters, as
mentioned in the note-sheet of the registry. In these circumstances, these matters have come up
before us for hearing.
3. We have heard the learned counsel for the parties and examined the record.
4. Since common questions of fact and law are involved in these matters, therefore, they are being
disposed of by this common order.
5. Since the writ petitions as well as special appeals have been tagged together and writ petition
No.8104/2008 is the main case, therefore, we are referring the facts of the said writ petition.
6. Petitioners No.1 to 10, who are members of the Rajasthan Administrative Service, have preferred
this writ petition under Article 226 of the Constitution of India challenging the Notification dated
25.4.2008 (Annexure-14), whereby the Government of Rajasthan, while exercising powers conferred
by the proviso to Article 309 of the Constitution of India, amended the Rajasthan Various Service
Rules, (hereinafter referred to as 'the Various Service Rules'), as mentioned in the Schedule
appended therewith with effect from 28.12.2002, whereby the following existing proviso to the rule,
as mentioned in Column No.3 against each of the Service Rules (110 in number), listed in Column
No.2 of the said Schedule, has been deleted:-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Provided that a candidate who has got the benefit of proviso inserted vide
Notification No.F.7 (1) DOP/A-II/96 dated 01.04.1997 on promotion to an immediate
higher post shall not be reverted and his seniority shall remain uneffected. This
proviso is subject to final decision of the Hon'ble Supreme Court of India in Writ
Petition (Civil) No.234/2002 All India Equality Forum V/s Union of India & Others.
7. The petitioners have also prayed; to issue appropriate writ directing the respondents to strictly
adhere to the catch-up rule and revise the seniority of all the petitioners in comparison to the
candidates belonging to Scheduled Castes and Scheduled Tribes (for short' the SCs and the STs)
after giving the benefit of regaining of the seniority by the general/OBC category candidates as
envisaged by the Notification dated 1.4.1997 (Annexure-3) and provisional seniority list dated
26.6.2000 of Selection Scale of the RAS (Annexure-4); to restrain the respondents from providing
the consequential seniority to the candidates belonging to the SCs and the STs as the Rajasthan
Administrative Service Rules, 1954 (hereinafter referred to as 'the RAS Rules) were not framed in
pursuance of Article 16(4-A) of the Constitution of India. In the alternative, if Rule 33 of the RAS
Rules talks about giving benefit of consequential seniority then that rule may be declared
unconstitutional to the extent it provides consequential seniority to the employees of the SC and the
ST category.
8. The petitioners have given the facts in respect of petitioner No.1 Bajrang Lal Sharma, respondent
No.3 Suraj Bhan Meena and respondent No.4 Sriram Choradia.
9. It is pleaded that petitioner No.1, respondent No.3 and respondent No.4 were inducted in the
Rajasthan Administrative Service in December 1982 through selection by the Rajasthan Public
Service Commission. The respondent-State issued a provisional seniority list of Rajasthan
Administrative Service (R.A.S.) Selection Scale vide notice dated 26.6.2000 as on 1.4.1997, wherein
petitioner No.1 Bajrang Lal was placed at Serial No.129 whereas the names of respondents No.3 and
4 namely, Suraj Bhan Meena (ST) and Sriram Choradia (SC) were placed at Serial No.142 and 147
respectively. This seniority list was issued in pursuance of order of the Hon'ble Apex Court dated
16.9.1999 in the case of Ajit Singh -II Vs. State of Punjab, (1997) 7 SCC 209 and another order of the
Hon'ble Apex Court dated 16.9.1999 in the case of Ram Prasad Vs. D.K. Vijay, (1999) 7 SCC 251 and
other judgments of the Rajasthan High Court/Appellate Tribunal and circulars of Department of
Personnel (DOP). Again a provisional seniority list was issued on 27.11.2003 and 12.5.2008. Now,
the Government of Rajasthan has published the final seniority lists of Super Time Scale and
Selection Scale of the RAS on 24.6.2008 as on 1.4.2007 (Annexure-1) and provisional seniority list
dated 02.07.2008 as on 1.4.2008 (Annexure-2), wherein names of petitioner No.1 and respondents
No.3 and 4 have been mentioned as under:-
Petitioner No.1 (Bajrang Lal Sharma) :
Seniority Lists dated :
24.6.2008 at S.No.170 as on 01.04.1997(Selection Scale) 02.7.2008 at S.No.107 as on
01.04.2008(Selection Scale) He was given the benefit of Selection Scale against theBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

vacancy of the year 1994-95.
Respondent No.3 (Suraj Bhan Meena) :
Seniority Lists dated:
24.6.2008 at S.No.72 as on 1.4.1997(Selection Scale) 02.7.2008 at S.No.34 as on
1.4.2008(Super Time Scale) He was given the benefit of Selection Scale against the
vacancy of the year 1991-92 and Super Time Scale in the year 2005-06.
Respondent No.4 (Sriram Choradia) :
Seniority List dated :
24.6.2008 at S.No.101 as on 1.4.1997(Selection Scale) 2.7.2008 at S.No.53 as on
1.4.2008 (Selection Scale) He was given the benefit of Selection Scale against the
vacancy of the year 1992-93.
10. Shri Sanjeev Prakash Sharma, the learned counsel for the petitioners argued that the impugned
Notification dated 25.4.2008 is illegal on two counts. First, is that the proviso dated 28.12.2002
which was added in the Various Service Rules, was subject to the final decision of the Hon'ble
Supreme Court in Writ Petition (Civil) No.234/2002 (All India Equality Forum V/s Union of India &
Others) but the said writ petition (Civil) No.234/2002 has not been decided finally so far by the
Hon'ble Supreme Court vide order dated 19.10.2006. Therefore, during pendency of the said writ
petition before the Hon'ble Apex Court, it was not proper for the respondents to delete the proviso
in the Various Service Rules including the RAS Rules. Secondly, the deletion of the proviso in the
Various Service Rules vide the Notification dated 25.4.2008, amounts to giving consequential
seniority to the candidates belonging to the SCs and the STs, which could not have been given
without collecting the required quantifiable data to reach to a conclusion that reservation is required
in promotion and to show that the State was having any compelling reason, namely, backwardness,
inadequacy of representation and that it would not cause any overall administrative efficiency before
providing reservation in promotion with consequential seniority, as held by the Hon'ble Supreme
Court in the case of M.Nagaraj & Ors. Vs. Union of India & Ors., reported in (2006) 8 SCC 212. Since
the State Government has not complied with the direction of the Hon'ble Supreme Court before
issuing the impugned Notification dated 25.4.2008, therefore, the said notification is liable to be
quashed being violative of the directions of the Hon'ble Apex Court in M.Nagaraj's case (supra).
11. Mr. Sharma further argued that the Hon'ble Supreme Court in the case of Indra Sawhney & Ors.
Vs. Union of India & Ors, reported in 1992 Supp.(3) SCC 217, has held that Article 16(4) of the
Constitution does not permit reservations in the matter of promotion. Thereafter, the Constitution
(Seventy-Seventh Amendment) Act, 1995 came into force on 17.6.1995. Later on, the Hon'ble
Supreme Court in the cases of Union of India & Ors. Vs. Virpal Singh Chauhan & Ors., reported in
(1995) 6 SCC 684, Ajit Singh Januja & Ors. (Ajit Singh-I) Vs. State of Punjab & Ors., reported in
(1996) 2 SCC 715 and Ajit Singh (II) & Ors. Vs. State of Punjab & ors., reported in (1999) 7 SCC 209,Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

introduced the catch-up rule and held that if the senior general candidate is promoted then he will
regain his seniority on promotion post above junior reserved promotees. It was also held that
consequential seniority on promotion post is not covered by Article 16(4A). The State Government
also added the similar 'proviso' vide Notification dated 1.4.1997 at the next serial number in the
Various Service Rules including the Rajasthan Administrative Service Rules.
12. The Parliament, in its wisdom, further amended the Constitution on 4.1.2002 by way of 'The
Constitution (Eighty-Fifth Amendment) Act, 2001', to give the benefit of consequential seniority to
reserved category candidates with effect from 17.6.1995. The constitutional validity of both the
aforesaid Constitution Amendment Acts was challenged before the Hon'ble Supreme Court in
number of writ petitions including writ petitions filed by M.Nagaraj and All India Equality Forum
and during pendency of the writ petition before the Hon'ble Apex Court, an interim order was
passed protecting the promotion and seniority of general/OBC category candidates during pendency
of the writ petition. The Government of Rajasthan while deleting the proviso added vide the
Notification dated 1.4.1997, inserted the new proviso vide the Notification dated 28.12.2002.
13. The Hon'ble Apex Court in M.Nagaraj's case on 19.10.2006, while upholding the constitutional
validity of the Constitution (Seventy-Seventh Amendment) Act, 1995 and the Constitution
(Eighty-Fifth Amendment) Act, 2001, made it clear that it will not be necessary for the State
Government to frame rule in respect of reservation in promotion with consequential seniority, but in
case the State Government is willing to frame the rule in this regard then it has to satisfy, by
quantifiable data, that there is backwardness, inadequacy of representation in public employment
and overall administrative efficiency, and unless that exercise is done by the State Government, the
rule relating to reservation in promotion with consequential seniority, cannot be introduced.
14. Mr. Sharma further contended that if the State Government was willing to frame rule in this
regard then the same could have been done after doing necessary exercise, by collecting quantifiable
data and forming an opinion that there is backwardness, inadequacy of representation in public
employment and overall administrative efficiency, as observed by the Hon'ble Supreme Court
M.Nagaraj's case(supra). But what the State has done in the present case is that they have deleted
the 'proviso' which was inserted on 1.4.1997 on the basis of catch-up rule vide Notification dated
28.12.2002 and further deleted the new 'proviso' added on 28.12.2002 vide Notification dated
25.4.2008 in Various Service Rules of the State. The net result of it is that the State Government has
provided consequential seniority to the SCs and the STs, without undergoing any exercise in respect
of three conditions as laid down in the judgment of the Hon'ble Apex Court in M.Nagaraj's
case(supra).
15. In these circumstances, the impugned Notification dated 25.4.2008 is liable to be declared as
ultra vires to the provisions of the Constitution of India as well as contrary to the judgment of the
Hon'ble Apex Court in M.Nagaraj's case(supra).
16. The next submission of Mr. Sharma is with regard to the wrongful seniority list published inspite
of their being a judgment passed by Division Bench of this Court in the case of B.K. Sharma & Anr.
Vs. State of Rajasthan & Ors., reported in WLC (Raj.) 1998 (2) 583 and the judgment of the Hon'bleBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Apex Court in the case of Ram Prasad & Ors. Vs. D.K. Vijay & Ors., reported in (1999) 7 SCC 251. It
is submitted that combined seniority list of the RAS cadre was published by the State Government
on 22.4.1995 which carried names of the petitioners alongwith other RAS officers; the same was
quashed by the High Court, and it was held that Rule 33 of the RAS Rules nowhere provides for
consequential seniority to reserved category promotees. Thus after the judgments in B.K. Sharma's
and Ram Prasad's cases (supra), the consequential seniority could not have been assigned to
reserved promotees above the senior general/OBC persons. After the judgment in Ram Prasad's case
(supra) by the Hon'ble Apex Court, a vested right was created of having seniority over all reserved
category persons by general category persons as per interpretation of Rule 33 of the RAS Rules. Rule
33 has not been amended thereafter except to withdraw the notifications dated 1.4.1997 and
28.12.2002. He, therefore, contended that vested or accrued rights in the matters of promotion,
seniority, substantive appointments etc. of the employees cannot be taken back retrospectively. Such
an act of the State Government is arbitrary, discriminatory and violative of the rights guaranteed
under Articles 14 and 16 of the Constitution of India.
17. Mr. R.C. Joshi, the learned counsel appearing on behalf of the petitioners contended that he has
challenged both the notifications i.e.28.12.2002 and 25.4.2008 in writ petitions No.7774/2009 and
7775/2009. He contended that so far as argument with regard to notification dated 25.4.2008 is
concerned, Mr. Sanjeev Prakash Sharma has already argued the case at length, and he adopts his
arguments. So far as notification dated 28.12.2002 is concerned, he contended that this notification
is also illegal and violative of Articles 14 and 16 of the Constitution. By way of the Constitutional
(Seventy-Seventh Amendment) Act, 1995, an enabling provision with regard to accelerated
promotion was made by inserting the words reservation in promotion in clause (4A) in Article 16 of
the Constitution which was considered and it was clarified by the Hon'ble Apex Court in the cases of
Union of India Vs. Virpal Singh Chauhan's case (supra) as well as Ajit Singh-I (supra) that the
reserved promotees be entitled for accelerated promotion, but they will not be entitled to get
accelerated seniority. The same view was further taken by the Constitution Bench of the Hon'ble
Apex Court on 16.9.1999 while deciding Ajit Singh-II case. In view of the judgment delivered in
Virpal Singh Chauhan's case (supra) and further in the case of Ajit Singh -I, the State Government
vide Notification dated 1.4.1997 inserted the new proviso in Various Service Rules, as mentioned in
the said notification, whereby benefit of regaining seniority was given to General/OBC candidates
above such earlier promoted candidates of the SC/ST in the immediate higher post/grade.
Subsequently, The Constitution (Eighty-Fifth Amendment) Act, 2001 was passed on 4.1.2002 with
effect from 16.9.1995 with regard to consequential seniority to reserved promotees. The number of
writ petitions were filed before the Hon'ble Apex Court challenging the constitutional validity of The
Constitution (Seventy-Seventh Amendment) Act,1995 as well as The Constitution (Eighty-Fifth
Amendment) Act,2001. The interim order was passed by the Hon'ble Apex Court in M.Nagaraj's
case(supra) as well as in the case of All India Equality Forum Vs. Union of India that the
general/OBC candidates who have already been promoted, they will not be reverted and their
seniority will not be disturbed. Vide the Constitution (Eighty-Fifth Amendment) Act, the words with
consequential seniority was inserted in clause (4A) of Article 16 of the Constitution after the words
reservation in promotion, but it was only an enabling provision and the said amendment was under
challenge before the Hon'ble Apex Court. The matter was subjudice before the Hon'ble Apex Court
and during that period itself,without waiting for the decision of the Apex Court in M.Nagaraj's caseBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

and in the case of All India Equality Forum Vs.Union of India, the State Government wrongly
withdrew earlier notification dated 1.4.1997 vide Notification dated 28.12.2002. Now the Hon'ble
Apex Court in M.Nagaraj's case vide judgment dated 19.10.2006 while upholding the constitutional
validity of the Constitution (Eighty-Fifth Amendment) Act, has made it mandatory on the part of the
State Government to go for three exercises, as mentioned in the judgment in case any rule is to be
framed by the State for reservation in promotion with consequential seniority. Admittedly, no
exercise was done by the State Government before amending the Various Service Rules including
the RAS Rules vide Notification dated 28.12.2002, and therefore, it is liable to be quashed.
18. Apart from the above, he further contended that proviso introduced vide notification dated
1.4.1997 had already been upheld and the rights of number of persons belonging to the general/OBC
category regarding their regaining seniority above their junior reserved promotees had already been
upheld by the Division Bench of this Court in B.K. Sharma's case (supra) and by the Hon'ble Apex
Court in the case of Ram Prasad Vs. D.K. Vijay (supra). Therefore, the Notification dated 28.12.2002
whereby earlier proviso introduced vide Notification dated 1.4.1997 has been withdrawn,
tantamount to negativing the judgment of the Division Bench of this Court in B.K. Sharma's case
(supra) and the judgment of the Hon'ble Apex Court in the case of Ram Prasad Vs. D.K. Vijay
(Supra). He, therefore, contended that the Notification dated 28.12.2002 is also liable to be quashed
by this Court.
19. Learned counsel for the petitioners, in support of their submissions, referred to the judgment of
the Hon'ble Apex Court in the cases of M.Nagaraj & Ors. Vs. Union of India, (2006) 8 SCC 212;
Indra Sawhney & Ors. Vs. Union of India & Ors., 1992 Supp.(3) SCC 217; Union of India & Ors. Vs.
Virpal Singh Chauhan & Ors., (1995) 6 SCC 684; Ajit Singh Juneja (Ajit Singh-I) & Ors. Vs. State of
Punjab & Ors., (1996) 2 SCC 715; Ajit Singh (II) & Ors. Vs. State of Punjab & Ors.,(1997) 7 SCC 209;
Ram Prasad & Ors. Vs. D.K. Vijay & Ors, (1999) 7 SCC 251; Anil Chandra & Ors. Vs. Radha Krishna
Gaur & Ors., (2009) 9 SCC 454; R.K. Sabharwal & Ors. VS. State of Punjab & Ors., (1995) 2 SCC 745;
State of Bihar & Anr. Vs. Bal Mukund Sah & Ors, (2000) 4 SCC 640; Andhra Pradesh Public Service
Commission Vs. Baloji Badhavath & Ors., (2009) 5 SCC 1; M.G. Badappanavar & Anr. Vs. State of
Karnataka & Ors., (2001) 2 SCC 666; D.P. Sharma & Ors. Vs. Union of India & Anr, 1989 Supp.(1)
SCC 244; Chairman, Railway Board & Ors. Vs. C.R. Rangadhamaiah & Ors., (1997) 6 SCC 623; S.S.
Bola & Ors. Vs. B.D. Sardana & Ors., (1997) 8 SCC 522; Rajesh Kumar Gupta & Ors. Vs. State of U.P.
& Ors., AIR 2005 SC 2540; Arun Tewari & Ors. Vs. Zila Mansavi Shikshak Sangh & Ors., AIR 1998
SC 331; Tridip Kumar Dingal & Ors. Vs. State of West Bengal & Ors., (2009) 1 SCC 768; the
judgment of the Division Bench of this Court in the case of B.K. Sharma & Anr. Vs. State of
Rajasthan & Ors., WLC (Raj.) 1998 (2) 583 and the judgment of the Himachal Pradesh High Court
in the case of Himachal Pradesh Samanaya Varg Karamchari Kalayan Mahasangh Vs. State of
Himachal Pradesh & Ors.(CWP-T No.2628 of 2008 decided on 18.9.2009).
20. Shri G.S. Bapna, the learned Advocate General contended that the State Government is
empowered under proviso to Article 309 of the Constitution to frame, amend, add or delete any rule
subject to constitutional limitations, which have not been breached in the present case. Although the
Constitution (Seventy-Seventh Amendment) Act, 1995 came into force on 17.6.1995, but in the cases
of Virpal Singh Chouhan (supra) and Ajit Singh-I (supra), the Hon'ble Apex Court held that if theBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

senior and general category candidate is promoted then he will regain his seniority on promotion
post above junior reserved promotees. It was also held that consequential seniority on promotion
post is not covered by Article 16(4A). The State Government, therefore, added similar rule in
Various Service Rules including the RAS Rules vide Notification dated 1.4.1997. However, the
Constitution (Eighty-Fifth Amendment) Act, 2001 came on 4.1.2002 with effect from 17.6.1995. The
number of writ petitions were preferred before the Hon'ble Supreme Court challenging the
constitutional validity of the Constitution (Seventy-Seventh Amendment) Act, 1995 and the
Constitution (Eighty-Fifth Amendment) Act, 2001, wherein interim order was passed that the
general/OBC persons who have already got the benefit of promotion will not be reverted and their
seniority shall remain unaffected. The respondents, therefore, deleted the proviso from the Various
Service Rules, which were added on 1.4.1997 and added new proviso under Various Service Rules
vide Notification dated 28.12.2002, which was in consonance with the interim order passed by the
Hon'ble Apex Court.
21. Now, the Hon'ble Apex Court upheld the constitutional validity of both the Amendments
inserted in the Constitution vide order dated 19.10.2006 in M.Nagaraj's case (supra). Therefore,
while exercising the powers under proviso to Article 309 of the Constitution, the State Government
vide its Notification dated 25.4.2008, deleted the proviso added vide Notification dated 28.12.2002
in Various Service Rules. Since the State Government is empowered to add or delete any rule, there
is no illegality in issuing the Notification dated 25.4.2008. It is within competence of the State
Government to add or delete any rule and the State Government has exercised its powers. The
legislative competence of the State cannot be allowed to be challenged.
22. He further contended that although a seniority list dated 26.6.2000 was issued on the basis of
judgment of the Hon'ble Apex Court dated 16.9.1999 in the case of Ajit Singh Juneja Vs. State of
Punjab (supra) and order dated 16.9.1999 in the case of Ram Prasad Vs. D.K. Vijay (supra), but no
person belonging to RAS was promoted on that basis till issuance of Notification dated 28.12.2002.
Therefore, no right vested in any of the petitioners which can be said to have been taken away vide
Notification dated 25.4.2008. He contended that seniority is not a fundamental right and if position
of petitioner is changed in seniority list on the basis of impugned notification then the same cannot
be said to be taking away the vested or accrued right. The petitioners cannot compel the State
Government to keep any rule on the statute. The respondents have not done anything vide
Notification dated 25.4.2008 except deleting the proviso added vide Notification dated 28.12.2002.
23. He further argued that three exercises which are required to be carried out as held by the
Hon'ble Apex Court in M.Nagaraj's case (supra) before framing any rule, are to be carried out only
in matters relating to 'reservation in promotion' and not with regard to 'consequential seniority'. The
action of the respondents is, therefore, not violative of the ratio laid down by the Hon'ble Apex Court
in M.Nagaraj's case (supra). The forming of opinion by the State Government that the SCs and the
STs are adequately represented or not has to be made at the time of providing reservation in
promotion and not for consequential seniority. The respondents issued a notification providing
reservation to SC & ST classes way back on 10.2.1975 in promotion.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

24. He further contended that the judgment delivered by the Hon'ble Apex Court in Indra Sawhney's
case (supra) was negatived by the Constitution (Seventy-Seventh Amendment) Act, 1995 and the
judgments of the Hon'ble Apex Court delivered in the cases of Virpal Singh Chouhan (supra) and
Ajit Singh -I (supra) were negatived by the Constitution (Eighty-Fifth Amendment) Act, 2001. The
impugned notifications are in accordance with the provisions of the Constitution, and therefore, the
same cannot be declared ultra vires to the Constitution by this Court.
25. He further contended that there is a provision for consequential seniority in Rule 33 of the RAS
Rules, therefore, reserve category candidates are entitled for consequential seniority as per Rule 33
itself. However, he admitted that after the judgment delivered by the Hon'ble Apex Court in
M.Nagaraj's case, Rule 33 has not been amended providing reservation in promotion with
consequential seniority to SC/ST candidates. He also admitted that no exercise with regard to three
conditions laid down by the Hon'ble Apex Court in M.Nagaraj's case has been done before issuing
notifications dated 28.12.2002 and 25.4.2008. His explanation is that the said exercise is required
for reservation in promotion and not for consequential seniority. He, therefore, contended that
there is no merit in the writ petition and the same is liable to be dismissed.
26. Learned Advocate General appearing on behalf of the State, in support of his submissions,
referred to the judgment of the Hon'ble Apex Court in the cases of Indra Sawhney & Ors. Vs. Union
of India & Ors., 1992 Supp.(3) SCC 217; M.Nagaraj & Ors. Vs. Union of India (2006) 8 SCC 212;
Union of India & Ors. Vs. Virpal Singh Chauhan & Ors., (1995) 6 SCC 684; Ajit Singh Juneja (Ajit
Singh-I) & Ors. Vs. State of Punjab & Ors., (1996) 2 SCC 715; Ajit Singh (II) & Ors. Vs. State of
Punjab & Ors.,(1997) 7 SCC 209; A.Janardhana Vs. Union of India & Ors., (1983) 3 SCC 601; B.S.
Vadera Vs. Union of India & Ors., AIR 1969 SC 118; Raj Kumar Vs. Union of India & Ors., (1975) 4
SCC 13; S.S. Bola & Ors. Vs. B.D. Sardana & Ors.,(1997) 8 SCC 522.
27. Mr. Ashok Gaur, the learned counsel appearing on behalf of respondent No.3-Suraj Bhan
Meena, contended that the Hon'ble Apex Court, while deciding the Indra Sawhney's case(supra) on
16.11.1992, made it clear that the existing rule relating to reservation in promotion to the SCs and
the STs would continue in operation for five years and within this period, it would be open to the
appropriate authorities to revise, modify or reissue the relevant rules to ensure the achievement of
the objective of Article 16(4) of the Constitution. However, before the said period of five years could
have ended on 16.11.1997. The Constitution (Seventy-Seventh Amendment) Act, 1995 came into
force on 17.6.1995 giving enabling powers to the State Government to frame rules with regard to
reservation in promotion. Subsequently, the catch-up rule was introduced by the Hon'ble Supreme
Court in the cases of Virpal Singh Chauhan(supra) and Ajit singh-I(supra), the State of Rajasthan
added 'proviso' below seniority rule in Various Service Rules vide Notification dated 1.4.1997 giving
benefit of regaining seniority to senior General/OBC category persons. However, the Central
Government further amended the Constitution by way of Constitution (Eighty-Fifth Amendment)
Act, 2001 on 4.1.2002 with effect from 17.6.1995 giving further enabling powers to the State
Government to give benefit of 'consequential seniority' to the SC and the ST roster promotees.
28. He further argued that a provisional seniority list of R.A.S. officers was published as on
26.6.2000, wherein senior general category candidates were placed above the merit promotees asBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

well as roster promotees. However, the said seniority list was challenged by way of writ petition filed
by merit promotee styled as Hanuman Singh Bhati Vs. State of Rajasthan & Ors.(S.B. Civil Writ
Petition No.2966/2000) and other connected writ petitions and the learned Single Judge of this
Court vide its judgment dated 30.5.2001 quashed the provisional seniority list dated 26.6.2000.
Thereafter, special appeal was preferred and the judgment of the learned Single Judge dated
30.5.2001 was upheld by the Division Bench. Special Leave Petition was also preferred against the
order of the Division Bench and the appeal arising out of it is still pending before the Hon'ble Apex
Court, wherein by way of an interim order dated 25.2.2002, the contempt proceedings were stayed.
He, therefore, contended that since no senior general category candidate was promoted in
pursuance of regaining seniority rule dated 1.4.1997 till it was withdrawn on 28.12.2002, therefore,
no right is accrued or vested in any of the petitioners. The rights of promotion and seniority, as per
notification dated 1.4.1997, was protected by adding new proviso on 28.12.2002, but after insertion
of the provision relating to 'consequential seniority' in Article 16(4-A) by way of the Constitution
(Eighty-Fifth Amendment) Act, 2001 and upholding of its constitutional validity by the Hon'ble
Supreme Court in M.Nagaraj's case(supra), the protected rule dated 28.12.2002 was also withdrawn
vide the notification dated 25.4.2008 with effect from 28.12.2002. The State is empowered to insert,
amend or delete any provision of the statutory rule with retrospective effect. Since no vested or
accrued rights have been taken back vide Notification dated 25.4.2008, therefore, he contended that
there is no merit in the writ petition and the same is liable to be dismissed. He has also referred to
the prayer of the writ petition and contended that since the petitioners want to revise the seniority
list of number of Rajasthan Administrative Service officers and have not impleaded all of them as
party in the writ petition, therefore, the present writ petition is liable to be dismissed on the ground
of non-joinder of necessary party also.
29. Learned counsel appearing on behalf of respondent No.3, in support of his submissions, referred
to the judgment of the Hon'ble Apex Court in the cases of Indra Sawhney & Ors. Vs. Union of India
& Ors., 1992 Supp.(3) SCC 217; M.Nagaraj & Ors. Vs. Union of India, (2006) 8 SCC 212; Union of
India & Ors. Vs. Virpal Singh Chauhan & Ors., (1995) 6 SCC 684; Ajit Singh Juneja (Ajit Singh-I) &
Ors. Vs. State of Punjab & Ors., (1996) 2 SCC 715; Ajit Singh (II) & Ors. Vs. State of Punjab &
Ors.,(1997) 7 SCC 209; Jagdish Lal & Ors. Vs. State of Haryana & Ors., (1997) 6 SCC 538; Ram
Prasad & Ors. Vs. D.K. Vijay & Ors., (1999) 7 SCC 251; and the judgment of this Court in the cases of
B.K. Sharma & Anr. Vs. State of Rajasthan & Ors., WLC (Raj.) 1998 (2) 583; Hanuman Singh Bhati
Vs. State of Rajasthan & Ors. (SB Civil Writ Petition No.2966/2000 decided on 30.5.2001). He has
also referred Civil Appeal No.171/2002 (State of Rajasthan Vs. Hanuman Singh Bhati) and Writ
Petition (Civil) No.234/2002 (All India Equality Forum Vs. Union of India & Ors.).
30. Mr. Hari Prasad Verma, learned counsel appearing on behalf of respondent No.4-Sriram
Choradia, the SC candidate, contended that SC/ST is not a caste but it is a class. Since it is a class
based reservation and creamy layer is applicable for OBC and not for SC/ST, he argued that after
upholding of the constitutional validity of the Constitution (Seventy-Seventh Amendment) Act, 1995
and the Constitution (Eighty-Fifth Amendment) Act, 2001 by the Hon'ble Apex Court, nothing
remains to be decided in the present case and therefore, the writ petition is liable to be dismissed.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

31. Learned counsel appearing on behalf of the respondent No.4 referred to the judgment of the
Hon'ble Apex Court in the case of Ashoka Kumar Thakur Vs. Union of India & Ors., (2008) 6 SCC 1.
32. Mr.Ajeet Kumar Sharma, learned counsel appearing on behalf of the intervenor argued that all
the applicants are senior to both the parties, therefore, neither he is supporting nor opposing the
writ petition or special appeals, but the interest of applicants have been affected by the interim order
passed in D.B. Civil Special Appeal (Writ) No.618/2009. Therefore, the interim order be suitably
modified giving a way to promotion of the applicants on the posts of Indian Administrative Service
(IAS). Since we were hearing the matters finally, therefore, interim stay order was neither vacated
nor modified by us. It is also relevant to mention that interim order was challenged by State before
the Hon'ble Supreme Court and the same was not interfered with.
33. Mr. Sanjeev Prakash Sharma, learned counsel appearing on behalf of the petitioners, in
rejoinder, contended that required exercise by the State Government, as per M.Nagaraj case(supra),
is necessary for giving the benefit of consequential seniority also to the reserved promotees. He
contended that he has also challenged the rule relating to reservation in promotion in the writ
petition. While giving reply to the objections raised on behalf of respondent No.3 about non-joinder
of necessary parties, he contended that it is a settled law that a person in representative capacity of a
class or group can be impleaded as party-respondent. In case a representative of a class or group is
impleaded as one of the respondent, then the writ petition cannot be thrown on this ground. He has
already impleaded respondent No.3 as a representative of ST category persons and respondent No.4
as a representative of SC category persons, therefore, he has impleaded the necessary parties in the
case. He has not sought any relief against any individual so as to implead a particular person as a
party to the writ petition.
34. We have considered the submissions of learned counsel for the parties.
35. First of all, we will now take up the preliminary objection raised on behalf of the respondent
No.3 about maintainability of the writ petition or its dismissal on the ground of non-joinder of
necessary parties.
36. It is contended that the petitioners have challenged the seniority list without impleading all the
affected persons as party respondents in the writ petition, and in their absence, their rights cannot
be determined by this Court.
37. The petitioners replied that the number of affected persons is too large that it is neither possible
to implead all of them as party nor there is any requirement of law in this regard. He contended that
as per the settled proposition of law, if some of the respondents are impleaded in representative
capacity on behalf of the affected persons then it is sufficient compliance. The petitioners have
already impleaded Suraj Bhan Meena as respondent No.3 as representative of the ST candidates and
has further impleaded Sri Ram Choradia as respondent No.4 as representative of the SC category.
The respondents No.3 and 4 have argued the case at length in representative capacity also.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

38. We have considered the submission of the learned counsel for the parties and we find that in this
bunch of writ petitions, the main challenge is about Notifications dated 25.4.2008 and 28.12.2002,
and therefore, the dispute is in between general and SC/ST candidates about their seniority on
promotion post. No relief against any individual has been sought in the writ petitions. The Hon'ble
Apex Court in the cases of Rajesh Gupta Vs. State of U.P., AIR 2005 SC 2540, Arun Tewari Vs. Zila
Mansvi Shikshak Sangh, AIR 1998 SC 331 and Tridip Kumar Dingal Vs. State of West Bengal & Ors.,
(2009) 1 SCC 768, has held that if some of the respondents are impleaded in representative capacity
considering that their number was too large for all of them to be joined individually as respondents,
their writ petition cannot be dismissed only for the reason that all the persons who would be vitally
affected, have not been impleaded as party. Since the petitioners have already impleaded Suraj Bhan
Meena as respondent No.3 as representative of the ST candidates and has further impleaded Sriram
Choradia as respondent No.4 as representative of the SC category, we do not find any substance in
the preliminary objection of the respondent No.3, and the same is hereby overruled.
39. Now following questions remain for our consideration in these matters on the basis of
submissions of learned counsel for the parties:-
1.Whether Notification dated 25.4.2008 which came into force with effect from
28.12.2002, is violative of Articles 14 and 16 of the Constitution, as it takes away the
vested and accrued rights retrospectively?
2.Whether Notification dated 28.12.2002 is violative of Articles 14 and 16 of the
Constitution?
40. Before considering the above questions, it would be relevant to refer the relevant rules and the
case law cited at the Bar and also the legislative history of the Rules as well as Constitutional
provisions relating to the present case.
41. The Rajasthan Administrative Service Rules, 1954 were published in the Rajasthan Rajpatra
dated 9.7.1954. Rule 4(c) defines by promotion means by the method prescribed by Rule 7(1)(b).
Rule 7 relates to Source of Recruitment. Rule 7(1)(b) reads as under:-
. . . . .
(b) by promotion of Tehsildars.
42. Rule 8 is in respect of reservation of vacancies for the Scheduled Castes and Scheduled Tribes,
which reads as under:-
(1) Reservation of vacancies for the Scheduled Castes and Scheduled Tribes shall be
in accordance with orders of the Government for such reservation in force at the time
of recruitment i.e. by direct recruitment and by promotion.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

(2) The vacancies so reserved for promotion shall be filled in by seniority- cum merit
and merit.
(3) In filling the vacancies so reserved the eligible candidates who are members of the
Scheduled Castes and the Scheduled Tribes shall be considered for appointment in
the order in which their names appear in the list prepared for direct recruitment by
the Commission for post falling in its purview, and by the Appointing Authority in
other cases and the Departmental Promotion Committee or the Appointing Authority
as the case may be in the case of promotees, irrespective of their relative rank as
compared with other candidates.
(4) Appointment shall be made strictly in accordance with the rosters prescribed
separately for direct recruitment and promotion. In the event of non availability of
the eligible and suitable candidates amongst the Scheduled Castes and the Scheduled
Tribes as the case may be, in a particular year, the vacancies so reserved for them
shall be carried forward until the suitable Scheduled Castes and the Scheduled Tribes
candidate(s), as the case may be, are available. In any circumstances no vacancy
reserved for Scheduled Castes and the Scheduled Tribes candidates shall be filled by
promotion as well as by direct recruitment from general category candidates.
However, in exceptional cases where in the public interest the Appointing Authority
feels that it is necessary to fill up the vacant reserved post(s) by promotion from the
general category candidates on urgent temporary basis, the Appointing Authority
may make a reference to the Department of Personnel and after obtaining prior
approval of the Department of Personnel, they may fill up such posts(s) by promoting
the general category candidate(s) on urgent temporary basis clearly stating in the
promotion order that the General category candidate(s) who are being promoted on
urgent temporary basis against the vacant post reserved for Scheduled Castes or the
Scheduled Tribes candidates, as the case may be, shall have to vacate the post as and
when the candidate(s) of that category become available.
Provided that there shall be no carry forward of the vacancies in posts or class/ category, group of
posts in any cadre of service to which promotions are made on the basis of merit alone, under these
Rules.
43. Rule 33 is an important and relevant rule for the purpose of present controversy. It relates to
seniority. Rule 33 is quoted as under:-
33. Seniority "Seniority of persons appointment to the post encadred in the service
shall be determined from the date of appointment on the post after regular selection
in accordance with the provisions of these rules. Appointment on ad hoc or urgent
temporary basis shall not be deemed to be appointment after regular selection."
Provided:-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

(i) that the seniority inter se of the persons appointed to the service before the
commencement of these Rules shall be such as may have been determined or as
hereafter be determined by the State Government in accordance with the principles
and instructions set out in Schedule V;
(ii) that persons who are appointed to the Service by promotion and by special
selections during a year or whose appointment is deemed to have been made during a
particular year interm of the provisions of the Rajasthan Service (Recruitment by
promotion against vacancies of earlier years) Rules, 1972 shall rank senior to those
appointed by direct recruitment during that year. Persons appointed to the service by
promotion deemed to have been so appointed in a particular year shall rank senior to
those appointed or deemed to have been appointed by Special Selection during the
same year. Persons appointed to a service by promotion from Tehsildars shall rank
senior to the one appointed by promotion from the post of Inspector Grade-I of
Devasthan Department during the same year.
(iii) Deleted.
(iv) Deleted.
(v) Deleted.
(vi) that the persons selected and appointed as a result of a selection, which is not
subject to review and revision, shall rank senior to the persons who are selected and
appointed as a result of sub-sequent selection;
Seniority inter se of persons selected on the basis of seniority-cum-merit and on the
basis of merit in the same selection shall be the same as in the next below grade.
(vii)" that the seniority inter se of the persons appointed to the Service on the result
of one and the same examination, except those who do not join the Service when a
vacancy is offered to them, shall follow the order in which they have been placed in
the list prepared by the Commission under rule 25;
(viii) Deleted.
(ix) Deleted.
(x) Deleted.
(2) In determination seniority of persons appointed to the Service in accordance with
the provisions of sub-rule (1) Government, if satisfied of any error or omission having
been made in the seniority list (in consequence of incorrect data supplied by the
persons appointed to the Service or otherwise) shall have the power :-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

(i) to fit in and adjust any person so appointed at such position therein as it may
deem just and proper, and
(ii) to after the position for the time being of any such person in the said list:
Provided - that changes in the seniority list of persons covered by proviso (i) of
sub-rule (1) will not be made by Government after 31-12-1958.
2. This will have effect from the 9th day of July, 1954.
44. A proviso was added below other provisos in Rule 33 by way of notification dated 1.4.1997 giving
benefit of regaining seniority to senior general/OBC candidates, which is reproduced as under:-
That if a candidate belonging to the Scheduled Caste/Scheduled Tribe is promoted to
an immediate higher post/grade against a reserved vacancy earlier than his senior
general/O.B.C. candidate who is promoted later to the said immediate higher
post/grade, the general/O.B.C. candidate will regain his seniority over such earlier
promoted candidates of the Scheduled Caste/Scheduled Tribe in the immediate
higher post/grade.
45. Vide notification dated 28.12.2002, the above proviso inserted vide notification dated 1.4.1997
was deleted and new proviso was substituted protecting the rights of seniority and promotion in
pursuance of notification dated 1.4.1997. The new proviso which was substitued on 28.12.2002
reads as under:-
Provided that a candidate who has got the benefit of proviso inserted vide
Notification No.F.7 (1) DOP/A-II/96 dated 01.04.1997 on promotion to an immediate
higher post shall not be reverted and his seniority shall remain uneffected. This
proviso is subject to final decision of the Hon'ble Supreme Court of India in Writ
Petition (Civil) No.234/2002 All India Equality Forum V/s Union of India & Others.
46. Vide notification dated 25.4.2008, the proviso which was added below all the provisos in Rule 33
vide notification dated 28.12.2002, has been deleted. The relevant portion of the notification dated
25.4.2008 is as under:-
2.Amendment:- The following existing proviso to rule as mentioned in Column No.3
against each of the Service Rules, listed in Column No.2 of the Schedule given below
is hereby deleted, namely:-
Provided that a candidate who has got the benefit of proviso inserted vide
Notification No.F.7 (1) DOP/A-II/96 dated 01.04.1997 on promotion to an immediate
higher post shall not be reverted and his seniority shall remain uneffected. This
proviso is subject to final decision of the Hon'ble Supreme Court of India in Writ
Petition (Civil) No.234/2002 All India Equality Forum V/s Union of India & Others.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

47. As per submissions of the learned Advocate General, a circular was issued by the State of
Rajasthan on 10.2.1975 providing for reservation in the matter of promotion to the extent of 16% for
the SCs and 12% for the STs.
48. The Hon'ble Apex Court vide judgment dated 16.11.1992 in Indra Sawhney & Ors. Vs. Union of
India & Ors.(supra) held that Article 16(4) does not permit any provision for reservation in the
matter of promotion. Para 859(7) of the judgment reads as under:-
. . . .
(7) Article 16(4) does not permit provision for reservation in the matter of promotion.
This rule shall, however, have only prospective operation and shall not affect the
promotions already made, whether made on regular basis or on any other basis. We
direct that our decision on this question shall operate only prospectively and shall not
affect promotions already made, whether on temporary, officiating or
regular/permanent basis. It is further directed that wherever reservations are already
provided in the matter of promotion be it Central Services or State Services, or for
that matter services under any Corporation, authority or body falling under the
definition of 'State' in Article 12 such reservations may continue in operation for a
period of five years from this day. Within this period, it would be open to the
appropriate authorities to revise, modify or re-issue the relevant rules to ensure the
achievement of the objective of Article 16(4). If any authority thinks that for ensuring
adequate representation of 'backward class of citizens' in any service, class or
category, it is necessary to provide for direct recruitment therein, it shall be open to it
to do so. (Ahmadi,J expresses no opinion on this question upholding the preliminary
objection of Union of India). It would not be impermissible for the State to extend
concessions and relaxations to members of reserved categories in the matter of
promotion without compromising the efficiency of administration.
(emphasis supplied)
49. The above para makes it clear that earlier rules relating to promotion were continued for a
period of five years and liberty was granted to the concerned/appropriate Governments to make
rules in this regard. However, before expiry of five years period and to nullify the above judgment of
the Hon'ble Apex Court, the Central Government brought the Constitution (Seventy-Seventh
Amendment) Act, 1995 on 17.6.1995, which reads as under:-
"THE CONSTITUTION (SEVENTY-SEVENTH AMENDMENT) ACT, 1995 Statement
of Objects and Reasons.- The Scheduled Castes and the Scheduled Tribes have been
enjoying the facility of reservation in promotion since 1955. The Supreme Court in its
judgment dated 16th November, 1992 in the case of Indra Sawhney v. Union of India,
however, observed that reservation of appointments or posts under Article 16(4) of
the Constitution is confined to initial appointment and cannot extent to reservation
in the matter of promotion. This ruling of the Supreme Court will adversely affect theBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

interests of the Scheduled Castes and the Scheduled Tribes. Since the representation
of the Scheduled Castes and the Scheduled Tribes in services in the States have not
reached the required level, it is necessary to continue the existing dispensation of
providing reservation in promotion in the case of the Scheduled Castes and the
Scheduled Tribes. In view of the commitment of the Government to protect the
interests of the Scheduled Castes and the Scheduled Tribes, the Government have
decided to continue the existing policy of reservation in promotion for the Scheduled
Castes and the Scheduled Tribes. To carry this out, it is necessary to amend Article 16
of the Constitution by inserting a new clause (4A) in the said Article to provide for
reservation in promotion for the Scheduled Castes and the Scheduled Tribes.
2. The Bill seeks to achieve the aforesaid object.
An Act further to amend the Constitution of India Be it enacted by Parliament in the
Forty-sixth Year of the Republic of India as follows:-
1.Short title.- This Act may be called the Constitution (Seventy-seventh Amendment)
Act, 1995.
2.Amendment of Article 16. - In Article 16 of the Constitution, after clause (4), the
following clause shall be inserted, namely:-
"(4A) Nothing in this Article shall prevent the State from making any provision for
reservation in matters of promotion to any class or classes of posts in the services
under the State in favour of the Scheduled Castes and the Scheduled Tribes which, in
the opinion of the State, are not adequately represented in the services under the
State."
50. Though the enabling provision was made in the Constitution in respect of reservation in
promotion by way of the Constitution (Seventy-Seventh Amendment) Act, 1995, however, the
Hon'ble Apex Court, for the first time, in Virpal Singh Chauhan's case (supra), introduced the
'catch-up' rule and held that if the senior general candidate is promoted then he will regain his
seniority on promotion post above junior reserved promotee. The Hon'ble Apex Court held that the
consequential seniority on promotion post is not covered by Article 16(4-A). Para 27 of the judgment
in the case of Union of India & Ors. Vs. Virpal Singh Chauhan (supra) is reproduced as under:-
We are of the opinion that the aforesaid circulars/letters providing for reservation in
favour of Scheduled Castes/Scheduled Tribes candidates, rosters and their operation
and on the subject of seniority as between general candidates and reserved category
candidates, being in the nature of special rules prevail over the general instructions
contained in Volume-I of the Indian Railway Establishment Manual including those
contained in Paras 306, 309 and 319 et al. Accordingly, we agree with the conclusion
of the Tribunal in the order under appeal (Virpal Singh Chauhan) though we may not
agree with all the reasons given by the Tribunal. In other words, we may not agreeBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

with the view expressed by the Tribunal that a harmonious reading of Clauses (1) and
(4) of Article 16 should mean that a reserved category candidate promoted earlier
than his senior general category candidate in the feeder category shall necessarily be
junior in the promoted category to such general category candidate. No such
principle may be said to be implicit in the said clauses. But inasmuch the Railway
Board's circulars herein concerned do provide specifically for such a situation and
since they cannot be said to be violative of the constitutional provisions, they must
prevail and have to be given effect to. It is not brought to our notice that the said
instructions are inconsistent in any manner with any of the statutory provisions or
statutory rules relevant in this behalf.
51. The same view was further taken by the Hon'ble Apex Court in Ajit Singh Juneja-I Vs. State of
Punjab & Ors.(supra). Para 16 of the judgment is reproduced as under:-
We respectfully concur with the view in Union of India vs. Virpal Singh Chauhan that
seniority between the reserved category candidates and general candidates in the
promoted category shall continue to be governed by their panel position i.e. with
reference to their inter se seniority in the lower grade. The rule of reservation gives
accelerated promotion, but it does not give the accelerated consequential seniority. If
a Scheduled Caste/Scheduled Tribe candidate is promoted earlier because of the rule
of reservation/roster and his senior belonging to the general category candidate is
promoted later to that higher grade the general category candidate shall regain his
seniority over such earlier promoted Scheduled Caste/Tribe candidate. As already
pointed out above that when a Scheduled caste/Tribe candidate is promoted earlier
by applying the rule of reservation/roster against a post reserved for such Scheduled
caste/Tribe candidate, in this process he does not supersede his seniors belonging to
the general category. In this process there was no occasion to examine the merit of
such ScheduledCaste/Tribe candidate vis-a-vis his seniors belonging to the general
category. As such it will be only rational, just and proper to hold that when the
general category candidate is promoted later from the lower grade to the higher
grade, he will be considered senior to a candidate belonging to the Scheduled
Caste/Tribe who had been given accelerated promotion against the post reserved for
him. Whenever a question arises for filling up a post reserved for Scheduled
Caste/Tribe candidate in a still higher grade then such candidate belonging to
Scheduled Caste/Tribe shall be promoted first but when the consideration is in
respect of promotion against the general category post in a still higher grade then the
general category candidate who has been promoted later shall be considered senior
and his case shall be considered first for promotion applying either principle of
seniority-cum-merit or merit-cum-seniority. If this rule and procedure is not applied
then result will be that majority of the posts in the higher grade shall be held at one
stage by persons who have not only entered in service on the basis of reservation and
roster but have excluded the general category candidates from being promoted to the
posts reserved for general category candidates merely on the ground of their initial
accelerated promotions. This will not be consistent with the requirement or the spiritBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

of Article 16(4) or Article 335 of the Constitution.
(emphasis supplied)
52. The Constitution Bench of the Hon'ble Apex Court in the case of Ajit Singh Juneja II Vs. State of
Punjab & Ors. (supra) further approved the 'catch-up' rule and followed its earlier judgments given
in Virpal Singh Chauhan and Ajit Singh-I's case(supra). Paras 81 of the judgment is reproduced as
under:-
81.As accepted in Virpal(see SCC at p.702) and Ajit Singh (see SCC at p.729), we hold
that in case any senior general candidate at Level 2 (Assistant) reaches Level 3
(Superintendent Grade II) before the reserved candidate (roster point promotee) at
Level 3 goes further up to Level 4 in that case the seniority at Level 3 has to be
modified by placing such a general candidate above the roster promotee, reflecting
their inter se seniority at Level 2. Further promotion to Level 4 must be on the basis
of such a modified seniority at Level 3, namely, that the senior general candidate of
Level 2 will remain senior also at Level 3 to the reserved candidate, even if the latter
had reached Level 3 earlier and remained there when the senior general candidate
reached that Level 3.In cases where the reserved candidate has gone upto Level 4
ignoring the seniority of the senior general candidate at Level 3, seniority at Level 4
has to be refixed (when the senior general candidate is promoted to Level 4) on the
basis of when the time of reserved candidate for promotion to Level 4 would have
come, if the case of the senior general candidates was considered at Level 3 in due
time. To the above extent, we accept the first part of the contention of the learned
counsel for the general candidates. Such a procedure in our view will properly
balance the rights of the reserved candidates and the fundamental rights guaranteed
under Article 16(1) to the general candidates.
(emphasis supplied)
53. In the case of M.G. Badappanavar & Anr.Vs. State of Karnataka & ors.(supra), the Hon'ble Apex
Court held that the equality is the basic feature of the Constitution of India and any treatment of
equals as unequally or unequals as equals will be violation of the basic structure of the Constitution
of India. Therefore, if consequential seniority is given to the roster point promotees it will violate the
equality principle which is part of the basic structure of the Constitution. Even Article 16(4-A)
cannot, therefore, be of any help to the reserved candidates.
54. In the case of Jagdish Lal & Ors. Vs. State of Haryana & Ors.(supra), the Hon'ble Apex Court
held that the SC/ST candidates will get seniority with reference to the date of their promotion. The
plea of general candidates on the basis of the judgment of the Hon'ble Apex Court in the cases of
Virpal Singh Chauhan(supra), Ajit Singh I(supra), was rejected. The relevant portion of Para 17 of
the judgment reads as under:-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

. . . ..Thus, we hold that the euphoria had by the general candidates from the ratios in
Virpal Chauhan and Ajit Singh cases is short lived; it does not help in so realising the
correct implications arising from the aforesaid ratios. It is settled law that
administrative instructions supplement the law but do not supplant the law. It fills
only yawning gaps. The administrative instructions issued by the Haryana
Government after Ajit Singh's case flies in the face of statutory Rule 11 of the Rules.
Therefore, it crushes itself with the grinding teeth of the above statutory Rule 11 and
the principles. Thus considered, we hold that the view taken by the High Court in that
behalf is correct in law and is not vitiated by any infirmity in law. We further hold
that the reserved candidates became senior to the general candidates in each
successive cadre/grade from Assistant to Superintendent in Class III Service and 5th
respondent in Class I Service. Their seniority is not and cannot have the effect of
getting wiped out after the promotion of general candidates from their respective
dates of promotion. The general candidates remain junior in higher echelons to the
reserved candidates as was held by the High Court.
55. It is relevant to mention that the judgment in the case of Jagdish Lal Vs. State of Haryana
(supra) was over-ruled by the Constitution Bench of the Hon'ble Apex Court in Ajit Singh II's case
Vs. State of Punjab (supra).
56. In the case of Hanuman Singh Bhati Vs. State of Rajasthan & Ors.(SBCWP No.2966/2000
decided by the learned Single Judge vide judgment dated 30.5.2001 and other connected writ
petitions, the Single Bench of this Court considered the dispute regarding inter se seniority in
between the general category candidates and held that merit promotees will rank senior to the
seniority promotees. The reserved category promotees have to be taken to be entitled to tentative
seniority alone which would depend on promotions of other candidates senior to them at lower
level. The last operative portion of the judgment reads as under:-
. . . . . . . . . . . . . .
The decision of the State Government to place the merit promotees below the
seniority promotees is, therefore, arbitrary and violative of Articles 14 and 16 of the
Constitution of India. The provisional seniority lists prepared on the basis of the
aforesaid decision of the State Govt. therefore, are also arbitrary and violative of
Articles 14 and 16 of the Constitution of India. The impugned decisions, circular
dated 11.2.2000 and the seniority lists dated 26.2.2000 are all quashed. The State
Government shall now prepare provisional seniority list in which the merit
promotees shall not be placed below seniority promotees only because seniority
promotees have to be placed above reserved category promotees senior to them at
lower level and such reserved category promotees were promoted earlier than the
merit promotees. The reserved category promotees have to be taken to be entitled to
tentative seniority alone which would depend on promotions of other candidates
senior to them at lower level.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

(emphasis supplied)
57. The aforesaid judgment was challenged by the State of Rajasthan by way of DBSAW
No.560/2001 and other connected special appeals. The Division Bench of this Court vide judgment
dated 12.9.2001 upheld the judgment of the learned Single Judge with slight modifications. Para 23
of the judgment reads as under:-
For the reasons aforementioned we confirm the impugned order of the learned Single
Judge with slight modification. We make it clear that no finality shall be attached to
the provisional seniority list drawn in pursuance to the order of learned Single Judge.
It would be open to challenge by the affected members of RAS. The objections so
raised shall be reasonably considered by the three member committee headed by the
Chief Secretary and thereafter final seniority list shall be published.
58. It is relevant to mention that ten special appeals were decided by the Division Bench vide
judgment dated 12.9.2001, but the State of Rajasthan preferred only one special leave petition
against the judgment in the case of Hanman Singh Bhati (DBSAW No.560/2001) and the Civil
Appeal No.171/2002 arising out of it, is still pending before the Hon'ble Apex Court as contended by
the learned counsel for the parties. The order dated 25.2.2002 passed by the Hon'ble Apex Court in
Civil Appeal No.171/2002, State of Rajasthan Vs. Hanuman Singh Bhati & Ors. was referred during
the course of arguments to show that only contempt proceedings were stayed in the matter and
operation of the orders of Division Bench and Single Bench was not stayed. The order dated
25.2.2002 is reproduced as under:-
Counter affidavit be filed within three weeks and rejoinder within three weeks there
after. List after six weeks. Contempt is stayed in the meantime.
59. To nullify the aforesaid four judgments of the Hon'ble Apex Court, the Central Government has
further brought The Constitution (Eighty-Fifth Amendment) Act, 2001 on 4.1.2002 with effect from
17.6.1995 which reads as under:-
THE CONSTITUTION(EIGHTY-FIFTH AMENDMENT) ACT, 2001 Statement of
Objects and Reasons.-The Government servants belonging to the Scheduled Castes
and the Scheduled Tribes had been enjoying the benefit of consequential seniority on
their promotion on the basis of rule of reservation. The judgments of the Supreme
Court in the case of Union of India v. Virpal Singh Chauhan and Ajit Singh Januja v.
State of Punjab, which led to the issue of the O.M. dated 30th January, 1997, have
adversely affected the interest of the Government servants belonging to the
Scheduled Castes and Scheduled Tribes category in the matter of seniority on
promotion to the next higher grade. This has led to considerable anxiety and
representations have also been received from various quarters including Members of
Parliament to protect the interest of the Government servants belonging to Scheduled
Castes and Scheduled Tribes.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

2.The Government has reviewed the position in the light of views received from
various quarters and in order to protect the interest of the Government servants
belonging to the Scheduled Castes and Scheduled Tribes, it has been decided to
negate the effect of O.M. dated 30th January 1997 immediately. Mere withdrawal of
the O.M. dated 30th January, 1997 will not meet the desired purpose and review or
revision of seniority of the Government servants and grant of consequential benefits
to such Government servants will also be necessary. This will require amendment to
Article 16(4A) of the Constitution to provide for consequential seniority in the case of
promotion by virtue of rule of reservation. It is also necessary to give retrospective
effect to the proposed constitutional amendment to Article 16(4A) with effect from
the date of coming into force of Article 16(4A) itself, that is, from the 17th day of
June, 1995.
3.The Bill seeks to achieve the aforesaid objects.
Received the assent of the President on the 4th January, 2002 An Act further to amend the
Constitution of India.
Be it enacted by Parliament in the Fifty-second Year of the Republic of India as follows:-
1. Short title and commencement.- (1)This Act may be called the Constitution
(Eighty-fifth Amendment) Act, 2001.
(2) It shall be deemed to have come into force on the 17th day of June 1995.
2.Amendment of Article 16.-In Article 16 of the Constitution, in clause (4A), for the words "in
matters of promotion to any class", the words "in matters of promotion, with consequential
seniority, to any class" shall be substituted."
60. The Constitutional validity of the Constitution (Seventy-Seventh Amendment) Act, 1995 and the
Constitution (Eighty-Fifth Amendment) Act, 2001 was challenged before the Hon'ble Apex Court in
M.Nagaraj Vs. Union of India (supra) and other various writ petitions including Writ Petition (Civil)
No.234/2002, All India Equality Forum Vs Union of India & Ors., wherein the State of Rajasthan
was one of the respondents. The Constitution Bench upheld the constitutional validity of the
Constitution (Seventy-Seventh Amendment) Act, 1995 and the Constitution (Eighty-Fifth
Amendment) Act, 2001 vide judgment dated 19.10.2006. Para 124 of the judgment is reproduced as
under:-
Subject to the above, we uphold the constitutional validity of the Constitution
(Seventy-Seventh Amendment) Act, 1995, the Constitution (Eighty-First
Amendment) Act, 2000, the Constitution (Eighty-Second Amendment) Act, 2000
and the Constitution (Eighty-Fifth Amendment) Act, 2001.
(emphasis supplied)Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

61. It is relevant to mention that while upholding the constitutional validity of the Constitution
(Seventy-Seventh Amendment) Act, 1995 and the Constitution (Eighty-Fifth Amendment) Act,
2001, the Hon'ble Apex Court specifically directed that the State is not bound to make reservation
for the SCs and the STs in the matters of promotion. However, if they wish to exercise their
discretion and make such provision, the State has to collect quantifiable data showing backwardness
of the class and inadequacy of representation of that class in public employment in addition to
compliance with Article 335. Para 123 of M.Nagraj's case (supra) is reproduced as under:-
However, in this case, as stated above, the main issue concerns the "extent of
reservation". In this regard the State concerned will have to show in each case the
existence of the compelling reasons, namely, backwardness, inadequacy of
representation and overall administrative efficiency before making provision for
reservation. As stated above, the impugned provision is an enabling provision. The
State is not bound to make reservation for SCs/STs in matter of promotions.
However, if they wish to exercise their discretion and make such provision, the State
has to collect quantifiable data showing backwardness of the class and inadequacy of
representation of that class in public employment in addition to compliance of Article
335. It is made clear that even if the State has compelling reasons, as stated above,
the State will have to see that its reservation provision does not lead to excessiveness
so as to breach the ceiling-limit of 50% or obliterate the creamy layer or extend the
reservation indefinitely.
(emphasis supplied)
62. In the case of B.K. Sharma & Anr. Vs. State of Rajasthan & Ors., 1998 (2) WLC (Raj.) 583, the
writ petitioners in writ petition No.2545/96 and other connected writ petitions, were members of
the Rajasthan Administrative Service and they had challenged the vires of Rule 8 and 33 of the RAS
Rules, 1954, being violative of Articles 14 and 16 of the Constitution of India. The members of the
Rajasthan Police Service also preferred writ petitions, which were connected in B.K. Sharma's
case(supra). This Court allowed the writ petitions and quashed the impugned orders by which the
benefit of accelerated promotions was extended to the private respondents belong to the
SC/ST/OBC. It was also directed that the petitioners whose seniority has been adversely affected,
consequent upon passing of the impugned orders which are subject matter of challenge in the writ
petitions, shall be entitled to regain their original seniority and the respondents are directed to
restore the said seniority to the petitioners with effect from the due date i.e. the date when their
immediate juniors(private respondents) were promoted with all consequential benefits. The writ
petitions were filed by senior general candidates for regaining their seniority in promotion post on
the basis of judgment of the Hon'ble Apex Court in the case of Union of India Vs. Virpal Singh
Chauhan (supra) and Ajit Singh I (supra) and during the pendency of the writ petition, a proviso in
this regard was also added below other provisos to Rule 33 of the RAS Rules alongwith Various
Service Rules vide notification dated 1.4.1997 which was quoted in para 7 of the judgment.
Therefore, the notification dated 1.4.1997 was also taken into consideration by the Division Bench.
Para 47 of B.K. Sharma's case (supra) is reproduced as under:-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

As a result of above discussions, we are of the view that the petitioners deserve to
succeed and accordingly the aforesaid writ petitions are allowed with the following
directions:-
(a) The impugned orders dated 19.1.1996/2.2.1996 passed by the respondents in
DBCWP No.2812/96 by which the benefit of accelerated promotions has been
extended to the private respondents belonging to the SC/ST/BC, are quashed and
set-aside;
(b) Seniority list dated 1.7.1987 circulated vide Annexure-3 dated 30.6.1990 in
DBCWP No.3086/1996 as well as the seniority list dated 30.6.1990 and the orders
dated 19.1.1996/2.2.1996 passed by the respondents in DBCWP No.6208/1996,
seniority list dated 23.4.1997 and the order dated 5.4.1997 in DBCWP No.4918/1997
in R.P.S. matters are quashed and set-aside.
(c) Combined seniority list published by the respondents in DBCWP Nos.2545/1996,
2675/1996, 4726/1997 (646/97) and 2963/1996 dated 22.4.1995 (in R.A.S. matters)
pertaining to grant of selection grade in Rajasthan Administrative Services of
SC/ST/BC candidates are quashed and set-aside.
(d) Rules 8, 9 28A and 33 of the Rules of 1954 are held intra-vires of the Constitution
of India and are not open to challenge;
(e) Benefit of reservation to the SC/ST/BC candidates in the matter of promotions to
higher posts from State Service i.e.R.P.S. and R.A.S. to I.P.S. and I.A.S. respectively
should not exceed the prescribed percentage quota i.e.28% since otherwise it would
adversely affect the service career of the general category candidates and the benefit
of this prescribed percentage in the matter of reservation should only be conferred at
the time of initial entry in service and should not extend in the matter of promotions.
(f) All promotions made from SC/ST/BC category candidates to R.P.S and R.A.S and
from said cadres to I.P.S and I.A.S., respectively in excess of the prescribed
percentage quota i.e.28% as fixed by the State Government for reserved category
candidates by which the benefit of accelerated promotions have been conferred on
the private respondents are quashed and set-aside.
(g) the petitioners whose seniority has been adversely affected consequent upon the
passing of the impugned orders which are subject matter of challenge in the aforesaid
writ petitions shall be entitled to regain their original seniority and the respondents
are directed to restore the said seniority to the petitioners with effect from due date,
i.e., the date when their immediate juniors (private respondents) were promoted with
all consequential benefits; andBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

(h) Review D.P.C shall be convened by the respondents with a period of 8 weeks from
the date of receipt of certified copy of this order which shall draw a fresh seniority list
out of the combined category of general as well as SC/ST/BC candidates and
promotions to next higher post to R.P.S and R.A.S and to I.P.S and I.A.S cadres,
respectively shall be made having due regard to the original panel position in strict
order of seniority of the petitioners as well as the private respondents in accordance
with the rules. The revised seniority list shall be published by the respondents
positively within a period of 60 days thereafter.
(emphasis supplied)
63. The above judgment of the Division Bench was challenged by the reserved candidates by way of
Special Leave Petition before the Hon'ble Apex Court styled as 'Ram Prasad Vs. D.K. Vijay' which
was decided by the Hon'ble Apex Court on 16.9.1999 [reported in (1999) 7 SCC 251], and the appeals
filed by the reserved candidates were dismissed subject to some concession as mentioned in the
judgment. The Hon'ble Apex Court held that the result is that officers from the reserved category
who were promoted at the roster points before 1.4.97 shall not be reverted but their seniority in the
promoted category shall be governed by the principles enumerated under Points 1 to 3 in the cases
of Ajit Singh No.1 and Ajit Singh No.II. The principle of regaining of seniority by the general
candidates was upheld. Para 21 and 22 of the judgment in Ram Prasad's case are reproduced as
under:-
21. In view of the peculiar facts of these cases, we are inclined to accede to this
contention. The result is that officers from the reserved category who were promoted
at the roster points before 1.4.97 shall not be reverted but their seniority in the
promoted category shall be governed by the principles enumerated under Points 1 to
3 in Ajit Singh I and Ajit Singh II. The prospectivity of Sabharwal as explained under
Point 4 in Ajit Singh II is not disturbed. So far as prospectivity of Ajit Singh I is
concerned, the principles in Ajit Singh II in Point 4 will apply but subject to
postponement of 1.3.96 to 1.4.97.
22. In other words, we agree that there is no need to revertthose reserved category
officers, if they were promoted even beyond 1.3.96 but before 1.4.97. To give an
example - in the case of two rosters from Level 1 to Level 2 and Level 2 to Level 3, if
the reserved candidate was promoted before 1.4.97 to Level 4, such reserved
candidate need not be reverted. If by the date of promotion of the reserved candidate
before 1.4.97 from Level 3,the senior general candidate at Level 2 has reached Level
3, he has to be considered as senior at Level 3 to the reserved candidate because the
latter was still at Level 3 on that date. But if such a general candidate's seniority was
ignored and the reserved candidate was treated as senior at level 3 and promoted to
Level 4, this has to be rectified after 1.3.96 by following Ajit Singh I as explained in
Ajit Singh II. In other words, if a reserved candidate was promoted to Level 4 before
1.4.97, without considering the case of the senior general candidate who had reached
Level 3 before such promotion, such reserved candidate need not be reverted but theBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

said promotion to Level 4 is to be reviewed and seniority at Level 3 and Level 4 (as
and when the general candidate is promoted to Level 4) is to be refixed.
(emphasis supplied)
64. In the case of State of Bihar Vs. Bal Mukund Sah (supra), the Hon'ble Apex Court also
considered the merit and efficiency in administration of justice in the matter relating to reservation
in judiciary, and held as under:-
58. . . . . . . . . . .
It is now time for us to take stock of the situation. In the light of the Constitutional scheme
guaranteeing independence of Judiciary and separation of powers between the executive and the
judiciary, the Constitution-makers have taken care to see by enacting relevant provisions for the
recruitment of eligible persons to discharge judicial functions from grass-root level of the Judiciary
up to the apex level of the District Judiciary, that rules made by the Governor in consultation with
the High Court in case of recruitment at grass-root level and the recommendation of the High Court
for appointments at the apex level of the District Judiciary under Article 233, remain the sole
repository of power to effect such recruitments and appointments. It is easy to visualise that if
suitable and competent candidates are not recruited at both these levels, the out turn of the judicial
product would not be of that high level which is expected of judicial officers so as to meet the
expectations of suffering humanity representing class of litigants who come for redressal of their
legal grievances at the hands of competent, impartial and objective Judiciary. The Presiding Officer
of the Court if not being fully equipped with legal grounding may not be able to deliver goods which
the litigating public expects him to deliver. Thus, to ensure the recruitment of the best available
talent both at grass-root level as well as at apex level of District Judiciary, Articles 233 and 234 have
permitted full interaction between the High Court which is the expert body controlling the District
Judiciary and the Governor who is the appointing authority and who almost carries out the
ministerial function of appointing recommended candidates both by the Public Service Commission
and the High Court at the grass-root level and also has to appoint only those candidates who are
recommended by the High Court for appointment at the apex level of District Judiciary. Any
independent outside inroad on this exercise by legislative enactment by the State Legislature which
would not require consultation with an expert agency like the High Court would necessarily fall foul
on the touchstone of the Constitutional scheme envisaging insulation of judicial appointments from
interference by outside agencies, bypassing the High Court, whether being the Governor or for that
matter Council of Ministers advising him or the Legislature. For judicial appointments the real and
efficacious advice contemplated to be given to the Governor while framing rules under Article 234 or
for making appointments on the recommendations of the High Court under Article 233 emanates
only from the High Court which forms the bed- rock and very soul of these exercises. It is axiomatic
that the High Court, which is the real expert body in the field in which vests the control over
Subordinate Judiciary, has a pivotal role to play in the recruitments of judicial officers whose
working has to be thereafter controlled by it under Article 235 once they join the Judicial Service
after undergoing filtering process at the relevant entry points. It is easy to visualise that when
control over District Judiciary under Article 235 is solely vested in the High Court, then the HighBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Court must have a say as to what type of material should be made available to it both at the
grass-root level of District Judiciary as well as apex level thereof so as to effectively ensure the
dispensation of justice through such agencies with ultimate object of securing efficient
administration of justice for the suffering litigating humanity. Under these circumstances,it is
impossible to countenance bypassing of the High Court either at the level of appointment at
grass-root level or at the apex level of the District Judiciary. The rules framed by the Governor as per
Article 234 after following due procedure and the appointments to be made by him under Article
233 by way of direct recruitment to the District Judiciary solely on the basis of the recommendation
of the High Court clearly project a complete and insulated scheme of recruitment to the Subordinate
Judiciary. This completely insulated scheme as envisaged by the founders of the Constitution cannot
be tinkered with by any outside agency dehors the permissible exercise envisaged by the twin
Articles 233 and 234. It is a misnomer to suggest that any imposition of scheme of reservation for
filling up vacancies in already existing, created and sanctioned posts in any cadre of district judges
or Subordinate Judiciary will have nothing to do with the concept of recruitment and appointment
for filling up such vacancies. Any scheme of reservation foisted on the High Court without
consultation with it directly results in truncating the High Courts power of playing a vital role in the
recruitment of eligible candidates to fill up these vacancies and hence such appointments on
reserved posts would remain totally ultra vires the scheme of the Constitution enacted for that
purpose by the founding fathers. It is also to be noted that the concept of social justice underlying
the scheme of reservation under Article 16(4) read with Article 335 cannot be said to be one which
the High Court would necessarily ignore being a responsible Constitutional functionary. In fact what
is required is that the right decision should be arrived at in the right manner. In the facts of the
present case, it is an admitted position that the High Court of Patna has already consented to have
14% reservation for SC candidates and 10% reservation for ST candidates in recruitment of Munsiffs
and Magistrates at grass-root level of Subordinate Judiciary and rules framed under Article 234 by
the Governor of Bihar in consultation with the High Court have permitted such reservation. Thus, it
is not as if the purpose of reservation cannot be achieved without reference to the High Court. But as
the saying goes you can take a horse to the water but cannot make it drink by force. Thus what is
expected of the executive and the Governor is to have an effective dialogue with the High Court so
that an appropriate reservation scheme can be adopted by way of rules under Article 234 and even
by prescribing quota of reservations of posts for direct recruits to District Judiciary under Article
233 if found necessary and feasible. That is the Constitutional scheme which is required to be
followed both by the High Court and by the executive represented through the Governor. But this
thrust of the Constitutional scheme cannot be given a go-bye nor can the entire apple-cart be turned
topsy-turvey by the legislature standing aloof in exercising its supposed independent Legislative
power dehors the High Courts consultation.
(emphasis supplied)
65. In the case of Andhra Public Service Commission Vs. Baloji Badhavath & Ors., (2009) 5 SCC 1,
the Hon'ble Supreme Court held that shortlisting of the candidates for main examination based on
performance in preliminary examination is permissible if tested on the touchstone of Article 335,
the State is bound to devise some procedure to shortlist candidates considering its limited resources,
to restrict lakhs of candidates from appearing at examination and interview. It was further held thatBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

category-wise reservation would be detrimental to the interest of meritorious candidates belonging
to the reserved categories, and would give rise to complexity since reservation to women and
handicapped persons is on horizontal basis. The Hon'ble Apex Court held that proviso to Article 335
is applicable only for the purpose of promotion. Lowering of marks for the candidates belonging to
the reserved category is not a constitutional mandate at the threshold. The minimum marks
prescribed at the initial stage for all categories including the reserved category was upheld. Paras 18
and 29 to 32 are reproduced as under:-
18. The Constitution of India lays down provisions for both protective discrimination
as also affirmative action. Reservation of posts for the disadvantaged class of people
as also seats in educational institutions are provided for by reason of Articles 15 and
16 of the Constitution of India. Reservation made for the members of the Scheduled
Castes, Scheduled Tribes and Other Backward Classes would, however, is subject to
Article 335 of the Constitution of India. Concededly, Constitution of India can claim
reservation as a matter of right. The provisions contained in Articles 15 and 16 of the
Constitution of India are merely enabling provisions. No writ of or in the nature of
mandamus, thus could be issued.
29. Indisputably, the preliminary examination is not a part of the main examination.
The merit of the candidate is not judged thereby. Only an eligibility criterion is fixed.
The papers for holding the examination comprise of General Studies and Mental
Ability. Such a test must be held to be necessary for the purpose of judging the basic
eligibility of the candidates to hold the tests. How and in what manner the State as
also the Commission would comply with the constitutional requirements of Article
335 of the Constitution of India should ordinarily not be allowed to be questioned.
30. The proviso appended to Article 335 of the Constitution, to which our attention
has been drawn by Mr. Rao, cannot be said to have any application whatsoever in this
case. Lowering of marks for the candidates belonging to the reserved candidates(sic
categories) is not a constitutional mandate at the threshold. It is permissible only for
the purpose of promotion. Those who possess the basic eligibility would be entitled to
appear at the main examination. While doing so, in regard to General English
whereas the minimum qualifying marks are 40% for OCs, it would be 35% for BCs
and 30% for SC/STs and physically handicapped persons. However, those marks
were not to be counted for ranking.
31. We have noticed hereinbefore, that candidates belonging to the reserved
categories as specified in the notification are not required to pay any fee. Their age is
relaxed upto five years. It is, therefore, not correct to contend that what is given by
one hand is sought to be taken by another. They can, thus, appear in the examination
for a number of times. Indisputably, the right conferred upon the
respondents-writ-petitioners in terms of Rules 22 and 22-A of the Andhra Pradesh
State and Subordinate Service Rules, 1996 was to be protected. The extent of
relaxation has been recognized. By reason of such a provision, the right to beBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

considered has not been taken away.
32. Judging of merit may be at several tiers. It may undergo several filtrations.
Ultimately, the constitutional scheme is to have the candidates who would be able to
serve the society and discharge the functions attached to the office. Vacancies are not
filled up by way of charity. Emphasis has all along been made, times without number,
to select candidates and/ or students based upon their merit in each category. The
disadvantaged group or the socially backward people may not be able to compete
with the open category people but that would not mean that they would not be able to
pass the basic minimum criteria laid down therefor.
(emphasis supplied)
66. In the case of D.P. Sharma & Ors. Vs. Union of India & Ors., (1989) Supp.(1) SCC 244 the
Hon'ble Apex Court considered the retrospectivity of criterion for determination of seniority and
held that rules will have prospective effect only. Rules cannot impair the existing rights of officials
who were appointed long prior to coming into force of the Rules. That being their right, the Rules
cannot take it away to their prejudice. Paras No.4 to 6 are reproduced as under:-
4. We have perused the judgment of the Division Bench and also considered the
submissions of the parties. The view taken by the Division Bench appears to be
erroneous. The Rules, no doubt provide that all persons substantially appointed to a
grade shall rank senior to those holding officiating appointments in the grade. But
the Rules have no retrospective effect. It could not impair the existing rights of
officials who were appointed long prior to the Rules came into force. The office
memorandums to which learned single Judge has referred in detail and which we
have extracted above clearly laid down that length of service should be the guiding
principle of arranging the inter-se seniority of officials. The appellants being
governed by those memorandums had the fight to have their seniority determined
accordingly before the Rules came into force. That being their right, the Rules cannot
take it away to their prejudice. The Division Bench was, therefore, clearly in error in
directing that the seniority shall follow their respective confirmations.
5. In construing similar office memorandums in a different context, this is what this
Court has observed in Union of India v. M. Ravi Varma, (SCC p.386, para 14) "As the
said Office Memorandum has, except in certain cases with which we are not
concerned, applied the rule of seniority contained in the Annexure thereto only to
employees appointed after the date of that Memorandum, there is no escape from the
conclusion that the seniority of Ganapathi Kini and Ravi Varma, respondents, who
were appointed prior to December 22. 1959 would have to be determined on the basis
of their length of service in accordance with Office Memorandum dated June 22,
1949 and not on the basis of the date of their confirmation."Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

6. These considerations apply equally to the present case as well. The general rule is if
seniority is to be regulated in a particular manner in a given period, it shall be given
effect to, and shall not be varied to disadvantage retrospectively. The view taken by
the Division Bench, which is in substance contrary to this principle is not sound and
cannot be supported.
(emphasis supplied)
67. The Hon'ble Apex court in the case of S.S. Bola & Ors. Vs. B.D. Sardana & Ors., (1997) 8 SCC
522, in para 198, held that though the legislature may be empowered to enact a law and give it
retrospective effect but such law cannot take away any accrued or vested rights of the employees.
The Hon'ble Apex Court, however, considered the other judgments and held that mere chances of
promotion are not conditions of services and the fact that there was reduction in the chances of
promotion did not tantamount to a change in the conditions of service. A right to be considered for
promotion is a term of service, but mere chances of promotion are not. A mere right to take
advantage of the provisions of an Act is not an accrued right. The Hon'ble Apex Court, therefore,
held that there is no bar for the legislature to amend the law in consequence of which the inter se
position in rank of Executive Engineer might get altered.
68. In the case of B.S. Vadera Vs. Union of India & Ors. (supra), the Hon'ble Apex Court held that
the appropriate legislation will have full effect both prospectively and retrospectively. The rules can
be framed with prospective effect. Para 24 of the judgment is reproduced as under:-
It is also significant to note that the proviso to Article 309, clearly lays down that 'any
rules so made shall have effect, subject to the provisions of any such Act'. The clear
and unambiguous expressions, used in the Constitution, must be given their full ad
unrestricted meaning, unless hedged-in, by any limitations. the rules, which have to
be 'subject to the provisions of the Constitution, shall have effect, 'subject to the
provisions of any such Act. That is, if the appropriate Legislature has passed an Act,
under Article 309, the rules, framed under the Proviso,will have effect,-subject to that
Act; but, in the absence of any Act, of the appropriate Legislature, on the matter, 'in
our opinion, the rules, made by the President, or by such person as he may direct, are
to have full effect, both prospectively and retrospectively. Apart from the limitations'
pointed out above,there is none other, imposed by the proviso to Art.309, regarding
the ambit of the operation of such-rules. In other words, the rules, unless they can be
impeached on grounds such as breach of Part 111, or any other Constitutional
provision, must be enforced, if made by the appropriate authority.
69. In the case of Raj Kumar Vs. Union of India & Ors. (supra), the Hon'ble Apex Court held that
rule can be amended retrospectively. The relevant portion of Para 2 of the judgment reads as
under:-
. . . . . There is no doubt that this rule is a valid rule because it is now well established
that rules made under the proviso to Article 309 of the Constitution are legislative inBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

character and therefore can be given effect to retrospectively. . . .
70. In the case of Ashoka Kumar Thakur Vs. Union of India & Ors.(supra), the Constitution Bench of
the Hon'ble Apex Court held that Article 15(5) of the Constitution of India is valid to the extent that
it permits reservation for socially and educationally backward classes in State or State-aided
educational institutions subject to the exclusion in the creamy layer from the OBCs. The majority of
Judges i.e.four out of five held that the question of validity of the inclusion of private unaided
institutions within the purview of Article 15(5) left open for a later occasion. However, Hon'ble Mr.
Justice Dalveer Bhandari held that the said inclusion of private unaided institutions is in violation of
the basic structure of the Constitution and hence invalid.
71. Now we proceed to decide both the questions mentioned above which were mainly argued at
length by both the parties.
Question No.1. :
Whether Notification dated 25.4.2008 which came into force with effect from
28.12.2002, is violative of Articles 14 and 16 of the Constitution, as it takes away the
vested and accrued rights retrospectively?
72. Mr. Sanjeev Prakash Sharma , the learned counsel for petitioners, Bajrang Lal Sharma & others
argued that on the basis of judgment in the cases of Virpal Singh Chauhan and Ajit Singh I decided
by the Hon'ble Apex Court, the officers belonging to the General/OBC category of Rajasthan
Administrative Service filed writ petition Nos.2545/1996 and other three connected writ petitions
i.e.2675/1996, 4726/96(646/97) & 2963/1996 in the year 1996 challenging the vires of Rules 8 and
33 of the RAS Rules consequent upon which the benefit of accelerated promotions to next
promotional posts were extended to the candidates belonging to the reserved quota i.e. the SCs and
STs and who were also granted the benefit of accelerated seniority. The petitioners in those writ
petitions sought directions from this Court for restoration of their seniority above the roster
promotees. During the pendency of writ petition, the respondent-Government amended the Various
Service Rules including the RAS Rules vide Notification dated 1.4.1997 giving the benefit of seniority
to senior general/Other Backward Classes candidates who were promoted later to the said
immediate higher post/grade above the candidates belonging to the SCs and the STs who were
earlier promoted. The members of the Rajasthan police Service also filed similar writ petitions and
all were tagged and decided by the common order dated 2.4.1998 by the Division Bench of this
Court (B.K. Sharma & Anr. Vs. State of Rajasthan & Ors.(supra)). This Court allowed the writ
petition and one of the directions was that senior general/OBC candidates will regain their seniority
on immediate higher post. The above judgment was challenged by the reserved candidates before
the Hon'ble Apex Court by way of Civil Appeal No.2866/1998 (Ram Prasad Vs. D.K. Vijay
(supra))and other connected appeals, which were decided on 16.9.1999. The Hon'ble Apex Court
held that inter se seniority must be determined on the basis of decision in the cases of Ajit Singh I
and Ajit Singh II on points 1 to 3 stated therein, meaning thereby, the Notification dated 1.4.1997
was upheld and the benefit of regaining seniority on promotional post was maintained. Therefore,
the matter attained finality. So far as members of the Rajasthan Police Service are concerned, theBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

judgments of the Division Bench, in the case of B.K. Sharma (supra) and the Hon'ble Apex Court in
the case of Ram Prasad Vs. D.K. Vijay (supra) were acted upon. The State Government published a
revised seniority list of Rajasthan Police Service officers on the basis of regaining principle as on
1.4.1997 and thereafter, the review DPC was convened for considering cases of promotions from
Rajasthan Police Service to the Indian Police Service, and on the basis of revised seniority list, senior
general/OBC candidates were promoted in I.P.S. including Mr. B.K. Sharma and reserved
promotees like Mr.Chunni Lal etc., were reverted. In the Rajasthan Administrative Service also, the
State Government complied with the directions given in the judgments in the cases of B.K. Sharma
(supra) and Ram Prasad Vs. D.K. Vijay (supra) referred above and issued a provisional seniority list
on that basis on 26.6.2000 and the senior general/OBC candidates were shown above the reserved
promotees on immediate higher post. Since the selection scale in Rajasthan Administrative Service
is granted 50% by merit and 50% by seniority cum merit, seniority becomes important and the
principle to frame the seniority, had already been finalised by the Hon'ble Apex Court. Therefore,
the rights of seniority and promotion which had vested in the petitioners, as per the judgment of the
Hon'ble Apex Court, itself is being taken back by the impugned notification.
73. Mr. S.C. Gupta, the learned counsel appearing on behalf of petitioner Gyan Prakash Gupta
contended that on the basis of seniority list, may be provisional, issued on the basis of Notification
dated 1.4.1997 upheld by the Hon'ble Apex Court, 15 persons including the petitioner Gyan Prakash
Gupta and Shiv Narayan were promoted in Super Time Scale under Rule 31 of the RAS Rules against
the year 2001-02 for a period of one year vide the order dated 29.11.2005. The respondent-State
extended the order of promotion in Super Time Scale of 50 persons vide the order dated 26.12.2006.
The earlier orders were further extended vide the order dated 9.7.2008. He, therefore, contended
that even the petitioners and other similarly situated persons were promoted in Super Time Scale.
Therefore, the right which stood vested is being taken back by the State Government by issuing the
impugned Notification dated 25.4.2008, and therefore, the same is violative of Article 14 and 16 of
the Constitution of India.
74. The submission of Mr. G.S. Bapna, the learned Advocate General is that no member of Rajasthan
Administrative Service was promoted during the period from 1.4.1997 to 28.12.2002, and therefore,
no right is accrued to them. So far as change in position in the seniority list on the basis of impugned
notification is concerned, the same cannot be said to have taken away the accrued or vested right as
higher position in seniority list is not a vested right.
75. Mr. Ashok Gaur, the learned counsel appearing on behalf of respondent No.3, a reserved
candidate, contended that although a provisional seniority list dated 26.6.2000 was issued in
pursuance of the order of the Hon'ble Apex Court in the case of Ram Prasad Vs. D.K. Vijay but
thereafter final seniority list was never issued and the said provisional seniority list dated 26.6.2000
has been quashed by the Single Bench of this Court vide order dated 30.5.2001 in the case of
Hanuman Singh Bhati CWP No.2966/2000 and the said judgment was upheld by the Division
Bench also vide its judgment dated 12.9.2001. The Special Leave Petition was preferred against the
judgment of the Division Bench and the matter is now pending before the Hon'ble Apex Court in CA
No.171/2002 wherein the Hon'ble Apex Court has stayed the contempt proceedings vide the order
dated 25.2.2002. In these circumstances,it cannot be said that the rights of the petitioners haveBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

been finalized or they have acquired any right.
76. We have considered the submissions of the learned counsel for the parties.
77. Article 14 guarantees equality before law and equal protection of laws. Article 15 protects citizens
against discrimination. The word employment being wider, there is no dispute that it takes within
its fold, the aspect of promotions to posts above the stage of level of recruitment.
78. Article 16(1) provides to every employee otherwise eligible for promotion or who comes within
the zone of consideration, a fundamental right to be considered for promotion. Equal opportunity
here means the right to be considered for promotion. If a person satisfies the eligibility and zone
criteria but is not considered for promotion, then there will be a clear infringement of his
fundamental right to be considered for promotion, which is his personal right. Promotion being a
condition of service and having regard to the requirements thereof it was expected that the
employer-State should have followed the said principle.
79. Where promotional avenues are available, seniority becomes closely interlinked with promotion
provided such a promotion is made after complying with the principle of equal opportunity stated in
Article 16(1). For example, if the promotion is by rule of seniority-cum-suitability, the eligible
seniors at the basic level as per seniority fixed at that level and who are within the zone of
consideration must be first considered for promotion and be promoted if found suitable. In the
promoted category they would have to count their seniority from the date of such promotion
because they get promotion through a process of equal opportunity. Similarly, if the promotion from
the basic level is by selection or merit or any rule involving consideration of merit, the senior who is
eligible at the basic level has to be considered and if found meritorious in comparison with others,
he will have to be promoted first. If he is not found so meritorious, the next in order of seniority is to
be considered and if found eligible and more meritorious than the first person in the seniority list,
he should be promoted. In either case, the person who is first promoted will normally count his
seniority from the date of such promotion. That is how right to be considered for promotion and the
seniority attached to such promotion become important facets of the fundamental right guaranteed
in Article 16(1).
80. The principles of seniority-cum-merit and merit-cum-seniority are conceptually different. For
the former, greater emphasis is laid in seniority, though it is not the determinative factor, while in
the later, merit is the determinative factor. Providing a quota is not new in the service jurisprudence
and whenever the feeder category itself consists of different category of persons and when they are
considered for any promotion, the employer fixes a quota for each category so that the promotional
cadre would be equi-balanced and at the same time, category of persons in the feeder category
would get the opportunity of being considred for promotion. This provision actually effectuates the
constitutional mandate engrafted in Article 16(1), as it would offer equality of opportunity in the
matters relating to employment and it would not be the monopoly of a specified category of persons
in the feeder category to get promotions.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

81. Where the seniority list prepared by the Government ignored the date of selection of the
employees and there was also violation of the quota rule, it was not only erroneous but also violative
of Articles 14 and 16 of the Constitution and was liable to be quashed.
82. If the rules were to be interpreted in a manner conferring seniority to the roster point promotees
who have not gone through the normal channel where basic seniority or selection process was
involved, then the rules would be ultra vires of Articles 14 and 16 of the Constitution of India. Article
16(4-A) could not also help. Such seniority, if given, would amount to treating unequals equally,
rather, more than equals. Equality is a basic feature of the Constitution of India and any treatment
of equals unequally or unequals as equals will be violative of basic structure of the Constitution.
83. In the case of State of Gujarat & Anr. Vs. Raman Lal Keshav Lal Soni, reported in (1983) 2 SCC
33, the Constitution Bench of the Hon'ble Apex court considered the retrospective amendment in
the facts and circumstances of that case and held that the legislature is undoubtedly competent to
legislate with retrospective effect to take away or impair any vested right acquired under existing
laws but since the laws are made under a written Constitution, and have to conform to the do's and
don'ts of the Constitution, neither prospective nor retrospective laws can be made so as to
contravene Fundamental Rights. The law must satisfy the requirements of the Constitution today
taking in to account the accrued or acquired rights of the parties today. The law cannot say, twenty
years ago the parties had no rights, therefore, the requirements of the Constitution will be satisfied if
the law is dated back by twenty years. We are concerned with today's rights and not yesterday's. A
legislature cannot legislate today with reference to a situation that obtained twenty years ago and
ignore the march of events and the constitutional rights accrued in the course of the twenty years.
That would be most arbitrary, unreasonable and a negation of history.
84. In the case of Ex-Capt.K.C. Arora & Anr. Vs. State of Haryana & Ors., reported in (1984) 3 SCC
281, three-Judge Bench of the Hon'ble Apex Court held that the amendment of law taking away
vested rights with retrospective effect is invalid, if it is violative of the present acquired or accrued
fundamental rights of the affected person. The Government of Punjab prior to the formation of
Haryana made statutory rules under Article 309 of the Constitution which are called The Punjab
National Emergency (Concessions) Rules, 1965. Rule 5 was relating to seniority, promotion,
increment, pension and leave of Government employees. It says that the period spent on military
service by a Government employee shall count for seniority, promotion, increment and pension in
the service of post held by him immediately before his joining the military service. According to
these rules and the previous assurances given by the Government the petitioners were to be given
seniority by counting period of military service for the purpose of determining seniority, increments
and pension etc. Immediately on appointment of the petitioners as temporary Assistant Engineers
they became entitled to get their seniority fixed giving them the benefit of their military service but
the gradation list prepared, however, did not include the military service of the petitioners for the
purpose of fixation of their seniority. The State of Haryana just to deprive the petitioners, and others
similarly situated, of military service amended the rules with retrospective effect from 1st
November, 1966 vide Haryana Government Gazette Notification
No.G.S.R.77/Const/Art.309/Amend/(1)/76 dated 22nd March, 1976. The definition of 'military
service' was amended. The Hon'ble Apex Court considered and held that this notification datedBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

22.3.1976 has been issued with retrospective effect from November 1, 1966 and restricted the
benefits of military service upto January 10, 1968, the date on which, the first emergency was lifted
with the result that the vested rights which accrued to the petitioners in 1969, 1970 and 1971 have
been taken away. The Hon'ble Apex Court considered the right of seniority, promotion, increment,
pension and leave of Government employees as vested and accrued right. The judgment of the
Constitution Bench in the case of State of Gujarat Vs. Raman Lal Keshav Lal Soni (Supra) was also
considered in Paras 22 and 23 and the Hon'ble Apex Court held that the law appears to be well
settled and the Haryana Government cannot take away the accrued rights of the petitioners and the
appellants by making amendment of the rules with retrospective effect and declared the Notification
dated 22.3.1976 to be ultra vires of the Constitution, insofar as they affect prejudicially persons who
had acquired rights stated therein.
85. In the case of T.R. Kapur & Ors. Vs. State of Haryana & Ors., reported in 1986 (Supp.) SCC 584,
the Hon'ble Apex Court considered the Punjab Service of Engineers, Class I, PWD (Irrigation
Branch) Rules, 1964. The Hon'ble Apex Court observed that the unamended Rule 6(b) conferred a
vested right on persons like the petitioners which could not be taken away by retrospective
amendment of Rule 6(b). Any rule which affects the right of a person to be considered for promotion
is a condition of service although mere chance of promotion may not be. The power to frame rules to
regulate the conditions of service under the proviso to Article 309 carries with it the power to amend
or alter the rules with a retrospective effect. An authority competent to lay down qualifications for
promotion, is also competent to change the qualifications. The rules defining qualifications and
suitability for promotion are conditions of service and they can be changed retrospectively. This rule
is, however, subject to a well recognized principle that the benefits acquired under the existing rules
cannot be taken away by an amendment with retrospective effect, that is to say, there is no power to
make such a rule under the proviso to Article 309 which affects or impairs vested rights.
86. In the case of P.D. Agarwal & Ors. Vs. State of U.P. & Ors. reported in (1987) 3 SCC 622, the
Hon'ble Apex Court considered the rights of Assistant Engineers appointed on temporary basis
under the unamended rules and entitled them to the benefit of the entire period of their service from
the date of such appointment for the purposes of inter se seniority and promotion alongwith the
appointees to the permanent posts. Therefore, on the basis of Rule 23 as it was before the
amendment made in 1971, held that the Assistant Engineers are entitled to have their seniority
reckoned from the date of their being members of the service. The Hon'ble Apex Court held that the
amendments of 1969 and 1971 were not only disadvantageous to the future recruits against
temporary vacancies but they were made applicable restrospectively from March 1, 1962 even to
existing officers recruited against temporary vacancies through the Public Service Commission. It is
well settled that any rule which affects the rights of a person to be considered for promotion is a
condition of service. Though the Government has power under proviso to Article 309 to make such
rules and to amend them giving retrospective effect, but if the rules purport to take away the vested
rights and are arbitrary and not reasonable then such retrospective amendments are subject to
judicial scrutiny if they have infringed Articles 14 and 16. For promotion from Assistant Engineer to
the post of Executive Engineer seniority-cum- merit is the criterion in accordance with the service
rules in question.Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

87. In the case of Union of India & Ors. Vs. Tushar Ranjan Mohanty & Ors., reported in (1994) 5
SCC 450, the Hon'ble Apex Court considered that the respondents in that appeal who were members
of Indian Statistical Service. The respondent No.1 belonged to the general category whereas
respondents No.2 to 9 belonged to the Scheduled Castes. Respondents 2 to 9 were promoted from
Grade IV to Grade III against vacancies for SCs & STs under the instructions of the Government of
India from time to time. Respondent No.1 being senior to respondents 2 to 9 in the Grade,
successfully impugned his supersession before the Central Administrative Tribunal on the ground
that reservation in respect of appointments by promotion, was not permitted under the Rules. The
Tribunal, without disturbing the promotion of respondents 2 to 9, granted to respondent No.1
necessary relief in respect of promotion and seniority over respondents No.2 to 9. Subsequently,
Rule 13 was amended with effect from 27.11.1972 by the notification dated 20.2.1989 and the
reservation for Scheduled Castes and Scheduled Tribes was provided even in the appointments
made by way of promotion. On the basis of this amendment the appellant Union of India sought
quashment of the Tribunal's decision in respect of the promotion of respondent No.1. Respondent
No.1 in turn challenged the validity of the retrospective amendment of the Rules. The Hon'ble Apex
Court while dismissing the appeal of the Union of India, held, The legislatures and the competent
authority under Article 309 of the Constitution of India have the power to make laws with
retrospective effect. This power, however, cannot be used to justify the arbitrary, illegal or
unconstitutional acts of the Executive. When a person is deprived of an accrued right vested in him
under a statute or under the Constitution and he successfully challenges the same in the court of
law, the legislature cannot render the said right and the relief obtained nugatory by enacting
retrospective legislation.
88. In the case of K.Ravindranath Pai & Anr. Vs. State of Karnataka & Anr., reported in 1995
Supp.(2) SCC 246, considered that both the appellants were belonging to the common cadre of
Junior Engineers upto 8.1.1974. That cadre got bifurcated into the cadre of Junior Engineers
(Division I) for graduates and Junior Engineers (Division II) for non-graduates with effect from
9.1.1974. Therefore, on 9.1.1974 respondents were required to fit the appellants in the proper cadre.
Obviously and admittedly on 9.1.1974 the appellants were having graduation degrees. In fact both of
them had got their degrees since long from 1967 and 1970 respectively. Consequently, when the
question of allotting the appellants to the proper bifurcated cadre of Junior Engineers with effect
from 9.1.1974 came up, the respondents were bound to treat the appellants as belonging to the
bifurcated cadre of Junior Engineers (Division-I) for graduates with effect from 9.1.1974. They
cannot be treated as belonging to the Junior Engineers (Division-I)from 1967 and 1970
retrospectively as such a separate cadre of Junior Engineers (Division-I) did not exist during that
period. The Hon'ble Apex Court held that in view of the settled legal position, therefore, it must be
held that the Act insofar as it sought to introduce by Section 2(1) (i), retrospective bifurcation of the
common cadre of Junior Engineers into two cadres of Junior Engineers (Division I)for graduates
and Junior Engineers (Division-II) for non-graduates from 1. 11.1956 is inoperative at law. It must
be held, on a parity reasoning which appealed to the High Court when it held in writ petition
no.3182 of 1973 and connected matters, that Section 2(1)(ii) could not operate retrospectively to
destroy common pay scales available to both the Junior Engineers graduates and
non-graduates.Section 2(1)(i) also could not operate retrospectively to bifurcate the said common
cadre with effect from 1.11.1956. It will also have only prospective effect. Consequently, theBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

bifurcation of pay scales as well as of the common cadre of Junior Engineers would legally become
effective at the highest from 9.1.1974 when the Government order of even date introducing such a
scheme saw the light of the day.
89. In the case of K.Narayanan & Ors. Vs. R.Mahadev & Ors., reported in 1994 Supp.(1) SCC 44, the
Hon'ble Apex Court considered the retrospective operation of the rules and held that the rules
operate prospectively. Retrospectivity is exception. Even where the statute permits framing of rule
with retrospective effect the exercise of power must not operate discriminately or in violation of any
constitutional right so as to affect vested right. The rule-making authority should not be permitted
normally to act in the past. The impugned rule made in 1985 permitting appointment by transfer
and making it operative from 1976 subject to availability of vacancy in effect results in appointing a
Junior Engineer in 1986 with effect from 1976.
Retrospectivity of the rules is a camouflage for appointment of Junior Engineers from a back date.
The rule operates viciously against all those Assistant Engineers who were appointed between 1976
to 1975.
90. The Hon'ble Apex Court in the case of R.S. Ajara & Ors. Vs. State of Gujarat & Ors., reported in
(1997) 3 SCC 641 held that a benefit that has accrued under the existing rules cannot be taken away
by an amendment with retrospective effect. No statutory rule or administrative order can whittle
down or destroy any right which has become crystallised. No rule can be framed under the proviso
to Article 309 of the Constitution which affects or impairs the vested rights. Para 16 of the judgment
is reproduced as under:-
The resolution dated 31-1-1992 has been assailed by the promotee officers on the
ground that it is retrospective in operation and affects their rights. The law in this
field is well settled by the decisions of this Court. A benefit that has accrued under the
existing rules cannot be taken away by an amendment with retrospective effect and
no statutory rule or administrative order can whittle down or destroy any right which
has become crystallized and no rule can be framed under the proviso to Article 309 of
the Constitution which affects or impairs the vested rights. Can it be said that the
resolution dated 31-1-1992 makes any change in the existing provision governing the
seniority so as to take away or deprive the respondents of a right which has accrued
to them or which has crystallized? As noticed earlier, the 1981 Rules do not contain
any principle governing the seniority of Assistant Conservators of Forests appointed
under the said Rules. Shri P.P. Rao has invited our attention to the Handbook for
Personnel Officers issued by the General Administrative Department of the
Government Gujarat. In para 1 of Chapter V, dealing with Seniority, it is stated:
In the case of direct recruits appointed on probation, the seniority would be
determined ordinarily with reference to the adte of their appointment on probation
while in the case of the promotees, seniority would be determined with reference to
the date of their promotion to long-term vacancies (emphasis supplied)Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

91. The Constitution Bench of the Hon'ble Apex Court again in case of Chairman, Railway Board &
Ors. Vs. C.R. Rangadhamaiah & Ors. (supra) considered its earlier judgment in the case of State of
Gujarat Vs. Raman Lal Keshav Lal Soni referred above and held that expressions vested rights or
accrued rights have been used while striking down the impugned provisions which had been given
retrospective operation so as to have an adverse effect in the matter of promotion, seniority,
substantive appointment etc., of the employees, taking away the benefit already available to the
employee under the existing rule is arbitrary, discriminatory and violative of the rights guaranteed
under Articles 14 and 16 of the Constitution. Para 20, 22, 23, 24 and 34 in the case of Chairman,
Railway Board are reproduced as under:-
20. It can, therefore, be said that a rule which operates in futuro so as to govern
future rights of those already in service cannot be assailed on the ground of
retroactivity as being violative of Articles 14 and 16 of the Constitution, but a rule
which seeks to reverse from an anterior date a benefit which has been granted or
availed of, e.g., promotion or pay scale, can be assailed as being violative of Articles
14 and 16 of the Constitution to the extent it operates retrospectively.
22. In State of Gujarat v. Raman Lal Keshav Lal Soni decided by a Constitution Bench
of the Court, the question was whether the status of ex- ministerial employees who
had been allocated to the Panchayat service as Secretaries, Officers and Servants of
Gram and Nagar Panchayats under the Gujarat Panchayat Act, 1961 as government
servants could be extinguished by making retrospective amendment of the said Act in
1978. Striking down the said amendment on the ground that it offended Articles 311
and 14 of the Constitution, this Court said:
"The legislature is undoubtedly competent to legislate with retrospective effect to
take away or impair any vested right ac-quired under existing laws but since the laws
are made under a written Constitution, and have to conform to the do's and don'ts of
the Constitution neither prospective nor retrospective laws can be made so as to
contravene Fundamental Rights. The law must satisfy the requirements of the
Constitution today taking into account the accrued or acquired rights of the parties
today. The law cannot say, twenty years ago the parties had no rights, therefore, the
requirements of the Constitution will be satisfied if the law is dated back by twenty
years. We are concerned with today's rights and not yesterday's. The legislature
cannot legislate today with reference to a situation that obtained twenty years ago
and ignore the march of events and the constitutional rights accrued in the course of
the twenty years. That would be most arbitrary, unreasonable and a negation of
history."
23. The said decision in Raman Lal Keshav Lal Soni & Ors. (supra) of the Constitution Bench of this
Court has been followed by various Division Benches of this Court.
24. In many of these decisions the expressions "vested rights" or "accrued rights" have been used
while striking down the impugned provisions which had been given retrospective operation so as toBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

have an adverse effect in the matter of promotion, seniority, substantive appointment, etc. of the
employees. The said expressions have been used in the context of a right flowing under the relevant
rule which was sought to be altered with effect from an anterior date and thereby taking away the
benefits available under the rule in force at that time. It has been held that such an amendment
having retrospective operation which has the effect of taking away a benefit already available to the
employee under the existing rule is arbitrary, discriminatory and violative of the rights guaranteed
under Articles 14 and 16 of the Constitution. We are unable to hold that these decisions are not in
consonance with the decisions in Roshan Lal Tandon, B.S. Yadav and Raman Lal Keshav Lal Soni.
(emphasis supplied)
34.. . . .The Full Bench of the Tribunal has, in our opinion, rightly taken the view that the
amendments that were made in Rule 2544 by the impugned notifications dated 5.12.1988, to the
extent the said amendments have been given retrospective effect so as to reduce the maximum limit
from 75% to 45% in respect of the period from 1.1.1973 to 31.3.1979 and reduce it to 55% in respect
of the period from 1.4.1979, are unreasonable and arbitrary and are violative of the rights
guaranteed under Articles 14 and 16 of the Constitution."
92. So far as facts of the present case are concerned, it is clear that B.K. Sharma's and other
connected writ petitions were filed before the Division Bench of this Court challenging the
accelerated promotions as well as consequential seniority to the members of the reserved category
on the basis of ratio laid down by the Hon'ble Apex Court in Virpal Singh Chouhan's case (supra)
and Ajit Singh-I's case (supra), and during the pendency of the writ petition, the respondent-State
itself amended the rule by adding proviso below the existing provisos in the Various Service Rules
including the RAS Rules on 1.4.1997 giving the benefit of regaining of seniority to senior
general/OBC candidates above the reserved promotees on the next higher/promotion post. The writ
petitions filed by the members of RAS as well as the RPS were clubbed. The Division Bench of this
Court allowed the writ petition vide the judgment dated 2.4.1998. The said judgment was upheld by
the Hon'ble Apex Court with slight modification in Ram Prasad's case (supra) on 16.9.1999. The
Hon'ble Apex Court held that inter se seniority vis-a-vis roster point promotees and general category
promotees will be determined on the basis of judgment in the cases of Ajit Singh I and Ajit Singh II
(supra) on points 1 to 3 stated therein. Therefore, the notification dated 1.4.1997 whereby the
proviso was added below the existing proviso in the Various Service Rules was upheld by the
Hon'ble Apex Court also. Therefore the accrued rights stood vested in the petitioners and other
similarly situated persons. It is relevant to mention that so far as the members of the Rajasthan
Police Service are concerned, the order of the Division Bench of this Court as well as the Hon'ble
Supreme Court referred above were implemented and the persons who were given accelerated
seniority were reverted and whom were deprived of the same benefit were promoted. In the RAS
also, the judgments in the cases of B.K. Sharma (supra) and Ram Prasad Vs. D.K. Vijay (supra) were
complied with and on that basis, a provisional seniority list was issued on 26.6.2000, wherein the
name of petitioner No.1 Bajrang Lal Sharma as on 1.4.1997 was mentioned at Serial No.129, whereas
the names of respondents No.3 and 4 namely, Suraj Bhan Meena and Sriram Choradia were
mentioned at Serial No.142 and 147 respectively. The said right of seniority in the petitioners, above
the respondents (reserved promotees) stood vested as per final adjudication of their rights by the
Hon'ble Supreme Court in Ram Prasad Vs. D.K. Vijay decided on 16.9.1999. However, there wasBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

some dispute amongst General category candidates that merit promotees should be treated as senior
and they should be placed above the seniority promotees. Therefore, the said seniority list was
challenged by the merit promotees amongst the general promotess and the Single Bench of this
Court vide its judgment dated 30.5.2001 decided the controversy and held that merit promotees will
rank senior and will be placed above the general seniority promotees. The Single Bench judgment
was upheld by the Division Bench also vide judgment dated 12.9.2001. It was also decided that
roster point promotees will rank junior from both the general category promotees. It is relevant to
mention that the roster point promotee did not challenge the order of the Division Bench in this
regard and it is only the State of Rajasthan who has challenged the order of the Division Bench
before the Hon'ble Apex Court against general category promotees on the ground that seniority
promotees should be placed above the merit promotees. The Civil Appeal No.171/2002 State of
Rajasthan Vs. Hanuman Singh Bhati & Ors., in this regard is pending before the Hon'ble Apex Court
as stated by the learned counsel for both the parties. However, the Hon'ble Apex Court has not
stayed the operation of the order of the Single Bench or the Division Bench.
93. The accrued rights stood vested in the petitioners under the Notification dated 1.4.1997, by
judgment of Division Bench dated 2.4.1998 in B.K. Sharma Vs. State of Rajasthan and the judgment
of the Hon'ble Apex Court dated 16.9.1999 in Ram Prasad Vs. D.K. Vijay, have been taken away by
the State Government retrospectively vide Notification dated 25.4.2008 and has made the above
judgment of the Division Bench and Hon'ble Supreme Court redundant, which is not permissible.
The Hon'ble Supreme Court in the case of Union of India Vs. Tushar Ranjan Mohanty reported in
(1994) 5 SCC 450, held, When a person is deprived of an accrued right vested in him under a statute
or under the Constitution and he successfully challenges the same in the Court of law, the legislature
cannot render the said right and the relief obtained nugatory by enacting retrospective legislation.
94. The Constitution Bench of the Hon'ble Supreme Court in the case of Chairman, Railway Board
Vs. C.R. Rangadhamaiah (supra) held, 'a rule which seeks to reverse from an anterior date, a benefit
which has been granted or availed of, e.g., promotion or pay scale, can be assailed as being violative
of Articles 14 and 16 of the Constitution to the extent it operates retrospectively. The Hon'ble
Constitution Bench also considered its number of earlier judgments and observed that In many of
these decisions the expressions "vested rights" or "accrued rights" have been used while striking
down the impugned provisions which had been given retrospective operation so as to have an
adverse effect in the matter of promotion, seniority, substantive appointment, etc. of the employees.
The said expressions have been used in the context of a right flowing under the relevant rule which
was sought to be altered with effect from an anterior date and thereby taking away the benefits
available under the rule in force at that time. It has been held that such an amendment having
retrospective operation which has the effect of taking away a benefit already available to the
employee under the existing rule is arbitrary, discriminatory and violative of the rights guaranteed
under Articles 14 and 16 of the Constitution........
95. The above discussion makes it clear that retrospective effect of Notification dated 25.4.2008 has
taken away the accrued and vested rights of the petitioners, therefore, it is arbitrary, discriminatory
and violative of the rights guaranteed under Articles 14 and 16 of the Constitution. Therefore, we
declare the Notification dated 25.4.2008 as ultra vires to the Constitution and the same is herebyBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

quashed.
Question No.2 :
Whether the Notification dated 28.12.2002 is violative of Articles 14 and 16 of the
Constitution?
96. Vide Notification dated 28.12.2002, the State Government made amendment in the Various
Service Rules as specified in the Schedule, whereby existing proviso inserted vide Notification dated
1.4.1997, has been deleted with effect from 1.4.1997 and by the same notification dated 28.12.2002,
a new proviso was added that a candidate who has got the benefit of proviso inserted vide
Notification 01.04.1997 on promotion to an immediate higher post shall not be reverted and his
seniority shall remain unaffected.
97. The Rajasthan Administrative Service Rules were framed in the year 1954. Rule 8 of the said
Rules provide for reservation of vacancies for the SC/ST. Rule 33 relates to seniority. It says that
seniority of persons appointed to the post encadred in the service shall be determined from the date
of appointment on the post after regular selection in accordance with the provisions of these rules.
Appointment on ad hoc or urgent temporary basis shall not be deemed to be appointment after
regular selection. Sub-rule (vi) of rule 33 says that the persons selected and appointed as a result of
selection, which is not subject to review and revision, shall rank senior to the persons who are
selected and appointed as a result of subsequent selection.
98. In the case of Indra Sawhney(supra), the Hon'ble Apex Court held that Article 16(4) does not
permit reservation in the matter of promotion. The Hon'ble Apex Court made it clear that on this
question, their decision shall operate only prospective and shall not affect the promotions already
made, whether made on temporary or officiating or regular/permanent basis. It was further directed
that wherever resevations are already provided in the matter of promotion - be it Central Services or
State Services, or for that matter services under any Corporation, authority or body falling under the
definition of State in Article 12- such reservations may continue in operation for a period of five
years from this day. Within this period it would be open to the appropriate authorities to revise,
modify or reissue the relevant rules to ensure the achievement of the objective of Article 16(4). If any
authority thinks that for ensuring adequate representation of 'backward class of citizens' in any
service, class or category it is necessary to provide for direct recruitment therein, it shall be open to
it to do so. It was also made clear that it would be impermissible for the State to extend the
concessions and relaxations to members of reserved categories in the matter of promotion without
compromising the efficiency of the administration.
99. In view of the commitment of government to protect the interest of SC/ST category, the Central
Government decided to continue the existing policy of reservation in the matter of promotion for the
SC/ST. To carry out this, Article 16 of the Constitution of India was amended with effect from
17.6.1995 by inserting the new clause (4-A) in the said Article to provide for reservation in
promotion of SC/ST. The new clause (4-A) reads as under:-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

"(4A) Nothing in this Article shall prevent the State from making any provision for
reservation in matters of promotion to any class or classes of posts in the services
under the State in favour of the Scheduled Castes and the Scheduled Tribes which, in
the opinion of the State, are not adequately represented in the services under the
State."
100. After the above amendment made in the Constitution, the Hon'ble Apex Court in the case of
Union of India Vs. Virpal Singh Chauhan (supra) held that a roster point promotee getting benefit of
accelerated promotion would not get consequential seniority. The same view was further accepted
by the Hon'ble Apex Court in the case of Ajit Singh-I(supra).
101. In view of the above decision of the Hon'ble Apex court, the State of Rajasthan, in exercise of
powers conferred by the proviso to Article 309 of the Constitution of India, made an amendment in
various service rules of Rajasthan on 1.4.1997 by adding new proviso after existing last proviso of
rule, which reads as under:-
That if a candidate belonging to the Scheduled Caste/Scheduled Tribe is promoted to
an immediate higher post/grade against a reserved vacancy earlier than his senior
general/OBC candidate who is promoted later to the said immediate higher
post/grade, the general/OBC candidate will regain his seniority over such earlier
promoted candidates of the Scheduled Caste/Scheduled Tribe in the immediate
higher post/grade.
102. The State Government by way of above-referred amendment on 1.4.1997 protected the seniority
of senior general/OBC candidates that they will regain their seniority over reserved promotees of the
SC/ST promoted earlier in the immediate higher post/grade.
103. In view of the above two decisions of the Hon'ble Apex Court in the cases of Virpal Singh
Chauhan (supra) and Ajit Singh-I (supra), clause (4-A) of Article 16 was again amended and benefit
of consequential seniority was given in addition to accelerated promotion to the roster point
promotees by the Constitution (Eighty-Fifth Amendment) Act, 2001 on 4.1.2002 with effect from
17.6.1995. The number of writ petitions were preferred in the Hon'ble Apex court challenging the
constitutional validity of the the Constitution (Seventy-Seventh Amendment ) Act, 1995 and the
Constitution (Eighty-Fifth Amendment) Act, 2001 including the writ petition (civil) No.61/2002
M.Nagaraj and writ petition (civil) no.234/2002 All India Equality Forum, wherein the State of
Rajasthan was also impleaded as party.As mentioned above, while deciding the question No.1, the
interim orders were passed in both the writ petitions.
104. In view of the Constitution (Eighty-Fifth Amendment) Act, 2001 and the interim orders passed
in the writ petitions in the Hon'ble Apex Court, the respondent-State of Rajasthan further amended
the Rajasthan Various Service Rules on 28.12.2002 deleting the 'proviso' which was added on
1.4.1997 with effect from 1.4.1997 and added new proviso with effect from the date of issuance of the
notification, which is reproduced as under:-Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Provided that a candidate who has got the benefit of proviso inserted vide
Notification No.F.7 (1) DOP/A-II/96 dated 01.04.1997 on promotion to an immediate
higher post shall not be reverted and his seniority shall remain uneffected. This
proviso is subject to final decision of the Hon'ble Supreme Court of India in Writ
Petition (Civil) No.234/2002 All India Equality Forum V/s Union of India & Others.
105. The constitutional validity of the Constitution (Seventy-Seventh Amendment ) Act, 1995 and
the Constitution (Eighty-Fifth Amendment) Act, 2001 was upheld by the Hon'ble Apex Court in
M.Nagaraj's case (supra) on 19.10.2006. However, individual cases were not decided and were left
open to be decided by the appropriate Benches in accordance with the law laid down in the said
order. The first writ petition (civil) no.234/2002 All India Equality Forum Vs. Union of India & Ors.,
wherein the State of Rajasthan is respondent No.4, is still pending in the Hon'ble Apex Court. The
State of Rajasthan further amended the Various Service Rules vide impugned Notification dated
25.4.2008 and with effect from 28.12.2002 and the proviso which was added/inserted vide
Notification dated 28.12.2002 was deleted. In pursuance of this amended provision, the respondent
State issued revised seniority list of RAS offices and all the reserved promotees were shown senior
and placed above the senior general candidates who got the benefit of earlier amended rule by way
of proviso with effect from 1.4.1997 based on two judgments of the Hon'ble Apex Court in the cases
of Virpal Singh Chauhan (supra) and Ajit Singh-I(supra). The said Notifications dated 28.12.2002
and 25.4.2008 as well as seniority list issued in pursuance thereof are under challenge in this writ
petition preferred on behalf of the senior general candidates/members of the Rajasthan
Administrative Service.
106. The Hon'ble Apex Court, while upholding the constitutional validity of the Constitution
(Seventy-Seventh Amendment ) Act, 1995 and the Constitution (Eighty-Fifth Amendment) Act,
2001 in M.Nagaraj's case (supra), in para 79 onwards, specifically laid down that the concepts of
catch up rule and consequential seniority are judicially evolved concepts to control the extent of
reservation. The source of these concepts is service jurisprudence. These concepts cannot be
elevated to the status of an axiom like secularism, constitutional sovereignty, etc. It cannot be said
that by insertion of the concept of consequential seniority the structure of Article 16(1) stands
destroyed or abrogated. It cannot be said that the equality code under Articles 14, 15 and 16 of the
Constitution is violated by deletion of catch-up rule. These concepts are based on practices.
However, such practices cannot be elevated to the status of a constitutional principle so as to be
beyond the amending power of the Parliament. In para 80, the Hon'ble Apex Court referred its
earlier judgment in the case of M.G. Badappanavar (supra) and observed that the service rule
concerned did not contemplate computation of seniority in respect of roster promotions. The
Hon'ble Apex Court also referred the earlier judgments in the cases of Virpal Singh Chauhan (supra)
and Ajit Singh-I(supra) and held that roster promotions were meant only for the limited purpose of
due representation of backward classes at various levels of service and, therefore, such roster
promotion did not confer consequential seniority to the roster-point promotee. In the case of Ajit
Singh II (supra) the circular which gave seniority to the roster-point promotees was held to be
violative of Articles 14 and 16. It was further held in M.G. Badappanavar that equality is the basic
feature of the Constitution and any treatment of equals as unequals or any treatment of unequals as
equals violated the basic structure of the Constitution. For this proposition, reliance was placed onBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

the judgment in the case of Indra Sawhney (supra) while holding that if creamy layer among
Backward Classes were given some benefits as Backward Classes, it will amount to equals being
treated unequals. Further in Para 81 of M.Nagaraj case (supra), the Hon'ble Apex Court observed
that in the cases of M.G. Badappanavar (supra) and Ajit Singh I(supra), the question of validity of
Constitutional Amendments was not involved, and these cases were essentially concerned with the
weightage. Whether weightage of earlier accelerated promotion with consequential seniority should
be given or not to be given are matters which would fall within the discretion of the appropriate
Government, keeping in mind the backwardness, inadequacy of representation in public
employment and overall efficiency of services.
107. Article 16(4) provides for reservation for Backward Classes in cases of inadequate
representation in public employment. Article 16(4) is enacted as a remedy for the past historical
discriminations against a social class. The object in enacting the enabling provisions like Articles
16(4), 16(4-A) and 16(4-B) is that the State is empowered to identify and recognise the compelling
interests. If the State has quantifiable data to show backwardness and inadequacy then the State can
make reservations in promotions keeping in mind maintenance of efficiency which is held to be a
constitutional limitation on the discretion of the State in making reservation as indicated by Article
335. The concept of efficiency, backwardness, inadequacy of representation are required to be
identified and measured. That exercise depends on availability of data. That exercise depends on
numerous factors. It is for this reason that enabling provisions are required to be made because each
competing claim seeks to achieve certain goals. How best one should optimise these conflicting
claims can only be done by the administration in the context of local prevailing conditions in public
employment. Therefore, there is a basic difference between equality in law and equality in fact.
However, when the State fails to identify and implement the controlling factors then excessiveness
comes in, which is to be decided on the facts of each case. Efficiency in administration is held to be a
constitutional limitation on the discretion vested in the State to provide for reservation in public
employment. In Para 108 of M.Nagaraj case, the Hon'ble Apex Court specifically opined that even
after insertion of proviso in Article 335, the limitation of overall efficiency is not obliterated. Reason
is that efficiency is a variable factor. It is for the State concerned to decide in a given case, whether
the overall efficiency of the system is affected.
108. In Indra Sawhney's case, the Hon'ble Apex Court considered the merit and efficiency in
administration with reference to Articles 15 and 16 and it was observed that the relevance and
significance of merit at the stage of initial recruitment cannot be ignored. It cannot also be ignored
that the very idea of reservation implies selection of a less meritorious person. At the same time, we
recognise that this much cost has to be paid, if the constitutional promise of social justice is to be
redeemed. So far as Articles 16 and 335 are concerned, relevant paras No.836, 837 and 838 are
reproduced as under:-
836. We do not think it necessary to express ourselves at any length on the
correctness or otherwise of the opposing points of view referred to above. (It is,
however, necessary to point out that the mandate if it can be called that of Article 335
is to take the claims of members of SC/ST in consideration, consistent with the
maintenance of efficiency of administration. It would be a misreading of the article toBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

say that the mandate is maintenance of efficiency of administration. Maybe, it is
wrong to treat merit as synonymous with efficiency in administration and that merit
is but a component of the efficiency of an administrator. Even so, the relevance and
significance of merit at the stage of initial recruitment cannot be ignored. It cannot
also be ignored that the very idea of reservation implies selection of a less meritorious
person. At the same time, we recognise that this much cost has to be paid, if the
constitutional promise of social justice is to be redeemed. We also firmly believe that
given an opportunity, members of these classes are bound to overcome their initial
disadvantages and would compete with and may, in some cases, excel - members of
open competition. It is undeniable that nature has endowed merit upon members of
backward classes as much as it has endowed upon members of other classes and that
what is required is an opportunity to prove it. It may not, therefore, be said that
reservations are anti-meritarian. Merit there is even among the reserved candidates
and the small difference, that may be allowed at the stage of initial recruitment is
bound to disappear in course of time. These members too will compete with and
improve their efficiency along with others.
837. Having said this, we must append a note of clarification. In some cases arising
under Article 15, this Court has upheld the removal of minimum qualifying marks, in
the case of Scheduled Caste/Scheduled Tribe candidates, in the matter of admission
to medical courses. For example, in State of M.P. Vs. Nivedita Jain, admission to
medical course was regulated by an entrance test (called Pre-Medical Test). For
general candidates, the minimum qualifying marks were 50% in the aggregate and
33% in each subject. For Scheduled Caste/Scheduled Tribe candidates, however, it
was 40% and 30% respectively. On finding that Scheduled Caste/Scheduled Tribe
candidates equal to the number of the seats reserved for them did not qualify on the
above standard, the Government did away with the said minimum standard together.
The Government's action was challenged in this Court but was upheld. Since it was a
case under Article 15, Article 335 had no relevance and was not applied. But in the
case of Article 16, Article 335 would be relevant and any order on the lines of the
order of the Government of Madhya Pradesh (in Nivedita Jain) would not be
permissible, being inconsistent with the efficiency of administration. To wit, in the
matter of appointment of Medical Officers, the Government or the Public Service
Commission cannot say that there shall be no minimum qualifying marks for
Scheduled Caste/Scheduled Tribe candidates, while prescribing a minimum for
others. It may be permissible for the Government to prescribe a reasonably lower
standard for Scheduled Castes/Scheduled Tribes/Backward Classes consistent with
the requirements of efficiency of administration it would not be permissible not to
prescribe any such minimum standard at all. While prescribing the lower minimum
standard for reserved category, the nature of duties attached to the post and the
interest of the general public should also be kept in mind.
838. While on Article 335, we are of the opinion that there are certain services and
positions where either on account of the nature of duties attached to them or the levelBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

(in the hierarchy) at which they obtain, merit as explained hereinabove, alone counts.
In such situations, it may not be advisable to provide for reservations. For example,
technical posts in research development organisations, departments, institutions, in
specialities and super-specialties in medicine, engineering and other courses in
physical sciences and mathematics, in defence services and in the establishments
connected therewith. Similarly, in the case of posts at the higher echelon e.g.,
Professors (in Education), Pilots in Indian Airlines and Air India, Scientists and
Technicians in nuclear and space application, provision for reservation would not be
advisable.
109. In H.P. Samanaya Varg Karamchari Kalayan Mahasangh Vs. State of H.P. & Ors. CWP-T
No.2628/2008 decided by the Division Bench of the Himachal Pradesh High Court on 18.9.2009,
the State of Himachal Pradesh issued instructions dated 7.9.2007 which makes provision for
reservation in the matter of promotions with consequential seniority for all classes of post in the
service under the State in favour of the SC/ST. The State instructions were challenged by Himachal
Pradesh Samanaya Varg Karamchari Kalayan Mahasangh. The Division Bench considered the
judgment of the Hon'ble Apex Court in the cases of Indra Sawhney(supra), R.K. Sabharwal (supra)
and M.Nagraj (supra), and after quoting the relevant paras of M.Nagraj's case, held that the State
has not carried out any exercise before issuing the instructions to collect the quantifiable data on the
lines indicated in M.Nagaraj's case to show backwardness, inadequacy of representation and overall
efficiency of State administration, and therefore, allowed the writ petition and quashed the
instructions. The last operative portion of the judgment reads as under:-
. . . . . . . . . . ..
In the present case, admittedly, the State before issuing the instructions has not
carried out any such exercise to collect such data. The reason given by the State is
that in the State of Himachal Pradesh there was already a provision for reservation in
promotion prior to the judgment in Indra Sawhneys case and thus collection of data
as mandated in M. Nagarajs case is not required. This submission is totally without
any basis. In Himachal Pradesh reservation was provided in promotion prior to the
judgment in Indra Sawhneys case. After Indra Sawhneys case such reservation could
not have been permitted beyond the period of 5 years. To get over this judgment the
constitutional amendments were enacted. The Apex Court in no uncertain terms
while upholding the constitutional amendments held that the collection of
quantifiable data to establish backwardness and inadequacy of representation
keeping in view the efficiency of administration of the State is necessary before
making reservations. This requirement never existed prior to the judgment.
According to the State it had after due consideration decided to make provision for
reservations in promotion much earlier. Due consideration is totally different from
collecting quantifiable data. This exercise has to be conducted and no reservation in
promotion can be made without conducting such an exercise. Therefore, the State
cannot be permitted to make reservations till such exercise is carried out and
clear-cut quantifiable data is collected on the lines indicated in M. Nagarajs case. WeBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

may also point out that other than making vague reference to due consideration
having been done, till date the State has not produced before us any clear-cut
quantifiable data which could establish the need for reservation.
Merely because the amended provision of the Constitution enable the State to make
reservation is no ground not to collect data. Therefore, the instructions have to be
struck down as being violative of the law laid down in M. Nagarajs case by the Apex
court.
No doubt under the provisions of Article 16(4B) the State is entitled to grant
consequential seniority on promotion to the members belonging to the scheduled
castes and scheduled tribes but there must be data available with the State
Government to show that the scheduled castes and scheduled tribes are inadequately
represented in the services or in the cadre to which promotions have to be made.
Therefore, also these instructions are illegal and liable to be set-aside.
It has also been contended on behalf of the petitioners that the observations of the
Apex Court in M. Nagarajs case in para 121 introduce the concept of creamy layer
even with regard to scheduled castes and scheduled tribes. This argument cannot be
accepted. The observations made in para 121 are general in nature. It would be
pertinent to mention that in Indra Sawhneys case it was clearly stated that the
concept of creamy layer was only applicable to OBCs. In M. Nagarajs case the Apex
Court has only stated that the concept of creamy layer should be kept in mind while
making reservations. It has nowhere specifically held that the concept of creamy layer
is applicable to SCs and STs also. The reference made to the concept of creamy layer
in para 121, appears to be a general observation with regard to the concept of
reservation in respect of all classes including OBCs and not in respect of scheduled
castes and scheduled tribes only.
In view of the above discussion, we allow the writ petition and hold that until the
State collects data and material establishing the need for reservation by collecting
quantifiable data to show backwardness, inadequacy of representation and keeping in
mind the overall efficiency of State administration, the State is not entitled to make
reservation in promotion for the scheduled castes and scheduled tribes. The
impugned instructions are accordingly quashed.
Since we have quashed the impugned instructions on these grounds we have not gone
into the other arguments raised with regard to the challenge to different portions of
the instructions.
110. In the case of Anil Chandra & Ors. Vs. Radha Krishna Gaur & Ors., (2009) 9 SCC 454, the
Government of Uttar Pradesh issued notification on 14.9.2007 by which the U.P. Government
Servants Seniority (Third Amendment) Rules, 2007 were issued. Rule 8-A of the said Rules was
relating to entitlement of consequential seniority to a person belonging to Scheduled Castes orBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Scheduled Tribes. The said Rules were issued after upholding the constitutional validity of the
Constitution (Eighty-Fifth Amendment) Act, 2001 by the Hon'ble Apex Court in M.Nagaraj's
case(supra). The validity of the aforesaid Rule 8-A was challenged by the engineers of the Irrigation
Department by way of writ petition before the High Court of Allahabad, Lucknow Bench, Lucknow
and some other persons who were working on the post of Superintending Engineer in U.P. Jal
Nigam. The High Court in the writ petition filed by the Engineers of the Irrigation Department
passed an interim order by which the seniority of the petitioners in that writ petition and other
promoted officers, which was in existence prior to the enforcement of the aforesaid Rules of 2007,
shall not be disturbed in pursuance of the said Rules and no reversion shall be effected. Similarly, in
another writ petition, the Division Bench by an interim order directed that the seniority of the
respondents which was in existence prior to the enforcement of the aforesaid Rules of 2007 shall not
be disturbed in pursuance of the Rules. The said interim orders were challenged before the Hon'ble
Apex Court. The Hon'ble Apex Court considered its earlier judgment in M.Nagaraj's case (supra)
wherein Constitution Bench held that the provisions contained in Article 16(4-A) of the Constitution
of India is the only enabling provision and the State is not bound to make reservation for SCs/STs in
the matter of promotion. However, if they wish to exercise their discretion and make such provision,
the State has to collect quantifiable data showing backwardness of the class and inadequacy of
representation of that class in public employment in addition to compliance with Article 335 of the
Constitution of India. The Hon'ble Apex Court observed that in the present case, neither any effort
has been made to identify the class or classes of posts for which reservation is to be provided in
promotion nor any exercise has been done to quantify the extent of reservation. The Hon'ble Apex
Court, therefore, dismissed the appeals and upheld the interim order of the Division Bench of the
High Court of Allahabad. Para 17 and 20 of the judgment are reproduced as under:-
17. In the present case and in the facts and circumstances stated herein earlier, we are
of the view that it was the constitutional obligation of the State, at the time of
providing reservation in the matter of promotion to identify the class or classes of
posts in the service for which reservation is required, however, neither any effort has
been made to identify the class or classes of posts for which reservation is to be
provided in promotion nor any exercise has been done to quantify the extent of
reservation. Adequate reservation does not mean proportional representation. Rule
8(A) has been inserted mechanically without taking into consideration the
perquisites for making such a provision as required under Article l6 (4-A) of the
Constitution of India. The ceiling limit of 50%, the concept of creamy layer and the
compelling reasons, namely, backwardness, inadequacy of representation and overall
administrative efficiency are all constitutional requirements without which, the
structure of equality of opportunity in Article 16 would collapse. However, in this
case, as stated, the main issue concerns the "extent of reservation" and in this regard,
the State should have shown the existence of the compelling reasons, namely,
backwardness, inadequacy of representation and overall administrative efficiency
before making provision for reservation.
20. In the light of the reasons above-mentioned, we are of the view that the High
Court was fully justified in granting the present interim order and there is noBajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

infirmity in the same. Since the interim order passed by the High Court, which has
not been interfered with by us in this judgment, we make it clear that the grant of
interim order and any observation made by the High Court while granting interim
order and any observations made by us in this order shall not influence the High
Court to decide the writ petition on merits and the High Court shall not be influenced
by any of the observations made by us in this order.
111. The exercise by the State as per M.Nagaraj's case in respect of three compelling reasons by
collecting quantifiable datas showing backwardness of the class and inadequacy of representation of
that class in public employment and compliance with regard to Article 335 of the Constitution
before making any rule providing reservation in promotion with consequential seniority for SCs and
STs candidates is necessary, otherwise as held by the Hon'ble Apex Court in Ajit Singh Juneja-I's
case, the result will be that majority of the posts in the higher grade shall be held at one stage by
persons who have not only entered in service on the basis of reservation and roster but have
excluded the general category candidates from being promoted to the posts reserved for general
category candidates merely on the ground of their initial accelerated promotions and this will not be
consistent with the requirement of the spirit of Article 16(4) or Article 335 of the Constitution.
112. The above discussion makes it clear that clause (4A) of Article 16 was only an enabling provision
and as held by the Hon'ble Apex Court in M.Nagaraj's case (supra), that the State is not bound to
make reservation for the SCs and the STs in the matters of promotion. However, if they wish to
exercise their discretion and make such provision, the State has to collect quantifiable data showing
backwardness of the class and inadequacy of representation of that class in public employment in
addition to compliance with Article 335. Admittedly, the said exercise has not been done by the
State Government either before amending the Various Service Rules including the RAS Rules vide
Notification dated 28.12.2002 or before issuing Notification dated 25.4.2008.
113. The learned Advocate General, in this regard, conceded while arguing the application under
Article 226(3) of the Constitution in SBCWP No.8104/2008, before the learned Single Judge. The
said admission of the learned Advocate General finds place in the impugned order dated 9.7.2009
passed by the learned Single Judge. The learned Advocate General fairly and frankly admitted that
the required exercise as per M.Nagaraj's case (supra) was not done by the State before issuing
Notifications dated 25.4.2008 or 28.12.2002. The State Government could not have amended the
Various Service Rules on 28.12.2002 only on the basis of the Constitution (Eighty-Fifth
Amendment) Act on 4.1.2002, as the same was only an enabling provision, and in case the State
Government wanted to give effect to the Constitution (Eighty-Fifth Amendment) Act, then the three
exercises, as mentioned in M.Nagaraj's case (supra), was necessary, which were admittedly not
carried out before issuing the impugned notification. Therefore, the impugned Notification dated
28.12.2002 is violative of Articles 14, 16 and 16(4A) of the Constitution, and the same is liable to be
declared ultra vires to the Constitution.
114. Apart from the above, it is also to be noted that the amendment in the Various Service Rules
vide Notification dated 1.4.1997 was upheld by the Division Bench of this Court in B.K. Sharma's
case (supra) and also by the Hon'ble Apex Court in the case of Ram Prasad Vs. D.K. Vijay (supra).Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

Vide the aforesaid two judgments, the right of seniority and promotion had vested in the persons
belonging to general/OBC categories. Therefore, to nullify the judgment of B.K. Sharma's case and
the Hon'ble Apex Court in the case of Ram Prasad Vs. D.K. Vijay (supra), and to deprive the
petitioners from their accrued and vested right under statute and above judgments, the Various
Service Rules including the RAS Rules, could not have been amended vide Notification dated
28.12.2002 with effect from 1.4.1997, as held by the Hon'ble Supreme Court in Union of India & Ors.
Vs. Tushar Ranjan Mohan, (1994) 5 SCC 450 and Chairman, Railway Board Vs. C.R.
Rangadhamaiah, (1997) 6 SCC 623.
115. In view of above discussion, the notification dated 28.12.2002 is liable to be quashed, and the
same is hereby quashed and set aside.
116. In view of our findings on both the questions, the writ petitions No.8104/2008, 6241/2008 and
7775/2009 are allowed and Notifications dated 28.12.2002 and 25.4.2008 are declared ultra vires to
the provisions of Articles 14 and 16 of the Constitution, and the same are hereby quashed and set
aside. All consequential orders or actions taken by respondent-State including seniority list of Super
Time Scale as well as Selection Scale of the Rajasthan Administrative Service officers, on the basis of
above notifications are also quashed and set aside.
117. Special Appeal (Writ) Nos.618/2009, 3/2010, 611/2009 and 610/2009 are directed against
interim orders passed in aforesaid writ petitions. Since the writ petitions have been disposed off
finally, the special appeals are dismissed as infructuous.
118. The parties are directed to bear their own costs.
(RAGHUVENDRA S.RATHORE),J. (NARENDRA KUMAR JAIN),J.
Skant/Bajrang Lal Sharma And Ors vs State Of Raj And Ors on 5 February, 2010

