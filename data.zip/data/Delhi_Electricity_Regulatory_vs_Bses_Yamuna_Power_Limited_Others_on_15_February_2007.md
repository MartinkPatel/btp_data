Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited &
Others on 15 February, 2007
Equivalent citations: 2007 AIR SCW 1602, 2007 (3) SCC 33, AIR 2007 SC
(SUPP) 601, (2008) 1 WLC(SC)CVL 45, (2007) 3 SCALE 289, (2007) 2
SUPREME 343
Bench: Arijit Pasayat, S. H. Kapadia
           CASE NO.:
Appeal (civil)  2733 of 2006
PETITIONER:
Delhi Electricity Regulatory Commission
RESPONDENT:
BSES Yamuna Power Limited & Others
DATE OF JUDGMENT: 15/02/2007
BENCH:
Dr. Arijit Pasayat & S. H. Kapadia
JUDGMENT:
J U D G M E N T KAPADIA, J.
This is an appeal by special leave concerning tariff fixation by Delhi Electricity Reforms Commission
('DERC' for short). In this appeal, a short point which arises for consideration is : whether on the
facts and circumstances of the case DERC was right in reducing the rate of depreciation from 6.69%
to 3.75%.
The facts giving rise to this civil appeal are as follows. On 23.1.92 Ministry of Power ('MOP' for
short) issued a notification (which was published in Official Gazette on 31.1.92) stating that a
licensee shall provide for depreciation in its Annual Statement of Accounts commencing on 1.4.92 as
per straight-line method in respect of asset(s), indicated in column no.1, at the rates indicated in the
columns of Schedule VI to the Electricity (Supply) Act, 1948 which vests the power to stipulate the
principles for depreciation in the said Ministry. A note was appended to the said Notification under
which it was stated that the reference to the straight-line method in the said Notification was
intended to differentiate the same from the concept of reducing balance method and not to derive
rates from the fair life of the asset(s).
On 29.3.94, in continuation of the above Notification, MOP amended the Schedule. A bare reading
of the said amendment indicates absence of linkage between the fair life of an asset and the rate of
depreciation. On 23.11.2000 the Delhi Electricity Reforms Act, 2000 ('DERA' for short) was enactedDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

by the State Legislature to establish DERC and to restructure the electricity industry in Delhi.
On 6.1.2001 the Government of National Capital Territory of Delhi ('GoNCTD' for short) decided to
unbundle Delhi Vidhyut Power ('DVB' for short), its undertaking and assets, and vest the same in six
successor companies including three distribution companies ('DISCOMs' for short). These three
DISCOMs are  North Delhi Power Limited ('NDPL' for short), BSES Yamuna Power Limited
('BYPL' for short) and BSES Rajdhani Power Limited ('BRPL' for short). On 15.2.2001 GoNCTD
issued the Request for Qualification document ('RFQ' for short) to the prospective bidders. It
indicated the period of transition and stated that tariff principles were being worked out by DERC so
that the investors could plan their investments. That, transition period was to be of 5 years. A tariff
order would be made available to the bidders before the last date of submission of their Statement of
Qualifications. Under RFQ document a chapter titled "Investment Highlights" was incorporated
(see: Chapter 5). Under para 5.9 of the RFQ document, DVB referred to Tariff Setting Principles for
2002-03, 2003-2004, 2004-05 and 2005-06. In the said para it is further stated that for revising
the tariffs in 2001- 02, DVB has already filed a tariff application with DERC in which DVB has
proposed Tariff Setting Principles through which the tariffs of 2001-02 would get adjusted in
2002-03, 2003-2004, 2004-05 and 2005-06. In para 5.10 of the RFQ document, GoNCTD stated
that it was committed to the power sector reforms in Delhi; that this was its commitment which
stood reflected in various steps undertaken by it, namely, creation of DERC, appointment of
financial advisors for unbundling and for privatization, enactment of DERA, approval to the
structure of unbundled DVB on 6.1.01 and commencement of the process of inviting RFQ bids
through the issuance of RFQ document. At this stage, it may be noted that DERC was created in
March 1999. However, vide para 5.10 of the RFQ document, GoNCTD indicated that by passing
DERA its role was restricted to provide directions on policy matters in the process of electricity tariff
determination. In the context of future tariffs, the RFQ document further clarified that the order to
be passed by DERC on the tariff application of DVB for the year 2001-02 would be made available to
the bidders before the last date of submission of Statement of Qualification ('SOQ' for short) so that
the bidders would have a clear idea of the tariff level for the next five years. This was, in order to
enable the bidders to prepare an appropriate business strategy [See: para 3.3.6.2]. In para 9.7 of the
RFQ document, the Tariff Setting Principles were set out. Vide para 9.7, the Tariff Principles were
summarized in the form of a formula which referred to tariff in any year as equal to tariff in the
financial year 2001-02 plus sum total of all expenses such as power purchase cost, salary, O&M,
administration and general expenses, interest on debt, return on equity minus increase in revenue
due to reduction in T&D losses divided by estimated units sold in a year. Vide para 9.7, it was
clarified that under the formula, the tariffs stipulated by DERC for the financial year 2001-02 was to
get adjusted in the financial years 2002-03, 2003-04, 2004-2005 and 2005-06. Vide para 9.7, it
was further stated that the above Tariff Setting Principles have been proposed to provide certainty to
the tariff determination process. Under para 9.7.2 of the RFQ document, it was further stipulated
that the order of DERC on the tariff proposal of DVB for the financial year 2001-02 shall be made
available by 2.4.01 so that the pre-qualified bidders could submit their financial bids for the
proposed DISCOMs.
On 23.5.01, DERC issued its Retail Supply Tariff Order on the Annual Revenue Requirement ('ARR'
for short) for the financial year 2001-02 and the Tariff Determination Principles for the financialDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

years 2002-2003 till 2005-06. This Tariff Order computed the ARR of DVB for the ensuing year
2001-02. As can be seen from the Tariff Order, DVB had computed the ARR for financial year
2001-02 at Rs.5514 crores. DVB suggested to DERC for framing Tariff Setting Principles in order to
develop a long-term business strategy so that tariff levels could be indicated for the next five years
[See: para 1.6.6]. Under the said order, DERC computed the depreciation expenditure for DVB in
relation to distribution of asset(s) at 6.83%. Before DERC, DVB had submitted Annual Accounts for
the financial year 1998-99 based on Weighted Average Depreciation Rate ('WADR' for short) which
was proposed at 6.83% based on the said Notifications issued by MOP. On these projections, DERC
held vide Tariff Order dated 23.5.01, that for want of details regarding asset-composition at the
beginning of financial year 2001-02, it approved the WADR of 6.83% for computing the
depreciation. At this stage it may be noted that on unbundling, the WADR stood reduced to 6.69%
for the financial year 2001-02. The said depreciation was chargeable to ARR of DVB. It was
quantified at Rs.232 crores for the financial year 2000-01 and at Rs.262 crores for the financial year
2001-02.
On 20.11.01 GoNCTD notified the Transfer Scheme under Section 15, 16 and 60 of DERA setting out
rules for transfer and vesting of assets, liabilities and obligations of DVB in the three DISCOMs
herein. Under the said Scheme DVB was unbundled, the Opening Balance Sheet of each of the three
DISCOMs gave the value of the Gross Fixed Asset ('GFA' for short) as also the value of Net Fixed
Asset ('NFA' for short) for tariff purposes. The Transfer Scheme was brought into force with effect
from 1.7.02.
On 22.11.01 GoNCTD issued Request for Proposal document ('RFP document' for short). The said
document was accompanied by the Policy Directions issued to the prospective bidders referring to
the transition period of 5 years. It also referred to the Tariff Principles framed by DERC in order to
enable the bidders to develop their business plans and in order to enable the bidders to make their
bids.
On 22.11.01, GoNCTD after considering the views expressed by DERC issued Policy Directions
under Section 12 of DERA for restructuring of the Electricity Industry and privatization of
Distribution Companies. In the Policy Directions, GoNCTD clarified that the Directions have been
issued in public interest to enable restructuring of DVB and to privatize the business of distribution.
It was further clarified that the transition period shall be of 5 years (2002 till 2007) to attract private
participation in respect of AT&C loss reduction, tariff structure including return on equity of 16%
and 50% additional revenue arising from AT&C loss reduction with inbuilt incentive to DISCOMs.
Under the Policy Directions, GoNCTD assured the bidders that a BST Order shall be issued by DERC
to facilitate investors to have a full idea of various elements in tariff fixation, before bidding. Vide
para 19 of the Policy Directions, it was clarified that DERC shall be bound by Policy Directions on
and from 22.11.01 till end of financial year 2006-07.
Accordingly on 22.2.2002, DERC issued the BST Order on a Joint Petition filed by GoNCTD owned
Distribution Companies (that is before privatization) and Delhi Power Supply Company Ltd. This
BST Order, issued by DERC, approved Bulk Supply Tariff to be charged by Delhi Power Supply
Company Ltd. to the said DISCOMs, on the basis of the paying capacity of the DistributionDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

Companies. The said BST Order issued by DERC also approved the Opening Levels of AT&C losses
for each Distribution Company. It also approved the Tariff Determination Principles for the period
of 5 years (2002 to 2007). As stated above, this BST Order was issued before bidding giving
certainty to the bidders regarding Tariff Entitlement for the transition period. Based on this order,
the bidders were expected to bid. They were expected to bid on the basis of annual reduction of
AT&C losses over a 5 year period.
Accordingly, M/s. Tata Power Company Limited submitted its bid for purchase of 51% equity in the
North North-West Delhi Distribution Company Limited on the basis of reduction of AT&C losses
which they were to achieve yearwise over a 5 year period (transition period). This was in April/May
2002. Bids were similarly made by M/s. BSES for purchase of 51% equity in the other Distribution
Companies owned by GoNCTD.
For the sake of convenience we are stating the facts concerning the bids submitted by M/s. Tata
Power Company Limited in the context of purchase of 51% equity in the North North-West Delhi
Distribution Company.
On 29.5.02, GoNCTD accepted the bid of M/s. Tata Power Company Ltd. based on the loss
reduction profile, RFP documents etc. Accordingly, M/s. Tata Power Company Ltd. was invited to
sign Share Acquisition Agreement by GoNCTD. This was on 31.5.2002.
On 1.7.02, the Transfer Scheme was brought into force by GoNCTD. The majority share-holding
(51%) and management control of the three Distribution Companies owned by GoNCTD stood
transferred to the successful private bidders. M/s. Tata Power Company Ltd. was one of the three
DISCOMs.
After privatization of Distribution Companies on 1.7.02, the Electricity Act, 2003 was brought into
force on and from 10.6.2003. Section 185 of the said 2003 Act saved DERA by stating that all
directives issued before the commencement of 2003 Act under DERA shall stand expressly saved.
Vide Tariff Order dated 26.6.03 DERC reduced the rate of depreciation from 6.69% to 3.75%.
On 25.7.03 North Delhi Power Ltd. ('NDPL' for short), a joint venture of M/s. Tata Power Company
Ltd., filed a Review Petition before DERC which was dismissed on 25.11.03. The Review Petition was
made by NDPL seeking to challenge the reduction in the rate of depreciation. While rejecting the
Review Petition it was held by DERC that depreciation is a charge to the Profit and Loss Account
and it represents a measure of loss in value of an asset arising from use, efflux of time and market
changes. It was further held that from a regulatory perspective, depreciation is a small amount of
the original cost of the capital asset(s), built into the tariff computation every year with a view to
provide the Utility a source of funding to repay instalments of debt capital. It was further held that
since the asset is used over its operational life, depreciation is a percentage charged over the fair life
of the asset(s). It was further held that in the BST Order dated 22.2.2002 the rate of depreciation
was based on WADR since the details of the asset(s) at the beginning of the financial year 2001-02
were not available and, therefore, at that time DERC had taken the view that instead of rejecting theDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

computation of ARR, submitted by DVB, it was better to give directions to DVB to update their data
so that in future it could file proper computation concerning ARR. It was further held that the
erstwhile DVB was required to file ARR by 31.12.01 for the financial year 2002-03 which they failed
to do so and instead the three Distribution Companies filed a Joint Petition for determination of the
Opening Levels of AT&C losses and also for determination of BST in order to enable the
privatization process to be proceeded further in accordance with the Policy Directions issued by
GoNCTD, that accordingly on 22.2.02 DERC had issued a BST Order on the Opening Levels of
AT&C losses and the BST applicable to the DISCOMs and, therefore, according to DERC, there was
no change in the principles of tariff fixation as regards treatment of expenses and revenue.
According to DERC, the basic principles underlying the approval of various items in ARR remained
unchanged across the first Retail Supply Tariff Order ('RST Order' for short) dated 23.5.01
applicable for the financial year 2001- 2002 and the BST Order dated 22.2.2002 applicable for two
months ending 31.3.02. It was further held that depreciation is the source of debt repayment for a
Utility and since no loan repayment was due during the financial years 2002-03 and 2003-04,
DERC had accepted the request of NDPL and two others to treat depreciation as a source of funding
to partly fund Capital Expenditure. It was further held by DERC that depreciation is a non-cash
expenditure and since there was no loan repayment in the financial year 2002-03 and financial year
2003-04, the allowed depreciation rate of 3.75% will not affect the DISCOMs' operations,
cash-flow/returns as all legitimate expenses were duly covered in the determination of ARR. It was
further held that DERA empowered DERC to depart from the Principles mentioned in Schedule VI
of the said 1948 Act, during the process of tariff determination, by providing in writing the reasons
for such variations. It was held that since there were serious deficiencies in the Fixed Asset Register
('FAR' for short), DERC took the decision to reduce the rate of depreciation from 6.69% to 3.75% in
accordance with the power entrusted to DERC vide Section 28(3) of DERA. It was further held that
the decision taken by DERC was in public interest since the higher rate of depreciation of 6.69%
would cast a heavy burden on the consumers. It was further held that the depreciation expenditure
at the rate of 3.75% allowed by DERC was in accordance with the statutory provisions of DERA, the
Policy Directions of the GoNCTD and the Regulatory Practices. It was further held that it was the
duty of DERC to allow adequate and prudent expenses which fall within the regulation on annual
basis. Accordingly, the Review Petition of NDPL came to be dismissed as per the order of DERC on
25.11.03.
Thereafter on 19.12.03 NDPL filed its petition for determination of ARR for financial year 2004-05
and for determination of Retail Supply Tariff in terms of Section 28 of DERA. Vide Tariff Order
dated 9.6.04 DERC denied to NDPL the assured return on equity at 16% as well as depreciation
expenditure at the rate of 6.69%.
Vide Review Petition dated 8.7.04, NDPL requested DERC to revise its Tariff Order dated 9.6.04.
On 23.7.04 NDPL preferred Writ Petition No.15175 of 2004 before this Court. That petition was
disposed of on 9.8.05 upon constitution of Appellate Tribunal for Electricity ('ATE' for short).
The above Review Petition dated 8.7.04 was dismissed by DERC on 29.10.04.Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

Aggrieved by the above decision of DERC, NDPL preferred Writ Petition No.140 of 2005 in the
Delhi High Court challenging the legality and validity of the impugned Tariff Order dated 9.6.04 in
respect of creation of Regulatory Asset(s) whereby 53% of the operating expenses of NDPL was
deferred without providing a schedule of recovery/amortization. However, in the meantime in view
of the constitution of the ATE, NDPL filed its statutory appeal before the Tribunal (that is ATE).
ATE allowed the appeal of NDPL on the question of depreciation vide Order dated 24.5.06 which
has been challenged by DERC in this civil appeal. By the said order dated 24.5.06 ATE held that
DERC has not given any reasons for deviating from the Principles mentioned in Schedule VI to the
said 1948 Act. By the said order, ATE further held that DISCOMs were entitled to 16% ROE, which is
accepted as final by DERC.
As stated above, aggrieved by the decision of ATE dated 24.5.06, DERC filed the present Civil
Appeal No.2733 of 2006 before this Court limited to the question of depreciation.
On 21.7.06 ATE also allowed another appeal filed by NDPL challenging the Tariff Order dated
9.6.04 concerning creation of Regulatory Asset(s) by DERC.
On 23.8.06 Civil Appeal No.2733 of 2006 filed by DERC came for hearing when the following
interim order was passed:
"After hearing learned counsel for the parties at some length, we feel it would be
appropriate for the Appellate Tribunal to consider the conclusions of the Commission
as if they were good and sufficient for the purpose of making a departure from the
Schedule VI rates. The basic issue involved in this appeal is whether the Appellate
Tribunal was justified in its view that the Commission had not indicated any reason
for deviating from Schedule VI rates. This direction is being given because the
Commission was of the view that no reasons have been indicated. Without expressing
any final opinion, we direct the Tribunal to examine whether the conclusions of the
Commission are supportable in facts and in law. Let the parties appear before the
Appellate Tribunal without further notice on 5th September, 2006 so that the
Appellate Tribunal can fix a confirmed date of hearing or take up the matter on that
very day. The Appellate Tribunal shall decide the matter after taking into
consideration all contentions raised or to be raised by the parties. However, we make
it clear that we have not expressed any opinion on the merits of the case. The exercise
to be undertaken by the Appellate Tribunal shall be only on the question of
depreciation.
It is clarified that order dated 13th June, 2006, we had permitted the process of
determination to be continued by the appellant as directed by the Appellate Tribunal
(by mistake recorded as High Court). The final decision may be taken, but the same
shall be open to challenge by the affected parties. This matter shall be placed for
further hearing after a period of six weeks.Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

It is, however, made clear that we have not given any interim protection for any
period other than the period to which the present appeal relates to.
The determination made by the Appellate Authority shall be indicated to the parties."
As per direction of this Court dated 23.8.06, ATE recorded it findings on the rate of depreciation
vide its order dated 29.9.06 (hereinafter referred to "the impugned order"). By the impugned order,
it was held that depreciation is not a source of fund, it is a process of Allocation of Cost and that
funds are generated by sales and not by depreciation, which is an expenditure incurred in terms of
Schedule VI. At the same time, ATE observed in its impugned order that in certain cases companies
did follow Depreciation Fund Method for replacement of asset(s). According to ATE, Section 28 (3)
of DERA was an enabling provision which empowered DERC to depart from the factors specified in
Schedule VI while determining the revenues subject to DERC recording reasons thereof; that in
respect of depreciation DERC has suggested deviation but there was total non-application of mind
on the part of DERC since the reasons given by DERC for fixing the rate of depreciation at 3.75%
were legally not sustainable. According to ATE, depreciation is a process of cost allocation. It is not a
process of valuation. It is not a cash-flow. It is not a source of funds. Therefore, DERC, according to
ATE, was wrong in assuming that depreciation was built into the tariff as a source of fund to repay
the debt capital. As stated above, DERC had taken the view that since NDPL had not borrowed any
loan during the relevant financial years, there was no liability on NDPL for loan repayment.
According to the impugned order passed by ATE this reasoning was erroneous since depreciation
under Schedule VI was admissible even in cases where the DISCOM has not taken any loan in the
relevant financial year. According to the impugned order, depreciation is an item of deduction in
respect of an outgoing which is notional, and which is a part of profit as also part of the asset(s)
charged. According to ATE, depreciation does not generate cash, it simply allocates the original cost
of an asset to the period in which the asset is used. According to ATE, depreciation is an item of
Allowable Expenditure and if the rate of depreciation is reduced from 6.69% to 3.75% the same will
disable the DISCOMs from funding replacement of one or the other of the equipments/machinery
which becomes obsolete, adversely affecting the distribution system. According to ATE, the DERC
has erred in holding that depreciation is meant to be utilized for meeting working capital
requirement, loan repayment, capital investment etc. According to ATE, depreciation under
Schedule VI is an item of authorized expenditure. According to ATE, DERC was wrong in holding
that depreciation stood built into tariff computation to provide source of funding to repay debt
capital, loan repayment and to meet working capital requirement. By the impugned order, ATE
further held that DERC had proceeded on an erroneous reasoning, namely, that the average fair life
of lines and cables in the distribution system was 25 years and, therefore, the average depreciation
worked out to 3.75%. By the impugned order, ATE came to the conclusion that the above reasoning
of DERC was erroneous since DERC had misread the MOP Notification of 1992, referred to above,
which categorically stated that the straight-line method was not for derivation of rates from the fair
life of the asset(s). Therefore, according to ATE, it was not open to DERC to derive the rate of
depreciation at the rate of 3.75% from the fair life of the equipment as is sought to be done by DERC.
According to ATE, the MOP Notification dated 29.3.94 had allowed depreciation at the rates
mentioned therein on a straight-line method as an authorized expenditure which had no linkage
with the fair life of the asset(s). According to ATE, NDPL was entitled to depreciation in terms ofDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

MOP notification dated 29.3.94, Policy Directions dated 22.11.01 and BST Order dated 22.2.02 and,
therefore, there was no reason to reduce the rate of depreciation from 6.69% claimed by the
DISCOMs herein as an allowable expenditure in terms of Schedule VI of the said 1948 Act. The said
Policy Directions issued by GoNCTD under Section 12 of DERA to DERC, according to ATE, were
binding on the DISCOMs which DERC failed to notice. According to the impugned order, DERC had
accepted the WADR proposed for Generation Company in terms of MOP Notification dated 29.3.94.
This rate was approved by DERC when DVB was in picture. Therefore, there was no reason to
reduce the rate of depreciation for DISCOMs herein on privatization. According to ATE, DERC on
22.2.2002 had issued BST Order which covered Tariff Elements, namely, depreciation, taxes and
return on equity. The investors submitted their bids on the basis of representations contained in the
Policy Directions dated 22.11.01, BST Order dated 22.2.02 and the tariff structure mentioned in
MOP Notification dated 29.3.94. Therefore, according to ATE, the method adopted by DERC to
calculate depreciation on the basis of the fair life was contrary to the above-mentioned BST Order
and Policy Directions as well as MOP Notifications. Further, according to ATE, the rate of
depreciation in term of MOP Notification works out at an average of 6.69%. According to ATE, even
the BST Order issued by DERC proceeds on the basis that depreciation is admissible at a rate for an
identical equipment and, therefore, there was no reason to treat the DISCOMs herein differently.
According to ATE, the Policy Directions of GoNCTD did not indicate depreciation at the rate of
6.69% but while passing the BST Tariff Order dated 22.2.02, DERC had granted depreciation at the
same rate of 6.69%. According to ATE, the BST Tariff Order dated 22.2.02 constituted a parameter
for the DISCOMs herein for the transition period of 5 years. According to ATE, 16% return on equity
was guaranteed. This was not in dispute. However, according to ATE, 16% of the return on equity
can be arrived at only if Allowable Expenditure is made admissible. Lastly, according to ATE,
depreciation has been allowed by DERC at the rate of 6.69% to TRANSCO and GENCO and,
therefore, there was no reason to treat the DISCOMs herein differently. According to ATE, MOP
Notification dated 29.3.94 enabled the DISCOMs herein to claim the accelerated rate of depreciation
so that the Utility can meet Higher Capital Expenditure and Higher Operational Expenditure
requirements. Thus, by the impugned order dated 29.9.06 ATE confirmed and reiterated in detail its
earlier order (dated 24.5.06) in favour of the DISCOMs herein holding that the rate of depreciation
fixed by DERC at 3.75% was erroneous and that the denial of depreciation to the Utility at 6.69%
was not sustainable either in law or in facts. Accordingly, the appeal filed by the DISCOMs herein
stood allowed by ATE. Hence this civil appeal by DERC.
Mr. S.K. Dholakia, learned senior counsel appearing for DERC, submitted that under Section 28 of
DERA, DERC had to fix tariff taking into account the interests of the DISCOMs and the consumers.
Under Section 28, according to learned counsel, DERC is required to follow the Principles of
Schedule VI of the said 1948 Act but it also has the power to deviate from the said Principles for
reasons to be recorded by DERC. In this connection, it was pointed out that in exercise of the powers
under Section 28, DERC had fixed the rate of depreciation at 3.75% having regard to the fair life of
the assets. According to learned counsel, DERC was right in rejecting the claim of 6.69% on the
ground that the said rate could be considered only if there was a debt redemption involved. Learned
counsel further submitted that GoNCTD had never promised 6.69% as rate of depreciation in the
RFQ, RFP or in the Policy Directions. In this connection, it was urged that allowing higher
depreciation at the rate of 6.69% would increase the tariff level imposing a burden of almost Rs.300Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

crores on the consumers for the financial years 2002-03, 2003-04 and 2004-05. Learned Counsel
further submitted that the reliance placed by DISCOMs on MOP Notifications of 1992 and 1994
were totally misplaced. They were issued under the said 1948 Act which stood repealed by DERA to
the extent of inconsistency and that Section 28 of DERA empowered DERC to deviate from the
principles mentioned in Schedule VI to the said 1948 Act. Moreover, according to learned counsel,
even under the MOP Notifications there was a concept of Advance Against Depreciation ("AAD" for
short) provided there existed actual loan liability in a given year. Therefore, in the present case,
according to learned counsel, DERC was right in rejecting the claim of 6.69% on the ground that
such rate was not admissible as there was no question of debt redemption during the aforestated
years. According to learned counsel, MOP Notifications granted higher rate of depreciation
depending on the loan repayment and since in the present case there was no liability of loan
repayment for the DISCOMs during the above years, they were not entitled to the higher rate of
depreciation of 6.69%. According to learned counsel, reliance placed by DISCOMs on the MOP
Notifications was erroneous since the said Notifications are based on the concept of AAD which is
limited to the actual loan liability in a given year. In the circumstances, according to learned
counsel, DERC was right in holding that DISCOMs were not entitled to the depreciation expenditure
at the rate of 6.69%. According to learned counsel, the MOP Notifications show that higher
depreciation was admissible in the regulatory mechanism because at the relevant time the Utility
had undertaken loan repayment liabilities which did not exist for the financial years 2002-03,
2003-04 and 2004-05.
Mr. Dholakia, learned counsel for DERC, next contended that the Policy Directions issued by
GoNCTD on 22.11.01 promised as assured return of 16% on equity and certain incentive on the
Utility attaining overachievement beyond the level specified in the Policy Directions in respect of
AT&C losses. No other promise was made by GoNCTD. It was urged that depreciation is a non-cash
expense, therefore, DERC could permit only reasonable depreciation which in the present case was
3.75%. It was urged that in the above Policy Directions dated 22.11.01 there was no promise that the
rate of depreciation will remain constant for all five years. As regards the BST Order dated 22.2.02
on which reliance has been placed by DISCOMs herein, learned counsel submitted that the said BST
Order was valid only for two months of February and March 2002 and, therefore, there was no
promise under the said BST Order regarding fixation of the rate of depreciation for 5 years. It was
further pointed out that in the said BST Order dated 22.2.02 there were certain variables which
included items of expenditure which varied from year to year, one such item was depreciation.
Accordingly, the Chart on Expenses allowed by DERC for NDPL show different amounts (in crores)
allowed as depreciation expenses in the financial years 2001-02 (two months), 2002-03 (9 months),
2003-04 and 2004-05. This Chart, according to learned counsel, shows that it was open to DERC to
allow depreciation as an item of expense on annual basis.
At this stage, it may pointed out that in the course of hearing before us, learned counsel for NDPL
submitted a Chart suggesting that the denial of depreciation at 6.69% resulted in reduction of rate of
return on equity. In this connection, learned counsel pointed out that the Chart submitted by NDPL
was erroneous. He pointed out that the disallowed depreciation mentioned in the Chart was reduced
from the total allowed ROE for the financial year 2004-05. He pointed out that in respect of the
financial year 2004-05, DERC had calculated 16% ROE and accordingly had allowed Rs.61.69 croresDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

as 16% ROE. However, in addition to the said sum of Rs.61.69 crores, DERC had also granted to
NDPL a sum of Rs.45.62 crores as depreciation. The total sum was, therefore, Rs.117.31 crores and,
therefore, NDPL was wrong in saying that its return on equity got adversely affected on account of
lower rate of depreciation.
On the concept of depreciation, learned counsel urged, relying on certain textbooks, that
depreciation is ordinarily based on fair life of the assets, the rate whereof can vary depending upon
the object sought to be achieved, for example, under I.T. Act, depreciation is a tool for tax incentive
and capital formation. Similarly, depreciation is often prescribed on different basis, in the case of
energy saving devices, pollution control equipments etc. Depreciation calculated under the
Companies Act is intended to arrive at the true and fair value of the assets of the company in order
to keep the shareholders, creditors and investors well informed. Learned counsel urged that in
Electricity Accounting, DERC is entitled to adopt a fair rate of depreciation based on fair life of the
assets so that the consumer is not overburdened. In the present case, it was urged that on the date of
transfer all the accumulated losses were taken over by GoNCTD; that the DISCOMs herein were
aware that the existing tariffs would not be enough to recover the cost of units input in the
immediate future as there were substantial AT&C losses; to recover the cost of units input,
DISCOMs were aware that the tariff would have to be increased to a higher level which was not
practical and for the above reasons GoNCTD offered to the DISCOMs herein assured 16% return on
equity. Accordingly, DISCOMs were required to reduce the AT&C losses. Higher the recovery from
consumers meant higher revenue to the DISCOMs and lower the tariff. Learned Counsel submitted
that the DISCOMs herein were fully aware of the above aspects when they came into business with
an obligation to reduce the said losses to assured levels as per Policy Directions and, therefore, the
rate of depreciation had no relevance to AT&C losses and to 16% ROE. Learned counsel submitted
that it was never the case of DISCOMs that the rate of depreciation had any connection with AT&C
losses. According to learned counsel, DERC had exercised its power under the statute in going for a
departure from Schedule VI to the said 1948 Act. Therefore, according to DERC, DISCOMs herein
were entitled to depreciation in the above years derived from the fair life of the assets since during
the said years there was no debt redemption involved.
Mr. Harish N. Salve, learned senior counsel appearing on behalf of NDPL, submitted that under
Section 28(2) & (3) of DERA, DERC was required to adhere to the financial principles and their
obligations provided in Schedule VI to the said 1948 Act and if DERC wants to depart from those
principles it has to record reasons in writing. Learned counsel submitted that the said reasons to
depart and the flexibility of DERC to depart are both subject to provisions of DERA including
Section 12(3) read with statutory Policy Directions dated 22.11.01 as reaffirmed by Parliament in
Section 185(2)(e) of the Electricity Act, 2003. In this connection, our attention was also invited to
para XVII of the Sixth Schedule to the said 1948 Act which gives the definition of the word "clear
profit". The definition shows that clear profit has to be arrived at after deducting the outgoings. The
word "clear profit" is defined in sub-para (2)(b) of para XVII to mean the difference between the
amount of income and expenditure. The word "expenditure" in sub-para (2) of para XVII refers to
depreciation, computed as hereinbefore set out [See: clause (x)]. Our attention was also invited to
para VI of the Sixth Schedule which, inter alia, states that the licensee shall provide each year for
depreciation such sum calculated in accordance with the principles as the Central Government may,Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

after consulting the Authority, by notification in the Official Gazette, lay down from time to time. In
other words, it was incumbent on the licensee to provide for depreciation in accordance with the
principles as the Central Government may by notification lay down, from time to time. Reliance, in
this connection, was placed on the first MOP Notification dated 23.1.92 in which depreciation was
prescribed in accordance with the straight-line method ("SLM" for short). In the notification there
was a column which indicated the fair life of the assets. However, a Note was added to the said
Notification making it clear that the rate of depreciation shall not be determined on the basis of the
fair life of the assets. The said Note read as under:
"NOTE: The reference to the straight line method in this notification is intended to
differentiate the same from the reducing balance method and not for derivation of
rates from the fair life of the asset and the residual value"
In other words, the rate of depreciation prescribed by the Central Government had no linkage with
the fair life of the assets. Therefore, where accounts were required to be drawn up under the Sixth
Schedule, it was incumbent on the DERC to provide rates of depreciation as per the above MOP
Notification and it was not open to DERC to recalculate the rates on the basis of the fair life of the
assets. Therefore, it was urged on behalf of NDPL that when they made a bid for buying 51% equity
after unbundling in April/May 2002, it was on the basis of the representations held out to the
investors as contained in MOP Notification dated 23.1.92, BST Order dated 22.2.02 and the Policy
Directions dated 22.11.01.
Mr. Salve, learned counsel for NDPL, next submitted that the only reason given by DERC to depart
from the Sixth Schedule was that the fair life of the assets was 25 years and since NDPL was not
required to redeem the debt as it had not borrowed during the aforestated years DERC was entitled
to derive the rate of depreciation at 3.75% having regard to the fair life of the asset(s) (25 years).
According to learned counsel, the above reasoning of DERC was contrary not only to the
representations made to the investors but it was also contrary to the Note appended to MOP
Notification dated 23.1.92 which stated that the rate of depreciation shall not be derived from the
fair life of the asset. Therefore, according to the learned counsel, DERC had departed from the Sixth
Schedule which was untenable and per se illegal.
In the alternative, Mr. Salve submitted that even if DERC was entitled to depart from MOP
Notification dated 23.1.92 and BST Order dated 22.2.02, the impugned order of DERC cannot
constitute a good order under Section 28(3) of DERA as it results in total dismembering of the total
5 year transition mechanism, it renders 16% ROE illusory and it extends the replacement period for
assets from 13.45 years to almost 24 years. Learned counsel submitted that the limited issue in the
present case is: whether DERC is empowered to flout para 17 of the Policy Directions dated 22.11.01
read with para 3.6.2 of the BST Order dated 22.2.02 by changing the depreciation rate from 6.69%
to 3.75% without any justifiable reason after having induced private investment on that premise.
Section 12, according to learned counsel, makes Policy Directions binding upon DERC. The Transfer
Scheme had indicated policy for privatization under Section 14 to 16 of DERA. The said Scheme
recognized the need for the Government to draw up the scheme for privatization. Therefore, in tariff
fixation DERC was required to comply with the Policy Directions dated 22.11.01 issued by GoNCTD.Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

In this context, it was pointed out that Policy Directions dated 22.11.01 and BST Order dated 22.2.02
had fixed the rate of 16% ROE after providing for all expenses including depreciation. They had also
fixed an incentive for reduction in AT&C losses. All these aspects were taken into account while
fixing the transition period of 5 years. The BST was fixed for 5 years and, therefore, it was not open
to DERC to reduce the rate of depreciation and thereby frustrate the reforms and the period of 5
years. It was further pointed out that one of the important problems which had dogged the
privatization process was that the particulars of the assets were not known and, therefore, DERC
had adopted WADR allowable on the assets in question. The rate of depreciation and the rate of
return on equity were significant features of the Transfer Scheme. It was submitted that if DERC is
allowed to reduce the rate then such tinkering would frustrate the reforms. It was further pointed
out that in order to ensure ARR to be met through the tariff, DERC was required to provide the basis
on which the return on equity was to be computed. It was contended on behalf of NDPL that ROE
and the rate of depreciation were significant features of the scheme and if the rate of depreciation is
reduced from 6.69% to 3.75% then the entire package/privatization process would fail. In this
connection, it is pointed out that under the order of the DERC the net return equal to 16% on ROE
in the ARR cannot be computed by reducing the allowable expenses since that would render the
return of 16% nugatory. It is pointed out, in this connection, that the net returns available to the
ARR under the orders of DERC was Rs.61 crores approximately (equal to 16% of ARR); that the
amount of depreciation allowed has been reduced by 60% and if the net return is calculated on the
principles applicable to the BST Tariff then the said return would stand reduced to less than 0.5%.
Therefore, even assuming for the sake of argument that DERC was entitled to deviate from the Sixth
Schedule, the impugned exercise undertaken by DERC leads to unjustifiable reasons. Learned
counsel submitted that DERC was wrong in holding that determination of the principles for tariff
entitlements for next 5 years was not the key factor in the privatization process.
Learned counsel for NDPL next contended that the reasons given by DERC for departing from the
Sixth Schedule was specious, untenable and erroneous. In this connection, it was urged that
depreciation is not a "source of funds". The source is always the "sale price" of goods. Depreciation is
a non-cash charge. It reduces the distributable profit without reducing the cash profit. The
difference between the distributable profit and cash profit is a sum which the company has to retain.
Depreciation in a sense is a source of funds for future investments. However, it is not a "sources of
funds" for the current year. The Sixth Schedule makes it clear that depreciation is an expenditure
properly incurred. Learned counsel for NDPL pointed out that DERC had erroneously assumed that
the rate of 6.69% was some sort of higher depreciation. It is further pointed out that the figure of 25
years is taken by DERC from the MOP Notification which itself clarifies that the said figure is not to
be taken into account for determining the rate of depreciation. It is submitted that DERC cannot
assume the power to alter the depreciation rate as per financial needs of the Utility of the DISCOMs.
It is submitted that if the argument advanced on behalf of DERC was to be accepted, namely, higher
depreciation for higher loan it would lead to disaster. If a DISCOM borrows money from the market
then, according to DERC, it can recover the cost of borrowing from the consumer. Such reasoning
would impose on the consumer twofold liabilities - firstly, the interest burden in such an event could
be passed on to the consumer as a cost and secondly, the redemption of the loan would result in
accelerated depreciation in tariff. Therefore, according to NDPL, DERC had erred in holding that
NDPL was not entitled to depreciation rate of 6.69% as it had not borrowed moneys from theDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

marker during the relevant years. According to learned counsel for NDPL there was no linkage
between depreciation and loan repayment since depreciation is a charge on the income to be kept
aside for asset replacement. Depreciation is admissible so that the cost of the asset can be recovered
by reducing the distributable profit and the money so retained in the business (distributable profit
minus cash profit) can be used for replacement of asset. According to NDPL, the above MOP
Notification dated 23.1.92 (as amended) contemplated different rates of depreciation having no
linkage with the fair life of the asset because MOP wanted faster replacement of the assets. It is
submitted that DERC has failed to appreciate this aspect. It is submitted that by increasing the
period of replacement DERC has taken a retrograde step. It has acted contrary to Section 12 of
DERA. In the circumstances, learned counsel submitted that we should not interfere with the
impugned order of ATE dated 29.9.06 by which ATE has held that the rate of depreciation cannot be
reduced from 6.69% to 3.75%. Mr. S. Ganesh, learned senior counsel appearing on behalf of BYPL
and BRPL, submitted that during the transition period, 2002-07, the tariffs of the aforestated to
DISCOMs had to be fixed strictly in conformity with the BST Order dated 22.2.02. According to
learned counsel, the said order dated 22.2.02 had laid down Normative Principles for tariff fixation.
It was submitted that the said BST Order followed the MOP Notifications dated 23.1.92 and 29.3.94
by which WADR of 6.69% was admissible. During the said transition period it was not permissible
for DERC to depart or deviate on any ground from the above MOP Notifications concerning rate of
depreciation. In the alternative, learned counsel submitted that in the present case the rate has been
reduced only on the basis of the estimated useful life of the assets which in law cannot be considered
to a good or cogent ground or reason for departing from the MOP rates, particularly, when the said
ground or reason is expressly prohibited by the MOP Notification of 1992 which lays down that the
rates shall not be recomputed on the basis of the fair life of the assets. It was submitted that such a
departure from the MOP rates violated Section 28 of DERA read with Section 185 of the Electricity
Act, 2003.
Relying on the doctrine of legitimate expectation, learned counsel submitted that Policy Directions
were issued by GoNCTD (Delhi Government) for facilitating the privatization of the electricity
distribution undertakings in Delhi. The Policy Directions were issued with the object of inducing
investors to bid for taking over the distribution entities. The bidders were invited to submit their
bids on the basis of tariff mentioned in the BST Order dated 22.2.02. In this connection, our
attention was invited by learned counsel to the RFQ document dated 15.2.01. This document gave
the entire programme. Under that programme the anticipated date for issue of the Tariff Order for
2001-02 was 2.4.01 while the date fixed for receiving RFQ bids was fixed as on 16.4.01. Similarly,
the receipt of RFP bids was by 30.8.01. Therefore, according to learned counsel, the bid documents
clearly indicated that the bidders had to file their bids after perusing the Tariff Order for 2001-02.
Learned counsel submitted that, therefore, the bids for privatization were specifically invited on the
clear basis that during the transition period the tariff of the DISCOMs would be fixed in accordance
with the Principles set out in the BST Order to be issued by DERC pursuant to the Policy Directions
dated 22.11.01. Learned counsel, therefore, submitted that the DISCOMs acted and alterd their
position on the basis of the tariffs mentioned in the BST Order read with the Policy Directions which
were not only binding on DISCOMs and GENCO but also on DERC, therefore, DERC was not
entitled to depart from the BST Order during the transition period on any ground whatsoever. In
this connection, learned counsel placed reliance on the order dated 21.7.06 of ATE in the case ofDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

BYPL and BRPL concerning Regulatory Assets. This order of ATE has been accepted by DERC. It
was held by ATE that the Policy Directions dated 22.11.01 were binding on DERC. In that matter the
issue which arose for determination was: whether it was lawful for DERC to direct the DISCOMs
herein to create a Regulatory Asset by capitalizing some of its revenue expenditure and by carrying
the same forward so that the expenditure would not be covered by the tariff admissible to the
DISCOMs during the tariff period. It was held by ATE that the Policy Directions were binding and
that the order passed by DERC was contrary to such directions and, therefore, the impugned order
passed by DERC was illegal and bad in law. This order of ATE, concerning the statutory binding
effect of the Policy Directions, has been accepted by DERC. It has not been challenged. It has
become final. Learned counsel, therefore, submitted that it was not open to DERC to raise any
contrary or inconsistent regarding the binding effect of Policy Directions. Moreover, it was pointed
out that even in the past DERC has followed the MOP Notification in its Tariff Order dated 23.5.01
for financial year 2000-01. This was even without FAR register. Learned counsel pointed out that
the MOP Notification was also followed by DERC in the BST Order dated 22.2.02. In the said BST
Order, there was no reference made for the depreciation rate to be computed on the basis of useful
life of the assets, as has been done in the impugned order of DERC in the present case. Therefore,
according to learned counsel, the departure from the BST Order was unjustifiable as Normative
Principles set out in the BST Order had to be followed till 31.3.07, in terms of the Policy Directions
dated 22.11.01. Learned counsel submitted that the BST Order and the Policy Directions were
intended to be relied upon by the investors for determining varies elements of the tariff so that they
could assess their financial position before filing their bids. Learned counsel urged that if the
impugned order of DERC was allowed to stand then the very object of having a BST Order for 5
years and inviting investors to buy 51% equity on that basis would stand completely frustrated.
Hence, the said representations held out to the investors binds the DERC for the transition period
and it does not allow DERC to deviate from the representations made by GoNCTD on any ground
including principles of accounting different from those set out in the BST Order. In the
circumstances, learned counsel submitted that the Policy Directions gave three assurances to the
investors, namely, ROE of 16%, incentive for overachievement in bringing down the AT&C losses
and recovery of expenses permissible in terms of the financial principles set out in the Sixth
Schedule to the said 1948 Act.
Learned counsel for BYPL and BRPL adopted the contentions advanced on behalf of NDPL. Learned
counsel, however, submitted that if any items of allowable expenditure are disallowed, the
consequence would be that the return earned by the DISCOMs will stand significantly reduced from
16% and this would be in breach of Policy Directions as well as the solemn assurances given to
investors at the time of inviting the bids. If the rate of depreciation allowed is reduced from 6.69% to
3.75%, the result would be that the difference between the amount denied by DERC, on account of
reduction in the depreciation rate and the amount granted as ROE, will show that instead of earning
the assured 16% ROE, the actual return earned by the DISCOMs herein may not be 0.5%. Therefore,
the variations from the Principles set out in the BST order would result in obliteration of the entire
basis of privatization. It was submitted that the DISCOMs herein were obliged to reduce AT&C
losses by 17% over a period of 5 years and in lieu of this promise they were entitled to retain 50% of
the additional revenue resulting from such better performance on part of the respondent DISCOMs.
This was also a part of Policy Directions. In the circumstances, it is not open to DERC to deviateDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

from the Principles mentioned in the BST Order.
Learned counsel for the respondent DISCOMs lastly submitted that for allowing revenue
requirement, DERC was duty-bound to follow the guiding Principles laid down in the Sixth Schedule
to the said 1948 Act which provides for depreciation each year vide Section VI(a) of the Sixth
Schedule. Such sum is required to be calculated in accordance with the principles set out in the MOP
Notifications. The schedule given for calculation of the rates of depreciation refers to the assets
existing in the books of accounts and the amount of depreciation is determined as a percentage of
such value. This procedure is followed by most of the State Electricity Regulatory Commissions in
India. Therefore, according to learned counsel, it was not open to DERC to deviate from the MOP
Notifications and the Principles mentioned therein.
For the following reasons, there is no merit in this civil appeal. Firstly, accounting for costs differs
according to the object and the purpose for which the exercise is undertaken. Depreciation is
Allocation of Costs so as to charge a fair proportion of the depreciable amount in each accounting
period during the expected useful life of the asset(s). Depreciation includes amortization of assets
whose useful life is pre-determined. It includes depletion of resources through the process of use.
Depreciation in Commercial Accounting differs from depreciation in Tax Accounting. In this case,
we are concerned with Electricity Accounting. An asset is recognized in the Balance Sheet when one
expects economic benefits associated with it to flow in future over a period of years. Accordingly, the
asset has a cost or value that can be measured. Matching of revenue and expenses is an important
exercise under Accounting. Depreciation is a part of this exercise. The Allocated Cost of a given year
has to match with the expected revenue for that year. The concept of matching is a concept
according to which expenses are recognized in the Statement of Profit and Loss on the basis of direct
connection between the costs incurred and the earning of specific items of income. Depreciation
helps this concept of matching. The Full Cost Method ('FCM' for short) is a method of matching
income (revenue) and expenses. This method proceeds on the basis that a proper matching of
income and expenses can take place only if total costs are depreciated on a pro rata basis. The FCM,
therefore, avoids distortion of reported earnings. It is in this context that one has to keep in mind
the difference between distributable profits and the cash profits. Depreciation reduces the
distributable profit without reducing the cash profit. The difference between the two is a sum which
the company has to retain to meet the cost of replacement in future. We may clarify that
depreciation is ordinarily not a "source of fund"
under Commercial Accounting, however, as held by this Court in the case of
Ahmedabad Miscellaneous Industrial Workers' Union v. Ahmedabad Electricity Co.,
Ltd. - AIR 1962 SC 1255, in the context of the Electricity Supply Act, depreciation
enables the Utility to work out the charges to be recovered from consumers for supply
of electricity, one has to follow the provisions of the schedule to the said Electricity
Act and that one has not to follow the provisions of Income-tax Act while calculating
depreciation as one of the items of expense under the Electricity Accounting. Since,
the charge is recoverable from the consumers, depreciation is a source of funding not
for the current year but for replacement cost. According to "The Principles of
Auditing" by F.R.M. de Paula, in the past the accepted principle behind providing forDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

depreciation was to recover the original capital invested in the purchase of the assets.
Revenue is required to be held back by means of depreciation charged to profit and
loss account to recover the original capital invested in the purchase of the assets.
Revenue is required to be held back in order to keep the original capital intact.
However, that model of Original Cost had to be replaced by the concept of
Replacement Cost in recent years owing to the increase in the level of prices due to
inflation. Thus, the concept of Historical Cost to a large extent is replaced by the
concept of Replacement Cost. In the past, according to De Paula, accounts were
prepared upon the basis of Historical Cost but on account of inflation in an economy
like ours which is cost push economy, the concept of Historical Cost as basis of
accounting is replaced by the concept of the Cost of Replacement of fixed assets. The
above analysis by De Paula has been accepted by this Court in its judgment in the
case of Associated Cement Companies Ltd., Dwarka Cement Works, Dwarka v. Its
Workmen and another  AIR 1959 SC 967. We quote hereinbelow paras 28 and 34 of
the said judgment:
"28. Besides, it is said, that the theory that the trading profits of the industry must
provide for the whole of the rehabilitation expenses is not universally accepted by
enlightened and progressive businessmen and economists. In this connection
reliance is placed on the observations of F. R. M. de Paula in his "Principles of
Auditing" that "the object of depreciation is the replacement of original investment
capital and that an increase in replacement cost is an important matter and means
that additional capital is required in order to maintain the original earning capacity".
It is also pointed out that the Institute of Chartered Accountants in England and Wales, in its
recommendations made in 1949 under the heading "Rising price levels in relation to accounts" has
pointed out that "the gap between historical and replacement costs might be too big to be bridged by
a provision made for replacement spread over a period of years either by way of supplementing the
depreciation charges or by setting up in lieu of depreciation a provision for renewals based on
estimated replacement costs."
It is therefore suggested that in revising the formula the claims for rehabilitation should be fixed at a
reasonable amount and industry should be required to find the balance from other sources and if
necessary from its share in the available surplus.
34. The theory that the whole of the rehabilitation charges need not come out of the trading profits
of the industry does not appear to be generally accepted. As has been observed by Paula himself, "In
the past the accepted principle has been that the main object of providing for the depreciation of
wasting assets is to recoup the original capital invested in the purchase of such assets. As part of the
capital of the concern has been invested in the purchase of these assets, therefore, when their
working life comes to an end, the earning capacity of these assets ceases. Thus they will become
valueless for the purposes of the business, and the original capital sunk in their acquisition, less any
scrap value, will have been lost. Hence, in order to keep the original capital of a business intact, if
any part thereof is invested in the purchase of wasting assets, revenue must be held back by meansDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

of depreciation charges to profit and loss account, in order to replace the capital that is being lost by
reason of the fact that it is represented by assets that are being consumed or exhausted in the course
of trading or seeking to earn income" (F. R. M. de Paula's Principles of Auditing', 1957, p. 136).
It is also stated by the same author that "in all cases where one of the direct causes of earning
revenue is gradually to consume fixed assets of wasting nature, the depreciation of such assets
should be provided for out of revenue" (Ibid, p. 138). It is true that the author recognises that "owing
to the very considerable increase in the price level since the termination of the 1939-45 war, industry
is finding its original money capital insufficient for its needs. Thus the cost of replacement of fixed
assets has greatly increased and in addition, further working capital is required to finance a given
volume of production. Many economists, industrialists, and accountants contend that provision
should be made, in arriving at profits, for this increased capital requirement". Having noticed this
view the author adds that "at the time of writing this matter is still being debated and final decisions
have not yet been reached", and he concludes that "until a final solution of this complex problem is
reached it would be inadvisable for the auditor to act on any principle other than that recommended
by the Institute" ((F. R. M. de Paula's Principles of Auditing', 1957, p. 80); and that principle appears
to be that depreciation should be provided for out of revenue. Besides, it must be borne in mind
that, in adjusting the claims of industry and labour to share in the profits on a notional basis, it
would be difficult to repel the claim of the industry that a provision should be made for the
rehabilitation of its plant and machinery from the trading profits. On principle the guaranteed
continuance of the industry is as much for the benefit of the employer as for that of labour; and so
reasonable provision made in that behalf must be regarded as justified."
The above discussion indicates the reasoning behind the higher rate being prescribed in the MOP
Notifications of 1992 and 1994. The above discussion indicates reasons for not linking the rates of
depreciation to the fair life of the asset(s) under the above Notifications. The above discussion
emphasizes the substitution of the concept of Historical Cost by the concept of the Replacement
Cost on account of the inflation in the economy. As stated above, our economy is essentially even
today cost push economy. India has achieved GDP rate of 8 to 9%. To sustain that rate we need the
rate of savings at 30 to 35%.
Infrastructure including electricity is one of the problems faced by our economy. Electricity -
generation, distribution and transmission - is a Capital Intensive Industry. The MOP Notifications
have referred to the life of the asset(s) in the Electricity Industry at 25 years. However, the Note
appended to the Notification of 1992 clarifies that the Utility shall not derive the rate of depreciation
from the fair life of the asset(s). The reason is obvious. Before disinvestment/privatization, the
Utility was under the Government. At that stage itself the Government had decided to substitute the
Historical Cost Method by Replacement Cost Method. Depreciation is a source of funding. On
account of inflation replacement cost increases rapidly. The object underlying the MOP
Notifications which provided for higher rate of depreciation appears to be two- fold  firstly, to
reduce the Asset Replacement Period ('ARP' for short) and secondly, to fund the rapid increase in
the replacement cost. The MOP Notifications proceeded on the basis that the Utilities were making
losses, expenses on replacement was heavy and that the assets needed replacement in the shorter
ARP. It is for this reason that in the MOP Notifications higher rate of depreciation stood prescribedDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

without nexus to the fair life of the asset(s). This Principle under the above MOP Notifications got
reflected in the subsequent BST Order which also, inter alia, prescribed the principles for tariff
determination for 5 years. The above principles also got reflected in the Policy Directions issued by
GoNCTD under Section 12 of DERA. It is for this reason that in the RFQ document the timetable
shows that the bidders were required to take note of the Tariff Structure before making bids. The
investors were put to notice regarding the Tariff Structure which existed before privatization. We are
living in the complex and ever- expanding exigencies of Government. In the matter of grant of
benefit of depreciation, the extent of the benefit lies in the economic wisdom of the Government.
That wisdom constituted the basis of the MOP Notifications which emphasized Asset Replacement
Period to be reduced by prescribing higher rate of depreciation because the Government intended
replacement to take place not after 25 years but at the end of 13 to 15 years. The order of DERC
dated 26.6.03 runs counter to the above reasoning behind the MOP Notifications as reflected in the
BST Order dated 22.2.02 and in the Policy Directions of GoNCTD dated 22.11.01.
Secondly, we may refer to the provisions of DERA. The said Act was enacted, inter alia, to
restructure the Electricity Industry by increasing the participation of private sector in the Electricity
Industry. Today public- private participation is a key element to develop infrastructure in our
economy. DERA was enacted keeping in mind the concept of public-private enterprise. It was
enacted to encourage such Joint Ventures. Under Section 12, DERC was required to be guided by
Directions in matters of Policy involving public interest as the Government may issue from time to
time. Government was the final Authority regarding such Directions. Section 28 of DERA came
under Part VII which dealt with fixation of tariffs. Under Section 28, the licensee was required to
observe the methodologies specified by the Commission (DERC) from time to time in the matter of
calculating the expected revenue from charges which the licensee was permitted to recover under
the terms of its licences. Under Section 28(2), DERC was entitled to prescribe the terms and
conditions for the determination of the licensee's revenues and tariffs in such manner as DERC
considers appropriate. However, Section 28(2) was subject to a proviso which stated that the DERC
shall be guided in the matter of determination of revenues for the licensees by the financial
principles mentioned in the Sixth Schedule to the said 1948 Act read with Sections 57 and 57A of the
said Act. This was one of the parameters mentioned in the proviso. The second parameter
prescribed in the proviso states that in fixing of revenues and tariffs, DERC shall keep in mind
economic use of resources, good performance, optimum investment and other matters. This was the
second parameter. The third parameter mentioned in the proviso states that the DERC shall keep in
mind the interest of the consumer. Under Section 28(3), DERC is entitled to depart from the factors
mentioned in the Sixth Schedule to the 1948 Act while determining the licensee's revenues and
tariffs. However, DERC was required to record reasons for such departure. In the present case, we
are of the view that DERC was certainly entitled to take a departure from the principles set out in
the Sixth Schedule to the said 1948 Act. However, that departure, in the facts and circumstances of
the case, had to be within the framework of the Policy Directions issued by GoNCTD under Section
12. Further, in any event, the departure from the principles under the 1948 Act was required to be
based on proper reasoning. In the present case, DERC was required to consider the effect of its
decision. Privatisation and disinvestment were the Policy decisions taken by GoNCTD. The Utilities
were incurring losses. The assets of the Utilities were getting depleted. The public-privateDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

participation is the order of the day. Therefore, the Policy Directions invited bids from the private
sector on the basis of certain assurances. Under the above circumstances, on the facts of the present
case, Legitimate Expectation was built into the investments made by the DISCOMs herein. The
representations were there in the Policy Directions, BST Order laying down Normative Principles
for tariff fixation for 5 years and the Transfer Scheme. Drawing up of tariff for 5 years was to impart
certainty. As stated above, the tariff for the financial year 2001-2002 was to be adjusted in the next
4 years, namely, financial years 2002-03, 2003-04, 2004-05 and 2005-06. It is for this reason that
even the RFQ document indicated Tariff Principles in the case of NDPL for the financial years
2002-03 and 2005-06. Even the Tariff Order dated 23.5.01 was based on the higher rate of
depreciation without taking into account the fair life of the asset. In short, a package was offered to
the prospective investors. The effect of the order of DERC dated 26.6.03 is to extend the ARP by
10.55 (years), if one goes by the said MOP Notification then the ARP comes to 13.45 years (90%
value of asset divided by 6.69%, rate of depreciation). On the other hand, if one goes by the same
value divided by 3.75% rate of depreciation then the ARP comes to 24 years. Similarly, on account of
the reduction in the rate of depreciation from 6.69% to 3.75%, the overall actual return from the
package becomes illusory. For example, for the financial year 2004-05, DERC approved 16% ROE
amounting to Rs.61.69 crores. However, for the same financial year on account of fall in the rate of
depreciation from 6.69% to 3.75%, DERC has disallowed depreciation to the tune of Rs.60.57 crores
(Rs.106.19 crores minus Rs.45.62 crores). In other words, what is given by one hand is taken away
by the other. In other words, the return on the total package becomes illusory if the rate of
depreciation is reduced from 6.69% to 3.75%. The certainty for 5 years is also obliterated for
reducing the rate of depreciation. This violation also infringes the doctrine of Legitimate
Expectation of the DISCOMs to get lawful and reasonable recovery of expenditure. DERC was
expected to fix the rate in the context of the policy of privatization. The object behind fixation of
principles for 5 years was to impart certainty and consistency in tariff designing, putting the
prospective investors to notice regarding their tariff entitlements for 5 years and to provide Level
Playing Field to the DISCOMs to compete with other competitors in the Electricity Industry. As
stated above, DERC had to give good reasons for departing from the principles in the Sixth Schedule
to the said 1948 Act. In the present case, it has been held by DERC that since the DISCOMs herein
were not obliged to redeem debt (as they had not undertaken any loans), they were not entitled to
the higher rate of depreciation. This assumption of DERC is wrong. There is a difference between
the concept of Depreciation and the concept of Advance Against Depreciation (AAD). In the case of
AAD, loan repayment may be one of the relevant factors. In the present case, as stated above, we are
concerned with the reduction of authorized expenditure from 6.69% to 3.75%. In the present case,
we are concerned with the reduction in the rate of depreciation from 6.69% to 3.75%. Therefore, in
the case of reduction of authorized expenditure (depreciation) repayment of loan is not the relevant
factor. One more points needs to be clarified. Conceptually, it is always possible to derive the rate of
depreciation from the fair life of an asset. However, as stated above, it will depend on the object for
which a fund or a reserve is sought to be created. We have already indicated that in the privatization
process, there is a transition from "no profit organization" to "profit-based organization". The
principles of Accounting will differ in the case of non-profit organization vis-`-vis private
profit-based organization. That transition is of 5 years in the present case. The Historical Cost
Method in a growing economy on account of price increases (inflation) may not be appropriate in
the case of public-profit enterprises. It will depend on the type of industry with which one isDelhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

concerned. Electricity is a Capital Intensive Industry. It needs replacement at a quicker rate in terms
of time-period as compared to a manufacturing industry. It is for this reason that the above Note
was appended to MOP Notification dated 23.1.92. That Notification prescribed the rates of
authorized expenditure which was more than the rate of depreciation derived from the life of an
asset. It is for this reason that the Note was appended to the said Notification stating that the life of
the asset shall not constitute the basis for fixing the rate of depreciation. In view of the above Note,
we are of the view that DERC was not entitled to derive the rate from the fair life of the asset,
particularly, when the consequence was to reduce the ARP substantially. In conclusion, we reiterate
that in the present case because of inflation, we have to go by the Cost of Replacement instead of
Historical Cost. However, we state that our judgment is confined to the facts of the present case
alone and the reasoning given hereinabove is in the context of the period of 5 years. This judgment
should not be construed to apply for all times. It is confined to the transition period only.
Before concluding, we may state that the basic object of providing depreciation is to allocate the
amount of depreciation of an asset over its useful life and not actual life so as to exhibit a true and
fair view of the financial statements of an enterprise. Useful life is a period over which a depreciable
asset is expected to be used. Useful life of an asset in a capital intensive industry is generally shorter
than its physical life. Useful life is pre-determined by contractual limits or by amount of extraction
or consumption dependent on the extent of use and physical deterioration on account of wear and
tear which depends on operational factors such as the number of shifts, repair and maintenance
policy of the Utility and reduced by obsolescence arising from technological changes, improvement
in production methods etc. In the present case, DERC has not considered the difference between the
physical life of an asset and the useful life of the asset.
For the reasons given hereinabove, we uphold the order dated 29.9.06 passed by ATE and
accordingly this civil appeal preferred by DERC stands dismissed with no order as to costs.Delhi Electricity Regulatory ... vs Bses Yamuna Power Limited & Others on 15 February, 2007

