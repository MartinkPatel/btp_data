Common Causea Registered Society vs Union Of India & Others
on 25 September, 1996
Equivalent citations: AIR 1996 SUPREME COURT 3538, 1996 AIR SCW 3696,
1996 (2) UJ (SC) 802, (1996) 8 JT 613 (SC), 1996 (8) JT 613, (1997) 3 CIVLJ 551,
1996 (6) SCC 530, (1997) 1 MAD LJ 65, (1996) 3 RAJ LW 64, (1997) 1 SCT 24,
(1996) 3 SCJ 432, (1997) 1 ICC 210
Author: Kuldip Singh
Bench: Kuldip Singh
           PETITIONER:
COMMON CAUSEA REGISTERED SOCIETY
        Vs.
RESPONDENT:
UNION OF INDIA & OTHERS
DATE OF JUDGMENT:       25/09/1996
BENCH:
KULDIP SINGH, FAIZAN UDDIN
ACT:
HEADNOTE:
JUDGMENT:
J U D G M E N T KULDIP SINGH J.
The allotments of retail outlets for petroleum products (the petrol pumps), by Capt. Satish Sharma,
Minister of State for Petroleum & Natural Gas, exercising the powers of the Central Government,
have been challenged in this public interest petition under Article 32 of the Constitution of India.
The petition as originally filed was directed against corruption in various fields of public life. Mr.
H.D. Shourie - Director "Common Cause" - appearing in person, invited this Court's attention to a
news item dated August 11, 1995, on the front page of "Indian Express" under the caption "In SatishCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

Sharma's Reign, Petrol and Patronage Flow Together". The solicitor general who was present in
Court, took notice of the news item and stated that the would have the matter examined in the
Ministry concerned and file an affidavit giving Ministry's response to the news item. The news item,
inter alia, stated as under:-
"Not only the relatives of most of the officials working for Captain Satish Sharma but
even his own driver and the driver of his additional Private Secretary have been
allotted a petrol pump and a gas agency respectively. The wives of two clerks and a
stenographer in the Ministry have similarly been allotted petrol pumps. Some of
these allotments have been made from the discretionary quota with the Petroleum
Minister while others have been made through an ostensibly objective selection
process undertaken by the Oil Selection Boards (OSBs). ..........A Mr Poda Rajshekar,
a relative of Mr. G. Gurusharan, Private Secretary to Captain Sharma has been
allotted a petrol pump at Banjara Hills, Hyderabad out of the Minister's discretionary
quota taking pity on the "financial circumstances that the family finds itself in."
Ms Madhuri Safaya, a relation of the Additional Private Secretary to the Minister, Mr. V.N. Safaya
has been allotted a petrol pump "on compassionate grounds" from the discretionary quota.
Another relation of Mr. Safaya, Mrs. Monica Malla, has also been a beneficiary of a petrol pump,
courtesy Captain Sharma.
Mrs Daya Rani, wife of Mr Hari Ram Verma, personal assistant to the Additional PS to the Minister,
Mr V.N. Safaya, was allotted a petrol pump out of the discretionary quota ........Mrs Vijaya Nair, wife
of Mr, D.V. Pillai, another additional Private Secretary to Captain Sharma has been allotted a petrol
pump on the grounds that the "applicant is a young unemployed [woman] with the responsibility of
looking after a large family" - hardly a unique classification in this country of 900 million. .......The
Chairman of the OSB for Uttar Pradesh is Justice S.H. Abidi (retd.) who lives at 50, Dariyabad,
Allahabad.
It so happens that Syed Shaukat Hasan Abidi, his son, living at 50/1, Daryabad, Allahabad put in a
request and was allotted a petrol pump on "compassionate grounds" at Fatehpur (80 Km Mile
Stone) in Uttar Pradesh.
A former MLA, Mr Shiv Balak Passi, from Rae Bareli is a member of the OSB for Madhya Pradesh
and his job is to allot petrol pumps to others.
He too had put in a request for the discretionary allotment of the petrol pump. Lo and behold, on
"compassionate grounds" he was immediately allotted a petrol pump on the Rae Bareli-Lucknow
Road in UP.
Mr. Krishna Swaroop, a Congress party worker and resident of 18/7, Punjabi Bagh Extension, New
Delhi-Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

26 is a member of the OSB for Delhi and chandigarh. His son, Mr Pradeep Kumar, was favoured
with a petrol pump by the Minister on the grounds that "the applicant is a young man from
Scheduled Caste Community with no source of regular income. The case deserves sympathetic
consideration. Therefore, a retail Outlet for MS-HSD in the Union Territory of Delhi is allotted to
Shri Pradeep Kumar, r/o 18/7, Punjabi Bagh Extension, New Delhi-
110026."
Mr. Ghulam Ahmed Mir is also a member of the OSB for Delhi and Chandigarh. An application was
made by him for the allotment of a petrol pump. And the Minister passed the order on
"compassionate grounds" from his discretionary quota.
Similarly the following OSB members, either themselves or their next of kin, have been allotted
petrol pumps : Mr K.L. Sharma (Member OSB, West Bengal), Mr R.S. Nautiyal (Member OSB,
Punjab), and Mr Harbanslal Gupta (member OSB, Haryana). Two relation of Mrs Satya Bahen
(Member OSB, Haryana) were allotted a gas agency in Etah and a petrol pump at Itmadpur near
Tundla, respectively.
The son of a former Home Minister who is currently a Cabinet Minister; the son of a present
Minister of State from the North-
East; the brother-in-law of a former Janata Dal office-bearer and now a Congressman from Eastern
UP;
the son of a Dalit leader who was with the late H.N. Bahuguna at one time and is now in the
Congress;
the son of former Congress Councillor of the Municipal Corporation of Delhi; the wife of an
ex-Congress MP from the UP hills; the wife of a prominent Dalit leader in the Opposition and
several political hacks from Amethi are among the hundreds who have been gifted petrol pumps or
gas agencies during the tenure of Captain Satish Sharma as the Petroleum Minister."
Mr. Vijay L. Kelkar, Secretary in the Ministry of Petroleum and Natural Gas, government of India,
filed affidavit dated October 9, 1995. The relevant part of the affidavit is as under:-
"It may be relevant to point out here that under the approved Guidelines, the Hon'ble
Minister personally decides each case and the order is a speaking order. An
unsuccessful applicant in the same category is entitled to have a copy of the order if a
request is made for it.
The specific instances referred to in the Indian Express newspaper dated 11th August,
1995, appear to relate to allotments made prior to the order of this Hon'ble Court
dated 31st March, 1995. However, those allotments also were made on merits of each
case as appearing from the applications which contained the circumstances underCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

which the request was made. For the cases mentioned in the newspaper report, it is
denied that the allotments were made on account of alleged relationship and/or any
improper motive. The relationship of a applicant with any official of the Ministry has
not been a relevant factor in considering discretionary allotment on compassionate
grounds. Should this Hon'ble Court direct, the relevant files shall be produced for
perusal for this Hon'ble Court."
This Court examined the affidavit of Mr. Kelkar on October 13, 1995 and passed the following
order:-
"Mr. Vijay L. Kelkar, Secretary in the Ministry of Petroleum and Natural Gas,
Government of India has filed an affidavit pursuant to this Court's order dated
August 11, 1995. Without commenting on the affidavit, we direct the Ministry of
Petroleum and Natural Gas to file a further and better affidavit within two weeks with
reference to the specific instances."
Pursuant to the above quoted order Mr. Kelkar filed affidavit dated October 28, 1995. The relevant
part of the affidavit is as under:-
"That the Deponent, in compliance with the said order dated 13th October, 1995, has
ascertained the position regarding the allegations that allottees under the
discretionary quota are related to various political leaders, officials and members of
Oil Selection Boards (OSBs) or the members themselves. Such allottees can be
grouped under three different categories and allegation regarding each one of them is
answered and/or dealt with as follows:
A ALLOTTEES SAID TO BE RELATED TO POLITICIANS
(i) With reference to the allegation that the son of a former Home Minister, who is
currently a Cabinet Minister, has been allotted a Petrol Pump,..... It is correct that the
allottee, Shri Sarbjot Singh is the son of the said Shri Buta Singh.
(ii) with reference to the allegation that the son of a present Minister of State from
North-East, has been allotted a petrol pump. .....It is correct that the said allottee is
the son of a Minister, namely, Shri K. Hollahan, in the State Government of
Nagaland.
B. ALLOTTEES SAID TO BE RELATED TO THE MEMBERS OF OSBs OR THE MEMBERS
THEMSELVES.
(i) With reference to the allegation that Shri Syed Shaukat Hasan Abidi is the son of Justice S.H.
Abidi (retd.), who is the Chairman of the OSB for Uttar Pradesh,....... Discretionary allotment was
made in favour of the applicant in January, 1995. It is correct that the said allottee is the son of the
said Chairman of OSB for U.P.Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

(ii) With reference to the allegation that Shri Shiv Balak Passi is a member of the OSB for Madhya
Pradesh and he is himself an allottee from discretionary quota, .......... A discretionary allotment was
sanctioned in his favour in December. 1994. It is correct that Shri Passi is a Member of the OSB for
Madhya Pradesh.
(iii) With reference to the allegation that the allottee, Shri Pradeep Kumar, is the son of Shri Krishna
Swaroop who is a Member of OSB for Delhi and Chandigarh, ...... It is correct that the allottee is the
son of the said Shri Krishna Swaroop.
(iv) With reference to the allegation that the allottee, Shri Ghulam Ahmad Mir is a Member of OSB
for Delhi and Chandigarh,..... It is correct that Shri Mir is Member of the OSB, Delhi.
(v) With reference to the allegation that Shri R.S. Nautiyal, who is a Member of OSB, Punjab, has
been allotted a Petrol Pump either in his own name or in the name of his next of kin, it is stated that
Smt. Nena Nautiyal, made an application in August, 1994, .....
It is correct that Smt. Nena Nautiyal is the wife of Shri R.S. Nautiyal, a Member of OSB, Punjab.
(vi) With reference to the allegation that a Petrol Pump was allotted to Shri Justice Harbanslal
Gupta, a Member of OSB, Haryana, in his own name or in the name of his next of kin, it is stated
that one Shri Arun K. Gupta made an application in September, 1993, ....... It is correct that Shri
Arun Kumar Gupta is the son of Shri Justice Harbanslal Gupta (Retd.) who is the Chairman of the
OSB, Haryana.
(viii) With reference to the allegation that two relations of Smt. Satya Bahin, a Member of the OSB
for Haryana, were allotted a Gas Agency and a Petrol Pump, it is stated that one Shri Dharmesh
Kumar made an application In September, 1994,..... Along with his application there was a
recommendation for discretionary allotment from Smt. Satya Bahin, Ex Member of Parliament..... It
is stated that the relationship of Shri Dharmesh Kumar with Smt. Satya Bahin is not known.
C. ALLOTTEES WHO ARE SAID TO BE RELATED TO VARIOUS OFFICIALS IN THE MINISTRY.
(i) The allegation is that relatives of the Drivers of the Minister and of the Additional Private
Secretary to the Minister have been allotted Petrol Pump and Gas Agency. It has been found that
one Smt. Leela Devi, wife of late Shri Kishan Swaroop made an application that her husband was
brutally murdered on 25.1.1994, she had no means of income to support her family and that she
belonged to a Scheduled Caste. A retail outlet was allotted to Smt. Leela Devi on compassionate
grounds from the discretionary quota in may, 1995.
It has now been ascertained that Smt. Leela Devi happens to be a relative of a Driver of the Minister.
     (ii)   With    reference   to   the
     allegation    that     Shri    PodaCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

Rajasekhar is a relative of Shri G. Gurucharan, Private Secretary to the Minister of State, it is stated
that an application was made by Shri Rajasekhar in July, 1993,....
A Retail Outlet Dealership for MS-
HSD at Secunderabad was sanctioned to Shri Rajasekhar on compassionate grounds. It has been
ascertained that the said allottee is a relative of the said Shri Gurucharan.
(iii) With reference to the allegation that Ms. Madhuri Safaya is a relative of Shri B.N. Safaya,
Additional Private Secretary to the Minister, to whom a Retail Outlet has been allotted,..... It has
been ascertained that she is related to the said Shri B.N. Safaya.
(iv) With reference to the allegation that Ms. Monica Malla is also related to Shri B.N. Safaya, ...... A
Retail Outlet was allotted to her in November, 1994 out of discretionary quota. It has been
ascertained that the said Ms. Malla is related to the wife of Shri B.N. Safaya.
(v) With reference to the allegation that the allottee, Mrs. Daya Rani, is the wife of Shri H.R. Verma,
Personal Assistant to the Additional Private Secretary to the Minister, Shri B.N. Safaya,..... It is
correct that the allottee is the wife of Shri H.R. Verma.
(vi) With reference to the allegation that Mrs. Vijaya Nair, who has been sanctioned a Retail Outlet,
is the wife of Shri D.V. Pillai, Additional Private Secretary to the Minister of State,.... It has been
ascertained that Mrs. Vijaya Nair is not the wife of Shri D.V. Pillai, but she is related to him".
This Court issued notice to all the 15 persons mentioned in the affidavit of Mr. Kelkar. Thirteen, out
of them filed affidavits justifying the allotments of petrol pumps made to them by Capt, Satish
Sharma.
This Court by the order dated December 6, 1995 directed that "the minister may, if he so desires, file
an affidavit in this regard". Capt. Satish Sharma has, however, not chosen to file any affidavit.
The relevant records have been produced before us. Mr. Sarbjot Singh in his application mentioned
that he was a commerce graduate belonging to the scheduled caste community. He completed
graduation in the year 1991. He was interested in sports (shooting) and won awards at the national
level. Because of his pre-occupation with the sports, he had average academic record and as a
consequence could not get admission to any professional courses. He further stated that in spite of
his best efforts he could not get any suitable employment for supporting himself and as such a petrol
pump in Delhi be allotted to him. The file does not indicate how the application was entertained.
There is no receipt/entry on the application. No official/officer has examined the application before
the Minister's order. There is nothing to shown that any guide-lines were kept in view. The
application, obviously, was given by hand to the Minister, who readily passed the allotment order.
There is a separate sheet containing the order of the Minister which is as under:-Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

"Office of the Minister of State (P&NG) Placed below is an application of Shri Sarbjot
Singh for allotment of a Retail Outlet dealership for MS- HSD. The applicant has
stated that he is a graduate without any suitable employment Submitted for kind
orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) Minister I have examined the application
carefully. The applicant is an unemployed graduate and a sportsman who
participated in national level competitions. The applicant has not been able to get any
gainful employment and is unable to support himself. The case deserves sympathetic
consideration. Therefore, a Retail Outlet for MS- HSD in the National Capital
Territory of Delhi is allotted to Shri Sarbjot Singh r/o 16, Ashok Road New Delhi.
Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
Thereafter, the matter was processed in the office and in one of the notes by an officer of the
ministry it was mentioned that the allottee "is son of Shri Buta Singh, Minister of Civil Supplies". No
one took notice of this fact and the allotment order was issued.
In all the cases discussed hereinafter the pattern of allotment and the method and procedure
followed was the same as in Sarbjot Singh's case.
Benjamin K. Hollohon stated in his application that he was an educated unemployed youth and also
active party worker in the area. He belonged to scheduled tribe from Nagaland State. He requested
in the application for allotment of petrol pump in Purana Bazar area of Dimapur town, Nagaland.
The application was sent to Captain Satish Sharma by Mr. K. Hollohon, Minister, Industry and
Commerce, Nagaland (Father of the applicant) along with a d.o. letter which reads as under:-
"Me dear Capt. satish Sharma, Kindly recall our discussions of date regarding
allotment of one retail outlet petrol pump (petrol & Diesel) in the Purana Bazar area
of Dimapur town in Nagaland in favour of my son Benjamin K. Hollohon. As you may
be aware, that Benjamin's application and my earlier note in this regard are available
in your Ministry. However, I am again enclosing copy of Benjamin's application for
your perusal.
It was indeed pleasure to note that you have very kindly agreed to allot one petrol
pump in favor of my son Shri Benjamin after careful and due consideration as a very
very special case. I shall personally grateful if you could kindly use your good offices
in issuing suitable instructions to the officials concerned in your Ministry so that the
possible bureaucratic delays are averted and the permit is issued without much loss
of time. Therefore, I request your personal intervention in the matter. I hope, you can
very well appreciate my predicament in the matter and am sure, you will do the
needful."Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

The allotment order by the Minister is reproduced here- under:-
"Office of the Minster of State (P&NG) Placed below is an application of Shri
Benjamin K. Hollohon for allotment of a retail outlet for MS-HSD. The applicant has
stated that he is an unemployed youth belonging to Scheduled Tribe community. The
applicant has also stated he no regular source of income.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) 10/10/94 Minister I have examined the
application carefully. The applicant is an educated unemployed Scheduled Tribe
youth without regular source of livelihood. The case deserves sympathetic
consideration. Therefore, a Retail Outlet for MS- HSD at Purana Bazar, Dimapur,
Nagaland is allotted to Shri Benjamin K. Hollohon r/o Durgapathar, 2 1/2 Mile,
Dimapur, Nagaland, Pine Code-797 112. Necessary orders may be issued accordingly.
Sd/-
(Capt. Satish Sharma) Minister of State"
Syed Hasan Shaukat Abidi stated in his application as under:-
"Respectfully I beg t state that I was born at Allahabad, Uttar Pradesh on 20th
December, 1965. I have passed B.Sc. and completed my Master's in Business
Administration (specialisation in Marketing). In spite of my best efforts, I have not
been able to get a suitable employment. I have no other source of income and am
entirely dependent on my aged parents for survival. My inability to find employment
and settle down is causing anxiety to my parents. Hence, I would most humbly
request you Sir, to grant me a petrol pump at Fatehpur (80 Km. Mole Stone) in Uttar
Pradesh."
The Minister passed the following order:-
"Office of the Minister of State (P&NG) Placed below is an application of Shri Syed
Hasan Shaukat Abidi for allotment of a Retail Outlet for MS-HSD. The applicant has
stated that he has completed his Post Graduation in Business Administration and has
not been able to find any suitable employment. The applicant has also stated that he
has no other source of income and is dependent on his parents for sustenance.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) Minister I have examined the application
carefully. the applicant is a professional qualified man without any regular
employment. The applicant has no other source of income and is entirely dependent
on his parents for support and sustenance. The case deserves sympatheticCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

consideration. Therefore, a Retail Outlet for MS- HSD at Fatehpur (80 Km. Mile
Stone) In Uttar Pradesh is allotted to Shri Syed Hasan Shaukat Abidi r/o 50/1,
Dariyabad, Allahabad, Uttar Pradesh.
Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
It is obvious from Mr. Kelkar's affidavit that Syed Hassan Shaukat Abidi is the son of Justice S.H.
Abidi (retd) who was at that time Chairman of the Oil Selection Board for Uttar Pradesh.
Shiv Balak Passi applied for allotment of petrol pump in the following words:-
"I wish to state the following about myself. I am a social worker who has devoted his
entire life for the upliftment of downtrodden, underprivileged. I have been in the
forefront in all activities involving eradication of social evils. But Sir, I am growing
old and am not in a position to support myself. Therefore, Sir, with due respect I
request you to grant me a petrol pump at Lucknow-Rae Bareilley Road, Uttar
Pradesh."
The Minister passed the following order:-
"Office of the Minister of State (P&NG) Placed below is an application of Shri Shiv
Balak Passi for allotment of a Retail Outlet for MS-HSD. The applicant has stated
that he is a social worker without any regular source of income.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) Minister I have examined the application
carefully. The applicant is an educated unemployed who has no regular source of
income due to his serious preoccupation for the upliftment of downtrodden. The case
deserves sympathetic consideration. Therefore, a Retail Outlet for MS- HSDA at Rae
Bareilley Lucknow Road, UP, is allotted to Shri Shiv Balak Passi, Ex-MLA, District
Rae Bareilley, Uttar Pradesh. Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
Mr. Kelkar's affidavit shows that Shiv Balak Passi himself is a member of the Oil Selection Board for
Madhya Pradesh.
Pradeep Kumar, in his application stated that he was an unemployed young man from Scheduled
Caste category with enterprise, initiative and determination and was very keen to make petrol pump
dealership as his business. He indicated that he was appearing in B.A (final). He further stated that
his father has been an active congress worker since 1952 and has held many important positions inCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

the organisation as well as on the executive side. The following order was made by the Minister:-
Office of the Minister of State (P&NG) Placed below is an application of Shri Pradeep
Kumar for allotment of Retail Outlet for MS-HSD. The applicant has stated that he
belongs to a Scheduled Caste Community and also an unemployed Under Graduate.
For kind orders.
Sd/-
(G. Gurucharan) PS to MOS (P&NG) 20/6/94 Minister I have examined the
application carefully. The applicant is a young man from Scheduled Caste
Community with no source of regular income. The case deserves sympathetic
consideration. Therefore, a Retail Outlet for MS-HSD in the Union Territory of Delhi
is allotted to Shri Pradeep Kumar, r/o 18/7, Punjabi Bagh Extension, New Delhi - 110
026.
Orders may be issued accordingly.
Sd/-
(Capt. Satish Sharma) Minister of State"
While processing the order, noting on the file is as under:-
"Reference notes on pre-page. MOS has sanctioned a retail outlet dealership at Delhi
on compassionate grounds to Shri Pradeep Kumar who is belonging to SC category.
He has stated in his application vide p-1/c that he is appearing in BA final year. He is
son of Shri Krishna Swaroop member of OSB, Delhi. The allowances and perks of the
Member of OSB exceed Rs. 5000/- per month.
2. However, in view of the sanction by MOS, file is put up with a fair sanction letter
for signature, if approved. Sd/-
Allotment of a dealership to the son of a sitting Member of the OSB will invite
adverse criticism. It will also create an avoidable impression that govt. is influencing
the OSB in this manner. sd/-
27.6.94"
Mr. Kelkar's affidavit shows that Shri Pradeep Kumar is the son of Shri Krishan
Swaroop, who was at that time member of Oil Selection Board for Delhi and
Chandigarh. Pradeep Kumar in his application did not mention this fact. The file
indicates that despite the noting to the effect that the allotment would invite adverseCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

criticism, the allotment orders were issued.
Mr. Ghulam Ahamd Mir in his application, addressed to the Minister, stated that due
to the escalation of extremist violence in Kashmir Valley in the recent years, it has
become difficult to lead a normal life in the Valley and as such earning a livelihood
has become very difficult. He further stated that the family was forced to sell some of
he ancestral property. He added that despite being a Graduate he could not get
regular employment. He also stated in the application that he was an active social
worker and had been promoting the nationalist cause in the Valley due to which he
and his family have been facing constant threats from the militants and extremists in
the Valley. The Minister passed the following order on the applications:
"Office of the Minster of State for (P&NG) Placed below is an application of Shri
Ghulam Ahamd Min for allotment of a Retail Outlet for MS-HSD. The applicant has
stated that he is a graduate from Jummu and Kashmir, who has been forced to
migrate from Kashmir as result of militant threats to his life. The applicant has also
state that he has no regular source of income for maintaining his family. Submitted
for kind orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) Minister I have examined the application
carefully. The applicant is an unemployed graduate from Jummu & kashmir trying to
settle in Delhi. The applicant is an active social worker espousing the nationalist
cause for which reason he and his family have become a target of militants in the
Valley. The applicant has not been able to obtain any suitable employment in Delhi
and is finding it difficult to support his immediate family in Delhi and his parents in
Jammu. The case deserves sympathetic consideration. Therefore an `A' site Retail
Outlet for MS-HSD in the Union Territory of Delhi is allotted to Shri Ghulam Ahmad
Mir s/o Haji Gh. Hassan Mir r/o 71-D, Pocket `K', Sheikh Sarai II, New Delhi.
Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
While processing the Minister's order the office put up the following note on the file:
"Ref. note above. Sh. G.A, Mir, has furnished his bio-data vide pp 3- 4/C. In his
bio-data he has stated that he working as Member of Oil Selection Board and is
getting Rs.250/- per sitting of the Board as Honorarium.
2. In view of he above, file is put up for orders whether we may issue sanction to Oil
Company for award of RO dealership, to Sh. G.A. Mir as per sanction letter placed
below, if approved."Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

Despite the above quoted note, the allotment order was issued. Mr, Kelkar in his affidavit has stated
that Shri Mir is a member of the Oil Selection Board for Delhi and Chandigarh.
Mrs. Nena Nautiyal addressed a three lined application to the Minister. It is stated in the application
that she is an educated lady and belong to Scheduled Tribe community. Being an unemployed, she
wished to install a retail outlet in the Union Territory, Delhi. The following order was passed by the
Minister:
"Office of the Minister of State (P&NG) Placed below is an application of Smt. Nena
Nautiyal for allotment of a retail Outlet for MS-HSD. The applicant has stated that is
an educated unemployed lady from Scheduled Tribe community. Submitted for kind
orders. Sd/-
(G Gurucharan) PS to MOS (P&NG) Minister I have examined the application
carefully. The applicant is an educated lady and belongs to Scheduled Tribe
community. The applicant is unemployed and has no regular source of income. The
case deserves sympathetic consideration. therefore, a Retail Outlet for MS- HSD in
the Union Territory of Delhi is allotted to Smt. Nena Nautiyal r/o B-399, Gali No.19,
Bhajanpura, Delhi.
Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minster of State"
While processing the Minister's order the office put up the following note:
"Ref. above. Smt. Nena Nautiyal has furnished her bio-data vide pp 8- 7/C wherein
she has stated that her occupation is agriculture and her and her husband's income is
25,000/- & 18,000/- per annum respectively. In this connection it is stated that it
happens from her bio-data that she is the wife of Sh. Ravi Sharan Nautiyal who is a
Member of OSB - Punjab.
2. In view of the above, file is put up for orders whether we may issue sanction to Oil
Company for setting up a RO dealership in favor of Smt. Nena Nautiyal".
The allotment letter dated 7th October, 1994 was issued to Nena Nautiyal. It is admitted in the
affidavit of Mr Kelkar that Nena Nautiyal is the wife of R.S. Nautiyal, Member, Oil Selection Board,
Punjab.
Arun Kumar Gupta in his application stated that he passed BSc. in Production Engineering in the
year 1970 and worked as Project Engineer in the Haryana State cooperative Supply and Marketing
Federation Ltd. at Chandigarh from 1976 to 1989 when he was forced to tender resignation on
political considerations when the Haryana Government was headed by Shri Devi ll. It is further
stated that since then he was unemployed and as such the application for grant of petrol pump. TheCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

application was directly dealt with by the Minister and his Private Secretary in the following
manner:
"Office of the Minister of State (P&NG) Placed below is an application of Shri Arun K.
Gupta for allotment of Retail Outlet. The applicant has stated that he is a professional
who has not been able to find a regular employment and is finding it difficult to make
ends meet. Submitted for king orders. Sd/ (G. Gurucharan) PS to MOT (P&NG)
22/X/93 Minister I have examined the application carefully. The applicant is a
graduate in Production Engineering and is without any regular employment. The
case deserves sympathetic consideration. Therefore, a Retail Outlet for MS- HSD is
allotted to Shri Arun K. Gupta, s/o Shri Harbans Lal r/o H.No. 68, Sector 8-A,
Chandigarh at Sector-20 C, Chandigarh. Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State While processing the above order, Mr. S.K.
Singh, under Secretary in the Ministry wrote on the file as under:
"A retail outlet dealership has been allotted to Shri arun Kumar Gupta s/o Sh.
Harbans Lal, at Chandigarh under discretionary powers of Govt. vide MOS' s order at
p-1/n and Government sanction at p-2/c.
2. Since the allottee has not mentioned anything about his father and since a similar
named person is working as Chairman of one of the Oil Selection Boards, IOC was
asked to check the detail from the allottee. A report now received from IOC is placed
at pp 5-3/c for perusal. It may be seen therefrom that the father of the allottee Shri
Harbans Lal is a Retd. Judge of the Punjab and Haryana High Court and practising
Senior Advocate in the Supreme Court at New Delhi, and also functioning as the
Chairman of the Oil Selection Board for Haryana.
3. It is humbly submitted that such allotments will invite adverse public criticism.
Sd/-
(S.K. SINGH) US (M.II)/6.12.93"
Letter of intent was issued to Mr. Arun Kumar Gupta on December 9, 1993. Mr. Kelkar in his
affidavit has stated that Arun kumar Gupta is the son of Justice Harbans Lal Gupta (retd.), who at
that time was Chairman of the Oil Selection Board, Haryana.
Satya Bahin, Ex.Member of Parliament and member of the Oil Selection Board for Haryana
recommended the application of Dharmesh Kumar for allotment of petrol pump. It was stated in the
recommendation that Dharmesh Kumar's father died few years back, they are poor and his mother
is suffering from cancer. The Minister allotted the petrol pump by the following order:Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

"Office of the Minister of State (P&NG) "Placed below is an application of Shri
Dharmesh Kumar for allotment of a Retail Outlet for MS-HSD. The applicant has
stated that he is an educated youth from Scheduled Tribe whose father had passed
away while in Government service. The Applicant has also stated his mother who had
been trying to support her family is also afflicted by Cancer which has put the family
in difficult circumstances.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS. to MOS (P&NG) 9.11.
Minister I have examined the application carefully. The applicant is an unemployed
youth whose father's sudden demise had prevented from completing his education.
The applicant's mother who had been the sole bread-winner for the family is also
afflicted with Cancer which has put the family in straitened circumstances. The
applicant has also not been able obtain suitable employment. The case deserves
sympathetic consideration. Therefore, a Retail Outlet for MS- HSD at
Ferozabad-Shikohabad Road, near Makhanpur, Uttar Pradesh is allotted to Shri
Dharmesh Kumar s/o Late Shri Johari Lal (Amin) r/o H.No.20, Katra Mohammad
Mah, Gandhi Marg, Shikohabad, Firozabad, Uttar Pradesh.
Orders may be issued accordingly. Sd/- 9/11 Capt. Satish Sharma) Minister of State"
In his affidavit filed before this Court Dharmesh Kumar stated that he is "neither a family member
nor dependent on Satya Bahin. The deponent is not closely related to Satya Bahin."
Leela Devi in her application stated that her husband expired on 25th January, 1994. Two clerks of
lawyers killed her husband in the premises of Patiala House. It is further stated that she is a
housewife with no means of income to feed herself and her family since the death of her husband.
The Minister allotted the petrol pump by the following order:
"Office of the Minister of State (P&NG) Placed below is an application of Smt. Leela
Devi for allotment of a retail Outlet for MS-HSD. The applicant has stated that her
husband was murdered and ever since his death her family is left without any regular
source of livelihood.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS to MOS(P&NG) 19/5/95 Minister I have examined the
application carefully. The applicant is a widow whose husband was murdered. The
applicant has no regular income to support herself and her family. The case deserves
sympathetic consideration. Therefore, a Retail Outlet for MS-HSD at NOIDA, UP is
allotted to Smt. Leela Devi w/o Late Shri Krishan Swaroop r/o H.No. B-412/A, Sector
No. 19, NOIDA, UP. Orders may be issued accordingly. Sd/-Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

(Capt. Satish Sharma) Minister of State"
The material on the file shows that the late husband of Leela Devi was a dismissed employee of Post
and Telegraph Department. He had six sons and a house on Kalibari Marg. Late husband of Leela
Devi was living away from the family for 7-8 years prior to his death. Mr. Kelkar in his affidavit has
stated that Leela Devi is the relative of the driver of the Minister. The affidavit filed by Leela Devi
and the documents attached with the affidavit read with Kelkar's affidavit clearly show that Leela
Devi is the mother of Nand Kishor who was working as driver of Capt. Satish Sharma. Mr. Kelkar in
his affidavit has stated that "Smt. Leela Devi happens to be a relative of the driver of the Minister".
Least we can say is that Mr. Kelkar should have known that Leela Devi was Minister's drivers's
mother.
Poda Rajasekhar has, in his application, stated that he completed his B.Com in 1980 and in spite of
his best efforts he could not settle in regular employment. His father was serving as an Inspector of
Customs and Central Excise. He expired in January 1981. His mother, who was a teacher, retired on
19.4.1993. He finds it difficult to cope with the present circumstances. The Minister allotted the
petrol pump by the following order:
"OFFICE OF THE MINISTER OF STATE (P&NG) Placed below is the application of
Shri Poda Rajasekhar r/o 8-3-897/6 Nagarjuna Nagar, Hyderabad (A.P.). The
applicant has stated that he is an educated unemployed person who has the
responsibility of looking after his mother as well as a cousin, who is mentally
retarded. He has stated that besides his best efforts, he has not been able to settle in
any regular employment. He has prayed that a retail outlet dealership for MS-HSD
may be allotted to him at Banjara Hills, Secunderabad (A.P.).
For kin orders.
Sd/-
(G. GURUCHARAN) PS TO MOS (P&NG) 23.7.93 Minister I have examined the
application carefully. The applicant's case is genuine in view of the adverse financial
circumstances that the family finds itself in. It is a fit case for sympathetic
consideration. Accordingly a retail outlet dealership for MS-HSD is allotted to Shri
Poda Rajasekhar at Banjara Hills, Secunderabad (A.P.). Orders may be issued
immediately. Sd/-
(CAPT. SATISH SHARMA) MOS (P&NG)"
Mr kelkar in his affidavit has stated that "Poda Rajasekhar is a relative of Shri Gurucharan, Private
Secretary to the Minister".
Madhuri safaya has stated in her application that she is a native of Kashmir. She is a young lady and
has been rendered homeless due to the increasing militancy in the Valley. Due to sudden migrationCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

to Delhi she has not been able to complete her education. On these grounds she requested the
Minister to allot her a petrol pump. The Minister readily obliged her by the following order:
"Office of the Minister of State (P&NG) Placed below is an application of Ms.
Madhuri Safaya for allotment of Retail Outlet for MS-HSD. The applicant has stated
that she belongs to Kashmir and her family has migrated to Kashmir. The applicant
has also stated that she has not been able to get a suitable job and is without a regular
source of livelihood.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) 12.10 Minister I have examined the application
carefully. The applicant is a young lady whose family has migrated from Kashmir and
are dependent on their relatives for sustenance. The applicant has not been able to
obtain a suitable job for herself and is without any regular source of income. The case
deserves sympathetic consideration. Therefore, a Retail Outlet for MS- HSD in the
national Capital Territory of Delhi is allotted to Ms. Madhuri Safaya r/o B-6/1,
Vasant Vihar, New Delhi. Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
Mr kelkar has confirmed in his affidavit that Madhuri Safaya is related to B.N. Safaya, Add1. Private
Secretary to the Minister.
Monika Malla in her application stated that her family was forced to leave Kashmir due to the
militant activities. Her family had to dispose of the property at a loss and all the savings had already
been spent. She has to support her parents who are not keeping good health. On these grounds she
requested the Minister for the allotment of petrol pump. The Minister passed the following order:
"Office of the Minister of State (P&NG) Placed below is an application of Ms. Monica
Malla for allotment of a Retail Outlet for MS-HSD. The applicant has stated that she
is young lady form Kashmir whose family has been forced to migrate to Delhi due to
growing militancy. The applicant has also stated that she has exhausted their family's
savings and are finding it difficult to sustain themselves in Delhi.
Submitted for kind orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) 12.10 Minister I have examined the application
carefully. The applicant is a young lady whose family had migrated to Delhi owing to
militant activities of the extremists. The applicant's family has no source of livelihood
and she has not been able to obtain any suitable employment. The case deserves
sympathetic consideration. Therefore, a Retail Outlet for MS- HSD in the National
Capital Territory of Delhi is allotted to Ms. Monica Malla c/o Smt. Labroo r/o D-1/54,
Vasant Vihar, New Delhi.Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
Mr. Kelkar has stated in his affidavit that Monika Malla is related to the wife of B.N.Safaya, Add1.
Private Secretary to the Minister.
Daya Rani stated in her application that she is a housewife of a low paid employee having four
school going children. It was difficult to live with the meagre salary of her husband. She wanted to
share the responsibility of her husband and as such requested the Minister to allot her a petrol
pump. The minister obliged her by passing the following order:
"Office of the Minister of State (P&NG) Placed below is an application of Smt. Daya
Rani w/o Shri H.R. Verma for allotment of a Retail Outlet for MS-HSD. The
Applicant has stated that she has a family of four school going children and is finding
it difficult to make ends meet with the income being earned by her husband.
Submitted for king orders. Sd/-
(G. Gurucharan) PS to MOS (P&NG) 10.10.94 Minister I have examined the
application carefully. The applicant is a housewife whose family is facing difficult
financial circumstances. The case deserves sympathetic consideration. Therefore, a
Retail Outlet in the Union Territory of Delhi is allotted to Smt. Daya Rani w/o Shri
H.R. Ramakrishna Ashram Marg, Gole Market, New Delhi. Orders may be issued
accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
Shri S.K. Singh, Under Secretary, while processing the Minister's order noted on the file as under:
"Smt. Daya Rani, the allottee is the wife of Shri Hari Ram Verma who is working in
this Ministry as an Assistant and presently posted to Minister's Office. His annual
income from pay and allowances during 1993-94 is reported Rs. 52,925/-. However,
the allottee has shown the annual income as Rs.36,000/- which is factually not
correct. It seems that she has shown only the take-home pay after deductions. It is for
consideration whether the sanction letter placed below as per Orders of MOS
recorded at p-1/n may be issued Sd/-
(S.K. SINGH) US (M.II)/25.10.94"
Allotment order was issued to Daya Rani on 31st October, 1994. Mr. Kelkar has stated in his
affidavit that Daya Rani is the wife of H.R. Verma, Personal Assistant to the Add1. Private Secretary
(B.N. Safaya) to the Minister.Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

Vijaya Nair has stated in her application that she is a young housewife with a large family to support.
She has studied up to B.A. level. The meagre income of her husband could not sustain their
liabilities. She requested the Minister to allot her a petrol pump which was done by the following
order:
"Office of the Minister of State (P&NG) Placed below is the application of Smt. Vijaya
Nair. The applicant is a young educated unemployed person with the responsibility of
looking after a family which has a meagre income. The applicant has stated that
despite best efforts she has been unable to obtain suitable job. She has, therefore
requested that as a special case she may be allotted a Retail Outlet MS-HSD in the
Union Territory of Delhi. For kind orders.
Sd/-
(G. Gurucharan) PS to MOS (P&NG) 23.7.93 Minister I have examined the
application carefully. The applicant is an educated unemployed housewife whose
family circumstance is one of considerable financial difficulty. The applicant has also
prayed that she has the necessary drive and initiative to run a Retail Outlet. This is a
fit case to be considered sympathetically. Accordingly, a Retail Outlet for MS-HSD is
allotted to Smt. Vijaya Nair, 2213, Lodi Road Complex, New Delhi-110 003, in the
Union Territory of Delhi as a special case.
Orders may be issued accordingly. Sd/-
(Capt. Satish Sharma) Minister of State"
Mr. Kelkar has stated in his affidavit that Vijaya Nair is related to D.V. Pillai, Add1. Private Secretary
to Minister.
All the 15 allotments - discussed above - have been made by the Minister in a stereotyped manner.
The applications have not been officially received by the Petroleum Ministry. There is no receipt -
entry on any of the applications. The applicants seem to have approached the Minister directly.
None of the applications have been dealt with in any of the branches of the Ministry. There is
nothing on the record to indicate that the Minister kept any criteria in view while making the
allotments. How the applicants came to know about the availability of the petrol pumps is not
known. No advertisement was made to invite the applications. There is nothing on the record to
show that any other method of inviting applications was adopted. There is no indication in the
allotment-orders or anywhere in the record to show that the Minister kept any guidelines in view
while making these allotments. The allotments have been made in a cloistered manner. The petrol
pumps - public property - have been doled out in a wholly arbitrary manner. This Court in Ramana
Dayaram Shetty vs. International Airport Authority of India and others (1979) 3 SCC 489, held ad
under:Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

"It must, therefore, be taken to be the law that where the Government is dealing with
the public, whether by way of gibing jobs or entering into contracts or issuing quotas
or licences or granting other forms of largesse, the Government cannot act arbitrarily
at its sweet will and, like a private individual, deal with any person it pleases, but its
action must be in conformity with standard or norms which is not arbitrary,
irrational or irrelevant. The power or discretion of the Government in the matter of
grant of largesse including award of jobs, contracts, quotas, licences, etc. must be
confined and structured by national, relevant and non-discriminatory standard or
norm and if the Government departs from such standard or norm in any particular
case or cases, the action of the Government would be liable to be struck down."
The allotments have been made by the Minister either on the ground of poverty or unemployment.
Assuming that the allottees belong to either of these two categories then how the Minister has
selected them court of millions of poor and unemployed in this country. As mentioned above no
criteria was fixed, no guidelines were kept in view, none knew how many petrol pumps were
available for allotment, applications were not invited and the allotments of petrol pumps were made
in an arbitrary and discriminatory manner.
We may examine these allotments from another angle which has very serious repercussions. Six of
the allottees are related to various officials working with the Minister. Leela Devi is the mother of
Minister's driver. Poda Rajasekhar is a relation of G. Gurucharan, Private Secretary to the Minister.
Madhuri Safaya and Monika Malla are related to B.N. Safaya, Add1. Private Secretary to the
Minister. Daya Rani is the wife of H.R. Verma. Personal Assistant to B.N. Safaya and Vijaya Nair is
the wife of D.V. Pallai, Add1. Private Secretary. Two of the allottees are related to the politicians.
Sarbjot Singh is the son of Buta Singh who was Home Minister and at the relevant time was Cabinet
Minister heading the Civil Supplies portfolio. Benjamin K. Hollohan is the son of Shri K. Hollahan,
Minister in the State of Nagaland. Remaining seven allottees are either members of the Oil Selection
Boards or their relations. Shaukat Hasan Abidi is the son of Justice S.H. Abidi(Retd.), who was the
Chairman of the Oil Selection Board, Uttar Pradesh. Similarly, Arun Kumar Gupta is the son of
Justice Harbans Lal Gupta (Retd.) who was the Chairman of Oil Selection Board, Haryana. Pradeep
Kumar is the son of Krishna Swaroop, who was Member of Oil Selection Board for delhi and
Chandigarh. Nena Nautiyal is the wife of R.S. Nautiyal, who was member of Oil Selection Board,
Punjab. Dharmesh Kumar was the recommended of Satya Bahin, Ex.Member of Parliament and
Member of the Oil Selection board for Haryana. Shiv Balak Passi and Ghulam Ahamd Mir were
themselves members of the Oil Selection Boards. It is obvious that Capt. Satish Sharma was
personally interested in making allotments of petrol pumps in favour of all these 15 persons. He
made allotments in favour of relations of his personal staff under the influence of the staff on wholly
extraneous considerations. The allotments to the sons of Ministers were only to oblige the Ministers.
The allotments to the members of the Oil Selection Boards and their/chairmen's relations have been
done to influence them and to have favours from them. All these allotments are wholly arbitrary,
nepotistic and are motivated by extraneous considerations.
The Government today - in a welfare State - provides large number of benefits to the citizens. It
distributes wealth in the form of allotment of plots, houses, petrol pumps, gas agencies, mineralCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

leases, contracts, quotas and licences etc. Government distributes largesses in various forms. A
Minister who is the executive head of the department concerned distributed these benefits and
largesses. He is elected by the people and is elevated to a position where he holds a trust on behalf of
the people. He has to deal with the peoples' property in a fair and just manner. He cannot commit
breach of the trust reposed in him by the people. We have no hesitation in holding that Capt. Satish
Sharma in his capacity as a Minister for Petroleum and Natural gas Deliberately acted in a wholly
arbitrary and unjust manner. We have no doubt in our mind that Capt. Satish Sharma knew that the
allottees were relations of his personal staff, sons of Ministers, sons/relations of Chairmen and
members of the Oil Selection Boards and the members of the Oil Selection Boards themselves. The
allotments made by him were wholly mala fide and as such cannot be sustained.
We are further of the view that Capt. Satish Sharma acted in a wholly biased manner inasmuch as he
unfairly regarded with favour the cases of 15 allottees before him. The relevant circumstances
available from record and discussed by us leave no manner of doubt in our mind that Capt. Satish
Sharma deliberately acted in a biased manner to favour these allottees and as such the allotment
orders are wholly vitiated and are liable to be set aside.
The orders of the Minister reproduced above read: "the applicant has no regular income to support
herself and her family", "the applicant is an educated lady and belongs to scheduled tribe
community, "the applicant is unemployed and has no regular source of income", "the applicant is an
uneducated, unemployed scheduled tribe youth without regular source of livelihood", "the applicant
is an uneducated, unemployed scheduled tribe youth without regular source of livelihood", "the
applicant is a housewife whose family is facing difficult financial circumstances" etc. etc. There
would be literally millions of people in the country having these circumstances or worse. There is no
justification whatsoever to pick up these person except that they happen to have won the favour of
the Minister on mala fide considerations. None of these cases fall within the categories placed before
this Court in writ petition (civil No. 886/93 titled Centre for public interest ligation vs. Union of
India & Anrs. decided on March 31, 1995 but even if we assume for argument sake that these cases
fall in some of those or similar guidelines the exercise of discretion was wholly arbitrary. Such a
discretionary power which is capable of being exercised arbitrarily is not permitted by Article 14 of
the Constitution of India. While Article 14 permits a reasonable classification having a rational
nexus to the objective sought to be achieved, it does not permit the power to pick and choose
arbitrarily out of several persons falling in the same category. A transport and objective
criteria/procedure has to be evolved so that the choice among the members belonging to the same
class or category is based on reason, fair play and non arbitrariness. It is essential to lay down as a
matter of policy as to how preferences would be assigned between two person falling in the same
category. If there are two eminent sportsmen in distress and only one patrol pump is available, there
should be clear, transparent and objective criteria/procedure to indicate who out of the two is to be
preferred. Lack of transparency in the system promotes neptosism and arbitrariness. It is absolutely
essential that the entire systems should be transparent right from the stage of calling for the upto
the stage of passing the orders of allotment. The names of the allottees, the orders and the reasons
for allotment should be available for public knowledge and scrutiny. Mr. Shanti Bhushan has
suggested that the petrol pumps, agencies etc. may be allotted by public auction - category-wise
amongst the eligible and objectively selected applicants. We do not wish to impose any procedure onCommon Causea Registered Society vs Union Of India & Others on 25 September, 1996

the Government. It is a matter of policy for the Government to lay down. We, however, direct that
any procedure laid down by the Government must be transparent, just, fair and non-arbitrary, This
Court in The Centre for Public Interest Litigation case (supra) has endorsed the guidelines
submitted by the Attorney General for allotment of petrol pumps, gas agencies etc. The Court in that
case did not have before it the actual manner of exercise of discretion by the Minister in the
allotment of pups/agencies. The allotment orders which are now before the Court clearly indicate
that leaving the authorities to enjoy absolute discretion even within the guidelines would inevitably
lead to gross violation of the constitutional norms when the persons for allotment are picked up
arbitrarily and discriminatory.
This Court as back as in 1979 in Ramana Shetty's case (supra) held "it must, therefore, be taken to be
the law...." that even in the matter of grant of largesses including award of jobs, contracts, quotas
and licences, the Government must act in fair and just manner and any arbitrary distribution of
wealth would violative the law of the land. Mr. Satish Sharma has acted in utter violation of the law
laid-down by this Court and has also infarcted Article 14 of the Constitution of India. As already
stated a minister in the Central Government is in a position of a trustee in respect of the public
property under his charge and discretion. The petrol pumps/gas agencies are a kind of wealth which
the Government must distribute in a bona fide manner and in conformity with law. Capt. Satish
Sharma has betrayed the trust reposed in him by the people under the constitution. It is high time
that the public servants should be held personally responsible for their mala fide acts in the
discharge of their functions as public servants. This Court in Lucknow Development Authority
versus M.K. Gupta (1994) 1 Supreme Court Cases 243, approved "Misfeasance in public offices" as a
part of the Law of Tort. Public servants may be liable in damages for malicious, deliberate or
injurious wrong-doing. According to Wade "There is, thus, tort which has been called misfeasance in
public office and which includes malicious abuse of power, deliberate maladministration, and
perhaps also other unlawful acts causing injury". With the change in socio- economic outlook, the
public servants are being entrusted with more and more discretionary power even in the field of
distribution of Government wealth in various forms. We take it to be perfectly clear, that if a public
servant abuses his office either by an act of omission or commission, and the consequence of that is
injury to an individual or loss of public property, an action may be maintained against such public
servant. No public servant can say "you may set-aside an order on the ground of mala fide but you
cannot hold me personally liable". No public servant can arrogate to himself the power to act in a
manner which is arbitrary.
For the reasons indicated above, we conclude that the orders passed by Capt. Satish Sharma, the
then Minister of State for Petroleum and Natural Gas, Government of India, allotting petrol pumps
to Sarbjot Singh, Benjamin K. Hollohon, Syed Hasan Shaukat Abidi, Shiv Balak Passi, Pradeep
Kumar, Ghulam Ahmad Mir, Nena Nautiyal, Arun Kumar Gupta, Dharmesh Kumar, Leela Devi,
Poda Rajasekhar, Madhuri Safaya, Monika Malla, Daya Rani and Vijaya Nair are arbitrary,
discriminatory, mala fide, wholly illegal and as such are liable to be quashed.
We, therefore, hold and direct as under:Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

1. The orders - reproduced in earlier part of this judgment - allotting petrol pumps to
the above mentioned fifteen persons are hereby quashed.
2. The allocation, allotment of the petrol pumps/retail outlet dealerships by the
Government of India, Indian Oil Corporation Ltd. or any other corporation in names
of the above said fifteen persons shall stand cancelled with immediate effect.
3. Most of these 15 persons have not as yet commissioned the petrol pumps. Those
who have commissioned the petrol pumps and are running the same shall stop
operating the petrol pumps and running the said business with effect from October
31, 1996. The Government of India/Oil Corporation (concerned) shall take over the
petrol pump premises from these persons within ten days thereafter. The Oil
Corporation shall have the market-value of the site and the construction thereon,
determined in a fair and just manner before October 31, 1996.
4. Each of the commissioned petrol pumps, taken over by the Government/Oil
Corporation (concerned) and the built-up area along with the site (whether
lease-hold or owned by the original allottee) shall be disposed of by way of public
auction. The original allottees may also participate in the auction. The petrol pump
shall be allotted to the highest bidder. The said allottee shall run the petrol pump on
the original terms and conditions. He shall have all the rights in respect of the site
and the construction thereon as the original allottee had on the date of auction. Out
of the auction money the value of the site and the construction as determined by the
Oil Corporation shall be paid to the original allottee and the remaining money shall
go to the Government coffer. On receipt of the said amount the original allottee shall
cease to have any right or interest in the site and the construction thereon. If the
successful bidder is the original allottee, he shall pay the difference between the
auction money and the value of the site and construction as determined by the Oil
Corporation.
5. Capt. Satish Sharma shall show-cause within two weeks why a direction be not
issued to the appropriate police authority to register a case and initiate prosecution
against him for criminal breach of trust or any other offence under law. He shall
further show-cause within the said period why he should not, in addition, be made
liable to pay damages for his mala fide action in allotting petrol pumps to the above
mentioned fifteen persons.
We place on record our appreciation for Mr. H.D. Shourie, who, very ably, assisted us in this matter.
He shall be entitled to costs which was quantify as rupees fifty thousand. The cost shall be paid by
Capt. Satish Sharma personally.
Before parting with this judgment, we may mention about Civil Writ Petitions Numbers 400./95
and 4430/95 which are pending before the Delhi High Court. In the said petitions, allotment of
petrol pumps/gas agencies to various other persons during the period 1992-93, 1993-94, 1994-95Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

and 1995-96 have been challenged. Transfer petition No.127/96 has been filed in this Court seeking
transfer of those writ petitions from Delhi High Court to this Court. We have issued notice in the
transfer petition and have stayed further proceedings before the High Court in the writ petitions.
Various affidavits have been filed on behalf of the Ministry of Petroleum & Natural Gas. Mr. Devi
Dayal, Joint Secretary of the Ministry, in his affidavit dated March 26, 1995, has stated that in
1995-96 petroleum products agencies were allotted to 99 persons under the discretionary powers of
the Government. It is further stated that orders on file have been made allotting petrol
pumps/agencies to 61 more persons. An affidavit filed by Mr. Srinivasan, Advocate supporting the
transfer petition gives a long list of persons who are related to the then Prime Minister/Ministers
and other VIPs and who have been allotted petrol pumps and gas agencies. Mr. Devi Dayal, Joint
Secretary in the Ministry of Petroleum has filed another affidavit dated April 18, 1996 in reply to the
affidavit of Mr. Srinivasan. Para 6 of the affidavit is as under:-
"As regards the list of allottees mentioned in paras 3 to 6 and the alleged relationship
with the Prime Minister, other Ministers, V.I.Ps., M.Ps/M.L.As, etc., it is to submit
that enquiries have been made through the Oil Companies from the allottees, who
have replied through affidavits. The comments of the Ministry, on the basis of above
enquiry and records, are contained in Annexure - I to this affidavit."
Annexure 1 with the affidavit shows that gas agencies were allotted to six relations of the then Prime
Minister, an agency to a son of the OSD in Prime Minister's office, LPG dealership to
daughter-in-law of the OSD tot eh then Minister of Petroleum, a petrol pump to the real brother of
Chadraswamy (Nemi Chand Jain), LPG distributorship to brother of Shri Bhagwan Shri Satya Sai
Baba, LPG dealership to Manju Devi, wife of private secretary to additional private secretary of Capt.
Satish Sharma, a petrol pump to wife of V.K. Aggarwal, additional private secretary, Ministry of
Law, RO dealership to Rakesh Saluja, son of R.L. Saluja, who was employed in the Ministry of
Petroleum till June, 1993, RO dealership to Prathiba Singh related to Shri Kalapnath Rai, RO
dealership in January, 1995 to Kanti Lal Bhuriya, who at that time was Minister for Tribal Welfare in
he Madhya Pradesh Government, a gas agency to the son-in-law of Mr. G. Ganga Reddy, Member of
Parliament and various others.
Since the two writ petitions, mentioned above, are pending before the High Court wherein the
allotments made to all the persons mentioned above and others, have been challenged, it is not
necessary for us to transfer the writ petitions to this Court. We vacate the stay order granted by this
Court and dispose of the transfer petition. We direct the Registry of this Court to send all the
affidavits filed by the parties in the transfer petition along with annexures to the High Court. We
have no doubt that the High Court shall examine the issues involved in he writ petitions and shall
also go into the validity of the allotment of petrol pumps/gas agencies to various persons, after
hearing them, in accordance with law. We request the High Court to expedite the hearing of the
petitions.Common Causea Registered Society vs Union Of India & Others on 25 September, 1996

