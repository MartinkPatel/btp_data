Bandhua Mukti Morcha vs Union Of India & Others on 16
December, 1983
Equivalent citations: 1984 AIR 802, 1984 SCR (2) 67, AIR 1984 SUPREME
COURT 802, 1984 LAB. I. C. 560, 1984 SCC (L&S) 389, (1984) 2 LAB LN 60,
1984 (3) SCC 161
Author: P.N. Bhagwati
Bench: P.N. Bhagwati, R.S. Pathak, Amarendra Nath Sen
           PETITIONER:
BANDHUA MUKTI MORCHA
        Vs.
RESPONDENT:
UNION OF INDIA & OTHERS
DATE OF JUDGMENT16/12/1983
BENCH:
BHAGWATI, P.N.
BENCH:
BHAGWATI, P.N.
PATHAK, R.S.
SEN, AMARENDRA NATH (J)
CITATION:
 1984 AIR  802            1984 SCR  (2)  67
 1984 SCC  (3) 161        1983 SCALE  (2)1151
 CITATOR INFO :
 R          1984 SC1099  (3)
 RF         1986 SC 847  (30)
 RF         1987 SC 990  (16)
 R          1987 SC1086  (3,4,5,6,7)
 R          1988 SC1863  (3,9,10)
 F          1989 SC 549  (15)
 RF         1989 SC 653  (12)
 F          1990 SC2060  (3)
 F          1991 SC 101  (35)
 RF         1991 SC 420  (7)
 RF         1991 SC1117  (7)
 RF         1991 SC1420  (25)
 RF         1992 SC  38  (4)
 RF         1992 SC1858  (11)
ACT:Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

     Constitution   of    India.-Article    32(1)-Mode    of
interpreting Article  32-"Appropriate proceedings",  meaning
of-Letter  addressed   by  a  party  on  behalf  of  persons
belonging  to  socially  and  economically  weaker  sections
complaining violation  of their  rights under various social
welfare  legislations-Whether  can  be  treated  as  a  writ
petition-Maintainability  of-Public   Interest   Litigation-
Nature and scope of.
     Constitution of  India, Article  32 (2)-Appointment  of
commissions  by  the  Supreme  Court  to  enquire  into  the
complaint made  in the  writ petition  and relying  upon the
commissioners' report-Propriety of-Adversarial Procedure-How
far binding on the Court-Supreme Court Rules, 1966, O, XXXV,
XLVI and XLVII, Rule 6-Code of Civil Procedure, O.XXVI.
Mines Act,  1952 -Sections 2  (j), (jj), (kk), 3 (1) (b)
proviso 18  Chapters V, VI & VII-Meaning of the word "mine"-
Whether stone  quarries are  mines-Whether  workers  of  the
stone  quarries   and  crushers  entitled  to  the  benefits
accruing under  the Act-Responsibility  of the mine lessees,
mine owners,  Central Government  and the  State Governments
for ensuring the benefits accruing under the Act, explained-
Mines Rules  1955, Rules,  Rules 30-32-Punjab  Minor Mineral
Concession Rules, 1964.
Inter-State Migrant  Workmen (Regulation  of Employment
and Conditions of Service) Act, 1979-ss.2 (1) (e), (b), (g),
4,8,12 and Chapter V-Inter-State Migrant Workmen (Regulation
of Employment  and Conditions  of  Service)  Central  Rules,
1980-Rules  23,   25-45-Definition  of  inter-state  migrant
workmen-Rights and  benefits of  inter-state migrant workmen
explained-Thekedars or  Jamadars recruiting workers for mine
lessees/owners from  outside the  State  are  "contractors"-
Contract Labour  (Regulation and  Abolition) Act, 1970-ss. 2
(1) (a), (b), (c) (g), 16 to 21.
Bonded Labour  System (Abolition)  Act, 1976 -ss.2  (f),
(g), 4,  5, 10-15-Existence  of Forced Labour-Whether bonded
labour-Burden of  proof lies  upon  the  employer  that  the
labourer is not a bonded labourer-Court will be justified in
presuming that  the labourer is a bonded labourer unless the
presumption is rebutted by producing satisfactory material.
     Minimum Wages  Act, Workmen's  Compensation Act,  1983,
Payment  of   Wages  Act,  Employees  State  Insurance  Act,
Employees Provident  fund and  Miscellaneous Provisions Act,
Maternity Benefits  Act, 1957-Benefits  accruing under these
Acts-Whether available to mine workers.
HEADNOTE:
     The petitioner,  an organisation dedicated to the cause
of release  of bonded  labourers in the country, addressed a
letter to Hon'ble Bhagwati, J. alleging: (1) that there were
a large  number of  labourers from  different parts  of  the
country who  were working  in some  of  the  stone  quarriesBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

situate in district Faridabad, State of
68
Haryana under  "inhuman and intolerable conditions; (2) that
a large  number of  them were bonded labourers; (3) that the
provisions of  the Constitution  and various  social welfare
laws passed  for the  benefit of  the said  workmen were not
being  implemented   in  regard   to  these  labourers.  The
petitioner also  mentioned in  the letter  the names  of the
stone quarries and particulars of labourers who were working
as bonded  labourers and  prayed that  a writ  be issued for
proper implementation  of  the  various  provisions  of  the
social welfare legislations, such as, Mines Act, 1952 Inter-
State  Migrant   Workmen  (Regulation   of  Employment   and
Conditions  of   Service)   Act,   1979,   Contract   Labour
(Regulation and  Abolition) Act,  1970, Bonded Labour System
(Abolition)  Act,   1976,  Minimum   Wages  Act,   Workmen's
Compensation Act,  Payment of  Wages  Act,  Employees  State
Insurance Act,  Maternity Benefits  Act etc.  applicable  to
these labourers  working in  the said  stone quarries with a
view to  ending the  misery, suffering  and helplessness  of
"these victims of the most inhuman exploitation."
     The Court  treated the  letter as  a writ  petition and
appointed a  commission to inquire into the allegations made
by  the  petitioner.  The  commission  while  confirming  he
allegations of  the petitioner,  pointed out  in its  report
that (i)  the whole atmosphere in the alleged stone quarries
was full  of dust  and it  was  difficult  for  any  one  to
breathe; (ii)  some of the workmen were not allowed to leave
the stone  quarries and  were providing forced labour; (iii)
there was  no facility  of providing pure water to drink and
the labourers  were compelled  to drink  dirty water  from a
nullah; (iv)  the labourers  were not  having proper shelter
but were  living in  jhuggies with stones piled one upon the
other as  walls and straw covering the top which was too low
to stand and which did not afford any protection against sun
and rain;  (v) some  of the  labourers were  suffering  from
chronic diseases;  (vi) no  compensation was  being paid  to
labourers who  were injured  due to accidents arising in the
course of  employment; (vii)  there were  no facilities  for
medical treatment  or schooling.  At the  direction  of  the
Court, a  socio-legal investigation was also carried out and
it suggested  measures for  improving the  conditions of the
mine workers.
     The  respondents  contended:  (1)  Article  32  of  the
Constitution is  not attracted  to the  instant case  as  no
fundamental right  of  the  petitioner  or  of  the  workmen
referred to  in the  petition is  infringed;  (2)  A  letter
addressed by  a party  to this  Court cannot be treated as a
writ petition; (3) In a proceeding under Art. 32, this Court
is  not   empowered  to   appoint  any   commission  or   an
investigating body  to enquire  into the allegations made in
the writ  petition; (4) Reports made by such commissions are
based only on ex-parte statements which have not been testedBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

by cross-examination  and therefore they have no evidentiary
value; and  (5) there might be forced labourers in the stone
quarries and stone crushers in the State of Haryana but they
were  not  bonded  labourers  within  the  meaning  of  that
expression as  used in  the Bonded Labour System (Abolition)
Act, 1976.
     Rejecting all  the contentions  and allowing  the  writ
petition on merits, the Court
^
     HELD:  The  State  Government's  objection  as  to  the
maintainability of the writ petition under Article 32 of the
Constitution by  the petitioners  is reprehensible.  If  any
citizen brings  before the  Court a  complaint that  a large
number of  peasants or workers are bonded serfs or are being
subjected  to   exploitation  by   a  few  mine  lessees  or
contractors or employers or are being denied the benefits of
69
social welfare  laws, the  State Government, which is, under
our constitutional  scheme,  charged  with  the  mission  of
bringing about a new socioeconomic order where there will be
social and economic justice for every one equality of status
and opportunity  for all,  would welcome  an inquiry  by the
court, so  that if it is found that there are in fact bonded
labourers or  even if  the workers  are not  bonded  in  the
strict sense  of the  term as  defined in  the Bonded Labour
System (Abolition)  Act 1976  but they  are made  to provide
forced  labour   or  are   consigned  to  a  life  of  utter
deprivation and  degradation, such  a situation  can be  set
right by  the State Government. Even if the State Government
is on  its own  inquiry satisfied  that the  workmen are not
bonded and  are not  compelled to  provide forced labour and
are living  and working  in decent  conditions with  all the
basic necessities  of  life  provided  to  them,  the  State
Government should  not baulk  an inquiry by the court when a
complaint is  brought by a citizen, but it should be anxious
to satisfy  the court  and through  the court, the people of
the country,  that  it  is  discharging  its  constitutional
obligation fairly  and adequately  and the workmen are being
ensured social and economic justice. [102A-D]
     2. Moreover,  when a  complaint is  made on  behalf  of
workmen that  they are  held in  bondage and are working and
living  in   miserable  conditions  without  any  proper  or
adequate shelter  over their  heads, without  any protection
against sun  and rain,  without two square meals per day and
with only  dirty  water  from  a  nullah  to  drink,  it  is
difficult how  such a  complaint can  be thrown  out on  the
ground that  it is not violative of the fundamental right of
the workmen.  It is  the fundamental  right of  every one in
this country,  assured under  the  interpretation  given  to
Article 21  by this  Court in Francis Mullen's Case, to live
with human  dignity, free  from exploitation.  This right to
live with  human dignity enshrined in Article 21 derives its
life breath  from the  Directive Principles  of State PolicyBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

and particularly  clauses (e)  and (f)  of  Article  39  and
Articles 41  and 42  and at  the least,  therefore, it  must
include protection  of the  health and  strength of workers,
men and  women, and  of the  tender age  of children against
abuse, opportunities  and facilities for children to develop
in a  healthy  manner  and  in  conditions  of  freedom  and
dignity, educational  facilities, just and humane conditions
of  work   and  maternity  relief.  These  are  the  minimum
requirements which must exist in order to enable a person to
live with  human dignity  and no  State neither  the Central
Government nor  any State  Government-has the  right to take
any action  which will  deprive a person of the enjoyment of
these basic  essentials. Since  the Directive  Principles of
State Policy contained in clauses (e) and (f) of Article 39,
Article 41  and 42 are not enforceable in a court of law, it
may not be possible to compel the State through the judicial
process  to   make  provision   by  statutory  enactment  or
executive fiat  for ensuring these basic essentials which go
to make  up a life of human dignity but where legislation is
already  enacted   by  the   State  providing   these  basic
requirements to  the workmen  and thus investing their right
to live  with basic human dignity, with concrete reality and
content, the  State can  certainly be  obligated  to  ensure
observance of  such legislation  for inaction on the part of
the State  in securing  implementation of  such  legislation
would amount  to denial  of the  right to  live  with  human
dignity enshrined  in Article  21, more so in the context of
Article 256 which provides that the executive power of every
State shall be so exercised as to ensure compliance with the
laws made by Parliament and any existing laws which apply in
that State. [103B-H 104A]
     3. The  State is  under a  constitutional obligation to
see that  there is  no violation of the fundamental right of
any person, particularly when he belongs to the
70
weaker sections  of the  community and  is unable  to wage a
legal battle  against a  strong and powerful opponent who is
exploiting him. The Central Government is therefore bound to
ensure observance  of various social welfare and labour laws
enacted by  Parliament for  the purpose  of securing  to the
workmen a life of basic human dignity in compliance with the
Directive Principles of State Policy. It must also follow as
a necessary corollary that the State of Haryana in which the
stone quarries  are vested  by reason  of  Haryana  Minerals
(Vesting of  Rights) Act  1973 and  which is  therefore  the
owner of  the mines  cannot while giving its mines for stone
quarrying  operations,  permit  workmen  to  be  denied  the
benefit of  various social  welfare and  labour laws enacted
with a  view to  enabling them  to  live  a  life  of  human
dignity. The State of Haryana must therefore ensure that the
minelessees or  contractors, to  whom it is giving its mines
for  stone  quarrying  operations,  observe  various  social
welfare and  labour laws  enacted for  the  benefit  of  theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

workmen. This  is a  constitutional obligation  which can be
enforced against  the Central  Government and  the State  of
Haryana  by   a  writ  petition  under  Article  32  of  the
Constitution. [104 A-D]
     4. While  interpreting Article  32, it must be borne in
mind that  our approach  must be guided not by any verbal or
formalistic canons  of construction  but  by  the  paramount
object and  purpose for  which this Article has been enacted
as  a   Fundamental  Right   in  the  Constitution  and  its
interpretation must receive illumination from the Trinity of
provisions  which   permeate   and   energies   the   entire
Constitution namely,  the Preamble,  the Fundamental  Rights
and the  Directive Principles of State Policy. Clause (1) of
Article 32  confers the  right to move the Supreme Court for
enforcement of  any of  the fundamental  rights, but it does
not say  as to who shall have this right to move the Supreme
Court nor  does it say by what proceedings the Supreme Court
may be  so moved.  There is  no limitation  in the  words of
Clause (1) of Article 32 that the fundamental right which is
sought to  be enforced by moving the Supreme Court should be
one belonging  to the person who moves the Supreme Court nor
does it say that the Supreme Court should be moved only by a
particular kind  of proceeding.  It is  clear on  the  plain
language of  clause (1) of Article 32 that whenever there is
a violation  of a  fundamental right,  any one  can move the
Supreme Court  for enforcement of such fundamental right. Of
course, the  court would not, in exercise of its discretion,
intervene at the instance of a meddlesome interloper or busy
body and  would ordinarily  insist that  only a person whose
fundamental right is violative should be allowed to activise
the court,  but there  is no  fetter upon  the power  of the
court to  entertain a  proceeding initiated  by  any  person
other than  the one  whose fundamental  right  is  violated,
though the  court would  not  ordinarily  entertain  such  a
proceeding, since  the person  whose  fundamental  right  is
violated can  always approach  the court  and if he does not
wish to  seek judicial  redress by  moving  the  court,  why
should some one else be allowed to do so on his behalf. This
reasoning however  breaks down  in the  case of  a person or
class of persons whose fundamental right is violated but who
cannot have  resort to the court on account of their poverty
or disability  or  socially  or  economically  disadvantaged
position and  in such  a case,  therefore, the court can and
must allow  any member  of the  public acting  bona fide  to
espouse the  cause of  such person or class of persons. This
does not  violate, in  the slightest measure the language of
the  constitutional  provision  enacted  in  clause  (1)  of
Article 32. [106 B-H-107A]
     5. Clause (1) of Article 32 says that the Supreme Court
can be  moved for  enforcement of a fundamental right by any
'appropriate' proceeding. There
71
is no  limitation  in  regard  to  the  kind  of  proceedingBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

envisaged in  clause (1)  of  Article  32  except  that  the
proceeding must  be "appropriate"  and this  requirement  of
appropriateness must  be judged  in the light of the purpose
for which the proceeding is to be taken, namely, enforcement
of a fundamental right. The Constitution makers deliberately
did not  lay down  any particular  form  of  proceeding  for
enforcement of  a fundamental  right nor  did they stipulate
that such  proceeding should conform to any rigid pattern or
straight jacket formula as, for example, in England, because
they knew  that in  a country  like India, where there is so
much of  poverty,  ignorance,  illiteracy,  deprivation  and
exploitation,  any   insistence  on   a  rigid   formula  of
proceeding for  enforcement of  a  fundamental  right  would
become self  defeating because it would place enforcement of
fundamental rights  beyond the  reach of  the common man and
the entire  remedy for  enforcement  of  fundamental  rights
which the  Constitution makers  regarded as  so precious and
invaluable  that  they  elevated  it  to  the  status  of  a
fundamental right,  would become  a mere rope of sand so far
as the  large masses  of the  people  in  this  country  are
concerned.  The   Constitution  makers  therefore  advisedly
provided in  clause (1) of Article 32 that the Supreme Court
may be  moved by any 'appropriate' proceeding, 'appropriate'
not in  terms of  any particular form but 'appropriate' with
reference to the purpose of the proceeding. [107 A-F]
     Therefore where a member of the public acting bona fide
moves the  Court for  enforcement of  a fundamental right on
behalf of  a person  or class  of persons  who on account of
poverty  or   disability   or   socially   or   economically
disadvantaged position cannot approach the court for relief,
such member  of the  public may  move the court even by just
writing a  letter, because  it would not be right or fair to
expect a  person acting  pro bono  publico to incur expenses
out of  his own pocket for going to a lawyer and preparing a
regular  writ   petition  for   being  filed  in  court  for
enforcement  of  the  fundamental  right  of  the  poor  and
deprived sections  of the  community and  in such  a case, a
letter addressed  by him  can legitimately be regarded as an
"appropriate" proceeding. [107 F-H]
     6. Public  Interest litigation  is not in the nature of
adversary  litigation   but  it   is  a   challenge  and  an
opportunity to the government and its officers to make basic
human rights  meaningful  to  the  deprived  and  vulnerable
sections of  the community  and to  assure them  social  and
economic  justice   which  is  the  signature  tune  of  our
Constitution. When  the Court  entertains  public  interest,
litigation, it  does not do so in a cavilling spirit or in a
confrontational mood  or with a view to tilting at executive
authority or  seeking to  unsurp it, but its attempt is only
to  ensure   observance  of   social  and   economic  rescue
programmes, legislative as well as executive, framed for the
benefit of  the have-nots and the handicapped and to protect
them against violation of their basic human rights, which isBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

also the  constitutional obligation  of the  executive.  The
Court is  thus merely  assisting in  the realisation  of the
constitutional objectives. [102 D-E, G-H, 103 A-B]
     7. Clause  (2) of  Article 32  conferring power  on the
Supreme Court  "to issue  directions, or  orders, or  writs,
including writs  in the  nature of  habeas corpus, mandamus,
prohibition, quo  warranto and certiorari" which ever may be
appropriate, for  enforcement  of  any  of  the  fundamental
rights, is  in the  widest terms.  It  is  not  confined  to
issuing  the   high  prerogative  writs  of  habeas  corpus,
mandamus, prohibition,  certiorari, and  quo warranto, which
are hedged  in by  strict conditions differing from one writ
to another.  But it  is much  wider and  includes within its
matrix, power to issue any directions, orders or writs which
may be appropriate
72
for enforcement  of the  fundamental right  in question  and
this is  made amply  clear by  the  inclusive  clause  which
refers  to   in  the  nature  of  habeas  corpus,  mandamus,
prohibition, qua  warranto and certiorari. Therefore even if
the conditions  for issue  of any  of these high prerogative
writs are  not fulfilled, the Supreme Court would have power
to issue  any direction,  order or  writ including a writ in
the nature  of any  high prerogative  writ.  This  provision
conferring  on  the  Supreme  Court  power  to  enforce  the
fundamental rights  in the  widest possible  terms shows the
anxiety  of   the  Constitution  makers  not  to  allow  any
procedural technicalities to stand in the way of enforcement
of  fundamental  rights.  The  Constitution  makers  clearly
intended that  the Supreme  Court should  have  the  amplest
power to  issue whatever  direction, order  or writ  may  be
appropriate in a given case for enforcement of a fundamental
right. That  is why  the Constitution  is silent  as to what
procedure  shall   be  followed  by  the  Supreme  Court  in
exercising the  power to  issue such  direction or  order or
writ  as  in  Article  32  and  advisedly  so,  because  the
Constitution makers  never intended to fetter the discretion
of the  Supreme Court  to evolve  a procedure appropriate in
the circumstances  of  a  given  case  for  the  purpose  of
enabling it to exercise its power of enforcing a fundamental
right. Neither  clause (2)  of  Article  32  nor  any  other
provision of  the Constitution  requires that any particular
procedure  shall   be  followed  by  the  Supreme  Court  in
exercising its  power to  issue  an  appropriate  direction,
order or  writ. The  purpose for which the power to issue an
appropriate direction,  order or  writ is  conferred on  the
Supreme Court  is to  secure enforcement  of  a  fundamental
right  and   obviously  therefore,   whatever  procedure  is
necessary  for   fulfillment  of   that  purpose   must   be
permissible to the Supreme Court. [108 B-H, 109 A-B]
     8. It  is not  at all  obligatory that  an  adversarial
procedure, where each party produces his own evidence tested
by cross  examination by  the other  side and the judge sitsBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

like an  umpire and  decides the  case only  on the basis of
such material as may be produced before him by both parties,
must be  followed in  a  proceeding  under  Article  32  for
enforcement of  a fundamental  right. In  fact, there  is no
such constitutional  compulsion enacted  in  clause  (2)  of
Article 32  or in  any other part of the Constitution. There
is nothing  sacrosanct about  the adversarial procedure with
evidence led by either party and tested by cross-exmaination
by the other party and the judge playing a positive role has
become a  part of our legal system because it is embodied in
the Code of Civil procedure and the Indian Evidence Act. But
these statutes  obviously have  no application  where a  new
jurisdiction is created in the Supreme Court for enforcement
of a  fundamental right.  Therefore it  is not  justified to
impose any  restriction on  the power  of the  Supreme Court
adopt such procedure as it thinks fit in exercise of its new
jurisdiction, by  engrafting adversarial  procedure  on  it,
when the constitution makers have deliberately chosen not to
insist on  any such  requirement and instead left it open to
the Supreme  Court to  follow such  procedure as  it  thinks
appropriate for  the purpose  of securing  the end for which
the power  is conferred namely, enforcement of a fundamental
right.[109 B-G]
     9. The  strict adherence  to the  adversarial procedure
can some  times lead  to injustice,  particularly  when  the
parties are  not  evenly  balanced  in  social  or  economic
strength. Where  one of  the parties to a litigation belongs
to a poor and deprived section of the community and does not
possess adequate  social and material resources, he is bound
to be  at a  disadvantage as  against a  strong and powerful
opponent under  the adversary  system of justice, because of
his difficulty in getting competent legal representation and
more than anything else, his inability to produce relevant-
73
evidence before  the court.  Therefore, when  the poor  come
before the  court, particularly  for  enforcement  of  their
fundamental rights,  it is  necessary  to  depart  from  the
adversarial procedure  and to  evolve a  new procedure which
will make it possible for the poor and the weak to bring the
necessary material  before the  court  for  the  purpose  of
securing enforcement  of their  fundamental rights.  If  the
adversarial procedure  is truly followed in their case, they
would never  be able to enforce their fundamental rights and
the  result   would  be   nothing  but   a  mockery  of  the
Constitution.  Therefore   the  Courts  should  abandon  the
laissez faire  approach in the judicial process particularly
where it  involves a  question of enforcement of fundamental
rights and forge new tools, devise new methods and adopt new
strategies for  the purpose  of  making  fundamental  rights
meaningful for  the large  masses of  people.  And  this  is
clearly permissible on the language of clause (2) of Article
32 because  the  Constitution  makers  while  enacting  that
clause have  deliberately and  advisedly not  used and wordsBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

restricting the  power of  the court  to adopt any procedure
which it  considers appropriate  in the  circumstances of  a
given case for enforcing a fundamental right. [110 B-F]
     10. It  is obvious  that the poor and the disadvantaged
cannot possibly  produce relevant  material before the Court
in support  of their  case and  equally where  an action  is
brought on  their  behalf  by  a  citizen  acting  pro  bono
publico, it would be almost impossible for him to gather the
relevant material  and place  it before the Court. In such a
case the  Supreme Court would be failing in discharge of its
contiotnal duties  of enforcing  a fundamental  right if  it
refuses to  intervene because  the stitupetitioner belonging
to the  underprivileged  segment  of  society  or  a  public
spirited citizen  espousing his  cause is  unable to produce
the relevant material before the court. If the Supreme Court
were to adopt a passive approach and decline to intervene in
such a  case because relevant material has not been produced
before  it  by  the  party  seeking  its  intervention,  the
fundamental rights would remain merely a teasing illusion so
far as  the poor and disadvantaged sections of the community
are concerned.  Therefore the  Supreme Court has evolved the
practice  of  appointing  commissions  for  the  purpose  of
gathering facts  and data in regard to a complaint of breach
of a fundamental right made on behalf of the weaker sections
of the society. The Report of the commissioner would furnish
prima facie  evidence of  the facts and data gathered by the
commissioner and that is why the Supreme Court is careful to
appoint a  responsible person  as commissioner  to  make  an
inquiry or  investigation into  the facts  relating  to  the
complaint. Even  in the past the Supreme Court has appointed
sometimes a district magistrate, sometimes a district Judge,
sometime  a   professor  of  law,  sometimes  a  journalist,
sometimes an  officer of the court and sometimes an advocate
practising in  the court, for the purpose of carrying out an
enquiry or  investigation and  making report  to  the  court
because the  commissioner appointed  by the  Court must be a
responsible person  who enjoys  the confidence  of the court
and who  is expected to carry out his assignment objectively
and impartially  without any predilection or prejudice. Once
the report  of the  commissioner is  received, copies  of it
would be supplied to the parties so that either party, if it
wants to  dispute any  of the  facts or  date stated  in the
Report, may  do so by filing an affidavit and the court then
consider the  report of  the commissioner and the affidavits
which may have been filed and proceed to adjudicate upon the
issue arising in the writ petition. It would be entirely for
the Court to consider what weight to attach to the facts and
data stated  in the  report of  the commissioner and to what
extent to  act upon such facts and data. But it would not be
correct to  say that  the report  of the commissioner has no
evidentiary value at all, since the statements
74
made in  it are  not tested  by cross-examination. To acceptBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

this  contention  would  be  to  introduce  the  adversarial
procedure in  a proceeding  where in the given situation, it
is totally inapposite. [111 B-H, 112, A-B]
     11. It  is true  that Order  XLVI of  the Supreme Court
Rules 1966 makes the provisions of Order XXVI of the Code of
Civil Procedure,  except rules  13, 14,  19 20,  21  and  22
applicable to  the Supreme Court and lays down the procedure
for an application for issue of a Commission, but Order XXVI
is not  exhaustive and  does not  detract from  the inherent
power of  the Supreme  Court to appoint a commission, if the
appointment of  such commission  is found  necessary for the
purpose of  securing enforcement  of a  fundamental right in
exercise of  its constitutional  jurisdiction under  Article
32. Order XLVI of the Supreme Court Rules 1966 cannot in any
way militate  against the  power of  the Supreme Court under
Article 32  and in fact rule 6 of Order XLVII of the Supreme
Court Rules 1966 provides that nothing in these Rules "shall
be deemed  to limit  or otherwise affect the inherent powers
of the court to make such orders as may be necessary for the
ends of justice. [112 C-F]
     In the  instant case,  therefore, the court did not act
beyond its  power in  appointing  the  commissions  for  the
purpose of  making an inquiry into the conditions of workmen
employed in  the stone  quarries. The petitioner in the writ
petition specifically  alleged violation  of the fundamental
rights of  the workmen  employed in the stone quarries under
Articles 21  and 23  and it  was therefore necessary for the
court to  appoint these  commissioners for  the  purpose  of
inquiring into  the facts  related to  this  complaint.  The
Reports of  the Commissions  were clearly  documents  having
evidentiary value and they furnished prima facie evidence of
the facts and data stated in those Reports. Of course, it is
for the  court to  consider what  weight it should attach to
the facts  and data  contained in these Reports in the light
of the various affidavits filed in the proceedings.[112 F-H,
113 A-B]
     12. The  position pointed  out  as  the  power  of  the
Supreme Court  to appoint  commissioners in  the exercise of
its jurisdiction  under Article  32 must  apply  equally  in
relation to  the exercise of jurisdiction by the High Courts
under Article  226 for the latter jurisdiction is also a new
constitutional jurisdiction  and it is conferred in the same
wide terms as the jurisdiction under Article 32 and the same
powers can and must therefore be exercised by the High Court
while exercising  jurisdiction under  Article 226.  In fact,
the jurisdiction  of the  High Courts  under Article  226 is
much wider, because the High Courts are required to exercise
this jurisdiction  not only for enforcement of a fundamental
right but  also for enforcement of any legal right and there
are many  rights conferred on the poor and the disadvantaged
which are  the creation  of statute  and  they  need  to  be
enforced as  urgently and  vigorously as fundamental rights.
[113 B-D]Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

     3: 1.  The Stone  quarries  in  the  instant  case  are
"mines" within the meaning of the Section 2 (j) of the Mines
Act, 1952  since they  are excavations  where operations for
the purpose of searching for or obtaining stone by quarrying
are being  carried on  but they  are not  open cast working'
since admittedly  excavations in  the case  of  these  stone
quarries extend below superjacent ground. Since the workings
in these  stone quarries extend below superjacent ground and
they are  not 'open  east workings'  and moreover explosives
are admittedly used in connection with
75
the excavation, the conditions set out in the proviso to see
3 (i)  (i) are  not fulfilled and hence the exclusion of the
provisions of  the Mines  Act 1952  (other than the excepted
sections) is  not attracted  and all  the provisions  of the
Mines Act 1952 apply to these stone quarries. The provisions
contained in  chapters V,  VI &  VII of the Mines Act confer
certain rights  and benefits  on the workmen employed in the
stone quarries  and stone  crushers  and  these  rights  and
benefits intended  to secure  to the  workman just and human
conditions of  work ensuring  a decent standard of life with
basic human  dignity. Since the stone quarries are not being
exploited by  the State of Haryana though it is the owner of
the stone  quarries, but  are being  given out  on lease  by
auction, the  mine-lessees who are not only lessees but also
occupiers of  the stone quarries are the owners of the stone
quarries within  the meaning  of that  expression as used in
section 2  (1) and  so also are the owners of stone crushers
in relation  to their  establishment. The  mine-lessees  and
owners  of  stone  crushers  are,  therefore,  liable  under
section 18  of the  Mines  Act,  1952  to  carry  out  their
operations in  accordance with  the provisions  of the Mines
Act, 1952  and the  Mines Rules,  1955 and  other Rules  and
Regulations made  under that  Act and  to  ensure  that  the
rights  and  benefits  conferred  by  these  provisions  are
actually and  concretely made  available to the workmen. The
Central Government  is entrusted  under the  Mines Act  1952
with the  responsibility of  securing  compliance  with  the
provisions of that Act and of the Mines Rules 1953 and other
Rules and  Regulations made  under that  Act and  it is  the
primary obligation  of the Central Government to ensure that
these provisions  are complied  with by the mine-lessees and
stone crusher  owners. The State of Haryana is also under an
obligation to  take all  necessary steps  for the purpose of
securing compliance  with  these  provisions  by  the  mine-
lessees and  owners of  stone crushers. The State of Haryana
is therefore,  in any event, bound to take action to enforce
the provisions  of the  Mines Act  1952 and  the Mines Rules
1955 and other Rules and Regulations made under that Act for
the benefit  of the  workmen. [113  G-H, 114 A, 115 A, E, G,
116 B-F, 117 C-D]
     13. The  Inter-state  Migrant  Workmen  (Regulation  of
Employment and  conditions of  Service) Act,  by sub-sectionBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

(4) of  section (1)  applies to every establishment in which
five or  more inter-State  Migrant workmen  are employed  or
were employed  on any day of the preceding twelve months and
so also  it applies  to  every  contractor  who  employs  or
employed five or more inter-State migrant workmen on any day
of the  preceding twelve months. Section (2) sub-section (1)
Clause (b)  of the Act defines contractor, in relation to an
establishment, to  mean "a person who undertakes (whether as
an independent  contractor, agent, employee or otherwise) to
produce a  given result  for the establishment, other than a
mere supply  of goods  and articles  of manufacture  to such
establishment, by  the employment  of workmen  or to  supply
workmen to  the establishment, and includes a subcontractor,
khatedar, sardar,  agent or  any other  person, by  whatever
name called, who recruits or employs workman." Clause (e) of
sub-section (1)  of section  (2) defines "interstate Migrant
Workmen" to  mean "any person who is recruited by or through
a contractor  in one  State  under  an  agreement  or  other
arrangement for  employment in  an establishment  in another
State,  whether  with  or  with-out  the  knowledge  of  the
principal employer  in relation  to such establishment." The
expression "principal  employer" is defined by clause (g) of
sub-section (1) of section 2 to mean "in relation to a mine,
the owner  or agent  of the mine and where a person has been
named as  the manager  of the  mine, the  person so  named."
Obviously, therefore,  the mine-lessees  and owners of stone
crushers in  the present  case would  be principal employers
within the meaning of that expression as used in the Inter-
76
State  Workmen   Act.  Section  16   lays  a  duty  on  every
contractor  employing   inter  State   migrant  workmen   in
connection with  the work  of an  establishment  to  provide
various other  facilities particulars  of which  are  to  be
found in  Rules 36  to 45 of the Inter-State Migrant Workmen
Rules.  (These   facilities   include   medical   facilities
protective clothing,  drinking water,  latrines, urinals and
washing  facilities,   rest  rooms,   canteens,  creche  and
residential accommodation).  The obligation to provide these
facilities is in relation to the inter-State migrant workmen
employed in  an establishment  to which the Act applies. But
this liability  is not  confined  only  to  the  contractor,
because Section  18 provides  in so  many terms  that if any
allowance required  to be  paid under-section 14 or 15 to an
inter-State migrant workman is not paid by the contractor or
if any  facility specified in Section 16 is not provided for
the benefit of such workman, such allowance shall be paid or
as the  case may  be, the  facility shall be provided by the
principal employer  within such time as may be prescribed by
the Rules  and all  the allowances  paid  by  the  principal
employer or  all  the  expenses  incurred  by  him  in  this
connection may  be recovered  by  him  from  the  contractor
either  by   deduction  from   the  amount  payable  to  the
contractor or as a debt payable by the contractor. [117 F-H,Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

119 E-A-120 A]
     14. The  thekedar or jamadar who is engaged by the mine
lessees or  the stone  crusher owners  to recruit workmen or
employ them  on behalf  of the mine lessees or stone crusher
owners would clearly be a 'contractor' within the meaning of
that term as defined in Section 2 sub-section (1) clause (b)
and the  workmen recruited  by or  through  him  from  other
States for  employment  in  the  stone  quarries  and  stone
crushers in the State of Haryana would undoubtedly be inter-
State migrant  workman .  Even when  the thekedar or jamadar
recruits or employs workmen for the stone quarries and stone
crushers by  sending  word  through  the  "old  hands",  the
workmen  so  recruited  or  employed  would  be  inter-State
migrant workmen,  because the  "old hands"  would be  really
acting as  agents of the thekedar or jamadar for the purpose
of recruiting  or employing workmen crushers in the State of
Haryana. [121-E]
     15. In  addition to  the rights  and benefits conferred
upon him  under the  Inter-State Migrant workmen Act and the
inter-State Migrant  Workmen Rules,  an inter-State  migrant
workman is  also, by  reason of  Section 21, entitled to the
benefit  of   the  provisions  contained  in  the  Workmen's
Compensation Act  1923, The  Payment of  Wages Act 1936, The
Employees'  State   Insurance  Act   1948,  The   Employees'
Provident Funds  and Misc.  Provisions Act,  1952,  and  the
Maternity Benefit Act 1961. [122 B-C]
     The  obligation   to  give  effect  to  the  provisions
contained in  these various  laws is  not only  that of  the
jamadar or  thekedar and  the minelessees and stone crushers
owners (provided  of course  there are 5 or more inter-State
Migrant Workmen employed in the establishment) but also that
of the  Central Government  because the  Central  Government
being the  "appropriate Government"  within the  meaning  of
Section 2(1)(a)  is under  an obligation  to take  necessary
steps for  the purpose  of securing  compliance  with  these
provisions by  the thekedar  or jamadar and mine-lessees and
owners of stone crushers. The State of Haryana is also bound
to ensure that these provisions are observed by the thekedar
or jamadar  and minelessees  and owners  of stone  crushers.
[122 D-F]
     16. If  the Jamadar  or thekadar  in a  stone quarry or
stone crusher  is a  contractor' within  the meaning  of the
definition of the term in the Inter-State Migrant
77
Workmen Act,  he would a fortiorari be 'contractor' also for
the purpose  of Contract Labour Act and any workmen hired in
or in  connection with  the work  of stone  quarry or  stone
crusher by  or through  the jamadar  or  thekedar  would  be
workmen entitled  to the  benefit of  the provisions  of the
Contract  Labour  Act.  Where  therefore  the  thekedar  for
Jamadar is  a Contractor,  and the  workmen are  employed as
'contract labour' within the meaning of these expressions as
used in  the Contract  Labour Act  the Contractor as well asBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

the principal  employer would  be liable  to comply with the
provisions of  the Contract  Labour  Act  and  the  Contract
Labour Rules  and to  provide to  the contract labour rights
and benefits  conferred by  these  provisions.  The  Central
Government being  the "appropriate  government"  within  the
meaning of  section 2  sub-section (1)  clause (a)  would be
responsible for  ensuring compliance  with the provisions of
the Contract Labour Act and the Contract Labour Rules by the
mine-lessees and  stone crushers  owners and the thekedar or
jamadar. So  also, for  reasons discussed while dealing with
the applicability  of the Mines Act 1952 and the Inter State
Migrant Workmen Act, the State of Haryana. would be under an
obligation to  enforce the provisions of the Contract Labour
Act and  the Contract  Labour Rules  for the  benefit of the
workmen. [123 E-F, H, 124 A-C]
     17. There  can be  no doubt  and indeed  this  was  not
disputed on  behalf of  the respondents,  that  the  Minimum
Wages Act  1948 is  applicable to  workmen employed  in  the
stone quarries and stone crushers. Therefore whatever be the
mode of  payment followed  by the  mine  lessees  and  stone
crusher owners,  the workmen  must get nothing less than the
minimum wage  for the job which is being carried out by them
and if  they are  required to  carry out additionally any of
the functions  pertaining to  another job  or occupation for
which a  separate minimum  wage is  prescribed, they must be
paid a  proportionate part  of such minimum wage in addition
to the  minimum wage  payable to them for the work primarily
carried out  by them.  The system  of payment which is being
followed in  the stone  quarries and  stone crushers,  under
which the  expenses of  the explosives and of drilling holes
are to  be borne  by the  workmen out  of their  own  wages,
should be  changed and  the explosives required for carrying
out blasting  should be  supplied by the mine lessees or the
jamadar or  thekedar without any deduction being made out of
the wages  of the workmen and the work of drilling holes and
shot firing  should be  entrusted only  to  those  who  have
received the  requisite training  under the Mines Vocational
Training  Rules  1966.  So  far  as  the  complaint  of  the
petitioner that  the workmen  employed in the stone quarries
and stone  crushers are  not being paid the minimum wage due
and payable  for the  work carried out by them is concerned,
it is  a matter  which would  have to  be  investigated  and
determined. [124C, 125 A-E]
     The Bonded  Labour system is intended to strike against
the system  of bonded  labour which has been a shameful scar
on the  Indian  Social  Scene  for  decades  and  which  has
continued to  disfigure the  life of  the nation  even after
independence. The Act was brought into force through out the
length and  breadth of  the country  with effect  from  25th
October 1975, which means that the Act has been in force now
for almost  8 years  and if  properly implemented, it should
have by  this time  brought about  complete  identification,
freeing  and   rehabilitation  of   bonded  labour.  But  asBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

official, semi-official  and non-official  reports show,  we
have yet to go a long way in wiping out this outrage against
humanity. [126 A-C]
     18. It  is clear  bonded labour  is a  form  of  forced
labour  and   Section  12   of  the   Bonded  Labour  System
(Abolition)   Act    1976   recognises   this   self-evident
proposition by  laying a  duty on  every District Magistrate
and every officer specified
78
by him  to inquire  whether any  bonded labour system or any
other form  of forced  labour is  being enforced  by  or  on
behalf of  any person and, if so, to take such action as may
be necessary  to eradicate  the enforcement  of such  forced
labour. The  thrust of the Act is against the continuance of
any form  of forced  labour. It  is  of  course  true  that,
strictly speaking,  a bonded  labourer means  a labourer who
incurs or  has or is presumed to have incurred a bonded debt
and a  bonded debt  means an advance obtained or presumed to
have  been  obtained  by  a  bonded  labourer  under  or  in
pursuance of the bonded labour system and it would therefore
appear that  before a  labourer can  be regarded as a bonded
labourer, he  must not  only be  forced to provide labour to
the employer  but he  must have  also received an advance or
other economic  consideration from the employer unless he is
made to  provide forced labour in pursuance of any custom or
social  obligation   or  by  reason  of  his  birth  in  any
particular caste or community. [130 A-D]
     19. The  contention of  the State  of Haryana  that the
burden of  proof under  the bonded labour System (Abolition)
Act, 1976  is upon  the bonded labourers is misconceived. To
insist that  the bonded labourers must first prove that they
are providing  forced labour  in consideration of an advance
or other  economic consideration  received by  them and then
only they  would be eligible for the benefits provided under
the Act,  is nothing  but asking  them to do a task which is
extremely difficult,  if not impossible. The labourers would
have no  evidence at all to prove so and since employment of
bonded labour is a penal offence under the Act, the employer
would immediately without any hesitation disown having given
any  advance   or  economic   consideration  to  the  bonded
labourers. The insistence of proof from two labourers by the
State Government which is constitutionally mandated to bring
about  change  in  the  life  conditions  of  the  poor  and
downtrodden  and   to  ensure  social  justice  to  them  is
reprehensible. [130 F-H, 131 A]
     It would  be cruel  to insist  that a  bonded labour in
order  to   derive  the  benefits  of  this  social  welfare
legislation, should  have to  go through a formal process of
trial with  the normal  procedure for recording of evidence.
That would be a totally futile process because it is obvious
that a  bonded labourers  can never stand up to the regidity
and formalism  of the  legal process  due  to  his  poverty,
illiteracy and  social and economic backwardness and if suchBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

a  procedure   were  required  to  be  followed,  the  State
Government might  as  well  obliterate  this  Act  from  the
statute book.  It is now statistically established that most
of bonded  labourers are  members of  Scheduled  Castes  and
Scheduled Tribes  or other  backward  classes  and  ordinary
course of  human affairs  would show, indeed judicial notice
can be  taken of  it, that  there would be no occasion for a
labourer to be placed in a situation where he is required to
supply forced labour for no wage or for nominal wage, unless
he has received some advance of other economic consideration
from the  employer and  under  the  consideration  from  the
employer and  under the  pretext of not having returned such
advance or  other economic  consideration, he is required to
render service to the employer or is deprived of his freedom
of employment  or of  the right  to move  freely wherever he
wants. Therefore,  whenever it  is shown that a labourers is
made to  provide forced  labour, the  Court  would  raise  a
presumption that he is required to do so in consideration of
an advance  or other  economic consideration received by him
and he  is therefore a bonded labourer. This presumption may
be rebutted by the employer and also by the State Government
if it  so chooses but unless and until satisfactory material
is produced  for reubutting this presumption, the Court must
proceed on  the basis that the labourer is a bonded labourer
entitled to  the benefit  of the  provisions of the Act. The
State Government cannot
79
be  permitted  to  repudiate  its  obligation  to  identify,
release and  rehabilitate the  bonded labourers  on the plea
that though  the concerned labourers may be providing forced
labour, the  State Government does not owe any obligation to
them unless  and until  they show  in an  appropriate  legal
proceeding conducted  according to  the rules  of  adversary
system of justice, that they are bonded labourers. [131 C-H,
132 A]
     20. Though  section 13  provides for  constitution of a
Vigilance Committee  in each  District and each sub-division
of a District, the Government of Haryana, for some reason or
the other,  did not constitute any Vigilance Committee until
its attention  was drawn  to this  requirement of the law by
this Court.  It may  be that  according to the Government of
Haryana there  were not  at any  time any  bonded  labourers
within its territories, but even so Vigilance Committees are
required  by  Section  13  to  be  constituted  because  the
function of  the Vigilance  Committee is  to identify bonded
labourers, if  there are  any, and  to free and rehabilitate
them and  it would not be right for the State Government not
to constitute  vigilance Committees  on the  assumption that
there are  no  bonded  labourers  at  all.  In  constituting
Vigilance Committee  in each  District and sub-division, the
Haryana Government  would do well to include representatives
of non-political social action groups operating at the grass
root level, for it is only through such social action groupsBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

and voluntary  agencies that  the problems of identification
of bonded labour can be effectively solved. [128 E-H, 129 A-
B]
     The magistrates  and  judicial  officers  take  a  very
lenient view  of violations  of labour  laws enacted for the
benefits of the workmen and let off the defaulting employers
with small  fines. There  have also been occasions where the
magistrate and  judicial officers have scotched prosecutions
and acquitted  or discharged  the  defaulting  employers  on
hyper  technicalities.  This  happens  largely  because  the
magistrates  and  judicial  officers  are  not  sufficiently
sensitised to  the importance  of the  observance of  labour
laws with  the result that the labour laws are allowed to be
ignored and breached with utter callousness and indifference
and the  workmen begin to feel that the defaulting employers
can, by  paying a  fine which  hardly touches  their pocket,
escape from  the arm  of law  and the labour laws supposdely
enacted for  their benefit  are not meant to be observed but
are merely  decorative appendages  intended to  assuage  the
conscience of  the workmen.  The  Magistrates  and  Judicial
Officers should  take a  strict view  of violation of labour
laws  and  to  impose  adequate  punishment  on  the  erring
employers so  that they  may realise that it does not pay to
commit a breach of such laws and to deny the benefit of such
laws to the workmen. [145 A-D]
     21. The  Court issued several directions to the Central
Government  and   the  State   Government  and  the  various
authorities  for  implementing  the  provisions  enacted  in
various social  welfare laws  for the benefit of the workmen
employed in  the stone  quarries and  stone crushers  in the
state of  Haryana. So  that the  poor  workmen  who  lead  a
miserable existence  may one  day be  able to  realise  that
freedom is  not only  the monopoly  of a  few but belongs to
them all  and that they are also equally entitled along with
others  to   participate  in   the  fruits  of  freedom  and
development. [132 D, 145 D-F]
PER PATHAK, J CONCURRING
     (1) Public  Interest Litigation  in  its  present  form
constitutes a  new chapter  in our  judicial system.  It has
acquired  a   significant  degree   of  importance   in  the
jurisprudence practised  by our  courts  and  has  evoked  a
lively, if somewhat con-
80
troversial, response  in legal  circles, in  the  media  and
among the  general public. In our country, this new class of
litigation is  justified by  its protagonists  on the  basis
generally of  vast areas in our population of illiteracy and
poverty, of  social and  economic backwardness,  and  of  an
insufficient awareness  and appreciation  of individual  and
collective rights.  These handicaps  have denied millions of
our countrymen access to justice. Public interest litigation
is said to possess the potential or providing such access in
the milieu of a new ethos, in which participating sectors inBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

the administration of justice cooperate in the creation of a
system  which   promises  legal  relief  without  cumbersome
formality and  heavy expenditure.  In the  result, the legal
organisation has  taken on  a radically  new dimension,  and
correspondingly  new  perspectives  are  opening  up  before
judges and  lawyers and  State Law  agencies  in  the  tasks
before them. A crusading zeal is abroad, viewing the present
as an opportunity to awaken the political and legal order to
the  objectives   of  social   justice  projected   in   our
constitutional system.  New slogans  fill the  air, and  new
phrases have  entered the legal dictionary, and one hears of
the  "justicing  system"  being  galvanised  into  supplying
justice to  the socioeconomic disadvantages. These urges are
responsible for  the birth of new judicial concepts. and the
expanding horizon  calpower.  They  claim  to  represent  an
increasing emphasis  on social  welfare  and  a  progressive
humanitarianism, To the mind trained in the certainty of the
law, of  defined principles,  of binding  precedent, and the
common law  doctrine of stare decisis, the future is fraught
with confusion  and disorder  in the  legal world and severe
strains in  the constitutional  system. At the lowest, there
is an  uneasy doubt  about where  we are  going.  If  public
interest litigation is to command broad acceptance attention
must be paid to certain relevant considerations. The history
of human  experience shows  that when  a revolution in ideas
and in action enters the life of a nation, the nascent power
so  released   possesses  the   potential  of  throwing  the
prevailing  social   order  into  disarray.  In  a  changing
society, wisdom  dictates that  reform should  emerge in the
existing polity  as an  ordered change  produce through  its
institution. Moreover,  the  pace  of  change  needs  to  be
handled  with  care  lest  the  institutions  themselves  be
endangered. [152 F-H; 153 A-C; 153 G; 154 A-B]
     1:2  Like   the  Warren   Court's  affirmative   action
programmes for  the benefit of minorities and other socially
or economically  disadvantaged interests through the avenues
of Public Law, the courts in India, are beginning to apply a
similar concept  of constitutional  duty.  The  doctrine  of
standing has  been  enlarged  in  India  to  provide,  where
reasonably possible,  access to  justice to large sectors of
people for  whom so  far it had been a matter of despair. It
is time  indeed for  the law to do so. In large measure, the
traditional  conception   of  adjudication  represented  the
socioeconomic vision  prevailing at the turn of the century.
In India,  as the  consciousness of  social  justice  spread
though our  multi-layered  social  order,  the  constitution
began to  come under  increasing pressure from social action
groups petitioning  on behalf  of the  under privileged  and
deprived sections  of society  for the  fulfillment of their
aspirations. Despite  the varying  fortunes of the number of
cases of  public interest  litigation which have entered the
Supreme Court,  Public Interest Litigation constitutes today
a significant  segment of the court's docket. [154 D: 156 A-Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

C]
     2:1. The  provisions of  Article 32 do not specifically
indicate who  can move  the  Court.  In  the  absence  of  a
confining provision  in that  respect, it  is plain  that  a
petitioner may  be anyone  in  whom  the  Law  recognises  a
standing to maintain an action of such nature. [156 E]
81
     2:2.  As   regards  the  form  of  proceeding  and  its
character,  Article  32  speaks  generally  of  "appropriate
proceedings."  It   should  be   a  proceeding   which   can
appropriately lead  to an adjudication of the claim made for
the enforcement of a fundamental right and can result in the
grant of  effective relief. Article 32 speaks of the Court's
power "to  issue direction  or  orders  of  writs,  and  the
specific reference to "writs in the nature of habeas corpus,
mandamus, prohibition,  quo warranto  and certiorari"  is by
way of illustration only. They do not exhaust the content of
the Court's power under Article 32. [156 F-G]
     3:1. A practice has grown in the public of invoking the
jurisdiction of this Court by a simple letter complaining of
a legal  injury to  the author  or to  some other  person or
group of persons, and the Court has treated such letter as a
petition under  Article 32  and entertained  the  proceeding
without anything  more. It  is only  comparatively  recently
that the Court has begun to call for the filing of a regular
petition on  the letter. There is grave danger inherent in a
practice where  a mere  letter is  entertained as a petition
from a person whose antecedents and status are unknown or so
uncertain that  no  sense  of  responsibility  can,  without
anything more,  be attributed to the communication. There is
good reason  for the  insistence on a document being set out
in a  form, or  accompanied by evidence, indicating that the
allegations  made   in  it   are  made   with  a   sense  of
responsibility by  a person  who  has  taken  due  care  and
caution to  verify those  allegations before  making them. A
plaint instituting  a suit  is required by the Code of Civil
Procedure to  conclude with a clause verifying the pleadings
contained in it. A petition or application filed in court is
required to  be supported on affidavit. These safeguards are
necessary because  the document,  a plaint  or  petition  or
application, commences  a course of litigation involving the
expenditure of  public time  and public  money,  besides  in
appropriate cases  involving the  issue of summons or notice
to the  defendant or  respondent to  appear and  contest the
proceeding. Men  are busy  conducting the  affairs of  their
daily lives,  and no  one occupied with the responsibilities
and  pressures  of  present  day  existence  welcomes  being
summoned to  a law  court and  involved in  a litigation.  A
document making  allegations without  any proof  whatever of
responsibility can  conceivably constitute  an abuse  of the
process of  law. Therefore,  in  special  circumstances  the
document  petitioning   the  court   for  relief  should  be
supported by  satisfactory verification. This requirement isBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

all the  greater where  petitions are  received by the Court
through  the   post.  It   is  never  beyond  the  bound  of
possibility  that   an  unverified   communication  received
through the post by the court may in fact have been employed
mala fide,  as an  instrument of  coercion or  blackmail  or
other oblique  motive against  a person  named  therein  who
holds a position of honour and respect in society. The Court
must be  ever vigilant  against the abuse of its process. It
cannot do  that better  in this matter than insisting at the
earliest stage, and before issuing notice to the respondent,
that an  appropriate  verification  of  the  allegations  be
supplied. The  requirement  is  imperative  in  private  law
litigation. Having  regard to  its nature and purpose, it is
equally attracted  to public interest litigation. While this
Court has  readily acted  upon letters  and telegrams in the
past,  there  is  need  to  insist  now  on  an  appropriate
verification of  the petitioner  other communication  before
acting on  it. It  will always  be a matter for the court to
decide. on  what petition  will it  require verification and
when will it waive the rule. [157 B-H; 158 A-C]
     3:2. All  communications  and  petitions  invoking  the
jurisdiction of  the Court  must be  addressed to the entire
Court, that  is to  say, the Chief Justice and his companion
judges, No  such communication  or petition  can properly be
addressed
82
to a particular judge. When the jurisdiction of the Court is
invoked, it  the jurisdiction  of the  entire  court.  Which
Judge or  Judges will  hear the case is exclusively a matter
concerning the  internal regulation  of the  business of the
Court, interference  with which  by a  litigant or member of
the public  constitutes the grossest impropriety. It is well
established that  when a  division of  the Court  house  and
decides cases  it is  in law  regarded as  a hearing  and  a
decision by  the Court  itself. The  judgment pronounced and
the decree  or  order  made  are  acts  of  the  Court,  and
accordingly  they   are  respected,   obeyed  and   enforced
throughout the  land. It  is only right and proper that this
should be  known clearly  to the  lay public. Communications
and petitions  addressed to  a particular Judge are improper
and violate the institutional personality of the Court. They
also  embarrass  the  judge  to  whom  they  are  personally
addressed. The  fundamental conception  of the Court must be
respected, that  is  a  single  indivisible  institution  of
united  purpose   and   existing   solely   for   the   high
constitutional functions  for which it has been created. The
conception of  the Court  as a loose aggregate of individual
Judges, to  one or  more of  whom  judicial  access  may  be
particularly  had,   undermines  its   very  existence   and
endangers its  proper and  effective functioning.  [158 E-H;
159 A]
     4:1. In  public interest  litigation, the  role held by
the Court  is more  assertive than  in traditional  actions.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Viewed from  the Warren  Court's experience  the role of the
Court is creative rather than passive, and it assumes a more
positive attitude  in determining  facts.  Not  infrequently
public interest litigation affects the rights of persons not
before the  Court, and  in shaping the relief the court must
invariably take  into account its impact on those interests.
Moreover, when  its jurisdiction  is invoked  on behalf of a
group, it  is as well to remember that differences may exist
in content  and emphasis  between the  claims  of  different
sections of  the group. For all these reasons the court must
exercise the  greatest caution and adopt procedures ensuring
sufficient notice  to all  interests likely  to be affected.
Moreover, the  nature of  the litigation  sometimes involves
the continued  intervention of  the Court  over a  period of
time, and the organising of the litigation to a satisfactory
conclusion  calls   for  judicial   statemanship,  a   close
understanding of  constitutional and  legal  values  in  the
context of  contemporary social  forces, and a judicious mix
of restraint  and activism  determined by  the  dictates  of
existing realities. Importantly, at the same time, the Court
must never  forget that  its jurisdiction extends no farther
than the legitimate limits of its constitutional powers, and
avoid trespassing  into political  territory which under the
Constitution has  been appropriated  to other  organs of the
State. [159 B; D-G]
     4;2. The  procedures adopted  by the  Court in cases of
public interest  litigation must  of  course  be  procedures
designed and  shaped by  the Court  with a view to resolving
the problem  presented before  it on  determining the nature
and  extent  of  relief  accessible  in  the  circumstances.
Whatever the  procedure adopted  by the  court  it  must  be
procedure known  to judicial  tenets and characteristic of a
judicial  proceeding.  There  are  methods  and  avenues  of
procuring material  available to  executive and  legislative
agencies and  often employed  by them  for the efficient and
effective discharge  of the tasks before them. Not all those
methods and  avenues are  available to  the Court. the Court
must ever  remind itself that one of the indicia identifying
it as  a Court  is the nature and character of the procedure
adopted by  it in  determining a  controversy. It is in that
sense limited  in the  evolution of procedures pursued by it
in the  process of  an adjudication,  and in  the grant  and
execution of  the relief.  Legal jurisprudence  has  in  its
historical
83
development identified  certain fundamental principles which
form the  essential constituents of judicial procedure. They
are employed  in every  judicial proceeding,  and constitute
the basic  infrastructure along  whose  chamacts  flows  the
power of  the Court  in the process of adjudication. [159 H;
160 A-D]
     4:3. What  should be  the  conceivable  frame  work  of
procedure in  public interest litigation does not admit of aBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

clear cut  answer. It  is not possible to envisage a defined
pattern of  procedure applicable  to all cases. Of necessity
the pattern  which the  Court  adopts  will  vary  with  the
circumstances of  each case.  But, if  there  is  a  statute
prescribing a  judicial procedure  governing the  particular
case the Court must follow such procedure. It is not open to
the Court  to bypass  the statute  and  evolve  a  different
procedure at variance with it. Where, however, the procedure
prescribed by statute is incomplete or insufficient, it will
be open  to the  Court to  supplement it by evolving its own
rules. Nonetheless, the supplementary procedure must conform
at all  stages to  the principles  of natural justice. There
can be  no deviation  from the principles of natural justice
and other well accepted procedural norms characteristic of a
judicial proceeding.  They  constitute  an  entire  code  of
general  principles  of  procedure,  tried  and  proven  and
hallowed by the sanctity of common and consistent acceptance
during long  years of the historical development of the law.
The general  principles of  law, to which  reference is made
here, command  the confidence,  not merely  of the judge and
the lawyer  and the  parties to  the litigation,  but supply
that  basic   credible  to  the  judicial  proceeding  which
strengthens public  faith in the Rule of Law. They are rules
rooted  in   reason  and   fairplay  and   their  governance
guarantees a  just disposition of the case. The Court should
be wary  of suggestions  favouring novel procedures in cases
where accepted  procedural rules will suffice. [160 E-H; 161
A]
     5:1. Article  32 confers  the widest amplitude of power
of this Court in the matter of granting relief. It has power
to issue  "directions or  orders of  writs", and there is no
specific  indication,   no  express  language,  limiting  or
circumscribing that  power. Yet, the power is limited by the
very nature,  that its  judicial power.  It is  power  which
pertains to  the judicial  organ of the State, identified by
the very  nature of  the  judicial  institution.  There  are
certain fundamental  constitutional concepts which, although
elementary, need  to be  recalled at times. The constitution
envisages a broad division of the power of the State between
the legislature,  the executive  and the judiciary. Although
the division  is not  precisely demarcated, there is general
acknowledgement of  its limits.  The limits  can be gathered
from the  written text of the Constitution, from conventions
and constitutional  practice, and  from an  entire array  of
judicial decisions.  The constitutional  lawyer  concedes  a
certain measure  of overlapping  in functional  action among
the three  organs of  the State. But there is no warrant for
assuming geometrical  congruence. It  is common  place  that
while  the   legislature  enacts   the  law   the  executive
implements it  and the court interprets it and, in doing so,
adjudicates on  the validity  of executive  action and under
our  Constitution,   even  judges   the  validity   of   the
legislation itself.  And yet it is well recognised that in aBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

certain sphere  the legislature  is  possessed  of  judicial
power, the executive possesses a measure of both legislative
and judicial  functions, and  the  court,  in  its  duty  of
interpreting the law, accomplished in its perfected action a
marginal degree of legislative exercise. Nonetheless, a fine
and delicate  balance is  envisaged under  our  Constitution
between these  primary institutions  of the  State. In every
case the  Court should  determine the  true  limits  of  its
jurisdiction and,  having done  so, it  should take  care to
remain within  the restraints of its jurisdiction. [161 B-H;
162 A]
84
     5:2. This  aspect  of  Court  action  assumes  especial
significance in  public interest  litigation. It  bears upon
the  legitimacy   of  the  judicial  institution,  and  that
legitimacy is  affected as much by the solution presented by
the Court  in resolving  a controversy  as by  the manner in
which the  solution is  reached.  In  an  area  of  judicial
functioning where  judicial activism  finds room  for  play,
where constitutional  adjudication can  become an instrument
of social  policy forged by the personal political philosphy
of the  judge, this is an important consideration to keep in
mind. [162 B-C]
     5:3. Where the Court embarks upon affirmative action in
the attempt  to remedy a constitutional imbalance within the
social order, few critics will find fault with it so long as
it confines itself to the scope of its legitimate authority.
But there  is always  the possibility,  in  public  interest
litigation, of succumbing to the temptation of crossing into
territory which  properly pertains  to the Legislature or to
the Executive Government. For in most cases the jurisdiction
of the  Court is  invoked when a default occurs in executive
administration, and sometimes where a void in community life
remains unfilled by legislative action. The resulting public
grievance finds  expression through  social  action  groups,
which consider  the Court  an appropriate forum for removing
the deficiencies.  Indeed, the citizen seems to find it more
convenient to  apply to  the Court  for the  vindication  of
constitutional  rights  than  appeal  to  the  executive  or
legislative  organs   of  the   State.  In  the  process  of
correcting executive  error or removing legislative omission
the Court  can so  easily find  itself  involved  in  policy
making of  a quality  and  to  a  degree  characteristic  of
political authority,  and  indeed  run  the  risk  of  being
mistaken for one. An excessively political role identifiable
with political  governance betrays  the Court into functions
alien to its fundamental character, and tends to destroy the
delicate balance  envisaged  in  our  constitutional  system
between its  three basic  institutions. The Judge, conceived
in the true classical mould, is an impartial arbiter, beyond
and above political bias and prejudice, functioning silently
in  accordance   with  the  Constitution  and  his  judicial
conscience. Thus  does he  maintain the  legitimacy  of  theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

institution he  serves and honour the trust which his office
has reposed in him. [162 D-H]
     The  affirmative  schemes  framed  in  public  interest
litigation  by   the  Court   sometimes   require   detailed
administration  under  constant  judicial  supervision  over
protected periods.  The lives  of large  sections of  people
some of  whom have had no voice in the decisions, are shaped
and ordered  by mandatory  Court action  extending into  the
future. In  that context  it is  as well  to  remember  that
public  approval   and  public   consent   assume   material
importance in  its successful  implementation.  In  contrast
with policy  making by  legislation, where  a large  body of
legislators debate  on a  proposed legislative enactment, no
such visual  impact can  be perceived  when judicial decrees
are forged and fashioned by a few judicial personages in the
confines of  a Court. The mystique of the robe, at the stage
of  decision-making,   is  associated   traditionally   with
cloistered secrecy  and confidentiality  and the  end-result
commonly issues  as a  final definitive act of the Court. It
is a serious question whether in every case the same awesome
respect and reverence will endure during different stages of
affirmative action  seeking to  regulate the  lives of large
numbers of  people, some  of whom  never participated in the
judicial process. [163 A-D]
     5:4. Treating  with public interest litigation requires
more than  legal scholar  ship and  a knowledge of text book
law. It is of the utmost importance in such
85
cases that  when formulating  a scheme  of action, the Court
must have  due regard to the particular circumstances of the
case, to  surrounding realities  including the potential for
successful implementation,  and the likelihood and degree of
response from  the agencies  on whom the implementation will
depend. In  most cases  of public interest litigation, there
will be neither precedent nor settled practice to add weight
and force to the validity of the Court's action. The example
of similar  cases  in  other  countries  can  afford  little
support. The  successful implementation of the orders of the
Court will  depend upon  the particular social forces in the
backdrop  of   local  history,   the   prevailing   economic
pressures, the  duration  of  the  stages  involved  in  the
implementation, the momentum of success from stage to stage,
and the  acceptability of the Court's action at all times by
those involved in or affected by it. [163 E-G]
     5:5. An  activist Court  spearheading the  movement for
the   development    and   extension    of   the   citizen's
constitutional rights,  for  the  protection  of  individual
liberty and  for  the  strengthening  of  the  socioeconomic
fabric   in    compliance   with   declared   constitutional
objectives, will  need to  move with  a degree  of  judicial
circumspection. In  the centre  of a  social order  changing
with dynamic  pace, the Court needs to balance the authority
of the  past with  the urges of the future. In that task theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

court must  ever be  conscious of  the constitutional truism
that it  possesses the sanction of neither the sword nor the
pursue and  that  its  strength  lies  basically  in  public
confidence and support, and that consequently the legitimacy
of its  acts and  decisions must  remain beyond  all  doubt.
Therefore, whatever the case before it, whatever the context
of facts  and legal rights, whatever the social and economic
pressures of  the times, whatever the personal philosophy of
the Judge,  let it  not  be  forgotten  that  the  essential
identity of the institution, that it is a Court, must remain
preserved so  that every  action of the Court is informed by
the fundamental norms of law, and by the principles embodied
in the  Constitution  and  other  sources  of  law.  If  its
contribution to  the Jurisprudential  ethos of society is to
advance our  constitutional objectives,  it must function in
accord with  only those  principles  which  enter  into  the
composition of  judicial action  and give  to its  essential
quality. [163 H; 164 A-D]
     5:6. There  is a great merit in the Court proceeding to
decide an  issue on  the basis of strict legal principle and
avoiding carefully the influence of purely emotional appeal.
For that  alone gives  the decision of the Court a direction
which  is   certain,  and  unfaltering,  and  that  especial
permanence in  legal jurisprudence which makes it a base for
the next  step forward  in the  further progress of the law.
Indeed,  both   certainty  of  substance  and  certainty  of
direction are  indispensable requirements in the development
of the  law,  and  invest  it  with  the  credibility  which
commands public confidence in its legitimacy. [165 A-B]
     This warning  is  of  especial  significance  in  these
times, during  a phase of judicial history when a few social
action groups  tend to  show evidence  of presuming  that in
every case  the court  must bend  and mould  its decision to
popular notions  of which way a case should be decided. [165
C]
     As  new   areas  open  before  the  Court  with  modern
developments in  jurisprudence, in a world more sensitive to
human  rights   as  well  as  the  impact  of  technological
progress, the Court will become increasingly consious of its
expanding  jurisdiction.   That  is   inevitable.  But   its
responsibilities  are  correspondingly  great,  and  perhaps
never greater than now. [165 D]
86
     It must  be remembered that there is no higher Court to
correct over  the Supreme  Court its  errors, and  that  its
Judge wear  the mantle  of infallibility  only because their
decisions are  final. That the Judges sit at the apex of the
judicial administration  and their  word, by  constitutional
mandate, is  the law of the land can induce an unusual sense
of power.  It is  a feeling  Judges must  guard  against  by
constantly reminding  themselves that every decision must be
guided by reason and by judicial principles. [65 E-F]
     6:1. Persons in this country obliged to serve as bondedBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

labour  are   entitled  to   invoke  Article   23   of   the
Constitution. The  provisions embodied in that clause form a
vital constituent  of the  Fundamental Rights  set forth  in
Part III  of the  Constitution, and their violation attracts
properly the  scope of  Article 32 of the Constitution. [165
G]
     6:2. It is true that the reports of the court appointed
commissions have  not been  tested by cross examination, but
then the  record does  not show whether any attempt was made
by the  respondents to  call  them  for  cross  examination.
Further, whether  the appointment of the commissioners falls
within the  term of  order XLVI  of the Supreme Court Rules,
1966 is  of technical  significance only  because there  was
inherent power in the court, in the particular circumstances
of this  case to  take that action, However, the court would
do  well   to  issue   notice  to  the  respondents,  before
appointing any  Commissioner, in  those cases where there is
little apprehension  of the  disappearance of evidence. [166
B-C]
     6:3. The present case is one of considerable importance
to a   section  of our  people,  who  pressed  by  the  twin
misfortunes of  poverty and  illiteracy, are  compelled to a
condition of  life which  long since should have passed into
history.  The   continued  existence   of  such  pockets  of
oppression and  misery do  no justice  to the  promises  and
assurances extended  by our  Constitution to  its  citizens.
[166 B-E]
     PER AMARENDRA NATH SEN, J: (Concurring with Pathak, J.)
     1:  1.  Article  32  of  the  Constitution  is  clearly
attracted to  the facts  of the case, as in the present case
the violation  of the  fundamental right  of liberty  of the
workmen who  are said  to be  kept in  wrongful and  illegal
detention, employed  in forced  labour, is  alleged.  Forced
labour is  constitutionally forbidden  by Article 23 of the,
Constitution. [168 D-E]
     1:2.  Any   person  who  is  wrongfully  and  illegally
employed as a labourer in violation of the provisions of the
Bonded Labour  System (Abolition)  Act, 1976  is in  essence
deprived of  his liberty.  A bonded labourer truly becomes a
slave and  the freedom of a bonded labourer in the matter of
his employment and movement is more or less completely taken
away and  forced labour  is thrust upon him. When any bonded
labourer approached  this Court  the real  grievance that he
makes is  that he  should be  freed from this bondage and he
prays for  being set  at liberty  and liberty  is no doubt a
fundamental right  guaranteed  to  every  person  under  the
Constitution. There  cannot be  any manner of doubt that any
person who  is wrongfully  and  illegally  detained  and  is
deprived of  his  liberty  can  approach  this  Court  under
Article 32  of the Constitution for his freedom and wrongful
and  illegal  detention,  and  for  being  set  at  liberty.
Whenever any  person is wrongfully and illegally deprived of
his liberty,  it is open to anybody who is interested in theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

person  to   move  this   Court  under  Article  32  of  the
Constitution for  his release.  It may  not  very  often  be
possible for the person who is deprived of his liberty to
87
approach this  Court, as  by  virtue  of  such  illegal  and
wrongful detention,  he may not be free and in a position to
move the Supreme Court. [167 E-H]
     1:3. The  Bonded labourers  working  in  the  far  away
places are  generally poor  and  belong  to  the  very  weak
section of  the people.  They are also not very literate and
they may  not be  conscious of their own rights. Further, as
they are  kept in  bondage their  freedom is also restricted
and they  may not  be in  a position to approach this Court.
Though no fundamental right of the petitioner may be said to
be infringed,  yet  the  petitioner  who  complains  of  the
violation of  the fundamental  right of the workmen who have
been wrongfully  and  illegally  denied  their  freedom  and
deprived of  their constitutional  right must  be held to be
entitled to  approach this  Court on  behalf of  the  bonded
labourers  for   removing  them  from  illegal  bondage  and
deprivation of liberty. [168 B-C]
     S.P. Gupta  v. Union  of India & Another, [1981] Suppl.
S.C.C. 87, referred to
     2:1. Article  32 or  for that  matter any other article
does not  lay down any procedure which has to be followed to
move this  Court for  relief against  the violation  of  any
fundamental right.  Article 32  (1)  only  lays down that the
right to  move this  court by  appropriate  proceedings  for
enforcement  of   fundamental  rights   is  guaranteed.  The
Constitution very  appropriately leaves  the question  as to
what will  constitute  an  appropriate  proceeding  for  the
purpose  of   enforcement  of   fundamental  rights   to  be
determined by  the Court. This Court when sought to be moved
under Article  32 by  any party for redressing his grievance
against the  violation of-fundamental rights has to consider
whether the  procedure followed  by the party is appropriate
enough to  entitle the  court to proceed to act on the same.
No doubt  this Court has framed rules which are contained in
part IV,  Order XXXV  of the  Supreme Court  Rules under the
Caption "application  for enforcement of fundamental rights"
("Article 32  of the  Constitution") Generally speaking, any
party who  seeks to  move this Court under Article 32 of the
Constitution should  conform to  the rules  prescribed.  The
rules lay  down  the  procedure  which  is  normally  to  be
followed in  the matter  of any application under Article 32
of the  Constitution. These  rules are rules relating to the
procedure to  be adopted and the rules are intended to serve
as maids  to the Deity of Justice. Procedural law which also
forms a part of the law and has to be observed, is, however,
subservient to substantive law and the laws of procedure are
prescribed for promoting and furthering the ends of justice.
There cannot  be any  doubt that  this Court  should usually
follow the  procedure laid  down in  O.XXXV of  the Rules ofBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

this Court and should normally insist on a petition properly
verified by  an affidavit to be filed to enable the Court to
take necessary  action on the same. Though this Court should
normally insist on the rules of procedure being followed, it
cannot be  said, taking  into consideration  the  nature  of
right conferred  under Article  32  to  move this Court by an
appropriate proceeding and the very wide powers conferred on
this Court  for granting  relief in the case of violation of
fundamental  rights,   that  this   Court   will   have   no
jurisdiction to entertain any proceeding which may not be in
conformity with  procedure prescribed  by the  Rules of this
Court. The Rules undoubtedly lay down the procedure which is
normally to  be followed  for making  an  application  under
Article 32  of the  Constitution. They,  however, do not and
cannot have  the effect of limiting the jurisdiction of this
Court of  entertaining a  proceeding under Article 32 of the
Constitution, if  made, only in the manner prescribed by the
rules. [169 F-H; 170 A-D]
88
     2:2.  For   effectively  safeguarding  the  fundamental
rights  guaranteed   by  the   Constitution,  the  Court  in
appropriate cases in the interests of justice will certainly
be competent to treat a proceeding, though not in conformity
with the procedure prescribed by the Rules of this Court, as
an  appropriate   proceeding  under   Article  32   of   the
Constitution and  to entertain  the same. Fundamental rights
guaranteed under  the Constitution  are indeed too sacred to
be  ignored   or  trifled  with  merely  on  the  ground  of
technicality or  any rule  of procedure. The rules framed by
this Court do not also lay down that this Court can be moved
under Article 32 of the Constitution only in accordance with
the procedure  prescribed by  the Rules and not otherwise. A
mere technicality  in the  matter of form or procedure which
may not  in any  way affect  the substance of any proceeding
should not stand in the way of the exercise of the very wide
Jurisdiction  and  powers  conferred  on  this  Court  under
Article  32   of  the   Constitution  for   enforcement   of
fundamental rights guaranteed under the Constitution. Taking
into consideration  the substance  of  the  matter  and  the
nature of  allegations made, it will essentially be a matter
for the court to decide whether the procedure adopted can be
considered to  be an appropriate proceeding within the ambit
of Article 32 of the Constitution. The Court if satisfied on
the materials  placed in  the form  of  a  letter  or  other
communication addressed  to this  Court, may  take notice of
the same in appropriate cases. Experience shows that in many
cases it may not be possible for the party concerned to file
a regular  writ petition  in conformity  with procedure laid
down in the Rules of this Court. The Supreme Court for quite
some years  now has  in many  cases proceeded  to act on the
basis of  the letters  addressed  to  it.  A  long  standing
practice of  the Court  in  the  matter  of  procedure  also
acquired sanctity.  Further in  various cases  the Court hasBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

refused to  take any  notice of  letters or  other  kind  of
communications addressed to Court and in many cases also the
Court on  being moved by a letter has directed a formal writ
petition to  be filed  before  it  has  decided  to  proceed
further in the matter. [170 F-H; 171 A-D]
     2:3. It  is however  eminently desirable  that normally
the procedure  prescribed in  the rules of this Court should
be followed  while entertaining  a petition under Article 32
of  the   Constitution,  though  in  exceptional  cases  and
particularly in  the matter of general public interest, this
Court may,  taking into consideration the peculiar facts and
circumstances of  case, proceed to exercise its jurisdiction
under Article  32 of  the Constitution  for  enforcement  of
fundamental rights  treating the letter or the communication
in any other form as an appropriate proceeding under Art. 32
of the  Constitution. Further  any  party  who  addresses  a
letter or  any other  communication to  this  Court  seeking
intervention of  this Court  on the basis of the said letter
and   communication    should   address   this   letter   or
communication to  this Court and not to any individual Judge
by name. Such communication should be addressed to the Chief
Justice of  the Court  and his companion Justices. A private
communication by  a party  to any  Learned  Judge  over  any
matter is  not proper  and may  create embarrassment for the
Court and the Judge concerned. [171 G-H; 172 A]
     In the  present case,  the unfortunate  workers who are
employed and  bonded labourers at a distant place, could not
possibly  in   view  of  their  bondage,  move  this  Court,
following the  procedure laid  down-in  the  Rules  of  this
Court. The  Petitioner which  claims to  be a social welfare
Organization interested  in restoring liberty and dignity to
these unfortunate  bonded  labourers  should  be  considered
competent  to   move  this   Court  by   a  letter  or  like
communication addressed to
89
this Court, to avoid trouble and expenses, as the petitioner
is not  moving  this  Court  for  any  personal  or  private
benefit.
     3:1. Whenever,  however,  there  is  an  allegation  of
violation   of    fundamental   rights,   it   becomes   the
responsibility and  also the  sacred duty  of this  Court to
protect  such   fundamental  rights   guaranteed  under  the
Constitution provided  that this  Court is  satisfied that a
case for  interference by  this Court appears prima facie to
have been  made out. Very often the violation of fundamental
rights  is   not  admitted   or  accepted.   On   a   proper
consideration of  the materials  the Court  has to come to a
conclusion  whether   there  has   been  any   violation  of
fundamental rights  to enable the court to grant appropriate
reliefs in  the matter.  In various  cases, because  of  the
peculiar facts  and circumstances  of  the  case  the  party
approaching this Court for enforcement of fundamental rights
may not  be in  a position to furnish all relevant materialsBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

and necessary  particulars. If,  however, on a consideration
of the  materials placed,  the Court  is  satisfied  that  a
proper probe  into the  matter is  necessary in  the  larger
interest of administration of justice and for enforcement of
fundamental rights  guaranteed, the  Court, in  view of  the
obligations  and   duty  cast  upon  it  of  preserving  and
protecting  fundamental   rights,  may  require  better  and
further materials  to enable  the Court  to take appropriate
action; and  there cannot be anything improper in the proper
exercise of  Court's jurisdiction  under Article  32 of  the
Constitution  to  try  to  secure  the  necessary  materials
through appropriate  agency. The  commission that  the Court
may appoint  or the  investigation that the court may direct
is essentially  for  the  Court's  satisfaction  as  to  the
correctness or  otherwise of  the allegation of violation of
fundamental rights  to enable the Court to decide the Course
to be adopted for doing proper justice to the parties in the
matter of  protection of their fundamental rights. It has to
be borne  in mind  that in  this land  of  ours,  there  are
persons  without   education,  without   means  and  without
opportunities and  they also are entitled to full protection
of  their  rights  or  privileges  which  the  Constitutions
affords.  Living   in  chilled   penury  without   necessary
resources and very often not fully conscious of their rights
guaranteed under  the Constitution,  a very large section of
the people  commonly termed  as the  weaker section  live in
this land.  When this  Court is approached on behalf of this
class of  people for  enforcement of  fundamental rights  of
which they  have been  deprived and  which they  are equally
entitled to  enjoy, it becomes the special responsibility of
the Court  to see that justice is not denied to them and the
disadvantageous position  in which  they are  placed, do not
stand in  the way  of their getting justice from this Court.
[172 D-H; 173 A-B]
     3:3.  The   power  to   appoint  a   commission  or  an
investigation  body   for  making   enquiries  in  terms  of
directions given  by the  Court must  be  considered  to  be
implied and  inherent in  the power that the Court has under
Article  32  for  enforcement,  of  the  fundamental  rights
guaranteed under  the Constitution. This is a power which is
indeed incidental  or ancillary to the power which the Court
is called  upon to exercise in a proceeding under Article 32
of the Constitution. It is entirely in the discretion of the
Court, depending on the facts and circumstances of any case,
to consider  whether any  such power regarding investigation
has to  be exercised  or not.  The Commission that the Court
appoints or  the investigation  that the Court directs while
dealing  with   a  proceeding   under  Article   32   of  the
Constitution is  not a  commission or enquiry under the Code
of Civil  Procedure. Such  power must necessarily be held to
be implied  within the  very wide  powers conferred  on this
Court  under  Article  32  for  enforcement  of  fundamental
rights.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

90
For proper  exercise of  its powers  under Article 32 of the
Constitution and  for due  discharge of  the obligation  and
duty cast  upon this  Court in  the matter of protection and
enforcement of  fundamental rights  which  the  Constitution
guarantees, this  Court has an inherent power to act in such
a manner  as will  enable this Court to discharge its duties
and  obligations   under  Article  32  of  the  Constitution
properly  and   effectively  in   the  larger   interest  of
administration of  justice, and  for  proper  protection  of
Constitution safeguards. [173 C-G]
     4. The litigation of this type particularly in relation
to bonded  labourers is  really not  in nature  an adversary
litigation and  it becomes the duty of the State and also of
the appropriate authorities to offer its best cooperation to
see that  this evil practice which has been declared illegal
is ended  at the earliest. The existence of bonded labour in
the Court  is an  unfortunate fact.  Whenever  there  is  an
allegation  of   the  existence  of  bonded  labour  in  any
particular State,  the State  instead of seeking to come out
with a  case of  denial of  such existence on the basis of a
feeling that the existence of bonded labour in the State may
cast a  slur or  stigma  on  its  administrative  machinery,
should cause  effective enquiries to be made into the matter
and if the matter is pending in this Court, should cooperate
with this  Court to  see that death-knell is sounded on this
illegal system  which constitutes  a veritable social menace
and stands  in the way of healthy development of the nation.
[174 A-C]
PER CONTRA :
     5. The  grievance of denial of other just rights to the
workmen and  the reliefs  claimed for giving the workmen the
benefits  to  which  they  may  be  entitled  under  various
legislations enacted  for their  welfare are more or less in
the nature  of consequential  reliefs incidental to the main
relief of freedom from bonded and forced labour to which the
workmen are  rejected. In the facts and circumstances of the
case, it  appears that the provisions of inter-State Migrant
Workmen (Regulation of Employment and Conditions of Service)
Act, 1979  are not  applicable and therefore do not fall for
any adjudication. [174 F-G]
JUDGMENT:
ORIGINAL JURISDICTION: Writ Petition No. 2135 of 1982. Under Article 32 of the Constitution.
Govind Mukhoty, S.K. Bhattacharya and N.R. Chaudhary for the Petitioner.
M.N. Phadke, K.B. Rohtagi and S.K. Dhingra for the Respondent Nos. 4,5,7, 8 & 9.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

K.B. Rohtagi and S.I. Dhingra for the Respondent No. 13 S.K. Verma for the Respondent No. 6.
Abdul Khadar Sr. Advocate and Miss. A. Subhashni for the respondent.
The following Judgments were delivered-
BHAGWATI, J. The petitioner is an organisation dedicated to the cause of release of bonded
labourers in the country. The system of bonded labour has been prevalent in various parts of the
country since long prior to the attainment of political freedom and it constitutes an ugly and
shameful feature of our national life. This system based on exploitation by a few socially and
economically powerful persons trading on the misery and suffering of large numbers of men and
holding them in bondage is a relic of a feudal hierarchical society which hypocritically proclaims the
divinity of men but treats large masses of people belonging to the lower rungs of the social ladder or
economically impoverished segments of society as dirt and chattel. This system under which one
person can be bonded to provide labour to another for years and years until an alleged debt is
supposed to be wiped out which never seems to happen during the life time of the bonded labourer,
is totally incompatible with the new egalitarian socioeconomic order which we have promised to
build and it is not only an affront to basic human dignity but also constitutes gross and revolting
violation of constitutional values. The appalling conditions in which bonded labourers live, not as
humans but as serfs, recall to the mind the following lines from "Man with the Hoe" which almost
seem to have been written with reference to this neglected and forlorn species of Indian humanity:
"Bowed by the weight of centuries he leans Upon his hoe and gazes on the ground
The emptiness of ages on his face, And on his back the burden of the world, They are
non-beings, exiles of civilization, living a life worst than that of animals, for the
animals are at least free to roam about as they like and they can plunder or grab food
whenever they are hungry but these out castes of society are held in bondage, robbed
of their freedom and they are consigned to an existence where they have to live either
in hovels or under the open sky and be satisfied with whatever little unwholesome
food they can manage to get inadequate though it be to fill their hungry stomachs.
Not having any choice, they are driven by poverty and hunger into a life of bondage a
dark bottomless pit from which, in a cruel exploitative society, they cannot hope to be
rescued.
This pernicious practice of bonded labour existed in many States and obviously with
the ushering in of independence it could not be allowed to continue to blight the
national life any longer and hence, when we framed our Constitution, we enacted
Article 23 of the Constitution which prohibits "traffic in human beings and beggar
and other similar forms of forced labour" practised by any one. The system of bonded
labour therefore stood prohibited by Article 23 and there could have been no more
solemn and effective prohibition than the one enacted in the Constitution in Article
23. But, it appears that though the Constitution was enacted as far back as 26th
January, 1950 and many years passed since then, no serious effort was made to give
effect to Article 23 and to stamp out the shocking practice of to bonded labour. It wasBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

only in 1976 that Parliament enacted the Bonded Labour System (Abolition) Act,
1976 providing for the abolition of bonded labour system with a view to preventing
the economic and physical exploitation of the weaker sections of the people. But,
unfortunately, as subsequent events have shown and that is borne out also by the
Report made by the Centre for Rural Development Administration, Indian Institute
of Public Administration to the Ministry of Labour Government of India on
"Rehabilitation of Bonded Labour in Monghyr District, Bihar", the Report made by
the Public Policy and Planning Division of the Indian Institute of Public
Administration to the Ministry of Labour, Government of India on "Evaluation Study
of Bonded Labour Rehabilitation Scheme In Tehri Garhwal, U.P.", the Report of
Laxmi Dhar Misra, the Director-General (Labour Welfare) of the Government of
India based on On the Spot Studies Regarding Identification, Release of Bonded
Labourers and Rehabilitation of Freed Labourers in Uttar Pradesh, Madhya Pradesh,
Madhya Pradesh, Karnataka, Orissa, Bihar, Rajasthan, Tamilnadu and Kerala and the
Report of the National Seminar on "Indentification and Rehabilitation of Bonded
Labour" held from 7th to 9th February, 1983 that the pernicious practice of bonded
labour has not yet been totally eradicated from the national scene and that it
continues to disfigure the social and economic life of the country at certain places.
There are still a number of bonded labourers in various parts of the country and
significantly, as pointed out in the Report of the National Seminar on "Identification
and Rehabilitation of Bonded Labour" a large number of them belong to Scheduled
Castes and Scheduled Tribes account for the next largest number while the few who
are not from Scheduled Castes or Scheduled Tribes are generally landless agricultural
labourers. It is absolutely essential we would unhesitatingly declare that it is a
constitutional imperative-that the bonded labourers must be identified and released
from the shackles of bondage so that they can assimilate themselves in the main
stream of civilised human society and realise the dignity, beauty and worth of human
existence. The process of identification and release of bonded labourers is a process
of discovery and transformation of non-beings into human-beings and what it
involves is eloquently described in the beautiful lines of Rabindra Nath Tagore in
"Kadi and Komal"
Into the mouths of these Dumb, pale and meak We have to infuse the language of the soul.
Into the hearts of these Weary and worn, dry and forlorn We have to minstrel the language of
humanity.' This Process of discovery and transformation poses a serious problem since the social
and economic milieu in which it has to be accomplished is dominated by elements hositle to it. But
this problem has to be solved if we want to emancipate those who are living in bondage and serfdom
and make them equal participants in the fruits of freedom and liberty. It is a problem which needs
urgent attention of the Government of India and the State Governments and when the Directive
Principles of State Policy have obligated the Central and the State Governments to take steps and
adopt measures for the purpose of ensuring social justice to the have-notes and the handicapped, it
is not right on the part of the concerned governments to shut their eyes to the inhuman exploitation
to which the bonded labourers are subjected. It is not uncommon to find that the administration inBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

some States is not willing to admit the existence of bonded labour, even though it exists in their
territory and there is incontrovertible evidence that it does so exist. We fail to see why the
administration should feel shy in admitting the existence of bonded labour, because it is not the
existence of bonded labour that is a slur on the administration but its failure to take note of it and to
take all necessary steps for the purpose of putting an end to the bonded labour system by quickly
identifying, releasing and permanently rehabilitating bonded labourers. What is needed is
determination, dynamism and a sense of social commitment of the part of the administration to free
bonded labourers and rehabilitate them and wipe out this ugly inhuman practice which is a blot on
our national life. What happened recently in the Ranga Reddy District of Andrha Pradesh as a result
of the initiative taken by this Court in Writ Petitions Nos. 1574 of 1982 and 54 of 1983 shows clearly
that if the political and administrative apparatus has a sense of commitment to the constitutional
values and is determined to take action for identifying, releasing and rehabilitating bonded
labourers despite pressures and pulls from different quarters, much can be done for securing
emancipation and rehabilitation of bonded labourers. The District Administration of Ranga Reddy
District could in less than six months release over 3000 bonded labourers from the clutches of
contractors in stone quarries in Ranga Reddy District and send them back to their homes with
tickets and pocket expenses. It is therefore essential that whichever be the State Government it
should, where there is bonded labour, admit the existence of such bonded labour and make all
possible efforts to eradicate it. By doing so, it will not only be performing a humanitarian function
but also discharging a constitutional obligation and strengthening the foundations of participatory
democracy in the country.
We also find that in some cases the State Governments in order to shirk their obligation, take shelter
under the plea that there may be some forced labour in their State but that is not bonded labour. We
shall have occasion to deal with this plea a little later when we refer to the definition of 'bonded
labour' given in the Bonded Labour System (Abolition) Act, 1976 which at first blush appears to be a
narrow definition limited only to a situation where a debtor is forced to provide labour to a creditor.
The State of Haryana has in the present case tried to quibble with this definition of 'bonded labour'
and its argument has been that these labourers may be providing forced labour but they are not
bonded labourers within the meaning of the Bonded Labour System (Abolition) Act, 1976 and they
may therefore be freed by the Court if it so pleases but the State of Haryana cannot be compelled to
rehabilitate them. We are constrained to observe that this argument, quite apart from its invalidity,
ill-behoves a State Government which is committed to the cause of socialism and claims to be
striving to ensure social justice to the vulnerable sections of the community. But we do not wish to
anitcipate the discussion in regard to this argument and at the present stage we content ourselves by
merely observing that it is unfortunate that any State Government should take up the plea that
persons who are forced to provided labour may be forced labourers but unless it is shown by them
by proper evidence tested by cross-examination that they are forced to provide labour against a
bonded debt, they cannot be said to be bonded labourers and the State Government cannot be held
to be under any obligation to rehabilitate them.
The petitioner made a survey of some of the stone quarries in Faridabad district near the city of
Delhi and found that there were a large number of labourers from Maharashtra, Madhya Pradesh,
Uttar Pradesh and Rajasthan who were working in these stone quarries under "inhuman andBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

intolerable conditions" and many of whom were bonded labourers. The petitioner therefore
addressed a letter to one of us on 25th February, 1982 pointing out that in the mines of Shri S.L.
Sharma, Gurukula Indra Prastha, Post Amar Nagar, Faridabad, District, a large number of labourers
were languishing under abject conditions of bondage for last about ten years, and the petitioner gave
the names of 11 bonded labourers who were from village Asarha, Barmer district of Rajasthan, 7
bonded labourers who were from village Bharol, district Jhansi of Madhya Pradesh and 23 bonded
labourers who were from village Barodia, Bhanger, Tehsil Khurai, district Sagar, M.P. The petitioner
pointed out that there were "yet another 14 bonded labourers from Lalitpur in U.P.". The petitioner
also annexed to its letter, statements in original bearing the thumb marks or signatures as the case
may be of these bonded labourers referred to in the letter. The petitioner pointed out in the letter
that the labourers working in these stone quarries were living under the most inhuman conditions
and their pitiable lot was described by the petitioner in the following words:
"Besides these cases of bonded labour, there are innumerable cases of fatal and
serious injuries caused due to accidents' while working in the mines, while
dynamiting the rocks or while crushing the stones. The stone-dust pollution near the
stone crushers is so various that many a valuable lives are lost due to tuberculosis
while others are reduced to mere skeletons because of T.B. and other diseases. The
workers are not provided with any medical care, what to speak of compensating the
poor worker for injury or for death. No cases are registered against the mine owners
or the lessees for violation of safety rules under Mines Act. We are enclosing herewith
the statements of about 75 workers who have suffered or are suffering continuously
due to non-implementation of the rules by the Central Government or by Haryana
Government or by the employers.
Almost 99% of the workers are migrant from drought prone areas of Rajasthan,
Madhya Pradesh, Andhra Pradesh, Orissa, Maharashtra and Bihar. But if there is any
one place where the Central legislation of Inter State Migrant Workmens Act 1979 is
being most flagrantly violated it is here in these mines, without any residential
accommodation, with the name-not even a thatched roof to fend against the icy winds
and winter rain or against the scorching heat in midsummer, with scanty clothing,
with very impure and polluted drinking water accumulated during rainy season in the
clitches, with absolutely no facilities for schooling or childcare, braving all the
hazards of nature and pollution and ill-treatment, these thousands of sons and
daughters of Mother India epitomise the "Wretched of the Earth".
On top of all these forms of exploitation is the totally illegal system of "Thekedars", middlemen who
extract 30% of the poor miner's wages as their ill gotten commission (Rs. 20 out of Rs. 60, wages for
per truck load of stone ballast). The trucks are invariably oversigned in some cases they doubt the
prescribed size of 150 Sq. feet but payment remains the same. The hills are dotted with liquor
vends-legal and illegal. Murders and molestation of women is very common."
The petitioner also set out the various provisions of the Constitution and the statutes which were not
being implemented or observed in regard to the labourers working in these stone quarries. TheBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

petitioner in the end prayed that a writ be issued for proper implementation of these provisions of
the Constitution and statutes with a view to ending the misery, suffering and helplessness of "these
victims of most inhuman exploitation".
The letter dated 25th February 1982 addressed by the petitioner was treated as a writ petition and
by an order dated 26th February 1982 this Court issued notice on the writ petition and appointed
two advocates, namely, M/s. Ashok Srivastava and Ashok Panda as commissioners to visit the stone
quarries of Shri S.L. Sharma in Godhokhor (Anangpur) and Lakkarpur in Faridabad district and to
interview each of the persons whose names were mentioned in the letter of the petitioner as also a
cross section of the other workers with a view to finding out whether they are willingly working in
these stone quarries and also to inquire about the conditions in which they are working. M/s. Ashok
Srivastava and Ashok Panda were directed to visit these stone, quarries on 27th and 28th February
1982 and to make a report to this Court on or before 2nd March 1982. Pursuant to this order made
by us, M/s. Ashok Srivastava and Ashok Panda visited the stone quarries of S.L. Sharma in
Godhokhor and Lakkarpur and carried out the assignment entrusted to them and submitted a
report to this Court on 2nd March 1982. The Report pointed out inter alia that in the stone quarries
of S.L. Sharma at Godhakhpur, "many stone crushing machines were operating with the result that
the whole atmosphere was full of dust and it was difficult even to breathe". The report then referred
to the statements of various workers interviewed by M/s. Ashok Srivastava and Ashok Panda and
according to the statements given by some of them, namely, Lalu Ram, Dalla Ram, Thakur Lal,
Budh Ram, Harda, Mahadev, Smt. Shibban, Hardev, Anam, Punnu, Ghanshyam, Randhir and Mute,
they were not allowed to leave the stone quarries and were providing forced labour and they did not
have even pure water to drink but were compelled in most cases to drink dirty water from a nallah
and were living in Jhuggies with stones piled one upon the other as walls and straw covering at the
top, which did not afford any protection against sun and rain and which were so low that a person
could hardly stand inside them. The statements of these workers showed that a few of them were
suffering from tuberculosis and even when injuries were caused due to accidents arising in the
course of employment, no compensation was being paid to them and there were no facilities for
medical treatment or schooling for children. The Report proceeded to state that M/s. Ashok
Srivastava and Ashok Panda then visited mine no. 8 in Godhokhor stone quarries and here they
found that the condition of the jhuggies was much worse in such as the jhuggies were made only of
straw and most of the people living in jhuggies had no clothes to wear and were shivering from cold
and even the small children were moving about without any proper clothing. M/s. Ashok Srivastava
and Ashok Panda found that none of the inmates of the jhuggies had any blanket or woolen clothes
and they did not even have any mat on which they could sleep. The statements of Phool Chand,
Babu Lal, Bhoolu, Karaya, Ram Bahadur and Sallu also showed that all these workers were bonded
labourers who were not allowed to leave the stone quarries and one of them, namely Sallu was
seriously injured on his left leg only a day before the visit of M/s. Ashok Srivastava and Ashok Panda
but be did not hope to get any compensation "because here no one gets any compensation for any
injury". Most of the workers interviewed by M/s. Ashok Srivastava and Ashok Panda stated that they
got very little by way of wages from the mine lessees or owners of stone crushers since they had to
purchase explosives with their own moneys and they had to incur other expenses which, according
to Dr. Patwardhan's report to which we shall refer hereafter, included 50 per cent of the expenses of
drilling holes. M/s. Ashok Srivastava and Ashok Panda also pointed out in the Report that theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

following persons working in the Godhokhor stone quarries claimed that they were bonded
labourers:
(1) Chand Bahadur son of Hastbir (2) Lal Bahadur son of Umbar Bahadur (3)
Chhotey Lal son of Jarau (4) Harak Bahadur son of Jeet Bahadur (5) Gopal Bahadur
son of Jhabu Singh (6) Roop Singh son of Govinda (7) Medh Bahadur son of Aspteir
(8) Jiddey Bahadur son of Nunbahadur (9) Phool Bahadur son of Ram Bahadur (10)
Heera Bahadur son of Balbahadur (11) Veer Bahadur son of Chhalvir (12) Nain Singh
son of Lal Bahadur (13) Lal Bahadur son of Gang Bahadur (14) Ganesh son of Gang
Bahadur (15) Amber Bahadur son of Sadhu Bahadur (16) Hira Lal son of Atbahadur
(17) Kamar Bahadur (18) Jagadh Bahadur son of Top Bahadur (19) Gajender Bahadur
son of Shyam Lal (20) Ganga Ram son of Lal Bahadur (21) Nar Bahadur and (22)
Sant Bahadur son of Bhag Bahadur.
So far as the workers working in Lakkarpur stone quarries were concerned, the report of M/s. Ashok
Srivastava and Ashok Panda stated that out of about 250 persons living in straw jhuggies 100
persons hailed from Bilaspur while 150 persons belonged to Allahabad and according to the report,
100 persons coming from Bilaspur stated that they were forcibly kept by the contractor and they
were not allowed to move out of their place and they were bonded labourers. M/s. Ashok Srivastava
and Ashok Panda described in the Report the pitiable condition in which these workers were living
in straw jhuggies without any protection against sun and rain and with drinking water available only
from the barsati nallah. The Report pointed out that wile M/s. Ashok Srivastava and Ashok Panda
were interviewing the workers in the Lakkarpur stone quarry it started raining heavily and
thereupon they took shelter in one of the jhuggies "but inside the jhuggi it was not safe, as water was
pouring inside" and they were completely drenched inside the jhuggi. The Report also stated that,
according to these workers, there were no medical facilities available and even where workers were
injured they did not get any medical aid. The Report ended by cbserving that these workmen
"presented a picture of helplessness, poverty and extreme exploitation at the hands of moneyed
people" and they were found "leading a most miserable life and perhaps beast and animal could be
leading more comfortable life than these helpless labourers".
Thereafter, the writ petition came up for hearing on 5th March 1982 along with another writ petition
filed by the present petitioner for release of some other bonded labourers and on this day the Court
made an order directing that the copies of the Report of M/s. Ashok Srivastava and Ashok Panda
should be supplied to all the minelesses and stone crushers who are respondents to the writ
petitions so that they may have an opportunity to file their reply to the facts found in the Report.
The Court also appointed Dr. Patwardhan of Indian Institute of Technology to carry out a socio-legal
investigation in the following terms:
"It is necessary that a socio-legal investigation should be carried out for the purpose
of determining what are the conditions prevailing in the various quarries in
Faridabad District and whether there are any workmen in those quarries against their
will or without their consent and what are the conditions in which they are living and
whether any of the provisions of the Bonded Labour System (Abolition) Act andBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Inter- State Migrant Workmen (Regulation of Employment & Conditions of Service)
Act is being violated. We may make it clear that when we are directing a socio-legal
investigation of these matters it is not in a spirit to criticise the State Government or
any of its officers but with a view to find out the correctness of the state of affairs so
that the State Government and its officers could take necessary steps for remedying
the situation if a state of affairs exists which is contrary to the provisions of law and
the basic human norms. The Court can take action only after the socio- legal
investigation is carried out by some responsible person and a copy of the report of the
socio-legal investigation is made available to the parties. We would, therefore,
request Dr. Patwardhan of I.I.T. to be good enough to carry out a socio-legal
investigation into the aforesaid matters in the quarries in Faridabad District a list of
which will be supplied by Mr. Mukhoty on behalf of the petitioners to Dr. Patwardhan
within' ten days from today after giving a copy to Mr. K.G. Bhagat, learned Counsel
appearing for the State of Haryana. Dr. Patwardhan is requested to carry out
socio-legal investigation with a view to putting forward a scheme for improving the
living conditions for the workers working in the stone quarries and after the scheme
is submitted to us we propose to hear the parties on the scheme with a view to
evolving a final scheme with the assistance of the State of Haryana for the purpose of
economic regeneration of these workmen. The Court permitted Dr. Patwardhan to
take the assistance of any person other than the parties to the writ petition in order to
help him in his task and at the suggestion of the Court, the State of Haryana agreed to
deposit a sum of Rs. 1500 to meet the expenses of Dr. Patwardhan in carrying out the
socio-legal investigation. The Court also recorded in its order that when it was
pointed out in the Report of M/s. Ashok Srivastava and Ashok Panda that the
workers in the stone quarries did not have any pure drinking water but were using
dirty water from the nallah for drinking purposes, Mr. K.G. Bhagat learned
Additional Solicitor General appearing on behalf of the State of Haryana fairly stated
that "though it may not be strictly the obligation of the State Government, the State
Government will take necessary measures for providing drinking facilities to the
workmen in the stone quarries". The Court also directed that the workmen whose
names were set out in the writ petition and in the Report of M/s. Ashok Srivastava
and Ashok Panda and particularly in regard to whom a separate statement had been
filed in Court on behalf of the petitioner, would be free to go wherever they liked and
they should not be restrained from doing so by any one and "if they go to their
respective villages, the district magistrates having jurisdiction over those villages"
shall "take steps or measures to the extent possible for rehabilitating them."
Pursuant to this order made by the Court, the State of Haryana deposited a sum of Rs. 1500 in Court
to meet the expenses of the socio-legal investigation and Dr. Patwardhan embarked upon his task
with the assistance of Mr. Krishan Mahajan, the legal correspondent of the Hindustan Times. It took
some time for Dr. Patwardhan to complete his assignment and prepare his report but having regard
to the immensity of the task, the time within which Dr. Patwardan finished the inquiry and
submitted his report was remarkably short. We shall have occasion to refer to this Report a little
latter when we deal with the arguments advanced on behalf of the parties, but we may point out atBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

this stage that the report of Dr. Patwardhan a comprehensive, well documented socio- legal study of
the conditions in which the workmen engaged in stone quarries and stone crushers live and work
and it has made various constructive suggestions and recommendations for the purpose of
improving the living conditions of these workmen. We are indeed grateful to Dr. Patwardhan for
carrying out this massive assignment so efficiently and in such a short time. Dr. Patwardhan has
submitted a statement of the expenses incurred by him in carrying out this socio-legal investigation
and this statement shows that he has incurred a total expense of Rs. 2078 which after withdrawal of
the amount of Rs.
1500 deposited by the State of Haryana, leaves a balance of Rs. 578 to be reimbursed to Dr.
Patwardhan. We are of the view that Dr. Patwardhan should also be paid a small honorarium of Rs.
1000. We would therefore direct the State of Haryana to deposit a sum of Rs. 1578 with the Registry
of this Court within 4 weeks from today with liberty to Dr. Patwardhan to withdraw the same.
Though it was stated by Shri K.G. Bhagat on behalf of the State of Haryana that the State
Government will take necessary measures for providing drinking facilities to the workmen in the
stone quarries referred to in the writ petition and in the report of M/s. Ashok Srivastava and Ashok
Panda, it appears that either no such measures were taken on behalf of the State Government or
even if they were taken, they were short lived. The result was that the workmen working in most of
these stone quarries had to remain without pure drinking water and they had to continue "to quench
their thirst by drinking dirty and filthy water". Whether it is the obligation of the State Government
to provide pure drinking water and if so what measures should be directed to be taken by the State
Government in that behalf are matters which we shall presently consider. These are matters of some
importance because there can be no doubt that pure drinking water is absolutely essential to the
health and well-being of the workmen and some authority has to be responsible for providing it.
Before we proceed to consider the merits of the controversy between the parties in all its various
aspects it will be convenient at this stage to dispose of a few preliminary objections urged on behalf
of the respondents. The learned Additional Solicitor General appearing on behalf of the State of
Harynana as also Mr. Phadke on behalf of one of the mine lessees contended that even if what is
alleged by the petitioner in his letter which has been treated as a writ petition, is true, it cannot
support a writ petition under Article 32 of the Constitution, because no fundamental right of the
petitioner or of the workmen on whose behalf the writ petition has been filed, can be said to have
been infringed. This contention is, in our opinion, futile and it is indeed surprising that the State
Government should have raised it in answer to the writ petition. We can appreciate the anxiety of
the mine lessees to resist the writ petition on any ground available to them, be it hyper-technical or
even frivolous, but we find it incomprehensible that the State Government should urge such a
preliminary objection with a view to stifling at the thresh-hold an inquiry by the Court as to whether
the workmen are living in bondage and under inhuman conditions. We should have thought that if
any citizen brings before the Court a complaint that a large number of peasants or workers are
bonded serfs or are being subjected to exploitation by a few mine lessees or contractors or
employers or are being denied the benefits of social welfare laws, the State Government, which is,
under our constitutional scheme, charged with the mission of bringing about a new socioeconomic
order where there will be social and economic justice for every one and equality of status andBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

opportunity for all, would welcome an inquiry by the court, so that if it is found that there are in fact
bonded labourers or even if the workers are not bonded in the strict sense of the term as defined in
the Bonded Labour System (Abolition) Act 1976 but they are made to provide forced labour or are
consigned to a life of utter deprivation and degradation such a situation can be set right by the State
Government. Even if the State Government is on its own inquiry satisfied that the workmen are not
bonded and are not compelled to provide forced labour and are living and working in decent
conditions with all the basic necessities of life provided to them, the State Government should not
baulk an inquiry by the court when a complaint is brought by a citizen, but it should be anxious to
satisfy the court and through the court the people of the country, that it is discharging its
constitutional obligation fairly and adequately and the workmen are being ensured social and
economic justice. We have on more occasions than one said that public interest litigation is not in
the nature of adversary litigation but it is a challenge and an opportunity to the government and its
officers to make basic human rights meaningful to the deprived and vulnerable sections of the
community and to assure them social and economic justice which is the signature tune of our
Constitution. The Government and its officers must welcome public interest litigation, because it
would provide them an occasion to examine whether the poor and the down-trodden are getting
their social and economic entitlements or whether they are continuing to ermine victims of
deception and exploitation at the hands of strong and powerful sections of the community and
whether social and economic justice has become a meaningful reality for them or it has remained
merely a teasing illusion and a promise of unreality, so that in case a the complaint in the public
interest litigation is found to be true, they can in discharge of their constitutional obligation root out
exploitation and injustice and ensure to the weaker sections their rights and entitlements. When the
Court entertains public interest litigation, it does not do so in a cavilling spirit or in a
confrontational mood or with a view to tilting at executive authority or seeking to usurp it but its
attempt is only to ensure observance of social and economic rescue programmes, legislative as well
as executive, framed for the benefit of the have-nots and the handicapped and to protect them
against violation of their basic human rights, which is also the constitutional obligation of the
executive. The Court is thus merely assisting in the realisation of the constitutional objectives.
Moreover, when a complaint is made on behalf of workmen that they are held in bondage and are
working and living in miserable conditions without any proper or adequate shelter over their heads,
without any protection against sun and rain, without two square meals per day and with only dirty
water from a nullah to drink, it is difficult to appreciate how such a complaint can be thrown out on
the ground that it is not violative of the fundamental right of the workmen. It is the fundamental
right of every one in this Country, assured under the interpretation given to Article 21 by this Court
in Francis Mullen's case, to live with human dignity, free from exploitation. This right to live with
human dignity, enshrined in Article 21 derives its life breath from the Directive Principles of State
Policy and particularly clauses (e) and (f) of Article 39 and Article 41 and 42 and at the least,
therefore, it must include protection of the health and strength of workers men and women, and of
the tender age of children against abuse, opportunities and facilities for children to develop in
healthy manner and in conditions of freedom and dignity, educational facilities, just and humane
conditions of work and maternity relief. These are the minimum requirements which must exist in
order to enable a person to live with human dignity and no State neither the Central Government
nor any State Government-has the right to take any action which will deprive a person of theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

enjoyment of these basic essentials. Since the Directive Principles of State Policy contained in
clauses (e) and (f) of Article 39, Article 41 and 42 are not enforceable in a court of law, it may not be
possible to compel the State through the judicial process to make provision by statutory enactment
or executive fiat for ensuring these basic essentials which go to make up a life of human dignity but
where legislation is already enacted by the State providing these basic requirements to the workmen
and thus investing their right to live with basic human dignity, with concrete reality and content, the
State can certainly be obligated to ensure observance of such legislation for inaction on the part of
the State in securing implementation of such legislation would amount to denial of the right to live
with human dignity enshrined in Article 21, more so in the context of Article 256 which provides
that, the executive power of every State shall be so exercised as to ensure compliance with the laws
made by Parliament and any existing laws which apply in that State. We have already pointed out in
Asiad Construction Worker(1) case that the State is under a constitutional obligation to see that
there is no violation of the fundamental right of any person, particularly when he belongs to the
weaker sections of the community and is unable to wage a legal battle against a strong and powerful
opponent who is exploiting him. The Central Government is therefore bound to ensure observance
of various social welfare and labour laws enacted by Parliament for the purpose of securing to the
workmen a life of basic human dignity in compliance with the Directive Principles of State Policy. It
must also follow as a necessary corollary that the State of Haryana in which the stone quarries are
vested by reason of Haryana Minerals (Vesting of Rights) Act 1973 and which is therefore the owner
of the mines cannot while giving its mines for stone quarrying operations, permit workmen to be
denied the benefit of various social welfare and labour laws enacted with a view to enabling them to
live a life of human dignity. The State of Haryana must therefore ensure that the mine-lessees or
contractors, to whom it is giving its mines for stone quarrying operations, observe various social
welfare and labour laws enacted for the benefit of the workmen. This is a constitutional obligation
which can be enforced against the Central Government and the State of Haryana by a writ petition
under Article 32 of the Constitution.
The next preliminary objection urged by the learned Additional Solicitor General on behalf of the
State of Haryana and Mr. Phadke on behalf of one of the mine-lessees was that the court had no
power to appoint either Mr. Ashok Srivastava and Mr. Ashok Panda or Mr. Patwardhan as
commissioners and the Reports made by them had no evidentiary value since what was stated in the
Reports was based only on ex-parte statements which had not been tested by cross-examination.
The learned Additional Solicitor General as also Mr. Phadke relied on Order XLVI of the Supreme
Court Rules 1966 which, as its heading shows, deals with commissions and contended that since the
commissions issued by the court in the present case did not fall within the terms of any of the
provisions of Order XLVI, they were outside the scope of the power of the court and the court was
not entitled to place any reliance on their reports for the purpose of adjudicating the issues arising
in the writ petition. This argument, plausible though it may seem at first sight, is in our opinion not
well founded and must be rejected. It is based upon a total misconception of the true nature of a
proceeding under Article 32 of the Constitution. Article 32 is so frequently used by lawyers and
Judges for enforcement of fundamental rights without any preliminary objection against its
invocation being raised on behalf of the State, that we have rarely any occasion to examine its
language and consider how large is the width and amplitude of its dimension and range. We are so
much accustomed to the concepts of Anglo-Saxon jurisprudence which require every legalBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

proceeding including a proceeding for a high prerogative writ to be cast in a rigid or definitive mould
and insist on observance of certain well settled rules of procedure, that we implicitly assume that the
same sophisticated procedural rules must also govern a proceeding under Article 32 and the
Supreme Court cannot permit itself to be freed from the shackles of these rules even if that be
necessary for enforcement of a fundamental right. It was on the basis of this impression fostered by
long association which the Anglo-Saxon system of administration of justice that for a number of
years this court had taken the view that it is only a person whose fundamental right is violated who
can approach the Supreme Court for relief under Article 32 or in other words, he must have a cause
of action for enforcement of his fundamental right. It was only in the years 1981 in the Judges
Appointment and Transfer Case(1) that this Court for the first time took the view that where a
person or class of persons to whom legal injury is caused by reason of violation of a fundamental
right is unable to approach the court for judicial redress on account of poverty or disability or
socially or economically disadvantaged position, any member of the public acting bona fide can
move the court for relief under Article 32 and a fortiorari, also under Article 226, so that the
fundamental rights may become meaningful not only for the rich and the well-to-do who have the
means to approach the court but also for the large masses of people who are living a life of want and
destitution and who are by reason of lack of awareness, assertiveness and resources unable to seek
judicial redress. This view which we took in the Judges Appointment and Transfer Case is clearly
within the terms of Article 32 if only we look at the language of this Article uninfluenced and
uninhibited by any pre-conceptions and prejudices or any pre-conceived notions. Article 32 in so far
it is material is in the following terms:
"Art. 32 (1): The right to move the Supreme Court by appropriate proceedings for the
enforcement of the rights conferred by this Part is guaranteed.
(2): The Supreme Court shall have power to issue directions or orders or writs
including writ in the nature of habeas corpus, mandamus, prohibition, quo warranto
and certiorari, whichever may be appropriate, for the enforcement of any of the rights
conferred by this Part.
While interpreting Article 32, it must be borne in mind that our approach must be
guided not by any verbal or formalistic canons of construction but by the paramount
object and purpose for which this Article has been enacted as a Fundamental Right in
the Constitution and its interpretation must receive illumination from the trinity of
provisions which permeate and energies the entire Constitution namely, the
Preamble, the Fundamental Rights and the Directive Principles of State Policy.
Clause (1) of Article 32 confers the right to move the Supreme Court foe enforcement
of any of the fundamental rights, but it does not say as to who shall have this right to
move the Supreme Court nor does it say by what proceedings the Supreme Court may
be so moved. There is no limitation in the words of Clause (1) of Article 32 that the
fundamental right which is sought to be enforced by moving the Supreme Court
should be one belonging to the person who moves the Supreme Court nor does it say
that the Supreme Court should be moved only by a particular kind of proceeding. It is
clear on the plain language of clause (1) of Article 32 that whenever there is aBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

violation of a fundamental right any one can move the Supreme Court for
enforcement of such fundamental right. Of course, the Court would not, in exercise of
its discretion, intervene at the instance of a meddlesome interloper or busy body and
would ordinarily insist that only a person whose fundamental right is violated should
be allowed to activise the court, but there is no fetter upon the power of the court to
entertain a proceeding initiated by any person other than the one whose fundamental
right is violated, though the court would not ordinarily entertain such a proceeding,
since the person whose fundamental right is violated can always approach the court
and if he does not wish to seek judicial redress by moving the court, why should some
one else be allowed to do so on his behalf. This reasoning however breaks down when
we have the case of a person or class of persons whose fundamental right is violated
but who cannot have resort to the court on account of their poverty or disability or
socially or economically disadvantaged position and in such a case, therefore, the
court can and must allow any member of the public acting bona fide to espouse the
cause of such person or class of persons and move the court for judicial enforcement
of the fundamental right of such person or class of persons. This does not violate, in
the slightest measure, the language of the constitutional provision enacted in clause
(1) of Article 32.
Then again clause (1) of Article 32 says that the Supreme Court can be moved for enforcement of a
fundamental right by any 'appropriate' proceeding. There is no limitation in regard to the kind of
proceeding envisaged in clause (1) of Article 32 except that the proceeding must be "appropriate"
and this requirement of appropriateness must be judged in the light of the purpose for which the
proceeding is to be taken, namely, enforcement of a fundamental right. The Constitution makers
deliberately did not lay down any particular form of proceeding for enforcement of a fundamental
right nor did they stipulate that such proceeding should conform to any rigid pattern or straight
jacket formula as, for example, in England, because they knew that in a country like India where
there is so much of poverty, ignorance, illiteracy, deprivation and exploitation, any insistence on a
rigid formula of proceeding for enforcement of a fundamental right would become self-defeating
because it would place enforcement of fundamental rights beyond the reach of the common man
and the entire remedy for enforcement of fundamental rights which the Constitution makers
regarded as so precious and invaluable that they elevated it to the status of a fundamental right,
would become a mere rope of sand so far as the large masses of the people in this country are
concerned. The Constitution makers therefore advisedly provided in clause (1) of Article 32 that the
Supreme Court may be moved by any 'appropriate' proceeding, 'appropriate' not in terms of any
particular form but 'appropriate' with reference to the purpose of the proceeding. That is the reason
why it was held by this Court in the Judges Appointment and Transfer Case (supra) that where a
member of the public acting bona fide moves the Court for enforcement of a fundamental right on
behalf of a person or class of persons who on account of poverty or disability or socially or
economically disadvantaged position cannot approach the court for relief, such member of the
public may move the court even by just writing a letter, because it would not be right or fair to
expect a person acting pro bono publico to incur expenses out of his own pocket for going to a
lawyer and preparing a regular writ petition for being filed in court for enforcement of the
fundamental right of the poor and deprived sections of the community and in such a case, a letterBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

addressed by him can legitimately be regarded as an "appropriate" proceeding.
But the question then arises as to what is the power which may be exercised by the Supreme Court
when it is moved by an "appropriate" proceeding for enforcement of a fundamental right. The only
provision made by the Constitution makers in this behalf is to be found in clause (2) of Article 32
which confers power on the Supreme Court "to issue directions or orders or writs including writs in
the nature of habeas corpus, mandamus, prohibition, quo warranto and certiorari, which-ever may
be appropriate, for enforcement of any of the fundamental rights. It will be seen that the power
conferred by clause (2) of Article 32 is in the widest terms. It is not confined to issuing the high
prerogative writs of habeas corpus, mandamus, prohibition, certiorari and quo quarranto, which are
hedged in by strict conditions differing from one writ to another and which to quote the words
spoken by Lord Atkin in United Australia Limited v. Barclays Bank Ltd. in another context often
"stand in the path of justice Clanking their mediavel chains". But it is much wider and includes
within its matrix, power to issue any directions, orders or writs which may be appropriate for
enforcement of the fundamental right in question and this is made amply clear by the inclusive
clause which refers to in the nature of habeas corpus, mandamus, prohibition, quo warranto and
certiorari. It is not only the high prerogative writs of mandamus, habeas corpus, prohibition, quo
warranto and certiorari which can be issued by the Supreme Court but also writs in the nature of
these high prerogative writs and therefore even if the conditions for issue of any of these high
prerogative writs are not fulfilled, the Supreme Court would not be constrained to fold its hands in
despair and plead its inability to help the citizen who has come before it for judicial redress, but
would have power to issue any direction, order or writ including a writ in the nature of any high
prerogative writ. This provision conferring on the Supreme Court power to enforce the fundamental
rights in the widest possible terms shows the anxiety of the Constitution makers not to allow any
procedural technicalities to stand in the way of enforcement of fundamental rights. The Constitution
makers clearly intended that the Supreme Court should have the amplest power to issue whatever
direction, order or writ may be appropriate in a given case for enforcement of a fundamental right.
But what procedure shall be followed by the Supreme Court in exercising the power to issue such
direction, order or writ ? That is a matter on which the Constitution is silent and advisedly so,
because the Constitution makers never intended to fetter the discretion of the Supreme Court to
evolve a procedure appropriate in the circums-
tances of a given case for the purpose of enabling it to exercise its power of enforcing a fundamental
right. Neither clause (2) of Article 32 nor any other provision of the Constitution requires that any
particular procedure shall be followed by the Supreme Court in exercising its power to issue an
appropriate direction, order or writ. The purpose for which the power to issue an appropriate
direction, order or writ is conferred on the Supreme Court is to secure enforcement of a
fundamental right and obviously therefore, whatever procedure is necessary for fulfillment of the
purpose must be permissible to the Supreme Court. It is not at all obligatory that an adversarial
procedure, where each party produces his own evidence tested by cross examination by the other
side and the judge sits like an umpire and decides the case only on the basis of such material as may
be produced before him by both parties, must be followed in a proceeding under Article 32 for
enforcement of a fundamental right. In fact, there is no such constitutional compulsion enacted in
clause (2) of Article 32 or in any other part of the Constitution. It is only because we have beenBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

following the adversarial procedure for over a century owing to the introduction of the Anglo-Saxon
system of jurisprudence under the British Rule that it has become a part of our conscious as well as
sub-conscious thinking that every judicial proceeding must be cast in the mould of adversarial
procedure and that justice cannot be done unless the adversarial procedure is adopted. But it may be
noted that there is nothing sacrosanct about the adversarial procedure and in fact it is not followed
in many other countries where the civil system of law prevails. The adversarial procedure with
evidence led either party and tested by cross-examination by the other party and the judge playing a
passive role has become a part of our legal system because it is embodied in the Code of Civil
Procedure and the Indian Evidence Act. But these statutes obviously have no application where a
new jurisdiction is created in the Supreme Court for enforcement of a fundamental right. We do not
think we would be justified in imposing any restriction on the power of the Supreme Court to adopt
such procedure as it thinks fit in exercise of its new jurisdiction, by engrafting adversarial procedure
on it. when the Constitution makers have deliberately chosen not to insist on any such requirement
and instead, left it open to the Supreme Court to follow such procedure as it thinks appropriate for
the purpose of securing the end for which the power is conferred, namely, enforcement of a
fundamental right. The adversarial procedure has, in fact, come in for a lot of criticism even in the
country of its origin and there is an increasing tendency even in that country to depart from its strict
norms. Lord De lin speaking of the English judicial system said: "If our methods were as antiquated
as our legal methods, we should be a bankrupt country". And Foster Q.C. observed : "I think the
whole English system is non-sense. I would go to the root of it- the civil case between two private
parties is a mimic battle........conducted according to rules of evidence." There is a considerable body
of juristic opinion in our country also which believes that strict adherence to the adversarial
procedure can some times lead to injustice, particularly where the parties are not evenly balanced in
social or economic strength. Where one of the parties to a litigation belongs to a poor and deprived
section of the community and does not possess adequate social and material resources, he is bound
to be at a disadvantage as against a strong and powerful opponent under the adversary system of
justice, because of his difficulty in getting competent legal representation and more than anything
els, his inability to produce relevant evidence before the court. Therefore, when the poor come
before the court, particularly for enforcement of their fundamental rights, it is necessary to depart
from the adversarial procedure and to evolve a new procedure which will make it possible for the
poor and the weak to bring the necessary material before the court for the purpose of securing
enforcement of their fundamental rights. It must be remembered that the problems of the poor
which are now coming before the court are qualitatively different from those which have hither to
occupied the attention of the court and they need a different kind of lawyering skill and a different
kind of judicial approach. If we blindly follow the adversarial procedure in their case, they would
never be able to enforce their fundamental rights and the result would be nothing but a mockery of
the Constitution. We have therefore to abandon the laissez faire approach in the judicial process
particularly where it involves a question of enforcement of fundamental rights and forge new tools,
devise new methods and adopt new strategies for the purpose of making fundamental rights
meaningful for the large masses of people. And this is clearly permissible on the language of clause
(2) of Article 32 because the Constitution makers while enacting that clause have deliberately and
advisedly not used any words restricting the power of the court to adopt any procedure which it
considers appropriate in the circumstances of a given case for enforcing a fundamental right. It is
true that the adoption of this non-traditional approach is not likely to find easy acceptance from theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

generality of lawyers because their minds are conditioned by constant association with the existing
system of administration of justice which has become ingrained in them as a result of long years of
familiarity and experience and become part of their mental make up and habit and they would
therefore always have an unconscious predilection for the prevailing system of administration of
justice. But if we want the fundamental rights to become a living reality and the Supreme Court to
become a real sentinel on the quivive, we must free ourselves from the shackles of outdated and
outmoded assumptions and bring to bear on the subject fresh outlook and original unconventional
thinking.
Now it is obvious that the poor and the disadvantaged cannot possibly produce relevant material
before the court in support of their case and equally where an action is brought on their behalf by a
citizen acting pro bono publico, it would be almost impossible for him to gather the relevant
material and place it before the court. What is the Supreme Court to do in such a case ? Would the
Supreme Court not be failing in discharge of its constitutional duty of enforcing a fundamental right
if it refuses to intervene because the petitioner belonging to the underprivileged segment of society
or a public spirited citizen espousing his cause is unable to produce the relevant material before the
court. If the Supreme Court were to adopt a passive approach and decline to intervene in such a case
because relevant material has not been produced before it by the party seeking its intervention, the
fundamental rights would remain merely a teasing illusion so far as the poor and disadvantaged
sections of the community are concerned. It is for this reason that the Supreme Court has evolved
the practice of appointing commissions for the purpose of gathering facts and data in regard to a
complaint of breach of fundamental right made on behalf of the weaker sections of the society. The
Report of the commissioner would furnish prima facie evidence of the facts and data gathered by the
commissioner and that is why the Supreme Court is careful to appoint a responsible person as
commissioner to make an inquiry or investigation into the facts relating to the complaint. It is
interesting to note that in the past the Supreme Court has appointed sometimes a district
magistrate, sometimes a district Judge, sometimes a professor of law, sometimes a journalist,
sometimes an officer of the court and sometimes an advocate practising in the court, for the purpose
of carrying out an inquiry or investigation and making report to the court because the commissioner
appointed by the Court must be a responsible person who enjoys the confidence, of the court and
who is expected to carry out his assignment objectively and impartially without any predilection or
prejudice. Once the report of the Commissioner is received, copies of it would be supplied to the
parties so that either party, if it wants to dispute any of the facts or data stated in the Report, may do
so by filing an affidavit and the court then consider the report of the commissioner and the affidavits
which may have been filed and proceed to adjudicate upon the issue arising in the writ petition. It
would be entirely for the Court to consider what weight to attach to the facts and data stated in the
report of the commissioner and to what extent to act upon such facts and data. But it would not be
correct to say that the report of the commissioner has no evidentiary value at all, since the
statements made in it are not tested by cross-examination. To accept this contention would be to
introduce the adversarial procedure in a proceeding where in the given situation, it is totally
inapposite. The learned Additional Solicitor General and Mr. Phadke relied on Order XXVI of the
Code of Civil Procedure and Order XLVI of the Supreme Court Rules 1966 for the purpose of
contending that a commission can be appointed by the Supreme Court only for the purpose of
examining witnesses, making legal investigations and examining accounts and the Supreme CourtBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

has no power to appoint a commission for making an inquiry or investigation into facts relating to a
complaint of violation of a fundamental right in a proceeding under Article 32. Now it is true that
Order XLVI of the Supreme Court Rules 1966 makes the provisions of Order XXVI of the Code of
Civil Procedure, except rules 13, 14, 19, 20, 21 and 22 applicable to the Supreme Court and days
down the procedure for an application for issue of a commission, but Order XXVI is not exhaustive
and does not detract from the inherent power of the Supreme Court to appoint a commission, if the
appointment of such commission is found necessary for the purpose of securing enforcement of a
fundamental right in exercise of its constitutional jurisdiction under Article 32. Order XLVI of the
Supreme Court Rules 1966 cannot in any way militate against the power of the Supreme Court
under Article 32 and in fact rule 6 of Order XLVII of the Supreme Court Rules 1966 provides that
nothing in those Rules "shall be deemed to limit or otherwise affect the inherent powers of the court
to make such orders as may be necessary for the ends of justice." We cannot therefore accept the
contention of the learned Addl. Solicitor General and Mr. Phadke that the court acted beyond its
power in appointing M/s. Ashok Srivastava and Ashok Panda as commissioners in the first instance
and Dr. Patwardhan as commissioner at a subsequent stage for the purpose of making an inquiry
into the conditions of workmen employed in the stone quarries. The petitioner in the writ petition
specifically alleged violation of the fundamental rights of the workmen employed in the stone
quarried under Articles 21 and 23 and it was therefore necessary for the court to appoint these
commissioners for the purpose of inquiring into the facts related to this complaint. The Report of
M/s. Ashok Srivastava and Ashok Panda as also the Report of Dr. Patwardhan were clearly
documents having eviden-
tiary value and they furnished prima facie evidence of the facts and data stated in those Reports. Of
course, as we have stated above, it will be for us to consider what weight we should attach to the
facts and data contained in these Reports in the light of the various affidavits filed in the
proceedings.
We may point out that what we have said above in regard to the exercise of jurisdiction by the
Supreme Court under Article 32 must apply equally in relation to the exercise of jurisdiction by the
High Courts under Article 226, for the latter jurisdiction is also a new constitutional jurisdiction and
it is conferred in the same wide terms as the jurisdiction under Article 32 and the same powers can
and must therefore be exercised by the High Courts while exercising jurisdiction under Article 226.
In fact, the jurisdiction of the High Courts under Article 226 is much wider, because the High Courts
are required to exercise this jurisdiction not only for enforcement of a fundamental right but also for
enforcement of any legal right and there are many rights conferred on the poor and the
disadvantaged which are the creation of statute and they need to be enforced as urgently and
vigorously as fundamental rights.
Having disposed of these preliminary objections, we shall now proceed to consider the writ petition
on merits. But, before we turn to examine the facts of this case, we may first consider which are the
laws governing the living and working conditions of workmen employed in the stone quarries. The
first statute to which we must refer in this connection is the Mines Act, 1952. This Act extends to the
whole of India and therefore applies a fortiorari in the State of Haryana. Section 2(j) defines "mine"
to mean "any excavation where any operation for the purpose of searching for or obtaining mineralsBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

has been or is being carried on and includes in clause (iv) "all open cast working". The word
"minerals" has been given a very broad meaning under section 2(jj) and it means "all substances
which can obtained from the earth by mining, digging, drilling, dredging, hydraulicing, quarrying or
by any other operation". Section 2(kk) gives the definition of "open cast working" and according to
this definition, it means "a quarry, that is to say, an excavation where any operation for the purpose
of searching for or obtaining minerals has been or is being carried on, not being a shaft or an
excavation which extends below superjacent ground". There can be no doubt that according to these
definitions, the stone quarries with which we are concerned in this writ petition constitute "mines"
within the meaning of the definition of that term in section 2(j). since they are excavations where
operations for the purpose of searching for of obtaining stone by quarrying are being carried on but
they are not `open cast working' since admittedly excavations in the case of these stone quarries
extend below superjacent ground. But the question still remains whether the provisions of the Mines
Act 1952 apply to these stone quarries even if they are "mines". Section 3(1) (b) enacts that the
provisions of the Mines Act, 1952 except those contained in sections 7, 8, 9, 44, 45 and 46 shall not
apply to any mine engaged in the extraction inter alia of kankar, murrum, laterite boulders, gravel,
shingle, building stone, road metal and earth and therefore, if this statutory provision stood alone
without any qualification, it would appear that barring the excepted sections, the provisions of
Mines Act 1952 would not apply to these stone quarries. But there is a proviso to section. 3(1)(b)
which is very material and it runs as follows :
"3(1) The provisions of this Act, except those contained in sections 7, 8, 9, 44, 45 and
46, shall not apply to-
(b) any mine engaged in the extraction of kankar, murrum, laterite, boulder, gravel,
shingle, ordinary sand (excluding moulding sand, glass sand and other mineral
sands), ordinary clay (excluding kaolin, china clay, white clay or fire clay), building
stone, road metal earth, fullers earth and lime stone :
Provided that-
(i) the workings do not extend below superjacent ground; or
(ii) where it is an open cast working-
(a) the depth of the excavation measured from its highest to its lowest point nowhere
exceeds six metres;
(b) the number of persons employed on any one day does not exceed fifty; and
(c) explosives are not used in connection with the excavation."
Since the workings in these stone quarries extend below superjacent ground and they are not `open
cast workings' and moreover explosives are admittedly used in connection with the excavation, the
conditions set out in the proviso are not fulfilled and hence the exclusion of the provisions of theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Mines Act 1952 (other than the excepted sections) is not attracted and all the provisions of the
Mines Act 1952 apply to these stone quarries. It may also be noted that the definition of `mine' in
section 2(j) includes in Clause (x) any premises or part thereof in or adjacent and belonging to a
mine on which any process ancillary to the getting, dressing or preparation for sale of
minerals...........is being carried on." Now obviously stone crushing is a process ancillary to the
getting, dressing or preparation for sale of stone quarried from the stone quarries and therefore if
the stone crushing activity is carried on in premises in or adjacent to a stone quarry and it belongs to
the same owner as the stone quarry, it would be subject to the discipline of the provisions of the
Mines Act 1952 and all workmen employed in connection with such stone crushers would be entitled
to the benefit of the provisions of that Act. It will, thus, be seen that all the provisions of the Mines
Act, 1952 are applicable to the workmen employed in the stone quarries as also to the workmen
employed in connection with stone crushers, where the stone crusher is situate in or adjoining to a
stone quarry and belongs to the same owner as the stone quarry. Now the provisions of the Mines
Act, 1952 which are material are those set out in Chapters V, VI and VII, Chapter V dealing with
provisions as to health and safety, Chapter VI, with hours and limitation of employment and
Chapter VII, with leave with wages. The provisions contained in these three Chapters confer certain
rights and benefits on the workmen employed in the stone quarries and stone crushers and these
rights and benefits are intended to secure to the workmen just and humane conditions of work
ensuring a decent standard of life with basic human dignity. We shall have occasion to consider
some of these rights and benefits when we deal with the specific complaints made on behalf of the
petitioner, but we may point out at this stage that the most important rights and benefits conferred
on the workmen are those relating to their health and safety which include provisions as to drinking
water, conservancy and injuries arising out of accidents, in regard to which detailed requirements
are laid down in Chapters V, VI and IX of the Mines Rules; 1955. We may also point out that the
obligation of complying with these provisions of the Mines Act, 1952 and the Mines Rules, 1955 rests
on the owner, agent and manager of every stone quarry and stone crusher, because section 18
declares that the owner, agent and manager of every mine shall be responsible that all operations
carried on in connection therewith are conducted in accordance with the provisions of the Act and of
the regulations, rules and by-laws and of any orders made under the Act. The `owner' is defined in
section 2(1) of the Mines Act, 1952 to mean "any person who is the immediate proprietor or lessee or
occupier of the mine or any part thereof.........but does not include a person who merely receives a
royalty, rent or fine from the mine or is merely the proprietor of the mine, subject to any lease, grant
or licence for the working thereof." Since the stone quarries in the present case are not being
exploited by the State of Haryana though it is the owner of the stone quarries, but are being given
out on lease by auction, the mine-lessees who are not only lessees but also occupiers of the stone
quarries are the owners of the stone quarries within the meaning of that expression as used in
section 2(1) and so also are the owners of stone crushers in relation to their establishment. The
mine-lessees and owners of stone crushers are, therefore liable under section 18 of the Mines Act,
1952 to carry out their operations in accordance with the provisions of the Mines Act, 1952 and the
Mines Rules, 1955 and other Rules and Regulations made under that Act and to ensure that the
rights and benefits conferred by these provisions are actually and concretely made available to the
workmen. The Central Government is entrusted under the Mines Act 1952 with the responsibility of
securing compliance with the provisions of that Act and of the Mines Rules 1955 and other Rules
and Regulations made under that Act and it is the primary obligation of the Central Government toBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

ensure that these provisions are complied with by the mine-lessees and stone crusher owners. The
State of Haryana is also, for reasons which we have already discussed, under an obligation to take all
necessary steps for the purpose of securing compliance with these provisions by the mine-lessees
and owners of stone crushers. The State of Haryana has in fact amended the Punjab Minor Mineral
Concession Rules 1964 in their application to the State of Haryana by issuing the Punjab Minor
Mineral Concession (Haryana First Amendment) Rules 1982 on 6th December 1982 and substituted
a new clause 16 in Form F, a new clause 13 in Form L and a new clause 10 in Form N providing that
the lessee/lessees or the contractor/contractors, as the case may be, "shall abide by the provisions of
Mines Act, 1952 Inter State Migrant Workmen (Regulation of Employment and Conditions of
Service) Act, 1979 and the rules and regulations framed thereunder and also the provisions of other
labour laws both Central and State as are applicable to the workmen engaged in the mines, and
quarries relating to the provisions of drinking water, rest shelters, dwelling houses, latrnesi and first
aid and medical facilities in particular and other safety and welfare provisions in general, to the
satisfaction of the competent authorities under the aforesaid Acts, rules and regulations and also to
the satisfaction of the District Magistrate concerned. In the case of non-compliance of any of the
provisions of the enactments as aforesaid, the State Government or any officer authorised by it in
this behalf may terminate the contract by giving one month's notice with forfeiture of security
deposited or in the alternative the State Labour Department may remedy the breach/breaches by
providing the welfare and safety measures as provided in the aforesaid enactments at the expense
and cost of the contractor/contractors. The amount thus spent shall be recovered from the
contractor/contractors by the Industries Department and reimbursed to Labour Department."
The State of Haryana is therefore, in any event, bound to take action to enforce the provisions of the
Mines Act 1952 and the Mines Rules 1955 and other Rules and Regulations made under that Act for
the benefit of the workmen.
We may then turn to the provisions of Inter-State Migrant Workmen (Regulation of Employment
and Conditions of Service) Act, 1979 (hereinafter referred to as the Inter- State Migrant Workmen
Act). This Act was brought into force in the State of Haryana with effect from 2nd October 1980 and
the authorities and this Act were notified on 21st July 1982. We may, therefore, proceed on the basis
that the provisions of this Act became enforceable, if not from 2nd October 1980 at least from 21st
July 1982. Now this Act by subsection (4) of Section (1) applies to every establishment in which five
or more inter-State migrant workmen are employed or were employed on any day of the preceding
twelve months and so also it applies to every contractor who employs or employed five or more
inter-State migrant workmen on any day of the preceding twelve months. Section (2) sub- section
(1) Clause (b) of the Act defines contractor, in relation to an establishment, to mean "a person who
undertakes (whether as an independent contractor, agent, employee or otherwise) to produce a
given result for the establishment, other than a mere supply of goods and articles of manufacture of
such establishment, by the employment of workmen or to supply workmen to the establishment,
and includes a sub-contractor, khatedar, sardar, agent or any other person, by whatever name
called, who recruits or employs workmen." Clause (e) of sub-section (1) of Section (2) defines
"inter-State migrant workmen" to means "any person who is recruited by or through a contractor in
one State under an agreement or other arrangement for employment in an establishment in another
State, whether with or without the knowledge of the principal employer in relation to suchBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

establishment." The expression "principal- employer" is defined by clause (g) of sub-section (1) of
Section 2 to mean "in relation to a mine, the owner or agent of the mine and where a person has
been named as the manager of the mine, the person so named." Obviously, therefore, the
mine-lessees and owners of stone crushers in the present case would be principal employers within
the meaning of that expression as used in the Inter-State Migrant Workmen Act. Section 4 provides
for registration of every principal employer of an establishment to which the Act applies and Section
6 enacts that no principal employer of an establishment to which this Act applies, shall employ
inter- State migrant workmen in the establishment unless a certificate of registration in respect of
such establishment is issued under the Act in force. Similarly, Section 8 sub- section (1) provides
that with effect from such date as the appropriate Government may be Notification in the Official
Gazette appoint no contractor to whom the Act applies shall recruit any person in a State for the
purpose of employing him in any establishment situated in another State, except under and in
accordance with a licence issued in that behalf by the licensing officer appointed by the Central
Government who has jurisdiction in relation to the area wherein the recruitment is made, nor shall
be employ as workmen for the execution of any work in any establishment in any State, persons
from another State excent under and in accordance with a licence issued in that behalf by the
licensing officer appointed by the appropriate Government having jurisdiction in relation to the area
wherein the establishment is situated. Sub-section (2) of Section 8 declares that a licence under
sub-section (1) may contain such conditions including, in particular, the terms and conditions of the
agreement or other arrangement under which the workmen will be recruited, the remuneration
payable, hours of work, fixation of wages and other essential amenities in respect of the inter-State
migrant workmen, as the appropriate Government may deem fit to impose in accordance with the
Rules, if any, made under Section 35. Section 12 imposes certain duties and obligations on
contractors which include inter alia the duty to issue to every inter-State migrant workman a
pass-book containing various particulars regarding recruitment and employment of the workman as
also to pay to the workman the return fare from the place of employment to the place of residence in
the home State when he ceases to be employed. Rule 23 of the Inter-State Migrant Workmen
(Regulation of Employment and Conditions of Service) Central Rules 1980 (hereinafter referred to
as Inter-State Migrant Workmen Rules) sets out certain additional particulars which must be
included in the pass-book to be issued to every inter-State migrant workmen. Section 13 then
proceeds to lay down the wage rates, holidays, hours of work and other conditions of service of an
inter-State migrant workman and provides inter alia that in no case shall a inter-State migrant
workman be paid less than the wages fixed under the Minimum Wages Act 1948, and the wages
shall be paid to an inter-State migrant workman in cash. The detailed particulars in regard to wages
payable to an inter-State migrant workman are laid down in Rules 25 to 35 of the Inter-State
Migrant Workmen Rules. Then follows Section 14 which provides that there shall be paid by the
contractor to every inter-State migrant workman at the time of recruitment, a displacement
allowance and the amount of displacement allowance shall not be refundable but shall be in addition
to the wages or other amounts payable to him. There is also a provision made in Section 15 for
payment to an inter-State migrant workman of a journey allowance of a sum not less than the fare
from the place of residence in his State to the place of work in the other State, both for outward and
return journeys and this Section also enacts that the workman shall be entitled to payment of wages
during the period of such journeys as if he was on duty. Section 16 days a duty on every contractor
employing inter- State migrant workmen in connection with the work of an establishment to provideBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

various other facilities particulars of which are to be found in Rules 36 to 45 of the Inter-State
Migrant Workmen Rules. These facilities include medical facilities, protective clothing, drinking
water, latrines, urinals and washing facilities, rest rooms, canteens, creche and residential
accommodation. The obligation to provide these facilities is in relation to the inter-State Migrant
Workmen employed in an establishment to which the Act applies. But this liability is not confined
only to the contractor, because Section 18 provides in so many terms that if any allowance required
to be paid under- section 14 or 15 to an inter-State migrant Workman is not paid by the contractor
or if any facility specified in section 16 is not provided for the benefit of such workman, such
allowance shall be paid or as the case may be, the facility shall be provided by the principal employer
within such time as may be prescribed by the Rules and all the allowances paid by the principal
employer or all the expenses incurred by him in this connection may be recovered by him from the
contractor either by deduction from the amount payable to the contractor or as debt payable by the
contractor. Section 25 & 26 make it an offence for any one to contravene any of the provisions of the
Inter-Stage Migrant Workmen Act or Inter- State Migrant Workmen Rules and Section 30 gives
over-riding effect to the provisions of the Inter-State Migrant Workmen Act over any other law or
any agreement or contract of service or any standing orders. These are broadly the relevant
provisions of the Inter-State Migrant Workmen Act and the Inter-State Migrant Workmen Rules
which may call for consideration.
But the question arises whether the Inter-State Migrant Workmen Act applies to the workmen
employed in the stone quarries and the stone crushers. Now it was not disputed on behalf of the
State of Haryana and indeed it was clear from the Report of Dr. Patwardhan that most of the
workmen employed in the stone quarries and stone crushers come from Uttar Pradesh, Madhya
Pradesh, Rajasthan, Tamilnadu and Andhra Pradesh and there are only a few workmen from
Haryana. It is only if 5 or more out of these workmen coming from States other than Haryana are
inter-State migrant workmen within the meaning of that expression as defined in Section 2
sub-section (1) clause (e) of the Inter-State Migrant Workmen Act that the establishment in which
they are employed would be covered by the Inter-State Migrant Workmen Act. It would therefore
have to be determined in case of each stone quarry and each stone crusher whether there are 5 or
more inter-State Migrant workmen employed in the establishment and if there are, the provisions of
the inter- State Migrant Workmen Act and the Inter-State Migrant Workmen Rules would become
applicable to such establishment. The Union of India in a submission filed on its behalf by Miss
Subhasini has taken up the stand that the workmen employed in the one quarries and stone
crushers "are coming to join the service in the stone quarries of their own volition and they are not
recruited by any agent for being migrated from any State" and "as such they do not come under the
definition of the term" inter-State migrant workman. We would have ordinarily been inclined to
accept this statement made on behalf of the Union of India, but we find that, according to the Report
of Dr. Patwardhan, the modus operandi that is followed for the purpose of recruitment of workmen
is "that the stone crusher owners or the lessees holders ask the thekedar or jamadar of the mine to
fetch people from various States to work in the mines" and some times "the jamadar or thekedar
communicates the need for workers to old hands at the quarries so that they could bring in people
on their return from their villages or their respective States". Now if what has been reported by Dr.
Patwardhan is true, there can be no doubt that the workmen employed in the stone quarries and
stone crushers would be inter-State migrant workmen. The thekedar or jamadar who is engaged byBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

the mine lessees or the stone-crusher owners to recruit workmen or employ them on behalf of the
mine lessees or stone crusher owners would clearly be a 'contractor' within the meaning of that term
as defined in Section 2 sub-section (1) clause (b) and the workmen recruited by or through him from
other States for employment in the stone quarries and stone crushers in the State of Haryana would
undoubtedly be inter- State migrant workmen. Even when the thekedar or jamadar recruits or
employs workmen for the stone quarries and stone crushers by sending word through the "old
hands", the workmen so recruited or employed would be inter-State migrant workmen, because the
"old hands" would be really acting as agents of the thekedar or jamadar for the purpose of recruiting
or employing workmen. The Inter-State Migrant Workmen Act being a piece of social welfare
legislation intended to effectuate the Directive Principles of State Policy and ensure decent living
and working conditions for the workmen when they come from other States and are in a totally
strange environment where by reason of their poverty, ignorance and illiteracy, they would be totally
unorganised and helpless and would become easy victims of exploitation, it must be given a broad
and expansive interpretation so as to prevent the mischief and advance they remedy and therefore,
even when the workmen are recruited or employed by the jamadar or thekedar by operating through
the "old hands", they must be regarded as inter-State migrant workmen entitled to the benefit of the
provisions of the Inter-State Migrant Workmen Act and the Inter-State Migrant Workmen Rules.
The Report of Dr. Patwardhan also points out one other aspect of the matter:
according to him, there is invariably "an understanding between the jamadar or
thekedar and the owners of stone crushers holding leases of stone quarries as to the
rate of output of stone to be fed through the crushers" and thus the jamadar or
thekedar is clearly a 'contractor' of the stone crusher owners and the workmen
recruited or employed by him on behalf of the owners of stone crushers are
inter-State migrant workmen. We entirely agree with this view put forward by Dr.
Patwardhan in his Report and we have no doubt that if there is any agreement or
understanding between the jamadar or thekedar on the one hand and the owners of
stone crushers on the other, that the jamadar or thekedar will ensure a certain rate of
output of stone to be fed to the stone crushers, the jamadar or thekedar would be a
'contractor' and the workmen recruited or employed by him on behalf of the stone
crusher owners would be inter-State migrant workmen. But whether in any particular
stone quarry or stone crusher the workmen employed are inter-State migrant
workmen on the application of this test laid down by us and if so, how many of them
are such inter-State migrant workmen, is a matter which would have to be
investigated and determined and that is what must be done if we are to make the
provisions of the Inter-State Migrant Workmen Act and the Inter-State Migrant
Workmen Rules meaningful for these workmen who are recruited from other States
and who come to the stone quarries and stone crushers in the State of Haryana. We
may point out that in addition to the rights and benefits conferred upon him under
the Inter-State Migrant Workmen Act and the Inter- State Migrant Workmen Rules,
an inter-State migrant workman is also, by reason of Section 21, entitled to the
benefit of the provisions contained in the Workman's Compensation Act 1923. The
Payment of Wages Act 1936, The Employees' State Insurance Act 1948, The
Employees' Provident Funds and Misc. Provisions Act, 1952, and the MaternityBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Benefit Act 1961. The obligation to give effect to the provisions contained in these
various laws is not only that of the jamadar or thekedar and the mine-lessees and
stone crusher owners (provided of course there are 5 or more inter-State migrant
workmen employed in the establishment) but also that of the Central Government
because the Central Government being the appropriate Government" within the
meaning of Section 2(1)(a) is under an obligation to take necessary steps for the
purpose of securing compliance with these provisions by the thekedar or jamadar and
mine-lessees and owners of stone crushers. The State of Haryana is also for reasons
already discussed above bound to ensure that these provisions are observed by the
thekedar or jamadar and mine-lessees and owners of stone crushers.
We then turn to consider the provisions of the Contract Labour (Regulation and
Abolition) Act 1970 (hereinafter referred to as the Contract Labour Act). This Act
applies to every establishment in which 20 or more workmen are employed or were
employed on any day of the preceding twelve months as contract labour and to every
contractor who employs or who employed on any day of the preceding twelve months
20 or more workmen. The expression "appropriate government" is defined in Section
2 sub-section (1) clause (a) and so far as the stone quarries and stone crushers are
concerned, the Central Government is the 'appropriate Government'. Section 2
sub-section (1) clause (b) states that a workman shall be deemed to be employed as
"contract labour" in or in connection with the work of an establishment when he is
hired in or in connection with the work of an establishment when he is hired in or in
connection with such work by or through a contractor and "contractor"
is defined in clause (c) of that sub-section to mean, in relation to an establishment, "a person who
undertakes to produce a given result for the establishment, other than a mere supply of goods or
articles of manufacture to such establishment, through contract labour or who supplies contract
labour for any work of the establishment and includes a sub-contractor". The expression "principal
employer" is defined in clause (g) of sub-section (i) of section 2 and for the purpose of a mine, it
means the owner or agent of the mine and therefore, so far as the stone quarries and stone crushers
are concerned, the mine lessees and owners of stone crushers would be the principal employers.
Then there are provisions in the Contract Labour Act for registration of establishment by every
principal employer and for licensing of every contractor to whom the Act applies. But more
importantly, Sections 16 to 19 impose a duty on every contractor to provide canteens, rest rooms,
first aid facilities and other facilities and Section 20 enacts that if any amenity required to be
provided under section 16, 17, 18 or 19 for the benefit of the contract labour employed in an
establishment is not provided by the contractor, such amenity shall be provided by the principal
employer and all expenses incurred by the principal employer in providing such amenity may be
recovered by the principal employer from the contractor. Every contractor is made responsible
under-section 21 for payment of wages to each worker employed by him as contract labour and such
wages are to be disbursed in the presence of a representative duly authorised by the principal
employer. Now if the jamadar or thekedar in a stone quarry or stone crusher is a 'contractor' within
the meaning of the definition of that term in the Inter-State Migrant Workmen Act, he would a
fortiorari be a 'contractor' also for the purpose of Contract Labour Act and any workmen hired in orBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

in connection with the work of a stone quarry or stone crusher by or through the jamadar or
thekedar would be workmen entitled to the benefit of the provisions of the Contract Labour Act.
There are elaborate Rules made under the Contract Labour Act called the Contract Labour
(Regulation and Abolition) Central Rules 1971 (hereinafter referred to as the Contract Labour Rules)
and these Rules not only deal with the procedure for application and grant of registration to a
principal employer and licence to a contractor, but also particularise the details of the various
welfare and other facilities directed to be provided to the contract labour by Section 16, 17, 18 and 19
of the Contract Labour Act. Where therefore the thekedar or jamadar is a 'contractor' and the
workmen are employed as contract labour' within the meaning of these expres-
sions as used in the Contract Labour Act, the contractor as well as the principal employer would be
liable to comply with the provisions of contract Labour Act and the Contract Labour Rules and to
provide to the contract labour rights and benefits conferred by these provisions. The Central
Government being the "appropriate government" within the meaning of Section 12 sub-section (1)
clause (a) would be responsible for ensuring compliance with the provisions of the Contract Labour
Act and the Contract Labour Rules by the mine-lessees and stone crusher owners and the thekedar
or jamadar. So also, for reasons which we have already discussed while dealing with the applicability
of the Mines Act 1952 and the Inter-State Migrant Workmen Act, the State of Haryana would be
under an obligation to enforce the provisions of the Contract Labour Act and the Contract Labour
Rules for the benefit of the workmen.
Turning to the provisions of the Minimum Wages Act 1948, there can be no doubt and indeed this
was not disputed on behalf of the respondents, that the Minimum Wages Act 1948 is applicable to
workmen employed in the stone quarries and stone crushers. The minimum wage fixed for miners
by the Notification of the Central Government dated 2nd December 1981 is Rs. 9.75 per day for
those working, above the ground and Rs. 11.25 per day for those working below the ground.
Moreover the Notification prescribes a separate minimum wage for the occupation of a shot firer,
stone breaker, stone carrier, mud remover and water carrier. There is a minimum wage prescribed
in the Notification for each of these occupations. The question is whether the workmen employed in
the stone quarries and stone crushers are paid minimum wage for the work done by them. The
Report of Dr. Patwardhan alleges that the mode of payment to the workmen employed in stone
quarrying operations is such that after deduction of the amounts spent on explosives and drilling of
holes, which amount has to be borne by the workmen out of their wages, what is left to the workmen
is less than the minimum wage. It is also stated in the Report of Dr. Patwardhan that the workmen
employed in the stone quarries not only quarry the stone but also carry out the work of a shot firer
and a stone breaker, though the work of a shot firer cannot be done by them without proper training
as provided in the Mines Vocational Training Rules 1966 and for this work of a shot firer and a stone
breaker carried cut by them, they do not get the minimum wage stipulated for the occupation of a
shot firer or a stone breaker and moreover since they are piece-rated workers, their output falls
because of the other jobs they are required to carry out with the result that they are deprived of the
minimum wage which they should otherwise receive. We are not in a position at the present stage to
give a definite finding that what is stated in the Report of Dr. Patwardhan is true, but there can be
no doubt that whatever be the mode of payment followed by the mine lessees and stone crusher
owners, the workmen must get nothing less than the minimum wage for the job which is beingBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

carried out by them and if they are required to carry out additionally any of the functions pertaining
to another job or occupation for which a separate minimum wage is prescribed, they must be paid a
proportionate part of such minimum wage in addition to the minimum wage payable to them for the
work primarily carried out by them. We would also suggest that the system of payment which is
being followed in the stone quarries and stone crushers, under which the expenses of the explosives
and of drilling holes are to be borne by the workmen out of their own wages, should be changed and
the explosives required for carrying out blasting should be supplied by the mine lessees or the
jamadar or thekedar without any deduction being made out of the wages of the workmen and the
work of drilling holes and shot firing should be entrusted only to those who have received the
requisite training under the Mines Vocational Training Rules 1966. We would direct the Central
Government and the State of Haryana to take necessary steps in this behalf. So far as the complaint
of the petitioner that the workmen employed in the stone quarries and stone crushers are not being
paid the minimum was due and payable for the work carried out by them is concerned, it is a matter
which would have to be investigated and determined in the light of the law laid down by us.
Lastly, we must consider the provisions of the Bonded Labour System (Abolition) Act 1976. We have
already pointed out that many of the States are not prepared to admit the existence of bonded
labour in their territories and the State of Haryana is no exception. But in order to determine
whether there is any bonded labour in the stone quarries and stone crushers in the Faridabad area
of the State of Haryana, it is necessary to examine some of the relevant provisions of the Bonded
Labour System (Abolition) Act 1976. This Act was enacted with a view to giving effect to Article 23 of
the Constitution which prohibits traffic in human beings and beggar and other similar forms of
forced labour. We have had occasion to consider the true scope and dimension of this Article of the
Constitution in People's Union for Democratic Rights v. Union of India(1) commonly known as the
Asiad workers' case and it is not necessary for us to say anything more about it in the present
judgment. Suffice it to state that this Act is intended to strike against the system of bonded labour
which has been a shameful scar on the Indian social scene for decades and which has continued to
disfigure the life of the nation even after independence. The Act was brought into force through out
the length and breadth of the country with effect from 25th October 1975, which means that the Act
has been in force now for almost 8 years and if properly implemented, it should have by this time
brought about complete identification, freeing and rehabilitation of bonded labour. But as official,
semi- official and non-official reports show, we have yet to go a long way in wiping out this outrage,
against humanity. Clause (d) of Section 2 defines "bonded debt" to mean an advance obtained or
presumed to have been obtained, by a bonded labourer, under or in pursuance of, the bonded labour
system. The expression 'bonded labourer' is defined in clause (f) to mean "a labourer who incurs, or
has, or is presumed to have incurred a bonded debt". Clause (g) defines "bonded labour system" to
mean:
"the system of forced, or partly forced, labour under which a debtor enters, or has, or
is presumed to have, entered, into an agreement with the creditor to the effect that,-
(i) in consideration of an advance obtained by him or by any of his lineal ascendants
or descendants (whether or not such advance is evidenced by any document) and in
consideration of the interest, if any, due on such advance, orBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

(ii) in pursuance of any customary or social obligation, or
(iii) for any economic consideration received by him or by any of his lineal
ascendants or descendants, or he would-
(1) render, by himself or through any member of his family, or any person dependent
on him, labour or service to the creditor, or for the benefit of the creditor, for a
specified period or for an unspecified period, either without wages or for nominal
wages, or (2) forfeit the freedom of employment or other means of livelihood for a
specified period or for an unspecified period, (3) forfeit the right to move freely
throughout the territory of India, or (4) forfeit the right to appropriate or sell at
market value any of his property or product of his labour or the labour of a member
of his family or any person dependent on him."
The expression "nominal wages" is defined in clause (i) of Section 2 to mean, in relation to any
labour, a wage which is less than-
(a) the minimum wages fixed by the Government, in relation to the same or similar labour, under
any law for the time being in force, and
(b) where no such wage has been fixed in relation to any form of labour, the wages that are normally
paid, for the same or similar labour to the labourers working in the same locality."
Section 4 is the material section which provides for abolition of bonded labour system and it runs as
follows:
"4(1) On the commencement of this Act, the bonded labour system shall stand
abolished and every bonded labourer shall, on such commencement, stand freed and
discharged from any obligation to render any bonded labour.
(2) after the commencement of this Act, no person shall-
(a) make any advance under, or in pursuance of, the bonded labour system, or
(b) compel any person to render any bonded labour or other form of forced labour.
Section 5 invalidates any custom or tradition or any contract agreement or other instrument by
virtue of which any person or any member of the family or dependent of such person is required to
do any work or render any service as a bonded labourer. Section 6 provides inter alia that on the
commencement of the Act, every obligation of a bonded labourer to repay and bonded debt or such
part of any bonded debt as remains unsatisfied immediately before such commencement, shall be
deemed to have been extinguished.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

There are certain other consequential provisions in Section 7 to 9 but it is not necessary to refer to
them. Sections 10 to 12 impose a duty on every District Magistrate and every officer to whom power
may be delegated by him, to inquire whether, after the commencement of the Act, any bonded
labour system or any other form of forced labour is being enforced by or on behalf of, any person
resident within the local limits of his jurisdiction and if, as a result of such inquiry, any person is
found to be enforcing the bonded labour system or any other system of forced labour, he is required
forthwith to take the necessary action to eradicate the enforcement of such forced labour. Section 15
provides for Constitution of a Vigilance Committee in each District and each sub-division of a
District and sets out what shall be the composition of each Vigilance Committee. The functions of
the Vigilance Committee are set out in Section 14 and among other things, that Section provinces
that the Vigilance Committee shall be responsible inter alia to advise the District Magistrate as to
the efforts made and action taken, to ensure that the provisions of the Act or any Rule made
thereunder are properly implemented, to provide for the economic and social rehabilitation of the
freed bonded labourers and to keep an eye on the number of offences of which cognizance has been
taken under the Act. Then comes Section 15 which lays down that whenever any debt is claimed by
any labourer or a Vigilance Committee to be a bonded debt, the burden of proof that such debt is not
a bonded debt shall lie on the creditor. These are some of the material provisions of the Bonded
Labour System (Abolition) Act 1976 which need to be considered.
It is a matter of regret that though Section 13 provides for constitution of a Vigilance Committee in
each District and each subdivision of a District, the Government of Haryana, for some reason or the
other, did not constitute any Vigilance Committee until its attention was drawn to this requirement
of the law by this Court. It may be that according to the Government of Haryana there were not at
any time any bonded labourers within its territories, but even so Vigilance Committees are required
by Section 13 to be constituted because the function of the Vigilance Committee is to identify bonded
labourers, if there are any, and to free and rehabilitate them and it would not be right for the State
Government not to constitute Vigilance Committees on the assumption that there are no bonded
labourers at all. But we are glad to find that the Government of Haryana has now constituted a
Vigilance Committee in each District. It does not appear from the record whether a Vigilance
Committee has been constituted also in each sub-division of a District but we have no doubt that the
Government of Haryana will without any delay and at any rate within six weeks from today
constitute a Vigilance Committee in each sub-division and thus comply with the requirement of
Section 13 of the Act. We may point out that in constituting Vigilance Committee in each-District
and sub-division, the Haryana Government would do well to include representatives of non-political
social action groups operating at the grass root level, for it is only through such social action groups
and voluntary agencies that the problem of identification of bonded labour can be effectively solved.
It was contended by the learned Additional Solicitor General on behalf of the State of Haryana that
in the stone quarries and stone crushers there might be forced labourers but they were not bonded
labourers within the meaning of that expression as used in the Act, since a labourer would be a
bonded labourer only if he has or is presumed to have incurred a bonded debt and there was nothing
in the present case to show that the workmen employed in the stone quarries and stone crushers
had incurred or could be presumed to have incurred any bonded debt. It was not enough, contended
the learned Additional Solicitor General the petitioner merely to show that the workmen wereBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

providing forced labour in that they were not allowed to leave the premises of the establishment, but
it was further necessary to show that they were working under the bonded labour system. The
learned Additional Solicitor General also submitted that in any event, even if the workmen filed
affidavits to the effect that they had taken advances from thekedar or jamadar and or mine lessees
and/or stone crusher owners and they were not allowed to leave the premises of the establishment
until the advances were paid of, that would not be enough evidence for the Court to hold that they
were bonded labourers, because the mine-lessees and stone crusher owners had no opportunity to
cross-examine the workmen making such affidavits. This contention was seriously pressed by the
learned Additional Solicitor General on behalf of the State of Haryana, but as we shall presently
show, there is no substance in this contention. We may point out that in the course of the arguments
we did suggest to the learned Additional Solicitor General that even if the workmen were not bonded
labourers in the strict sense of the term but were merely forced to provide labour, should the State
Government not accept liability for freeing and rehabilitating them, particularly in view of the
Directive Principles of State Policy. The State of Haryana was however not prepared to come
forward with any proposal in this behalf.
Now it is clear that bonded labour is a form of forced labour and Section 12 of the Bonded Labour
System (Abolition) Act 1976 recognises this self-evident proposition by laying a duty on every
District Magistrate and every officer specified by him to inquire whether any bonded labour system
or any other form of forced labour is being enforced by or on behalf of any person and, if so, to take
such action as may be necessary to eradicate the enforcement of such forced labour. The thrust of
the Act is against the continuance of any form of forced labour. It is of course true that, strictly
speaking, a bonded labourer means a labourer who incurs or has or is presumed to have incurred a
bonded debt and a bonded debt means an advance obtained or presumed to have been obtained by a
bonded labourer under or in pursuance of the bonded labour system and it would therefore appear
that before a labourer can be regarded as a bonded labourer, he must not only be forced to provide
labour to the employer but he must have also received an advance or other economic consideration
from the employer unless he is made to provide forced labour in pursuance of any custom or social
obligation or by reason of his birth in any particular caste or community. It was on the basis of this
definitional requirement that the learned Additional Solicitor General on behalf of the State of
Haryana put forward the argument that even if the workmen employed in the stone quarries and
stone crushers were being compelled to provide forced labour, they were not bonded labourers,
since it as not shown by them or by the petitioner that they were doing so in consideration of an
advance or other economic consideration received from the mine-lessees and owners of stone
crushers. Now if this contention of the learned Additional Solicitor General were well-founded, it
would become almost impossible to enforce the provisions of the Bonded Labour System (Abolition)
Act 1976 because in every case where bonded labourers are sought to be identified for the purpose of
release and rehabilitation under the provisions of the Act, the State Authorities as also the employer
would be entitled to insist that the bonded labourers must first prove that they are providing forced
labour in consideration of an advance or other economic consideration received by them and then
only they would be eligible of the benefits provided under the Act and this would make it extremely
difficult, if not impossible, for the labourers to establish that they are bonded labourers because they
would have no evidence at all to prove that any advance or economic consideration was provided to
them by the employer and since employment of bonded labourers is a penal offence under the ActBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

the employer would immediately, without any hesitation, disown having given any advance or
economic consideration to the bonded labourers. It is indeed difficult to understand how the State
Government which is constitutionally mandated to bring about change in the life conditions of the
poor and the down-trodden and to ensure social justice to them, could possibly take up the stand
that the labourers must prove that they are made to provide forced labour in consideration of an
advance or other economic consideration received from the employer and are therefore bonded
labourers. It is indeed a matter of regret that the State Government should have insisted on a
formal, rigid and legalistic approach in the matter of a statute which is one of the most important
measures for ensuring human dignity to these unfortunate specimens of humanity who are exiles of
civilization and who are leading a life of abject misery and destitution. It would be cruel to insist that
a bonded labourer in order to derive the benefits of this social welfare legislation, should have to go
through a formal process of trial with the normal procedure for recording of evidence. That would
be a totally futile process because it is obvious that a bonded labourer can never stand up to the
rigidity and formalism of the legal process due to his poverty, illiteracy and social and economic
backwardness and if such a procedure were required to be followed, the State Government might as
well obliterate this Act from the statute book. It is now statistically established that most of bonded
labourers are members of Scheduled Castes and Scheduled Tribes or other backward classes and
ordinary course of human affairs would show, indeed judicial notice can be taken of it, that there
would be no occasion for a labourer to be placed in a situation where he is required to supply forced
labour for no wage or for nominal wage, unless he has received some advance or other economic
consideration from the employer and under the pretext of not having returned such advance or
other economic consideration, he is required to render service to the employer or is deprived of his
freedom of employment or of the right to move freely wherever he wants. Therefore, whenever it is
shown that a labourer is made to provide forced labour, the Court would raise a presumption that he
is required to do so in consideration of an advance or other economic consideration received by him
and he is therefore a bonded labourer. This presumption may be rebutted by the employer and also
by the State Government if it so chooses but unless and until satisfactory material is produced for
rebutting this presumption, the Court must proceed on the basis that the labourer is a bonded
labourer entitled to the benefit of the provisions of the Act. The State Government cannot be
permitted to repudiate its obligation to identify, release and rehabilitate the bonded labourers on the
plea that though the concerned labourers may be providing forced labour, the State Government
does not owe any obligation to them unless and until they show in an appropriate legal proceeding
conducted according to the rules of adversary system of justice, that they are bonded labourers.
The first question that arises in regard to the implementation of the Bonded Labour System
(Abolition) Act 1976 is that of identification of bonded labour. One major handicap which impedes
the identification of bonded labour, is the reluctance of the administration to admit the existence of
bonded labour, even where it is prevalent. It is therefore necessary to impress upon the
administration that it does not help to ostrich-like bury its head in the sand and ignore the
prevalence of bonded labour, for it is not the existence of bonded labour that is a slur on the
administration but its failure to eradicate it and moreover not taking the necessary steps for the
purpose of wiping out this blot on the fair name of the State is a breach of its constitutional
obligation. We would therefore direct the Government of Haryana and also suggest to the other
State Governments, to take steps to sensitise the officers concerned with the implementation of theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Act to this acute human problems and its socioeconomic parameters. Moreover it may be noted that
the District Magistrates have a central role to play under the provisions of the Act and the State
Governments would therefore do well to instruct the District Magistrates to take up the work of
identification of bonded labour as one of their top priority tasks. There are certain areas of
concentration of bonded labour which can be easily identified on the basis of various studies and
reports made by governmental authorities, social action groups and social scientists from time to
time. These areas of concentration of bonded labour are mostly to be found in stone quarries, brick
kilns and amongst agricultural landless labourers and such areas must be mapped out by each State
Government and task forces should be assigned for identification and release of bonded labour.
Labour camps should be held periodically in these areas with a view to educating the labourers and
for this purpose, the assistance of the National Labour Institute may be taken, because the National
Labour Institute has the requisite expertise and experience of holding such camps and it should be
associated with the organisation and conduct of such camps and in each such camp, individuals with
organisational capability or potential should be identified and given training in the work of
identification and release of bonded labour. More importantly non-political social action groups and
voluntary agencies and particularly those with a record of honest and competent service for
Scheduled Castes and Scheduled Tribes, agricultural labourers and other unorganised workmen
should be involved in the task of identification and release of bonded labourers, for it is primarily
through such social action groups and voluntary agencies alone that it will be possible to eradicate
the bonded labour system, because social action groups and voluntary agencies comprising men and
women dedicated to the cause of emancipation of bonded labour will be able to penetrate through
the secrecy under which very often bonded labourers are required to work and discover the
existence of bonded labour and help to identify and release bonded labourers. We would therefore
direct the Vigilance Committees as also the District Magistrates to take the assistance of
non-political social action groups and voluntary agencies for the purpose of ensuring
implementation of the provisions of the Bonded Labour System (Abolition) Act 1976.
The other question arising out of the implementation of the Bonded Labour System (Abolition) Act
1976 is that of rehabilitation of the released bonded labourers and that is also a question of the
greatest importance, because if the bonded labourers who are identified and freed, are not
rehabilitated, their condition would be much worse than what it was before during the period of
their serfdom and they would become more exposed to exploitation and slide back once again into
serfdom even in the absence of any coercion. The bonded labourer who is released would prefer
slavery to hunger, a world of 'bondage and (illusory) security' as against a world of freedom and
starvation. The State Governments must therefore concentrate on rehabilitation of bonded labour
and evolve effective programmes for this purpose. Indeed they are under an obligation to do so
under the provisions of the Bonded Labour System (Abolition) Act 1976. It may be pointed out that
the concept of rehabilitation has the following four main features as admirably set out in the letter
dated 2nd September 1982 addressed by the Secretary. Ministry of Labour, Government of India to
the various States Governments:
(i) Psychological rehabilitation must go side by side with physical and economic
rehabilitation;Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

(ii) The physical and economic rehabilitation has 15 major components namely
allotment of house-sites and agricultural land, land development, provision of low
cost dwelling units, agriculture, provision of credit, horticulture, animal husbandry,
training for acquiring new skills and developing existing skills, promoting traditional
arts and crafts, provision of wage employment and enforcement of minimum wages,
collection and processing of minor forest produce, health medical care and sanitation
supply of essential commodities, education of children of bonded labourers and
protection civil rights;
(iii) There is scope for bringing about an integration among the various central and
centrally sponsored schemes and the on-going schemes of the State Governments for
a more qualitative rehabilitation.
The essence of such integration is to avoid duplication i.e. pooling resources from different sources
for the same purpose. It should be ensured that while funds are not drawn from different sources for
the same purpose drawn from different sectors for different components of the rehabilitation
scheme are integrated skillfully; and
(iv) While drawing up any scheme/programme of rehabilitation of freed bonded labour, the latter
must necessarily be given the choice between the various alternatives for their rehabilitation and
such programme should be finally selected for execution as would need the total requirements of the
families of freed bonded labourers to enable them to cross the poverty line on the one hand and to
prevent them from sliding back to debt bondage on the other.
We would therefore direct the Government of Haryana to draw up a scheme on programme for "a
better and more meaningful rehabilitation of the freed bonded labourers" in the light of the above
guidelines set out by the Secretary to the Government of India, Ministry of Labour in his letter dated
2nd September 1982. The other State Governments are not parties before us and hence we cannot
give any direction to them, but we hope and trust that they will also take suitable steps for the
purpose of securing identification, release and rehabilitation of bonded labourers on the lines
indicated by us in this Judgment.
We are not at all satisfied that the stand taken on behalf of the State of Haryana that there is no
bonded labour at all in the stone quarries and stone crushers is correct. The Report of M/s Ashok
Srivastava and Ashok Panda shows that, according to the statements given by some of the workers,
they were not allowed to leave the stone quarries and were providing forced labour and this Report
also stated that several persons working in the Ghodhokor and Lakarpur stone quarries were
forcibly kept by the contractors and they were not allowed to move out of their places and were
bonded labourers. The petitioner also filed the affidavits of a large number of workers on 24th
August 1982, each of them stating that he is under heavy debt of the thekedar who does not allow
him to leave the premises without settling the account. We cannot ignore this material which has
been placed before us and unquestioningly accept the statement made on behalf of the State of
Haryana that there is no bonded labour in the stone quarries and stone crushers. But at the same
time, we do not think that it would be right for us on the basis of this material to come to a definiteBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

finding that these workers whose names are given in the Report of M/s Ashok Srivastava and Ashok
Panda or who have filed affidavits are providing forced labour or are bonded labourers. It is
necessary to direct a further inquiry for the purpose of ascertaining whether any of the labourers
working in the stone quarries and stone crushers in Faridabad District are bonded labourers in the
light of the law laid down by us in this judgment. We would therefore direct Shri Laxmi Dhar Misra,
Joint Secretary in the Ministry of Labour, Government of India, who has considerable experience of
the work of identification, release and rehabilitation of bonded labourers, to visit the stone quarries
and stone crushers in Faridabad District and ascertain by enquiring from the labourers in each
stone quarry or stone crusher whether any of them are being forced to provide labour and are
bonded laboureres. While making this inquiry, Shri Laxmi Dhar Misra will take care to see that
when he interviews the labourers either individually or collectively, neither the mine-lessees or
owners of stone crushers nor the thekedar of jamadar nor any one else is present. Shri Laxmi Dhar
Misra will prepare in respect of each stone quarry or stone crusher a statement showing the names
and particulars of those who, according to the inquiry made by him, are bonded labourers and he
will also ascertain from them whether they want to continue to work in the stone quarry or stone
crusher or they want to go back to their homes and if they want to go back, the District Magistrate of
Faridabad will on receipt of the statement from Shri Laxmi Dhar Misra, make necessary
arrangements for releasing them and provide for their transportation back to their hromes and for
this purpose the State Government shall make the requisite funds available to the District
Magistrate. Shri Laxmi Dhar Misra will also enquire from the mine-lessees and owners of stone
crushers as also from the thekedar or jamadar whether there are any advances made by them to the
labourers working in the stone quarry or stone crusher and if so, whether there is any documentary
evidence in support of the same and he will also ascertain what, according to the mine-lessees and
owners of stone crushers or the jamadar or thekedar, are the amounts of loans still remaining
outstanding against such labourers. Shri Laxmi Dhar Misra will submit his report to this Court on or
before 28th February 1984. We may make it clear that the object and purpose of this inquiry by Shri
Laxmi Dhar Misra is not to fasten any liability on the minelessees and owners of stone crushers and
the jamadar or thekedar on the basis of the Report of Shri Laxmi Dhar Misra but to secure the
release and repatriation of those labourers who claim to be bonded labourers and who want to leave
the employment and go some where else. We may point out that the problem of bonded labourers is
a difficult problem because unless, on being freed from bondage, they are provided proper and
adequate rehabilitation, it would not help to merely secure their release. Rather in such cases it
would be more in their interest to ensure proper working conditions with full enjoyment of the
benefits of social welfare and labour laws so that they can live a healthy decent life. But of course
this would only be the next best substitute for release and rehabilitation which must receive the
highest priority.
So far as implementation of the provisions of the Minimum Wages Act 1948 is concerned we would
direct the Central Government and State of Haryana to take necessary steps for the purpose of
ensuring that minimum wages are paid to the workmen employed in the stone quarries and stone
crushers in accordance with the principles laid down by us in this judgment. It may not be a matter
of any consequence as to which mode of payment is followed, whether the workmen are paid on
truck basis or on any other basis, but what is essential is and that is what the Minimum Wages Act
1948 requires that the workmen must not receive any wage less than the minimum wage. Even ifBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

payment of wages is made to the workmen on truck basis, a formula would have to be evolved by the
Central Government and the State of Haryana to ensure that the workmen receive no less than the
minimum wage and to facilitate this formula it would have to be provided that the expenses on
explosives and drilling holes shall be borne by the mine-lessees and or the jamadar or thekedar and
the work of drilling holes and shot firing shall be entrusted only to those who have received requisite
training under the Mines Vocational Training Rules 1966. We would direct the Central Government
and the State of Haryana to take the necessary steps in this behalf so that within the shortest
possible time and as far as possible within six weeks from today the workmen start actually receiving
in their hands a wage not less than the minimum wage. If payment of wages is continued to be made
on truck basis, it is necessary that the appropriate officer of the Central Enforcement Machinery
must determine the measurement of each truck as to how many cubic feet of stone it can contain
and print or inscribe such measurement on the truck, so that appropriate and adequate wage is
received by the workmen for the work done by them and they are not cheated out of their legitimate
wage. We would also direct the inspecting officers of Central Enforcement Machinery to carry out
surprise checks for the purpose of ensuring that the trucks are not loaded beyond their true
measurement capacity. Such surprise checks shall be carried out by the inspecting officers of the
Central Enforcement Machinery at least once in a week and if it is found that the trucks are loaded
in excess of their true measurement capacity and the workmen are thereby deprived of their
legitimate wages, the inspecting officers carrying out such checks will immediately bring this fact to
the notice of the appropriate authorities for initiation of necessary action against the defaulting
mine owners and/or thekedar or jamadar. We would also direct the Central Government and the
State of Haryana to ensure that payment of wage is made directly to the workmen by the
mine-lessees and stone-crusher owners or at any rate in the presence of a representative of the
mine-lessees and stone crushers owners and the inspecting officers of the Central Government as
also of the State of Haryana shall carry out periodic checks in order to ensure that payment of the
stipulated wage is made to the workmen. Shri Laxmi Dhar Misra will also, while holding an inquiry
pursuant to this order, ascertain, by carrying out sample check, whether the workmen employed in
any particular stone quarry or stone crusher are actually in receipt of wage not less than the
minimum wage and whether the directions given by us in this order are being implemented by the
authorities.
There are also two other matters in respect of which it is necessary for us to give directions. The first
is that, apart from poverty and helplessness, one additional reason why the workmen employed in
stone quarries and stone crushers are deprived of the rights and benefits conferred upon them
under various social welfare laws enacted for their benefit and are subjected to deception and
exploitation, in that they are totally ignorant of their rights and entitlements. It is this ignorance
which is to some extent responsible for the total denial of the rights and benefits conferred upon
them. It is therefore necessary to educate the workmen employed in stone quarries and stone
crushers so that they become aware as to what are the rights and benefits to which they are entitled
under the various social welfare laws. The knowledge of their rights and entitlements will give them
the strength to fight against their employers for securing their legitimate dues and it will go a long
way towards reducing, if not eliminating, their exploitation. We have fortunately in our country the
Central Board of Workers Education which is entrusted with the function of educating workers in
their rights and entitlements and we would therefore direct the Central Board of Workers EducationBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

to organise periodic camps near the sites of stone quarries and stone crushers in Faridabad District
for the purpose of creating awareness amongst the workmen about the rights and benefits conferred
upon them by social welfare laws. This educational campaign shall be taken up by the Central Board
of Workers Education as early as possible and the progress made shall be reported to this Court by
the Central Board of Workers Education from time to time, at least once in three months.
The other matter in regard to which we find it necessary to give directions relates to the tremendous
pollution of air by dust thrown out as a result of operation of the stone crushers. When the stone
crushers are being operated, they continually throw out large quantities of dust which not only
pollute the air, but also affect the visibility and constitute a serious health hazard to the workmen.
The entire air in the area where stone crushers are being operated is heavily laden with dust and it is
this air which the workmen breathe day in and day out and it is no wonder that many of them
contract tuberculosis. We would therefore direct the Central Government and the State of Haryana
to immediately take steps for the purpose of ensuring that the stone crushers owners do not
continue to foul the air and they adopt either of two devices, namely, keeping a drum of water above
the stone crushing machine with arrangement for continues spraying of water upon it or installation
of dust sucking machine. This direction shall be carried out by the Central Government and the
State of Haryana in respect of each stone crusher in the Faridabad District and a compliance report
shall be made to this Court on or before 28th February, 1984.
So far as the provisions of the Contract Labour Act and the Inter-State Migrant Workmen Act are
concerned, we have already discussed those provisions and pointed out in what circumstances those
provisions would be applicable in relation to workmen employed in the stone quarries and stone
crushers. It is not possible for us on the material on record to come to a definite finding whether the
provisions of the Contract Labour Act and the Inter-State Migrant Workmen Act are applicable in
the case of any particular stone quarry or stone crusher, because it would be a matter for
investigation and determination, particularly since it has been disputed by the Central Government
that there are any inter-State migrant workmen at all in any of the stone quarries or stone crushers.
We would therefore direct Shri Laxmi Dhar Misra to conduct an inquiry in each of the stone
quarries and stone crushers in Faridabad District for the purpose of ascertaining whether there are
any contract labourers or inter-State migrant workmen in any of these stone quarries or stone
crushers, in the light of the interpretation laid down by us in this judgment, and, if so, what is the
number of such contract labourers or inter-State migrant workmen in each stone quarry or stone
crusher. If Shri Laxmi Dhar Misra finds as a result of his inquiry that the Contract Labour Act
and/or the Inter-State Migrant Workmen Act is applicable, he will make a report to that effect to the
Court on or before 15th February 1984. We may make it clear that this inquiry by Shri Laxmi Dhar
Misra is not directed for the purpose of fastening any liability on the mine-lessees and stone crusher
owners or the jamadars and thekedars proprio vigore on the basis of such report, but merely for the
purpose of considering whether a prima facie case exists on the basis of which action can be initiated
by the Central Government, in which the mine- lessees and stone crusher owners and/or the
jamadars or thekedars would have an opportunity of contesting the allegation that the Contract
Labour Act and/or the Inter- State Migrant Workmen Act applies to their stone quarry or stone
crusher and defending such action.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

We may now take up a few specific complaints urged on behalf of the workmen. The first complaint
relates to the failure to provide pure drinking water to the workmen in most of the stone quarries
and stone crushers. The Report of M/s Ashok Srivastava and Ashok Panda as also the Report made
by Dr. Patwardhan shows that pure drinking water is not made available to the workmen. In
Lakarpur mines the workmen are obliged to take water "from a shallow rivulet covered with thick
algae" and that too, "after a walk over a dangerously steep incline". The same situation also prevails
in the mine in the Gurukul area as also in the Anangpur mines and in these mines "quite often the
upstream and the further down-stream of the rivulet get blocked due to mining of stone and the
water becomes stagnant" and the workmen have no other option but to use this water for drink king
purposes. It is true that in the lower reaches of Lakarpur near the road there is a tube-well from
which the workmen get water but that is only when they are permitted to do so by the persons
operating it. The Report of Dr. Patwardhan also points out that it is the children or women of the
workmen who are usually engaged in the work of transporting water from distant places like the
tubewell but they are not paid anything for this work which is being done by them. Neither any
mine-lessee or stone crusher owner nor any jamadar or thekedar regards it as his duty to make
provision for drinking water for the workmen nor does any officer of the Central Government or of
the State Government bother to enforce the provisions of law in regard to supply of drinking water.
It is clear that, quite apart from the provisions of the Contract Labour Act and the Inter-State
Migrant Workmen Act, there is a specific prescription in section 19 of the Mines Act 1952 and Rules
30 to 32 of the Mines Rules 1955 that the mine-lessees and stone crusher owners shall make
effective arrangements for providing and maintaining at suitable points conveniently situated a
sufficient supply of cool and wholesome drinking water for all workmen employed in the stone
quarries and stone crushers. The quality of drinking water to be provided by them has to be on a
scale of at least 2 litres for every person employed at any one time and such drinking water has to be
readily available at conveniently accessible points during the whole of the working time. Rule 31
requires that if drinking water is not provided from taps connected with constant water supply
system, it should be kept cool in suitable vessels sheltered from weather and such vessels must be
emptied, cleaned and refilled every day and steps have to be taken to preserve the water, the storage
vessels and the vessels used for drinking water in clean and hygienic condition. The inspectors may
also by order in writing require the mine-lessees and stone crusher owners to submit with the least
possible delay a certificate from a competent health officer or analyst as to the fitness of the water
for human consumption. This obligation has to be carried out by the mine-lessees and stone crusher
owners and it is the responsibility of the Central Government as also of the State of Haryana to
ensure that this obligation is immediately carried out by the mine-lessees and stone crusher owners.
We would therefore direct the Central Government and the State of Haryana to ensure immediately
that the mine-lessees and stone crusher owners start supplying pure drinking water to the workmen
on a scale of at least 2 litres for every workman by keeping suitable vessels in a shaded place at
conveniently accessible points and appointing some one, preferably, amongst the women and/or
children of the workmen to look after these vessels. The Central Government and the State of
Haryana will also take steps for ensuring that the vessels in which drinking water is kept by the
mine-lessees and stone crusher owners are kept in clea and hygienic condition and are emptied,
cleaned and refilled every day and they shall also ensure that minimum wage is paid to the women
and/or children who look after the vessels. The Chief Labour Commissioner, the Deputy Chief
Labour Commissioner, the Assistant Labour Commissioner and the Labour Enforcement Officers ofBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

the Government of India as also the appropriate inspecting officers of the Government of Haryana
shall supervise strictly the enforcement of this obligation and initiate necessary action if there is any
default. The Central Government as also the State of Haryana will also immediately direct the
mine-lessees and stone-crusher owners to start obtaining drinking water from any unpolluted
source or sources of supply and to transport it by tankers to the works site with sufficient frequency
so as to be able to keep the vessels filled up for supply of clean drinking water to the workmen. The
Chief Administrator, Faridabad Complex is directed to set up the points from where the
mine-lessees and stone crusher owners can, if necessary, obtain supply of potable water for being
carried by tankers. These directions given by us shall be promptly and immediately carried out by
the appropriate authorities and Shri Laxmi Dhar Misra will, while conducting his inquiry, also
ascertain whether these directions have been carried out and pure drinking water has been made
available to the workmen in accordance with these directions and submit a report in that behalf to
the Court on or before 28th February 1984.
The second complaint related to the failure to provide conservancy facilities to the workmen in the
stone quarries and stone crushers. Section 20 of the Mines Act 1952 requires that there shall be
provided separately for males and females a sufficient number of latrines and urinals of prescribed
types so situated as to be convenient and accessible to persons employed in the stone quarries and
stone crushers and all such latrines and urinals shall be adequately lighted, ventilated and at all
times maintained in a clean and sanitary condition. What should be the number of latrines and
urinals to be provided in each stone quarry or stone crusher and what should be the standard of
construction to be complied with in erecting the latrines are provided in Rules 33 to 35 of the Mines
Rules 1955 and Rule 36 provides that a sufficient number of water taps conveniently accessible shall
be provided in or near such latrines and if piped water supply is not available, then a sufficient
quantity of water shall be hept stored in suitable receptacles near such latrines. The Report of Dr.
Patwardhan shows that there is not a trace of such conservancy facilities in any of the stone quarries
and the "vast open mountain dug-up without a thought as to environment is used by men and
women and children as one huge open latrine" where the only privacy is that provided by the
"curtain drawn by the turned down eyes of women and the turned away eyes of men". This
statement made in the Report of Dr. Patwardhan has not been denied in any of the affidavits in reply
filed on behalf of the respondents. We would therefore direct the Central Government as also the
State Government to ensure that conservancy facilities in the shape of latrines and urinals in
accordance with the provisions contained in Section 20 of the Mines Act 1950 and Rules 33 to 36 of
the Mines Rules 1955 are provided immediately by mine lessees and owners of stone crushers. This
direction shall be carried out at the earliest without any delay and Shri Laxmi Dhar Misra will, while
making his inquiry, ascertain whether the mine-lessees and owners of stone crushers in each of the
stone quarries and stone crushers visited by him have complied with this direction and a Report in
that behalf shall be submitted by Shri Laxmi Dhar Misra on or before 28th February, 1984.
There was also one other complaint made on behalf of the workmen and that related to the absence
of any medical or first aid facilities. The Report of Dr. Patwardhan shows that no such facilities are
provided to the workmen employed in the stone quarries and stone crushers and this finding was
not seriously disputed on behalf of the respondents. It is indeed regrettable that despite there being
a mandatory provision for medical and first aid facilities in Section 21 of the Mines Act 1952 andBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Rules 40 to 45A of the Mines Rules 1955, no medical or first aid facilities seem to be provided in the
stone quarries and stone crushers. We would therefore direct the Central Government as also the
State Government to take steps to immediately ensure that proper and adequate medical and first
aid facilities as required by Section 21 of the Mines Act 1952 and Rules 40 to 45A of the Mines Rules
1955 are provided by the mine-lessees and owners of stone quarries to the workmen. Rule 45
provides that every shot firer and blaster in a mine shall hold first aid qualification specified in Rule
41 and shall carry, while on duty, a first aid outfit consisting of one large sterilized dressing and an
amul of tincture of iodine or other suitable antiseptic. But we find that this requirement is also not
observed by the mine-lessees and stone crusher owners and the workmen are required to carry on
blasting with explosives without any first aid qualification or first aid outfit. We would therefore
direct the Central Government as also the State of Haryana to ensure that every workman who is
required to carry out blasting with explosives should not only be trained under the Mines Vocational
Training Rules 1966 but should also hold first aid qualification and he should carry a first aid outfit,
while on duty, as required by Rule 45. The Central Government and the State Government will also
take steps to secure that proper and adequate medical treatment is provided by the mine-lessees and
owners of stone crushers to the workmen employed by them as also to the members of their families
and such medical assistance should be made available to them without any cost of transportation or
otherwise and the cost of medicines prescribed by the doctors must be reimbursed to them. Where
the workmen or the members of their families meet with any serious accident involving fracture or
possibility of disability or suffer from any serious illness, the mine- lessees and owners of stone
crushers should be required by the Central Government as also the State Government to make
arrangements for hospitalisation of such workmen or members of their families at the cost of the
mine-lessees and/or owners of stone crushers. We would also direct the Central Government and
the State of Haryana to ensure that the provisions of the Maternity Benefit Act, 1961, the Maternity
Benefit (Mines and Circus) Rules 1963 and the Mines Creche Rules, 1966, where applicable in any
particular stone quarries or stone crushers,, are given effect to by the mine-lessees and owners of
stone crushers. These directions given by us shall also be carried out at the earliest without any
undue delay and Shri Laxmi Dhar Misra, while conducting his inquiry, will ascertain whether these
directions have been complied with and the necessary medical and first aid facilities including
hospitalization have been provided to the workmen and the members of their families.
We may point out that the above directions in regard to provision of health and welfare facilities
have been given by us only with reference to the provisions of the Mines Act 1952 and the Mines
Rules 1955 which are admittedly applicable in the case of stone quarries and stone crushers. We
have not given any directions for enforcement of the provisions of the Contract Labour Act and the
Inter-State Migrant Workmen Act because it has yet to be determined whether these two statutes
are applicable in any particular stone quarry or stone crusher. It is also necessary to point out that
whenever any workman suffers any injury or contracts any disease in the course of employment, he
is entitled to compensation under the Workmens' Compensation Act 1923, but unfortunately he is
very often not in a position to approach the appropriate court or authority for enforcing his claim to
compensation and even if he files such a claim, it takes a long time before such claim is disposed of
by the court or authority. We would therefore direct that as soon as any workman employed in a
stone quarry or stone crusher receives injury or contracts disease in the course of his employment,
the concerned mine-lessee or stone crusher owner shall immediately report this fact to the ChiefBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Inspector or Inspecting Officers of the Central Government and/or the State Government and such
Inspecting Officers shall immediately provide legal assistance to the workman with a view to
enabling him to file a claim for compensation before the appropriate court or authority and they
shall also ensure that such claim is pursued vigorously and the amount of compensation awarded to
the workman is secured to him. We would like to impress upon the Court or Authority before which
a claim for compensation is filed by or on behalf of the workman to dispose of such claim without
any undue delay, since delay in the awarding of compensation to the workman would only and to his
misery and helplessness and would be nothing sort of gross denial of justice to him. The Inspecting
Officers of the Central Government as also of the State Government will visit each stone quarry or
stone crusher at least once in a fortnight and ascertain whether there is any workman who is injured
or who is suffering from any disease or illness, and if so, they will immediately take the necessary
steps for the purpose of providing medical and legal assistance and if they fail to do so, the Central
Government and the State Government, as the case may be, shall take unnecessary action against
the defaulting Inspecting Officer or Officers.
We have given these directions to the Central Government and the State of Haryana and we expect
the Central Government and the State of Haryana to strictly comply with these directions. We need
not state that if any of these directions is not properly carried out by the Central Government or the
State of Haryana, we shall take a very serious view of the matter, because we firmly believe that it is
no use having social welfare laws on the statue book if they are not going to be implemented. We
must not be content with the law in books but we must have law in action. If we want our democracy
to be a participatory democracy, it is necessary that law must not only speak justice but must also
deliver justice.
Before parting with this case, we may point out, and this has come to our notice not only through the
Report of Dr. Patwardhan but also otherwise, that the magistrates and judicial officers take a very
lenient view of violations of labour laws enacted for the benefits of the workmen and let off the
defaulting employers with small fines. There have also been occasions where the magistrate and
judicial officers have scotched prosecutions and acquitted or discharged the defaulting employers on
hyper technicalities. This happens largely because the magistrates and judicial officers are not
sufficiently sensitised to the importance of observance of labour laws with the result that the labour
laws are allowed to be ignored and breached with utter callousness and indifference and the
workmen begin to feel that the defaulting employers can, by paying a fine which hardly touches their
pocket, escape from the arm of law and the labour laws supposedly enacted for their benefit are not
meant to be observed but are merely decorative appendages intended to assuage the conscience of
the workmen. We would therefore strongly impress upon the magistrates and judicial officers to
take a strict view of violation of labour laws and to impose adequate punishment on the erring
employers so that they may realise that it does not pay to commit a breach of such laws and to deny
the benefit of such laws to the workmen.
We accordingly allow this writ petition and issue the above directions to the Central Government
and the State of Haryana and the various authorities mentioned in the preceding paragraphs of this
judgment so that these poor unfortunate workmen who lead a miserable existence in small hovels,
exposed to the vagaries of weather, drinking foul water, breathing heavily dust-laden polluted airBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

and breaking and blasting stone all their life, may one day be able to realise that freedom is not only
the monopoly of a few but belongs to them all and that they are also equally entitled along with
others to participate in the fruits of freedom and development. These directions may be summarized
as follows (1) The Government of Haryana will, without any delay and at any rate within six weeks
from today, constitute Vigilance Committee in each sub- division of a district in compliance with the
requirements of section 13 of the Bonded Labour System (Abolition) Act 1976 keeping in view the
guidelines given by us in this judgment.
(2) The Government of Haryana will instruct the district magistrates to take up the work of
identification of bonded labour as one of their top priority tasks and to map out areas of
concentration of bonded labour which are mostly to be found in stone quarries and brick kilns and
assign task forces for identification and release of bonded labour and periodically hold labour camps
in these areas with a view to educating the labourers inter alia with the assistance of the National
Labour Institute. (3) The State Government as also the Vigilance Committees and the district
magistrates will take the assistance of non-political social action groups and voluntary agencies for
the purpose of ensuring implementation of the provisions of the Bonded Labour System (Abolition)
Act, 1976. (4) The Government of Haryana will draw up within a period of three months from today
a scheme or programme for rehabilitation of the freed bonded labourers in the light of the
guidelines set out by the Secretary to the Government of India, Ministry of Labour in his letter dated
2nd September 1982 and implement such scheme or programme to the extent found necessary.
(5) The Central Government and the Government of Haryana will take all necessary steps for the
purpose of ensuring that minimum wages are paid to the workmen employed in the stone quarries
and stone crushers in accordance with the principles laid down in this judgment and this direction
shall be carried out within the shortest possible time so that within six weeks from today, the
workmen start actually receiving in their hands a wage not less than the minimum wage.
(6) If payment of wages is made on truck basis, the Central Government will direct the appropriate
officer of the Central Enforcement Machinery or any other appropriate authority or officer to
determine the measurement of each truck as to how many cubic ft. of stone it can contain and print
or inscribe such measurement on the truck so that appropriate and adequate wage is received by the
workmen for the work done by them and they are not cheated out of their legitimate wage.
(7) The Central Government will direct the inspecting officers of the Central Enforcement
Machinery or any other appropriate inspecting officers to carry out surprise checks at least once in a
week for the purpose of ensuring that the trucks are not loaded beyond their true measurement
capacity and if it is found that the trucks are loaded in excess of the true measurement capacity, the
inspecting officers carrying out such checks will immediately bring this fact to the notice of the
appropriate authorities and necessary action shall be initiated against the defaulting mine owners
and/or thekedars or jamadars.
(8) The Central Government and the Government of Haryana will ensure that payment of wages is
made directly to the workmen by the mine lessees and stone crusher owners or at any rate in the
presence of a representative of the mine lesseses or stone crusher owners and the inspecting officersBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

of the Central Government as also of the Government of Haryana shall carry out periodic checks in
order to ensure that the payment of the stipulated wage is made to the workmen.
(9) The Central Board of Workers Education will organise periodic camps near the sites of stone
quarries and stone crushers in Faridabad district for the purpose of educating the workmen in the
rights and benefits conferred upon them by social welfare and labour laws and the progress made
shall be reported to this Court by the Central Board of Workers Education at least once in three
months.
(10) The Central Government and the Government of Haryana will immediately take steps for the
purpose of ensuring that the stone crusher owners do not continue to foul the air and they adopt
either of two devices, namely,, keeping a drum of water above the stone crushing machine with
arrangement for continuous spraying of water upon it or installation of dust sucking machine and a
compliance report in regard to this direction shall be made to this Court on or before 28th February,
1984.
(11) The Central Government and the Government of Haryana will immediately ensure that the
mine lessees and stone crusher owners start supplying pure drinking water to the workmen on a
scale of at least 2 litres for every work man by keeping suitable vessels in a shaded place at
conveniently accessible points and such vessels shall be kept in clean and hygienic condition and
shall be emptied, cleaned and refilled every day and the appropriate authorities of the Central
Government and the Government of Haryana will supervise strictly the enforcement of this
direction and initiate necessary action if there is any default.
(12) The Central Government and the Government of Haryana will ensure that minimum wage is
paid to the women and/or children who look after the vessels in which pure drinking water is kept
for the workmen.
(13) The Central Government and the Government of Haryana will immediately direct the mine
lessees and stone crusher owners to start obtaining drinking water from any unpolluted source or
sources of supply and to transport it by tankers to the work site with sufficient frequency so as to be
able to keep the vessels filled up for supply of clean drinking water to the workmen and the Chief
Administrator, Faridabad Complex will set up the points from where the mine lessees and stone
crusher owners can, if necessary, obtain supply of potable water for being carried by tankers.
(14) The Central Government and the State Government will ensure that conservancy facilities in the
shape of latrines and urinals in accordance with the provisions contained in section 20 of the Mines
Act, 1950 and Rules 33 to 36 of the Mines Rules 1955 are provided at the latest by 15th February
1984.
(15) The Central Government and the State Government will take steps to immediately ensure that
appropriate and adequate medical and first aid facilities as required by section 21 of the Mines Act
1952 and Rules 40 to 45A of the Mines Rules 1955 are provided to the workmen not later than 31st
January 1984.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

(16) The Central Government and the Government of Haryana will ensure that every workmen who
is required to carry out blasting with explosives is not only trained under the Mines Vocational
Training Rules 1966 but also holds first aid qualification and carries a first aid outfit while on duty
as required by Rule 45 of the Mines Rules 1955.
(17) The Central Government and the State Government will immediately take steps to ensure that
proper and adequate medical treatment is provided by the mine lessees and owners of stone
crushers to the workmen employed by them as also to the members of their families free of cost and
such medical assistance shall be made available to them without any cost of transportation or
otherwise and the doctor's fees as also the cost of medicines prescribed by the doctors including
hospitalisation charges, if any, shall also be reimbursed to them.
(18) The Central Government and the State Government will ensure that the provisions of the
Maternity Benefit Act 1961, the Maternity Benefit (Mines and Circus) Rules 1963 and the Mines
Creche Rules 1966 where applicable in any particular stone quarry or stone crusher are given effect
to by the mine lessees and stone crusher owners.
(19) As soon as any workman employed in a stone quarry or stone crusher receives injury or
contracts disease in the course of his employment, the concerned mine lessee or stone crusher
owner shall immediately report this fact to the Chief Inspector or Inspecting Officers of the Central
Government and/or the State Government and such Inspecting Officers shall immediately provide
legal assistance. to the workman with a view to enabling him to file a claim for compensation before
the appropriate court or authority and they shall also ensure that such claim is pursued vigorously
and the amount of compensation awarded to the workman is secured to him.
(20) The Inspecting Officers of the Central Government as also of the State Government will visit
each stone quarry or stone crusher at least once in a fortnight and ascertain whether there is any
workman who is injured or who is suffering from any disease or illness, and if so, they will
immediately take the necessary steps for the purpose of providing medical and legal assistance.
(21) If the Central Government and the Government of Haryana fail to ensure performance of any of
the obligations set out in clauses 11, 13, 14 and 15 by the mine lessees and stone crusher owners
within the period specified in those respective clauses, such obligation or obligations to the extent to
which they are not performed shall be carried out by the Central Government and the Government
of Haryana.
We also appoint Shri Laxmi Dhar Misra, Joint Secretary in the Ministry of Labour, Government of
India as a Commissioner for the purpose of carrying out the following assignment.
(a) He will visit the stone quarries and stone crushers in Faridabad district and ascertain by
enquiring from the labourers in each stone quarry or stone crusher in the manner set out by us
whether any of them are being forced to provide labour and are bonded labourers and he will
prepare in respect of each stone quarry or stone crusher a statement showing the names and
particulars of those who, according to the inquiry made by him, are bonded labourers and he willBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

also ascertain from them whether they want to continue to work in the stone quarry or stone crusher
or they want to go away and if he finds that they want to go away, he will furnish particulars in
regard to them to the District Magistrate, Faridabad and the District Magistrate will, on receipt of
the particulars from Shri Laxmi Dhar Misra, make necessary arrangements for releasing them and
provide for their transporation back to their homes and for this purpose the State Government will
make the requisite funds available to the District Magistrate.
(b) He will also enquire from the mine lessees and owners of stone crushers as also from the
thekedars and jamadars whether there are any advances made by them to the labourers working in
the stone quarries or stone crushers and if so, whether there is any documentary evidence in support
of the same and he will also ascertain what, according to the mine lessees and owners of stone
crushers or the Jamadar or Thekedar, are the amounts of loans still remaining outstanding against
such labourers.
(c) He will also ascertain by carrying out sample check whether the workmen employed in any
particular stone quarry or stone crusher are actually in receipt of wage not less than the minimum
wage and whether the directions given in this order in regard to computation and payment of
minimum wage are being implemented by the authorities.
(d) He will conduct an inquiry in each of the stone quarries and stone crushers in Faridabad District
for the purpose of ascertaining whether there are any contract labourers or inter-State migrant
workmen in any of these stone. quarries or stone crushers and if he finds as a result of his inquiry
that the Contract Labour Act and/or the Inter State Migrant Workmen Act is applicable, he will
make a report to that effect to the Court.
(e) He will ascertain whether the directions given by us in this judgment regarding effective
arrangement for supply of pure drinking water have been carried out by the mine lessees and stone
crusher owners and pure drinking water has been made available to the workmen in accordance
with those directions.
(f) He will also ascertain whether the mine lessees and owners of stone crushers in each of the stone
quarries and stone crushers visited by him have complied with the directions given by us in this
judgment regarding provision of conservancy facilities.
(g) He will also ascertain whether the directions given by us in this judgment in regard to provision
of first aid facilities and proper and adequate medical treatment including hospitalisation to the
workmen and the members of their families are being carried out by the mine lessees and stone
crusher owners and the necessary first aid facilities and proper and adequate medical services
including hospitalisation are provided to the workmen and the members of their families.
(h) He will also enquire whether the various other directions given by us in this judgment have been
and are being carried out by the mine lessees and stone crusher owners.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Shri Laxmi Dhar Misra will carry out this assignment entrusted to him and make his report to the
Court on or before 28th February 1984. It will be open to Shri Laxmi Dhar Misra to take the
assistance of such other person or persons as he thinks fit including officers or employees in the
Ministry of Labour or in the Ministry of Mines, who may be made available by the higher
authorities. If Shri Laxmi Dhar Misra finds it necessary, he may request the Court to extend the time
for submitting his report by addressing a letter to the Registry of the Court. The State of Haryana
will deposit a sum of Rs. 5000 within two weeks from today for the purpose of meeting the costs and
out of pocket expenses of Shri Laxmi Dhar Misra.
We have no doubt that if these directions given by us are honestly and sincerely carried out, it will be
possible to improve the life conditions of these workmen and ensure social justice to them so that
they may be able to breathe the fresh air of social and economic freedom. The Central Government
and the State of Haryana will pay to the petitioner's advocate a sum of Rs. 5000 by way of costs. We
are grateful to Mr. Govind Mukhoty for rendering valuable assistance to us in this case.
PATHAK, J. I have read the judgments prepared by my brothers Bhagwati and A.N. Sen, and while I
agree with the directions proposed by my brother Bhagwati I think it proper, because of the
importance of the questions which arise in such matters, to set forth my own views.
Public interest litigation in its present form constitutes a new chapter in our judicial system. It has
acquired a significant degree of importance in the jurisprudence practised by our courts and has
evoked a lively, if somewhat controversial, response in legal circles, in the media and among the
general public. In the United States, it is the name "given to efforts to provide legal representation to
groups and interests that have been unrepresented or under-represented in the legal process. These
include not only the poor and the disadvantaged but ordinary citizens who, because they cannot
afford lawyers to represent them, have lacked access to courts, administrative agencies and other
legal forums in which basic policy decisions affecting their interests are made".(1) In our own
country, this new class of litigation is justified by its protagonists on the basis generally of vast areas
in our population of illiteracy and poverty, of social and economic backwardness, and of an
insufficient awareness and apprecia-
tion of individual and collective rights. These handicaps have denied millions of our countrymen
access to justice. Public interest litigation is said to possess the potential of providing such access in
the milieu of a new ethos, in which participating sectors in the administration of justice co-operate
in the creation of a system which promises legal relief without cumbersome formality and heavy
expenditure. In the result, the legal organisation has taken on a radically new dimension and
correspondingly new perspectives are opening up before judges and lawyers and State Law agencies
in the tasks before them. A crusading zeal is abroad, viewing the present as an opportunity to
awaken the political and legal order to the objectives of social justice projected in our constitutional
system. New slogans fill the air, and new phrases have entered the legal dictionary, and we hear of
the "justicing system" being galvanised into supplying justice to the socioeconomic disadvantaged.
These urges are responsible for the birth of new judicial concepts and the expanding horizon of
juridical power. They claim to represent an increasing emphasis on social welfare and a progressive
humanitarianism.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

On the other side, the attempts of the judge and the lawyer are watched with skeptical concern by
those who see interference by the courts in public interest litigation as a series of quixotic forays in a
world of unyielding and harsh reality, whose success in the face of opposition bolstered by the
inertia and apathy of centuries is bound to be limited in impact and brief in duration. They see
judicial endeavour frustrated by the immobility of public concern and a traditional resistance to
change, and believe that the temporary success gained is doomed to waste away as a mere ripple in
the vastness of a giant slow-moving society. Even the optimistic sense danger to the credibility and
legitimacy of the existing judicial system, a feeling contributed no doubt by the apprehension that
the region into which the judiciary has ventured appears barren, uncharted and unpredictable, with
few guiding posts and direction finding principles, and they fear that a traditionally proven legal
structure may yield to the anarchy of purely emotional impulse. To the mind trained in the certainty
of the law, of defined principles, of binding precedent, and the common law doctrine of Stare decisis
the future is fraught with confusion and disorder in the legal world and severe strains in the
constitutional system. At the lowest, there is an uneasy doubt about where we are going.
Amidst this welter of agitated controversy, I think it appropriate to set down a few considerations
which seem to me relevant if public interest litigation is to command broad acceptance. The history
of human experience shows that when a revolution in ideas and in action enters the life of a nation,
the nascent power so released possesses the potential of throwing the prevailing social order into
disarray. In a changing society, wisdom dictates that reform should emerge in the existing polity as
an ordered change produced through its institutions. Moreover, the pace of change needs to be
handled with care lest the institutions themselves be endangered.
In his Law in the Modern State, Leon Duguit observed:
"Any system of public law can be vital only so far as it is bused on a given sanction to
the following rules: First, the holders of power cannot do certain things; second,
there are certain things they must do." (1) Traditional legal remedies have been
preoccupied largely with the first rule. It is recently that the second has begun
substantially to engage the functional attention of the judicial administration. In the
United States, the Warren Court achieved a remarkable degree of success in
decreeing affirmative action programmes for the benefit of minorities and other
socially or economically disadvantaged interests through the avenues of public law.
In India, we are now beginning to apply a similar concept of constitutional duty.
Until the arrival of public interest litigation,' civil litigation was patterned exclusively
on the traditional model. The traditional conception of adjudication believes a suit to
be a means for settling disputes between private parties concerning their private
rights. In the usual form, the suit is an organised proceeding between two individual
contestants. It deals with a definite framework of facts requiring identification
through principles codified by statute and on the basis of which the right-obligation
relations between the parties are determined, culminating in the grant or denial of
relief by the Court, It is a proceeding confined to the parties, on whose volition
depends the fact material brought on the record, with the judge sitting over theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

contest as a mere passive neutral umpire. Judicial initiative has no significant role.
The rigid character of civil litigation conceived as a contests between two individual
parties representing their personal interests has been allowed to expand into a
representative proceeding where a person can, with the permission of the Court,
represent others also having the same interest although not named in the suit. And
the disability, temporary or permanent, of a person whose legal right is violated,
enables another to represent his interest in a judicial proceeding. They are cases
where next friends are permitted by the Court to act for minors and persons. of
unsound mind, where a person may petition for the release of an illegally detained
individual, and where a minority shareholder, complaining of an ultra vires
transaction by the management of a company, can sue in the name of the company.
Interveners are allowed to participate in a proceeding involving the decision of legal
questions affecting their interests. A rate payer of a local authority has been held
entitled to challenge its illegal action. A person conferred by statute the right to
participate in the decision-making process of a statutory authority is entitled to seek
relief against such decision. In S.P. Gupta v. Union of India,(1) this Court has laid
down that its jurisdiction can be invoked by a third party in the case of violation of
the constitutional rights of another person or determinate class of persons who, by
reason of poverty, helplessness, disability or social or economic disadvantage is
unable to move the Court personally for relief. The Court observed further that where
the public injury was suffered by an indeterminate class of persons from the breach
of a public duty or from the violation of a constitutional provision of the law, any
member of the public having sufficient interest can maintain an action for judicial
redress for such public injury. The principle was qualified by the reservation that
such petitioner should act bona fide and not for personal gain or private profit, nor be
moved by political or other oblique motivation. The doctrine of standing has thus
been enlarged in this country to provide, where reasonably possible, access to justice
to large sections of people for whom so far it had been a matter of despair.
It is time indeed for the law to do so. In large measure, the traditional conception of
adjudication represented the socioeconomic vision prevailing at the turn of the
century. The expansion of governmental activity into the life of individuals through
programmes of social welfare and development had not yet been foreshadowed. An
environment permeated by the doctrine of laissez faire shaped the development of
legal jurisprudence. But soon, progressive social and economic forces began to grow
stronger and influence the minds of people, and governments, in response to the
pressures of egalitarian and socialist- oriented urges, began to enter increasingly
upon socioeconomic programmes in which legislation and the courts constituted the
principal instruments of change. The movements accelerated with the close of the
Second World War, and a character of human rights was written into the political
constitutions adopted by most nations emerging from colonial rule even as, on
another plane, it altered our basic conception of international law. In India, as the
consciousness of social justice spread though our multi- layered social order, theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

courts began to come under increasing pressure from social action groups petitioning
on behalf of the underprivileged and deprived sections of society for the fulfillment of
their aspirations. It is not necessary to detail the number of cases of public interest
litigation which have entered this Court. It is sufficient to point out that, despite the
varying fortune of those cases, public interest litigation constitutes today a significant
segment of the Court's docket.
In the debate before us, questions of substantial importance have been raised by
learned counsel, questions which go to the procedure adopted by the Court and the
manner of the exercise of its constitutional powers.
This petition invokes the jurisdiction of the Court under Article 32 of the
Constitution, which confers the guaranteed right to move this Court by appropriate
proceedings for the enforcement of fundamental rights. The right exercised is a right
to a constitutional remedy and the jurisdiction invoked is a constitutional
jurisdiction. Bearing this in mind, we must also take into account that the provisions
of Article 32 do not specifically indicate who can move the Court. In the absence of a
confining provision in that respect. It is plain that a petitioner may be anyone in
whom the law recognises a standing to maintain an action of such nature.
As regards the form of the proceeding and its character, Article 32 speaks generally of
a "appropriate proceedings". It should be a proceeding which can appropriately lead
to an adjudication of the claim made for the enforcement of a fundamental right and
can result in the grant of effective relief. Article 32 speaks of the Court's power "to
issue directions or orders or writs", and the specific reference to "writs in the nature
of habeas corpus, mandamus, prohibition, quo warranto and certiorari" is by way of
illustration only. They do not exhaus the content of the Court's power under Article
32.
Entering not into a more controversial area, it is appropriate to consider the nature of
the procedure which the court may adopt under Article 32 of the Constitution. So far
as the traditional private law is concerned, the procedure follows the accepted pattern
and traditional forms associated with it. There can be little dispute there. Does public
interest litigation call for somewhat different considerations ? Before dealing with
this aspect, however, it is necessary to touch on two fundamental matters.
First, as to the petition, A practice has grown in the public of invoking the jurisdiction
of this Court by a simple letter complaining of a legal injury to the author or to some
other person or group of persons, and the Court has treated such letter as a petition
under Article 32 and entertained the proceeding without anything more. It is only
comparatively recently that the Court has begun to call for the filing of a regular
petition on the letter. I see grave danger inherent in a practice where a mere letter is
entertained as a petition from a person whose antecedents and status are unknown or
so uncertain that no sense of responsibility can, without anything more, be attributedBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

to the communication. There is good reason for the insistence on a document being
set out in a form, or accompanied by evidence; indicating that the allegations made in
it are made with a sense of responsibility by a person who has taken due care and
caution to verify those allegations before making them. A plaint instituting a suit is
required by the Code of Civil Procedure to conclude with a clause verifying the
pleadings contained in it. A petition or application filed in court is required to be
supported on affidavit. These safeguards are necessary because the document, a
plaint or petition or application, commences a course of litigation involving the
expenditure of public time and public money, besides in appropriate cases involving
the issue of summons or notice to the defendant or respondent to appear and contest
the proceeding. Men are busy conducting the affairs of their daily lives, and no one
occupied with the responsibilities and pressures of present day existence welcomes
being summoned to a law court and involved in a litigation. A document making
allegations without any proof whatever of responsibility can conceivably constitute an
abuse of the process of law. There is good reason, I think, for maintaining the rule
that, except in special circumstances, the document petitioning the court for relief
should be supported by satisfactory verification. This requirement is all the greater
where petitions are received by the Court through the post. It is never beyond the
bound of possibility that an unverified communication received through the post by
the court may in fact have been employed mala fide, as an instrument of coercion or
blackmail or other oblique motive against a person named therein who holds a
position of honour and respect in society.
The Court must be ever vigilant against the abuse of its process It cannot do that
better in this matter than insisting at the earliest stage, and before issuing notice to
the respondent, that an appropriate verification of the allegations be supplied. The
requirement is imperative in private law litigation. Having regard to its nature and
purpose, it is equally attract to public interest litigation. While this Court has readily
acted upon letters and telegrams in the past, there is need to insist now on an
appropriate verification of the petition or other communication before acting on it.
As I have observed earlier, there may be exceptional circumstances which may justify
a waiver of the rule. For example, when the habeas corpus jurisdiction of the Court is
invoked. For in all cases of illegal detention there is no doubt that the Court must act
with speed and readiness. Or when the authorship of the communication is so
impeccable and unquestionable that the authority of its contents may reasonably be
accepted prima facie until rebutted. It will always be a matter for the Court to decide,
on what petition will it require verification and when will it waive the rule.
Besides this, there is another matter which, although on the surface appears to be of
merely technical significance, merits more than passing attention. I think the time
has come to state clearly that all communications and petitions invoking the
jurisdiction of the Court must be addressed to the entire Court, that is to say, the
Chief Justice and his companion Judges. No such communication of petition can
properly be addressed to a particular Judge. When the jurisdiction of the Court isBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

invoked, it is the jurisdiction of the entire court. Which Judge or Judges will hear the
case is exclusively a matter concerning the internal regulation of the business of the
Court, interference with which by a litigant or member of the public constitutes the
grossest impropriety. It is well established that when a division of the Court hears
and decides cases it is in law regarded as a hearing and a decision by the Court itself.
The judgment pronounced and the decree or order made are acts of the Court, and
accordingly they are respected, obeyed and enforced throughout the land. It is only
right and proper that this should be known clearly to the lay public. Communications
and petitions addressed to a particular Judge are improper and violate the
institutional personality of the Court. They also embarrass the judge to whom they
are personally addressed. The fundamental conception of the Court must be
respected, that it is a single indivisible institution, of united purpose and existing
solely for the high constitutional functions for which it has been created. The
conception of the Court as a loose aggregate of individual Judges, to one or more of
whom judicial access may be particularly had, undermines its very existence and
endangers its proper and effective functioning.
I shall now turn to the character and incidents of the procedure open to the Court in
public interest litigation and the nature of the power exercised by it during the
proceeding. In public interest litigation, the role held by the Court is more assertive
than in traditional actions. During the regime of the Warran Court in the United
States, it proceeded to the point where affirmative programmes were envisaged, and
the relationship between right and remedy was freed from the rigid intimacy which
constitutes a fundamental feature of private law litigation. While remedial procedure
was fashioned according to the demands of the case and varied from stage to stage, in
the shaping of relief the court treated with the future and devised a code of regulatory
action. Viewed in that context, the role of the Court is creative rather than passive
and it assumes a more positive attitude in determining facts.
Not infrequently public interest litigation affects the rights of persons not before the
court, and in shaping the relief the court must invariably take into account its impact
on those interests. Moreover, when its jurisdiction is invoked on behalf of a group, it
is as well to remember that differences may exist in content and emphasis between
the claims of different sections of the group. For all these reasons the court must
exercise the greatest caution and adopt procedures ensuring sufficient notice to all
interests likely to be affected. Moreover, the nature of the litigation sometimes
involves the continued intervention of the court over a period of time, and the
organising of the litigation to a satisfactory conclusion calls for judicial
statesmanship, a close understanding of constitutional and legal values in the context
of contemporary social forces, and a judicious mix of restraint and activism
determined by the dictates of existing realities. Importantly, at the same time, the
Court must never forget that its jurisdiction extends no farther than the legitimate
limits of its constitutional powers, and avoid trespassing into political territory which
under the Constitution has been appropriated to other organs of the State. This lastBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

aspect of the matter calls for more detailed consideration, which will be attempted
later.
The procedures adopted by the Court in cases of public interest litigation must of
course be procedures designed and shaped by the Court with a view to resolving the
problem presented before it and determining the nature and extent of relief
accessible in the circumstances. On the considerations to which I have adverted
earlier, the Court enjoys a degree of flexibility unknown to the trial of traditional
private law litigation. But I think it necessary to emphasis that whatever the
procedure adopted by the court it must be procedure known to judicial tenets and
characteristic of a judicial proceeding. There are methods and avenues of procuring
material available to executive and legislative agencies, and often employed by them
for the efficient and effective discharge of the tasks before them. Not all those
methods and avenues are available to the Court. The Court must ever remind itself
that one of the indicia identifying it as a Court is the nature and character of the
procedure adopted by it in determining a controversy. It is in that sense limited in the
evolution of procedures pursued by it in the process of an adjudication and in the
grant and execution of the relief. Legal jurisprudence has in its historical
development identified certain fundamental principles which form the essential
constituents of judicial procedure. They are employed in every judicial proceeding,
and constitute the basic infrastructure along whose channels flows the power of the
Court in the process of adjudication What should be the conceivable framework of
procedure in public interest litigation ? This question does not admit of a clear cut
answer. As I have observed earlier, it is not possible to envisage a defined pattern of
procedure applicable to all cases. Of necessity the pattern which the Court adopts will
vary with the circumstances of each case. But it seems to me that one principle is
clear. If there is a statute prescribing a judicial procedure governing the particular
case the Court must follow such procedure. It is not open to the Court to bypass the
statute and evolve a different procedure at variance with it. Where, however, the
procedure prescribed by statute is incomplete or insufficient, it will be open to the
Court to supplement it by evolving its own rules, Nonetheless, the supplementary
procedure must conform at all stages to the principles of natural justice. There can be
no deviation from the principles of natural justice and other well accepted procedural
norms characteristic of a judicial proceeding. They constitute an entire code of
general principles of procedure, tried and proven and hallowed by the sanctity of
common and consistent acceptance during long years of the historical development
of the law. The general principles of law, to which reference is made here, command
the confidence, not merely of the Judge and the lawyer and the parties to the
litigation, but supply that basic credibility to the judicial proceeding which
strengthens public faith in the Rule of Law. They are rules rooted in reason and
fairplay, and their governance guarantees a just disposition of the case. The court
should be wary of suggestions favouring novel procedures in cases where accepted
procedural rules will suffice.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Turning now to the nature and extent of the relief which can be contemplated in
public interest litigation, we enter into an area at once delicate and sensitive and
fraught with grave implications. Article 32 confers the widest amplitude of power on
this Court in the matter of granting relief. It has power to issue "directions or orders
or writs", and there is no specific indication, no express language, limiting or
circumscribing that power. Yet, the power is limited by its very nature, that it is
judicial power. It is power which pertains to the judicial organ of the State, identified
by the very nature of the judicial institution. There are certain fundamental
constitutional concepts which, although elementary, need to be recalled at times. The
Constitution envisages a broad division of the power of the State between the
legislature, the executive and the judiciary. Although the division is not precisely
demarcated, there is general acknowledgment of its limits. The limits can be gathered
from the written text of the Constitution, from conventions and constitutional
practice, and from an entire array of judicial decisions. The constitutional lawyer
concedes a certain measure of overlapping in functional action among the three
organs of the State. But there is no warrant for assuming a geometrical congruence. It
is common place that while the legislature enacts the law, the executive implements it
and the court interprets it and, in doing so, adjudicates on the validity of executive
action and, under our Constitution, even judges the validity of the legislation itself.
And yet it is well recognised that in a certain sphere the legislature is possessed of
judicial power, the executive possesses a measure of both legislative an judicial
functions, and the court, in its duty of interpreting the law, accomplishes in its
perfected action a marginal degree of legislative exercise. Nonetheless, a fine and
delicate balance is envisaged under our Constitution between these primary
institutions of the State. In similar Constitutions elsewhere the courts have been
anxious to maintain and preserve that balance. An example is provided by Marbury v.
Madisan(1) I do not mean to say that the Court should hesitate or falter or withdraw
from the exercise of its jurisdiction. On the contrary, it must plainly do its duty under
the Constitution. But I do say that in every case the Court should determine the true
limits of its jurisdiction and, having done so, it should take care to remain within the
restraints of its jurisdiction.
This aspect of Court action assumes especial significance in public interest litigation.
It bears upon the legitimacy of the judicial institution, and that legitimacy is affected
as much by the solution presented by the Court in resolving a controversy as by the
manner in which the solution is reached. In an area of judicial functioning where
judicial activism finds room for play, where constitutional adjudication can become
an instrument of social policy forged by the personal political philosophy of the
judge, this is an important consideration to keep in mind.
Where the Court embarks upon affirmative action in the attempt to remedy a
constitutional imbalance within the social order, few critics will find fault with it so
long as it confines itself to the scope of its legitimate authority. But there is always the
possibility, in public interest litigation, of succumbing to the temptation of crossingBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

into territory which properly pertains to the Legislature or to the Executive
Government. For in most cases the jurisdiction of the Court is invoked when a default
occurs in executive administration, and sometimes where a void in community life
remains unfilled by legislative action. The resulting public grievance finds expression
through social action groups, which consider the Court an appropriate forum for
removing the deficiencies. Indeed, the citizen seems to find it more convenient to
apply to the Court for the vindication of constitutional rights than appeal to the
executive or legislative organs of the State.
In the process of correcting executive error or removing legislative omission the
Court can so easily find itself involved in policy making of a quality and to a degree
characteristic of political authority and indeed run the risk of being mistaken for one.
An excessively political role identifiable with political governance betrays the Court
into functions alien to its fundamental character, and tends to destroy the delicate
balance envisaged in our constitutional system between its three basic institutions.
The Judge, conceived in the true classical mould, is an impartial arbiter, beyond and
above political bias and prejudice, functioning silently in accordance with the
Constitution and his judicial conscience. Thus does he maintain the legitimacy of the
institution he serves and honour the trust which his office has reposed in him.
The affirmative schemes framed in public interest litigation by. the Court sometimes
require detailed administration under constant judicial supervision over protracted
periods. The lives of large sections of people, some of whom have had no voice in the
decision, are shaped and ordered by mandatory Court action extending into the
future. In that context, it is as well to remember that public approval and public
consent assume material importance in its successful implementation. In contrast
with policy making by legislation, where a large body of legislators debate on a
proposed legislative enactment, no such visual impact can be perceived when judicial
decrees are forged and fashioned by a few judicial personages in the confines of a
Court. The mystique of the robe, at the stage of decision-making, is associated
traditionally with cloistered secrecy and confidentiality and the end-result commonly
issues as a final definitive act of the Court. It is a serious question whether in every
case the same awesome respect and reverence will endure during different stages of
affirmative action seeking to regulate the lives of large numbers of people, some of
whom never participated in the judicial process.
There is good reason to suppose that treating with public interest litigation requires
more than legal scholarship and a knowledge of textbook law. It is of the utmost
importance in such cases that when formulating a scheme of action, the Court must
have due regard to the particular circumstances of the case, to surrounding realities
including the potential for successful implementation, and the likelihood and degree
of response from the agencies on whom the implementation will depend. In most
cases of public interest litigation, there will be neither precedent nor settled practice
to add weight and force to the vitality of the Court's action. The example of similarBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

cases in other countries can afford little support. The successful implementation of
the orders of the Court will depend upon the particular social forces in the backdrop
of local history, the prevailing economic pressures, the duration of the stages
involved in the implementation, the momentum of success from stage to stage, and
acceptance of the Court's action at all times by those involved in or affected by it.
An activist Court, spearheading the movement for the development and extension of
the citizen's constitutional rights, for the protection of individual liberty and for the
strengthening of the socioeconomic fabric in compliance with declared constitutional
objectives, will need to move with a degree of judicial circumspection. In the centre of
a social order changing with dynamic pace, the Court needs to balance the authority
of the past with the urges of the future, As far back as 1939, Judge Learned Hand(1)
observed that a Judge "must preserve his authority by cloaking himself in the majesty
of an over-shadowing past; but he must discover some composition with the
dominant needs of his times". In that task the Court must ever be. conscious of the
constitutional truism that it possesses the sanction of neither the sword nor the purse
and that its strength lies basically in public confidence and support, and that
consequently the legitimacy of its acts and decisions must remain beyond all doubt.
Therefore, whatever the case before it, whatever the context of facts and legal rights,
whatever the social and economic pressures of the times, whatever the personal
philosophy of the Judge, let it not be forgotten that the essential identity of the
institution, that it is a Court, must remain preserved so that every action of the Court
is informed by the fundamental norms of law, and by the principles embodied in the
Constitution and other sources of law. If its contribution to the jurisprudential ethos
of society is to advance our constitutional objectives, it must function in accord with
only those principles which enter into the composition of judicial action and give to it
its essential quality. In his perceptive Lectures entitled "The Warren Court:
Constitutional Decision as an Instrument of Reform"(2). Professor Archicald Cox
pointedly observes:
"Ability to rationalise a constitutional judgment in terms of principles referable to
accepted sources of law is an essential, major element of constitutional adjudication.
It is one of the ultimate sources of the power of the Court- including the power to
gain acceptance for the occasional great leaps forward which lack such justification.
Constitutional government must operate by consent of the governed. Court decrees
draw no authority from the participation of the. people. Their power to command
consent depends upon more than habit or even the deserved prestige of the justices.
It comes, to an important degree, from the continuing force of the rule of law-from
the belief that the major influence in judicial decisions is not fiat but principles which
bind the judges as well as the litigants and which apply consistently among all men
today, and also yesterday and tomorrow".
There is great merit in the Court proceeding to decide an issue on the basis of strict legal principle
and avoiding carefully the influence of purely emotional appeal. For that alone gives the decision ofBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

the Court a direction which is certain, and unfaltering, and that particular permanence in legal
jurisprudence which makes it a base for the next step forward in the further progress of the law.
Indeed, both certainty of substance and certainty of direction are indispensable requirements in the
development of the law, and invest it with the credibility which commands public confidence in its
legitimacy.
This warning is of especial significance in these times, during a phase of judicial history when a few
social action groups tend to show evidence of presuming that in every case the court must bend and
mould its decision to popular notions of which way a case should be decided.
I have endeavoured by these observations to indicate some of the areas in which the Court should
move with caution and circumspection when addressing itself to public interest litigation. As new
areas open before the Court with modern developments in jurisprudence, in a world more sensitive
to human rights as well as the impact of technological progress, the Court will become increasingly
conscious of its expanding jurisdiction. That is inevitable. But its responsibilities are
correspondingly great, and perhaps never greater than now. And we must remember that there is no
higher Court to correct our errors, and that we wear the mantle of infallibility only because our
decisions are final. That we sit at the apex of the judicial administration and our word, by
constitutional mandate, is the law of the land can induce an unusual sense of power. It is a feeling
we must guard against by constantly reminding ourselves that every decision must be guided by
reason and by judicial principles.
My brothers have dealt with the preliminary objections raised by the respondents to the
maintainability of this proceeding. On the considerations to which I have adverted earlier I have no
hesitation in agreeing with them that the preliminary objections must be rejected. I have no doubt in
my mind that persons in this country obliged to serve as bonded labour are entitled to invoke Article
23 of the Constitution. The provisions embodied in that clause form a vital constituent of the
Fundamental Rights set forth in Part III of the Constitution, and their violation attracts properly the
scope of Article 32 of the Constitution. I also find difficulty in upholding the objection by the
respondents to the admissibility and relevance of the material consisting of the report of the two
advocates and of Dr. Patwardhan appointed as Commissioners. It is true that the reports of the said
Commissioners have not been tested by cross-examination, but then the record does not show
whether any attempt was made by the respondents to call them for cross-examination. The further
question whether the appointment of the Commissioners falls within the terms of order XLVI of the
Supreme Court Rules 1966 is of technical significance only, because there was inherent power in the
Court, in the particular circumstances of this case, to take that action. I have already set forth earlier
my views in respect of the nature and forms of procedure open to the Court in public interest
litigation and I need not elaborate them here. I may add, however, that the Court would do well to
issue notice to the respondents, before appointing any Commissioner, in those cases where there is
little apprehension of the disappearance of evidence.
On the merits of the case I find myself in agreement with my brother Bhagwati, both in regard to the
operation of the various statutes as well as the directions proposed by him. The case is one of
considerable importance to a section of our people, who pressed by the twin misfortunes of povertyBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

and illiteracy, are compelled to a condition of life which long since should have passed into history.
The continued existence of such pockets of oppression and misery do no justice to the promises and
assurances extended by our Constitution to its citizens.
AMARENDRA NATH SEN, J. The relevant facts have been fully set out in the judgment of my
learned brother Bhagwati, J. My learned brother has also recorded in his judgment the various
contentions which were urged before us in this writ petition.
A preliminary objection was raised by Shri K. L. Bhagat. Additional Solicitor General of India and
also by Shri Phadke, learned counsel appearing on behalf of the respondents, as to the
maintainability of the present petition. The objection to the maintainability of the present petition is
taken mainly on the following three grounds:-
1 Art. 32 of the Constitution is not attracted to the instant case as no fundamental
right of the petitioners or of the workmen referred to in the petition are infringed.
2 A letter addressed by a party to this Court cannot be treated as a writ petition and
in the absence of any verified petition this Court cannot be moved to exercise its writ
jurisdiction.
3 In a proceeding under Art. 32 of the Constitution this Court is not empowered to
appoint any commission or an investigating body to enquire into the allegations
made and make a report to this Court on the basis of the enquiry to enable this Court
to exercise its power and jurisdiction under Art. 32 of the Constitution.
I propose to consider the objections in the order noted above. I shall first deal with
the first objection, namely, that Art. 32 of the Constitution is not attracted as there is
no violation of any fundamental right of the petitioner or of the workmen referred to
in the petition.
The substance of the grievance of the petitioners in this petition is that the workmen
referred to in the communication addressed to this Court are bonded labourers. In
1976, the Parliament enacted the Bonded Labour System (Abolition) Act, 1976 and by
virtue of the provisions of the said Act, the bonded labour system has been declared
to be illegal in this country. Any person who is wrongfully and illegally employed as a
labourer in violation of the provisions of the Act, is in essence deprived of his liberty.
A bonded labourer truly becomes a slave and the freedom of a bonded labourer in the
matter of his employment and movement is more or less completely taken away and
forced labour is thrust upon him. When any bonded labourer approaches this Court,
the real grievance that he makes is that he should be freed from this bondage and he
prays for being set at liberty and liberty is no doubt a fundamental right guaranteed
to every person under the Constitution. There cannot be any manner of doubt that
any person who is wrongfully and illegally detained and is deprived of his liberty can
approach this Court under Art. 32 of the Constitution for his freedom from wrongfulBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

and illegal detention, and for being set at liberty. In my opinion, whenever any
person is wrongfully and illegally deprived of his liberty, it is open to anybody who is
interested in the person to move this Court under Art. 32 of the Constitution for his
release. It may not very often be possible for the person who is deprived of his liberty
to approach this Court, as by virtue of such illegal and wrongful detention, he may
not be free and in a position to move this Court. The Petitioner in the instant case
claims to be an association interested in the welfare of society and particularly of the
weaker section. The Petitioner further states that the petitioner seeks to promote the
welfare of the labourers and for promoting the welfare of labour, the petitioner seeks
to move this Court for releasing the bonded labourers from their bondage and for
restoring to them their freedom and other legitimate rights. The bonded labourers
working in the far away places are generally poor and belong to the very weak section
of the people. They are also not very literate and they may not be conscious of their
own rights. Further, as they are kept in bondage their freedom is also restricted and
they may not be in a position to approach this Court. Though no fundamental right of
the petitioner may be said to be infringed, yet the petitioner who complains of the
violation of the fundamental right of the workmen who have been wrongfully and
illegally denied their freedom and deprived of their constitutional right must be held
to be entitled to approach this Court on behalf of the bonded labourers for removing
them from illegal bondage and deprivation of liberty. The locus standi of the
petitioner to move this Court appear to be conclusively established by the decision of
this Court in the case of S.P. Gupta v. Union of India & Anr.(1) Forced labour is
constitutionally forbidden by Art. 23 of the Constitution. As in the present case the
violation of the fundamental right of liberty of the workmen who are said to be kept
in wrongful and illegal detention, employed in forced labour, is alleged, Art. 32 of the
Constitution to my mind, is clearly attracted. The first ground raised on behalf of the
respondents cannot, therefore, be sustained.
Before I proceed to deal with the second ground urged on behalf of the respondents,
it will be convenient to set out the provisions of Art. 32 of the Constitution. Art. 32
read as follows:-
"(1) The right to move the Supreme Court by appropriate proceedings for the
enforcement of the rights conferred by this Part is guaranteed.
(2) The Supreme Court shall have power to issue directions or orders or writs,
including writs in the nature of habeas corpus, mandamus, prohibition, quo warrants
and certiorari, whichever may be appropriate, for the enforcement of any of the rights
conferred by this part.
(3) Without prejudice to the powers conferred on the Supreme Court by clauses (1)
and (2), Parliament may by law empower any other Court to exercise within the local
limits of its jurisdiction all or any of the powers exercisable by the Supreme Court
under clause (2). (4) The right guaranteed by this article shall not be suspendedBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

except as otherwise provided for by this Constitution."
Art. 32(1) confers the right to move this Court by appropriate proceedings for enforcement of the
fundamental rights guaranteed under the Constitution. Art. 32(2) makes provision for the powers of
this Court in the matter of granting relief in any proceeding in this Court for enforcement of the
fundamental rights guaranteed by the Constitution. Art. 32(3) and 32(4) which I have also set out
for the purpose of complete understanding of the provisions of Art. 32 for proper appreciation of its
scope and effect, do not have any material bearing on the question involved in the present
proceeding.
The second ground which raises the question whether the letter addressed by a party to this Court
can be treated as a writ petition and in the absence of any verified petition this court can be moved
to exercise its writ jurisdiction, is essentially an objection to the procedure to be adopted by this
Court in the matter of entertaining a proceeding under Art. 32 for enforcement of fundamental
rights of the parties. Art. 32(1) of the Constitution which has been earlier set out guarantees the
right to move this Court by an appropriate proceeding for the enforcement of the fundamental
rights. Art. 32(2) confers wide powers on this Court in the matter of granting relief against any
violation of the fundamental rights. Art. 32 or for that matter any other article does not lay down
any procedure which has to be followed to move this Court for relief against the violation of any
fundamental right. Art. 32(1) only lays down that the right to move this Court by appropriate
proceedings for enforcement of fundamental rights is guaranteed. The Constitution very
appropriately leaves the question as to what will constitute an appropriate proceeding for the
purpose of enforcement of fundamental rights to be determined by the Court. This Court, when
sought to be moved under Art. 32 by any party for redressing his grievance against the violation of
fundamental rights has to consider whether the procedure followed by the party is appropriate
enough to entitle the court to proceed to act on the same. No doubt this Court has framed rules
which are contained in part IV, Order XXXV of the Supreme Court Rules under the Caption
"application for enforcement of fundamental rights ("Art. 32 of the Constitution"). Generally
speaking, any party who seeks to move this Court under Act. 32 of the Constitution should conform
to the rules prescribed. The rules lay down the procedure which is normally to be followed in the
matter of any application under Art. 32 of the Constitution. These rules are rules relating to the
procedure to be adopted and the rules are intended to serve as maids to the Deity of Justice.
Procedural law which also forms a part of the law and has to be observed, is, however, subservient to
substantive law and the laws of procedure are prescribed for promoting and furthering the ends of
justice. There cannot be any doubt that this Court should usually follow the procedure laid down in
O.XXXV of the Rules of this Court and should normally insist on a petition properly verified by an
affidavit to be filed to enable the Court to take necessary action on the same. Though this Court
should normally insist on the rules of procedure being followed, it cannot be said, taking into
consideration the nature of right conferred under Art. 32 to move this Court by an appropriate
proceeding and the very wide powers conferred on this Court for granting relief in the case of
violation of fundamental rights that this Court will have no jurisdiction to entertain any proceeding
which may not be in conformity with procedure prescribed by the Rules of this Court. The Rules
undoubtedly lay down the procedure which is normally to be followed for making an application
under Art. 32 of the Constitution. They, however, do not and cannot have the effect of limiting theBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

jurisdiction of this Court of entertaining a proceeding under Art. 32 of the Constitution, if made,
only in the manner prescribed by the rules. For effectively safeguarding the fundamental rights
guaranteed by the Constitution, the Court in appropriate cases in the interests of justice will
certainly be competent to treat a proceeding, though not in conformity with the procedure
prescribed by the Rules of this Court, as an appropriate proceeding under Art. 32 of the Constitution
and to entertain, the same. Fundamental rights guaranteed under the Constitution are indeed too
sacred to be ignored or trifled with merely on the ground of technicality or any rule of procedure. It
may further be noticed that the rules framed by this Court do not also lay down that this Court can
be moved under Art. 32 of the Constitution only in accordance with the procedure prescribed by the
Rules and not otherwise. A mere technicality in the matter of form or procedure which may not in
any way affect the substance of any proceeding should not stand in the way of the exercise of the
very wide jurisdiction and powers conferred on this Court under Art. 32 of the Constitution for
enforcement of fundamental rights guaranteed under the Constitution. Taking into consideration
the substance of the matter and the nature of allegations made, it will essentially be a matter for the
Court to decide whether the procedure adopted can be considered to be an appropriate proceeding
within the ambit of Art. 32 of the Constitution. The Court, if satisfied on the materials placed in the
form of a letter or other communication addressed to this court, may take notice of the same in
appropriate cases. Experience shows that in many cases it may not be possible for the party
concerned to file a regular writ petition in conformity with procedure laid down in the Rules of this
Court. It further appears that this Court for quite some years now has in many cases proceeded to
act on the basis of the letters addressed to it. A long standing practice of the Court in the matter of
procedure also acquires sanctity. It may also be pointed out that in various cases the Court has
refused to take any notice of letters or other kind of communications addressed to Court and in
many cases also the court on being moved by a letter has directed a formal writ petition to be filed
before it has decided to proceed further in the matter. It is, however, eminently desirable, in my
opinion, that normally the procedure prescribed in the rules of this Court should be followed while
entertaining a petition under Art. 32 of the Constitution, though in exceptional cases and
particularly in matter of general public interest, this Court may, taking into consideration the
peculiar facts and circumstances of the case, proceed to exercise its jurisdiction under Art. 32 of the
constitution for enforcement of fundamental rights treating the letter or the communication in any
other form as an appropriate preceding under Art. 32 of the Constitution. It is, however, eminently
desirable that any party who addresses a letter or any other communication to this Court seeking
intervention of this Court on the basis of the said letter and communication should address this
letter or communication to this Court and not to any individual Judge by name. Such
communication should be addressed to the Chief Justice of the Court and his companion Justices. A
private communication by a party to any Learned Judge over any matter is not proper and may
create embarrassment for the Court and the Judge concerned.
In the present case, the unfortunate workers who are emploced as bonded labourers at as distant
place, could not possibly in view of their bondage, move this Court, following the procedure laid
down in the Rules of this Court. The Petitioner which claims to be a Social Welfare Organisation
interested in restoring liberty and dignity to these unfortunate bonded labourers should be
considered competent to move this Court by a letter or like communication addressed to this Court,
to avoid trouble and expenses, as the petitioner is not moving this Court for any personal or privateBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

benefit.
I shall now consider the third and the last objection which relates to the powers of this Court to
direct an enquiry into the allegations made and to call for a report in a proceeding under Art. 32 of
the Constitution to enable this Court to exercise its power and jurisdiction under Art. 32 of the
Constitution.
We have earlier noted that the fundamental rights are guaranteed by the Constitution and for the
enforcement of the fundamental rights very wide powers have been conferred on this Court. Before
this Court proceeds to exercise its owers under Art. 32 of the Constitution for enforcing the
fundamental rights guaranteed, this Court has to be satisfied that there has been a violation of the
fundamental rights. The fundamental rights may be alleged to have been violated under various
circumstances. The facts and circumstances differ from case to case. Whenever, however, there is an
allegation of violation of fundamental rights, it becomes the responsibility and also the sacred duty
of this Court to protect such fundamental rights guaranteed under the Constitution provided that
this Court is satisfied that a case for interference by this Court appears prima facie to have been
made out. very often the violation of fundamental rights is not admitted or accepted. On a proper
consideration of the materials the Court has to come to a conclusion whether there has been any
violation of fundamental rights to enable the Court to grant appropriate reliefs in the matter. In
various cases, because of the peculiar facts and circumstances of the case the party approaching this
Court for enforcement of fundamental rights may not be in a position to furnish all relevant
materials and necessary particulars. If, however, on a consideration of the materials placed, the
Court is satisfied that a proper probe into the matter is necessary in the larger interest of
administration of justice and for enforcement of fundamental rights guaranteed, the Court, in view
of the obligations and duty cast upon it of preserving and protecting fundamental rights, may
require better and further materials to enable the Court to take appropriate action; and there cannot
be anything improper in the proper exercise of Court's jurisdiction under Art. 32 of the Constitution
to try to secure the necessary materials through appropriate agency. The Commission that the Court
may appoint or the investigation that the court may direct is essentially for the Court's satisfaction
as to the correctness or otherwise of the allegation of violation of fundamental rights to enable the
Court to decide the course to be adopted for doing proper justice to the parties in the matter of
protection of their fundamental rights. We have to bear in mind that in this land of ours, there are
persons without education, without means and without opportunities and they also are entitled to
full protection of their rights or privileges which the Constitution affords. Living in chilled penury
without necessary resources and very often not fully conscious of their rights guaranteed under the
Constitution, a very large section of the people commonly termed as the weaker section live in this
land. When this Court is approached on behalf of this class of people for enforcement of
fundamental rights of which they have been deprived and which they are equally entitled to enjoy, it
becomes the special responsibility of this Court to see that justice is not denied to them and the
disadvantageous position in which they are placed, do not stand in the way of their getting justice
from this Court. The power to appoint a commission or an investigating body for making enquiries
in terms of directions given by the Court must be considered to be implied and inherent in the
power that the Court has underBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

Art. 32 for enforcement of the fundamental rights guaranteed under the Constitution.
This is a power which is indeed incidental or ancillary to the power which the Court is
called upon to exercise in a proceeding under Art. 32 of the Constitution. It is entirely
in the discretion of the Court, depending on the facts and circumstances of any case,
to consider whether any such power regarding investigation has to be exercised or
not. The Commission that the Court appoints or the investigation that the Court
directs while dealing with a proceeding under Art. 32 of the Constitution is not a
commission or enquiry under the Code of Civil Procedure. Such power must
necessarily be held to be implied within the very wide powers conferred on this Court
under Art. 32 for enforcement of fundamental rights. I am, further of the opinion that
for proper exercise of its powers under Art. 32 of the Constitution and for due
discharge of the obligation and duty cast upon this Court in the matter of protection
and enforcement of fundamental rights which the Constitution guarantees, it must be
held that this Court has an inherent power to act in such a manner as will enable this
Court to discharge its duties and obligations under Art. 32 of the Constitution
properly and effectively in the larger interest of administration of justice, and for
proper protection of constitutional safeguards. I am, therefore, of the opinion that
this objection is devoid of any merit.
I may incidentally observe that as a result of such action on the part of the Court
attention of the appropriate authorities concerned has in a number of cases been
pointedly drawn to the existence of bonded labourers in various parts of the country
and to their miserable plight and a large number of bonded labourers have been freed
from their bondage. To my mind, the litigation of this type particularly in relation to
bonded labourers is really not in nature in adversary litigation and it becomes the
duty of the State and also of the appropriate authorities to offer its best co-operation
to see that this evil practice which has been declared illegal is ended at the earliest.
The existence of bonded labour in the country is an unfortunate fact. Whenever there
is any allegation of the existence of bonded labour in any particular State, the State
instead of seeking to come out with a case of denial of such existence on the basis of a
feeling that the existence of bonded labour in the State may cast a slur or stigma on
its administrative machinery, should cause effective enquiries to be made into the
matter and if the matter is pending in this Court, should co- operate with this Court
to see that death-knell is sounded on this illegal system which constitutes a veritable
social menace and stands in the way of healthy development of the nation.
For reasons aforesaid, I do not find any merit in the preliminary objections raised
and I agree with my learned brother that the preliminary objections must be
over-ruled.
On the merits of the case my learned brother Bhagwati, J. has in his judgment
carefully and elaborately discussed all the aspects. Apart from the principal grievance
made that the workmen in the instant case are bonded labourers, various grievances
on behalf of the workmen have been voiced and denial to the workmen of variousBandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

other just rights has been alleged. The grievance of denial of other just rights to the
workmen and the reliefs claimed for giving the workmen the benefits to which they
may be entitled under various legislations enacted for their welfare are more or less
in the nature of consequential reliefs incidental to the main relief of freedom from
bonded and forced labour to which the workmen are subjected. I must frankly
confess that in the facts and circumstances of this case I have some doubts as to the
applicability of the provisions of Inter State Migrant Workmen (Regulation of
Employment and Conditions of Service) Act, 1979. The views expressed by my
learned brother Bhagwati, J. in his judgment, to my mind, do not amount to any
adjudication on the question of applicability of the Inter State Migrant Workmen
(Regulation of Employment and Conditions of Service) Act, 1979. The observations
made by my learned brother Bhagwati, J. and the directions given by him on the
various aspects with regard to the merits of the case after carefully considering the
provisions of all the relevant labour legislations enacted tor the benefit of labourers
and for improvement and betterment of their lot, are for furthering the interests of
the workmen and for proper protection and preservation of their just rights and to
enable the appropriate authorities to take necessary action in the matter. As I am in
agreement with the views expressed by my learned Brother Bhagwati, J. I do not
propose to deal with these aspects at any length and I content myself by expressing
my agreement with the judgment of my learned brother Bhagwati, J. on these
matters.
S. R.                                  Petitions allowed and
                                       preliminary grounds
                                       rejected.Bandhua Mukti Morcha vs Union Of India & Others on 16 December, 1983

