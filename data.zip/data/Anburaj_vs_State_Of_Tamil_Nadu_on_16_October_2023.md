Anburaj vs State Of Tamil Nadu on 16 October, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                             H.C.P(MD)No.851 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                              DATED: 16.10.2023
                                                      Coram
                                    THE HON'BLE MR.JUSTICE M.SUNDAR
                                                   and
                                  THE HON'BLE MR. JUSTICE R.SAKTHIVEL
                                           H.C.P(MD)No.851 of 2023
                  Anburaj                                                  .. Petitioner
                                                        vs
                  1.State of Tamil Nadu,
                    Represented by the Principal Secretary to Government,
                    Home, Prohibition and Excise Department,
                    Secretariat, Chennai – 600 009.
                  2.The Commissioner of Police,
                    O/o.The Commissioner of Police,
                    Madurai City, Madurai.
                  3.The Superintendent,
                    Central Prison,
                    Madurai.                                         .. Respondents
                  Prayer:- Petition filed under Article 226 of the Constitution of India praying
                  for issuance of a writ of Habeas Corpus calling for the entire records in
                  detention order passed in No.31/BCDFGISSSV/2023 dated 21.04.2023 on
                  the file of the second respondent herein and set aside the same as illegal and
                  direct the respondents to produce the body or person of the petitioner's son
                  namely Iyyappan, son of Anburaj, male, aged 26 years, who is detained in
                  Central Prison, Madurai before this Court and set him at liberty.
https://www.mhc.tn.gov.in/judis
                  1/8
                                                                            H.C.P(MD)No.851 of 2023
                            For Petitioner         :     Mr.B.Mohamed IdrishAnburaj vs State Of Tamil Nadu on 16 October, 2023

                            For Respondents        :     Mr.A.Thiruvadi Kumar
                                                         Additional Public Prosecutor
                                                        ORDER
[Order of the Court was made by M.SUNDAR, J.] Captioned 'Habeas Corpus Petition' [hereinafter
'HCP' for the sake of brevity] has been filed by the father of the detenu assailing a 'preventive
detention order dated 21.04.2023 bearing No. 31/BCDFGISSSV/2023' [hereinafter 'impugned
preventive detention order' for the sake of brevity and convenience]. To be noted, sponsoring
authority has not been arrayed as a respondent but we find that Station House Officer of B6
Jaihindpuram Police Station is the sponsoring authority [hereinafter 'Sponsoring Authority' for the
sake of convenience and clarity] and second respondent is the detaining authority as impugned
preventive detention order has been made by second respondent.
2. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of
https://www.mhc.tn.gov.in/judis 1982' for the sake of convenience and clarity] on the premise that
the detenu is a 'Goonda' within the meaning of Section 2(f) of Act 14 of 1982.
3.There is no adverse case. This solitary case which is the sole substratum of the impugned
preventive detention order is Crime No.69 of 2023 on the file of B6 Jaihindpuram Police Station for
alleged offences under Sections 147, 148, 294(b), 341, 342, 302 and 506(ii) of 'The Indian Penal
Code (45 of 1860)' [hereinafter 'IPC' for the sake of convenience and clarity] and subsequently
altered into Sections 147, 148, 294(b), 341, 342, 302, 506(ii) and 120-B of IPC. Considering the
nature of the challenge to the impugned detention order, it is not necessary to delve into the factual
matrix of the case.
4.Mr.B.Mohamed Idrish, learned counsel on record for petitioner and Mr.A.Thiruvadi Kumar,
learned State Additional Public Prosecutor for all respondents are before us.
5. Learned counsel for petitioner submitted that 'live and proximate link' between the grounds of
detention and purpose of detention has snapped as date of arrest in the ground case is 01.02.2023
but the impugned preventive detention order has been made only on 21.04.2023.
https://www.mhc.tn.gov.in/judis
6. Mr.A.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits to the contrary by
saying that materials had to be collected and time was consumed in this exercise. Considering the
facts / circumstances of the case on hand and nature of ground case, we find that this explanation of
learned Prosecutor is unacceptable.
7. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic SubstancesAnburaj vs State Of Tamil Nadu on 16 October, 2023

Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after considering
a proposal by a Sponsoring Authority and after noticing the trajectory the matter took, Hon'ble
Supreme Court held that the 'live and proximate link between grounds of detention and purpose of
detention snapping' point should be examined on a case to case basis. Hon'ble Supreme Court has
held in Banik case law that this point has two facets. One facet is 'unreasonable delay' and the other
facet is 'unexplained delay'. We find that the captioned matter falls under latter facet i.e.,
unexplained delay.
https://www.mhc.tn.gov.in/judis
8. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:
1159 and a series of similar orders in HCP cases.
9. To be noted, the sole substratum of the impugned preventive detention order is a solitary case
viz., Crime No.69 of 2023 on the file of B6 Jaihindpuram Police Station for alleged offences under
Sections 147, 148, 294(b), 341, 342, 302 and 506(ii) of IPC and subsequently altered into Sections
147, 148, 294(b), 341, 342, 302, 506(ii) and 120-B of IPC.
10. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ. https://www.mhc.tn.gov.in/judis
11. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
21.04.2023 bearing No.31/BCDFGISSSV/2023 made by the second respondent is set aside and the
detenu Thiru.Iyyappan, aged 26 years, son of Thiru.Anburaj, is directed to be set at liberty
forthwith, if not required in connection with any other case / cases. There shall be no order as to
costs.
(M.S.,J.) (R.S.V.,J.) 16.10.2023 Index : Yes/No Neutral Citation : Yes/No ps P.S: Registry to
forthwith communicate this order to Jail authorities in Central Prison, Madurai.
https://www.mhc.tn.gov.in/judis To
1.The Principal Secretary to Government, Home, Prohibition and Excise Department, Secretariat,
Chennai – 600 009.
2.The Commissioner of Police, O/o.The Commissioner of Police, Madurai City, Madurai.Anburaj vs State Of Tamil Nadu on 16 October, 2023

3.The Superintendent, Central Prison, Madurai.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., ps 16.10.2023
https://www.mhc.tn.gov.in/judisAnburaj vs State Of Tamil Nadu on 16 October, 2023

