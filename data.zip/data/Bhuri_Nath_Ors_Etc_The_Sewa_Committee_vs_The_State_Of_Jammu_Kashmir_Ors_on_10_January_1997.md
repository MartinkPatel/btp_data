Bhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of
Jammu & Kashmir & Ors on 10 January, 1997
Equivalent citations: AIR 1997 SUPREME COURT 1711, 1997 (2) SCC 745,
1997 AIR SCW 869, 1997 (1) SCALE 250, (1997) 1 SCR 138 (SC), (1997) 1 JT
546 (SC), (1997) 1 CURCC 94, (1997) 1 SUPREME 358, (1997) 1 SCJ 218,
(1997) 1 SCALE 250
Author: K. Ramaswamy
Bench: K. Ramaswamy
           PETITIONER:
BHURI NATH & ORS. ETC. THE SEWA COMMITTEE BARIDARAN &ORS. (B
        Vs.
RESPONDENT:
THE STATE OF JAMMU & KASHMIR & ORS.
DATE OF JUDGMENT:       10/01/1997
BENCH:
K. RAMASWAMY, G.B. PATTANAIK
ACT:
HEADNOTE:
JUDGMENT:
THE 10TH DAY OF JANUARY, 1997 Present:
Hon'ble Mr. Justice K. Ramaswamy Hon'ble Mr. Justice G. B. Pattanaik N.N. Bhat,
Mahesh Aggarwal, G.P. Srivastava, Atul Sharma, E.C. Agarwala, Advs. for the
appellants.
S.K. Dholakia, P.P. Rao, Sr. Advs. J.S. Manhas, Subhash Sharma, Mulk Raj Vij, N.P.
Sharma, Sunil Dogra, Ms. Monica Sharma, S.S. Shroff, Advs. with them for S.A.Bhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

Shroff & Co., Advs. for the Respondents.
J U D G M E N T The following Judgment of the Court was delivered:
K. Ramaswamy, J.
Leave granted.
All Hindus, in millions, of India from nook and corner and those settled abroad, go
by foot or carriage, bearing all arduous journey and inconveniences, covering a
distance of 16 miles from foothill of Katra to have darshan and blessings of Mata
Vaishno Deviji. When the Legislature of the State of Jammu and Kashmir stepped in
for effective and proper management of the shrine and convenience of the pilgrims
and the Shrine, it gave rise to the present litigation.
These appeals, sequally, by special leave arise from the common judgment of the
Division Bench of Jammu and Kashmir High Court, made on March 17, 1994 in CWP
Nod. 1328/96 and 1039/95. The appellants challenged the constitutionality of the
Jammu and Kashmir Shri Mata Vaishno Devi Shrine Act, 1988 (XVI of 1988) (for
short, the "Act"). On March 17, 1986, the Governor, exercising the power of Section
92 of the Constitution of Jammu & Kashmir, promulgated Ordinance No.1 of 1986
which got transformed into J & K Shri Mata Vaishno Devi Shrine Act, 1986, the
Governor's Act and is now replaced by the Act. The Act has come into force by
operation of Section 1(2) of the Act w.e.f. August 13, 1986, the date on which the said
Ordinance had come into force.
The Preamble of the Act manifests that the Act came to be passed "to provide for the
better management, administration and governance of Shri Mata Vaishno Devi
shrine and its endowments including the land and buildings attached, or appurtenant
to the Shrine, beginning from Katra upto the holy cave and adjoining hillocks
currently under the management of Dharmarth Trust". Section 2 gives to the Act
overriding effect and envisages that the Act shall have effect, notwithstanding
anything to the contrary contained "in any law or in any scheme of management,
decree, custom, usage or instrument". The Act consists of, in all, 25 Section. Section
3(a) defines the "Board" to mean "the Shri Mata Vaishno Devi Shrine Board
constituted under this Act". Section 3(b) defines "Endowment" to mean all property,
movable or immovable, including the idols installed therein. The important facet of
this definition of "endowment" is that the sum total of properties belonging to, given
or endowed for the maintenance, improvement, additions to or worship in the Shrine
or for the purpose of any service or charity connected therewith including the idols
installed therein, the premises of the Shrine, the lands and buildings attached or
appurtenant thereto, beginning from Katra upto the holy cave and the adjoining
hillocks, are the endowment of Mata Shri Vaishno Deviji. They all, as on the date of
the Act, were endowment properties under the management of the Dharmarth Trust,Bhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

or property belonging to Baridar or Baridars Association within the area specified in
the Preamble of the Act. Section 3(c) defines "Shrine Fund" to mean the endowment
and includes all sums received by or on behalf of the Shrine or for the time being held
for the benefit of the Shrine; it an inclusive definition and details of the endowments
described therein being not material, the same are omitted. Section 3(d) is relevant
which defines the "Shrine" to mean the Shrine of Shri Mata Vaishno Devi Shrine and
includes the Shrine, holy cave and other temples within the premises specified in the
preamble of the Act. It would, thus, be clear that the Act was made to provide better
management, administration and governance of Shri Mata Vaishno Devi Shrine, its
endowments, all temples, and sum total of the properties, movable and immovable
attached or appurtenant to the Shrine within the area specified in the preamble of the
Act, notwithstanding the fact that there exist any law, scheme of management,
decree, custom, usage or instrument to the contrary. The object of the Act, therefore,
clearly is proper, efficient and effective management, administration and governance
of the Shrine, its endowments and properties. All this is aimed to cater facilities,
sources and comfort to the pilgrims who visit the Shrine.
Section 4 vests the ownership of the Shrine Fund in the Board envisaging that "the
ownership of the Shrine Fund shall, from the commencement of this Act vest in the
Board and the Board shall be entitled to its possession, administration and use for
the purposes of this Act". The Board gets constituted under Section 5. Sub-section (1)
adumberates that the administration, management and governance of Shri Mata
Vaishno Devi Shrine and the Shrine Fund shall vest in the Board comprising a
Chairman and not more than ten members. The composition thereof is elaborated
with the a mandatory language, viz., "shall be". Under clause (a) of sub-section (1)
thereof, the Governor of the State of Jammu and Kashmir, and if the Governor be not
a Hindu, then an eminent person professing Hindu religion and qualified to be a
member to be nominated by the Governor, shall be the ex-officio Chairman of the
Board. Clause (b) provides that a Governor shall nominate nine members in the
manner indicated therein, viz., (i) two persons who, in the opinion of the Governor,
have distinguished themselves in the service of Hindu religion or culture; (ii) two
women, who in the opinion of the Governor, have distinguished themselves in the
service of Hindu religion, culture or social work, especially in regard to advancement
of women;
(iii) three persons, out of persons who have distinguished themselves in
administration, legal affairs of financial matters; and (iv) two eminent Hindus of the
State of Jammu and Kashmir. Under the provision, for a period not exceeding three
months from the date the Act came into force, the Governor shall "act as and exercise
all the powers of the Board under this Act". Sub-section (2) of Section 5 declares that
a person shall not be eligible for being nominated as a member of the Board, if he
suffers or incurs any of the disqualifications specified in Section 8.Bhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

Section 6 declares that the Board shall be a body corporate and shall have perpetual succession and
a common seal. It is to sue or be sued in the name of the statutory Board. Section 7 prescribes term
of office of the members for a period of three years from the date of nomination made under Section
5. Disqualifications for membership of the Board are enumerated in Section 8 which envisages that
a person shall be disqualified for being nominated as a member of the Board for any of the
disqualifications mentioned in clauses (a) to (i). Clause (a) is of importance and provides that if
"such person is not a Hindu" he becomes disqualified to be or be appointed as a member. Clause (b)
provides unsoundness of mind declared by a competent court is a disqualification. Under clauses (c)
to (i) are enumerated various disqualifications, the details of which are not material for the purpose
of this case. Section 9 gives power to the Governor for dissolution and supersession of the Board.
Sub-section (1) says that "if in the opinion of the Governor, the Board is not competent to perform
or persistently makes default in performing the duties imposed on it under this Act, or exceeds or
abuses its powers, the Governor may, after due enquiry and after giving the Board reasonable
opportunity of being heard, by order, dissolve or supersede the Board and reconstitute another
Board in accordance with this Act" Thereafter, by operation of Section 9(2), the Governor "shall
assume all the powers and perform all the functions and exercise all the powers of the Board for a
period not exceeding three months or until the constitution of another Board whichever is earlier".
Filling up of vacancies is provided for under Section 10; the details thereof are not material for the
present purpose. Under Section 11, any member may resign his office by giving notice in writing to
the Chief Executive Officer of the Board and his office becomes vacant from the data of acceptance
of such resignation. Section 12 speaks of "removal of a member" by the Governor. It reads as under:
12. Removal of a member. - The Governor may, for good and sufficient reason,
remove any member after giving him an opportunity of showing cause against such
removal and after considering the explanation offered therefor"
Section 13 gives liberty to the Board to maintain its office and hold meetings at the
place as may be decided by it. The Governor and in his absence one of the members
to be elected for the purpose, shall preside at the meetings as Chairman. Coram of
every meeting is prescribed under sub- section (3) as 4 members. Sub-section (4)
gives power to the members of the Board to decide the matters by majority of votes
and in case of equality of votes, the person presiding "shall have a second or casting
vote". Section 14 gives power to the Board to appoint officers and servants to assist
the Board. Under sub-section (1), the Board may appoint, for efficient discharge of
the functions assigned to it under the Act, a Chief Executive Officer and such other
officers and servants as it consider necessary with such designation, pay etc. as the
Board may determine from time to time. Under the proviso, the Chief Executive
Officer of the Board will not a person below the rank of a "District Magistrate of the
District" and in the case of the Chief Accounts Officer, not below the rank of a
"Deputy Director of Accounts. The Chief Executive Officer shall be responsible for
proper and efficient management, administration and governance of the Shrine, its
funds and all arrangements for orderly, peaceful darshan of the Deity by the pilgrims,
their comfortable stay etc. The Accounts Officer shall be responsible for sound
financial management. The honest, efficient and experienced officers shall be drawnBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

from the bureaucracy for the purpose on deputation basis. Subject to the bye-laws
made, by operation of sub- section (2), the Chairman of the Board shall have the
power to transfer, suspend, remove or dismiss any officer or servant of the Board for
the breach of discipline, for carelessness, unfitness, neglect of duty or misconduct or
for any other sufficient cause. An officer on deputation is liable to be reverted to the
parent cadre or Department in the Government. Under Section 15, officers and
servants of the Board are public servants.
Section 16 prescribes the liability of members. Section 17 prohibits transfer or
alienation of movable and immovable property without prior sanction of the Board.
Under sub- section 91) without prior sanction of the Board, no property, movable or
immovable, shall not be transferred. Sub-section (2) of Section 17 prohibits alienation
of the properties including land or other immovable property except by resolution of
the Board.
Section 18 prescribes duties of the Board. Section 19 which is material for the purpose
of this case, extinguishes the rights of Baridars. Sub-section (1) thereof reads as
under:
"(1) All rights of Baridars shall stand extinguished from the date of commencement of
this Act.
Provided that the Governor may appoint a Tribunal which shall give personal hearing to the
Baridars and representatives of the Board, shall recommend compensation to be paid by the Board
in lieu of extinction of their rights. While making its recommendation to the Board, the Tribunal
shall have due regard to the income which the Baridar had been deriving as Baridars. The Board
shall examine the recommendations forwarded to it by the Tribunal and take such by the Tribunal
and take such decision as it may deem appropriate. The decision of the Board should be final.
Provided further that where the Baridar surrenders his right to compensation and offers himself for
employment to the Board, the Board shall cause his suitability for such employment to be adjudged
and may offer him employment in case he is found suitable by the Selection Committee to be
appointed for the purpose subject to the Baridar giving an undertaking to the Board to abide by the
administration and disciplinary control of the Board in accordance with bye-laws framed by the
Board."
Constitution of India by Section 2 and 6 respectively of the Constitution (44th Amendment) Act,
1978 w.e.f. June 20, 1979 does not apply to the State of Jammu and Kashmir. The right to property
is, therefore, still a fundamental right to the residents of Jammu and Kashmir. The Act does not
make either any provision for payment of compensation or principle or guidelines for determination
of compensation to Baridars. The Board being a controlled Corporation, as an arm of the
Government, all the properties of the Shrine stand vested in the Government. The Governor, though
is an ex-officio Chairman, he nominates the members of the Board as executive-head of the State. If
the Governor happens to be a non-Hindu, he has to nominate an eminent Hindu qualified to be aBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

member of the Board. The object to empower the Governor to preside over the Board as its
Chairman, is to ensure its control by the State. The Governor being the head of the executive,
exercises the powers of nomination with the aid and advice of the Council of Ministers. The Chief
Executive Officer, the District Magistrate and Chief Accounts Officer, Deputy Director of Accounts
are the Government servants drawn from the different Departments of the Government. The
Governor, therefore, exercises executive power of the State under the Constitution of the Jammu
and Kashmir and Constitution of India, unless the relevant provisions of the later are not extended.
The executive power of the Governor, thus, flows from the sovereign power of the State. The
statutory power under the Act is integral to the executive power which flows from the Constitution.
The Governor, therefore, is the repository of the State power exercised by the executive. Various
powers conferred on the Hindu Governor are exercisable by virtue of the statute as Governor.
Therefore, in his capacity as the executive Head, the Governor is required to exercise the power
under the Act with the aid and advice of the Council of Ministers. Even otherwise, he exercises the
powers under the Act ex-officio as Governor of the State. Therefore, in either event, he is the
repository of executive power of the State. When the Governor supersedes or reconstitutes the Board
with perpetual succession and seal, he exercises the executive power of the State Government and,
therefore, the Board is a State controlled Corporation. In support thereof, he placed reliance on
Samsher Singh vs. State of Punjab & Anr. [(1974) 2 SCC 831] and Ram Nagina Singh & Ors. vs.
Sohni & Ors. [AIR 1976 Patna 39 para 5]. He also placed reliance on Mansingh Surajsingh Padvi vs.
The State of Maharashtra [(1968 BLR 654]; S. Gurmukh Singh vs. Union of India & Ors. [AIR 1952
Pun. 143]; Home Telephone & Under sub-section (2), all existing employees of Dharmarth Trust
engaged in any functions connected with the Shrine, unless they opt to the contrary, would be
subject to the administration, disciplinary control of the Board. The terms and conditions of service
shall be regulated by the bye-laws framed by the Board. By operation of sub-section (3), the tenants
or lease-holders who were till the commencement of the Act tenants/licensee of the Dharmarth
Trust are transposed to be tenants of the Board. Section 20 prescribes bar of suits and other
proceedings. Section 21 gives power to the Board to make grants in favour of any institution for
religious spiritual purposes. Section 22 mandates auditing of the accounts of the Board for every
financial year by the Chartered Accountant to be nominated by the Board. Section 23 provides
procedure for arbitration of any dispute arising between the Dharamarth Trust and the Board.
Section 24 gives power to make bye-laws and Section 25 provides for repeal of the Governor's Act
No.XXIII of 1986.
By order dated January 16, 1995, this Court directed the Board to frame a scheme for rehabilitation
of all the persons engaged in the performance of Pooja at Shri Mata Vaishno Devi Shrine and other
temples to be displaced by the implementation of the Act. When the matter had come up on March
20, 1995, Shri D.D. Thakur, Tearned senior counsel appearing for Saridars, stated that Baridars do
not want rehabilitation. Instead they prefer to receive compensation to be determined under Section
20. He pointed out the absence of guidelines for determination of the compensation by the Tribunal
to be appointed under the proviso to Section 20 of the Act. Accordingly, we ordered that the issue be
left to the Governor to make appropriate guidelines to determine the compensation. Pursuant
thereto, guidelines were framed by the Governor were published in the State Gazette and placed on
record on May 8, 1995. By order dated August 21, 1995, the controversy was limited to a question, as
suggested by Shri Thakur, thus; "whether Mata Vaishno Devi Management Board is a controlledBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

corporation?" If the finding was to go in favour of the appellants, they would be entitled to
compensation for deprivation of their right to receive offerings made by the pilgrims to Shri Mata
Vaishno Deviji. The counsel were directed to file the written arguments. Accordingly, written
arguments were filed by the counsel on both sides.
Shri D.D. Thakur contended that Shri Mata Vaishno Devi Board is a controlled Corporation. The
repeal of Article 19(1) (f) and Article 31 of the Telegraph Company vs. City of Los Angeles [57 L.ed.
510; 227 US SCR 1913] and a passage from Shri Kishan Singh & Ors. vs. The State of Rajasthan &
Ors. [(1955) 2 SCR 531 at 539]. On the concept of control under the Act, he placed strong reliance on
the meaning of the word `control' in Black' Law Dictionary (6th Edn.) at page 329. The
Commissioner of Income-Tax, Kerala, Ernakulam vs. V.K. Ramakrishnan [AIR 1968 Kerala 156] In
re: Kodur Thimma Reddi & Ors. [AIR 1957 AP 758]. Right to receive offerings from the pilgrims was
held to be property of Baridars by this Court in Badri Nath & Anr. vs. Mst. Punna (Dead) By Lrs. and
Ors. [AIR 1978 SC 1314 at 1318]. Offerings and other properties were acquired under the Act and got
vested in the controlled Corporation, viz., the Board. For their abolition, Baridars are entitled to
compensation. Section 19 downs not prescribe compensation for payment nor it lay any principle to
determine compensation. Therefore, the Act is ultra vires of the power of the legislature.
Shri P.P. Rao, learned senior counsel contended that by operation of clause (2-A) of Article 31 of the
Constitution, the transfer of ownership of acquired property or right to control any Corporation by
the State under an Act, should in law vest in the State, or in the Corporation owned or controlled by
the State, under the Act. The properties or the offerings are not owned or controlled by the State.
The Board is not a controlled Corporation. The Act requires to be read in the light of the scheme it
has evolved. The sovereign power of the State is to supervise and ensure proper administration or
management of religious institution or an endowment. Secularism, being a basic feature of the
Constitution, the Constitution does not permit the State to interfere with the management of
religious affairs of any religion or denomination. But the State has power to interfere with the same
for proper supervision and efficient management of religious institution or endowment which is
secular in its character. The abolition of the right to receive offerings is part of secular management
of the religious institution or endowment. The legislature, therefore, enacted the Act vesting the
properties including the offerings, in the Board. The Board is a statutory authority under the Act set
up for better management, administration and governance of the Shrine and its endowments
including the sum total of properties attached or appurtenant to the Shrine within the premises
specified in the preamble of the Act. The Board is composed of the Governor and the nominated
nine members. The power to nominate the members is conferred upon the Governor which he
exercises in his ex-officio capacity but not as the executive head of the State with the aid and advice
of the Council of Ministers. His power to nominate a member is conditioned upon his being a
Hindu; he downs not suffer from any disqualification. The power to dissolve or supersede the Board
or reconstitution of the Board within a period of three months and to assume administration within
the interregnum of three months, stands vested only in the Governor obviously in his ex-officio
capacity but not as executive head of the State. Section 9, 11 and 12 of the Act, form back-drop or
throw light as the key to understand the scheme. There is a distinction between the Governor and
the State Government. The analogous provisions in similar Acts in other States like A.P., Bihar, U.P.
and Rajasthan contain provision for interference by the political executive for supersession orBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

reconstitution of the Board and have vested that power in the State Government. The State
Legislature having been aware of that existing law and practice in that behalf, chose to enact the Act
empowering the Governor to act under the Act. The General Clauses Act, though would apply in
interpretation of the Constitution, does not define "Governor". On the other hand, it has defined the
"State Government". Therefore, when the Governor exercises his powers under the Act, he exercises
them in his official capacity as Governor and not as executive head of the State. In support thereof,
he place reliance on Hardwari Lal, Rohtak vs. G.D. Thapase, Chandigarh & Ors [AIR 1982 P & H
439]; Mr Kiran Babu vs. Government of Andhra Pradesh & Anr. [AIR 1986 AP 275]. He also
contended that supervising role of the Governor under Section 9, 11 and 12 is limited to traditional
role and responsibility of the sovereign to ensure proper management and responsible
administration of the religious institutions or endowments and of their properties and nothing
more. The Governor can seek assistance only in an appropriate case from the bureaucracy or
Council of Ministers, if necessary. But the exercise of power under the Act is in his official capacity
as Governor. The properties of the Shrine or the management are not vested in the State. Article 31
(2A) makes it clear and so Article 31(2) does not apply to the facts of the case. Shri Dholakia, learned
senior counsel for the State, contended that the properties of the Shrine and funds are under the
Control of the State; the property is not vested in the State and so the Act is a valid law. There is a
distinction between acquisition and deprivation. The Act deprives Baridars to receive offerings but it
is not an acquisition by the State. Mere deprivation does not amount to acquisition.
The respective contentions give rise to the two-fold question: whether the Board is a controlled
Corporation and whether the Governor exercises the powers under the Act as executive head of the
State or in his official capacity as the Governor of the State of Jammu & Kashmir? We have
elaborately brought out the relevant provisions hereinbefore; hence there is no need to reproduce
them once over. The preamble of the Act makes it clear that the Act regulates only better
management, administration and governance of Shri Mata Vaishno Devi Shrine and its endowments
including the lands and the hills attached and appurtenant to the Shrine within the premises
specified therein, including the Shrine, holy cave and other temples. The are all the properties of the
Shrine. Mutation proceedings do bear it out. The ownership of the Shrine Fund is vested in the
Board. The Board is made entitled to their possession, administration and use "for the purpose of
the Act" and "for convenience, comfort or benefit of the pilgrims".
The administration, management and governance of the Shrine and the Shrine Fund are vested in
the Board consisting of the Chairman and nine members nominated by the Governor. The Governor
is the ex-officio Chairman. In case, the Governor happens to be a non-Hindu, his nominee, who has
to be an eminent person professing Hindu religion and qualified to be a member, shall be ex-officio
Chairman of the Board, obviously, to act as his substitute to preside over the Board participate in the
deliberations of the Board. In other words, he represents the Governor. Nonetheless, the Governor
bears responsibility for proper, efficient and effective management, administration and governance
of the Shrine, its properties, the Fund and to provide facilities and comfort to the pilgrims, the
sustaining source. Nomination of all the persons as members is conditioned upon the qualifications
that they should be Hindus and do not incur all or any of the disqualifications enumerated in
Section 8 of the Act. By virtue of his office as Governor, he shall be the ex-officio Chairman of the
Board and has been vested with the power to nominate nine persons who, in his opinion, haveBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

distinguished themselves in the service of Hindu religion or culture etc. as mentioned earlier. For a
period of three months from the date the Act came into force, the Governor shall act as and exercise
all the powers of the Board until its constitution. Within three months, the Board has to be
constituted or reconstituted even when it is dissolved or superseded or its term expired by efflux of
time. During the interregnum between its dissolution or supersession and reconstitution, the
Governor exercises the powers as the Board. One important factor that cannot be lost sight of is that
in the absence of the Board during the period of three months, either initially at the commencement
of the Act or thereafter, it is the Governor that takes over the management and acts as the Board.
But a peculiar situation may arise when, suppose, the Governor is a non-Hindu, and the governance
and management vest in the executive Government in Cabinet system under the Constitution. Who
would in that situation assume the power of management? Suppose, a Minister and/or for that
matter, the Chief Minister professing Islam are in office, could they discharge the functions under
the Act? Answer is obviously and definitely `No'.
Section 9 empowers the Governor to supersede or dissolve the Board, when the Governor forms an
opinion that the Board is not competent to perform the duties imposed on it under the Act or the
Board persistently makes default in performing the duties imposed on it under the Act or the Board
acts in excess of its authority and power or abuses its power. He was been empowered to supersede
the Board. He is equally empowered to dissolve the Board. But before doing it, the Governor is
required to have a due enquiry conducted, after giving the Board reasonable opportunity of being
heard, i.e., observing principle of natural justice or to avoid any charge of arbitrary action. After
having formed the aforestated opinion, on an objective consideration of the material before him, he
would pass an order either superseding or dissolving the Board. he would reconstitute Board,
shortly thereafter, but not exceeding three months. As soon as it is dissolved, the Governor shall
assume all the powers and perform all the functions and exercise all powers of the Board for a
period not exceeding three months or until the constitution of another Board, whichever is earlier.
This would appear to manifest the legislative intention that the Governor bestows constant personal
care and attention in proper, efficient and effective administration, management and governance of
the Shrine, the sum total of properties and facilities and services to the pilgrims. In case the
Governor happens to be a non-Hindu, he obviously gets the management done through the Board,
The Chief Executive who would always be Hindus and they act under the directions of the Governor.
The Governor has to bestow added personal attention to the management, administration and
governance of the Shrine etc. Similarly, Section 12 gives power to the Governor for good and
sufficient reasons to remove any member after giving him an opportunity of showing cause against
his removal and after consideration of the explanation offered by him. The resignation of any
member shall be by a notice given in writing to the Chief Executive Officer and acceptance of the
same by the Governor. The Governor, when he nominates a member, equally has power to remove
him when the Governor finds any member abusing the office etc. as found in the enquiry. It would,
thus, appear that the Act intends to invest with the Governor the power to nominate the members in
his official personal capacity as the Governor of the State of the power to constitute the Board to
supersede or to dissolve the Board; the Power to accept resignation and to fill up the resultant casual
vacancies under Section 10, are conferred on the Governor. The question, therefore, emerges:
whether such exercise of the powers by the Governor is in his capacity as the executive head of the
State under parliamentary mechanism devised under the Constitution or in his official capacity asBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

Governor of the State?
It is true, as contended by Shri D.D. Thakur, that in interpretation of the Constitution, by operation
of Article 367, unless the context otherwise requires, the General Clauses Act, 1897 (for short, the
"GC Act") as modified, shall apply. Section 3(23) of the GC Act defines "State Government" to
include both the Central Government and the State Government and Section 3(61) defines "State
Government", as regards anything done or to be done, to mean the Governor. Part VI of the
Constitution titled "State Government", as regards anything done or to be done, to mean the
Governor. Part VI of the Constitution titled "The States" consists of Chapter I "General", Chapter II
"Executive", Chapter III "The Legislature, Chapter IV, "The Legislative Power of the Governor",
Chapter V "The High Courts in the States (Judicial Power)", and Chapter VI "Subordinate Courts".
Article 152 in Chapter II defines "State" unless the context otherwise requires, so as not to include
the State of Jammu and Kashmir. Thereby, as regards the State of Jammu and Kashmir, the
distinction is made between the Governor ex-officio and the Governor as executive head of the State,
unless it is applied by exercise of the power under Article 370(1), (i) and (d). Article 370 (1) declares
that "notwithstanding anything in this Constitution", the provisions of article 238 shall not apply in
relation to the State of Jammu & Kashmir and clause
(d) states that subject to such exceptions and modifications as the President may by order specify,
such other provisions of the Constitution shall apply in relation to the said State. Chapter II, Part VI
deals with the executive power of the State. Under Article 153, there shall be a Governor for each
State or one Governor for more than one State. By operation of the First Schedule to the
Constitution, Item 15 relates to State of Jammu and Kashmir. Item 15 read with Articles 1 and 4 of
the Constitution, the territories, which immediately before the commencement of the Constitution
was comprised in the Indian State of Jammu and Kashmir is the State of Jammu and Kashmir. The
Constitution of Jammu and Kashmir, 1957 contains detailed provisions in this behalf and the
executive powers given under Sections 21 to 45 are not inconsistent therewith. it would, thus, appear
that there is no inconsistency in the Constitution of Jammu and Kashmir and the Constitution of
India in application of Chapter II of Part VI of the Constitution in relation to executive power of the
Governor of Jammu and Kashmir.
By operation of Article 154, the executive power of the State shall be vested in the Governor and
shall be exercised by him either directly or through officers subordinate to him in accordance with
the Constitution. By Operation of Article 162, subject to the provisions of the Constitution, the
executive power of the State shall extend to all matters with respect to which the legislature of the
State has power to make law. Thus, except his discretionary powers like that of appointing Chief
Minister, the Governor does not exercise any power in his individual discretion. The Governor is
aided and advised by the Council of Ministers appointed by him under Article 163. The executive
power of the State is co-extensive with that of the legislative power of the State and the Governor in
the constitutional sense discharges the functions under the Constitution with the aid and advice of
the Council of Ministers except in so far as he is by or under the Constitution required to exercise his
functions in his discretion. This is subject to Article 370 and the Constitution (Application to Jammu
& Kashmir) Order, 1950 repealed and revised by the Constitution (Application to Jammu &
Kashmir) Order, 1954 and the Constitution of Jammu & Kashmir, 1957 (Part V). All the executiveBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

actions of the State Government shall be expressed to be taken in the name of the Governor as per
the business rules of the Government made in accordance with Article 166 of the Constitution and
the business rules made by the Governor under clause (3) thereof (Section 45 of the Constitution of
Jammu and Kashmir). In Samsher Singh's case, a Bench of seven Judges of this Court had held that
under the Cabinet system of Government, as embodied in our Constitution, the Governor is the
formal head of the State. He exercises all his powers and functions conferred on him by or under the
Constitution with the aid and advice of his Council of Ministers save in spheres where the Governor
is required by or under the Constitution to exercise his functions in his discretion. The satisfaction
of the Governor for the exercise of any other powers or functions required by the Constitution is not
the personal satisfaction of the Governor but is the satisfaction in the constitutional sense under the
Cabinet system of Government. The executive is to act subject to the control of the legislature. The
executive power of the State is vested in the Governor as head of the executive. The real executive
power is vested in the Council Ministers of the Cabinet. There is a Council of Ministers with the
Chief Minister as its head to aid and advise the Governor in the exercise of his executive functions.
In R.K. Jain vs. Union of India [(1993) 4 SCC 119], it was held that the Cabinet system is a
constitutional mechanism to ensure that before important decisions are taken, many sides of the
question are weighed and considered. The Cabinet takes political decisions of importance and the
permanent bureaucracy works out the details and implements the policy. The Cabine headed by the
Prime Minister bears collective responsibility for the governance of the country. The Cabinet as a
whole is responsible for the advice and conduct of business by each of the members of Cabinet of his
Department and requires to maintain secrecy in the performance of the decision making process
individually or collectively. They are also equally responsible individually and collectively for their
acts and policies. The Cabinet, as a whole, is collectively responsible for the advice to the President
and to the Parliament and the people. In S.R. Bommai & Ors. vs. Union of India & Ors. [(1994) 3
SCC 1] at page 238 in paragraph 313 and 314, this Court had held that the executive power of the
Union shall be vested in the President and shall be exercised by him whether directly or through
officers subordinate to him in accordance with the Constitution. All the executive actions of the
Government shall be expressed to be taken in the name of the President under Article 77(1).
Therefore, he acts with the aid and advice of the Council of Ministers under Article 78 of the
Constitution headed by the Prime Minister as elaborated under paragraphs 313 to 321. In Samsher
Singh's case, this Court had held thus:
"Under the Cabinet system of Government as embodied in our Constitution, the
Governor is the constitutional or formal head of the State and he exercised all his
powers and functions conferred on him by or under the Constitution on the aid and
advice of his Council of Ministers save in spheres where the Governor is required by
or under the Constitution to exercise his functions in his discretion.
The executive power is generally described as the residue which does not fall within
the legislative or judicial power. But executive power may also partake of legislative
or judicial actions. All powers and functions of the President except his legislative
powers as for example in Article 123, viz., ordinance making power and all powers
and functions of the Governor except his legislative power as for example in Article
213 in the President under Article 53(1) in one case and are executive powers of theBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

State vested in the Governor under Article 154(1) in the other case. Clause (2) or
clause (3) of Article 77 is not limited in its operation to the executive action of the
Government of India under clause (1) of Article 77. Similarly, clause (2) or clause (3)
of Article 166 is not limited in its operation to the executive action of the Government
of the State under clause (1) of Article 166. The expression "Business of the
Government of India" in clause (3) of Article 77, and the expression "Business of the
Government of the State" in clause (3) of Article 166 includes all executive business."
The constitutional mechanism, i.e., Cabinet system of Government is devised for convenient
transaction of business of the executive power of the State. Though constitutionally the executive
power of the State vests in the Governor, he does not, unless Constitution expressly conferred on
him, personally take the decision. The decision are taken according to business rules at different
levels and ultimately the decision rests with the authority specified in the business rules and is
expressed to be taken in the name of the Governor. In substance and in reality, decisions are taken
by the Council of Ministers headed by the Chief Minister or the Minister or Secretary as per business
rules. But they are all expressed to be taken by the Council of Ministers in the name of the Governor
and authenticated by an authorised officer. The Governor being the constitutional head of the State,
unless he is required to perform the function under the Constitution in his individual discretion, the
performance of the executive power, which is coextensive with the legislative power, is with the aid
and advice of the Council of Ministers headed by the Chief Minister.
As posed earlier, the question is; when the Governor discharges the functions under the Act, is it
with the aid and advice of the Council of Ministers or in his official capacity as the Governor? The
legislature is aware of the above constitutional mechanism of governance. Equally, the legislature of
Jammu and Kashmir, while making the Act would be presumed to be aware that similar provisions
in the Endowment Acts exist in other States in India. Section 86 read with Section 95 of Andhra
Pradesh Charitable Hindu Religious Institutions and Endowments Act, 1966 gives power to "the
State Government" to dissolve the Board of Trustees of Tirumala Tirupathi Devasthanams and the
Board of Trustees of other institutions and reconstitution thereof. Similarly, in Bihar Hindu
Religious Trusts Act, 1950, Section 7 and 8 give power to the State Government for appointment of
the members of the Board and Section 80 empowers the State Government to dissolve the Board.
The Bombay Public Trusts Act, 1950 confers similar powers on the State Government under
Sections 56D, 56G, 56H and 56R. Orissa Hindu Religious Endowments Act, 1959 contains similar
provisions conferring power on the State Government, vide Section 4 thereof, for constitution of the
Board. The U.P. Shri Kashi Vishwanth Temple Act, 1983 is yet another Act where the entire
responsibility is saddled on the Governor.
It would be clear that the legislature entrusted the powers under the Act to the Governor in his
official capacity. it expressly states that the would preside over the meetings of the Board. If he is a
non-Hindu, his nominee, an eminent qualified Hindu will be his substitute to preside over the
functions. As seen, no distinction between the Governor and executive Government is made by the
legislature in the relevant provisions in the Act. Under Section 9, 11 and 12 of the Act, though the
Governor acts as repository of the sovereign power of the State, the phraseology employed therein
does not indicate that power is given to the Council of Ministers and the Governor is to act on itsBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

advice as executive head of the State. It is an admitted position that prior to the Act, Dharmarth
Trust was in management and administration of the Shrine and the properties attached thereto.
From the material on record, placed in the paper books, it is clear that originally the immovable
properties were mutated in the name of Shri Mata Vaishno Deviji under the management of the
individuals. Subsequently, they were in, Column 5, mutated to be in the possession of Dharmarth
Trust. The ownership of Shri Mata Vaishno Deviji is under the management of Dharmarth Trust. It
was mutated by proceedings dated October 18, 1986 that the properties of Shri Mata Vaishno Deviji
are under the management of the Shrine Board. It is stated that the mutation has been effected
pursuant to the directions issued by the Deputy Commissioner and the Shrine Board has taken over
possession of the properties. Accordingly, entry in that behalf was entered in column 14 thereof. It
was effected by order dated December 27, 1986.
Under Section 5 of the Act, the Board headed by the Governor as the ex-officio Chairman, shall
administer, manage and govern Shri Mata Vaishno Devi Shrine and the Shrine Fund is vested in the
Board as a body corporate with perpetual succession with common seal and it can sue and be sued
in a court of law. The Board discharges the functions and duties under the Act in particular, as
enumerated in 14 to 18. It would, therefore, be apparent from the scheme of the Act that the
legislature, though having been aware of the executive functions of the Governor, in Part VI, Chapter
Ii of the Constitution (Part VI of Jammu and Kashmir Constitution), as head of the State, did not
entrust the power under the Act to the Governor under the mechanism of the Cabinet system
devised under the Constitution. It appears, for the reasons stated supra, that the Governor of the
State of Jammu and Kashmir is required to exercise his ex-officio power as Governor to oversee
personally the administration, management and governance of Shri Mata Vaishno Devi Shrine,
Shrine Fund and the properties vested in the Board. A non-Hindu Governor shall nominate an
eminent Hindu as his deputy responsible for presiding over the meetings as Chairman to take
decisions to be taken by the Board in the administration, management and governance of Shri Mata
Vaishno Devi Shrine and the Shrine fund and sum total of properties attached or belonging to the
Shrine within the premises specified in the premable of the Act and all other properties belonging to
the Shrine and vested in the Board Sections 9, 11 and 12, as stated earlier, gives a clear indication in
that behalf that the Governor is sovereign ex-officio holder of power, shall be responsible for proper,
efficient and effective administration, management and governance of Shri Mata Vaishno Devi
Shrine, Shrine Fund and sum total of the properties etc. Considered from this perspective, we hold
that there is no scope to apprehend that the Board will misuse or abuse the power and mismanage
the funds or properties of the Shrine. Even in case of such necessity, the Governor as the repository
of sovereign power, would always have the assistance, in any given situation or case, to get the
matter examined by an appropriate authority or officer or collect necessary information or material
etc. the same having been placed before him for his decision. The decision is his own decision on his
personal satisfaction and not one the aid and advice of the Council of Ministers. The exercise of the
powers and functions under the Act is distinct and different from those exercised formally in his
name for which responsibility rests only with his Council of Ministers headed by the Chief Minister.
In Hardwarilal's case (supra), a Full Bench of the Punjab and Haryana High Court was to consider
whether the Governor in his capacity as the Chancellor of Maharshi Dayanand University was to actBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

under Maharshi Dayanand University Act, 1975 (Haryana Act No.25 of 1975) in his official capacity
as Chancellor or with aid and advice of the Council of Ministers. The Full Bench, after elaborate
consideration of the provisions of the Act and the statutes, came to observe in paragraph 121 at page
476 that the Act and the statutes intended that the State Government would not interfere in the
affairs of the University. The State Government is an authority quite distinct from the authority of
the Chancellor. The State Government cannot advise the Chancellor to act in a particular manner.
The University, as a statutory Body, autonomous in character, has been given certain powers
exercisable by the Chancellor in his absolute discretion without any interference from any quarter.
In the appointment of the Vice-Chancellor or the Pro-Vice- Chancellor, the Chancellor is not
required to consult the Council of Ministers. Though by virtue of his office as Governor, he becomes
the Chancellor of the University, but while discharging the functions of his office, he does not
perform any duty or exercise any power of the office of the Governor individually. However, while
discharging the functions as a Chancellor, he does every act in his discretion as Chancellor and he
does not act on the aid and advice of his Council of Ministers. The performance of the functions and
duties under the Constitution with the aid and advice of the Council of Ministers is distinct and
different from his discharge of the powers and duties of his office as Chancellor of the University.
Under the Act and the statute, the Chancellor has independent existence and exercises his powers
without any interference from any quarter. Therefore, the office as a Chancellor held by the
Governor is a statutory office quite distinct from the office of the Governor. Same view was taken by
Andhra Pradesh High Court in Kiran Kumar's case. In Ram Nagina Singh & Ors. vs. S.V. Sohni &
Ors. [AIR 1976 Patna 36], the question was as to the appointment of a Lokayukta under Section 3 of
the Bihar Lokayukta Act, 1974 to be made by the Governor in his capacity as Governor of the State,
with the aid and advice of the Council of Ministers. The language of Section 3(1) of the said Act
provides that "the Governor shall be warrant under his hand and seal appoint a person to be known
as the Lokayukta of Bihar". Considering the language in that provisions and the scheme of the Act
for removal of the Lokayukta, the Division Bench came to hold that the Governor, with the aid and
advice of the Council of Ministers, discharges the function in the appointment of the Lokayukta
under Section 3 of that Act. In the light of the language therein, there is little difficulty in upholding
correctness of the decision but it renders little assistance to the present controversy. The ratio in
Mansingh Surajsingh Padvi's case relates to the exercise of the power by the Governor under West
Khandesh Mehwassi Estates (Proprietary Rights Abolition, etc.) Regulation, 1961. From the
notification issued thereunder the learned Judges appears to have reached the conclusion that the
Governor acts with aid and advice of the Council of Ministers. They did not correctly understand the
scope of Schedule V to the Constitution in its relation to the administration of the scheduled area.
The power of State and the Governor in that behalf was not properly understood nor brought home
to the learned Judges. Therefore, the learned Judges were not right in holding that the Governor
while exercising the power under Schedule V of the Constitution acts with the aid and advice of the
Council of Ministers. The law laid down therein is not correct in law.
The next question is: whether the Board is a controlled Corporation? The thrust which Shri D.D.
Thakur forcefully sought to bring home is that the Governor, be it in exercise of his executive power
in the Cabinet system of Government devised under the Constitution or in his official capacity as
Governor, draws his power, which flows from the statute, as the repository of the State executive. He
has control over the nomination f the members to the Board, supersession, dissolution andBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

reconstitution of the Board as well as administration, management and governance of Shri Mata
Vaishno Devi Shrine, Shrine Fund and the sum total of all the properties. He performs the functions
with the assistance of the Chief Executive Officer of the rank not below the District Magistrate and of
the Chief Accounts Officer of the rank not below Deputy Director of Accounts. Government
bureaucrats on deputation and all officers of the Board are under the control and supervision of the
Chief Executive Officer. Therefore, it is a controlled Corporation. Section 19 of the Act, while
extinguishing all rights of the Baridars form the date of the commencement of the Act, does not
provide for compensation in a specified sum nor it lay any principles to determine compensation.
Therefore, the Act is void offending their fundamental rights guaranteed by Article 19(1)(f) and
Article 31(2) of the Constitution. Though, prima facie, the argument is alluring but on deeper probe,
we find it difficult to give acceptance to the same. The presumption in law is that an Act is valid and
the legislature does not intend to enact a law which is ultra vires the Constitution. The burden to
prove contra is on the appellants to establish the contrary. The provisions of the Act are required to
be examined carefully to find whether it is purported to have that effect. Section 19 in this behalf is
relevant. It is already seen that "all rights of Baridars shall stand extinguished from the date of the
commencement of the Act" by operation of sub-section (1) of Section 19 of the Act. It is an admitted
case of the appellants themselves that they perform Pooja and would appropriate part of the
offerings. Their right to perform Pooja is only customary right coming from generations. Section 2 of
the Act gives over-riding effect to any custom, usage of instrument or any law, decree or scheme of
management, notwithstanding anything contained contra to the Act etc. It declares that the Act shall
have over-riding effect thereon. In A.S. Narayana Deekshitulu vs. State of A.P. & Ors. [(1996) 9 SCC
548 at 604] Section 144 of the Andhra Pradesh Charitable and Hindu Religious Institutions and
Endowments Act, 1987 abolished the right of the appellants to receive offerings with the abolition of
the hereditary right of Archaka service. The question arose; whether it offended the religion or
protection of Articles 25 and 26? It was held that the word `religion' used in Articles 25 and 26 of
the Constitution is personal to the person having faith and belief in the religion. The religion is that
which binds a man with his Cosmos, his Creator or super force. Essentially, religion is a matter of
personal faith and belief or personal relations of an individual with what the regards as Cosmos, his
Maker or his Creator which, he believes, regulates the existence of insentient beings and the forces
of the universe. Religion is not necessarily theistic. A religion undoubtedly has its basis in a system
of beliefs and doctrine which are regarded by those who profess religion to be conducive to their
spiritual well- being. Right to religion guaranteed under Article 25 or 26 is not an absolute or
unfettered right but is subject to legislation by the State limiting or regulating any activity
- economic, financial, political or secular which are associated with the religious belief, faith,
practice or custom. The are subject to reform as social welfare by appropriate legislation by the
State. Though religious practices and performances of acts in pursuance of religious belief are, as
must as, a part of religion, as faith or belief in a particular doctrine, that by itself is not conclusive or
decisive. What are essential parts of religion or religious belief or matters of religion and religious
practice is essentially a question of fact to be considered in the context in which the question has
arisen and the evidence - factual or legislative presented in that context is required to be examined
and a decision reached. In secularising the matters of religion which are not essentially and
integrally parts of religion, secularism, therefore consciously denounces all forms of
supernaturalism or superstitious beliefs or actions and acts which are not essentially or integrallyBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

matters of religion or religious belief or faith or religious practice. Non-religious or anti-religious
practices are anti-thesis to secularism which seeks to contribute in some degree to the process of
secularisation of the matters of religion or religious practices. A balance, therefore, has to be struck
between the rigidity of right to religious belief and faith and their intrinsic restrictions in matters of
religion, religious beliefs or religious practices guaranteed under the Constitution. The Andhra
Pradesh Act impugned Therein, was held to regulate administration and maintenance of charitable
and Hindu religious institutions and endowments in their secular administration. It laid emphasis
on preserving Hindu Dharma and performance of religious worship ceremonies and Pooja in
religious institutions according to their prevailing Sampradayams and Agamas. There is a
distinction between religious service and the person who performs the service; performance of the
religious service according to the tenets, Agamas, customs and usages prevalent in the temple etc. is
an integral part of the religious faith and belief and to that extent the legislature cannot intervene to
regulate. But the service of the priest (Archaka) is a secular part. The hereditary right as such is not
an integral part of the religious practice but a source to secure the services of a priest independent of
it. Though performance of the ritual ceremonies is an integral part of the religion, the person who
performs it or associates himself with performance of ritual ceremonies, is not. Therefore, when the
hereditary right to perform service in the temple can be terminated or abolished by sovereign
legislature, it can equally regulate the service conditions sequel to the abolition of the hereditary
right of succession in the office of an Archaka. Though an archaka integrally associates himself with
the performance of ceremonial rituals and daily pooja to the Deity, he is the holder of an office of
priest in the temple. He is subject to the discipline on par with other members of the establishment.
Abolition of emoluments attached to the office of the Archaka, therefore, cannot be said to be
invalid. The customs or usages in that behalf were held not an integral part of the religion. It was,
therefore, held that the legislature has power to regulate the appointment of the Archaka,
emoluments and abolition of customary share in the offerings to the Deity. The same ratio applies to
the facts in this case.
In a private litigation between Baridar holders, this Court in Badri Nath's case (supra) had held that
though the right to receive a share in the offerings was subject to performance of those duties, none
of them was in nature priestly or required a personal qualification. All of them were of non-religious
or secular character which could be performed by the Baridar's agented or servants incurring
expense on his account. When the right to receive the offerings made at a temple is independent of
an obligation to render services involving qualification of personal nature such a right is heritable as
well as alienable. The right of the baridars cannot be equated with the right ad duties of a shebait.
The Baridars are not managers of the Shrine in the sense that a shebait is in relation to a temple in
his charge. The right to share in the offerings being a right coupled with duties other than those
involving personal qualification and being heritable property, it will descend in accordance with the
dictates of the Hindu Succession Act in supersession of all customs to the contrary in view of Section
4 of the Hindu Succession Act. It is seen that Section 2 gives over-riding effect to the Act over any
contrary law or any scheme of the management, decree, custom, usage or instrument. The Act,
therefore, abolishes the customary right or duty of service as Baridar and the receipt of offerings
being conditioned upon performing Pooja, he loses the right with cessation of performing service.
Right to receive offerings, by operation of Section 19(1) of the Act has ceased. The question is;
whether the State controls the vesting of the properties and the Board is a controlled CorporationBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

within the meaning of Article 12 of the Constitution? By operation of Section 6, the Board is a body
corporate with perpetual succession and seal with a right to sue or be sued by or in the name of the
Board. The sum total of properties are of and vest in the Shrine. The management of the Shrine and
the Shrine Fund stood vested in the Board under Section 4. The appellants had the fundamental
right to property guaranteed by Article 19(1) (g) of the Constitution. Though the Constitution (44th
Amendment) Act, 1978 which came into force w.e.f. June 29, 1979, deleted Article 19(1) (g) and
Article 31 by operation of Sections 2 and 6 thereof, they would still be available to the residents of
the Stat of Jammu and Kashmir. In Bela Banerjee vs. State of West Bengal [(1954) SCR 558] Article
31(1) and Article 31(2) of the Constitution were interpreted by the Constitution Bench and it was
held that the word `compensation' must mean a full and fair money equivalent. The same ratio was
followed in State of West Bengal vs. Kameshwar Singh [AIR 1952 SC 252]. The Constitution (5th
Amendment) Act was made in 1955 amending Article 31(2) and also introducing Article 31(2A). It
would, therefore, be necessary to look into those provisions relevant to the case since they were
operative in the field when the Act was enacted. They read as under:
"31. Compulsory acquisition of property - (1) No person shall be deprived of his
property save by authority of law.
(2) No property shall be compulsorily acquired or requisitioned save for a public
purpose and save by authority of a law which provides for acquisition or
requisitioning of the property for a compensation which may be fixed by such law or
which may be determined in accordance with such principles and given in such
manner as may be specified in such law;
and no such law shall be called in question in any court on the ground that the
amount so fixed or determined is not adequate or that the whole or any part of such
amount is to be given a otherwise than in cash:
Provided that in making any law providing for the compulsory acquisition of any
property of an educational institution established and administered by a minority,
referred to in clause (1) of Article 30, the State shall ensure that the amount fixed by
or determined under such law for the acquisition of such property is such as would
not restrict or abrogate the right guaranteed under that clause.
(2A) Where a law does not provide for the transfer of the ownership or right to
possession of any property to the State or to a corporation owned or controlled by the
State, it shall not be deemed to provide for the compulsory acquisition or
requisitioning of property, notwithstanding that it deprives any person of his
property."
In Charanjit Lal Chowdhary vs. Union of India [(1950) SCR 869 at 902] it was held
by the Constitution Bench that the acquisition means and implies the acquiring of the
entire title of the appropriate owner, whatever the nature or extent of the title might
be. All rights which were vested in the original holder would pass on acquisition toBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

the acquirer leaving nothing in the former. In State of West Bengal vs. Subodh Gopal
Bose & Ors. [(1954) SCR 587], the view taken was that clauses (1) and (2) of Article 31
were to be read together to call out the scope of contents, and understood as dealing
with the same subject, viz., the protection of the right to property by means of
limitations on the State's power. Wider meaning, therefore, was given to the word
`acquisition'. Deprivation contemplated therein was interpreted to mean divesting
title and vesting it in the State and the word `requisition' to mean taking possession
of the property other than by acquisition of the property mentioned in clause (2) of
Article 31. Same view was expressed in Kameshwar Singh' case (supra). In
Dwarkadas Shrinivas of Bombay vs. The Sholapur Spinning & Weaving Co.
Ltd. & Anr. [(1954) SCR 674], it was held that acquisition was a quite wider concept, meaning
thereby procuring of the property and taking of it permanently or temporarily. It was not confined
only to the acquisition of the legal title by the State in the property taken possession of. As a
consequence, clause (2A) of Article 31 was brought on the Constitution by Constitution (4th
Amendment) Act in 1955. Clause (2A) of Article 31 provides that where law does not envisage
transfer of ownership or right to possession of any property to the State or to a Corporation owned
or controlled by the State, which shall not be deemed to provide for the compulsory acquisition or
requisition of the property, notwithstanding that, it deprives any person of his property. At this
juncture, we may dispose of the contentions of Shri Dholakia as being untenable. Acquisition has the
effect of deprivation and enjoyment of the property. the acquisition in order to be valid must be for a
public purpose and the person deprived of the same is entitled to compensation. However, in
respect of the property which was divested from him, e.e., right, title and interest coupled with
possession must be vested in the State or beneficiary. Such deproved person is entitled to
compensation. It is equally settled law that abolishing and/or extinction does not mean vesting. The
two are distinct and separate. Deprivation of property is concomitant to acquisition in that context.
The right to superintendence of management, administration and governance of the Shrine is not
the property which the Stat acquires. It carries with it no beneficial enjoyment of the property to the
State. The Act merely regulates the management, administration and governance of the Shrine. It is
not an extinguishment of the right. The appellants-Baridarans were rendering pooja, a customary
right which was abolished and vested in the Board. The management, administration and
governance of the Shrine alwayed remained with the Dharmarth Trust from who the Board has
taken over the same for proper administration, management and governance. In other words, the
effect of the enactment of the Act is that the affairs of the functioning of the Shrine merely have got
transferred from Dharmarth Trust to the Board. The At merely regulates in that behalf incidentally,
the right to collect offering enjoyed by the Baridarans by rendering service of Pooja has been put ti
an end under the Act. The State, resultantly, has not acquired that right onto itself. The contention
of Shri D.D. Thakur is that the word "control" is of wider connotation and, therefore, requires to be
interpreted in the light of the scheme of the Act, i.e., the Governor exercise, as the repository of the
State power or State executive power in the matter of nomination of nine members of the Board, the
supersession/dissolution and reconstitution of the Board and filling up of the vacancies or
appointment of a new post and taking care of the management, administration and governance of
the properties of the Shrine through the Board. So, the Governor exercises his executive power of
the State as Governor and, therefore, the Board is a controlled Corporation.Bhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

It is true that the word "control", as defined in Black's Law Dictionary [Sixth Edition] at page 329,
means as verb "to exercise restraining or directing influence over; to regulate; restrain; dominate;
curb; to hold from action; overpower; counteract; govern; Power of authority to manage, direct,
superintend, restrict, regulate, govern, administer or oversee. The ability to exercise a restraining or
directing influence over something". In S. Gurmukh Singh vs. Union of India & Ors. [AIR 1952 Pun.
143], a Full Bench of the High Court had held that the Executive power of the Union of India is
vested in the President and is exercised by him. The Government is for all practical purposes
synonymous with the Executive of the country. If the executive power of the country is vested in the
President and is exercised by him, the act of the President must be deemed to be the act of the
Government or of the State. The official acts of the President are the official acts of the State for the
purposes of Article 15 of the Constitution. Therefore, the State is synonymous with the President or,
at any rate, includes his official personality when acts of the State are under Articles 15 and 341 of
the Constitution. The Division Bench of the Andhra Pradesh High Court in Re: Kodur Thimma
Reddi & Ors. [supra] in the context of Section 19F of the Arms Act had held that the word "control"
over a fire arm by the person in possession means a conscious possession in his control but when it
is accessible to others, it was held that he was not having the control. Similar view was taken by the
Kerala High Court. However, these decisions do not assist us in deciding this case.
To appreciate the contentions, it is necessary to deal clauses (2) and (2A) of Article 31 together. If so
read, the expression "Corporation owned or controlled by the State"
clearly indicates that the control should be total control which is as good as
ownership of the Corporation by the State. The ownership of the acquired property is
through its Corporation owned by the State. The Corporation is only a cloak. The
State should be able to deal with the property transferred to the Corporation by virtue
of its control as if it deals with property transferred to itself or the Corporation is only
a conduit pipe itself to use the property as if it is owned by itself. The control of the
State as envisaged in clause (2A), should have nexus with the property transferred to
the Corporation. Then only it may be said that there was compulsory acquisition of
the property by the State and the property is owned by the Corporation owned on
controlled by the State as having been vested in it. Under the Land Acquisition Act,
when the property is acquired, the right, title and interest of the previous owner
stand extinguished after taking possession of the land and is vested in the State under
Section 16 f that Act or the transfree-beneficiary free from all encumbrances. That
would be total divestment of pre-existing right, title and interest in the land by the
previous owner and vesting of the same in the State or the Corporation controlled by
the State. In order to attract clause (2A) of Article 31, the law in question should,
therefore, provide for the transfer of ownership of the property of the Baridars to the
State or to a Corporation owned or controlled by the State. There is no dispute that
the impugned Act does not transfer the ownership of the property of Baridars to the
State or to a Corporation owned by the State. It merely extinguishes the right of the
Baridars. The appellants' contention is that the Act has merely transferred the right
to property of the Baridars to the Shrine Board which is a Corporation controlled by
the State. This is not correct because the word "controlled' has to be construed in theBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

light of the preceding word `owned'. The control should be to such an extent as
would amount to virtual ownership by the State as indicated above. In the instant
case, the Act deals with the property of a religious institution which cannot be owned
by the State under the Constitution and which cannot be controlled by the State, like
an owner, having regard to the basic feature of secularism permeating the
Constitution, which separates religion from the State. When the property, namely,
right to recover offerings is extinguished by Section 19(1) of the Act, it does not vest
in the State; on the other hand, the board becomes entitled to the right to the
collection, possession and management of the offerings given to the Shrine and
provide welfare services and facilities to the pilgrims. The Governor exercises his
statutory power as ex-officio Chairman of the board, though he is the repository of
State power by virtue of his office as a Governor. Nonetheless, he exercises it in his
capacity as Chairman, a distinct and separate function and power and not in the
constitutional sense of the Cabinet system, of performing executive power the State
Government has under
the Constitution, with the aid and advice of the Council of Ministers headed by the
Chief Minister. The power to supervise and to take remedial steps to correct
mismanagement, abuse of power or incompetence to exercise the power or access of
the line power are only incidental to the management, administration or governance
of Shri Mata Vaishno Devi Shrine, Shrine Fund and the properties including the
collection and taking possession of the offerings. All are his individual performance
of the statutory functions in his official capacity as Chairman of the Board and not as
Governor. Therefore, by exercising the power under the Act, it is impressible for the
State to deal with the properties vested in the Board in terms of the Act; the Act does
not permit the State to deal with the said properties as if they are the properties of the
State acquired directly or indirectly through the medium of the Board. The extent of
supervision permitted by the provisions of the Act is limited to and only to ensure
proper, efficient, effective and responsible administration, management and
governance of the Shrine, properties of the Shrine and Fund of the Shrine and
nothing more. The degree of control required in clause (2A) of Article 31 is, therefore,
missing in the Act.
In Gullapalli Nageswara Rao & Ors. vs. Andhra Pradesh State Road Transport
Corporation & Anr. [1959 Supp. (1) SCR 319] it was contended that the State by
nationalisation of the Transport Services, exercised its power in Chapter IVA of the
Motor Vehicles Act, 1939 and in effect and substance authorised in law to effect the
transfer of the business of the citizens to the State or a Corporation owned or
controlled by the State, without paying full equivalent of the compensation under
Article 31(2). The acquisition was, therefore, contended to be invalid. Repelling the
contention, the Constitution Bench of this Court had held that Section enabled the
Government to frame a scheme and give effect to the approved scheme in respect of a
notified area of a notified route and stop the private operators from entering on the
notified route, from entertaining any application for renewal of any other permit andBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

from cancelling any existing permit or modifying the terms of existing permit so as to
render the permit ineffective from the specified date. The impugned provision was
held to be a regulated power conferred on the Transport Authority in the interest of
the public for efficient, economical and co- ordinate regulated service offered by the
STU. The business of the private operators and the STU has nothing to do with one
another. They are two independent businesses carried on under two different
licenses. The contention that the scheme enabled the nominee of the State to do the
business and, thereby, in effect and substance transfer the business on the existing
permit holders to the STU was held to be not correct. The contention was held to be
fallacious. It may be by process of law that the existing permit holders are precluded
from doing their business and it also may be that the STU carriers on a similar
business. By no stretch of imagination, in law it can be said that STU is doing
business carried on by previous permit holders by or on behalf of the State.
Accordingly, it was held that the State has no control and it is not an acquisition on
behalf of the State. In Union of India vs. Sudhansu Mazumdar & Ors. [1971]) Supp.
SCR 244], on September 10, 1958 an agreement was entered into between the
Government of India and Pakistan called the "Indo-Pakistan agreement". Item 3 of
the agreement related to transfer of group of villages lying within the territory of
India, known as Berubari Union No. 12 and it was accordingly transferred to
Pakistan. It was contended that it was an acquisition without compensation violating
Article 31(1) and (2) of the Constitution. This Court by a Constitution Bench had held
that in order to constitute acquisition or requisition, there must be transfer of
ownership or of right to possession of any property to the State or Corporation owned
or controlled by the State. It was held that the effect of the Constitution, by the
Constitution (9th Amendment) Act, 1960 by no stretch of imagination could be
regarded as transfer of Berubari Union No.12 to Pakistan as transfer of the ownership
or of right to possession of any property of the respondents in the State under Article
31(2) of the Constitution. The Amendment Act, 1955 made it clear that mere
deprivation of the property, unless its acquisition or requisition was within the
meaning of clause (2A), shall not attract clause (2) and no application to pay
compensation will arise thereunder. In Katra Education Society, Allahabad vs. State
of U.P. [AIR 1966 SC 1307 at 1311] the contention was that Section 16F(4) of the U.P.
Intermediate Education Act, 1921 violated their fundamental right under Article 14,
19 or 31 of the Constitution. It was contended that since the scheme of management
did not provide for any compensation, it was ultra vires the Constitution. The
Constitution Bench rejected the contention by holding that the educational
authorities, after considering the representation of the management, had the power
to make recommendation after selectmen. The power to appoint persons possessed of
prescribed qualifications vests in the institution. The education authorities did not
accept suitability of persons selected by the management on the specified grounds,
and reasons therefor. It is only an exercise of the control envisaged by the
amendment of Section 16D(3) of the Act with a view to prevent appointment of
unqualified person. The power under Section 16D(4) entrusted to the authorised
controller was merely of management. Management of institution in respect of whichBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

Authorised Controller had been appointed had to be conducted and carried out in
accordance with the directions given by the Authorised Controlled. IT was held that
the property did not vest in the State but continued to remain the property of the
institution as Article 31(2A) saves such control and Section 31(2) has no application.
In Constitutional Law of India by H.M. Seervai (Third Edn.) Volume II at page 1109 in para 30 it is
stated that distinction between ordinary acquisitions where law provides full compensation and
large schemes of social engineering or reform which would have to be located at from the point of
view of justice to the individual as well as to the community, is harmonised by the legal view. In the
after light of Bela Banerjee's case (supra), it is clear that the eminent lawyers (founding fathers of
the Constitution) committed a grave error in leaving to implication what they could have clearly
expressed in Article 31(2). Bela Banerjee's case showed that the intention of the framers failed
because it was not expressly embodied in Article 31(2). Obviously, an amendment of the
Constitution is meant to change the existing law, and the 4th Amendment by excluding the
challenge on the ground of adequacy of compensation was meant to change the law laid down in
Bela Banerjee's case that compensation under Article 31(2) meant a full and fair money equivalent.
After the 4th Amendment, the word "compensation", could not mean a full and fair money
equivalent, for if it did, the law would have remained unchanged and the 4th Amendment would
have failed of its purpose. By excluding a challenge on the ground that the compensation provided
by the law was not adequate, the 4th Amendment removed the restriction on legislative power in the
sense that for the law to be valid it was no longer obligatory to provide for the payment of full and
fair money equivalent. After the 4th Amendment a law which fixed compensation which amounted
to 80 per cent of full and fair money equivalent would not violate Article 31(2) and was a valid law.
The 4th Amendment achieved this result by introducing the concept of inadequate compensation.
On consideration of above provisions, we have, therefore, no hesitation to hold that the Board is not
a controlled Corporation within the meaning of Article 12 of the Constitution. By operation of clause
(2A) of Article 31 of the Constitution the Board or the properties of the Shrine did not vest in the
State. The right to collection of the offerings or the divestment of the properties, if any, of the
Baridars or the right to collection or a share in the offerings do not vest in the State. Consequently,
Section 19(1) of the Act is not ultra vires of Article 19(1)(f) or Article 31(2) of the Constitution.
It is seen that the proviso to Section 19 provides that the Governor may appoint a Tribunal which,
after giving personal hearing to the Baridars and the representations of the Board, "shall
recommend compensation to be paid by the Board in lieu of extinction of their right". While making
its recommendations to the Board, the Tribunal "shall have due regard to the income which the
Baridars had been deriving as Baridars". The Board shall examine the recommendations forwarded
to it by the Tribunal and take such decision as it may deem appropriate. The decision of the Board
shall be final. Pursuant to the directions issued by this Court, the Governor made guidelines which
were duly notified in the Gazette. Another notification inviting claims from Baridars was published
and time was extended from time to time informing to lay claims for compensation. It would appear
that while the matter remained pending, the Baridars do not seem to have not laid their claims. The
guidelines framed by the Governor are by exercising the rule-making power under Section 24 of the
Act. So they acquired the status as subordinate legislation and became integral part of the proviso to
Section 19 of the Act. As we have upheld the Act, they are at liberty to file their claims within twoBhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

months from today. The Tribunal shall have due regard to the guidelines in determining the income
of Baridars before the Tribunal makes its recommendations to the Board for consideration and the
Board shall also take a decision, as it may deem appropriate, consistent with proviso to Section 19(1)
and the guidelines, in the light of the recommendations made by the Tribunal. It would be obvious
that in case the Board does not find itself in agreement with the recommendations made by the
Tribunal, it would be required to state its reasons in that behalf, give an opportunity to the Baridars
and, if necessary, a personal hearing through their representatives or a counsel and then take a
decision to pay compensation as it may deem appropriate. In case it disagrees with the
recommendations of the Tribunal, it should record reasons in writing and would communicate the
same to all the affected persons. This exercise should be done within two months from the date of
the receipt of the recommendations of the Tribunal. The Governor would appoint the Tribunal
within six weeks from the date of the receipt of the judgment. We hope and trust that the Tribunal
would dispose of the claims as expeditiously as possible since more than a decade has passed by
now.
The appeals are accordingly disposed of but, in the circumstances, there is no order as to costs.Bhuri Nath & Ors. Etc. The Sewa Committee ... vs The State Of Jammu & Kashmir & Ors on 10 January, 1997

