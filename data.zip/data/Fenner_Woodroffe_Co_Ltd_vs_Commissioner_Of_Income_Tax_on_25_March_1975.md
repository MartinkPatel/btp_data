Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax
on 25 March, 1975
Equivalent citations: [1976]102ITR665(MAD)
Author: V. Ramaswami
Bench: V. Ramaswami
JUDGMENT
 V. Ramaswami, J. 
1. The assessee--M/s. Fenner Woodroffe & Company Ltd. (since changed to Gordon Woodrofle
(Belting) Ltd.), Madras, was incorporated in India as a private limited company in 1959. It carries
on business in the manufacture and sale of leather belting and other industrial leather, having been
licensed under the Industries (Development and Regulation) Act. The assessee-company entered
into an agreement on July 22, 1959, with M/s. Henry F. Cockill & Sons Ltd., a company
incorporated in England, The relevant portions of the agreement read as follows :
"(A) Cockill has for many years been engaged in the manufacture of (inter alia) the
product (as defined in Clause 1 of this agreement) and during that time has
discovered and acquired valuable secret processes and technical knowledge in
connection with such manufacture.
(B) The Indian company is proposing to undertake the manufacture of the product in
India and has requested Cockill to make available to it Cockill's secret processes and
technical knowledge in relation to the product which Cockill has agreed to do upon
and subject to the terms of this agreement.
NOW THIS AGREEMENT WITNESSETH AND IT IS HEREBY AGREED AND DECLARED AS
FOLLOWS :
1. In this agreement where the context so permits the following expressions shall
have the meanings set opposite thereto respectively, that is to say:
(a) "the product" means leather belting and such other products as may from time to
time be agreed on by Cockill and the Indian company.Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

(b) "the territory" moans the Rupublic of India as now constituted.
(c) "technical data" means (subject as hereinafter provided) all processes, formulae,
engineering drawings, tool designs, bills of material specifications and any other
technical information in the possession of Cockill necessary to enable a competent
manufacturer to undertake the manufacture on a commercial scale of the product to
which the technical data relates PROVIDED that any such supplied to Cockill by a
third party under licence or under a pledge of socrecy are excepted from the scope of
this definition.
2. In consideration of the remuneration to be paid by the Indian company to Cockill as hereinafter
provided, Cockill--
(a) shall within fourteen days after the date hereof supply to the Indian company the
technical data relating to leather belting ;
(b) shall from time to time, when in Cockill's opinion the Indian company is able and
ready to undertake the manufacture of the remainder of the products, disclose to the
Indian company the technical data relating thereto;
(c) hereby grants to the Indian company the right without further let or hindrance
from or by Cockill, to use the technical data for the purpose of the manufacture in the
territory only of the product;
(d) shall promptly and to the best of its ability advise the Indian company in
connection with any technical or manufacturing problems or difficulties which may
(as provided in Clause 9 hereof) be referred to it by the Indian company during the
continuance of this agreement.
3. (a) As consideration for the services to be provided by Cockill to the Indian company pursuant to
this agreement the Indian company shall pay to Cockill in free sterling in England subject to
deduction of Indian taxes and approval of the Reserve Bank of India a service fee equal to one-half
of one per cent. of the amount of the ex-factory invoice prices of the Indian company in respect of
the quantities of the product sold by the Indian company--......
5. (a) To assist the Indian company in the manufacture of the product, Cockill shall when required
by the Indian company--
(i) provide technicians from its own staff to attend at the Indian company's factory in
India but the full salary and first class travelling and board and lodging expenses of
such technicians from the time of leaving home to the time of return shall be paid by
the Indian company ;Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

(ii) provide training facilities at the works in England of Cockill and/or its associated
companies for selected Indian technicians but the salary and all travelling and board
and lodging expenses of such technicians shall be paid by the Indian company.
(b) The parties mutually agree that they will each inform the other of any new
developments in design, texture, materials or methods of manufacture which they
respectively may discover during the continuance of this agreement but only in so far
as any such new developments are applicable to the product.
6. (a) The Indian company shall use upon or in connection with the product such trade marks as
Cockill may from time to time designate by notice in writing addressed to the Indian company
provided that nothing herein contained shall authorise the Indian company to use any trade marks
owned by Cockill except as a registered user thereof in conformity with laws of the territory.
(b) Cockill shall grant or procure the grant to the Indian company and the Indian company shall
enter into such registered user agreements as may be necessary for the purpose aforesaid and each
party shall do all things necessary to procure the registration of any such registered user agreement.
7. The Indian company may not except with the prior written consent of Cockill assign, mortgage,
charge or otherwise alienate its rights under this agreement and may not grant any sub-licence or
sub-rights hereunder.
8. The Indian company shall use and maintain and procure its officers and employees to use and
maintain the utmost secrecy in connection with any technical data supplied by Cockill to the Indian
company hereunder.
9. The Indian company shall not during the continuance of the agreement refer any technical or
manufacturing problems or difficulties to any one other than Cockill but shall regard and use Cockill
as its sole technical consultant.
10. (a) Subject as hereinafter provided, the agreement shall continue in force for a period of ten
years from the date hereof.
(b) If either party shall commit any breach of any of its obligations hereunder and shall fail to
remedy the same within thirty days of written notice from the other party requiring that such breach
shall be remedied or if either party shall become insolvent or go into liquidation whether voluntary
or compulsory (otherwise than for the purpose of reconstruction or amalgamation) or shall have a
receiver appointed of its assets or any part thereof or shall make any assignment or composition for
the benefit of its creditors then the other party may by written notice forthwith determine this
agreement.
(c) Determination of this agreement shall be without prejudice to any rights which may have
accrued to either party hereunder prior to the date of such determination....."Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

2. The company went into production in May, 1960. As per the above provisions in the agreement
the assessee-company paid the sums of Rs. 5,808, Rs. 5,617 and Rs. 4,508 during the accounting
years relevant to the assessment years 1962-63, 1963-64 and 1964-65, respectively. The company
claimed deduction of these amounts from the income of the respective assessment years. The
Income-tax Officer was of the view that the amount represented the consideration paid for making
available to the assessee-company the technical know-how and the technical data for starting the
new industrial venture in India and that it was obvious that the assessee had acquired a benefit or an
asset of an enduring nature by such payment. In that view, he held that it is an expenditure of a
capital nature and, therefore, disallowed the claim. The assessee preferred appeals before the
Appellate Assistant Commissioner in respect of all the three assessment years. By a common order
the Appellate Assistant Commissioner held that the fee paid was for the use of the technical data and
that......... Though in the longer run the assessee might be benefited by experience that would not
make it a capital investment and that the amounts claimed were in the nature of a revenue
expenditure. Revenue preferred appeals to the Tribunal. The Tribunal on an interpretation of the
terms of the agreement held that till the date of the agreement the assessee was not manufacturing
leather belts or any other leather products and it was for the first time entering into a new venture to
manufacture those products with foreign collaboration and the foreign company had undertaken to
supply the secret process and technical data required for the production. The Tribunal further held
that the technical information or know-how supplied by the foreign collaborators to the
assessee-company was a capital asset and that the payments made for the purchase of that was a
capital expenditure. In any case, the assessee-company had acquired an asset or benefit of an
enduring nature and, therefore, the amount spent or laid out for acquiring such enduring benefit
would be a capital expenditure. In coming to this conclusion the Tribunal relied on the fact that
there was no provision in the agreement that the technical data obtained by the assessee can be used
by it for the duration of the agreement and there was also no provision for returning the drafts of
formulae, engineering drawings, tool designs, etc., to the foreign collaborators on the expiry of the
agreement or a prohibition to the use of the knowledge acquired beyond the period of the
agreement. In support of this view, the Tribunal relied on the decision of the Mysore High Court in
Mysore Kirloskar Ltd. v. Commissioner of Income-tax, [1968] 67 ITR 23 (Mys) and distinguished
the decision of the Bombay High Court in Commissioner of Income-tax v. Ciba Pharma Private Ltd.,
[1965] 57 ITR 428 (Bom).
3. At the instance of the assessee, the following question has been referred :
"Whether, on the facts and in the circumstances of the case, the payment of the sums
of Rs. 5,808, Rs. 5,617 and Rs. 4,508 made by the assessee to M/s, Henry F. Cockill
and Sons Ltd. are admissible deductions under the Income-tax Act, 1961, for the
assessment years 1962-63, 1963-64 and 1964-65, respectively ?"
4. The learned counsel for the assessee contended that this was a case where the foreign company
had no business or goodwill in this country and they did not part with any of their capital asset, but
they just only taught the assessee as to how to make the specified articles. In other words, they
shared the knowledge without in any way affecting or diminishing its value to them and, therefore,
no asset was acquired by the assessee. They were only utilising their knowledge for the purpose ofFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

earning profit. The assessee also incurred the expenditure not for the purpose of bringing into
existence any such asset or advantage of an enduring nature but for running the business or working
it with a view to produce profit. Though the assessee-company was started with the agreement
before commencing its business, the expenditure is linked with the manufacture and, therefore, it
was an allowable business expenditure. In any case the money paid subsequent to the company
commencing production is only a revenue expenditure. On the other hand, the learned counsel for
the revenue submitted that the technical data and know-how was given for the very establishment of
the assessee-company and that know-how derived by the assessee is a capital asset. Even otherwise,
the learned counsel for the revenue contended, the expenditure incurred by the assessee would
amount to an outlay which brings in an advantage of an enduring nature to the trade and, therefore,
not an allowable expenditure.
5. We may now notice three cases decided by the House of Lords which throw some light on the
point to be considered. They are--Evans Medical Supplies Ltd. v. Moriarty, [1957] 37 TC 540; [1959]
35 ITR 707 (HL), Jeffrey v. Rolls-Royce Ltd., [1962] 40 TC 443; [1965] 56 ITR 580 (HL) and Musker
v. English Electric Co. Ltd., [1964] 41 TC 556 (HL). In Evans Medical Supplies case the facts as
summarised in the headnote were as follows :
"The appellant-company, which manufactured pharmaceutical products and had a
world-wide trade, carried on business in Burma through an agency. In 1953 the
Burmese Government wished itself to establish an industry there for the production
of pharmaceutical and other products, and the company secured a contract, dated
20th October, 1953, from the Burmese Government to assist in setting up this
industry. The company undertook to disclose secret processes to the Burmese
Government and to provide other information in consideration of the payment of a
'capital sum of 100,000'. The company also undertook to provide certain services and
to manage the proposed factory in return for an annual fee, which was admitted to be
subject to tax. No similar agreement had been entered into by the company with any
other foreign Government or any other party."
6. It was held that the sum of 100,000 received by the company represented consideration for the
sale of a capital asset and was a capital receipt in the hands of the company. There the members of
the House of Lords--Lord Simonds, Lort Morton of Henry ton and Lord Tucker agreeing with the
Court of Appeal and Upjohn J. in the Chancery Division--also held that the know-how should be
regarded as capital asset of the company.
7. In Rolls-Royce case the facts as set out in the head-note were as follows:
"The respondent-company, during the manufacture of aero engines, had engaged in
metallurgical research and the development of engineering techniques and acquired a
fund of technical knowledge commonly called 'know-how'. During the period 1946 to
1953 it entered into a number of agreements with foreign governments and
companies under which it agreed to supply information necessary to construct
certain engines which it had developed and to license the other party to manufactureFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

these engines. For example, by an agreement with the Republic of China the company
undertook to license the Chinese to manufacture a Rolls-Royce jet aero engine and to
supply the necessary information and drawings ; to advise them from time to time as
to improvements and modifications in manufacture and design ; to instruct Chinese
personnel in their works and to release one or two members of their own staff to
assist in China with the manufacture of the engine in consideration of the payment of
' a capital sum of fifty thousand pounds' plus royalties. Agreements in similar terms
were entered into with the Governments of Argentina, Belgium and Australia and
companies in France, the United States of America and Italy. Some of these
agreements provided for payment of an annual technical liaison fee in addition to the
capital sum."
8. The Special Commissioners and the High Court upheld the contention of the company and held
that the consideration paid for the know-how represented a capital receipt in the hands of the
company. But the Court of Appeal and the House of Lords took a different view and held that the
sums in question were receipts on revenue account of the company's trade. The Court of Appeal held
that know-how was part of the capital equipment of a company and the nature of the receipt
depends almost entirely on the circumstances of each case and the nature of the contract or
contracts under which the lump sum or sums were paid. The company could exploit this capital
equipment in producing the articles they sell or alternatively or in addition they can be imparted to
others for reward. The nature of the consideration for imparting the know-how, whether capital or
revenue, would depend on the circumstances of each case and the nature of the contract. If the
knowledge imparted is some secret of permanent value given by the owner while transferring or
terminating the business the consideration received would amount to a sale of a fixed asset and the
consideration also a capital receipt. The House of Lords also took the view that know-how is an
intangible asset of sui generis. Lord Radcliffe, as he then was, as to the nature of know-how, said,
[1965] 56 ITR 580, 585 (HL).:
"First, as to 'know-how'. I see no objection to describing this as an asset. It is
intangible: but then so is goodwill. It would be difficult to identify with any precision
the sources of the expenditure which has gradually created it and, patents apart, I
would not have thought of it as a natural balance-sheet item. But it is a reality when
associated with production and development such as that of Rolls-Royce, and a large
part, though not the whole of it, finds its material record in all those lists drawings
and manufacturing and engineering data that are specified in the various licence
agreements.
It is fundamental to the appellants' case that we should categorise this asset as being
part of their fixed capital. Indeed, their argument proceeds from the premise that it is
fixed capital. That, I think, is to start from too assured a base. An asset of this kind is,
I am afraid that I must use the phrase, sui generis. It is not easily compared with
factory or office buildings, ware-houses, plant and machinery or such independent
legal rights as patents, copyrights or trade marks, or even with goodwill. 'Know-how'
is an ambience that pervades a highly specialised production organisation and,Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

although I think it correct to describe it as fixed capital so long as the manufacturer
retains it for his own productive purposes and Expresses its value in his products,
one must realise that in so describing it one is proceeding by an analogy which can
easily break down owing to the inherent differences that separate 'know-how' from
the more straightforward elements of fixed capital. For instance, it would be wrong to
confuse the physical records with the 'know-how' itself, which is the valuable asset:
for, if you put them on a duplicator and produce one hundred copies, you have
certainly not multiplied your asset in proportion. Again, as the facts of the present
appeal show, 'know-how' has the peculiar quality that it can be communicated to or
shared with others outside the manufacturer's own business, without in any sense
destroying its value to him. It becomes, if you like, diluted, and its value to him may
be affected, though, in my view, it begs the question to say that that value is
necessarily reduced because the asset is used for outside instruction. These
considerations lead me to say that, although 'know-how' is properly described as
fixed capital by way of analogy, it is the kind of intangible entity that can very easily
change its category according to the use to which its owner himself decides to put it. I
am not sure that it is too much to say that it is his use of it that determines the
category. It is not like a single physical entity which must be employed for production
or else broken up ; it is more like a fluid in store which can be pumped down several
channels."
9. In English Electric Company's case, the facts as summarised in the head-note were as follows :
"The respondent-company, in the course of carrying on its trade of engineering
manufacturers, acquired a fund of specialised information and technique in
engineering processes. It had not been its practice to turn this information and
technique to account by imparting it to others. In 1949, however, at the request of the
Admiralty, the company entered into an agreement to design and develop a marine
turbine and to license its a manufacture by a limited number of companies in the
United Kingdom, Australia and Canada. Later, in 1950 and 1952, the company, at the
request of the Ministry of Supply, entered into agreements with the Government of
Australia and an American aircraft manufacturing corporation, respectively, under
which it licensed them to manufacture the Canberra bomber which it had designed
and developed. All three agreements provided, inter alia, for the imparting of
'manufacturing technique' to the licensees and in consideration of this the company
received specified lump sum payments."
10. Justice Pennycuick held that the case was governed by the decision in Rolls-Royce case. As for
the difference between Evans Medical Supplies, [1959] 35 ITR 707 ; [1957] TC 540 (HL.) case and
Rolls-Royce case, the learned judge observed :
"It was held, then, in the Rolls-Royce case, that what is called 'know-how', in the
hands of a manufacturer is an asset of such character that it may be communicated
for value to another, on the one hand in such manner that it loses its value to theFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

trader--in which case the consideration is capital--or on the other hand in such
manner that it retains its value to the trader--in which case the consideration must be
brought into account in the computation of income profit. I hope that is not an undue
simplification of the decision for the purpose of the present case. The Evans Medical
Supplies case was an instance of the former, the Rolls-Royce case, an instance of the
latter type."
11. While confirming this decision, Lord Denning M. R. in the Court of Appeal said:
"Now it seems to me that this is a typical case of 'know-how'. 'Manufacturing
technique' is just 'know-how'. 'Know-how' is an intangible asset, just as intangible as
goodwill and just as worthy of recognition. It is a revenue-producing asset, just as
goodwill is. ' Know-how can be put to use so as to produce revenue in two ways. The
manufacturer can use it himself to make things for sale and make profit in that way:
or he can teach it to others, so that they can make their own things, in which case he
gets paid for the knowledge and information which he imparts to them. His fees and
rewards are then revenue in his hands. I assume, of course, that the manufacturer,
although teaching it to others, still retains the knowledge himself and intends to go
on using it himself and making things from it. So long as he does this, he, retains his
capital asset himself and is only using it to produce revenue. But 'know-how' can be
used to produce a capital receipt. It can be sold outright and bring in a capital fund.
This happens when a trader or manufacturer sells his goodwill or 'know-how'
outright to a purchaser, withdraws from the business himself, and agrees not to use
the 'know-how' or goodwill to the prejudice of the purchaser. The purchase price he
receives is then capital in his hands."
12. The House of Lords also was of the opinion that the case was governed by the Rolls-Royce case.
They distinguished Evans Medical Supplies case, as one in which "know-how" is imparted as one
element of a comprehensive arrangement by virtue of which a trader effectively gives up his
business in a particular area, and the said monies paid for the know-how, whether or not
independently quantified, may properly rank as capital receipts. But the Rolls-Royce case provides a
different context in which the imparting is no more than a service, of however special a kind,
attendant upon an activity that arises out of the appellant's trading.
13. Updating the references, we find two cases applying these principles. In Wolf Electric Tools Ltd.
v. Wilson, [1968] 45 TC 326 (Ch D), the facts were these : The company which carried on business as
mechanical and electrical engineers manufactured electric power tools among others in which it had
an extensive export trade. About 1950 its sole agency in India was taken over by Rallis Ltd., which
bought from the company on a principal to principal basis. On a representation from the Indian
company about the Indian Government's policy of encouraging the setting up of local factories for
making tools and the possibility of losing the entire market in India, the company agreed with Rallis
India to the formation of a new company in the name of Ralliwolf Private Ltd. for the manufacture
of electric power tools. In consideration of the issue to the company by Ralliwolf of 3,625 ordinary
shares of Rs. 100 each fully paid, which represented 45% in the capital of the Ralliwolf, the companyFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

agreed to provide and make available to Ralliwolf, all present and future drawings, designs,
schedules and technical knowledge and data necessary for the establishment, erection and
installation of the factory and the production thereat of the selected electric tools. It was held that
the fund of confidential material in relation to its manufacturing process and the connection the
company had with India which was in the nature of a goodwill are capital assets of the company's
trade and that the company agreed for consideration to the supply of confidential material to
Ralliwolf in order that Ralliwolf should carry on the manufacture of selected tools and undertook
not to compete in effect with Ralliwolf in India as regards the selected tools. Since the
subject-matter of the transfer is of capital asset the consideration received was also capital. The case,
according to Justice Pennycuick, was covered by the decision in Evans Medical Supplies case and
distinguishing Rolls-Royce case and English Electric Company case, observed:
"I would add only this that in the Rolls-Royce and English Electric cases the
companies concerned had no pre-existing goodwill in the countries with the
governments of which they made the contracts for imparting 'know-how'. Here the
company did have this pre-existing connection of goodwill in India and that
circumstance, it seems to me, is the crucial factor which places the present case
within the former and not the latter of the two alternatives."
14. The next decision is one in Coalite & Chemical Products Ltd. v. Treeby, [1971] 48 TC 171. Shortly
stated, the facts in that case were these : A company which was doing research in chlorinated
phenols for use in agriculture, among others, joined a consortium to advise and assist in a project to
instal a plant for the large-scale production of herbicides in East Germany, wherein production
already existed, but in insufficient quantities. The company was paid a sum of 68,000 for the
provision of know-how. In the assessment to corporation tax, the company contended that the sum
was a receipt on capital account but the Crown said it was a revenue receipt. Agreeing with the
Special Commissioners it was held that the company did not dispose of any of its existing trade in
East Germany and, therefore, it was a revenue receipt.
15. All the above cases related to the nature of the receipt in the hands of the company which
disclosed the know-how, but they do help us to understand the nature of know-how itself, and it is
because of this we have dealt with these cases in extenso.
16. It is seen from these judgments that it is difficult to give a comprehensive definition for the word
"know-how", but it may be safely taken as comprehending within it the fund of knowledge or
experience gained by a manufacturer during the long number of years in which they had been
manufacturing on how to make each component accurately, quickly and efficiently, how to adapt
standard machine tools for particular purposes, how to stretch or bend materials to particular
shapes, how to assemble the components accurately, quickly and efficiently into a complete article,
the formulae, the engineering drawings and specifications, mechanical details or processes and
general knowledge that is associated with the production and development which is in the exclusive
knowledge of the trader. Know-how is also referred to as a manufacturing technique. The disclosure
of this know-how is generally made by handing over documents relating to the processes, formulae,
manufacturing and engineering data, drawings and specifications and other information necessaryFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

for the manufacture and also by oral disclosure at lectures and demonstration and training of staff
and inter-change of employees. It is an intangible asset of sui generis and forms capital equipment
of the company. It is not necessarily a balance-sheet item. It could form the subject-matter of a sale
as illustrated by Evans Medical Supplies case or it may be imparted or shared without any
diminution or destruction in its value to the trader with another.
17. In support of his argument, the learned counsel for the assessee strongly relied on the decision of
the Supreme Court in Commissioner of Income-tax v. Ciba of India Ltd. The facts in that case were
these : Ciba Ltd., Basle, Switzerland (hereinafter referred to as "Ciba Basle"), which deals in drugs,
medicals, chemicals, pharmaceuticals and biological products, was carrying on its business in India
through its subsidiary called Ciba India Ltd. The activities of Ciba Basle carried on in India through
Ciba India Ltd. consisted of dealings both in pharmaceutical sales, dealings in dyes and chemicals.
These activities in India which were carried on through Ciba India Ltd. were bifurcated in the year
1948. The pharmaceutical section was carved out and given to another subsidiary company of Ciba
Basle called Ciba Pharma Ltd. (hereinafter called "Ciba Pharma") which was Incorporated on
December 13, 1947, and the rest of the activities in dyes and chemicals were continued by Ciba India
Ltd. under a changed name Ciba Dyes Ltd. On December 17, 1947, Ciba Basle entered into an
agreement with Ciba Pharma. Under the terms of the agreement Ciba Basle, as found by the
Supreme Court, undertook to deliver to Ciba Pharma all processes, formulae, scientific data,
working rules and prescriptions pertaining to the manufacture or processing of product discovered
and developed in the Ciba Basle laboratory and to forward to Ciba Pharma as far as possible all
scientific and bibliographic information, pamphlets or drafts which might be useful to introduce
licensed preparations and to permit their sale in India. Ciba Basle had also granted to the assessee
full and sole right under the licences listed in Schedule I to the agreement to make, use, exercise and
vend the inventions referred to in India and had also granted a licence to use the trade marks in the
territory of India. In consideration of this right to receive scientific and technical assistance, Ciba
Pharma agreed to pay the following percentage of contributions of the net selling prices of all
pharmaceutical products manufactured or processed and are sold by Ciba Pharma.
(a) Contribution towards technical consultancy and technical service rendered and research work
done ...
5%
(b) Contribution towards cost of raw material used for experimental work ...
3%
(c) Royalties on trade marks used by Ciba Pharma ...
2% 10%
18. Ciba Pharma was prohibited from divulging or assigning the benefit of the agreement or
sub-licensing of the patents and trade marks to third parties without the consent of the SwissFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

company any confidential information received under the agreement. The agreement further
provided that it shall be in force for a period of five years from January 1, 1948, and that upon
termination of the agreement for any cause Ciba Pharma shall cease to use the patents and trade
marks and to return to the Swiss company all copies of information, scientific data, or material sent
to it and refrain from communicating any such information, scientific data or materials received by
it to any person. It was not in dispute that the 2% of the consideration referable to royalties on trade
marks used by Ciba Pharma are allowable but so far as the remaining 8% paid by Ciba Pharrna was
concerned the revenue contended that it was an expenditure incurred for the acquisition of an asset
or an advantage of an enduring benefit and, therefore, capital. The High Court held that Ciba
Pharma did not acquire any asset or an advantage of an enduring nature and that, therefore, the
amount was allowable as a deduction under Section 10(2)(xv) of the Indian Income-tax Act, 1922.
This decision was confirmed by the Supreme Court. Both the High Court and the Supreme Court in
coming to this conclusion relied on the following facts: Ciba Pharma did not under the agreement
become entitled exclusively even for the period of the agreement to the patents and trade marks of
the Swiss company. It had merely access to the technical knowledge and experience in the
pharmaceutical field which Ciba Basle commanded. Ciba Pharma was on that account a mere
licensee for a limited period of the technical knowledge of Ciba Basle with a right to use the patents
and trade marks. Ciba Pharma was prohibited from divulging or assigning the information or data
connected with the manufacturing process received by it. On the termination of the agreement Ciba
Pharma is required to return to Ciba Basle all copies of information, scientific data or materials sent
to it. The use of the knowledge or practical experience which Ciba Pharma gets by knowing the
technical know-how was thus limited only for the purpose of conduct of the business during the
period of five years provided for in the agreement. There was no attempt by the Ciba Basle to part
with the technical knowledge absolutely in favour of Ciba Pharma,
19. In the instant case, we do not find any such limitation. Under the agreement, in consideration of
the remuneration to be paid, the foreign company shall supply to the assessee the technical data
relating to leather belting and grant the assessee the right to use the technical data for the purpose
of manufacture in the territory of India. The assessee shall not, except with the prior written consent
of the foreign company, assign, mortgage, charge or otherwise alienate its rights under the
agreement and shall not grant any sub-licence or sub-right thereunder. The assessee was also under
an agreement to maintain utmost secrecy in connection with the technical data supplied. Though
the agreement is stated to be in force for a period of ten years there was no prohibition of the use of
the technical data by the assessee after the period of ten years nor is there any clause requiring the
assessee to return the technical data as in Ciba's case implying that the benefit under the agreement
is to be enjoyed only during the period of the agreement. Even the prohibition against assignment,
mortgage or charge or otherwise alienating the rights under the agreement was not made to enure
beyond the period of ten years provided under the agreement. Nor even the assessee was required to
keep the knowledge secret after the period of ten years. Under these circumstances, we have no
doubt that the assessee has acquired an asset or an advantage of enduring benefit to his trade.
20. The decision in Commissioner of Income-tax v. Hindustan General Electrical Corporation Ltd.,
is to the effect that the facts in that case were very similar to the facts in Ciba's case and, therefore,
that decision has no application.Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

21. The learned counsel for the revenue relied in this connection on two decisions--one of the
Mysore High Court in Mysore Kirloskar Ltd. v. Commissioner of Income-tax and the other of the
Andhra Pradesh High Court in Hylam Ltd. v. Commissioner of Income-tax, . In Mysore Kirloskar's
case, the assessee entered into an agreement with a foreign company under which the foreign
company was to provide the assessee with manufacturing technique from time to time and also
furnish two complete sets of detailed and general arrangement drawings, material specifications and
particulars relating to appropriate machines. They had also to supply patterns, jigs, fixtures and
special tools at certain agreed prices. One of the employees of the foreign company was to
superintend the assessee's factory and manufacture. The assessee is also to send its employees for
training to the foreign company in England. The agreement also provided that the machines
manufactured by the assessee should be sold under the trade mark, Herbert Kirloskar. In
consideration of the above facilities of information and manufacturing technique the assessee had to
pay a certain sum of money to the foreign company. The assessee undertook and agreed that it
would observe strict secrecy as to all confidential and secret documents, information and know-how
supplied to it. On the facts, the High Court found that the assessee was not manufacturing the
machine tools, workshop equipment, etc., on the date of the agreement and it was to go into
production of these machines on the basis of the know-how supplied by the foreign company.
Whatever know-how came to be supplied to the assessee, it was also found, the same became a part
of its own know-how. There was no objection for utilising the know-how by the assessee even after
the period of the agreement came to an end which was 15 years. In pursuance of the agreement the
assessee had paid during the relevant accounting year a sum of Rs. 26,713. The question for
consideration was whether this expenditure should be considered as a capital expenditure or as a
revenue expenditure. Justice Hegde (as he then was), speaking for the Bench, held that the
knowledge acquired would be available for the assessee for all time to come in the future if the
assessee carried out the terms of the agreement. Further, know-how is primarily a capital asset.
Therefore, either way there can be no doubt that the expenditure incurred by the assessee for
acquiring that know-how is a capital expenditure. In support of the finding that know-how is a
capital asset, the learned judges also relied on the decision of the House of Lords in Rolls-Royce
case. This decision is, therefore, directly in point and is in favour of the revenue,
22. In Hylam Ltd. v. Commissioner of Income-tax the facts were these : Under one agreement the
assessee-company who was carrying on the business of manufacture of laminated materials
obtained an exclusive non-assignable licence to manufacture laminates in accordance with the
process covered by the patents owned by an English company in India. The licence granted was to
continue for an unexpired term of Indian Letters Patent and any extension or regrant thereof. As a
consideration for the grant the assessee was to pay 5% royalty on the net selling price of all
laminated products made and sold by it in accordance with the patented processes. When the total
of the royalty payment reached 5,000, the assessee was no more liable to pay royalty. Under another
agreement the English company agreed to furnish exclusively to the assessee technical information
relating to the manufacture and testing of the products. As a consideration thereof, the assessee
agreed to pay a consultancy fee at 2% of the net sales on certain products and at 5% of the net sales
on other products sold by the assessee during every year during which the agreement remained in
force. The assessee claimed deduction of the amounts paid as royalties and consideration under the
above agreements in the computation of its income for the respective assessment years on theFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

ground that it is an expenditure of a revenue nature. The assessee's claim was rejected. But, so far as
the consultancy fee is concerned, in the view that certain items enumerated in the agreement related
to the routine operation of the business, they apportioned the consultancy fee between capital and
revenue in the ratio of 1: 2 and allowed only 2/3rds of the consultancy fee as revenue expenditure.
On a reference, the High Court distinguished the Ciba's case as relating to facts which showed that
the special knowledge in scientific data and materials relating to it had to be returned to Ciba Basle
after the expiry of the agreed period and could not be utilised by Ciba Pharma after such expiry. The
learned judges considered that the ratio of the decision in Mysore Kirloskar case would apply and in
that view they upheld the decision of the Tribunal.
23. We may also deal with one of the reasonings of the Tribunal for holding that the Mysore
Kirloskar case is applicable to the facts rather than the decision in Ciba's case. Ciba's case was
distinguished by the Tribunal on the ground that Ciba Pharma was an existing company on the date
when it entered into an agreement relating to the know-how. But, on the other hand, in Mysore
Kirloskar case, the agreement was for the purpose of the very establishment of the concern. It is true
that Mysore Kirloskar case related to a case where the assessee was to go into production on the
basis of know-how supplied to it not for the purpose of manufacturing any machine that the
assessee was already manufacturing, and this fact excluded the applicability of Section 10(2)(xv) of
the Indian Income-tax Act, 1922. It was also true that the learned judges in that case have pointed
out that know-how was to be utilised not for the purpose of manufacturing the machine that the
assessee was already manufacturing but for the purpose of bringing into production new types of
machines solely on the basis of the know-how supplied by the foreign company. In this connection,
the learned judges also referred to Parisutha Nadar v. Commissioner of Income-tax, [1992] 46 ITR
1041 (Mad), where it was held that Section 10(2)(xv) indicates that the expenditure should relate to
a business which is already in existence and not one that is to come into existence in future. But that
was not the point on which the case was decided. Relying on Rolls-Royce case, they first held that
know-how is a capital asset or an advantage of enduring nature. They referred to the decision in
Assam Bengal Cement Co. Ltd. v. Commissioner of Income-tax, and observed that if the know-how
supplied by the foreign company can be considered as a capital asset then there is no doubt that the
expenditure incurred by the assessee for acquiring that know-how is a capital expenditure.
Therefore, the ratio of the judgment is that know-how is a capital asset and that, therefore, the
expenditure was a capital expenditure. On facts, they also found that the knowledge acquired was an
enduring benefit to the assessee and on that ground also the expenditure is capital.
24. The learned counsel for the assessee then sought to distinguish the decision in Mysore
Kirloskar's case on the basis that the consideration paid was a lump sum payment and not a
periodical payment as in the instant case. The learned counsel was prepared to concede that if a
lump sum was fixed as consideration the terms could provide for payment in instalments of the
same but if no fixed amount was agreed and a periodical payment will have to be made with
reference to the production or sale either for a definite or indefinite period, such payment would
point to the revenue nature of the expenditure and not a capital expenditure. In this connection, he
referred to the oft-quoted dictum of Lord Cave in Atherton v. British Insulated & Helsby Cables Ltd.,
[1925] 10 TC 155,192 (HL) which reads as follows:Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

"But when an expenditure is made, not only once and for all, but with a view to
bringing into existence an asset or an advantage for the enduring benefit of a trade, I
think that there is very good reason (in the absence of special circumstances leading
to an opposite conclusion) for treating such an expenditure as properly attributable
not to revenue but to capital."
25. He also relied on the decision of the Supreme Court in Travancore Sugars & Chemicals Ltd. v.
Commissioner of Income-tax, in support of his contention that if the consideration paid was a
periodical payment it is a revenue expenditure. It is true that in Mysore Kirloskar case the
consideration paid was a lump sum but we do not think that made any distinction. Further, if the
aim or object of the expenditure was the acquisition of an asset or advantage of an enduring nature,
as we would presently show with reference to decisions, the expenditure is only capital in nature and
the mere fact that the payment was not a lump sum or instalment payment but a periodical
payment, that it was from the profits or linked with the trading activity of the assessee would not in
any way change the nature of the expenditure.
26. The Supreme Court, after consideration of the tests laid down in various cases to determine the
nature of the expenditure, summarised the principles in Assam Bengal Cement Co. Ltd. v.
Commissioner of Income-tax in the following words :
"In cases where the expenditure is made for the initial outlay or for extension of a
business or a substantial replacement of the equipment, there is no doubt that it is
capital expenditure. A capital asset of the business is either acquired or extended or
substantially replaced and that outlay, whatever be its source, whether it is drawn
from the capital or the income of the concern, is certainly in the nature of capital
expenditure. The question however arises for consideration where expenditure is
incurred while the business is going on and is not incurred either for extension of the
business or for the substantial replacement of its equipment. Such expenditure can
be looked at either from the point of view of what is acquired or from the point of
view of what is the source from which the expenditure is incurred. If the expenditure
is made for acquiring or bringing into existence an asset or advantage for the
enduring benefit of the business it is properly attributable to capital and is of the
nature of capital expenditure. If on the other hand it is made not for the purpose of
bringing into existence any such asset or advantage but for running the business or
working it with a view to produce the profits it is a revenue expenditure. If any such
asset or advantage for the enduring benefit of the business is thus acquired or
brought into existence it would be immaterial whether the source of the payment was
the capital or the income of the concern or whether the payment was made once and
for all or was made periodically. The aim and object of the expenditure would
determine the character of the expenditure whether it is a capital expenditure or a
revenue expenditure. The source or the manner of the payment would then be of no
consequence. It is only in those cases where this test is of no avail that one may go to
the test of fixed or circulating capital and consider whether the expenditure incurred
was part of the fixed capital of the business or part of its circulating capital. If it wasFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

part of the fixed capital of the business it would be of the nature of capital
expenditure and if it was part of its circulating capital it would be of the nature of
revenue expenditure. These tests are thus mutually exclusive and have to be applied
to the facts of each particular case in the manner above indicated. It has been rightly
observed that in the great diversity of human affairs and the complicated nature of
business operations it is difficult to lay down a test which would apply to all the
situations. One has, therefore, got to apply these criteria one after the other from the
business point of view and come to the conclusion whether on a fair appreciation of
the whole situation the expenditure incurred in a particular case is of the nature of
capital expenditure or revenue expenditure......"
27. The above decision was later on followed by the Supreme Court in State of Madras v. G.J.
Coelho, .
28. Lord Greene M. R. in Associated Portland Cement Manufacturers Ltd. v. Kerr, [1945] 27 TC 103
(CA) on the question whether an item of expenditure is of capital or a revenue nature observed:
"Whether or not an item of expenditure is to be regarded as of a revenue or capital
nature must in many, and indeed in the majority of cases I should have thought,
depend upon the nature of the asset or the right acquired by means of that
expenditure. If it is an asset which properly appears as a capital asset in the
balance-sheet, then that is an end of the matter. But it must never be forgotten that
an asset, which may properly and quite correctly appear and only appear in the
balance-sheet as an asset, may be acquired out of revenue. There is nothing in the
world to force a company or a trader who buys a capital asset to debit the cost of it to
capital. Conservatively managed companies every day pay for capital assets out of
revenue if they are fortunate enough to have the revenue available. It is, therefore, no
sufficient test to say that an asset has been paid for out of revenue, because the
consequence does not by any means necessarily follow that it is an asset of a revenue
nature as distinct from a capital nature. Similarly, there is nothing to prevent a
company or a trader who has acquired a capital asset from refraining from placing
any value on that asset in his balance-sheet. I put to Mr. King an example which I
think is worth repeating. If a trader buys up somebody-else's business and pays
10,000 for the goodwill, that being the price on which the vendor insists, there is
nothing in the world to prevent the purchaser paying the 10,000 out of revenue and
debiting it to revenue account, and then writing down the goodwill in his own
balance-sheet to nothing. The fact that he has written it down in his own
balance-sheet does not mean that he has not got an asset. He has ; he has the
goodwill, but for his own domestic purposes he chooses not to put a value upon it:
just in the same way as many companies, who have patents of very great value
indeed, are in the habit of valuing them at a pound in their balance-sheet, or at some
other nominal sum. I venture to think, therefore, when one is considering the nature
of an asset acquired by a piece of expenditure, it is by no means conclusive to find
that the asset does not have any definite value set upon it in the balance-sheet."Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

29. In Sargent v. Eayrs also it has been held that if the object of the expenditure was for the purpose
of setting up a new or extended business it would amount to capital expenditure and the nature of
the expenditure would not change according to whether it be successful or unsuccessful.
30. Now, let us consider whether the Supreme Court in Gotan Lime Syndicate v. Commissioner of
Income-tax, and Travancore Sugars & Chemicals Ltd. v. Commissioner of Income-tax have laid
down any principle different from that stated above. Gotan Lime Syndicate case related to the
payment of royalty under a mining lease. After observing that it is difficult to distinguish between
revenue expenditure and capital expenditure their Lordships referred to the decision in Assam
Bengal Cement Co. Ltd. v. Commissioner of Income-tax above referred to. They further stated that
in view of the argument of the respondent and the judgment of the High Court they had to
concentrate only on the test laid down by Viscount Cave in Atherton's case. Applying the test, the
learned judges held that it is a revenue expenditure. It is true that in coming to this conclusion the
fact that no lump sum payment was ever settled or paid was relied on but two other observations
which are material have to be quoted :
At page 726 it is said ;
"The reason why royalty has to be allowed as revenue expenditure must be the
relation which the royalty has to the raw material which is going to be excavated or
extracted."
And again in another place they said that;
"We have not been referred to any case in which payments of royalty under a mining
lease have been treated as capital expenditure."
31. As already pointed out, Viscount Cave's dictum in Atherton's case is only one of the tests and not
the sole and exclusive test for deciding the question as to whether it is a capital expenditure or a
revenue expenditure.
32. In Travancore Sugars & Chemicals case, the short facts were these : The assessee-company took
over the assets of three undertakings run by the Travancore company. The consideration for the sale
was a fixed cash consideration, agreed to be paid for the sale. In addition to the fixed cash
consideration the agreement provided a payment of 20% of the net profits earned by the assessee in
every year subject to a maximum of Rs. 40,000 per annum. The question for consideration was
whether this 20% share in the net profits payable to the company was a capital expenditure or a
revenue expenditure. On the ground that the amount was payable for an indefinite period and was
related to annual profits and the "payment has no relation to the capital value of the asset" it was
held that it was a revenue expenditure. If we take the ratio of the judgment it was more on the
ground that the payment has no relation to the capital value of the asset that the decision was
rendered. We, therefore, think that these two decisions in no way help the assessee.Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

33. We may also now notice a note of caution made by Lord Reid in Regent Oil Co. Ltd. v. Strick,
[1969] 73 ITR 301 (HL) which reads as follows :
"Whether a particular outlay by a trader can be set against income or must be
regarded as a capital outlay has proved to be a difficult question. It may be possible to
reconcile all the decisions but it is certainly not possible to reconcile all the reasons
given for them. I think that much of the difficulty has arisen from taking too literally
general statements made in earlier cases and seeking to apply them to a different
kind of case which their authors almost certainly did not have in mind--in seeking to
treat expressions of judicial opinion as if they were words in an Act of Parliament.
And a further source of difficulty has been a tendency in some cases to treat some one
criterion as paramount and to press it to its logical conclusion without proper regard
to other factors in the case."
34. In the same judgment, Lord Wilberforce had the following observation to make with reference to
the tests propounded in the various judgments, [1969] 73 ITR 301, 349(HL) :
"In the course of the numerous decisions which have distinguished between capital
and revenue expenditure in relation to widely different trades and varying
circumstances, certain ' tests ' have emerged. These may be useful, so long as it is
recognised that they have emerged a posteriorari from the facts of a given situation
and that they may not always be suitable as guiding lines in other situations. I begin
by asking two questions, which may be said to be generally relevant: what is the
nature of the payment, and for what was the payment made ? These, together with a
third question, namely, how that, for which the payment was made, was to be used,
were stated by DJxon J. in his classic judgment in Sun Newspapers Ltd. v. Federal
Commissioner of Taxation, 61 CLR 337, 363. There are, he said, three matters to be
considered, (a) the character of the advantage sought, and in this its lasting qualities
may play a part, (b) the manner in which it is to be used, relied upon or enjoyed, and
in this and under the former head recurrence may play its part, and (c) the means
adopted to obtain it; that is, by providing a perodical reward or outlay to cover its use
or enjoyment for periods commensurate with the payment or by making a final
provision or payment so as to secure future use or enjoyment.
35. I may add to this another statement by the same learned judge in the later case of Hallstroms
Proprietary Ltd. v. Federal Commissioner of Taxation, 72 CLR 634, 648:
'What is an outgoing of capital and what is an outgoing on account of revenue
depends on what the expenditure is calculated to effect from a practical and business
point of view, rather than upon the juristic classification of the legal rights, if any,
secured, employed or exhausted in the process."
36. It may be seen from the foregoing discussions that it is the aim and object of the expenditure
that would determine the character of the sum whether it is a capital or revenue expenditure andFenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

neither the source nor the manner of payment may be of any consequence. The fact, therefore, that
the agreement did not fix any lump sum consideration but referred to a periodical payment linked to
the production or sale of the articles does not in any way take it out of the category of a capital
expenditure.
37. The foregoing discussions would show that if the facts and circumstances of the case and the
nature of the contract are such as to warrant a finding that there was a sale of the know-how it could
safely be inferred that even in the transferee's hand it is capital asset unless the same is considered
as a trading asset of the transferee. If, on the other hand, it is considered to be an exploitation of its
know-how by a trader without any diminution or destruction in the value to him there may not be a
sale but still the knowledge acquired by the transferee by the disclosure of the know-how will be an
asset or an advantage of an enduring nature unless there are any limitations in the agreement on its
endurability or otherwise pointing to the contrary. If the agreement was for the very establishment
and the production is to be on the basis of the know-how supplied to it, the above principle will
apply a fortiori as in that case Section 10(2)(xv) of the Indian Income-tax Act, 1922, or the
corresponding Section 37 in the Income-tax Act, 1961, would not apply as an expenditure relating to
a business which is not already in existence but that is to come into existence in future.
38. We have already noted that there was no such limitation in the agreement on its endurability.
The assessee could use the technical data and the knowledge acquired even after the period of ten
years and could deal with it as if it were their own asset. We are, therefore, of opinion that the
amounts paid are not admissible deductions under the Income-tax Act, 1961.
39. The learned counsel for the assessee relying on certain clauses in the agreement wanted to
submit that the agreement is a composite document providing for not only the supply of know-how
but also for providing training facilities at their workshop in England for the selected Indian
technicians and that only that portion of the consideration relatable to the technical know-how
alone could be disallowed. The revenue on the other hand contended that the whole thing is
know-how and there is no question of apportionment for any revenue expenditure. We may point
out that the allocation, if any, in the consideration paid is not covered by the question referred for
our decision and it had not even been argued before the Tribunal or the authorities. Therefore, we
cannot consider this point.
40. For the foregoing reasons, we answer the reference in the negative and against the assessee with
costs. Counsel fee Rs. 250.Fenner Woodroffe & Co. Ltd. vs Commissioner Of Income-Tax on 25 March, 1975

