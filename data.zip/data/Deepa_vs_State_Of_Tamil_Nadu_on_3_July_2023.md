Deepa vs State Of Tamil Nadu on 3 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                 H.C.P.No.265 of 2023
                                      IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                    DATED : 03.07.2023
                                                          CORAM
                                        THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                       THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                   H.C.P.No.265 of 2023
                     Deepa                                                           ..
                                                                                      Petitioner
                                                            Vs.
                     1.State of Tamil Nadu
                       Rep by The Secretary to Government,
                       Prohibition & Excise Department,
                       Fort.St.George, Chennai-600 009.
                     2.The Commissioner of Police,
                       Tambaram City.
                     3.The Superintendent,
                       Central Prison, Puzhal, Chennai – 66.
                     4.The Inspector of Police,
                       T9 Maraimalai Nagar Police Station,
                       Chengalpattu.                                      ..       Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the records
                     relating to the detention order dated 22.12.2022 passed by the 2nd
                     respondent in the proceedings in BCDFGISSSV No.217 of 2022 in
                     TPDA No.3989 and to quash the same, consequently direct the
                     respondents herein to produce the petitioner's husband namely
                     Page Nos.1/8Deepa vs State Of Tamil Nadu on 3 July, 2023

https://www.mhc.tn.gov.in/judis
                                                                                         H.C.P.No.265 of 2023
                     S.Manikandan @ Sullan Mani, son of Sundaram, aged about 33 years,
                     who is presently undergoing detention in Central Prison, Puzhal,
                     Chennai as Goonda under Section 3(1) of the Tamilnadu Prevention of
                     Dangerous            Activities   of   Bootleggers,     Drug    Offenders,       Forest
                     Offenders, Goondas, Immoral Traffic Offenders, Sand Offenders, Slum
                     Grabbers and Video Pirates Act, 1982 (Tamilnadu Act 14 of 1982)
                     before this Court and set him at liberty forthwith.
                                  For Petitioner            :     Mr.R.Rajadurai
                                  For Respondents           :     Mr.E.Raj Thilak
                                                                  Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.,] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
21.02.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 13.02.2023 inter
alia assailing a detention order dated 22.12.2022 bearing reference BCDFGISSSV
No.217 of 2022 made by 'second respondent' [hereinafter 'Detaining Authority' for
the sake of convenience and clarity]. To be noted, fourth respondent is the
Sponsoring Authority.
2. Wife of the detenu is the petitioner.
3. Mr.R,Rajadurai, learned counsel on record for habeas https://www.mhc.tn.gov.in/judis corpus
petitioner is before us. Learned counsel for petitioner submits that ground case qua the detenu is for
alleged offences under Sections 341, 294(b), 323, 324, 307, 506(ii) of 'Indian Penal Code, 1860 (Act
45 of 1860)' ['IPC' for brevity] in Crime No.566 of 2022 on the file of T-9, Maraimalai Nagar Police
Station.
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest- offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that some of the pages in the
booklet are illegible, which prevented the detenu from making an effective representation
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.Deepa vs State Of Tamil Nadu on 3 July, 2023

7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'
https://www.mhc.tn.gov.in/judis
2. The aforementioned order made in the 21.02.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are five adverse cases. The ground case which constitutes substantial part of substratum of
the impugned preventive detention order is Crime No.566 of 2022 on the file of T-9 Maraimalai
Nagar Police Station for alleged offences under Sections 341, 294(b), 323, 324, 307 and 506(ii) of
IPC. Owing to the nature of the challenge to the impugned detention order, it is not necessary to
delve into the factual matrix or be detained further by facts.
4. Mr.R.Rajadurai, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. In the support affidavit qua captioned HCP, several points have been raised/urged. In the
Admission Order, as would be evident https://www.mhc.tn.gov.in/judis from paragraph 5 of the
21.02.2023 order (reproduced supra), challenge to the impugned preventive detention order was
predicated on the ground that some pages in the grounds booklet are illegible and this prevented the
detenu from making an effective representation. Elaborating on this point projected in the
Admission Board, learned counsel drew our attention to pages 473 to 477 of the grounds booklet. To
be noted, these pages contain a bail order dated 23.04.2021 made in Crl.M.P. No.2440 of 2021 on
the file of Principal Sessions Judge of Kancheepuram District at Chengalpattu, which has been relied
on by the detaining authority to arrive at subjective satisfaction qua imminent possibility of detenu
being enlarged on bail. We had the benefit of perusing the grounds booklet served on the detenu and
we find that pages 475 and 477 are not readable at all. As it is a bail order which has been relied on
by the detaining authority to arrive at subjective satisfaction qua imminent possibility of detenu
being enlarged on bail, we have no hesitation in accepting the submission of learned counsel for
petitioner that the detenu's right to make an effective representation against the impugned
preventive detention order has been hampered. To be noted, such right of the detenu i.e., right of
the detenu to make an effective representation against a preventive detention order is a
constitutional https://www.mhc.tn.gov.in/judis safeguard ingrained in Clause 5 of Article 22 of the
Constitution of India.
6. The narrative thus far brings to light that in the case on hand, aforementioned constitutional
safeguard qua Article 22 (5) of the Constitution of India has been impaired. This means that
impugned preventive detention order is vitiated and it deserves to be dislodged.
7. Apropos, the sequitur is, captioned HCP is allowed.
Impugned detention order dated 22.12.2022 bearing reference BCDFGISSSV No.217/2022 made by
the second respondent is set aside and the detenu Thiru.S.Manikandan @ Sullan Mani, aged 33Deepa vs State Of Tamil Nadu on 3 July, 2023

years, son of Thiru.Sundaram, is directed to be set at liberty forthwith, if not required in connection
with any other case / cases.
There shall be no order as to costs.
                                                                     (M.S.,J.)        (R.S.V.,J.)
                                                                           03.07.2023
                     Index : Yes / No
                     Neutral Citation : Yes / No
                     mmi
https://www.mhc.tn.gov.in/judis
P.S.: Registry to forthwith communicate this order to Jail authorities in Central Prison,Puzhal,
Chennai.
To
1.The Secretary to Government, Prohibition & Excise Department, Fort.St.George, Chennai-600
009.
2.The Commissioner of Police, Tambaram City.
3.The Superintendent, Central Prison, Puzhal, Chennai – 66.
4.The Inspector of Police, T9 Maraimalai Nagar Police Station, Chengalpattu.
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mmi 03.07.2023
https://www.mhc.tn.gov.in/judisDeepa vs State Of Tamil Nadu on 3 July, 2023

