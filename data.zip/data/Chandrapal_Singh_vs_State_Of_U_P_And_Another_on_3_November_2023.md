Chandrapal Singh vs State Of U.P. And Another on 3 November,
2023
Author: Pritinker Diwaker
Bench: Pritinker Diwaker, Ashwani Kumar Mishra, Ajay Bhanot
HIGH COURT OF JUDICATURE AT ALLAHABAD
2023:AHC:212021-FB 
 Chief Justice's Court
 Case :- APPLICATION U/S 482 No. - 28574 of 2019
Applicant :- Chandrapal Singh
Opposite Party :- State of U.P. and Another
Counsel for Applicant :- Prashant Shukla, Rajrshi Gupta, Sudhanshu Kumar
Counsel for Opposite Party :- G.A.,Rohit Shukla,Shashi Kant Shukla
 Hon'ble Pritinker Diwaker, Chief Justice
Hon'ble Ashwani Kumar Mishra,J.
Hon'ble Ajay Bhanot,J.
[Per: Hon'ble Ajay Bhanot,J.]
1. The judgment is being structured in the following conceptual framework to facilitate the
discussion:
I Facts, Applications and Submissions of learned counsels II Asian Resurfacing:
A Asian Resurfacing I,II,III&IV : Fazalullah Khan Vs M. Akbar Contractor B
Implementing Asian Resurfacing : Consequences and Complications III Fixation of
time limits by courts to conclude criminal/judicial proceedings : Whether AsianChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Resurfacing (supra) runs contrary to the law laid down in A.R. Antulay and P.
Ramachandra Rao ?
IV Interim Orders : Grant, Alteration & Vacation V High Court:
A Pre-Constitution Phase to the Constitution : Articles 215, 226 & 227 B Inherent
Powers C Basic Structure VI Supreme Court:
A Article 141:
I Article 141 & Asian Resurfacing B Article 142:
II Article 142 & Asian Resurfacing C High Court & Supreme Court: Relationship VII
Article 132 & Substantial questions of law as to interpretation of the Constitution of
India VIII Orders on Applications & grant of certificate for appeal to the Supreme
Court I. FACTS, APPLICATIONS AND SUBMISSIONS OF LEARNED COUNSELS
I(A). FACTS:
2. An interim order was granted by this Court on 25.07.2019 in favour of the applicant in application
under Section 482 Cr.P.C No. 28574 of 2019 (Chandrapal Singh Vs State of U.P. and another)
staying the criminal trial. The informant did not file a counter affidavit nor did he enter appearance
through counsels in the aforesaid proceedings before this Court. The State Government too did not
file a counter affidavit in the said case.
3. The matter was listed on several occasions but could not be taken up for hearing due to paucity of
time and large docket size of the Court. The first informant moved the learned trial court on the
footing that the stay order granted by this Court stood vacated by operation of the judgment of the
Supreme Court in Asian Resurfacing of Road Agency Private Limited and Another Vs Central
Bureau of Investigation1. The trial court commenced the criminal trial proceedings in compliance of
the directions in Asian Resurfacing (supra). Non bailable warrants were issued against the applicant
by the trial court, leading to his arrest. He was granted bail subsequently by this Court.
4. According to the applicant's counsel, the interim order in the applicant's favour was automatically
vacated and the applicant suffered imprisonment for no fault of his. The applicant now faces a
vexatious prosecution.
5. The section 482 Cr.P.C. application as well as the bail application were later connected and heard
together by a Single Judge Bench of which one of us (Ajay Bhanot, J.) was a member.
6. A number of counsels, and the Allahabad High Court Bar Association appeared before the Court
and advanced various submissions. The intervention application of the Bar was allowed. The
complications arising from the compliance of the directions in Asian Resurfacing (supra), were
brought to the notice of the Court.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

7. The Single Judge Bench framed the following questions for consideration:
"(i) Whether the Single Judge of this Court or the High Court can consider and
interpret the judgment of the Supreme Court rendered in Asian Resurfacing (supra)?
(ii) Whether this issue is liable to be referred to a Full Bench, if yes, the relevant
provisions and authorities of law?
(iii) Whether the High Court can interpret the Asian Resurfacing (supra) and pass
orders in regard to its implementation in the wake of Asian Resurfacing-IV(sic.)
rendered on 25.04.2022?
(iv) Whether the issue raises substantial questions relating to interpretation of
Constitution of India?"
8. In view of the constitutional importance of the matter and the wide ranging consequences in the
State of U.P. resulting from the directions in Asian Resurfacing (supra), this Full Bench has been
constituted to decide the controversy. Applications made by various parties before the Full Bench
have been heard.
I(B). APPLICATIONS:
APPLICATION FILED BY HIGH COURT BAR ASSOCIATION, ALLAHABAD
9. The application filed on behalf of the High Court Bar Association, Allahabad has meticulously
highlighted the widespread complications caused by the implementation of the directions issued in
Asian Resurfacing (supra) in the State of U.P. The application on behalf of the Bar Association is
filed by Shri Ashok Kumar Singh, its President and Sri Nitin Sharma, its Secretary. The application
has been argued by Shri Nitin Sharma, learned counsel.
10. According to the applicant matters are often not taken up for hearing due to paucity of time in
the Court. Parties whose conduct cannot be faulted suffer due to the automatic vacation of interim
orders by operation of the directions in Asian Resurfacing (supra). Interim orders extended by the
High Court citing paucity of time are being disregarded by the trial courts. Pursuant to the
automatic vacation of stay orders criminal and civil proceedings are set on foot before the trial
courts and tribunals alike and the parties suffer imprisonment and/or other civil and criminal
consequences.
11. On earlier occasions the High Court Bar Association, Allahabad had filed applications before the
Registry of Allahabad High Court, drawing attention to the plight of the litigants and the learned
counsels in these matters.
12. The illustrative cases cited in the application depict that the litigants virtually before all courts
and tribunals, irrespective of jurisdictions or the nature of lis are being adversely impacted by theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

implementation of the directions in Asian Resurfacing (supra).
13. Some of the paragraphs of the application are being extracted in full to demonstrate the extent of
the grievances of the litigants and the counsels alike:
"9. That the members of the Bar submitted that the automatic vacation of stay
orders/interim relief leads to resumption of numerous litigations/trials which had
been stayed by this Hon'ble Court through its respective orders after due application
of judicial mind after expending precious judicial time. As a natural concomitant, this
had engendered a novel branch of legal practice viz. 'stay-extension' wherein litigants
face immense financial and mental strain for no fault of theirs.
14. That the applicant HCBA would like to place on record the hardships being faced by the litigants
due to automatic vacation of interim orders. The applicant humbly submits that the hardships have
arisen not only due to direct application of the decision of Asian Resurfacing, but also due to its
misinterpretation whereby all interim reliefs granted by the High Court are treated as vacated by the
district courts. A few such instances are illustratively listed herein below:
i. Proceedings instituted with patent lack of jurisdiction where the exclusive
jurisdiction vests with specialized courts/tribunals viz. family court, commercial
court, DRT, NCLT etc., stay granted by High Court got vacated, proceedings were
resumed and culminated into a final decision. Final decision becomes a nullity due to
inherent lack of jurisdiction but a lit of time & money is spent by both parties
pursuing the lis.
ii. Proceedings of an eviction suit stayed on account of presence of arbitration clause
in the tenancy agreement, stay got vacated and proceedings got resumed without
jurisdiction and against the provisions of the contract between the parties. This
renders the arbitration agreement between the parties otiose.
iii. Stay got vacated in a trademark suit, permitting the offending party to pass off the
registered trademark freely while applications for stay extension are being decided.
iv. Second appeal admitted on substantial question of law can be exclusively decided
by the Hon'ble High Court where the lower  appellate court had passed decree for
mandatory injunction ordering demolition, stay got vacated and execution proceeded
resulting in demolition of the property. Thus, despite having his appeal admitted on a
substantial question of law, the subject matter of suit get destroyed in execution of
the decree frustrating the admission of second appeal, besides inhibiting
development of jurisprudence on the admitted point of law.
v. Similarly, the litigants are also misusing the direction of the Hon'ble Supreme
Court by not contesting the admitted appeals and after lapse of six months are
creating third party rights or making irreversible changes to the suit property.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

vi. Conditional stay granted in eviction cases, matrimonial cases etc. after paying
considerable amount of arrears of rent/maintenance getting vacated after six months,
execution proceedings resuming to the detriment of the party having showed its bona
fide by complying with the directions of the Hon'ble High Court.
vii. Proceedings of a criminal case arising out of commercial/matrimonial dispute
stayed after compromise between the parties on payment of considerable amount for
money. Stay gets vacated while the verification process is undergoing or balance
amount is being paid, enabling the complainant to extort more money for closing the
criminal case.
viii. Proceedings of criminal case stayed on account of refusal of court below to
permit some essential evidence under S. 311 Cr.P.C, Trial proceeds without the same,
hampering effective adjudication of the case, which eventually may equally prejudice
both the accused and the complainant.
ix. Stay over proceedings of a criminal case got vacated after lapse of six months, the
accused was unaware of the same and got arrested n compliance of NBW isued by the
trial court. The bail application was heard by the Hon'ble High Court along with the
quashing application. Both the applications were allowed and the proceedings were
quashed. The applicant/accused remained in jail for more than a month in case
which was eventually quashed by this Hon'ble Court.
x. Although the law doesn't permit, the parties to a divorce proceeding are misusing
the direction of the Hon'ble Supreme Court. Where the appeal against divorce decree
is pending adjudication and six months lapse after grant of stay order, the
respondents are solemnising second marriage.
xi. Order refusing juvenility stayed by this Hon'ble Court which gets vacated due to
lapse of six months, now a juvenile is made to face a regular trial without the
especially delineated procedure prescribed for dealing with child in conflict with law.
xii. A frivolous case under Section 498-A IPC and Section 3/4 Dowry Prohibition Act.
Even the Hon'ble Supreme Court has taken judicial notice of the growing tendency to
falsely implicate all the family members including aged parents. The High Court may
initially stay proceedings against the parents till the next date of listing of the case.
The stay gets vacated after 6-months exposing the aged parents to NBW and
consequent arrest.
xiii. A landlord-tenant dispute where the order is stayed upon the condition of tenant
depositing the entire decretal amount. However, with automatic vacation of such
orders, the landlord's institute execution proceedings against the tenant resulting in
their dispossession/eviction.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

15. That a unique practical difficulty has arisen by the operation of the directives issued in the Asian
Resurfacing Case. Thus, as an unintended result of the operation of Asian Resurfacing(supra), the
interim orders get vacated exposing the litigants to Non-Bailable Warrants (in criminal cases) and
eviction, dispossession, and demolition in civil cases without any fault of theirs. In fact, without any
express change in circumstances, the litigant faces adverse consequences having detrimental effect
on his fundamental rights.
20. That, therefore, without there being any laxity on the part of the litigant or his/her counsel or
the Registry, the interim orders do not get extended within the time-frame of six months, thereby
leading to their cessation in view of the directions made by the Hon'ble Court in Asian Resurfacing
(supra).
24. That with respect to orders falling in Category (i) it is submitted that the Hon'ble Court grants
interim relief intending it to last the lifetime of the petition. That natural interference which can be
drawn is that this Hon'ble Court while entertaining the matter found it fit enough for its
intervention to protect the interest of the litigant. However, in view of the order passed by the
Hon'ble Supreme Court in Asian Resurfacing Case the respondent/ Opposite party in the petition
now strategically avoids filing any stay vacation application/counter affidavit before the Hon'ble
Court and does not even contest the petition on its merits. They simply wait for the period of
6-months to lapse whereupon proceedings before the courts below resume.
30. That it has been routinely observed that the opposite party simply awaits the expiry of six
months whereafter the interim relief granted by the Hon'ble Court becomes ineffective. This
constrains the petitioner/applicant to move either a stay extension application or seek extension of
interim relief by oral mentioning. As has been indicated above, owing to an overflowing docket of
such stay extension cases, the interim relief does not get extended due to paucity of time. Thus, for
no fault of his, and despite having a prima facie case on merits, a litigant is compelled to face
proceedings before the courts below.
34. That however due to heavy docket of stay extension cases, on the subsequent date the matter
may not get heard which would result in the vacation of the interim order. On some occasions the
Hon'ble Court has been pleased to extend interim orders citing paucity of time. However, even these
orders by which the interim order is extended citing paucity of time is not being acknowledged by
the trial court. Thus, the decision of the Hon'ble Supreme Court has created an unintended
consequence under which the courts below have been constrained to disregard the orders passed by
the High Court.
35. That it is humbly submitted that once stay has been granted by this Hon'ble Court by means of a
speaking order, it continues until  the court holds otherwise by means of another speaking order.
Therefore, a stay order extended due to paucity of time remains a speaking order unless this Hon'ble
Court reflects otherwise by another order. Therefore, the term speaking order is being interpreted
wrongly by the courts below resultin in an unsavoury situation where subordinate courts are sitting
over judgment of this Hon'ble Court's orders.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

44. That it is also noteworthy to state here that the existing situation is being exploited by
respondents. They stand to gain an unenviable advantage without even contesting the case on
merits. The applicant herein (HCBA) has no doubt in its mind that the Hon'ble Supreme Court
clearly did not intend to reward such unscrupulous respondents.
46. That the operation of the decision of the Supreme Court is already resulting in large number of
petitions being rendered infructuous. As more and more respondents decide against filing counter
affidavit, automatic vacation of interim orders results in virtual decision on the merits of the case.
49. That the HCBA faces situations regularly on working days where the members of the Bar
approach and request for intervening in their matters and get their grievances redressed by the
Registry of the Hon'ble High Court or before the Hon'ble Judge where the matter is listed or is on
board but could not be taken up or considered which ultimately results in non-passing of any order
on the stay extension application.
50. That the HCBA twice a week transmits hundreds of stay extension applications details to the
registry requesting for posting of the stay extension application before the appropriate Hon'ble
Court as early as possible. This exercise is also getting frustrated and the earnest requests are also
not proving very fruitful because the applications are not being heard on time. Copies of such
applications are being attached as Annexure No. 1 to this affidavit.
51. That in the meantime, either non-bailable warrants are issued or the litigant gets arrested and
sent to judicial custody in criminal matters and in civil matters the litigants face eviction,
dispossession and demolition or loss of a rightful claim. As such, the applicant is constrained to seek
the following reliefs from the court. The applicant is cognisant of the fact that the directions of the
Supreme Court must be obeyed at any cost. At the same time, the applicant holds an earnest belief
that some relief would be given to the litigants and the lawyers alike."
14. Various prayers have been made by the High Court Bar Association, Allahabad in the application
which is supported by an affidavit. The aforesaid prayers in effect seek clarifications of the directions
issued by the Supreme Court in paras 34, 36, 37 in Asian Resurfacing (supra).
APPLICATION FILED IN APPLICATION U/S 482 Cr.P.C. No. 36085 OF 2019 (RAJU AGRAWAL
VS STATE OF U.P. AND ANOTHER
15. An interim order was granted in favour of the applicant on 30.09.2019 in Criminal Misc. 482
Application No. 36085 of 2019 (Raju Agrawal Vs State of UP and another). By operation of Asian
Resurfacing (supra) after lapse of the prescribed period of time the interim order was automatically
vacated. Vacation of the interim order happened due to excessive work load before this Court, and
failure of the Registry to list the matter and for no fault of the applicant. It is contended that devoid
of interim protection the applicant faces a threat to his liberty, and his remedy before this Court will
be rendered futile in case the application is not allowed.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

16. The application in effect seeks modification/clarification of the directions issued by the Supreme
Court in Asian Resurfacing (supra).
APPLICATION IN APPLICATION UNDER SECTION 482 Cr.P.C. No. 28574 OF 2019
17. The applicant in the instant case has also filed a similar application before us (Criminal Misc.
Application No. 28574 of 2023 (Chandrapal Singh Vs State of U.P. and another) seeking
modification of the directions in Asian Resurfacing (supra). In the absence of such modifications the
applicant will continue to face the harassment of a frivolous criminal case.
I(C). SUBMISSIONS OF LEARNED COUNSELS:
18. Heard Shri Gaurav Mehrotra, learned counsel assisted by Shri Akbar Khan, learned counsel, Ms.
Maria Fatima, learned counsel, Ms. Alina, learned counsel, Shri Swapnil Kumar, learned counsel,
Shri Sushil Shukla, learned counsel, Shri Nitin Sharma, learned counsel, Shri Rahul Agarwal,
learned counsel, Shri Imranullah, learned counsel, Shri Rajrshi Gupta, learned counsel, Shri Kunal
Shah, learned counsel, Ms. Gunjan Jadwani, learned counsel, Shri Ram Kaushik, learned counsel
and Shri Saurabh Pandey, learned counsel, Shri Vishnu Behari Tewari, learned counsel, Shri Tarun
Agrawal, learned counsel, Shri Nadeem Murtaza, learned counsel has appeared through video
conferencing from Lucknow. Shri Manish Goyal, learned Additional Advocate General assisted by
Shri Rupak Chaubey, learned A.G.A.-I have appeared for the State of Uttar Pradesh. Ms. Anjali
Goklani, learned counsel has also assisted the learned Additional Advocate General.
19. The following submissions were made by the learned counsels:
I. The directions of the Supreme Court contained in Asian Resurfacing of Road
Agency Private Limited and another v. Central Bureau of Investigation2 in Paras 34,
36, 37 do not constitute the ratio and are not binding precedent within the meaning
of Article 141 of the Constitution of India.
II. The directions rendered in Asian Resurfacing (supra) by a Division Bench
consisting of three Hon'ble Judges have been made without consideration of the
judgment rendered by a five Judge Bench of the Supreme Court in Abdul Rehman
Antulay v. R.S. Nayak3 and a seven Judge Bench judgment of the Supreme Court in
P. Ramachandra Rao v. State of Karnataka4. Non consideration of the previous
precedents in point render the said directions in Asian Resurfacing (supra) per
incuriam and the same cease to be binding precedent.
III. The directions in Paras 34, 36 and 37 in Asian Resurfacing (supra) are contrary to
the law expounded by the Supreme Court in A. R. Antulay (supra) and P.
Ramchandra Rao (supra). The High Court in a situation of conflict between two
judgments is bound to follow the law laid down by a judgment of larger Bench
strength.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

IV. The Supreme Court in DCIT Vs. Pepsi Foods Ltd.5 has read down the legislative
provision (Section 254-A of the Income Tax Act) which was in the likeness to the
directions in Paras 34, 36 and 37 in Asian Resurfacing (supra) in form, substance and
effect. Section 254-A of the I.T. Act was found to be violative of Article 14 of the
Constitution of India in Pepsico (supra).
V. The directions in Paras 34, 36, 37 of Asian Resurfacing (supra) amount to 'judicial
legislation'. They have to be interpreted consistently with Part III of the Constitution
of India and the doctrine of proportionality.
VI. The powers under Articles 226 and 227 of the Constitution of India are part of the
Basic Structure of the Constitution of India. The directions in Asian Resurfacing
(supra) abridge the aforesaid powers and damage the Basic Structure of the
Constitution.
VII. There is a disarray in the administration of justice in the State due to large scale
vacation of stay orders upon lapse of time in compliance of Asian Resurfacing (supra)
causing the imprisonment of many litigants for no fault of theirs. Similarly, a large
number of litigants also face civil consequences despite diligently prosecuting their
cases before this Court. In most cases the matters cannot be heard due to paucity of
time and large docket size of the High Court. The High Court is liable to provide
necessary clarifications in the matter as the litigants cannot be left remediless.
VIII. Orders extending interim protection passed by the High Court are being
disregarded by the trial courts in many instances after the directions in Asian
Resurfacing (supra).
IX. Lastly, it is submitted in the alternative that in case the High Court rejects their
applications, prayers have been made for grant of certificate for appeal to the
Supreme Court under Articles 132 read with Article 134-A of the Constitution
contending that the directions in Asian Resurfacing (supra) raise substantial
questions as to interpretation of the Constitution.
20. Shri Manish Goyal, learned Additional Advocate General has appeared on behalf of the State.
Shri Manish Goyal, learned Additional Advocate General has contended that the State is committed
to ensuring fair and equal justice to all citizens. The State cannot support a situation where the
interim orders granted in favour of litigant are getting vacated without opportunity of hearing and
for no fault of their. According to the learned Additional Advocate General the High Court cannot
redress the grievances of the said litigants. However, the directions in Paras 34, 36, 37 of Asian
Resurfacing (supra) raise substantial questions relating to interpretation of the Constitution which
have to be framed and addressed promptly in view of the prevailing situation in the State. The
learned Additional Advocate General has lastly reserved the right of the State to make applications
in specific cases for expediting proceedings in the interest of justice and as per law.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

21. Shri Vishnu Behari Tewari, learned counsel and Shri Tarun Agrawal, learned counsel to the
contrary have contended that no substantial questions as to interpretation of the Constitution can
arise as law laid down by the Supreme Court is final.
II A. Asian Resurfacing I,II,III &IV : Fazalullah Khan Vs M. Akbar Contractor
22. The Bench of three Hon'ble Judges of the Supreme Court in Asian Resurfacing of Road Agency
Private Limited and Another Vs Central Bureau of Investigation6 at the outset reproduced the order
of the learned Bench of two Judges of the Supreme Court which defined the issue for consideration:
"A.K. Goel, J. (for himself and Navin Sinha, J.; Nariman, J., concurring)--These
appeals have been put up before this Bench of three Judges in pursuance of the order
of the Bench of two Judges dated 9-9-2013 [Asian Resurfacing of Road
Agency v. CBI, Criminal Appeal No. 1375 of 2013, order dated 9-9-2013 (SC)] as
follows:
"Leave granted. The learned counsel for the parties are agreed that there is
considerable difference of opinion amongst different Benches of this Court as well as
all the High Courts. Mr Ram Jethmalani, learned Senior Counsel appearing for the
petitioner in criminal appeal arising out of Special Leave Petition (Criminal) No.
6470 of 2012 submits that the subsequent decisions rendered by the two-Judge
Benches are per incuriam, and in conflict with the ratio of law laid down in the
Constitution Bench decision in Mohanlal Maganlal Thakkar v. State of
Gujarat [Mohanlal Maganlal Thakkar v. State of Gujarat, (1968) 2 SCR 685 : AIR
1968 SC 733 : 1968 Cri LJ 876] .
In this view of the matter, we are of the opinion that it would be appropriate if the
matters are referred to and heard by a larger Bench. Office is directed to place the
matters before the Hon'ble the Chief Justice of India for appropriate orders.
In the meantime, further proceedings before the trial court shall remain stayed."
23. The Supreme Court in Asian Resurfacing (supra) thereafter enlarged the scope of the issues
under examination and considered a further question as to the approach adopted by the High Court
in dealing with the challenge to the order framing charge:
"2. Since the question of law to be determined is identical in all cases, we have taken
up for consideration this matter. In the light of the answer to the referred question,
this as well as all other matters may be considered for disposal on merits by the
appropriate Bench.
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

18. We have given due considerations to the rival submissions and perused the
decisions of this Court. Though the question referred relates to the issue whether
order framing charges is an interlocutory order, we have considered further question
as to the approach to be adopted by the High Court in dealing with the challenge to
the order framing charge. As already noted in para 11, the impugned order also
considered the said question. The learned counsel for the parties have also addressed
the Court on this question."
(emphasis supplied)
24. Following observations as regards delays in criminal trials and its "deleterious effect" on the
administration of justice were made in Asian Resurfacing (supra):
"30. It is well accepted that delay in a criminal trial, particularly in the PC Act cases,
has deleterious effect on the administration of justice in which the society has a vital
interest. Delay in trials affects the faith in Rule of Law and efficacy of the legal
system. It affects social welfare and development. Even in civil or tax cases it has
been laid down that power to grant stay has to be exercised with restraint. Mere
prima facie case is not enough. Party seeking stay must be put to terms and stay
should not be an incentive to delay. The order granting stay must show application of
mind. The power to grant stay is coupled with accountability. [Siliguri
Municipality v. Amalendu Das, (1984) 2 SCC 436, para 4 : 1984 SCC (Tax)
133; CCE v. Dunlop India Ltd., (1985) 1 SCC 260, para 5 : 1985 SCC (Tax) 75; State
(UT of Pondicherry) v. P.V. Suresh, (1994) 2 SCC 70, para 15 and State of
W.B. v. Calcutta Hardware Stores, (1986) 2 SCC 203, para 5]
31. Wherever stay is granted, a speaking order must be passed showing that the case
was of exceptional nature and delay on account of stay will not prejudice the interest
of speedy trial in a corruption case. Once stay is granted, proceedings should not be
adjourned, and concluded within two-three months."
25. Finally the Supreme Court in Asian Resurfacing (supra) extended the mandate of speedy justice
to all civil and criminal cases, pending before all High Courts in which interim orders staying civil
suits and criminal trials were granted and issued the following directions:
"34. If contrary to the above law, at the stage of charge, the High Court adopts the
approach of weighing probabilities and reappreciating the material, it may be
certainly a time-consuming exercise. The legislative policy of expeditious final
disposal of the trial is thus, hampered. Thus, even while reiterating the view that
there is no bar to jurisdiction of the High Court to consider a challenge against an
order of framing charge in exceptional situation for correcting a patent error of lack
of jurisdiction, exercise of such jurisdiction has to be limited to the rarest of rare
cases. Even if a challenge to order framing charge is entertained, decision of such a
petition should not be delayed. Though no mandatory time-limit can be fixed,Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

normally it should not exceed two-three months. If stay is granted, it should not
normally be unconditional or of indefinite duration. Appropriate conditions may be
imposed so that the party in whose favour stay is granted is accountable if court
finally finds no merit in the matter and the other side suffers loss and injustice. To
give effect to the legislative policy and the mandate of Article 21 for speedy justice in
criminal cases, if stay is granted, matter should be taken on day-to-day basis and
concluded within two-three months. Where the matter remains pending for longer
period, the order of stay will stand vacated on expiry of six months, unless extension
is granted by a speaking order showing extraordinary situation where continuing stay
was to be preferred to the final disposal of trial by the trial court. This timeline is
being fixed in view of the fact that such trials are expected to be concluded normally
in one to two years.
(emphasis supplied)
36. In view of the above, situation of proceedings remaining pending for long on
account of stay needs to be remedied. Remedy is required not only for corruption
cases but for all civil and criminal cases where on account of stay, civil and criminal
proceedings are held up. At times, proceedings are adjourned sine die on account of
stay. Even after stay is vacated, intimation is not received and proceedings are not
taken up. In an attempt to remedy this situation, we consider it appropriate to direct
that in all pending cases where stay against proceedings of a civil or criminal trial is
operating, the same will come to an end on expiry of six months from today unless in
an exceptional case by a speaking order such stay is extended. In cases where stay is
granted in future, the same will end on expiry of six months from the date of such
order unless similar extension is granted by a speaking order. The speaking order
must show that the case was of such exceptional nature that continuing the stay was
more important than having the trial finalised. The trial court where order of stay of
civil or criminal proceedings is produced, may fix a date not beyond six months of the
order of stay so that on expiry of period of stay, proceedings can commence unless
order of extension of stay is produced.
(emphasis supplied)
37. Thus, we declare the law to be that order framing charge is not purely an
interlocutory order nor a final order. Jurisdiction of the High Court is not barred
irrespective of the label of a petition, be it under Sections 397 or 482 CrPC or Article
227 of the Constitution. However, the said jurisdiction is to be exercised consistent
with the legislative policy to ensure expeditious disposal of a trial without the same
being in any manner hampered. Thus considered, the challenge to an order of charge
should be entertained in a rarest of rare case only to correct a patent error of
jurisdiction and not to reappreciate the matter. Even where such challenge is
entertained and stay is granted, the matter must be decided on day-to-day basis so
that stay does not operate for an unduly long period. Though no mandatoryChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

time-limit may be fixed, the decision may not exceed two-three months normally. If it
remains pending longer, duration of stay should not exceed six months, unless
extension is granted by a specific speaking order, as already indicated. Mandate of
speedy justice applies to the PC Act cases as well as other cases where at trial stage
proceedings are stayed by the higher court i.e. the High Court or a court below the
High Court, as the case may be. In all pending matters before the High Courts or
other courts relating to the PC Act or all other civil or criminal cases, where stay of
proceedings in a pending trial is operating, stay will automatically lapse after six
months from today unless extended by a speaking order on the above parameters.
Same course may also be adopted by civil and criminal appellate/Revisional Courts
under the jurisdiction of the High Courts. The trial courts may, on expiry of the above
period, resume the proceedings without waiting for any other intimation unless
express order extending stay is produced."
(emphasis supplied)
26. It needs to be mentioned that Asian Resurfacing (supra) decided the issue as regards nature of
order of framing of the charge and remedies against it by holding thus:
"Thus, we declare the law to be that order framing charge is not purely an
interlocutory order nor a final order. Jurisdiction of the High Court is not barred
irrespective of the label of a petition, be it under Sections 397 or 482 CrPC or Article
227 of the Constitution. However, the said jurisdiction is to be exercised consistent
with the legislative policy to ensure expeditious disposal of a trial without the same
being in any manner hampered."
27. The issue of compliance of the directions (paras 34, 36, 37) in Asian Resurfacing (supra) arose in
Asian Resurfacing of Road Agency Private Limited and Another v. Central Bureau of Investigation7,
(hereinafter referred to as "Asian Resurfacing-II"), wherein the aforesaid directions were
emphatically reiterated:
"1. Having heard Mr Dilip Annasaheb Taur, learned counsel for the applicant and Mr
S.V. Raju, learned ASG for the respondent, we are constrained to point out that in our
directions contained in the judgment delivered in Asian Resurfacing of Road Agency
(P) Ltd. v. CBI [Asian Resurfacing of Road Agency (P) Ltd. v. CBI, (2018) 16 SCC 299
: (2020) 1 SCC (Cri) 686] and, in particular, para 35, it is stated thus : (SCC p. 324)
"35. ... In cases where stay is granted in future, the same will end on expiry of six
months from the date of such order unless similar extension is granted by a speaking
order. The speaking order must show that the case was of such exceptional nature
that continuing the stay was more important than having the trial finalised. The trial
court where order of stay of civil or criminal proceedings is produced, may fix a date
not beyond six months of the order of stay so that on expiry of period of stay,
proceedings can commence unless order of extension of stay is produced."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

2. The learned Additional Chief Judicial Magistrate, Pune, by his order dated 4-12-2019, has instead
of following our judgment in letter as well as spirit, stated that the complainant should move an
application before the High Court to resume the trial. The Magistrate goes on to say:"The lower
court cannot pass any order which has been stayed by the Hon'ble High Court, Bombay with due
respect of ratio of the judgment in Asian Resurfacing of Road Agency (P) Ltd. [Asian Resurfacing of
Road Agency (P) Ltd. v. CBI, (2018) 16 SCC 299 : (2020) 1 SCC (Cri) 686]". We must remind the
Magistrates all over the country that in our pyramidical structure under the Constitution of India,
the Supreme Court is at the apex, and the High Courts, though not subordinate administratively, are
certainly subordinate judicially. This kind of orders fly in the face of para 36 of our judgment.
(emphasis supplied)
3. We expect that the Magistrates all over the country will follow our order in letter and spirit.
Whatever stay has been granted by any court including the High Court automatically expires within
a period of six months, and unless extension is granted for good reason, as per our judgment, within
the next six months, the trial court is, on the expiry of the first period of six months, to set a date for
the trial and go ahead with the same.
(emphasis supplied)
4. With this observation, the order dated 4-12-2019 is set aside with a direction to the learned
Additional Chief Judicial Magistrate, Pune to set down the case for hearing immediately."
28. Similarly the need to comply the said directions was restated in Asian Resurfacing of Road
Agency Private Limited Vs. Central Bureau of Investigation8 (hereinafter referred to as the Asian
Resurfacing-III).
29. In Misc. Application No. 1577 of 2020 in Criminal Appeals Nos. 1375-1376 of 2013 seeking
clarification of in Asian Resurfacing (supra) the following order was passed on 25.04.20229:
"In the application for clarification, we pass the following order:
The applicant seeks clarification that the order passed by this Court in Asian
Resurfacing of Road Agency Private Limited and Another v. Central Bureau of
Investigation (2018) 16 SCC 299 would apply to the facts of the applicant's case. It
must be noted that the applicant is writ petitioner before the High Court. Learned
Single Judge has disposed of the writ petition. The said judgment is challenged
before the Division Bench in a Letter Patent Appeal. In the LPA, an interim order was
passed granting 1 MA No. 706/2022 in MA 1577/2020 in Crl.A. No. 1375-1376/2013
stay on 06.02.2015:
"One of the contention raised is that the respondent-Engineering College remained
functional for hardly 2-3 years and is lying closed since the year 2013 and all the
students who were admitted in that college have been migrated to other recognizedChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Engineering Colleges.
Let notice of motion be issued to respondent No. 1 only for 21.05.2015.
Meanwhile, operation of the order passed by the learned Single Judge shall remain
stayed.
Relying upon the judgment in Asian Resurfacing of Road Agency Private Limited and
Another (supra), a clarification is sought that in the fact situation projected by the
applicant, the principle enunciated by this Court will apply. We must notice that the
direction issued in Asian Resurfacing of Road Agency Private Limited and Another
(supra) arose out of the factual and legal matrix present therein. The case revolved
around the questions arising out of the pendency of civil and criminal cases, i.e., of
trial being halted and the tendency towards procrastination on the strength of the
orders of stay granted. The result was that cases were not being taken to their logical
conclusion with the speed with which they should have been done. We may notice the
following :
"36. In view of the above, situation of proceedings remaining pending for long on
account of stay needs to be remedied. Remedy is required not only for corruption
cases but for all civil and criminal cases where on account of stay, civil and criminal
proceedings are held up. At times, proceedings are adjourned sine die on account of
stay. Even after stay is vacated, intimation is not received and proceedings are not
taken up. In an attempt to remedy this 2 MA No. 706/2022 in MA 1577/2020 in
Crl.A. No. 1375-1376/2013 situation, we consider it appropriate to direct that in all
pending cases where stay against proceedings of a civil or criminal trial is operating,
the same will come to an end on expiry of six months from today unless in an
exceptional case by a speaking order such stay is extended. In cases where stay is
granted in future, the same will end on expiry of six months from the date of such
order unless similar extension is granted by a speaking order. The speaking order
must show that the case was of such exceptional nature that continuing the stay was
more important than having the trial finalised. The trial court where order of stay of
civil or criminal proceedings is produced, may fix a date not beyond six months of the
order of stay so that on expiry of period of stay, proceedings can commence unless
order of extension of stay is produced."
We are afraid that the attempt of the applicant to draw inspiration from the above directions as
referred to above cannot succeed in view that this Court cannot be understood as having intended to
apply the principle to the fact situation which is presented in this case. Accordingly, the
miscellaneous application for clarification is disposed of by clarifying that the order of stay granted
by the Division Bench in the High Court cannot be treated as having no force. However, we leave it
open to the applicant to seek early disposal of the case."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

30. The aforesaid order does not have any bearing on the proceedings before this Court inasmuch as
the proceedings in the clarification application arose out of a judgment rendered by a Single Judge
disposing of a writ petition which was assailed before a Division Bench in letters patent appeal.
31. Lastly it is noteworthy that the Supreme Court in Fazalullah Khan Vs M. Akbar Contractor (D) by
Lrs. And others10 clarified that the directions issued in Asian Resurfacing (supra) shall not be
applicable to similar proceedings pending before the Supreme Court. The relevant part of the
judgment is extracted hereunder:
"5. We are constrained to pen down a more detailed order as the judgment of this
Court in Asian Resurfacing of Road Agency's case (supra) is sought to be relied upon
by difference courts even in respect of interim orders granted by this Court where the
period of 6 months has expired. Such a course of action is not permissible and if
the interim order granted by this Court is not vacated and continues beyond a period
of 6 months by reason of pendency of the appeal, it cannot be said that the interim
order would automatically stand vacated.
6. Thus, the interim order granted by this Court on 20th March, 2009 must continue
to be in force till the appeal is decided.
7. The aforesaid observation made by us should be kept in mind by both the trial
Court and the High Court while dealing with this aspect.
8. The application accordingly stands disposed of."
IIB.Implementation of Asian Resurfacing(supra) : Consequences & Complications
32. The details provided by the Registry of Allahabad High Court, reproduced hereinafter, clearly
disclose that strict adherence to the timeline of six months prescribed in paras 34, 36, 37 of Asian
Resurfacing of Road Agency Private Limited and Another v. Central Bureau of Investigation11 is
practically unfeasible. The report submitted by the Registry in this regard is extracted hereinunder:
"The average daily docket size of the respective Benches of this Hon'ble Court in the
following determinations for the past two years:
Sr. No. Determination Total cases listed before each Hon'ble Court on a daily basis
1.
Article 227
2. Article 226 (Criminal Writs)
3. Section 482 Cr.P.C.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

4. Criminal Revision
5. F.A.F.O.
6. Second Appeal There are multiple Benches taking up/hearing aforementioned determinations."
33. Large docket sizes which include fresh and listed cases, the need to give fair hearing and render
speaking orders as well as other requirements of fairness in judicial proceedings, limitations of time,
infrastructure availability and other relevant factors determine the capacity of the High Court to
decide cases in any given time frame. The facts and figures on the relevant parameters presented by
the Allahabad High Court Registry and other germane criteria regarding the capacity of the High
Court to decide cases in the time frame stipulated in Asian Resurfacing (supra) have been examined
by this Bench.
34. The High Court has granted interim orders staying criminal trials or civil suits while exercising
powers under different nomenclatures namely Article 226, Article 227, Section 482 Cr.P.C. and even
under revisional jurisdictions. Upon consideration of the said relevant factors and available figures
we conclude that it is practically unfeasible for this Court to decide all civil and criminal cases in
which interim orders staying trials/suits have been granted, or to extend the interim orders after
returning the findings within the prescribed period of six months and in the manner stipulated in
the directions contained in paras 34, 36, 37 of Asian Resurfacing (supra). On many occasions all
listed matters are not taken up or heard on merits due to paucity of time before the court. Further,
listing of matters is restricted owing to the size of the docket.
35. Consequently interim orders so granted by the High Court are automatically vacated after lapse
of six months in most of the said category of cases by operation of directions in Asian Resurfacing
(supra). The criminal trials and civil suits and proceedings before tribunals which were stayed by
High Court are ipso facto set in motion in compliance of Asian Resurfacing (supra). Interim
protection granted by the High Court is thus being withdrawn on a large scale without any fault of
the parties which are adversely affected. Thus devoid of protection of the interim orders vast
numbers of litigants suffer arrest and imprisonment or face vexatious litigation or are visited by civil
consequences.
36. The opposite parties adopt unscrupulous tactics. They fail to enter appearance before the court
or do not file counter affidavits. The opposite parties avoid adjudication on merits, and simply wait
out the period of six months for the interim orders to be vacated automatically. There is a de-facto
termination of proceedings without adjudication of substantive rights by this Court after the stay
orders are vacated and the parties suffer the consequences.
37. The compliance of the directions in Asian Resurfacing (supra) by the courts in Uttar Pradesh has
spawned multiplicity of litigation and duplication of efforts. The parties whose interim orders have
been vacated and face imminent threat of arrest file fresh petitions on the same cause of action.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

38. It is also urged that there is a large scale explosion of the dockets on account of increase in the
stay extension applications, as well as fresh petitions under Section 482 Cr.P.C., Article 227 petition
etc. which is also putting pressure on the time of the court. Besides in many instances, contempt
proceedings have been drawn against judicial officers who have disobeyed the stay extension orders
passed by this Court on the footing that the said orders are in the teeth of Asian Resurfacing (supra)
and Asian Resurfacing II (supra) and Asian Resurfacing III(supra).
39. The learned members of the Bar contended that there are numerous instances of miscarriages of
justice in the State by the implementation of the directions in paras 34, 36, 37 of Asian Resurfacing
(supra). Few of such cases cited at the Bar are being referenced by way of exemplars.
40. The facts in Application U/s 482 No. 2856 of 2021 (Smt. Lalita Chauhan and 2 others Vs State of
U.P. and another) are these. The three applicants namely Smt. Lalita Chauhan, Vishakha Chauhan,
Yogendra Chauhan had assailed the criminal proceedings registered against them as Criminal Case
No. 13789 of 2019 (arising out of Case Crime No. 459 of 2018) under Section 420 I.P.C., by
instituting the above mentioned application under Section 482 Cr.P.C. contending that the
proceedings were an abuse of the process of law. Finding prima facie substance in such contention
an interim order was granted by this Court on 10.02.2021 staying the criminal trial proceedings. The
informant did not appear before this Court despite notices, and no counter affidavit was filed by the
State Government either. The matter was listed several times. However it could not be taken up for
hearing due to paucity of time with the court and large docket size. The applicants also filed a stay
extension application. No order could be passed on the stay extension application by this Court for
the same reasons. In the meantime the interim order granted by this Court was vacated
automatically by operation of the directions in Asian Resurfacing (supra). Trial proceedings
commenced. The trial court took out coercive measures by issuing non-bailable warrants leading to
the arrest of applicant no. 2. The applicant no. 2 Ms. Vishakha Chauhan was a bright student who
had been offered admission in Niagara College, Toronto, Canada. According to Sri Sushil Shukla,
learned counsel the imprisonment cast an indelible stigma on her. It is noteworthy that the said
application U/s 482 was finally allowed by this Court vide judgment dated 18.10.2022, and the
criminal proceedings against the applicants including Ms. Vishakha Chauhan were quashed.
41. Another instance cited at the bar arose out of a civil suit registered as S.C.C. Suit No. 20 of 2005.
The judgment and decree dated 31.10.2013 rendered by the learned trial court in the SCC Suit No.
20 of 2005 and the judgment of the revising court handed down in SCC Revision No. 11 of 2014 on
10.10.2019 were assailed in Matters Under Article 227 No. 134 of 2020 (Late Mohammad Yunus
Qureshi (Deceased) and 8 others Vs Mohammad Yunus Qureshi) by the applicant before this Court.
An interim order was passed by this Court directing stay of the judgments and decrees dated
31.10.2013 and 10.10.2019 passed by the trial and revisional courts respectively.
42. The matter could not be taken up for hearing on many occasions due to paucity of time and large
docket size. The interim order was vacated in view of Asian Resurfacing (supra) for no fault of the
applicant. The court below commenced execution proceedings after recording that the same is in
compliance of the directions of the Supreme Court in Asian Resurfacing (supra).Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

43. In the aforesaid case, the judgment debtor was dispossessed on orders of the learned court
below despite the interim order granted by this Court. Subsequently contempt proceedings were
registered against the judicial officer by registering Civil Contempt Application No. 5178 of 2022
(Late Mohammad Yunus Qureshi and 8 others Vs Lovely Jaiswal, Civil Judge (Senior Division)
First, Hapur and another) for violating the orders passed by this Court.
44. It has been contended that the judgment of this Court in Dharam Vir Sood Vs Savitri Devi and
others12, has distinguished the directions in Asian Resurfacing (supra) and held that the same are
not applicable to execution proceedings. However, the trial courts are disregarding the judgment of
this Court in Dharam Vir Sood (supra) in view of the directions of the Supreme Court in Asian
Resurfacing-II and III.
45. Trial courts have also declined to comply with stay extension orders passed by the High Court on
the footing that they are not consistent with Asian Resurfacing (supra). Consequently contempt
proceedings have also been instituted against the judicial officers. One such instance is Contempt
Application No. 6688 of 2019 (Satpal Singh and 2 others Vs Piyush Verma, Civil Judge (J.D.) and
another). Relevant parts of the order of this Court dated 14.12.2018 are extracted below:
"The applicant/plaintiffs filed the stay order before the trial court, but, the trial court
vide order dated 26.11.2018 relying upon the decision of the Supreme Court rendered
in Asian Resurfacing of Road Agency v. Central Bureau of Investigation, 2018 (Suppl)
ADJ 209, declined to stay the suit proceedings for the reason that the order passed by
this Court extending the interim order is not a speaking order in terms of Asian
Resurfacing (supra). In the opinion of the trial court the interim order passed by this
Court staying the suit proceedings stands vacated, consequently, the trial court by
order dated 26.11.2018 has posted the suit for evidence.
Learned counsel for the applicant submits that it is not open for the trial court to
bypass the order/direction of this Court or decline to obey the order staying the
proceedings of the trial court. The conduct of the judicial officer tantamounts to
judicial impropriety and contempt of court. This Court while extending the interim
order noted that the matter arising out of original suit proceeding was not cognizable
by the Bench, consequently, the interim order was extended till the next date of
listing which is sufficient reason.
Learned counsel appearing for the High Court submits that it is not open for the
subordinate court to disobey any order or direction passed by this Court even if in the
opinion of the trial court such an order is a non-speaking order. The plea that the
order is not a speaking order would not be a ground to defy the order of the superior
court. If such a situation is permitted to prevail, the judicial officers on the pretext of
the Supreme Court judgment would ignore and bypass the High Court. Such a
situation would lead to judicial choas and indiscipline, and the litigant would loose
faith in the administration of justice.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

The mandate in Asian Resurfacing (supra) is binding on the Courts. This Court has
been extending the interim orders due to paucity of time. The order is a non-speaking
order but in any case it is an order of this Court which binds the court below. Non
compliance of the order of the High Court for whatever reason does not augment well
with the litigant and embarrasses the superior Court in the administration of justice.
The situation needs to be remedied."
(emphasis supplied)
46. However, the High Court cannot remedy the situation prevailing in the trial courts in view of the
directions in Asian Resurfacing (supra) which were also emphatically reiterated in Asian
Resurfacing-II & III(supra). Though it needs to be clarified unequivocally that this Court is
complying with the directions in paras 34, 36, 37 in Asian Resurfacing (supra) in letter and spirit.
Pursuant to the said directions of the Supreme Court, the Registry of Allahabad High Court vide
circular dated 26.04.2018 has directed all trial courts to follow the said judgment of the Supreme
Court scrupulously.
47. Implementation of the directions in paras 34, 36, and 37 of Asian Resurfacing (supra) has raised
several complications. It is not an exaggeration to say that the Allahabad High Court faces a
challenge of epic scale. The status of the High Court as a Constitutional Court founded to achieve the
preambled resolve of securing justice to all citizens and to uphold the laws and liberties is being
called in question on a daily basis. The superintending jurisdiction of the High Court over the trial
courts and tribunals is being undermined regularly. The administration of justice in the State has
been severely impaired. This is the unvarnished truth of the matter. We say with responsibility and
not in rhetoric that the Allahabad High Court faces a constitutional crisis.
48. The problem of arrears is among the most critical challenges being faced not only by Allahabad
High Court but the judiciary in the country. This Court is conscious of the pressing need to decide
cases expeditiously. To this end, the Court has bent all its energies and has spared no efforts. The
problem of arrears is also being examined and addressed by this Court on the administrative side by
a committee of seven Judges constituted exclusively for this task. However in view of both the
magnitude and complexity of the problem no easy solutions are in sight. Unremitting endeavours,
constant institutional thought and concerted action of all stakeholders would ultimately pave the
way for a solution.
III. Fixation of time limits by courts to conclude criminal/judicial proceedings: Whether Asian
Resurfacing (supra) runs contrary to the law laid down in A. R. Antulay(supra) and P. Ramachandra
Rao(supra)?
49. After acknowledging the mandate for speedy trials emanating both from constitutional
guarantees and provisions of Code of Criminal Procedure the Supreme Court in A. R. Antulay
(supra) reflected upon various complex and inter related causes for delays in trials:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"82.The provisions of the Code of Criminal Procedure are consistent with and indeed
illustrate this principle. They provide for an early investigation and for a speedy and
fair trial. The learned Attorney General is right in saying that if only the provisions of
the Code are followed in their letter and spirit, there would be little room for any
grievance. The fact however, remains unpleasant as it is, that in many cases, these
provisions are honoured more in breach. Be that as it may, it is sufficient to say that
the constitutional guarantee of speedy trial emanating from Article 21 is properly
reflected in the provisions of the Code.
83. But then speedy trial or other expressions conveying the said concept -- are
necessarily relative in nature. One may ask -- speedy means, how speedy? How long a
delay is too long? We do not think it is possible to lay down any time schedules for
conclusion of criminal proceedings. The nature of offence, the number of accused, the
number of witnesses, the workload in the particular court, means of communication
and several other circumstances have to be kept in mind. For example, take the very
case in which Ranjan Dwivedi (petitioner in Writ Petition No. 268 of 1987) is the
accused. 151 witnesses have been examined by the prosecution over a period of five
years. Examination of some of the witnesses runs into more than 100 typed pages
each. The oral evidence adduced by the prosecution so far runs into, we are told,
4000 pages. Even though, it was proposed to go on with the case five days of a week
and week after week, it was not possible for various reasons viz., non-availability of
the counsel, non-availability of accused, interlocutory proceedings and other systemic
delays. A murder case may be a simple one involving say a dozen witnesses which can
be concluded in a week while another case may involve a large number of witnesses,
and may take several weeks. Some offences by their very nature e.g., conspiracy
cases, cases of misappropriation, embezzlement, fraud, forgery, sedition, acquisition
of disproportionate assets by public servants, cases of corruption against high public
servants and high public officials take longer time for investigation and trial. Then
again, the workload in each court, district, region and State varies. This fact is too
well known to merit illustration at our hands. In many places, requisite number of
courts are not available. In some places, frequent strikes by members of the bar
interferes with the work schedules. In short, it is not possible in the very nature of
things and present day circumstances to draw a time-limit beyond which a criminal
proceeding will not be allowed to go. Even in the USA, the Supreme Court has refused
to draw such a line. Except for the Patna Full Bench decision under appeal, no other
decision of any High Court in this country taking such a view has been brought to our
notice. Nor, to our knowledge, in United Kingdom. Wherever a complaint of
infringement of right to speedy trial is made the court has to consider all the
circumstances of the case including those mentioned above and arrive at a decision
whether in fact the proceedings have been pending for an unjustifiably long period.
In many cases, the accused may himself have been responsible for the delay. In such
cases, he cannot be allowed to take advantage of his own wrong. In some cases,
delays may occur for which neither the prosecution nor the accused can be blamed
but the system itself. Such delays too cannot be treated as unjustifiable -- broadlyChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

speaking. Of course, if it is a minor offence -- not being an economic offence -- and
the delay is too long, not caused by the accused, different considerations may arise.
Each case must be left to be decided on its own facts having regard to the principles
enunciated hereinafter. For all the above reasons, we are of the opinion that it is
neither advisable nor feasible to draw or prescribe an outer time-limit for conclusion
of all criminal proceedings. It is not necessary to do so for effectuating the right to
speedy trial. We are also not satisfied that without such an outer limit, the right
becomes illusory."
50. Thereafter the Supreme Court in A. R. Antulay (supra) clearly set its face against the fixing of
outer time limits for trial of offences as a solution for such delays. A. R. Antulay (supra) cautioned
against frivolous litigation, but also made a categorical pronouncement that proceedings taken out
by either party to vindicate their rights and interests, as perceived by them, cannot be treated as
delaying tactics nor can the time taken in pursuing such proceedings be counted towards delay by
holding thus:
"86. (4) At the same time, one cannot ignore the fact that it is usually the accused
who is interested in delaying the proceedings. As is often pointed out, "delay is a
known defence tactic". Since the burden of proving the guilt of the accused lies upon
the prosecution, delay ordinarily prejudices the prosecution. Non-availability of
witnesses, disappearance of evidence by lapse of time really work against the interest
of the prosecution. Of course, there may be cases where the prosecution, for whatever
reason, also delays the proceedings. Therefore, in every case, where the right to
speedy trial is alleged to have been infringed, the first question to be put and
answered is -- who is responsible for the delay? Proceedings taken by either party in
good faith, to vindicate their rights and interest, as perceived by them, cannot be
treated as delaying tactics nor can the time taken in pursuing such proceedings be
counted towards delay. It goes without saying that frivolous proceedings or
proceedings taken merely for delaying the day of reckoning cannot be treated as
proceedings taken in good faith. The mere fact that an application/petition is
admitted and an order of stay granted by a superior court is by itself no proof that the
proceeding is not frivolous. Very often these stays are obtained on ex parte
representation.
(emphasis supplied) (5) While determining whether undue delay has occurred
(resulting in violation of Right to Speedy Trial) one must have regard to all the
attendant circumstances, including nature of offence, number of accused and
witnesses, the workload of the court concerned, prevailing local conditions and so on
-- what is called, the systemic delays. It is true that it is the obligation of the State to
ensure a speedy trial and State includes judiciary as well, but a realistic and practical
approach should be adopted in such matters instead of a pedantic one.
(emphasis supplied) (10) It is neither advisable nor practicable to fix any time-limit for trial of
offences. Any such rule is bound to be qualified one. Such rule cannot also be evolved merely to shiftChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the burden of proving justification on to the shoulders of the prosecution. In every case of complaint
of denial of right to speedy trial, it is primarily for the prosecution to justify and explain the delay. At
the same time, it is the duty of the court to weigh all the circumstances of a given case before
pronouncing upon the complaint. The Supreme Court of USA too has repeatedly refused to fix any
such outer time-limit in spite of the Sixth Amendment. Nor do we think that not fixing any such
outer limit ineffectuates the guarantee of right to speedy trial."
(emphasis supplied)
51. It is equally noteworthy that despite the aforesaid holdings in A. R. Antulay (supra), directions
were issued by the Supreme Court in subsequent cases prescribing limitation for concluding trials
and other criminal proceedings.
52. In Common Cause Vs Union of India-I13, Common Cause Vs Union of India-II14, Raj Deo
Sharma Vs State of Bihar-I15, Raj Deo Sharma Vs State of Bihar-II16, strict time limits to conclude
trials and other criminal proceedings were prescribed by the Supreme Court.
53. One such case depicts the anomalies which arose from the aforesaid directions and was quoted
in P. Ramachandra Rao (supra):
"2. In Criminal Appeal No. 535 of 2000, the appellant was working as an Electrical
Superintendent in Mangalore City Corporation. For the check period 1-5-1961 to
25-8-1987, he was found to have amassed assets disproportionate to his known
sources of income. Charge-sheet accusing him of offences under Section 13(1)(e) read
with Section 13(2) of the Prevention of Corruption Act, 1988 was filed on 15-3-1994.
The accused appeared before the Special Court and was enlarged on bail on 6-6-1994.
Charges were framed on 10-8-1994 and the case proceeded for trial on 8-11-1994.
However, the trial did not commence. On 23-2-1999, the learned Special Judge who
was seized of the trial directed the accused to be acquitted as the trial had not
commenced till then and the period of two years had elapsed which obliged him to
acquit the accused in terms of the directions of this Court in Raj Deo Sharma v. State
of Bihar [(1998) 7 SCC 507: 1998 SCC (Cri) 1692] [hereinafter Raj Deo Sharma (I)]."
(emphasis supplied)
54. Complications resulting from the aforesaid directions were squarely brought to the notice of the
Supreme Court. When the said appeals came up for hearing the Supreme Court found that apart
from the merits, questions in the said appeals which would have relevance in many more to follow.
55. In this view of the matter a Bench of three Judges of the Supreme Court in P. Ramachandra Rao
Vs State of Karnataka17, passed the following order on 19.09.2000:
"3. The appeals came up for hearing before a Bench of three learned Judges who
noticed the common ground that the appeals in the High Court were allowed by theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

learned Judge thereat without issuing notice to the accused and upon this ground
alone, of want of notice, the appeals hereat could be allowed and the appeals before
the High Court restored to file for fresh disposal after notice to the accused but it was
felt that a question arose in these appeals which was likely to arise in many more and
therefore the appeals should be heard on their merits. In the order dated 19-9-2000
[P. Ramachandra Rao v. State of Karnataka, (2002) 4 SCC 607] , the Bench of three
learned Judges stated:
"The question is whether the earlier judgments of this Court, principally, in 'Common
Cause' A Registered Society v. Union of India [(1996) 4 SCC 33 : 1996 SCC (Cri) 589]
, 'Common Cause' A Registered Society v. Union of India [(1996) 6 SCC 775 : 1997
SCC (Cri) 42] , Raj Deo Sharma v. State of Bihar [(1998) 7 SCC 507 : 1998 SCC (Cri)
1692] and Raj Deo Sharma (II) v. State of Bihar [(1999) 7 SCC 604 : 1999 SCC (Cri)
1324] would apply to prosecutions under the Prevention of Corruption Act and other
economic offences.
Having perused the judgments aforementioned, we are of the view that these appeals
should be heard by a Constitution Bench. We take this view because we think that it
may be necessary to synthesise the various guidelines and directions issued in these
judgments. We are also of the view that a Constitution Bench should consider
whether time-limits of the nature mentioned in some of these judgments can, under
the law, be laid down."
56. The Constitution Bench so constituted heard the appeals. During the hearing an issue clearly
arose that the directions made in Common Cause I & II and Raj Deo Sharma I & II ran counter to
the Constitution Bench in A. R. Antulay (supra). In the opinion of the Constitution Bench the
appeals were liable to be heard by a Bench of seven Hon'ble Judges. The relevant part of the order is
extracted below:
"4. On 25-4-2001 [P. Ramachandra Rao v. State of Karnataka, (2001) 4 Scale 226(2)]
, the appeals were heard by the Constitution Bench and during the course of hearing,
attention of the Constitution Bench was invited to the decision of an earlier
Constitution Bench in Abdul Rehman Antulay v. R.S. Nayak [(1992) 1 SCC 225 : 1992
SCC (Cri) 93] and the four judgments referred to in the order of reference dated
19-9-2000 by the Bench of three learned Judges. It appears that the learned Judges
of the Constitution Bench were of the opinion that the directions made in the
two Common Cause cases and the two Raj Deo Sharma cases ran counter to the
Constitution Bench directions in Abdul Rehman Antulay case [(1992) 1 SCC 225 :
1992 SCC (Cri) 93] the latter being a five-Judge Bench decision, the appeals deserved
to be heard by a Bench of seven learned Judges. The relevant part of the order dated
25-4-2001 [P. Ramachandra Rao v. State of Karnataka, (2001) 4 Scale 226(2)] reads
as under:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"The Constitution Bench judgment in A.R. Antulay case [(1992) 1 SCC 225 : 1992 SCC
(Cri) 93] holds that 'it is neither advisable nor feasible to draw or prescribe an outer
time-limit for conclusion of all criminal proceedings'. Even so, the four judgments
aforementioned lay down such time-limits. Two of them also lay down to which class
of criminal proceedings such time-limits should apply and to which class they should
not.
We think, in these circumstances, that a Bench of seven learned Judges should
consider whether the dictum aforementioned in A.R. Antulay case [(1992) 1 SCC 225 :
1992 SCC (Cri) 93] still holds the field; if not, whether the general directions of the
kind given in these judgments are permissible in law and should be upheld.
Having regard to what is to be considered by the Bench of seven learned Judges,
notice shall issue to the Attorney-General and to the Advocates-General of the States.
The papers shall be placed before the Hon'ble the Chief Justice for appropriate
directions. Having regard to the importance of the matter, the Bench may be
constituted at an early date."
(emphasis supplied)
57. The seven Judges Constitution Bench in P. Ramachandra Rao (supra) began its consideration in
the backdrop of various landmark judgments including Hussainara Khatoon (I) Vs Home Secretary
State of Bihar18, Maneka Gandhi Vs Union of India19 & A. R. Antulay (supra):
"8. The width of vision cast on Article 21, so as to perceive its broad sweep and
content, by the seven-Judge Bench of this Court in Maneka Gandhi v. Union of
India [(1978) 1 SCC 248] inspired a declaration of law, made on 12-2-1979
in Hussainara Khatoon (I) v. Home Secy., State of Bihar [(1980) 1 SCC 81 : 1980 SCC
(Cri) 23] that Article 21 confers a fundamental right on every person not to be
deprived of his life or liberty, except according to procedure established by law; that
such procedure is not some semblance of a procedure but the procedure should be
"reasonable, fair and just"; and therefrom flows, without doubt, the right to speedy
trial. The Court said (SCC p. 89, para 5)--
"No procedure which does not ensure a reasonably quick trial can be regarded as
'reasonable, fair or just' and it would fall foul of Article 21. There can, therefore, be no
doubt that speedy trial, and by speedy trial we mean reasonably expeditious trial, is
an integral and essential part of the fundamental right to life and liberty enshrined in
Article 21."
Many accused persons tormented by unduly lengthy trial or criminal proceedings, in any forum
whatsoever were enabled, by Hussainara Khatoon (I) [(1980) 1 SCC 81 : 1980 SCC (Cri) 23]
statement of law, in successfully maintaining petitions for quashing of charges, criminal proceedingsChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

and/or conviction, on making out a case of violation of Article 21 of the Constitution. Right to
speedy trial and fair procedure has passed through several milestones on the path of constitutional
jurisprudence. In Maneka Gandhi [(1978) 1 SCC 248] this Court held that the several fundamental
rights guaranteed by Part III required to be read as components of one integral whole and not as
separate channels. The reasonableness of law and procedure, to withstand the test of Articles 21, 19
and 14, must be right and just and fair and not arbitrary, fanciful or oppressive, meaning thereby
that speedy trial must be reasonably expeditious trial as an integral and essential part of the
fundamental right of life and liberty under Article 21. Several cases marking the trend and
development of law applying Maneka Gandhi [(1978) 1 SCC 248] and Hussainara Khatoon
(I) [(1980) 1 SCC 81 : 1980 SCC (Cri) 23] principles to myriad situations came up for the
consideration of this Court by a Constitution Bench in Abdul Rehman Antulay v. R.S. Nayak [(1992)
1 SCC 225 : 1992 SCC (Cri) 93] (A.R. Antulay for short). The proponents of right to speedy trial
strongly urged before this Court for taking one step forward in the direction and prescribing
time-limits beyond which no criminal proceeding should be allowed to go on, advocating that unless
this was done, Maneka Gandhi [(1978) 1 SCC 248] and Hussainara Khatoon (I) [(1980) 1 SCC 81 :
1980 SCC (Cri) 23] exposition of Article 21 would remain a mere illusion and a platitude. Invoking
of the constitutional jurisdiction of this Court so as to judicially forge two termini and lay down
periods of limitation applicable like a mathematical formula, beyond which a trial or criminal
proceeding shall not proceed, was resisted by the opponents submitting that the right to speedy trial
was an amorphous one, something less than other fundamental rights guaranteed by the
Constitution. The submissions made by proponents included that the right to speedy trial flowing
from Article 21 to be meaningful, enforceable and effective ought to be accompanied by an outer
limit beyond which continuance of the proceedings will be violative of Article 21. It was submitted
that Section 468 of the Code of Criminal Procedure applied only to minor offences but the court
should extend the same principle to major offences as well. It was also urged that a period of 10
years calculated from the date of registration of crime should be placed as an outer limit wherein
shall be counted the time taken by the investigation."
58. P. Ramachandra Rao (supra) after considering the impact of the time lines to conclude trials laid
down in Common Cause (I) (II) (supra) and Raj Deo Sharma (I) (II) (supra) noticed the dissenting
judgment of M.B. Shah, J. at length which was rendered in Raj Deo Sharma-I (supra):
"17. M.B. Shah, J. in his dissenting judgment noted the most usual causes for delay in
delivery of criminal justice as discernible from several reported cases travelling up to
this Court and held that the remedy for the causes of delay in disposal of criminal
cases lies in effective steps being taken by the judiciary, the legislature and the State
Governments, all the three. The dangers behind constructing time-limit barriers by
judicial dictum beyond which a criminal trial or proceedings could not proceed, in
the opinion of M.B. Shah, J., are (i) it would affect the smooth functioning of the
society in accordance with law and finally the Constitution. The victims left without
any remedy would resort to taking revenge by unlawful means resulting in further
increase in the crimes and criminals. People at large in the society would also feel
unsafe and insecure and their confidence in the judicial system would be shaken. Law
would lose its deterrent effect on criminals; (ii) with the present strength of JudgesChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

and infrastructure available with criminal courts it would be almost impossible for
the available criminal courts to dispose of the cases within the prescribed time-limit;
(iii) prescribing such time-limits may run counter to the law specifically laid down by
the Constitution Bench in Antulay case [(1992) 1 SCC 225 : 1992 SCC (Cri) 93] . In the
fore-quoted thinking of M.B. Shah, J., we hear the echo of what the Constitution
Bench spoke in Kartar Singh v. State of Punjab [(1994) 3 SCC 569 : 1994 SCC (Cri)
899] vide SCC p. 707, para 351:
"351. No doubt, liberty of a citizen must be zealously safeguarded by the courts;
nonetheless the courts while dispensing justice in cases like the one under the TADA
Act, should keep in mind not only the liberty of the accused but also the interest of
the victim and their near and dear and above all the collective interest of the
community and the safety of the nation so that the public may not lose faith in the
system of judicial administration and indulge in private retribution."
59. The concept of "judicial legislation" was discussed in P. Ramachandra Rao (supra) in the context
of cases where the courts prescribe various periods of limitation by stating:
"22. Legislation is that source of law which consists in the declaration of legal rules by
a competent authority. When Judges by judicial decisions lay down a new principle of
general application of the nature specifically reserved for the legislature they may be
said to have legislated, and not merely declared the law. Salmond on Principles of
Jurisprudence (12th Edn.) goes on to say--
"we must distinguish law-making by legislators from law-making by the courts.
Legislators can lay down rules purely for the future and without reference to any
actual dispute; the courts, insofar as they create law, can do so only in application to
the cases before them and only insofar as is necessary for their solution. Judicial
law-making is incidental to the solving of legal disputes; legislative law-making is the
central function of the legislator." (page 115).
(emphasis supplied) It is not difficult to perceive the dividing line between
permissible legislation by judicial directives and enacting law -- the field exclusively
reserved for the legislature. We are concerned here to determine whether in
prescribing various periods of limitation, adverted to above, the Court transgressed
the limit of judicial legislation.
(emphasis supplied)
24. In a monograph "Judicial Activism and Constitutional Democracy in India",
commended by Professor Sir William Wade, Q.C. as a "small book devoted to a big
subject", the learned author, while recording appreciation of judicial activism, sounds
a note of caution--Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"it is plain that the judiciary is the least competent to function as a legislative or the
administrative agency. For one thing, courts lack the facilities to gather detailed data
or to make probing enquiries. Reliance on advocates who appear before them for data
is likely to give them partisan or inadequate information. On the other hand if courts
have to rely on their own knowledge or research it is bound to be selective and
subjective. Courts also have no means for effectively supervising and implementing
the aftermath of their orders, schemes and mandates. Moreover, since courts
mandate for isolated cases, their decrees make no allowance for the differing and
varying situations which administrators will encounter in applying the mandates to
other cases. Courts have also no method to reverse their orders if they are found
unworkable or requiring modification".
Highlighting the difficulties which the courts are likely to encounter if embarking in the fields of
legislation or administration, the learned author advises "the Supreme Court could have well left the
decision-making to the other branches of government after directing their attention to the problems
rather than itself entering the remedial field".
60. The seven Judges Constitution Bench of the Supreme Court in P. Ramachandra Rao (supra) was
conscious of the menace of delays in our legal system, but acknowledged the "greater problems"
caused by judicial directives creating bars of limitation as a solution to the said problem by holding
as follows:
"23. Bars of limitation, judicially engrafted, are, no doubt, meant to provide a
solution to the aforementioned problems. But a solution of this nature gives rise to
greater problems like scuttling a trial without adjudication, stultifying access to
justice and giving easy exit from the portals of justice. Such general remedial
measures cannot be said to be apt solutions. For two reasons we hold such bars of
limitation uncalled for and impermissible : first, because it tantamounts to
impermissible legislation -- an activity beyond the power which the Constitution
confers on the judiciary, and secondly, because such bars of limitation fly in the face
of law laid down by the Constitution Bench in A.R. Antulay case [(1992) 1 SCC 225 :
1992 SCC (Cri) 93] and, therefore, run counter to the doctrine of precedents and their
binding efficacy.
(emphasis supplied)
27. Prescribing periods of limitation at the end of which the trial court would be
obliged to terminate the proceedings and necessarily acquit or discharge the accused,
and further, making such directions applicable to all the cases in the present and for
the future amounts to legislation, which, in our opinion, cannot be done by judicial
directives and within the arena of the judicial law-making power available to
constitutional courts, howsoever liberally we may interpret Articles 32, 21, 141 and
142 of the Constitution. The dividing line is fine but perceptible. Courts can declare
the law, they can interpret the law, they can remove obvious lacunae and fill the gapsChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

but they cannot entrench upon in the field of legislation properly meant for the
legislature. Binding directions can be issued for enforcing the law and appropriate
directions may issue, including laying down of time-limits or chalking out a calendar
for proceedings to follow, to redeem the injustice done or for taking care of rights
violated, in a given case or set of cases, depending on facts brought to the notice of
the court. This is permissible for the judiciary to do. But it may not, like the
legislature, enact a provision akin to or on the lines of Chapter XXXVI of the Code of
Criminal Procedure, 1973."
61. Before issuing directions the Supreme Court in P. Ramachandra Rao (supra) reiterated the
principle of law of precedents which contemplates that a Bench of lesser strength is bound by the
view expressed by a Bench of larger strength and that the bar of limitation enacted in Common
Cause (I) & (II) (supra) and Raj Deo Sharma (I) & II (supra) cannot be sustained after noticing that
A.R. Antulay (supra) had declined the plea to lay down time limits beyond which a criminal
proceeding or trial could not proceed:
"28. The other reason why the bars of limitation enacted in Common Cause
(I) [(1996) 4 SCC 33 : 1996 SCC (Cri) 589] , Common Cause (II) [(1996) 6 SCC 775 :
1997 SCC (Cri) 42] and Raj Deo Sharma (I) [(1998) 7 SCC 507 : 1998 SCC (Cri) 1692]
and Raj Deo Sharma (II) [(1999) 7 SCC 604 : 1999 SCC (Cri) 1324] cannot be
sustained is that these decisions, though two-or three-Judge Bench decisions, run
counter to that extent to the dictum of the Constitution Bench in A.R. Antulay
case [(1992) 1 SCC 225 : 1992 SCC (Cri) 93] and therefore cannot be said to be good
law to the extent they are in breach of the doctrine of precedents. The well-settled
principle of precedents which has crystallised into a rule of law is that a Bench of
lesser strength is bound by the view expressed by a Bench of larger strength and
cannot take a view in departure or in conflict therefrom. We have in the earlier part
of this judgment extracted and reproduced passages from A.R. Antulay case [(1992) 1
SCC 225 : 1992 SCC (Cri) 93] . The Constitution Bench turned down the fervent plea
of proponents of right to speedy trial for laying down time-limits as bar beyond which
a criminal proceeding or trial shall not proceed and expressly ruled that it was
neither advisable nor practicable (and hence not judicially feasible) to fix any
time-limit for trial of offences. Having placed on record the exposition of law as to
right to speedy trial flowing from Article 21 of the Constitution, this Court held that it
was necessary to leave the rule as elastic and not to fix it in the frame of defined and
rigid rules. It must be left to the judicious discretion of the court seized of an
individual case to find out from the totality of circumstances of a given case if the
quantum of time consumed up to a given point of time amounted to violation of
Article 21, and if so, then to terminate the particular proceedings, and if not, then to
proceed ahead. The test is whether the proceedings or trial has remained pending for
such a length of time that the inordinate delay can legitimately be called oppressive
and unwarranted, as suggested in A.R. Antulay [(1992) 1 SCC 225 : 1992 SCC (Cri)
93] ."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
62. Finally the Supreme Court in P. Ramachandra Rao (supra) overruled the directions in Common
Cause Vs Union of India-I, Common Cause Vs Union of India-II, Raj Deo Sharma Vs State of Bihar-I
& Raj Deo Sharma Vs State of Bihar-II which prescribed the limitation for conclusion of trials and
categorically held that it was not judicially permissible to prescribe periods of limitation or an outer
time limit for conclusion of all criminal proceedings or trials. In conclusion after reaffirming A.R.
Antulay (supra), and P. Ramachandra Rao (supra) laid down the red lines in law as follows:
"29. ...."(1) The dictum in A.R. Antulay case [(1992) 1 SCC 225 : 1992 SCC (Cri) 93] is
correct and still holds the field.
(emphasis supplied) (2) The propositions emerging from Article 21 of the
Constitution and expounding the right to speedy trial laid down as guidelines in A.R.
Antulay case [(1992) 1 SCC 225 : 1992 SCC (Cri) 93] adequately take care of right to
speedy trial. We uphold and reaffirm the said propositions.
(3) The guidelines laid down in A.R. Antulay case [(1992) 1 SCC 225 : 1992 SCC (Cri)
93] are not exhaustive but only illustrative. They are not intended to operate as
hard-and-fast rules or to be applied like a straitjacket formula. Their applicability
would depend on the fact situation of each case. It is difficult to foresee all situations
and no generalization can be made.
(4) It is neither advisable, nor feasible, nor judicially permissible to draw or prescribe
an outer limit for conclusion of all criminal proceedings. The time-limits or bars of
limitation prescribed in the several directions made in Common Cause (I) [(1996) 4
SCC 33 : 1996 SCC (Cri) 589] , Raj Deo Sharma (I) [(1998) 7 SCC 507 : 1998 SCC
(Cri) 1692] and Raj Deo Sharma (II) [(1999) 7 SCC 604 : 1999 SCC (Cri) 1324] could
not have been so prescribed or drawn and are not good law. The criminal courts are
not obliged to terminate trial or criminal proceedings merely on account of lapse of
time, as prescribed by the directions made in Common Cause case (I) [(1996) 4 SCC
33 : 1996 SCC (Cri) 589] , Raj Deo Sharma case (I) [(1998) 7 SCC 507 : 1998 SCC
(Cri) 1692] and (II) [(1999) 7 SCC 604 : 1999 SCC (Cri) 1324] . At the most the
periods of time prescribed in those decisions can be taken by the courts seized of the
trial or proceedings to act as reminders when they may be persuaded to apply their
judicial mind to the facts and circumstances of the case before them and determine
by taking into consideration the several relevant factors as pointed out in A.R.
Antulay case [(1992) 1 SCC 225 : 1992 SCC (Cri) 93] and decide whether the trial or
proceedings have become so inordinately delayed as to be called oppressive and
unwarranted. Such time-limits cannot and will not by themselves be treated by any
court as a bar to further continuance of the trial or proceedings and as mandatorily
obliging the court to terminate the same and acquit or discharge the accused.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied) (5) The criminal courts should exercise their available powers, such as those
under Sections 309, 311 and 258 of the Code of Criminal Procedure to effectuate the right to speedy
trial. A watchful and diligent trial Judge can prove to be a better protector of such right than any
guidelines. In appropriate cases, jurisdiction of the High Court under Section 482 CrPC and Articles
226 and 227 of the Constitution can be invoked seeking appropriate relief or suitable directions.
(6) This is an appropriate occasion to remind the Union of India and the State Governments of their
constitutional obligation to strengthen the judiciary -- quantitatively and qualitatively -- by
providing requisite funds, manpower and infrastructure. We hope and trust that the Governments
shall act.
We answer the questions posed in the orders of reference dated 19-9-2000 and 26-4-2001 in the
abovesaid terms."
63. P. Ramachandra Rao (supra) after holding that the bars of limitation created by "judicial
legislation" ran counter to the doctrine of binding precedents, did not extend the said restrictions on
powers under Article 141, 142, 32 to other subject matters like PILs and social action litigations:
"33. Thirdly, we are deleting the bars of limitation on the twin grounds that it
amounts to judicial legislation, which is not permissible, and because they run
counter to the doctrine of binding precedents. The larger question of powers of this
Court to pass orders and issue directions in public interest or in social action
litigations, specially by reference to Articles 32, 141, 142 and 144 of the Constitution,
is not the subject-matter of the reference before us and this judgment should not be
read as an interpretation of those articles of the Constitution and laying down,
defining or limiting the scope of the powers exercisable thereunder by this Court."
(emphasis supplied)
64. At this stage it would be apposite to reflect on observations made in P. Ramachandra Rao
(supra) regarding the persisting problems of delays in judicial system. The Supreme Court declined
to take a simplistic view of the problem and instead embarked on a global consideration of the issue:
"19. A perception of the cause for delay at the trial and in conclusion of criminal
proceedings is necessary so as to appreciate whether setting up bars of limitation
entailing termination of trial or proceedings can be justified. The root cause for delay
in dispensation of justice in our country is poor judge-population ratio. The Law
Commission of India in its 120th Report on Manpower Planning in Judiciary (July
1987), based on its survey, regretted that in spite of Article 39-A being added as a
major directive principle in the Constitution by the Forty-second Amendment (1976),
obliging the State to secure such operation of legal system as promotes justice and to
ensure that opportunities for securing justice are not denied to any citizen, several
reorganisation proposals in the field of administration of justice in India have been
basically patchwork, ad hoc and unsystematic solutions to the problem. TheChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

judge-population ratio in India (based on the 1971 census) was only 10.5 Judges per
million population while such ratio was 41.6 in Australia, 50.9 in England, 75.2 in
Canada and 107 in United States. The Law Commission suggested that India required
107 judges per million of the Indian population; however, to begin with, the judge
strength needed to be raised to fivefold i.e. 50 judges per million population in a
period of five years but in any case, not going beyond ten years. Touch of sad sarcasm
is difficult to hide when the Law Commission observed (in its 120th Report, ibid.)
that adequate reorganisation of the Indian judiciary is at the one and at the same
time everybody's concern and, therefore, nobody's concern. There are other factors
contributing to the delay at the trial. In A.R. Antulay case [(1992) 1 SCC 225 : 1992
SCC (Cri) 93] vide para 83, the Constitution Bench has noted that in spite of having
proposed to go on with the trial of a case, five days a week and week after week, it
may not be possible to conclude the trial for reasons viz. (1) non-availability of the
counsel, (2) non-availability of the accused, (3) interlocutory proceedings, and (4)
other systemic delays. In addition, the Court noted that in certain cases there may be
a large number of witnesses and in some offences, by their very nature, the evidence
may be lengthy. In Kartar Singh v. State of Punjab [(1994) 3 SCC 569 : 1994 SCC (Cri)
899] another Constitution Bench opined that the delay is dependent on the
circumstances of each case because reasons for delay will vary, such as (i) delay in
investigation on account of the widespread ramifications of the crime and its
designed network either nationally or internationally, (ii) the deliberate absence of
witness or witnesses, (iii) crowded dockets on the file of the court etc. In Raj Deo
Sharma (II) [(1999) 7 SCC 604 : 1999 SCC (Cri) 1324] in the dissenting opinion of
M.B. Shah, J., the reasons for delay have been summarized as, (1) dilatory
proceedings; (2) absence of effective steps towards radical simplification and
streamlining of criminal procedure; (3) multitier appeals/revision applications and
diversion to disposal of interlocutory matters; (4) heavy dockets, mounting arrears,
delayed service of process; and (5) judiciary, starved by executive by neglect of basic
necessities and amenities, enabling smooth functioning.
20. Several cases coming to our notice while hearing appeals, petitions and
miscellaneous petitions (such as for bail and quashing of proceedings) reveal, apart
from inadequate judge strength, other factors contributing to the delay at the trial.
Generally speaking, these are : (i) absence of, or delay in appointment of, Public
Prosecutors proportionate with the number of courts/cases; (ii) absence of or belated
service of summons and warrants on the accused/witnesses; (iii) non-production of
undertrial prisoners in the court; (iv) presiding Judges proceeding on leave, though
the cases are fixed for trial; (v) strikes by members of the Bar; and (vi) counsel
engaged by the accused suddenly declining to appear or seeking an adjournment for
personal reasons or personal inconvenience. It is common knowledge that
appointments of Public Prosecutors are politicized. By convention, Government
Advocates and Public Prosecutors were appointed by the executive on the
recommendation of or in consultation with the head of the judicial administration at
the relevant level but gradually the executive has started bypassing the merit-basedChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

recommendations of, or process of consultation with, District and Sessions Judges.
For non-service of summons/orders and non-production of undertrial prisoners, the
usual reasons assigned are shortage of police personnel and police people being busy
in VIP duties or law and order duties. These can hardly be valid reasons for not
making the requisite police personnel available for assisting the courts in expediting
the trial. The members of the Bar shall also have to realize and remind themselves of
their professional obligation -- legal and ethical, that having accepted a brief for an
accused, they have no justification to decline or avoid appearing at the trial when the
case is taken up for hearing by the court. All these factors demonstrate that the goal
of speedy justice can be achieved by a combined and result-oriented collective
thinking and action on the part of the legislature, the judiciary, the executive and
representative bodies of members of the Bar."
65. The judgments of the Supreme Court in A. R. Antulay (supra) and P. Ramachandra Rao (supra)
explicitly propound the law that judicial directions or "judicial legislation" by the Supreme Court
cannot prescribe an outer time limit for conclusion of "all criminal proceedings" or 'trials' which
clearly includes criminal proceedings and interim applications pending therein before the High
Courts under various jurisdictions (i.e. Article 226, Article 227, Section 482 Cr.P.C., Section 397
Cr.P.C.).
66. The "encroaching nature20" of plenary powers was checked by the Supreme Court when it
forbade exercise of powers under Article 142 to create judicial legislation in the said fields.
67. The directions made by the two Judge Bench of Supreme Court in Imtiyaz Ahmad Vs State of
U.P.21 also related to delays in judicial proceedings. The Supreme Court in Imtiyaz Ahmad (supra)
issued directions to Registrars General/Registrars of all the High Courts in the country to furnish
data as regards pending cases in which criminal proceedings had been stayed at various stages.
Upon consideration of the aforesaid data the Supreme Court in Imtiyaz Ahmad (supra) examined
the remit of the Law Commission to suggest solutions to tackle problems of arrears in courts. The
following directions were given to the High Court in Imtiyaz Ahmad (supra) for maintenance of the
rule of law and better administration of justice:
"55. Certain directions are given to the High Courts for better maintenance of the rule
of law and better administration of justice:
While analysing the data in aggregated form, this Court cannot overlook the most
important factor in the administration of justice. The authority of the High Court to
order stay of investigation pursuant to lodging of FIR, or trial in deserving cases is
unquestionable. But this Court is of the view that the exercise of this authority carries
with it the responsibility to expeditiously dispose of the case. The power to grant stay
of investigation and trial is a very extraordinary power given to the High Courts and
the same power is to be exercised sparingly only to prevent an abuse of the process
and to promote the ends of justice. It is therefore clear that:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(i) Such an extraordinary power has to be exercised with due caution and
circumspection.
(ii) Once such a power is exercised, the High Court should not lose sight of the case
where it has exercised its extraordinary power of staying investigation and trial.
(iii) The High Court should make it a point of finally disposing of such proceedings as
early as possible but preferably within six months from the date the stay order is
issued."
68. Imtiyaz Ahmad (supra) while iterating that the constitutional scheme did not give power of
superintendence to the Supreme Court over the High Court as the High Court has over District
Courts stated:
"56. It is true that this Court has no power of superintendence over the High Court as
the High Court has over District Courts under Article 227 of the Constitution. Like
this Court, the High Court is equally a superior court of record with plenary
jurisdiction. Under our Constitution the High Court is not a court subordinate to this
Court. This Court, however, enjoys appellate powers over the High Court as also
some other incidental powers. But as the last court and in exercise of this Court's
power to do complete justice which includes within it the power to improve the
administration of justice in public interest, this Court gives the aforesaid guidelines
for sustaining common man's faith in the rule of law and the justice delivery system,
both being inextricably linked."
69. A detailed analysis of submissions of the learned counsels on the impact of the directions made
in Asian Resurfacing (supra) which run counters to A.R. Antulay (supra) and P. Ramachandra Rao
(supra) shall be made in the subsequent part of the judgement in light of the interpretations of
Articles 141 and 142 of the Constitution of India.
IV. Interim Orders : Grant, Alteration & Vacation
70. Interim orders are granted by courts in aid of final relief. Interim orders are passed by Courts to
protect fundamental liberties, secure the nature of the disputed property, to prevent the situation
from being altered irremediably, and like ends. The importance of grant, alteration or vacation of
interim orders is an important part of legal proceedings is self evident and needs little elaboration.
Interim orders are granted altered and vacated in exercise of inherent powers vested in the Court or
powers endowed by statutes. Interim orders have a direct bearing on the substantive rights of a
party and efficacy of the legal remedy.
71. The Supreme Court in Manohar Lal Chopra v. Rai Bahadur Rao Raja Seth Hiralal22 affirmed the
exercise of inherent jurisdiction of High Courts constituted under Charters to issue an injunction by
holding:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"42. It is true that the High Courts constituted under Charters and exercising
ordinary original jurisdiction do exercise inherent jurisdiction to issue an injunction
to restrain parties in a suit before them from proceeding with a suit in another court,
but that is because the Chartered High Courts claim to have inherited this
jurisdiction from the Supreme Courts of which they were successors. This jurisdiction
would be saved by Section 9 of the Charter Act (24 and 25 Vict. c. 104) of 1861 and in
the Code of Civil Procedure, 1908 it is so expressly provided by Section 4. But the
power of the civil courts other than the Chartered High Courts must be found within
Section 94 and Order 39 Rules 1 and 2 of the Civil Procedure Code."
72. Interim orders are sourced to inherent powers vested in superior courts. The Supreme Court in
Girish Kumar Suneja Vs CBI23 after referencing cases in point held that the High Court has an
inherent power to grant stay of proceedings:
"55. The penultimate submission of the learned counsel for the appellants was that
the High Court has an inherent power to stay proceedings in a criminal case. Reliance
was placed on ITO v. M.K. Mohammed Kunhi [ITO v. M.K. Mohammed Kunhi, AIR
1969 SC 430] wherein it was categorically held by this Court that the Income Tax
Appellate Tribunal must be held to have the power to grant a stay as incidental or
ancillary to its appellate jurisdiction. Reference was also made to Satish
Mehra v. State (NCT of Delhi) [Satish Mehra v. State (NCT of Delhi), (2012) 13 SCC
614 : (2012) 4 SCC (Cri) 354] . There is no doubt that a High Court has an inherent
power to grant a stay of proceedings and it is not necessary to labour any further on
this issue."
(emphasis supplied)
73. The Supreme Court in Income Tax Officer, Cannanore v. M.K. Mohammed Kunhi24 opined that
when a legislature vests jurisdiction upon the tribunal to decide the case, it impliedly grants the
power of stay:
"8. Section 255(5) of the Act does empower the Appellate Tribunal to regulate its own
procedure, but it is very doubtful if the power of stay can be spelt out from that
provision. In our opinion the Appellate Tribunal must be held to have the power to
grant stay as incidental or ancillary to its appellate jurisdiction. This is particularly so
when Section 220(6) deals expressly with a situation when an appeal is pending
before the Appellate Assistant Commissioner, but the Act is silent in that behalf when
an appeal is pending before the Appellate Tribunal. It could well be said that when
Section 254 confers appellate jurisdiction, it impliedly grants the power of doing all
such acts, or employing such means, as are essentially necessary to its execution and
that the statutory power carries with it the duty in proper cases to make such orders
for staying proceedings as will prevent the appeal if successful from being rendered
nugatory.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
74. In In re, Powers, Privileges and Immunities of State Legislatures25 the Supreme Court
propounded that if the Court under Article 226 of the Constitution of India had jurisdiction to deal
with matter, it is a given that the Court also possessed the power to grant interim relief:
"137. In the course of his arguments, Mr Seervai laid considerable emphasis on the
fact that in habeas corpus proceedings, the High Court had no jurisdiction to grant
interim bail. It may be conceded that in England it appears to be recognised that in
regard to habeas corpus proceedings commenced against orders of commitment
passed by the House of Commons on the ground of contempt, bail is not granted by
courts. As a matter of course, during the last century and more in such habeas corpus
proceedings returns are made according to law by the House of Commons, but "the
general rule is that the parties who stand committed for contempt cannot be
admitted to bail" But it is difficult to accept the argument that in India the position is
exactly the same in this matter. If Article 226 confers jurisdiction on the Court to deal
with the validity of the order of commitment ever though the commitment has been
ordered by the House, how can it be said that the Court has no jurisdiction to make
an interim order in such proceedings? As has been held by this Court in State of
Orissa v. Madan Gopal Rungta [1951 SCC 1024 : 1952 SCR 28] , an interim relief can
be granted only in aid of, and as ancillary to, the main relief which may be available
to the party on final determination of his rights in a suit or proceeding. Indeed, as
Maxwell has observed, when an Act confers a jurisdiction, it impliedly also grants the
power of doing all such acts, or employing such means, as are essentially necessary to
its execution [Maxwell on Interpretation of Statutes, 11th Edn., p. 350] . That being
so, the argument based on the relevant provisions of the Criminal Procedure Code
and the decision of the Privy Council in Lala Jairam Das v. King Emperor [72 IA 120]
is of no assistance."
(emphasis supplied)
75. While examining the scope of grant of interim orders and the power to alter or vacate the same,
the Supreme Court in Empire Industries Ltd. v. Union of India26 expounded thus:
"59. Good deal of arguments were canvassed before us for variation or vacation of the
interim orders passed in these cases. Different courts sometimes pass different
interim orders as the courts think fit. It is a matter of common knowledge that the
interim orders passed by particular courts on certain considerations are not
precedents for other cases which may be on similar facts. An argument is being built
up nowadays that once an interim order has been passed by this Court on certain
factors specially in fiscal matters, in subsequent matters on more or less similar facts,
there should not be a different order passed nor should there be any variation with
that kind of interim order passed. It is submitted at the Bar that such variance creates
discrimination. This is an unfortunate approach. Every Bench hearing a matter onChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the facts and circumstances of each case should have the right to grant interim orders
on such terms as it considers fit and proper and if it had granted interim order at one
stage, it should have the right to vary or alter such interim orders. We venture to
suggest, however, that a consensus should be developed in the matter of interim
orders.
(emphasis supplied)
76. At this juncture we may also refer to Article 226(3) of the Constitution of India:
"Article 226(3) in The Constitution Of India 1949 (3) Where any party against whom
an interim order, whether by way of injunction or stay or in any other manner, is
made on, or in any proceedings relating to, a petition under clause ( 1 ), without
(a) furnishing to such party copies of such petition and all documents in support of
the plea for such interim order; and
(b)giving such party an opportunity of being heard, makes an application to the High
Court for the vacation of such order and furnishes a copy of such application to the
party in whose favour such order has been made or the counsel of such party, the
High Court shall dispose of the application within a period of two weeks from the
date on which it is received or from the date on which the copy of such application is
so furnished, whichever is later, or where the High Court is closed on the last day of
that period, before the expiry of the next day afterwards on which the High Court is
open; and if the application is not so disposed of, the interim order shall, on the
expiry of that period, or, as the case may be, the expiry of the aid next day, stand
vacated."
77. The constitutional provision was interpreted by various High Courts. There was a cleavage of
judicial opinions on this issue. One line of authorities in point held that the provision was
mandatory and the interim order was deemed to be vacated upon expiry of the period of 14 days
after the application for stay vacation was made and if the same was not decided. This line of
opinions included a Division Bench judgment of this Court in R.C. Chaudhary Vs Vice Chancellor,
Dr. Bhim Rao Ambedkar University, Agra27.
78. The other view was best depicted in the judgment rendered by a learned Single Judge of the
Madras High Court in Dr. T. Gnanasambanthan vs. The Board of Governors28. Upon consideration
of the divergent judicial authorities V. Ramasubramanian, J. (as His Lordship then was) held that
automatic vacation of stay order would cause prejudice to a party which was the beneficiary of the
interim order and whose conduct could not be faulted. More often than not the stay orders were
getting vacated on account of failure of the Courts to take up and decide the stay vacation
application on merits. On this footing Article 226(3) of the Constitution of India insofar as it
envisaged automatic vacation of the stay order was held to be directory:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"64.Before considering the impact of those decisions, it is necessary to take note of
the fact that Clause (3) was inserted originally by The Constitution (42nd
Amendment) Act, 1976. Later, it was substituted by the present Clause (3) by The
Constitution (44th Amendment) Act, 1978. A careful look at Clause (3) would show
that it comprises of two parts namely (1) a mandate to the High Court to dispose of
the application for vacation of an ex parte interim order, within a period of two weeks
from the date on which an application for vacating the interim order is received or
furnished; and (2) a dicta that if the application is not so disposed of, the interim
order would stand vacated on the expiry of that period. All the High Courts, which
have taken the views indicated above, have approached the question of interpretation
of Article 226(3)(i) from the point of view of rules relating to statutory interpretation;
and (ii) from the angle as to whether it is mandatory or directory.
65. But unfortunately, none of the High Courts, whose decisions are relied upon by
the respondents, has considered the question from the pedestal of the most
fundamental principle of law namely that no one shall be prejudiced by an act of
court (actus curiae neminem gravabit). An act can either be an act of omission or be
an act of commission. The non listing of an application for vacation of an interim
order, if not due to the fault of any of the parties, but due to the fault of the Registry
of the Court, would fall under the category of "act of omission". No law can be so
absurd as to say that if the Court is at fault, the parties shall suffer. I do not think that
any case law is required to support the proposition that an act of court shall not
prejudice a party.
(emphasis supplied)
66. The question as to whether Clause (3) is directory or mandatory should have been
approached by the Courts from the perspective as to whether a party can be
prejudiced by an act of Court or not. All the Courts including the Division Bench of
the Allahabad High Court came to the conclusion that Clause (3) is mandatory, only
on the premise that the consequences of non compliance are also prescribed in the
clause itself. But, such a view tantamounts to missing the tree for the wood.
67. In Raza Buland Sugar Co. Ltd v. The Municipal Board AIR 1965 SC 895, a
Constitution Bench of the Supreme Court held that the question whether a particular
provision is mandatory or directory, cannot be resolved by laying down any general
rule and that it would depend upon the facts of each case. The Court has to consider
the purpose for which the provision had been made, its nature, the intention of the
legislature in making the provision, the serious general inconvenience or injustice to
persons resulting therefrom whether the provision is read one way or the other, the
relation of the particular provision to other provisions dealing with the same subject
as well as other considerations which may arise on the fact of a particular case,
including the language of the provision. The said decision of the Constitution Bench
was followed by the Supreme Court in Salem Advocate Bar v. Union of India 2005 6Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

SCC 344. While doing so, the Supreme Court pointed out therein that our laws on
procedure are grounded on a principle of natural justice which requires that men
should not be condemned unheard, that decision should not be reached behind their
backs, that proceedings that affect their lives and properties should not continue in
their absence and that they should not be precluded from participating in them.
Therefore, we have to interpret Article 226(3), consistent with the interpretation
given by the Constitution Bench. If the interpretation given to clause (3) of Article
226 would result in putting one of the parties to grave injustice, without any
opportunity of hearing, the provision cannot be taken to be mandatory but can be
taken only as directory.
(emphasis supplied)
68. In Sharif-Ud-Din v. Abdul Gani Lone (1980) 1 SCC 403 : AIR 1980 SC 303, the
Supreme Court indicated that the question whether a provision of law is mandatory
or not depends upon its language, the context in which it is enacted and its object.
The Court made an important observation, which will resolve the problem for us and
hence it is extracted as follows:--
"In order to find out the true character of the legislation, the Court has to ascertain
the object which the provision of law in question is to subserve and its design and the
context in which it is enacted. If the object of a law is to be defeated by
non-compliance with it, it has to be regarded as mandatory. But when a provision of
law relates to the performance of any public duty and the invalidation of any act done
in disregard of that provision causes serious prejudice to those for whose benefit it is
enacted and at the same time who have no control over the performance of the duty,
such provision should be treated as a directory one. Where however, a provision of
law prescribes that a certain act has to be done in a particular manner by a person in
order to acquire a right and it is coupled with another provision which confers an
immunity on another, when such act is not don in that manner, the former has to be
regarded as a mandatory one".
(emphasis supplied)
69. Therefore, it is clear that if the condition imposed by the provision of law to do a certain thing
within a time frame is upon an institution and the consequences of that institution not complying
with the condition is to fall upon someone else who have no control over the institution which is to
perform the duty, then the provision of law cannot be construed as mandatory, but only directory.
(emphasis supplied)
70. It is true that if a statutory provision contains a prescription and also stipulates the
consequences of non compliance with the condition, it would normally be taken to be mandatory.
But, the direction as well as the consequences of non compliance with the direction should both fallChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

upon the same person, if such an interpretation is to be given.
(emphasis supplied)
71. In other words, the statutory provision should contain a direction to a party to the proceeding. It
should also prescribe the consequences that would fall upon the party, on whom, the obligation to
comply with the condition is imposed by the provision. Take for instance, the provisions of Order
XXXIX Rules 3 and 3-A. If a person, in whose favour an interim order of injunction is granted ex
parte, fails to comply with the obligation cast under Sub-Rule (a) of Rule 3 of Order XXXIX, the
interim injunction granted can be vacated on the ground of failure to comply with the obligation.
But, where a direction to do something is against one party, the consequences of that party not
complying with the direction, cannot be made to fall upon another party. Article 226(3) imposes an
obligation upon the High Courts to dispose of the application for vacating the stay within two weeks.
The failure of the High Court to comply with this Constitutional mandate, cannot result in an
adverse consequence upon the party. If an obligation is cast upon one party and the consequences of
failure to fulfill the obligation are to be suffered by another party, the provision prescribing such an
obligation and consequence, cannot be treated as mandatory, but can be treated as directory.
(emphasis supplied)
72. As a matter of fact, the Division Bench of the Allahabad High Court appears to have realised this
problem in the decision in R.C. Chaudhary. That is why in paragraph 22 of the report, the Division
Bench of the Allahabad High Court held that if a vacate stay application is filed in a leisurely
manner, such a party will not be entitled to avail the benefit of Clause (3) of Article 226.
73. In other words, the Division Bench of the Allahabad High Court has created an exception to the
rule enunciated under Article 226(3). But, it must be pointed out that if a provision is mandatory, it
is not permissible for a Court to carve out an exception not inbuilt in the statutory provision itself.
Interpreting a statutory provision to be mandatory and at the same time, carving out an exception
not found in the language of the provision, go contrary to each other. Therefore, the proper
interpretation to be given to Clause (3) of Article 226 is to say that it is directory and not mandatory,
so that no party is allowed to take advantage of the failure of the Court to dispose of an application
for vacation of stay within 14 days.
74. As a matter of fact, the Division Bench of the Allahabad High Court took note of only one serious
consequence namely that of a party approaching the Court with a vacate stay application in a
leisurely manner and the Division Bench took such a situation out of the purview of Article 226(3).
But, any number of such situations, which will prove to be disastrous, can be thought of. Take for
instance a case, where an application for vacating the stay is taken up for hearing within two weeks
of its presentation and the Court reserves orders. If orders were not pronounced on or before the
expiry of the 14th day from the date of filing of the vacate stay application, could it be said that the
party, who obtained an interim stay, should still suffer, despite ensuring that the application is
heard within two weeks. It is not within the control of any party to have his application or the
opposite party's application listed for hearing. Even if a party succeeds in getting the applicationChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

listed within two weeks, it is not in his control to ensure that the application is heard before the
expiry of two weeks. Even if a party succeeds in making the Court hear the application for vacation
of the interim order within two weeks, it is not in his control (especially these days) to ensure that it
is disposed of within two weeks from the date of filing of the vacate stay application.
75. Therefore, an interpretation that would put a party, who is not at fault, to disastrous
consequences, for the failure of an institution or for the happening of something that is beyond his
control, is wholly unjustified. If a statutory provision imposes an obligation upon one party and
makes the opposite party suffer for the consequences of non fulfillment of the obligation cast
therein, such a provision cannot be said to be mandatory. Unfortunately, none of the High Courts,
whose decisions are relied upon by the respondents, has taken note of this basic difference between
the person, on whom, an obligation is cast and the person, on whom, the consequences are made to
fall under Article 226(3). Hence, with great respect, I am unable to agree with the views expressed
by the other High Courts."
79. We find the reasoning assigned in Dr. T. Gnanasambanthan (supra) to be impeccable and the
judgment expounds the correct law. We are in respectful agreement with the law laid down in Dr. T.
Gnanasambanthan (supra), in preference to the Division Bench judgment of this Court in R.C.
Chaudhary (supra).
80. Similarly, Section 254(2-A) of the Income Tax Act, 1961 restricted the life of an interim order to
a period fixed in the provision and contemplated automatic vacation of the stay order after the lapse
of said period in the event the appeal was not disposed of. The provision is extracted hereunder:
"254. Orders of Appellate Tribunal.--(1)-(2) * * * (2-A) In every appeal, the Appellate
Tribunal, where it is possible, may hear and decide such appeal within a period of
four years from the end of the financial year in which such appeal is filed under
sub-section (1) or sub-section (2) of Section 253:
Provided that the Appellate Tribunal may, after considering the merits of the
application made by the assessee, pass an order of stay in any proceedings relating to
an appeal filed under sub-section (1) of Section 253, for a period not exceeding one
hundred and eighty days from the date of such order and the Appellate Tribunal shall
dispose of the appeal within the said period of stay specified in that order:
Provided further that where such appeal is not so disposed of within the said period
of stay as specified in the order of stay, the Appellate Tribunal may, on an application
made in this behalf by the assessee and on being satisfied that the delay in disposing
of the appeal is not attributable to the assessee, extend the period of stay, or pass an
order of stay for a further period or periods as it thinks fit; so, however, that the
aggregate of the period originally allowed and the period or periods so extended or
allowed shall not, in any case, exceed three hundred and sixty-five days and the
Appellate Tribunal shall dispose of the appeal within the period or periods of stay so
extended or allowed:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Provided also that if such appeal is not so disposed of within the period allowed
under the first proviso or the period or periods extended or allowed under the second
proviso, the order of stay shall stand vacated after the expiry of such period or
periods."
(emphasis supplied)
81. The said provision was assailed before the Bombay High Court in Narang Overseas (P) Ltd. Vs
Income Tax Appellate Tribunal.29 wherein the Bombay High Court noticed the importance of the
vested right of an appeal and also stated the implication of Article 14 on automatic vacation of stay
orders for no fault of the assessee:
"16. Did the section as it stood before the Finance Act of 2007, and after the Finance
Act of 2007, exclude the power of the Tribunal to grant interim relief after the period
provided in the proviso. Was it the intendment of Parliament that the Tribunal even
in a case where the assessee was not at fault should be denuded of its incidental
power to continue the interim relief granted and if so what mischief was it seeking to
avoid. The mischief if and at all was the long delay in disposing of proceedings where
interim relief had been obtained by the assessee. The second proviso as it earlier
stood, in a case when in an appeal interim relief was granted, if the appeal was not
disposed of within 180 days provided that the stay shall stand vacated. The proviso as
it stood could really have not have stood the test of non-arbitrariness as it would
result in an appeal being defeated even if the assessee was not at fault, as in the
meantime the Revenue could proceed against the assets of the assessee. The proviso
as introduced by the Finance Act, 2007 was to an extent to avoid the mischief of it
being rendered unconstitutional. Once an appeal is provided, it cannot be rendered
nugatory in cases were the assessee was not at fault.
17. The amendment of 2007 conferred the power to extend the period of interim
relief to 360 days. Parliament clearly intended that such appeals should be disposed
of at the earliest. If that be the object the mischief which was sought to be avoided
was the non-disposal of the appeal during the period the interim relief was in
operation. By extending the period Parliament took note of laws delay. The object
was not to defeat the vested right of appeal in an assessee, whose appeal could not be
disposed of not on account of any omission or failure on his part, but either the
failure of the Tribunal or acts of Revenue resulting in non-disposal of the appeal
within the extended period as provided.
18. Can it then be said that the intention of Parliament by restricting the period of
stay or interim relief up to 360 days had the effect of excluding by necessary
intendment the power of the Tribunal to continue the interim relief. Would not
reading the power not to continue the power to continue interim relief in cases not
attributable to the acts of the assessee result in holding that such a provision would
be unreasonable. Could Parliament have intended to confer the remedy of an appealChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

by denying the incidental power of the Tribunal to do justice. In our opinion for
reasons already discussed it would not be possible to so read it.
19. It would not be possible on the one hand to hold that there is a vested right of an
appeal and on the other hand to hold that there is no power to continue the grant of
interim relief for no fault of the assessee by divesting the incidental power of the
Tribunal to continue the interim relief. Such a reading would result in such an
exercise being rendered unreasonable and violative of Article 14 of the Constitution.
The courts must, therefore, construe and/or give a construction consistent with the
constitutional mandate and principle to avoid a provision being rendered
unconstitutional."
(emphasis supplied)
82. Finally the Bombay High Court in Narang Overseas (supra) held:
"22. We are of the respectful view that the law as enunciated in Kumar Cotton Mills
(P) Ltd. [Commr. of Customs v. Kumar Cotton Mills (P) Ltd., (2005) 13 SCC 296]
should also apply to the construction of the third proviso as introduced in Section
254(2-A) by the Finance Act, 2007. The power to grant stay or interim relief being
inherent or incidental is not defeated by the provisos to the sub-section. The third
proviso has to be read as a limitation on the power of the Tribunal to continue
interim relief in case where the hearing of the appeal has been delayed for acts
attributable to the assessee. It cannot mean that a construction be given that the
power to grant interim relief is denuded even if the acts attributable are not of the
assessee but of the Revenue or of the Tribunal itself. The power of the Tribunal,
therefore, to continue interim relief is not overridden by the language of the third
proviso to Section 254(2-A). This would be in consonance with the view taken
in Kumar Cotton Mills (P) Ltd. [Commr. of Customs v. Kumar Cotton Mills (P) Ltd.,
(2005) 13 SCC 296] There would be power in the Tribunal to extend the period of
stay on good cause being shown and on the Tribunal being satisfied that the matter
could not be heard and disposed of for reasons not attributable to the assessee."
83. Close on the heels of the judgment of the Bombay High Court Section 254(2-A) of the Income
Tax Act, 1961 came to be amended and read as follows:
"254. Orders of Appellate Tribunal.--(1)-(2) * * * (2-A) In every appeal, the Appellate
Tribunal, where it is possible, may hear and decide such appeal within a period of
four years from the end of the financial year in which such appeal is filed under
sub-section (1) or sub-section (2) of Section 253:
Provided that the Appellate Tribunal may, after considering the merits of the
application made by the assessee, pass an order of stay in any proceedings relating to
an appeal filed under sub-section (1) of Section 253, for a period not exceeding oneChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

hundred and eighty days from the date of such order and the Appellate Tribunal shall
dispose of the appeal within the said period of stay specified in that order:
Provided further that where such appeal is not so disposed of within the said period
of stay as specified in the order of stay, the Appellate Tribunal may, on an application
made in this behalf by the assessee and on being satisfied that the delay in disposing
of the appeal is not attributable to the assessee, extend the period of stay, or pass an
order of stay for a further period or periods as it thinks fit; so, however, that the
aggregate of the period originally allowed and the period or periods so extended or
allowed shall not, in any case, exceed three hundred and sixty-five days and the
Appellate Tribunal shall dispose of the appeal within the period or periods of stay so
extended or allowed:
Provided also that if such appeal is not so disposed of within the period allowed
under the first proviso or the period or periods extended or allowed under the second
proviso, which shall not, in any case, exceed three hundred and sixty-five days, the
order of stay shall stand vacated after the expiry of such period or periods, even if the
delay in disposing of the appeal is not attributable to the assessee."
(emphasis supplied)
84. After its amendment the provision was assailed before Gujarat High Court in DCIT Vs Vodafone
Essar (Gujarat) Ltd. and another30. The Gujarat High Court upon interpretation of the provision
protected the powers of the tribunal to grant extension of stay beyond the period of 365 days from
the date of initial stay by holding as under:
"26. Applying the decision of the Division Bench of this Court in Small Industries
Development Bank of India [Commr. v. Small Industries Development Bank of India,
2014 SCC OnLine Guj 6563] to the facts of the case on hand, more particularly while
considering the powers of the Tribunal under Section 254(2-A) of the Act, it is
observed and held that by Section 254(2-A) of the Act, it cannot be inferred a
legislative intent to curtail/withdraw the powers of the Appellate Tribunal to extend
stay of demand beyond the period of 365 days. However, the aforesaid extension of
stay beyond the period of total 365 days from the date of grant of initial stay would
always be subject to the subjective satisfaction by the learned Appellate Tribunal and
on an application made by the appellant assessee to extend stay and on being
satisfied that the delay in disposing of the appeal within a period of 365 days from the
date of grant of initial stay is not attributable to the appellant assessee. For that
purpose, on expiry of every 180 days, the appellant assessee is required to make an
application to extend stay granted earlier and satisfy the learned Appellate Tribunal
that the delay in not disposing of the appeal is not attributable to him/it and the
learned Appellate Tribunal is required to review the matter after every 180 days and
while disposing of such application of extension of stay, the learned Appellate
Tribunal is required to pass a speaking order after having satisfied that the appellantChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

assessee has not indulged into any delay tactics and that the delay in disposing of the
appeal within stipulated time is not attributable to the appellant assessee. However,
at the same time, it may not be construed that widest powers are given to the
Appellate Tribunal to extend the stay indefinitely and that the Appellate Tribunal is
not required to dispose of the appeals at the earliest. The object and purpose of
Section 35-C(2-A) of the Act particularly one of the object and purpose is to see that
in a case where stay has been granted by the learned Appellate Tribunal, the learned
Appellate Tribunal is required to dispose of the appeal within total period of 365
days, as ultimately the Revenue has not to suffer and all efforts should be made by
the learned Appellate Tribunal to dispose of such appeals in which stay has been
granted as far as possible within total period of 365 days from the date of grant of
initial stay and the Appellate Tribunal shall grant priority to such appeals over
appeals in which no stay is granted. For that even the Appellate Tribunal and/or
Registrar of the Appellate Tribunal is required to maintain separate register of the
appeals in which stay has been granted fully and/or partially and the appeals in
which no stay has been granted."
85. The Delhi High Court in Pepsi Foods (P) Ltd. v. CIT31 ultimately struck down the part of Section
254(2-A) of the Income Tax Act, 1961 (as amended by the Finance Act of 2008) on the footing that it
offended Article 14 of the Constitution of India. After referencing the history of the provisions and
relying on the judgment rendered in Mardia Chemicals Ltd. Vs Union of India32 and the judgment
of a Division Bench of the Punjab and Haryana High Court in PML Industries Ltd. Vs CCE33 the
Court propounded the law as under :
"23. Keeping in mind the principles set out by the Supreme Court in Subramanian
Swamy [Subramanian Swamy v. CBI, (2014) 8 SCC 682 : (2014) 6 SCC (Cri) 42 :
(2014) 3 SCC (L&S) 36] , we need to examine whether the present challenge to the
validity of the third proviso to Section 254(2-A) can be sustained. This is not a case of
excessive delegation of powers and, therefore, we need not bother about the second
dimension of Article 14 in its application to legislation. We are here concerned with
the question of discrimination, based on an impermissible or invalid classification. It
is abundantly clear that the power granted to the Tribunal to hear and entertain an
appeal and to pass orders would include the ancillary power of the Tribunal to grant a
stay. Of course, the exercise of that power can be subjected to certain conditions. In
the present case, we find that there are several conditions which have been
stipulated. First of all, as per the first proviso to Section 254(2-A), a stay order could
be passed for a period not exceeding 180 days and the Tribunal should dispose of the
appeal within that period. The second proviso stipulates that in case the appeal is not
disposed of within the period of 180 days, if the delay in disposing of the appeal is not
attributable to the assessee, the Tribunal has the power to extend the stay for a period
not exceeding 365 days in aggregate. Once again, the Tribunal is directed to dispose
of the appeal within the said period of stay. The third proviso, as it stands today,
stipulates that if the appeal is not disposed of within the period of 365 days, then the
order of stay shall stand vacated, even if the delay in disposing of the appeal is notChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

attributable to the assessee. While it could be argued that the condition that the stay
order could be extended beyond a period of 180 days only if the delay in disposing of
the appeal was not attributable to the assessee was a reasonable condition on the
power of the Tribunal to grant an order of stay, it can, by no stretch of imagination,
be argued that where the assessee is not responsible for the delay in the disposal of
the appeal, yet the Tribunal has no power to extend the stay beyond the period of 365
days. The intention of the legislature, which has been made explicit by insertion of
the words -- 'even if the delay in disposing of the appeal is not attributable to the
assessee' -- renders the right of appeal granted to the assessee by the statute to be
illusory for no fault on the part of the assessee. The stay, which was available to him
prior to the 365 days having passed, is snatched away simply because the Tribunal
has, for whatever reason, not attributable to the assessee, been unable to dispose of
the appeal. Take the case of delay being caused in the disposal of the appeal on the
part of the Revenue. Even in that case, the stay would stand vacated on the expiry of
365 days. This is despite the fact that the stay was granted by the Tribunal, in the first
instance, upon considering the prima facie merits of the case through a reasoned
order.
24. Furthermore, the petitioners are correct in their submission that unequals have
been treated equally. Assessees who, after having obtained stay orders and by their
conduct delay the appeal proceedings, have been treated in the same manner in
which assessees, who have not, in any way, delayed the proceedings in the appeal.
The two classes of assessees are distinct and cannot be clubbed together. This
clubbing together has led to hostile discrimination against the assessees to whom the
delay is not attributable. It is for this reason that we find that the insertion of the
expression -- 'even if the delay in disposing of the appeal is not attributable to the
assessee' -- by virtue of the Finance Act, 2008, violates the non-discrimination clause
of Article 14 of the Constitution of India. The object that appeals should be heard
expeditiously and that assessees should not misuse the stay orders granted in their
favour by adopting delaying tactics is not at all achieved by the provision as it stands.
On the contrary, the clubbing together of "well behaved" assessees and those who
cause delay in the appeal proceedings is itself violative of Article 14 of the
Constitution and has no nexus or connection with the object sought to be achieved.
The said expression introduced by the Finance Act, 2008 is, therefore, struck down
as being violative of Article 14 of the Constitution of India. This would revert us to the
position of law as interpreted by the Bombay High Court in Narang Overseas [Narang
Overseas (P) Ltd. v. Income Tax Appellate Tribunal, 2007 SCC OnLine Bom 671 :
(2007) 295 ITR 22] , with which we are in full agreement. Consequently, we hold
that, where the delay in disposing of the appeal is not attributable to the assessee, the
Tribunal has the power to grant extension of stay beyond 365 days in deserving cases.
The writ petitions are allowed as above.'' (emphasis supplied)
86. Lastly, the said provision was tested for its validity before the Bench of three Hon'ble Judges of
the Supreme Court in Deputy Commissioner of Income Tax and another Vs Pepsi Foods Ltd. (nowChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Pepsico India Holdings Private Limited)34 when the said judgments of various High Courts were
carried in appeal to the Supreme Court. Affirming the holdings of the High Courts and finding that
the provision violates Article 14 the Supreme Court in Pepsico Foods Ltd. (supra) laid down the law
in the following terms:
"20. Judged by both these parameters, there can be no doubt that the third proviso to
Section 254(2-A) of the Income Tax Act, introduced by the Finance Act, 2008, would
be both arbitrary and discriminatory and, therefore, liable to be struck down as
offending Article 14 of the Constitution of India. First and foremost, as has correctly
been held in the impugned judgment, unequals are treated equally in that no
differentiation is made by the third proviso between the assessees who are
responsible for delaying the proceedings and assessees who are not so responsible.
This is a little peculiar in that the legislature itself has made the aforesaid
differentiation in the second proviso to Section 254(2-A) of the Income Tax Act,
making it clear that a stay order may be extended up to a period of 365 days upon
satisfaction that the delay in disposing of the appeal is not attributable to the
assessee. We have already seen as to how, as correctly held by Narang Overseas
[Narang Overseas (P) Ltd. v. Income Tax Appellate Tribunal, 2007 SCC OnLine Bom
671 : (2007) 295 ITR 22] , the second proviso was introduced by the Finance Act,
2007 to mitigate the rigour of the first proviso to Section 254(2-A) of the Income Tax
Act in its previous avatar. Ordinarily, the Appellate Tribunal, where possible, is to
hear and decide appeals within a period of four years from the end of the financial
year in which such appeal is filed. It is only when a stay of the impugned order before
the Appellate Tribunal is granted, that the appeal is required to be disposed of within
365 days. So far as the disposal of an appeal by the Appellate Tribunal is concerned,
this is a directory provision. However, so far as vacation of stay on expiry of the said
period is concerned, this condition becomes mandatory so far as the assessee is
concerned.
"22. Since the object of the third proviso to Section 254(2-A) of the Income Tax Act is
the automatic vacation of a stay that has been granted on the completion of 365 days,
whether or not the assessee is responsible for the delay caused in hearing the appeal,
such object being itself discriminatory, in the sense pointed out above, is liable to be
struck down as violating Article 14 of the Constitution of India. Also, the said proviso
would result in the automatic vacation of a stay upon the expiry of 365 days even if
the Appellate Tribunal could not take up the appeal in time for no fault of the
assessee. Further, vacation of stay in favour of the Revenue would ensue even if the
Revenue is itself responsible for the delay in hearing the appeal. In this sense, the
said proviso is also manifestly arbitrary being a provision which is capricious,
irrational and disproportionate so far as the assessee is concerned."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

23. In fact, in a recent judgment of this Court in Essar Steel (India) Ltd. (CoC) v. Satish Kumar
Gupta [Essar Steel (India) Ltd. (CoC) v. Satish Kumar Gupta, (2020) 8 SCC 531 : (2021) 2 SCC (Civ)
443] , the word "mandatorily" in the 2nd proviso inserted through an amendment made to Section
12(3) of the Insolvency and Bankruptcy Code, 2016 was struck down. This Court held : (SCC pp.
626-28, paras 124-27) "124. Given the fact that timely resolution of stressed assets is a key factor in
the successful working of the Code, the only real argument against the amendment is that the time
taken in legal proceedings cannot ever be put against the parties before NCLT and Nclat based upon
a Latin maxim which subserves the cause of justice, namely, actus curiae neminem gravabit.
125. In Atma Ram Mittal v. Ishwar Singh Punia [Atma Ram Mittal v. Ishwar Singh Punia, (1988) 4
SCC 284] , this Court applied the maxim to time taken in legal proceedings under the Haryana
Urban (Control of Rent and Eviction) Act, 1973, holding : (SCC pp. 288-89, para 8) '8. It is well
settled that no man should suffer because of the fault of the court or delay in the procedure. Broom
has stated the maxim actus curiae neminem gravabit -- an act of court shall prejudice no man.
Therefore, having regard to the time normally consumed for adjudication, the ten years' exemption
or holiday from the application of the Rent Act would become illusory, if the suit has to be filed
within that time and be disposed of finally. It is common knowledge that unless a suit is instituted
soon after the date of letting it would never be disposed of within ten years and even then within
that time it may not be disposed of. That will make the ten years' holiday from the Rent Act illusory
and provide no incentive to the landlords to build new houses to solve problem of shortages of
houses. The purpose of legislation would thus be defeated. Purposive interpretation in a social
amelioration legislation is an imperative irrespective of anything else.'
127. Both these judgments in Atma Ram Mittal [Atma Ram Mittal v. Ishwar Singh Punia, (1988) 4
SCC 284] and Sarah Mathew [Sarah Mathew v. Institute of Cardio Vascular Diseases, (2014) 2 SCC
62 : (2014) 1 SCC (Cri) 721] have been followed in Neeraj Kumar Sainy v. State of U.P. [Neeraj
Kumar Sainy v. State of U.P., (2017) 14 SCC 136 : 8 SCEC 454] , SCC paras 29 and 32. Given the fact
that the time taken in legal proceedings cannot possibly harm a litigant if the Tribunal itself cannot
take up the litigant's case within the requisite period for no fault of the litigant, a provision which
mandatorily requires the CIRP to end by a certain date -- without any exception thereto -- may well
be an excessive interference with a litigant's fundamental right to non-arbitrary treatment under
Article 14 and an excessive, arbitrary and therefore unreasonable restriction on a litigant's
fundamental right to carry on business under Article 19(1)(g) of the Constitution of India. This being
the case, we would ordinarily have struck down the provision in its entirety. However, that would
then throw the baby out with the bath water, inasmuch as the time taken in legal proceedings is
certainly an important factor which causes delay, and which has made previous statutory
experiments fail as we have seen from Madras Petrochem [Madras Petrochem Ltd. v. BIFR, (2016) 4
SCC 1 : (2016) 2 SCC (Civ) 478] . Thus, while leaving the provision otherwise intact, we strike down
the word "mandatorily" as being manifestly arbitrary under Article 14 of the Constitution of India
and as being an excessive and unreasonable restriction on the litigant's right to carry on business
under Article 19(1)(g) of the Constitution. The effect of this declaration is that ordinarily the time
taken in relation to the corporate resolution process of the corporate debtor must be completed
within the outer limit of 330 days from the insolvency commencement date, including extensions
and the time taken in legal proceedings. However, on the facts of a given case, if it can be shown toChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the adjudicating authority and/or the Appellate Tribunal under the Code that only a short period is
left for completion of the insolvency resolution process beyond 330 days, and that it would be in the
interest of all stakeholders that the corporate debtor be put back on its feet instead of being sent into
liquidation and that the time taken in legal proceedings is largely due to factors owing to which the
fault cannot be ascribed to the litigants before the adjudicating authority and/or the Appellate
Tribunal, the delay or a large part thereof being attributable to the tardy process of the adjudicating
authority and/or the Appellate Tribunal itself, it may be open in such cases for the adjudicating
authority and/or the Appellate Tribunal to extend time beyond 330 days. Likewise, even under the
newly added proviso to Section 12, if by reason of all the aforesaid factors the grace period of 90
days from the date of commencement of the amending Act of 2019 is exceeded, there again a
discretion can be exercised by the adjudicating authority and/or the Appellate Tribunal to further
extend time keeping the aforesaid parameters in mind. It is only in such exceptional cases that time
can be extended, the general rule being that 330 days is the outer limit within which resolution of
the stressed assets of the corporate debtor must take place beyond which the corporate debtor is to
be driven into liquidation."
27. We have already seen how unequals have been treated equally so far as assessees who are
responsible for delaying appellate proceedings and those who are not so responsible, resulting in a
violation of Article 14 of the Constitution of India. Also, the expression "permissible" policy of
taxation would refer to a policy that is constitutionally permissible. If the policy is itself arbitrary
and discriminatory, such policy will have to be struck down, as has been found in para 20 above.
(emphasis supplied)
30. The law laid down by the impugned judgment of the Delhi High Court in Pepsi Foods (P)
Ltd. [Pepsi Foods (P) Ltd. v. CIT, 2015 SCC OnLine Del 9543 : (2015) 376 ITR 87] is correct.
Resultantly, the judgments [CIT v. Parnod Ricard (India) (P) Ltd., 2017 SCC OnLine Del
12851] , [CIT v. Anil Girishbhai Darji, 2016 SCC OnLine Guj 10059] , [CIT v. Maruti Suzuki (India)
Ltd., 2016 SCC OnLine Del 6680] , [CIT v. Pepsi Foods (P) Ltd., 2016 SCC OnLine Del
6682] , [CIT v. Pepsi Foods (P) Ltd., 2016 SCC OnLine Del 6681] , [CIT v. Jindal Steel & Power Ltd.,
2017 SCC OnLine P&H 5411] , [CIT v. BMW (India) (P) Ltd., 2017 SCC OnLine P&H
5414] , [CIT v. Towers Watson (India) (P) Ltd., 2017 SCC OnLine P&H 5413] , [CIT v. Pepsi Foods
(P) Ltd., 2017 SCC OnLine Del 12849] , [CIT v. Maruti Suzuki (India) Ltd., 2017 SCC OnLine Del
12852] , [CIT v. Vertex Customer Services (P) Ltd., 2017 SCC OnLine Del 12850] , [CIT v. Towers
Watson (India) (P) Ltd., 2017 SCC OnLine P&H 5410] , [CIT v. Swarovski (India) (P) Ltd., 2017 SCC
OnLine Del 12854] , [CIT v. Religare Capital Markets Ltd., 2017 SCC OnLine Del
12848] , [CIT v. Jindal Steel & Power Ltd., 2017 SCC OnLine P&H 5412] , [CIT v. Motherson Sumi
Systems Ltd., 2017 SCC OnLine Del 12853] , [CIT v. Maruti Suzuki (India) Ltd., 2018 SCC OnLine
Del 13370] of the various High Courts which follow the aforesaid declaration of law are also correct.
Consequently, the third proviso to Section 254(2-A) of the Income Tax Act will now be read without
the word "even" and the words "is not" after the words "delay in disposing of the appeal". Any order
of stay shall stand vacated after the expiry of the period or periods mentioned in the Section only if
the delay in disposing of the appeal is attributable to the assessee. The appeals of the Revenue are,
therefore, dismissed."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

87. An examination of the submissions of learned counsels of the application of the law laid down in
Pepsico Foods Ltd. (supra) to the current controversy and substantial questions as to the
interpretation of the Constitution arising therefrom will be made in the latter part of the narrative.
V. High Court : Pre-Constitution Phase to the Constitution : Articles 215, 226 & 227
88. The High Courts were the first superior courts in the country, and together with the Privy
Council and the trial court constituted the judicial system in British India. At the time of their
creation the High Courts were vested with the attributes of courts of record and the powers
necessary for administration of justice by the Indian High Courts Act read with Letters Patent. The
autonomous exercise of these powers by the High Courts in colonial India developed sturdy
traditions of independence which have always endured.
89. The High Courts attained the stature of primacy in large measure because their relationship with
the Privy Council flourished with an understanding of the common purpose of administration of
justice and recognition of limits of judicial power. Together the superior courts in colonial India had
laid the foundations of civil and criminal law, and conventions of refined judicial dialogue on which
independent India could build the temples of justice.
90. The legitimacy acquired by the High Courts in colonial India is best attested by this episode.
After independence upon entering into the office of Chief Justice of Bombay High Court, Justice M C
Chagla received messages "to maintain high traditions of impartiality and independence in the
administration of justice that the British had left behind." Others hoped that His Lordship would
"prove a worthy successor of Chief Justices like Sir Charles Sargent and Sir Lawrence Jenkins35".
Justice M.C. Chagla was the first Indian to hold the high office. Barring some aberrational
instances36 this tells the story of other pre independence High Courts as well (including Allahabad
High Court).
91. Referencing these aspects of the history of the High Courts will be fruitful as a new order may
loom in the distance.
92. The Constitution retained the High Courts as superior courts of record, but also exalted their
status to Constitutional Courts. Further the framers of the Constitution not only protected the
existing inherent powers of the High Court, but enlarged the plenary jurisdictions of the High Court.
93. Under Article 215 of the Constitution of India, the High Courts are the courts of record with all
powers of such a court including the power to punish for contempt of itself. Well established
attributes of courts of record were restated by the Supreme Court while interpreting Article 215 of
the Constitution of India in High Court of Judicature at Allahabad through its Registrar Vs. Raj
Kishore Yadav and others37 as follows:
"10. However the learned Judges were persuaded to declare the impugned Rule as
ultra vires on the ground that it conflicted with Article 215 of the Constitution of
India. It is difficult to appreciate the said line of reasoning which appealed to theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

learned Judges. All that Article 215 states is that every High Court shall be a court of
record meaning thereby all the original record of the court will be preserved by the
said court and it shall have all the powers of such a superior court of record including
the power to punish for contempt of itself. It has to be kept in view that as a superior
court of record the High Court is entitled to preserve its original record in perpetuity.
It is also now well settled that even apart from the aforesaid attribute of a superior
court of record the High Court as such has twofold powers. Being a court of record
the High Court (i) has power to determine the question about its own jurisdiction;
and (ii) has inherent power to punish for its contempt summarily. The aforesaid twin
incidents of a court of record are well established by a catena of decisions of this
Court. We may usefully refer to one of them. A majority of the Constitution Bench of
nine learned Judges of this Court in the case of Naresh Shridhar Mirajkar v. State of
Maharashtra [AIR 1967 SC 1 : (1966) 3 SCR 744] speaking through Gajendragadkar,
C.J., has made the following pertinent observations in para 60 of the Report:
"There is yet another aspect of this matter to which it is necessary to refer. The High
Court is a superior court of record and under Article 215 shall have all powers of such
a court of record including the power to punish contempt of itself. One distinguishing
characteristic of such superior courts is that they are entitled to consider questions of
their jurisdiction raised before them. This question fell to be considered by this Court
in Special Reference No. 1 of 1964 [(1965) 1 SCR 413 : AIR 1965 SC 745] , SCR at p.
499. In that case, it was urged before this Court that in granting bail to Keshav Singh,
the High Court had exceeded its jurisdiction and as such, the order was a nullity.
Rejecting this argument this Court observed that in the case of a superior court of
record, it is for the court to consider whether any matter falls within its jurisdiction
or not. Unlike a court of limited jurisdiction, the superior court is entitled to
determine for itself questions about its own jurisdiction. That is why this Court did
not accede to the proposition that in passing the order for interim bail, the High
Court can be said to have exceeded its jurisdiction with the result that the order in
question was null and void. In support of this view, this Court cited a passage
from Halsbury's Laws of England where it is observed that 'prima facie, no matter is
deemed to be beyond the jurisdiction of a superior court unless it is expressly shown
to be so, while nothing is within the jurisdiction of an inferior court unless it is
expressly shown on the face of the proceedings that the particular matter is within
the cognizance of the particular court.' If the decision of a superior court on a
question of its jurisdiction is erroneous, it can, of course, be corrected by appeal or
revision as may be permissible under the law; but until the adjudication by a superior
court on such a point is set aside by adopting the appropriate course, it would not be
open to be corrected by the exercise of the writ jurisdiction of this Court."
94. The pre-existing inherent powers of High Courts came to be preserved under Article 225 of the
Constitution of India. The extraordinary jurisdiction was vested in the High Courts under Article
226, and superintending jurisdiction over trial courts and tribunals was endowed in the High Court
under Article 227 of the Constitution of India.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

95. Tracing the history of the High Courts in the country and also adverting to the vast scope of writ
jurisdiction vested by the Constitution of India under Article 226 in all High Courts to meet the
peculiar and complicated requirements of the country, the Supreme Court in Prabodh Verma v.
State of U.P.38, also compared the scope of Article 226 and Article 32 of the Constitution of India
and went on to hold:
"36. In India, prior to the Constitution, the power to issue prerogative writs was
vested only in three High Courts, that is, the High Courts established by Letters
Patent issued by Queen Victoria under authority given by the Indian High Courts Act,
1861 (24 & 25 Vict c, 104) for the establishment of the High Courts of Judicature at
Fort William in Bengal and at Madras and at Bombay for these three presidencies,
namely, the High Courts of Calcutta, Madras and Bombay. Hence this Act is generally
called the Charter Act and the High Courts established there under the Chartered
High Courts. These High Courts were the successors so far as their original
jurisdictions were concerned of the Supreme Courts which were established in these
three Presidency- towns and inherited from those Courts the powers of the Courts of
King's Bench which included the power to issue prerogative writs, Apart from these
three High Courts none of the other High Courts in India possessed this power. The
position was changed when the Constitution of India came into force. Article 225
continues the jurisdiction of existing High Courts. Article 226, however, confers upon
every High Court the power to issue to any person or authority, including in proper
cases, any Government, within the territories in relation to which it exercises
jurisdiction, ''directions, orders or writs, including writs in the nature of habeas
corpus, mandamus, prohibition, quo warranto and certiorari or any of them, for the
enforcement of the rights conferred by Part III or for any other purpose''. It may be
mentioned that under Article 32 of the Constitution, the same power as has been
conferred upon the High Courts is conferred upon this Court without any restriction
as to territorial jurisdiction but, unlike the High Court, restricted only to the
enforcement of any of the rights conferred by Part III of the Constitution, namely, the
Fundamental Rights. Referring to Article 226, this Court in Dwarka nath, Hindu
Undivided Family v. Income Tax officer, Special Circle. Kanpur and another(1) said: 
''This article is couched in comprehensive phraseology and it ex facie confers a wide
power on the High Courts to reach injustice wherever it is found. The Constitution
designedly used a wide language in describing the nature of the power, the purpose
for which and the person or authority against whom it can be exercised. It can issue
writs in the nature of prerogative writs as understood in England but the scope of
those writs also is widened by the use of the expression `nature', for the said
expression does not equate the writs that can be issued in India with those in
England, but only draws an analogy from them, That apart High Courts can also issue
directions, orders or writs other than the prerogative writs. It enables the high Courts
to mould the reliefs to meet the peculiar and complicated requirements of this
country. Any attempt to equate the scope of the power of the High Court under
Article 226 of the Constitution with that of the English Courts to issue prerogativeChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

writs is to introduce the unnecessary procedural restrictions grown over the years in
a comparatively small country like England with a unitary form of Government in to
a vast country like India functioning under a federal structure, such a construction
defeats the purpose of the article itself. To say this is not to say that the High Courts
can function arbitrarily under this article. Some limitations are implicit in the article
and others may be evolved to direct the article through the defined channels.''
(emphasis supplied) 
96. The Constitution Bench of the Supreme Court in T.C. Basappa v. T. Nagappa39 after noticing
wide powers of the Supreme Court and High Courts to issue orders, writs or directions including the
writs of different types, declined to import the procedural technicalities of English Law of writs by
holding:
"6. The language used in Articles 32 and 226 of our Constitution is very wide and the
powers of the Supreme Court as well as of all the High Courts in India extend to
issuing of orders, writs or directions including writs in the nature of habeas corpus,
mandamus, quo warranto, prohibition and certiorari as may be considered necessary
for enforcement of the fundamental rights and in the case of the High Courts, for
other purposes as well. In view of the express provisions in our Constitution we need
not now look back to the early history or the procedural technicalities of these writs
in English law, nor feel oppressed by any difference or change of opinion expressed in
particular cases by English Judges. We can make an order or issue a writ in the
nature of certiorari in all appropriate cases and in appropriate manner, so long as we
keep to the broad and fundamental principles that regulate the exercise of
jurisdiction in the matter of granting such writs in English law."
97. Powers of superintendence of the High Court under Article 227 of the Constitution of India over
trial courts as well as the tribunals were construed to be both judicial and administrative by the
Supreme Court in  Waryam Singh v. Amarnath40:
"13.....Re. 2.-- The material part of Article 227 substantially reproduces the provisions
of Section 107 of the Government of India Act, 1915, except that the power of
superintendece has been extended by the Article also to Tribunals. That the Rent
Controller and the District Judge exercising jurisdiction under the Act are Tribunals
cannot and has not been controverted. The only question raised is as to the nature of
the power of superintendence conferred by the Article. Reference is made to clause
(2) of the article in support of the contention that this article only confers on the High
Court administrative superintendence over the subordinate courts and tribunals. We
are unable to accept this contention because clause (2) is expressed to be without
prejudice to the generality of the provisions in clause (1). Further, the preponderance
of judicial opinion in India was that Section 107 which was similar in terms to Section
15 of the High Courts Act, 1861, gave a power of judicial superintendence to the High
Court apart from and independently of the provisions of other laws conferring
revisional jurisdiction on the High Court. In this connection it has to be rememberedChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

that Section 107 of the Government of India Act, 1915, was reproduced in the
Government of India Act, 1935, as Section 224. Section 224 of the 1935 Act, however,
introduced sub-section (2), which was new, providing that nothing in the section
should be construed as giving the High Court any jurisdiction to question any
judgment of any inferior court which was not otherwise subject to appeal or revision.
The idea presumably was to nullify the effect of the decisions of the different High
Courts referred to above. Section 224 of the 1935 Act has been reproduced with
certain modifications in Article 227 of the Constitution. It is significant to note that
sub-section (2) to Section 224 of the 1935 Act has been omitted from Article 227. This
significant omission has been regarded by all High Courts in India before whom this
question has arisen as having restored to the High Court the power of judicial
superintendence it had under Section 15 of the High Courts Act, 1861, and Section
107 of the Government of India Act, 1915. See the cases referred to in Moti Lal v. The
State through Shrimati Sagrawati [ILR (1952) 1 Allahabad 558 at p. 567] . Our
attention has not been drawn to any case which has taken a different view and, as at
present advised, we see no reason to take a different view."
98. The judgment of Waryam Singh (supra) was followed by Seven Judges Bench in Hari Vishnu
Kamath v. Syed Ahmad Ishaque and others41:
"20. We are also of opinion that the Election Tribunals are subject to the
superintendence of the High Courts under Article 227 of the Constitution, and that
superintendence is both judicial and administrative. That was held by this Court
in Waryam Singh v. Amarnath [1954 SCR 565] where it was observed that in this
respect Article 227 went further than Section 224 of the Government of India Act,
1935, under which the superintendence was purely administrative, and that it
restored the position under Section 107 of the Government of India Act, 1915. It may
also be noted that while in a certiorari under Article 226 the High Court can only
annul the decision of the Tribunal, it can, under Article 227, do that, and also issue
further directions in the matter. We must accordingly hold that the application of the
appellant for a writ of certiorari and for other reliefs was maintainable under Articles
226 and 227 of the Constitution."
99. The scope of inherent powers of the High Court under Section 482 Cr.P.C. will be discussed
later.
100. Repertoire of plenary powers under Articles 226 and 227 of the Constitution of India or Section
482 Cr.P.C. are equal to the high purposes they subserve. The High Courts have exercised these
powers to act ex debito justitiae, uphold the law, protect fundamental rights of citizens, thwart abuse
of the process of court at the threshold, prevent miscarriage of justice and interpret the Constitution.
Briefly put, for administration of justice.
101. The constitutional status of the High Court preserves its autonomy. The plenary powers under
inherent and extraordinary jurisdictions protect the independence of the High Court. The capacityChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

of the High Court to administer justice flowing from these powers undergirds its position as the
sentinel on the qui vive and keeps the abiding faith of the citizenry.
102. Powers of the High Court whether vested under Articles 226 and 227 of the Constitution of
India or inherent powers under Section 482 Cr.P.C. together comprise the defining elements of the
High Court. Infact the existence of inherent powers under Section 482 Cr.P.C. and the endowment
of extraordinary jurisdictions under Articles 226 and 227 of the Constitution of India and exercise of
these powers and jurisdictions are the pivots on which legitimacy of the High Court rests. The
Supreme Court has zealously protected these powers of the High Court, and entrenched them in the
body of constitutional law as enduring virtues of our constitutional scheme.
103. Curtailment of these powers will cause disarray in the administration of justice. Bereft of these
powers the constitutional status of the High Court will be rendered illusory.
104. Salience of the High Court as a Constitutional Court and its autonomy are a given in the
constitutional text, but they cannot be taken for granted in constitutional law. There are various
factors which can dilute the autonomy of the High Courts and denude their capacity for
administration of justice. Some facets and consequences of dilution of autonomy of the High Courts
over the years were discussed by this Court in Hasae @ Hasana Wae  Vs. State of U.P. and
another42.
105. In Hasae @ Hasana Wae (supra), this Court had the occasion to consider some features of the
raison detre of the High Court as a Constitutional Court:  
"8. The Allahabad High Court has a history of more than 155 years which predates
most constitutional Courts in the country. Rectitude of conduct of the judges,
adherence to ethical norms by lawyers, and professional achievements which set
standards of excellence form the quintessence of its storied reputation and animates
the Court even today. The Allahabad High Court has thus earned the abiding trust of
the people of the State by dispensing fair and impartial justice and by the probity of
conduct of the Bar and the Bench alike. 
9. The Bar of this Court was in the frontline of the freedom struggle and the Court has
been at the vanguard of protection of rights and liberties of citizens in times of
maximum peril. 
10. The paradox of the Allahabad High Court is that the unconditional trust of the
citizens is its most precious asset but also poses the most pressing challenge. The
people of the State of U.P. approach this Court with full confidence and no constraint.
The result of the people of the State approaching the Court in huge numbers is the
largest docket size in the country. The workload on Judges in the Allahabad High
Court is the highest in the country. Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

11. Unremitting the toil of judges and unsurpassed industry of lawyers has allowed
the Court to keep the faith and confidence of the people in its ability to deliver
justice. 
12. The distant vision of the founding fathers was reflected in the creation of the
comity of constitutional Courts which included the High Courts of the States and the
Supreme Court of India. The High Courts and the Supreme Court have been vested
with analogous powers by the Constitution of India. Constitutional autonomy of the
High Courts is paired with the attribute of finality to the holdings of the Supreme
Court as the highest appellate Court in the country. These features are integral to the
scheme of judicial federalism in the Constitution of India. 
13. The High Courts possess supervisory powers over the District Courts under
Article 227 of the Constitution of India. However it is noteworthy that no such
powers of superintendence over the High Courts are vested in the Supreme Court by
the Constitution of India. The reasons are not far to seek. 
14. Considering the unique circumstances of our country, most citizens are not likely
to go beyond the High Court in search of justice. 
15. An overwhelming majority of the citizens make the Allahabad High Court the final
temple in their pursuit of justice. Primarily it is the quality of justice and trust in the
institution which persuades the majority of our citizens to accept the finality of the
judgements of the Allahabad High Court. High Court is the litigative terminus for
other reasons as well, including litigation fatigue, financial burden and desire for
closure. The Allahabad High Court is final because of the citizens' choice as the Court
of last resort. 
32. The High Courts are best placed to understand and respond to the local problems
of the State and the special needs of its people. Upholding the law and dispensing
justice on a day to day basis in this setting provides an acute insight to the High
Courts and imparts great value to their judgements. Legal practices evolved by the
High Courts from the experience gained by proximity to ground realities of the State
and which have eminently served the cause of justice should not be readily reversed. 
49. The understanding of particularized circumstances of the society and the facts of
the case is essential to dispense justice in a State like Uttar Pradesh. The richness of
the State of U.P. is reflected in the diversity of its heritage. The disparities in the
society are manifested in the challenges faced by the State and the complex issues
arising before the High Court." 
VB. INHERENT POWERS U/S 482 Cr.P.C.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

106. After tracing the origins of inherent powers under Section 482 Cr.P.C. to the inception of High
Courts, the Supreme Court in Ratilal Bhanji Mithani v. Asstt. Collector of Custom43, expounded the
purpose of the said powers:
"9. Now the question is whether the inherent power of the High Court is conferred by
or has the sanction of enacted law. From its very inception the High Court has
possessed and enjoyed its inherent powers including the power to prevent the abuse
of the process of any Court within its jurisdiction and to secure the ends of justice.
These powers inhere in the High Court and spring from its very nature and
constitution as a court of superior jurisdiction. All the existing powers of the High
Courts were preserved and continued by legislation from time to time.
(emphasis supplied)
10. Section 561-A of the Criminal Procedure Code declared that "nothing in this Code
shall be deemed to limit or affect the inherent power of the High Court to make such
orders as may be necessary to give effect to any order passed under this Code, or to
prevent the abuse of process of any Court or otherwise to secure the ends of justice".
The section was inserted in the Code by Act 18 of 1923 to obviate any doubt that these
inherent powers have been taken away by the Code. In terms, this section did not
confer any power, it only declared that nothing in the Code shall be deemed to limit
or affect the existing inherent powers of the High Court, see King Emperor v. Khwaja
Nazir Ahmad [LR 61 IA 203, 213].Then came other enactments which were framed
differently. Section 223 of the Government of India Act, 1935, provided:
(emphasis supplied) "Subject to the provisions of this Part of this Act, to the
provisions of any Order in Council made under this or any other Act and to the
provisions of any Act of the appropriate Legislature enacted by virtue of powers
conferred on that Legislature by this Act, the jurisdiction of and the law administered
in, any existing High Court, and the respective powers of the judges thereof in
relation to the administration of justice in the court, including any power to make
rules of Court and to regulate the sittings of the Court and of members thereof sitting
alone or in Division Courts, shall be the same as immediately before the
commencement of Part III of this Act."
The Section enacted that the jurisdiction of the existing High Courts and the powers of the judges
thereof in relation to the administration of justice "shall be" the same as immediately before the
commencement of Part III of the Act. The statute confirmed and revested in the High Court all its
existing powers and jurisdiction including its inherent powers. Then came the Constitution. Article
225 of the Constitution provides:
"225. Subject to the provisions of this Constitution and to the provisions of any law of
the appropriate legislature made by virtue of powers conferred on that Legislature by
this Constitution, the jurisdiction, of and the law administered in, any existing HighChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Court, and the respective powers of the Judges thereof in relation to the
administration of justice in the Court, including any power to make rules of Court
and to regulate the sittings of the Court and of members thereof sitting alone or in
Division Courts, shall be the same as immediately before the commencement of this
Constitution."
The proviso to the article is not material and need not be read. The Article enacts that the
jurisdiction of the existing High Courts and the powers of the judges thereof in relation to
administration of justice "shall be" the same as immediately before the commencement of the
Constitution. The Constitution confirmed and re-vested in the High Court all its existing powers and
jurisdiction including its inherent powers, and its power to make rules. When the Constitution or
any enacted law has embraced and confirmed the inherent powers and jurisdiction of the High
Court which previously existed, that power and jurisdiction has the sanction of an enacted "law"
within the meaning of Article 21 as explained in A.K. Gopalan case. The inherent powers of the High
Court preserved by Section 561-A of the Code of Criminal Procedure are thus vested in it by "law"
within the meaning of Article 21. The procedure for invoking the inherent powers is regulated by
rules framed by the High Court. The power to make such rules is conferred on the High Court by the
Constitution. The rules previously in force were continued in force by Article 372 of the
Constitution. The order of the High Court cancelling the bail and depriving the appellant of his
personal liberty is according to procedure established by law and is not violative of Article 21."
(emphasis supplied)
107. Some instances of exercise of inherent powers by the High Court for quashing criminal cases as
illustrated by the Supreme Court in R. P. Kapur v. State of Punjab44 are as under:
"6. ... It is well established that the inherent jurisdiction of the High Court can be
exercised to quash proceedings in a proper case either to prevent the abuse of the
process of any court or otherwise to secure the ends of justice. Ordinarily criminal
proceedings instituted against an accused person must be tried under the provisions
of the Code, and the High Court would be reluctant to interfere with the said
proceedings at an interlocutory stage. It is not possible, desirable or expedient to lay
down any inflexible rule which would govern the exercise of this inherent
jurisdiction. However, we may indicate some categories of cases where the inherent
jurisdiction can and should be exercised for quashing the proceedings. There may be
cases where it may be possible for the High Court to take the view that the institution
or continuance of criminal proceedings against an accused person may amount to the
abuse of the process of the court or that the quashing of the impugned proceedings
would secure the ends of justice. If the criminal proceeding in question is in respect
of an offence alleged to have been committed by an accused person and it manifestly
appears that there is a legal bar against the institution or continuance of the said
proceeding the High Court would be justified in quashing the proceeding on that
ground. Absence of the requisite sanction may, for instance, furnish cases under this
category. Cases may also arise where the allegations in the first information report orChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the complaint, even if they are taken at their face value and accepted in their entirety,
do not constitute the offence alleged; in such cases no question of appreciating
evidence arises; it is a matter merely of looking at the complaint or the first
information report to decide whether the offence alleged is disclosed or not. In such
cases it would be legitimate for the High Court to hold that it would be manifestly
unjust to allow the process of the criminal court to be issued against the accused
person. A third category of cases in which the inherent jurisdiction of the High Court
can be successfully invoked may also arise. In cases falling under this category the
allegations made against the accused person do constitute an offence alleged but
there is either no legal evidence adduced in support of the case or evidence adduced
clearly or manifestly fails to prove the charge. In dealing with this class of cases it is
important to bear in mind the distinction between a case where there is no legal
evidence or where there is evidence which is manifestly and clearly inconsistent with
the accusation made and cases where there is legal evidence which on its appreciation
may or may not support the accusation in question. In exercising its jurisdiction
under Section 561-A the High Court would not embark upon an enquiry as to
whether the evidence in question is reliable or not. That is the function of the trial
Magistrate, and ordinarily it would not be open to any party to invoke the High
Court's inherent jurisdiction and contend that on a reasonable appreciation of the
evidence the accusation made against the accused would not be sustained. Broadly
stated that is the nature and scope of the inherent jurisdiction of the High Court
under Section 561-A in the matter of quashing criminal proceedings...."
108. The Supreme Court examined the concept of doctrine of abuse of the process of court and
remedy of refusal to allow the trial by relying on judgments of English Courts as well as Courts in
India in Chandran Ratnaswami v. K.C. Palanisamy45, by holding:
"32. Before we embark upon dealing with the issue posed before us, we would like to
discuss the principles laid down by various courts as to when continuance of criminal
proceeding will amount to abuse of the process of the court.
33. The doctrine of abuse of process of court and the remedy of refusal to allow the
trial to proceed is well-established and recognised doctrine both by the English courts
and courts in India. There are some established principles of law which bar the trial
when there appears to be abuse of process of court.
34. Lord Morris in Connelly v. Director of Public Prosecutions [1964 AC 1254 : (1964)
2 WLR 1145 : (1964) 2 All ER 401 (HL)], observed: (AC pp. 1301-02) "There can be no
doubt that a court which is endowed with a particular jurisdiction has powers which
are necessary to enable it to act effectively within such jurisdiction. ... A court must
enjoy such powers in order to enforce its rules of practice and to suppress any abuses
of its process and to defeat any attempted thwarting of its process.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

The power (which is inherent in a court's jurisdiction) to prevent abuses of its process
and to control its own procedure must in a criminal court include a power to
safeguard an accused person from oppression or prejudice."
In his separate pronouncement, Lord Delvin in the same case observed that where particular
criminal proceedings constitute an abuse of process, the court is empowered to refuse to allow the
indictment to proceed to trial.
35. In Hui Chi-ming v. R. [(1992) 1 AC 34 : (1991) 3 WLR 495 : (1991) 3 All ER 897 (PC)] , the Privy
Council defined the word "abuse of process" as something so unfair and wrong with the prosecution
that the court should not allow a prosecutor to proceed with what is, in all other respects, a perfectly
supportable case.
36. In the leading case of R. v. Horseferry Road Magistrates' Court, ex p Bennett [(1994) 1 AC 42 :
(1993) 3 WLR 90 : (1993) 3 All ER 138 (HL)] , on the application of abuse of process, the court
confirms that an abuse of process justifying the stay of prosecution could arise in the following
circumstances:
(i) where it would be impossible to give the accused a fair trial; or
(ii) where it would amount to misuse/manipulation of process because it offends the
court's sense of justice and propriety to be asked to try the accused in the
circumstances of the particular case.
37. In R. v. Derby Crown Court, ex p Brooks [(1984) 80 Cr App R 164 (DC)] , Lord Chief Justice
Ormrod stated:
"It may be an abuse of process if either (a) the prosecution has manipulated or
misused the process of the court so as to deprive the defendant of a protection
provided by law or to take unfair advantage of a technicality, or (b) on the balance of
probability the defendant has been, or will be, prejudiced in the preparation of
conduct of his defence by delay on the part of the prosecution which is unjustifiable."
38. Neill, L.J. in R. v. Beckford (Anthony) [(1996) 1 Cr App R 94 : 1995 RTR 251 (CA)] , observed
that:
"The jurisdiction to stay can be exercised in many different circumstances.
Nevertheless two main strands can be detected in the authorities: (a) cases where the
court concludes that the defendant cannot receive a fair trial; (b) cases where the
court concludes that it would be unfair for the defendant to be tried."
What is unfair and wrong will be for the court to determine on the individual facts of each case."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

109. Chandran Ratnaswami (supra) thereafter cited various other authorities with approval
including State of Haryana Vs. Bhajan Lal46; Zandu Pharmaceutical Works Ltd. vs. Mohd. Sharaful
Haque47, Inder Mohan Goswami Vs. State of Uttranchal48 and G. Sagar Suri v. State of U.P.49
110. The purpose of vesting inherent powers in the High Court from their inception to act ex debito
justitiae was reiterated by the Supreme Court in Minu Kumari v. State of Bihar50, while
determining the ambit of Section 482 Cr.P.C.:
"19. The section does not confer any new power on the High Court. It only saves the
inherent power which the Court possessed before the enactment of the Code. It
envisages three circumstances under which the inherent jurisdiction may be
exercised, namely, (i) to give effect to an order under the Code, (ii) to prevent abuse
of the process of court, and (iii) to otherwise secure the ends of justice. It is neither
possible nor desirable to lay down any inflexible rule which would govern the exercise
of inherent jurisdiction. No legislative enactment dealing with procedure can provide
for all cases that may possibly arise. Courts, therefore, have inherent powers apart
from express provisions of law which are necessary for proper discharge of functions
and duties imposed upon them by law. That is the doctrine which finds expression in
the section which merely recognises and preserves inherent powers of the High
Courts. All courts, whether civil or criminal, possess, in the absence of any express
provision, as inherent in their constitution, all such powers as are necessary to do the
right and to undo a wrong in course of administration of justice on the
principle quando lex aliquid alicui concedit, concedere videtur id sine quo res ipsa
esse non potest (when the law gives a person anything it gives him that without which
it cannot exist). While exercising powers under the section, the Court does not
function as a court of appeal or revision. Inherent jurisdiction under the section
though wide has to be exercised sparingly, carefully and with caution and only when
such exercise is justified by the tests specifically laid down in the section itself. It is to
be exercised ex debito justitiae to do real and substantial justice for the
administration of which alone courts exist. Authority of the court exists for
advancement of justice and if any attempt is made to abuse that authority so as to
produce injustice, the court has power to prevent abuse. It would be an abuse of
process of the court to allow any action which would result in injustice and prevent
promotion of justice. In exercise of the powers court would be justified to quash any
proceeding if it finds that initiation/continuance of it amounts to abuse of the process
of court or quashing of these proceedings would otherwise serve the ends of justice."
(emphasis supplied)
111. After examining the provisions of the statute, the Supreme Court in Hamida v. Rashid Alias
Rasheed51, noticed that the statute did not limit the inherent powers of the High Court. Further the
procedural Code, howsoever exhaustive, cannot provide for all contingencies for all times to come.
Existence of inherent powers was accordingly justified in Hamida (supra) on the following footing:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"6. We are in agreement with the contention advanced on behalf of the complainant
appellant. Section 482 CrPC saves the inherent powers of the High Court and its
language is quite explicit when it says that nothing in the Code shall be deemed to
limit or affect the inherent powers of the High Court to make such orders as may be
necessary to give effect to any order under the Code, or to prevent abuse of the
process of any court or otherwise to secure the ends of justice. A procedural code,
however exhaustive, cannot expressly provide for all time to come against all the
cases or points that may possibly arise, and in order that justice may not suffer, it is
necessary that every court must in proper cases exercise its inherent power for the
ends of justice or for the purpose of carrying out the other provisions of the Code. It is
well-established principle that every court has inherent power to act ex debito
justitiae to do that real and substantial justice for the administration of which alone it
exists or to prevent abuse of the process of the court. As held by the Privy Council
in Emperor v. Khwaja Nazir Ahmad [AIR 1945 PC 18] with regard to Section 561-A of
the Code of Criminal Procedure, 1898 (Section 482 CrPC is a verbatim copy of the
said provision) gives no new powers. It only provides that those powers which the
Court already inherently possesses shall be preserved and is inserted, lest it should be
considered that the only powers possessed by the Court are those expressly conferred
by the Code and that no inherent power had survived the passing of the Act."
(emphasis supplied)
112. The scope of the inherent powers of the High Court under Section 482 Cr.P.C., and the rationale
for confiding such wide powers in the High Court was explained by the Supreme Court in Zandu
Pharmaceutical Works Ltd. v. Mohd. Sharaful Haque52:
"8. Exercise of power under Section 482 of the Code in a case of this nature is the
exception and not the rule. The section does not confer any new powers on the High
Court. It only saves the inherent power which the Court possessed before the
enactment of the Code. It envisages three circumstances under which the inherent
jurisdiction may be exercised, namely, (i) to give effect to an order under the Code,
(ii) to prevent abuse of the process of court, and (iii) to otherwise secure the ends of
justice. It is neither possible nor desirable to lay down any inflexible rule which
would govern the exercise of inherent jurisdiction. No legislative enactment dealing
with procedure can provide for all cases that may possibly arise. Courts, therefore,
have inherent powers apart from express provisions of law which are necessary for
proper discharge of functions and duties imposed upon them by law. That is the
doctrine which finds expression in the section which merely recognises and preserves
inherent powers of the High Courts. All courts, whether civil or criminal, possess, in
the absence of any express provision, as inherent in their constitution, all such
powers as are necessary to do the right and to undo a wrong in course of
administration of justice on the principle "quando lex aliquid alicui concedit,
concedere videtur et id sine quo res ipsae esse non potest" (when the law gives a
person anything, it gives him that without which it cannot exist). While exercisingChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

powers under the section, the court does not function as a court of appeal or revision.
Inherent jurisdiction under the section though wide has to be exercised sparingly,
carefully and with caution and only when such exercise is justified by the tests
specifically laid down in the section itself. It is to be exercised ex debito justitiae to do
real and substantial justice for the administration of which alone courts exist.
Authority of the court exists for advancement of justice and if any attempt is made to
abuse that authority so as to produce injustice, the court has power to prevent abuse.
It would be an abuse of process of the court to allow any action which would result in
injustice and prevent promotion of justice. In exercise of the powers, court would be
justified to quash any proceeding if it finds that initiation/continuance of it amounts
to abuse of the process of court or quashing of these proceedings would otherwise
serve the ends of justice. When no offence is disclosed by the complaint, the court
may examine the question of fact. When a complaint is sought to be quashed, it is
permissible to look into the materials to assess what the complainant has alleged and
whether any offence is made out even if the allegations are accepted in toto."
113. While describing the plenitude of the powers under Section 482 Cr.P.C., the need to observe
caution in exercise of such powers and the importance of jealously preserving the said powers was
underscored by the Supreme Court after citing authorities of our courts as well as international
authorities in point in Gorige Pentaiah v. State of A.P.53:
"12. This Court in a number of cases has laid down the scope and ambit of courts'
powers under Section 482 CrPC. Every High Court has inherent power to act ex
debito justitiae to do real and substantial justice, for the administration of which
alone it exists, or to prevent abuse of the process of the court. Inherent power under
Section 482 CrPC can be exercised:
(i) to give effect to an order under the Code;
(ii) to prevent abuse of the process of court; and
(iii) to otherwise secure the ends of justice.
(emphasis supplied) Inherent powers under Section 482 CrPC though wide have to be exercised
sparingly, carefully and with great caution and only when such exercise is justified by the tests
specifically laid down in this section itself. Authority of the court exists for the advancement of
justice. If any abuse of the process leading to injustice is brought to the notice of the court, then the
court would be justified in preventing injustice by invoking inherent powers in absence of specific
provisions in the statute.
13. Reference to the following cases would reveal that the courts have consistently taken the view
that they must use this extraordinary power to prevent injustice and secure the ends of justice. The
English courts have also used inherent power to achieve the same objective. It is generally agreed
that the Crown Court has inherent power to protect its process from abuse. In Connelly v. DirectorChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

of Public Prosecutions[1964 AC 1254 : (1964) 2 WLR 1145 : (1964) 2 All ER 401 (HL)] Lord Devlin
stated that where particular criminal proceedings constitute an abuse of process, the court is
empowered to refuse to allow the indictment to proceed to trial. Lord Salmon in Director of Public
Prosecutions v. Humphrys [1977 AC 1 : (1976) 2 WLR 857 : (1976) 2 All ER 497 (HL)] stressed the
importance of the inherent power when he observed that it is only if the prosecution amounts to an
abuse of the process of the court and is oppressive and vexatious that the Judge has the power to
intervene. He further mentioned that the courts' power to prevent such abuse is of great
constitutional importance and should be jealously preserved."
(emphasis supplied)
114. The jurisdiction under Section 482 Cr.P.C. was construed as a crowning power to exercise
control over the administration of justice within its territorial jurisdiction by the Supreme Court in
State of Punjab v. Davinder Pal Singh Bhullar54:
"60. The rule of inherent powers has its source in the maxim quando lex aliquid alicui
concedit, concedere videtur id sine quo res ipsa esse non potest which means that
when the law gives anything to anyone, it gives also all those things without which the
thing itself could not exist. The order cannot be passed bypassing the procedure
prescribed by law. The court in exercise of its power under Section 482 CrPC cannot
direct a particular agency to investigate the matter or to investigate a case from a
particular angle or by a procedure not prescribed in CrPC. Such powers should be
exercised very sparingly to prevent abuse of process of any court. Courts must be
careful to see that their decision in exercise of this power is based on sound
principles.
61. To inhere means that it forms a necessary part and belongs as an attribute in the
nature of things. The High Court under Section 482 CrPC is crowned with a statutory
power to exercise control over the administration of justice in criminal proceedings
within its territorial jurisdiction. This is to ensure that proceedings undertaken under
CrPC are executed to secure the ends of justice. For this, the legislature has
empowered the High Court with an inherent authority which is repository under the
statute. The legislature therefore clearly intended the existence of such power in the
High Court to control proceedings initiated under CrPC. Conferment of such inherent
power might be necessary to prevent the miscarriage of justice and to prevent any
form of injustice. However, it is to be understood that it is neither divine nor
limitless. It is not to generate unnecessary indulgence. The power is to protect the
system of justice from being polluted during the administration of justice under the
Code.
(emphasis supplied)
62. The High Court can intervene where it finds the abuse of the process of any court
which means, that wherever an attempt to secure something by abusing the process isChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

located, the same can be rectified by invoking such power. There has to be a nexus
and a direct correlation to any existing proceeding, not foreclosed by any other form
under the Code, to the subject-matter for which such power is to be exercised."
115. The scope and the powers under Section 482 Cr.P.C. was discussed at length by the Supreme
Court in Gian Singh v. State of Punjab55, wherein need to consider the facts and circumstances of a
case to determine whether the inherent jurisdiction can be exercised was restated:
"53. Section 482 of the Code, as its very language suggests, saves the inherent power
of the High Court which it has by virtue of it being a superior court to prevent abuse
of the process of any court or otherwise to secure the ends of justice. It begins with
the words, "nothing in this Code" which means that the provision is an overriding
provision. These words leave no manner of doubt that none of the provisions of the
Code limits or restricts the inherent power. The guideline for exercise of such power
is provided in Section 482 itself i.e. to prevent abuse of the process of any court or
otherwise to secure the ends of justice. As has been repeatedly stated that Section 482
confers no new powers on the High Court; it merely safeguards existing inherent
powers possessed by the High Court necessary to prevent abuse of the process of any
court or to secure the ends of justice. It is equally well settled that the power is not to
be resorted to if there is specific provision in the Code for the redress of the grievance
of an aggrieved party. It should be exercised very sparingly and it should not be
exercised as against the express bar of law engrafted in any other provision of the
Code.
(emphasis supplied)
54. In different situations, the inherent power may be exercised in different ways to
achieve its ultimate objective. Formation of opinion by the High Court before it
exercises inherent power under Section 482 on either of the twin objectives, (i) to
prevent abuse of the process of any court, or (ii) to secure the ends of justice, is a sine
qua non.
55. In the very nature of its constitution, it is the judicial obligation of the High Court
to undo a wrong in course of administration of justice or to prevent continuation of
unnecessary judicial process. This is founded on the legal maxim quando lex aliquid
alicui concedit, conceditur et id sine qua res ipsa esse non potest. The full import of
which is whenever anything is authorised, and especially if, as a matter of duty,
required to be done by law, it is found impossible to do that thing unless something
else not authorised in express terms be also done, may also be done, then that
something else will be supplied by necessary intendment. Ex debito justitiae is inbuilt
in such exercise; the whole idea is to do real, complete and substantial justice for
which it exists. The power possessed by the High Court under Section 482 of the
Code is of wide amplitude but requires exercise with great caution and
circumspection. (emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

56. It needs no emphasis that exercise of inherent power by the High Court would
entirely depend on the facts and circumstances of each case. It is neither permissible
nor proper for the court to provide a straitjacket formula regulating the exercise of
inherent powers under Section 482. No precise and inflexible guidelines can also be
provided."
(emphasis supplied)
116. The scope of powers under Section 482 Cr.P.C. was interpreted in light of necessity of inherent
powers in a court for administration of justice in State of Karnataka v. M. Devendrappa56:
"6. Exercise of power under Section 482 of the Code in a case of this nature is the
exception and not the rule. The section does not confer any new powers on the High
Court. It only saves the inherent power which the Court possessed before the
enactment of the Code. It envisages three circumstances under which the inherent
jurisdiction may be exercised, namely, (i) to give effect to an order under the Code,
(ii) to prevent abuse of the process of court, and (iii) to otherwise secure the ends of
justice. It is neither possible nor desirable to lay down any inflexible rule which
would govern the exercise of inherent jurisdiction. No legislative enactment dealing
with procedure can provide for all cases that may possibly arise. Courts, therefore,
have inherent powers apart from express provisions of law which are necessary for
proper discharge of functions and duties imposed upon them by law. That is the
doctrine which finds expression in the section which merely recognizes and preserves
inherent powers of the High Courts. All courts, whether civil or criminal possess, in
the absence of any express provision, as inherent in their constitution, all such
powers as are necessary to do the right and to undo a wrong in course of
administration of justice on the principle quando lex aliquid alicui concedit,
concedere videtur et id sine quo res ipsae esse non potest (when the law gives a
person anything it gives him that without which it cannot exist). While exercising
powers under the section, the court does not function as a court of appeal or revision.
Inherent jurisdiction under the section though wide has to be exercised sparingly,
carefully and with caution and only when such exercise is justified by the tests
specifically laid down in the section itself. It is to be exercised ex debito justitiae to do
real and substantial justice for the administration of which alone courts exist.
Authority of the court exists for advancement of justice and if any attempt is made to
abuse that authority so as to produce injustice, the court has power to prevent abuse.
It would be an abuse of process of the court to allow any action which would result in
injustice and prevent promotion of justice. In exercise of the powers court would be
justified to quash any proceeding if it finds that initiation/continuance of it amounts
to abuse of the process of court or quashing of these proceedings would otherwise
serve the ends of justice. When no offence is disclosed by the complaint, the court
may examine the question of fact. When a complaint is sought to be quashed, it is
permissible to look into the materials to assess what the complainant has alleged and
whether any offence is made out even if the allegations are accepted in toto."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

117. Citing the higher purpose of ex debito justitiae the Supreme Court in Sushil Suri v. Central
Bureau of Investigation57, declined to lay down any inflexible rule which would restrict the exercise
of inherent jurisdiction:
"16. Section 482 CrPC itself envisages three circumstances under which the inherent
jurisdiction may be exercised by the High Court, namely, (i) to give effect to an order
under CrPC; (ii) to prevent an abuse of the process of court; and (iii) to otherwise
secure the ends of justice. It is trite that although the power possessed by the High
Court under the said provision is very wide but it is not unbridled. It has to be
exercised sparingly, carefully and cautiously, ex debito justitiae to do real and
substantial justice for which alone the Court exists. Nevertheless, it is neither feasible
nor desirable to lay down any inflexible rule which would govern the exercise of
inherent jurisdiction of the Court. Yet, in numerous cases, this Court has laid down
certain broad principles which may be borne in mind while exercising jurisdiction
under Section 482 CrPC. Though it is emphasised that exercise of inherent powers
would depend on the facts and circumstances of each case, but the common thread
which runs through all the decisions on the subject is that the Court would be
justified in invoking its inherent jurisdiction where the allegations made in the
complaint or charge-sheet, as the case may be, taken at their face value and accepted
in their entirety do not constitute the offence alleged."
(emphasis supplied)
118. Minu Kumari (supra) also advised caution while invoking section 482 Cr.P.C. but refrained
from laying down any hard and fast rule for exercise of extraordinary jurisdiction:
"20. As noted above, the powers possessed by the High Court under Section 482 of
the Code are very wide and the very plenitude of the power requires great caution in
its exercise. Court must be careful to see that its decision in exercise of this power is
based on sound principles. The inherent power should not be exercised to stifle a
legitimate prosecution. The High Court being the highest court of a State should
normally refrain from giving a prima facie decision in a case where the entire facts
are incomplete and hazy, more so when the evidence has not been collected and
produced before the Court and the issues involved, whether factual or legal, are of
magnitude and cannot be seen in their true perspective without sufficient material.
Of course, no hard-and-fast rule can be laid down in regard to cases in which the
High Court will exercise its extraordinary jurisdiction of quashing the proceeding at
any stage."
(emphasis supplied)
119. The law set its face against a narrow and pedantic approach while exercising inherent
jurisdiction and declining the relief on technical grounds in State v. M. Subrahmanyam58:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"10. The High Court was exercising inherent jurisdiction in the interest of justice and
to prevent the abuse of the process of law. In the facts and circumstances of the case,
the High Court ought to have exercised its inherent powers to allow the bringing of
the authorisation order on record rather than to have adopted a narrow and pedantic
approach to its own jurisdiction given the provisions of Sections 173(2) & (5)(a)
CrPC, as observed in R.S. Pai."
120. Similarly the Supreme Court in Janata Dal v. H.S. Chowdhary59 held:
"132. The criminal courts are clothed with inherent power to make such orders as
may be necessary for the ends of justice. Such power though unrestricted and
undefined should not be capriciously or arbitrarily exercised, but should be exercised
in appropriate cases, ex debito justitiae to do real and substantial justice for the
administration of which alone the courts exist. The powers possessed by the High
Court under Section 482 of the Code are very wide and the very plenitude of the
power requires great caution in its exercise. Courts must be careful to see that its
decision in exercise of this power is based on sound principles."
(emphasis supplied)
121. The importance of rendering reasoned judgments in application under Section 482 Cr.P.C. was
emphasised by the Supreme Court in Shree Mahavir Carbon Ltd. v. Om Prakash Jalan60:
"11. After all the High Court was setting aside the order of the subordinate court by
which the subordinate court had taken cognizance in the matter. This could be done
after appropriately dealing with the contentions of both the parties, more specially
when it was the first judicial review of the orders of the court below. In Hindustan
Times Ltd. v. Union of India [Hindustan Times Ltd. v. Union of India, (1998) 2 SCC
242 : 1998 SCC (L&S) 481] this Court made pertinent observation in the context:
(SCC p. 248, para 8) "8. In an article 'On Writing Judgments' [(1990) 64 ALJ 691
(Aust)] , Justice Michael Kirby of Australia has approachwed the problem from the
point of view of the litigant, the legal profession, the subordinate courts/tribunals,
the Brother Judges and the Judges' own conscience. To the litigant, the duty of the
Judge is to uphold his own integrity and let the losing party know why he lost the
case. The legal profession is entitled to have it demonstrated that the Judge had the
correct principles in mind, had properly applied them and is entitled to examine the
body of the judgment for the learning and precedent that they provide and for the
reassurance of the quality of the judiciary which is still the centrepiece of our
administration of justice. It does not take long for the profession to come to know,
including through the written pages of published judgments, the lazy Judge, the
Judge prone to errors of fact, etc. The reputational considerations are important for
the exercise of appellate rights, for the Judges' own self-discipline, for attempts at
improvement and the maintenance of the integrity and quality of our judiciary. From
the point of view of other Judges, the benefit that accrues to the lower hierarchy ofChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Judges and tribunals is of utmost importance. Justice Asprey of Australia has even
said in Petit v. Dankley [Petit v. Dankley, (1971) 1 NSWLR 376 (CA Aust)] that the
failure of a Court to give reasons is an encroachment upon the right of appeal given to
a litigant."
12. It was finally stated: (Hindustan Times Ltd. case [Hindustan Times Ltd. v. Union of India,
(1998) 2 SCC 242 : 1998 SCC (L&S) 481] , SCC p. 248, para 8) "8. ... In our view, the satisfaction
which a reasoned judgment gives to the losing party or his lawyer is the test of a good judgment.
Disposal of cases is no doubt important but quality of the judgment is equally, if not more,
important. There is no point in shifting the burden to the higher court either to support the
judgment by reasons or to consider the evidence or law for the first time to see if the judgment needs
a reversal."
(emphasis supplied) In that case, the order of dismissal of the writ petition by the High Court was
affirmed by us but the task fell on the Supreme Court, to inform the appellant why it had lost the
case in the High Court.
13. In the present case, we have avoided to do this exercise and have not gone into the merits of the
case to find out whether the conclusion of the High Court is correct or not, as the counsel for both
the parties have agreed for remand of the matter.
14 [Ed.: Para 14 corrected vide Official Corrigendum No. F.3/Ed.B.J./23/2014 dated 23-4-2014.] . It
is nowhere suggested by us that the judgment should be too lengthy or prolix and disproportionate
to the issue involved. However, it is to be borne in mind that the principal objective in giving
judgment is to make an effective, practical and workable decision. The court resolves conflict by
determining the merits of conflicting cases, and by choosing between notions of justice,
convenience, public policy, morality, analogy, and takes into account the opinions of other courts or
writers (precedents). Since the court is to come to a workable decision, its reasoning and conclusion
must be practical, suit the facts as found and provide an effective, workable remedy to the winner.
15. We are of the opinion that while recording the decision with clarity, the Court is also supposed to
record sufficient reasons in taking a particular decision or arriving at a particular conclusion. The
reasons should be such that they demonstrate that the decision has been arrived at on an objective
consideration.
16. When we talk of giving "reasons" in support of a judgment, what is meant by "reasons"? In the
context of legal decision-making, the focus is on what makes something a legal valid reason. Thus,
"reason would mean a justifying reason, or more simply a justification for a decision is a
consideration, in non-arbitrary ways in favour of making or accepting that decision. If there is no
justification in support of a decision, such a decision is without any reason or justifying reason.
17. We are not entering into a jurisprudential debate on the appropriate theory of legal reasoning. It
is not even a discourse on how to write judgments. Our intention is to simply demonstrate the
importance of legal reasoning in support of a particular decision. What we have highlighted is thatChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

instant is a case or arriving at a conclusion, in complete absence of reasons, what to talk of adequate
or good reasons that justify that conclusion.
18. In the given case, it was required by the High Court to take note of the arguments of the
complainant on the basis of which the complainant insisted that ingredients of the particular
offences alleged are prime facie established justifying the cognizance of the complaint and the
arguments of the respondents herein on the basis of which the respondents made an endeavour to
demonstrate that it was a pure civil dispute with no elements of criminality attached. Thereafter, the
conclusion should have been backed by reasons as to why the arguments of the complainant are
meritless and what is the rationale basis for accepting the case of the accused persons. We hope that
this aspect would be kept in mind by the High Court while deciding the case afresh."
122. The requirement to conform the principles of natural justice by giving adversary parties an
opportunity to file objections was iterated in Engineering Export Promotion Council v. Usha
Anand61.
123. The extraordinary powers conferred under Article 226 of the Constitution of India and the
inherent jurisdiction under Section 482 Cr.P.C. were put on a similar footing since the two were
created for the same elevated purpose i.e. ex debito justitiae but the Supreme Court did not lay down
any cast iron rule for exercise of such powers in Varala Bharath Kumar v. State of Telangana62 by
holding: 
"6. It is by now well settled that the extraordinary power under Article 226 or
inherent power under Section 482 of the Code of Criminal Procedure can be
exercised by the High Court, either to prevent abuse of process of the court or
otherwise to secure the ends of justice. Where allegations made in the first
information report/the complaint or the outcome of investigation as found in the
charge-sheet, even if they are taken at their face value and accepted in their entirety
do not prima facie constitute any offence or make out the case against the accused;
where the allegations do not disclose the ingredients of the offence alleged; where the
uncontroverted allegations made in the first information report or complaint and the
material collected in support of the same do not disclose the commission of offence
alleged and make out a case against the accused; where a criminal proceeding is
manifestly attended with mala fide and/or where the proceeding is maliciously
instituted with an ulterior motive for wreaking vengeance on the accused and with a
view to spite him due to private and personal grudge, the power under Article 226 of
the Constitution of India or under Section 482 of the Code of Criminal Procedure
may be exercised.
(emphasis supplied)
7. While exercising power under Section 482 or under Article 226 in such matters,
the court does not function as a court of appeal or revision. Inherent jurisdiction
under Section 482 of the Code though wide has to be exercised sparingly, carefully orChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

with caution and only when such exercise is justified by the tests specifically laid
down under Section 482 itself. It is to be exercised ex debito justitiae to do real and
substantial justice, for the administration of which alone courts exist. The court must
be careful and see that its decision in exercise of its power is based on sound
principles. The inherent powers should not be exercised to stifle a legitimate
prosecution. Of course, no hard-and-fast rule can be laid down in regard to cases in
which the High Court will exercise its extraordinary jurisdiction of quashing the
proceedings at any stage."
(emphasis supplied)
124. Similarly, the powers vested by virtue of Articles 226 and 227 of the Constitution of India and
those Section 482 Cr.P.C. were construed as analogous powers which were vested with the sole
purpose to achieve justice and not to frustrate it in State of Maharashtra v. Arun Gulab Gawali63 by
holding:
"13.....The provisions of Articles 226, 227 of the Constitution of India and Section 482
of the Code of Criminal Procedure, 1973 (hereinafter called as "CrPC") are a device to
advance justice and not to frustrate it. The power of judicial review is discretionary,
however, it must be exercised to prevent the miscarriage of justice and for correcting
some grave errors and to ensure that stream of administration of justice remains
clean and pure. However, there are no limits of power of the Court, but the more the
power, the more due care and caution is to be exercised in invoking these powers."
[Also See: State of W.B. v. Swapan Kumar Guha  (1982) 1 SCC 561;  Pepsi Foods Ltd. v. Special
Judicial Magistrate (1998) 5 SCC 749;  G. Sagar Suri v. State of U.P. (2000) 2 SCC 636 and Ajay
Mitra v. State of M.P. [(2003) 3 SCC 11].
125. The salutary purpose of inherent powers of the High Court under Section 482 Cr.P.C. and
extraordinary jurisdiction under Article 226 of the Constitution of India was outlined by the
Supreme Court in Kapil Agarwal v. Sanjay Sharma64 to equate both two jurisdictions by holding:
"18.1. As observed and held by this Court in a catena of decisions, inherent
jurisdiction under Section 482 CrPC and/or under Article 226 of the Constitution is
designed to achieve salutary purpose that criminal proceedings ought not to be
permitted to degenerate into weapon of harassment. When the Court is satisfied that
criminal proceedings amount to an abuse of process of law or that it amounts to
bringing pressure upon the accused, in exercise of inherent powers, such proceedings
can be quashed."
126. Abuse of the process of court and other extraordinary situations would create right conditions
for invoking the exercise of inherent and revisional jurisdictions and that the limitations created by
the courts in exercise of the same was nothing more than self restraint as held by the Supreme Court
in Raj Kapoor v. State65 by establishing the contours of law as under:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"10. The first question is as to whether the inherent power of the High Court under
Section 482 stands repelled when the revisional power under Section 397 overlaps.
The opening words of Section 482 contradict this contention because nothing of the
Code, not even Section 397, can affect the amplitude of the inherent power preserved
in so many terms by the language of Section 482. Even so, a general principle
pervades this branch of law when a specific provision is made: easy resort to inherent
power is not right except under compelling circumstances. Not that there is absence
of jurisdiction but that inherent power should not invade areas set apart for specific
power under the same Code. In Madhu Limaye case [Madhu Limaye v. State of
Maharashtra, (1977) 4 SCC 551 : 1978 SCC (Cri) 10 : AIR 1978 SC 47] this Court has
exhaustively and, if I may say so with great respect, correctly discussed and
delineated the law beyond mistake. While it is true that Section 482 is pervasive it
should not subvert legal interdicts written into the same Code, such, for instance, in
Section 397(2). Apparent conflict may arise in some situations between the two
provisions and a happy solution "would be to say that the bar provided in sub-section
(2) of Section 397 operates only in exercise of the revisional power of the High Court,
meaning thereby that the High Court will have no power of revision in relation to any
interlocutory order. Then in accordance with one or the other principles enunciated
above, the inherent power will come into play, there being no other provision in the
Code for the redress of the grievance of the aggrieved party. But then, if the order
assailed is purely of an interlocutory character which could be corrected in exercise of
the revisional power of the High Court under the 1898 Code, the High Court will
refuse to exercise its inherent power. But in case the impugned order clearly brings
about a situation which is an abuse of the process of the Court or for the purpose of
securing the ends of justice interference by the High Court is absolutely necessary,
then nothing contained in Section 397(2) can limit or affect the exercise of the
inherent power by the High Court. But such cases would be few and far between. The
High Court must exercise the inherent power very sparingly. One such case would be
the desirability of the quashing of a criminal proceeding initiated illegally, vexatiously
or as being without jurisdiction" [(1977) 4 SCC 551, 556, para 10 : AIR 1978 SC 47, 51]
.
In short, there is no total ban on the exercise of inherent power where abuse of the
process of the court or other extraordinary situation excites the court's jurisdiction.
The limitation is self-restraint, nothing more. The policy of the law is clear that
interlocutory orders, pure and simple, should not be taken up to the High Court
resulting in unnecessary litigation and delay. At the other extreme, final orders are
clearly capable of being considered in exercise of inherent power, if glaring injustice
stares the court in the face. In between is a tertium quid, as Untwalia, J. has pointed
out as for example, where it is more than a purely interlocutory order and less than a
final disposal. The present case falls under that category where the accused complain
of harassment through the court's process. Can we state that in this third category the
inherent power can be exercised? In the words of Untwalia, J.:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied) "The answer is obvious that the bar will not operate to prevent
the abuse of the process of the Court and/or to secure the ends of justice. The label of
the petition filed by an aggrieved party is immaterial. The High Court can examine
the matter in an appropriate case under its inherent powers. The present case
undoubtedly falls for exercise of the power of the High Court in accordance with
Section 482 of the 1973 Code, even assuming, although not accepting, that invoking
the revisional power of the High Court is impermissible."
127. Raj Kapoor (supra) was approved in Prabhu Chawla v. State of Rajasthan66. 
128. The Supreme Court provided some categories of cases by way of illustration where
extraordinary powers under Article 226 of the Constitution of India or inherent power under Section
482 Cr.P.C. could be exercised by the High Court in State of Haryana v. Bhajan Lal67 by expounding
the law as under:
"108. In the backdrop of the interpretation of the various relevant provisions of the
Code under Chapter XIV and of the principles of law enunciated by this Court in a
series of decisions relating to the exercise of the extraordinary power under
Article 226 or the inherent powers under Section 482 of the Code which we have
extracted and reproduced above, we give the following categories of cases by way of
illustration wherein such power could be exercised either to prevent abuse of the
process of any court or otherwise to secure the ends of justice, though it may not be
possible to lay down any precise, clearly defined and sufficiently channelised and
inflexible guidelines or rigid formulae and to give an exhaustive list of myriad kinds
of cases wherein such power should be exercised.
(1) Where the allegations made in the first information report or the complaint, even
if they are taken at their face value and accepted in their entirety do not prima facie
constitute any offence or make out a case against the accused.
(2) Where the allegations in the first information report and other materials, if any,
accompanying the FIR do not disclose a cognizable offence, justifying an
investigation by police officers under Section 156(1) of the Code except under an
order of a Magistrate within the purview of Section 155(2) of the Code.
(3) Where the uncontroverted allegations made in the FIR or complaint and the
evidence collected in support of the same do not disclose the commission of any
offence and make out a case against the accused.
(4) Where, the allegations in the FIR do not constitute a cognizable offence but
constitute only a non-cognizable offence, no investigation is permitted by a police
officer without an order of a Magistrate as contemplated under Section 155(2) of the
Code.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(5) Where the allegations made in the FIR or complaint are so absurd and inherently
improbable on the basis of which no prudent person can ever reach a just conclusion
that there is sufficient ground for proceeding against the accused.
(6) Where there is an express legal bar engrafted in any of the provisions of the Code
or the Act concerned (under which a criminal proceeding is instituted) to the
institution and continuance of the proceedings and/or where there is a specific
provision in the Code or the Act concerned, providing efficacious redress for the
grievance of the aggrieved party.
(7) Where a criminal proceeding is manifestly attended with mala fide and/or where
the proceeding is maliciously instituted with an ulterior motive for wreaking
vengeance on the accused and with a view to spite him due to private and personal
grudge.
109. We also give a note of caution to the effect that the power of quashing a criminal proceeding
should be exercised very sparingly and with circumspection and that too in the rarest of rare cases;
that the court will not be justified in embarking upon an enquiry as to the reliability or genuineness
or otherwise of the allegations made in the FIR or the complaint and that the extraordinary or
inherent powers do not confer an arbitrary jurisdiction on the court to act according to its whim or
caprice."
(emphasis supplied)
129. A more categorical pronouncement acknowledging the overlap in the extraordinary
jurisdictions under Article 226 and 227 of the Constitution of India and inherent powers under
Section 482 Cr.P.C. was made by the Supreme Court in Pepsi Foods Ltd. and another Vs. Special
Judicial Magistrate and others68. In Pepsi Foods (supra) the nomenclature of the petition was held
not relevant, as the said powers are devised to advance justice and not to frustrate it:
"22. It is settled that the High Court can exercise its power of judicial review in
criminal matters. In State of Haryana v. Bhajan Lal [1992 Supp (1) SCC 335 : 1992
SCC (Cri) 426 : JT (1990) 4 SC 650] this Court examined the extraordinary power
under Article 226 of the Constitution and also the inherent powers under Section 482
of the Code which it said could be exercised by the High Court either to prevent abuse
of the process of any court or otherwise to secure the ends of justice. While laying
down certain guidelines where the court will exercise jurisdiction under these
provisions, it was also stated that these guidelines could not be inflexible or laying
rigid formulae to be followed by the courts. Exercise of such power would depend
upon the facts and circumstances of each case but with the sole purpose to prevent
abuse of the process of any court or otherwise to secure the ends of justice. One of
such guidelines is where the allegations made in the first information report or the
complaint, even if they are taken at their face value and accepted in their entirety do
not prima facie constitute any offence or make out a case against the accused. UnderChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Article 227 the power of superintendence by the High Court is not only of
administrative nature but is also of judicial nature. This article confers vast powers
on the High Court to prevent the abuse of the process of law by the inferior courts
and to see that the stream of administration of justice remains clean and pure. The
power conferred on the High Court under Articles 226 and 227 of the Constitution
and under Section 482 of the Code have no limits but more the power more due care
and caution is to be exercised while invoking these powers. When the exercise of
powers could be under Article 227 or Section 482 of the Code it may not always be
necessary to invoke the provisions of Article 226. Some of the decisions of this Court
laying down principles for the exercise of powers by the High Court under Articles
226 and 227 may be referred to.
26. Nomenclature under which petition is filed is not quite relevant and that does not
debar the court from exercising its jurisdiction which otherwise it possesses unless
there is special procedure prescribed which procedure is mandatory. If in a case like
the present one the court finds that the appellants could not invoke its jurisdiction
under Article 226, the court can certainly treat the petition as one under Article 227
or Section 482 of the Code. It may not however, be lost sight of that provisions exist
in the Code of revision and appeal but some time for immediate relief Section 482 of
the Code or Article 227 may have to be resorted to for correcting some grave errors
that might be committed by the subordinate courts. The present petition though filed
in the High Court as one under Articles 226 and 227 could well be treated under
Article 227 of the Constitution.
(emphasis supplied)
30. It is no comfortable thought for the appellants to be told that they could appear
before the court which is at a far off place in Ghazipur in the State of Uttar Pradesh,
seek their release on bail and then to either move an application under Section
245(2) of the Code or to face trial when the complaint and the preliminary evidence
recorded makes out no case against them. It is certainly one of those cases where
there is an abuse of the process of the law and the courts and the High Court should
not have shied away in exercising their jurisdiction. Provisions of Articles 226 and
227 of the Constitution and Section 482 of the Code are devised to advance justice
and not to frustrate it. In our view the High Court should not have adopted such a
rigid approach which certainly has led to miscarriage of justice in the case. Power of
judicial review is discretionary but this was a case where the High Court should have
exercised it."
(emphasis supplied)
130. Advancement of justice and prevention of abuse of the process of court were outlined as the
existential purposes of courts in State of Orissa v. Saroj Kumar Sahoo69  and use of powers under
Section 482 Cr.P.C. were set forth as under:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"8. ... While exercising the powers under the section, the court does not function as a
court of appeal or revision. Inherent jurisdiction under the section though wide has
to be exercised sparingly, carefully and with caution and only when such exercise is
justified by the tests specifically laid down in the section itself. It is to be exercised ex
debito justitiae to do real and substantial justice for the administration of which
alone the courts exist. Authority of the court exists for advancement of justice and if
any attempt is made to abuse that authority so as to produce injustice, the court has
power to prevent abuse. It would be an abuse of process of the court to allow any
action which would result in injustice and prevent promotion of justice. In exercise of
the powers the court would be justified to quash any proceeding if it finds that
initiation/continuance of it amounts to abuse of the process of court or quashing of
these proceedings would otherwise serve the ends of justice. When no offence is
disclosed by the report, the court may examine the question of fact. When a report is
sought to be quashed, it is permissible to look into the materials to assess what the
report has alleged and whether any offence is made out even if the allegations are
accepted in toto."
(emphasis supplied)
131. Saroj Kumar Sahoo (supra) was followed by the Supreme Court in Mahendra K.C. v. State of
Karnataka70, to hold that the High Court in exercise of powers under Section 482 Cr.P.C. can issue
orders to prevent abuse of legal process or otherwise secure the ends of justice. [Also see: Parbatbhai
Aahir v. State of Gujarat, (2017) 9 SCC 641; R. Kalyani v. Janak C. Mehta, (2009) 1 SCC 516;
Pratibha v. Rameshwari Devi, (2007) 12 SCC 369; and Dinesh Dutt Joshi v. State of Rajasthan,
(2001) 8 SCC 570].
132. The Supreme Court in Inder Mohan Goswami v. State of Uttaranchal71, advocated invocation of
inherent powers to advance justice and prevent injustice whenever abuse of the process leading to
injustice is brought to the notice of the court:
"23. This Court in a number of cases has laid down the scope and ambit of courts'
powers under Section 482 CrPC. Every High Court has inherent power to act ex
debito justitiae to do real and substantial justice, for the administration of which
alone it exists, or to prevent abuse of the process of the court. Inherent power under
Section 482 CrPC can be exercised:
(i) to give effect to an order under the Code;
(ii) to prevent abuse of the process of court, and
(iii) to otherwise secure the ends of justice.
24. Inherent powers under Section 482 CrPC though wide have to be exercised sparingly, carefully
and with great caution and only when such exercise is justified by the tests specifically laid down inChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

this section itself. Authority of the court exists for the advancement of justice. If any abuse of the
process leading to injustice is brought to the notice of the court, then the court would be justified in
preventing injustice by invoking inherent powers in absence of specific provisions in the statute."
(emphasis supplied)
133. Criminal proceedings arising out of certain offences were terminated in Gian Singh v. State of
Punjab72 after identifying certain categories of cases and the fact that the parties had arrived at a
compromise by holding:
"61. ... Inherent power is of wide plenitude with no statutory limitation but it has to
be exercised in accord with the guideline engrafted in such power viz. : (i) to secure
the ends of justice, or (ii) to prevent abuse of the process of any court. In what cases
power to quash the criminal proceeding or complaint or FIR may be exercised where
the offender and the victim have settled their dispute would depend on the facts and
circumstances of each case and no category can be prescribed. However, before
exercise of such power, the High Court must have due regard to the nature and
gravity of the crime. Heinous and serious offences of mental depravity or offences
like murder, rape, dacoity, etc. cannot be fittingly quashed even though the victim or
victim's family and the offender have settled the dispute. Such offences are not
private in nature and have a serious impact on society. Similarly, any compromise
between the victim and the offender in relation to the offences under special statutes
like the Prevention of Corruption Act or the offences committed by public servants
while working in that capacity, etc.; cannot provide for any basis for quashing
criminal proceedings involving such offences. But the criminal cases having
overwhelmingly and predominatingly civil flavour stand on a different footing for the
purposes of quashing, particularly the offences arising from commercial, financial,
mercantile, civil, partnership or such like transactions or the offences arising out of
matrimony relating to dowry, etc. or the family disputes where the wrong is basically
private or personal in nature and the parties have resolved their entire dispute. In
this category of cases, the High Court may quash the criminal proceedings if in its
view, because of the compromise between the offender and the victim, the possibility
of conviction is remote and bleak and continuation of the criminal case would put the
accused to great oppression and prejudice and extreme injustice would be caused to
him by not quashing the criminal case despite full and complete settlement and
compromise with the victim. In other words, the High Court must consider whether it
would be unfair or contrary to the interest of justice to continue with the criminal
proceeding or continuation of the criminal proceeding would tantamount to abuse of
process of law despite settlement and compromise between the victim and the
wrongdoer and whether to secure the ends of justice, it is appropriate that the
criminal case is put to an end and if the answer to the above question(s) is in the
affirmative, the High Court shall be well within its jurisdiction to quash the criminal
proceeding."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
134. Noticing the tendency of unscrupulous litigants to abuse the process of court and use the
criminal justice system as a weapon of harassment, the Supreme Court in Birla Corpn. Ltd. v.
Adventz Investments & Holdings Ltd.73 emphasised the need to employ the inherent powers under
Section 482 Cr.P.C. as a tool of justice by holding:
"84. It is well settled that the inherent jurisdiction under Section 482 CrPC is
designed to achieve a salutary purpose and that the criminal proceedings ought not to
be permitted to degenerate into a weapon of harassment. When the Court is satisfied
that the criminal proceedings amount to an abuse of process of law or that it amounts
to bringing pressure upon the accused, in exercise of the inherent powers, such
proceedings can be quashed."
135. The need to exercise the powers under Section 482 Cr.P.C. to prevent the judicial process from
being used as an instrument of harassment in the hands of frustrated litigants was held to be not
only desirable but necessary by the Supreme Court in S.W. Palanitkar v. State of Bihar74:
"27. In the case on hand, we have already stated above that except against Appellant
7, no offence was made out against the remaining appellants as the ingredients of
offences alleged against them were not satisfied. Unfortunately, the High Court failed
to exercise jurisdiction under Section 482 CrPC to correct manifest error committed
by the learned Magistrate in issuing process against Appellants 1-6 and 8 when the
alleged acts against them did not constitute offences for want of satisfying the
ingredients of the offences. The approach and considerations while exercising power
and jurisdiction by a Magistrate at the time of issuing process are to be in terms of
Sections 200 to 203 under Chapter XV CrPC, having due regard to the position of law
explained in various decisions of this Court, and whereas while exercising power
under Section 482 CrPC the High Court has to look at the object and purpose for
which such power is conferred on it under the said provision. Exercise of inherent
power is available to the High Court to give effect to any order under CrPC, or to
prevent abuse of the process of any court or otherwise to secure the ends of justice.
This being the position, exercise of power under Section 482 CrPC should be
consistent with the scope and ambit of the same in the light of the decisions
aforementioned. In appropriate cases, to prevent judicial process from being an
instrument of oppression or harassment in the hands of frustrated or vindictive
litigants, exercise of inherent power is not only desirable but necessary also, so that
the judicial forum of court may not be allowed to be utilized for any oblique motive.
When a person approaches the High Court under Section 482 CrPC to quash the very
issue of process, the High Court on the facts and circumstances of a case has to
exercise the powers with circumspection as stated above to really serve the purpose
and object for which they are conferred."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

136. In Krishna Lal Chawla v. State of U.P.75 the Supreme Court reiterated the fundamental rights
of the individual to be free from frivolous and repeated criminal prosecution forced upon him by the
might of the State or by vexatious complaints. Consequences of frivolous criminal litigation, the
powers and duties of the courts in such situations was underscored thus :
"10. Article 21 of the Constitution guarantees that the right to life and liberty shall not
be taken away except by due process of law. Permitting multiple complaints by the
same party in respect of the same incident, whether it involves a cognizable or private
complaint offence, will lead to the accused being entangled in numerous criminal
proceedings. As such, he would be forced to keep surrendering his liberty and
precious time before the police and the courts, as and when required in each case. As
this Court has held in Amitbhai Anilchandra Shah [Amitbhai Anilchandra
Shah v. CBI, (2013) 6 SCC 348 : (2014) 1 SCC (Cri) 309] , such an absurd and
mischievous interpretation of the provisions of the CrPC will not stand the test of
constitutional scrutiny, and therefore cannot be adopted by us.
12. Thus, it is incumbent upon this Court to preserve this delicate balance between
the power to investigate offences under the CrPC, and the fundamental right of the
individual to be free from frivolous and repetitive criminal prosecutions forced upon
him by the might of the State. If Respondent 2 was aggrieved by lack of speedy
investigation in the earlier case filed by him, the appropriate remedy would have
been to apply to the Magistrate under Section 155(2) CrPC for directions to the police
in this regard. Filing a private complaint without any prelude, after a gap of six years
from the date of giving information to the police, smacks of mala fides on the part of
Respondent 2.
(emphasis supplied)
22. Frivolous litigation should not become the order of the day in India. From
misusing the public interest litigation jurisdiction of the Indian courts to abusing the
criminal procedure for harassing their adversaries, the justice delivery system should
not be used as a tool to fulfil personal vendetta. The Indian judiciary has taken
cognizance of this issue. In 2014, this Court elucidated as follows, the plight of a
litigant caught in the cobweb of frivolous proceedings in Subrata Roy Sahara v. Union
of India [Subrata Roy Sahara v. Union of India, (2014) 8 SCC 470 : (2014) 4 SCC
(Civ) 424 : (2014) 3 SCC (Cri) 712] : (SCC p. 642, para 191) (emphasis supplied) "191.
... One needs to keep in mind, that in the process of litigation, there is an innocent
sufferer on the other side, of every irresponsible and senseless claim. He suffers long
drawn anxious periods of nervousness and restlessness, whilst the litigation is
pending, without any fault on his part. He pays for the litigation, from out of his
savings (or out of his borrowings), worrying that the other side may trick him into
defeat, for no fault of his. He spends invaluable time briefing counsel and preparing
them for his claim. Time which he should have spent at work, or with his family, is
lost, for no fault of his."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

While the Court's ruling pertained to civil proceedings, these observations ring true for the criminal
justice machinery as well. We note, with regret, that 7 years hence, and there has still been no
reduction in such plight. A falsely accused person not only suffers monetary damages but is exposed
to disrepute and stigma from society. While running from pillar to post to find a lawyer to represent
his case and arranging finances to defend himself before the court of law, he loses a part of himself."
137. The Supreme Court in Krishna Lal Chawla (supra) invoked Article 142 of the Constitution of
India to quash frivolous criminal proceedings or those instituted with oblique or vengeful or
malafide motives and also noticed earlier decisions on use of Section 482 Cr.P.C. by the High Courts
for the same cause:
"27. This Court's inherent powers under Article 142 of the Constitution to do
"complete justice" empowers us to give preference to equity and a justice-oriented
approach over the strict rigours of procedural law (State of Punjab v. Rafiq
Masih [State of Punjab v. Rafiq Masih, (2014) 8 SCC 883 : (2014) 4 SCC (Civ) 657 :
(2014) 6 SCC (Cri) 154 : (2014) 3 SCC (L&S) 134] ). This Court has used this inherent
power to quash criminal proceedings where the proceedings are instituted with an
oblique motive, or on manufactured evidence (Monica Kumar v. State of
U.P. [Monica Kumar v. State of U.P., (2008) 8 SCC 781 : (2008) 3 SCC (Cri) 649] ).
Other decisions have held that inherent powers of High Courts provided in Section
482 CrPC may be utilised to quash criminal proceedings instituted after great delay,
or with vengeful or mala fide motives. (Sirajul v. State of U.P. [Sirajulv. State of U.P.,
(2015) 9 SCC 201 : (2015) 3 SCC (Cri) 749] ; State of Haryana v. Bhajan Lal [State of
Haryana v. Bhajan Lal, 1992 Supp (1) SCC 335 : 1992 SCC (Cri) 426 : AIR 1992 SC
604] .) Thus, it is the constitutional duty of this Court to quash criminal proceedings
that were instituted by misleading the court and abusing its processes of law, only
with a view to harass the hapless litigants."
138. The need to check frivolous criminal complaints and to nip such litigation in the bud was
emphasized by the Supreme Court in Deepak Gaba and others Vs. State of Uttar Pradesh and
another76 by holding:
"28. ....Pertinently, this Court, in a number of cases, has noticed attempts made by
parties to invoke jurisdiction of criminal courts, by filing vexatious criminal
complaints by camouflaging allegations which were ex facie outrageous or pure civil
claims. These attempts are not to be entertained and should be dismissed at the
threshold. To avoid prolixity, we would only like to refer to the judgment of this Court
in Thermax Ltd. v. K.M. Johny [Thermax Ltd. v. K.M. Johny, (2011) 13 SCC 412 :
(2012) 2 SCC (Cri) 650] , as it refers to earlier case laws in copious detail."
139. The Supreme Court in R. Nagender Yadav v. State of Telangana77 laid down that the purpose of
inherent jurisdiction was to prevent abuse of the process of court and otherwise to secure the ends
of justice:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"19. While exercising its jurisdiction under Section 482CrPC, the High Court has to
be conscious that this power is to be exercised sparingly and only for the purpose of
prevention of abuse of the process of the court or otherwise to secure the ends of
justice. Whether a complaint discloses a criminal offence or not, depends upon the
nature of the act alleged thereunder. Whether the essential ingredients of a criminal
offence are present or not, has to be judged by the High Court. A complaint disclosing
civil transaction may also have a criminal texture. But the High Court must see
whether the dispute which is in substance of a civil nature is given a cloak of a
criminal offence. In such a situation, if civil remedy is available and is in fact adopted,
as has happened in the case on hand, the High Court should have quashed the
criminal proceeding to prevent abuse of process of court."
140. Converting civil cases into the criminal proceedings was construed to be an abuse of the process
of court in Rajib Ranjan v. R. Vijaykumar78.
141. In B.S. Joshi v. State of Haryana, (2003) 4 SCC 675 ; Manoj Sharma v. State, (2008) 16 SCC 1;
Nikhil Merchant v. CBI, (2008) 9 SCC 677; Shiji v. Radhika, (2011) 10 SCC 705, it was held that the
High Court may quash proceedings exercising powers under Section 482 Cr.P.C. and the same are
not limited by Section 320 of the Cr.P.C.
142. The Supreme Court in State of Karnataka v. L. Muniswamy79 discussed the salutatory public
purpose of inherent powers to appreciate the width and contours of that salient jurisdiction:
"7......In the exercise of this wholesome power, the High Court is entitled to quash a
proceeding if it comes to the conclusion that allowing the proceeding to continue
would be an abuse of the process of the Court or that the ends of justice require that
the proceeding ought to be quashed. The saving of the High Court's inherent powers,
both in civil and criminal matters, is designed to achieve a salutary public purpose
which is that a court proceeding ought not to be permitted to degenerate into a
weapon of harassment or persecution. In a criminal case, the veiled object behind a
lame prosecution, the very nature of the material on which the structure of the
prosecution rests and the like would justify the High Court in quashing the
proceeding in the interest of justice. The ends of justice are higher than the ends of
mere law though justice has got to be administered according to laws made by the
legislature. The compelling necessity for making these observations is that without a
proper realisation of the object and purpose of the provision which seeks to save the
inherent powers of the High Court to do justice, between the State and its subjects, it
would be impossible to appreciate the width and contours of that salient
jurisdiction."
(emphasis supplied)
143. There is something so right and obvious about the inherent powers of superior courts that they
are traced by ancient authorities as those plenary powers which were vested when the superiorChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

courts came into existence. Inherent powers exist because the superior courts are there.
144. Cases in point also advert to the fact that Section 482 Cr.P.C. did not infact confer any power
but only recognised that such powers inhered in superior courts.
145. Article 225 saved the aforesaid power under Section 482 Cr.P.C. which inhered in the High
Courts prior to the Constitution.
146. The nature and ambit of these powers has been settled by long line of consistent cases in point.
The powers are exercised ex debito justitiae, and to prevent miscarriage of justice for which alone
the courts exist. The power is also used to thwart abuse of process of court at the very inception.
147. Inherent powers are plenary in scope. By their very nature inherent powers elude specific
definitions and are incapable of being cast into rigid formulae. Courts have never attempted to limit
or to catalogue such powers, but simultaneously advocated caution and self restraint in its exercise.
Cases in point have left it to the Courts to decide the manner of use of these powers in the facts and
circumstances of a case. The grant of interim orders to serve the ends of justice has also been traced
to inherent powers.
148. Inherent powers under Section 482 Cr.P.C. and the jurisdictions of the Court under Articles
226 and 227 of the Constitution of India may be distinct in some ways but also have many
commonalities of purpose and overlap in usage. In many instances, the same relief can be sought in
either of the jurisdictions. Institution of separate proceedings under these jurisdictions is only a rule
of self restraint and convenience in orderly judicial procedure.
149. Nomenclature of the jurisdiction be it an application under Section 482 Cr.P.C or an
application under Articles 226 and 227 may not matter if the powers are being used to fulfill the
crowning purpose of acting ex debito justitiae and to prevent abuse of process of court.
150. The preceding discussion highlights that the plenary powers under inherent jurisdiction
(Section 482 Cr.P.C.) and extraordinary jurisdictions (under Article 226 and Article 227 of the
Constitution of India) provide the High Courts with the capacity of administration of justice, while
the exercise of these jurisdictions prove the quality of administration of justice.
151. More importantly the narrative also provides an insight into the consequences of curtailment of
powers under Article 226, Article 227 of the Constitution of India and Section 482 Cr.P.C. which the
legislature has not restricted and the Constitutional Courts never downsized.
V (C). Basic Structure:
152. The proposition that the jurisdiction conferred on the High court under Articles 226 and 227 of
the Constitution of India was part of the basic structure of the Constitution arose squarely for
consideration before a Bench of Seven Judges of the Supreme Court in L. Chandra Kumar v. Union
of India80. L. Chandra Kumar (supra) entrenched judicial review under Article 226 of theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Constitution of India and the judicial superintendence of High Courts over decisions of Courts and
Tribunal under Article 227 of the Constitution of India in the basic structure of the Constitution of
India:
"76. To express our opinion on the issue whether the power of judicial review vested
in the High Courts and in the Supreme Court under Articles 226/227 and 32 is part of
the basic structure of the Constitution, we must first attempt to understand what
constitutes the basic structure of the Constitution. The doctrine of basic structure was
evolved in Kesavananda Bharati case [(1973) 4 SCC 225] . However, as already
mentioned, that case did not lay down that the specific and particular features
mentioned in that judgment alone would constitute the basic structure of our
Constitution. Indeed, in the judgments of Shelat and Grover, JJ., Hegde and
Mukherjea, JJ. and Jaganmohan Reddy, J., there are specific observations to the
effect that their list of essential features comprising the basic structure of the
Constitution are illustrative and are not intended to be exhaustive. In Indira Gandhi
case [1975 Supp SCC 1] , Chandrachud, J. held that the proper approach for a Judge
who is confronted with the question whether a particular facet of the Constitution is
part of the basic structure, is to examine, in each individual case, the place of the
particular feature in the scheme of our Constitution, its object and purpose, and the
consequences of its denial on the integrity of our Constitution as a fundamental
instrument for the governance of the country. (supra at pp. 751-752). This approach
was specifically adopted by Bhagwati, J. in Minerva Mills case [(1980) 3 SCC 625] (at
pp. 671-672) and is not regarded as the definitive test in this field of Constitutional
Law.
77. We find that the various factors mentioned in the test evolved by Chandrachud, J.
have already been considered by decisions of various Benches of this Court that have
been referred to in the course of our analysis. From their conclusions, many of which
have been extracted by us in toto, it appears that this Court has always considered the
power of judicial review vested in the High Courts and in this Court under Articles
226 and 32 respectively, enabling legislative action to be subjected to the scrutiny of
superior courts, to be integral to our constitutional scheme. While several judgments
have made specific references to this aspect [Gajendragadkar, C.J. in Keshav Singh
case [(1965) 1 SCR 413 : AIR 1965 SC 745] , Beg, J. and Khanna, J. in Kesavananda
Bharati case [(1973) 4 SCC 225] , Chandrachud, C.J. and Bhagwati, J. in Minerva
Mills [(1980) 3 SCC 625] , Chandrachud, C.J. in Fertilizer Kamgar [(1981) 1 SCC 568]
, K.N. Singh, J. in Delhi Judicial Service Assn. [(1991) 4 SCC 406] , etc.] the rest have
made general observations highlighting the significance of this feature.
78. The legitimacy of the power of courts within constitutional democracies to review
legislative action has been questioned since the time it was first conceived. The
Constitution of India, being alive to such criticism, has, while conferring such power
upon the higher judiciary, incorporated important safeguards. An analysis of the
manner in which the Framers of our Constitution incorporated provisions relating toChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the judiciary would indicate that they were very greatly concerned with securing the
independence of the judiciary. [ See Chapter VII, "The Judiciary and the Social
Revolution" in Granville Austin, The Indian Constitution : Cornerstone of a Nation,
Oxford University Press, 1972; the chapter includes exhaustive references to the
relevant preparatory works and debates in the Constituent Assembly.] These
attempts were directed at ensuring that the judiciary would be capable of effectively
discharging its wide powers of judicial review. While the Constitution confers the
power to strike down laws upon the High Courts and the Supreme Court, it also
contains elaborate provisions dealing with the tenure, salaries, allowances,
retirement age of Judges as well as the mechanism for selecting Judges to the
superior courts. The inclusion of such elaborate provisions appears to have been
occasioned by the belief that, armed by such provisions, the superior courts would be
insulated from any executive or legislative attempts to interfere with the making of
their decisions. The Judges of the superior courts have been entrusted with the task
of upholding the Constitution and to this end, have been conferred the power to
interpret it. It is they who have to ensure that the balance of power envisaged by the
Constitution is maintained and that the legislature and the executive do not, in the
discharge of their functions, transgress constitutional limitations. It is equally their
duty to oversee that the judicial decisions rendered by those who man the
subordinate courts and tribunals do not fall foul of strict standards of legal
correctness and judicial independence. The constitutional safeguards which ensure
the independence of the Judges of the superior judiciary, are not available to the
Judges of the subordinate judiciary or to those who man tribunals created by
ordinary legislations. Consequently, Judges of the latter category can never be
considered full and effective substitutes for the superior judiciary in discharging the
function of constitutional interpretation. We, therefore, hold that the power of
judicial review over legislative action vested in the High Courts under Article 226 and
in this Court under Article 32 of the Constitution is an integral and essential feature
of the Constitution, constituting part of its basic structure. Ordinarily, therefore, the
power of High Courts and the Supreme Court to test the constitutional validity of
legislations can never be ousted or excluded.
79. We also hold that the power vested in the High Courts to exercise judicial
superintendence over the decisions of all courts and tribunals within their respective
jurisdictions is also part of the basic structure of the Constitution. This is because a
situation where the High Courts are divested of all other judicial functions apart from
that of constitutional interpretation, is equally to be avoided."
153. Following the judgment rendered in L. Chandra Kumar (supra), the Supreme Court in Union of
India and Others vs. Parashotam Dass81 affirmed judicial review as part of the basic structure of the
Constitution and emphasized the distinction between self-restraint of the High Court under Article
226 and an embargo on the High Court to exercise such jurisdiction:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"25. While we agree with the aforesaid principle, we are unable to appreciate the
observations in the case of Major General Shri Kant Sharma, which sought to put an
embargo on the exercise of jurisdiction under Article 226 of the Constitution, diluting
a very significant provision of the Constitution which also forms the part of basic
structure. The principles of basic structure have withstood the test of time and are
emphasized in many judicial pronouncements as an ultimate test. This is not
something that can be doubted. That being the position, the self-restraint of the High
Court under Article 226 of the Constitution is distinct from putting an embargo on
the High Court in exercising this jurisdiction under Article 226 of
the Constitution while judicially reviewing a decision arising from an order of the
Tribunal.
26. On the legislature introducing the concept of "Tribunalisation" (one may say that
this concept has seen many question marks vis-a-vis different tribunals, though it has
also produced some successes), the same was tested in L. Chandra Kumar case before
a Bench of seven Judges of this Court. Thus, while upholding the principles of
"Tribunalisation" under Article 323A or Article 323B, the Bench was unequivocally of
the view that decisions of Tribunals would be subject to the jurisdiction of the High
Court under Article 226 of the Constitution, and would not be restricted by the
42ndConstitutional Amendment which introduced the aforesaid two Articles. In our
view, this should have put the matter to rest, and no Bench of less than seven Judges
could have doubted the proposition. The need for the observations in the five-Judges'
Bench in Rojer Mathew case qua the Armed Forces Tribunal really arose because of
the observations made in Major General Shri Kant Sharma Thus, it is, reiterated and
clarified that the power of the High Court under Article 226 of the Constitution is not
inhibited, and superintendence and control under Article 227 of the Constitution are
somewhat distinct from the powers of judicial review under Article 226 of
the Constitution.
29. We believe that there is no necessity to carve out certain cases from the scope of
judicial review under Article 226 of the Constitution, as was suggested by the learned
Additional Solicitor General. It was enunciated in the Constitution Bench judgment
in S.N. Mukherjee case that even in respect of courts-martial, the High Court could
grant appropriate relief in a certain scenario as envisaged therein, i.e., "if the said
proceedings have resulted in denial of the fundamental rights guaranteed under Part
III of the Constitution or if the said proceedings suffer from a jurisdictional error or
any error of law apparent on the face of the record."
30. How can courts countenance a scenario where even in the aforesaid position, a party is left
remediless? It would neither be legal nor appropriate for this Court to say something to the contrary
or restrict the aforesaid observation enunciated in the Constitution Bench judgment in S.N.
Mukherjee case. We would loath to carve out any exceptions, including the ones enumerated by the
learned Additional Solicitor General extracted aforesaid as irrespective of the nature of the matter, if
there is a denial of a fundamental right under Part III of the Constitution or there is a jurisdictionalChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

error or error apparent on the face of the record, the High Court can exercise its jurisdiction. There
appears to be a misconception that the High Court would re-appreciate the evidence, thereby
making it into a second appeal, etc. We believe that the High Courts are quite conscious of the
parameters within which the jurisdiction is to be exercised, and those principles, in turn, are also
already enunciated by this Court.
32. We have, thus, no hesitation in concluding that the judgment in Major General Shri Kant
Sharma case does not lay down the correct law and is in conflict with judgments of the Constitution
Benches rendered prior and later to it, including in L. Chandra Kumar case, S.N. Mukherjee case,
and Rojer Mathew case making it abundantly clear that there is no per se restriction on the exercise
of power under Article 226 of the Constitution by the High Court. However, in respect of matters of
self-discipline, the principles already stand enunciated."
154. The submissions of the learned counsels at the Bar are grounded in the holdings of the Supreme
Court in L. Chandra Kumar (supra) and Parashotam Dass (supra). Powers to grant, alter or vary
interim orders flow from Articles 226 and 227 of the Constitution of India. According to the learned
counsels, the directions in Paras 34, 36, 37 of Asian Resurfacing (supra) damage the Basic Structure
of the Constitution of India by curtailing the said powers. The magnitude of the impact on the
administration of justice by the High Court consequent to the abridgement of its powers by the said
directions in Asian Resurfacing (supra), vindicates the Basic Structure doctrine. Since the Basic
Structure of the Constitution has to be protected at all costs, the submissions of the learned counsels
do give rise to substantial questions as to interpretation of the Constitution.
VI. SUPREME COURT
155. The Supreme Court is the highest court of the land. The Supreme Court has been constituted as
a Court of record under Article 129 of the Constitution of India. The Supreme Court exercises
appellate jurisdiction over all High Courts. The Supreme Court also possesses original jurisdiction in
certain matters. There are other distinctive provisions relating to the Supreme Court contained in
Chapter IV of the Constitution of India. However, for the purposes of this controversy, three
provisions are of relevance.
156. Under Article 141 of the Constitution of India the law declared by the Supreme Court is binding
on all courts. Article 142 of the Constitution of India vests the Supreme Court with plenary powers
for doing complete justice in any case or matter pending before it. Article 144 of the Constitution of
India requires all civil and judicial authorities to act in aid of the Supreme Court.
VI (A). ARTICLE 141:
157. Article 141 of the Constitution of India is a constitutional recognition of the doctrine of
precedents which was followed by courts in pre independence India.
158. The law is settled to the point that it is axiomatic that only the ratio decidendi in a judgement
constitutes the binding precedent.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

159. The Civil Appeal before the Supreme Court in State of Orissa v. Sudhansu Sekhar Misra and
others82 was an outcome of the conflict between the High Court and the Government of Orissa. The
High Court effected transfers of judicial officers in light of its reading of the judgment of the
Supreme Court in State of Assam v. Ranga Muhammad and others83. The High Court relied on the
observations in Ranga Muhammad (supra) that after a judicial officer is posted to the cadre it is for
the High Court to effect his transfers and accordingly passed orders transferring judicial officers to
posts in the State Government.
160. The Supreme Court in Sudhansu Sekhar Misra (supra) clarified the ratio in Ranga Muhammad
(supra) as follows:
"13. ...Obviously relying on the observation of this Court that after a judicial officer is
posted to the cadre, it is for the High Court to effect his transfers, the court below has
come to the conclusion that as the posts of the law secretary, deputy law secretary
and superintendent and legal remembrancer are included in the cadre, the High
Court has the power to fill those posts by transfer of judicial officers. The cadre this
Court was considering in Ranga Mahammad case [(1967) 1 SCR 454] , namely, Assam
Superior Judicial Services Cadre consisted of the Registrar of the Assam High Court
and three district judges in the first grade and some additional district judges in
Grade II. In that cadre, no officer holding any post under the government was
included. Hence the reference by this Court to the cadre is a reference to a cadre
consisting essentially of officers under the direct control of the High Court. It was in
that context this Court spoke of the cadre. The question of law considered in that
decision was as regards the scope of the expression "control over District Court" in
Article 235. The reference to the cadre was merely incidental."
161. The principle that only the ratio decidendi of a judgement that is treated as a binding precedent
was reflected in Sudhansu Sekhar (supra) wherein after relying on British authorities it was held:
" 13. ...A decision is only an authority for what it actually decides. What is of the
essence in a decision is its ratio and not every observation found therein nor what
logically follows from the various observations made in it. On this topic this is what
Earl of Halsbury L.C. said in Quinn v. Leathem [[1901] AC 495]:
"Now before discussing the case of Allen v. Flood, [1898] AC 1 and what was decided
therein, there are two observations of a general character which I wish to make, and
one is to repeat what I have very often said before, that every judgment must be read
as applicable to the particular facts proved, or assumed to be proved, since the
generality of the expressions which may be found there are not intended to be
expositions of the whole law, but governed and qualified by the particular facts of the
case in which such expressions are to be found. The other is that a case is only an
authority for what it actually decides. I entirely deny that it can be quoted for a
proposition that may seem to follow logically from it. Such a mode of reasoning
assumes that the law is necessarily a logical code, whereas every lawyer mustChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

acknowledge that the law is not always logical at all.
It is not a profitable task to extract a sentence here and there from a judgment and to
build upon it."
162. The said judgment was also followed by the Supreme Court in H.H. Maharajadhiraja Madhav
Rao Jivaji Rao Scindia Bahadur of Gwalior, etc. v. Union of India and another84. Madhav Rao
Scindia Bahadur (supra) also cautioned:
"It is not proper to regard a word, a clause or a sentence occurring in a judgment of
the Supreme Court, divorced from its context, as containing a full exposition of the
law on a question when the question did not even fall to be answered in that
judgment."
163. A Full Bench of this Court in Indian Ceramic House, Langra-Ki-Chowki, Agra v. Sales Tax
Officer, II Sector, Agra85 when faced with two conflicting decisions of this Court delineated ratio
decidendi from obiter dictum and expounded the law of binding precedents as follows:
"7. The above question, in one way, determines the jurisdiction of this Full Bench,
and it shall but be proper that we should clearly express our opinion why we regard
the observations made in the above Full Bench case as obiter dicta, which cannot be
used as a precedent on the interpretation of Rule 41 of the U.P. Sales Tax Rules (to be
referred hereinafter as the Rules). In Sec. 29 of Salmond on Jurisprudence, Twelfth
Edition, rules determining ratio decidendi have been indicated. It can, broadly
speaking, be said that what is not a ratio decidendi is an obiter dictum. It is the ratio
decidendi which is binding on the Courts. The material observations on this question
contained in the above section are as below:--
"First, however, we must distinguish what a case decides generally and as against all
the world from what it decides between the parties themselves. What it decides
generally is the ratio decidendi or rule or law for which it is authority
............................"
"As against persons not parties to the suit, the only part of a case which is conclusive
(with the exception of cases relating to status) is the general rule of law for which it is
authority. This rule or proposition, the ratio decidendi, may be described roughly as
the rule of law applied by and acted on by the Court, or the rule which the court
regarded as governing the case.
 8. Or again, having decided the case on one point, the judge may feel it unnecessary
to pronounce on the other points raised by the parties but he may nevertheless want
to indicate how he would have decided these points if necessary. Here again we are
not given the judge's final decision on a live issue, so that once more it would be
unwise to endow it with as much authority as the actual decision. These observationsChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

by the way, obiter dicta, are without binding authority, but are nonetheless
important: not only to do they help to rationalise the law but they serve to suggest
solutions to problems not yet decided by the courts. Indeed dicta of the House of
Lords or of judges who were masters of their fields, like Lord Blackburn, may often in
practice enjoy greater prestige than the rationes of lesser judges.
 9. The ratio-decidendi, as opposed to obiter dicta is the rule acted on by the court in
the case,......
"Various methods of determining the ratio have been advanced. The "reversal" test of
Professor Wambaugh suggested that we should take the proposition of law put
forward by the judge, reverse or negate it, and then see if its reversal would have
altered the actual decision. If so, then the proposition is the ratio or part of it; if the
reversal would have made no difference, it is not. In other words the ratio is a general
rule without which the case would have been decided otherwise. This test, however,
will not help us in cases ........ Nor is it very helpful where a court gives several
reasons for its decision. In such cases we could reverse each reason separately and
the decision would remain unaltered, since it could still rest on the other grounds ......
Quite often, in fact, where a case is argued on several grounds the judge will decide it
on one of these and merely indicate his views on the remaining points, so that here
his first proposition of law alone will constitute the ratio. Sometimes, however, he
will declare that he is deciding the case on more than one ground, and here each
proposition on which he bases the decision will qualify as a ratio."
 10. Consequently, where the case is decided in favour of the petitioner on grounds more than one,
but on certain points a finding is recorded against him, on the application of the reversal test, the
decision on the main question, if apparent from the judgment, would be ratiod decidendi, otherwise
all the grounds in support of the decision would be ratio decidendi; but the point on which a finding
is given against the petitioner would not be a ratiod decidendi and shall be mere obiter
dictum considering that the reversal of the finding on this point would not alter the decision of the
case.
 11. In Chapter X of Keeton's Elementary Principles of Jurisprudence, Second Edition, "obiter dicta"
is described as "statements of law made by a judge in the course of a decision, arising out of the
circumstances of the case, but not necessary for the decision." It was further laid down "that the
value of such dicta as sources of law naturally varies with the reputation of the judge, and with the
closeness of their relation to the matter in issue in the case in which the dicta are delivered."
 12. The opinions of other authorities and also the English decisions are reproduced in the three
cases of Bombay, Madras and Nagpur High Courts to which we shall make a reference shortly. The
purpose shall be served by our giving certain quotations from these cases. In Mohandas
Issardas v. A.N. Sattonathan, the point under consideration was whether an obiter dictum of the
Supreme Court was as much binding upon the High Courts, as an express decision given by the
Supreme Court. However, the allied question what is an obiter dictum which has a binding effectChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

upon a Court was also commented upon. Obiter dictum was regarded as an expression of opinion on
a point which was not necessary to the decision of the case. The material observations on this point
are as below:--
"Now, an 'obiter dictum' is an expression of opinion on a point which is not necessary
for the decision of a case. This very definition draws a clear distinction between a
poist which is necessary for the determination of a case and a point which is not
necessary for the determination of the case. But in both cases points must arise for
the determination of the tribunal. Two questions may arise before a Court for its
deterfination. The Court may determine both although only one of them may be
necessary for the ultimate decision of the case. The question which was necessary for
the determination of the case would be the 'ratio decidendi'; the opinion of the
tribunal on the question which was not necessary to decide the case would be only an
'obiter dictum.'
 13. Reference was then made to the definition of 'obiter dictum' to be found in Stroud's Judicial
Dictionary, which is based upon the case--'Flower v. Ebbw Vale Steel Iron and Coal Co.' and the
following passage at page 154 in the judgment of Mr. Jnstire Talbot in 'Dew v. United British
Steamship Co. Ltd.
"........ It is of course perfectsy familiar doctrine that obiter dicta, though they may
have great weight as such, are not conclusive authority. Obiter dicta in this context
means what the words literally signify--namely, statements by way.
If a judge thinks it desirable to give his opinion on some point which is not necessary
for the decision of the case, that of course has not the binding weight of the decision
of the case and the reasons for the decision".
 14. Thereafter the statement of the law in Halsbury, Volume XIX, at page 251 was quoted and it is as
below:--
"It may be laid down as general rule that part alone of a decision of a Court of law is
binding upon Courts of co-ordinate jurisdiction and inferior Courts which consists of
the enunciation of the reason or principle upon which the question before the Court
has really been determined. This underlying principle which forms the only
authoritative element of a precedent is often termed the 'ratio decidendi'. Statements
which are not necessary to the decision, which go beyond the occasion and lay down a
rule that is unnecessary for the purpose in hand (usually termed decta) have no
binding authority on another Court, though they may have some merely persuasive
efficacy."
 15. In M. Shaikh Dawood v. Collector of Central Excise, Madras7, reference was made not only to
the passage in the judgment of Mr. Justice Talbot, already quoted above, but also to certain passages
from Salmond on Jurisprudence, 11th Edition, the material part of which is as below:--Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"A precedent, therefore, is a judicial decision which contains in itself, a principle. The
underlying principle which thus forms its authorities element is often termed
the ratio decidendi. The concrete decision is binding between the parties to it, but it is
the abstract ratio decidendi which alone has the force of law as regards the word at
large ................ 'The only thing' says the same distinguished judge in another case, 'in
a Judge's decision binding as an authority upon a subsequent judge is the principle
upon which the case was decided" .......... The only judicial principles which are
authoritative are those which are thus relevant in their subject matter and limited in
their scope. All others, at the best, are of merely persuasive efficacy. They are not
true rationes decidendi, and are distinguished from them under the name
of dicta or obiter dicta, things said by the way."
"The weight to be given to obiter dicta depends upon the circumstances, Sir Carleton
Allen's conclusion is that "if the eminence of the tribunal, the consensus of judicial
opinion, and the degree of deliberation all combine to lend a special weight and
solemnity to dicta, then their authority is for all practical purposes indistinguishable
from that of rationes decidendi."
 16. In Kanglu Baula Kotwal v. Chief Executive Officer, Janpad Sabha, Durg, reference was made to
rule for determining the ratio decidendi of a case as stated by Professor John Chipman Gray at page
261 in the Nature and Sources of the law (2nd Edition 1921) and also to Allen in his Law in the
Making and to the following observations of Lord Sterndale M.B. in--"Slack v. Leeds Industrial
Co-operative Society Ltd.".
"Dicta are of different kinds and of varying degrees of weight: Sometimes they may be
called almost casual expressions of opinion upon a point which has not been raised in
the case, and is not really present to the Judge's mind. Such dicta, though entitled to
the respect due to the speaker, may fairly be disregarded by judges before whom the
point has been raised and argued in a way to bring it under much fuller
consideration. Some dicta, however, are of a different kind; they are, although not
necessary for the decision of the case, deliberate expressions of opinion given after
consideration upon a point clearly brought and argued before the Court. It is open,
no doubt, to other judges to give decisions contrary to such dicta, but much greater
weight attaches to them than to the former class."
 17. The well recognized principle of interpretation accepted by the Courts in England, therefore,
is:--
"Any judgment of any Court is authoritative only as to that part of it, called the 'ratio
decidendi', which is considered to have been necessary to the decision of the actual
issue between the litigants. It is for the Court, of whatever degree, which is called
upon to consider the precedent, to determine what the true 'ratio decidendi'
was..............Judicial opinions upon such matters, whether they be merely casual, or
wholly gratuitous or (as is far more usual) of what may be called collateral relevance,Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

are known as 'obiter dicta or simply 'dicta', and it is extremely difficult to establish
any standard of their relative weight." (Allen in his Law in the Making).
(emphasis supplied)
 18. A Judgment is authoritative only as to that part of it which is considered to have been necessary
to the decision of the case, and not that part which was not necessary to its decision. The first is
called 'ratio decidendi'. Which is binding as a precedent. The other called 'obiter dicta' cannot be
treated as a binding precedent though the opinion so expressed is entitled to respect. This rule has
been followed by the three High Courts mentioned above and we find no reason to depart from this
well recognized principle.
 19. The learned Standing Counsel invited our attention to two English decisions -- Jacobs  v.
 London County Council and Behrens  v.  Bertram Mills Circus Ltd. But they apply to only those
cases where more than one reason has been given for the decision, and not where it was not
necessary to record a finding on a particular point for the proper decision of the case. Where more
than one reason has been given for the view expressed in the case, that is, in support of the decision,
both shall be ratio decidendi as no one can say with certainty, expect for the judge himself who
decided the case, which point was upper most in his mind; but where many questions arise in the
case, some are decided in favour of the petitioner and others against him, and, in the end, decision is
given in favour of the petitioner, they shall be the points decided in his favour which have a binding
precedent, and not the one which was decided against him, for the simple reason, that for the
decision of the case it was not necessary to record a finding on the latter category of points. Only
those points were material for the decision of the case which entitled him to a favourable judgment
and the others which could not entitle him to a favourable judgment need not have been decided.
 20. There can never exist any controversy as to the absence of binding effect of observations of a
casual nature, or where the remarks have been made in passing on certain questions of law involved
in the case. They shall all be casual observations which cannot take the place of a final expression of
opinion on those questions. Such observations cannot amount to a precedent, that is, ratio
decidendi: they would be obiter dicta which can be disregarded by an other judge, though the
observations made by higher Court or even by a Bench of a larger number of Judges must be given
due respect and departure therefrom made on good grounds after detailed consideration of the
provisions of the law and the rules. Difficulty arises only when observations have been made after
detailed consideration on points which were not necessary to the decision of the case. Where there
has been no detailed comments on the provisions of the enactment and the rules, formal expression
of opinion on points not necessary to the decision of the case, can be placed in the same category as
casual observations and they shall be obiter dicta not binding on other Courts, all the more, a Court
constituted with the same number of Judges. Even when the points not necessary to the decision of
the case are decided after detailed consideration of the provisions of the law, they can be regarded as
the considered expression of opinion by the Judges but in other respects would fall in the same
category as casual observations not necessary to the decision of the case. We find no reason to
depart from the well recognized principles already commented upon above.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

 21. In Adarsh Bhandar v. Sales Tax Officer, Aligarh, the petitioner furnished a return of his turnover
for the quarter ending 30th June, 1956, but denied that any sales tax could legally be recovered from
him on the turnover on the ground that the turnover on the goods in which he dealt was not liable to
tax. The Sales Tax Officer, however, provisionally assessed the petitioner to a tax of Rs. 75,000/- on
an estimated turnover of Rs. 12 lakhs at the rate of one anna per rupee. The Full Bench allowed the
Writ Petition on a few grounds, though they also recorded the finding that the Sales Tax Officer had
the jurisdiction to provisionally assess the petitioner when proper sales tax had not been deposited
before submitting the return or a cheque for the proper amount was not enclosed with the return.
This finding would have justified the dismissal of the Writ Petition in case the other points were not
favourable to the petitioner. In other words, for the favourable decision of the Writ Petition, it was
not necessary to record a finding on the jurisdiction of the Sales Tax Officer to make provisional
assessment where proper tax, though the liability was disputed, was not deposited or remitted by
cheque with the return. Even if a finding was not recorded on this point, the decision of the case
would have been the same.
 22. The observations of Mootham, C.J. on this question are contained in Para. 38 of the Report. It
shall be found that no detailed comments have been made, all the more, with reference to the
provisions of Sec. 7 of the U.P. Sales Tax Act (to be referred hereinafter as the Act). In the earlier
part Mootham, C.J. himself mentioned that he was referring briefly to the three submissions made
on behalf of the petitioner with regard to the invalidity of the assessment proceedings. This by itself
makes it clear that there was no proper and detailed consideration of these points and Mootham,
C.J. made certain observations simply because these points had also been argued before the Bench.
When the other points raised by the petitioner had appealed to the Bench, the petitioner himself
may not have made detailed submissions in the three points on which the validity of the assessment
proceedings was being challenged. We are thus of opinion that the finding on the above question
contained in Para 38 of the Report of the Full Bench case of Adarsh Bhandar v. Sales Tax Officer,
Aligarh1 cannot be placed in the category of a precedent binding on other Benches, all the more, on
a Full Bench with a similar strength. It is not a ratio decidendi, but is mere obiter dictum which
cannot be used as a precedent in other cases. When this finding cannot be deemed to be a judicial
pronouncement having the force of a binding precedent, the matter can be reconsidered by this Full
Bench without recourse to a reference to a still larger Bench. This view is in consonance with the
observations in Atma Ram v. State of Punjab. Their Lordships of the Supreme Court had advised
reference to a larger Bench where a Full Bench of three Judges was inclined to take a view contrary
to that of another Full Bench of equal strength so that the subordinate Courts may not be placed
under the embarrassment of preferring one view to another, both equally binding upon them. When
the expression of opinion by the earlier Full Bench does not have the force of a binding precedent,
there shall be only one decision of the Full Bench binding on the subordinate courts and no occasion
for embarrassment shall arise. We are thus of the opinion that we are competent to hear and decide
the question referred to us even though the earlier Full Bench had made observations contrary to
the law as is being enunciated by us."
164. The scope of law declared within the meaning of Article 141 of the Constitution of India arose
for consideration before the Supreme Court in Dalbir Singh and others v. State of Punjab86. The
process to isolate the ratio decidendi from the judgment was set out in Dalbir Singh (supra) asChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

under:
"22. With greatest respect, the majority decision in Rajendra Prasad case does not lay
down any legal principle of general applicability. A decision on a question of sentence
depending upon the facts and circumstances of a particular case, can never be
regarded as a binding precedent, much less "law declared" within the meaning of
Article 141 of the Constitution so as to bind all courts within the territory of India.
According to the well-settled theory of precedents every decision contains three basic
ingredients:
"(i) findings of material facts, direct and inferential. An inferential finding of facts is
the inference which the Judge draws from the direct or perceptible facts;
(ii) statements of the principles of law applicable to the legal problems disclosed by
the facts; and
(iii) judgment based on the combined effect of (i) and (ii) above."
For the purposes of the parties themselves and their privies, ingredient (iii) is the material element
in the decision for it determines finally their rights and liabilities in relation to the subject-matter of
the action. It is the judgment that estops the parties from reopening the dispute. However, for the
purpose of the doctrine of precedents, ingredient (ii) is the vital element in the decision. This indeed
is the ratio decidendi. [ R.J. Walker & M.G. Walker : The English Legal System. Butterworths, 1972,
3rd Edn., pp. 123-24] It is not everything said by a judge when giving judgment that constitutes a
precedent. The only thing in a judge's decision binding a party is the principle upon which the case
is decided and for this reason it is important to analyse a decision and isolate from it the ratio
decidendi. In the leading case of Qualcast (Wolverhampton) Ltd. v. Haynes [LR 1959 AC 7 43 :
(1959) 2 All ER 38] it was laid down that the ratio decidendi may be defined as a statement of law
applied to the legal problems raised by the facts as found, upon which the decision is based. The
other two elements in the decision are not precedents. The judgment is not binding (except directly
on the parties themselves), nor are the findings of facts. This means that even where the direct facts
of an earlier case appear to be identical to those of the case before the court, the judge is not bound
to draw the same inference as drawn in the earlier case."
(emphasis supplied)
165. The precedential value of the judgement of the Supreme Court rendered in State Bank of India
v. Yasangi Venkateswara Rao87 arose for consideration before the Supreme Court in Jayant Verma
and others v. Union of India and others88. The issue which arose for consideration in Jayant Verma
(supra) was defined thus:
"53. By a short judgment in Yasangi Venkateswara Rao (supra), this Court upset the
elaborate judgment of the High Court thus:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"7. We are unable to understand as to how the High Court could come to the
conclusion that Parliament had no jurisdiction to enact Section 21-A. There can be no
doubt that Section 21-A deals with the question of the rate of interest which can be
charged by a banking company. Entry 45 of List I of the Seventh Schedule clearly
empowers Parliament to legislate with regard to banking. The enactment of Section
21-A was clearly within the domain of Parliament. The said section applies to all types
of loans which are granted by a banking company, whether to an agriculturist or a
non- agriculturist, and, therefore, reference by the High Court to Entry 30 of List II
was of no consequence. In our opinion, the said Section 21-A had been validly
enacted."
At first blush, it appears that, though cryptic, the said paragraph does contain reasons for upsetting
the High Court judgment. But, on a closer look, it becomes clear that there is no reasoning worth the
name for so doing. Paragraph 7 is a series of conclusions put together without any clear reasoning in
support. This is probably because only the learned Additional Solicitor General for the appellant
appeared before the Court and argued the case on behalf of the appellant. The respondent, though
probably served, did not appear and consequently was not heard. It will also be noticed that, despite
the fact that  the judgment of the single Judge referred to a very large number of High Court,
Federal Court, Privy Council and Supreme Court judgments, not a single judgment is adverted to in
the cryptic paragraph 7 set out hereinabove. Can it be said that this judgment is a declaration of the
law under Article 141 of the Constitution, which as a matter of practice we cannot differ from being a
bench of coordinate strength?"
(emphasis supplied)
166. The discussion on binding precedents was initiated in Jayant Verma (supra) by citing from
authorities of repute. Precedent in English Law by Cross and Harris (4th Edn.) was quoted and the
dissenting judgement of A.P. Sen, J. in Dalbir Singh v. State of Punjab89, was also cited with
approval :
"54. This question is answered by referring to authoritative works and judgments of
this Court. In Precedent in English Law by Cross and Harris (4th edn.), 'ratio
decidendi' is described as follows:
"The ratio decidendi of a case is any rule of law expressly or impliedly treated by the
judge as a necessary step in reaching his conclusion, having regard to the line of
reasoning adopted by him, or a necessary part of his direction to the jury."
167. Thereafter, the judgement in Jayant Verma (supra) proceeded to discuss the following
authorities rendered by the Supreme Court :
"56. Similarly, this Court in Som Prakash Rekhi v. Union of India (1981) 2 SCR 111 at
139 referred to the "laconic discussion and limited ratio" in Subhajit Tewary v. Union
of India (1975) 3 SCR 616, a judgment of a Constitution Bench of this Court, and wasChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

not bound by it. Krishna Iyer, J. put it thus:
"43. We may first deal with Subhajit Tewary v. Union of India (1975) 3 SCR 616,
where the question mooted was as to whether the C.S.I.R. (Council of Scientific and
Industrial Research) was 'State' under Art. 12. The  C.S.I.R. is a registered society
with official and non-official members appointed by Government and subject to some
measure of control by Government in the Ministry of Science and Technology. The
court held it was not 'State' as defined in Art. 12. It is significant that the court
implicitly assented to the proposition that if the society were really an agency of the
Government it would be 'State'. But on the facts and features present there the
character of agency of Government was negatived. The rulings relied on are,
unfortunately, in the province of Art. 311 and it is clear that a body may be 'State'
under Part III but not under Part XIV. Ray, C.J., rejected the argument that merely
because the Prime Minister was the President or that the other members were
appointed and removed by Government did not make the Society a 'State'. With great
respect, we agree that in the absence of the other features elaborated in Airport
Authority case (1979) 3 SCC 489, the composition of the Governing Body alone may
not be decisive. The laconic discussion and the limited ratio in Tewary (supra) hardly
help either side here."
58. Further, in State of M.P. v. Narmada Bachao Andolan, (2011) 7 SCC 639 at 679-680, it was
stated:
"65. "Incuria" literally means "carelessness". In practice per incuriam is taken to
mean per ignoratium. The courts have developed this principle in relaxation of the
rule of stare decisis. Thus, the "quotable in law" is avoided and ignored if it is
rendered in ignorance of a statute or other binding authority.
67. Thus, "per incuriam" are those decisions given in ignorance or forgetfulness of
some statutory provision or authority binding on the court concerned, or a statement
of law caused by inadvertence or conclusion that has been arrived at without
application of mind or proceeded without any reason so that in such a case some part
of the decision or some step in the reasoning on which it is based, is found, on that
account to be demonstrably wrong."
168. Finally in light of the said discussion the Jayant Verma (supra) expounded the law as under:
 "59. It is clear, therefore, that where a matter is not argued at all by the respondent,
and the judgment is one of reversal, it would be hazardous to state that the law can be
declared on an ex parte appraisal of the facts and the law, as demonstrated before the
Court by the appellant's counsel alone. That apart, where there is a detailed judgment
of the High Court dealing with several authorities, and it is reversed in a cryptic
fashion without dealing with any of them, the per incuriam doctrine kicks in, and the
judgment loses binding force, because of the manner in which it deals with theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

proposition of law in question. Also, the ratio decidendi of a judgment is the principle
of law adopted having regard to the line of  reasoning of the Judge which alone binds
in future cases. Such principle can only be laid down after a discussion of the relevant
provisions and the case law on the subject. If only one side is heard and a judgment is
reversed, without any line of reasoning, and certain conclusions alone are arrived at,
without any reference to any case law, it would be difficult to hold that such a
judgment would be binding upon us and that we would have to follow it. In the
circumstances, we are of the opinion that the judgment in Yasangi Venkateswara Rao
(supra) cannot deter us in our task of laying down the law on the subject."
(emphasis supplied)
169. The Supreme Court in Arnit Das v. State of Bihar90 cautioned that a decision not accompanied
by reasons and not proceeding on a conscious consideration of an issue cannot be a law declared
within the meaning of Article 141 of the Constitution of India by holding:
"20. A decision not expressed, not accompanied by reasons and not proceeding on a
conscious consideration of an issue cannot be deemed to be a law declared to have a
binding effect as is contemplated by Article 141. That which has escaped in the
judgment is not the ratio decidendi. This is the rule of sub silentio, in the technical
sense when a particular point of law was not consciously determined."
170. Analysis of facts of a case and the process of reasoning were part of the process to ascertain the
ratio decidendi of a judgement or the principle of law having binding force in all Courts in India
according to the Supreme Court in Krishena Kumar v. Union of India and others91. Krishena Kumar
(supra) also clarified if the ratio is not clear the Court is not bound by the judgement:
"19. The doctrine of precedent, that is being bound by a previous decision, is limited
to the decision itself and as to what is necessarily involved in it. It does not mean that
this Court is bound by the various reasons given in support of it, especially when they
contain "propositions wider than the case itself required". This was what Lord
Selborne said in Caledonian Railway Co. v. Walker's Trustees [(1882) 7 App Cas 259 :
46 LT 826 (HL)] and Lord Halsbury in Quinn v. Leathem [1901 AC 495, 502 : 17 TLR
749 (HL)] . Sir Frederick Pollock has also said : "Judicial authority belongs not to the
exact words used in this or that judgment, nor even to all the reasons given, but only
to the principles accepted and applied as necessary grounds of the decision."
(emphasis supplied)
20. In other words, the enunciation of the reason or principle upon which a question before a court
has been decided is alone binding as a precedent. The ratio decidendi is the underlying principle,
namely, the general reasons or the general grounds upon which the decision is based on the test or
abstract from the specific peculiarities of the particular case which gives rise to the decision. The
ratio decidendi has to be ascertained by an analysis of the facts of the case and the process ofChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

reasoning involving the major premise consisting of a pre-existing rule of law, either statutory or
judge-made, and a minor premise consisting of the material facts of the case under immediate
consideration. If it is not clear, it is not the duty of the court to spell it out with difficulty in order to
be bound by it. In the words of Halsbury (4th edn., Vol. 26, para 573) "The concrete decision alone is
binding between the parties to it but it is the abstract ratio decidendi, as ascertained on a
consideration of the judgment in relation to the subject matter of the decision, which alone has the
force of law and which when it is clear it is not part of a tribunal's duty to spell out with difficulty a
ratio decidendi in order to bound by it, and it is always dangerous to take one or two observations
out of a long judgment and treat them as if they gave the ratio decidendi of the case. If more reasons
than one are given by a tribunal for its judgment, all are taken as forming the ratio decidendi."
(emphasis supplied)
33. Stare decisis et non quieta movere. To adhere to precedent and not to unsettle things which are
settled. But it applies to litigated facts and necessarily decided questions. Apart from Article 14 of
the Constitution of India, the policy of courts is to stand by precedent and not to disturb settled
point. When court has once laid down a principle of law as applicable to certain state of facts, it will
adhere to that principle, and apply it to all future cases where facts are substantially the same. A
deliberate and solemn decision of court made after argument on question of law fairly arising in the
case, and necessary to its determination, is an authority, or binding precedent in the same court, or
in other courts of equal or lower rank in subsequent cases where the very point is again in
controversy unless there are occasions when departure is rendered necessary to vindicate plain,
obvious principles of law and remedy continued injustice. It should be invariably applied and should
not ordinarily be departed from where decision is of long standing and rights have been acquired
under it, unless considerations of public policy demand it. But in Nakara [(1983) 1 SCC 305 : 1983
SCC (L&S) 145 : (1983) 2 SCR 165] it was never required to be decided that all the retirees formed a
class and no further classification was permissible."
(emphasis supplied)
171. In State of Orissa and others v. Md. Illiyas92, the Supreme Court iterated the well settled
position of law that it is only the ratio decidendi which comes within the ambit of the law declared
by Supreme Court and is binding precedent by stating the law as follows:
"12. When the allegation is of cheating or deceiving, whether the alleged act is wilful
or not depends upon the circumstances of the case concerned and there cannot be
any straitjacket formula. The High Court unfortunately did not discuss the factual
aspects and by merely placing reliance on an earlier decision of the Court held that
prerequisite conditions were absent. Reliance on the decision without looking into
the factual background of the case before it, is clearly impermissible. A decision is a
precedent on its own facts. Each case presents its own features. It is not everything
said by a Judge while giving judgment that constitutes a precedent. The only thing in
a Judge's decision binding a party is the principle upon which the case is decided and
for this reason it is important to analyse a decision and isolate from it the ratioChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

decidendi. According to the well-settled theory of precedents, every decision contains
three basic postulates : (i) findings of material facts, direct and inferential. An
inferential finding of facts is the inference which the Judge draws from the direct, or
perceptible facts; (ii) statements of the principles of law applicable to the legal
problems disclosed by the facts; and (iii) judgment based on the combined effect of
the above. A decision is an authority for what it actually decides. What is of the
essence in a decision is its ratio and not every observation found therein nor what
logically flows from the various observations made in the judgment. The enunciation
of the reason or principle on which a question before a court has been decided is
alone binding as a precedent. (See State of Orissa v. Sudhansu Sekhar Misra [(1968)
2 SCR 154 : AIR 1968 SC 647] and Union of India v. Dhanwanti Devi [(1996) 6 SCC
44] .) A case is a precedent and binding for what it explicitly decides and no more.
The words used by Judges in their judgments are not to be read as if they are words
in an Act of Parliament. In Quinn v. Leathem [1901 AC 495 : 85 LT 289 : (1900-03)
All ER Rep 1 (HL)] the Earl of Halsbury, L.C. observed that every judgment must be
read as applicable to the particular facts proved or assumed to be proved, since the
generality of the expressions which are found there are not intended to be the
exposition of the whole law but governed and qualified by the particular facts of the
case in which such expressions are found and a case is only an authority for what it
actually decides."
(emphasis supplied)
172. It would be apposite to refer to the following observations of the three-Judge Bench of the
Supreme Court in Regional Manager and another v. Pawan Kumar Dubey93, wherein it was held
that even a single fact could make a difference in conclusions drawn in two cases:
"7.  ...It is the rule deducible from the application of law to the facts and
circumstances of a case which constitutes its ratio decidendi and not some conclusion
based upon facts which may appear to be similar. One additional or different fact can
make a world of difference between conclusions in two cases even when the same
principles are applied in each case to similar facts."
(emphasis supplied)
173. While deducing the ratio in a judgement, the Supreme Court in Delhi Airport Metro Express
Private Limited v. Delhi Metro Rail Corporation94 held:
"35. This Court has held that the ratio decidendi is the rule deducible from the
application of law to the facts and circumstances of a case which constitutes its ratio
decidendi and not some conclusion based upon facts which may appear to be similar.
It has been held that one additional or different fact can make a world of difference
between conclusions in two cases even when the same principles are applied in each
case to similar facts."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
174. The process of deducing the ratio of the binding statement of law made in a judgment arose for
consideration before the Supreme Court in Union of India and others v. Dhanwanti Devi and
others95. Dhanwanti Devi (supra) after emphasizing the need to examine the established facts of a
case and the principle of law on which the issue was decided, the law of precedents was
encapsulated as under:
"9. Before adverting to and considering whether solatium and interest would be
payable under the Act, at the outset, we will dispose of the objection raised by Shri
Vaidyanathan that Hari Krishan Khosla case [1993 Supp (2) SCC 149] is not a binding
precedent nor does it operate as ratio decidendi to be followed as a precedent and
is per se per incuriam. It is not everything said by a Judge while giving judgment that
constitutes a precedent. The only thing in a Judge's decision binding a party is the
principle upon which the case is decided and for this reason it is important to analyse
a decision and isolate from it the ratio decidendi. According to the well-settled theory
of precedents, every decision contains three basic postulates--(i) findings of material
facts, direct and inferential. An inferential finding of facts is the inference which the
Judge draws from the direct, or perceptible facts; (ii) statements of the principles of
law applicable to the legal problems disclosed by the facts; and (iii) judgment based
on the combined effect of the above. A decision is only an authority for what it
actually decides. What is of the essence in a decision is its ratio and not every
observation found therein nor what logically follows from the various observations
made in the judgment. Every judgment must be read as applicable to the particular
facts proved, or assumed to be proved, since the generality of the expressions which
may be found there is not intended to be exposition of the whole law, but governed
and qualified by the particular facts of the case in which such expressions are to be
found. It would, therefore, be not profitable to extract a sentence here and there from
the judgment and to build upon it because the essence of the decision is its ratio and
not every observation found therein. The enunciation of the reason or principle on
which a question before a court has been decided is alone binding as a precedent. The
concrete decision alone is binding between the parties to it, but it is the abstract ratio
decidendi, ascertained on a consideration of the judgment in relation to the
subject-matter of the decision, which alone has the force of law and which, when it is
clear what it was, is binding. It is only the principle laid down in the judgment that is
binding law under Article 141 of the Constitution. A deliberate judicial decision
arrived at after hearing an argument on a question which arises in the case or is put
in issue may constitute a precedent, no matter for what reason, and the precedent by
long recognition may mature into rule of stare decisis. It is the rule deductible from
the application of law to the facts and circumstances of the case which constitutes
its ratio decidendi.
10. Therefore, in order to understand and appreciate the binding force of a decision it
is always necessary to see what were the facts in the case in which the decision wasChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

given and what was the point which had to be decided. No judgment can be read as if
it is a statute. A word or a clause or a sentence in the judgment cannot be regarded as
a full exposition of law. Law cannot afford to be static and therefore, Judges are to
employ an intelligent technique in the use of precedents.
(emphasis supplied)
175. The Dhanwanti Devi (supra) was followed in Kotak Mahindra Bank Limited v. A. Balakrishnan
and another96 by the Supreme Court.
176. Deriving the ratio of a judgement arose for consideration in Islamic Academy Education and
another v. State of Karnataka and others97 wherein the Supreme Court explained the process as
follows:
"2. Most of the petitioners/applicants before us are unaided professional educational
institutions (both minority and non-minority). On behalf of the
petitioners/applicants it was submitted that the answers given to the questions, as set
out at the end of the majority judgment, lay down the true ratio of the judgment. It
was submitted that any observation made in the body of the judgment had to be read
in the context of the answers given. We are unable to accept this submission. The
answers to the questions, in the majority judgment in Pai case [(2002) 8 SCC 481]
are merely a brief summation of the ratio laid down in the judgment. The ratio
decidendi of a judgment has to be found out only on reading the entire judgment. In
fact, the ratio of the judgment is what is set out in the judgment itself. The answer to
the question would necessarily have to be read in the context of what is set out in the
judgment and not in isolation. In case of any doubt as regards any observations,
reasons and principles, the other part of the judgment has to be looked into. By
reading a line here and there from the judgment, one cannot find out the entire ratio
decidendi of the judgment. We, therefore, while giving our clarifications, are disposed
to look into other parts of the judgment other than those portions which may be
relied upon.
139. A judgment, it is trite, is not to be read as a statute. The ratio decidendi of a
judgment is its reasoning which can be deciphered only upon reading the same in its
entirety. The ratio decidendi of a case or the principles and reasons on which it is
based is distinct from the relief finally granted or the manner adopted for its disposal.
(See Executive Engineer, Dhenkanal Minor Irrigation Division v. N.C.
Budharaj [(2001) 2 SCC 721] .
143. It will not, therefore, be correct to contend, as has been contended by Mr
Nariman, that answers to the questions would be the ratio to a judgment. The
answers to the questions are merely conclusions. They have to be interpreted, in a
case of doubt or dispute with the reasons assigned in support thereof in the body of
the judgment, wherefor, it would be essential to read the other paragraphs of theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

judgment also. It is also permissible for this purpose (albeit only in certain cases and
if there exist strong and cogent reasons) to look to the pleadings of the parties.
146. The judgment of this Court in T.M.A. Pai Foundation [(2002) 8 SCC 481] will,
therefore, have to be construed or to be interpreted on the aforementioned principles.
The Court cannot read some sentences from here and there to find out the intent and
purport of the decision by not only considering what has been said therein but the
text and context in which it was said. For the said purpose the Court may also
consider the constitutional or relevant statutory provisions vis-à-vis its earlier
decisions on which reliance has been placed."
(emphasis supplied)
177. Ratio decidendi of a judgement alone constituted the law declared in a judgment rendered by
the Supreme Court and the method to cull out the ratio from a judgement in Natural Resources
Allocation, In Re, Special Reference No.1 of 201298 was restated after referencing good authorities
in point:
"69. Article 141 of the Constitution lays down that the "law declared" by the Supreme
Court is binding upon all the courts within the territory of India. The "law declared"
has to be construed as a principle of law that emanates from a judgment, or an
interpretation of a law or judgment by the Supreme Court, upon which, the case is
decided. (See Fida Hussain v. Moradabad Development Authority [(2011) 12 SCC 615
: (2012) 2 SCC (Civ) 762] .) Hence, it flows from the above that the "law declared" is
the principle culled out on the reading of a judgment as a whole in light of the
questions raised, upon which the case is decided. [Also see Ambica Quarry
Works v. State of Gujarat [(1987) 1 SCC 213] and CIT v. Sun Engg. Works (P)
Ltd. [(1992) 4 SCC 363] ] In other words, the "law declared" in a judgment, which is
binding upon courts, is the ratio decidendi of the judgment. It is the essence of a
decision and the principle upon which the case is decided which has to be ascertained
in relation to the subject-matter of the decision.
70. Each case entails a different set of facts and a decision is a precedent on its own
facts; not everything said by a Judge while giving a judgment can be ascribed
precedential value. The essence of a decision that binds the parties to the case is the
principle upon which the case is decided and for this reason, it is important to
analyse a decision and cull out from it the ratio decidendi. In the matter of applying
precedents, the erudite Justice Benjamin Cardozo in The Nature of the Judicial
Process, had said that "if the Judge is to pronounce it wisely, some principles of
selection there must be to guide him among all the potential judgments that compete
for recognition" and "almost invariably his first step is to examine and compare
them;" "it is a process of search, comparison and little more" and ought not to be akin
to matching "the colors of the case at hand against the colors of many sample cases"
because in that case "the man who had the best card index of the cases would also beChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the wisest Judge". Warning against comparing precedents with matching colours of
one case with another, he summarised the process, in case the colours do not match,
in the following wise words:
"It is when the colors do not match, when the references in the index fail, when there
is no decisive precedent, that the serious business of the Judge begins. He must then
fashion law for the litigants before him. In fashioning it for them, he will be
fashioning it for others. The classic statement is Bacon's: 'For many times, the things
deduced to judgment may be meum and tuum, when the reason and consequence
thereof may trench to point of estate. The sentence of today will make the right and
wrong of tomorrow."
73. It is also important to read a judgment as a whole keeping in mind that it is not an abstract
academic discourse with universal applicability, but heavily grounded in the facts and circumstances
of the case. Every part of a judgment is intricately linked to others constituting a larger whole and
thus, must be read keeping the logical thread intact.
(emphasis supplied)
178. The process of deciphering the ratio of decidendi in a judgement was elaborated in Sanjay
Singh and another v. U.P. Public Service Commission, Allahabad and another99 in the following
terms :
"10. The contention of the Commission also overlooks the fundamental difference
between challenge to the final order forming part of the judgment and challenge to
the ratio decidendi of the judgment. Broadly speaking, every judgment of superior
courts has three segments, namely, (i) the facts and the point at issue; (ii) the reasons
for the decision; and (iii) the final order containing the decision. The reasons for the
decision or the ratio decidendi is not the final order containing the decision. In fact,
in a judgment of this Court, though the ratio decidendi may point to a particular
result, the decision (final order relating to relief) may be different and not a natural
consequence of the ratio decidendi of the judgment. This may happen either on
account of any subsequent event or the need to mould the relief to do complete
justice in the matter. It is the ratio decidendi of a judgment and not the final order in
the judgment, which forms a precedent. The term "judgment" and "decision" are
used, rather loosely, to refer to the entire judgment or the final order or the ratio
decidendi of a judgment. Rupa Ashok Hurra [(2002) 4 SCC 388] is of course, an
authority for the proposition that a petition under Article 32 would not be
maintainable to challenge or set aside or quash the final order contained in a
judgment of this Court. It does not lay down a proposition that the ratio decidendi of
any earlier decision cannot be examined or differed in another case. Where violation
of a fundamental right of a citizen is alleged in a petition under Article 32, it cannot
be dismissed, as not maintainable, merely because it seeks to distinguish or challenge
the ratio decidendi of an earlier judgment, except where it is between the sameChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

parties and in respect of the same cause of action. Where a legal issue raised in a
petition under Article 32 is covered by a decision of this Court, the Court may dismiss
the petition following the ratio decidendi of the earlier decision. Such dismissal is not
on the ground of "maintainability" but on the ground that the issue raised is not
tenable, in view of the law laid down in the earlier decision. But if the Court is
satisfied that the issue raised in the later petition requires consideration and in that
context the earlier decision requires re-examination, the Court can certainly proceed
to examine the matter (or refer the matter to a larger Bench, if the earlier decision is
not of a smaller Bench). When the issue is re-examined and a view is taken different
from the one taken earlier, a new ratio is laid down. When the ratio decidendi of the
earlier decision undergoes such change, the final order of the earlier decision as
applicable to the parties to the earlier decision, is in no way altered or disturbed.
Therefore, the contention that a writ petition under Article 32 is barred or not
maintainable with reference to an issue which is the subject-matter of an earlier
decision, is rejected."
(emphasis supplied)
179. The need to study the whole judgment in light of facts and circumstances of a case, and to avoid
cherry picking select facts was essential while determining the precedential value of a decision as
held by the Supreme Court in Commissioner of Income Tax v. Sun Engineering Works (P) Ltd.100:
"39.  ...Such an interpretation would be reading that judgment totally out of context
in which the questions arose for decision in that case. It is neither desirable nor
permissible to pick out a word or a sentence from the judgment of this Court,
divorced from the context of the question under consideration and treat it to be the
complete 'law' declared by this Court. The judgment must be read as a whole and the
observations from the judgment have to be considered in the light of the questions
which were before this Court. A decision of this Court takes its colour from the
questions involved in the case in which it is rendered and while applying the decision
to a later case, the courts must carefully try to ascertain the true principle laid down
by the decision of this Court and not to pick out words or sentences from the
judgment, divorced from the context of the questions under consideration by this
Court, to support their reasonings."
(emphasis supplied)
180. The dictum of law that the ratio of a decision must be understood in the facts situation of a case
and that a judgment is an authority for what it actually decides and not what logically follows from it
was reiterated by the Supreme Court in Ambica Quarry Works and others v. State of Gujarat and
others101:
"18...The ratio of any decision must be understood in the background of the facts of
that case. It has been said long time ago that a case is only an authority for what itChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

actually decides, and not what logically follows from it."
(emphasis supplied)
181. The Supreme Court in Prakash Amichand Shah v. State of Gujarat and others102 cautioned that
a judgement is not a statute, and underscored the need to carefully ascertain the true principles laid
down by the previous decision and outlined when decisions are liable to be disregarded:
"26. Before embarking upon the examination of these decisions we should bear in
mind that what is under consideration is not a statute or a legislation but a decision
of the court. A decision ordinarily is a decision on the case before the court while the
principle underlying the decision would be binding as a precedent in a case which
comes up for decision subsequently. Hence while applying the decision to a later
case, the court which is dealing with it should carefully try to ascertain the true
principle laid down by the previous decision. A decision often takes its colour from
the questions involved in the case in which it is rendered. The scope and authority of
a precedent should never be expanded unnecessarily beyond the needs of a given
situation.
31. Expressions like "virtually overruled" or "in substance overruled" are expressions
of inexactitude. In such circumstances, it is the duty of a Constitution Bench of this
Court which has to consider the effect of the precedent in question to read it over
again and to form its own opinion instead of wholly relying upon the gloss placed on
it in some other decisions. It is significant that none of the learned judges who
decided the subsequent cases has held that the Act had become void on account of
any constitutional infirmity. They allowed the Act to remain in force and the State
Governments concerned have continued to implement the provisions of the Act.
What cannot be overlooked is that the decision in Shantilal Mangaldas case [(1969) 1
SCC 509 : AIR 1969 SC 634 : (1969) 3 SCR 341] was quoted in extenso with approval
and relied on by the very same judge while deciding the Bank Nationalisation
case [(1970) 1 SCC 248 : AIR 1970 SC 564 : (1970) 3 SCR 530] . He may have arrived
at an incorrect or contradictory conclusion in striking down the Bank Nationalisation
Act. The result achieved by him in the subsequent case may be wholly wrong but it
cannot have any effect on the efficacy of the decision in Shantilal Mangaldas
case [(1969) 1 SCC 509 : AIR 1969 SC 634 : (1969) 3 SCR 341] . An inappropriate
purpose for which a precedent is used at a later date does not take away its binding
character as a precedent. In such cases there is good reason to disregard the later
decision. Such occasions in judicial history are not rare."
(emphasis supplied)
182. The Supreme Court in Delhi Administration in the NCT of Delhi v. Manohar Lal103 reiterated
the need to find out the ratio of a decision and cautioned against following decisions which do not
lay down any principle of law:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"5. The High Court and all other courts in the country were no doubt ordained to
follow and apply the law declared by this Court, but that does not absolve them of the
obligation and responsibility to find out the ratio of the decision and ascertain the
law, if any, so declared from a careful reading of the decision concerned and only
thereafter proceed to apply it appropriately, to the cases before them. Considered in
that context, we could not find from the decisions reported in Sukumaran [(1997) 9
SCC 101 : 1997 SCC (Cri) 608] and Santosh Kumar [(2000) 9 SCC 151 : 2000 SCC
(Cri) 1184 : 2000 Cri LJ 2777] any law having been declared or any principle or
question of law having been decided or laid down therein and that in those cases this
Court merely proceeded to give certain directions to dispose of the matter in the
special circumstances noticed by it and the need felt, in those cases, by this Court to
give such a disposal. The same could not have been mechanically adopted as a
general formula to dispose of, as a matter of routine, all cases coming before any or
all the courts as a universal and invariable solution in all such future cases also."
(emphasis supplied)
183. In Union of India v. Amrit Lal Manchanda and another104, it was observed:
"15. ... Observations of courts are neither to be read as Euclid's theorems nor as
provisions of the statute and that too taken out of their context. These observations
must be read in the context in which they appear to have been stated. Judgments of
courts are not to be construed as statutes. To interpret words, phrases and provisions
of a statute, it may become necessary for Judges to embark into lengthy discussions
but the discussion is meant to explain and not to define. Judges interpret statutes,
they do not interpret judgments. They interpret words of statutes; their words are not
to be interpreted as statutes."
184. The need to ascertain the principle of law in a judgement and caution against unnecessary
expansion of the scope and authority of the precedent was restated by the Supreme Court in
Divisional Controller, KSRTC v. Mahadeva Shetty105 :
"23. So far as Nagesha case [(1997) 8 SCC 349] relied upon by the claimant is
concerned, it is only to be noted that the decision does not indicate the basis for
fixing of the quantum as a lump sum was fixed by the Court. The decision ordinarily
is a decision on the case before the court, while the principle underlying the decision
would be binding as a precedent in a case which comes up for decision subsequently.
Therefore, while applying the decision to a later case, the court dealing with it should
carefully try to ascertain the principle laid down by the previous decision. A decision
often takes its colour from the question involved in the case in which it is rendered.
The scope and authority of a precedent should never be expanded unnecessarily
beyond the needs of a given situation. The only thing binding as an authority upon a
subsequent Judge is the principle upon which the case was decided. Statements
which are not part of the ratio decidendi are distinguished as obiter dicta and are notChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

authoritative. The task of finding the principle is fraught with difficulty as without an
investigation into the facts, it cannot be assumed whether a similar direction must or
ought to be made as a measure of social justice. Precedents sub silentio and without
argument are of no moment. Mere casual expressions carry no weight at all, nor
every passing expression of a Judge, however eminent, can be treated as an ex
cathedra statement having the weight of authority."
(emphasis supplied)
185. Upon considering the law of binding precedents the Supreme Court in Indian Drugs &
Pharmaceuticals Ltd. v. Workmen, Indian Drugs and Pharmaceuticals Ltd.106 held that mere
directions issued under Article 142 do not constitute binding precedent under Article 141 of the
Constitution of India:
"41. No doubt, in some decisions the Supreme Court has directed regularisation of
temporary or ad hoc employees but it is well settled that a mere direction of the
Supreme Court without laying down any principle of law is not a precedent. It is only
where the Supreme Court lays down a principle of law that it will amount to a
precedent. Often the Supreme Court issues directions without laying down any
principle of law, in which case, it is not a precedent. For instance, the Supreme Court
often directs appointment of someone or regularisation of a temporary employee or
payment of salary, etc. without laying down any principle of law. This is often done
on humanitarian considerations, but this will not operate as a precedent binding on
the High Court. For instance, if the Supreme Court directs regularisation of service of
an employee who had put in 3 years' service, this does not mean that all employees
who had put in 3 years' service must be regularised. Hence, such a direction is not a
precedent. In Municipal Committee, Amritsar v. Hazara Singh [(1975) 1 SCC 794 :
1975 SCC (Cri) 354 : AIR 1975 SC 1087] the Supreme Court observed that only a
statement of law in a decision is binding. In State of Punjab v. Baldev Singh [(1999) 6
SCC 172 : 1999 SCC (Cri) 1080] this Court observed that everything in a decision is
not a precedent. In Delhi Admn. v. Manohar Lal [(2002) 7 SCC 222 : 2002 SCC (Cri)
1670 : AIR 2002 SC 3088] the Supreme Court observed that a mere direction without
laying down any principle of law is not a precedent.
42. In J&K Public Service Commission v. Dr. Narinder Mohan [(1994) 2 SCC 630 :
1994 SCC (L&S) 723 : (1994) 27 ATC 56 : AIR 1994 SC 1808] this Court held that the
directions issued by the Court from time to time for regularisation of ad hoc
appointments are not a ratio of this decision, rather the aforesaid directions were to
be treated under Article 142 of the Constitution of India. This Court ultimately held
that the High Court was not right in placing reliance on the judgment as a ratio to
give the direction to the Public Service Commission to consider the cases of the
respondents for regularisation. In that decision this Court observed : (SCC pp.
640-41, para 11) "11. This Court in A.K. Jain (Dr.) v. Union of India [1987 Supp SCC
497 : 1988 SCC (L&S) 222 : (1988) 1 SCR 335] gave directions under Article 142 toChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

regularise the services of the ad hoc doctors appointed on or before 1-10-1984. It is a
direction under Article 142 on the peculiar facts and circumstances therein.
Therefore, the High Court is not right in placing reliance on the judgment as a ratio to
give the direction to the PSC to consider the cases of the respondents. Article
142-power is confined only to this Court. The ratio in P.P.C. Rawani (Dr.) v. Union of
India [(1992) 1 SCC 331 : 1992 SCC (L&S) 309 : (1992) 19 ATC 503] is also not an
authority under Article 141. Therein the orders issued by this Court under Article 32
of the Constitution to regularise the ad hoc appointments had become final. When
contempt petition was filed for non-implementation, the Union had come forward
with an application expressing its difficulty to give effect to the orders of this Court.
In that behalf, while appreciating the difficulties expressed by the Union in
implementation, this Court gave further direction to implement the order issued
under Article 32 of the Constitution. Therefore, it is more in the nature of an
execution and not a ratio under Article 141. In Union of India v. Dr. Gyan Prakash
Singh [1994 Supp (1) SCC 306 : 1994 SCC (L&S) 472 : (1994) 26 ATC 940 : JT (1993)
5 SC 681] this Court by a Bench of three Judges considered the effect of the order
in A.K. Jain case [1987 Supp SCC 497 : 1988 SCC (L&S) 222 : (1988) 1 SCR 335] and
held that the doctors appointed on ad hoc basis and taken charge after 1-10-1984
have no automatic right for confirmation and they have to take their chance by
appearing before the PSC for recruitment. In H.C. Puttaswamy v. Hon'ble Chief
Justice of Karnataka High Court [1991 Supp (2) SCC 421 : 1992 SCC (L&S) 53 : (1992)
19 ATC 292 : AIR 1991 SC 295 : 1991 Lab IC 235] this Court while holding that the
appointment to the posts of clerk etc. in the subordinate courts in Karnataka State
without consultation of the PSC are not valid appointments, exercising the power
under Article 142, directed that their appointments as regular, on humanitarian
grounds, since they have put in more than 10 years' service. It is to be noted that the
recruitment was only for clerical grade (Class III post) and it is not a ratio under
Article 141. In State of Haryana v. Piara Singh [(1992) 4 SCC 118 : 1992 SCC (L&S)
825 : (1992) 21 ATC 403 : AIR 1992 SC 2130] this Court noted that the normal rule is
recruitment through the prescribed agency but due to administrative exigencies, an
ad hoc or temporary appointment may be made. In such a situation, this Court held
that efforts should always be made to replace such ad hoc or temporary employees by
regularly selected employees, as early as possible. ... Therefore, this Court did not
appear to have intended to lay down as a general rule that in every category of ad hoc
appointment, if the ad hoc appointee continued for long period, the rules of
recruitment should be relaxed and the appointment by regularisation be made. Thus
considered, we have no hesitation to hold that the direction of the Division Bench is
clearly illegal and the learned Single Judge is right in directing the State Government
to notify the vacancies to the PSC and the PSC should advertise and make
recruitment of the candidates in accordance with the rules."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

186. A blind reliance on judgments without considering the fact situation was disapproved in
Ashwani Kumar Singh v. U.P. Public Service Commission and others107:
"10. Courts should not place reliance on decisions without discussing as to how the
factual situation fits in with the fact situation of the decision on which reliance is
placed. Observations of courts are not to be read as Euclid's theorems nor as
provisions of the statute. These observations must be read in the context in which
they appear. Judgments of courts are not to be construed as statutes. To interpret
words, phrases and provisions of a statute, it may become necessary for Judges to
embark upon lengthy discussions, but the discussion is meant to explain and not to
define. Judges interpret statutes, they do not interpret judgments. They interpret
words of statutes; their words are not to be interpreted as statutes. In London
Graving Dock Co. Ltd. v. Horton [1951 AC 737 : (1951) 2 All ER 1 (HL)] (AC at p. 761)
Lord McDermott observed : (All ER p. 14 C-D) "The matter cannot, of course, be
settled merely by treating the ipsissima verba of Willes, J., as though they were part
of an Act of Parliament and applying the rules of interpretation appropriate thereto.
This is not to detract from the great weight to be given to the language actually used
by that most distinguished Judge...."
11. In Home Office v. Dorset Yacht Co. [(1970) 2 All ER 294 : 1970 AC 1004 : (1970) 2 WLR 1140
(HL)] Lord Reid said, "Lord Atkin's speech ... is not to be treated as if it were a statutory definition.
It will require qualification in new circumstances" (All ER p. 297g-h). Megarry, J. in Shepherd
Homes Ltd. v. Sandham (No. 2) [(1971) 1 WLR 1062 : (1971) 2 All ER 1267] observed : (All ER p.
1274d-e) "One must not, of course, construe even a reserved judgment of even Russell, L.J. as if it
were an Act of Parliament;" In Herrington v. British Rlys. Board [(1972) 2 WLR 537 : (1972) 1 All ER
749 : 1972 AC 877 (HL)] Lord Morris said : (All ER p. 761c) "There is always peril in treating the
words of a speech or a judgment as though they were words in a legislative enactment, and it is to be
remembered that judicial utterances are made in the setting of the facts of a particular case."
12. Circumstantial flexibility, one additional or different fact may make a world of difference
between conclusions in two cases. Disposal of cases by blindly placing reliance on a decision is not
proper."
(emphasis supplied)
187. The ratio decidendi was distinguished from the obiter dicta in Director of Settlement, A.P. and
others v. M.R. Apparao and another108 as under:
"7. So far as the first question is concerned, Article 141 of the Constitution
unequivocally indicates that the law declared by the Supreme Court shall be binding
on all courts within the territory of India. The aforesaid Article empowers the
Supreme Court to declare the law. It is, therefore, an essential function of the Court
to interpret a legislation. The statements of the Court on matters other than law like
facts may have no binding force as the facts of two cases may not be similar. But whatChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

is binding is the ratio of the decision and not any finding of facts. It is the principle
found out upon a reading of a judgment as a whole, in the light of the questions
before the Court that forms the ratio and not any particular word or sentence. To
determine whether a decision has "declared law" it cannot be said to be a law when a
point is disposed of on concession and what is binding is the principle underlying a
decision. A judgment of the Court has to be read in the context of questions which
arose for consideration in the case in which the judgment was delivered. An "obiter
dictum" as distinguished from a ratio decidendi is an observation by the Court on a
legal question suggested in a case before it but not arising in such manner as to
require a decision. Such an obiter may not have a binding precedent as the
observation was unnecessary for the decision pronounced, but even though an obiter
may not have a binding effect as a precedent, but it cannot be denied that it is of
considerable weight. The law which will be binding under Article 141 would,
therefore, extend to all observations of points raised and decided by the Court in a
given case. So far as constitutional matters are concerned, it is a practice of the Court
not to make any pronouncement on points not directly raised for its decision. The
decision in a judgment of the Supreme Court cannot be assailed on the ground that
certain aspects were not considered or the relevant provisions were not brought to
the notice of the Court (see Ballabhadas Mathurdas Lakhani v. Municipal Committee,
Malkapur [(1970) 2 SCC 267 : AIR 1970 SC 1002] and AIR 1973 SC 794 [ (sic)] ).
When the Supreme Court decides a principle it would be the duty of the High Court
or a subordinate court to follow the decision of the Supreme Court. A judgment of the
High Court which refuses to follow the decision and directions of the Supreme Court
or seeks to revive a decision of the High Court which had been set aside by the
Supreme Court is a nullity. (See Narinder Singh v. Surjit Singh [(1984) 2 SCC 402]
and Kausalya Devi Bogra v. Land Acquisition Officer [(1984) 2 SCC 324] .) We have
to answer the first question bearing in mind the aforesaid guiding principles. We may
refer to some of the decisions cited by Mr Rao in elaborating his arguments
contending that the judgment of this Court dated 6-2-1986 [State of A.P. v. Rajah of
Venkatagiri, (2002) 4 SCC 660] cannot be held to be a law declared by the Court
within the ambit of Article 141 of the Constitution. Mr Rao relied upon the judgment
of this Court in the case of M.S.M. Sharma v. Sri Krishna Sinha [AIR 1959 SC 395 :
1959 Supp (1) SCR 806] wherein the power and privilege of the State Legislature and
the fundamental right of freedom of speech and expression including the freedom of
the press was the subject-matter of consideration. In the aforesaid judgment it has
been observed by the Court that the decision in Gunupati Keshavram
Reddy v. Nafisul Hasan [(1952) 1 SCC 343 : AIR 1954 SC 536 : 1954 Cri LJ 1704]
relied upon by the counsel for the petitioner which entirely proceeded on a
concession of the counsel cannot be regarded as a considered opinion on the subject.
There is no dispute with the aforesaid proposition of law."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

188. More recently the Supreme Court adopted the Inversion Test which was propounded by Eugene
Wambaugh, a Professor at The Harvard Law School in State of Gujarat and others v. Utility Users'
Welfare Association and others109 :
"112. It is undoubtedly true that the question which the Court was seized of, related to
the interpretation of Section 86 of the said Act and certain other matters, which are
not connected with the controversy herein. Thus, the issue arises, whether the
observations made, albeit to be construed as advisory or suggestive qua the
appointment of a Chairman and a Member are to be treated as ratio
decidendi or obiter dicta.
113. In order to determine this aspect, one of the well-established tests is "the
Inversion Test" propounded inter alia by Eugene Wambaugh, a Professor at The
Harvard Law School, who published a classic text book called The Study of Cases [
Eugene Wambaugh, The Study of Cases (Boston: Little, Brown & Co., 1892).] in the
year 1892. This textbook propounded inter alia what is known as the "Wambaugh
Test" or "the Inversion Test" as the means of judicial interpretation. "the Inversion
Test" is used to identify the ratio decidendi in any judgment. The central idea, in the
words of Professor Wambaugh, is as under:
"In order to make the test, let him first frame carefully the supposed proposition of
law. Let him then insert in the proposition a word reversing its meaning. Let him
then inquire whether, if the court had conceived this new proposition to be good, and
had it in mind, the decision could have been the same. If the answer be affirmative,
then, however excellent the original proposition may be, the case is not a precedent
for that proposition, but if the answer be negative the case is a precedent for the
original proposition and possibly for other propositions also. [ Eugene
Wambaugh, The Study of Cases (Boston: Little, Brown & Co., 1892) at p. 17.] "
114. In order to test whether a particular proposition of law is to be treated as the ratio decidendi of
the case, the proposition is to be inversed i.e. to remove from the text of the judgment as if it did not
exist. If the conclusion of the case would still have been the same even without examining the
proposition, then it cannot be regarded as the ratio decidendi of the case. This test has been followed
to imply that the ratio decidendi is what is absolutely necessary for the decision of the case. "In
order that an opinion may have the weight of a precedent", according to John Chipman Grey [
Another distinguished jurist who served as a Professor of Law at Harvard Law School.] , "it must be
an opinion, the formation of which, is necessary for the decision of a particular case".
189. The Inversion Test was also applied in Nevada Properties Pvt. Ltd. v. State of Maharashtra and
another110:
"13. It follows from the aforesaid discussion that the decision in Tapas D.
Neogy [State of Maharashtra v. Tapas D. Neogy, (1999) 7 SCC 685 : 1999 SCC (Cri)
1352] did not go into and decide the issue: whether immovable property would fallChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

under the expression "any property" under Section 102 of the Code. We say so by
applying the inversion test as referred to in State of Gujarat v. Utility Users' Welfare
Assn. [State of Gujarat v. Utility Users' Welfare Assn., (2018) 6 SCC 21] , which states
that the Court must first carefully frame the supposed proposition of law and then
insert in the proposition a word reversing its meaning to get the answer whether or
not a decision is a precedent for that proposition. If the answer is in the affirmative,
the case is not a precedent for that proposition. If the answer is in the negative, the
case is a precedent for the original proposition and possibly for other propositions
also. This is one of the tests applied to decide what can be regarded and treated as
ratio decidendi of a decision. Reference in this regard can also be made to the
decisions of this Court in U.P. SEB v. Pooran Chandra Pandey [U.P. SEB v. Pooran
Chandra Pandey, (2007) 11 SCC 92 : (2008) 1 SCC (L&S) 736] , CIT v. Sun Engg.
Works (P) Ltd. [CIT v. Sun Engg. Works (P) Ltd., (1992) 4 SCC 363] and other cases
which hold that a decision is only an authority for what it actually decides. What is of
the essence in a decision is its ratio. Not every observation found therein nor what
logically flows from those observations is the ratio decidendi. Judgment in question
has to be read as a whole and the observations have to be considered in light of the
instances which were before the Court. This is the way to ascertain the true principles
laid down by a decision. Ratio decidendi cannot be decided by picking out words or
sentences averse to the context under question from the judgment."
190. Similarly in Career Institute Educational Society v. Om Shree Thakurji Educational Society111
the Supreme Court followed the "Inversion Test" and Jayant Verma (supra) to hold:
"6. The distinction between obiter dicta and ratio decidendi in a judgment, as a
proposition of law, has been examined by several judgments of this Court, but we
would like to refer to two, namely, State of Gujarat v. Utility Users' Welfare
Association3 and Jayant Verma v. Union of India.
7. The first judgment in State of Gujarat (supra) applies, what is called, "the inversion
test" to identify what is ratio decidendi in a judgment. To test whether a particular
proposition of law is to be treated as the ratio decidendi of the case, the proposition is
to be inversed, i.e. to remove from the text of the judgment as if it did not exist. If the
conclusion of the case would still have been the same even without examining the
proposition, then it cannot be regarded as the ratio decidendi of the case.
8. In Jayant Verma (supra), this Court has referred to an earlier decision of this Court
in Dalbir Singh v. State of Punjab5 to state that it is not the findings of material facts,
direct and inferential, but the statements of the principles of law applicable to the
legal problems disclosed by the facts, which is the vital element in the decision and
operates as a precedent. Even the conclusion does not operate as a
precedent, albeit operates as res judicata. Thus, it is not everything said by a Judge
when giving judgment that constitutes a precedent. The only thing in a Judge's
decision binding as a legal precedent is the principle upon which the case is decidedChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

and, for this reason, it is important to analyse a decision and isolate from it the obiter
dicta."
191. Gasket Radiator Pvt. Ltd. v. Employees' State Insurance Corporation and another112 rendered
by the Supreme Court highlighted the importance of not construing judgments as statutes held thus:
"8. ....We once again have to reiterate what we were forced to point out in Amar Nath
Om Prakash v. State of Punjab [(1985) 1 SCC 345 : 1985 SCC (Tax) 92 : AIR 1985 SC
218] that judgments of courts are not to be construed as Acts of Parliament. Nor can
we read a judgment on a particular aspect of a question as a Holy Book covering all
aspects of every question whether such questions and facets of such questions arose
for consideration or not in that case."
(emphasis supplied)
192. In Sreenivasa General Traders and others v. State of Andhra Pradesh and others113, the
Supreme Court explained the concept of binding precedents and expounded that observations in a
judgment which were not necessary for the purpose of the decision are not binding precedents:
"30. In the ultimate analysis, the Court held in Kewal Krishan Puri case [(1980) 1 SCC
416 : AIR 1980 SC 1008 : (1979) 3 SCR 1217] that so long as the concept of fee
remains distinct and limited in contrast to tax, such expenditure of the amounts
recovered by the levy of a market fee cannot be countenanced in law. A case is an
authority only for what it actually decides and not for what may logically follow from
it. Every judgment must be read as applicable to the particular facts proved, or
assumed to be proved, since the generality of the expressions which may be found
there are not intended to be expositions of the whole law but governed or qualified by
the particular facts of the case in which such expressions are to be found. It would
appear that there are certain observations to be found in the judgment in Kewal
Krishan Puri case [(1980) 1 SCC 416 : AIR 1980 SC 1008 : (1979) 3 SCR 1217] which
were really not necessary for purposes of the decision and go beyond the occasion
and therefore they have no binding authority though they may have merely
persuasive value. The observation made therein seeking to quantify the extent of
correlation between the amount of fee collected and the cost of rendition of service,
namely: (SCC p. 435, para 23) "At least a good and substantial portion of the amount
collected on account of fees, maybe in the neighbourhood of two-thirds or
three-fourths, must be shown with reasonable certainty as being spent for rendering
services in the market to the payer of fee", appears to be an obiter."
(emphasis supplied)
193. The Supreme Court in Sanjeev Coke Manufacturing Company v. M/s Bharat Coking Coal
Limited and another114 expressed reservations on the issue of courts answering hypothetical
questions where constitutional issues are involved without a proper lis by holding :Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"11. We confess the case has left us perplexed. In the first place, no question
regarding the constitutional validity of Section 4 of the Constitution (Forty-second
Amendment) Act, 1976 appears to have arisen for consideration in that case. The
question was about the nationalisation and take-over by the Central Government of a
certain textile mill under the provisions of the Sick Textile Undertakings
(Nationalisation) Act, 1974. The validity of some of the provisions of that Act was
impugned. We have serious reservations on the question whether it is open to a court
to answer academic or hypothetical questions on such considerations, particularly so
when serious constitutional issues are involved. We (Judges) are not authorised to
make disembodied pronouncements on serious and cloudy issues of constitutional
policy without battle lines being properly drawn. Judicial pronouncements cannot be
immaculate legal conceptions. It is but right that no important point of law should be
decided without a proper lis between parties properly ranged on either side and a
crossing of the swords. We think it is inexpedient for the Supreme Court to delve into
problems which do not arise and express opinion thereon."
(emphasis supplied)
194. In Ashok Kumar Gupta and another v. State of U.P. and others115, the Supreme Court
cautioned that constitutional issues not directly arising for decision cannot be decided :
"32. In Mandal case [1992 Supp (3) SCC 217 : 1992 SCC (L&S) Supp 1 : (1992) 22 ATC
385] admittedly, the two Government Memorandums provided for reservation to
OBCs in initial direct recruitment in Central services. The question of reservation in
promotion was a non-issue as conceded in that case itself and across the bar; but the
learned Judges, with all due respect and deference to their learned views, decided a
non-issue, though objected to on the ground that counsel appearing for the parties
had put their heads together and framed the issue and reference was made to a larger
Bench so that the issue was decided on that premise. Though it is settled
constitutional law that constitutional issues cannot be decided unless the issue
directly arises for decision, with due respect, the Bench decided a non-issue on a
constitutional law affecting 22% of the national population and held that Article 16(1)
read with Article 16(4) provides right to reservation in initial recruitment. The
framers of the Constitution did not intend to provide for reservation in promotion.
Since Article 335 speaks of efficiency of administration, reservation in promotion to
the Dalits and Tribes, without competition with non-reserved employees would affect
efficiency in service and is unconstitutional. It is an admitted case that as there was
no issue, nor was any evidence adduced to prove whether efficiency of administration
was deteriorated due to reservation in promotion; nor was it pointed out from the
facts of any case."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

195. The Supreme Court in Government of India v. Workmen and State Trading Corporation and
others116 opined that a decision which does not set out the facts or the reasons for the conclusion
given cannot be treated as a binding precedent and held:
"4. ....The decision of this Court is virtually a non-speaking order which does not set
out the facts and the circumstances in which the direction came to be issued against
the Government. It is not clear as to what was the connection between the
respondent-Corporation and the State Government. In the present case the
Government of India had clearly averred that it had nothing to do with the State
Trading Corporation and there was no relationship of master and servant between
the petitioners and the Government of India and, therefore, the Government of India
was not in any manner concerned with the closure of the Leather Garment unit of the
State Trading Corporation and the consequences thereof. Mr Usgaocar rightly
emphasised that the decision on which the High Court had relied could not be treated
as a precedent and in support of this contention he drew our attention to a
Constitution Bench judgment in the case of Krishena Kumar v. Union of
India [(1990) 4 SCC 207 : 1991 SCC (L&S) 112 : (1990) 14 ATC 846 : AIR 1990 SC
1782 : JT (1990) 3 SC 173] . In paras 18 and 19 the question as to when a decision can
have binding effect has been dealt with. We need say no more as it is obvious from
the decision relied on that it does not set out the facts or the reason for the conclusion
or direction given. It can, therefore, not be treated as a binding precedent."
(emphasis supplied)
196. While enquiring into the ratio of the judgement the Supreme Court in Dr. Shah Faesal and
others v. Union of India and another117 bisected a judgment into two parts :
"25. In this line, further enquiry requires us to examine, to what extent does a ruling
of coordinate Bench bind the subsequent Bench. A judgment of this Court can be
distinguished into two parts : ratio decidendi and the obiter dictum. The ratio is the
basic essence of the judgment, and the same must be understood in the context of the
relevant facts of the case. The principal difference between the ratio of a case, and the
obiter, has been elucidated by a three-Judge Bench decision of this Court in Union of
India v. Dhanwanti Devi [Union of India v. Dhanwanti Devi, (1996) 6 SCC 44]."
(emphasis supplied)
197. Dr. Shah Faesal (supra) thereafter elucidated the benefits of the practice of adopting judicial
precedents as binding statements of law:
"18. Doctrines of precedents and stare decisis are the core values of our legal system.
They form the tools which further the goal of certainty, stability and continuity in our
legal system. Arguably, Judges owe a duty to the concept of certainty of law, therefore
they often justify their holdings by relying upon the established tenets of law."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

198. In Dr. Rohit Kumar v. Secretary Office of Lieutenant Governor of Delhi and others118, the
Supreme Court delineated the distinction between the law laid down by the Supreme Court which
was binding on all Courts under Article 141 of the Constitution of India, and the directions made in
exercise of powers under Article 142 of the Constitution of India by holding :
"33.  It is well settled that a judgment is an authority for the issue of law which is
raised and decided. What is binding on the courts is what the Supreme Court decides
under Article 141 and not what the Supreme Court does under Article 142, in exercise
of its power to do complete justice in any cause or matter pending before it.
34. To quote V. Sudhish Pai from Constitutional Supremacy--A Revisit:
"Judgments and observations in judgments are not to be read as Euclid's theorems or
as provisions of statute. Judicial utterances/pronouncements are in the setting of the
facts of a particular case. To interpret words and provisions of a statute it may
become necessary for Judges to embark upon lengthy discussions, but such
discussion is meant to explain not define. Judges interpret statutes, their words are
not to be interpreted as statutes."
199. The rule of per incuriam carves out an exception to the doctrine of binding precedent.
Halsbury's Laws of England119 elucidates the rule in this manner:
"1687. ...the court is not bound to follow a decision of its own if given per incuriam. A
decision is given per incuriam when the court has acted in ignorance of a decision of
the House of Lords. In the former case it must decide which decision to follow, an in
the latter it is bound by the decision of the House of Lords."
(emphasis supplied)
200. The Supreme Court in Municipal Corporation of Delhi v. Gurnam Kaur120 held that a
judgment which was delivered without arguments and consideration of provisions of the Act was
passed sub silentio and did not constitute a binding precedent by holding:
"10. ..Quotability as "law" applies to the principle of a case, its ratio decidendi. The
only thing in a judge's decision binding as an authority upon a subsequent judge is
the principle upon which the case was decided. Statements which are not part of the
ratio decidendi are distinguished as obiter dicta and are not authoritative. The task of
finding the principle is fraught with difficulty because without an investigation into
the facts, as in the present case, it could not be assumed whether a similar direction
must or ought to be made as a measure of social justice. That being so, the direction
made by this Court in Jamna Das case [ Writ Petitions Nos. 981-82 of 1984] could not
be treated to be a precedent.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

11. Pronouncements of law, which are not part of the ratio decidendi are classed as
obiter dicta and are not authoritative. With all respect to the learned Judge who
passed the order in Jamna Das case [ Writ Petitions Nos. 981-82 of 1984] and to the
learned Judge who agreed with him, we cannot concede that this Court is bound to
follow it. It was delivered without argument, without reference to the relevant
provisions of the Act conferring express power on the Municipal Corporation to
direct removal of encroachments from any public place like pavements or public
streets, and without any citation of authority. Accordingly, we do not propose to
uphold the decision of the High Court because, it seems to us that it is wrong in
principle and cannot be justified by the terms of the relevant provisions. A decision
should be treated as given per incuriam when it is given in ignorance of the terms of a
statute or of a rule having the force of a statute. So far as the order shows, no
argument was addressed to the court on the question whether or not any direction
could properly be made compelling the Municipal Corporation to construct a stall at
the pitching site of a pavement squatter. Professor P.J. Fitzgerald, editor of the
Salmond on Jurisprudence, 12th Edn. explains the concept of sub silentio at p. 153 in
these words:
"A decision passes sub silentio, in the technical sense that has come to be attached to
that phrase, when the particular point of law involved in the decision is not perceived
by the court or present to its mind. The Court may consciously decide in favour of one
party because of point A, which it considers and pronounces upon. It may be shown,
however, that logically the court should not have decided in favour of the particular
party unless it also decided point B in his favour; but point B was not argued or
considered by the court. In such circumstances, although point B was logically
involved in the facts and although the case had a specific outcome, the decision is not
an authority on point B. Point B is said to pass sub silentio."
(emphasis supplied)
201. The consequences of failure to consider an earlier binding precedent by a Bench were examined
by the Supreme Court in D.J.Malpani v. Commissioner of Central Excise, Nashik121 which quoted
Salmond on Jurisprudence122 with approval: 
"27. ...a decision held is not binding since it was decided "without argument, without
reference to the crucial words of the rule, and without any citation of authority",
therefore, would not be followed. The author also states that precedents sub silentio
and without arguments are of no moment."
(emphasis supplied)
202. The Constitution Bench in A. R. Antulay v. R.S. Nayak and another123 stipulated that
observations reached per incuriam in a judgement are devoid of any precedent value and stated
forth:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

 "183. But the point is that the circumstance that a decision is reached per-incuriam,
merely serves to denude the decision of its precedent value. Such a decision would
not be binding as a judicial precedent. A co-ordinate bench can disagree with it and
decline to follow it. A larger bench can over rule such decision. When a previous
decision is so overruled it does not happen-nor has the overruling bench any
jurisdiction so to do-that the finality of the operative order, inter-parties, in the
previous decision is overturned. In this context the word 'decision' means only the
reason for the previous order and not the operative- order in the previous decision,
binding inter-parties. Even if a previous decision is overruled by a larger-bench, the
efficacy and binding nature, of the adjudication expressed in the operative order
remains undisturbed inter-parties. Even if the earlier decision of the five Judge bench
is per- incuriam the operative part of the order cannot be interfered within the
manner now sought to be done. That apart the five Judge bench gave its reason. The
reason, in our opinion, may or may not be sufficient. There is advertence to Section
7(1) of the 1952 Act and to the exclusive jurisdiction created thereunder. There is also
reference to Section 407 of the Criminal Procedure Code. Can such a decision be
characterised as one reached per- incurium? Indeed, Ranganath Misra, J. says this on
the point:
"Overruling when made by a larger bench of an earlier decision of a smaller one is
intended to take away the precedent value of the decision without affecting the
binding effect of the decision in the particular case. Antulay, therefore, is not entitled
to take advantage of the matter being before a larger bench .. "
(emphasis supplied)
203. Similarly the Supreme Court in Punjab Land Development & Reclamation Corpn. Ltd.,
Chandigarh v. Presiding Officer, Labour Court, Chandigarh and others124 considered the
consequences of judgements rendered in ignorance of relevant constitutional provisions or statutory
provisions and held that the law laid down has to be interpreted consistently with the subject or
context:
"43. As regards the judgments of the Supreme Court allegedly rendered in ignorance
of a relevant constitutional provision or other statutory provisions on the subjects
covered by them, it is true that the Supreme Court may not be said to "declare the
law" on those subjects if the relevant provi- sions were not really present to its mind.
But in this case ss. 25G and 25H were not directly attracted and even if they could be
said to have been attracted in laying down the major premise, they were to be
interpreted consistently with the subject or context. The problem of judgment per
incuriam when actually arises, should present no difficulty as this Court can lay down
the law afresh, if two or more of its earlier judgments cannot stand together."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

204. Further Dr. Shah Faesal (supra) elaborated the concept of per incuriam when a judgment is
rendered in ignorance of a previous decision of the Court of coordinate jurisdiction and categorically
propounded that a judgment ceases to be a binding precedent by the operation of the rule of per
incuriam :
"27. Having discussed the aspect of the doctrine of precedent, we need to consider
another ground on which the reference is sought i.e. the relevance of
non-consideration of the earlier decision of a coordinate Bench. In the case at hand,
one of the main submissions adopted by those who are seeking reference is that, the
case of Sampat Prakash [Sampat Prakash v. State of J&K, AIR 1970 SC 1118] did not
consider the earlier ruling in Prem Nath Kaul [Prem Nath Kaul v. State of J&K, AIR
1959 SC 749] .
28. The rule of per incuriam has been developed as an exception to the doctrine of
judicial precedent. Literally, it means a judgment passed in ignorance of a relevant
statute or any other binding authority [see Young v. Bristol Aeroplane Co.
Ltd. [Young v. Bristol Aeroplane Co. Ltd., 1944 KB 718 (CA)] ]. The aforesaid rule is
well elucidated in Halsbury's Laws of England in the following manner [ 3rd Edn.,
Vol. 22, Para 1687, pp. 799-800.] :
"1687. ... the court is not bound to follow a decision of its own if given per incuriam. A
decision is given per incuriam when the court has acted in ignorance of a previous
decision of its own or of a court of a coordinate jurisdiction which covered the case
before it, or when it has acted in ignorance of a decision of the House of Lords. In the
former case it must decide which decision to follow, and in the latter it is bound by
the decision of the House of Lords."
(emphasis supplied)
29. In this context of the precedential value of a judgment rendered per incuriam, the opinion of
Venkatachaliah, J., in the seven-Judge Bench decision of A.R. Antulay v. R.S. Nayak [A.R.
Antulay v. R.S. Nayak, (1988) 2 SCC 602 : 1988 SCC (Cri) 372] assumes great relevance : (SCC p.
716, para 183) "183. But the point is that the circumstance that a decision is reached per incuriam,
merely serves to denude the decision of its precedent value. Such a decision would not be binding as
a judicial precedent. A coordinate Bench can disagree with it and decline to follow it. A larger Bench
can overrule such decision. When a previous decision is so overruled it does not happen -- nor has
the overruling Bench any jurisdiction so to do -- that the finality of the operative order, inter partes,
in the previous decision is overturned. In this context the word "decision" means only the reason for
the previous order and not the operative order in the previous decision, binding inter partes. ... Can
such a decision be characterised as one reached per incuriam? Indeed, Ranganath Misra, J. says this
on the point : (para 105) "Overruling when made by a larger Bench of an earlier decision of a smaller
one is intended to take away the precedent value of the decision without effecting the binding effect
of the decision in the particular case. Antulay, therefore, is not entitled to take advantage of the
matter being before a larger Bench."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
31. Therefore, the pertinent question before us is regarding the application of the rule of per
incuriam. This Court while deciding Pranay Sethi case [National Insurance Co. Ltd. v. Pranay Sethi,
(2017) 16 SCC 680 : (2018) 3 SCC (Civ) 248 : (2018) 2 SCC (Cri) 205] , referred to an earlier
decision rendered by a two-Judge Bench in Sundeep Kumar Bafna v. State of Maharashtra [Sundeep
Kumar Bafna v. State of Maharashtra, (2014) 16 SCC 623 : (2015) 3 SCC (Cri) 558] , wherein this
Court emphasised upon the relevance and the applicability of the aforesaid rule : (Sundeep Kumar
Bafna case [Sundeep Kumar Bafna v. State of Maharashtra, (2014) 16 SCC 623 : (2015) 3 SCC (Cri)
558] , SCC p. 642, para 19) "19. It cannot be overemphasised that the discipline demanded by a
precedent or the disqualification or diminution of a decision on the application of the per incuriam
rule is of great importance, since without it, certainty of law, consistency of rulings and comity of
courts would become a costly casualty. A decision or judgment can be per incuriam any provision in
a statute, rule or regulation, which was not brought to the notice of the court. A decision or
judgment can also be per incuriam if it is not possible to reconcile its ratio with that of a previously
pronounced judgment of a co-equal or larger Bench; or if the decision of a High Court is not in
consonance with the views of this Court. It must immediately be clarified that the per incuriam rule
is strictly and correctly applicable to the ratio decidendi and not to obiter dicta."
(emphasis supplied)
32. The view that the subsequent decision shall be declared per incuriam only if there exists a
conflict in the ratio decidendi of the pertinent judgments was also taken by a five-Judge Bench
decision of this Court in Punjab Land Development & Reclamation Corpn. Ltd. v. Labour
Court [Punjab Land Development & Reclamation Corpn. Ltd. v. Labour Court, (1990) 3 SCC 682 :
1991 SCC (L&S) 71] : (SCC pp. 706-07, para 43) "43. As regards the judgments of the Supreme Court
allegedly rendered in ignorance of a relevant constitutional provision or other statutory provisions
on the subjects covered by them, it is true that the Supreme Court may not be said to "declare the
law" on those subjects if the relevant provisions were not really present to its mind. But in this case
Sections 25-G and 25-H were not directly attracted and even if they could be said to have been
attracted in laying down the major premise, they were to be interpreted consistently with the subject
or context. The problem of judgment per incuriam when actually arises, should present no difficulty
as this Court can lay down the law afresh, if two or more of its earlier judgments cannot stand
together."
(emphasis supplied)
205. The Supreme Court elucidated the concept of binding precedent in Siddharam Satlingappa
Mhetre v. State of Maharashtra and others125 and stipulated the limitations imposed on the same
by the rule of per incuriam after citing the British authorities and also judgements rendered by the
Supreme Court :
"128. Now we deem it imperative to examine the issue of per incuriam raised by the
learned counsel for the parties. In Young v. Bristol Aeroplane Company LimitedChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(1994) All ER 293 the House of Lords observed that `Incuria' literally means
`carelessness'. In practice per incuriam appears to mean per ignoratium. English
courts have developed this principle in relaxation of the rule of stare decisis. The
`quotable in law' is avoided and ignored if it is rendered, `in ignoratium of a statute
or other binding authority. The same has been accepted, approved and adopted by
this court while interpreting Article 141 of the Constitution which embodies the
doctrine of precedents as a matter of law.
"......... In Halsbury's Laws of England (4th Edn.) Vol. 26: Judgment and Orders:
Judicial Decisions as Authorities (pp. 297-98, para 578) per incuriam has been
elucidated as under:
"A decision is given per incuriam when the court has acted in ignorance of a previous
decision of its own or of a court of coordinate jurisdiction which covered the case
before it, in which case it must decide which case to follow (Young v. Bristol
Aeroplane Co. Ltd., 1944 KB 718 at 729 : (1944) 2 All ER 293 at 300.
In Huddersfield Police Authority v. Watson, 1947 KB 842 : (1947) 2 All ER 193.); or
when it has acted in ignorance of a House of Lords decision, in which case it must
follow that decision; or when the decision is given in ignorance of the terms of a
statute or rule having statutory force."
129. Lord Godard, C.J. in Huddersfield Police Authority v. Watson (1947) 2 All ER 193 observed that
where a case or statute had not been brought to the court's attention and the court gave the decision
in ignorance or forgetfulness of the existence of the case or statute, it would be a decision rendered
in per incuriam.
130. This court in Government of A.P. and Another v. B. Satyanarayana Rao (dead) by LRs. and
Others (2000) 4 SCC 262 observed as under:
"The rule of per incuriam can be applied where a court omits to consider a binding
precedent of the same court or the superior court rendered on the same issue or
where a court omits to consider any statute while deciding that issue."
131. In a Constitution Bench judgment of this Court in Union of India v. Raghubir Singh (1989) 2
SCC 754, Chief Justice Pathak observed as under:
"The doctrine of binding precedent has the merit of promoting a certainty and
consistency in judicial decisions, and enables an organic development of the law,
besides providing assurance to the individual as to the consequence of transactions
forming part of his daily affairs. And, therefore, the need for a clear and consistent
enunciation of legal principle in the decisions of a court."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

132. In Thota Sesharathamma and another v. Thota Manikyamma (Dead) by LRs. and others (1991)
4 SCC 312 a two Judge Bench of this Court held that the three Judge Bench decision in the case of
Mst. Karmi v. Amru (1972) 4 SCC 86 was per incuriam and observed as under:
"...It is a short judgment without adverting to any provisions of Section 14(1) or 14(2)
of the Act. The judgment neither makes any mention of any argument raised in this
regard nor there is any mention of the earlier decision in Badri Pershad v. Smt. Kanso
Devi. The decision in Mst. Karmi cannot be considered as an authority on the ambit
and scope of Section 14(1) and (2) of the Act."
133. In R. Thiruvirkolam v. Presiding Officer and Another (1997) 1 SCC 9 a two Judge Bench of this
Court observed that the question is whether it was bound to accept the decision rendered in Gujarat
Steel Tubes Ltd. v. Mazdoor Sabha (1980) 2 SCC 593, which was not in conformity with the decision
of a Constitution Bench in P. H. Kalyani v. Air France (1964) 2 SCR 104. J.S. Verma, J. speaking for
the court observed as under:
"With great respect, we must say that the above-quoted observations in Gujarat Steel
at P. 215 are not in line with the decision in Kalyani which was binding or with D.C.
Roy to which the learned Judge, Krishna Iyer, J. was a party. It also does not match
with the underlying juristic principle discussed in Wade. For the reasons, we are
bound to follow the Constitution Bench decision in Kalyani, which is the binding
authority on the point."
134. In Bharat Petroleum Corporation Ltd. v. Mumbai Shramik Sangra and others (2001) 4 SCC 448
a Constitution Bench of this Court ruled that a decision of a Constitution Bench of this Court binds a
Bench of two learned Judges of this Court and that judicial discipline obliges them to follow it,
regardless of their doubts about its correctness.
135. A Constitution Bench of this Court in Central Board of Dawoodi Bohra Community v. State of
Maharashtra (2005) 2 SCC 673 has observed that the law laid down by this Court in a decision
delivered by a Bench of larger strength is binding on any subsequent Bench of lesser or coequal
strength.
137. In Subhash Chandra and Another v. Delhi Subordinate Services Selection Board and
Others (2009) 15 SCC 458, this court again reiterated the settled legal position that Benches of
lesser strength are bound by the judgments of the Constitution Bench and any Bench of smaller
strength taking contrary view is per incuriam. The court in para 110 observed as under:-
"110. Should we consider S. Pushpa v. Sivachanmugavelu (2005) 3 SCC 1 to be an
obiter following the said decision is the question which arises herein. We think we
should. The decisions referred to hereinbefore clearly suggest that we are bound by a
Constitution Bench decision. We have referred to two Constitution Bench decisions,
namely Marri Chandra Shekhar Rao v. Seth G. S. Medical College (1990) 3 SCC 139
and E.V. Chinnaiah v. State of A.P. (2005) 1 SCC 394. Marri Chandra Shekhar RaoChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(supra) had been followed by this Court in a large number of decisions including the
three-Judge Bench decisions. S. Pushpa (supra) therefore, could not have ignored
either Marri Chandra Shekhar Rao (supra) or other decisions following the same only
on the basis of an administrative circular issued or otherwise and more so when the
constitutional scheme as contained in clause (1) of Articles 341 and 342 of the
Constitution of India putting the State and Union Territory in the same bracket.
Following Official Liquidator v. Dayanand and Others (2008) 10 SCC 1 therefore, we
are of the opinion that the dicta in S. Pushpa (supra) is an obiter and does not lay
down any binding ratio."
138. The analysis of English and Indian Law clearly leads to the irresistible conclusion that not only
the judgment of a larger strength is binding on a judgment of smaller strength but the judgment of a
co-equal strength is also binding on a Bench of judges of co-equal strength. In the instant case,
judgments mentioned in paragraphs 135 and 136 are by two or three judges of this court. These
judgments have clearly ignored a Constitution Bench judgment of this court in Sibbia's case (supra)
which has comprehensively dealt with all the facets of anticipatory bail enumerated under section
438 of Cr.P.C.. Consequently, judgments mentioned in paragraphs 135 and 136 of this judgment are
per incuriam.
139. In case there is no judgment of a Constitution Bench or larger Bench of binding nature and if
the court doubts the correctness of the judgments by two or three judges, then the proper course
would be to request Hon'ble the Chief Justice to refer the matter to a larger Bench of appropriate
strength."
206. The Supreme Court adhered to the judicial discipline of subsequent benches of lesser or
coequal strength being bound by an earlier pronouncement in Central Board Dawoodi Bohra
Community and another v. State of Maharashtra and another126:
"12. Having carefully considered the submissions made by the learned Senior Counsel
for the parties and having examined the law laid down by the Constitution Benches in
the abovesaid decisions, we would like to sum up the legal position in the following
terms:
(1) The law laid down by this Court in a decision delivered by a Bench of larger
strength is binding on any subsequent Bench of lesser or coequal strength."
207. The need for the High Courts to fully consider the views expressed by the larger Benches of the
Supreme Court in preference to those expressed by smaller Benches was expounded in State of
Orissa and others v. Titaghur Paper Mills Company Limited and another127:
"122. It is also true that an interpretation placed by the court on a document is not
binding upon it when another document comes to be interpreted by it but that is so
where the two documents are of different tenors and not where they have the same
tenor. On the ground that they dealt with the general law of real property, the CourtChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

in Orient Paper Mills case [(1977) 2 SCC 77 : 1977 SCC (Tax) 261 : (1977) 2 SCR 149]
did not advert to the earlier decisions of this Court relating to documents with similar
tenor even though those cases were referred to in the judgment of the Madhya
Pradesh High Court under appeal before it. In view of this, the Orissa High Court in
the judgment under appeal before us held that Orient Paper Mills case [(1977) 2 SCC
77 : 1977 SCC (Tax) 261 : (1977) 2 SCR 149] was decided by this Court per incuriam
because it did not take into consideration decisions of larger Benches of this Court."
(emphasis supplied)
208. The view was reiterated in Modern Dental College and Research Centre and others v. State of
Madhya Pradesh and others128, as under:
"8. The aforesaid decision of the eleven-Judge Bench of this Court in T.M.A. Pai
Foundation [(2002) 8 SCC 481] was no doubt considered in Islamic Academy
case [(2003) 6 SCC 697] and Inamdar case [(2005) 6 SCC 537] , but those latter two
decisions were of smaller Benches and hence cannot be deemed to have overruled or
laid down anything contrary to the eleven-Judge Bench decision in T.M.A. Pai
Foundation [(2002) 8 SCC 481] . It is well-settled that a larger Bench decision
prevails over the decision of a smaller Bench."
(emphasis supplied)
209. The conflict between the two or more judgments of the Supreme Court was resolved in Pyare
Mohan Lal v. State of Jharkhand and others129, by holding:
"24. In view of the above, the law can be summarised to state that in case there is a
conflict between two or more judgments of this Court, the judgment of the larger
Bench is to be followed."
[Also see: (i) The State of U.P. v. Ram Chandra Trivedi130; (ii) Smt. Triveniben v. State of
Gujarat131].
210. The Supreme Court in Bhargavi Constructions and another v. Kothakapu Muthyam Reddy and
others132, held that it was bound by its own pronouncements by virtue of being law under Article
141 of the Constitution of India:
"33. ....In our view, the decision rendered in State of Punjab [State of Punjab v. Jalour
Singh, (2008) 2 SCC 660 : (2008) 1 SCC (Civ) 669 : (2008) 1 SCC (Cri) 524 : (2008) 1
SCC (L&S) 535] is by the larger Bench (three Judge) and is, therefore, binding on us."
(emphasis supplied)
211. In Shanker Raju v. Union of India133 the Supreme Court held:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"18. The second observation we wish to make is, the doctrine of binding precedent
has the merit of promoting certainty and consistency in judicial decisions. The
pronouncement of law by a larger Bench of this Court is binding on a Division Bench
of this Court, especially where the particular determination by this Court not only
disposes of the case, but also decides a principle of law. We further add that it would
be inappropriate to reagitate the very issue or a particular provision, which this Court
had already considered and upheld."
(emphasis supplied)
212. In Shayara Bano v. Union of India and others134, the Supreme Court of India categorically laid
down that it was bound by the judgments rendered by it in terms of Article 141 of the Constitution of
India :
"353. .... In fact, this Court is bound by the judgments of the Supreme Court of India,
which in terms of Article 141 of the Constitution, are binding declarations of law."
(emphasis supplied)
213. The recourse available to the High Court in a situation where two mutually irreconcilable
decisions of the Supreme Court are cited at the Bar was highlighted by the Supreme Court in
Sundeep Kumar Bafna v. State of Maharashtra135. Further the diminution of the precedential value
of a decision upon the application of the per incuriam rule was embedded in the tenets of discipline
demanded by the rule of precedent in Sundeep Kumar Bafna (supra):
"19. It cannot be overemphasised that the discipline demanded by a precedent or the
disqualification or diminution of a decision on the application of the per
incuriam rule is of great importance, since without it, certainty of law, consistency of
rulings and comity of courts would become a costly casualty. A decision or judgment
can be per incuriam any provision in a statute, rule or regulation, which was not
brought to the notice of the court. A decision or judgment can also be per incuriam if
it is not possible to reconcile its ratio with that of a previously pronounced judgment
of a co-equal or larger Bench; or if the decision of a High Court is not in consonance
with the views of this Court. It must immediately be clarified that the per
incuriam rule is strictly and correctly applicable to the ratio decidendi and not
to obiter dicta. It is often encountered in High Courts that two or more mutually
irreconcilable decisions of the Supreme Court are cited at the Bar. We think that the
inviolable recourse is to apply the earliest view as the succeeding ones would fall in
the category of per incuriam."
(emphasis supplied)
214. The binding effect of law laid down by the Supreme Court cannot be diluted on the ground that
full facts were not placed before the Supreme Court as it would be detrimental to the rule of law andChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

constitutional order, as held by the Supreme Court in Palitana Sugar Mills Private Limited and
another v. Vilasiniben Ramachandran and others136 :
"12. It is well settled that the judgments of this Court are binding on all the
authorities under Article 142 of the Constitution and it is not open to any authority to
ignore a binding judgment of this Court on the ground that the full facts had not been
placed before this Court and/or the judgment of this Court in the earlier proceedings
had only collaterally or incidentally decided the issues raised in the show-cause
notices. Such an attempt is to belittle the issues and the orders of this Court. We are
pained to say that the then Deputy Collector has scant respect for the orders passed
by the Apex Court."
(emphasis supplied)
215. The Courts are often faced with conflicting judgements on the same point or the judgements
which do not consider the earlier decisions of a coordinate Bench. The decision rendered by a
coordinate Bench is binding on the subsequent Benches or equal lesser strength. This proposition of
law was reiterated in National Insurance Co. Ltd. v. Pranay Sethi137, wherein it is held:
"59.1.The two-Judge Bench in Santosh Devi should have been well advised to refer
the matter to a larger Bench as it was taking a different view than what has been
stated in Sarla Verma, a judgment by a coordinate Bench. It is because a coordinate
Bench of the same strength cannot take a contrary view than what has been held by
another coordinate Bench."
(emphasis supplied)
216. Dealing squarely with the issue where two conflicting judgements of the Supreme Court were
cited before the High Court, the Supreme Court in Union of India v. K.S. Subramanian138
unequivocally held that the proper course for the High Court was to follow the opinion expressed by
larger Benches of the Court in preference to those expressed by smaller Benches of the Court by
holding:
"12. But, we do not think that the High Court acted correctly in skirting the views
expressed by larger Benches of this Court in the manner in which it had done this.
The proper course for a High Court, in such a case, is to try to find out and follow the
opinions expressed by larger Benches of this Court in preference to those expressed
by smaller Benches of the Court. That is the practice followed by this Court itself. The
practice has now crystallised into a rule of law declared by this Court."
217. The question which arose for consideration before a Full Bench of this Court in Ganga Saran v.
Civil Judge, Hapur, Ghaziabad and others139 was:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"8. ...When there is a direct conflict between the two decisions of Supreme Court
rendered by Judges of equal strength, which of them should be followed by the High
Court and whether later decision of the Supreme Court has effect of overruling the
earlier decision of the Supreme Court?"
218. The Full Bench of this Court embarked on the following line of reasoning to answer the
aforesaid question after relying on a Full Bench of Punjab & Haryana High Court:
"9. One line of decision is that if there is a conflict in two Supreme Court decisions,
the decision which is later in point of time would be binding on the High Courts. The
second line of decisions is that in case there is a conflict between the judgments of
Supreme Court consisting of equal authorities, incidence of time is not a relevant
factor and the High Court must follow the judgment which appears it to lay down law
elaborately and accurately.
10. Similar situation arose before a Full Bench of Punjab and Haryana High Court in
the case of M/s Indo Swiss Time Limited, Dundahera vs. Umrao, AIR 1981 Punj &
Har 213. What the Full Bench in the said case held is extracted below (at pp. 219-220
of AIR) :
"Now the contention that the latest judgment of a co-ordinate Bench is to be
mechanically followed and must have pre-eminence irrespective of any other
consideration does not commend itself to me. When judgments of the superior Court
are of co-equal Benches and therefore, of matching authority then their weight
inevitably must be considered by the rationale and the logic thereof and not by the
mere fortutious circumstances of the time and date on which they were rendered. It is
manifest that when two directly conflicting judgments of the superior Court and of
equal authority are extant then both of them cannot be binding on the courts below.
Inevitably a choice, though a difficult one, has to be made in such a situation. On
principle it appears to me that the High Court must follow the judgment which
appears to it to lay down the law more elaborately and accurately. The mere incidence
of time whether the judgments of coequal Benches of the Superior Court are earlier
later is a consideration which appears to me as hardly relevant."
(emphasis supplied)
11. This decision was followed by the Bombay High Court in the case of Special Land Acquisition
Officer v. Municipal Corporation, AIR 1988 Bombay 9. The majority of Judges in the Full Bench
held that if there was a conflict between the two decisions of equal benches which cannot possibly
reconcile, the courts must follow the judgment which appear to them to state the law accurately and
elaborately. We are in respectful agreement with the view expressed by the Full Bench of Punjab &
Haryana High Court in the case of M/s Indo Swiss Time Limited v. Umrao, (AIR 1981 Punj & Har
213) (Supra) especially when the Supreme Court while deciding Qamaruddin's case (1990 All WC
308) (Supra) did not notice the U.P. amendment to S. 115, C.P.C. and earlier decision of theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Supreme Court. In the light of the view expressed in this case it is to be examined as to which of the
case decided by the Supreme Court lays down the law accurately. As noticed earlier the U.P.
Amendment Act No. XXXI of 1978 amended S. 115 of Code of Civil Procedure. By virtue of this
amendment, revision u/S. 115, S.P.C. did not lie to the High Court against the appellate or revisional
order passed by the District Court where the valuation of the suit is less than Rs. 20,000/-. This
amendment came up for consideration in M/s Jupiter Chit Fund (Pvt) Ltd. v. Dwarka Diesh (AIR
1979 All 218) (FB) (Supra) and it was held that S. 115, C.P.C. as amended by U.P. Amendment Act
mutually exclusive jurisdiction to the High Court and district Court. This full bench decision was
affirmed by Supreme Court in its two decisions namely in the cases of Vishesh Kumar v. Shanti
Prasad, (AIR 1980 SC 892) and Vishnu Awatar v. Shiv Autar (AIR 1980 SC 1575) (supra). A perusal
of the judgment of the Supreme Court in the case of Qamaruddin's case (1990 All WC 309) (Supra)
indicates that it was not brought to the notice of the bench deciding' the case that it was a case from
U.P. and that S. 115, C.P.C. amended by U.P. Amendment Act No. XXXI of 1978 governed the
matter. The matter was disposed of as if S. 115, C.P.C. as originally enacted applied.
12. In such a situation it cannot be held that the case of Qamaruddin (Supra) lays| down the law
accurately. Further it also cannot be held that the decision of the Supreme Court in Qamaruddin's
case overruled the decision of Full Bench of this Court which as noticed already, has been
specifically affirmed in two decisions of the Supreme Court. It would not be reasonable to say that
even though Qamaruddin's case does not notice U.P. Amendment Act and the earlier decision of
Supreme Court approving the Full Bench decision of this Court, it must be deemed to have dissented
or departed from earlier decisions or that it has over-ruled the Full Bench decision of this Court. It
goes without saying that even the decision of the Supreme Court must be understood reasonably. It
would not be reasonable to say that the Supreme Court would depart or dissent from its earlier
decision without even referring to them or without even referring to the relevant provisions of law.
13. For the above reasons it must be held that the decision of Supreme Court in Qamaruddin's case
(1990 All WC 308) (Supra) to the extent it holds that revision against an appellate or revisional
order passed by the district court is maintainable u/S. 115, C.P.C. (as amended by U.P. Act 31/78) to
the High Court does not state the law accurately or overrule the decision of the Full Bench of this
Court in Jupiter Chit Fund (Pvt) Ltd. v. Dwarka Diesh (AIR 1979 All 218) (Supra) particularly when
it has specifically been approved by the two earlier decisions of the Supreme Court."
(emphasis supplied)
219. The process of distilling the ratio in a judgment is a deliberative process governed by a long line
of legal precedents. It is the duty of all Courts (including trial courts and tribunals) to cull out the
ratio of a judgement in light of the cases in point before following it as a binding precedent. The first
step in isolating the ratio of a judgment requires a full reading of the judgment. The material facts
and the legal issues in the controversy have to be then ascertained from the judgement as a whole.
Finally the principle of law on which the decision was rendered on the subject matter under
consideration has to be identified. The said statement of law so extracted is the binding precedent in
the said judgement. Courts have to observe the caution of not picking up stray facts or observations
and apply them mechanically or out of context as binding precedents.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

220. The doctrine of precedent is leavened by judicial discipline. Judicial discipline contemplates
that the law laid down by a Bench of larger strength will prevail over the legal dictum propounded
by Benches of lesser strength.
221. The law of precedents is also limited in its operation by the concept of per incuriam. The
judgment is rendered per incuriam when it is passed in ignorance of earlier binding law or failure to
consider relevant statutory provisions. A judgment per incuriam does not have any precedential
value. Deviating from the ratio of a judgement or following observations not comprised in the ratio
amounts to lack of adherence to the law of precedents.
222. Further when faced with conflicting decisions of the Supreme Court the process of law in the
High Court will not stand still. Hands of the High Courts are not tied and they shall chart their
course of action in light of authorities which hold the field. [See: K.S. Subramanian (supra) & Ganga
Saran (supra)].
VI.A(I) Article 141 & Asian Resurfacing (supra) :
223. The submissions of the learned counsel at the Bar are these. The material facts and legal issues
under consideration before the Supreme Court in Asian Resurfacing (supra) were with regard to the
legal remedies available to a litigant against an order framing a charge under the Prevention of
Corruption Act and whether the High Court can grant interim protection to the accused who has
been charged under the Prevention of Corruption Act. The issue of pendency of all criminal and civil
cases in all High Courts where criminal trials and civil suits had been stayed was not the subject
matter of the controversy and did not arise for consideration. The plea is also sought to be advanced
on the footing of the law laid down by the Supreme Court in Sanjeev Coke Manufacturing Company
(supra) & Islamic Academy Education (supra) that no arguments were raised on this issue, and
"battle lines were not properly drawn" and neither was any response called from parties on the said
issues. On that count the directions in paras 34, 36, 37 Asian Resurfacing (supra) do not comprise
the ratio of the judgement and hence the directions do not have binding effect. Further issues and
consequences of not referencing previous judgements of larger Benches in point was also raised.
These submissions in the facts of the controversy at hand raise substantial questions as to the
interpretation of the Constitution.
224. The application of the concept of judgment rendered per incuriam and also the judicial
discipline of precedents which contemplates that a judgment rendered by a Larger Bench strength
will be binding over a judgment of a lesser Bench strength shall be considered in view of the
submissions at the Bar.
225. After placing the said judgments of the Supreme Court in A. R. Antulay (supra) and P.
Ramachandra Rao (supra) the learned counsels made the following submissions.
226. The judgement of the Asian Resurfacing (supra) was passed without consideration of the
judgement rendered by the Supreme Court by the Benches of superior strength in A. R. Antulay
(supra) and P. Ramachandra Rao (supra). According to the learned counsels directions in paras 34,Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

36, 37 in Asian Resurfacing (supra) are per incuriam for this reason.
227. The directions issued by the Supreme Court in Paras 34, 36, 37 in Asian Resurfacing (supra)
are contrary to the law laid down by the Supreme Court in A. R. Antulay (supra) and P.
Ramachandra Rao (supra). Binding law laid down under Article 141 in A. R. Antulay (supra) and P.
Ramachandra Rao (supra) proscribes judicial directions creating an outer time limit to conclude
criminal proceedings or trials pending before the courts. Imperative directions issued under Article
142 in paras 34, 36, 37 of Asian Resurfacing (supra) prescribe mandatory timelines to conclude
criminal and civil proceedings before the High Courts.
228. The contention at the Bar is that the judgments of five Judges Bench in A. R. Antulay (supra)
and seven Judges Bench in P. Ramachandra Rao (supra) were binding on the three Judges Bench in
Asian Resurfacing (supra).
229. The law laid down by the Supreme Court in A. R. Antulay (supra) and P. Ramachandra Rao
(supra) is binding on all Courts including this Court. It is also submitted that this Court has to
determine which judgement lays down the binding law and follow the same accordingly. According
to the learned counsels in the instant case it is the bounden duty of this Court and all trial courts to
follow the judgements rendered by Benches of superior strength in A. R. Antulay (supra) and P.
Ramchandra Rao (supra), in preference to the contrary directions in Asian Resurfacing (supra),
which was handed down by a Bench of lesser strength.
VI(B) ARTICLE 142
230. The scope of powers of the Supreme court under Article 142, the interface of Article 142 with
Article 194 (3) and the issue of conflict between Article 142 and Article 32 of the Constitution of
India were examined by the Court in Prem Chand Garg v. Excise Commissioner140. Prem Chand
Garg (supra) noticed the following submissions made at the Bar:
"10. It is, however, urged by the learned Solicitor-General that the powers of this
Court under Article 142 are very wide and cannot be controlled by Article 32. He has
put his argument in two ways. He urges that the words used in Article 142 are very
wide and since they constitute the constitutional charter of this Court's powers, they
must be very liberally construed. This contention is undoubtedly well founded.
Article 142(1) provides that in exercise of its jurisdiction, this Court may pass such
decree or make such order as is necessary for doing complete justice in any cause or
matter pending before it; and it adds that a decree or order so made shall be
enforceable throughout the territory of India in the manner prescribed by any law
made by Parliament and, until provision in that behalf is so made, in such manner as
the President may by order prescribe. The Solicitor-General wants us to compare
Article 142(1) with Article 194(3) and he suggests that just as the powers, privileges
and immunities specified by the latter article are not subject to the provisions in
respect of fundamental rights so is the power specified by Article 142(1) not subject to
the said rights."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

231. However, the Supreme Court in Prem Chand Garg (supra) categorically rejected the argument
that the powers under Article 142(1) can be compared with Article 194(3) of the Constitution which
are not subject to the provisions of Part III by holding:
"12. Basing himself on this decision, the Solicitor-General argues that the power
conferred on this Court under Article 142(1) is comparable to the privileges claimed
by the members of the State Legislatures under the latter part of Article 194(3), and
so, there can be no question of striking down an order passed by this Court under
Article 142(1) on the ground that it is inconsistent with Article 32. It would be noticed
that this argument proceeds on the basis that the order for security infringes the
fundamental right guaranteed by Article 32 and it suggests that under Article 142(1)
this Court has jurisdiction to pass such an order. In our opinion, the argument thus
presented is misconceived. In this connection, it is necessary to appreciate the actual
decision in the case of Sharma [(1959) 1 SCR 806 at 859-860] and its effect. The
actual decision was that the rights claimable under the latter part of Article 194(3)
were not subject to Article 19(1)(a), because the said rights had been expressly
provided for by a constitutional provision viz. Article 194(3), and it would be
impossible to hold that one part of the Constitution is inconsistent with another part.
The position would, however, be entirely different if the State Legislature was to pass
a law in regard to the privileges of its members. Such a law would obviously have to
be consistent with Article 19(1)(a). If any of the provisions of such a law were to
contravene any of the fundamental rights guaranteed by Part III, they would be
struck down as being unconstitutional. Similarly, there can be no doubt that if in
respect of petitions under Article 32 a law is made by Parliament as contemplated by
Article 145(1), and such a law, in substance, corresponds to the provisions of Order
25 Rule 1 or Order 41 Rule 10, it would be struck down on the ground that it purports
to restrict the fundamental right guaranteed by Article 32. The position of an order
made either under the rules framed by this Court or under the jurisdiction of this
Court under Article 142(1) can be no different. If this aspect of the matter is borne in
mind, there would be no difficulty in rejecting the Solicitor-General's argument based
on Article 142(1). The powers of this Court are no doubt very wide and they are
intended to be and will always be exercised in the interest of justice. But that is not to
say that an order can be made by this Court which is inconsistent with the
fundamental rights guaranteed by Part III of the Constitution. An order which this
Court can make in order to do complete justice between the parties, must not only be
consistent with the fundamental rights guaranteed by the Constitution, but it cannot
even be inconsistent with the substantive provisions of the relevant statutory laws.
Therefore, we do not think it would be possible to hold that Article 142(1) confers
upon this Court powers which can contravene the provisions of Article 32.
(emphasis supplied)
13. In this connection, it may be pertinent to point out that the wide powers which
are given to this Court for doing complete justice between the parties, can be used byChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

this Court, for instance, in adding parties to the proceedings pending before it, or in
admitting additional evidence, or in remanding the case, or in allowing a new point to
be taken for the first time. It is plain that in exercising these and similar other
powers, this Court would not be bound by the relevant provisions of procedure if it is
satisfied that a departure from the said procedure is necessary to do complete justice
between the parties.
14. That takes us to the second argument urged by the Solicitor-General that Article
142 and Article 32 should be reconciled by the adoption of the rule of harmonious
construction. In this connection, we ought to bear in mind that though the powers
conferred on this Court by Article 142(1) are very wide, and the same can be exercised
for doing complete justice in any case, as we have already observed, this Court cannot
even under Article 142(1) make an order plainly inconsistent with the express
statutory provisions of substantive law, much less, inconsistent with any
constitutional provisions. There can, therefore, be no conflict between Article 142(1)
and Article 32. In the case of K.M. Nanavati v. State of Bombay [(1961) 1 SCR 497] on
which the Solicitor-General relies, it was conceded, and rightly, that under Article
142(1) this Court had the power to grant bail in cases brought before it, and so, there
was obviously a conflict between the power vested in this Court under the said article
and that vested in the Governor of the State under Article 161. The possibility of a
conflict between these powers necessitated the application of the rule of harmonious
construction. The said rule can have no application to the present case, because on a
fair construction of Article 142(1), this Court has no power to circumscribe the
fundamental right guaranteed under Article 32. The existence of the said power is
itself in dispute, and so, the present case is clearly distinguishable from the case of
K.M. Nanavati [(1961) 1 SCR 497] ."
(emphasis supplied)
232. The view taken by the Supreme Court in Prem Chand Garg (supra) as regards the scope of
Article 142 of the Constitution of India was fully endorsed in A. R. Antulay (1988) (supra). A. R.
Antulay (1988) (supra) after considering the ratio of Prem Chand Garg (supra) held:
"50. This Court by majority held that Rule 12 of Order 35 of the Supreme Court Rules
was invalid insofar as it related to the furnishing of security. The right to move the
Supreme Court, it was emphasised, under Article 32 was an absolute right and the
content of this right could not be circumscribed or impaired on any ground and an
order for furnishing security for the respondent's costs retarded the assertion or
vindication of the fundamental right under Article 32 and contravened the said right.
The fact that the rule was discretionary did not alter the position. Though Article
142(1) empowers the Supreme Court to pass any order to do complete justice between
the parties, the court cannot make an order inconsistent with the fundamental rights
guaranteed by Part III of the Constitution. No question of inconsistency between
Article 142(1) and Article 32 arose. Gajendragadkar, J., speaking for the majority ofChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the judges of this Court said that Article 142(1) did not confer any power on this
Court to contravene the provisions of Article 32 of the Constitution. Nor did Article
145 confer power upon this Court to make rules, empowering it to contravene the
provisions of the fundamental right. At page 899 of the Reports, Gajendragadkar, J.,
reiterated that the powers of this Court are no doubt very wide and they are intended
and "will always be exercised in the interests of justice". But that is not to say that an
order can be made by this Court which is inconsistent with the fundamental rights
guaranteed by Part III of the Constitution. It was emphasised that an order which
this Court could make in order to do complete justice between the parties, must not
only be consistent with the fundamental rights guaranteed by the Constitution, but it
cannot even be inconsistent with the substantive provisions of the relevant statutory
laws (emphasis supplied). The court therefore, held that it was not possible to hold
that Article 142(1) conferred upon this Court powers which could contravene the
provisions of Article 32. It follows, therefore, that the directions given by this Court
on 16-2-1984, on the ground of expeditious trial by transferring Special Case No. 24
of 1982 and Special Case No. 3 of 1983 pending in the court of Special Judge, Greater
Bombay. Shri S.B. Sule, to the High Court of Bombay with a request to the learned
Chief Justice to assign these two cases to a sitting Judge of the High Court was
contrary to the relevant statutory provision, namely, Section 7(2) of the Criminal Law
Amendment Act, 1952 and as such violative of Article 21 of the Constitution.
Furthermore, it violates Article 14 of the Constitution as being made applicable to a
very special case among the special cases, without any guideline as to which cases
required speedier justice. If that was so as in Prem Chand Garg case [AIR 1963 SC
996 : 1963 Supp (1) SCR 885] , that was a mistake of so great a magnitude that it
deprives a man by being treated differently of his fundamental right for defending
himself in a criminal trial in accordance with law. If that was so then when the
attention of the court is drawn the court has always the power and the obligation to
correct it ex debito justitiae and treat the second application by its inherent power as
a power of review to correct the original mistake. No suitor should suffer for the
wrong of the court. This Court in Prem Chand Garg case [AIR 1963 SC 996 : 1963
Supp (1) SCR 885] struck down not only the administrative order enjoined by Rule 12
for deposit of security in a petition under Article 32 of the Constitution but also
struck down the judicial order passed by the court for non-deposit of such security in
the subsequent stage of the same proceeding when attention of the court to the
infirmity of the rule was drawn. It may be mentioned that Shah, J., was of the opinion
that Rule 12 was not violative. For the present controversy it is not necessary to deal
with this aspect of the matter."
(emphasis supplied)
233. Subsequently, however, clarifying the judgments rendered in Prem Chand Garg (supra) and A.
R. Antulay (1988) (supra) in regard to the ambit and the limitations of the powers under Article
142(1) of the Constitution, the Supreme Court in Union Carbide Corporation v. Union of India141
ruled:Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

"60. The expression "cause or matter" in Article 142(1) is very wide covering almost
every kind of proceedings in Court. In Halsbury's Laws of England (4th edn., vol. 37,
para 22) referring to the plenitude of that expression it is stated:
"Cause or matter.-- The words 'cause' and 'matter' are often used in juxtaposition, but
they have different meanings. 'Cause' means any action or any criminal proceedings
and 'matter' means any proceedings in court not in a cause. When used together, the
words 'cause or matter' cover almost every kind of proceeding in court, whether civil
or criminal, whether interlocutory or final, and whether before or after judgment."
Any limited interpretation of the expression "cause or matter" having regard to the wide and
sweeping powers under Article 136 which Article 142(1) seeks to effectuate, limiting it only to the
short compass of the actual dispute before the Court and not to what might necessarily and
reasonably be connected with or related to such matter in such a way that their withdrawal to the
apex Court would enable the court to do "complete justice", would stultify the very wide
constitutional powers. Take, for instance, a case where an interlocutory order in a matrimonial
cause pending in the trial court comes up before the apex Court. The parties agree to have the main
matter itself either decided on the merits or disposed of by a compromise. If the argument is correct
this Court would be powerless to withdraw the main matter and dispose it of finally even if it be on
consent of both sides. Take also a similar situation where some criminal proceedings are also
pending between the litigating spouses. If all disputes are settled, can the court not call up to itself
the connected criminal litigation for a final disposal? If matters are disposed of by consent of the
parties, can any one of them later turn around and say that the apex Court's order was a nullity as
one without jurisdiction and that the consent does not confer jurisdiction? This is not the way in
which jurisdiction with such wide constitutional powers is to be construed. While it is neither
possible nor advisable to enumerate exhaustively the multitudinous ways in which such situations
may present themselves before the Court where the Court with the aid of the powers under Article
142(1) could bring about a finality to the matters, it is common experience that day in and day out
such matters are taken up and decided in this Court. It is true that mere practice, however long, will
not legitimize issues of jurisdiction. But the argument, pushed to its logical conclusions, would mean
that when an interlocutory appeal comes up before this Court by special leave, even with the consent
of the parties, the main matter cannot be finally disposed of by this Court as such a step would imply
an impermissible transfer of the main matter. Such technicalities do not belong to the content and
interpretation of constitutional powers.
83. It is necessary to set at rest certain misconceptions in the arguments touching the scope of the
powers of this Court under Article 142(1) of the Constitution. These issues are matters of serious
public importance. The proposition that a provision in any ordinary law irrespective of the
importance of the public policy on which it is founded, operates to limit the powers of the apex
Court under Article 142(1) is unsound and erroneous. In both Garg [1963 Supp 1 SCR 885, 899-900
: AIR 1963 SC 996] as well as Antulay cases [(1988) 2 SCC 602 : 1988 SCC (Cri) 372] the point was
one of violation of constitutional provisions and constitutional rights. The observations as to the
effect of inconsistency with statutory provisions were really unnecessary in those cases as the
decisions in the ultimate analysis turned on the breach of constitutional rights. We agree with ShriChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Nariman that the power of the Court under Article 142 insofar as quashing of criminal proceedings
are concerned is not exhausted by Section 320 or 321 or 482 CrPC or all of them put together. The
power under Article 142 is at an entirely different level and of a different quality. Prohibitions or
limitations or provisions contained in ordinary laws cannot, ipso facto, act as prohibitions or
limitations on the constitutional powers under Article 142. Such prohibitions or limitations in the
statutes might embody and reflect the scheme of a particular law, taking into account the nature and
status of the authority or the court on which conferment of powers -- limited in some appropriate
way -- is contemplated. The limitations may not necessarily reflect or be based on any fundamental
considerations of public policy. Sri Sorabjee, learned Attorney General, referring to Garg case [1963
Supp 1 SCR 885, 899-900 : AIR 1963 SC 996] , said that limitation on the powers under Article 142
arising from "inconsistency with express statutory provisions of substantive law" must really mean
and be understood as some express prohibition contained in any substantive statutory law. He
suggested that if the expression 'prohibition' is read in place of 'provision' that would perhaps
convey the appropriate idea. But we think that such prohibition should also be shown to be based on
some underlying fundamental and general issues of public policy and not merely incidental to a
particular statutory scheme or pattern. It will again be wholly incorrect to say that powers under
Article 142 are subject to such express statutory prohibitions. That would convey the idea that
statutory provisions override a constitutional provision. Perhaps, the proper way of expressing the
idea is that in exercising powers under Article 142 and in assessing the needs of "complete justice" of
a cause or matter, the apex Court will take note of the express prohibitions in any substantive
statutory provision based on some fundamental principles of public policy and regulate the exercise
of its power and discretion accordingly. The proposition does not relate to the powers of the Court
under Article 142, but only to what is or is not 'complete justice' of a cause or matter and in the
ultimate analysis of the propriety of the exercise of the power. No question of lack of jurisdiction or
of nullity can arise.
84. Learned Attorney General said that Section 320 Criminal Procedure Code is "exhaustive of the
circumstances and conditions under which composition can be effected." (See Sankar
Rangayya v. Sankar Ramayya [AIR 1916 Mad 483, 485 : 16 Cri LJ 750 : 31 IC 350] ) and that "the
courts cannot go beyond a test laid down by the legislature for determining the class of offences that
are compoundable and substitute one of their own". Learned Attorney General also referred to the
following passage in Biswabahan Das v. Gopen Chandra Hazarika [(1967) 1 SCR 447, 451 : AIR 1967
SC 895 : 1967 Cri LJ 828] :
"If a person is charged with an offence, then unless there is some provision for
composition of it the law must take its course and the charge enquired into resulting
either in conviction or acquittal."
He said that "if a criminal case is declared to be non-compoundable, then it is against public policy
to compound it, and any agreement to that end is wholly void in law." (See Majibar
Rahman v. Muktashed Hossein [ILR 40 Cal 113, 117-18 : 16 CWN 854 : 15 IC 259] ); and submitted
that court "cannot make that legal which the law condemns". Learned Attorney General stressed
that the criminal case was an independent matter and of great public concern and could not be the
subject matter of any compromise or settlement. There is some justification to say that statutoryChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

prohibition against compounding of certain class of serious offences, in which larger social interests
and social security are involved, is based on broader and fundamental considerations of public
policy. But all statutory prohibitions need not necessarily partake of this quality. The attack on the
power of the apex Court to quash the criminal proceedings under Article 142(1) is ill-conceived. But
the justification for its exercise is another matter.
86. But Shri Nariman put it effectively when he said that if the position in relation to the criminal
cases was that the Court was invited by the Union of India to permit the termination of the
prosecution and the Court consented to it and quashed the criminal cases, it could not be said that
there was some prohibition in some law for such powers being exercised under Article 142. The
mere fact that the word 'quashing' was used did not matter. Essentially, it was a matter of mere form
and procedure and not of substance. The power under Article 142 is exercised with the aid of the
principles of Section 321 CrPC which enables withdrawal of prosecutions. We cannot accept the
position urged by the learned Attorney General and learned counsel for the petitioners that Court
had no power or jurisdiction to make that order. We do not appreciate Union of India which filed
the memorandum of February 15, 1989, raising the plea of want of jurisdiction."
234. Both the scope and limits of the plenary powers under Article 142 of the Constitution arose for
consideration before a Constitution Bench of the Supreme Court in Supreme Court Bar Association
v. Union of India142 and the Supreme Court observed as under:
"43. The power of the Supreme Court to punish for contempt of court, though quite
wide, is yet limited and cannot be expanded to include the power to determine
whether an advocate is also guilty of "professional misconduct" in a summary
manner, giving a go-by to the procedure prescribed under the Advocates Act. The
power to do complete justice under Article 142 is in a way, corrective power, which
gives preference to equity over law but it cannot be used to deprive a professional
lawyer of the due process contained in the Advocates Act, 1961 by suspending his
licence to practice in a summary manner while dealing with a case of contempt of
court.
47. The plenary powers of this Court under Article 142 of the Constitution are
inherent in the Court and are complementary to those powers which are specifically
conferred on the Court by various statutes though are not limited by those statutes.
These powers also exist independent of the statutes with a view to do complete justice
between the parties. These powers are of very wide amplitude and are in the nature of
supplementary powers. This power exists as a separate and independent basis of
jurisdiction apart from the statutes. It stands upon the foundation and the basis for
its exercise may be put on a different and perhaps even wider footing, to prevent
injustice in the process of litigation and to do complete justice between the parties.
This plenary jurisdiction is, thus, the residual source of power which this Court may
draw upon as necessary whenever it is just and equitable to do so and in particular to
ensure the observance of the due process of law, to do complete justice between the
parties, while administering justice according to law. There is no doubt that it is anChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

indispensable adjunct to all other powers and is free from the restraint of jurisdiction
and operates as a valuable weapon in the hands of the Court to prevent "clogging or
obstruction of the stream of justice". It, however, needs to be remembered that the
powers conferred on the Court by Article 142 being curative in nature cannot be
construed as powers which authorise the Court to ignore the substantive rights of a
litigant while dealing with a cause pending before it. This power cannot be used to
"supplant" substantive law applicable to the case or cause under consideration of the
Court. Article 142, even with the width of its amplitude, cannot be used to build a new
edifice where none existed earlier, by ignoring express statutory provisions dealing
with a subject and thereby to achieve something indirectly which cannot be achieved
directly. Punishing a contemner advocate, while dealing with a contempt of court
case by suspending his licence to practice, a power otherwise statutorily available
only to the Bar Council of India, on the ground that the contemner is also an
advocate, is, therefore, not permissible in exercise of the jurisdiction under Article
142. The construction of Article 142 must be functionally informed by the salutary
purposes of the article, viz., to do complete justice between the parties. It cannot be
otherwise. As already noticed in a case of contempt of court, the contemner and the
court cannot be said to be litigating parties.
48. The Supreme Court in exercise of its jurisdiction under Article 142 has the power
to make such order as is necessary for doing complete justice "between the parties in
any cause or matter pending before it". The very nature of the power must lead the
Court to set limits for itself within which to exercise those powers and ordinarily it
cannot disregard a statutory provision governing a subject, except perhaps to balance
the equities between the conflicting claims of the litigating parties by "ironing out the
creases" in a cause or matter before it. Indeed this Court is not a court of restricted
jurisdiction of only dispute-settling. It is well recognised and established that this
Court has always been a law-maker and its role travels beyond merely
dispute-settling. It is a "problem-solver in the nebulous areas" (see K. Veeraswami v.
Union of India [(1991) 3 SCC 655 : 1991 SCC (Cri) 734] but the substantive statutory
provisions dealing with the subject-matter of a given case cannot be altogether
ignored by this Court, while making an order under Article 142. Indeed, these
constitutional powers cannot, in any way, be controlled by any statutory provisions
but at the same time these powers are not meant to be exercised when their exercise
may come directly in conflict with what has been expressly provided for in a statute
dealing expressly with the subject."
235. Supreme Court Bar Association (supra) also reconciled the judgments in Union Carbide
Corporation (supra), A.R. Antulay (1988) (supra), Prem Chand Garg (supra) in the following
manner:
"55. Thus, a careful reading of the judgments in Union Carbide Corpn. v. Union of
India [(1991) 4 SCC 584] ; the Delhi Judicial Service Assn. case [(1991) 4 SCC 406 :
(1991) 3 SCR 936] and Mohd. Anis case [1994 Supp (1) SCC 145 : 1994 SCC (Cri) 251]Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

relied upon in V.C. Mishra case [(1995) 2 SCC 584] show that the Court did not
actually doubt the correctness of the observations in Prem Chand Garg case [AIR
1963 SC 996 : 1963 Supp (1) SCR 885] . As a matter of fact, it was observed that in the
established facts of those cases, the observations in Prem Chand Garg case [AIR 1963
SC 996 : 1963 Supp (1) SCR 885] had "no relevance". This Court did not say in any of
those cases that substantive statutory provisions dealing expressly with the subject
can be ignored by this Court while exercising powers under Article 142.
56. As a matter of fact, the observations on which emphasis has been placed by us
from the Union Carbide case [(1991) 4 SCC 584] , A.R. Antulay case [(1988) 2 SCC
602 : 1988 SCC (Cri) 372] and Delhi Judicial Service Assn. case [(1991) 4 SCC 406 :
(1991) 3 SCR 936] go to show that they do not strictly speaking come into any conflict
with the observations of the majority made in Prem Chand Garg case [AIR 1963 SC
996 : 1963 Supp (1) SCR 885] . It is one thing to say that "prohibitions or limitations
in a statute" cannot come in the way of exercise of jurisdiction under Article 142to do
complete justice between the parties in the pending "cause or matter" arising out of
that statute, but quite a different thing to say that while exercising jurisdiction under
Article 142, this Court can altogether ignore the substantive provisions of a statute,
dealing with the subject and pass orders concerning an issue which can be settled
only through a mechanism prescribed in another statute. This Court did not say so in
Union Carbide case [(1991) 4 SCC 584] either expressly or by implication and on the
contrary it has been held that the Apex Court will take note of the express provisions
of any substantive statutory law and regulate the exercise of its power and discretion
accordingly. We are, therefore, unable to persuade ourselves to agree with the
observations of the Bench in V.C. Mishra case [(1995) 2 SCC 584] that the law laid
down by the majority in Prem Chand Garg case [AIR 1963 SC 996 : 1963 Supp (1)
SCR 885] is "no longer a good law"."
236. Finally the Supreme Court in Supreme Court Bar Association (supra), stipulated following
restraints in exercise of powers under Article 142 of the Constitution of India:
"78. Thus, to conclude we are of the opinion that this Court cannot in exercise of its
jurisdiction under Article 142 read with Article 129 of the Constitution, while
punishing a contemner for committing contempt of court, also impose a punishment
of suspending his licence to practice, where the contemner happens to be an
advocate. Such a punishment cannot even be imposed by taking recourse to the
appellate powers under Section 38 of the Act while dealing with a case of contempt of
court (and not an appeal relating to professional misconduct as such). To that extent,
the law laid down in Vinay Chandra Mishra, Re [(1995) 2 SCC 584] is not good law
and we overrule it.
82. In V.C. Mishra case [(1995) 2 SCC 584] the Bench relied upon its inherent powers
under Article 142 to punish him by suspending his licence, without the Bar Council
having been given any opportunity to deal with his case under the Act. We cannotChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

persuade ourselves to agree with that approach. It must be remembered that wider
the amplitude of its power under Article 142, the greater is the need of care for this
Court to see that the power is used with restraint without pushing back the limits of
the Constitution so as to function within the bounds of its own jurisdiction. To the
extent this Court makes the statutory authorities and other organs of the State
perform their duties in accordance with law, its role is unexceptionable but it is not
permissible for the Court to "take over" the role of the statutory bodies or other
organs of the State and "perform" their functions."
237. After noticing that the holdings of the Supreme Court in Union Carbide Corporation (supra),
A.R. Antulay (1988) (supra), Prem Chand Garg (supra), Supreme Court Bar Assn. (supra) are not in
conflict, the Supreme Court in ONGC v. Gujarat Energy Transmission Corporation Ltd.143 adhered
to the regime of restraints created by it while exercising powers under Article 142 of the Constitution
of India and declined to condone the delay beyond the statutory limits by holding:
"12. In A.R. Antulay v. R.S. Nayak [A.R. Antulay v. R.S. Nayak, (1988) 2 SCC 602 :
1988 SCC (Cri) 372] , while explicating and elaborating the principles under Article
142, Sabyasachi Mukharji, J. (as his Lordship then was) opined thus : (SCC p. 656,
para 50) "50. ... The fact that the rule was discretionary did not alter the position.
Though Article 142(1) empowers the Supreme Court to pass any order to do complete
justice between the parties, the court cannot make an order inconsistent with the
fundamental rights guaranteed by Part III of the Constitution. No question of
inconsistency between Article 142(1) and Article 32 arose. Gajendragadkar, J.,
speaking [Prem Chand Garg v. Excise Commr., AIR 1963 SC 996 : 1963 Supp (1) SCR
885] for the majority of the Judges of this Court said that Article 142(1) did not
confer any power on this Court to contravene the provisions of Article 32 of the
Constitution. Nor did Article 145 confer power upon this Court to make rules,
empowering it to contravene the provisions of the fundamental right. At AIR pp.
1002-03, para 12 : SCR p. 899 of the Report, Gajendragadkar, J., reiterated that the
powers of this Court are no doubt very wide and they are intended and "will always be
exercised in the interests of justice". But that is not to say that an order can be made
by this Court which is inconsistent with the fundamental rights guaranteed by Part
III of the Constitution. It was emphasised that an order which this Court could make
in order to do complete justice between the parties, must not only be consistent with
the fundamental rights guaranteed by the Constitution, but it cannot even be
inconsistent with the substantive provisions of the relevant statutory laws. The court
therefore, held that it was not possible to hold that Article 142(1) conferred upon this
Court powers which could contravene the provisions of Article 32."
15. From the aforesaid decisions, it is clear as crystal that the Constitution Bench in Supreme Court
Bar Assn. [Supreme Court Bar Assn. v. Union of India, (1998) 4 SCC 409] has ruled that there is no
conflict of opinion in Antulay case [A.R. Antulay v. R.S. Nayak, (1988) 2 SCC 602 : 1988 SCC (Cri)
372] or in Union Carbide Corpn. case [Union Carbide Corpn. v. Union of India, (1991) 4 SCC 584 :
1991 Supp (1) SCR 251] with the principle set down in Prem Chand Garg v. Excise Commr. [PremChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Chand Garg v. Excise Commr., AIR 1963 SC 996 : 1963 Supp (1) SCR 885] Be it noted, when there is
a statutory command by the legislation as regards limitation and there is the postulate that delay
can be condoned for a further period not exceeding sixty days, needless to say, it is based on certain
underlined, fundamental, general issues of public policy as has been held in Union Carbide Corpn.
case [Union Carbide Corpn. v. Union of India, (1991) 4 SCC 584 : 1991 Supp (1) SCR 251] . As the
pronouncement in Chhattisgarh SEB [Chhattisgarh SEB v. Central Electricity Regulatory
Commission, (2010) 5 SCC 23] lays down quite clearly that the policy behind the Act emphasising
on the constitution of a special adjudicatory forum, is meant to expeditiously decide the grievances
of a person who may be aggrieved by an order of the adjudicatory officer or by an appropriate
Commission. The Act is a special legislation within the meaning of Section 29(2) of the Limitation
Act and, therefore, the prescription with regard to the limitation has to be the binding effect and the
same has to be followed regard being had to its mandatory nature. To put it in a different way, the
prescription of limitation in a case of present nature, when the statute commands that this Court
may condone the further delay not beyond 60 days, it would come within the ambit and sweep of the
provisions and policy of legislation. It is equivalent to Section 3 of the Limitation Act. Therefore, it is
uncondonable and it cannot be condoned taking recourse to Article 142 of the Constitution.
16. We had stated earlier that we will be adverting to the passage in Suryachakra Power Corpn.
Ltd.[Suryachakra Power Corpn. Ltd. v. Electricity Deptt., (2016) 16 SCC 152 : (2016) 10 Scale 46]
There, the Court had referred to Section 14 of the Limitation Act. It fundamentally relied on M.P.
Steel Corpn. [M.P. Steel Corpn. v. CCE, (2015) 7 SCC 58 : (2015) 3 SCC (Civ) 510] wherein the Court
after referring to certain authorities, analysed thus : (M.P. Steel Corpn. case [M.P. Steel
Corpn. v. CCE, (2015) 7 SCC 58 : (2015) 3 SCC (Civ) 510] , SCC p. 91, para 43) "43. ... when a certain
period is excluded by applying the principles contained in Section 14, there is no delay to be
attributed to the appellant and the limitation period provided by the statute concerned continues to
be the stated period and not more than the stated period. We conclude, therefore, that the principle
of Section 14 which is a principle based on advancing the cause of justice would certainly apply to
exclude time taken in prosecuting proceedings which are bona fide and with due diligence pursued,
which ultimately end without a decision on the merits of the case."
238. After following the ONGC (supra) the Supreme Court in National Spot Exchange Ltd. v. Dunar
Foods Ltd. (Resolution Professional)144 held as under:
"16. It is also required to be noted that even Shri Maninder Singh, learned Senior
Counsel appearing on behalf of the appellant has, as such, fairly conceded that
considering Section 61(2) of the IB Code, the Appellate Tribunal has jurisdiction or
power to condone the delay not exceeding 15 days from the completion of 30 days,
the statutory period of limitation. However, he has requested and prayed to condone
the delay in exercise of powers under Article 142 of the Constitution of India, in the
facts and circumstances of the case and submitted that the amount involved is a very
huge amount and that the appellant is a public body. We are afraid what cannot be
done directly considering the statutory provisions cannot be permitted to be done
indirectly, while exercising the powers under Article 142 of the Constitution of India."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

239. The judgment in ONGC (supra) was followed by the Supreme Court in Assistant Commissioner
(CT) v. Glaxo Smith Kline Consumer Health Care Ltd.145 with similar results:
"16. Indubitably, the powers of the High Court under Article 226 of the Constitution
are wide, but certainly not wider than the plenary powers bestowed on this Court
under Article 142 of the Constitution. Article 142 is a conglomeration and repository
of the entire judicial powers under the Constitution, to do complete justice to the
parties. Even while exercising that power, this Court is required to bear in mind the
legislative intent and not to render the statutory provision otiose. In a recent decision
of a three-Judge Bench of this Court in ONGC v. Gujarat Energy Transmission Corpn.
Ltd. [ONGC v. Gujarat Energy Transmission Corpn. Ltd., (2017) 5 SCC 42 : (2017) 3
SCC (Civ) 47] , the statutory appeal filed before this Court was barred by 71 days and
the maximum time-limit for condoning the delay in terms of Section 125 of the
Electricity Act, 2003 was only 60 days. In other words, the appeal was presented
beyond the condonable period of 60 days. As a result, this Court could not have
condoned the delay of 71 days. Notably, while admitting the appeal, the Court had
condoned the delay in filing the appeal. However, at the final hearing of the appeal,
an objection regarding appeal being barred by limitation was allowed to be raised
being a jurisdictional issue and while dealing with the said objection, the Court
referred to the decisions in Singh Enterprises v. CCE [Singh Enterprises v. CCE,
(2008) 3 SCC 70] , CCE v. Hongo (India) (P) Ltd. [CCE v. Hongo (India) (P) Ltd.,
(2009) 5 SCC 791] , Chhattisgarh SEB v. CERC [Chhattisgarh SEB v. CERC, (2010) 5
SCC 23] and Suryachakra Power Corpn. Ltd. v. Electricity Deptt. [Suryachakra Power
Corpn. Ltd. v. Electricity Deptt., (2016) 16 SCC 152 : (2017) 5 SCC (Civ) 761] and
concluded that Section 5 of the Limitation Act, 1963 cannot be invoked by the Court
for maintaining an appeal beyond maximum prescribed period in Section 125 of the
Electricity Act."
(emphasis supplied)
240. While interpreting the expression "complete justice" in Article 142, the Supreme Court in
Rajeev Suri v. DDA146 did not take a narrow view to doing justice but looked at the positions of the
parties and the subject matter as a goal and held:
"578. The character of a public interest proceeding is necessarily non-adversarial in
nature and it is not a matter of two individuals fighting against each other at all
possible forums. In Kalpana Mehta v. Union of India [Kalpana Mehta v. Union of
India, (2018) 7 SCC 1] , this Court, in para 264, had observed that "When courts enter
upon issues of public interest and adjudicate upon them, they do not discharge a
function which is adversarial." Such a proceeding is essentially in the nature of a
collective enquiry to determine whether the State is acting in accordance with settled
principles of law and such collective enquiry is always targeted towards larger public
interest. What purpose will a public interest proceeding serve if the fulfilment of one
notion of public interest leads to a clear subjugation of another legitimate action ofChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

the State taken in public interest and as the petitioners themselves put it, concerning
project of national importance touching upon democratic polity. That is where the
role of this Court comes in, which ought to be active and not passive in such
proceedings.
579. We may usefully refer to our prior discussion on the statutory jurisdiction of
NGT vis-à-vis the constitutional powers of this Court. We are not reiterating the same
here to avoid repetition. The expression "complete justice" does not contemplate a
narrow view of doing justice to the petitioners or the respondents. Rather, the
principle entails looking at the parties, their respective positions and the
subject-matter/cause before it as a whole. The Court needs to be even more vigilant
and proactive in its pursuit of complete justice when the subject-matter involves an
exercise of power in rem and considerations of public interest traverse beyond the
immediate expectations of the parties before the Court. It is not a case where the
parties have approached the Court for the vindication of personal rights, as already
noted above, and the nature of subject-matter is entirely different.
580. When competing public interests are brought before a constitutional court, it
becomes the duty of the Court to harmonise and balance such interests, even if it
requires the invocation of an extraordinary power. The performance of this function
by the Court becomes even more indispensable when the grievance of the petitioners
is that national interest is at stake. It is precisely for such occasions that this Court is
bestowed with such a plenary power."
(emphasis supplied)
241. The restraints devised by the Supreme Court in exercise of powers in determining the scope of
jurisdiction under Article 142 of the Constitution of India were restated by the Supreme Court in
Anupal Singh v. State of U.P.147 wherein the Summit Court refused to issue orders which were
contrary to expressed provisions of law by unequivocally stating:
"83. Article 142 of the Constitution of India confers wide power upon the Supreme
Court to do complete justice between the parties. Though the powers conferred on
the Supreme Court by Article 142 are very wide, the same cannot be exercised to pass
an order inconsistent with express statutory provisions of substantive law. In Ramji
Veerji Patel v. Revenue Divl. Officer [Ramji Veerji Patel v. Revenue Divl. Officer,
(2011) 10 SCC 643 : (2012) 3 SCC (Civ) 1062] , the Supreme Court held that the
power under Article 142 of the Constitution of India is to be exercised very carefully
and sparingly. The power under Article 142 of the Constitution of India can be
exercised so as to do complete justice between the parties. However, as held in
Supreme Court Bar Assn. v. Union of India [Supreme Court Bar Assn. v. Union of
India, (1998) 4 SCC 409] , though the power under Article 142 of the Constitution is
plenary in nature, the same cannot be construed to mean that the power can be used
to supplant the substantive law applicable to the case."Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
242. The impermissibility of issuing directions under Article 142 of the Constitution of India which
were contrary to a specific provision of law was again emphasized in Raj Kumar v. State of U.P.148
by stating forth:
"15. It was also urged that we may exercise powers under Article 142 of the
Constitution of India because the occurrence took place more than twenty years back.
We are clearly of the view that the power under Article 142 cannot be exercised
against the specific provision of law. Section 16(1)(a) of the Act lays down a minimum
sentence of six months. Considering the bane of adulteration and the deleterious
effect of adulteration and sub-standard food on the health of the citizens (especially
children when milk is involved), the legislature provided a minimum sentence of six
months. Passage of time can be no excuse to award a sentence lower than the
minimum.
(emphasis supplied)
16. Furthermore, the power under Article 142, in our considered view, cannot be used
in total violation of the law. When a minimum sentence is prescribed by law, this
Court cannot, in exercise of its power under Article 142, pass an order totally contrary
to law. If such power could be used in a food adulteration case to impose a sentence
lower than the minimum prescribed, then even in cases of murder and rape, this
Court applying the same principles could impose a sentence less than the minimum.
This, in our opinion, is not the purpose of Article 142. We have no doubt in our mind
that powers under Article 142 cannot be exercised in such a manner that they make a
mockery of the law itself."
(emphasis supplied)
243. The difference between Articles 141 and 142 of the Constitution was considered in Bir Singh v.
Mukesh Kumar149 by holding thus:
"30. It is well settled that a judgment is a precedent for the issue of law which is
raised and decided. It is the ratio decidendi of the case which operates as a binding
precedent. As observed by this Court in State of Punjab v. Surinder Kumar [State of
Punjab v. Surinder Kumar, (1992) 1 SCC 489 : 1992 SCC (L&S) 345] , what is binding
on all courts is what the Supreme Court says under Article 141 of the Constitution,
which is declaration of the law and not what it does under Article 142 to do complete
justice."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

244. While observing the distinctions between the law laid down by the Supreme Court under
Article 141 and Article 142 which gave precedence to equity over law, the Supreme Court in State v.
Kalyan Singh150 reiterated that equity cannot disregard substantive provisions of law and stated the
law the under:
"22. Article 142(1) of the Constitution of India had no counterpart in the Government
of India Act, 1935 and to the best of our knowledge, does not have any counterpart in
any other Constitution world over. The Latin maxim fiat justitia ruat caelum [ This
maxim was quoted by Lord Mansfield in R. v. Wilkes, (1770) 4 Burr 2527 : 98 ER 327
: (1558-1774) All ER Rep 570. The passage in which it is quoted makes interesting
reading, and among the many other things stated by that great Judge, it is stated: "I
wish Popularity: but it is that popularity which follows; not that which is run after. It
is that popularity which, sooner or later, never fails to do justice to the pursuit of
noble ends, by noble means."] is what first comes to mind on a reading of Article 142
-- Let justice be done though the heavens fall. This article gives a very wide power to
do complete justice to the parties before the Court, a power which exists in the
Supreme Court because the judgment delivered by it will finally end the litigation
between the parties. It is important to notice that Article 142 follows upon Article 141
of the Constitution, in which it is stated that the law declared by the Supreme Court
shall be binding on all courts within the territory of India. Thus, every judgment
delivered by the Supreme Court has two components -- the law declared which binds
courts in future litigation between persons, and the doing of complete justice in any
cause or matter which is pending before it. It is, in fact, an Article that turns one of
the maxims of equity on its head, namely, that equity follows the law. By Article 142,
as has been held in State of Punjab [State of Punjab v. Rafiq Masih, (2014) 8 SCC 883
: (2014) 4 SCC (Civ) 657 : (2014) 6 SCC (Cri) 154 : (2014) 3 SCC (L&S) 134] judgment,
equity has been given precedence over law. But it is not the kind of equity which can
disregard mandatory substantive provisions of law when the court issues directions
under Article 142. While moulding relief, the court can go to the extent of relaxing the
application of law to the parties or exempting altogether the parties from the rigours
of the law in view of the peculiar facts and circumstances of the case."
(emphasis supplied)
30. According to Shri Venugopal, the Supreme Court's power under Section 406 is circumscribed by
transfer taking place only from a criminal court subordinate to one High Court to another criminal
court of equal or superior jurisdiction subordinate to another High Court. Clearly Section 406 does
not apply to the facts of the present case as the transfer is from one criminal court to another
criminal court, both subordinate to the same High Court. This being the case, nothing prevents us
from utilising our power under Article 142 to transfer a proceeding from one criminal court to
another criminal court under the same High Court as Section 406 does not apply at all. The learned
Senior Counsel went on to add that such a power is exercisable only under Section 407 by the High
Court and not this Court. Again, the fact that the High Court has been given a certain power of
transfer under the Code of Criminal Procedure does not detract from the Supreme Court using aChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

constitutional power under Article 142 to achieve the same end to do complete justice in the matter
before it. In the present case, there is no substantive mandatory provision which is infracted by
using Article 142. This being the case, both grounds taken by Shri Venugopal are without
substance."
245. The Supreme Court in Nidhi Kaim v. State of M.P.151 unequivocally declined to issue directions
in exercise of powers under Article 142 of the Constitution of India which were contrary to the law
declared under Article 141 of the Constitution of India even in exceptional circumstances in light of
the pronouncement of the Constitution Bench in Supreme Court Bar Assn. v. Union of India152.
However, "the window for such thought and consideration" was left open by observing:
"90. We shall now consider the submission, founded on the interpretation placed by
Mr Fali S. Nariman (see para 20, and onwards), on Article 142 of the Constitution. If
the instant contention is acceptable then surely, according to the learned counsel, it
would be possible to overlook the consequences of fraud (refer to para 81,
hereinabove), in case sufficient justification was shown for taking a different course
for doing complete justice. Mr Nariman's suggestion that the Supreme Court must be
"trusted", and that, this Court can even ignore statutory law in the overriding interest
of doing complete justice under Article 142 of the Constitution has been put forth for
our consideration. The said view was sought to be extended by the learned counsel,
even to a declared pronouncement of law under Article 141 of the Constitution (in
addition to statutory law). Accepting the proposition canvassed, we are sure, would
substantially enhance the authority of this Court. And for that reason, the hypothesis
of Mr Nariman is extremely attractive. It is, however, not possible for us to ignore the
decision of a Constitution Bench of this Court, in Supreme Court Bar Assn. v. Union
of India [Supreme Court Bar Assn. v. Union of India, (1998) 4 SCC 409] . The
projection of Mr Fali S. Nariman, that this Court had virtually denuded itself of its
constitutional power to do complete justice through the above judgment, is an
expression of his opinion, which we respect. We are indeed bound by the declaration
of the Constitution Bench.
(emphasis supplied)
91. In terms of the above judgment in Supreme Court Bar Assn. case [Supreme Court
Bar Assn. v. Union of India, (1998) 4 SCC 409] , with which we express our
unequivocal concurrence, it is not possible to accept that the words "complete justice"
used in Article 142 of the Constitution, would include the power to disregard even
statutory provisions, and/or a declared pronouncement of law under Article 141 of
the Constitution, even in exceptional circumstances. Undoubtedly, the proposition
can certainly be acceptable to a very limited extent -- to the extent of
self-aggrandisement. The "trust", Mr Nariman reposes in this Court, is indeed
heartening and reassuring. But then, Mr Nariman, and a number of other
outstanding legal practitioners like him, undeniably have the brilliance to mould the
best of minds. And thereby, to persuade a court, to accept their sense of reasoning, soChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

as to override statutory law and/or a declared pronouncement of law. It is this, which
every court, should consciously keep out of its reach. In our considered view the
hypothesis -- that the Supreme Court can do justice as it perceives, even when
contrary to statute (and, declared pronouncement of law), should never as a rule, be
entertained by any court/Judge, however high or noble. Can it be overlooked, that
legislation is enacted, only with the object of societal good, and only in support of
societal causes? Legislation, always flows from reason and logic. Debates and
deliberations in Parliament, leading to a valid legislation, represent the will of the
majority. That will and determination, must be equally "trusted", as much as the
"trust" which is reposed in a court. Any legislation which does not satisfy the above
parameters would per se be arbitrary, and would be open to being declared as
constitutionally invalid. In such a situation, the legislation itself would be struck
down. It is difficult to visualise a situation wherein a valid legislation would render
injustice to the parties, or would lead to a situation of incomplete justice -- for one or
the other party. Imagination, perception and comprehension of future events, have
inherent limitations. We would therefore refrain ourselves from saying anything
beyond what we have. At the cost of repetition, we would reiterate, that such a
situation, as is contemplated by Mr Nariman, does not seem to be possible. We would
however not like to close the window for such thought and consideration. We would
rather leave it to the conscience of the court concerned to deal with such an
exceptional situation if it ever arises. In our view, in the facts and circumstances of
the present case, the cause of the appellants is not furthered even by the approach
suggested by relying on the hypothesis of Mr Nariman. We can only conclude by
observing that keeping in mind the conscious involvement of the appellants in
gaining admission to the MBBS course, by means of a fraudulent stratagem of
trickery, it is not possible for us to ignore or overlook the declaration of law with
reference to fraud. Nothing obtained by fraud can be sustained. This declared
proposition of law must apply to the case of the appellants as well. This is the
outcome of the "trust" reposed in this Court, as being fully equipped to determine at
its own, when Article 142 of the Constitution can be invoked to render complete
justice, and when it cannot be so invoked."
(emphasis supplied)
246. Delving into the scope of jurisdiction under Article 142 of the Constitution of India, the
Supreme Court in Asha Ranjan v. State of Bihar153 held that the said powers cannot curtail the
Fundamental Rights of the citizens:
"86.6. The Court in exercise of power under Article 142 of the Constitution cannot
curtail the fundamental rights of the citizens conferred under the Constitution and
pass orders in violation of substantive provisions which are based on fundamental
policy principles, yet when a case of the present nature arises, it may issue
appropriate directions so that criminal trial is conducted in accordance with law. It is
the obligation and duty of this Court to ensure free and fair trial.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
247. Delineating differences between Articles 141 and 142 of the Constitution of India and keeping
the latter outside the purview of the former, the Supreme Court in State of Punjab v. Rafiq Masih154
has held that:
"11. Article 136 of the Constitution of India was legislatively intended to be exercised
by the Highest Court of the land, with scrupulous adherence to the settled judicial
principle well established by precedents in our jurisprudence. Article 136 of the
Constitution is a corrective jurisdiction that vests a discretion in the Supreme Court
to settle the law clear and as forthrightly forwarded in Union of India v. Karnail Singh
[(1995) 2 SCC 728] , it makes the law operational to make it a binding precedent for
the future instead of keeping it vague. In short, it declares the law, as under Article
141 of the Constitution.
12. Article 142 of the Constitution of India is supplementary in nature and cannot
supplant the substantive provisions, though they are not limited by the substantive
provisions in the statute. It is a power that gives preference to equity over law. It is a
justice-oriented approach as against the strict rigours of the law. The directions
issued by the Court can normally be categorised into one, in the nature of moulding
of relief and the other, as the declaration of law. "Declaration of law" as contemplated
in Article 141 of the Constitution: is the speech express or necessarily implied by the
highest court of the land. This Court in Indian Bank v. ABS Marine Products (P) Ltd.
[(2006) 5 SCC 72] , Ram Pravesh Singh v. State of Bihar [(2006) 8 SCC 381 : 2006
SCC (L&S) 1986] and in State of U.P. v. Neeraj Awasthi [(2006) 1 SCC 667 : 2006
SCC (L&S) 190] has expounded the principle and extolled the power of Article 142 of
the Constitution of India to new heights by laying down that the directions issued
under Article 142 do not constitute a binding precedent unlike Article 141 of the
Constitution of India. They are direction issued to do proper justice and exercise of
such power, cannot be considered as law laid down by the Supreme Court under
Article 141 of the Constitution of India. The Court has compartmentalised and
differentiated the relief in the operative portion of the judgment by exercise of powers
under Article 142 of the Constitution as against the law declared. The directions of
the Court under Article 142 of the Constitution, while moulding the relief, that relax
the application of law or exempt the case in hand from the rigour of the law in view of
the peculiar facts and circumstances do not comprise the ratio decidendi and
therefore lose its basic premise of making it a binding precedent. This Court on the
qui vive has expanded the horizons of Article 142 of the Constitution by keeping it
outside the purview of Article 141 of the Constitution and by declaring it a direction of
the Court that changes its complexion with the peculiarity in the facts and
circumstances of the case."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

248. The restriction of not issuing orders in contravention of law under Article 142 was iterated by
the Supreme Court in Poonam v. Sumit Tanwar155:
"7. This very Bench decided in Manish Goel v. Rohini Goel [(2010) 4 SCC 393] vide
judgment and order dated 5-2-2010 observing that this Court, in exercise of its
powers under Article 142 of the Constitution, generally should not issue any direction
to waive the statutory requirement. The courts are meant to enforce the law and
therefore, are not expected to issue a direction in contravention of law or to direct the
statutory authority to act in contravention of law. While deciding the said case,
reliance has been placed upon a large number of judgments of this Court including
Constitution Bench judgments of this Court viz. Prem Chand Garg v. Excise Commr.
[AIR 1963 SC 996] ; Supreme Court Bar Assn. v. Union of India [(1998) 4 SCC 409 :
AIR 1998 SC 1895] and E.S.P. Rajaram v. Union of India [(2001) 2 SCC 186 : 2001
SCC (L&S) 352 : AIR 2001 SC 581]."
249. The same view was taken in Manish Goel v. Rohini Goel156:
"14. Generally, no court has competence to issue a direction contrary to law nor can
the court direct an authority to act in contravention of the statutory provisions. The
courts are meant to enforce the rule of law and not to pass the orders or directions
which are contrary to what has been injected by law. (Vide State of Punjab v. Renuka
Singla [(1994) 1 SCC 175] , State of U.P. v. Harish Chandra [(1996) 9 SCC 309 : 1996
SCC (L&S) 1240 : AIR 1996 SC 2173] , Union of India v. Kirloskar Pneumatic Co. Ltd.
[(1996) 4 SCC 453 : AIR 1996 SC 3285] , University of Allahabad v. Dr. Anand
Prakash Mishra [(1997) 10 SCC 264 : 1997 SCC (L&S) 1265] and Karnataka SRTC v.
Ashrafulla Khan [(2002) 2 SCC 560 : AIR 2002 SC 629] .) The Constitution Benches
of this Court in Supreme Court Bar Assn. v. Union of India [(1998) 4 SCC 409 : AIR
1998 SC 1895] and E.S.P. Rajaram v. Union of India [(2001) 2 SCC 186 : 2001 SCC
(L&S) 352 : AIR 2001 SC 581] held that under Article 142 of the Constitution, this
Court cannot altogether ignore the substantive provisions of a statute and pass orders
concerning an issue which can be settled only through a mechanism prescribed in
another statute. It is not to be exercised in a case where there is no basis in law which
can form an edifice for building up a superstructure.
16. Similar view has been reiterated in A.R. Antulay v. R.S. Nayak [(1988) 2 SCC 602
: 1988 SCC (Cri) 372] , Bonkya v. State of Maharashtra [(1995) 6 SCC 447 : 1995 SCC
(Cri) 1113] , Common Cause v. Union of India [(1999) 6 SCC 667 : 1999 SCC (Cri)
1196 : AIR 1999 SC 2979] , M.S. Ahlawat v. State of Haryana [(2000) 1 SCC 278 :
2000 SCC (Cri) 193 : AIR 2000 SC 168] , M.C. Mehta v. Kamal Nath [(2000) 6 SCC
213 : AIR 2000 SC 1997] , State of Punjab v. Rajesh Syal [(2002) 8 SCC 158 : 2002
SCC (Cri) 1867] , Govt. of W.B. v. Tarun K. Roy [(2004) 1 SCC 347 : 2004 SCC (L&S)
225] , Textile Labour Assn. v. Official Liquidator [(2004) 9 SCC 741 : AIR 2004 SC
2336] , State of Karnataka v. Ameerbi [(2007) 11 SCC 681 : (2008) 1 SCC (L&S) 975] ,
Union of India v. Shardindu [(2007) 6 SCC 276 : (2007) 2 SCC (L&S) 456 : AIR 2007Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

SC 2204] and Bharat Sewa Sansthan v. U.P. Electronics Corpn. Ltd. [(2007) 7 SCC
737 : AIR 2007 SC 2961]
19. Therefore, the law in this regard can be summarised to the effect that in exercise
of the power under Article 142 of the Constitution, this Court generally does not pass
an order in contravention of or ignoring the statutory provisions nor is the power
exercised merely on sympathy."
[Also see: A.B. Bhaskara Rao v. CBI157]
250. Construing the powers under Article 142 of the Constitution of India, the Supreme Court in
Laxmidas Morarji v. Behrose Darab Madan158 held that though the power is not restricted by
statutory enactments, but the Supreme Court would not pass an order which would supplant
substantive law or ignore express statutory provisions:
"25. Article 142 being in the nature of a residuary power based on equitable
principles, the Courts have thought it advisable to leave the powers under the article
undefined. The power under Article 142 of the Constitution is a constitutional power
and hence, not restricted by statutory enactments. Though the Supreme Court would
not pass any order under Article 142 of the Constitution which would amount to
supplanting substantive law applicable or ignoring express statutory provisions
dealing with the subject, at the same time these constitutional powers cannot in any
way, be controlled by any statutory provisions. However, it is to be made clear that
this power cannot be used to supplant the law applicable to the case. This means that
acting under Article 142, the Supreme Court cannot pass an order or grant relief
which is totally inconsistent or goes against the substantive or statutory enactments
pertaining to the case. The power is to be used sparingly in cases which cannot be
effectively and appropriately tackled by the existing provisions of law or when the
existing provisions of law cannot bring about complete justice between the parties."
(emphasis supplied)
251. The Supreme Court in Monica Kumar (Dr.) v. State of U.P.159 interpreted the word "cause" or
"matter" to include every kind of proceeding whether civil or criminal, and after noticing that no
provision like Section 482 Cr.P.C. conferred powers on the Supreme Court to quash or set aside
criminal proceedings pending before a criminal court to prevent abuse of the process of the Court,
the same was done by exercising powers under Article 142 of the Constitution of India read with
Article 32 and 136 of the Constitution of India:
"45. Under Article 142 of the Constitution this Court in exercise of its jurisdiction
may pass such decree or make such order as is necessary for doing complete justice in
any "cause" or "matter" pending before it. The expression "cause" or "matter" would
include any proceeding pending in court and it would cover almost every kind of
proceeding in court including civil or criminal. Though there is no provision likeChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Section 482 of the Criminal Procedure Code conferring express power on the
Supreme Court to quash or set aside any criminal proceedings pending before a
criminal court to prevent abuse of process of the court, but the inherent power of this
Court under Article 142 coupled with the plenary and residuary powers under
Articles 32 and 136 embraces power to quash criminal proceedings pending before
any court to do complete justice in the matter before this Court. If the Court is
satisfied that the proceedings in a criminal case are being utilised for oblique
purposes or if the same are continued on manufactured and false evidence or if no
case is made out on the admitted facts, it would be in the ends of justice to set aside
or quash the criminal proceedings. Once this Court is satisfied that the criminal
proceedings amount to abuse of process of court, it would quash such proceedings to
ensure justice. This Court's power under Article 142(1) to do "complete justice" is
entirely of different level and of a different quality. What would be the need of
"complete justice" in a cause or matter would depend upon the facts and
circumstances of each case and while exercising that power the Court would take into
consideration the express provisions of a substantive statute. Any prohibition or
restriction contained in ordinary laws cannot act as a limitation on the constitutional
power of this Court. Once this Court has seisin of a cause or matter before it, it has
power to issue any order or direction to do "complete justice" in the matter.
(emphasis supplied)
46. While considering the nature and ambit of its own power under this article, this
Court observed that it was advisable to leave its power undefined and uncatalogued
so that it remains elastic enough to be moulded to suit the given situation; even
where no alternative remedy is efficacious due to lapse of time. [See DDA v. Skipper
Construction Co. (P) Ltd. [(1996) 4 SCC 622] relying on Vinay Chandra Mishra, In re
[(1995) 2 SCC 584] and Kerala SEB v. Kurien E. Kalathil [(2000) 6 SCC 293] The
power to do complete justice under this Article is, in a way, corrective power, which
gives preference to equity over law. It is a residuary power, supplementary and
complementary to the powers specially conferred by the statutes to do complete
justice between the parties whenever it is just and equitable to do so. It is intended to
prevent any obstruction to the stream of justice."
252. The distinction between a principle of law which amounts to a binding precedent under Article
141 of the Constitution of India and directions issued under Article 142 of the Constitution of India
without laying down any principle of law was stated in Indian Drugs & Pharmaceuticals Ltd. v.
Workmen160 by holding thus:
"41. No doubt, in some decisions the Supreme Court has directed regularisation of
temporary or ad hoc employees but it is well settled that a mere direction of the
Supreme Court without laying down any principle of law is not a precedent. It is only
where the Supreme Court lays down a principle of law that it will amount to a
precedent. Often the Supreme Court issues directions without laying down anyChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

principle of law, in which case, it is not a precedent. For instance, the Supreme Court
often directs appointment of someone or regularisation of a temporary employee or
payment of salary, etc. without laying down any principle of law. This is often done
on humanitarian considerations, but this will not operate as a precedent binding on
the High Court. For instance, if the Supreme Court directs regularisation of service of
an employee who had put in 3 years' service, this does not mean that all employees
who had put in 3 years' service must be regularised. Hence, such a direction is not a
precedent. In Municipal Committee, Amritsar v. Hazara Singh [(1975) 1 SCC 794 :
1975 SCC (Cri) 354 : AIR 1975 SC 1087] the Supreme Court observed that only a
statement of law in a decision is binding. In State of Punjab v. Baldev Singh [(1999) 6
SCC 172 : 1999 SCC (Cri) 1080] this Court observed that everything in a decision is
not a precedent. In Delhi Admn. v. Manohar Lal [(2002) 7 SCC 222 : 2002 SCC (Cri)
1670 : AIR 2002 SC 3088] the Supreme Court observed that a mere direction without
laying down any principle of law is not a precedent. In Divisional Controller, KSRTC
v. Mahadeva Shetty [(2003) 7 SCC 197 : 2003 SCC (Cri) 1722] this Court observed as
follows : (SCC p. 206, para 23) "The decision ordinarily is a decision on the case
before the court, while the principle underlying the decision would be binding as a
precedent in a case which comes up for decision subsequently. ... The scope and
authority of a precedent should never be expanded unnecessarily beyond the needs of
a given situation. The only thing binding as an authority upon a subsequent Judge is
the principle upon which the case was decided."
253. While exercising the discretionary jurisdiction under Article 142 of the Constitution of India,
the Supreme Court in Sandeep Subhash Parate v. State of Maharashtra161 emphasised the need to
consider all relevant aspects of the matter including the decisions of the Supreme Court and stated
forth:
"14. It is not in dispute that the Bombay High Court held so. However, as it appears
from the decision of this Court in LIC [(2006) 2 SCC 471 : 2006 SCC (L&S) 329] that
the State might have also issued some government orders making such declaration.
Indisputably, the conduct of a party assumes significance in moulding the relief. This
Court, while exercising its discretionary jurisdiction and to do complete justice
between the parties in terms of Article 142 of the Constitution of India, must consider
all relevant aspects of the matter, including the decisions of this Court. The doctrine
of proportionality emerging from the recent trend of decisions in preference to the
doctrine of Wednesbury unreasonableness is also a factor which weighs with us. [See
Teri Oat Estates (P) Ltd. v. U.T., Chandigarh [(2004) 2 SCC 130] and A. Sudhakar v.
Post Master General [(2006) 4 SCC 348 : 2006 SCC (L&S) 817 : (2006) 3 Scale 524]
."
(emphasis supplied)
254. The Supreme Court in State of Haryana v. Sumitra Devi162 while defining the scope of
jurisdiction under Article 142 of the Constitution of India reiterated that no such order could beChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

passed in contravention of statute or statutory rules.
255. Same view was taken in Textile Labour Assn. v. Official Liquidator163.
256. The Supreme Court in M.S. Ahlawat v. State of Haryana164 recalled orders which were
purportedly passed under Article 142 of the Constitution of India without following the procedure
prescribed under Section 195 and 340 Cr.P.C. when the issue was raised before it by holding thus:
"12. This Court has always adopted this procedure whenever it is noticed that
proceedings before it have been tampered with by production of forged or false
documents or any statement has been found to be false. We have not been able to
appreciate as to why this procedure was given a go-by in the present case. Maybe the
provisions of Sections 195 and 340 CrPC were not brought to the notice of the learned
Division Bench.
13. In the light of the enunciation of law made by this Court in the Supreme Court Bar
Assn. case [(1998) 4 SCC 409] this Court could not have assumed jurisdiction by
issue of a notice proposing conviction for forgery and making false statements at
different stages in the Court punishable under Section 193 IPC without following the
procedure prescribed under Sections 195 and 340 CrPC. Primarily this Court does
not exercise any original criminal jurisdiction in relation to offences arising under
Section 193 IPC and secondly the seriousness of the charge arising under Section 193
IPC requires an elaborate inquiry and trial into the matter by the competent criminal
court and a summary inquiry by mere issuing a show-cause notice and considering
affidavits or inquiry reports would not tantamount to the procedure provided under
the Criminal Procedure Code. The order made by this Court convicting the petitioner
under Section 193 IPC is, therefore, one without jurisdiction and without following
the due procedure prescribed under law. Though it is not clear from the impugned
order whether the powers under Article 142 of the Constitution were exercised to
convict the petitioner under Section 193 IPC, we have proceeded on the assumption
that it is by exercise of that power that the impugned order had been made for there
is no other provision enabling the passing of such an order. As discussed earlier, in
view of the decision in Supreme Court Bar Assn. case [(1998) 4 SCC 409] such an
order could not have been made."
257. Despite the wide coverage of Article 142 of the Constitution of India the Supreme Court in State
of Punjab v. Bakshish Singh165 stated that the Court cannot ignore the substantive rights of a
litigant while dealing with a cause pending before it and declined to invoke Article 142 of the
Constitution of India:
"5. Learned counsel for the appellant contended that the respondent has not filed any
cross-appeal and, therefore, the order of remand passed by the lower appellate court
for a fresh order of punishment need not be interfered with, particularly as that order
has been upheld by the High Court which had summarily dismissed the secondChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

appeal filed by the State of Punjab. If, therefore, this Court intervenes in the matter
even in exercise of its power under Article 142 of the Constitution, the same would be
without jurisdiction. This contention cannot be accepted.
6. A Constitution Bench of this Court in Supreme Court Bar Assn. v. Union of India
[(1998) 4 SCC 409 : AIR 1998 SC 1895] has already held that while exercising power
under Article 142 of the Constitution, the court cannot ignore the substantive rights
of a litigant while dealing with a cause pending before it. The power cannot be used to
"supplant" substantive law applicable to a case. The Court further observed that
Article 142, even with the width of its amplitude, cannot be used to build a new
edifice where none existed earlier, by ignoring express statutory provisions dealing
with a subject and thereby achieve something indirectly which cannot be achieved
directly."
(emphasis supplied)
258. The Supreme Court in Chandrakant Patil v. State166 restrained frequent use of powers under
Article 142 of the Constitution by holding thus:
"9. It is now well nigh settled that Supreme Court's powers under Article 142 of the
Constitution are vastly broad-based. That power in its exercise is circumscribed only
by two conditions, first is, that it can be exercised only when Supreme Court
otherwise exercises its jurisdiction and the other is that the order which Supreme
Court passes must be necessary for doing complete justice in the cause or matter
pending before it. The first condition is satisfied here as the appellate jurisdiction of
the Supreme Court is exercisable by virtue of Section 19 of TADA.
10. In Delhi Judicial Service Assn. v. State of Gujarat [(1991) 4 SCC 406] as also in
Union Carbide Corpn. v. Union of India [(1991) 4 SCC 584] , this Court made the
position clear that power under Article 142 of the Constitution is entirely of different
level and is of a different quality which cannot be limited or restricted by provisions
contained in statutory law. No enactment made by the Central or State Legislature
can limit or restrict the power of this Court under Article 142, though while exercising
it the Court may have regard to statutory provisions. In Mohd. Anis v. Union of India
[1994 Supp (1) SCC 145 : 1994 SCC (Cri) 251] , Ahmadi, J. (as the learned Chief
Justice then was) by following the dictum in the above-mentioned decisions has
observed in para 6, as follows: (SCC p. 149) "This power has been conferred on the
Apex Court only and the exercise of that power is not dependent or conditioned by
any statutory provision. The constitutional plenitude of the powers of the Apex Court
is to ensure due and proper administration of justice and is intended to be
co-extensive in each case with the needs of justice of a given case and to meeting any
exigency. Very wide powers have been conferred on this Court for due and proper
administration of justice and whenever the Court sees that the demand of justice
warrants exercise of such powers, it will reach out to ensure that justice is done byChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

resorting to this extraordinary power conferred to meet precisely such a situation."
13. We are aware that powers under Article 142 are not to be exercised frequently but only sparingly.
The occurrence described in this case is not the usual type of crimes reaching this Court. When all
the four accused were caught red-handed while making nocturnal movements towards some
targeted destination, in the densely crowded city with highly lethal and quickly explosive articles, it
is a matter of reasonable imagination that, had they not been timely intercepted by the alert and
vigilant police force, the consequences would have been disastrous and calamitous. We have no
manner of doubt that the sentence of imprisonment of five years for the offence under Section 5 of
the TADA in the circumstances of this case is too inadequate and it warrants enhancement."
(emphasis supplied)
259. Construing the powers under Article 142 as a constituent power transcending statutory
prohibitions and its relationship with the law declared under Article 32, 136, 141 of the Constitution
of India, the Supreme Court in Ashok Kumar Gupta v. State of U.P.167 held:
"60. It would be seen that there is no limitation under Article 142(1) on the exercise
of the power by this Court. The necessity to exercise the power is to do "complete
justice in the cause or matter". The inconsistency with statute law made by
Parliament arises when this Court exercises power under Article 142(2) for the
matters enumerated therein. Inconsistency in express statutory provisions of
substantive law would mean and be understood as some express prohibition
contained in any substantive statutory law. The power under Article 142 is a
constituent power transcendental to statutory prohibition. Before exercise of the
power under Article 142(2), the Court would take that prohibition (sic provision) into
consideration before taking steps under Article 142(2) and we find no limiting words
to mould the relief or when this Court takes appropriate decision to mete out justice
or to remove injustice. The phrase "complete justice" engrafted in Article 142(1) is the
word of width couched with elasticity to meet myriad situations created by human
ingenuity or cause or result of operation of statute law or law declared under Articles
32, 136 and 141 of the Constitution and cannot be cribbed or cabined within any
limitations or phraseology. Each case needs examination in the light of its backdrop
and the indelible effect of the decision. In the ultimate analysis, it is for this Court to
exercise its power to do complete justice or prevent injustice arising from the
exigencies of the cause or matter before it. The question of lack of jurisdiction or
nullity of the order of this Court does not arise. As held earlier, the power under
Article 142 is a constituent power within the jurisdiction of this Court. So, the
question of a law being void ab initio or nullity or voidable does not arise."
(emphasis supplied)
260. The Supreme Court has given full effect to the wide amplitude of powers under Article 142 of
the Constitution of India to do complete justice between the parties as is comprehended in theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

provision.
261. The very nature of the power is such that it is not amenable to precise definition, and the
Supreme Court has not confined it in narrow bounds. However, restrictions have been devised by
the Supreme Court for exercise of powers under Article 142 of the Constitution of India.
262. Clearly the powers under Article 142 of the Constitution of India as per the holdings of the
Supreme Court are malleable enough to serve justice in the facts of a case, but not sufficiently fluid
to create fault lines in the edifice of law.
VI B(II) Article 142 & Asian Resurfacing (supra)
263. The submissions squarely raised before this Court do give rise to substantial questions
pertaining to interpretation of the Constitution which in the facts and circumstances of this case are
liable to be adjudicated with finality by the Supreme Court.
264. The question is whether peremptory directions issued by the Supreme Court in Asian
Resurfacing (supra) under Article 142 will prevail over explicit law expounded by the Supreme Court
in A. R. Antulay (supra) and P. Ramachandra Rao (supra) under Article 141? This conflict between
the two provisions is a substantial question which relates to the interpretation of the constitution.
265. There is also one corollary. The concept of judicial discipline envisages that the law laid down
by a Bench of higher strength is binding on a Bench of lesser strength is part of the body of law of
binding precedents relatable to Article 141 of the Constitution of India. The question of
constitutional interpretation which may arise is that whether the said dictum is also applicable to
Article 142 of the Constitution of India.
266. The question also arises whether the amplitude of Article 142 gives it primacy over other
provisions of the Constitution and the law, namely, Articles 141, 226, 227 of the Constitution of
India and Section 482 Cr.P.C.?
267. There is another facet of the scope of Article 142 which comes in sharp focus in the facts of this
case from the submissions raised before this Court by the learned counsels.
268. The substantial questions as to interpretation of the Constitution arising from the holdings of
the Supreme Court in Pepsico Foods Ltd. (supra) and its interface with Article 142 will not be
discussed.
269. In summation, the holdings in Pepsico Foods Ltd. (supra) show that the constitutional law has
set its face against legislative enactments which contemplate the automatic vacation of stay orders
upon lapse of a particular period of time even when the litigant cannot be faulted for the delay. The
timeless legal maxim "Actus Curiae Neminem Gravabit" i.e. the litigant cannot be prejudiced by an
act of the Court, is entrenched in the body of legal precedents unanimously rendered by various
Constitutional Courts in the country. Further arbitrary curtailment or restriction by the legislatureChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

on powers to extend interim orders will render the substantive rights of the parties before the
court/tribunal nugatory, and the remedy for adjudication of such rights will become a nullity.
270. A legislative enactment (Section 254-A I.T. Act) bearing likeness in form, substance and effect
to the directions in Paras 34, 36, 37 of Asian Resurfacing (supra) has been held to be violative of
Article 14 and read down by the Supreme Court in Pepsico (supra). The submission at the Bar is that
an act which is prohibited by the courts for the legislature cannot be made permissible in "judicial
legislation". Further powers under Article 142 cannot be exercised in contravention of Part III of the
Constitution of India.
271. Moreover litigants aggrieved by legislative enactments (even Constitutional amendments) have
the remedy of judicial review. Absence of remedy against judicial legislation created by directions
issued under Article 142, and immunity of such legislation from judicial review also raises
substantial questions as to interpretation of the Constitution.
272. The consequence of concentration of powers in one department of government and the broad
separation of powers as applicable in India were stated by Y.V. Chandrachud, J. (as the then Hon'ble
Chief Justice of India was) in Indira Nehru Gandhi Vs Raj Narain168. In this context it would also
be apposite to extract the principles of "distinction between judicial and other powers which are vital
to the maintenance of Constitution itself" and the adherence to fine checks and balances between
three organs without which no constitution can survive as propounded in Indira Nehru Gandhi
(supra):
"685. The truth of the matter is that the existence, and the limitations on the powers
of the three departments of government are due to the normal process of
specialisation in governmental business which becomes more and more complex as
civilization advances. The legislature must make laws, the executive enforce them and
the judiciary interpret them because they have in their respective fields acquired an
expertise which makes them competent to discharge their duly appointed functions.
The Moghal Emperor, Jehangir, was applauded as a reformist because soon after his
accession to the throne in 1605, he got a golden chain with sixty bells hung in his
palace so that the common man could pull it and draw the attention of the ruler to his
grievances and sufferings. The most despotic monarch in the modern world prefers to
be armed, even if formally, with the opinion of his judges on the grievances of his
subjects.
686. The political usefulness of the doctrine of separation of powers is now widely
recognized though a satisfactory definition of the three functions is difficult to evolve.
But the function of the Parliament is to make laws, not to decide cases. The British
Parliament in its unquestioned supremacy could enact a legislation for the settlement
of a dispute or it could, with impunity, legislate for the boiling of the Bishop of
Rochester's cook. The Indian Parliament will not direct that an accused in a pending
case shall stand acquitted or that a suit shall stand decreed. Princely India, in some
parts, often did it.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

(emphasis supplied)
687. The reason of this restraint is not that the Indian Constitution recognizes any
rigid separation of powers. Plainly, it does not. The reason is that the concentration
of powers in any one organ may, by upsetting that fine balance between the three
organs, destroy the fundamental premises of a democratic government to which we
are pledged. Sir Carleton K. Alien says in his Law and Orders (1965 Edn., p. 8) that
neither in Montesquieu's analysis nor in Locke' s are the governmental powers
conceived as the familiar trinity of legislative, executive and judicial powers.
Montesquieu's "separation" took the form not of impassable barriers and unalterable
frontiers, but of mutual restraints, or of what afterwards came to be known as
"checks and balances" (p. 10). The three organs must act in concert, not that their
respective functions should not ever touch one another. If this limitation is respected
and preserved, "it is impossible for that situation to arise which Locke and
Montesquieu regarded as the eclipse of liberty -- the monopoly, or the
disproportionate accumulation, of power in one sphere" (p. 19; Allen). In a federal
system which distributes powers between three coordinate branches of Government,
though not rigidly, disputes regarding the limits of constitutional power have to be
resolved by courts and therefore, as observed by Paton, "the distinction between
judicial and other powers may be vital to the maintenance of the Constitution itself" [
A Text-book of Jurisprudence (1964) p. 295] . Power is of an encroaching nature,
wrote Madison in The Federalist. The encroaching power which the federalists feared
most was the legislative power and that, according to Madison, is the danger of all
republics. Allen says that the history of both the United States and France has shown
on many occasions that the fear was not unjustified."
(emphasis supplied)
688. I do not suggest that such an encroaching power will be pursued relentlessly or ruthlessly by
our Parliament. But no Constitution can survive without a conscious adherence to its fine checks
and balances. Just as courts ought not to enter into problems entwined in the "political thicket".
Parliament must also respect the preserve of the courts. The principle of separation of powers is a
principle of restraint which "has in it the precept, innate in the prudence of self-preservation (even if
history has not repeatedly brought it home), that discretion is the better part of valour" [ Julius
Stone : Social Dimensions of Law and Justice, (1966) p. 668] . Courts have, by and large, come to
check their valorous propensities. In the name of the Constitution, the Parliament may not also turn
its attention from the important task of legislation to deciding court cases for which it lacks the
expertise and the apparatus. If it gathers facts, it gathers facts of policy. If it records findings, it does
so without a pleading and without framing any issues. And worst of all, if it decides a court case, it
decides without hearing the parties and in defiance of the fundamental principle of natural justice."
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

273. The Supreme Court in Indira Nehru Gandhi (supra) stood at the vanguard in defence of the
prerogative of the courts to exercise judicial functions and negatived the legislative (Parliamentary
in this case) attempt to assume judicial powers by holding:
"689. The Parliament, by clause (4) of Article 329-A, has decided a matter of which
the country's courts were lawfully seized. Neither more nor less. It is true, as
contended by the learned Attorney-General and Shri Sen, that retroapective
validation is a well-known legislative process which has received the recognition of
this Court in tax cases, pre-emption cases, tenancy cases and variety of other matters.
In fact, such validation was resorted to by the legislature and upheld by this Court in
at least four election cases, the last of them being Kanta Kathuria v. Manak Chand
Surana [(1969) 3 SCC 268 : (1970) 2 SCR 835] . But in all of these cases, what the
legislature did was to change the law retrospectively so as to remove the reason of
disqualification, leaving it to the courts to apply the amended law to the decision of
the particular case. In the instant case the Parliament has withdrawn the application
of all laws whatsoever to the disputed election and has taken upon itself to decide
that the election is valid. Clause (5) commands the Supreme Court to dispose of the
appeal and the cross-appeal in conformity with the provisions of clause (4) of Article
329-A, that is, in conformity with the "judgment" delivered by the Parliament. The
"separation of powers does not mean the equal balance of powers", says Harold
Laski, but the exercise by the legislature of what is purely and indubitably a judicial
function is impossible to sustain in the context even of our cooperative federalism
which contains no rigid distribution of powers but which provides a system of
salutary checks and balances."
(emphasis supplied)
274. Further recalling the dissenting view of P.N. Bhagwati, J. (as the then Hon'ble Chief Justice of
India was) in Minerva Mills Ltd. and others Vs Union of India and others169, would be
enlightening:
"86. It is clear from the majority decision in Kesavananda Bharati case [Kesavananda
Bharati v. State of Kerala, (1973) 4 SCC 225 : 1973 Supp SCR 1 : AIR 1973 SC 1461]
that our Constitution is a controlled Constitution which confers powers on the
various authorities created and recognised by it and defines the limits of those
powers. The Constitution is suprema lex, the paramount law of the land and there is
no authority, no department or branch of the State which is above or beyond the
Constitution or has powers unfettered and unrestricted by the Constitution. The
Constitution has devised a structure of power relationship with checks and balances
and limits are placed on the powers of every authority or instrumentality under the
Constitution. Every organ of the State, be it the executive or the legislature or the
judiciary, derives its authority from the Constitution and it has to act within the
limits of such authority. Parliament too, is a creature of the Constitution and it can
only have such powers as are given to it under the Constitution. It has no inherentChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

power of amendment of the Constitution and being an authority created by the
Constitution, it cannot have such inherent power, but the power of amendment is
conferred upon it by the Constitution and it is a limited power which is so conferred.
Parliament cannot in exercise of this power so amend the Constitution as to alter its
basic structure or to change its identity. Now, if by constitutional amendment.
Parliament were granted unlimited power of amendment, it would cease to be an
authority under the Constitution, but would become supreme over it, because it
would have power to alter the entire Constitution including its basic structure and
even to put an end to it by totally changing its identity. It will therefore be seen that
the limited amending power of Parliament is itself an essential feature of the
Constitution, a part of its basic structure, for if the limited power of amendment were
enlarged into an unlimited power, the entire character of the Constitution would be
changed. It must follow as a necessary corollary that any amendment of the
Constitution which seeks, directly or indirectly, to enlarge the amending power of
Parliament by freeing it from the limitation of unamendability of the basic structure
would be violative of the basic structure and hence outside the amendatory power of
Parliament.
(emphasis supplied)
87. It is a fundamental principle of our constitutional scheme, and I have pointed this
out in the preceding paragraph, that every organ of the State, every authority under
the Constitution, derives its power from the Constitution and has to act within the
limits of such power. But then the question arises as to which authority must decide
what are the limits on the power conferred upon each organ or instrumentality of the
State and whether such limits are transgressed or exceeded. Now there are three
main departments of the State amongst which the powers of government are divided;
the executive, the legislature and the judiciary. Under our Constitution we have no
rigid separation of powers as in the United States of America, but there is a broad
demarcation, though, having regard to the complex nature of governmental
functions, certain degree of overlapping is inevitable. The reason for this broad
separation of powers is that "the concentration of powers in any one organ may" to
quote the words of Chandrachud, J., (as he then was) in Indira Gandhi case [(1975)
Supp SCC 1 : AIR 1975 SC 2299 : (1976) 2 SCR 341] "by upsetting that fine balance
between the three organs, destroy the fundamental premises of a democratic
government to which we are pledged". Take for example, a case where the executive
which is in charge of administration acts to the prejudice of a citizen and a question
arises as to what are the powers of the executive and whether the executive has acted
within the scope of its powers. Such a question obviously cannot be left to the
executive to decide and for two very good reasons. First, the decision of the question
would depend upon the interpretation of the Constitution and the laws and this
would pre-eminently be a matter fit to be decided by the judiciary, because it is the
judiciary which alone would be possessed of expertise in this field and secondly, the
constitutional and legal protection afforded to the citizen would become illusory, if itChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

were left to the executive to determine the legality of its own action. So also if the
legislature makes a law and a dispute arises whether in making the law the legislature
has acted outside the area of its legislative competence or the law is violative of the
fundamental rights or of any other provisions of the Constitution, its resolution
cannot, for the same reasons, be left to the determination of the legislature. The
Constitution has, therefore, created an independent machinery for resolving these
disputes and this independent machinery is the judiciary which is vested with the
power of judicial review to determine the legality of executive action and the validity
of legislation passed by the legislature. It is the solemn duty of the judiciary under the
Constitution to keep the different organs of the State such as the executive and the
legislature within the limits of the power conferred upon them by the Constitution.
This power of judicial review is conferred on the judiciary by Articles 32 and 226 of
the Constitution. Speaking about draft Article 25, corresponding to present Article 32
of the Constitution, Dr Ambedkar, the principal architect of our Constitution, said in
the Constituent Assembly on December 9, 1948:
(emphasis supplied) "If I was asked to name any particular Article in this
Constitution as the most important -- an Article without which this Constitution
would be a nullity -- I could not refer to any other Article except this one. It is the
very soul of the Constitution and the very heart of it and I am glad that the House has
realised its importance. (CAD, Vol. 7, p.953)"
It is a cardinal principle of our Constitution that no one howsoever highly placed and no authority
however lofty can claim to be the sole judge of its power under the Constitution or whether its action
is within the confines of such power laid down by the Constitution. The judiciary is the interpreter of
the Constitution and to the judiciary is assigned the delicate task to determine what is the power
conferred on each branch of government, whether it is limited, and if so, what are the limits and
whether any action of that branch transgresses such limits. It is for the judiciary to uphold the
constitutional values and to enforce the constitutional limitations. That is the essence of the rule of
law, which inter alia requires that "the exercise of powers by the government whether it be the
legislature or the executive or any other authority, be conditioned by the Constitution and the law".
The power of judicial review is an integral part of our constitutional system and without it, there will
be no government of laws and the rule of law would become a teasing illusion and a promise of
unreality. I am of the view that if there is one feature of our Constitution which, more than any
other, is basic and fundamental to the maintenance of democracy and the rule of law, it is the power
of judicial review and it is unquestionably, to my mind, part of the basic structure of the
Constitution. Of course, when I say this I should not be taken to suggest that effective alternative
institutional mechanisms or arrangements for judicial review cannot be made by Parliament. But
what I wish to emphasise is that judicial review is a vital principle of our Constitution and it cannot
be abrogated without affecting the basic structure of the Constitution. If by a constitutional
amendment, the power of judicial review is taken away and it is provided that the validity of any law
made by the legislature shall not be liable to be called in question on any ground, even if it is outside
the legislative competence of the legislature or is violative of any fundamental rights, it would be
nothing short of subversion of the Constitution, for it would make a mockery of the distribution ofChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

legislative powers between the Union and the States and render the fundamental rights meaningless
and futile. So also if a constitutional amendment is made which has the effect of taking away the
power of judicial review and providing that no amendment made in the Constitution shall be liable
to be questioned on any ground, even if such amendment is violative of the basic structure and,
therefore, outside the amendatory power of Parliament, it would be making Parliament sole judge of
the constitutional validity of what it has done and that would, in effect and substance, nullify the
limitation on the amending power of Parliament and affect the basic structure of the Constitution.
The conclusion must therefore inevitably follow that clause (4) of Article 368 is unconstitutional and
void as damaging the basic structure of the Constitution."
(emphasis supplied)
275. In wake of preceding observations in Indira Nehru Gandhi (supra) and Minerva Mills (supra),
it is evident that "distinction between the judicial and other powers" has to be kept in mind while
preserving the salutary system of the structure of power relationship with checks and balances and
limits on the power of every authority or instrumentality under the Constitution. According to the
learned members of the Bar this caution would apply both to the judiciary and the legislature.
276. The constraints of the legislature to exercise judicial functions are much akin to the limitations
of the superior courts to undertake legislative exercises.
277. The expertise of the legislature and their apparatus and procedures are best suited to the most
important task of legislation. The inherent difficulties of the legislature to undertake the task of
judging have been brought out in Indira Nehru Gandhi (supra).
278. If judging by the legislature is forbidden, what are the restrictions on legislation by the courts?
279. The limitations of the capacity of the judiciary for undertaking legislative exercises cannot be
denied. The process of courts is siloed by its very nature, restricts participation as a matter of
practice, and adheres to the discipline of pleadings and evidences before the Court as a rule.
Legislation requires a much broader outreach, a more open consultative process and a different
institutional experience. The intellectual capital created by the process of courts is often inadequate
for the complex task of legislation.
280. It is for this reason that from time to time the Supreme Court has created red lines on the
exercise of powers under Article 142, particularly in certain fields of judicial legislation.
281. However, the issue cannot be approached in a pedantic manner, but has to be understood in a
nuanced fashion.
282. The Courts cannot neglect consideration of another important facet of this issue. Complexities
of modern day governance defy comprehensive cataloguing and watertight compartmentalization of
legislative and judicial powers. The fast pace of socio-economic changes and the lightning speed of
technological advancement outstrip the capacity of the legislature and at times of the executive toChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

deal with the fruits of advancing technology and the challenges of social change. Consequently at
times the legislature and the executive cannot address such issues with the required promptitude.
283. On many occasions the Courts become cognizant of social and legal problems arising from
socio-economic and technological developments much before the cause is brought in the
consciousness of the legislative process or in the realm of execution action. There are many
instances where absence of legislation or executive inaction implicates fundamental rights of
citizens. Legislative lag and executive inertia cannot cause a constitutional stasis.
284. In such situations, the superior courts cannot become silent spectators and standby. The
process of realization of fundamental rights of the citizenry will never standstill. The courts have to
protect the fundamental rights of the citizens at all times, and constitutional guarantees have to be
enforced on demand.
285. Fruitful exercise of judicial legislation was evidenced in Vishaka and others Vs State of
Rajasthan and others170. This was one cause where the legislative field was vacant and judicial
legislation was made to secure the fundamental rights of a vulnerable class of citizens. Subsequently,
the legislature enacted the law [The Sexual Harassment of Women at Workplace (Prevention,
Prohibition and Redressal) Act, 2013] to provide statutory remedies to the aggrieved citizens.
286. This Court too on various occasions is confronted with similar issues. In Saumya Tiwari Vs.
State of U.P. and others171 absence of Maternity Leave Regulations was the justification of the
University to deny the maternity benefits and maternity support systems to a student who was an
expectant mother.
287. This Court in Saumya Tiwari (supra) while relying on the law laid down by the Supreme Court
in Rattan Chand Hira Chand v. Askar Nawaz Jung172, K.S. Puttaswamy v. Union of India173,
Vishaka and others Vs State of Rajasthan and others174 held as under:
"59. The fast pace of life in modern times often outstrips the capacity of the
legislature to cope with the consequences of social change. There is a limit to human
foresight, but the possibilities of life are limitless. The limits of legislation are the
constraints of human foresight. The legislative process is complex and even time
taking. Human affairs do not wait on the legislative process. These facts frequently
create a legislative lag. It is almost inevitable in the nature of things.
60. The first intersection of life with law, at times happens in courts, even before the
legislatures grapple with the problems. The courts are often seized of various
emerging issues in social and individual lives, before the legislatures are cognizant of
them.
61. A legislative hiatus or executive lethargy cannot cause a constitutional stasis. The
enforcement of fundamental rights cannot be forestalled by a legislative lag or
executive inertia or a regulatory void. Constitutional guarantees and FundamentalChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Rights have to be enforced on demand. Constitutional overhang is perpetual. Law is
always in motion and never at a standstill. The Constitution of India is a forever
living organism. Constitutional law can never be stone deaf to calls of violations of
fundamental rights.
62. The text of the Constitution contains a conceptual philosophy of fundamental
rights, and is not an exhaustive compendium of all fundamental rights. The text of
the Constitution is constant, fundamental rights are always evolving. This is the
essence of constitutional law jurisprudence.
63. There is a method in the evolution of constitutional law jurisprudence. Evolution
of constitutional law rights are guided and controlled by the text of the constitution,
long settled judicial principles of interpretation of the constitution, and judicial
precedents in point. The march of law is also assisted by consensus of values in the
comity of civilized nations. These universal values are often manifested in
international instruments. Another source of such values is comparative
international jurisprudence. The felt needs of the times are also factored in by the
courts. Development of constitutional law and evolution of fundamental rights
happens on these sure foundations. Fundamental rights are thus distilled by the
constitutional courts in discharge of their constitutional obligations. This is not
judicial activism by courts. It is judging.
64. The Supreme Court in Vishaka v. State of Rajasthan19, issued various guidelines
for the safety of women at working places. The guidelines held the field, till the
Parliament enacted a legislation. Judicial directions in that case preceded the
legislative enactment. Infact the legislature was alerted, to the need of a legislation to
cover the field, by the judgment of the constitutional court.
65. This narrative will profit from the observations made in Rattan Chand Hira
Chand v. Askar Nawaz Jung:
"The legislature often fails to keep pace with the changing needs and values nor is it
realistic to expect that it will have provided for all contingencies and eventualities. It
is, therefore, not only necessary but obligatory on the courts to step in to fill the
lacuna. When courts perform this function undoubtedly they legislate judicially. But
that is a kind of legislation which stands implicitly delegated to them to further the
object of the legislation and to promote the goals of the society. Or to put it
negatively, to prevent the frustration of the legislation or perversion of the goals and
values of the society. So long as the courts keep themselves tethered to the ethos of
the society and do not travel off its course, so long as they attempt to furnish the felt
necessities of the time and do not refurbish them, their role in this respect has to be
welcomed.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

All courts have at one time or the other felt the need to bridge the gap between what
is and what is intended to be. The courts cannot in such circumstances shirk from
their duty and refuse to fill the gap. In performing this duty they do not foist upon the
society their value judgments. They respect and accept the prevailing values, and do
what is expected of them. The courts will, on the other hand, fail in their duty if they
do not rise to the occasion but approve helplessly of an interpretation of a statute or a
document or of an action of an individual which is certain to subvert the societal
goals and endanger the public good."
66. K.S. Puttaswamy (supra) unequivocally set forth that determining different facets of dignified
existence which fall within Article 21 of the Constitution of India, is a function of judicial review:
"127. The submission that recognising the right to privacy is an exercise which would
require a constitutional amendment and cannot be a matter of judicial interpretation
is not an acceptable doctrinal position. The argument assumes that the right to
privacy is independent of the liberties guaranteed by Part III of the Constitution.
There lies the error. The right to privacy is an element of human dignity. The sanctity
of privacy lies in its functional relationship with dignity. Privacy ensures that a
human being can lead a life of dignity by securing the inner recesses of the human
personality from unwanted intrusion. Privacy recognises the autonomy of the
individual and the right of every person to make essential choices which affect the
course of life. In doing so privacy recognises that living a life of dignity is essential for
a human being to fulfill the liberties and freedoms which are the cornerstone of the
Constitution. To recognise the value of privacy as a constitutional entitlement and
interest is not to fashion a new fundamental right by a process of amendment
through judicial fiat. Neither are the Judges nor is the process of judicial review
entrusted with the constitutional responsibility to amend the Constitution. But
judicial review certainly has the task before it of determining the nature and extent of
the freedoms available to each person under the fabric of those constitutional
guarantees which are protected. Courts have traditionally discharged that function
and in the context of Article 21, as we have already noted, a panoply of protections
governing different facets of a dignified existence has been held to fall within the
protection of Article 21."
77. The respondent University has neglected to frame Regulations or create appropriate legal
instruments to provide for maternity benefits to expectant mothers and new mothers. The failure of
the University to perform its statutory functions has left the students bereft of maternity benefits.
This inertia of the University betrays its insensitivity to the plight of pregnant students, undermines
the rule of law and subverts the ideal of holistic education. The University cannot justify violation of
fundamental rights of the petitioner on the foot of its own omissions.
86. By failing to frame Regulations or appropriate legal instruments for grant of maternity benefits
and by declining to grant such benefits to the petitioner, the University has violated the fundamental
rights of the petitioner as guaranteed under Articles 14, 15(3) and 21 of the Constitution of India andChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

as expounded in the law laid down by Constitutional Courts.
88. A writ in the nature of mandamus is issued to the respondent-University to execute the
following directions:
I. The University shall create Regulations/Ordinances/appropriate legal instruments
for grant of pre-natal and post-natal support and other maternity benefits to
expectant mothers and new mothers who are pursuing various courses in the
University. The maternity benefits shall also include additional chances to clear the
exams in an enlarged time frame."
288. The scope of judicial legislation gives rise to various substantial questions as to
interpretation of the powers under Article 142 of the Constitution of India and the
concept of broad separation of powers under the constitutional scheme.
VI C. High Court & Supreme Court: Relationship
289. The Constitution has created a hierarchy of appellate courts, and a comity of Constitutional
Courts. Under the Constitution, the Supreme Court is the final court of appeal for all citizens of the
country. In reality the High Courts are the courts of last resort for a vast majority of litigants. This
among other reasons impelled the Constitution makers to vest the status of Constitutional Courts
and courts of records in the High Courts and the Supreme Courts. The High Courts and the Supreme
Court are thus endowed with congruent powers to serve the overarching common purposes to act ex
debito justitiae, uphold fundamental liberties, prevent miscarriage of justice, and interpret the
Constitution and the laws. High Courts make access to justice easy and approachable in the first
instance to most citizens.
290. The High Courts and the Supreme Court comprise the comity of Constitutional Courts. When
judgments of the High Courts are carried in appeal and the Supreme Court hands down the final
judgments in the lis, a legal and a constitutional discourse happens between the courts. In this
process, the lis arrives at a terminus and the rights of parties are adjudicated with finality.
291. Simultaneously other important transitions happen. The constitutional discourse guides the
evolution of constitutional law, and a national consensus of constitutional values emerges. The
judicial discourse of this nature cements the unity of the nation. The manner and conduct of the
constitutional dialogue amongst the comity of Constitutional Courts is most critical to the process of
evolution of law, defining rights of citizens and ultimately dispensing justice.
292. The relationship between the High Court and the Supreme Court has evolved both by long
standing judicial conventions and high authorities in point. (Some aspects of this relationship have
been discussed in the earlier part of the judgement.) Reference to some authorities will fortify the
narrative.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

293. Acknowledging the powers of both Constitutional Courts namely the Supreme Court and High
Court to issue writs and also noticing that the powers of High Court under Article 226 of the
Constitution of India are wider than Article 32 of the Constitution of India, the Supreme Court in
Naresh Shridhar Mirajkar and Others Vs. State of Maharashtra and Another175 held:
"52. It is well-settled that the powers of this Court to issue writs of certiorari under
Article 32(2) as well as the powers of the High Courts to issue similar writs under
Article 226 are very wide. In fact, the powers of the High Courts under Article 226
are, in a sense, wider than those of this Court, because the exercise of the powers of
this Court to issue writs of certiorari are limited to the purposes set out in Article
32(1). The nature and the extent of the writ jurisdiction conferred on the High Courts
by Article 226 was considered by this Court as early as 1955 in T.C. Basappa v. T.
Nagappa [(1955) 1 SCR 250, at pp 256-8] . It would be useful to refer to some of the
points elucidated in this judgment. The first point which was made clear by
Mukherjea, J., who spoke for the Court, was that "in view of the express provisions in
our Constitution, we need not now look back to the early history or the procedural
technicalities of these writs in English law, nor feel oppressed by any difference or
change of opinion expressed in particular cases by English Judges. We can make an
order or issue a writ in the nature of certiorari in all appropriate cases and in
appropriate manner, so long as we keep to the broad and fundamental principles that
regulate the exercise of jurisdiction in the matter of granting such writs in English
law". One of the essential features of the writ, according to Mukherjea, J., is "that the
control which is exercised through it over judicial or quasi-judicial tribunals or bodies
is not in an appellate but supervisory capacity. In granting a writ of certiorari, the
superior court does not exercise the powers of an Appellate Tribunal. It does not
review or reweigh the evidence upon which the determination of the inferior tribunal
purports to be based. It demolishes the order which it considers to be without
jurisdiction or palpably erroneous but does not substitute its own views for those of
the inferior tribunal. The supervision of the superior Court exercised through writs of
certiorari goes to two points, one is the area of inferior jurisdiction and the
qualifications and conditions of its exercise; the other is the observance of law in the
course of its exercise. Certiorari may lie and is generally granted when a court has
acted without or in excess of its jurisdiction. The want of jurisdiction may arise from
the nature of the subject-matter of the proceeding or from the absence of some
preliminary proceeding or the court itself may not be legally constituted or suffer
from certain disability by reason of extraneous circumstances. When the jurisdiction
of the court depends upon the existence of some collateral fact, it is well settled that
the court cannot by a wrong decision of the fact give it jurisdiction which it would not
otherwise possess". It is in the light of these principles which have been consistently
followed by this Court in dealing with the problem relating to the exercise of the writ
jurisdiction by the High Courts under Article 226 or by this Court under Article 32,
that we must now proceed to deal with the point before us.
(emphasis supplied)Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

59. There is yet another aspect of this matter to which it is necessary to refer. The
High Court is a superior court of record and under Article 215, shall have all powers
of such a court of record including the power to punish contempt of itself. One
distinguishing characteristic of such superior courts is that they are entitled to
consider questions of their jurisdiction raised before them. This question fell to be
considered by this Court in Special Reference No. I of 1964 [(1965) 1 SCR 413 at p
499] . In that case, it was urged before this Court that in granting bail to Keshav
Singh, the High Court had exceeded its jurisdiction and as such, the order was a
nullity. Rejecting this argument, this Court observed that in the case of a superior
court of record, it is for the court to consider whether any matter falls within its
jurisdiction or not. Unlike a court of limited jurisdiction, the superior court is entitled
to determine for itself questions about its own jurisdiction. That is why this Court did
not accede to the proposition that in passing the order for interim bail, the High
Court can be said to have exceeded its jurisdiction with the result that the order in
question was null and void. In support of this view, this Court cited a passage from
Halsbury's Laws of England where it is observed that "prima facie, no matter is
deemed to be beyond the jurisdiction of a superior court unless it is expressly shown
to be so, while nothing is within the jurisdiction of an inferior court unless it is
expressly shown on the face of the proceedings that the particular matter is within
the cognizance of the particular court [Halsbury's Laws of England, Vol 9, p. 349] ". If
the decision of a superior court on a question of its jurisdiction is erroneous, it can, of
course, be corrected by appeal or revision as may be permissible under the law; but
until the adjudication by a superior court on such a point is set aside by adopting the
appropriate course, it would not be open to be corrected by the exercise of the writ
jurisdiction of this Court."
294. The judicial relationship between the High Court and Supreme Court reflected in the
judgements of Constitutional Courts impacts the functioning of the High Courts. Exploring various
facets of the relationship of the Supreme Court and the High Court, the former in Tirupati Balaji
Developers (P) Ltd. And Others Vs. State of Bihar and Others176 propounded:
"16. The Founding Fathers of the Constitution devised a justice-delivery system in the
country as one homogeneous in content, taking care of independence and hierarchy
both, and holding the scales of balance even while doing so. The Union judiciary and
the State judiciary are undoubtedly independent of each other except for a few areas
relating to jurisdiction as we have very briefly indicated hereinbefore. However, at
the same time, we cannot resist laying emphasis on the appellate hierarchy which,
examined in the correct perspective, is a factor strongly contributing towards the
independence of the judiciary and securing finality in adjudication within the system
and its insulation from any outside interference or correction. The delicate balance
has been carefully crafted and sought to be achieved by independence and
interconnection -- both existing simultaneously -- of the Supreme Court and the High
Courts. There are "relationships of tension as well as those of cooperation", to borrow
the expression employed by Frank M. Coffin in his work On Appeal -- Courts,Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

Lawyering, and Judging. He says, "on the sensitive and sophisticated application of
the various doctrines governing these relationships depends in large part the effective
functioning of our unique form of federalism". (at pp. 52-53)
18. How the Supreme Court and the High Court have to deal with each other specially
when the Supreme Court is exercising its appellate jurisdiction over a decision by, or
proceedings -- concluded or pending -- in the High Court? The Constitution has
clearly divided the jurisdiction between the two institutions and while doing so these
institutions have to have mutual respect for each other. The framers of the
Constitution did not think it necessary to specifically confer power on the Supreme
Court to give a command to the High Court for they were men of vision and foresight.
They knew that all the constitutional functionaries and institutions would act in the
best interest of norms and traditions consistent with democracy and
constitutionalism, set down in and discernible from the Constitution and as handed
down by history and generations of judges. Everyone would, it was expected, keep
within its bounds and would not overstep its limits so that the ideals and the values
remain a living reality and do not become either an intrusion or an illusion. The
constitutional and democratic institutions, complementing and supplementing each
other, would lend strength to these handed-down traditions and would also
contribute to developing such rich traditions as would be respected and hailed by
posterity. This would result in strengthening the working of the Constitution. In the
realms of constitutionalism the values of mutual trust and respect between the
functionaries, nurtured by tradition, alleviate the need to codify the rules of the
relationship. Experience shows that any rigid codification of such delicate
relationship is advantageous to those bent upon vilification. A rigid written law
makes it difficult to maintain that dignity which is better and rightly left to be
perceived by right-minded people who zealously uphold the dignity of others as they
do their own.
19. An institution dealing with another institution under the Constitution shall have
to observe grace and courtesy. No judge shall criticise another judge and certainly not
strongly. Any departure therefrom needs to be corrected at the earliest and in the
larger interest. It is obligatory on an appellate forum to correct such deviation from
rule brought to its notice as having been committed by a jurisdiction subject to appeal
and if it does not do so it fails in its duty. Undoubtedly, the corrective step too is
taken carefully with courtesy and respect and not by way of harsh criticism. An
instance quoted by David Pannick is worthy of reference and reverence. In a 1971 case
Mr Justice Lawson gave his reasons for doubting the correctness of an earlier
decision of the Court of Appeal. Nevertheless, he concluded, 'I am bound by the
decision in [the earlier case], although I am compelled to say, again with the greatest
respect, that I believe it to have been wrongly decided'. The Court of Appeal was very
unhappy. Lord Justice Davies replied, 'with the greatest respect to Lawson, J.', that
he thought that 'those observations were out of place. It is unusual, and, I am bound
to say, undesirable, in my opinion, for a judge sitting at first instance... to express theChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

opinion, although accepting that he is bound by it, that a decision, and a fairly recent
decision, of this court was wrong.' (Judges, pp. 127-28)
25. Harry T. Edwards, Chief Judge, US Court of Appeals for the DC Circuit
emphasises self-restraint as helping build up the courts' constitutional legitimacy
overtime inasmuch as judicial self-restraint helps both to generate and to preserve
judicial independence. In the context of dealing of judges by judges, he uses the term
"collegiality" and then he mentions the relationship between collegiality and
independence by saying:
"... an aspect of judicial practice that has seemed increasingly important to me over
the last decade: the practice of collegiality. By collegiality I mean an attitude among
judges that says, we may disagree on some substantive issues, but we all have a
common interest and goal in getting the law right. ... We are, in a word, one another's
colleagues. An attitude of collegiality means, in practice, that we respect one
another's views, listen to one another, and, where possible, aim to identify areas of
agreement. ... Collegiality does mean, however, that, even when I disagree with
another judge, I recognize that we are part of a common endeavor, and that each of
us is, almost always, acting in good faith according to his or her own view of what the
law requires. ... Because I see myself as engaged in a common endeavor with my
judicial colleagues, it follows that I have the interests of the judiciary as a whole at
heart. ... When there is little or no judicial collegiality, there is less incentive for
judges to exercise self-restraint. ... Collegiality is important not only for working
together effectively, but also at a deeper structural level. An attitude of judicial
collegiality helps reinforce judges' incentives to behave in a principled and
responsible fashion. I think that any discussion of judicial independence, either at the
level of institutions or individuals, should take this practice of collegiality into
account."
27. Cooperation can be achieved and tension avoided between two judicial institutions if only
judicial collegiality is learnt, nobility prevails and Holmes' humility rules.
29. While quoting the several authorities and references as hereinabove we should not be
misunderstood as calling "the Supreme Court a superior court and the High Court an inferior court";
all that we wish to say is that jurisdictionally, and in the hierarchical system, so far as the exercise of
appellate jurisdiction is concerned, undoubtedly, the Supreme Court is a superior forum and the
High Court an inferior forum in the sense that the latter is subjected to jurisdiction, called "appellate
jurisdiction", of the former.
30. The very existence of appellate jurisdiction obliges the lower jurisdiction to render all of its
assistance to the higher jurisdiction to enable the exercise of appellate jurisdiction fully and
effectively. The lower forum may be called upon to certify its record of case and proceedings to the
superior forum. The superior forum may stand in need of some information which being in the
possession or knowledge of the subordinate forum, shall have to be made available only by it. TheChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

superior forum may issue a stay order or restraint order or may suspend, expedite or regulate the
proceedings in the subordinate forum. During or at the end of exercise of the appellate jurisdiction
any direction made by the higher forum shall have to be complied with by the lower forum,
otherwise the hierarchy becomes meaningless."
295. The constitutional status of the High Courts is most invaluable. But experience shows that it
can be equally fragile. The constitutional status and autonomy of the High Courts will thrive when
shepherded with care in discourse between Constitutional Courts and buttressed in constitutional
law and honoured in constitutional conventions.
296. The constitutional vision will make a tryst with its destiny when in conventions and practices,
in law and in speech the Constitutional Courts follow the discipline of the hierarchy of appeals and
foster the collegiality in the comity of courts.
297. The Supreme Court in Shankar Kumar Jha vs. State of Bihar & Others177 made the following
observations depicting enduring constitutional wisdom in crisp words:
"The only prayer made in this petition filed under Article 136 of the Constitution of
India is to direct the High Court of Judicature at Patna to decide the pending writ
petition of the petitioner within a time bound schedule.
It may be noted here that the High Court is also a Constitutional Court and is not
subordinate to this Court. Every High Court has a different scenario when it comes to
pendency of old cases.
It is ultimately for the concerned High Court to fix its own priorities considering the
pendency of cases. The remedy of the petitioner is to apply to the High Court for
giving priority to the hearing of his case.
No relief can be granted in this petition. Accordingly, the same is dismissed. Pending
applications(s), if any, shall stand disposed of."
(emphasis supplied) VII(A). ARTICLE 132
298. The submissions made at the Bar are persuasive and even commend themselves for acceptance.
299. It was also urged that this Court should decide the controversy in light of the judgments in K.S.
Subramanian(supra) and Ganga Saran(supra).
300. However, the facts and circumstances arising out of Asian Resurfacing(supra) are rather
unprecedented. The extraordinary situation being faced by this Court has no parallel in living or
archival memory of the institution. The imperative directions in Para 34, 36, 37 of Asian
Resurfacing(supra) which were emphatically reiterated in Asian Resurfacing-II (supra), and also in
Asian Resurfacing-III (supra) create a unique predicament for this Court for which past authoritiesChandrapal Singh vs State Of U.P. And Another on 3 November, 2023

are not reliable guides. In this wake, it would not be apposite to adjudicate submissions made at the
Bar on merits. However, there is no denying the fact that the questions raised in the controversy go
to the heart of constitutional interpretation and the root of raison detre of the High Court.
Constitutional repose is not an option when faultlines have travelled to the very edifice of justice.
301. Recourse to Article 132 of the Constitution of India provides the most dignified and
constitutionally decorous way out of the dilemma. Judicial discipline instructs all courts to comply
with the directions of Asian Resurfacing (supra). Constitutional obligation mandates this Court to
frame substantial questions as to the interpretation of the Constitution which arise out of the
directions in Asian Resurfacing (supra).
302. The breadth of Article 132 of the Constitution of India underscores the importance of settling
constitutional issues with decisive pronouncements of the Supreme Court through an inclusive
judicial discourse amongst Constitutional Courts. The High Courts have their ears to the ground and
are first to be alerted to issues of constitutional importance which start affecting the common
citizens in a significant manner, or impacting the legitimacy of constitutional organs, or impeding
the administration of justice.
303. Article 132 of the Constitution of India assigns a pre-eminent role to the High Courts in
initiating the constitutional discourse on vital issues of constitutional interpretation. The provision
accords the paramount role to the Supreme Court in deciding the questions pertaining to
interpretation of the Constitution so framed by the High Court.
304. When the High Courts frame substantial questions as to interpretation of the Constitution
arising in the facts and circumstances of various cases, they lay down the framework of a
constitutional debate. The process creates a repository of constitutional thought where ideas survive
or perish on their merits, and the discourse is essential to enlightened opinion in the legal fraternity.
305. Article 132 envisages an internal mechanism of discourse of legal ideas and issues between the
Constitutional Courts which augments the capacity of the judicial process to address the myriad
challenges faced by the courts.
306. The framers of the Constitution by inserting Article 132 clearly envisioned free exchange and
frank speech in the discourse between Constitutional Courts. It is a core value of the Constitution
which ensures that evolution of law is responsive to the needs of justice and in conformity with Basic
Structure of the Constitution. If the Basic Structure of the Constitution is to remain inviolable, the
Core Values of the Constitution have to be indestructible.
VII. (B) SUBSTANTIAL QUESTIONS OF LAW AS TO INTERPRETATION OF THE
CONSTITUTION:
307. In the wake of the preceding narrative the following substantial questions of law as to the
interpretation of the Constitution arise for consideration.Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

I. Whether the directions in paras 34, 36, 37 of Asian Resurfacing (supra) run contrary to the law
laid down by the Five Judges Bench of the Supreme Court in A. R. Antulay (supra) and the Seven
Judges Bench of the Supreme Court in P. Ramachandra Rao (supra)?
II. Whether in view of non consideration of the judgments rendered by Constitution Benches in A.
R. Antulay (supra) and P. Ramachandra Rao (supra) in Asian Resurfacing (supra), the directions
issued in paras 34, 36, 37 of the Asian Resurfacing (supra) require reconsideration? As a corollary,
whether the judgments rendered by Larger Benches in A. R. Antulay (supra) and P. Ramachandra
Rao (supra) are liable to be followed in preference to the judgment by a Bench of lesser strength in
Asian Resurfacing (supra)?
III. Whether the directions in paras 34, 36, 37 of the Asian Resurfacing (supra) satisfy the
ingredients of law laid down by the Supreme Court under Article 141 of the Constitution of India?
IV. Whether the directions in paras 34, 36, 37 of the Asian Resurfacing (supra) are an instance of
"judicial legislation" and are relatable to Article 142 of the Constitution of India?
V. Whether the directions contained in paras 34, 36, 37 in Asian Resurfacing (supra) can be issued
by the Supreme Court under Article 142 of the Constitution of India and would such directions not
contravene the law laid down by the Supreme Court under Article 141 of the Constitution of India in
A. R. Antulay (supra) and P. Ramachandra Rao (supra)? Alternatively whether there is conflict
between Articles 142 and 141 of the Constitution of India arising in the context of Asian Resurfacing
(supra) and whether Article 142 will control Article 141?
VI. Whether the directions in paras 34, 36, 37 of Asian Resurfacing (supra) can be said to be in
conformity with Part III of the Constitution of India, when a similar parliamentary legislation
(Section 254 (2-A) of the Income Tax Act) was held to be violative of Article 14 of the Constitution of
India, and struck down by the Delhi High Court in Pepsi Foods Pvt. Ltd. Vs Deputy Commissioner of
Income Tax and Anr.178 and read down by the Bombay High Court in Narang Overseas Pvt. Ltd. Vs
Income Tax Appellate Tribunal and others179, the Gujarat High Court in CIT Vs Vodafone Essar
Gujarat Ltd.180, and finally read down by the Supreme Court in DCIT Vs Pepsi Foods Ltd.181? If the
answer is in the negative whether the said directions in Asian Resurfacing (supra) are liable to be
implemented?
VII. Alternatively whether "judicial legislation" made under Article 142 vide Asian Resurfacing
(supra) can be judicially reviewed on the grounds on which legislative enactments are tested? What
are the remedies for citizens who claim violation of Fundamental Rights by operation of "judicial
legislation" made under Article 142?
VIII. Whether in view of the fact that while all legislations or enactments made by the legislature can
be subjected to judicial review, but the absence of remedy of judicial review against judicial
legislations made under Article 142 of the Constitution, impacts the broad separation of powers
between the legislature and the judiciary?Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

IX. Whether in view of the fact that the powers vested in the High Courts by virtue of Articles 226
and 227 of the Constitution of India are part of the Basic Structure of the Constitution in light of the
law propounded by the Supreme Court in L. Chandra Kumar (supra), the directions in paras 34, 36,
37 of Asian Resurfacing (supra) by prescribing a strict time limit of interim orders and curtailing the
powers of High Courts under Articles 226 and 227 of the Constitution of India to extend interim
orders beyond that period damage the Basic Structure of the Constitution of India?
X. Whether in view of the findings of this Court that compliance of directions in paras 34, 36, 37 of
Asian Resurfacing (supra) is not realistically feasible, and automatic vacation of stay orders in
compliance of the said directions in Asian Resurfacing (supra) is visiting litigants with adverse
consequences for no fault of theirs, and that the trial courts are disregarding interim orders passed
by this Court, paired with the inability of the High Court to provide redress to the litigants is
adversely impacting administration of justice by the High Court, the said directions issued in Asian
Resurfacing (supra) are liable to be reconsidered?
VIII. Orders on Applications & Grant of Certificate For Appeal to the Supreme Court
308. In light of our deliberations and discussions held above, the applications filed by various
applicants are rejected. However, in view of the substantial questions formulated for consideration
by the Hon'ble Supreme Court under Article 132 of the Constitution of India, we grant Certificate
For Appeal to the Supreme Court to the applicants before us and all other persons who are similarly
circumstanced. The Registry is directed to forthwith issue necessary certificates directly to such
parties, as and when the parties approach the Registry.
309. Before concluding, this Court would like to place its appreciation on record for the efforts of the
members of the Bar who assisted the Court with scholarship and eloquence. In the highest traditions
of the Bar the counsels effectively raised the plight of litigants to ensure that citizenry does not lose
faith in the capacity of this Court to serve justice. We had recounted the glorious traditions of this
Court. But after hearing the young members of the Bar we are assured that the finest hour of this
Court is not in the past.
Order Date: 03.11.2023 Dhananjai/Vandit/Ashish/Pravin (Pritinker Diwaker, CJ.) (Ashwani Kumar
Mishra, J.) (Ajay Bhanot, J.)    Chandrapal Singh vs State Of U.P. And Another on 3 November, 2023

