Dayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012
Equivalent citations: AIR 2012 SUPREME COURT 3046, 2012 (8) SCC 263,
2012 AIR SCW 4488, AIR 2012 SC (CRIMINAL) 1481, (2013) 1 UC 264, 2012 (3)
SCC(CRI) 838, 2012 (7) SCALE 165, (2012) 3 CHANDCRIC 7, (2012) 2 ORISSA
LR 879, (2012) 3 CURCRIR 310, (2012) 3 ALLCRIR 2377, (2012) 4 ALLCRILR
149, (2012) 7 SCALE 165, (2012) 53 OCR 252, (2012) 3 RECCRIR 949, (2012) 3
DLT(CRL) 384
Author: Swatanter Kumar
Bench: Swatanter Kumar, Fakkir Mohamed Ibrahim Kalifulla
                                                                             REPORTABLE
                        IN THE SUPREME COURT OF INDIA
                       CRIMINAL APPELLATE JURISDICTION
                       CRIMINAL APPEAL NO.529 OF 2010
Dayal Singh & Ors.                                       … Appellants
                                   Versus
State of Uttaranchal                               … Respondent
                               J U D G M E N T
Swatanter Kumar, J.
1. Settled canons of criminal jurisprudence when applied in their correct perspective, give rise to the
following questions for consideration of the Court in the present appeal:
a) Where acts of omission and commission, deliberate or otherwise, are committed
by the investigating agency or other significant witnesses instrumental in proving the
offence, what approach, in appreciation of evidence, should be adopted?
b) Depending upon the answer to the above, what directions should be issued by the
courts of competent jurisdiction?
c) Whenever there is some conflict in the eye-witness version of events and the
medical evidence, what effect will it have on the case of the prosecution and whatDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

would be the manner in which the Court should appreciate such evidence?
2. The facts giving rise to the questions in the present appeal are that the fields of Gurumukh Singh
and Dayal Singh were adjoining in the village Salwati within the limits of Police Station Sittarganj,
district Udham Singh Nagar. These fields were separated by a mend (boundary mound). On 8th
December, 1985, Gurumukh Singh, the complainant, who was examined as PW2, along with his
father Pyara Singh, had gone to their fields. At about 12 noon, Smt. Balwant Kaur, PW4, wife of
Pyara Singh came to the fields to give meals to Pyara Singh and their son Gurumukh Singh. At about
12.45 p.m, the accused persons, namely, Dayal Singh, Budh Singh & Resham Singh (both sons of
Dayal Singh) and Pahalwan Singh came to the fields wielding lathis and started hurling abuses. They
asked Pyara Singh and Gurumukh Singh as to why they were placing earth on their mend, upon
which they answered that mend was a joint property belonging to both the parties. Without any
provocation, all the accused persons started attacking Pyara Singh with lathis. Gurumukh Singh,
PW2, at that time, was at a little distance from his father and Smt. Balwant Kaur, PW4, was nearby.
On seeing the occurrence, they raised an alarm and went to rescue Pyara Singh. The accused,
however, inflicted lathi injuries on both PW2 and PW4. In the meanwhile, Satnam Singh, who was
ploughing his fields, which were quite close to the fields of the parties and Uttam Singh (PW5) who
was coming to his village from another village, saw the occurrence. These two persons even
challenged the accused persons upon which the accused persons ran away from the place of
occurrence. Pyara Singh, who had been attacked by all the accused persons with lathis fell down and
succumbed to his injuries on the spot. Few villagers also came to the spot. According to the
prosecution, pagri (Ex.1) of one of the accused, Budh Singh, had fallen on the spot which was
subsequently taken into custody by the Police. Gurumukh Singh, PW2, left the dead body of his
deceased father in the custody of the villagers and went to the police station where he got the report,
Exhibit Ka-3, scribed by Kashmir Singh in relation to the occurrence. The report was lodged at
about 2.15 p.m. on 8th December, 1985 by PW2 in presence of SI Kartar Singh, PW6. FIR (Exhibit
Ka-4A) was registered and the investigating machinery was put into motion. The two injured
witnesses, namely, PW2 and PW4 were examined by Dr. P.C. Pande, PW1, the medical officer at the
Public Health Centre, Sittarganj on the date of occurrence. At 4.00 p.m., the doctor examined PW2
and noticed the following injuries on the person of the injured witness vide Injury Report, Ex. Ka-1.
PW-2 “1. Lacerated wound of 5 cm X 1 cm and 1 cm in depth. Margins were lacerated. Red fresh
blood was present over wound. Wound was caused by hard and blunt object. Wound was at the
junction of left parietal and occipital bone 7 cm from upper part of left ear caused by blunt object.
Advised X- ray. Skull A.P. and lateral and the injury was kept under observation.
2. Contusion of 6 cm X 2.5 cm on left side of body 3 cm above the left ilic crest. Simple in nature
caused by hard and blunt object.” According to the Doctor, the injuries were caused by hard and
blunt object and they were fresh in duration.
On 8.12.1985 at 7.30 p.m. Dr. P.C. Pande (PW1) examined the injuries of Smt. Balwant Kaur PW4
and found the following injuries on her person vide injury report Ex.Ka.2:
PW-4Dayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

1. Contusion 6 cm X 3 cm on left shoulder caused by hard and blunt object.
2. Contusion of 5 cm X 2 cm on lateral side of middle of left upper arm. Bluish red in
colour caused by hard and blunt object.
3. Contusion of 4 cm X 2 cm on left parietal bone 6 cm from left ear caused by hard
and blunt object.
According to Dr. Pande, these injuries were caused by hard and blunt object and the duration was
within 12 hours and the nature of the injuries was simple. According to Dr. Pande the injuries of
both these injured persons could have been received on 8.12.1985 at 12.45 p.m. by lathi.”
3. As noted above, according to Dr. Pande, the injuries were caused by a hard and blunt object and
duration was within 12 hours. Thereafter, SI Kartar Singh, PW6, proceeded to the place of
occurrence in village Salwati. He found the dead body of Pyara Singh lying in the fields. In the
presence of panchas, including Balwant Singh, PW8, he noticed that there were three injuries on the
person of the deceased, Pyara Singh and prepared Inquest Report vide Ex. Ka-6 recording his
opinion that the deceased died on account of the injuries found on his body. After preparing the site
plan, Ext. Ka-10, he also wrote a letter to the Superintendent, Civil Hospital, Haldwani for post
mortem, being Exhibit Ka-9. The dead body was taken to the said hospital by Constable Chandrapal
Singh, PW7. Dr. C.N. Tewari, PW3, medical officer in the Civil Hospital, Haldwani, performed the
post mortem upon the body of the deceased and did not find any ante-mortem or post-mortem
injuries on the dead body. On internal examination, he did not find any injuries and could not
ascertain the cause of death. Further, he preserved the viscera and gave the post-mortem report,
Exhibit Ka-4. After noticing that there was no injury or abnormality found upon external and
internal examination of the dead body, the doctor in his report recorded as under:
“Viscera in sealed jars handed over to the accompanying Constables.
Jar No.1 sample preservative saline water.
Jar No.2 Pieces of stomach Jar No.3 Pieces of liver, spleen and kidney.
Death occurred about one day back.
Cause of death could not be ascertained. Hence, viscera preserved.”
4. It appears from the record that the deceased’s viscera, which allegedly was handed over by doctor
to the police, was either never sent to the Forensic Science Laboratory (for short, the ‘FSL’) for
chemical examination, or if sent, the report thereof was neither called for nor proved before the
Court. In fact, this has been left to the imagination of the Court.
5. The accused persons, at about 5.45 p.m. on the same day, lodged a written report at the same
Police Station, which was received by Head Constable Inder Singh, who prepared the check reportDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

Exhibit C-1 and made appropriate entry. The case was registered under Section 307 of the Indian
Penal Code, 1860 (IPC) against PW2, Gurumukh Singh. Dayal Singh was arrested in furtherance of
the FIR, Exhibit Ka-4A. He was also sent for medical examination and was examined by Dr. K.P.S.
Chauhan, CW2. After examining the said accused at about 7.45 p.m., the doctor found two injuries
on his person and prepared the report (Exhibit C-4). According to Dr. Chauhan, the injuries on the
person of the accused could have been received by a firearm object and injuries were fresh within six
hours.
6. The investigating officer completed the investigation and filed charge sheet (Exhibit Ka-11)
against the accused persons on 15th January, 1986. It may be noticed that in furtherance to Exhibit
C-2, neither any case was registered nor any charge-sheet was presented before the Court of
competent jurisdiction. The accused also took no steps to prove that report in Court. They also did
not file any private complaint.
7. Considering the ocular and other evidence produced by the prosecution, the learned Trial Court
vide its judgment of conviction and order of sentence, both dated 29th June, 1990, found the
accused persons guilty of offences under Section 302 read with Section 34 IPC as well as under
Section 323 read with Section 34 IPC. The Trial Court, while dealing with the arguments of the
accused for application of Section 34, as well as the submission that the witnesses had not attributed
specific role to the respective accused persons, held as under:
“The attack was premeditated and the accused had come fully prepared to do the
overt act. The injury was caused on the head of the deceased which is a vital part of
the body at which it was aimed by employing lathi, it was clear that the accused
persons had intended to cause death by giving blow on vital part of the body of the
deceased. After receiving the injuries, the deceased fell down and even thereafter he
was attacked by the accused persons and he died on the spot immediately. This all
goes to show that the accused persons who all were armed with lathis and had
attacked in furtherance of their common intention by surrounding Sri Pyara Singh.
At that juncture when the occurrence took place suddenly and the witnesses were at
some distance it was quite natural for the witnesses not to have noted as to whose
lathi blow caused the injuries on Sri Pyara Singh and also on the injured persons. It
was thus quite natural in such circumstances for the witnesses not to have noted the
minute details of the incident. The Hon’ble Supreme Court has held in 1971 Cri.L.J.
1135 Har Prasad vs. State of Madhya Pradesh that in view of the large number of
accused involved in the occurrence it is quite natural for the prosecution witnesses to
get a bit confused. In fact, no cross- examination was made on this respect of the case
which has been discussed by me above. The fact that the accused persons had gone to
the place of occurrence fully armed with lathis and immediately on the basis of
‘mend’ started attacking the deceased Sri Pyara Singh indicates that they had gone
there with premeditation and prior concert. All the four accused were physically
present at the time of the commission of offence. The criminal act was done by the
accused persons and they all had shared the common intention by engaging in that
criminal enterprise for which they had come fully prepared. The prosecution hasDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

succeeded in showing the existence of common purpose or design. All the accused
persons were confederates in the commission of the offence and they had
participated in that common intention. Each of the accused person is liable for the
fact done in pursuance of that common purpose of design. The acts done by the
accused persons are similar as they all had come prepared armed with lathis and lathi
blows were struck on the deceased Sri Pyara Singh by the accused persons in
furtherance of their common intention. Each of them is liable for the blows struck
with lathi on the deceased and also on the injured persons. It is proved beyond all
reasonable doubt that lathi blow was struck on the head of Sri Pyara Singh which was
a vital part and he died on the spot due to injuries. Whoever may have struck that
lathi blow, each of the accused person is liable for the lathi blows struck on the vital
part of the deceased. Since the ladhi blow was struck on the head of the deceased
which is a vital part, the offence amounts to murder (See 1972 SCC (Cri) 438 Gudar
Dusadh Vs. State of Bihar). The death of Sri Pyara Singh was caused in the
occurrence and it is proved to the hilt and beyond all reasonable doubt that he died
on the spot on account of lathi blows inflicted on him. It is nobody’s case that he died
natural death. The accused persons have committed offence punishable under
Section 302/34 I.P.C. for committed offence punishable under Section 323/34 I.P.C.
for causing voluntary hurt to Sri Gurumukh Singh and Smt. Balwant Kaur.”
8. The above judgment of the Trial Court was assailed by the accused persons in appeal before the
High Court. The High Court, vide its judgment dated 17th March, 2008, dismissed the appeal and
affirmed the judgment of conviction and order of sentence passed by learned Trial Court giving rise
to the present appeal.
9. From the narration of the above facts, brought on record by the prosecution and proved in
accordance with law, it is clear that there are three eye-witnesses to the occurrence. Out of them,
two are injured witnesses, namely PW2 and PW4. PW2 is the son of the deceased and PW4 is the
wife. Presence of these two witnesses at the place of occurrence is normal and natural. According to
PW4, she had gone to the place of occurrence to give food to her husband and son around 12 noon,
which is the normal hour for lunch in the villages. The son of the deceased had come to the field with
his father to work. They were putting earth on the mend which was objected to by the accused
persons who had come there with lathis and with a premeditated mind of causing harm to the
deceased. Upon enquiry, the deceased informed the accused persons that the mend was a joint
property of the parties. Without provocation, the accused persons thereupon started hurling abuses
upon Pyara Singh and his son, and assaulted the deceased with lathis. PW2 and PW4 intervened to
protect their father and husband respectively, but to no consequence and in the process, they
suffered injuries. In the meanwhile, when the accused persons were challenged by PW5 and Satnam
Singh, who were close to the place of occurrence, they ran away. The presence of PW2, PW4 and
PW5 cannot be doubted. The statement made by them in the Court is natural, reliable and does not
suffer from any serious contradictions. Once the presence of eye-witnesses cannot be doubted and it
has been established that their statement is reliable, there is no reason for the Court to not rely upon
the statement of such eye witnesses in accepting the case of the prosecution. The accused persons
had come with pre-meditated mind, together with common intention, to assault the deceased and allDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

of them kept on assaulting the deceased till the time he fell on the ground and became breathless.
10. This Court has repeatedly held that an eye-witness version cannot be discarded by the Court
merely on the ground that such eye-witness happened to be a relation or friend of the deceased. The
concept of interested witness essentially must carry with it the element of unfairness and undue
intention to falsely implicate the accused. It is only when these elements are present, and statement
of the witness is unworthy of credence that the Court would examine the possibility of discarding
such statements. But where the presence of the eye-witnesses is proved to be natural and their
statements are nothing but truthful disclosure of actual facts leading to the occurrence and the
occurrence itself, it will not be permissible for the Court to discard the statements of such related or
friendly witness. The Court in the case of Dharnidhar v. State of Uttar Pradesh [(2010) 7 SCC 759]
took the following view :
“12. There is no hard-and-fast rule that family members can never be true witnesses
to the occurrence and that they will always depose falsely before the court. It will
always depend upon the facts and circumstances of a given case. In Jayabalan v. UT
of Pondicherry (2010) 1 SCC 199, this Court had occasion to consider whether the
evidence of interested witnesses can be relied upon. The Court took the view that a
pedantic approach cannot be applied while dealing with the evidence of an interested
witness. Such evidence cannot be ignored or thrown out solely because it comes from
a person closely related to the victim. The Court held as under: (SCC p. 213, paras
23-24) “23. We are of the considered view that in cases where the court is called upon
to deal with the evidence of the interested witnesses, the approach of the court, while
appreciating the evidence of such witnesses must not be pedantic. The court must be
cautious in appreciating and accepting the evidence given by the interested witnesses
but the court must not be suspicious of such evidence. The primary endeavour of the
court must be to look for consistency. The evidence of a witness cannot be ignored or
thrown out solely because it comes from the mouth of a person who is closely related
to the victim.
24. From a perusal of the record, we find that the evidence of PWs 1 to 4 is clear and
categorical in reference to the frequent quarrels between the deceased and the
appellant.
They have clearly and consistently supported the prosecution version with regard to the beating and
the ill- treatment meted out to the deceased by the appellant on several occasions which compelled
the deceased to leave the appellant's house and take shelter in her parental house with an intention
to live there permanently. PWs 1 to 4 have unequivocally stated that the deceased feared threat to
her life from the appellant. The aforesaid version narrated by the prosecution witnesses viz. PWs 1 to
4 also finds corroboration from the facts stated in the complaint.”
13. Similar view was taken by this Court in Ram Bharosey v. State of U.P. AIR 1954 SC 704, where
the Court stated the dictum of law that a close relative of the deceased does not, per se, become an
interested witness. An interested witness is one who is interested in securing the conviction of aDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

person out of vengeance or enmity or due to disputes and deposes before the court only with that
intention and not to further the cause of justice. The law relating to appreciation of evidence of an
interested witness is well settled, according to which, the version of an interested witness cannot be
thrown overboard, but has to be examined carefully before accepting the same.”
11. Similar view was taken by this Court in the cases of Mano Dutt & Anr. v. State of UP [(2012 (3)
SCALE 219] and Satbir Singh & Ors. v. State of Uttar Pradesh [(2009) 13 SCC 790].
12. With some vehemence, it has then been contended on behalf of the appellant that the post
mortem report and the statement of PW3, Dr. C.N Tewari, specifically state that no external or
internal injuries were found on the body of the deceased. In other words, no injury was either
inflicted by the accused or suffered by the deceased. In face of this expert medical evidence, the
statement of the eye-witnesses cannot be believed. The expert evidence should be given precedence
and the accused persons are entitled to acquittal. This argument is liable to be rejected at the very
outset despite the fact that it sounds attractive at first blush. No doubt the post mortem report
(Exhibit Ka-4) and the statement of PW3 Dr. C.N. Tewari, does show/reflect that he had not noticed
any injuries upon the person of the deceased externally or even after opening him up internally. But
the fact of the matter is that Pyara Singh died. How he suffered death is explained by three
witnesses, PW2, PW4 and PW5, respectively. Besides this, the statement of the investigating officer,
PW6, also clearly shows that the body of the deceased contained three apparent injuries. He
recorded in his investigative proceedings that the accused had died of these injuries and was found
lying dead at the place of occurrence. It is not only the statement of PW-6, but also the Panchas in
whose presence the body was recovered, who have endorsed this fact. The course of events as
recorded in the investigation points more towards the correctness of the case of the prosecution
than otherwise. Strangely, Dayal Singh and other accused persons not only took the stand of
complete denial in their statement under Section 313 of the Code of Criminal Procedure, 1973
(CrPC) but even went to the extent of stating that they had no knowledge (pata nahin) when they
were asked whether Pyara Singh had died as a result of injuries.
13. We have already discussed above that the presence of PW2, PW4 and PW5 at the place of
occurrence was in the normal course of business and cannot be doubted. Their statements are
reliable, cogent and consistent with the story of the prosecution. Merely because PW3 and PW6 have
failed to perform their duties in accordance with the requirements of law, and there has been some
defect in the investigation, it will not be to the benefit of the accused persons to the extent that they
would be entitled to an order of acquittal on this ground. Reference in this regard can usefully be
made to the case of C. Muniappan v. State of Tamil Nadu {AIR 2010 SC 3718 : (2010) 9 SCC 567}.
14. Now, we will deal with the question of defective or improper investigation resulting from the acts
of omission and/or commission, deliberate or otherwise, of the Investigating Officer or other
material witnesses, who are obliged to perform certain duties in discharge of their functions and
then to examine its effects. In order to examine this aspect in conformity with the rule of law and
keeping in mind the basic principles of criminal jurisprudence, and the questions framed by us at
the very outset of this judgment, the following points need consideration:Dayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

i) Whether there have been acts of omission and commission which have resulted in
improper or defective investigation.
ii) Whether such default and/or acts of omission and commission have adversely
affected the case of the prosecution.
iii) Whether such default and acts were deliberate, unintentional or resulted from
unavoidable circumstances of a given case.
iv) If the dereliction of duty and omission to perform was deliberate, then is it
obligatory upon the court to pass appropriate directions including directions in
regard to taking of penal or other civil action against such officer/witness.
15. In order to answer these determinative parameters, the Courts would have to examine the
prosecution evidence in its entirety, especially when a specific reference to the defective or
irresponsible investigation is noticed in light of the facts and circumstances of a given case.
16. The Investigating Officer, as well as the doctor who are dealing with the investigation of a
criminal case, are obliged to act in accordance with the police manual and the known canons of
medical practice, respectively. They are both obliged to be diligent, truthful and fair in their
approach and investigation. A default or breach of duty, intentionally or otherwise, can sometimes
prove fatal to the case of the prosecution. An Investigating Officer is completely responsible and
answerable for the manner and methodology adopted in completing his investigation. Where the
default and omission is so flagrant that it speaks volumes of a deliberate act or such irresponsible
attitude of investigation, no court can afford to overlook it, whether it did or did not cause prejudice
to the case of the prosecution. It is possible that despite such default/omission, the prosecution may
still prove its case beyond reasonable doubt and the court can so return its finding. But, at the same
time, the default and omission would have a reasonable chance of defeating the case of the
prosecution in some events and the guilty could go scot-free. We may illustrate such kind of
investigation with an example where a huge recovery of opium or poppy husk is made from a vehicle
and the Investigating Officer does not even investigate or make an attempt to find out as to who is
the registered owner of the vehicle and whether such owner was involved in the commission of the
crime or not. Instead, he merely apprehends a cleaner and projects him as the principal offender
without even reference to the registered owner. Apparently, it would prima facie be difficult to
believe that a cleaner of a truck would have the capacity to buy and be the owner, in possession of
such a huge quantity, i.e., hundreds of bags, of poppy husk. The investigation projects the poor
cleaner as the principal offender in the case without even reference to the registered owner.
17. Even the present case is a glaring example of irresponsible investigation. It, in fact, smacks of
intentional mischief to misdirect the investigation as well as to withhold material evidence from the
Court. It cannot be considered a case of bona fide or unintentional omission or commission. It is not
a case of faulty investigation simplicitor but is an investigation coloured with motivation or an
attempt to ensure that the suspect can go scot free. This can safely be gathered from the following:Dayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

a) The entire investigation, including the statement of the investigating officer, does
not show as to what happened to the viscera which was, as per the statement of PW3,
handed over to the Constable, PW7, who, in turn, stated that the viscera had been
deposited in the Police Station Malkhana. In the entire statement of the Investigating
Officer, there is no reference to viscera, its collection from the hospital, its deposit in
the Malkhana and whether it was sent to the FSL at all or not. If sent, what was the
result and, if not, why?
b) Conduct of the Investigating Officer is more than doubtful in the present case. In
his statement, he had stated that he noticed three injuries on the body of the
deceased. He also admitted that in the post mortem report, no internal or external
injuries were shown on the body of the deceased. According to him, he had asked
PW3 in that regard but the reply of the doctor was received late and the explanation
rendered was satisfactory. Firstly, this reply or explanation does not find place on
record. There is no document to that effect and secondly, even in his oral evidence, he
does not say as to what the explanation was.
c) In his statement, PW3, Dr. C.N. Tewari, stated that he did not find any external or
internal injuries even after performing the post mortem on the body of the deceased.
This remark on the post mortem report apparently is falsified both by the
eye-witnesses as well as the Investigating Officer. It will be beyond apprehension as
to how a healthy person could die, if there were no injuries on his body and when,
admittedly, it was not a case of cardiac arrest or death by poison etc., more so, when
he was alleged to have been assaulted with dandas (lathi) by four persons
simultaneously. In any case, the doctor gave no cause for death of the deceased and
prepared a post mortem report which ex facie was incorrect and tantamount to
abrogation of duty. The Trial Court while giving the judgment of conviction, noticed
that medico-legal post mortem examination is a very important part of the
prosecution evidence and, therefore, it is necessary that it be conducted by a doctor
fully competent and experienced. The Court also commented adversely upon the
professional capabilities and/or misconduct of Dr. C.N. Tewari, as follows:
“Whatever may have been the reasons but it is quite evident that Dr. C.N. Tewari
failed in his professional duty and he did not perform post mortem examination
properly after considering the inquest report and the police papers sent to him. If his
finding deferred from the finding of the Panchas he should have informed his
superior officers in that regard so that another opinion could have been obtained
before the disposal of the dead body. The evidence leaves no room for doubt that Sri
Pyara Singh was attacked with lathis as alleged by the prosecution and he received
three injuries already referred to above which were mentioned in the inquest report
(Ex.Ka-6)….
The case of the prosecution cannot be thrown on account of the gross negligence and
apathy of the Medical Officer Dr. C.N. Tewari who had performed autopsy on theDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

dead body of Sri Pyara Singh. Since the Medical Officer Dr. C.N. Tewari had
conducted in a manner not befitting the medical profession and prepared post
mortem report against facts for reasons best known to him and was negligent in his
duty in ascertaining the injuries on the body of the deceased, hence it is just and
proper that the Director General, Medical health U.P. be informed in this regard for
taking necessary action and for eradicating such practices in future.” (Emphasis
supplied)
18. From the record, it is evident that the learned counsel appearing for the State was also not aware
if any action had been taken against Dr. C.N. Tewari. On the contrary, Mr. Ratnakar Dash, learned
senior counsel appearing for Dr. C.N. Tewari, informed us that no action was called for against Dr.
C.N. Tewari as he had authored the post mortem report and given his evidence truthfully and
without any dereliction of duty. He also informed us that since Dr. C.N. Tewari is now retired and is
not well, this Court need not pass any further directions.
19. We are not impressed with this contention at all. We have already noticed that PW3, Dr. C.N.
Tewari, certainly did not act with the requisite professionalism. He even failed to truthfully record
the post mortem report, Exhibit Ka-4. At the cost of repetition, we may notice that his report is
contradictory to the evidence of the three eye-witnesses who stood the test of cross-examination and
gave the eye-version of the occurrence. It is also in conflict with the statement of PW6 as well as the
inquest report (Exhibit Ka-6) prepared by him where he had noticed that there were three injuries
on the body of the deceased. It is clear that the post mortem report is silent and PW3 did not even
notice the cause of death. If he was not able to record a finding with regard to the cause of death, he
was expected to record some reason in support thereof, particularly when it is conceded before us by
the learned counsel for the parties, including the counsel for Dr. C.N. Tewari that it was not a case of
death by administering poison.
20. Similarly, the Investigating Officer has also failed in performing his duty in accordance with law.
Firstly, for not recording the reasons given by Dr. C.N. Tewari for non-mentioning of injuries on the
post mortem report, Exhibit Ka-4, which had appeared satisfactory to him. Secondly, for not
sending to the FSL the viscera and other samples collected from the body of the deceased by Dr.
C.N. Tewari, who allegedly handed over the same to the police, and their disappearance. There is
clear callousness and irresponsibility on their part and deliberate attempt to misdirect the
investigation to favour the accused.
21. This results in shifting of avoidable burden and exercise of higher degree of caution and care on
the courts. Dereliction of duty or carelessness is an abuse of discretion under a definite law and
misconduct is a violation of indefinite law. Misconduct is a forbidden act whereas dereliction of duty
is the forbidden quality of an act and is necessarily indefinite. One is a transgression of some
established and definite rule of action, with least element of discretion, while the other is primarily
an abuse of discretion. This Court in the case of State of Punjab & Ors. v. Ram Singh Ex. Constable
[(1992) 4 SCC 54] stated that the ambit of these expressions had to be construed with reference to
the subject matter and the context where the term occurs, regard being given to the scope of the
statute and the public purpose it seeks to serve. The police service is a disciplined service and itDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

requires maintenance of strict discipline. The consequences of these defaults should normally be
attributable to negligence. Police officers and doctors, by their profession, are required to maintain
duty decorum of high standards. The standards of investigation and the prestige of the profession
are dependent upon the action of such specialized persons. The police manual and even the
provisions of the CrPC require the investigation to be conducted in a particular manner and method
which, in our opinion, stands clearly violated in the present case. Dr. C.N. Tewari, not only breached
the requirement of adherence to professional standards but also became instrumental in preparing a
document which, ex facie, was incorrect and stood falsified by the unimpeachable evidence of eye
witnesses placed by the prosecution on record. Also, in the same case, the Court, while referring to
the decision in Ram Bihari Yadav and Others v. State of Bihar & Ors. [(1995) 6 SCC 31] noticed that
if primacy is given to such designed or negligent investigation, to the omission or lapses by
perfunctory investigation or omissions, the faith and confidence of the people would be shaken not
only in the law enforcement agency but also in the administration of justice.
22. Now, we may advert to the duty of the Court in such cases. In the case of Sathi Prasad v. The
State of U.P. [(1972) 3 SCC 613], this Court stated that it is well settled that if the police records
become suspect and investigation perfunctory, it becomes the duty of the Court to see if the evidence
given in Court should be relied upon and such lapses ignored. Noticing the possibility of
investigation being designedly defective, this Court in the case of Dhanaj Singh @ Shera & Ors. v.
State of Punjab [(2004) 3 SCC 654], held, “in the case of a defective investigation the Court has to be
circumspect in evaluating the evidence. But it would not be right in acquitting an accused person
solely on account of the defect; to do so would tantamount to playing into the hands of the
investigating officer if the investigation is designedly defective.”
23. Dealing with the cases of omission and commission, the Court in the case of Paras Yadav v. State
of Bihar [AIR 1999 SC 644], enunciated the principle, in conformity with the previous judgments,
that if the lapse or omission is committed by the investigating agency, negligently or otherwise, the
prosecution evidence is required to be examined de hors such omissions to find out whether the said
evidence is reliable or not. The contaminated conduct of officials should not stand in the way of
evaluating the evidence by the courts, otherwise the designed mischief would be perpetuated and
justice would be denied to the complainant party. In the case of Zahira Habibullah Sheikh & Anr. Vs.
State of Gujarat & Ors. [(2006) 3 SCC 374], the Court noticed the importance of the role of witnesses
in a criminal trial. The importance and primacy of the quality of trial process can be observed from
the words of Bentham, who states that witnesses are the eyes and ears of justice. The Court issued a
caution that in such situations, there is a greater responsibility of the court on the one hand and on
the other the courts must seriously deal with persons who are involved in creating designed
investigation. The Court held that legislative measures to emphasize prohibition against tampering
with witness, victim or informant have become the imminent and inevitable need of the day.
Conducts which illegitimately affect the presentation of evidence in proceedings before the Courts
have to be seriously and sternly dealt with. There should not be any undue anxiety to only protect
the interest of the accused. That would be unfair, as noted above, to the needs of the society. On the
contrary, efforts should be to ensure fair trial where the accused and the prosecution both get a fair
deal. Public interest in proper administration of justice must be given as much importance if not
more, as the interest of the individual accused. The courts have a vital role to play. (EmphasisDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

supplied)
24. With the passage of time, the law also developed and the dictum of the Court emphasized that in
a criminal case, the fate of proceedings cannot always be left entirely in the hands of the parties.
Crime is a public wrong, in breach and violation of public rights and duties, which affects the
community as a whole and is harmful to the society in general.
25. Reiterating the above principle, this Court in the case of National Human Rights Commission v.
State of Gujarat [(2009) 6 SCC 767], held as under:
“The concept of fair trial entails familiar triangulation of interests of the accused, the
victim and the society and it is the community that acts through the State and
prosecuting agencies. Interest of society is not to be treated completely with disdain
and as persona non grata. The courts have always been considered to have an
overriding duty to maintain public confidence in the administration of justice—often
referred to as the duty to vindicate and uphold the ‘majesty of the law’. Due
administration of justice has always been viewed as a continuous process, not
confined to determination of the particular case, protecting its ability to function as a
court of law in the future as in the case before it. If a criminal court is to be an
effective instrument in dispensing justice, the Presiding Judge must cease to be a
spectator and a mere recording machine by becoming a participant in the trial
evincing intelligence, active interest and elicit all relevant materials necessary for
reaching the correct conclusion, to find out the truth, and administer justice with
fairness and impartiality both to the parties and to the community it serves. The
courts administering criminal justice cannot turn a blind eye to vexatious or
oppressive conduct that has occurred in relation to proceedings, even if a fair trial is
still possible, except at the risk of undermining the fair name and standing of the
judges as impartial and independent adjudicators.”
26. In the case of State of Karnataka v. K. Yarappa Reddy [2000 SCC (Crl.) 61], this Court
occasioned to consider the similar question of defective investigation as to whether any
manipulation in the station house diary by the Investigating Officer could be put against the
prosecution case. This Court, in Paragraph 19, held as follows:
“19. But can the above finding (that the station house diary is not genuine) have any
inevitable bearing on the other evidence in this case? If the other evidence, on
scrutiny, is found credible and acceptable, should the Court be influenced by the
machinations demonstrated by the Investigating Officer in conducting investigation
or in preparing the records so unscrupulously? It can be a guiding principle that as
investigation is not the solitary area for judicial scrutiny in a criminal trial, the
conclusion of the Court in the case cannot be allowed to depend solely on the probity
of investigation. It is well- nigh settled that even if the investigation is illegal or even
suspicious the rest of the evidence must be scrutinised independently of the impact of
it. Otherwise the criminal trial will plummet to the level of the investigating officersDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

ruling the roost. The court must have predominance and pre-eminence in criminal
trials over the action taken by the investigation officers. Criminal Justice should not
be made a casualty for the wrongs committed by the investigating officers in the case.
In other words, if the court is convinced that the testimony of a witness to the
occurrence is true the court is free to act on it albeit the investigating officer's
suspicious role in the case.”
27. In Ram Bali v. State of Uttar Pradesh [(2004) 10 SCC 598], the judgment in Karnel Singh v.
State of M.P. [(1995) 5 SCC 518] was reiterated and this Court had observed that ‘in case of defective
investigation the court has to be circumspect while evaluating the evidence. But it would not be right
in acquitting an accused person solely on account of the defect; to do so would tantamount to
playing into the hands of the investigation officer if the investigation is designedly defective’.
28. Where our criminal justice system provides safeguards of fair trial and innocent till proven
guilty to an accused, there it also contemplates that a criminal trial is meant for doing justice to all,
the accused, the society and a fair chance to prove to the prosecution. Then alone can law and order
be maintained. The Courts do not merely discharge the function to ensure that no innocent man is
punished, but also that a guilty man does not escape. Both are public duties of the judge. During the
course of the trial, the learned Presiding Judge is expected to work objectively and in a correct
perspective. Where the prosecution attempts to misdirect the trial on the basis of a perfunctory or
designedly defective investigation, there the Court is to be deeply cautious and ensure that despite
such an attempt, the determinative process is not sub-served. For truly attaining this object of a ‘fair
trial’, the Court should leave no stone unturned to do justice and protect the interest of the society as
well.
29. This brings us to an ancillary issue as to how the Court would appreciate the evidence in such
cases. The possibility of some variations in the exhibits, medical and ocular evidence cannot be ruled
out. But it is not that every minor variation or inconsistency would tilt the balance of justice in
favour the accused. Of course, where contradictions and variations are of a serious nature, which
apparently or impliedly are destructive of the substantive case sought to be proved by the
prosecution, they may provide an advantage to the accused. The Courts, normally, look at expert
evidence with a greater sense of acceptability, but it is equally true that the courts are not absolutely
guided by the report of the experts, especially if such reports are perfunctory, unsustainable and are
the result of a deliberate attempt to misdirect the prosecution. In Kamaljit Singh v. State of Punjab
[2004 Cri.LJ 28], the Court, while dealing with discrepancies between ocular and medical evidence,
held, “It is trite law that minor variations between medical evidence and ocular evidence do not take
away the primacy of the latter. Unless medical evidence in its term goes so far as to completely rule
out all possibilities whatsoever of injuries taking place in the manner stated by the eyewitnesses, the
testimony of the eyewitnesses cannot be thrown out.”
30. Where the eye witness account is found credible and trustworthy, medical opinion pointing to
alternative possibilities may not be accepted as conclusive. The expert witness is expected to put
before the Court all materials inclusive of the data which induced him to come to the conclusion and
enlighten the court on the technical aspect of the case by examining the terms of science, so that theDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

court, although not an expert, may form its own judgment on those materials after giving due regard
to the expert’s opinion, because once the expert opinion is accepted, it is not the opinion of the
medical officer but that of the Court. {Plz. See Madan Gopal Kakad v. Naval Dubey & Anr. [(1992) 2
SCR 921 : (1992) 3 SCC 204]}.
31. Profitably, reference to the value of an expert in the eye of law can be assimilated as follows:
“The essential principle governing expert evidence is that the expert is not only to
provide reasons to support his opinion but the result should be directly
demonstrable. The court is not to surrender its own judgment to that of the expert or
delegate its authority to a third party, but should assess his evidence like any other
evidence. If the report of an expert is slipshod, inadequate or cryptic and the
information of similarities or dissimilarities is not available in his report and his
evidence in the case, then his opinion is of no use. It is required of an expert whether
a government expert or private, if he expects, his opinion to be accepted to put before
the court the material which induces him to come to his conclusion so that the court
though not an expert, may form its own judgment on that material. If the expert in
his evidence as a witness does not place the whole lot of similarities or dissimilarities,
etc., which influence his mind to lead him to a particular conclusion which he states
in the court then he fails in his duty to take the court into confidence. The court is not
to believe the ipse dixit of an expert. Indeed the value of the expert evidence consists
mainly on the ability of the witness by reason of his special training and experience to
point out the court such important facts as it otherwise might fail to observe and in so
doing the court is enabled to exercise its own view or judgment respecting the
cogency of reasons and the consequent value of the conclusions formed thereon. The
opinion is required to be presented in a convenient manner and the reasons for a
conclusion based on certain visible evidence, properly placed before the Court. In
other words the value of expert evidence depends largely on the cogency of reasons
on which it is based.” [See: Forensic Science in Criminal Investigation & Trial (Fourth
Edition) by B.R. Sharma]
32. The purpose of expert testimony is to provide the trier of fact with useful, relevant information.
The overwhelming majority rule in the United States, is that an expert need not be a member of a
learned profession. Rather, experts in the United States have a wide range of credentials and testify
regarding a tremendous variety of subjects based on their skills, training, education or experience.
The role of the expert is to apply or supply specialized, valuable knowledge that lay jurors would not
be expected to possess. An expert may present the information in a manner that would be
unacceptable with an ordinary witness. The common law tried to strike a balance between the
benefits and dangers of expert testimony by allowing expert testimony to be admitted only if the
testimony were particularly important to aiding the trier of fact. Even in United States, if the
helpfulness of expert testimony is substantially outweighed by the risk of unfair prejudice, confusion
or waste of time, then the testimony should be excluded under the relevant Rules, and State equally
balanced. Expert testimony on any issue of fact and significance of its application has been doubted
by the scholars in the United States. Even under the law prevalent in that country, the opinion of anDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

expert has to be scientific, specific and experience based. Conflict in expert opinions is a well
prevalent practice there. While referring to such incidence David H. Kaye and other authors in ‘The
New Wigmore A Treatise on Evidence – Expert Evidence’ (2004 Edition) opined as under :
“The district court opinion reveals that one pharmacologist asserted “that Danocrine
more probably than not caused plaintiff’s death from pulmonary hypertension,” but it
describes the reasoning behind this opinion in the vaguest of terms, referring only to
“extensive education and training in pharmacology” and an unspecified “scientific
technique” that “relied upon epidemiological, clinical and animal studies, as well as
plaintiff’s medical records and medical history…” The nature of these studies and
their relationship to the patient’s records is left unstated. The district court incanted
the same mantra to justify admitting the remaining testimony. It asserted that the
other experts “similarly base their testimony upon a careful review of medical
literature concerning Danocrine and pulmonary hypertension, and plaintiff’s medical
records and medical history.” The court of appeals elaborated on the testimony of two
of the experts. The physician “was confident to a reasonable medical certainty that
the Danocrine caused Mrs. Zuchowicz’s PPH” because of “the temporal relationship
between the overdose and the start of the disease and the differential etiology method
of excluding other possible causes.” Yet the “differential etiology” here was barely
more than a differential diagnosis of PPH. The causes of PPH are generally unknown
and it appears that the only other putative alternative causes considered were drugs
other than Danocrine. It is not at all clear that such a “differential etiology” is
adequate to support a conclusion of causation to any kind of a “medical certainty.”
The pharmacologist, not being a medical doctor, testified “to a reasonable degree of
scientific certainty . . . [that] the overdose of Danocrine, more likely than not, caused
PPH. . . .” He postulated a mechanism by which this might have occurred: “I) a
decrease in estrogen; 2) hyperinsulinemia, in which abnormally high levels of insulin
circulate in the body; and 3) increase in free testosterone and progesterone . . . that . .
. taken together, likely caused a dysfunction of the endothelium leading to PPH.” In
sum, plaintiff’s experts did not know what else might have caused the hypertension,
and they offered a conjecture as to a causal chain leading from the drug to the
hypertension. This logic would be more than enough to justify certain clinical
recommendations—the advice to Mrs. Zuchowicz to discontinue the medication, for
example. But is it enough to allow an expert not merely to testify to a reasonable
diagnosis of PPH, or “unexplained pulmonary hypertension,” as the condition also is
known, but also be able to propound a novel explanation that has yet to be verified,
even in an animal model?”
33. The Indian law on Expert Evidence does not proceed on any significantly different footing. The
skill and experience of an expert is the ethos of his opinion, which itself should be reasoned and
convincing. Not to say that no other view would be possible, but if the view of the expert has to find
due weightage in the mind of the Court, it has to be well authored and convincing. Dr. C.N. Tewari
was expected to prepare the post mortem report with appropriate reasoning and not leave
everything to the imagination of the Court. He created a serious doubt as to the very cause of deathDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

of the deceased. His report apparently shows an absence of skill and experience and was, in fact, a
deliberate attempt to disguise the investigation.
34. We really need not reiterate various judgments which have taken the view that the purpose of an
expert opinion is primarily to assist the Court in arriving at a final conclusion. Such report is not
binding upon the Court. The Court is expected to analyse the report, read it in conjunction with the
other evidence on record and then form its final opinion as to whether such report is worthy of
reliance or not. Just to illustrate this point of view, in a given case, there may be two diametrically
contradictory opinions of handwriting experts and both the opinions may be well reasoned. In such
case, the Court has to critically examine the basis, reasoning, approach and experience of the expert
to come to a conclusion as to which of the two reports can be safely relied upon by the Court. The
assistance and value of expert opinion is indisputable, but there can be reports which are, ex facie,
incorrect or deliberately so distorted as to render the entire prosecution case unbelievable. But if
such eye-witnesses and other prosecution evidence are trustworthy, have credence and are
consistent with the eye version given by the eye-witnesses, the Court will be well within its
jurisdiction to discard the expert opinion. An expert report, duly proved, has its evidentiary value
but such appreciation has to be within the limitations prescribed and with careful examination by
the Court. A complete contradiction or inconsistency between the medical evidence and the ocular
evidence on the one hand and the statement of the prosecution witnesses between themselves on the
other, may result in seriously denting the case of the prosecution in its entirety but not otherwise.
35. Reverting to the case in hand, the Trial Court has rightly ignored the deliberate lapses of the
investigating officer as well as the post mortem report prepared by Dr. C.N. Tewari. The consistent
statement of the eye-witnesses which were fully supported and corroborated by other witnesses, and
the investigation of the crime, including recovery of lathis, inquest report, recovery of the pagri of
one of the accused from the place of occurrence, immediate lodging of FIR and the deceased
succumbing to his injuries within a very short time, establish the case of the prosecution beyond
reasonable doubt. These lapses on the part of PW3 and PW6 are a deliberate attempt on their part to
prepare reports and documents in a designedly defective manner which would have prejudiced the
case of the prosecution and resulted in the acquittal of the accused, but for the correct approach of
the trial court to do justice and ensure that the guilty did not go scot-free. The evidence of the
eye-witness which was reliable and worthy of credence has justifiably been relied upon by the court.
36. Despite clear observations of the Trial Court, no action has been taken by the Director General,
Medical Health, Uttar Pradesh. We do not see any justification for these lapses on the part of the
higher authority. Thus, it is a fit case where this Court should issue notice to show cause why action
in accordance with the provisions of the Contempt of Courts Act, 1971 be not initiated against him
and he be not directed to conduct an enquiry personally and pass appropriate orders involving Dr.
C.N. Tewari and if found guilty, to impose punishment upon him including deduction of pension.
Admittedly, this direction was passed when Dr. C.N. Tewari was in service. His retirement,
therefore, will be inconsequential to the imposing of punishment and the limitation of period
indicated in the service regulations would not apply in face of the order of this Court.Dayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

37. Similarly, the Director General of Police UP/Uttarakhand also be issued notice to take
appropriate action in accordance with the service rules against PW6, SI Kartar Singh, irrespective of
the fact whether he is in service or has since retired. If retired, then authorities should take action
for withdrawal or partial deduction in the pension, and in accordance with law.
38. Lastly, the learned counsel for the appellant had, of course, with some vehemence, argued that
the offence even if committed by the appellant, would not attract the provisions of Section 302 IPC
and would squarely fall within the ambit of Part II of Section 304 IPC. In other words, he prays for
alteration of the offence to an offence punishable under Part II of Section 304 IPC. We are
concerned with a case where four persons armed with lathis had gone to the fields of the deceased.
They first hurled abuses at him and without any provocation started assaulting him with the dang
(lathi) that they were carrying. Despite efforts to stop them by the the wife and son of the deceased,
PW4 and PW2, they did not stop assaulting him and assaulted both these witnesses also.
Thereupon, they kept on assaulting the deceased until he fell down dead on the ground. Three
injuries were noticed by the Police on the body of the deceased including a protuberant injury on the
head, which the Court is only left to presume has resulted in his death. In the absence of an
authentic and correct post- mortem report (Exhibit Ka-4), the truthfulness of the prosecution eye-
witnesses cannot be doubted. In addition thereto, the stand taken by the accused that they had
suffered injuries was a false defence. Firstly, according to the doctor, CW2, it was injuries of a
firearm, while even according to the defence, the deceased or his son were not carrying any gun at
the time of occurrence. Secondly, they did not choose to pursue their report with the police at the
time of investigation or even when the trial was on before the Trial Court. The accused persons had
gone together armed with lathis with a common intention to kill the deceased and they brought their
intention into effect by simultaneously assaulting the deceased. They had no provocation. Thus, the
intention to kill is apparent. It is not a case which would squarely fall under Part II of Section 304
IPC. Thus, the cumulative effect of appreciation of evidence, as afore- discussed, is that we find no
merit in the present appeal.
39. Having analyzed and discussed in some elaboration various aspects of this case, we pass the
following orders:
A) The appeal is dismissed both on merits and on quantum of sentence.
B) The Director Generals, Health Services of UP/Uttarakhand are hereby issued
notice under the provisions of the Contempt of Courts Act, 1971 as to why appropriate
action be not initiated against them for not complying with the directions contained
in the judgment of the Trial Court dated 29th June, 1990.
C) The above-said officials are hereby directed to take disciplinary action against Dr.
C.N. Tewari, PW3, whether he is in service or has since retired, for deliberate
dereliction of duty, preparing a report which ex facie was incorrect and was in conflict
with the inquest report (Exhibits Ka-6 and Ka-7) and statement of PW6. The bar on
limitation, if any, under the Rules will not come into play because they were directed
by the order dated 29th June, 1990 of the Court to do so. The action even forDayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

stoppage/reduction in pension can appropriately be taken by the said authorities
against Dr. C.N. Tewari.
D) Director Generals of Police UP/Uttarakhand are hereby directed to initiate, and
expeditiously complete, disciplinary proceedings against PW6, SI Kartar Singh,
whether he is in service or has since retired, for the acts of omission and commission,
deliberate dereliction of duty in not mentioning reasons for non-disclosure of cause
of death as explained by the doctor, not sending the viscera to the FSL and for
conducting the investigation of this case in a most callous and irresponsible manner.
The question of limitation, if any, under the Rules, would not apply as it is by
direction of the Court that such enquiry shall be conducted.
E) We hold, declare and direct that it shall be appropriate exercise of jurisdiction as
well as ensuring just and fair investigation and trial that courts return a specific
finding in such cases, upon recording of reasons as to deliberate dereliction of duty,
designedly defective investigation, intentional acts of omission and commission
prejudicial to the case of the prosecution, in breach of professional standards and
investigative requirements of law, during the course of the investigation by the
investigating agency, expert witnesses and even the witnesses cited by the
prosecution. Further, the Courts would be fully justified in directing the disciplinary
authorities to take appropriate disciplinary or other action in accordance with law,
whether such officer, expert or employee witness, is in service or has since retired.
40. The appeal is accordingly dismissed.
………...….…………......................J. (Swatanter Kumar) ………...….…………......................J. (Fakkir
Mohamed Ibrahim Kalifulla) New Delhi, August 3, 2012 REPORTABLE IN THE SUPREME COURT
OF INDIA CRIMINAL APPELLATE JURISDICTION CRIMINAL APPEAL NO.529 OF 2010 Dayal
Singh & Ors. … Appellants Versus State of Uttaranchal … Respondent O R D E R Today, by a
separate judgment, we have directed that action be taken against PW 3 Dr. C.N. Tewari and PW 6 SI
Kartar Singh. The Director General of Police and Director General, Health of State of Uttar Pradesh
and/or Uttarakhand whoever is the appropriate authority, to take action within three months from
today and report the matter to this Court. List for limited purpose on 15th October, 2012.
………...….…………......................J. (Swatanter Kumar) ………...….…………......................J. (Fakkir
Mohamed Ibrahim Kalifulla) New Delhi, August 3, 2012Dayal Singh & Ors vs State Of Uttaranchal on 3 August, 2012

