Andhra Pradesh Brewery Rules, 2006
ANDHRA PRADESH
India
Andhra Pradesh Brewery Rules, 2006
Rule ANDHRA-PRADESH-BREWERY-RULES-2006 of 2006
Published on 27 January 2007• 
Commenced on 27 January 2007• 
[This is the version of this document from 27 January 2007.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Brewery Rules, 2006Published vide Notification No. G.O. Ms. No. 92, Revenue
(Excise-3), dated 27.01.2007Last Updated 25th September, 2019No. G.O. Ms. No. 92. - In exercise
of the powers conferred by Section 72 read with Sections 13, 15, 16, 17, 18, 22, 23, 28 and 29 of the
Andhra Pradesh Excise Act, 1968 (Andhra Pradesh Act 17 of 1968) and in supersession of all rules
on the subject, the Government of Andhra Pradesh hereby make the following rules.Part - I
Preliminary
1.
(1)These rules may be called the Andhra Pradesh Brewery Rules, 2006.(2)They shall extend to all
the areas where the Andhra Pradesh Excise Act, 1968 is in force.(3)They shall come into force at
once.
2. Definitions.
(1)In these rules, unless the context otherwise requires:(a)"Act" means the Andhra Pradesh Excise
Act, 1968;(b)"Assistant Commissioner" in relation to these rules, means an officer appointed under
Section 5 (1) of the Act;(c)"Beer" includes ale, stout, porter and all other fermented liquors usually
made from malt;(d)"Brewery" means a manufactory where beer is manufactured and includes every
place where beer is stored or issued;(e)"Brewery Officer" means an Excise Officer appointed by the
Commissioner to be in-charge of a Brewery and includes Assistant Brewery Officer so
appointed;(f)"Cooler" means any vessel in which worts are passed to be cooled and includes a
refrigerator;(g)"Copper" means any vessel in which either worts or water is boiled or heated in the
course of brewing;(h)"Draught Beer" means Bulk Beer (filtered and carbonized and ready for
bottling) drawn from a vat/ barrel/cask or any other vessel before pasteurization is called Draught
Beer;(i)"Excise Supervision" means supervision over operations including manufacture of Beer in a
manufactory by the members of the staff of Prohibition and Excise Department appointed in that
behalf by the Commissioner or any Excise Officer duly empowered by the State Government or byAndhra Pradesh Brewery Rules, 2006

the Commissioner in that behalf;(j)"Fermenting Vessel" means any vessel in which worts are
fermented by the action of yeast;(k)"Form" means a form appended to these rules:(l)"Gravity"
means the proportion which the weight of a liquid bears to that of an equal bulk of distilled water,
the gravity of distilled water at 60 F. being taken to be 1,000;(m)"Gauge" means to determine the
capacity of any cask or receptacle;(n)"Hop back" means any vessel into which wort is run alter
boiling in order to remove the spent hops; (o) "Licence" means a licence granted for the construction
and working of a brewery under Section 16(1 )(c) of the Act;(p)"Licensee" means a holder of such
licence;(q)"Mashtum" means any vessel in which malt or grain is exhausted in the course of
brewing;(r)"Racking or settling back" means the process by which worts are passed from a
fermenting vessel into any other vessel and racket either at once or after a time;(s)"Maximum Retail
Price" (MRP) means the price to be indicated by the Andhra Pradesh Beverages Corporation
Limited or any other agency authorized by the Government for declaration on in each variety of
Label by the Brewers as required under Section 39 of the Standards of Weights and Measures Act,
1976 and as defined in clause (r) of Rule (2) of the Standards of Weights and Measures (Packaged
Commodities) Rules, 1977;(t)"Sugar" means any saccharine substance, extract or syrup and includes
any material capable of being used in brewing, except malt or corn.(u)"Under back" means any
vessel into which wort runs either from the mashtum or hop back;(v)"Wort" means the liquor
obtained by the exhaustion of malt or grain or by a solution of saccharine matter in the process of
brewing.(2)The words and expressions used but not defined in these rules shall have the meanings
assigned to them in the Andhra Pradesh Excise Act, 1968 and A.P. Distillery (Manufacture of
Spirits) Rules, 2006, and A.P. Distillery (Manufacture of Indian Made Foreign Liquor other than
Beer and wine) Rules, 2006.Part - II Provision Relating to Notification and Grant of License to a
Brewery
3.
(1)No letter of intent for establishment of any new Brewery or expansion of the production capacity
of an existing Brewery shall be issued without previous notification issued by the Government
expressing the intention to grant the same from time to time.(2)A notification shall be issued by the
Government separately from time to time for grant of Letter of Intent for establishment of a new
Brewery or expansion of production capacity of an existing Brewery.(3)Government may, by
notification issued from time to time, withdraw their intention of granting Letter of Intent for
establishment of new Brewery or expansion of the production capacity of the existing Brewery for
any of the purposes separately.
4.
(1)No licence for Brewery shall be granted unless the same is notified and sanctioned under
Sub-rules (1) and (2) of Rule 3 and sanctioned under Rule 4 (2) (c) of these rules.(2)Procedure for
Obtaining Sanction of the Government. - (a) On Notification By The Government Under Rule 3(1)
And (2), Any Person Intending To Construct And Work Such A Brewery Or Expand The Production
Capacity of The Existing Brewery May Apply In Form - B (1) Along With His Scheme To The
Government Through The Commissioner.(b)(i)No application mentioned in Clause (a) above shall
be entertained unless a non-refundable and non-adjustable fee as specified below is paid intoAndhra Pradesh Brewery Rules, 2006

Government treasury and the challan in original in support of payment is produced along with the
application.
Annual Production capacity of the proposedBrewery Non-refundable and non-adjustable Fee
Upto 200 Lakh Bulk Litres. Rupees One Crores.
Above 200 Lakh Bulk Litres. Rupees One Crore Twenty Five Lakhs.
(ii)A special fee as specified below shall also be paid into Government treasury and the challan in
original in support of payment is produced along with the application.
Annual Production capacity of the proposedBrewery Special Fee
Upto 200 Lakh Bulk Litres. Rupees One Crores.
Above 200 Lakh Bulk Litres. Rupees One Crore Twenty Five Lakhs.
(iii)The special fee remitted under clause (ii) above shall be adjusted towards future licence fee or
Excise Duty or both on commencement of production.(c)When the Government are satisfied of the
proposed scheme, they may accord the sanction and communicate it in the form of Letter of Intent
in Form-B(S). This Letter of Intent shall be valid for a period of two and half years from the date of
issue.(d)The Government have right to accept or reject without assigning any reason any application
made for grant of Letter of Intent in pursuance of the notification under Rule 3(1) and (2) of these
rules.(e)The holder of the Letter of Intent shall obtain a licence in Form B-2 within six months from
the date of issue of Letter of Intent.(f)If the holder of the Letter of Intent fails to obtain a licence
within a period of six months from the date of issue of Letter of Intent, he ceases to have any right
on the Letter of Intent.(g)If the holder of the Letter of Intent and licence fails to commence
production within two and half years from the date of issue of Letter of Intent, he forfeits his right
over Letter of Intent and on the licence.(h)The Letter of Intent communicated under Clause (c) shall
not confer any right or privilege for grant of a licence and is liable to be revoked or withdrawn by the
Government at any time without giving any notice to the holder if the Government to desires.(i)No
compensation for damage or loss shall be payable when a Letter of Intent is rejected under clause
(d) or revoked or withdrawn under Clause (h).
5. Grant of Licence.
(1)The holder of letter of intent shall obtain licence from the Commissioner with in six months from
the date of sanction of the Government in the form of Letter of Intent referred to in Rule 4 (2)
(c).(2)The holder of letter of intent shall apply in Form-B (1) (A) and the application shall be
accompanied by: (a) Copy of the sanction (Letter of Intent) accorded by the
Government.(b)Description and plans for the construction of the proposed
manufactory.(c)Statement of plant and machinery proposed to be erected.(d)'No objection
certificate' from the local body competent to issue.(e)No Objection certificate' from the competent
authority under Factories Act, 1948.(f)Clearance certificate from the Andhra Pradesh Pollution
Control Board.(g)An undertaking in the prescribed form on a non-judicial stamp paper of the
requisite value as per the Indian Stamp Act binding himself that he shall erect the plant and
machinery as per the standards, as may be prescribed by the Commissioner from time to time for
maintaining the specifications and quality of products.(h)Counterpart agreement in Form-B (1)
(C).(3)No licence shall be granted unless the applicant deposits Rs. 5,00,000/-(Rupees Five LakhsAndhra Pradesh Brewery Rules, 2006

only) in the shape of a cash deposit or fixed deposit receipt or Bank guarantee from any scheduled
bank situated in Andhra Pradesh as a security for fulfillment of all the conditions of licence and
enter into a counterpart agreement in Form-B (1)(C).(4)(a)Where the Commissioner is satisfied that
the applicant for a new Brewery has fulfilled the conditions specified in subrule (1) to (3) above, he
may grant a licence to the applicant in Form B-2.(b)The license fee for a new Brewery shall be Rs.
1,00,000/- (Rupees One Lakh only) per annum till the commencement of production or expiry of
two and half years period from the issue of letter of intent which ever is earlier.(c)Where the
Commissioner is satisfied that the applicant for expansion of production capacity of an existing
Brewery has fulfilled the conditions specified in subrules (1) to (3) above, he may endorse the
sanction of expansion on the existing licence.(5)The licensee shall before expiry of two and half
years from the date of grant of letter of intent report to the Commissioner, the date on which the
construction or expansion of brewery is completed and the date from which its working is
commenced.(6)In case the licensee fails to construct or expand and work the brewery before expiry
of two and half years from the date of grant of letter of intent, the new licence or the expansion
sanctioned under Sub-rule (4) (a) of (4) (c) as the case may be shall be liable for cancellation without
compensation for any damage or loss.
6. Existing Licenses Under A.P. Brewery Rules 1970.
- Andhra Pradesh Brewery Rules 1970 shall cease to operate on the commencement of these rules
and all relevant licences granted under Andhra Pradesh Brewery Rules 1970 shall be deemed to have
been granted under these rules.Provided that the licence fee in respect of the existing Breweries
shall be paid by the licensees proportionately from the date of commencement of these rules.
7. Licence Fee Structure.
(1)The Government shall fix the Production capacity of the Brewery.(2)The capacity of the
equipment and devices for bottling of Beer shall be according to the production capacity as fixed for
the Brewery and shall be as per the specifications and norms as may be prescribed by the
Commissioner from time to time.(3)The annual licence fee shall be fixed by the Commissioner
basing on the prod action capacity in accordance with the licence fee structure prescribed here
under.
Annual Production Capacity Annual Licence Fee
1. Upto 200 lakh Bls:- Rs. 5,00,000/-
2. For every additional 100 lakh Bis or part there of:- Rs. 25,00,000/-
Provided that the production capacity once fixed shall not be reduced under any
circumstances.Provided further that in case of new licence as granted under Rule 5(4) (a) the
licensee commences manufacture from such date specified therein and the licence fee shall be paid
as prescribed under sub rule (3) proportionately on the production capacity for the remaining
period of licence.Provided also that in case of expansion granted under Rule 5(4) (c) the licensee
shall pay the licence fee as prescribed under sub rule (3) proportionately from the date of erection of
expanded capacity for the remaining period of licence.(4)Whenever the licensed production capacityAndhra Pradesh Brewery Rules, 2006

is fully utilised by the licensee before the completion of licensed year and if the licensee desires to
have additional production during the remaining part of the licence year, the licensee shall take
special permission from the Government for causing additional production over and above the fixed
production capacity by submitting the requirement through Commissioner. On grant of such
permission, the licensee shall pay the additional licence fee on such additional production at the rate
of 0.50 paise (fifty paise only) per bulk liter of additional production.Part - III Common Provisions
Relating to Renewal, Sub Leasing, Shifting, Transfer and Merger of Licences
8. Renewal of Licence.
(1)Licence granted under these rules shall come into effect from such date as specified
therein.(2)Licence shall ordinarily be for a period of one year.(3)The licensee shall get his licence
renewed before the commencement of the Licence year, by paying the licence fee as prescribed in
Rule 7, other wise he is either eligible to go into production nor permitted to transact any
business.(4)If the licensee fails to apply for renewal by paying the specified fee before the
commencement of the licence year, he shall pay the licence fee along with late fee specified below for
renewal of his licence.
Period Late fee
(1) Within six months from the date of commencement of
licenceyear5% of the Annual Licence Fee
(2) After six months from the date of commencement of
Licenceyear.10% of the Annual Licence
Fee.
Provided, if the licensee does not apply for renewal of licence within the licence year, he shall pay
the annual licence fee for the entire period for which he does not have his licence renewed along
with the late fee as specified above, subject to the condition laid down in sub-rule (7) of this
Rule.(5)Every application for renewal of licence under these rules shall bear a court fee stamp of
requisite value as specified in the Indian Stamp Act and shall be addressed to the
Commissioner.(6)Where the Commissioner is satisfied that the licensee has fulfilled the conditions
specified for renewal and that the manufacturing facilities on ground are not modified in any
manner in deviation of the provisions of previous licence, he may renew the licence.(7)The right of
the licensee to get his licence renewed stands forfeited if the licence is not renewed continuously for
a period of 3 years.
9. Excise Duty.
(1)The Excise duty shall be paid at such rates as may be specified by the Government.(2)The licensee
shall execute an agreement binding himself, his heirs, legal representatives and assignees to observe
the conditions of licence, hypothecating the buildings, machinery, apparatus together with the stock
as security for the payment of money, which may be due to the Government.Andhra Pradesh Brewery Rules, 2006

10. Sub-Leasing of Brewery.
(1)The Commissioner may, on application made by the holder of a licence issued under these rules,
permit sub-leasing the whole of the licensed capacity of such brewery to the proposed
sub-lessee.(i)No sub-lease shall be permitted unless:(a)A sub-lease fee of sum equal to 10% (Ten
percent) of the annual licence fee is remitted in Government treasury.(b)The licensee keeps a
security deposit of an amount equal to 15% (Fifteen percent) of the annual licence fee of the brewery
in the shape of Fixed Deposit Receipt or Bank Guarantee issued by any scheduled Bank situated in
Andhra Pradesh in the name of the Commissioner.(ii)The proposed sub-lessee referred to in
sub-rule (1) shall not be a person disqualified to hold a licence under the A.P. Excise Act, 1968 and
the rules made there under.(iii)The sub-lease permitted under sub-rule (i) shall be for a period of
one year or part thereof and such sub-lease holder shall not have any claim for renewal of such
sublease.(iv)The Commissioner may, for reasons to be recorded in writing, refuse to grant
permission for sublease or withdraw the permission granted for sub-lease.(v)The licensee and the
sub-lessee shall not have any claim for compensation towards any damage or loss sustained on
account of non-sanction or withdrawal of permission for sub-lease.(vi)If the original licence is
suspended or cancelled for any reasons, the sub-lease shall also stand automatically suspended or
cancelled as the case may be.(vii)An application for grant of permission for sub-lease shall be made
in Form-B (SL) and shall be accompanied by:(a)Sub-lease deed between the licensee and the
proposed sublessee on a non-judicial stamp paper of the requisite value as per the provisions of the
Indian Stamp Act, 1899, which shall be registered within 15 days from the date of grant of
permission for sub-lease.(b)Memorandum of Articles of Association/partnership deed, declaration
of sole proprietorship, as the case may be, of the licensee and the sub-lessee.(c)Lists of
Directors/Partners, as the case may be, of both licensee and sub-lessee.(d)Undertaking in Form-B 1
(SLU) on non-judicial stamp paper worth Rs. 100/- duly signed by the licensee and
sub-lessee:(e)Original Challan as proof of having paid ten percent of annual Licence fee of the
distillery towards sub-lease fee and fifteen percent of the annual licence fee as security deposit in the
shape of Fixed Deposit Receipt or Bank Guarantee issued by a Scheduled Bank situated in Andhra
Pradesh in the name of the Commissioner.(viii)The sub-lease granted under subrule (1) is not
transferable.(ix)The licensee and sub-lessee shall be jointly and severally responsible for all the acts
of omissions and commissions of the sub-lessee.(x)The Sub-lessee shall be responsible for payment
of all duties, taxes and fees etc., payable to the Government pertaining to the period of sublease. In
case the sub-lessee fails the same shall be recovered from the licensee.(2)The security deposit as
contemplated under sub-rule (1) (i) (b) shall be valid for the lease period or till the dues are paid to
the Government whichever is later.(3)All the coutstanding duties, taxes, fees or any other dues
payable to the Government shall be recovered from the security deposit and the balances if any shall
be recovered from the sub-lessee and licensee as if they were arrears of land revenue.(4)The fixed
deposit Receipt or the Bank Guarantee produced as security deposit shall be returned to the licensee
after the clearance of all the dues to the Government by the sub lessee and licensee.
11. Shifting of Existing Brewery.
(1)Where the management of a Brewery intends to shift the Brewery from the place to another place,
it shall notify the same to the Commissioner by an application in Form-B3 after remitting anAndhra Pradesh Brewery Rules, 2006

amount of Rs.2.00 Lakhs (Rupees two lakhs only) in the Government treasury and enclose the
challan in original in support of payment along with the application.(2)On receipt of such an
application the Commissioner if satisfied, may obtain such undertaking or Bond and such other
material or documents to protect the interest of the Government as he may deem fit, may grant such
permission after obtaining the orders from Government for the shifting of the Brewery.
12. Change or Alteration of Licence.
- (1) Transfer of Licence:(i)No licensee shall except with the sanction of the Commissioner transfer
his license to any other person. The Commissioner may allow such transfer of license on payment of
prescribed fee and on production of certificate to the effect that no cases involving contravention of
Excise Act and Rules framed there under are pending against him and also on production of Sales
Tax and Income Tax clearance certificates.(ii)When there are only two partners in the firm holding
the licence and one of them withdraws or expire the entity of firm changes from partnership to
proprietary and it amounts to transfer of licence.(iii)Conversion of a proprietary concern into a firm
or a company or a firm into a company and vice versa shall amount to transfer of licence.(iv)The
Commissioner on payment of a fee of Rupees Two lakhs and on obtaining such undertaking or Bond
and such other material or documents to protect the interest of the Government as he may deem fit,
may grant such permission for the transfer of the licence in the cases referred in clause (ii) and (iii)
above.(v)Where there is a change of 50% or more partners, it shall be construed as complete change
in the ownership, a fee amounting to 10% of the licence fee shall be paid.(2)Inclusion or exclusion of
partners. - No licensee shall except prior permission of the licensing authority get any person
included as a partner to his business or get an existing partner excluded.(3)Death of licensee or
incapability of the licensee. - A licence issued under these rules shall be only to the person named
there in and on his death the legal heirs may apply for continuance of the licence in their name to
the Commissioner within thirty days of death of the licensee. If the Commissioner is satisfied he
may permit the legal heir to continue the licence in his name.(4)Merger of licence. - (i) When
licensees of two or more existing Breweries subject to provisions of sub-rule (1) desire to merge into
one Brewery may apply to the Commissioner in Form-B3 (M) along with a challan for Rupees Two
lakhs.(ii)On receipt of such an application the Commissioner if satisfied, may obtain such
undertaking or Bond and such other material or documents to protect the interest of the
Government as he may deem fit, may grant such permission after obtaining the orders from the
Government for the merger of the Breweries.Part - IV Provision Relating to Bottling of Beer and
Labelling
13. Bottling of Beer.
(1)Operations connected with the filling of bottles with beer for issue, shall be conducted in bond
under the supervision of the Brewery Officer in a separate room called the bottling room for beer set
apart for the purpose, within the Brewery' premises near the finished stores. Bottled beer shall be
stored in a separate room called the 'Bottle beer store' set apart for the purpose, within the Brewery'
premises near the bottling rooms.(2)The bottling rooms and the bottled Beer store-rooms shall be
secured in such manner as the Commissioner may approve.(3)Beer shall be bottled at the strength
specified by the Commissioner from time to time.(4)Sample from each batch shall be sent to theAndhra Pradesh Brewery Rules, 2006

Chemical Examiner and it shall be passed by the Chemical Examiner.(5)Bottling shall be done
during the ordinary working hours of the Brewery.(6)No bottling shall be allowed except in the joint
presence of the Excise Officer and a representative of the licensee.(7)Beer required for bottling shall
be measured out and brought into the bottling room by a permanently fixed pipe or such other
means as may be approved by the Commissioner(8)Bottling shall be done in bottles of the capacity'
as may be prescribed by the Commissioner from time to time.(9)The bottles mentioned in sub-rule
(8) shall be standard pattern and shall bear the following specifications molded on the glass:'(a)The
figures and words of the capacity.(b)A line across the neck up to which the bottle shall be Filled in
order to contain the proper quantity.(10)The licensee shall not use bottles bearing the name or trade
mark of any other bottle or any other Brewery.(11)The Bottles shall be properly sealed with gas-tight
crown caps.(12)The licensee shall not keep the beer in tanks for more than three months without
bottling.
14. Labelling of Beer Bottles.
(1)The licensee shall label each bottle after bottling with a label printed in English or Telugu
language showing the name of the licensed Brewery and the place where the bottling is done.(2)The
labels shall be affixed to the liquor bottles only after such labels are approved by the Commissioner.
15. Approval of Labels.
(1)The licensee shall submit an application in Form-B4 to the Commissioner through the Assistant
Commissioner (Distilleries) duly affixed with Court fee stamp of requisite value as per the provisions
of Indian Stamp Act, 1899 and shall enclose with ten copies of each variety of label sought to be
approved.(2)No application referred in subrule (1) shall be entertained unless the licensee remits
the label approval fee of Rs. 2,00,000/- (Rupees two lakhs only) and the challan in support of the
payment is produced with the application.(3)The licensee shall also get the label re-approved for
each licensed year by paying the label fee specified in subrule (2).Provided that if a particular label
was approved in a year, the stocks bearing such label are laying unsold in the warehouse, the
licensee need not get such label re-approved for the purpose of their release of such stock in the
subsequent year.(4)The format of the label shall contain the following:-(i)Name and address of the
manufacturer.(ii)Batch Number, Month and Year of Manufacture(iii)Net
contents(iv)Strength(v)Kind of Beer(vi)Maximum Retail Price. (M.R.P.) shall be incorporated in the
label after the same is indicated by the Andhra Pradesh Beverages Corporation Limited.)(vii)Details
of manufacturing under Sub-lease arrangements.(viii)Maximum Retail Price (MRP) shall be
prominently depicted on a separate band on the top of the label.(ix)Inscription "Consumption of
liquor is injurious to health".(5)In case of supply of Beer to Canteen Stores Department, each variety
of labels shall be approved separately after collecting a non-refundable fee of Rs. 2,00,000/-. The
Label shall be re-approved for each Excise year after collecting the same fee applicable for
approval.(6)The label fee once remitted and the label was duly approved it shall not be refunded or
adjusted for any reason including withdrawal or cancellation of rate contract by the Andhra Pradesh
Beverages Corporation Limited or non-issue of purchase orders.(7)The manner and the contents of
the label shall be in the form as may be specified by the Commissioner from time to time.Part - V
Provision Relating to Regulation and SupervisionAndhra Pradesh Brewery Rules, 2006

16.
On granting a licence under these rules, the licensee shall furnish a duplicate copy to the Asst.
Commissioner concerned of the descriptions, plans and statements as approved by the
Commissioner.
17.
Every licensee shall exhibit his licence or a copy of the Licence and an approved copy of the plant in
a conspicuous part of the licensed premises.
18.
The licensee shall not hypothecate the whole or any part of the licensed premises without the prior
written sanction of the Commissioner.
19.
The licensee shall extend full assistance to any Excise Officer authorized by the Commissioner to
inspect the distillery at any time.
20.
The licensee shall provide accommodation for the office of the Brewery officer and his staff within
the licensed premises and extend required assistance to the Excise Officer in carrying out his duties.
21.
The licensee shall conduct his business either personally or by an agent authorized by him in this
behalf and the information of such authorization shall be intimated to the Brewery Officer, Assistant
Commissioner and the Commissioner.
22.
The licensee shall maintain the registers which are required under these rules and shall submit them
for inspection by Excise Officers concerned as and when required.
23.
The licensee shall provide with sacchrometer and thermometer, other appliances and measures as
are necessary and as specified by the Commissioner.Andhra Pradesh Brewery Rules, 2006

24.
The buildings, plant and machinery specified in the licence, shall be maintained properly and
cleanly to the satisfaction of the Commissioner. No alterations or additions shall be made without
prior sanction of the Commissioner.
25.
Every process connected with the manufacture, issue of Beer shall be conducted within the
licensed premises.
26.
Every person leaving the Brewery shall be liable to be searched under the orders of Excise Officer
in-charge of the unit. The Excise officer shall use these powers with discretion. No respectable
person shall be subjected to search except on valid grounds. All cases of search of persons other than
the workers shall be recorded by the Excise officer in his dairy and shall report the matter to the
Assistant Commissioner immediately.
27.
Where the Commissioner is not satisfied as to the maintenance of the building plant and machinery
including the measures and other appliances he may require the licensee to stop working of the
Brewery and direct to rectify the defects within one week.
28. Requirements within the Brewery.
(1)The licensee shall erect as number of tanks and vessels as required as per the licensed production
capacity of the Brewery.(2)The Brewery premises shall be closed by a compound wall with sufficient
protection to prevent undue access into the licensed premises from outside.(3)Naked lights of any
description shall not be used within the Brewery. All electrical fittings shall be maintained and fitted
with flame proof equipment.(4)Fire extinguishers shall be installed at suitable places as to enable
easy handling in case of an emergency.(5)All pipes from sinks and wash basins inside the Brewery
shall discharge into closed drains forming part of the general drainage system of the
premises.(6)The licensee shall maintain a laboratory with required infrastructure to formalize the
working of the Brewery with regard to quality of Beers manufactured.(7)The licensee shall provide
and maintain sufficient and accurate measures, scales and weights and other necessary and
reasonable appliances to enable the Brewery Officer and other officers to take account of or check by
weight, gauge or measure all materials and liquids used or produced in brewing and provide
sufficient lights, ladders and other convenience to enable the Excise staff to perform their
duties(8)The licensee shall cause to be legibly painted with oil colour and keep so painted, on some
conspicuous part of every mashtum, under back, copper, heating tank, cooler, fermenting vessel and
settling back intended to be used by him in his business and on the outside of the door of every roomAndhra Pradesh Brewery Rules, 2006

and place wherein any part of his business is to be carried on, the name of vessel, room or place
according to the purpose for which it is intended.(9)Where more than one vessel, room or place is
used for the same purpose, all such vessels, rooms or places shall be marked by progressive
numbers.(10)All mushtums, under backs, coolers, fermenting vessels and settling backs shall be so
placed and fixed as to admit of the contents being accurately ascertained by gauge or measure and
shall not be altered in shape, position or capacity without two days notice in writing to the Brewery
Officer.(11)All mushtums and fermenting vessels shall be gauged jointly by the Brewery Officer and
the licensee, and the Brewery Officer shall prepare tables showing the total capacity of each vessel in
litres and capacity of the contents in each to the tenth of centimeter in depth.(12)No vessel which
has been altered in shape, position or capacity shall again be taken into use unless it has been
re-gauged by the Brewery Officer and new tables prepared by him if necessary.(13)The tables
prepared under Rule 12 and 13 shall before being taken into use be certified by the licensee or his
accredited agent as correct.(14)The Brewery officer shall also certify as to the correctness of the
tables and check from time to time the data, based on which they are prepared.(15)The licensee
shall:(i)Keep a book in Form B-5 in the licensed premises and make it available at all times, for the
inspection by the other Excise Officers who is authorized to inspect the brewery and for making
extracts there from:(ii)make entry in the book in accordance with such instructions as may be given
by the Commissioner or Brewery Officer from time to time; and(iii)send notice in writing to the I
Brewery Officer of his intention to brew forty eight hours, before such brewing takes place if so
required * by the Commissioner.(16)The licensee shall allow the Brewery Officer to take account of
the worts or grains or cereals mixed during the, process of brewing whenever such | accounting
becomes necessary.
29. Brewing Process.
(1)Beer shall be brewed from good j materials and its quality shall be such as to satisfy the
Commissioner. Wort shall not be brewed of a higher gravity than 1073°. Nothing shall be added to
beer after it has been rocked and removed to a beer store, except findings or other material
approved by the Commissioner in such proportions as fixed by him. Beer in the store must not be
diluted and any beer found in store which has been either diluted or in any way adulterated will be
liable to confiscation. The confiscation of the beer will not exonerate the licensee from any penal
action under the Act.(2)No material other than malt, grain, cereals, sugar, glucose or hops shall be
used in brewing and nothing other than fining may be added to beer in store, without previous
sanction of the Commissioner. The use of the following materials is permitted.(A)In
Brewing:(1)Burtan Crystals(2)Caramel(3)Corpulos(4)Maltose(5)porterine(6)Ibrite(7)Hop
substitute(8)Optanis(9)Zumsite(10)Gypsum(11)American flour(12)Septose(13)Klearwort(14)Pure
cell acid(15)Cheratta(16)Malt flour(17)Standard salt(18 ) Un-fermentable syrup(19)Diastagic mart
syrup(20)Sulphosite(B)In Beer store(1)Bisulphite of Lime(2)Calcium Meta
Sulphite(3)Phylax(4)Beer Neutralizer(5)Hop Oil(6)Un-fermentable Syrup.(3)No ingredients,
noxious to health shall be used. Should the licensee intend to use any material not previously
approved for use, he shall apply to the Commissioner for necessary sanction through the Brewery
Officer, with a sample of material detailing the purpose for which it is to be used. The Brewery
Officer shall submit such application through the Assistant Commissioner of Distilleries to the
Commissioner.(4)The storage of either malt or unmalted corn is not controlled. The room, in whichAndhra Pradesh Brewery Rules, 2006

malt is ground in having internal communication with any room or place of the bonded premises of
the brewery, shall be included into the bonded premises of the brewery as shown in the approved
plant.(5)All sugar shall be stored in a room specially set apart for that purpose to be shown as a
Sugar-store. Sugar shall not be removed from the store into any other part of the brewery except in
pursuance of an entry in the book for use in brewing.(6)(a)Hops or Hop substitutes shall be stored
in a room specially indicated in the bonded premises of the brewery for such purpose.(b)Other
approved brewing materials shall be stored either in the hop store or in a room specially set apart
and called "Brewing Specialty Room"(7)Potassium Meta-sulphate and Burtom crystals may be
stored at the discretion of the licensee.(8)When the licensee intends to use a sugar solution for
priming beer prior to issue, he shall obtain prior permission from the Commissioner to do so. He
shall provide a separate cask or vat, which shall be used for the purpose of dissolving sugar only and
shall be distinctly marked 'Priming Vessel'.When a sugar solution is to be used for priming beer
prior to issue the licensee shall intimate to the Brewery Officer, the above fact in writing at least 6
hours before making the solution, declaring the quantity of sugar to be used in making the solution
and the hour at which he proposes to make the solution.The quantity of sugar to be used in making
the solution and the hour of dissolving the sugar shall be entered in the proper columns in Brewing
Book at least six hours before making the solution. The gravity of the solution shall not exceed
1073°. When the solution is complete the licensee shall enter its dip and gravity in the Brewing Book
and shall not remove any portion of it unless the Brewery Officer or some superior officer bad
checked the entry. The quantity declared by the licensee or found by the officer whichever is greater
shall be taken into account for charging duty.Priming solution may be concentrated by boiling to
density not more than 1050° after the charge has been taken by the Brewery Officer provided the
licensee gives notice to concentrate the solution in the Brewing Book. Such an entry shall be made in
red ink. The Brewery Officer shall immediately make a survey record it red ink and note in the
remarks column of the surveying book, the survey in which the charge for duty has been
taken.Before removal of solution the licensee shall note in the remarks column of the Brewing Book
the quantity to be removed, the hour of removal and the number of casks to which the solution is to
be added. No greater quantity than 4'/ Litres shall be added to each hogs head of beer and
proportionately for small casks. The Brewery Officer shall check the addition as often as
possible.(9)The licensee shall obtain prior permission from the Commissioner, for the use of hops
and hop substitutes and the proportion in which they are to be used.(10)The licensee shall not use
palmyrah Sugar in the manufacture of beer or as an addition to finished beer.(11)Casks may be used
for making and storing solutions of . Caramel, Corpulose. Maltose or Porterine. Every such cask
shall be given a number and entered in the survey book as a collecting vessel with a note of the
material for which it is intended to be used.(12)The licensee shall enter in the Brewing Book the date
and hour of making the Caramel solution and the material to be used and on conclusion of the
operation shall enter at once the quantity and gravity of the solution. The gravity shall not exceed
1073°. The licensee shall note in the remarks column of the Brewery Book each removal from the
cask, specifying the quantity removed and the vessel to which it has been added. The Brewery
Officer shall show the condition of the cask upon each complete survey.(13)Yeast may be added at
any stage of collection of wort in the fermenting vessel, but if it is added so early before the complete
collection of wort that fermentation has commenced the licensee must declare the original gravity of
the wort before fermentation commenced.(14)The licensee shall enter in the brewing book the
quantity and gravity of the expressed wort and the name and the number of the vessel to which it isAndhra Pradesh Brewery Rules, 2006

to be added. When expressed wort is added to beer in store, it shall be added to beer irrespective of
the nature of the brewing from which expressed but wort filtered without pressure may be added to
beer of the same denomination as itself.(15)Vessels used for yeast culture shall be duly entered and
brought under survey. They may be placed in any suitable room in the brewery. They shall be
gauged to the nearest litre per centimeter of depth so that the quantity may be verified or cross
checked if necessary by Excise Officers. Vessels said to contain yeast shall be examined so as to
satisfy that uncharged wort is not being fermented. After the first change is taken in a yeast culture
vessel the surface shall not be broken unless fraud is suspected. The entry in the survey book in such
surveys shall be the word 'growing'(16)Small unfixed casks may be used as fermenting vessels to
take any unexpected excess of wort produced in brewing, the quantity of which is too small to permit
efficient fermentation in a fixed fermenting vessel. The licensee shall inform the officer in writing
the said fact and shall declare the quantity of the wort contained in the cask originally. Permission
for the use of such casks may be withdrawn whenever it is found that they are employed as a matter
of course and continuously.(17)(a)The duty on Beer, at specified rates shall be charged on the total
quantity of beer pumped to the Bright Beer Tanks less an allowance of 3% for wastage towards
bottling. For this purpose the licensee shall maintain an account of beer pumped to the Bright Beer
Tanks (Tank-wise account) after due maturation and carbonated. This account shall show the daily
final production of Beer which shall be issued as draught beer or for bottling.(b)The duty on beer
shall become due immediately after the account of beer as specified under Clause (a) above has been
taken by the Brewery officer or at the end of each month which ever is later and the time for its
payment shall not be later than fifteenth day of the succeeding month in which the duty was charged
provided that no stock of beer shall be removed from the Brewery except on payment of duty
specified in Rule 9.(c)If the duty payable by the licensee remains unpaid beyond the period specified
in this regard, the Commissioner may forfeit to Government, the sum guaranteed by the Bank and
either the whole or part of the security deposit furnished by the licensee under these rules.(d)The
Brewery Officer shall maintain an account of Beer pumped in Bright Beer Tanks (Tank-wise) and
issues made from the Bright Beer Tanks in Form B-6.
30. Draught Beer.
(1)The licensee shall be allowed to issue Beer straight from Bright Beer Tank without subjecting the
Beer to pasteurization as 'Draught Beer'.(2)The following precautionary measures shall be taken
while issuing Draught Beer as the shelf life of the Beer is only 36 hours.(a)Draught Beer shall be
issued from the brewery in Aluminium Alloy Kegs having a capacity of 30 litres or 50 litres specially
designed for the purpose.(b)On receiving the Keg, the brewery shall thoroughly sterilize the keg
using either hot water or steam.(c)After sterilization the keg shall be allowed to cool for a few
minutes in B.B.T.Room.(d)The filling valve and filling tank shall also be sterilized.(e)Before filling
the keg, the beer drawn from Bright Beer Tank shall be filtered by means of Sterile
Filtration.(f)During filling the keg with beer a counter pressure of 1.5 to 2 kg/ cms shall be
maintained.(g)After the keg is filled with beer, it shall be weighed to ensure that the required
quantity is filled up in the keg.(h)The temperature of the keg shall be maintained below
5°C.(i)Transportation of Draught beer in kegs from the brewery to the destination shall be made in
specially designed vehicle having ice and thermostat arrangements.Andhra Pradesh Brewery Rules, 2006

31. Working Conditions of the Brewery.
(1)Except as provided herein the Brewery shall be kept open during the ordinary working
hours.(2)No Brewery shall be open for work on a Sunday or other public holiday except with the
sanction of the Commissioner which may be given at least one day in advance.(3)If the manufactory
works on Sunday or other public holiday, Excise Officer shall be preset and shall make adequate
arrangements for regulating the entry or exit of persons at fixed hours in connection with the
working of the manufactory.(4)Where the Brewery is to worked at hours other than the ordinary
working hours, the licensee may do so only on obtaining permission from the
Commissioner.Provided that if the total extra hours to be sanctioned on any day is more than the
normal working hours i.e., eight hours, it shall be sanctioned with the prior approval of the
Government.
32. Drawl of Samples.
- The licensee shall, when required permit samples of the material used or Beer manufactured to be
taken for analysis under the orders of the Commissioner or by any officer authorized by him to take
samples. Each sample shall be taken in three 750 ml. bottles or when the material cannot be placed
in bottles, in three parcels, in the presence of a representative of the licensee; each bottle or parcel
shall be immediately and securely sealed in the presence of the Excise Officer and the licensee's
representative. One bottle or parcel shall then be made over to the licensee's representative, the
second shall be sent for analysis and the third be kept by the Excise Officer, pending disposal of the
case.
33. Removal of Beer.
(1)No Beer manufactured or stored otherwise than that under bond shall be removed unless the
Excise duty as specified in Rule 9 (a) (if not reduced or exempted by an order of competent
authority) as specified by Commissioner from time to time has been paid by the Licensee before
such removal.(2)No Beer shall be issued in quantities of less than 30 litres.(3)No bottled Beer hall
be removed unless it is properly packed to withstand a road journey.(4)On payment of Excise Duty,
a transport permit for removal of Beer shall be issued by the Excise Officer In-charge of the unit in
favour of the following persons only:(i)The Andhra Pradesh Beverages Corporation depots located
in the State as per the purchase orders given by the corporation.(ii)Persons holding a licence in any
other State for sale of Beer by whole sale or retail on production of valid permit issued by the
Commissioner.(iii)Persons holding a licence in Form - CS.3 under Andhra Pradesh Excise (Grant of
licence of selling by In-house and conditions of Licence) Rules, 2005.(5)Every application for a
Transport permit for the removal of Beer, shall be made in writing in Form - B7 to the Excise Officer
and shall be accompanied by a challan in original in support of payment of Excise duty therefor and
the certificate or permit required under the foregoing rules, such certificate or permit being either a
general or a special one for the purpose of a single removal.(6)The licensee shall present the
treasury receipt in token of his having paid the Excise duty to the Excise Officer.(7)The licensee shall
be responsible for the correct and full payment of the Excise duty due on the Beer to be removed.
But if he is in doubt as to the amount of such Excise duty, he may, prior to its payment in theAndhra Pradesh Brewery Rules, 2006

treasury, apply to the excise officer for a revision of calculation.(8)If the Brewery Officer is satisfied
that the applicant is entitled under these rules to remove Beer and that the Excise duty has been
paid, he shall issue Beer under a permit in Form-B-8 sending a copy to the concerned Prohibition
and Excise Superintendent of destination.
34. Issue of Beer for Laboratory Purpose.
(1)If the licensee requires Beer for the use in the laboratory attached to the brewery, he shall be
entitled to remove it to the laboratory without payment of any excise duty, to the extent of 5 Liters
(five liters only) per month.(2)The spirit so removed under subrule (1) shall not be used in the
laboratory otherwise than for experimental work connected with the manufactory operations.(3)An
application for every quantity of Beer required under this rule shall be made in writing to the Excise
officer, who shall record thereon, the quantity of the Beer taken and record the same in the relevant
registers of the distillery.(4)The licensee shall keep a regular account of Beer taken under this rule
which shall be subject to the examination of the Excise officer.
35. Registers to be Maintained.
- The following registers shall be maintained in a Brewery
1. Raw material Stock registers.
2. Brew Account Register.
3. Bright Beer Stock Account (Tank-wise)
4. Bottling operations Register.
5. Brand wise stock Register.
6. Consolidated stock Register of finished stock.
7. Issues Register.
8. Draught Beer issue Register.
9. Sample Register.
10. Purchase order Register.Andhra Pradesh Brewery Rules, 2006

11. Brewery Gate pass Register.
12. Excise duty Register.
13. Reconciliation of remittances Register.
The licensee shall also maintain the registers prescribed by the Commissioner from time to
time.Part - VI Provision Relating to Hygienic Conditions and Quality of Beers
36. The licensee shall maintain the following hygienic conditions in the
Brewery.
(1)The structure of the building of the Brewery shall be of permanent nature and shall be designed
as to provide sufficient space for equipment and material storage and facilitate carrying out process
operations in hygienic manner.(2)No portion of the Brewery building shall be used for domestic
purposes or other food preparations.(3)All equipments shall be cleaned regularly to prevent
contamination.(4)The materials used shall be free from contamination.(5)Proper care must be taken
to cover the vats and vessels.(6)Tanks in the storage room for Brew should be of stainless steel
material. They should be cleaned and maintained in such a way as to prevent corrosion.(7)Quality of
de-mineralized water plant should be properly maintained with anionic, cationic and mixed beds for
proper treatment of water.(8)The tanks and pipe lines shall be constructed with stainless steel
material. The pumps shall be flame proof. Tanks and pipe lines shall be earmarked for a particular
product to prevent contamination from one product to another. Pipes and fittings shall be leak
proof. Motors shall be placed to prevent dripping oil into the tanks.(9)All bottles shall be thoroughly
cleaned immediately before filling by automatic washing machines. Washing shall be accomplished
by pre-rinse and final rinse. For final rinse de-chlorinated potable water shall be used. Bottles
should be thoroughly drained after rinse so that quality of Beer is not affected after filling. Water jets
in the washing machine should be so designed that the jet pressure so maintained as to thoroughly
rinse the whole internal and external surface area of the bottles. Wash water in the bottle washer
should be thoroughly drained and changed frequently to prevent algal growth.(10)Whenever second
hand bottles are . being used, all the bottles should be pre-washed prior to feeding to the bottle
washer. This should be done in the following manner:a. Pre-rinse first soaking in a tank to remove
labels and other extraneous matter.b. Rinse in the second tank with hot water around 60°C and 3%
caustic solution at 60°C using brushes-to clean the interior and exterior of bottles thoroughly.c.
Final rinse in the third tank with potable water; and thend. Feed the bottles to the bottle
washer.(11)Filler nozzles shall be of stainless steel material with poly liners or PVC to prevent
chipping of bottles. Filler bungs above the nozzles shall be cleaned every day and periodically
replaced to prevent particular matter settling into liquor. Filling of the product into bottles can be
automatic fillers. Liquor falling on line due to breakage of bottles should be immediately cleaned
and broken glass taken off to prevent contamination.(12)The licensee shall erect the plant and
machinery as per the standards, as may be prescribed by the Commissioner from time to time for
maintaining the specifications and quality of products.Andhra Pradesh Brewery Rules, 2006

37.
The Brewery licensed under these rules shall maintain the quality of Beer as specified
hereunder:-Specifications for Beer:(1)Ethyl Alcohol content at 15°C. percent (v/v)(a)Light Beer
..........0.5 to below 4.0(b)Standard Beer ...........4.0 to below 5.0(c)Extra Strong Beer .........5.0 to
below 6.0(d)Super Strong Beer .........above 6.00(2)pH .................4.2 to 4.6(3)Carbon dioxide,
percent (v/v) Minimum: 2.5 Vol.(4)Beer shall be free from any other ingredient injurious to
health.(5)Beer shall be free from any added colouring matter except caramel produced from sugar.
The caramel shall be in conformity of Bureau of Indian Standards.(6)Bottled Beer or caned Beer
shall be effectively pasteurized.(7)Beer shall be free from coliform Bacteria and other pathogenic
microorganisms.Form -B(1)(See Rule-4 (2)(a))Application for Issue of Letter of IntentToThe
Principal Secretary to GovernmentRevenue (Excise) DepartmentHyderabad.Through the
Commissioner of Prohibition and ExciseSir,In pursuance of the notification issued by the
Government vide I / We................... R/o............I/We intend to establish a Brewery for manufacture
of Beer/ expand the production capacity of the existing Brewery as detailed in the following scheme
at .......of........District of A.P. State. I/We, therefore request that the scheme may kindly be examined
and necessary sanction accorded as required under Rule 4(2)(c) of Andhra Pradesh Brewery Rules
2006.Scheme
1. (a) Name and address:
(b)Name and address of the undertaking:(c)Whether Public/Private Ltd., or
Partnership/Proprietary' concern:
2. Location where the applicant intends to establish the Brewery:
3.
(1)Nature of manufactory:(a)* Whether it is a new Brewery?(b)* Whether it is the expansion of
existing Brewery? If so(i)Existing licence held by the applicant:(ii)Nature of activity:(iii)Existing
production capacity:(iv)Production capacity proposed to be increased:
4. Whether the applicant owns sufficient land at the proposed site: If so the
details thereof:
5. Whether the applicant has remitted the non-refundable and non-adjustable
fee & Special fee as specified in Rule 4.(2) (b) (i) & (ii).
(a)If so:(i)Amount remitted: Rs.(ii)Challan No. & Date:(iii)Name of the Treasury at which the
amount remitted:(b)Whether original Challan is enclosed to this application:Andhra Pradesh Brewery Rules, 2006

6. Proposed Investment Details:
(a)Capital investment:(b)Borrowings:(c)Investment on Land:(d)Investment on
Buildings:(e)Investment on Plant and Machinery:(f)Working Capital:
7. Whether sufficient water is available at the proposed place:
8. Whether proper power supply is available at proposed place to meet the
requirements of the unit:
9. Details of the raw materials:
(a)Quantity and value of raw materials to be imported or of imported origin per year.(b)Quantity
and value of raw materials if indigenous origin per year:
10. Whether the applicant is able to secure the raw material without the aid of
the Government:
11. Whether the plant and machinery to be installed is of imported or
indigenous and its details:
12. Details Of the Beer Proposed to be Manufactured:
(a)Name(s) of the Beer proposed to manufactured:(b)Standards of the product(s) proposed to
manufacture:(c)Brief process of manufacture:
13. Estimated annual production of Beer in bulk litres:
14. Whether the proposed unit will have any buyback arrangement? If so the
details thereof:
15. (a) Time required to secure land:
(b)Time required for erecting plant and machinery:
16. Employment potential of the proposed unit: (Indicate category-wise)
Enclosures:Andhra Pradesh Brewery Rules, 2006

1.
2.
3.
Date:Place:Signature of the applicant.Address for
correspondence:Sri.....................M/s.....................[*Strike out, which is not applicable]Form -
B(S)(See Rule 4(2) (c))Letter of IntentGovernment of Andhra PradeshRevenue (Excise) Department
Lr. No......... Dated:
FromThe Principal Secretary to Government (Rev. (Excise) Department)A.P.
Hyderabad.ToM/s...............SirSub:-Prohibition and Excise - Establishment of Brewery - Sanction
accorded for establishment and working for manufacture of Beer orders issued. Read:(l) Govt, of
A.P. Notification dated.................(2)Sri/M/s..................... Application
dated..............(3)Commissioner of Prohibition and Excise reference in CR. No dated------.
1. In response to the notification issued in the reference 1stcited, Sri/M/s.
has/ have submitted an application in the reference 2nd cited for sanction of
the Government for establishment and working of a Brewery or expand the
production capacity of the existing unit as required under Rule 4 (2) (a) of
Andhra Pradesh Brewery Rules 2006 for Manufacture of Beer. The applicant
proposes to establish the Unit or expand the production capacity of the unit
at of-------------District of Andhra Pradesh.
2. In the reference 3rd cited, the Commissioner of Prohibition and Excise,
Hyderabad has recommended the proposal.
3. The Government have examined the request of the applicant and the
recommendation of the Commissioner. The Government hereby accord
sanction for construction and work a Brewery or expansion of the production
capacity of the existing unit under Rule 4(2) (c) of Andhra Pradesh Brewery
Rules, 2006 subject to the following conditions:
(a)The quantity of Beer permitted for manufacture per annum shall be -Lakh bulk Liters
only.(c)This sanction is accorded without any commitment for allowing import of any machinery or
supply of raw materials.(d)This letter of Intent is valid for a period of two and half years from the
date of issue, subject to the condition that the holder shall obtain a licence from the Commissioner
of Prohibition and Excise within Six months duly fulfilling the formalities as required under A.P.
Brewery Rules, 2006.(e)The holder of this Letter of Intent shall fulfill the formalities laid down in
the Andhra Pradesh Distillery (Manufacture of Indian Made Foreign Liquors other than Beer andAndhra Pradesh Brewery Rules, 2006

Wine) Rules, 2006.(f)This Letter of Intent shall not, however confer any right or privilege for the
grant of a licence and is liable to be cancelled or withdrawn at any time and in such an event, no
compensation or damages whatever shall be payable.Principal Secretary to
GovernmentToM/s.....Copy to:The Commissioner of Prohibition and Excise, A.P. HyderabadThe
Commissioner of Industries, A.P. Hyderabad.Form - B(1)(A)(See Rule - 5(2))Application for Grant
of Licence for Brewery or Expansion of the Production Capacity of Existing BreweryToThe
Commissioner of Prohibition and Excise,A.P. Hyderabad.Sir,Sub:- Excise-Establishment of Brewery
for manufacture of Beer-Scheme approved by the Government - Certain request for grant of licence-
Regarding.Ref:- Lt. No....... Dated............Kindly peruse the reference cited wherein the Government
of Andhra Pradesh accorded sanction for establishment of a Brewery for manufacture of Beer or
expansion of production capacity of existing Brewery at_________________.As per the orders of
the Government as contemplated in the Letter of Intent, we are approaching your good self with the
following necessary documents with a request to grant new licence or accord sanction for expansion
of production capacity of existing Brewery :_____________________. under A.P. Brewery
Rules, 2006.
1. Copy of the Letter of Intent.
2. Particulars of land with relevant documents.
3. Blue print of the proposed Brewery.
4. Remittance particulars of initial licence fee under Rule 5 (4) (b) (Original
challan enclosed)
5. Remittance particulars security deposit under Rule 5 (3).
6. No objection certificate obtained from the competent local authority.
7. No objection certificate obtained from the A.P. Pollution Control Board.
8. Undertaking as required under Rule 5 (2) (g).
9. Counterpart agreement in form B(l) (c) as required under Rule 5 (3).
I/We undertake
1. to furnish any further plans, estimates or information as required.Andhra Pradesh Brewery Rules, 2006

2. that in the event of a Licence being granted, we commence/working of the
Brewery within the period limit prescribed and inform the date by which the
plant commences commercial production.
3. to comply in all respects with the provisions of the A.P. Brewery Rules,
2006 and the conditions of the License.
4. to pay the licence fee at the rates specified in Rule 7(a) from the date of
commencement of commercial production.
This application is within the specified time mentioned in the Letter of Intent.Enclosures:Signature
of the applicant.Form - B-1(C)(See Rule 5(3))Counterpart AgreementThis agreement is made and
executed as required under Andhra Pradesh Brewery Rules, 2006 issued under Andhra Pradesh
Excise Act, 1968 this day of 20 between Sri (herein after called the Licensee' which expression shall
include his heirs, representatives, successors and assignees) on the one part and the Governor of
Andhra Pradesh (herein after called the Government which expression shall include his successors
in office) on the other part.Whereas the licensee has applied for a licence for manufacture of
Beer:And whereas the Commissioner of Prohibition and Excise by virtue of the powers conferred
upon him under Rule 5(4)(a) of A.P. Brewery Rules, 2006 granted a licence in FORM B-2 for
manufacture of Beer, and whereas the licensee hereby agrees to the same and covenants with the
Government as follows:Now This Indenture Witnessed:
1. The licensee shall during the subsistence of the licence comply with the
conditions of licence and the provisions of Andhra Pradesh Excise Act, 1968
and rules framed there under and any notifications and orders of the
Government and Commissioner issued there under.
2. The licensee shall also be bound by the rules that may be made further
and other conditions that may be imposed from time to time during the
currency of the licence.
3. The licensee shall keep intact a security deposit of Rs Lakhs as laid down
in Rule 5(3) for due performance of this agreement.
4. In case of the breach of the terms and conditions of this agreement
including the conditions of licence it shall be lawful for the Government to
cancel the agreement and to forfeit the security deposit without prejudice to
any other action that may be taken against the licensee under the Act, and
the rules framed there under and also to recover all dues payable as arrears
of land revenue under Andhra Pradesh Revenue Recovery Act, 1864 or anyAndhra Pradesh Brewery Rules, 2006

other law for the time being in force in that behalf.
5. The agreement shall commence from the date of sanction or renewal of the
licence and shall remain in force till end of the currency of licence.
In witness whereof said Sri for and on behalf of the licensee and the Commissioner of Prohibition
and Excise, Andhra Pradesh Hyderabad for and on behalf of Governor of Andhra Pradesh have
signed this agreement on the date and year herein above written in the presence of the following
witness:Witness:Signature of the Licensee.
1.
2.
Signature of the Commissioner for and on behalf of the Governor of Andhra Pradesh.Form - B2(See
Rule-5(4)(a))Licence for Manufacture of Beer
Licence No: Issued On:
I, Sri............................ Commissioner of Prohibition and Excise under the provisions of
AndhraPradesh Brewery Rules, 2006 and in pursuance of the Letter of Intent bearingNo dated
Issued by the Government of Andhra Pradesh and on payment of annual the licence fee of Rs.
(Rupees only) Licence you Sri/Ms.hereinafter called the 'Licensee" to manufacture Beer.
SI.
No.Names of the Beers licensed for
manufactureQuantity permitted for manufacture per annum
inbulk liters
12   
This licence is issued subject to the following conditions:
1. The Licensee shall abide by the provisions of the Andhra Pradesh Excise
Act, 1968 and A.P. Brewery Rules, 2006 and all Rules made under any other
law, for the time being in force applicable to the manufacture, storage, issue
and sale of Beer.
2. This licence shall stand revoked in case the licensee fails to erect the
Brewery within a period of two and half years from the date of issue of Letter
of Intent.
3. The terms and conditions of this licence may be modified at any time
during the currency of this licence.Andhra Pradesh Brewery Rules, 2006

4. The licensee shall pay the differential license fee from the date of
commencement of commercial production proportionately as per the rates
specified under Rule 7(a)
5. A statement showing the number, size, description and capacity of the
Vats, tanks, bottling lines which the licensee may erect or maintain under
this licence and the plans and statement of the premises and buildings to be
used as Brewery, storage purpose and for other purposes relating to the
Brewery as approved by the Commissioner shall be annexed to this licence.
6. The licensee, without prior sanction-permission of the Commissioner,
shall not:- (a) Erect any other Vats, Tanks, Bottling lines, equipment, and
machinery other than those approved by the Commissioner.
(b)Alter, modify or make additions to the building and plant in deviation to the plans approved by
the Commissioner.
7. The Licensee shall at all times maintain the efficiency of the plant to the
satisfaction of the Commissioner.
8. The licensee shall maintain the registers and furnish the statements and
other information as may be required by the Commissioner in the manner
specified.
9. The licensee shall comply with the directions of the Commissioner
regarding quality, strength and purity of the Beer licensed for manufacture.
10. The licensee shall comply with the directions of the Commissioner
regarding usage of ingredients of high quality, stocks materials to be
maintained in day to day functioning of the Brewery.
11. The licensee shall not discontinue working of the Brewery (except in case
of closure for cleaning or repairs) without giving six months notice in writing
to the Commissioner of his intention to cease the work. He shall continue to
fulfill the conditions of this licence during the currency of the notice.Andhra Pradesh Brewery Rules, 2006

12. The licensee for any reason becomes incapable of carrying on with the
operations of the business or dies or becomes insolvent, the Commissioner
may either cancel the licence or continue it in the name of the legal heir as
the case may be.
13. Upon revocation or cancellation of licence under the preceding
conditions, the licensee shall forthwith cease Brewing and shall cease to use
the building and the plant for the purpose for which they were licensed.
Neither the licensee nor any other person shall be entitled to any
compensation or damage whatsoever, in respect of revocation or
cancellation of the licence.
14. If the licensee infringes or cause or permit any person to infringe any of
the conditions of this licence, the Commissioner shall have the power to
suspend or cancel this licence forthwith.
15. No Beer shall be removed from the Brewery without valid permit issued
by the competent authority.
16. The licensee shall have no right to claim any supply of raw materials
produced in the State of Andhra Pradesh for manufacture of Beer.
17. The licensee shall not act in any manner prejudicial to the interest of the
revenues of the Government.
18. The licensee shall not advertise his products by extolling their merits or
in any other objectionable manner.
Commissioner of Prohibition and Excise Andhra Pradesh, Hyderabad.Form - B1 (SL)(See Rule 10
(vii))Application for Grant of Permission for Sub-Lease of the BreweryToThe Commissioner
ofProhibition Excise, Andhra Pradesh,Hyderabad.Date............... at............Application of M/s. for
grant of permission for sub-lease in favour of M/s._______________ for carrying out
Manufacture of Beer.
1. The undersigned Licensee M/s. _______________ beg to apply for
permission for sub-lease of M/s __________________to
Sri/M/s._______________in whole of the licensed capacity under Rule 10 of
A.P. Distillery Brewery Rules, 2006.Andhra Pradesh Brewery Rules, 2006

2. The proposed sub-lessee desired to manufacture Beer as per the licensed
capacity granted to M/s._________________
3. In the event of grant of sub-lease being granted, the sub-lease holder
proposes to commence working at the Brewery on--------------------.
4. In the event of grant of sub-lease to the proposed sub-lessee, he
undertakes to comply in all respects with (a) the provisions of the rules
applicable to the Brewery', its working and (b) the conditions which are
entered in the licence.
5. The following documents are furnished:
(a)The sub-lease deed between the licensee and the proposed sub-lessee on a nonjudicial stamp
paper of the requisite value as per the provisions of the Indian Stamp Act, 1899.(b)Memorandum of
Articles of Association/partnership deed/declaration of sole proprietorship of licensee and
sub-lessee.(c)List of Directors/Partners of licensee and sub-lessee with their dated
signatures.(d)Undertaking in Form B (1) (SLU) on a non-judicial stamp paper of requisite value duly
singed by the licensee and sub-lessee.(e)Original challan as a proof of having paid 10% of Licence
fee.(f)F.D.R./B.G for an amount equal to 15% of the annual licence fee towards security deposit.
6. The applicants undertake to furnish duly registered lease deed within 15
days from the date of grant of permission of sub-lease.
7. The applicant licensee and the proposed sub-lessee severally and jointly
undertake to be bound by the A.P. Excise Act, 1968 and A.P. Brewery Rules,
2006 and other rules under any law for the time being in force applicable to
the manufacture, storage, issue and sale of Beer.
Signature of the Applicant (Licensee)Signature of the proposed sub-lessee.Form - B 1 (SLU)(See
Rule - 10(1)(vii)(d))Sub-Lease Undertaking(Non-Judicial Stamp Paper Worth Rupees One
Hundred)ToThe Commissioner of Prohibition &Excise, Andhra
Pradesh,Hyderabad.Sir,I/We__________S/o_______________holder of B-2 License of
M/s________________Distillery, aged about_________________years, resident
of_______________and Sri________________S/o__________________ proposed
sub-lease holder of M/s__________________________________Brewery, hereby
undertake:Andhra Pradesh Brewery Rules, 2006

1. That the sub-lease will be effective from the of------------------month-------year.
2. The licensed capacity of the Licensee per annum is BLs. The Licensee has
agreed to lease out.
3. That we shall be severally and jointly responsible to abide by the terms
and conditions of the licence as laid down in the licence in Form B-2 dated
and the provisions of A.P. Brewery Rules, 2006.
4. That we shall jointly and severally abide by the provisions of A.P. Excise
Act 1968 and the rules made there under from time to time.
5. That we shall be bound to pay any enhanced licence fee, excise duty,
security deposit . and any other fee or taxes to be levied from time to time.
6. That, we shall be bound to pay any penalties levied from time to time.
7. That, we hereby agree that the licence is liable to be cnacelled on the basis
of any adverse report of investigation for any lapse which amounts to
contravention of any rule or any conditions of licence or any other provisions
of Law and also for any conviction in any criminal case at any time.
8. That the licensee or sub-lease holder will not have any right or claim for
continuation or renewal of sub-lease in dependent of the B-2 licence and in
case the licence is cancelled or suspended or any other action taken under
excise law, it will automatically attract the sub-lease also.
9. If the licence/sub-lease is surrendered or cancelled in the middle of the
licence period, we shall not be eligible for refund of Licence Fee.
10. That, if we fail to pay the Excise Duty, Penalties etc., if any due to
Government on time, the licence is liable to be canceled and the entire
amount so due, without prejudice to any other mode of recovery, may be
recovered form the security deposit and also by way of restraining our
movable and immovable property whatsoever we possess and selling the
said properties under the Andhra Pradesh Revenue Recovery Act.Andhra Pradesh Brewery Rules, 2006

11. We declare that we have not been convicted of any offence under A.P.
Excise Act.
12. That we shall maintain all the registers of accounting etc., as required
under Andhra Pradesh Brewery Rules, 2006.
13. We shall not have any claim for any increase in the licensed capacity on
account of permission granted for sub-lease.
14. We shall be responsible for utilization/disposal as per Andhra Pradesh
Brewery Rules, 2006 of the balance stock of all the raw materials and the
Beer that remain at the end of the lease period.
Place : Signature of Licensee
Date : Proposed Sub-lease holder.
Form - B3(See Rule 11(1))Application for Shifting of the Existing Brewery
1. (a) Name of the Brewery:
(b)Name(s) & address (s)s of the Partner/Board Directors:(c)Whether Public/Private Ltd., or
Proprietary concern:
2. (a) Details of existing premises with Survey No. etc.:
(b)Details of total existing area and constructed area:(c)Details of existing man power:(i)Office
Staff:(ii)Technical Staff:(iii)Supervisory Staff:(iv)Permanent workers:(v)Temporary workers:
3. Details of Existing plant and Machinery:
(a)Existing Machinery:(b)Capacity of Machinery:(c)Existing Production capacity:
4. Reasons for shifting:
5. Details of proposed premises:
(a)Address with Survey No.(b)Details of availability of water and power requirement.(c)Details of
man power requirement at new site and availabilityAndhra Pradesh Brewery Rules, 2006

6. Details of clearance from the following Government institutions:
(a)Competent Local authorities:(b)A.P. Pollution Control Board:(c)Competent authority under
Factories Act:
7. Details of Plant and Machinery to be shifted to new premises:
8. Details of shifting Fee remitted:
Signature of the applicant with dateForm - B3 (M)(See Rule - 12(4)(i))Application for Merger of two
Breweries
1. Name and address of the Brewery proposed for merger:
2. Whether Proprietary/ Partnership concern/Limited Company:
3. Nature of Licence held:
4. Whether the licence is in force:
5. No. of bottling lines existing (Specify the details lines):
6. Production capacity of the Brewery as fixed by the Commissioner:
7. Annual Licence fee:
8. Reasons for merger:
9. Name and address of the taking over Brewery:
10. Whether proprietary/Partnership concern/Limited Company:
11. Nature of licence held by the taking over Brewery
12. Whether the licence is in force:
13. No. of bottling lines existing (Specify the details)Andhra Pradesh Brewery Rules, 2006

14. production capacity of the taking over Brewery as fixed by the
Commissioner:
15. Annual Licence fee:
16. Whether the licensee of the Brewery proposed for merger continue as a
partner/ Director even after merger:
17. Cumulative production capacity after merger:
18. Cumulative Licence fee of both the Breweries:
19. Licence fee payable according to the cumulative production capacity:
20. Whether the taking over distillery is willing for the liabilities of the
distillery proposed for merger:
Signature of the licensee of Brewery proposed for
merger.the Signature of the licensee of the Taking over
Brewery.
Form B - 4(See Rule 15(1))Application for Approval of Label to be Pasted on the Stocks of Beer
1. Name of the applicant:
2. Full address:
3. Details of licence held:
4. If the applicant is a partnership firm or company, the details thereof:
5. Full address of Brewery:
6. Details of Brand label for which approval sought:
(a)Name of the Brand:(b)Size of the bottles:
7. Details of payment of Label approval fee:
(a)Amount remitted: Rs.(b)Name of the treasury in which amount remitted:(c)Challan No. & Date:Andhra Pradesh Brewery Rules, 2006

8. Previous approval of same label by the Commissioner of Excise with
reference number and date (when submitted for re-approval)
9. No. of sample labels enclosed:
Signature of the applicant.Form B - 5(See Rule 28 (15) (i))Brew Book
No:......................... Brewery:
Quarter ending............Examined Folios:Officers name:Rank:Date:
Checked: Brewery Officer.
Brewery
BookBreweryQuantity to
be used of
Date and
hour of Hops  
Date and
hour of
entryMashing
malt or
cornDissolving
sugarMaltUn-malted
CornSugar Glucose FreshPartly
spentHops
Substitutes
(1) Kg(2) Kg(3) Kg(4) Kg(5) Kg(6) Kg(7) Kg(8) Kg(9) Kg(10)
Date and Hour when
wart will be drainedWorts
collectedDate and hour
of mixingDate of
BrewingMixing
worts
Date and hour when
collectedVesselsVessels from
which taken
Number Name Dip Gravity Number Name
(11) (12) (13) (14) (15) (16) (17) (18) (19) (20)
          
Worts maixed Initials Remarks
Vessels Brewers Officers
Number Name Dip Gravity
(21) (22) (23) (24) (25) (26) (27)
Form B-6(See Rule 29(17)(d))Bright Beer Stock Account(To be maintained Tank-wise)
Tank No.............. Alcoholic percentage:.............. %
(v/v)
DateOpening
Balance of
Beer in the
BBT (B.Ls)Receipt of
Beer in the
BBT (B.Ls)Total Beer
in the BBT
(B.Ls.)Issued
towards
Draught Beer
(B.Ls)Issue for
Bottling
(B.Ls.)Total
issues
from the
BBT (5+6)Closing
Balance of
Beer in the
BBT (B.Ls)
4-7)
1 2 3 4 5 6 7 8
        
 Andhra Pradesh Brewery Rules, 2006

Quantity of Beer
actually bottled
and transferredto
ware houseTotal issues
accounted for
in B.Ls(9+12)Wastage(in
B.Ls
Col.7-13)Percentage for
wastage Col.
13x100 : Col.7Signature of
the Brewery
Officer
Quantity of
draught beer
actually issued
and
dutyrealized
(B.Ls)No. of Bottles Size Qty. in B.Ls
9 10 11 12 13 14 1516
        
Form B - 7(See Rule 33 (e))Permit for Removal of BeerNo:.........................Date:.......................
1. Name and address of the Brewery:
2. Licence No. & Date:
3. Particulars of Beer to be removed:
(Batch No. & Description of packing)
4. Quantity in Litres:
5. Rate of duty:
6. Amount of duty paid:
7. Name of the Treasury, challan No. & date:
(Challan shall be enclosed in original)
8. Consignees address and licence No:
9. Remarks:
Signature of the Licensee or his authorized agent.Checked and found to be correct the consignment
for which duty has been paid. Indent passed and stock issued.Officer In-charge...........Brewery.Form
B - 8(See Rule 33 (8))Brewery Permit
No:................. Date:......................Andhra Pradesh Brewery Rules, 2006

(1)Name and address of the Brewery:(2)Licence No. & Date:(3)Particulars of Beer to be
removed:(Brand, Batch No. & Description of packing)(4)Quantity Issued:(a)No. of cases:(b)Size of
the Bottles:(c)Quantity in terms of bulk Litres:(d)Alcoholic percentage:(5)consignees address &
Licence No:(6)Vehicle No:(7)Time of dispatch:(8)Route:Checked the consignment for which duty
has been paid and found correct. Indent accepted and the stock released. This permit is valid
for___________Hours/days.Brewery Officer(1)Original Brewery permit with the Brewery
Officer.(2)Duplicate to Asst. Commissioner for Distilleries, having jurisdiction.(3)Triplicate to the
Excise Superintendent under whom the consignment goes.(4)Quadruplicate with
consignment.(5)Quintuplicate to Asst, Commissioner concerned to Brewery.(6)Sixth copy to the
Director of Enforcement, Hyderabad.Andhra Pradesh Brewery Rules, 2006

