Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9
February, 2023
Author: Jasmeet Singh
Bench: Jasmeet Singh
                          $~49
                          *      IN THE HIGH COURT OF DELHI AT NEW DELHI
                                                                  Judgment reserved on: 15.11.2022
                                                                  Judgment pronounced on: 09.02.2023
                          +      BAIL APPLN. 2919/2022 & CRL.M.(BAIL)1188/2022
                                 CHITRA RAMKRISHNA                                       ..... Petitioner
                                                         Through:    Ms. Rebecca John, Sr. Adv. with Mr.
                                                         Rony John, Mr. Shivam Batra, Mr. Akhil
                                                         Ranganathan, Mr. Subir Sarkar, Mr. Ankit
                                                         Bhushan, Mr. Arshdeep Singh, Mr. Aditya Luthra,
                                                         Mr. Piyush Swami, Mr. Anuj Dubey, Advs.
                                                                  versus
                                 ASSISTANT DIRECTOR, ENFORCEMENT DIRECTORATE,
                                                                                        ..... Respondent
                                                         Through:   Mr. Zoheb Hossain, Adv. with Mr.
                                                         Vivek Gurnani, Mr. Siddharth Sharma, Advs.
                                 CORAM:
                                 HON'BLE MR. JUSTICE JASMEET SINGH
                                                         JUDGMENT
JASMEET SINGH, J
1. This is a petition filed seeking grant of regular bail to the applicant in ECIR/DLZO-I/28/2022
dated 11.07.2022 for the offences punishable under Sections 3 / 4 of the Prevention of Money
Laundering Act, 2002 (PMLA).
2. The ECIR was registered by the Respondent, after CBI filed an FIR / RC on 07.07.2022 for the
offences punishable under Section 120- B/420/409 Indian Penal Code (IPC) read with Sections
20/21/24/26 of the Indian Telegraph Act as well as Sections 3 and 6 of the Indian Wireless
Telegraphy Act, and Sections 69B/72/72A of the Information Technology Act (IT Act), and Sections
13(1)(d) read with Section 13(2) of the Prevention of Corruption Act (PC Act).
3. The Applicant has been in custody since 14.07.2022 in relation to the present ECIR.
4. The applicant and other persons have been alleged to have illegally intercepted / monitored
telephone calls of employees of the National Stock Exchange Ltd. (hereinafter "NSE"). It is statedChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

that illegal tapping of phone calls of NSE employees was conducted under the guise of an agreement
between NSE and M/s ISEC Services Private Limited (hereinafter "ISEC").
5. To conduct Periodic Study Of Cyber Vulnerabilities, a payment of approximately Rs. 4.54 crores
was made by NSE to ISEC for the work between 01.01.2009 to 13.02.2017.
6. It has been alleged that ISEC monitored / intercepted the calls of 4 MTNL PRI lines, each having
capacity of 30 telephone connections used by the employees of NSE.
7. It is also alleged that ISEC submitted the transcripts of conversations to top management of NSE
during 01.01.2009 to 13.02.2017. The applicant was the Deputy Managing Director (hereinafter
"DMD") of the NSE till 2010, Joint Managing Director (hereinafter "JMD") till March, 2013 and
Managing Director (hereinafter "MD") till December, 2016.
8. The statement of the applicant was recorded on 21.05.2022 under Section 50 of the PMLA,
pursuant to the permission granted to ED on 20.05.2022. The statements of the Applicant were also
recorded on 14th-17th, 19th and 21st July 2022 pursuant to her remand/custody orders. The charge
sheet has already been filed on 09.09.2022.
9. On 05.08.2022, the applicant sought regular bail before the learned Special Judge, Rouse Avenue,
New Delhi in connection with the present ECIR which was dismissed on 29.08.2022.
10. The allegations against the applicant as per the prosecution complaint are primarily:-
"During the initial meeting for award of this contract in 2009, Sh. Sanjay Pandey, one
of the founding directors of the company till 2006 visited NSE to represent M/s.
ISEC in the discussion. During these deliberations, NSE was represented amongst
others by Sh. Ravi Narayan (the then MD) & Ms. Chitra Ramkrishna (the then DMD)
NSE.
...
The telephone numbers to be monitored were identified by Ms. Chitra Ramkrishna
(DMD), NSE Mumbai and conveyed to M/s. ISEC through employees of NSE. The
identified officers/departments included Market Watch, Market Surveillance, Risk
Management having access to critical online information and access to online Real
time data bases. ...
The payment of Rs. 4.54 Crore (approx.) was made by NSE to ISEC for this work
between 01.01.2009 to 13.02.2017. ...
The above facts revealed that during 2009 to 2017, Shri Ravi Narain, the then MD
(from 2009 to 2013), Ms. Chitra Ramkrishna, the then DMD/JMD (2009 to 2013) &
the then MD (2013-2016) abusing their official position entered into a conspiracyChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

with M/s. ISEC in furtherance of which M/s. ISEC was engaged for illegal
interception of phone calls of employees of NSE in the guise of Periodic Study of
Cyber Vulnerabilities of NSE."
11. Ms. Rebecca John, learned senior counsel appearing for the applicant contends the following:
11.1. As per the statement of Sanjay Pandey (one of the co-
accused and director of M/s ISEC), stated that it was Mr. Ravi Narain who introduced the applicant
to Mr. Sanjay Pandey in 2009.
11.2. Mr. Ravi Narain asked Mr. Sanjay Pandey to send proposal for the proposed work. It was in
fact Ravi Narain who had decided to utilise the services of Sanjay Pandey and his company, viz.
ISEC Services Pvt. Ltd., and not the applicant.
11.3. Ms. John, learned senior counsel states that a perusal of the statements of Ravi Narain and
Sanjay Pandey reveal that in 2009 it was Ravi Narain, who was the Managing Director and at the
helm of affairs at NSE, who approved the proposal submitted by ISEC Services Pvt. Ltd. and
directed the Applicant, the then Deputy Managing Director to implement his instructions. This goes
to show that the Applicant has been wrongly named as an accused in the case as her role is similar to
that of Ravi Varanasi and Mahesh Haldipur, who were also tasked with the implementation of the
instructions given by Ravi Narain.
11.4. The learned senior counsel states that the scheduled offences against the applicant are under
Section 120-B/420 IPC, Section 72 of the IT Act, 2000 and 13(2) r/w 13(1)(d) of PC Act, 1988. She
further states that in the facts of the present case none of the ingredients of the aforesaid Sections
are attracted.
11.5. As regards Section 420 IPC is concerned, Ms. John, learned senior counsel has drawn my
attention to Section 39 CrPC under which Section 420 IPC is not an offence for which any member
of the public can go and report a crime to the Police. She states that the offences under which any
member of the public can go and report a crime are exhaustively mentioned under Section 39 of the
CrPC and Section 420 IPC is not listed therein. Hence, in order to invoke the ingredients of Section
420 IPC, there must be a person aggrieved.
11.6. In the present case, it cannot be that the NSE is the person that is aggrieved by the actions of
the applicant, as it is neither the NSE who has registered the FIR nor any of the employees of NSE
whose lines were tapped by the applicant.
11.7. She further states that there is no element of deception, fraud or dishonest inducement as NSE
was, at all times, aware of the fact that the scope of the "Periodic Study of Cyber Vulnerabilities"
includes electronic monitoring. To further this contention, she places reliance on the "Proposal for
Periodic Study of Cyber Vulnerabilities" dated 05.02.2013, 27.06.2013, 07.02.2014, 09.02.2015 and
22.01.2016 submitted by ISEC to NSE, which clearly states that ISEC proposes to "continue" itsChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

services in the area of "electronic monitoring services at NSE".
11.8. With regards to section 120-B IPC, Ms. John, learned senior counsel states that the same is not
a standalone scheduled offence. The ED in their first and second remand application states 120B
r/w 420 IPC as one of the schedules offences. Additionally, she states that even the impugned order
as well as reply of the ED also refers to 120B read with other scheduled offences and section 120-B
IPC is not a standalone offence as far as the Applicant is concerned. 11.9. As regards Section 72 of
the IT Act is concerned, the learned senior counsel states that the Applicant or NSE had never been
conferred with any powers in terms of the Information Technology Act or rules and regulations
made thereunder. Moreover, there is no allegation to this effect in the FIR either against the
Applicant or NSE. 11.10. As regards section 13(1)(d) of the Prevention of Corruption Act is
concerned, she states that the Applicant is not a public servant within the meaning of the PC Act. Be
that as it may, assuming under Section 13(1)(d) and 13(2) PC Act that the applicant is performing a
public duty, still there is no illegal gain or benefit obtained by the applicant. It is not the case that
the applicant has received any kickbacks from the fee of Rs. 4.54 crores given to M/s ISEC Services
Private Limited. She states that the applicant has not unjustly enriched herself.
11.11. The learned senior counsel submits that the Delhi High Court in its order dated 15.04.2010
passed in Writ Petition (CIVIL) No. 4748 of 2007 held NSE to be a public authority under the RTI
Act. The said order has been stayed by the Division Bench of the Delhi High Court in LPA No. 315 of
2010 vide order dated 04.05.2010 and stay was made absolute on 21.08.2012. Thus, it is the NSEs
own case that NSE is not a public authority.
11.12. Lastly, it is the submission of the learned senior counsel for the applicant that the Proviso of
Section 45 PMLA will apply to the applicant being a woman.
11.13. She draws an analogy with Section 437 of the CrPC to state that an exception is carved out for
a woman and even in cases such as Section 302 IPC, a woman is entitled to bail. 11.14. It is
submitted that the applicant is in custody since 14.07.2022. The charge sheet has already been filed
and the applicant deserves to be released on bail.
11.15. She places reliance on the judgment of the Honble Supreme Court viz., Vijay Madanlal
Choudhary and Ors. v. UOI and Ors., 2022 SCC OnLine SC 929 wherein the court stated:
"388. There is no challenge to the provision on the ground of legislative competence.
The question, therefore, is : whether such classification of offenders involved in the
offence of money-laundering is reasonable? Considering the concern expressed by
the international community regarding the money- laundering activities world over
and the transnational impact thereof, coupled with the fact that the presumption that
the Parliament understands and reacts to the needs of its own people as per the
exigency and experience gained in the implementation of the law, the same must
stand the test of fairness, reasonableness and having nexus with the purposes and
objects sought to be achieved by the 2002 Act. Notably, there are several other
legislations where such twin conditions have been provided for617. Such twinChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

conditions in the concerned provisions have been tested from time to time and have
stood the challenge of the constitutional validity thereof. The successive decisions of
this Court dealing with analogous provision have stated that the Court at the stage of
considering the application for grant of bail, is expected to consider the question
from the angle as to whether the accused was possessed of the requisite mens rea.
The Court is not required to record a positive finding that the accused had not
committed an offence under the Act. The Court ought to maintain a delicate balance
between a judgment of acquittal and conviction and an order granting bail much
before commencement of trial. The duty of the Court at this stage is not to weigh the
evidence meticulously but to arrive at a finding on the basis of broad probabilities.
Further, the Court is required to record a finding as to the possibility of the accused
committing a crime which is an offence under the Act after grant of bail."
12. Per contra, Mr. Hossain, learned standing counsel for ED states:
12.1. Section 120 B IPC is not an offence which is to be read in conjunction with any
other Scheduled offence. 12.2. He states that Section 120 A IPC defines criminal
conspiracy as:
"120A. Definition of criminal conspiracy.--When two or more persons agree to do, or
cause to be done,-- (1) an illegal act, or (2) an act which is not illegal by illegal means,
such an agreement is designated a criminal conspiracy:
Provided that no agreement except an agreement to commit an offence shall amount
to a criminal conspiracy unless some act besides the agreement is done by one or
more parties to such agreement in pursuance thereof.
Explanation.-- It is immaterial whether the illegal act is the ultimate object of such
agreement, or is merely incidental to that object."
12.3. He states that the definition of 120A IPC reveals that the agreement between
two or more persons to do an illegal act is the most important ingredient for the
offence of conspiracy. The illegal act may or may not be committed pursuant to the
agreement but the very agreement is an offence and the conspiracy to commit an
illegal act is itself a standalone scheduled offence which in the present case was a
conspiracy to record and tap telephone lines that violates the Telegraph Act.
12.4. He argues that it is not necessary that the object of the conspiracy should be
achieved. Failing to execute the conspiracy on account of abandonment or detection
before commission of offence is immaterial as the very act of entering into an illegal
agreement is itself an offence punishable under law. In this regard, he places reliance
on Yogesh alias Sachin Jagdish Joshi v. State of Maharashtra (2008) 10 SCC 394
wherein the relevant para reads as under:Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

"25. Thus, it is manifest that the meeting of minds of two or more persons for doing
an illegal act or an act by illegal means is sine qua non of the criminal conspiracy but
it may not be possible to prove the agreement between them by direct proof.
Nevertheless, existence of the conspiracy and its objective can be inferred from the
surrounding circumstances and the conduct of the accused. But the incriminating
circumstances must form a chain of events from which a conclusion about the guilt of
the accused could be drawn. It is well settled that an offence of conspiracy is a
substantive offence and renders the mere agreement to commit an offence
punishable even if an offence does not take place pursuant to the illegal agreement."
12.5. Mr. Hossain has drawn my attention to Part A of the Schedule under PMLA to show that
Section 120 B is a standalone scheduled offence under the PMLA. 12.6. The submission of the
learned counsel is that once the ingredients of Section 120 B are satisfied and there is a conspiracy
to do something illegal, nothing else needs to be seen. He states that Section 43 of the IPC defines
"illegal" as:
"43. "Illegal". "Legally bound to do".-- The word "illegal" is applicable to everything
which is an offence or which is prohibited by law, or which furnishes ground for a
civil action; and a person is said to be "legally bound to do" whatever it is illegal in
him to omit."
12.7. He contends that the object of criminal conspiracy is to do something „illegal. Thus, the
conspiracy to violate the Telegraph Act by tapping phone lines is an illegal act under section 4 and
20 of the Telegraph Act and intentionally tampering with telegraph to acquaint oneself with
contents of the message forms an offence under section 25(b) of the Telegraph Act.
12.8. He states that provisions of the Information Technology Act have been breached viz., section
69B(2) read with sub- section 4 as M/s ISEC was not authorized to transmit or receive traffic data or
information. NSE officials in conspiracy with M/s ISEC tried to secure access to information without
consent of the person concerned and disclosed such information to higher officials of NSE thereby
violating section 72 of the IT Act which is a scheduled offence under PMLA.
12.9. He has further relied upon the statement of Mr. Subramanium Iyer, in charge of the supplier of
the equipment who categorically stated:
"Q6. What is the function of this equipment supplied by you to iSec Services Private
Limited and installed at NSE Office at Bandra Kuria Complex, Mumbai?
Ans6. It records all incoming and outgoing calls of all Primary Rate Interface (PRI)
lines which are connected to the Voice logging System.
Q7. In what manner were these PRI lines connected to the Voice Logging System?Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

Ans7. The PRI lines coming from the service provider were split into two lines with
the help of a splitter. Out of these two lines, one went to the EPABX system of NSE
and the other line went to the Voice logging system."
12.10. He states that Section 25(b) of the Indian Telegraph Act which reads as under:
"25. Intentionally damaging or tampering with telegraphs.--If any person,
intending--
(a) to prevent or obstruct the transmission or delivery of any message, or
(b) to intercept or to acquaint himself with the contents of any message, or
(c) to commit mischief, damages, removes, tampers with or touches any battery,
machinery, telegraph lines, post or other thing whatever, being part of or used in or
about any telegraph or in the working thereof, he shall be punished with
imprisonment for a term which may extend to three years, or with fine, or with both."
12.11. A preliminary submission has been made by the learned senior counsel for the Applicant that
the Section 25(b) has not been invoked or mentioned in the FIR.
12.12. Mr. Hossain, learned counsel submits that the FIR is not an encyclopedia of the charges. The
FIR need not spell out all the sections. Suffice it to say that if the ingredients of the offence are made
out, the section can always be read into the FIR.
12.13. He states that a bare perusal of the FIR clearly spells out the ingredients of Section 25(b).
12.14. The role of the petitioner has been crystallized in the Prosecution Complaint dated
09.09.2022 as under:
"Name of the 3. MS. CHITRA RAMKRISHNA Accused Role in the Based upon the
investigation conducted, as detailed case above, it is clearly established that Ms.
Chitra Ramkrishna was occupying senior positions in National Stock Exchange of
India Limited (NSE) through out the period 2009 to 2017. During the entire period of
offence i.e. from 01.01.2009 to 13.02.2017, she was holding the position of either
Deputy Managing Director (till 2010) or Joint Managing Director (till 2013) or
Managing Director (till December 2016) of NSE. After she relinquished the post of
Managing Director of NSE in December 2016, the contract for so called „Periodic
Study of Cyber Vulnerabilities of NSE expired on
13.02.2017 and was not renewed subsequently, thus proving that the said illegal activity was
co-terminus with her holding key position as Joint Managing Director/Managing Director in NSE.
She has miserably failed in her attempt to prove that she was not having knowledge of specific
details of the monitoring/recording/interception of telephone calls of NSE employees. In fact, it hasChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

been proved that she abused her official position and was instrumental in
recording/interception/monitoring of telephone calls much prior to 2009. She was part of the
decision making process at NSE wherein it was decided to engage M/s. ISEC Services Private
Limited for the said work from 01.01.2009. Admittedly, she was one who engaged with Mr. Sanjay
Pandey for the said work and issued instructions to her subordinates namely Sh. Ravi Varanasi and
Sh. Mahesh Haldipur to coordinate with Sh. Sanjay Pandey for the said work. It was she who had
instructed Mr. Ravi Varanasi to receive the call monitoring reports from ISEC Services Private
Limited and to brief her if anything significant was noticed. It is a proven fact that she was deeply
and fully involved in monitoring/interception/recording of telephone calls of NSE employees and its
nomenclature as „Periodic Study of Cyber Vulnerabilities. It was she who along with Sh. Ravi
Narain had participated in the discussions with Mr. Sanjay Pandey on behalf of NSE regarding
monitoring/ interception/recording of telephone calls of NSE employees and also the decision to
term· as Cyber Vulnerability Studies. The work order dated 03.06.2009 was issued as per
instructions. She had issued, instructions to Sh. Ravi Varanasi to forward the proposals for the work
orders issued to ISEC Services Private Limited for the interception of phone calls of NSE employees
from the year 2010 onwards. For all the subsequent years till 2016 (for the period upto 13.02.2017),
the proposals were forwarded by him to Ms. Chitra Ramkrishna, the then Joint Managing
Director/Managing Director of NSE for necessary approvals as instructed by her. It was on her
instructions that the approval for the period January 1, 2012 to March 31, 2012 was granted by Sh.
Ravi Varanasi. The employees and telephone numbers which were to be monitored were identified
and communicated to Sh. Ravi Varanasi by her. From time to time, She had reviewed and revised
the list of employees/numbers which were to be monitored. Both Ms. Chitra Ramkrishna and Mr.
Ravi Narain had decided on interception/ monitoring/recording of telephone calls which was done
under the garb of Periodic Study of Cyber Vulnerabilities. She had admitted that the actual scope of
Periodic Study of Cyber Vulnerabilities was recording/monitoring/interception of telephone calls of
NSE employees. She was instrumental in according approval for payment of the amount of Rs.
4,54,38,162/- i.e. the proceeds of crime which would not have been acquired by M/s. ISEC Services
Private Limited without the said approval.
Thus, Ms. Chitra Ramkrishna is guilty of offence of money laundering as defined in Section 3 of the
PMLA, 2002 as she was directly or indirectly indulging in or knowingly assisting in and was actually
involved in all or any process or activity connected with the proceeds of crime including its
concealment, possession, acquisition or use and projecting or claiming it as untainted property."
12.15. Proposal for call interception and monitoring was processed by Mahesh Haldipur through the
applicant who was at that point in time the Deputy Managing Director of NSE. 12.16. It is submitted
that Applicant is the mastermind of the entire conspiracy. It is the applicant who represented NSE
in the initial meetings for award of contract to Sanjay Pandey representing M/s ISEC. The telephone
numbers which were to be monitored were identified by the applicant.
12.17. It is further stated that monitoring record submitted by ISEC had no information on cyber
vulnerability. It only contained the conversations recorded of the employees of NSE identified by the
applicant.Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

12.18. Rs. 4,54,00,000/-, the fee received from January 2009 to February 2017 are therefore
proceeds of crime, as they were pursuant to an illegal act/ activity. He submits that all approvals
were processed through the applicant and given by her when she was the MD.
12.19. The erstwhile M.D., Mr. Ravi Narain in his Section 50 statement has stated that the
operational and day to day functioning was monitored by the applicant. 12.20. The tapping of the
conversations of the employees were co-
terminus with the Applicant holding key position as JMD/MD in NSE.
12.21. In December 2016, the applicant retired and the contract with ISEC was not renewed after
13.02.2017. 12.22. He states that the offence is money-laundering is non-
bailable and cognizable. He states the Honble Supreme Court in Vijay Madanlal Choudhary (supra)
has observed as under:
"406. It was urged that the scheduled offence in a given case may be a non-cognizable
offence and yet rigors of Section 45 of the 2002 Act would result in denial of bail even
to such accused. This argument is founded on clear misunderstanding of the scheme
of the 2002 Act. As we have repeatedly mentioned in the earlier part of this judgment
that the offence of money-laundering is one wherein a person, directly or indirectly,
attempts to indulge or knowingly assists or knowingly is a party or is actually
involved in any process or activity connected with the proceeds of crime. The fact that
the proceeds of crime have been generated as a result of criminal activity relating to a
scheduled offence, which incidentally happens to be a noncognizable offence, would
make no difference. The person is not prosecuted for the scheduled offence by
invoking provisions of the 2002 Act, but only when he has derived or obtained
property as a result of criminal activity relating to or in relation to a scheduled
offence and then indulges in process or activity connected with such proceeds of
crime. Suffice it to observe that the argument under consideration is completely
misplaced and needs to be rejected."
12.23. He also contends that at this stage, in light of the material placed on record, no satisfaction of
the twin conditions can be reached hence, bail cannot be granted under section 45 PMLA.
12.24. He states the proviso to section 45 PMLA is a discretionary power of the Court to grant bail to
persons falling in the categories mentioned therein but the said discretion shall be exercised by the
court based on the peculiar facts and circumstances of each case. He places reliance on Mrs Shivani
Rajiv Saxena v. Directorate of Enforcement & Anr. Vide order dated 15.09.2017 in Bail Appln.
1518/2017 wherein it was observed:
"9. A perusal of Section 45(1) of PMLA makes it clear that no person, accused of an
offence punishable for a term of imprisonment of more than three years under Part A
of the Schedule, shall be released on bail or on his own bond unless twin conditionsChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

as stipulated in Section 45(1) are satisfied. Firstly, Public Prosecutor has to be given
an opportunity; secondly in case Public Prosecutor opposes the application the Court
has to be satisfied that there are reasonable grounds for believing that accused is not
guilty of such offence and that he is not likely to commit any offence while on bail.
First proviso is exception to the above rule and vests power of discretion to the Court
to release on bail the categories of persons, as notified in the proviso, which includes
a woman or a sick person. I am of the view, that rigours of Section 45(1)(ii) of PMLA
will not be applicable to the categories of persons, as mentioned in the proviso. In
case it is held that conditions as laid in Section 45(1)(ii) shall also be attracted in
respect of the persons, as notified in the proviso, in my opinion, proviso will be
rendered nugatory, in as much as, an accused will otherwise be entitled to be released
if he satisfies the condition laid down in section 45(1)(ii).However, in my view, the
discretion as envisaged in the proviso has to be applied depending upon the special
circumstances attending to such categories of person and not as a matter of Thumb
rule that all such categories of persons shall necessarily be granted bail."
ANALYSIS:
13. I have heard learned counsel for the parties.
14. In the present case, for the purpose of this bail application, I am only to decide prima-facie
whether the scheduled offences are made out against the Applicant.
15. The scheduled offences alleged against the applicant are:
 Section 72 of the IT Act  Section 120-B of IPC read with section 420 of IPC 
Section 13(2) read with section 13(1)(d) of the PC Act
16. Section 72 of the IT Act reads as under:
"72. Penalty for breach of confidentiality and privacy.-- Save as otherwise provided in
this Act or any other law for the time being in force, if any person who, in pursuance
of any of the powers conferred under this Act, rules or regulations made thereunder,
has secured access to any electronic record, book, register, correspondence,
information, document or other material without the consent of the person
concerned discloses such electronic record, book, register, correspondence,
information, document or other material to any other person shall be punished with
imprisonment for a term which may extend to two years, or with fine which may
extend to one lakh rupees, or with both."
17. Section 72 of the IT Act is only limited to breach of confidentiality and privacy. The ingredients of
the said offence are:Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

 A person has been vested with powers conferred under the Act, rules or regulations
made thereunder;
 In pursuance of those powers, that person secured access to any electronic record,
book, register, correspondence, information, document or other material without the
consent of the person concerned;
 Disclosure of such electronic record, book, register, correspondence, information,
document or other material to any other person.
18. As regards section 72 of the IT Act is concerned, the elements of the said offence are not made
out in the present case as neither the Applicant nor the NSE was conferred with any powers under
the said Act. Moreover, the Applicant or the NSE was not acting in pursuance of the powers
conferred under the IT Act or the rules or regulations made therein.
19. In Sanjay Pandey v. Directorate of Enforcement BAIL APPLN. 2409/2022 vide order 08.12.2022
this court has already held as under:
"41. Sec.72 of the IT Act prescribes the penalty for breach of confidentiality and
privacy. The language of sec. 72 IT Act categorically states that it penalises only
persons acting "in pursuance of any of the powers conferred under" the IT Act or the
rules or regulations made thereunder. In the present case, the prosecution under
PMLA seems to be predicated on the fact that by tapping the telephone lines of the
employees of NSE, the applicant has secured access to electronic record without the
consent of that person and is punishable. However, the key words in section 72 IT Act
state that the person who secures access to electronic record, book, register,
correspondence, information, document or other material has to be in pursuance of
powers conferred under the Act or rules and regulations made thereunder."
20. The contract between NSE and M/s ISEC permitted recording of conversations. Recording or
tapping of phone calls sans consent of the concerned persons is an offence punishable under the
Indian Telegraph Act and Indian Wireless Telegraphy Act. However, the same are not scheduled
offences. Thus, invocation of section 72 of the IT Act is misplaced in the present case.
21. The ED has vehemently argued that section 120B of IPC is a standalone scheduled offence.
However, the pleadings and case set up by the ED is to the contrary. A bare perusal of the FIR,
Prosecution Complaint as well as the Remand Applications make it evident that section 120B IPC
has not been invoked as an independent standalone scheduled offence as the same is read with
section 420/409 IPC. Section 409 IPC is not a scheduled offence.
22. The Remand Application dated 14.07.2022 reads as under:
"3. That Sections 120B r/w 420 of IPC Section 72 of information Technology Act,
2000 and Section 13(2) r/w.13(1)(d) of PC Act,1988 are covered under the definitionChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

of Scheduled Offences as defined under Section 2(1) (y) of the prevention of Money-
Laundering Act, 2002 (PMLA) As such investigation have been initiated by the
applicant under PMLA, 2002 for the offence of money laundering as defined under
Section 3 & punishable under Section 4 of PMLA 2002."
23. The Remand Application 18.07.2022 reads as under:
"4. That Sections 120B r/w 420 of IPC, Section 72 of Information Technology Act,
2000 and Section 13(2) r/w 13(1)(d) of PC Act, 1988, are covered under the definition
of 'Scheduled Offences' as defined under Section 2 (1)(y) of The Prevention of
Money-Laundering Act, 2002 (PMLA). As such, investigations have been initiated by
the applicant under PMLA, 2002 for the offence of money-laundering a defined
under Section 3 & punishable under Section 4 of PMLA, 2002."
24. The Remand Application dated 22.07.2022 reads as under:
"4. That Central Bureau of Investigation registered FIR/RC bearing no.
RC2212022E0030 dated 07.07.2022 inter-alia for the commission of offences
punishable u/s Section-120B r/w 409 & 420 of IPC, 1860, Section 20,21,24 & 26 of
Indian Telegraph Act, 1885, Section 3 & 6 of Indian Wireless Telegraphy Act, 1933,
Section 13(2) r/w 13(1) (d) of Prevention of Corruption Act, 1988 and Section 69B, 72
& 72A of Information Technology Act, 2000 at EO-III, CBI, New Delhi against M/s
iSec Services Private Limited and other accused including Ms. Chitra Ramkrishna,
the then DMD/MD of NSE regarding illegal interception/monitoring of telephone
calls of NSE employees.
5. That Sections 120B r/w 420 of IPC, Section 72 of Information Technology Act,
2000 and Section 13(2) r/w 13(1)(d) of PC Act, 1988, are covered under the definition
of 'Scheduled Offences' as defined under Section 2 (1)(y) of The Prevention of
Money-Laundering Act, 2002 (PMLA). As such, investigations have been initiated by
the applicant under PMLA, 2002 for the offence of money-laundering as defined
under Section 3 & punishable under Section 4 of PMLA, 2002."
25. The Prosecution Complaint records the following:
"3. Brief facts of the offence/ allegation/ charge/ amount involved under PMLA:
a. That an investigation under PMLA was initiated vide F. No.
ECIR/DLZ0-1/28/2022 in Enforcement Directorate, Delhi Zone-I and is under
investigation in Delhi Zone-I. The LEA case of predicate offence vide
RC2212022E0030 dated 07.07.2022 under Sections 120B r/w 409 & 420 of IPC,
1860, Section 20,21,24 &Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

26 of Indian Telegraph Act, 1885, Section 3 & 6 of Indian Wireless Telegraphy Act, 1933, Section
13(2) r/w 13(1) (d) of Prevention of Corruption Act, 1988 and Section 69B, 72 & 72A of Information
Technology Act, 2000, is pending investigation with EO-III, Central Bureau of Investigation, New
Delhi..."
26. In the reply filed by the ED to the bail application moved in the Trial Court, the ED continues to
treat the offence under 120B to be read with the other scheduled offences. The relevant paras of the
reply read as under:
"c. That Sections 120B r/w 420 of IPC, Section 72 of Information Technology Act,
2000 and Section 13(2) r/w 13(1)(d) of PC Act, 1988, are covered under the definition
of 'Scheduled Offences' as defined under Section 2 (1)(y) of The Prevention of
Money-Laundering Act, 2002 (PMLA). As such, investigations have been initiated by
the applicant under PMLA, 2002 for the offence of money-laundering as defined
under Section 3 & punishable under Section 4 of PMLA, 2002."
27. The order dated 29.08.2022 reads as under:
"2. As per record, CBI had registered FIR/RC bearing No. RC2212022E0030 dated
07.7.2022 inter-alia for commission of offences punishable under Section 120B read
with Section 409 & 420 IPC, Section 20, 21, 24 & 26 of Indian Telegraph Act, Section
3 & 6 of Indian Wireless Telegraphy Act, Section 13(2) read with Section 13(1)(d) of
PC Act and Section 69B, 72 & 72A of Information Technology Act at EO-III, CBI, New
Delhi against M/s iSec Services Pvt.Ltd. & other accused persons including the
applicant regarding illegal interception/monitoring of telephone calls of NSE
Employees. Since, some of aforementioned offences punishable under section 120B
read with 420 IPC, Section 13(2) read with Section 13(1)(d) of PC Act and Section 72
of Information Technology Act, 2000 are covered under the definition of 'Scheduled
Offences' as defined under Section 2 (1)(Y) of The Prevention of Money-Laundering
Act, 2002 (PMLA), ED also registered instant case ECIR/DLZ0-1/28/2022 dated
11.7.2022 under PML Act for the offence of money laundering as defined under
section 3 and punishable under section 4 of PMLA."
28. In this view of the matter, section 120B has not been invoked as a standalone charging section
but has been invoked along with section 420 /409 IPC vis-à-vis the Applicant.
29. Section 120B of IPC reads as under:
"120B. Punishment of criminal conspiracy. --
(1) Whoever is a party to a criminal conspiracy to commit an offence punishable with
death, 2[imprisonment for life] or rigorous imprisonment for a term of two years or
upwards, shall, where no express provision is made in this Code for the punishment
of such a conspiracy, be punished in the same manner as if he had abetted suchChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

offence. (2) Whoever is a party to a criminal conspiracy other than a criminal
conspiracy to commit an offence punishable as aforesaid shall be punished with
imprisonment of either description for a term not exceeding six months, or with fine
or with both."
30. With regards to Section 120B IPC, I am of the view that the ingredients of the said offence are
not established since the criminal intent i.e., agreement to do an illegal act as defined under
sec.120A IPC is not made out.
31. In Sanjay Pandey (supra), I have held the following:
"58. The offence under section 120-B IPC (which is also a PMLA scheduled offence) is
also not made out in so far as the criminal intent i.e., agreement to do an illegal act as
defined under sec.120-A IPC is not established. NSE has been involved in
call-recording since 1997 through other vendors such as M/s Comtel, prior to ISEC
being brought into the picture to analyse recorded calls. Since call recording was
being done prior to the arrival of ISEC, there is no criminal conspiracy entered into
between ISEC and NSE with the intention of committing an illegal act, namely, call
recording. Thus, the element of criminal intent is not made out in the present case
and no offence under section 120 B read with 409 and 420 IPC is established."
32. As per the documents placed before me, it is observed that NSE was recording conversations
since 1997 through other vendors and the transactions with ISEC occurred from 2009 to 2017. The
Applicant was DMD of NSE till 2010 and JMD till 2013 and MD till 2016. As call recording was done
by NSE prior to ISECs involvement, it is wrong to allege that the Applicant conspired with ISEC to
illegally tap and record calls. Thus, the ingredients of section 120B IPC are not made out in the
present case.
33. Section 420 of the IPC reads as under:
"420. Cheating and dishonestly inducing delivery of property.--Whoever cheats and
thereby dishonestly induces the person deceived to deliver any property to any
person, or to make, alter or destroy the whole or any part of a valuable security, or
anything which is signed or sealed, and which is capable of being converted into a
valuable security, shall be punished with imprisonment of either description for a
term which may extend to seven years, and shall also be liable to fine."
34. The Apex Court in Prof. R.K. Vijayasarathy and Anr. v. Sudha Seetharam and Anr. (2019) 16 SCC
739 held that for the offence of cheating to manifest under section 420 IPC, the following
ingredients need to be present:
"19. The ingredients to constitute an offence under Section 420 are as follows:Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

19.1. A person must commit the offence of cheating under Section 415; and 19.2. The
person cheated must be dishonestly induced to
(a) deliver property to any person; or
(b) make, alter or destroy valuable security or anything signed or sealed and capable
of being converted into valuable security.
20. Cheating is an essential ingredient for an act to constitute an offence under
Section 420."
35. In the present case, there was no complaint from NSE or any employee of the NSE that the
Applicant cheated NSE or its employees. Furthermore, there is no allegation that the Applicant
deceived or fraudulently induced NSE to deliver any property to any person.
36. As far as the business arrangement with M/s ISEC is concerned, there is no difference between
NSE and the management of NSE, including the Applicant. The business contract was between M/s
ISEC and NSE for which NSE made payments to M/s ISEC.
37. The Applicant was at all times acting on behalf of NSE and representing NSE in her capacity as
DMD/JMD/MD of NSE. She carried out her duties in the capacity of DMD/JMD/MD of NSE,
therefore, it is wrong to allege that the Applicant deceived or fraudulently induced NSE to enter into
an agreement with M/s ISEC and make payments to M/s ISEC.
38. The documents titled "Periodic Study of Cyber Vulnerabilities" clearly records that M/s ISEC
proposes to "continue" its services in the area of "electronic monitoring services at NSE". Since NSE
was at all times aware that the scope of "Periodic Study of Cyber Vulnerabilities"
includes electronic monitoring, there is no deception, fraud or dishonest inducement
on the part of the Applicant.
39. Pertinently, no victim has been identified by the ED who has suffered a wrongful loss on account
of deception or cheating by the Applicant. Except for a vague and bald averment that customers
have been cheated, there is no mention of the names of the persons who have been cheated. Thus,
the ingredients of section 420 IPC are not made out in the present case.
40. In view of the above, prima facie the ingredients of the scheduled offences under IPC viz.,
Section 120B read with section 420 IPC are not made out against the Applicant.
41. Section 13(1)(d) and 13(2) of PC Act (pre-amended) is reproduced below:
"13. Criminal misconduct by a public servant.--
(1) A public servant is said to commit the offence of criminal misconduct,--Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

...
(d) if he,--
(i) by corrupt or illegal means, obtains for himself or for any other person any valuable thing or
pecuniary advantage; or
(ii) by abusing his position as a public servant, obtains for himself or for any other person any
valuable thing or pecuniary advantage; or
(iii) while holding office as a public servant, obtains for any person any valuable thing or pecuniary
advantage without any public interest; or ...
(2) Any public servant who commits criminal misconduct shall be punishable with imprisonment
for a term which shall be not less than one year but which may extend to seven years and shall also
be liable to fine."
42. The Honble Supreme Court has outlined the essential ingredients for determining the offence
under Section 13(1)(d) of PC Act in A. Subair v. State of Kerala (2009) 6 SCC 587 while stating the
following:
"14. Insofar as Section 13(1)(d) of the Act is concerned, its essential ingredients are:
i. that he should have been a public servant; ii. that he should have used corrupt or
illegal means or otherwise abused his position as such public servant, and iii. that he
should have obtained a valuable or pecuniary advantage for himself or for any other
person."
43. The ingredients of Section 13(1)(d) of the PC Act are not made out in the present case as the
Applicant is not a public servant within the meaning of the PC Act. NSE is not a public authority. In
this regard, the learned senior counsel for the Applicant had brought to my notice the order dated
04.05.2010 of the Division Bench of the Delhi High Court in LPA No. 315 of 2010 wherein this court
stayed the order of the learned Single Judge holding NSE to be public authority. The stay was made
absolute on 21.08.2012. Thus, since NSE is not a public authority, the Applicant is not a public
servant.
44. In addition, the ED has also failed to show how the Applicant has obtained for herself or for any
other person any valuable thing or pecuniary advantage within the meaning of section 13 of PC Act.
45. There is no evidence placed on record to prove corruption or abuse of position by the Applicant.
The consideration received by M/s ISEC is pursuant to a contract entered into with NSE and work
orders issued with the approval of Mr. Ravi Narain, the Managing Director. Thus, the ingredients of
section 13(1)(d) r/w 13(2) PC Act are not made out against the Applicant. Hence, scheduled offence
under section 13 PC Act is not established against the Applicant.Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

46. Since I have held above that prima facie no scheduled offences against the Applicant are
established, the provisions of PMLA cannot be attracted to the present case.
47. After conclusion of arguments, I was informed that the Applicant has been granted regular bail
by the Ld. Special Judge, Rouse Avenue in RC No. 2212022E0030 dated 07.07.2022 vide order
dated 21.12.2022.
48. The Applicant has sought bail under section 45 PMLA. According to Section 45 PMLA, the two
conditions for grant of bail are:
(i) public prosecutor has to be given an opportunity to oppose bail and;
(ii) there are reasonable grounds to believe that the accused is not guilty of the
offence and the accused is not likely to commit any offence while on bail.
49. Addressing the second condition, the ingredients of section 3 PMLA are culled out as follows:
 A person who directly or indirectly attempts to indulge or knowingly assists, or
knowingly is a party, or is actually involved;
 In any process or activity connected with the proceeds of crime including its
concealment, possession, acquisition or use and projecting or claiming it as untainted
property.
50. This court in Sanjay Pandey (supra) has held as under:
"77. I am of the view that in the present case, no scheduled offence is prima facie
made out, concomitantly there cannot be proceeds of crime having been generated as
there is no criminal activity relating to a scheduled offence. This position is in
consonance with the dicta of Vijay Madanlal Choudhary (supra) where the Honble
Supreme Court held as under:
"406.... The fact that the proceeds of crime have been generated as a result of
criminal activity relating to a scheduled offence, which incidentally happens to be a
noncognizable offence, would make no difference. The person is not prosecuted for
the scheduled offence by invoking provisions of the 2002 Act, but only when he has
derived or obtained property as a result of criminal activity relating to or in relation
to a scheduled offence and then indulges in process or activity connected with such
proceeds of crime. Suffice it to observe that the argument under consideration is
completely misplaced and needs to be rejected."
78. Since none of the ingredients of the scheduled offences viz., Section 72 IT Act, Section 120B r/w
409 and 420 IPC, Section 13(2) read with 13(1)(d) PC Act are made out, there is no occasion to
allege acquisition or retention of „proceeds of crime, which under Section 2(u) of PMLA is definedChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

to mean proceeds arising out of „scheduled offences. "
51. In the case of Vijay Madanlal Choudhary (supra) the Honble Supreme Court has
opined that provisions of PMLA would apply when a person has derived or obtained
property as a result of a scheduled offence, and then indulged in any process or
activity connected with such property.
52. In the present case there is no allegation that the Applicant has derived or
obtained any property or proceeds of crime. Additionally, there is no allegation or
evidence produced before me to suggest that the Applicant has concealed, possessed,
used, projected or claimed any proceeds of crime as untainted property.
53. Respondent has relied upon the judgment of this Honble Court in Mrs Shivani
Rajiv Saxena vs. Directorate of Enforcement & Anr, order dated 15.09.2017 in Bail
Appl. 1518/2017 to contend that the discretion under the proviso to section 45 PMLA
may not be exercised in cases where the accused has played an active role in the
offence of money laundering. The said decision of this court is not applicable to the
present case as the facts of that case stand on a different footing.
54. In Shivani Saxenas (supra) case, the court was of the view that the Applicant
therein was a partner/director in both the companies which were accused of money
laundering. The court was of the view that they were carriers of proceeds of crime.
The present case is distinguishable as I have already given a prima facie finding that
the applicant is not guilty of scheduled offences.
55. In view of my findings above, I have not dealt with the argument of the Applicant
being entitled to bail on account of being a woman under the proviso to section 45
PMLA.
56. Prima facie there are reasonable grounds to believe that the Applicant is not
guilty of the offence and she is not likely to commit any offence while on bail. I have
given an opportunity to the ED to oppose the bail application thereby satisfying the
twin conditions enumerated under 45 PMLA.
57. Even though not relevant for the purpose of deciding this bail application, it is
noted that Mr Ravi Narain (co-accused) has been granted bail on humanitarian
grounds by Learned ASJ on 07.11.2022 in CBI vs. Ravi Narain, Bail Matter No.
02/2022 and Bail Matter No. 232/2022.
58. For the aforesaid reasons, the application is allowed and the applicant is granted
bail in ECIR/DLZO-I/28/2022 dated 11.07.2022 on the following terms and
conditions:Chitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

i. The applicant shall furnish a personal bond in the sum of Rs. 1,00,000/- with two
sureties in the like amount to the satisfaction of the Trial Court;
ii. The applicant shall join investigation as and when called by the I.O concerned;
iii. The applicant shall appear before the Court as and when the matter is taken up for
hearing;
iv. The applicant shall provide her mobile number to the Investigating Officer (IO)
concerned, which shall be kept in working condition at all times. The applicant shall
not switch off, or change the same without prior intimation to the IO concerned,
during the period of bail;
v. In case the applicant changes her address, she will inform the IO concerned and
this Court also;
vi. The applicant shall not leave the country during the bail period and surrender her
passport at the time of release before the I.O. concerned;
vii. The applicant shall not indulge in any criminal activity during the bail period;
viii. The applicant shall not communicate with, or come into contact with any of the
prosecution witnesses or tamper with the evidence of the case.
59. In view of the above, the bail application is disposed of.
60. The relevant documents handed over in Court are taken on record.
JASMEET SINGH, J FEBRUARY 09, 2023 (MS)/jv Click here to check corrigendum, if anyChitra Ramkrishna vs Assistant Director, Enforcement ... on 9 February, 2023

