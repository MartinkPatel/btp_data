Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of
Gujarat & 1....Opponents on 4 August, 2016
Equivalent citations: AIR 2016 (NOC) 739 (GUJ.)
Author: R. Subhash Reddy
Bench: R.Subhash Reddy, Vipul M. Pancholi
                C/WPPIL/108/2016                                              CAV JUDGMENT
                    IN THE HIGH COURT OF GUJARAT AT AHMEDABAD
                              WRIT PETITION (PIL) NO. 108 of 2016
                                              With
                        SPECIAL CIVIL APPLICATION NO. 8804 of 2016
                                              With
                        SPECIAL CIVIL APPLICATION NO. 8655 of 2016
                                              With
                        SPECIAL CIVIL APPLICATION NO. 9740 of 2016
         FOR APPROVAL AND SIGNATURE:
         HONOURABLE THE CHIEF JUSTICE
         MR. R.SUBHASH REDDY
         and
         HONOURABLE MR.JUSTICE VIPUL M. PANCHOLI
         ==========================================================
         1     Whether Reporters of Local Papers may be allowed
               to see the judgment ?
         2     To be referred to the Reporter or not ?
         3     Whether their Lordships wish to see the fair copy of
               the judgment ?
         4     Whether this case involves a substantial question of
               law as to the interpretation of the Constitution of
               India or any order made thereunder ?
         ==========================================================
             DAYARAM KHEMKARAN VERMA S/O KHEMKARAN VERMA....ApplicantsDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

                                     Versus
                        STATE OF GUJARAT & 1....Opponents
         ==========================================================
         Appearance:
         WP(PIL) NO 108 OF 2016:
         MR IH SYED with MR RAHUL SHARMA, ADVOCATE for Petitioner
         MR KAMAL B TRIVEDI, ADVOCATE GENERAL with MS SK VISHEN, AGP
                                           Page 1 of 104
HC-NIC                                   Page 1 of 104     Created On Sat Aug 06 03:51:36 IST 2016
               C/WPPIL/108/2016                                          CAV JUDGMENT
         with MR PK JANI, ADDITIONAL ADVOCATE GENERAL with MS ML SHAH,
         GOVERNMENT PLEADER for Respondent No. 1
         MR AMIT PANCHAL with MS SHIVANI RAJPUROHIT, ADVOCATE for
         Respondent No. 2
         SPECIAL CIVIL APPLICATION NO 8804 OF 2016:
         MR SN SHELAT, SR. ADVOCATE with MS VD NANAVATI,ADVOCATE for
         Petitioners
         MR KAMAL B TRIVEDI, ADVOCATE GENERAL with MS SK VISHEN, AGP
         with MR PK JANI, ADDITIONAL ADVOCATE GENERAL with MS ML SHAH,
         GOVERNMENT PLEADER for Respondent No. 1
         MR AMIT PANCHAL with MS SHIVANI RAJPUROHIT, ADVOCATE for
         Respondent No. 5
         MR MIHIR THAKORE, SR. ADVOCATE with MS AMRITA M THAKORE,
         ADVOCATE for Respondent Nos. 6 to 9
         SPECIAL CIVIL APPLICATION NO 8655 OF 2016:
         MR BT RAO with MR VIJAY NANGESH, ADVOCATE for Petitioner
         MR KAMAL B TRIVEDI, ADVOCATE GENERAL with MS SK VISHEN, AGP
         with MR PK JANI, ADDITIONAL ADVOCATE GENERAL with MS ML SHAH,
         GOVERNMENT PLEADER for Respondent No. 1
         MR AMIT PANCHAL with MS SHIVANI RAJPUROHIT, ADVOCATE for
         Respondent No. 5
         MR MIHIR THAKORE, SR. ADVOCATE with MS AMRITA M THAKORE,
         ADVOCATE for Respondent Nos. 6 to 9
         SPECIAL CIVIL APPLICATION NO 9740 OF 2016:
         MR SHALIN MEHTA, SR. ADVOCATE with MR HEMANG M SHAH.
         ADVOCATE for Petitioner
         MR KAMAL B TRIVEDI, ADVOCATE GENERAL with MS SK VISHEN, AGP
         with MR PK JANI, ADDITIONAL ADVOCATE GENERAL with MS ML SHAH,
         GOVERNMENT PLEADER for Respondent No. 1
         MR AMIT PANCHAL with MS SHIVANI RAJPUROHIT, ADVOCATE for
         Intervener.
         ==========================================================
          CORAM: HONOURABLE THE CHIEF JUSTICE MR. R.SUBHASHDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

                 REDDY
                 and
                 HONOURABLE MR.JUSTICE VIPUL M. PANCHOLI
                                     Page 2 of 104
HC-NIC                             Page 2 of 104     Created On Sat Aug 06 03:51:36 IST 2016
                C/WPPIL/108/2016                                             CAV JUDGMENT
                                     Date : 04/08/2016
                                      CAV JUDGMENT
(PER : HONOURABLE THE CHIEF JUSTICE MR. R.SUBHASH REDDY)
1. In this group of petitions, filed under Article 226 of the Constitution of India, challenge is to the
Gujarat Ordinance No.1 of 2016, which provides for the reservation of seats in the educational
institutions in the State and of appointments and posts in the services under the State in favour of
the Economically Weaker Sections of unreserved categories.
2. As common issue is involved in this batch of petitions, we have heard all the petitions together
and dispose of the same by this common judgment. For the disposal of this group of petitions, we
have taken up Special Civil Application No. 8804 of 2016 as lead matter and referred to the facts
contained in the said petition.
3. Special Civil Application No. 8804 of 2016 is filed by two petitioners through their guardians who
have completed 10 + 2 course, aspiring to get admission in the medical stream for the prayers which
read as under:-
                          "(A)       Your Lordships may be pleased to admit and
                              allow the present petition;
(B) Your Lordships may be pleased to issue a writ of mandamus or any other writ in the nature of
mandamus, order or direction in the nature of mandamus declaring the provisions of Ordinance 1 of
2016 ultra vires the Constitution of India and invalid in law and may be pleased to restrain the
HC-NIC Page 3 of 104 Created On Sat Aug 06 03:51:36 IST 2016 respondents from enforcing the
provisions of Ordinance 1 of 2016 forthwith.
(C) Pending the admission and final hearing of the present petition, Your Lordships may be pleased
to stay operation of Ordinance 1 of 2016 forthwith and restrain the respondents from enforcing the
provisions of Ordinance of 1 of 2016.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

(D) Pending the admission and final hearing of the present petition, Your Lordships may be pleased
to restrain the respondent Nos. 4 and 5 not to enforce the reservation policy of providing 10%
reservation for economically weaker section of the society.
(E) Any other and further reliefs as deemed fit in the interest of justice may kindly be granted."
4. Before we refer to various clauses of the impugned Ordinance, which provides for the reservation
of seats in educational institutions in the State and of appointments and posts in the services under
the State in favour of the Economically Weaker Sections of unreserved categories, we deem it
appropriate to refer to certain background facts which led to issuance of the impugned Ordinance.
4.1 There was a long-standing demand from Patidar and other communities for providing
reservation in the government jobs and higher education. There was also agitation/movement as
these demands were not considered for reservation. To consider such representations demanding
reservation in higher education from social groups and communities, the government constituted a
High Power Committee of Hon'ble Ministers headed by Shri Nitin Patel as Chair-Person. The High
Power Committee prepared its report dated 25.4.2016, which is placed on record. A perusal of the
Committee's report indicates that the Committee has considered representations HC-NIC Page 4 of
104 Created On Sat Aug 06 03:51:36 IST 2016 numbering about 225 from Patidars and other
communities, castes and organizations. There was also a representation from a Trust, named Sardar
Patel Seva Trust received by the High Power Committee after it was constituted. The High Power
Committee also received other representations relating to reservations, the demands in such
representations were as under:
(a) In Gujarat, different groups involved in the agriculture and animal husbandry,
namely, Anjana Chaudhary, Koli Patidar and Patidars from South Gujarat were
incorporated as ST category and are availing all benefits of reservations, whereas
Kadva-Leua Patidar and Kachchhi Patidar communities do not get the benefit of
reservations. It is their case that though they are also involved in the agricultural
activities, they should also be included in the other backward classes.
(b) Patidars who have ceased to be a khatedar should be incorporated in Special
Backward Class (SBC), claiming 5% reservations.
(c) The posts/seats meant for open category/unreserved class should be reserved for
the unreserved class/caste.
(d) Reservation in the academic institutions and jobs be provided on the basis of
economic criteria and not on the caste criterion, there was a request to accept the
report of Rane Commission in toto and to devise a system to provide reservation
based on economic criteria.
HC-NIC Page 5 of 104 Created On Sat Aug 06 03:51:36 IST 2016Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

(e) The Patidars should be incorporated in the Other Backward Class (OBC) category and in case of
such non- inclusion, the reservation policy should be abolished completely.
(f) The Patidars have been incorporated in SEBC/OBC in Rajasthan, Maharashtra, Madhya Pradesh
and Bihar and on the same basis, such benefits should be extended in Gujarat as well.
(g) The candidates from certain categories obtaining posts/seats of general category in a
considerable number, cannot be considered as backward, the government should undertake a
survey for the purpose and such castes that are no more socially and educationally backward should
be removed from the reserved category.
(h) Provision for reservation should be absolutely on the economic criterion because a few
castes/groups from the Scheduled Tribes, Scheduled Castes and Other Backward Castes have been
taking advantage of reservation also, whereas comparatively more backward castes/groups are not
benefited.
3. Castes like Brahmin, Rajput, Soni, Vaishnav, Vanik, Bhavsar are economically very backward,
hence, these castes should be incorporated in the OBC.
(j) The benefit of reservation should be given only once and to a single individual of a family in a
generation. HC-NIC Page 6 of 104 Created On Sat Aug 06 03:51:36 IST 2016 4.2 In addition to the
demands for reservation and inclusion in OBC category etc there were also economic demands
claiming that all the benefits provided to the candidates of socially and educationally backward class
should be provided to the candidates of general category also; to create the Patidar Vikas
Commission by creating Sardar Patel Vikas Board; special budget should be allocated not less than
Rs. 500 crore; economically weaker families should be given loans/subsidies for trade and
employment from such board; free of cost training and facilities and for appearing in the
competitive examinations should be provided to economically unreserved category; candidates of
unreserved category have to pay a high amount towards fees for such examinations whereas
reserved category candidates are exempted; exemption should be given to the unreserved category
also or the standard for such fees should be uniform to all; Economic Reservation Commission
should be created for considering such issues; to constitute Higher Class Development Commission
and all the students should be given scholarship, uniforms, text books, educational loans, vehicles
for the girls for higher education and further economically weaker families should be given
loans/subsidies for trade and employment. People from unreserved category, who are not part of the
creamy layer should be provided all the benefits which are available to other backward classes,
including assistance for studying abroad. Various govt. schemes like Kunvarbai nu mameru,
scholarships etc are to be HC-NIC Page 7 of 104 Created On Sat Aug 06 03:51:36 IST 2016 awarded
on the basis of economic criterion without reference to castes or community.
4.3 There were also further demand related to educational issues demanding that students should
be given scholarships, educational loans, vehicle for girls for higher education; number of seats be
increased in the medical colleges, removal of reservation in higher training institutes and
reservation should be extended to grant-in-aid academic institutions; demands relating to removalDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

of reservation in the promotions in the services and posts and to make upper age limit uniform to all
the categories.
4.4 Considering such various types of demands for reservation relating to admissions in educational
institutions and of appointment and posts in services under the State, the Committee analyzed
various issues. As stated in the Report, while analyzing the demands which were before the
Committee, the Committee noticed that the government has already introduced Mukhyamantri
Yuva Swavlamban Yojna, which provides financial support and assistance based on the quality and
income, to the talented youth of unreserved category and under that scheme, children of the family
whose income was below Rs.4.5 lakh were given different types of assistance for primary, secondary
and higher education, and later on the government has increased the ceiling limit of annual income
up to Rs. 6 lakh to extend the benefit of the scheme. Further under the Mukhyamantri HC-NIC Page
8 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Yuva Swavlamban Yojna, the State Government
has also provided financial support to students of all castes and communities, based on their merit
and family income for higher education. The Committee noticed that such issues related to
reservation in admission in educational institutions and direct recruitment in the government jobs
still persist in spite of such benefits extended by the government by granting financial assistance to
the students. 4.5 With reference to the demands before the Committee, after analyzing the schemes
which were already in force and available for benefit of the students below ceiling limit income, the
Committee concluded that it is necessary and proper to take some definitive decision of reservation
based on income criteria. The Committee observed in its report that financial assistance alone does
not suffice for providing sufficient opportunities of education and employment to the economically
backward class youth of unreserved category. While considering the issue of demand of Patidars to
incorporate them in the Socially and Educationally Backward Class, the Committee realized that
along with the Patidars, there are many other unreserved category castes of the society whose youth
are facing difficulties in getting higher education and government jobs due to weaker financial
background of the family. The Committee found that economically weaker families of unreserved
category and socially forward class lag behind in aggregate development of their castes as they are
devoid of opportunities to higher education. The Committee HC-NIC Page 9 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 made reference to the recommendations made by Justice Rane
Commission which recommended for reservation based on economic criteria. The Committee
further found that provision for admission in primary education to the children belonging to Below
Poverty Line (BPL) families of unreserved category has been done with implementation and
enforcement of the Right to Education Act. However, the Committee found that there is no
provision of reservation in the higher education for students belonging to the economically weaker
families of unreserved category. The Committee further found that Social Welfare Department and
Tribal Development Department have been operating a number of schemes for self- employment of
youth, but such schemes are not available to the youth of economically weaker section of unreserved
category, as such, they have to rely largely upon the government jobs. The Committee found that
lack of opportunity for higher education and employment has infused disappointment in youth
belonging to unreserved category and as such, economically weaker sections of unreserved category
should be given the benefits without adversely affecting the benefits of reservation etc already given
to the Scheduled Castes, Scheduled Tribes and Socially and Economically Backward Classes. The
Committee therefore, recommended that such complex issues can be resolved only if justice is doneDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

to all the economically weaker families of different castes and communities by reserving 10% of the
seats in appointments to the government services and in educational institutions which will serve
the purpose. HC-NIC Page 10 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Thus, the Committee
made the following recommendations:-
"Recommendations of the Committee:-
Taking into consideration all these, with a view to ensure that the educational and
economic progress of the youngsters of economically weaker unreserved category is
not hampered, they get opportunity to obtain education and employment, no
injustice is done to any other community and still adhering to the policy of the
development of disadvantaged groups, and maintaining the spirit of "sau no saath,
sau no vikaas", the Committee recommends as follows:
"Economically weaker class (with the family income of Rs.6.00 lakh per annum) of
the Unreserved Category is hereby given the reservation of 10 per cent in the
appointment to the Government services and in the admission to the educational
institutions. This benefit will be given to them as per the standard of the reservation
benefit given to the Socially and Educationally Backward Class (SEBC). This means
that it will be in accordance with the present income limit of Rs. 6 lakh and the
standing-presently prevalent instructions of the Social Justice and Empowerment
Department, for the socially and economically backward class among the forward
class.""
4.6 Before referring to the various clauses of the impugned Ordinance by which the petitioners are
aggrieved, we would also like to refer to the statement annexed to the impugned Ordinance. 4.7 In
the statement annexed to the impugned Ordinance, it is stated that the State Government is
following and implementing the policy of reservation for Scheduled Castes, Scheduled Tribes and
Socially and Educationally Backward Classes in the admissions to educational institutions in the
State and in the appointments in the services and posts under the State and because of the effective
HC-NIC Page 11 of 104 Created On Sat Aug 06 03:51:36 IST 2016 implementation of the reservation
policy for such classes, a reasonable number of persons belonging to the said classes are being
benefited both socially and educationally to some extent and the existing policy of reservation for
these classes in the State to continue. At the same time, economically weaker sections of unreserved
categories of the society have expressed their inability to compete with higher strata who are
economically sound and as a result of which, such economically weaker sections feel disadvantaged
in terms of their representation in the matter of admission to educational institutions and in the
services and posts under the State. It is further stated in the statement that it is the prime duty of the
government to strive for inclusive development and address the reasonable requirement of such
Economically Weaker Sections of unreserved categories of the society so that they may also share
the fruits of the policies of the government. Thus, the government considers it necessary to provide
ten per cent reservation on the basis of economic status to economically weaker sections of the
society other than the Scheduled Castes, Scheduled Tribes and Socially and Educationally Backward
Classes for admissions in the educational institutions and for appointments in the services and postsDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

under the State.
5. We now refer to relevant clauses of the impugned Ordinance. Clauses 3 to 8 of the impugned
Ordinance read as under:
HC-NIC Page 12 of 104 Created On Sat Aug 06 03:51:36 IST 2016 "3. Reservation of
seats in educational institutions in the State.- The reservation in respect of the annual
permitted strength for admission into such educational institutions and courses in
the State, as may be prescribed, for Economically Weaker Sections, shall be ten per
cent.
4. Reservation of appointments and posts in the services under the State.-(1) The
reservation of appointments and posts in the services under the State for the
Economically Weaker Sections shall be ten per cent.
(2) Notwithstanding anything contained in sub-
section (1), such reservation shall not apply in the matters of promotion.
5. No reservation in certain cases.-
Notwithstanding anything contained in section 4, there shall be no reservation in respect of the post,
which is single (isolated) in any cadre or grade.
6. Criteria for reservation.- For the purposes of this Ordinance, reservation under sections 3 and 4
for the Economically Weaker Sections shall be as per the criteria applicable to the Socially and
Educationally Backward Classes in the State.
7. Power to make rules.- (1) The State Government may, by notification in the Official Gazette, make
rules for carrying out all or any of the purposes of this Ordinance.
(2) All rules made under this section shall be laid for not less than thirty days before the State
Legislature HC-NIC Page 13 of 104 Created On Sat Aug 06 03:51:36 IST 2016 as soon as possible
after they are made and shall be subject to the recession by the State Legislature or to such
modification as the State Legislature may make during the session in which they are so laid or the
session immediately following.
(3) Any recession or modification so made by the State Legislature shall be published in the Official
Gazette, and shall thereupon take effect.
8. Power to remove difficulties.- If any difficulty arises in giving effect to the provisions of this
Ordinance, the State Government may, by order published in the Official Gazette, make such
provisions not in consistent with the provisions of this Ordinance as may appear to be necessary for
removing the difficulty:Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

Provided that no such order shall be made after the expiry of the period of two years
from the commencement of this Ordinance."
5.1 Section 2(a) of the Ordinance defines the term "Economically Weaker Sections" to
mean all such sections of the society consisting of persons belonging to unreserved
category who meet with the criteria provided under section 6. Section 2(e) defines the
term "unreserved category" to mean that it shall include all persons not falling within
the reserved categories of Scheduled Castes, Scheduled Tribes and Socially and
Educationally Backward Classes.
6. Coming to the facts of the case, it is stated in the petition that petitioner no.1 Ms.
Dulari Mahesh Basarge passed her 12th Science HC-NIC Page 14 of 104 Created On
Sat Aug 06 03:51:36 IST 2016 Semester Examination with 93.75%. She also passed
her GCET examination and secured 99% marks out of 120. Petitioner no.2 also
completed her 12th Standard and secured 98.97 percentile marks and secured
96.87% in the GCET examination, 2016 and both of them desire to seek admission in
the medical/engineering courses. By the time the writ-petition was filed, there was no
notification by the Gujarat Admission Committee constituted by the government for
making admissions to medical courses. But the Admission Committee issued an
advertisement dated 22.5.2016 for making admissions to technical courses. The
admission procedure for the year 2016 for Bachelor of Engineering and Technological
courses is also placed on record.
6.1 To implement the reservation as mandated in the impugned Ordinance, 10% seats
are reserved for economically weaker sections of the unreserved category. Clause-6 of
the admission brochure deals with reservation of seats which reads as under:-
"6. Reservation of Seats:-
(1) For the purpose of admission, the seats shall be reserved for the candidates who
are of Gujarat origin and falling under the following categories and in following
proportion, namely:-
               (a)     Scheduled Castes                      :7%
               (b)     Scheduled Tribes                      : 15%
               (c)     Socially and Educationally Backward Classes, including
               Widows and orphan of any caste                : 27%
HC-NIC                                 Page 15 of 104      Created On Sat Aug 06 03:51:36 IST 2016
         Unreserved Economically Weaker Sections: 10%Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

         (2)     A candidate seeking admission on reserved seat shall be
required to produce a Certificate of inclusion in the concerned category, Provided
that the candidate belonging to Socially and Educationally Backward Classes shall be
required to produce a certificate to the effect of non-inclusion in Creamy Layer in
addition to the caste certificate.
(3) No caste certificate shall be valid unless it is duly stamped, signed and issued by
the authority empowered by the Government of Gujarat.
(4) No certificate to the effect of non-inclusion in Creamy Layer shall be valid, unless
it is duly stamped, signed and issued by the authority empowered by the Government
of Gujarat. Such certificate shall have been issued on or after the 1st April of the
academic year in which the candidate is seeking admission.
(5) If a candidate fails to submit the certificates as required under sub-rule (2) within
the stipulated time, his candidature shall be considered for admission under
unreserved category. (6) If a candidate of reserved category gets admission on
unreserved seat in order of merits, he may be given admission on the unreserved seat
according to his preference. (7) The admission of a candidate of a reserved category
on a reserved seat shall be valid subject to the verification of caste certificate issued to
him by the authority empowered by the State Government in this behalf. In case the
caste certificate is found to be invalid on verification, he shall not have right to claim
his admission on reserved seat and if he has already been granted admission, such
admission shall be canceled.
Admission of such candidate may be continued in case of HC-NIC Page 16 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 availability of vacant unreserved seats, subject to the condition of
eligibility of merit.
(8) After granting admission to all the candidates of reserved categories on respective reserved
seats, the reserved category seats remaining vacant shall be transferred to the unreserved category
seats."
6.2 After the issuance of the impugned Ordinance, the 1st respondent-State passed and issued
Resolution No. SSP/122016/271436/A, dated 6.5.2016. The aforesaid Government Resolution is
purportedly issued in exercise of powers under Section 8 of the Ordinance which empowers the
State Government to issue order by publishing in the Official Gazette to remove the difficulties in
giving effect to the provisions of the Ordinance. The relevant part of the aforesaid Government
Resolution dated 6.5.2016 reads as under:-
ResolutionDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

1. For the purpose of this reservation the Unreserved Economically Weaker Sections
shall be the classes / persons who are not Scheduled Castes, Scheduled Tribes and
Socially and Educationally Backward Classes and who are not the classes/persons
shown in the column-3 of the Schedule attached herewith.
2. For Unreserved Economically Weaker Sections, the certificate shall be in the
format as attached with this resolution in Appendix - A and prescribed application
form shall be in the format as attached in the Appendix - B.
3. The Competent Officers to issue the Unreserved Economically Weaker Section
certificates shall be the HC-NIC Page 17 of 104 Created On Sat Aug 06 03:51:36 IST
2016 same officers who are authorized, from time to time, to issue the non-creamy
layer certificates. To issue such certificates mainly the following officers are there:
(1) District Magistrate / Addl. District Magistrate/ Collector / Deputy Commissioner
/ Deputy Collector / Addl. Deputy Commissioner / First Class Stipendiary Magistrate
/ Sub Divisional Magistrate / Taluka Magistrate / Executive Magistrate / Addl. Asst.
Commissioner ( not below the First Class Stipendiary Magistrate) (2) Chief Presidency Magistrate /
Addl. Chief Presidency Magistrate / Presidency Magistrate (3) Revenue Officer not below the rank of
Mamlatdar (Tehsildar).
(4) Sub Divisional Officer (5) Taluka Development Officer (6) District Deputy Director (Developing
Castes) and District Social Welfare Officer (Developing Castes)
4. The procedure to issue the Unreserved Economically Weaker Sections Certificates, shall be the
same as it is prevalent in the case of non creamy layer certificates.
5. The benefit of this reservation shall be available to the Unreserved Economically Weaker Section
persons who are original natives of Gujarat State.
6. The validity period of such Economically Weaker Sections certificates shall be three years,
including the financial years in which it is issued, as in the case of non creamy layer certificates and
if there is any change in any of the parameters, it shall be the responsibility of the
guardian/student/applicant/candidate to declare voluntarily the same before the competent
authority as provided in the GR dt. 26/04/2016 as shown against sr. no. (12) as referred above.
7. When the competent authority refuses to give the Unreserved Economically Weaker Sections
certificate or when such wrong certificate is issued the appellate authorities shall be as under as
provided in the Resolution dt. 02/06/2014 as mentioned against sr. no. HC-NIC Page 18 of 104
Created On Sat Aug 06 03:51:36 IST 2016 (9) as referred above (1) If the decision is taken by the
Mamlatdar, the appellate authorities shall be Prant Officer/Deputy Collector/Assistant Collector.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

(2) If the decision is taken by the Prant Officer/ Deputy Collector/Assistant Collector, the appellate
authority shall be the District Collector.
(3) If the decision is taken by the District Collector, the appellate authorities shall be the State level
scrutiny committee.
8. The responsibility of the verification of such Unreserved Economically Weaker Sections
Certificates shall be with the state level scrutiny committee constituted vide updated Resolution dt.
26/03/2015 as mentioned against sr. no. (10) as referred above. The responsibility to get such
certificates to be verified at the stage of admissions and recruitment shall be on the concerned
agency giving educational admission/recruitment committee/commission/recruiting agency or
competent appointing authority.
9. The procedure of the verification of such Certificates shall be as it is presently in the case of the
Socially and Educationally Backward Classes certificates and non- creamy layer certificates.
10. For the removal of difficulties in issuing such certificates, arising at the local level, shall be solved
by the committee headed by the collector as provided in the resolution dt.27-4-2010 as mentioned
against sr no.(7) as referred above.
11. It shall be the responsibility of the concerned competent authority to preserve the record in this
regard.
12. This resolution and policy shall not be applicable for the reservation policy under the
Government of India.
13. Whenever and whatever changes shall be made by the State Government in respect of the policy
of non creamy layer certificates in case of the Socially and Educationally Backward Classes, the same
shall be applicable mutatis mutandis in case of the certificates of the Unreserved HC-NIC Page 19 of
104 Created On Sat Aug 06 03:51:36 IST 2016 Economically Weaker Sections also."
6.3 It is stated in the petition that there was no reservation till last year for economically weaker
sections of the unreserved category for admission to educational institutions and for employment
and posts under the State services, and by the impugned Ordinance which is arbitrary and illegal,
they are sought to be denied 10% of the available seats for the purpose of admission to educational
institutions. It is the case of the petitioners that such ordinance is violative of their fundamental
rights guaranteed under Articles 14, 15 and 16 of the Constitution and is arbitrary and runs contrary
to the constitutional scheme and structure of the Constitution. It is their case that equality
guaranteed under Article 14 is one of the basic tenets of the Constitution and the State policy and
actions for admission and employment should be within the framework of such constitutional
scheme. It is their further say that reservation provided under the impugned Ordinance is
unreasonable and runs contrary to the public interest as it results in sacrifice of merit. It is further
case of the petitioners that such benefit can be sacrificed only for the purpose of reservation as well
as for making special provision under Article 15(4) or under Article 16(4) of the Constitution forDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

advancement of Scheduled Caste and Scheduled Tribes and backward classes but not for making any
other classification on the ground of economic criteria. It is stated that as the Ordinance has
continued to retain 49% seats, that is, 7% seats for Scheduled Castes, HC-NIC Page 20 of 104
Created On Sat Aug 06 03:51:36 IST 2016 15% for Scheduled Tribes and 27% for Socially and
Educationally Backward Classes, and further 10% reservation is provided for economically weaker
sections of unreserved category for admission to educational institutions, which will come to 59%
and rest of the communities have to compete only with 41% that will result in sacrificing merit and
the same is not in larger public interest. While referring to case-law on the subject in the case of
Indra Sawhney vs. Union of India, reported in AIR 1993 SC 477 and in the case of M. Nagaraj & Ors
vs. Union of India, reported in AIR 2007 SC 71, it is stated that percentage of reservation is contrary
to the upper ceiling limit fixed by the Hon'ble Supreme Court in the aforesaid cases. It is further case
of the petitioners that as no extraordinary jurisdiction existed there as observed by the Hon'ble Apex
Court in the above judgments, compelling the government to breach the declaration of law, the
impugned Ordinance is fit to be struck down as invalid. It is their say that income cannot be the
criteria to constitute a class for providing reservation to economically weaker section of unreserved
category and the same is a fraud on the Constitution and blatantly violating the rights of the citizens
guaranteed under Article 14 of the Constitution. It is also the say of the petitioners that in the
absence of any empirical data and material, the Committee considered the representations and
recommended for reservation and such recommendations made are readily accepted by the
government which resulted in issuance of the impugned Ordinance. In the absence of any
quantifiable data and empirical study, no such HC-NIC Page 21 of 104 Created On Sat Aug 06
03:51:36 IST 2016 Ordinance can be issued particularly by Statute for the purpose of effecting
reservation in educational institutions and of appointment and posts under the State for the persons
belonging to economically weaker sections of unreserved category.
6.4 It is also the say of the petitioners that the State Government has issued resolutions on 7th
October, 2015 and 5th April, 2016, granting benefit to the children whose parents' income is to the
extent of Rs. 4,50,000/- for the purpose of payment of fees etc and without waiting to see the effect,
has already issued the impugned Ordinance in the absence of any acceptable material on record. On
the aforesaid grounds, the declaration is sought to set aside the impugned ordinance by declaring
the same as ultra vires the Constitution of India and to restrain the respondent no.1-State from
enforcing the provisions of the impugned Ordinance No.1 of 2016.
7. Additional Secretary, Social Justice and Empowerment Department has filed affidavit in reply on
behalf of respondent no.1- State. In the affidavit in reply, reference is made to the constitutional
provision under Articles 14, 15, 16 and Articles 38, 39 and 46 of the Constitution of India which are
extracted in the affidavit. While denying various allegations made by the petitioner in the petition, it
is stated that it was around June-July, 2015 that various weaker sections of society not belonging to
reserved categories of Scheduled Castes, Scheduled Tribes and Socially and Educationally Backward
HC-NIC Page 22 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Classes, expressed a feeling that
they were subjected to discrimination in comparison with the higher strata of people who are
economically sound, and about the resultant inability to compete with them in the matters of
admissions in educational institutions and in the services and posts under the State. There was
series of representations given to the State Government for doing something for the benefit of suchDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

economically weaker sections. In view of such representations, the State Government appointed a
High Level Committee consisting of 5 Hon'ble Ministers by Government Resolution dated
13.8.2015. The said High Level Committee considered such representations and orally heard various
parties for providing level playing field in the matter of admission and employment. As a result of
such consideration, to redress their grievances, the State Government issued Government
Resolution dated 7.10.2015, formulating a policy by providing financial aid to the meritorious and
needy students on merit-cum-means basis and such benefits flowing from the said policy are made
admissible to all the candidates irrespective of categories. Such policy formulated by Government
Resolution dated 7.10.2015 was exclusively dealing with the grant of financial assistance in the
matter of admission and was restricted exclusively for meritorious students. The same was followed
by another Government Resolution dated 5.4.2016 enlarging the scope of earlier resolutions so as to
cover the Diploma students who are aspiring to get admission to recognized degree courses. It is
stated that in spite of such steps taken by the government by issuing HC-NIC Page 23 of 104 Created
On Sat Aug 06 03:51:36 IST 2016 Government Resolutions dated 7.10.2015 and 5.4.2016, still
general feeling of dissatisfaction was prevailing in the State amongst the economically weaker
sections of the society. In this regard, the government received plethora of representations and on
considering such representations, to redress their grievances, the State Government appointed High
Power Committee consisting of 5 Hon'ble Ministers under the Chairmanship of Shri Nitin Patel, the
Hon'ble Minister for Health and Family Welfare, on 11.3.2016 considered 225 representations,
wherein, social, caste and community groups had narrated their plights about discrimination and
difficulties being faced by them while seeking admission in educational institutions and of
appointments and posts in the services under the State. Reference is made to the issues which were
there before the Committee for consideration. The committee recommended reservation of 10% in
the government services and for admission in educational institutions for Economically Weaker
Class ( with family income of Rs.6 lakh per annum).
7.1 It is stated in the affidavit in reply that the aforesaid report was placed before the State
Government at highest level on 25.4.2016 and further debate about the issue took place in the
Cabinet meeting held on 29.4.2016.The Cabinet, after discussion and deliberations on various issues
threadbare resolved to request His Excellency the Governor of Gujarat for promulgation of
Ordinance for earmarking a classification to the extent of 10% for unreserved category so as to
HC-NIC Page 24 of 104 Created On Sat Aug 06 03:51:36 IST 2016 provide a level playing field to the
weaker sections of unreserved categories without disturbing the reservation provided under Articles
15 and 16 of the Constitution of India. It is further stated in the affidavit in reply that the entire file
was thereafter sent to His Excellency the Governor of Gujarat on 1.5.2016 as the Legislative
Assembly was not in session. His Excellency the Governor of Gujarat, in exercise of power conferred
under clause (1) of Article 213 of the Constitution, on being satisfied, promulgated the Ordinance.
Thereafter, various steps were taken to implement the provisions of the Ordinance.
7.2 It appears that thereafter the Social Justice and Empowerment Department issued a
Government Resolution dated 6.5.2016, inter alia, formulating guidelines for implementation of the
Ordinance. It is stated in the said Government Resolution that categories have been formulated for
issuing the certificates in favour of unreserved Economically Weaker Sections. Reference is made to
Circular instructions dated 7.5.2016 which also provided for parameters governing recruitment ofDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

unreserved Weaker Sections by virtue of the provisions of the Ordinance. Further reference is also
made to Circular instructions dated 7.5.2016, 12.5.2016, 17.5.2016 and 18.5.2016.
7.3 Referring to various technical professional courses in the faculty of Degree Engineering/Diploma
Engineering and Certificate to HC-NIC Page 25 of 104 Created On Sat Aug 06 03:51:36 IST 2016
Diploma Engineering, it was stated that admission process had already begun and in the
hengineering degree courses total seats were to the tune of 70,799 and in response thereto, 47,897
candidates had registered and after scrutiny, 46,941 candidates were qualified for admission and the
merit list of 8643 candidates belonging to unreserved Economically Weaker Sections was prepared.
7.4 In response to the main contention raised by the petitioners in the petition, it is stated in the
affidavit in reply that earmarking of 10% of seats for economically weaker class in the matter of
admission and appointments is stricto sensu not 'reservation', but a further classification in
General/Open/Unreserved category of citizens of the State. While denying the allegations made by
the petitioner by which challenge is made to the impugned Ordinance, it is stated that the State is
enjoined to reach out to more deserving people and the task of finding out the most deserving must
necessarily be a matter of continuous evolution. It is stated that the constitutional reservation
available to various categories, flowing from Articles 15 and 16 is not affected in any manner by the
Ordinance and the Ordinance is meant only and only for unreserved category covering all the
persons not falling within the reserved categories of SC, ST and SEBC. While denying the allegation
of the petitioners that by the impugned Ordinance, the object of reservation under Article 16(4) of
the Constitution is defeated, reference is made to the provision under HC-NIC Page 26 of 104
Created On Sat Aug 06 03:51:36 IST 2016 Article 46 which deals with the directive principles of the
State Policy which provides that the State shall promote with special care, the educational and
economic interest of the weaker sections of people. It is stated in the affidavit in reply that the
impugned Ordinance which provides for a reasonable classification with reference to
General/Open/Unreserved category is permissible under Article 14 read with Article 46 of the
Constitution of India. While making reference to the Resolution dated 1.1.1995 and the Resolution
dated 6.5.2016 issued by the government read with the Schedule appended thereto, it is pleaded that
to give benefit of Ordinance, there are five other parameters wherein sons and daughters of various
functionaries of different categories would not be entitled to the benefit of the impugned Ordinance,
even though their income may be less than Rs. 6 lakh per annum. The respondent no.1 has denied
the allegation of the petitioners that income criteria alone is taken into consideration for issuance of
the impugned Ordinance. 7.5 In response to the allegations of the petitioner that by issuance of the
impugned Ordinance, reservations are exceeded beyond 50% and the same is contrary to the ratio
laid down by the Hon'ble Supreme Court in the case of Indra Sawhney (supra). It is stated that 50%
ceiling limit mentioned in the judgment of the Hon'ble Supreme Court, applies only to the
reservation of SC, ST and SEBC. It is stated that such ratio of 50% ceiling was first laid down by the
Hon'ble Supreme Court in the case of Balaji vs. State of Mysore, reported HC-NIC Page 27 of 104
Created On Sat Aug 06 03:51:36 IST 2016 in AIR 1963 SC 649. It is further pleaded that the
Ordinance in question provides for only classification/categorization amongst the open category to
the extent of 10%, and as such, the same cannot be construed as reservation as provided under
Articles 15(4) and 16(4) of the Constitution which is made for SC, ST, SEBC and other backward
classes. Further it is also stated that the Ordinance in question containing the said classification toDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

the extent of 10% is relatable to Article 46 of the Constitution and the same is not with reference to
backward class quota.
7.6 While reiterating their stand, it is stated that the impugned Ordinance is issued without affecting
the reservation which has already provided for SC,ST and SEBC categories, therefore, it is pleaded
that there are no merits in the petition prayed to dismiss the petition.
8. Affidavit in reply is filed on behalf of the impleaded respondent no.5. While justifying the
issuance of Ordinance in question by the State, the 5th respondent has denied various allegations
made by the petitioners and has pleaded that legislature of the State of Gujarat is fully competent
and empowered under the Constitution to promulgate the Ordinance which is under challenge. The
5th respondent has taken a stand that the term 'reservation' as mentioned in the Ordinance is not
reservation under Article 16(4) of the Constitution and is to be read down to be a reasonable
HC-NIC Page 28 of 104 Created On Sat Aug 06 03:51:36 IST 2016 classification made under Article
14 of the Constitution. It is stated that while making reasonable classification, the State of Gujarat
has protected reserved categories under Article 16(4) of the Constitution and has not disturbed their
rights in any manner guaranteed under the Constitution. While making reference to the
recommendations of the High Power Committee which is referred to in the affidavit in reply filed on
behalf of the respondent no.1-State, it is stated that from such recommendations of the Committee,
it is clear that only with a view to ensure that educational and economic progress of the
economically weaker sections of unreserved category is not hampered, to provide opportunity for
admission and employment to the weaker sections of unreserved category, reasonable classification
is made by providing 10% of seats for them. The 5th respondent has made reference to the
judgments on the subject-matter rendered by the Hon'ble Supreme Court and has prayed for
dismissal of the petitions.
9. After the affidavit in reply is filed on behalf of the respondent no.1-State, there is rejoinder filed
by the petitioners. Responding to the averments made in the affidavit in reply filed on behalf of the
respondent no.1-State, in rejoinder, the petitioners have denied that any representations were made
on behalf of the weaker sections of society alleging that they were subjected to discrimination in
comparison with the higher strata of people who are economically sound. It is stated that there is
continuous agitation on behalf of HC-NIC Page 29 of 104 Created On Sat Aug 06 03:51:36 IST 2016
Patidar community seeking reservation and no other group has made any application to the State
Government or representation for seeking benefits as alleged and the agitation on behalf of the
SEBC class was to protect their reservation. It is stated that the impugned Ordinance which
provided for reservation of 10% to the unreserved category leading to classification amongst the
socially and educationally advanced class is in breach and spirit of constitutional provision under
Article 14 of the Constitution. While referring to the averments made in the affidavit in reply about
the number of seats available in technical courses, it is stated that as the demand is less than
available seats and there is no reason for providing reservation to such courses, as such, that itself
shows non-application of mind for issuance of the impugned Ordinance and its applicability to
technology courses. While referring to the provisions under Article 46 of the Constitution, it is
pleaded that economically weaker sections do not constitute homogeneous class for the purpose of
effecting reservation. As there is no certain likeness or common strait who are identified by someDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

common attribute such as status, rank, occupation, residence in the locality, race, religion and like,
they cannot be construed as class for the purpose of effecting reservation. While reiterating their
stand that income criteria cannot be the basis for classification as it consists of heterogeneous
individual, it is pleaded that the same also cannot be treated as a source for making admissions to
the educational institutions.
HC-NIC Page 30 of 104 Created On Sat Aug 06 03:51:36 IST 2016
10. Further affidavit in sur rejoinder to the affidavit of rejoinder filed by the petitioners is filed on
behalf of the respondent no.1-State. In such affidavit, the 1st respondent has denied the allegation of
the petitioners that there are no other representations as 225 individual representations made on
behalf of the various communities and castes. It is pleaded that such representations were from
various castes, communities and groups etc. covering a very fulcrum of citizens of the State,
consisting of the entire unreserved category including entire Brahmin Samaj, Rajputs, Kansara
Samaj, Brahmkshtriya, Lohana, Vaishnav Vanik, Brahm Samaj, Samasta Patidar Samaj, Agrawal
Samaj, Bhanushalis, Anavils, forward Muslim groups etc. It is stated that such 225 representations
were sent and presented through the office bearers of the said communities and groups on behalf of
their entire communities. In response to the allegation of the petitioners that High Power
Committee has made its recommendations without any empirical study, it is stated that having
regard to representations which were made to the Committee, the Committee has fully considered
various aspects and material including the recommendations of Justice Rane Commission
appointed in the year 1981. It is further pleaded that such empirical study is required when one
needs to determine the Socially and Educationally Backward Classes and Other Backward Classes
and as much as the impugned order is issued only for classification, no empirical study is required.
While denying the averment in the counter that classified group in the impugned Ordinance cannot
be HC-NIC Page 31 of 104 Created On Sat Aug 06 03:51:36 IST 2016 construed as homogeneous
group, it is stated that mere use of the word 'reservation' in the impugned Ordinance per se does not
and cannot have the consequence of ipso facto applying the entire mechanism underlying the
constitutional concept of protective reservation designed for the advancement of any Socially and
Educationally Backward Classes of citizens or other backward classes of citizens. By reiterating their
stand, it is prayed for dismissal of petitions.
11. Heard Mr. S.N.Shelat, learned Sr. Advocate appearing with Ms. V.D. Nanavati and Mr. Shalin M.
Mehta, Mr. B.T. Rao, Mr. I.H.Syed and other learned counsel on record for the petitioners in the
respective petitions and Mr. Kamal B.Trivedi, learned Advocate General with Mr. P.K. Jani, learned
Additional Advocate General with Ms M.L. Shah, learned Government Pleader with Ms S.K.Vishen,
learned Assistant Government Pleader for respondent no.1 State of Gujarat, Mr.Mihir Thakore,
learned Sr. Advocate appearing with Ms Amrita Thakore, learned counsel for respondent nos. 6 to 9
in respective petitions and Mr. Amit Panchal with Ms Shivani Rajpurohit, learned counsel appearing
on behalf of respondent no.5 and as intervener in the respective petitions.
12. Mr. S.N.Shelat, learned Sr.Advocate, appearing for the petitioners in Special Civil Application
No. 8804 of 2016 has taken us through various clauses in the impugned Ordinance and other
HC-NIC Page 32 of 104 Created On Sat Aug 06 03:51:36 IST 2016 material on record and submitsDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

that impugned Ordinance providing for reservation of 10% of seats in educational institutions in the
State and of appointments and posts in the services under the State in favour of the Economically
Weaker Sections of unreserved category, violates the equality clause under Article 14 of the
Constitution; no classification can be made based on income criteria for the purpose of admission
into educational institutions and for employment and such classification offends Article 14 of the
Constitution; while effecting such reservation, the State has overlooked the merit criteria for
admissions into various important educational courses and for the purpose of employment in the
services under the State Government; economically weaker section of society as contemplated under
the impugned Ordinance No. 1 of 2016 does not constitute either a class or source for the purpose of
effecting reservation. According to the learned Senior Advocate, in the absence of any extraordinary
situation, the State has exceeded the maximum cap of 50% of reservation and thus, the impugned
Ordinance is contrary to the authoritative judgments of the Hon'ble Supreme Court and the other
judgments of this Court.
12.1 Learned Senior Advocate, in support of his arguments has placed reliance on the following
judgments:-
(1) Janki Prasad Parimoo and others v. State of Jammu & Kashmir and others,
reported in AIR 1973 SC 930 (2) Indra Sawhney etc.etc. v. Union of India and others,
etc. HC-NIC Page 33 of 104 Created On Sat Aug 06 03:51:36 IST 2016 etc., reported
in AIR 1993 SC 477 (3) Division Bench judgment of this Court rendered in Letters
Patent Appeal Nos. 698 and 699 of 1994 (4) Judgment of this Court in the case of
Asha D. Bhatt v.
Director of Primary Education and Anr., reported in 2003 (4) GLR 3991 (5) Minor A. Periakaruppan
& another v. State of Tamil Nadu and others, reported in AIR 1971 SC 2303 (6) Govt. of A.P. v. P.B.
Vijaykumar and another, reported in AIR 1995 SC 1648 (7) Post-Graduate Institute of Medical
Education and Research, Chandigarh v. Faculty Association and others, reported in AIR 1998 SC
1767 (8) Dr.Preeti Srivastava and another v State of Madhya Pradesh and others, reported in AIR
1999 SC 2894 (9) A.I.I.M.S. Students Union v. A.I.I.M.S. and others, reported in AIR 2001 SC 3262
(10) N.T.R. University of Health Sciences, Vijayawada v. G. Babu Rajendra Prasad and another,
reported in AIR 2003 SC 1947 (11) M. Nagraj & Ors v. Union of India & Ors, reported in AIR 2007
SC 71 (12) Ram Singh v. Union of India, reported in 2015 (4) SCC 697 (13) Union of India v.
Elphinstone Spinning and Weaving Co.
Ltd. and others, reported in AIR 2001 724 HC-NIC Page 34 of 104 Created On Sat Aug 06 03:51:36
IST 2016 (14) Kailash Chand Sharma, etc.etc. v. State of Rajasthan and others, reported in AIR 2002
SC 2877 (15) Karamsad Medical Association v. State of Gujarat, reported in 2000 (2) GLR 1648 (16)
State of Madhya Pradesh and others v. Gopal D.Tirthani and others, reported in AIR 2003 SC 2952
13. Mr. Shalin Mehta, learned Sr. Advocate, appearing with Mr Hemang M. Shah, learned counsel
for the petitioner in Special Civil Application No.9740 of 2016 submits that reservation based on
income criteria is already disapproved by the authoritative pronouncement of the Supreme Court in
the case of Indra Sawhney v. Union of India, reported in 1992 Suppl. 3 SCC 217. Reservation of 10%Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

seats in the educational institutions and of appointments and posts in the services under the State in
favour of economically weaker sections of unreserved category provided in the impugned Ordinance
violates the basic tenets of the constitutional scheme under Article 14 of the Constitution of India.
According to the learned counsel, a class which is sought to be created on the ground of economic
criteria cannot constitute homogeneous class at all for the purpose of reservation. In any event, the
reservation to the extent of 10% exceeds 50% of reservation cap determined by the Hon'ble Supreme
Court in the judgment in the case of Indra Sawhney (supra) and other cases and in the absence of
any extraordinary circumstances indicated in the impugned Ordinance, the impugned HC-NIC Page
35 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Ordinance is illegal and arbitrary and is fit to be
struck down as the same runs contrary to the judgment of the Hon'ble Supreme Court. It is further
contended by Mr. Mehta that neither the Parliament nor the State Legislature can make any law that
runs counter to the law declared by the Hon'ble Supreme Court. The impugned Ordinance is
contrary to the judgment declared by the Hon'ble Supreme Court in the case of Indra Sawhney
(supra) and others. The reservation which is sought to be provided is not covered either under
Articles 15 and 16 or under Article 46 of the Constitution of India. It is submitted that such
reservation offends Articles 14, 15 and 16 of the Constitution of India. The economically weaker
sections of unreserved category are heterogeneous and therefore, such reservation is illegal and
arbitrary. In support of his argument that Article 46 will not confer any right on the State to make
reservation to economically weaker sections of unreserved category, Mr. Mehta placed reliance on
the case of State of Madras v. Sm. Champakam Dorairajan, reported in AIR 1951 SC 226. In any
event, if there is any clash between the fundamental rights and directive principles, the fundamental
rights guaranteed to the citizens under Articles 14, 15 and 16 cannot be emasculated. It is also
pleaded that there cannot be any presumption of constitutionality in favour of the
Ordinance/Legislation when such legislation or Ordinance is ex facie contrary to fundamental rights
guaranteed to the citizens under Article 14 of the Constitution of India. There was absolutely no
scientific data collected by the State before effecting the reservation by way of Ordinance to the
HC-NIC Page 36 of 104 Created On Sat Aug 06 03:51:36 IST 2016 economically weaker sections of
unreserved category. Learned counsel, in support of his arguments placed reliance on the judgment
of the Hon'ble Supreme Court in the case of AIIMS Students' Union vs. AIIMS reported in (2002) 1
SCC 428 and in the case of Atyant Pichhara Barg Chhatra Sangh and Anr. v. Jharkhand State
Vaishya Federation and Ors. reported in (2006) 6 SCC 718. Learned counsel further submits that
the impugned Ordinance is issued as a knee jack reaction to the agitation of Patidars and the same is
also evident from the statement of objects and reasons for issuing the impugned Ordinance.
14. Mr. B.T. Rao, learned counsel appearing for the petitioners in Special Civil Application No. 8655
of 2016 has taken us through the report of the High Power Committee pursuant to which the
impugned Ordinance is issued. It is submitted that there is no scientific data collected before
issuance of Ordinance and only in view of the agitation of Patidar section of citizens, the impugned
Ordinance is issued.
15. Mr. I.H. Syed, learned counsel appearing for the petitioner in Special Civil Application No. 108 of
2016 submits that the impugned Ordinance is politically motivated and is not referable to any of the
provisions under the constitutional scheme. Learned counsel has placed reliance on the judgment of
the Hon'ble Supreme Court in the case of Indra Sawhney v. Union of India and others, reported inDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

HC-NIC Page 37 of 104 Created On Sat Aug 06 03:51:36 IST 2016 (2000) 1 SCC 168.
16. Before making submissions, Mr. Kamal B Trivedi, learned Advocate General, pointed out the
following facts leading to passing of the impugned Ordinance.
16.1 In June-July 2015, various weaker sections of society not belonging to reserved categories of SC,
ST and SEBC, expressed a feeling about they being subjected to discrimination in comparison with
higher strata of people who are economically sound and resultant inability to compete with them in
the matter of admission in educational institutions and in the services and posts under the State.
Following this, the State Government appointed a High Level Committee consisting of 7 Ministers
vide G.R. dated 13.08.2015. The said Committee, after considering the grievance, made
recommendations.
16.2 Pursuant to such recommendations, the government issued Government Resolution dated
07.10.2015, whereby general policy was formulated, inter alia, providing for financial aid to the
meritorious and needy students on merit-cum-means basis. The benefits flowing from the said
policy are made admissible to all the students irrespective of categories. On 05.04.2016, the
government issued another Government Resolution, enlarging the scope of the earlier Government
Resolution dated 07.10.2015 so as to cover the HC-NIC Page 38 of 104 Created On Sat Aug 06
03:51:36 IST 2016 Diploma Students, who are aspiring to get admission in the recognized degree
courses. Despite having taken the aforesaid measures, there was still a general feeling of
dissatisfaction amongst the economically weaker sections of the society that the policy contained in
both the aforesaid Resolutions needs further strengthening by expanding its scope and purview. 16.3
On 11.03.2016, a High Power Committee was constituted consisting of five Hon'ble Ministers. The
said Committee considered number of representations and ultimately made certain
recommendations.
16.4 Report of the aforesaid Committee was placed before the Cabinet which was held on
29.04.2016 and after considering and after due deliberations with respect to various aspects
including the element of unemployment, economic criteria, etc., request was made to His Excellency
Governor for promulgation of Ordinance. 16.5 On 01.05.2016, the impugned Ordinance was
promulgated in exercise of powers conferred by Clause (1) of Article 213 of the Constitution of India.
16.6 Criteria for making the benefits available to the economically weaker sections are to be as per
the criteria applicable to SEBC in the State. Criteria for SEBC is prescribed vide G.R. dated
01.11.1995. HC-NIC Page 39 of 104 Created On Sat Aug 06 03:51:36 IST 2016 16.7 It appears that
after issuance of the Ordinance, various steps have been taken by the State Government towards the
implementation of the provisions of the ordinance.
17. Per contra to the arguments of the petitioners, learned Advocate General Mr. Kamal B Trivedi,
appearing with Ms. SK Vishen, learned Assistant Government Pleader with Mr.P.K. Jani, learned
Additional Advocate General with Ms ML Shah, learned Government Pleader, appearing for the
respondent no.1-State of Gujarat has taken us to the entire various clauses in the Ordinance and
detailed affidavit in reply filed and also other material placed on record. Learned Advocate GeneralDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

submitted that provision as regards earmarking 10% of economically weaker class in the matters of
admissions and appointments is stricto sensu not 'reservation' but a further classification in the
general/unreserved category of the citizens of the State.
18. He submits that the impugned Ordinance issued is only a classification for the purpose of
promoting the interest of the economically weaker sections of unreserved category in education and
services. It is submitted that such classification made in the impugned Ordinance is totally outside
the scope of reservations provided under Articles 15 and 16 of the Constitution of India. By making
distinction with the reservation provided under Articles 15 HC-NIC Page 40 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 and 16 of the Constitution of India, it is submitted that such reservations
are class centric and the classification which is made under the provisions is not based on such
castes and communities, but the same is issued only with a view to promote the economically
weaker sections of unreserved category as it was found that they are not able to compete with the
economically rich in the field of education and employment. By making such classification, reserved
category is not at all affected and the classification applies only to the area which is not covered by
earlier reservation made under Articles 15 and 16 of the Constitution of India.
18.1 It is the contention of the learned Advocate General that the Ordinance in question is issued to
translate the constitutional philosophy provided under the directive principles of the State Policy as
laid down under Articles 38, 39(b) and 46 of the Constitution of India, which inter alia mandates the
State to effect economic empowerment of the weaker sections of the society. Such Ordinance
satisfies the twin test of Article 14, viz. it is based on intelligible differentia, and it has nexus with the
object sought to be achieved as discernible from the Ordinance that it promotes economically
weaker sections belonging to unreserved category of citizens in the matters of admissions and
appointments. The judgment in the case of Indra Sawhney (supra) is with reference to the situation
prevailing at the time of submission of the Mandal Commission's Report on 31.12.1980 which has
recognized as many as 3743 castes as socially and HC-NIC Page 41 of 104 Created On Sat Aug 06
03:51:36 IST 2016 educationally backward classes and in that context, the judgment was rendered
on 16.11.1992.
18.2 It is further submission of the learned Advocate General that a period of 36 years since the
submission of the Mandal Commission Report and 24 years since the rendition of the judgment of
the Apex Court in the said case, has passed by and even as per the said report, the same was to be
reviewed after 20 years. Therefore, time has come for adopting new practices, methods and
yardsticks by moving away from caste-centric definition of backward class as observed by the Apx
Court in the case of Ram, Singh v. Union of India, reported in (2015) 4 SCC 697. In any event, as the
judgment in the case of Indra Sawhney (supra) was only with reference to backward classes as
referred in Article 16(4) of the Constitution, as such, now having regard to lapse of time and as it
was found that economically weaker sections of the society are not able to get their due share in
admissions and appointments, impugned Ordinance is issued by making reasonable classification
which does not offend equality clause of Article 14 of the Constitution of India and the same is also
in conformity with Articles 38, 39(b) and 46 of the Constitution.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

19. Over and above the above submissions, the learned Advocate General made the following
submissions:
19.1 Constitutional reservation available to various reserved HC-NIC Page 42 of 104
Created On Sat Aug 06 03:51:36 IST 2016 categories flowing from Articles 15 and 16
is not affected in any manner by the impugned Ordinance and the impugned
Ordinance is meant only and only for unreserved category covering all persons not
falling within the reserved categories of SC, ST and SEBC.
19.2 Similarly, no question arises with regard to the alleged violation of Article 14 of
the Constitution because reasonable classification in the open/unreserved category of
citizens is always permissible, when there is a rationale behind the said classification
to the extent of 10%, which has nexus to the object sought to be achieved. Learned
Advocate General referred the comparative chart of Article 15 and Article 16 of the
Constitution of India.
19.3 It is submitted that Article 46 of the Constitution of India deals with directive
principles of State policy and provides that the State shall promote with special care,
the educational and economic interest of the people from weaker sections. A concept
of 'weaker section' in Article 46 has no limitation, inasmuch as the individuals
belonging to the weaker sections may not form a class and they may be weaker as
individuals only. In this regard, the learned Advocate General referred to relevant
paragraphs of the decision of the Apex Court in the case of Indra Sawhney (supra)
19.4 Provision of the Ordinance providing for reasonable classification with reference
to the general/unreserved category of HC-NIC Page 43 of 104 Created On Sat Aug 06
03:51:36 IST 2016 citizens is permissible under Article 14 read with Article 46 of the
Constitution of India. Learned Advocate General also referred to Article 38 and
Article 39(b) of the Constitution of India in this regard.
19.5 Even assuming that the Ordinance in question is relatable to Article 16(1) of the
Constitution, then in that case also the classification to the extent of 10% in the
general/unreserved category of citizens of the State in the matters of admissions and
appointments cannot be said to be based on economic criteria alone and therefore
such a classification would be a reasonable classification under Article 16(1) of the
Constitution of India.
19.6 Ordinance in question provides for classification/categorization amongst the
open category to the extent of 10%, which is not 'reservation' as provided under
Articles 15(4) and 16(4) of the Constitution of India, meant for SC, ST, SEBC and
other backward classes. The said classification to the extent of 10% is relatable to
Article 46 of the Constitution. Thus, so far as the contention regarding
non-permissibility of crossing 50% ceiling is concerned, even in case of 'backward
classes' under Article 16(4) of the Constitution, the reservation can exceed the said
ceiling of 50% if the facts and circumstances of the case so warrant. In support of hisDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

submission, the learned Advocate General referred to the case of Indra Sawhney
(supra).
HC-NIC Page 44 of 104 Created On Sat Aug 06 03:51:36 IST 2016 19.7 In the present case, the
Ordinance in question does not deal with the reservation provided under Articles 15(4) or 16(4) of
the Constitution, whereas rule of 50% ceiling is confined to reservations made under the said
Articles.
19.8 By the impugned Ordinance, reservation for various categories like SC, ST and SEBC has not
been touched and therefore the said Ordinance does not seek to enhance the percentage of backward
classes contemplated under Article 16(4) of the Constitution. Thus, earmarking of 10% reservation
referred to in the Ordinance cannot be said to be in addition to 49% reservation in respect of SC, ST
and SEBC.
19.9 225 representations were received from various institutions/communities, groups, etc. covering
a very large fulcrum of citizens of the State consisting of the entire unreserved categories, several
castes and communities including entire Brahmin Samaj, Rajputs, Kansara Samaj, Brahmkshtriya,
Lohana, Vaishnav Vanik, Smasta Patidar Samaj, Agrawal Samaj, etc. Such representations were in
fact representative in nature on behalf of entire community members. Therefore, these
representations were in effect, the representations on behalf of lakhs of people.
19.10 Empirical study referred to by the petitioners is required when one needs to determine
'Socially and Educationally Backward HC-NIC Page 45 of 104 Created On Sat Aug 06 03:51:36 IST
2016 Classes'. When the classification flowing from the Ordinance translating the constitutional
philosophy flowing from various provisions of the directive principles of State policy is not related to
the 'reservation' as contemplated under Articles 15 and 16 of the Constitution and when there is no
determination of any SEBC or other backward classes, the question does not arise for any empirical
study. Learned Advocate General referred to pages 2, 24, 26, 27, 56, 58, 70, 72, 88 and 92 of the
Report of Justice Rane Commission in this regard. Learned Advocate General relied upon the
decision rendered by the Hon'ble Supreme Court in the case of K.G.Vasantha Kumar & Anr. v. State
of Karnataka, reported in 1985 (supp) SCC 714, more particularly para 2, 24 to 31, 79, 80, 82 and 84.
19.11 Earmarking/classification of 10% in favour of economically weaker sections belonging to
unreserved category of citizens in the matters of admissions and appointments under the Ordinance
in question is not a 'vertical reservation' as contemplated under Article 16(4) of the Constitution
since it does not deal with SC, ST, SEBC or other backward classes. It is also not a 'horizontal
reservation' under Article 16(1) since it does not cut across the 'vertical reservation' as it happens in
case of other 'horizontal reservations' like reservation in cases of physically handicapped persons,
women, army personnel, project affected families, etc. 19.12 Identification of backward class of
citizens requires the HC-NIC Page 46 of 104 Created On Sat Aug 06 03:51:36 IST 2016 conduct of
empirical study as was done by Mandal Commission. However, such detailed empirical study is not
required in the matter of effecting classification under Article 14 of the Constitution which needs to
satisfy only twin test being based on intelligible differentia and having reasonable nexus with the
object of the Ordinance, to be achieved.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

19.13 What is necessary for reasonable classification under Article 14 of the Constitution is that there
must be a nexus between the basis of classification and the object of the Act under consideration. In
the present case, promotion of interest of economically weaker sections belonging to unreserved
category of citizens in the matter of admissions and appointments is the objective of the impugned
Ordinance which is required to be achieved. 19.14 Mere use of the word 'reservation', per se, does
not have the consequence of ipso facto applying the entire mechanism underlying the Constitutional
concept of a protective reservation. 19.15 The rule of ceiling of 50% applies only to reservation in
favour of backward classes made under Article 16(4) of the Constitution. In the present case,
earmarking/classification to the extent of 10% in favour of economically weaker sections belonging
to unreserved category of citizens is not falling under the purview of Articles 15(4) or 16(4) of the
Constitution. Hence, the same is not in HC-NIC Page 47 of 104 Created On Sat Aug 06 03:51:36 IST
2016 addition to the reservation to the extent of 27% in favour of SEBC or in addition to 7% and 15%
in favour of SC and ST respectively. 19.16 Homogeneity of the class of citizens is inevitable for
determining Social and Educational Backwardness as refereed to under Article 15(4) where the
words 'Class of Citizen' immediately following the expression 'Socially and Educationally' are used.
However, this test of homogeneous class is not applicable in the matter of classification under
Article 14 of larger category of citizens belonging to unreserved category in contradiction with the
citizens belonging to reserved category of SC, ST, SEBC or other backward classes.
19.17 In support of his arguments, the learned Advocate General has placed reliance upon the
following decisions:
1. I.R.Coelho v. State of Tamil Nadu, reported in (2007) 2 SCC 1
2. K.C. Vasanth Kumar v. State of Karnataka, reported in (1985) (Supp.) SCC 714.
3. Kedar Nath Bajoria v. State of West Bengal, reported in AIR 1953 SC 404
4. Mohd. Hanif Quaresh & Ors. v. State of Bihar, reported in AIR 1958 SC 731.
5. Kum. Chitra Ghosh v. Union of India, reported in (1969) 2 SCC 228
6. D.N. Chandhala v. State of Mysore, reported in (1971) 2 SCC HC-NIC Page 48 of
104 Created On Sat Aug 06 03:51:36 IST 2016
7. S.S. Bedi v. Union of India, reported in (1981) 4 SCC 676
8. Indra Sawhney v. Union of India, reported in (1992) (Supp) 3 SCC 271
9. K. Duraisamy v. State of Tamil Nadu, reported in (2001) 2 SCC 538
10. Union of India v. National Federation of the Blind, reported in (2013) 10 SCC 772
11. National Legal Services Authority v. Union of India, reported in (2014) 5 SCC 438Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

12. Ram Singh v. Union of India, reported in (2015) 4 SCC
13. Rajeev Kumar Gupta v. Union of India, reported in (2016) SCC Online SC 651
14. State of Punjab v. Rafiq Mashi, reported in (2015) 4 SCC
15. Laxmi Devi v. State of Bihar, reported in (2015) 10 SCC 19.18 Learned Advocate
General further submitted that the judgments relied on by the learned counsel for the
petitioners are not only factually distinguishable, but most of them are with reference
to protective reservation contemplated under Article 15(4) and/or Articles 16(4) of
the Constitution of India and hence, would not render any support to the case of the
petitioner. It is therefore, prayed for HC-NIC Page 49 of 104 Created On Sat Aug 06
03:51:36 IST 2016 dismissal of these petitions.
20. Mr. Mihir Thakore, learned Sr. Advocate assisted by Ms Amrita Thakore, learned
counsel for respondent nos. 6 to 9 in Special Civil Application No.8655 of 2016 would
contend that as per the constitutional scheme, Articles 15(4), 16(4),(4A) and 4(B) of
the Constitution of India alone provide for reservation and the reservation and the
impugned ordinance providing 10% reservation for the purpose of admission in
educational institutions, in the services and in the employment, are only
classification traceable to power under Article 14 read with Article 16 of the
Constitution of India. According to Mr. Thakore, classification in respect of
admission is permissible under Article 14, while in respect of employment, it is
permissible under Article 14 read with Article 16(1) of the Constitution. It is
contended that when such classification meets the twin criteria of test under Article
14 of the Constitution, it is permissible for the State to bring such ordinance.
Reservation contemplated by ordinance is not reservation in true and strict sense, but
it is classification permissible under the constitutional scheme. It is also contended
that while interpreting the constitutional provision, there cannot be blanket
proposition that classification done on the basis of income is per se illegal and ultra
vires the Constitution of India. Such criteria for classification will have to be tested on
the basis of objectives sought to be achieved by such Act and ordinance.
Ratio of the judgment of the Hon'ble Supreme Court in the case of HC-NIC Page 50 of 104 Created
On Sat Aug 06 03:51:36 IST 2016 Indra Sawhney (supra) prohibiting classification based on income
is violative of Article 14 of the Constitution of India and such ratio will have to be read in the context
of the object of enactment/circular which was under challenge before the Hon'ble Supreme Court.
Learned counsel, in support of his arguments has placed reliance on the following decisions:
1. State of West Bengal and others v. Committee for Protection of Democratic Rights,
West Bengal and others, reported in (2010) 3 SCC 571
2. Central Public Information Officer, Supreme Court of India v.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

Subhash Chandra Agrawal, reported in (2011) 1 SCC 496
3. Charanjit Lal Chowdhury v. The Union of India and others, reported in AIR 1951 SC 41
4. The State of W.B. v. Anwar Ali Sarkar and another, reported in AIR 1952 SC 75
5. Kathi Raning Rawat v. State of Saurashtra, reported in AIR 1952 SC 123
6. Ameerunnissa Begum and others v. Mahboob Begum and others, reported in AIR 1953 SC 91
7. Sakhawant Ali v. State of Orissa, reported in AIR 1955 SC
8. Shri Ram Krishna Dalmia & others v. Shri Justice S.R. Tendolkar and others, reported in AIR
1958 SC 538
9. Mohd. Hanif Quareshi and others & others v. State of Bihar & Others, reported in AIR 1958 SC
731 HC-NIC Page 51 of 104 Created On Sat Aug 06 03:51:36 IST 2016
10. Transport and Dock Workers Union and others v. Mumbai Port Trust and Another, reported in
(2011) 2 SCC 575
11. Satyawati Sharma (Dead) by LRs v. Union of India and another, reported in (2008) 5 SCC 287
12. State of Kerala and another v. N.M. Thomas and others, reported in (1976) 2 SCC 310
13. Copy of judgment of the Supreme Court in the case of Rajiv Kumar Gupta & others v. Union of
India, rendered in Writ Petition (Civil) No. 521 of 2008
14. Rita Kumar v. Union of India, reported in 1973 (1) SCC
15. Javed Niaz Beg and another v. Union of India and another, reported in AIR 1981 SC 794
16. K. Duraiswamy and another v. State of T.N. and others, reported in (2001) 2 SCC 538
17. Pre-PG Medical Sangharsh Committee and another v. Dr. Bajrang Soni and others, reported in
(2001) 8 SCC 694
18. Saurabh Chaudri and others v. Union of India and others, reported in (2003) 11 SCC 146
19. K.C. Vasanth Kumar and another v. State of Karnataka, reported in AIR 1985 SC 1495
20. Pramati Educational and Cultural Trust (Registered) and others v. Union of India and others,
reported in (2014) 8 SCC 1Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

21. Mr. Amit Panchal, learned counsel assisted by Ms. HC-NIC Page 52 of 104 Created On Sat Aug
06 03:51:36 IST 2016 Shivani Rajpurohit, appearing for respondent no.5, by taking us to various
clauses in the ordinance, submitted that the State of Gujarat has issued ordinance for reserving 10%
of available seats for admission in educational institutions and in services and posts under the State,
only to strike balance of reservation in SC, ST and ECBC and unreserved category of people. It is
submitted that such ordinance is issued to protect the citizens from social injustice and to avoid
exploitation by the rich against the persons belonging to economically weaker sections of the society.
It is submitted that such reservation of 10% under the ordinance is not a quota, but is an additional
requirement amongst the general category of people within 51% and such classification is extended
only to the weaker sections of 51% people without touching the communal reservation of 49% under
Articles 15 and 16 of the Constitution of India. It is submitted that such ordinance is issued in
conformity with Articles 14 and 46 of the Constitution. By referring to the provision under Article 46
of the Constitution of India, it is submitted by the learned counsel that it is the duty of the welfare
state to promote the educational and economic interest of SC, ST and also other weaker sections of
the society. It is further contended that it is an obligation on the State to apply all directive
principles under the Constitution of India for making laws. Learned counsel places reliance upon
the judgment of the Hon'ble Supreme Court in the case of State of Madras vs. Champakam
Dorairajan, reported in AIR 1951 SC 226 and also in the case in re: Kerala Education Bill reported in
in 1958 SC HC-NIC Page 53 of 104 Created On Sat Aug 06 03:51:36 IST 2016
956. Thus, it is submitted that this Court may not entirely ignore the directive principles and the
State Policy laid down in Part-IV of the Constitution, but should adopt the principles of harmonious
construction and should attempt to give effect to both as much as possible. Placing reliance on the
judgment of the Hon'ble Supreme Court in the case of Minerva Mills Ltd v. Union of India, reported
in (1980) 3 SCC 625, it is contended by the learned counsel that directive principles of Chapter-IV
impose an obligation on the State to take positive action for creating socio-economic conditions in
which there will be an egalitarian social order with social and economic justice to all. Learned
counsel also placed reliance on the judgment of the Hon'ble Supreme Court in the case of Ashoka
Kumar Thakur v. Union of India, reported in (2008) 6 SCC 1, in support of his argument that when
a constitutional provision is interpreted, the cardinal rule is to look to the Preamble to the
Constitution as the guiding star and directive principles of the Sate Policy as the book of
interpretation. Learned counsel placed reliance on the publication of the Indian Constitution,
Cornerstone of a Nation, published by Oxford University Press, wherein, author has discussed about
the rights and obligations with reference to fundamental rights and directive principles under the
State Policy.
22. Responding to the arguments of the learned Advocate General and also other learned counsel
appearing for the respective respondents in this batch of petitions, Mr. S.N. Shelat, learned Senior
HC-NIC Page 54 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Advocate, in his reply-argument
contends that the impugned ordinance provides reservation to the extent of 10% to the economically
weaker sections of the society in the educational institutions and services and posts under the State.
When the language is clear from the ordinance/legislative document, there is no reason to read such
reservation as a classification as explained by the learned counsel appearing for the respondents. It
is submitted that it is well-settled principle that when language is plain and unambiguous, it is to beDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

read as it is but not to interpret in a manner contrary to the legislative intent. The said ordinance is
issued for indefinite period and is not temporary measure for any particular period and also not a
source for the purpose of effecting reservation. Learned counsel placed reliance on the judgment of
the Hon'ble Supreme Court in the case of Shiv Shakti Co.op.Hsg.Society, Nagpur v. (M/s) Swaraj
Developers & Ors, reported in 2003 (2) GLH 562, Maulvi Hussein Haji Abraham Umarji v. State of
Gujarat, reported in AIR 2004 SC 3946, Rohitash Kumar and others v. Om Prakash Sharma and
others, reported in (2013) 11 SC 451, (2015) 4 SCC 697, M. Nagraj & Ors v. Union of India & Ors,
reported in AIR 2007 SC 71, Asha D. Bhatt v. Director of Primary Education and Anr. reported in
2003 (4) GLR 3199, Janki Prasad Parimoo and others v. State of Jammu & Kashmir and others,
reported in AIR 1973 SC 930, Kailash Chand Sharma etc. etc. v. State of Rajasthan and others,
reported in AIR 2002 SC 2877. It is submitted further that the reservation based on the economic
criteria, is no more res integra in view of the HC-NIC Page 55 of 104 Created On Sat Aug 06
03:51:36 IST 2016 judgment of the Hon'ble Supreme Court in the case of Indra Sawhney
(supra).What cannot be the criteria for the purpose of reservation under Article 16(4) of the
Constitution can equally be applied for the purpose of reservation of 10% quota in unreserved
category to economically weaker sections of the society and the same is violative of equality clause
under Article 14 of the Constitution. Economic criteria cannot be construed as homogeneous clause
for the purpose of reservation. Ordinance is issued based on the report of the Committee constituted
by the government and there was no data before the Committee and the Committee has not
considered the financial assistance granted earlier by the government to the students belonging to
economically weaker sections of the society. In the absence of any quantifiable data before the
Committee, the Committee constituted by the government just based on the representations
pending before it, recommended reservation of 10% to the economically weaker sections of the
society and based on such recommendations of the Committee, the impugned ordinance is issued.
Thus, such ordinance is illegal, arbitrary and cannot stand the legal scrutiny as it violates the
principles to meet the requirement under Article 14 of the Constitution of India. Learned counsel in
support of his arguments also placed reliance on the following judgments:
1. Chitra Ghosh Kum. Chitra Ghosh v. Union of India, reported in (1969) 2 SCC 228
2. Saurabh Chaudri and others v. Union of India and others, HC-NIC Page 56 of 104
Created On Sat Aug 06 03:51:36 IST 2016 reported in (2003) 11 SCC 146
3. K. Duraisamy and another etc. etc. v. State of T.N and others, reported in AIR 2001
SC 717
4. A.I.I.M.S. Students Union v. A.I.I.M.S. and others, reported in AIR 2001 SC 3262.
23. Mr. S.N. Shelat, learned Sr. Advocate, would contend that the impugned ordinance clearly
provides reservation of 10% quota to economically weaker sections and the same cannot be
construed as a classification as projected by the learned Advocate General on behalf of the State of
Gujarat. In support of his argument, he placed reliance on the judgment of the Hon'ble Supreme
Court in the case of State of Madhya Pradesh v. Union of India, reported in (2003) 7 SCC 83. It is
submitted that income criteria can never be the criteria for the purpose of grouping persons withDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

income less than Rs.6 lakh to a class for the purpose of effecting reservation. Reliance is placed in
this connection on the judgment of the Hon'ble Supreme Court in the case of Deepak Sibal v. Punjab
University and another, reported in AIR 1989 SC 903.
24. Mr. Shalin Mehta, learned Sr. Advocate appearing on behalf of the petitioner in one of the
petitions, responding to the arguments of the learned Advocate General, Mr. Mihir Thakore, learned
Sr. Advocate and Mr. Amit Panchal, learned counsel appearing on behalf of the respective
respondents in the respective HC-NIC Page 57 of 104 Created On Sat Aug 06 03:51:36 IST 2016
petitions, submitted that the impugned ordinance providing for 10% reservation to economical
weaker sections is vertical reservation based on economic criteria only. In support of his argument,
learned counsel placed on record the Admission Prospectus, 2016-17 issued for giving Admissions to
Medical Educational Courses for academic years 2016-17, issued by the Chairman of Admission
Committee for Professional Medical Educational Courses and submitted that quota of 10% for
economical weaker sections is clearly shown under the heading of "reservation of seats along with
Scheduled Castes, Scheduled Tribes, Socially & Educationally Backward Class and Economical
Weaker Sections", in the ratio of 7%, 15%, 27% and 10% respectively. In that view of the matter, it is
clear that what is provided in the impugned ordinance is only reservation to class of persons who are
having income of less than Rs.6 Lakhs. The learned counsel would contend that income criteria
cannot be the criteria for the purpose of effecting reservations and while pleading that same runs
contrary to the authoritative pronouncements of the Hon'ble Supreme Court in various judgments,
it is submitted that if such income criteria is allowed for the purpose of reservation, then some
people may try to reduce their income purposefully so as to gain the benefit of such reservation.
Reservation to the reserved categories viz. SC, ST, SEBC, women, Physically Handicapped, Army
personnel etc is definite one where there is no scope for variation, but whereas if income criteria is
shown for the purpose of reservation, the same is a fluctuating factor which cannot be the basis for
reservation. HC-NIC Page 58 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Learned counsel
would also contend that even assuming that it is a classification as projected on behalf of the State,
the same is not based on any intelligible differentia and there is no reasonable classification for such
ordinance. It is issued on the basis of the recommendation of the Committee of the Hon'ble
Ministers in the absence of any empirical study, there was no material at all before the Committee of
Hon'ble Ministers which was constituted to consider the representations and High-Powered
Committee has made recommendations in the absence of any quantifiable data for the purpose of
recommending reservations. Such reservation which is ordered by the impugned ordinance is
whimsical and is a fraud on the Constitution. Learned counsel placed reliance on the judgments of
the Hon'ble Supreme Court in the case of Atyant Pichhara Barg Chhatra Sangh and Anr. v.
Jharkhand State Vaishya Federation and Ors., reported in (2006) 6 SCC 718 and in the case of
National Legal Services Authority v. Union of India, reported in (2014) 5 SCC 438. It is also
contended that in any event, if the impugned ordinance is allowed to be given effect to, it exceeds
the reservation of more than 50% ceiling limit which is fixed by the Hon'ble Supreme Court in the
case of Indra Sawhney (supra). As it is there are reservations for various categories to the tune of
49% and if further reservation of 10% is allowed, it will be 59%, leaving the balance of only 41% for
general category and thus, results in denial of equal opportunity for meritorious personnel in the
matter of admissions in educational institutions and in the services and posts HC-NIC Page 59 of
104 Created On Sat Aug 06 03:51:36 IST 2016 under the State. Thus, it affects the equality clauseDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

guaranteed under Article 14 of India.
24.1 It is submitted by the learned counsel that economic criteria adopted for the purpose of
distinguishing the creamy layer within backward classes cannot be the criteria for the purpose of
determining the economically weaker sections having annual income below the limit of Rs.6 lakhs as
a class for the purpose of effecting reservations. All the families having annual income below Rs.6
lakh cannot be treated as homogeneous class in absence of empirical study. Rane Commission is
constituted only for the purpose of identification of socially and educationally backward classes to
extend the benefits under Articles 16(49) of the Constitution and the report of the said Rane
Commission is not acted upon by the government and its recommendations are also confined only
for the purpose of extending benefits of reservations to Socially and Educationally Backward Classes
for providing benefits under Articles 16(4) of the Constitution. It is submitted that such
ordinance/legislation is suspect one and for the purpose of classification is arbitrary and illegal and
burden is on the State to show that such classification is made to meet the twin criteria under Article
14 of the Constitution of India. In support of such argument, Mr. Mehta placed reliance upon the
judgment of the Hon'ble Supreme Court in the case of AIIMS Students' Union vs. AIIMS reported in
(2002) 1 SCC 428. That by applying the doctrine of precedence, HC-NIC Page 60 of 104 Created On
Sat Aug 06 03:51:36 IST 2016 ratio decided by the Hon'ble Supreme Court in the case of Indra
Sawhney (supra) has to be applied to test the validity of the impugned ordinance. It is submitted
that if implementation of such ordinance is allowed, it will amount to overlooking the merit. Lastly,
it is submitted that so-called representations which were taken into consideration and placed before
the Committee cannot be the basis for issuing ordinance and such representations and the steps
taken by the Committee on such representations can be starting point to examine the issue and such
representations themselves cannot be the sole material and basis for making recommendations for
reservations. As the High-Powered Committee made recommendations, it is not the basis of any
quantifiable data and relevant material and therefore, the ordinance is issued on the basis of such
recommendations is illegal and fit to be declared as arbitrary.
25. Shri B.T. Rao, learned counsel appearing for the petitioners in one of the petitions would
contend that there is no study at all before issuing impugned ordinance and in absence of any such
study and empirical data, it is not open for the State to issue the impugned ordinance. Learned
counsel referred to para XVI of the report of Rane Commission and also the judgment of the Hon'ble
Supreme Court in the case of Indra Sawhney (supra) in support of his arguments.
26. Responding to the arguments of learned counsel for the HC-NIC Page 61 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 petitioners, Mr. Kamal B.Trivedi, learned Advocate General further
contended that even in the judgment in the case of Indra Sawhney(supra) the conclusions arrived at
stating that economic criteria cannot be the criteria for the purpose of identification of backward
classes, cannot be construed as ratio decidendi as much as the same is contrary to the view of the
majority in the judgment. Further, by referring to the judgment of the Hon'ble Supreme Court in the
case of Ashoka Kumar Thakur v. State of Bihar & Ors, reported in (1995) 5 SCC 403, it is submitted
that in the aforesaid judgment, the Hon'ble Supreme Court has approved the economic criteria for
the purpose of identifying the creamy layer by approving the rule of exclusion framed by the
Government of India under para 2(c) read with the Schedule of Office Memorandum quoted in theDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

aforesaid judgment. It is submitted that when such criteria is accepted for determination of creamy
layer, economic criteria can be the criteria for the purpose of identifying a class within the
economically weaker sections for giving the benefit of reservation of 10% seats in educational
institutions and in appointments and posts in the services under the State. Placing reliance on the
judgment of the Hon'ble Supreme Court in the case of A.I.I.M.S. Students Union v. A.I.I.M.S. and
others, reported in AIR 2001 SC 3262, it is submitted that classification is based by providing a
source of entry and such source of entry is aimed at securing equal or proportionate distribution of
seats in the educational institutions and services. It is submitted that the characteristics of the two
may to some extent be HC-NIC Page 62 of 104 Created On Sat Aug 06 03:51:36 IST 2016 over
lapping, yet the distinction is perceptible though fine. Learned Advocate General also placed
reliance on the judgment of the Hon'ble Supreme Court in the case of Janki Preasad Parimoo and
others v. State of jammu & Kashmir and others, reported in AIR 1973 SC 930 and submitted that
educational backwardness which makes a class, can be identified based on economical
backwardness. In this regard, emphasis is laid by the learned Advocate General on para-23 of the
aforesaid judgment. Further placing reliance on the judgment of the Hon'ble Supreme Court in the
case of Rajeev Kumar Gupta v. Union of India, reported in (2016) 2 SCC 445, the learned Advocate
General would contend that the principles laid down in the case of Indra Sawhney (supra) are
applicable only when the State seeks to give preferential treatment in the matter of employment
under the State to certain classes of citizens identified to be a backward class. As such, it is
submitted that class is identified based on the economic criteria to extend the benefit for admissions
in educational institutions and appointments and posts in services under the State and therefore, no
empirical study is required to be made.
27. Having regard to the pleadings on record and on hearing the arguments of learned counsel
appearing for the parties, we are of the view that following points arise for consideration in this
group of petitions:
(1) Whether, the allocation of 10% seats in educational institutions in the State and
for making appointments and posts in the services HC-NIC Page 63 of 104 Created
On Sat Aug 06 03:51:36 IST 2016 under the State in favour of economically weaker
sections of unreserved category, impugned Ordinance No. 1/2016 is a reservation or a
classification?
(2) If it is to be held that such allocation is reservation of 10% of seats, whether the
State is justified in providing reservation in favour of economically weaker sections of
unreserved category only on the basis of economic criterion?
(3) Whether, the State is justified in issuing the impugned Ordinance providing
reservation of 10% of available seats for admissions in educational institutions and
appointments in services in favour of economically weaker sections of unreserved
category, without carrying out any detailed scientific and technical impact
assessment study by the experts and without collecting quantifiable and empirical
data?Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

(4) Whether, the State is justified in issuing the impugned Ordinance providing 10%
of reservation in favour of economically weaker sections of unreserved category, and
exceeded the ceiling limit of 50% of available seats?
(5) Whether, the State is justified in issuing the impugned Ordinance on 1.5.2016,
when the Government Resolutions dated 7.10.2015 and 5.4.2016 granting financial
assistance to the students of economically weaker sections of unreserved category are
in existence and that too without waiting for result of such benefits conferred under
the resolutions?
HC-NIC Page 64 of 104 Created On Sat Aug 06 03:51:36 IST 2016
28. Point No.1:
Whether, the allocation of 10% seats in educational institutions in the State and for
making appointments and posts in the services under the State in favour of
economically weaker sections of unreserved category, impugned Ordinance No.
1/2016 is a reservation or a classification?
28.1 With reference to the above point, it is to be noted that Preamble of the
impugned Ordinance itself undertakes that such Ordinance is issued to provide
reservation of seats. The impugned Ordinance is titled as "the Gujarat Unreserved
Economically Weaker Sections (Reservation of Seats in Educational Institutions in
the State and of Appointments and Posts in services under the State) Ordinance,
2016. Sections 3 and 4 of the impugned Ordinance read as under:
"3. Reservation of seats in educational institutions in the State.- The reservation in
respect of the annual permitted strength for admission into such educational
institutions and courses in the State, as may be prescribed, for Economically Weaker
Sections, shall be ten per cent.
4. Reservation of appointments and posts in the services under the State.-(1) The
reservation of appointments and posts in the services under the State for the
Economically Weaker Sections shall be ten per cent.
(2) Notwithstanding anything contained in sub-
HC-NIC Page 65 of 104 Created On Sat Aug 06 03:51:36 IST 2016 section (1), such reservation shall
not apply in the matters of promotion."
28.2 When it is the specific case of the petitioners that no reservation of seats in favour of
economically weaker sections of unreserved category is permissible, it is pleaded in the affidavit in
reply filed on behalf of the respondent no.1-State of Gujarat that it is only a classification and in
stricto sensu, it is not reservation for Socially and Educationally Backward Classes as providedDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

under Articles 15 and 16 of the Constitution of India. Even during the course of arguments, the
learned Advocate General, appearing on behalf of the State of Gujarat, specifically argued that such
Ordinance is issued only for making a reasonable classification to provide reasonable opportunities
to the economically weaker sections of unserved category and it meets the twin test, to examine,
whether the same is in breach of Article 14 of the Constitution of India. It is contended by the
learned Advocate General that merely because the word "reservation" is used in the impugned
Ordinance, the same cannot be treated as the reservation but, the same is classification, and it
withstands the legal scrutiny under Article 14 of the Constitution of India and the same is to be
construed as reasonable classification, within the class of unreserved category. On the other hand, it
is submitted by Shri S.N. Shelat as well as Mr. Mehta, learned counsel appearing on behalf of the
petitioners that when the legislative intent is clear from the Statute, it is to be read as drafted and
there is no reason to construe the same as a classification as projected by the HC-NIC Page 66 of 104
Created On Sat Aug 06 03:51:36 IST 2016 State. It is submitted that if the background which led to
issuance of the impugned Ordinance is looked at, the agitation of Patidars was for the purpose of
reservation only and if the contents of the Report of the High Power Committee constituted by the
State are looked at, it is clear that the Committee recommended only reservation of seats basing on
which the impugned Ordinance is issued. We would like to refer to the Report of the High Power
Committee and think it apt to extract the paragraph at the very beginning of the Report which reads
as under:
"With the demand of providing reservation in the government jobs and higher
education, various social groups and communities have given representations to the
Government. With a view to consider these representations given by such different
communities/their representatives in the backdrop of the agitation/movement for
the same, the Government has decided to create a High Power Committee.
The Committee Report also refers to various demands related to reservation in the
government jobs and higher education and the said Committee has also referred to
the Report of Rane Commission and finally made recommendations which read as
under:-
"Recommendations of the Committee:
Taking into consideration all these, with a view to ensure that the educational and
economic progress of the youngsters of economically weaker unreserved category is
not hampered, they get opportunity to obtain education and employment, no
injustice is done to any other community and still adhering to the policy of the
development of disadvantaged groups, and maintaining the spirit of "Sau no saath,
Sau no vikaas", the Committee recommends as follows:
HC-NIC Page 67 of 104 Created On Sat Aug 06 03:51:36 IST 2016 "Economically
weaker class (with the family income of Rs. 6.00 lakh per annum) of the Unreserved
Category is hereby given the reservation of 10 percent in the appointment to the
Government services and in the admission to the educational institutions. ThisDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

benefit will be given to them as per the standard of the reservation benefit given to
the Socially and Educationally Backward Class (SEBC). This means that it will be in
accordance with the present income limit of Rs.6 lakh and the standing-presently
prevalent instructions of the Social Justice and Empowerment Department, for the
socially and economically backward class among the forward class.""
28.3 It is clear from the background facts and the contents of the Report which led to issuance of the
impugned Ordinance and various clauses in the Ordinance that what is provided is 10% of seats in
educational institutions and in appointments and posts in the services under the State to
economically weaker sections of unreserved category is nothing but reservation and not
classification. Even if dictionery meaning of reservation is seen, the reservation is nothing but an act
of booking, kept blank, destined for a particular use of particular person. By virtue of the impugned
Ordinance, specific number of seats/posts available to unreserved category are reserved for
economically weaker sections. As it is clear from the same that every candidate belonging to
unreserved community cannot compete with the quota of 10%, such allocation of 10% is nothing but
reservation. From the reading of various clauses in the Ordinance and also the consequent
resolutions issued by the government, it is clear that only such of the candidates having family
income below Rs.6 lakh alone are entitled into the specified quota in the impugned Ordinance
among available seats to unreserved HC-NIC Page 68 of 104 Created On Sat Aug 06 03:51:36 IST
2016 categories. In view of the aforesaid reasoning and clear and unambiguous language used in the
impugned Ordinance for reservation of 10% of available seats in the educational institutions and in
appointments and posts in the services under the State it is to be held as only a reservation but not
classification. In this regard, it is profitable to refer to the judgment of the Hon'ble Supreme Court in
the case of Maulvi Hussein Haji Abraham Umarji v. State of Gujarat and Anr.,reported in AIR 2004
SC 3946. In the said judgment, the Hon'ble Supreme Court has held that Court cannot read
anything into a statutory provision which is plain and unambiguous. It is further held that a statute
is an edict of the legislature and the language employed in the statute is determinative factor of
legislative intent. Paras-18 and 19 of the said judgment read as under:
"18. It is well settled principle in law that the Court cannot read anything into a
statutory provision which is plain and unambiguous. A statute is an edict of the
Legislature. The language employed in a statute is the determinative factor of
legislative intent.
19.Words and phrases are symbols that stimulate mental references to referents. The
object of interpreting a statute is to ascertain the intention of the Legislature enacting
it. (See Institute of Chartered Accountants of India v. M/s. Price Waterhouse and
another (AIR 1998 SC 74)). The intention of the Legislature is primarily to be
gathered from the language used, which means that attention should be paid to what
has been said as also to what has not been said. As a consequence, a construction
which requires for its support, addition or substitution of words or which results in
rejection of words as meaningless has to be avoided. As observed in Crawford v.
Spooner (1846 (6) Moore PC 1), Courts, cannot aid the Legislatures' defective
phrasing of an Act, we cannot add or mend, and by construction make up deficienciesDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

which are left there. (See The State of Gujarat and others v. Dilipbhai HC-NIC Page
69 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Nathjibhai Patel and another (JT
1998 (2) SC 253)). It is contrary to all rules of construction to read words into an Act
unless it is absolutely necessary to do so. (See Stock v. Frank Jones (Tipan) Ltd.,
(1978) 1 All ER 948 (HL)). Rules of interpretation do not permit Courts to do so,
unless the provision as it stands is meaningless or of doubtful meaning. Courts are
not entitled to read words into an Act of Parliament unless clear reason for it is to be
found within the four corners of the Act itself. (Per Lord Loreburn L.C. in Vickers
Sons and Maxim Ltd. v. Evans, (1910) AC 445 (HL)), quoted in Jumma Masjid,
Mercara v. Kodimaniandra Deviah and others (AIR 1962 SC 847)."
28.4 Learned Advocate General, in support of his argument that 10% of allocation of seats for
admissions in educational institutions and for appointments and posts in the services under the
State is reasonable classification within the class of unreserved categories, has placed reliance on the
judgment of the Hon'ble Supreme Court in the case of Kedar Nath Bajoria, v. State of West Bengal,
reported in AIR 1953 SC 404 and other authorities on the subject referred above. We have given our
serious thought on the authority relied on by the learned Advocate General in the above case of
Kedar Nath Bajoria (supra). In the said case, the Hon'ble Supreme Court has held that equal
protection of the laws guaranteed by Article 14 of the Constitution does not mean that all the laws
must be general in character and universal in application and that the State is no longer to have the
power of distinguishing and classifying persons or things for the purposes of legislation. It is further
held that legislative classification must not be arbitrary but should be based on an intelligible
principle having a reasonable relation to the object which the legislature seeks to attain. It is also
held that further to HC-NIC Page 70 of 104 Created On Sat Aug 06 03:51:36 IST 2016 meet the
requirement of Article 14 of the Constitution,legislative classification need not be scientifically
perfect or logically complete. 28.5 In the judgment in the case of Mohd. Hanif Qureshi and others v.
State of Bihar and others, reported in AIR 1958 SC 731, the Hon'ble Supreme Court held in paras 15
and 16 as under:-
"15. The meaning, scope and effect of Art. 14 which is the equal protection clause in
our Constitution, has been explained by this Court in a series of decisions in cases
beginning with Charanjitlal Chowdhury v. Union of India, 1950 S C R 869: (AIR 1951
S C 41) (C) and ending with the recent case of Ramkrishna Dalmia v. Justice
Tendolkar, C A Nos. 455 to 457 and 656 to 658 of 1957 D /-28-3-1958: (AIR 1958 S C
538) (D). It is now well established that while Art. 14 forbids class legislation it does
not forbid reasonable classification for the purposes of legislation and that in order to
pass the rest of permissible classification two conditions must be fulfilled, namely, (i)
the classification must be founded on an intelligible different which distinguishes
persons or things that are grouped together from others left out of the group and (ii)
such differentia must have a rational relation to the object sought to be achieved by
the statute in question. The classification, it has been held, may be founded on
different bases, namely, geographical, or according to objects or occupations or the
like and what is necessary is that there must be a nexus between the basis of
classification and the object of the Act under consideration. The pronouncements ofDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

this Court further establish, amongst other things, that there is always a presumption
in favour of the constitutionality of an enactment and that the burden is upon him,
who attacks it, to show that there has been a clear violation of the constitutional
principles. The Courts, it is accepted, must presume that the Legislature understands
and correctly appreciates the needs of its own people, that its laws are directed to
problems made manifest by experience and that its discriminations are based on
adequate grounds,. It must be borne in mind that the Legislature is free to recognise
degrees of harm and may confine its restrictions to those cases where the need is
deemed to be the clearest and finally that in order to sustain HC-NIC Page 71 of 104
Created On Sat Aug 06 03:51:36 IST 2016 the presumption of constitutionality the
Court may take into consideration matters of common knowledge, matters of
common report, the history of the times and may assume every state of facts which
can be conceived existing at the time of legislation. We, therefore, proceed to examine
the impugned Acts in the light of the principles thus enunciated by this Court.
16. The impugned Acts, it may be recalled, have been made by the States in discharge
of the obligations imposed on them by Art. 48. In order to implement the directive
principles the respective Legislatures enacted the impugned Acts in exercise of the
powers conferred on them by Art. 246 read with entry 15 in List II of the Seventh
Schedule. It is, therefore, quite clear that the objects sought to be achieved by the
impugned Acts are the preservation, protection and improvement of livestock's.
Cows, bulls, bullocks and calves of cows are no doubt the most important cattle for
the agricultural economy of this country. Female buffaloes yield a large quantity of
milk and are therefore, well looked after and do not need as much protection as cows
yielding a small quantity of milk require. As draught cattle male buffaloes are not half
as useful as bullocks. Sheep and goat give very little milk compared to the cows and
the female buffaloes and have practically no utility as draught animals. These
different categories of animals being susceptible of classification into separate groups
on the basis of their usefulness to society the butchers who kill each category may
also be placed in distinct classes according to the effect produced on society by the
carrying on of their respective occupations. Indeed the butchers, who kill cattle,
according to the allegations of the petitioners themselves in their respective petitions,
form a well defined class based on their occupation. That classification is based on an
intelligible differentia which places them in a well defined class and distinguishes
them from those who kill goats and sheep and this different has a close connection
with the object sought to be achieved by the impugned Act, namely, the preservation,
protection and improvement of our livestock. The attainment of these objectives may
well necessitate that the slaughters of cattle should be dealt with more stringently
than the slaughterers of, say, goats and sheep. The impugned Acts, therefore have
adapted a classification on sound and intelligible basis and can quite clearly stand the
test laid down in the decisions of this Court. Whatever objections there may be
against the validity of the impugned Acts the denial of equal protection of the laws
does not prima facie, appear to us to be one of them. In any case, bearing in mind the
presumption of constitutionality attaching to all enactments founded on theDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

recognition by the Court of the fact that the legislature correctly appreciates the
needs of its own people there appears HC-NIC Page 72 of 104 Created On Sat Aug 06
03:51:36 IST 2016 to be no escape from the conclusion that the petitioners have not
discharged the onus that was on them and the challenge under Art. 14 cannot,
therefore prevail."
28.6 In the case of Kumari Chitra Ghosh and another v. Union of India and others, reported in 1969
(2) SCC 228, while considering the provisions for reservation of seats for certain categories of
students under the Delhi University Act, 1922, the Hon'ble Supreme Court observed that if the
sources are properly classified, whether on territorial, geographical or other reasonable basis it is
not for the courts to interfere with the manner and method of making the classification.
28.7 In the case of D.N. Chanchala v. State of Mysore and others, reported in 1971 (2) SCC 293, the
Hon'ble Supreme Court, while considering the issue that University wise distribution of seats will
amount to discrimination and violative of Articles 14 and 15 of the Constitution, held that so long as
the rules for selection applicable to the colleges run by the government do not suffer from any
constitutional or legal infirmity, they cannot be challenged as the government can regulate
admission to its own institutions. In the aforesaid judgment, the Hon'ble Supreme Court in para-43
held as under:
"43. Once the power to lay down classifications or categories of persons from whom
admission is to be given is granted, the only question which would remain for
consideration would be whether such categorisation has an intelligible criteria and
HC-NIC Page 73 of 104 Created On Sat Aug 06 03:51:36 IST 2016 whether it has a
reasonable relation with the object for which the rules for admission are made. Rules
for admission are inevitable so long as the demand of every candidate seeking
admission cannot be complied with in view of the paucity of institutions imparting
training in such subjects as medicine. The definition of a 'political sufferer' being a
detailed one and in certain terms, it would be easily possible to distinguish children
of such political sufferers from the rest as possessing the criteria laid down by the
definition. The object of the rules for admission can obviously be to secure a fair and
equitable distribution of seats amongst those seeking admission and who are eligible
under the University Regulations. Such distribution can be on the principle that
admission should be available to the best and the most meritorious. But an equally
fair and equitable principle would also be that which secures admission in a just
proportion to those who are handicapped and who, but for the preferential treatment
given to them, would not stand a chance against those who are not so handicapped
and are, therefore in a superior position. The principle underlying Article 15 (4) is
that a preferential treatment can validly be given because the socially and
educationally backward classes need it, so that in course of time they stand in equal
position with the more advanced sections of the society. It would not in any way be
improper, if that principle were also to be applied to those who are handicapped but
do not fall under Article 15(4). It is on such a principle that reservation for children of
Defence personnel and Ex-Defence personnel appears to have been upheld. TheDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

criteria for such reservation is that those serving in the Defence forces or those who
had so served are and were at a disadvantage in giving education to their children
since they had to live, while discharging their duties, in difficult places where normal
facilities available elsewhere are and were not available. In our view it is not
unreasonable to extend that principle to the children of political sufferers who in
consequence of their participation in the emancipation struggle became unsettled in
life; in some cases economically ruined and were therefore not in a position to make
available to their children that class of education which would place them in fair
competition with the children of those who did not suffer from that disadvantage. If
that be so, it must follow that the definition of 'political sufferer' not only makes the
children of such sufferers distinguishable from the rest but such a classification has a
reasonable nexus with the object of the rules which can be nothing else than a fair
and just distribution of seats. In our view neither of the two contentions raised by
counsel for the petitioner can be accepted with the result that the writ petition fails
and is dismissed."
HC-NIC Page 74 of 104 Created On Sat Aug 06 03:51:36 IST 2016 28.8 All the aforesaid judgments
relate to classification into categories and groups. In all the cases referred above, the issue fell for
consideration was whether such categorisation, reservation university wise was within the scope of
reasonable classification and meets the requirements of Article 14 of the Constitution. The meaning,
scope and effect of Articles 14 which is the equal protection clause in our Constitution, has been
explained by the Hon'ble Supreme Court in series of decisions. It is fairly well settled that while
Article 14 forbids class legislation and it does not forbid reasonable classification for the purposes of
legislation and that in order to pass the test of permissible classification two conditions must be
fulfilled, namely, (i) the classification must be founded on an intelligible differentia which
distinguishes persons or things that are grouped together from others left out of the group and (ii)
such differentia must have a rational relation to the object sought to be achieved by the statute in
question. By applying the above practice, such classification and categorisation was held to be
reasonable in the above cases. Setting apart 10% of seats to weaker sections of unreserved category
is a classification or reservation is addressed by us separately. By drawing distinction between the
classification and reservation, we have already held that by the impugned Ordinance what is
allocated separate quota of 10% seats in educational institutions and in appointments and posts in
the services under the State is reservation but not classification.
HC-NIC Page 75 of 104 Created On Sat Aug 06 03:51:36 IST 2016 28.9 In the case of S.S. Bedi v.
Union of India and others, reported in (1981) 4 SCC 676, wherein the constitutional validity of
Special Bearer Bonds (Immunities and Exemptions) Ordinance, 1981 fell for consideration before
the Hon'ble Supreme Court. The said Ordinance was tested on the touchstone of equality clause
under Article 14 of the Constitution and in paras-6 and 7 of the judgment, the Hon'ble Supreme
Court held as under:
"6. That takes us to the principal question arising in the writ petitions namely,
whether the provisions of the Act are violative of Article 14 of the Constitution. The
true scope and ambit of Article 14 has been the subject-matter of discussion inDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

numerous decisions of this Court and the propositions applicable to cases arising
under that Article have been repeated so many times during the last thirty years that
they now sound plantitudinous. The latest and most complete exposition of the
propositions relating to the applicability of Article 14 as emerging from "the
avalanche of cases which have flooded this Court" since the commencement of the
Constitution is to be found in the judgment of one of us (Chandrachud, J., as he then
was) in In re The Special Courts Bill, 1978. It not only contains a lucid statement of
the propositions arising under Article 14, but being a decision given by a Bench of
seven Judges of this Court, it is binding upon us. That decision sets out several
propositions delineating the true scope and ambit of Article 14 but not all of them are
relevant for our purpose and hence we shall refer only to those which have a direct
bearing on the issue before us. They clearly recognise that classification can be made
for the purpose of legislation but lay down that:
1. The classification must not be arbitrary but must be rational, that is to say, it must
not only be based on some qualities or characteristics which are to be found in all the
persons grouped together and not in others who are left out but those qualities or
characteristics must have a reasonable relation to the object of the legislation.
In order to pass the test, two conditions must be fulfilled, namely, (1) that the classification must be
founded on an intelligible differentia which distinguishes those that are grouped together from
others and (2) that differentia HC-NIC Page 76 of 104 Created On Sat Aug 06 03:51:36 IST 2016
must have a rational relation to the object sought to be achieved by the Act.
2. The differentia which is the basis of the classification and the object of the Act are distinct things
and what is necessary is that there must be a nexus between them. In short, while Article 14 forbids
class discrimination by conferring privileges or imposing liabilities upon persons arbitrarily selected
out of a large number of other persons similarly situated in relation to the privileges sought to be
conferred or the liabilities proposed to be imposed, it does not forbid classification for the purpose
of legislation, provided such classification is not arbitrary in the sense above mentioned.
It is clear that Article 14 does not forbid reasonable classification of persons, objects and
transactions by the legislature for the purpose of attaining specific ends. What is necessary in order
to pass the test of permissible classification under Article 14 is that the classification must not be
"arbitrary, artificial or evasive" but must be based on some real and substantial distinction bearing a
just and reasonable relation to the object sought to be achieved by the legislature. The question to
which we must therefore address ourselves is whether the classification made by the Act in the
present case satisfies the aforesaid test or it is arbitrary and irrational and hence violative of the
equal protection clause in Article 14.
7. Now while considering the constitutional validity of a statute said to be violative of Article 14, it is
necessary to bear in mind certain well established principles which have been evolved by the courts
as rules of guidance in discharge of its constitutional function of judicial review. The first rule is that
there is always a presumption in favour of the constitutionality of a statute and the burden is uponDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

him who attacks it to show that there has been a clear transgression of the constitutional principles.
This rule is based on the assumption, judicially recognised and accepted, that the legislature
understands and correctly appreciates the needs of its own people, its laws are directed to problems
made menifest by experience and its discrimination are based on adequate grounds. The
presumption of constitutionality is indeed so strong that in order to sustain it, the Court may take
into consideration matters of common knowledge, matters of common report, the history of the
times and may assume every state of facts which can be conceived existing at the time of legislation."
28.10 Thus, we hold on Point No. 1 that allocation of 10% of HC-NIC Page 77 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 seats for admission in educational institutions in the State and in
appointments and posts in the services under the State in favour of economically weaker sections of
unreserved category in the impugned Ordinance is reservation only, but not classification.
29. Point Nos. 2 and 4:
(2) If it is to be held that such allocation is reservation of 10% of seats, whether the
State is justified in providing reservation in favour of economically weaker sections of
unreserved category only on the basis of economic criterion?
(4) Whether, the State is justified in issuing the impugned Ordinance providing 10%
of reservation in favour of economically weaker sections of unreserved category, and
exceeded the ceiling limit of 50% of available seats?
29.1 The concept of reservation in educational institutions and reservations of posts is accepted
phenomenon in our constitutional scheme. But the same is subject to certain limitations,
requirements and mandates in the Constitution itself. Fundamental rights guaranteed under the
constitutional scheme are in Part III of the Constitution which cover Articles 12 to 35 which include
Articles 13,14, 15 and 16. Article 13 of the Constitution deals with the laws inconsistent with or in
derogation of the fundamental rights. As per Article 13 (2) of the Constitution, the State shall not
make any law which takes away or abridges the rights conferred by the said Part HC-NIC Page 78 of
104 Created On Sat Aug 06 03:51:36 IST 2016 and any law made in contravention of this clause
shall, to the extent of the contravention, be void. Article 14 of the Constitution guarantees the
citizens equality before the law and equal protection of laws within the territory of India. Article 15
of the Constitution prohibits discrimination on the grounds of religion, race, caste, sex or place of
birth. However, by the Constitution (First Amendment) Act, 1951, clause (4) is added in Article 15 by
which the State is empowered to make any special provision for the advancement of any socially and
educationally backward classes of citizens or for the Scheduled Castes and the Scheduled Tribes.
Further clause-5 was inserted in Article 15 of the Constitution by Constitution (Ninety-third
Amendment) Act, 2005, which states that nothing in this article or in sub-clause (g) of clause (1) of
Article 19 shall prevent the State from making any special provision, by law, for the advancement of
any socially and educationally backward classes of citizens or for the Scheduled Castes or the
Scheduled Tribes in so far as such special provisions relate to their admission to educational
institutions including private educational institutions, whether aided or unaided by the State, other
than the minority educational institutions referred to in clause (1) of Article 30. Article 16 of the
Constitution provides for equality of opportunities in matters of appointments. Under Article 16(4)Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

of the Constitution, the State is empowered to make any provision for the reservation of
appointments or posts in favour of any backward class of citizens which, in the opinion of the State,
is not adequately represented in the services under the State. HC-NIC Page 79 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 29.2 Whenever orders are issued by way of executive or by legislative
mandate providing for reservation in educational institutions and in appointments and posts in the
services unde the State, many times, such orders or mandates were under challenge before various
High Courts and the Hon'ble Supreme Court. 29.3 Prior to the 1st constitutional amendment by
which clause (4) was inserted in Article 15 of the Constitution, the Madras Government had issued
order fixing certain percentage of seats in the State Colleges for different communities for admission
into the medical colleges, which was the subject-matter of challenge before the Madras High Court,
which judgment was appealed against before the Hon'ble Supreme Court in the case of State of
Madras v. Sm.Champakam Dorairajan and another, reported in A.I.R. 1951 SC 226. In the aforesaid
judgment, the Hon'ble Supreme Court, while considering the scope of Article 29(2) and Article 46 of
the Constitution of India held that classification in the said G.O proceeds on the basis of religion and
caste, is opposed to the Constitution and constitutes a clear violation of the fundamental rights
guaranteed to the citizen under Article 29(2). It was further held in the aforesaid judgment that so
far as there is no infringement of fundamental rights as conferred by Part III of the Constitution
there can be no objection to the State acting according to the directive principles set out in Part IV
subject to the legislative and executive powers and HC-NIC Page 80 of 104 Created On Sat Aug 06
03:51:36 IST 2016 limitations conferred on the State under different provisions of the Constitution.
Thereafter clause (4) of Article 15 was brought into the Constitution by way of amendment which
empowers the State to make special provision for the advancement of any socially and educationally
backward classes of citizens or for the Scheduled Castes and the Scheduled Tribes. By taking into
consideration the further constitutional amendment by which clause (4) was inserted in Article 16 of
the Constitution, it is clear that under Article 15(4) of the Constitution, the State is empowered for
effecting reservation by making special provision for the advancement of any socially and
educationally backward class of citizens so far as the educational institutions in Gujarat are
concerned, and under Article 16(4) of the Constitution, the State is empowered to make any
provision for the reservation of appointments or posts in favour of any backward class of citizens
which, in the opinion of the State, is not adequately represented in the services under the State.
Except the above powers conferred on the State under the constitutional scheme, there is no other
power conferred on the State for effecting reservation in favour of any other category more
particularly the economically weaker sections of unreserved category. In the absence of any specific
provision which empowers the State for making special provision for advancement of economically
weaker sections of unreserved category, under the guise of classification it is not open for the State
to issue any order by way of Ordinance giving effect to 10% of available seats for admission in the
educational institution and in the HC-NIC Page 81 of 104 Created On Sat Aug 06 03:51:36 IST 2016
appointments and posts in services under the State. In the absence of such specific provision
empowering the State to make reservation in favour of economically backward category among
unreserved category candidates, such Ordinance is in breach of equality rights guarantee under
Article 14 of the Constitution of India. Unreserved category itself is a class and it is not open for the
State to issue any order either by legislative action or by issuing executive order to effect the
reservation on the ground that part of section in that category is economically weak. While
extending the benefit of reservation to the socially and economically backward class and for removalDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

of creamy layer, economic criterion can also be looked into. But it is not open for the State to make
any reservation for section of citizens in unreserved category, only on the ground that section of
such category of citizens belong to economically weak. As the economically weaker sections among
unreserved category cannot constitute as homogeneous group for the purpose of reservation and
such reservation will not withstand to the scrutiny of twin test under Article 14 of the Constitution of
India. Further, the economic criteria being fluctuating issue, the same cannot be the basis for any
classification for the purpose of affirmative action for admission to educational institutions and
while filling up the posts in the services under the State. Thus, such Ordinance which itself is issued
based on economic criteria and as the same is in breach of equality clause under Article 14 of the
Constitution, it is to be declared as void in view of the provision under Article 13(2) of the
Constitution. HC-NIC Page 82 of 104 Created On Sat Aug 06 03:51:36 IST 2016 29.4 As it is the case
of the petitioners that the impugned Ordinance runs contrary to the ratio laid down by the Hon'ble
Supreme Court in the judgment of Indra Sawhney v. Union of India, reported in 1992 Supp. (3) SCC
217, we also refer to the case-law on the subject relating to reservation for backward class citizens
under Articles 15(4) and 16(4) of the Constitution of India. Earlier to the judgment in the case of
Indra Sawhney v. Union of India, reported in 1992 Supp. (3) SCC 217, the scope of provision under
Article 15(4) of the Constitution fell for consideration of the Hon'ble Supreme Court in the case of
M.R. Balaji and others, v. The State of Mysore and others, reported in AIR 1963 SC 649(1). In the
said case, the orders were issued by the State of Mysore reserving seats in technical institutions for
backward class. While considering the scope of constitutional provision under Articles 15(1), 15(4),
29(2) and 340 of the Constitution, the Hon'ble Supreme Court set aside the said order by holding
that socially and educationally backwardness cannot be determined basing on the caste.
29.5 In the case of Janaki Prasad Parimoo and others v. State of J. and K., reported in AIR 1973 SC
930(1), the Hon'ble Supreme Court interpreted the word, expression and meaning of the words
"backward class of citizens" with reference to the socially and educationally backwardness under
Article 16(4) of the Constitution. In HC-NIC Page 83 of 104 Created On Sat Aug 06 03:51:36 IST
2016 the aforesaid judgment, the Hon'ble Supreme Court held that mere educational backwardness
or the social backwardness does not by itself make a class of citizens backward. The Hon'ble
Supreme Court further held that in order to be identified as belonging to such a class, one must be
both educationally and socially backward. 29.6 In support of his argument on Issue Nos. 2 and 4
that the economic criteria can be the criteria for the propose of identifying the group, the learned
Advocate General placed reliance on the judgment in the case of K.C. Vasanth Kumar and another v.
State of Karnataka, reported in 1985 (Supp) SCC 714, the Hon'ble Supreme Court extensively dealt
with the two questions, namely, (i) how to identify the backward classes for the purpose of
reservation and (ii) what should be the permissible extent of reservations. Answering the question
no.1, apart from various observations and directions, the Hon'ble Supreme Court was of the opinion
that economic criterion could, simultaneously take a vital step in the direction of destruction of caste
structure. To the extent of reservation, the Hon'ble Supreme Court observed that reservation may
not exceed 50%. In the aforesaid judgment, in opinion no.2, the Hon'ble Supreme Court observed as
under:
"(2) The means test, that is to say, the test of economic backwardness ought to be
made applicable even to the Scheduled Castes and Scheduled Tribes after the periodDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

mentioned in (1) above. It is essential that the privileged section of the
underprivileged society should not be permitted to monopolise preferential benefits
for an indefinite period of HC-NIC Page 84 of 104 Created On Sat Aug 06 03:51:36
IST 2016 time."
29.7 Referring to the said opinion no.2, it is submitted by the learned Advocate General that
economic criteria can be the criteria for the purpose of identifying the group of weaker sections
within the class of unreserved categories.
29.8 In the case of Indra Sawhney and others v. Union of India, reported in 1992 (3) SCC 217, which
is popularly known as Mandal Commission case, special bench of 9 Judges extensively dealt with the
scope of reservation under Articles 15(4) and 16(4) of the Constitution with reference to
constitutional mandate under Articles 14 and 32 of the Constitution of India. Various questions had
fallen for consideration which are discussed in the majority judgment written by Hon'ble Mr. Justice
B.P. Jeevan Reddy. One of the questions which is relevant for the purpose of the present case was
question no.4(a) which was to the effect that, whether the backward classes can be identified only
and exclusively with references to economic criteria. Question no.4(b) was whether a criteria like
occupation-cum-income without reference to caste altogether, can be evolved for identifying the
backward classes. The Hon'ble Supreme Court answering the question no.4 (a) observed as under:
"(a) Whether backward classes can be identified only and exclusively with reference
to the economic criterion?
799. It follows from the discussion under Question No.3 that a HC-NIC Page 85 of 104 Created On
Sat Aug 06 03:51:36 IST 2016 backward class cannot be determined only and exclusively with
reference to economic criterion. It may be a consideration or basis along with and in addition to
social backwardness, but it can never be the sole criterion. This is the view uniformly taken by this
Court and we respectfully agree with the same." 29.9 In the said judgment, out of 9 Hon'ble Judges,
8 Hon'ble Judges were of the same view and there was dissenting judgment by one of the Hon'ble
Judges. Even the extent of percent of reservation in the aforesid judgment was addressed under
Question 6(a) and (b) with reference to reservation under Article 15(4) of the Constitution and it was
answered that reservation contemplated under clause (4) of Article 16 should not exceed 50%.
Paragraphs 809 and 810 of the majority judgment read as under:
"809. From the above discussion, the irresistible conclusion that follows is that the
reservations contemplated in clause (4) of Article 16 should not exceed 50%.
810. While 50% shall be the rule, it is necessary not to put out of consideration
certain extraordinary situations inherent in the great diversity of this country and the
people. It might happen that in farflung and remote areas the population inhabiting
those areas might, on account of their being out of the mainstream of national life
and in view of conditions peculiar to and characteristical to them, need to be treated
in a different way, some relaxation in this strict rule may become imperative. In
doing so, extreme caution is to be exercised and a special case made out."Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

Thus, it is clear that in the aforesaid judgment, the Hon'ble Supreme Court has held that economic
criteria cannot be the criterion for the purpose of determination of social backwardness. Further,
even with regard to cap of percentage of reservation, from the above said HC-NIC Page 86 of 104
Created On Sat Aug 06 03:51:36 IST 2016 judgment, it is clear that reservation cannot exceed 50%
and 50% shall be the rule. Exception is carved out only in certain extraordinary situation, as referred
in the above paragraph, to make some departure by some relaxation. As we do not find any such
extraordinary circumstance for making departure to 50% of reservation, we hold that reservations
exceeding 50% by virtue of the impugned Ordinance also cannot be sustained.
29.10 However, Shri Trivedi, learned Advocate General has taken us through the judgment of the
Hon'ble Supreme Court and submitted that, the said judgment is rendered with reference to the
situation prevailing at the time of submission of Mandal Commission Report on 31.12.1980 which
recognized as many as 3743 castes as Socially and Educationally Backward Classes, he submitted
that as further period of 36 years has passed by, time has come for adopting new practice and
methods and yardsticks by moving away from caste-centric definition of backward class as observed
by the Hon'ble Apex Court in the case of Ram, Singh v. Union of India, reported in (2015) 4 SCC
697. In the case of Ram Singh (supra), the Hon'ble Supreme Court held that though caste may be a
prominent and distinguishing factor for easy determination of backwardness of a social group and
the Supreme Court has been routinely discouraging the identification of a group as backward solely
on the basis of caste. The Hon'ble Supreme Court further held that social groups who would be most
deserving must necessarily be a matter of continuous HC-NIC Page 87 of 104 Created On Sat Aug 06
03:51:36 IST 2016 evolution. New practices, methods and yardsticks have to be continuously
evolved moving away from caste centric definition of backwardness. This alone can enable
recognition of newly emerging groups in society which would require palliative action. With
reference to such submission made above by the learned Advocate General, we are of the view that
in the absence of any amendments to the basic document of the Constitution, such submissions
cannot be accepted, in view of the binding nature of ratio laid down by the Hon'ble Supreme Court,
we have no other option but to accept that economic criteria cannot be the basis for effecting the
reservation. It is to be noted that when the economic criterion cannot be the sole basis for
determination of Socially and Economically Backward Class of citizens under Articles 15 and 16 of
the Constitution, equally it cannot be accepted that such criteria adopted by the respondent- State is
for giving effect of allocation of 10% reservation in educational institutions and in services to the
economically weaker sections of unreserved category. What cannot be accepted as criteria to extend
the benefit under Articles 15 and 16, can by all force equally apply to any other category for which
reservations are sought to be given effect to.
29.11 Further contention of the learned Advocate General that the Ordinance in question is issued to
translate the constitutional philosophy provided under the directive principles of the State Policy as
laid down under Articles 38, 39(b) and 46 of the Constitution of HC-NIC Page 88 of 104 Created On
Sat Aug 06 03:51:36 IST 2016 India, which inter alia mandates the State to effect economic
empowerment of the weaker sections of the society. But in this regard, it is relevant to notice that in
the judgment of the Hon'ble Supreme Court in the case of A.I.I.M.S. Students Union v. A.I.I.M.S.
And others, reported in AIR 2001 SC 3262, the Hon'ble Supreme Court, while considering the issue
of institutional reservation of 33% coupled with 50% reservation discipline-wise and percentileDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

system and while distinguishing the reservation and source of entry, held in paras 52 and 53 as
under:
"52. Preamble to the Constitution of India secures, as one of its objects, fraternity
assuring the dignity of the individual and the unity and integrity of the nation to 'we
the people of India'. Reservation unless protected by the Constitution itself, as given
to us by the founding fathers and as adopted by the people of India, is sub-version of
fraternity, unity and integrity and dignity of the individual. While dealing with
Directive Principles of State Policy, Article 46 is taken note of often by overlooking
Articles 41 and 47. Article 41 obliges the State inter alia to make effective provision
for securing the right to work and right to education. Any reservation in favour of
one, to the extent of reservation, is an inroad on the right of others to work and to
learn. Article 47 recognises the improvement of public health as one of the primary
duties of the State. Public health can be improved by having the best of doctors,
specialists and super specialists. Under-graduate level is a primary or basic level of
education in medical sciences wherein reservation can be understood as the
fulfilment of societal obligation of the State towards the weaker segments of the
society. Beyond this, a reservation is a reversion or diversion from the performance of
primary duty of the State. Permissible reservation at the lowest or primary rung is a
step in the direction of assimilating the lesser fortunates in mainstream of society by
bringing them to the level of others which they cannot achieve unless protectively
pushed. Once that is done the protection needs to be withdrawn in the own interest of
protectees so that they develop strength and feel confident of stepping on higher
rungs on their own legs shedding the crutches. Pushing the protection of reservation
beyond the HC-NIC Page 89 of 104 Created On Sat Aug 06 03:51:36 IST 2016
primary level betrays bigwigs' desire to keep the crippled crippled for ever. Rabindra
Nath Tagore's vision of a free India cannot be complete unless "knowledge is free"
and "tireless striving stretches its arms towards perfection". Almost a quarter century
after the people of India have given the Constitution unto themselves, a chapter on
fundamental duties came to be incorporated in the Constitution. Fundamental
duties, as defined in Article 51A, are not made enforceable by a writ of Court just as
the fundamental rights are, but it cannot be lost sight of that 'duties' in Part IVA -
Article 5lA are prefixed by the same word 'fundamental' which was prefixed by the
founding fathers of the Constitution to 'rights' in Para III. Every citizen of India is
fundamentally obligated to develop the scientific temper and humanism. He is
fundamentally duty bound to strive towards excellence in all spheres of individual
and collective activity so that the nation constantly rises to higher levels of endeavour
and achievements. State is, all the citizens placed together and hence though Article
51A does not expressly cast any fundamental duty on the State, the fact remains that
the duty of every citizen of India is the collective duty of the State. Any reservation,
apart from being sustainable on the constitutional anvil, must also be reasonable to
be permissible. In assessing the reasonability one of the factors to be taken into
consideration would be - whether the character and quantum of reservation would
stall or accelerate achieving the ultimate goal of excellence enabling the nationDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

constantly rising to higher levels. In the era of globalisation, where the nation as a
whole has to compete with other nations of the world so as to survive, excellence
cannot be given an unreasonable go by and certainly not compromised in its entirety.
Fundamental duties though not enforceable by a writ of the Court, yet provide a
valuable guide and aid to interpretation of constitutional and legal issues. In case of
doubt or choice; people's wish as manifested through Article 51-A, can serve as a
guide not only for resolving the issue but also for constructing or moulding the relief
to be given by the Courts. Constitutional enactment of fundamental duties, if it has to
have any meaning, must be used by Courts as a tool to tab, even a taboo, on State
action drifting away from constitutional values.
Conclusion
53. The upshot of the above discussion is that institutional reservation is not
supported by the Constitution or constitutional principles. A certain degree of
preference for students of the same Institution intending to prosecute further studies
therein is permissible on grounds of convenience, suitability and familiarity with an
educational environment.
HC-NIC Page 90 of 104 Created On Sat Aug 06 03:51:36 IST 2016 Such preference
has to be reasonable and not excessive. The preference has to be prescribed without
making an excessive or substantial departure from the rule of merit and equality. It
has to be kept within limits. Minimum standards cannot be so diluted as to become
practically non-existent. Such marginal institutional preference is tolerable at
post-graduation level but is rendered intolerable at still higher levels such as that of
super-speciality. In the case of institutions of national significance such as AIIMS
additional considerations against promoting reservation or preference of any kind
destructive of merit become relevant. One can understand a reasonable reservation
or preference being provided for at the initial stage of medical education, i.e.,
under-graduate level while seeking entry into the institute. It cannot be forgotten that
the medical graduates of AIIMS are not 'sons of the soil'. They are drawn from all
over the country. They have no moorings in Delhi. They are neither backward nor
weaker sections of the society by any standards-social, economical, regional or
physical. They were chosen for entry into the Institute because of their having
displayed and demonstrated excellence at all India level competition where
thousands participate but only a mere 40 or so are chosen. Their achieving an
all-India merit and entry in the premier institution of national importance should not
bring in a brooding sense of complacence in them. They have to continue to strive for
achieving still higher scales of excellence. Else there would be no justification for
their continuance in a premier Institution like AIIMS. In AIIMS where the best of
facilities are available for learning with best of teachers, best of medical services,
sophistication, research facilities and infrastructure, the best entrants selected from
the length and breadth of the country must come out as best of all India graduates.
We fail to understand why those who were assessed to be best in the country beforeDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

entering the portals of the Institute fall down to such low levels as having perceptibly
ceased to be best, not remaining even better, within a period of a few years spent in
the Institute. They trail behind even such candidates as fall in constitutionally
reserved categories and yet steal a march order them in claiming creamy disciplines.
The only reason which logically follows from the material available on record is that
being assured of allotment of post- graduation seats in the same institution, the zeal
for preserving excellence is lost. The students lose craving for learning. Those who
impart instructions also feel that their non-seriousness would not make any
difference for their taughts. If that is so, there is no reason why at the point of
clearing graduation and seeking entry in post-graduation courses of study they
should not give way for those who deserve better, and much better, than them. AIIMS
holds and conducts a common entrance examination for post-graduation wherein
graduates of AIIMS HC-NIC Page 91 of 104 Created On Sat Aug 06 03:51:36 IST 2016
and graduates from all over the country participate and are tested by common
standards. The AIIMS students trail in the race and yet are declared winners, thanks
to the ingenious reservation in their favour. One who justified reservation must place
on record adequate material enough, to satisfy an objective mind judicially trained, to
sustain the reservation, its extent and qualifying parameters. In the case at hand no
such material has been placed on record either by the institute or by the AIIMS
Students' Union. The facts found by Delhi High Court, well articulated by the learned
Chief Justice speaking for the Division Bench of the High Court of Delhi, visibly
demonstrate the arbitrariness and hence unsustainability of such a reservation. It
was an outcome of agitation-generated-pressure depriving application of mind
reason and objectivity of those who took the decision. No material has been placed on
record to show that Institute graduates, if asked to face all-India competition while
seeking PG seats, would get none or face feeble opportunities because of the policies
of other universities. The way merit has been made a martyr by institutional
reservation policy of AIIMS, the high hopes on which rests the foundation of AIIMS
are belied. No sound and sensible mind can accept scorers of 15-20% being declared
as passed, crossing over the queue and arraigning themselves above scorers of
60-70% and that too to sit in a course where they will be declared qualified to fight
with dreaded and complicated threats to human life. Will a less efficient post
graduate or specialist doctor be a boon to society? Is the human life so cheap as to be
entrusted to mediocre when meritorious are available? If the answer is yes, we are
cutting at the roots of nation's health and depriving right to equality of its meaning.
We have no hesitation in holding, and thereby agreeing with the Division Bench of
High Court, that reserving 33% seats for institutional candidates was in effect 100%
reservation for subjects. Coupled with 50% reservation in allocation of specialities
not exceeding overall 33% reservation integrated with 65 percentile - a complex
method, the actual working where of even the learned senior counsel for the parties
frankly confessed their inability in demonstrating before us at the time of hearing - is
a conceited gimmick and accentuated politics of pampering students, weak in merit
but mighty in strength. Such a reservation based on institutional continuity in the
absence of any relevant evidence in justification thereof is unconstitutional andDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

violative of Article 14 of the Constitution and has therefore to be struck down. The
impugned reservation, obnoxious to merit, fails to satisfy the twin test under Article
14. Having taken a common entrance test, there is no intelligible differentia which
distinguishes the institutional candidates from others; and there is no nexus sought
to be achieved with the objects of AIIMS by such HC-NIC Page 92 of 104 Created On
Sat Aug 06 03:51:36 IST 2016 reservation. Can the Court sustain and uphold such
reservation? 'Justice is the earnest and constant will to render every man his due. The
precepts of the law are these: to live honorably, to injure no other man, to render to
every man his due' - said Justinian. Giving a man his due, one of the basics of justice,
finds reflected in right to equality. Mediocracy over meritocracy cuts at the roots of
justice and hurts right to equality. Protective push or prop, by way of reservation or
classification must withstand the test of Article 14. Any over- generous approach to a
section of the beneficiaries if it has the effect of destroying another's right to
education, more so, by pushing a mediocre over a meritorious belies the hope of our
Founding Fathers on which they structured the great document of Constitution and
so must fall to the ground. To deprive a man of merit of his due, even marginally, no
rule shall sustain except by the aid of Constitution; one such situation being when
deprivation itself achieves equality subject to satisfying tests of reason, reasonability
and rational nexus with the object underlying deprivation."
29.12 In the judgment in the case of Indra Sahwney v. Union of India and others, reported in (2000)
1 SCC 168, the Hon'ble Supreme Court held in paras 64 and 65 as under:
"64. The Preamble to the Constitution of India emphasises the principle of equality as
basic to our Constitution. In Keshavananda Bharati v. State of Kerala (1973) 4 SCC
225 :
(AIR 1973 SC 1461), it was ruled that even constitutional amendments which
offended the basic structure of the Constitution would be ultra vires the basic
structure. Sikri, C.J. laid stress on the basic features enumerated in the preamble to
the Constitution and said that there were other basic features too which could be
gathered from the constitutional scheme (Para 506-A of SCC) : (Para 523 of AIR).
Equality was one of the basic features referred to in the Preamble to our Constitution.
Shelat and Grover, JJ. also referred to the basic rights referred to in the Preamble.
They specifically referred to equality (Paras 520 and 535-A of SCC) : (Paras 537 and
552 of AIR). Hegde and Shelat, JJ. also referred to the Preamble (Paras 648, 652) :
(of SCC) : (Paras 664, 668 of AIR). Ray, J. (as he then was) also did so (Para 886) (of
SCC) : (Para 902 of AIR). Jaganmohan Reddy, J. too referred to the Preamble and
the equality doctrine (Para 1159) (of SCC) : (Para 1171 of AIR). Khanna, J. accepted
this position (Para 1471) (of SCC) : (Para 1482 of AIR). Mathew, J.
HC-NIC Page 93 of 104 Created On Sat Aug 06 03:51:36 IST 2016 referred to equality as a basic
feature (Para 1621) (of SCC) :Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

(Para 1634 of AIR). Dwivedi, J. (Paras 1882, 1883) (of SCC) :
(Paras 1895, 1896 of AIR) and Chandrachud, J. (as he then was) (see Para 2086)
accepted this position.
65. What we mean to say is that Parliament and the Legislatures in this country
cannot transgress the basic feature of the Constitution, namely, the principle of
equality enshrined in Art. 14 of which Art. 16(1) is a facet. Whether creamy layer is
not excluded or whether forward castes get included in the list of Backward Classes,
the position will be the same, namely, that there will be a breach not only of Art. 14
but of the basic structure of the Constitution. The non-exclusion of the creamy layer
or the inclusion of forward castes in the list of Backward Classes will, therefore, be
totally illegal. Such an illegality offending the root of the Constitution of India cannot
be allowed to be perpetuated even by constitutional amendment.
The Kerala Legislature is, therefore, least competent to perpetuate such an illegal discrimination.
What even Parliament cannot do, the Kerala Legislature cannot achieve." 29.13 Though the learned
Advocate General relied on other authorities of the Hon'ble Supreme Court on the point of
reservations in the universities, it is to be regarded as source but not reservation as distinguished by
the Hon'ble Supreme Court in the case of A.I.I.M.S. Students Union v. A.I.I.M.S. And others,
reported in AIR 2001 SC 3262. In view of the same, we are of the view that that would not render
any assistance to the respondents in support of their case.
29.14 Over and above the above judgments, we would like to refer to the judgments relied on by the
learned Advocate General as under:
29.15 Learned Advocate General has also placed reliance on HC-NIC Page 94 of 104
Created On Sat Aug 06 03:51:36 IST 2016 the judgment of the Hon'ble Supreme
Court in the case of Ashoka Kumar Thakur v. State of Bihar and others, reported in
(1995) 5 SCC 403. In the aforesaid judgment, the criteria for identification and
exclusion of creamy layer as directed by the Hon'ble Supreme Court in the case of
Indra Sahwney (Mandal Case) fell for consideration before the Hon'ble Supreme
Court. In the aforesaid case, the economic criteria adopted for identifying the creamy
layer as per the Office Memorandum dated 8.9.93 was approved. But it is to be noted
that such identification of creamy layer is within the group of permitted category of
reservation in view of the provision under Article 16(4) of the Constitution of India.
29.16 In the case of Duraisamy and another v. State of T.N. and others, reported in
(2001) 2 SCC 538, reservation of 50% of seats for in-service candidates for admission
to Diploma and Degree courses fell for consideration before the Hon'ble Supreme
Court and the Hon'ble Supreme Court held that in-service candidates could not, on
the basis of merit be considered against the seats earmarked for non-service
candidates. By applying the principle of doctrine of purposive construction,
distinction was drawn between in-Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

service and non-service candidates in the medical colleges. 29.17 In support of the argument that
10% of quota allocated under the impugned Ordinance cannot be said to be in violation of the
judgment of the Hon'ble Supreme Court in the case of Indra HC-NIC Page 95 of 104 Created On Sat
Aug 06 03:51:36 IST 2016 Sawhney without crossing 50% ceiling, the learned Advocate General
relied on the judgment of the Hon'ble Supreme Court in the case of Union of India and Anr. v.
National Federation of the Blind and others, reported in (2013) 10 SCC 772, wherein, the Hon'ble
Supreme Court has considered with regard to 3% reservation for Physically Handicapped as
required under Persons with Disabilities (Equal Opportunities, Protection of Rights and Full
Participation) Act, 1995. In the said judgment, the Hon'ble Supreme Court has held that ceiling of
50% reservation mandated in Indra Sahwney case applies only to reservation in favour of other
backward classes under Article 16(4) of the Constitution, whereas reservation in favour of persons
with disabilities is horizontal and is under Article 16(1) of the Constitution. Thus, it is held by the
Hon'ble Supreme Court that it will not violate 50% of ceiling as mandated in the case of Indra
Sawhney vs. Union of India and others, etc. reported in (1992) Suppl. 3 SCC 217.
29.18 Having regard to the nature of reservation which fell for consideration in the aforesaid
judgment, we are of the view that such ratio laid down in the aforesaid judgment would not come to
the aid of the respondents.
29.19 Reliance is also placed by the learned Advocate General on the judgment of the Hon'ble
Supreme Court in the case of National Legal Services Authority v. Union of India and HC-NIC Page
96 of 104 Created On Sat Aug 06 03:51:36 IST 2016 others, reported in (2014) 5 SCC 438, wherein
the Hon'ble Supreme Court has considered the rights of transgenders and issued directions to the
Central Government and the State Governments to extend all the benefits available to Socially and
Educationally Backward Class/Other Backward Classes.
29.20 In the judgment in the case of State of Punjab and others v. Rafiq Masih (White Washer) and
others, reported in (2015) 4 SCC 334, relied on by the learned Advocate General, the Hon'ble
Supreme Court has considered the embodiment of the doctrine of equality in Articles 38, 39, 39-A,
43 and 46 contained in Part IV of the Constitution, dealing with the directive principles of State
Policy. In the aforesaid judgment, the Hon'ble Supreme Court has held in para-9 as under:
"9. The doctrine of equality is a dynamic and evolving concept having many
dimensions. The embodiment of the doctrine of equality can be found in Articles 14
to 18 contained in Part III of the Constitution of India, dealing with "fundamental
rights".
These articles of the Constitution, besides assuring equality before the law and equal protection of
the laws, also disallow discrimination with the object of achieving equality, in matters of
employment; abolish untouchability, to upgrade the social status of an ostracised section of the
society; and extinguish titles, to scale down the status of a section of the society, with such
appellations. The embodiment of the doctrine of equality, can also be found in Articles 38, 39, 39-A,
43 and 46 contained in Part IV of the Constitution of India, dealing with the "directive principles of
State policy". These articles of the Constitution of India contain a mandate to the State requiring itDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

to assure a social order providing justice - social, economic and political, by inter alia minimising
monetary inequalities, and by securing the right to adequate means of livelihood, and by providing
for adequate wages so as to ensure, an appropriate HC-NIC Page 97 of 104 Created On Sat Aug 06
03:51:36 IST 2016 standard of life, and by promoting economic interests of the weaker sections."
29.21 Learned Advocate General placed reliance on the judgment of the Hon'ble Supreme Court in
the case of Rajeev Kumar Gupta & Others v. Union of India & others, reported in 2016 SCC Online
SC 651,wherein, the Hon'ble Supreme Court has recently held that the principle laid down in Indra
Sawhney is applicable only when the State seek to give preferential treatment in the matter of
employment under State to certain classes of citizens identified to be a backward class. But Article
16(4) of the Constitution does not disable the State from providing differential treatment to other
classes of citizens under Article 16(1) if they otherwise deserve such treatment. In the aforesaid case,
the Hon'ble Supreme Court was considering the claim of reservation of seats for persons with
disability under the provisions of the Persons with Disabilities (Equal Opportunities, Protection of
Rights and Full Participation) Act, 1995. 29.22 All the authorities relied on by the learned Advocate
General referred above relate to reservation to backward class under Article 16(4) or reservation
relating to disabled persons within the meaning of the Persons with Disabilities (Equal
Opportunities, Protection of Rights and Full Participation) Act, 1995. As such, we are of the view
that the aforesaid judgments are of no help to the case of the respondents as much as we have held
that 10% of the group in HC-NIC Page 98 of 104 Created On Sat Aug 06 03:51:36 IST 2016
unreserved category cannot be considered as homogeneous group. In view of the fact that the very
group is identified based on economic criteria which is disapproved by the Hon'ble Supreme Court
in the case of Indra Sahwney (supra), for the purpose of effecting reservations for backward classes
under Article 16(4) of the Constitution, we are of the considered view that the said ratio holds good
equally for identifying the group of 10% within the class of unreserved category.
29.23 Mr. Shelat, learned Sr. Advocate, appearing on behalf of the petitioners also placed reliance
on the judgment of a Division Bench of this Court in the case of State of Gujarat v. Bindu Niranjan
Doctor & Ors, rendered in Letters Patent Appeal No. 698 of 1994, dated 29th December, 1994. In
the aforesaid case, challenge was to the reservation of 2% seats to the medical colleges in the State of
Gujarat for economically backward classes who live below poverty line and whose total income does
not exceed Rs. 11000/- per annum who are not covered under the category of SC, ST, NT DNT and
SEBC. The said reservation of 2% seats was in addition to 27% seats reserved for SEBC. When it was
challenged on the ground that the said reservation was contrary to the judgment rendered in the
Mandal Case, that is, Indra Sawhney v. Union of India, reported in 1993 SC 477, a Division Bench of
this Court Court held it to be illegal by considering the reservation based on economic criteria. The
view taken by a Division Bench of this Court also supports the case of HC-NIC Page 99 of 104
Created On Sat Aug 06 03:51:36 IST 2016 the petitioners in this batch of petitions.
29.24 For the aforesaid reasons and in view of the authoritative pronouncements of the Hon'ble
Supreme Court which we have referred above, we answer that reservation of 10% seats based on
economic criteria by exceeding the limit of 50% is illegal and contrary to the ratio laid down by the
Hon'ble Supreme Court in the case of Indra Sawhney vs. Union of India, reported in (1992) Supp. 3
SCC 217.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

30. Point No. 3:
Whether, the State is justified in issuing the impugned Ordinance providing
reservation of 10% of available seats for admissions and appointments in services in
favour of economically weaker sections of unreserved category, without carrying out
any detailed scientific and technical impact assessment study by the experts and
without collecting quantifiable and empirical data?
30.1 With reference to the above point, it is the specific case of the petitioners that the
impugned Ordinance is issued providing reservation of 10% of available seats in
educational institutions and to fill posts in the services under the State without
carrying out detailed scientific and technical impact assessment study by experts and
without collecting quantifiable and empirical data. It is stated in HC-NIC Page 100 of
104 Created On Sat Aug 06 03:51:36 IST 2016 the affidavit in reply filed by the State
that based on representations numbering about 225, High Power Committee
consisting of 5 Hon'ble Ministers recommended the reservation of 10% to weaker
sections in unreserved category. It is also the contention of the learned Advocate
General that since such reservation is not traceable to provision under Articles 15 and
16 of the Constitution of India, no such technical impact assessment study by experts
and quantifiable and empirical data is required. In this regard, it is relevant to note
that apart from the fact that the respondent-State is not empowered under the
constitutional scheme to make such law for reservation exclusively for economically
weaker sections of unreserved category, we are of the view that there is no technical
impact assessment study and quantifiable and empirical data before arriving at the
conclusion that such reservation is necessary. When equality is the rule of law under
the scheme of Article 14, for creating group for the purpose of providing reservation,
unless detailed scientific and technical study is made, no such reservation can be
permitted. Except by referring to representations based on which the High Powered
Committee has recommended reservation, there is no other scientific data collected
by the Committee for making recommendations for reservation. In this regard, it is
relevant to refer to the judgment of the Hon'ble Supreme Court in the case of Atyant
Pichhara Barg Chhatra Sangh and Anr. v. Jharkhand State Vaishya Federation and
Ors.reported in (2006) 6 SCC 718. In the aforesaid judgment, while dealing with the
affirmative action under Articles 15(4) and 16(4) of HC-NIC Page 101 of 104 Created
On Sat Aug 06 03:51:36 IST 2016 the Constitution, the Hon'ble Supreme Court in
paras 22 and 23 held as under:-
"22. The State has failed to show any new circumstances except for a bald statement
that the same was done after careful application of mind and due statement that the
same was done after careful application of mind and due deliberation by the highest
policy-making body I.e the Council of Ministers. There are no materials or empirical
data to indicate that the circumstances had been changed and the State has not
undertaken any study, research or work. In such circumstances to merely suggest
that the Council of Ministers had applied their minds and had reached a decision isDayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

arbitrary and unreasonable.
23. Mandal Commission case has specifically noted that there is no constitutioal bar
to a State categorising the Backward Classes as backward and more Backward Class.
The State of Jharkhand by its actions seeks to disempower communities that have
been extended the benefits of reservation after a conscious adoption of the Bihar Act.
What GO No. 5800 seeks to do by combining the Extremely Backward Class and
Backward Class into one group is to treat unequals as equals thus violating the notion
of substantive equality and Article 14 of the Constitution of India bringing it within
the purview of judicial review by the Court."
From the aforesaid judgment also it is clear that unless there is empirical study on the subject, there
cannot be any casual approach in the matter relating to separation of group for affirmative action
contrary to the rule of equality guaranteed under Article 14 of the Constitution. Thus, the above
observations in the judgment referred above, fortify the case of the petitioners. In the above view of
the matter, we answer the point no. 3 in favour of the petitioners by holding that the impugned
Ordinance is based on the recommendations of the High Powered Committee which has not
HC-NIC Page 102 of 104 Created On Sat Aug 06 03:51:36 IST 2016 done any scientific analysis nor
did it do any empirical study for the purpose of providing reservation to the extent of 10% in the
educational institutions and in appointments and posts in services under the State to the weaker
sections of unreserved category.
31. Point No.5:
Whether, the State is justified in issuing the impugned Ordinance on 1.5.2016, when
the Government Resolutions dated 7.10.2015 and 5.4.2016 granting financial
assistance to the students of economically weaker sections of unreserved category are
in existence and that too without waiting for result of such benefits conferred under
the resolutions?
31.1 With reference to the above point, it is the case of the petitioners that the
government has issued resolutions on 5.4.2016 and 7.5.2016 granting financial
assistance to the students belonging to economically weaker sections of unreserved
category but without waiting for any period to assess the benefits from such
Government Resolutions, the impugned Ordinance is issued in haste. But having
regard to our findings recorded on point nos. 1 to 4, we are of the view that there is no
need to adjudicate on the said issue any further without going into the merits of such
contention, and having regard to the findings recorded on the other points, we are of
the view that no other findings are required to be recorded on this point.
HC-NIC Page 103 of 104 Created On Sat Aug 06 03:51:36 IST 2016
32. In view of the aforesaid discussion and reasons recorded herein above, we are of the view that
the impugned Ordinance is fit to be quashed and set aside. Accordingly, these petitions are allowed.Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

The impugned Ordinance No. 1 of 2016 titled as "the Gujarat Unreserved Economically Weaker
Sections (Reservation of Seats in Educational Institutions in the State and of Appointments and
Posts in services under the State) Ordinance, 2016, issued by the State Government is hereby
quashed and set aside by declaring the same as unconstitutional and contrary to fundamental rights
guaranteed to the petitioners under Articles 13(2), 14, 15 and 16 of the Constitution of India.
Consequently, we direct that if any admissions are proposed by notifying 10% seats for weaker
section of unreserved category under the impugned Ordinance, they shall be treated as not reserved
and admissions to be made by treating such quota in unreserved category.
(R. SUBHASH REDDY, CJ) (VIPUL M. PANCHOLI, J.) pirzada HC-NIC Page 104 of 104 Created On
Sat Aug 06 03:51:36 IST 2016Dayaram Khemkaran Verma S/O Khemkaran ... vs State Of Gujarat & 1....Opponents on 4 August, 2016

