Anjalai vs Government Of Tamil Nadu on 30 October, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                             HCP(MD)No.921 of 2023
                          BEFORE THE MADURAI BENCH OF MADRAS HIGH COURT
                                                 DATED: 30.10.2023
                                                      CORAM:
                                    THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                         and
                                  THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                             H.C.P.(MD)No.921 of 2023
                     Anjalai                                                        : Petitioner
                                                          Vs.
                     1.Government of Tamil Nadu,
                       Rep. By its the Additional Chief Secretary
                        to Government,
                       Home, Prohibition and Excise (XVI) Department,
                       Fort St. George, Chennai – 600 009.
                     2.The District Collector and District Magistrate,
                       Thanjavur District, Thanjavur.
                     3.The Superintendent,
                       Central Prison,
                      Tiruchirappalli.                                   : Respondents
                     PRAYER: Petition filed under Article 226 of the Constitution of India to
                     issue a writ of Habeas Corpus, calling for the entire records connected with
                     the detention order of the 2nd respondent in Detention Order No.31/2023
                     dated 30.05.2023 and detained at Central Prison, Tiruchirappalli and quash
                     the same and direct the respondents to produce the body or person of
                     Page 1 of 10
https://www.mhc.tn.gov.in/judis
                                                                                 HCP(MD)No.921 of 2023
                     petitioner's son namely Maniraj, Male aged about 25/2023 Son ofAnjalai vs Government Of Tamil Nadu on 30 October, 2023

                     Rengasamy, now confined at Central Prison, Tiruchirappalli and set him at
                     liberty forthwith.
                                             For Petitioner    : Mr.B.Jameelarasu
                                             For Respondents : Mr.A.Thiruvadi Kumar
                                                                Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of brevity] was listed in the Admission Board on 25.07.2023, a
Hon'ble Coordinate Division Bench made the following order in the Admission Board:
https://www.mhc.tn.gov.in/judis
2. It has now become necessary to set out a thumbnail sketch of factual matrix and we do so in the
paragraphs infra.
3. Today, the captioned matter is in the Final Hearing Board.
4. Mr.B.Jameelarasu, learned counsel on record for petitioner and Mr.A.Thiruvadi Kumar, learned
State Additional Public Prosecutor for all respondents are before us.
5. Captioned HCP has been filed by the mother of the detenu assailing a 'preventive detention order
dated 30.05.2023 bearing P.D.No. 31/2023' [hereinafter 'impugned preventive detention order' for
the sake of brevity and convenience]. To be noted, sponsoring authority has not been arrayed as a
respondent but we find that 'Station House Officer of Vattathikkottai Police Station' is the
sponsoring authority [hereinafter 'Sponsoring Authority' for the sake of convenience and clarity]
and second respondent is the detaining authority as impugned preventive detention order has been
made by second respondent.
https://www.mhc.tn.gov.in/judis
6. Impugned preventive detention order has been made under 'The Tamil Nadu Prevention of
Dangerous Activities of Bootleggers, Cyber law offenders, Drug-offenders, Forest-offenders,
Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders, Slum-grabbers and Video
Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity] on the premise that the detenu is a 'Goonda' within the meaning of Section
2(f) of Act 14 of 1982.
7. There is no adverse case. The ground case which constitutes sole substratum of the impugned
preventive detention order is Crime No.225 of 2023 on the file of Vattathikkottai Police Station
registered under Sections 147, 148, 294(b), 324 and 307 of 'The Indian Penal Code (45 of 1860)'
[hereinafter 'IPC' for the sake of convenience and clarity] read with Sections 3(1)(r), 3(1)(s), 3(2)(va)Anjalai vs Government Of Tamil Nadu on 30 October, 2023

of 'Scheduled Castes and Scheduled Tribes (Prevention of Atrocities) Amendment Act, 2015'
[hereinafter 'SC/ST (POA) Act' for the sake of convenience and clarity], which was subsequently
altered into Sections 147, 148, 294(b), 324, 307 and 302 IPC read with Sections 3(1)(r), 3(1)(s),
3(2)(v) of SC/ST (POA) Act. https://www.mhc.tn.gov.in/judis Considering the nature of the
challenge to the impugned detention order, it is not necessary to delve into the factual matrix of the
case.
8. In the support affidavit qua captioned HCP several grounds have been raised but learned Counsel
for petitioner predicated his campaign against the impugned Preventive Detention Order on the
point that the detenu was arrested on 31.03.2023 but the impugned preventive detention order has
been made only on 30.05.2023 resulting in live and proximate link between grounds and purpose of
detention getting snapped.
9. Mr.Thiruvadi Kumar, learned State Additional Public Prosecutor, submits to the contrary by
saying that materials had to be collected and time was consumed in this exercise. Considering the
facts / circumstances of the case on hand and nature of ground case, we find that this explanation of
learned Prosecutor is unacceptable.
10. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case https://www.mhc.tn.gov.in/judis arose under 'Prevention of Illicit Traffic in Narcotic
Drugs and Psychotropic Substances Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in
Tirupura, wherein after considering a proposal by a Sponsoring Authority and after noticing the
trajectory the matter took, Hon'ble Supreme Court held that the 'live and proximate link between
grounds of detention and purpose of detention snapping' point should be examined on a case to case
basis. Hon'ble Supreme Court has held in Banik case law that this point has two facets. One facet is
'unreasonable delay' and the other facet is 'unexplained delay'. We find that the captioned matter
falls under latter facet i.e., unexplained delay.
11. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court being
2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of https://www.mhc.tn.gov.in/judis Madras High Court being 2023:MHC:1159 and a series
of similar orders in HCP cases.
12. To be noted, the impugned preventive detention order is predicated on a solitary case viz., Crime
No.225 of 2023 on the file of Dindigul Taluk Police Station registered under Sections 147, 148,
294(b), 324 and 307 of IPC read with Sections 3(1)(r), 3(1)(s), 3(2)(va) of of SC/ST (POA) Act, which
was subsequently altered into Sections 147, 148, 294(b), 324, 307 and 302 IPC read with Sections
3(1)(r), 3(1)(s), 3(2)(v) of SC/ST (POA) Act and therefore this solitary case is the sole substratum of
the impugned preventive detention order.Anjalai vs Government Of Tamil Nadu on 30 October, 2023

13. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
14. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
30.05.2023 bearing reference P.D.No. 31/2023 made by the second respondent is set aside and the
detenu Thiru.Maniraj, male, aged 25 years, son of Thiru.Rengasamy, is directed to
https://www.mhc.tn.gov.in/judis be set at liberty forthwith, if not required in connection with any
other case / cases. There shall be no order as to costs.
                                                                   [M.S.,J.] & [R.S.V.,J.]
                     vsm                                                  30.10.2023
                     Index        : Yes
                     Neutral Citation : Yes
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison,
Tiruchirappalli.
https://www.mhc.tn.gov.in/judis To
1.The Additional Chief Secretary to Government, Government of Tamil Nadu, Home, Prohibition
and Excise (XVI) Department, Fort St. George, Chennai – 600 009.
2.The District Collector and District Magistrate, Thanjavur District, Thanjavur.
3.The Superintendent, Central Prison, Tiruchirappalli.
4.The Additional Public Prosecutor, Madurai Bench of Madras High Court, Madurai.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J.
and R.SAKTHIVEL, J.
vsm 30.10.2023 https://www.mhc.tn.gov.in/judisAnjalai vs Government Of Tamil Nadu on 30 October, 2023

