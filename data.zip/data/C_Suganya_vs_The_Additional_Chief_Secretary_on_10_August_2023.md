C.Suganya vs The Additional Chief Secretary on 10 August,
2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:3708
                                                                                   H.C.P.No.747 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                       DATED : 10.08.2023
                                                             CORAM
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                      and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                      H.C.P.No.747 of 2023
                     C.Suganya
                     W/o.Veeramani                                                    .. Petitioner
                                                                 Vs.
                     1.           The Additional Chief Secretary
                                  Government of Tamil Nadu
                                  Home, Prohibition and Excise Department
                                  Secretariat, Chennai-600 009.
                     2.           The District Collector and District Magistrate
                                  Tiruvannamalai District
                                  Tiruvannamalai.
                     3.           The Superintendent of Police
                                  Tiruvannamalai
                                  Tiruvannamalai District.
                     4.           The Superintendent of Prison
                                  Central Prison, Vellore.
                     5.           State By
                                  Inspector of Police
                                  Arni Town Police Station
                                  Tiruvannamalai District.                         ..Respondents
                     Page Nos.1/9C.Suganya vs The Additional Chief Secretary on 10 August, 2023

https://www.mhc.tn.gov.in/judis
                                                                                       H.C.P.No.747 of 2023
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ order or direction in the nature of WRIT OF HABEAS
                     CORPUS, calling for the records pertaining to the order of detention passed
                     by the second respondent herein made in D.O.No.30/2023-C2 dated
                     04.03.2023 and to set aside the same and directing the fourth respondent to
                     produce the detenu my Husband Viz, Veeramani, aged 32 years,
                     S/o.Periyasamy now confined in Central prison, Vellore before this Honble
                     Court and thereby setting him at liberty.
                                  For Petitioner           :     Mr.Nagoor Moideen
                                                                 representing Mr.R.Krishnakumar
                                  For Respondents          :     Mr.A.Gokulakrishnan
                                                                 Additional Public Prosecutor
                                                           ORDER
[Order of the Court was made by M.SUNDAR, J.,] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
01.06.2023, this Court made the following order:
M.SUNDAR, J.
and R.SAKTHIVEL, J.
(Order of the Court was made by M.SUNDAR, J.,) Captioned Habeas Corpus Petition
has been filed in this https://www.mhc.tn.gov.in/judis Court on 26.04.2023 inter
alia assailing a detention order dated 04.03.2023 bearing reference
D.O.No.30/2023-C2 made by 'second respondent' [hereinafter 'Detaining Authority'
for the sake of convenience and clarity]. To be noted, fifth respondent is the
Sponsoring Authority.
2. To be noted, wife of the detenu is the petitioner.
3. Mr.C.Loganathan learned counsel on record for habeas corpus petitioner is before us. Learned
counsel for petitioner submits that ground case qua the detenu was registered for Man Missing and
subsequently altered to Section 364A of 'Indian Penal Code, 1860 (Act 45 of 1860)' ['IPC' for brevity]
and again altered to Sections 147, 364A, 302, 201 read with 120(B) of IPC in Crime No.10 of 2023 on
the file of Arani Town Police Station.
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders,
Sexual-offenders, Slum- grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)'
[hereinafter 'Act 14 of 1982' for the sake of convenience and clarity].C.Suganya vs The Additional Chief Secretary on 10 August, 2023

5. The detention order has been assailed inter alia on the ground that the grounds of detention in
Tamil was not served on the detenu, which prevented the detenu from making an effective
representation.
6. Prima facie case made out for admission. Admit. Issue https://www.mhc.tn.gov.in/judis Rule nisi
returnable by four weeks.
7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'
2. The aforementioned Admission Board order captures the essentials that are imperative for
appreciating this order and therefore, we are not setting out the same again. However, short forms,
short references and abbreviations used in the Admission Board order will continue to be used in
the instant order also for the sake of brevity, convenience and clarity.
3. Mr.M.Nagoor Moideen, learned counsel representing the counsel on record for petitioner and
Mr.A.Gokulakrishnan, learned State Additional Public Prosecutor for all respondents are before us.
4. At the time of admission i.e., in the Admission Board, the point that the grounds of detention in
Tamil was not served on the detenu, which prevented the detenu from making an effective
representation was urged but in the final hearing Board today, learned counsel for petitioner
predicated his campaign against the impugned preventive detention order on one point
https://www.mhc.tn.gov.in/judis and that one point is 'live and proximate link' between the
grounds of detention and purpose of detention has snapped as date of arrest in the ground case is
19.01.2023 but the impugned preventive detention order has been made only on 04.03.2023.
5. Mr.A.Gokulakrishnan, learned State Additional Public Prosecutor, submits to the contrary by
saying that materials had to be collected and time was consumed in this exercise. Considering the
facts / circumstances of the case on hand and nature of ground case, we find that this explanation of
learned Prosecutor is unacceptable.
6. We remind ourselves of Sushanta Kumar Banik's case [Sushanta Kumar Banik Vs. State of
Tripura & others reported in 2022 LiveLaw (SC) 813 : 2022 SCC OnLine SC 1333]. To be noted,
Banik case law arose under 'Prevention of Illicit Traffic in Narcotic Drugs and Psychotropic
Substances Act, 1988' [hereinafter 'PIT NDPS Act' for the sake of brevity] in Tirupura, wherein after
considering a proposal by a Sponsoring Authority and after noticing the trajectory the matter took,
Hon'ble Supreme Court https://www.mhc.tn.gov.in/judis held that the 'live and proximate link
between grounds of detention and purpose of detention snapping' point should be examined on a
case to case basis. Hon'ble Supreme Court has held in Banik case law that this point has two facets.
One facet is 'unreasonable delay' and the other facet is 'unexplained delay'. We find that the
captioned matter falls under latter facet i.e., unexplained delay.
7. To be noted, Banik case has been respectfully followed by this Court in Gomathi Vs.The Principal
Secretary to Government and others reported vide Neutral Citation of Madras High Court beingC.Suganya vs The Additional Chief Secretary on 10 August, 2023

2023/MHC/334, Sadik Basha Yusuf Vs. The State of Tamil Nadu and others reported vide Neutral
Citation of Madras High Court being 2023/MHC/733, Sangeetha Vs. The Secretary to the
Government and others reported vide Neutral Citation of Madras High Court being
2023:MHC:1110, N.Anitha Vs. The Secretary to Government and others reported vide Neutral
Citation of Madras High Court being 2023:MHC:1159 and a series of other orders in HCP cases.
8. To be noted, the sole substratum of the impugned preventive https://www.mhc.tn.gov.in/judis
detention order is a solitary case viz., Crime No.10 of 2023 on the file of Arni Town Police Station
registered for 'Man Missing' and subsequently altered into Section 364A of IPC and again altered
into Sections 147, 364A, 302, 201 of IPC read with 120(B) of IPC.
9. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
10. Apropos, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
04.03.2023 bearing reference D.O.No.30/2023-C2 made by the second respondent is set aside and
the detenu Thiru.Veeramani, male, aged 32, son of Thiru.Periyasami, is directed to be set at liberty
forthwith, if not required in connection with any other case / cases. There shall be no order as to
costs.
                                                                     (M.S.,J.)         (R.S.V.,J.)
                                                                            10.08.2023
                     Index : Yes
                     Speaking
                     Neutral Citation : Yes
                     mk
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Vellore.
https://www.mhc.tn.gov.in/judis To
1. The Additional Chief Secretary Government of Tamil Nadu Home, Prohibition and Excise
Department Secretariat, Chennai-600 009.
2. The District Collector and District Magistrate Tiruvannamalai District Tiruvannamalai.
3. The Superintendent of Police Tiruvannamalai Tiruvannamalai District.
4. The Superintendent of Prison Central Prison, Vellore.
5. State By Inspector of Police Arni Town Police Station Tiruvannamalai District.
6. The Public Prosecutor High Court, Madras.C.Suganya vs The Additional Chief Secretary on 10 August, 2023

https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., mk 10.08.2023
https://www.mhc.tn.gov.in/judisC.Suganya vs The Additional Chief Secretary on 10 August, 2023

