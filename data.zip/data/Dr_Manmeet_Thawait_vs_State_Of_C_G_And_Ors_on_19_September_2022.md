Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September,
2022
Bench: Arup Kumar Goswami, Parth Prateem Sahu
                                    1
                                                                         AFR
                 HIGH COURT OF CHHATTISGARH, BILASPUR
                          WPC No. 591 of 2012
Guru Ghasidas Sahitya Avam Sanskriti Academy, through its President:
P.R.Gahine son of Late Sahas Ram Gahine, aged about 73 years, office at
Guru Ghasidas Colony, Sanskritik Bhawan, New Rajendra Nagar, Raipur,
Chhattisgarh.
                                                                 ---Petitioner
                                 Versus
1.   State of Chhattisgarh, through the Secretary, Department of General
Administration, Mantralaya, DKS Bhawan, Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
                                                           ----Respondents
For Petitioner             : Mr. Brijendra Singh and Mr. Shyam Sunder Lal
                             Tekchandani, Advocates.
For Respondents            : Mr. S.C.Verma, Advocate General alongwith Mr.
                             Vikram Sharma and Mr. Gagan Tiwari, Deputy
                             Government Advocates.
For Intervenors            : Dr. K.S.Chauhan, Senior Advocate assisted by
                             Mr. Ajit Kumar Ekka, Mr. Ravi Prakash, Mr.
                             Ashish Kumar Beck, Mr. Lekh Ram Dhruw and
                             Mr. R.V.Rajwade, Mr. Anchal Kumar Matre,
                             Advocates.
                              WPC/592/2012
1. P.R.Khute son of Shri Kalap Ram Khunte (Ex Member of Parliament), aged
about 62 years, R/o A-12, Palas Vihar, New Purena Mahavir Nagar, Raipur,
Chhattisgarh.
2. Smt. Padma Manhar wife of Shri Ghanshyam Manhar (Member of
Legislative Assembly, Chhattisgarh), aged about 36 years, R/o Sarangarh,
District Raigarh.
                                                                ---Petitioners
                                       2
                                   Versus
1.   State   of Chhattisgarh, through the Secretary, Department of General
Administration, Mantralaya, DKS Bhawan, Raipur, Chhattisgarh.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

2. The Chief Secretary, State of Chhattisgarh, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
                                                           ----Respondents
For Petitioner               : Mr. Brijendra Singh and Mr. Shyam Sunder Lal
                              Tekchandani, Advocates.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                              Mr. Vikram Sharma and Mr. Gagan Tiwari,
                              Deputy Government Advocates.
                               WPC/593/2012
Satyanam Seva Sangh, Raipur, Chhattisgarh, through: it's President Shri
Sundar Lal Lahre, son of Shri D.R.Lahre, aged about 64 years, R/o Veer
Shivaji Ward No. 7, Khamtarai, Raipur, Chhattisgarh.
                                                                ---Petitioner
                                   Versus
1.   State of Chhattisgarh, through the Secretary, Department of General
Administration, Mantralaya, DKS Bhawan, Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
                                                           ----Respondents
For Petitioner               : Mr. Brijendra Singh and Mr. Shyam Sunder Lal
                              Tekchandani, Advocates.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                              Mr. Vikram Sharma and Mr. Gagan Tiwari,
                              Deputy Government Advocates.
                               WPC/594/2012
1. H.R.Bhatpahare S/o Late Panch Ram Bhatpahare, aged about 77 years,
R/o Om Nagar, Jarhabhatha, Bilaspur, Chhattisgarh.
2. Om Prakash Gangotri S/o Late Bhairo Dayal Gangotri, aged about 64
years, R/o Main Road, Dayalband, Bilaspur, Chhattisgarh.
3. Ms. Pushpa Adile D/o Shri Basant Kumar Adile, aged about 25 years, R/o
                                       3
Ravi Nagar, Sindhi Colony, Bilaspur, Chhattisgarh.
4. Mahendra Gangotri S/o Shri Om Prakash Gangotri, aged about 35 years,
R/o Main Road, Dayalband, Bilaspur.
                                                                  ---Petitioners
                                   Versus
1.   State   of Chhattisgarh, through the Secretary, Department of General
Administration, Mantralaya, DKS Bhawan, Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
                                                               ----Respondents
For Petitioner               : Mr. N. Naha Roy, Advocate.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                              Mr. Vikram Sharma and Mr. Gagan Tiwari,
                              Deputy Government Advocates.
                               WPC/652/2012
1. Chandra Prakash Jangde S/o Shri Fagu Ram Jangde, aged about 45
years, resident of Balram Talkies Road, Nehru Nagar, Bilaspur, Chhattisgarh.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

2. Ram Ratan Jangde S/o Late Moti Lal Jagde, aged about 73 years, resident
of Gurughasi Das School, Nehru Nagar, Bilaspur, Chhattisgarh.
                                                                  ---Petitioners
                                   Versus
1. State of Chhattisgarh, through Chief Secretary, DKS Building, Mantralaya,
Raipur, Chhattisgarh.
2. State of Chhattisgarh, through Secretary, Scheduled Caste, Scheduled
Tribal Welfare Department, DKS Building, Mantralaya, Raipur, Chhattisgarh.
3. State of Chhattisgarh, through Assistant Commissioner, Scheduled Caste,
Scheduled Tribal Welfare Department, Bilaspur, Chhattisgarh.
                                                               ----Respondents
For Petitioner               : Mr. Anchal Kumar Matre, Advocate.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                              Mr. Vikram Sharma and Mr. Gagan Tiwari,
                              Deputy Government Advocates.
                              WPC/653/2012
Ramayan Lal Jangde S/o Late Moti Lal Jangde, aged about 63 years,
                                        4
Resident of Adile Chouk, Purani Basti, Korba, Chhattisgarh.
                                                                  ---Petitioner
                                    Versus
1. State of Chhattisgarh, through Chief Secretary, Chhattisgarh State, DKS
Building, Mantralaya, Raipur, Chhattisgarh.
2. State of Chhattisgarh, through Secretary, Scheduled Caste, Scheduled
Tribal Welfare Department, DKS Building, Mantralaya, Raipur, Chhattisgarh.
                                                              ----Respondents
For Petitioner               : Mr. Anchal Kumar Matre, Advocate.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                                Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                Deputy Government Advocates.
                                WPC/936/2012
Shri Ram Baghel S/o Sadhram Baghel, aged about 35 years, R/o Vijeta
Complex, Shop No. 14-15, Shastri Bazar, Raipur, Tahsil and District Raipur,
Chhattisgarh.
                                                                  ---Petitioner
                                    Versus
1. State of Chhattisgarh, through General Administrative Department, DKS
Bhawan, Raipur, Chhattisgarh.
2. Union of India, through its Secretary, Ministry of Personnel, Public
Grievances and Pension, Department of Personnel & Training, Shastri
Bhawan, New Delhi.
                                                              ----Respondents
For Petitioner               : Mr. Anumeh Shrivastava and Mr. Akash
                                Shrivastava, Advocates.
For Respondent No. 1         : Mr. S.C.Verma, Advocate General alongwith
                                Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                Deputy Government Advocates.
For Respondent No. 2            Mr. Krishna Gopal Yadav and Ms. Anmol
                                Sharma, Central Government counsel.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

                                WPC/2072/2014
1. Arun Kumar Pathak, Late Shri Ramesh Prasad Pathak, aged about 39
years, R/o village Dhangaon, Thana Gaurella, District Bilaspur, Chhattisgarh.
                                         5
2. Bhola Singh, Shri Sheshnath Singh, aged about 31 years, R/o Shivnandan
Nagar,   Sector-1,    WRS    Colony,    Thana   Khamtarai,    District   Raipur,
Chhattisgarh.
3. Ranjit Pratap Singh, Shri Virendra Singh, aged about 30 years, R/o Indira
Nagar, Zone-1, Thana Purana Bhilai, District Durg, Chhattisgarh.
4. Pushpendra Tiwari, Shri Hemdatta Tiwari, Aged about 32 years, R/o 23,
Sundar   Nagar,      Thana   Dindayal   Upadhyay   Nagar,     District   Raipur,
Chhattisgarh.
                                                                   ---Petitioners
                                   Versus
1.   State      of Chhattisgarh, through Secretary, Department of General
Administration, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, Mahanadi Bhawan,
Naya Raipur, Chhattisgarh.
                                                              ----Respondents
For Petitioners               : Mr. Vinay Pandey, Advocate.
For Respondents               : Mr. S.C.Verma, Advocate General alongwith
                               Mr. Vikram Sharma and Mr. Gagan Tiwari,
                               Deputy Government Advocates.
                               WPS/4240/2014
Chhattisgarh Anusuchit Jati/Janjati Chhatra Sangathan (Student Union)
(Registration No. 19557/88) having it's office at Tandan Niwas, Chourasiya
Colony, Santoshi Nagar, Raipur, Chhattisgarh, through: it's President
Yashwant Bandhe, son of Shri Brij Lal Bandhe, aged about 25 years, R/o
Village Matwali, Post Sundarvan, PS Palari, Civil and Revenue District
Baloda-Bazar-Bhatapara, Chhattisgarh.
                                                                    ---Petitioner
                                   Versus
1. State of Chhattisgarh, through the Secretary, Tribal Welfare Department,
Mantralaya, Mahanadi Bhawan, New Raipur, Chhattisgarh.
2. Commissioner, Adim Jati Tatha Anusuchit Jati vikas, Chhattisgarh, Raipur,
Chhattisgarh.
                                                              ----Respondents
                                        6
For Petitioner                 : Mr. Rahul Agrawal, Advocate.
For Respondents                : Mr. S.C.Verma, Advocate General alongwith
                                Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                Deputy Government Advocates.
                                WPS/5578/2012
1. Sparsh Lunkad D/o Shri S.K.Lunkad, aged about 27 years, R/o B-303,
Palm Residency, Opposite Bagrecha Nursing Home, Katora Talab, PS Civil
Lines, Raipur, Chhattisgarh.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

2. Bhupendra Kumar Sahu S/o Shri H.C.Sahu, aged about 26 years, R/o
village: Tikripar, Post Armarikala, Block and PS Gurur, District Balod,
Chhattisgarh.
3. Ajay Sur S/o Shri R.K.Sur, aged about 28 years, R/o Ganesh Nagar, Naya
Para, PS Torwa, Bilaspur, Chhattisgarh.
                                                                ---Petitioners
                                     Versus
1.   State of Chhattisgarh, through the Secretary, Department of General
Administration, Mantralaya, DKS Bhawan, Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
3. Chhattisgarh State Civil Supplies Corporation, through The Managing
Director, Head Office: Hitwad Parisar, Avanti Vihar, PS Telibandha, Raipur,
Chhattisgarh.
4. Santosh Agrawal, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Raipur, District Raipur, Chhattisgarh.
5. Nitin Deewan, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Surajpur, District Surajpur, Chhattisgarh.
6. Abhinay Shukla, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Raigarh, District Raigarh, Chhattisgarh.
7. Vinod Budhicha, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Korba, District Korba, Chhattisgarh.
8. Pragya Kadam, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Janjgir, District Janjgir-Champa, Chhattisgarh.
9. Alka Shukla Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Mahasamund, District Mahasamund, Chhattisgarh.
                                         7
10. Anita Soni, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Gariaband, District Gariaband, Chhattisgarh.
11. Neha Sahu, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Bemetara, District Bemetara, Chhattisgarh.
12. Pramod Jangde, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Balod, District Balod, Chhattisgarh.
13. Manoj Minj, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Jashpur, District Jashpur, Chhattisgarh.
14. Mamta Dhruv, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Baloda Bazar, District Baloda Bazar, Chhattisgarh.
15. Sameer Tirkey, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Jagdalpur, District Bastar, Chhattisgarh.
16. Akash Rahi, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Bijapur, District Bijapur, Chhattisgarh.
17. Rupesh Dhruv, Assistant Manager, Chhattisgarh State Civil Supplies
Corporation, Jagdalpur, District Bastar, Chhattisgarh.
                                                             ----Respondents
For Petitioners               : Mr. N. Naha Roy, Advocate.
For Respondents No. 1 & 2 : Mr. S.C.Verma, Advocate General alongwith
                            Mr. Vikram Sharma and Mr. Gagan Tiwari,
                            Deputy Government Advocates.
For Respondent No. 3          : Mr. Abhishek Vinod Deshmukh, Advocate.
For Private Respondents         Ms. Surya Kawalkar Dangi, Advocate.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

                                WPC/1067/2012
Dr. Rajesh Baghel aged about 41 years, s/o Shri Punni Das Baghel, R/o
Forest Colony, Belvapaelai, Kondagaon, Chhattisgarh.
                                                                  ---Petitioner
                                     Versus
1. State of Chhattisgarh, Through Secretary, Health and Family Welfare
Department, Mantralaya, DKS Bhavan, Raipur, Chhattisgarh.
2. Director, Health and Family Welfare Department, Mantralaya, DKS Bhavan,
Raipur, Chhattisgarh.
3. Director, Medical Education, DKS Bhavan Campus, Old Nursing Hostel,
Raipur, Chhattisgarh.
4. Ayush & Health Sciences University of Chhattisgarh, Through its Registrar,
                                        8
GE Road, Raipur, Chhattisgarh.
                                                           ----Respondents
For Petitioner               : Mr. Mateen Siddiqui and Ms. Diksha Gouraha,
                                 Advocate.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                                 Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                 Deputy Government Advocates.
                                 WPC/1093/2012
1. L.L.Koshley son of Late Shri S.L.Koshley, aged 62 years, R/o D-102, Guru
Ghasidas Colony, New Rajendra Nagar, Raipur, Chhattisgarh.
2. K.P.Khande son of Late Shri S.P.Khande, aged 72 years, R/o Shyam
Nagar, Telibandha Raipur, Chhattisgarh.
3. H.R.Bhatpahre son of Late Panch Ram Bhatpahre, aged 77 years, R/o Om
Nagar, Jarhabhata, Bilaspur, Chhattisgarh.
                                                                ---Petitioners
                                     Versus
1.   State of Chhattisgarh, through the Secretary, Department of General
Administration, Mantralaya, DKS Bhawan, Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
3. Secretary, Department of Higher Education, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
                                                           ----Respondents
For Petitioner               : Mr. Brijendra Singh and Mr. Shyam Sunder Lal
                                 Tekchandani, Advocates.
For Respondents              : Mr. S.C.Verma, Advocate General alongwith
                                 Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                 Deputy Government Advocates.
                                 WPC/1121/2012
1. Dr. Pankaj Sahu, aged about 35 years, S/o Shri B.R.Sahu, R/o R-3, Vinoba
Nagar, Bilaspur, Chhattisgarh.
2. Dr. Sudhir Kumar Bhoi, aged about 30 years, S/o Late Shri S.K.Bhoi, R/o
Mahalpara, Saraipali, Mahasamund, Chhattisgarh.
3. Dr. Mamta Sahu, aged about 30 years, W/o Dr. Pankaj Sahu, R/o R-3,
                                         9Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Vinoba Nagar, Bilaspur, Chhattisgarh.
4. Dr. Chaturbhuj Mishra, aged about 35 years, S/o Dr. Sheshnath Mishra, R/
o Sr. MIG 12, Nehru Nagar, Bilaspur, Chhattisgarh.
                                                                    ---Petitioners
                                     Versus
1.   State of Chhattisgarh, through Secretary, Health and Family Welfare
Department, Mantralaya, DKS Bhavan, Raipur, Chhattisgarh.
2. Director, Health and Family Welfare Department, Mantralaya, DKS Bhavan,
Raipur, Chhattisgarh.
3. Director, Medical Education, DKS Bhavan Campus, Old Nursing Hostel,
Raipur, Chhattisgarh.
4. Ayush & Health Sciences University of Chhattisgarh, Through its Registrar
GE Road, Raipur, Chhattisgarh.
                                                                ----Respondents
For Petitioner                : Mr. Mateen Siddiqui and Ms. Diksha Gouraha
                                Advocates.
For Respondents               : Mr. S.C.Verma, Advocate General alongwith
                                Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                Deputy Government Advocates.
                                WPC/1372/2012
Dr. Manmeet Thawait aged about 31 years, S/o Shri Ram Kumar Thawait, R/o
Infront of Railway Station, Ward No. 1, Bilha, District Bilaspur, Chhattisgarh.
                                                                     ---Petitioner
                                     Versus
1.   State   of Chhattisgarh, through Secretary, Health and Family Welfare
Department, Mantralaya, DKS Bhavan, Raipur, Chhattisgarh.
2. Director, Health & Family Welfare Department, Mantralaya, DKS Bhawan,
Raipur, Chhattisgarh.
3. Director, Medical Education, DKS Bhavan Campus, Old Nursing Hostel,
Raipur, Chhattisgarh.
4. Ayush & Health Sciences University of Chhattisgarh, through its Registrar,
GE Road, Raipur, Chhattisgarh.
                                                                ----Respondents
For Petitioner                : Mr. Mateen Siddiqui and Ms. Diksha Gouraha
                                        10
                                Advocates.
For Respondents               : Mr. S.C.Verma, Advocate General alongwith
                                Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                Deputy Government Advocates.
                               WPS/5290/2021
Dr. Renu Pant W/o Shri Nitesh Pant, Aged about 40 years, Occupation
Government Service (Lecturer,Nagriya Nikay) R/o Amapara, Main Road,
Kanker, District North Bastar, Kanker, Chhattisgarh.
                                                                    ---Petitioner
                                    VersusDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

1.   State    of Chhattisgarh, through Secretary, Department of General
Administration, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, Mahanadi Bhawan,
Naya Raipur, Chhattisgarh.
3. State of Chhattisgarh, through the Higher Education Department,
Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
4. Chhattisgarh Public Service Commission, through its Secretary, Shankar
Nagar Road, Raipur, Chhattisgarh.
                                                                ----Respondents
For Petitioner                : Mr. Anil S. Pandey, Advocate.
For Respondents No. 1 to 3 : Mr. S.C.Verma, Advocate General alongwith
                             Mr. Vikram Sharma and Mr. Gagan Tiwari,
                             Deputy Government Advocates.
For Respondent No. 4            Mr. Anand Mohan Tiwari, Advocate.
                               WPS/7100/2021
Aparna Agrawal W/o Shri Sanskar Mishra, aged about 46 years, Occupation
Government Service (Lecturer Nagriya Nikay) R/o House No. 89/489, Ward
No.51, Purani Basti, Raipur, District Raipur, Chhattisgarh.
                                                                    ---Petitioner
                                    Versus
1.   State   of Chhattisgarh, through Department of General Administration,
Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, Mahanadi Bhawan,
                                         11
Naya Raipur, Chhattisgarh.
3. State of Chhattisgarh, through Department, Mantralaya, Mahanadi Bhawan,
Naya Raipur, Chhattisgarh.
4. Chhattisgarh Public Service Commission, through its Secretary, Shankar
Nagar Road, Raipur, Chhattisgarh.
                                                              ----Respondents
For Petitioner               : Mr. Shivanshu Pandey, Advocate.
For Respondents No. 1 to 3 : Mr. S.C.Verma, Advocate General alongwith
                               Mr. Vikram Sharma and Mr. Gagan Tiwari,
                               Deputy Government Advocates.
For Respondent No. 4           Mr. Anand Mohan Tiwari, Advocate.
                               WPS/4049/2018
Rashmi Agrawal D/o Shri Vinod Kumar Agrawal, Aged about 32 years, R/o
Baniyapara, Near Kankalin Mandir, Durg, District Durg, Chhattisgarh.
                                                                  ---Petitioner
                                    Versus
1.   State      of Chhattisgarh, through Secretary, Department of General
Administration, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
2. The State of Chhattisgarh, through Secretary, Department of Health and
Family   Development,     Mantralaya,    Mahanadi   Bhawan,    Naya    Raipur,
Chhattisgarh.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

3. State of Chhattisgarh, through the Principal Secretary, Law and Legislative
Affairs, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
4. Chhattisgarh Public Service Commission, Through its Secretary, Shankar
Nagar Road, Raipur, Chhattisgarh.
                                                              ----Respondents
For Petitioner               : Mr. Vinay Pandey, Advocate.
For Respondents No. 1 to 3 : Mr. S.C.Verma, Advocate General alongwith
                               Mr. Vikram Sharma and Mr. Gagan Tiwari,
                               Deputy Government Advocates.
For Respondent No. 4           Mr. Anand Mohan Tiwari, Advocate.
                               WPS/6083/2018
                                         12
Dr. Shraddha Sharma D/o Shri Veerbhadra Prasad Sharma, aged about 36
years, R/o House No. 314, Ward No. 1, Near Dharam Ara Mill, Bemetara,
District Bemetara, Chhattisgarh.
                                                                  ---Petitioner
                                    Versus
1.   State      of Chhattisgarh, through Secretary, Department of General
Administration, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
2. The State of Chhattisgarh, through Secretary, Department of Health and
Family   Development,     Mantralaya,    Mahanadi   Bhawan,    Naya   Raipur,
Chhattisgarh.
3. State of Chhattisgarh, through the Principal Secretary, Law and Legislative
Affairs, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
4. Chhattisgarh Public Service Commission, through its Secretary, Shankar
Nagar Road, Raipur, Chhattisgarh.
                                                              ----Respondents
For Petitioner               : Mr. Vinay Pandey, Advocate.
For Respondents No. 1 to 3 : Mr. S.C.Verma, Advocate General alongwith
                               Mr. Vikram Sharma and Mr. Gagan Tiwari,
                               Deputy Government Advocates.
For Respondent No. 4           Mr. Anand Mohan Tiwari, Advocate
                               WPC/4665/2019
1. Vivek Kumar singh S/o Shri Lallan Prasad Singh, age 22 years, R/o 52A
Mayapur, Shastri Ward, Ambikapur, District Sarguja, Chhattisgarh Pincode
497001
2. Amit Kumar Singh S/o Shri Kundan Lal Singh, age 31 years, R/o 27(2) Lal
Bangla Ward No. 1, Janakpur, District Koriya, Chhattisgarh, Pin code 497778
at present address Mannu Chowk, Tikrapara, Bilaspur, District Bilaspur,
Chhattisgarh.
                                                                 ---Petitioners
                                    Versus
1. State of Chhattisgarh, through the General Administration Department,
Mahanadi Bhawan, Atal Nagar, Naya Raipur, Chhattisgarh.
2. Secretary, Law and Legislative Affairs Department, Mahanadi Bhawan, Atal
                                          13Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Nagar, Naya Raipur, District Raipur, Chhattisgarh.
                                                                  ----Respondents
For Petitioner                   : Mr. Sangharsh Pandey, Advocate.
For Respondents                  : Mr. S.C.Verma, Advocate General alongwith
                                  Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                  Deputy Government Advocates.
                                  WPS/2091/2018
Chandrakant Pandey, Shri Harendra Nath Pandey, Aged about 35 years, R/o
Daya Kunj, Karbala Road, Thana Civil Lines, District Bilaspur, Chhattisgarh.
                                                                      ---Petitioner
                                      Versus
1.   State      of Chhattisgarh, through Secretary, Department of General
Administration, Mantralay, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
2. The Chief Secretary, State of Chhattisgarh, Mantralaya, Mahanadi Bhawan,
Naya Raipur, Chhattisgarh.
3. State of Chhattisgarh, through the Principal Secretary, Law and Legislative
Affairs, Mantralaya, Mahanadi Bhawan, Naya Raipur, Chhattisgarh.
4. Chhattisgarh Public Service Commission, Through its Secretary, Shankar
Nagar Road, Raipur, Chhattisgarh.
5. Shri Suresh Toppo (selected candidate), C/o Chhattisgarh Public Service
Commission,      through   its   Secretary,     Shankar   Nagar   Road,   Raipur,
Chhattisgarh.
                                                                  ----Respondents
For Petitioner                   : Mr. Vinay Pandey, Advocate.
For Respondents No. 1 to 3 : Mr. S.C.Verma, Advocate General alongwith
                                  Mr. Vikram Sharma and Mr. Gagan Tiwari,
                                  Deputy Government Advocates.
For Respondent No. 4             : Mr. Anand Mohan Tiwari, Advocate.
Dates of Hearing                 : 13.06.2022,      15.06.2022,      28.06.2022,
                                  04.07.2022 and 06.07.2022
Date of Judgment                 : 19.09.2022
                                           14
                    Hon'ble Mr. Arup Kumar Goswami, Chief Justice
                         Hon'ble Mr. Parth Prateem Sahu, Judge
                                     C A V Judgment
     Per Arup Kumar Goswami, Chief Justice
        In this batch of writ petitions, primarily, the pleadings in WPC No.
591/2012 and WPC No. 1067/2012 are relied upon by the learned counsel forDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

the parties and therefore, while disposing of these petitions, essentially,
reference would be made to the pleadings in the aforesaid writ petitions. Of
course, whenever necessary, reference to the pleadings made in other writ
petitions would be made as well.
2.      At the very outset, nevertheless, a brief reference to the writ petitions as
well as prayers made therein would be in order.
3.      WPC No. 591/2012 is filed by a registered society espousing the cause
of the Scheduled Caste (SC) community. In the writ petition, following prayers
are made:
         "1. Quash amendment No. 368/D.19/21-A/PRA/CHH.G./12,
         dated 18.01.2012 whereby Section 4(2)(i) of Chhattisgarh Public
         Service (Reservation for Scheduled Caste, Scheduled Tribe &
         Other Backward Classes) Act, 1994 has been amended
         (Chhattisgarh Lok Seva (Anusuchit Jatiyon, Anusuchit Jan
         Jatiyon Aur Anya Pichere Wargo Ke Liye Aarakshan) Adhiniyam,
         1994) and declare the same as unconstitutional and ultra vires.
                                          Or
          2. Issue an appropriate writ and declare the Chhattisgarh Lok
          Seva (Anusuchit Jatiyon, Anusuchit Jan Jatiyon Aur Anya
                                          15
        Pichere Wargon Ke Liye Aarakshan) Sanshodhan Adhiniyam,
        2011 (Act of 2011) as ultra vires and unconstitutional.
        3. Any other relief(s) which may deem fit, looking to the facts
        and circumstances of the case, may be given by this Hon'ble
        Court."Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

4.    We will revert back to the pleadings in WPC No. 591/2012 in detail after
we briefly take note of the salient facts in each of the other writ petitions.
5.    In WPC No. 592/2012, the petitioners belong to SC community and they
are social activists. Identical prayers, as made in WPC No. 591/2012, are
made. The return filed by the State relies on the return filed in WPC No.
591/2012.
6.    In WPC No. 593/2012, the petitioner is a registered society working for
upliftment of the SC community. In this petition, the notification dated
18.01.2012, as elaborated in the prayer of WPC No.591/2012, is challenged.
The return filed by the State in this case relies on the return filed in WPC No.
591/2012.
7.    In WPC No. 594/2012, the petitioners belong to SC community. While
petitioner Nos. 1 and 2 are social activists, petitioners No. 3 and 4 are aspiring
for recruitment to the services of the State. In WPC No. 652/2012, the
petitioners belong to to SC community. Petitioner No. 1 is aged about 45
years and petitioner No. 2 aged about 73 years. In WPC No. 653/2012, the
petitioner belongs to SC category. In WPC No. 936/2012, the petitioner
belongs to SC community. In WPC No. 2072/2014, the petitioners belong to
the unreserved category. In these petitions, prayers, as made in WPC No.
593/2012, are made. The return filed by the State in in WPC No. 591/2012 are
                                       16
relied on in WPC No. 594/2012, WPC No. 652/2012, WPC No. 653/2012 and
WPC No. 936/2012. Though an independent return has been filed in WPC
No. 2072/2014, in this return, essentially, the averments made in the return
and the additional returns filed by the State in WPC No. 591/2012 areDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

incorporated.
8.    In WPS No. 4240/2014, petitioner is Chhattisgarh Anusuchit Jati/Janjati
Chhatra Sangathan (Student Union). Prayer is made to quash advertisement
issued in the month of July, 2014 by the Commissioner, Tribal and Scheduled
Caste Welfare, Raipur, for the recruitment to 800 posts of Hostel
Superintendent, Group-D. By the aforesaid advertisement, 96 posts for SCs,
256 posts for Scheduled Tribes (ST) and and 112 posts for Other Backward
Classes (OBC) were reserved. Similar return as filed in WPC No. 591/2012 is
filed in this case.
9.    In WPS No. 5578/2012, the three petitioners are graduates from
commerce stream and they had also obtained MBA degree. They had been
appointed on contractual basis in the post of Assistant Manager vide orders
dated 16.09.2011 and 14.09.2011. The contractual appointment of petitioner
No. 1 and 2 had been extended for a period of 6 months. In this petition,
prayer is made for declaration of the Chhattisgarh Lok Seva (Anusuchit
Jatiyon, Anusuchit Jan Jatiyon Aur Anya Pichere Wargon Ke Liye Aarakshan)
Sanshodhan Adhiniyam, 2011 (Act of 2011) as ultra vires and unconstitutional
as also to quash the selection list dated 19.11.2012 (Annexure P/9) issued by
the Managing Director, Chhattisgarh State Civil Supplies Corporation Limited,
Raipur, for 15 posts of Assistant Manager, pursuant to the advertisement
dated 30.07.2012. Prayer is also made to initiate fresh recruitment process.
                                        17
10.   In WPS No. 5578/2012, return was filed by the CG Civil Supplies
Corporation, which is arrayed as respondent No. 3. The respondents No. 1
and 2 have filed return adopting the return filed in WPC No. 591/2012.
Respondents No. 4, 7, 8, 10, 11, 13, 15 and 17, i.e. the private respondentsDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

filed return stating that pursuant to the advertisement, 292 candidates from
the unreserved category had applied. It is stated that the petitioner No. 1 had
cleared the computer test but the petitioners No. 2 and 3 could not clear the
computer test conducted by the National Institute of Computer Science, a
Government of India Undertaking. The petitioner No. 1 was placed at serial
No. 10 of the waiting list, which has already expired.
11.   In WPC No. 1067/2012, the petitioner belongs to SC community. In
WPC No. 1093/2012, the petitioners belong to SC community and they are
social activists. In WPC No. 1121/2012, petitioner No. 1 to 3 belong to OBC
category while petitioner No. 4 belongs to unreserved category. In WPC No.
1372/2012, petitioner belongs to OBC category. In WPC Nos. 1067/2012,
1121/2012 and 1372/2012, challenge is made to the Notification dated
16.05.2012 issued by the Director, Medical Education, Raipur, for admission
in Pre-P.G. Medical and Dental and to declare Section 3 of the Chhattisgarh
Educational Institutions (Reservation in Admission) Act, 2012, (for short, Act
of 2012), which came into force on 13.03.2012, as ultra vires. In WPC No.
1067/2012 and WPC No. 1121/2012, an additional prayer is made to declare
the entire selection process of Chhattisgarh Pre-Post Graduate Medical
Education, 2012 as void ab-initio. In WPC No. 1093/2012, essentially, Section
3 of the Act of 2012 is challenged. More or less similar return is filed in the
above four petitions.
                                        18
12.   Stand taken in the return in WPC No. 1067/2012 will be considered at
an appropriate place. It is also to be noted a similar return is filed in WPC No.
1093/2012.
13.   In WPS No. 5290/2021 and WPS No. 7100/2021 petitioners belong toDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

unreserved category. They appeared in the competition examination for the
post of Assistant Professor (Hindi) pursuant to an advertisement dated
10.09.2014. The petitioner in WPS No. 5290/2021 was kept in the waiting list
at serial No. 5 and the petitioner in WPS No. 7100/2021 was kept in the
waiting list at serial No. 2 for the post of Assistant Professor (Hindi). They
challenge the amendment notification dated 18.01.2012 and pray for quashing
the advertisement as well as the select list to the extent reservation had
exceeded 50% and for a direction to the respondents to appoint them with
consequential benefits. It is stated that the advertisement in question indicated
that the selection would be governed by the outcome of the decision pending
in WPC Nos. 591/2012, 593/2012 and 594/2012. Prayer 10.1 of WPS No.
7100/2021 is with regard to placing the petitioner above respondents No. 3
and 4 in the gradation list which does not fit in with the factual matrix of the
writ petition as the respondents No. 3 and 4 are the State and the
Chhattisgarh Public Service Commission (for short, CGPSC). While State has
not filed any return in these two writ petitions, the CGPSC had filed return
stating that it had issued the advertisement as per requisition given by the
State Government.
14.   In WPS No. 4049/2018 and WPS No. 6083/2018, petitioners belong to
unreserved category. They responded to the advertisement dated 21.06.2017
issued by the CGPSC for 57 posts of Homeopathy Medical Officer. While the
                                        19
petitioner in WPS No.4049/2018 was kept in the waiting list at serial No. 1, the
petitioner in WPS No. 6083/2018 was kept at serial No. 3 in the waiting list.
The petitioners challenge amendment notification dated 18.01.2012 and pray
for quashing the advertisement and select list to the extent reservation hadDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

exceeded ceiling limit of 50%. Prayer is also made to appoint them with
all consequential benefits. However, in WPS No. 4049/2018, wrongly,
appointment is sought to the post of 'Civil Judge' with all consequential
benefits, though, admittedly, she had applied for Homeopathy Medical Officer.
It is stated that the advertisement in question indicated that the selection
would be governed by the outcome of the decision pending in WPC No.
591/2012, 593/2012 and 594/2012. Though an independent return has been
filed in WPS No. 4049/2018, in this return, essentially, the averments made in
the return and the additional returns filed by the State in WPC No. 591/2012
are incorporated. In the return filed in WPS No. 6083/2018, apart from
referring to certain judicial precedents, it is stated that the petitioner has
erroneously relied on Chhattisgarh Lok Sewa Anusuchit Jati, Anusuchit
Janjatiya Aur Anya Pichhre Vargon Ke Liye Arakshan Sanshodhan
Adhiniyam, 2011, which is a legislation pertaining to reservation in public
employment, while the petition is in respect of providing for reservation in
educational institutions under Article 15(5) of the Constitution of India. It is
also stated that by notification dated 29.11.2012, Chhattisgarh Public Service
Scheduled Caste, Scheduled Tribe and Other Backward Class Reservation
Rules, 1998 (for short, the Rules of 1998) was amended and on the basis
thereof, Schedule I, II and III of the reservation roster was changed to new
                                        20
Schedule I and II. The CGPSC had filed return in both the cases stating that it
had issued the advertisement as per the notification dated 18.01.2012.
15.   In WPS No. 2091/2018, petitioner belongs to unreserved category. The
petitioner responded to the advertisement dated 07.09.2016 for the 40 posts
of Civil Judge, Entry Level Exam, 2016 and he was kept at serial No. 3 in theDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

waiting list. Respondent No. 5 in the writ petition is the last candidate who had
been selected against 'reserved category (T)'. The petitioner challenges
amendment notification dated 18.01.2012 and prays for quashing the
advertisement and select list to the extent reservation had exceeded ceiling
limit of 50%. Prayer is also made to appoint him with all consequential
benefits. The High Court is not a party-respondent. Though an independent
return has been filed, in this return, essentially, the averments made in the
return and the additional returns filed by the State in WPC No. 591/2012 are
incorporated. The CGPSC had filed return stating that it had issued the
advertisement as per the notification dated 18.01.2012.
16.   In WPC No. 4665/2019, the petitioners belong to general category. The
petitioners challenge the amendment effected to the Rules of 1998 vide
notification dated 29.11.2012 whereby Schedule I and II were substituted.
Schedule I deals with model roster for the post/cadre to be filled by direct
recruitment in State level and Schedule-II deals with model roster for the post/
cadre to be filled by direct recruitment at Division and District level,
respectively. Prayer is made to declare the notification dated 29.11.2012 as
ultra vires to the extent of making reservation of posts of SCs, STs, and OBCs
exceeding 50% in Class III and Class IV posts of Districts falling under
Surguja Division. It is pleaded that while Schedule I model roster provides for
                                        21
reservation at State Level by direct recruitment for Class I, II, III and IV at
12%, 32% and 14% for SCs, STs and OBCs, in Schedule II model roster
which provides for reservation at the Division and District level for Class III
and Class IV posts, higher percentage of reservation has been prescribed for
Surguja Division and Surguja District. Surguja Division comprises of districtsDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

of Surguja, Surajpur, Balrampur-Ramanujganj, Jashpur and Koriya. In the
return filed, essentially, the averments made in the return and the additional
returns filed by the State in WPC No. 591/2012 are incorporated.
The reservation in District Surguja is 76% (SC-5%, ST 57% OBC, 14%)
District Surjapur- 64% (SC-5%, ST-45%, OBC-14%), District Balrampur-
Ramanujganj- 80% (SC-4%, ST-62%, OBC-14%), District Jashpur- 81%
(SC- 5%, ST-62%, OBC-14%), District Koria - 66% (SC-8%, ST-44%, OBC-
14%), Surguja Division- 74% (SC-5%, ST-57%, OBC-14%). The return is
conspicuously silent as to why such higher percentage for reservation is fixed.
17.   From the prayers made in the writ petitions, it is seen that essentially in
WPC Nos. 591/2012, 592/2012, 593/2012, 594/2012, 652/2012, 653/2012,
936/2012, 2072/2014, WPS Nos. 5578/2012, 5290/2021, 7100/2021,
4049/2018 and 6083/2018, challenge is made to the Amendment Act of 2011.
18.   The Chhattisgarh Lok Seva (Anusuchit Jatiyon, Anusuchit Jan Jatiyon
Aur Anya Pichere Wargo Ke Liye Aarakshan) Adhiniyam, 1994, was enacted
to provide for reservation of vacancies in public services and posts in favour of
the persons belonging to SC, ST and OBC and for the matters connected
therewith and incidental thereto. The Act had received assent of the Governor
on 03.06.1994 and the same was published in the Gazette (Extraordinary) on
08.06.1994. The Act was brought into force w.e.f 01.07.1994.
                                          22
19.   Section 4 of the Act of 1994 provided for fixation of percentage for
reservation of posts and standards of evaluation. By the Chhattisgarh Lok
Seva (Anusuchit Jatiyon, Anusuchit Jan Jatiyon Aur Anya Pichere Wargon Ke
Liye Aarakshan) Sanshodhan Adhiniyam, 2011 (for short, Amendment Act ofDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

2011), Section 4(2)(i) of the Act of 1994 was substituted.
20.   As the focal point of controversy in WPC Nos. 591/2012, 592/2012,
593/2012, 594/2012, 652/2012, 653/2012, 936/2012, 2072/2014, WPS Nos.
5578/2012, 5290/2021, 7100/2021, 4049/2018 and 6083/2018, is amendment
effected in the Act of 1994 relating to Section 4(2)(i), at this juncture, it will be
appropriate to take note of the provisions prior and post-amendment. The
provision immediately existing before amendment reads as follows:
         "4. Fixation of percentage for reservation of posts and standard of
         evaluation. - (1) Unless otherwise provided by or under this Act, the
         posts reserved for the members of the Scheduled Castes or
         Scheduled Tribes or other Backward Classes shall not be filled by
         the members who do not belong to such castes or tribes or classes,
         as the case may be.
         (2) Subject to other provisions of this Act there shall be reserved for
         the persons belonging to the Scheduled Castes, Scheduled Tribes
         and other Backward Classes, at the stage of direct recruitment in
         public services and posts.
         (i) at the State level, the following percentage of vacancies arising
         in a recruitment year, in Classes I, II, III and IV posts -
         (a) In Class I and Class II posts
                                          23
                Scheduled Castes                 16 percent.
                Scheduled Tribes                 20 percent
                Other Backward Classes           14 percent.
           (b) Class III and Class IV posts -
                Scheduled Castes                 16 percent.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

                Scheduled Tribes                 20 percent
                Other Backward Classes           14 percent."
21.   By the Amendment Act of 2011, Section 4(2)(i) was substituted as
follows:
       "(i) at the State level, the following percentage of vacancies arising in a
       recruitment year in Class I, II, III and IV posts:-
       Scheduled Castes              12 %
       Scheduled Tribes              32%
       Other Backward Classes 14%.
22.   In WPC No. 591/2012, it is wrongly stated that prior to the impugned
amendment, reservation in Class I and Class II posts in respect of SC, ST and
OBC was fixed at 15%, 18% and 14%, respectively.
23.   The Act of 2012 is an act to provide for reservation in admission of the
students belonging to STs, SCs and OBCs to certain educational institutions
established, maintained or aided by the State Government and for matters
connected therewith or incidental thereto.
24.   Section 2(f) describes an educational institution to mean (i) a University
established or incorporated by or under an Act of legislature of the State of
                                         24
Chhattisgarh and (ii) an institution, other than a minority educational institution
referred to in Article 30(1) of the Constitution, maintained by or receiving aid
from the State Government, whether directly or indirectly, and affiliated to a
University referred to in clause (i), and (iii) an educational institution
established by the State Government under the Chhattisgarh Societies
Registration Adhiniyam, 1973. As section 3 of the Act of 2012 is underDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

challenge, the same is reproduced here in below:
      "3. The reservation of seats in admission to each academic session and
      its extent in an Educational Institution shall be in the following manner,
      namely:-
      (a) out of the annual permitted strength in each branch of study or
      faculty, thirty two percent seats shall be reserved for the Scheduled
      Tribes;
      (b) out of the annual permitted strength in each branch of study or
      faculty, twelve percent seats shall be reserved for the Scheduled
      Castes;
      (c) out of the annual permitted strength in each branch of study or
      faculty, fourteen percent seats shall be reserved for the Other
      Backward Classes:
      Provided that where the seats reserved for the Scheduled Tribes
      remain vacant due to non availability of eligible students on the cut-off
      date(s), the same shall be filled from among eligible students belonging
      to the Scheduled Castes and vice versa.
                                       25
      Provided further that where seats reserved under clause (a), (b) and (c)
      remain vacant on the cut-off date(s), even after the arrangement
      referred to in the foregoing proviso, the same shall be filled from other
      eligible students.
      Provided also that the State Government may, for the purpose of givingDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

      effect to reservation under this section, aggregate the annual permitted
      strength of any or all branches of study at the post-graduate or higher
      levels, if in the opinion of the State Government such reservation
      cannot be made in such branch or branches of study taken alone."
25.   It is pleaded in WPC No. 591/2012 that the Ministry of Public
Grievances and Training issued an office memorandum dated 05.07.2005
pertaining to quantum of reservation to the SC, ST and OBC in case of direct
recruitment to Group C and D posts. According to the said office
memorandum, for the State of Chhattisgarh, the percentage of reservation for
the SCs, STs and OBCs was fixed as 12%, 32% and 6%. The said
memorandum set out the revision of quantum of reservation for SCs, STs and
OBC in accordance with the figures of 2001 census for Group C and D posts
also stating that the reservation would not exceed 50%. It is pleaded that
when the census of 2011 was conducted and the data/figures were expected
within a couple of months, the amendment effected by Amendment Act of
2011 in Section 4(2)(i) of the Act of 1994 on the basis of the census data of
2001 defies rationale and the same is, per se, unconstitutional, reservation
having reached 58%, thus breaching the ceiling of 50% reservation as laid
down by the Hon'ble Supreme Court in the case of Indra Sawhney & Others
                                         26
v. Union of India & Others, reported in (1992) Supp 3 SCC 217 and M.R.Balaji
& Others v. The State of Mysore & Others, reported in AIR 1963 SC 649.
26.   It is further pleaded that reduction of percentage drastically from 16% to
12% in respect of SC in all classes of posts is not tenable as they are not
adequately represented in service. Similarly, increase of percentage from 20
to 32% in respect of STs is also stated to be without any rationale basis.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

27.   Return was filed by the State respondents on 27.04.2012. In the return,
it is stated that the State of Chhattisgarh has come into existence pursuant to
the Madhya Pradesh Reorganization Act, 2000 as a result of bifurcation of the
State of Madhya Pradesh into State of Madhya Pradesh and State of
Chhattisgarh. While the re-organization resulted in allocation of a number of
tribal districts to the State of Chhattisgarh, SC dominated districts largely
formed the new State of Madhya Pradesh. The population of OBC continued
to be substantially same in both the States. At the relevant time, there were 27
districts in the State of Chhattisgarh with total population of 28.83 million, out
of which the SC population was 2.42 million and the ST population was 6.62
million as per the 2001 census and thus, the SC population constituted about
12% of the total population of the State while the ST population constituted
about 31.76%. It is pleaded that incidence of poverty amongst STs is 54.8% in
comparison to All India figure of 44.7%. Prior to issuance of the OM dated
05.07.2005, reservation of posts in Group C and D Central Government posts
in the State of Chhattisgarh stood at 14% for SCs, 23% for STs and at that
point of time, the Government of Chhattisgarh followed a policy of reservation
of 16% for SCs, 20% for the STs and 14% for OBCs in respect of Class III and
IV posts corresponding to Group C and D posts of the Central Government. It
                                        27
is pleaded that as a result of a demographic change in the population of the
SCs and STs, consequent upon formation of the two States i.e. State of
Madhya Pradesh and State of Chhattisgarh, the Government of Chhattisgarh
decided to review and re-frame the existing reservation policy for the State-
cadre posts, based on the data from the 2001 Census. In the process,Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

numerous representations were received from the tribal groups which
demanded a revision in the State's reservation policy. After due consideration
of all relevant aspects, the revision was effected in the existing reservation
policy which resulted in the Amendment Act of 2011. It is pleaded that so far
as the districts are concerned, there is no direct recruitment to Class A and B
posts. Class C and D posts are filled up by direct recruitment as per the
reservation policy which is not changed by the impugned amendment. It is
pleaded that the revised reservation policy is constitutionally valid and the
same is based on the Directive Principles of the State Policy, in particular,
Article 46 of the Constitution, which requires the State to protect and preserve
the interest of the tribal communities, which not only form 32% of the State's
population but also markedly backward in social and economic terms. It is
also pleaded that the Tribes Advisory Council, which is a constitutional body
under Schedule V of the Constitution of India, had recommended in its
meeting dated 26.09.2011 that the tribals in the State of Chhattisgarh should
be accorded reservation at 32%. It is pleaded that the State can take into
account special circumstances and in order to uplift the lot of the ST
communities, apart from increasing reservation in Government posts, have
taken many welfare measures to promote their educational and economic
interests so that they can be integrated into the main stream and with that
                                         28
objective, many social welfare legislation had been enacted and a number of
administrative schemes have been launched. The respondents have also filed
an application dated 03.05.2012 for taking documents on record in respect of
the aforesaid measures and the documents relied upon have been marked as
Annexure A, collectively.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

28.   Class A, B, C and D as referred to in the return possibly refers to Class
I, II, III and IV posts.
29.   A rejoinder affidavit was filed by the petitioner to the return filed by the
respondents No. 1 and 2 on 05.07.2012. In the said rejoinder, it is stated that
whether demographic position is altered or not would be revealed from the
subsequent census of 2011. It is pleaded that there was no justification for
making amendment in the year 2011 based on the census of the year 2001
when the tentative census data of 2011 was already available. It is stated that
while the State is free to exercise its discretion of providing reservation, same
is subject to the conditions that there must exist compelling reasons of
backwardness and inadequacy of representation in a class of post(s) and in
the process, overall administrative efficiency is also to be borne in mind. In the
instant case, discretionary power has been misused while breaching the
ceiling limit of 50% reservation and the respondents have made the
reservation proportionate to the population which cannot be sustained in law.
It is asserted that there is no basis whatsoever for changing the percentage of
reservation or breaching the ceiling of 50%.
30.   An additional return was filed on 19.11.2012 by the State respondents
stating that the presumption attached to the constitutionality of the legislation
ought not be lightly interfered with and no ground has been laid down in the
                                          29
writ petition for entering into the examination of the constitutional validity of the
impugned amendment. By the said affidavit, the State respondents have
furnished additional data claiming the same to be not exhaustive
demonstrating inadequacy of representation of SC, ST and OBC in the
services of the State which would go to show that there was a valid andDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

reasonable basis for extending the reservation policy beyond the limit of 50%
with regard to the parameters of backwardness, inadequacy in representation
and overall administrative efficiency.
31.   In paragraph 17 of the said additional return, 8 tables relating to (i) SC,
ST and OBC Representation among Candidates Selected by Chhattisgarh
State PSC through Open Competition (i.e., without the Aid of Reservation), (ii)
SC, ST and OBC representation among Students selected for MBBS/BDS
course through Open Competition, i.e., without the aid of Reservation, in Pre-
Medical Test, (iii) SC, ST and OBC representation among Students selected
for Engineering Course through Open Competition, i.e., without the aid of
Reservation, in Pre-Engineering Test, (iv) Distribution households of social
groups in Chhattisgarh by employment status (as per NSSO, 61 st round, 2004-
05 survey), (v) Distribution of household of social groups in Chhattisgarh by
monthly per capita expenditure (Rs.) (as per NSSO, 61 st round, 2004-05
survey), (vi) Proportion of persons (15 yrs & above) among social groups in
Chhattisgarh by level of general education (rural + urban) (as per NSSO, 61 st
round, 2004-05 survey), (vii) Proportion of persons (15 yrs & above) among
social groups in Chhattisgarh by level of general education (urban) (as per
NSSO, 61st round, 2004-05 survey), and (viii) Proportion of households with
no literate adult (15 yrs & above) / adult female member among social groups
                                        30
in    Chhattisgarh   (as   per   NSSO,      61 st   round,   2004-05       survey).
Explanations/interpretations of the aforesaid tables are given at paragraphs
18 to 30.
32.   An additional rejoinder was filed by the petitioner on 18.02.2013.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

33.   In the return filed by the State respondents in WPC No. 1067/ 2012, it is
submitted that there is no violation or infraction of any constitutional
requirement for passing the Act of 2012 and that the reservation has been
provided not by an executive action but by a substantive legislation passed by
a competent legislature. The presumption attached to the constitutionality of
the legislation may not be allowed to be lightly interfered with. It is further
submitted that the petitioner therein has not pleaded violation of any
fundamental or legal right and that the challenge raised in this petition has
been rendered academic as the Medical Pre PG Entrance Test, 2012 has
already been conducted. The State respondents have furnished the same
data as submitted in the additional return to WPC No. 591/2012 and also
relies on return filed in WPC No. 1093/2012, in support of their case. In WPC
No. 1093/2012, it is stated that the respondents are relying on the return in
WPC No. 1067/2012. Five tables are incorporated in the aforesaid two
returns. Table 1 relates to Table 1 in WPC No. 591/2012, Table 2 relates to
Table 3 of WPC No. 591/2012, Table 3 relates to Table 6 of WPC No.
591/2012, Table 4 relates to Table 7 of WPC No. 591/2012 and Table 5
relates to Table 8 of WPC No. 591/2012.
34.   We have heard Mr. Vinay Pandey, learned counsel, appearing for the
petitioner in WPC No. 2072/2014, WPS No. 2091/2018, WPS No. 4049/2018,
                                      31
WPS No. 6083/2018, Mr. Anchal Kumar Matre, learned counsel, appearing for
the petitioners in WPC No. 652/2012 and WPC No. 653/2012, Mr. Anil S.
Pandey, learned counsel, appearing for the petitioner in WPS No. 5290/2021,
Mr. Sanjeev Pandey and Mr. Sangharsh Pandey, learned counsel, appearingDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

for the petitioner in WPC No. 4665/2019, Mr. Akash Shrivastava and Mr.
Anumeh Shrivastava, learned counsel, appearing for the petitioners in WPC
No. 936/2012, Mr. N.N.Roy, learned counsel, appearing for the petitioner in
WPC No. 594/2012, Mr. Rahul Agrawal, learned counsel, appearing for the
petitioner in WPS No. 4240/2014, Mr.Brijendra Singh and Mr. Shyam Sunder
Lal Tekchandani, learned counsel, appearing for the petitioners in WPC Nos.
591/2012, 592/2012, 593/2012 and 1093/2012, Mr. Mateen Siddique and Ms.
Diksha Gouraha, learned counsel, appearing for the petitioner, in WPC No.
1121/2012, 1372/2012, and 1067/2012 and Mr. Shivanashu Pandey, learned
counsel, appearing for the petitioner in WPS No. 7100/2021. None appears
for the petitioners in WPS No. 5578/2012.
35.   We have also heard Mr. S.C.Verma, learned Advocate General,
assisted by Mr. Vikram Sharma as well as Mr. Gagan Tiwari, learned Deputy
Government Advocates, appearing for the respondent State of Chhattisgarh in
this batch of petitions, Mr. Anand Mohan Tiwari, learned counsel, appearing
for the respondent Chhattisgarh Public Service Commission in WPS No.
2091/2018, 4049/2018, 6083/2018, 5290/2021 and 7100/2021, Mr. Krishna
Gopal Yadav and Ms. Anmol Sharma, learned Central Government counsel,
appearing for the Union of India in WPC No. 936/2012, Mr. Abhishek Vinod
Deshmukh and Ms. Suraya Kawalkar Dangi, learned counsel, appearing for
some of the private respondents in WPS No. 5578/2012 as well as Dr.
                                        32
K.S.Chauhan, learned senior counsel, assisted by Mr. Ajit Kumar Ekka, Mr.
Lekh Ram Dhruw and Mr. R.V.Rajwade, learned counsel, appearing for the
intervenors in WPC No. 591/2012, Mr. Ashish Beck and Mr. Anand K. Kujur,Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

learned counsel, appearing for the intervenors in WPC No. 591/2012.
36.   Lead arguments have been advanced by Mr. Vinay Kumar Pandey, Mr.
Mateen Siddique, and Mr. N.Naha Roy, learned counsel, appearing for the
petitioners.
37.   Mr. Vinay Kumar Pandey, learned counsel, appearing for the petitioners
submits that as the reservation has exceeded 50%, it has violated the
principles of equality of opportunity under Article 16(1) of the Constitution of
India. It is further submitted that no materials have been placed before this
Court to justify the impugned amendment brought in by Amendment Act of
2011 and such amendment has been effected breaching 50% ceiling without
any exercise being undertaken with regard to representation of various
classes such as SCs, STs and OBCs in service. No exceptional circumstance
is made out for breaching the 50% ceiling of reservation and the State has
brought the amendment as a measure of proportional representation, which is
not permissible in law.
38.   Mr. Mateen Siddique, learned counsel, while endorsing the submissions
of Mr. Pandey, submits that Section 3 of the Act of 2012 is ultra vires as
without there being any compelling or extraordinary circumstances, 58% seats
have been reserved in the proportion of 32% for ST, 12% for SC and 14% for
OBC. It is submitted that since Census 2011 was conducted and the data
relating to the population pattern was expected within a short period, there
was no justification for effecting the amendment in the year 2012 on the basis
                                        33
of Census data of 2001. No justification whatsoever have been provided for
reducing the percentage of reservation in respect of SCs from 16% to 12%.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

39.   In support of their contention, learned counsel for the petitioners rely on
the decisions of the Hon'ble Supreme Court in M.R.Balaji (supra), Indra
Sawhney (supra), M. Nagaraj & Others v. Union Of India & Others, reported in
(2006) 8 SCC 212, Ashoka Kumar Thakur v. Union of India & Others, reported
in (2008) 6 SCC 1, Union of India v. Ramesh Ram & Others , reported in
(2010) 7 SCC 234, Madras Institute of Development Studies & Another v. K.
Sivasubramaniyan & Others, reported in (2016) 1 SCC 454,             Dr. Jaishri
Laxmanrao Patil v. Chief Minister & Others, reported in (2021) 8 SCC 1, and a
Division Bench judgment of Madhya Pradesh High Court in Mayank Jain v.
State of Madhya Pradesh & Others, reported in MANU/MP/0276/2003.
40.   Mr. S.C.Verma, learned Advocate General submits that incidence of
poverty in the State of Chhattisgarh amongst SCs is lower in comparison to all
India figures while in case of STs, there is a substantial higher incidence of
poverty. The decision to amend the reservation policy was taken after taking
into consideration the relevant aspects of the matter by which proportionate
reservation is introduced in the State cadre posts. It is submitted that
Chhattisgarh is a tribal majority state and therefore, reserving 32% posts in
service or seats in educational institutions for the STs cannot be faulted with.
The State has got legislative competence and no violation of any fundamental
rights has been established by the petitioners. It is submitted that 50% ceiling
can be breached if (a) quantifiable contemporary data relating to
backwardness is shown which has to be determined on the basis of objective
factors such as studies of a particular community in a given area, (b)
                                         34
inadequacy in representation, which must factually exist though it need not beDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

proved with exact and precise data and (c) overall administrative efficiency,
which cannot be supported by any data but is a matter of opinion based on
various factors. It is submitted that Tables 1 to 8 of the additional return along
with the explanation for the same in WPC No. 591/2012, justifies the
amendments. In support of his contentions, Mr. Verma also relies on the
decision of the Hon'ble Supreme Court in Indra Sawhney (supra).
41.   Learned counsel for the intervenors led by Dr. K.S.Chauhan, learned
senior counsel argued that the amendment vide notification dated 18.01.2012
is legally justified as the ST population constituted 38.1% of the total
population in the State and accordingly, reservation is sought to be enhanced
to 32% as the same was only 20% prior to amendment. It is submitted that in
R.K.Sabharwal & Others v. State of Punjab & Others, reported in (1995) 2
SCC 745, it is held that reservation could be provided in proportion to the
population of the backward classes. No material has been placed that the
opinion of the Government as regards inadequacy of representation in service
is not justified. In support of their contention, they rely on the decisions of the
Hon'ble Supreme Court in Jarnail Singh & Others v. Lachhmi Narain Gupta &
Others, reported in (2018) 10 SCC 396 (hereinafter referred to as Jarnail
Singh & Others-I), and B.K. Pavitra & Others v. Union of India & Others,
reported in (2019) 16 SCC 129 and Jarnail Singh & Others v. Lachhmi Narain
Gupta & Others, reported in 2022 SCC OnLine SC 96 (hereinafter referred to
as Jarnail Singh & Others-II) and Managing Director, ECIL, Hyderabad &
Others v. B. Karunakar & Others, reported in (1993) 4 SCC 727.
                                         35
42.   We have considered the submissions of the learned counsel for the
parties and have perused the materials on record.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

43.   Articles 15 and 16 read as follows:
       15. Prohibition of discrimination on grounds of religion, race, caste, sex
       or place of birth. - (1) The State shall not discriminate against any
       citizen on grounds only of religion, race, caste, sex, place of birth or
       any of them.
       (2) No citizen shall, on grounds only of religion, race, caste, sex, place
       of birth or any of them, be subject to any disability, liability, restriction
       or conditions with regard to -
       (a) access to shops, public restaurants, hotels and places of public
       entertainment; or
       (b) the use of wells, tanks, bathing ghats, roads and places of public
       resort maintained wholly or partly out of State funds or dedicated to the
       use of general public.
       (3) Nothing in this article shall prevent the State from making any
       special provision for women and children.
       (4) Nothing in this article or in clause (2) of article 29 shall prevent the
       State from making any special provision for the advancement of any
       socially and educationally backward classes of citizens or for the
       Scheduled Castes and Scheduled Tribes.
       (5) Nothing in this article or in sub-clause (g) of clause (1) of article 19
       shall prevent the State from making any special provision, by law, for
                                  36Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

the advancement of any socially and educationally backward classes
of citizens or for the Scheduled Castes or the Scheduled Tribes in so
far as such special provisions relate to their admission to educational
institutions including private educational institutions, whether aided or
unaided by the State, other than the minority educational institutions
referred to in clause (1) of Article 30.
(6) Nothing in this article or sub-clause (g) of clause (1) of article 19 or
clause (2) of article 29 shall prevent the State from making -
(a) any special provision for the advancement of any economically
weaker sections of citizens other than the classes mentioned in
clauses (4) and (5); and
(b) any special provision for the advancement of any economically
weaker sections of citizens other than the classes mentioned in
clauses (4) and (5) in so far as such special provisions relate to their
admission to educational institutions including private educational
institutions, whether aided or unaided by the State, other than the
minority educational institutions referred to in clause (1) of article 30,
which in the case of reservation would be in addition to the existing
reservations and subject to a maximum of ten per cent of the total
seats in each category.
Explanation. - For the purpose of this article and article 16,
"economically weaker sections" shall be such as may be notified by the
State from time to time on the basis of family income and other
indicators of economic disadvantage.
                                 37Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

16. Equality of opportunity in matters of public employment . - (1)
There shall be equality of opportunity for all citizens in matters relating
to employment or appointment to any office under the State;
(2) No citizen shall, on grounds only of religion, race, caste, sex,
descent, place of birth, residence or any of them, be ineligible for, or
discriminated against in respect of, any employment or office under the
State.
(3) Nothing in this article shall prevent Parliament from making any law
prescribing, in regard to a class or classes of employment or
appointment to an office under the Government of, or any local or
other authority within, a State or Union Territory, any requirement as to
residence within that State or Union Territory prior to such employment
or appointment.
(4) Nothing in this article shall prevent the State from making any
provision for the reservation of appointments or posts in favour of any
backward class of citizens which, in the opinion of the State, is not
adequately represented in the services under the State.
(4A) Nothing in this article shall prevent the State from making any
provision for reservation in matters of promotion, with consequential
seniority, to any class or classes of posts in the services under the
State in favour of the Scheduled Castes and the Scheduled Tribes
which, in the opinion of the State, are not adequately represented in
the services under the State.
                                        38Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

       (4B) Nothing in this article shall prevent the State from considering any
       unfilled vacancies of a year which are reserved for being filled up in
       that year in accordance with any provision for reservation made under
       clause (4) or clause (4A) as a separate class of vacancies to be filled
       up in any succeeding year or years and such class of vacancies shall
       not be considered together with the vacancies of the year in which they
       are being filled up for determining the ceiling of fifty per cent
       reservation on total number of vacancies of that year.
       (5) Nothing in this article shall affect the operation of any law which
       provides that the incumbent of an office in connection with the affairs
       of any religious or denominational institution or any member of the
       governing body thereof shall be a person professing a particular
       religion or belonging to a particular denomination.
       (6) Nothing in this article shall prevent the State from making any
       provision for the reservation of appointments or posts in favour of any
       economically weaker sections of citizens other than the classes
       mentioned in clause (4), in addition to the existing reservation and
       subject to a maximum of ten per cent of the posts in each category.
44.   Article 15(4) provides that nothing in this Article or Article 29(2) shall
prevent the State from making any special provision for the advancement of
any socially and educationally Backward Classes of citizens or for the SCs
and the STs.
45.   Article 15(4) was added by the Constitution (First Amendment) ActDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

1951. The object of this amendment was to bring Articles 15 and 29 in line
                                        39
with Article 16(4) as a result of the decision rendered by the Hon'ble
Supreme Court in the case of The State of Madras v. Srimathi Champakam
Dorairajan & Another, reported in AIR 1951 SC 226. In the aforesaid case, the
validity of an order issued by the Madras Government fixing certain
proportions in which students seeking for admissions to the Engineering and
Medical Colleges in the State should be admitted, was challenged. The said
government order being on the face of it a communal order fixing the
admissions in the stated proportion by reference to the communities of the
candidates, was struck down by the Madras High Court and the decision of
the Madras High Court was confirmed by the Hon'ble Supreme Court in
appeal, on the ground that the fundamental rights guaranteed by Articles
15(1) and 29(2) were not controlled by any exception, and that since there
was no provision under Article 15 corresponding to Article 16(4), the
impugned order could not be sustained. Thus, there is no doubt that Article
15(4) has to be read as a proviso or an exception to Articles 15(1) and 29(2).
In other words, if the impugned order is justified by the provisions of Article
15(4), its validity cannot be impeached on the ground that it violates Article
15(1) or Article 29(2). The fundamental rights guaranteed by the said two
provisions do not affect the validity of the special provision which it is
permissible to make under Article. 15(4).
46.   Article 15(4) authorises the State to make a special provision for the
advancement of any socially and educationally backward classes of citizens,
as distinguished from the SCs and STs. No doubt, special provision can be
made for both categories of citizens, but in specifying the categories, the firstDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

category is distinguished from the second. Sub-clauses (24) and (25) of
                                        40
Article 366 define SCs and STs respectively, but there is no clause defining
socially and educationally backward classes of citizens, and so, in determining
the question as to whether a particular provision has been validly made under
Article 15 (4) or not, the first question which falls to be determined is whether
the State has validly determined who should be included in these Backward
Classes. It seems fairly clear that the backward classes of citizens for whom
special provision is authorised to be made are, by Article 15(4) itself, treated
as being similar to the SCs and STs. SCs and STs which have been defined
were known to be backward and the Constitution-makers felt no doubt that
special provision had to be made for their advancement. It was realised that in
the Indian society there were other classes of citizens who were equally, or
may be somewhat less, backward than the SCs and STs and it was thought
that some special provision ought to be made even for them. Article 341
provides for the issue of public notification specifying the castes, races or
tribes which shall, for the purposes of the Constitution, be deemed to be SCs
either in the State or the Union territory as the case may be. Similarly, Article
342 makes a provision for the issue of public notification in respect of STs.
Under Article 338 (3), it is provided that references to the SCs and STs shall
be construed as including references to such other Backward Classes as the
President may, on receipt of the report of a Commission appointed under
Article 340(1), by order, specify and also to the Anglo Indian community. It
would thus be seen that this provision contemplates that some Backward
Classes may by the Presidential order be included in scheduled castes and
tribes. That helps to bring out the point that the Backward Classes for whoseDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

                                          41
improvement special provision is contemplated by Article 15 (4) are in the
matter of their backwardness comparable to SCs and STs.
47.     In M. R. Balaji (supra), the validity of an order dated 31.07.1962 passed
by the State of Mysore under Article 15(4) of the Constitution of India
superseding all previous orders for reservation of seats in favour of the SCs,
STs as well as OBCs was questioned. The OBCs were divided into two
categories, namely, Backward Classes and More Backward Classes. 50%
was fixed as the quota for the reservation of seats for OBCs; 28% out of this
was reserved for Backward Classes so called and 22% for More Backward
Classes. 15% seats was reserved for the SCs and 3% for the STs. The result
of the order was that 68% of the seats available for admission to the
Engineering and Medical Colleges and to other Technical Institutions specified
in the aforesaid order, is reserved and only 32% was available to the merit
pool.
48.     On consideration of the materials on record as well as Nagan Gowda
Committee recommendations, the Hon'ble Supreme Court held that the
classification of the socially backward classes of citizens made by the State
proceeded on the only consideration of their castes without regard to the other
factors which are relevant and therefore, the social backwardness of the
communities to whom the order applied had been determined in a manner
which is not permissible under Article 15(4) and that itself would introduce an
infirmity which is fatal to the validity of the said classification. It was held that
the sub-classification made by the order between Backward Classes and
More Backward Classes is not justified under Article 15(4) which authorisesDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

special provision being made for the really backward classes. By introducing
                                         42
two categories, the order purported to devise measures for the benefit of all
the classes of citizens who are less advanced compared to the most
advanced classes in the State which is not within the scope of Article 15(4).
49.   It was observed that in considering the scope and extent of the
expression 'backward classes' under Art. 15(4), it is necessary to remember
that the concept of backwardness is not intended to be relative in the sense
that any classes who are backward in relation to the most advanced classes
of the society should be included in it. If such relative tests were to be applied
by reason of the most advanced classes, there would be several layers or
strata of backward classes and each one of them may claim to be included
under Article 15(4). The backwardness under Article 15(4) must be social and
educational. It is not either social or educational but it is both social and
educational.
50.   While considering the question of social backwardness observed that
the problem of determining as to who are socially backward classes is very
complex and for determination of which an elaborate investigation and
collection of data and examining the said data in a rational and scientific way
will be required. It was observed that the castes cannot be the sole or the
dominant test to consider in determining social backwardness of groups or
classes of citizens as social backwardness is on the ultimate analysis the
result of poverty, to a very large extent. It is in that context it was held that
both caste and poverty have relevance in determining backwardness of
citizens.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

                                       43
51.   While considering the question of educational backwardness of the
classes of citizens, it was noticed by the Hon'ble Supreme Court that the
impugned order proceeded to deal with the question on the basis of the
average of the student population in the last three High School classes in the
State in relation to a thousand citizens of that community and on the basis of
the figures supplied, the Nagan Gowda Committee came to the conclusion
that the State average of student population in the last three High School
classes of all High Schools in the State was 6.9 per thousand. Accordingly, all
castes whose average was less than 6.9 per thousand be added as backward
community and had further held that if the average of any community was less
than 50% of the State average, it should be recorded as constituting the more
backward classes. The Hon'ble Supreme Court held that assuming that the
test applied is rational and permissible under Article 15(4), then also, if the
State average is 6.9 per thousand, a community which satisfied the said test
or is just below the said test cannot be regarded as educationally backward
classes of citizens and that classes of citizens whose average of student
population works below 50% of the State average, are obviously
educationally backward classes of citizens.
52.   Coming to the question about the extent of the special provision which it
would be competent for the State to make under Article 15(4), in M.R.Balaji
(supra), it was observed that unless the educational and economic interests of
the weaker sections of the people are promoted quickly and liberally, the ideal
of establishing social and economic equality will not be attained and so, there
can be no doubt that Article 15(4) authorises the State to take adequate stepsDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

to achieve the object which it has in view. The Hon'ble Supreme Court
                                         44
emphasised that consideration of national interest and the interests of the
community or society as a whole cannot be ignored in determining the
question as to whether the special provision contemplated by Article 15(4) can
be special provision which excludes the rest of the society altogether. It was
observed that if admission to professional and technical colleges is unduly
liberalised, it will be idle to contend that the quality of our graduates would not
suffer. While advocating reservation, it was observed that reservation should
and must be adopted to advance the prospects of the weaker sections of the
society. It was also emphasised that while providing for special measures in
that behalf, care should be taken not to exclude admission to higher
educational centres to the deserving and qualified candidates of other
communities. Special provision contemplated by Article 15(4) like reservation
of posts and appointments contemplated by Article 16(4) must be within
reasonable limits. While expressing no opinion categorically and definitely as
to what would be a proper provision to make, it was observed that speaking
generally and in a broad way, a special provision should be less than 50%;
how much less than 50% would depend upon the relevant prevailing
circumstances in each case. Resultantly, the impugned order was held to be a
fraud on the Constitutional power conferred on the State by Article 15(4).
53.   In the majority judgment in Indra Sawhney (supra), at paragraph 681,
the Hon'ble Supreme Court noted eight questions which were framed by the
learned counsel for the parties for consideration and the same read as
follows:
                                45Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

"(I) Whether Article 16(4) is an exception to Article 16(1) and would
be exhaustive of the right to reservation to posts in services under
the State?
(II) What would be the content of the phrase Backward Class in
Article 16(4) of the Constitution and whether caste by itself could
constitute a class and whether economic criterion by itself could
identify a class for Article 16(4) and whether backward Classes in
Article 16(4) would include the Article 46 as well?
(III) If economic criterion by itself could not constitute a Backward
Classes under Article 16(4) whether reservation of posts in
services under the State based exclusively on economic criteria
would be covered by Article 16(1) of the Constitution?
(IV) Can the extent of reservation to posts in the services under
the State under Article 16(4) or, if permitted under Articles 16(1)
and 16(4) together, exceed 50% of the posts in a cadre or Service
under the State or exceed 50% of the appointment in a cadre or
Service in any particular year and can such extent of reservation
be   determined     without    determining    the     inadequacy   of
representation of each class in the different categories and grades
of Services under the State?
(V) Does Article 16(4) permit the classification of 'Backward
Classes' into Backward Classes and Most Backward Classes or
permit classification among them based on economic or other
considerations?Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

                                        46
         (VI) Would making "any provision" under Article 16(4) for
         reservation "by the State" necessarily have to be by law made by
         the Legislatures of the State or by law made by Parliament? Or
         could such provisions be made by an executive order?
         (VII) Will the extent of judicial review be limited or restricted in
         regard to the identification of Backward Classes and the
         percentage of reservations made for such classes, to a
         demonstrably     perverse    identification   or   a   demonstrably
         unreasonable percentage?
         (VIII) Would reservation of appointments or posts "in favour of any
         Backward Class" be restricted to the initial appointment to the post
         or would it extend to promotions as well?
54.   At paragraph 682, the Hon'ble Supreme Court re-framed the questions
as follows:
         "1(a) Whether the 'provision' contemplated by Article 16(4) must
         necessarily be made by the legislative wing of the State?
         (b) If the answer to Clause (a) is in the negative, whether an
         executive order making such a provision is enforceable without
         incorporating it into a rule made under the proviso to Article 309?
         2(a) Whether Clause (4) of Article 16 is an exception to Clause (1)
         of Article 16?Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

         (b) Whether Clause (4) of Article 16 is exhaustive of the special
         provisions that can be made in favour of 'backward class of
                               47
citizens'? Whether it is exhaustive of the special provisions that can
be made in favour of all sections, classes or groups?
(c) Whether reservations can be made under Clause (1) of
Article 16 or whether it permits only extending of preferences/
concessions?
3(a) What does the expression 'backward class of citizens' in
Article 16(4) mean?
(b) Whether backward classes can be identified on the basis and
with reference to caste alone?
(c) Whether a class, to be designated as a backward class, should
be situated similarly to the SCs/STs?
(d) Whether the 'means' test can be applied in the course of
identification of backward classes? And if the answer is yes,
whether providing such a test is obligatory?
4(a). Whether the backward classes can be identified only and
exclusively with reference to economic criteria?
(b) Whether a criteria like occupation-cum-income without
reference to caste altogether, can be evolved for identifying the
backward classes?Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

5. Whether the backward classes can be further categorised into
backward and more backward categories?
6. To what extent can the reservation be made?
                                 48
(a) Whether the 50% rule enunciated in Balaji a binding rule or only
a rule of caution or rule of prudence?
(b) Whether the 50% rule, if any, is confined to reservations made
under Clause (4) of Article 16 or whether it takes in all types of
reservations that can be provided under Article 16?
(c) Further while applying 50% rule, if any, whether an year should
be taken as a unit or whether the total strength of the cadre should
be looked to?
(d) Whether Devadasan was correctly decided?
7. Whether Article 16 permits reservations being provided in the
matter of promotions?
8. Whether reservations are anti-meritian? To what extent are
Articles 335, 38(2) and 46 of the Constitution relevant in the matter
of construing Article 16?
9. Whether the extent of judicial review is restricted with regard to
the identification of Backward Classes and the percentage of
reservations made for such classes to a demonstrably perverse
identification or a demonstrably unreasonable percentage?Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

10. Whether the distinction made in the second Memorandum
between 'poorer sections' of the backward classes and others
permissible under Article 16?
11. Whether the reservation of 10% of the posts in favour of 'other
economically backward sections of the people who are not covered
                                           49
           by any of the existing schemes of the reservations' made by the
           Office Memorandum dated September 25, 1991 permissible under
Article 16?"
55.   In paragraphs 809 and 810, it is stated as follows:
           "809. From the above discussion, the irresistible conclusion that
           follows is that the reservations contemplated in clause (4) of Article
           16 should not exceed 50%.
           810. While 50% shall be the rule, it is necessary not to put out of
           consideration certain extraordinary situations inherent in the great
           diversity of this country and the people. It might happen that in
           farflung and remote areas the population inhabiting those areas
           might, on account of their being out of the mainstream of national life
           and in view of conditions peculiar to and characteristical to them,
           need to be treated in a different way, some relaxation in this strict rule
           may become imperative. In doing so, extreme caution is to be
           exercised and a special case made out."
56.   At paragraph 860, the answers to the questions as framed by the
counsel for the parties and as set out in paragraph 681 were recorded as
follows:Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

           "(1) Article 16(4) is not an exception to Article 16(1). It is an
           instance of classification inherent in Article 16(1). Article 16(4) is
           exhaustive of the subject of reservation in favour of backward
           classes, though it may not be exhaustive of the very concept of
                               50
reservation. Reservations for other classes can be provided under
Clause (1) of Article 16.
(2) The expression 'backward class' in Article 16(4) takes in 'Other
Backward Classes', SCs, STs and may be some other backward
classes as well. The accent in Article 16(4) is upon social
backwardness.     Social    backwardness   leads   to   educational
backwardness and economic backwardness. They are mutually
contributory to each other and are intertwined with low occupations
in the Indian society. A caste can be and quite often is a social
class in India. Economic criterion cannot be the sole basis for
determining the backward class of citizens contemplated by Article
16(4). The weaker sections referred to in Article 46 do include
SEBCs referred to in Article 340 and covered by Article 16(4).
(3) Even under Article 16(1), reservations cannot be made on the
basis of economic criteria alone.
(4) The reservations contemplated in Clause (4) of Article 16
should not exceed 50%. While 50% shall be the rule, it is
necessary not to put out of consideration certain extraordinary
situations inherent in the great diversity of this country and theDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

people. It might happen that in far-flung and remote areas the
population inhabiting those areas might, on account of their being
out of the mainstream of national life and in view of the conditions
peculiar to and characteristic of them need to be treated in a
different way, some relaxation in this strict rule may become
                               51
imperative. In doing so, extreme caution is to be exercised and a
special case made out.
For applying this rule, the reservations should not exceed 50% of
the appointments in a grade, cadre or service in any given year.
Reservation can be made in a service or category only when the
State is satisfied that representation of backward class of citizens
therein is not adequate.
To the extent, Devadasan is inconsistent herewith, it is over-ruled.
(5) There is no constitutional bar to classification of backward
classes into more backward and backward classes for the
purposes of Article 16(4). The distinction should be on the basis of
degrees of social backwardness. In case of such classification,
however, it would be advisable- nay, necessary- to ensure
equitable distribution amongst the various backward classes to
avoid lumping so that one or two such classes do not eat away the
entire quota leaving the other backward classes high and dry.
For excluding 'creamy layer', an economic criterion can be adopted
as an indicium or measure of social advancement.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

(6) A 'provision' under Article 16(4) can be made by an executive
order. It is not necessary that it should be made by Parliament/
Legislature.
                                             52
        (7) No special standard of judicial scrutiny can be predicated in
        matters arising under Article 16(4). It is not possible or necessary
        to say more than this under this question.
        (8) Reservation of appointments or posts under Article 16(4) is
        confined to initial appointment only and cannot extend to providing
        reservation in the matter of promotion. We direct that our decision
        on this question shall operate only prospectively and shall not
        affect promotions already made, whether on temporary, officiating
        or regular/ permanent basis. It is further directed that wherever
        reservations are already provided in the matter of promotion - be it
        Central Services or State Services, or for that matter services
        under any Corporation, authority or body falling under the definition
        of 'State' in Article 12 - such reservations may continue in operation
        for a period of five years from this day. Within this period, it would
        be open to the appropriate authorities to revise, modify or re-issue
        the relevant rules to ensure the achievement of the objective of
Article 16(4). If any authority thinks that for ensuring adequate
        representation of 'backward class of citizens' in any service, class
        or category, it is necessary to provide for direct recruitment therein,
        it shall be open to it to do so."
57.   In R.K.Sabharwal (supra), it was laid down that Article 16(4) of theDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Constitution of India permits the State Government to make any provision for
the reservation of appointments or posts in favour of any backward class of
citizen which, in the opinion of the State is not adequately represented in the
services under the State. It is, therefore, incumbent on the State Government
                                       53
to reach a conclusion that the backward class/classes for which the
reservation is made is not adequately represented in the State Services.
While doing so the State Government may take the total population of a
particular backward class and its representation in the State services. When
the State Government after doing the necessary exercise makes the
reservation and provides the extent of percentage of posts to be reserved for
the said backward class then the percentage has to be followed strictly. The
prescribed percentage cannot be varied or changed simply because some of
the members of the backward class have already been appointed/promoted
against the general seats. The roster point which is reserved for a backward
class has to be filled by way of appointment/promotion of the member of the
said class. No general category candidate can be appointed against a slot in
the roster which is reserved for the backward class. The fact that considerable
number of members of a backward class have been appointed/promoted
against general seats in the State services may be a relevant factor for the
State Government to review the question of continuing reservation for the said
class but so long as the instructions/rules providing certain percentage of
reservations for the backward classes are operative the same have to be
followed.
58.   In M. Nagaraj (supra), the petitioner had prayed for quashing of the
Constitution (Eighty-Fifth Amendment) Act, 2001 inserting Article 16(4A) of theDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Constitution retrospectively from 17.6.1995 providing reservation in promotion
with consequential seniority as being unconstitutional and violative of the
basic structure. Article 16(4A) is inspired by the observations in Indra
Sawhney (supra) vide paragraphs 802 and 803 in which the Hon'ble Supreme
                                        54
Court had observed that in order to avoid lumping of OBC, SC and ST which
would make OBC take away all the vacancies leaving SC and ST high and
dry, the State concerned was entitled to categorise and sub- classify SCs and
STs on one hand vis-a-vis OBC on the other hand. In paragraphs 121, 122,
123, it was observed as follows:
      "121. The impugned constitutional amendments by which Articles
      16(4A) and 16(4B) have been inserted flow from Article 16(4). They do
      not alter the structure of Article 16(4). They retain the controlling factors
      or the compelling reasons, namely, backwardness and inadequacy of
      representation which enables the States to provide for reservation
      keeping in mind the overall efficiency of the State administration under
Article 335. These impugned amendments are confined only to SCs
      and STs. They do not obliterate any of the constitutional requirements,
      namely, ceiling limit of 50% (quantitative limitation), the concept of
      creamy layer (qualitative exclusion), the sub-classification between
      OBCs on one hand and SCs and STs on the other hand as held in
      Indra Sawhney, the concept of post-based roster with inbuilt concept of
      replacement as held in R.K. Sabharwal.
      122. We reiterate that the ceiling limit of 50%, the concept of creamy
      layer and the compelling reasons, namely, backwardness, inadequacyDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

      of representation and overall administrative efficiency are all
      constitutional requirements without which the structure of equality of
      opportunity in Article 16 would collapse.
                                         55
       123. However, in this case, as stated above, the main issue concerns
       the "extent of reservation". In this regard the State concerned will have
       to show in each case the existence of the compelling reasons, namely,
       backwardness, inadequacy of representation and overall administrative
       efficiency before making provision for reservation. As stated above, the
       impugned provision is an enabling provision. The State is not bound to
       make reservation for SCs/STs in matter of promotions. However if they
       wish to exercise their discretion and make such provision, the State
       has to collect quantifiable data showing backwardness of the class and
       inadequacy of representation of that class in public employment in
       addition to compliance of Article 335. It is made clear that even if the
       State has compelling reasons, as stated above, the State will have to
       see that its reservation provision does not lead to excessiveness so as
       to breach the ceiling limit of 50% or obliterate the creamy layer or
       extend the reservation indefinitely."
59.   In Ashoka Kumar Thakur (supra), insertion of Article 15(5) by the
Constitution (Ninety-third Amendment) Act, 2005, which reads as under, was
challenged:
       "15. (5) Nothing in this article or in sub-clause (g) of Clause (1) of
Article 19 shall prevent the State from making any special provision, by
       law, for the advancement of any socially and educationally backwardDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

       classes of citizens or for the Scheduled Castes or the Scheduled
       Tribes insofar as such special provisions relate to their admission to
       the educational institutions including private educational institutions,
                                         56
       whether aided or unaided by the State, other than the minority
       educational institutions referred to in Clause (1) of Article 30".
60.   After the above Constitution (Ninety-third Amendment Act), 2005, the
Parliament passed Central Educational Institutions (Reservation in Admission)
Act 2006 (Act 5 of 2007) wherein Section 3 provided for reservation of 15%
seats for Scheduled Castes, 7 ½ % of seats for Scheduled Tribes and 27% for
Other Backward Classes in the State aided institutions which were defined as
"Central Educational Institutions". The order of the Court in Ashoka Kumar
Thakur (supra) was as follows:
       "668. The Constitution (Ninety-third Amendment) Act, 2005, is valid
       and does not violate the "basic structure" of the Constitution so far as it
       relates to the State-maintained institutions and aided educational
       institutions.   Question    whether     the    Constitution    (Ninety-third
       Amendment) Act, 2005 would be constitutionally valid or not so far as
       "private unaided" educational institutions are concerned, is not
       considered and left open to be decided in an appropriate case.
       Bhandari J, in his opinion, has, however, considered the issue and has
       held that the Constitution (Ninety-third Amendment) Act, 2005 is not
       constitutionally valid so far as private unaided educational institutions
       are concerned.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

       669. Act 5 of 2007 is constitutionally valid subject to the definition of
       "Other Backward Classes" in Section 2(g) of Act 5 of 2007 being
       clarified as follows: If the determination of "Other Backward Classes"
                                         57
       by the Central Government is with reference to a caste, it shall exclude
       the "creamy layer" among such caste.
       670. Quantum of reservation of 27% of seats to Other Backward
       Classes in the educational institutions provided in the Act is not illegal.
       671. Act 5 of 2007 is not invalid for the reason that there is no time-limit
       prescribed for its operation but majority of Judges are of the view that
       the review should be made as to the need for continuance of
       reservation at the end of 5 years.
       672. The writ petitions are disposed of in the light of majority judgment.
       However, in Contempt Petition No. 112 of 2007 in WPC No. 265 of
       2006, no orders are required."
61.   In Union of India v. Ramesh Ram & Others, reported in (2010) 7 SCC
234, a Constitution Bench reiterated that the aggregate reservation should not
exceed 50% of all the available vacancies, in accordance with the decision in
Indra Sawhney (supra).
62.   In Jarnail Singh & Others-I (supra), the controversy centered around
interpretation of Articles 16(4-A) and 16(4-B), 335, 341 and 342 of the
Constitution of India. Arguments were advanced for reconsideration of the
judgment rendered in Nagaraj (supra), which is a later judgment, on the
ground that it was in conflict with E.V.Chinnaiah v. State of A.P., reported inDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

(2005) 1 SCC 394 as well as on some other grounds. It was observed by the
Hon'ble Supreme Court that in E.V.Chennaiah (supra), the Supreme Court
was dealing with a completely different problem, apart from dealing with a
State statute and not a constitutional amendment, as was dealt in Nagaraj
                                         58
(supra). However, it was held that the observations in Nagaraj (supra) that
the State has to collect quantifiable data showing backwardness of the SCs
and STs was contrary to the decision in Indra Sawhney (supra) and therefore
had to be declared as bad on that ground. It was observed that the whole
object of reservation is to see that the backward classes of citizens move
forward so that they may march hand in hand with other citizens on an equal
basis. This will not be possible if only the creamy layer within that class bag all
the coveted jobs in the public sector and perpetuate themselves, leaving the
rest of the class as backward as they always were. This being the case, it is
clear that when a court applies the creamy layer principle to SCs and STs, it
does not in any manner tinker with the Presidential List under Article 341 and
342 of the Constitution of India. The caste or group or sub-group named in the
said List continues exactly as before. It is only those persons within that group
or sub-group who have come out of untouchability or backwardness by virtue
of belonging to the creamy layer, who are excluded from the benefit of
reservation. Even these persons who are contained within the group or sub-
group in the Presidential Lists continue to be within those Lists. It is only when
it comes to the application of the reservation principle under Articles 14 and
16 that the creamy layer within that sub-group is not given the benefit of such
reservation. In view of the above, the Hon'be Supreme Court held that when
in Nagaraj (supra), when the creamy layer test to SCs and STs was applied inDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

exercise of application of the basic structure test to uphold the constitutional
amendments leading to Articles 16(4-A) and 16(4-B), it did not in any manner
interfere with Parliament's power under Article 341 and 342, and therefore, in
                                          59
Jarnail Singh-I (supra), it was observed that there was no necessity to refer
the judgment in Nagaraj (supra) to a Seven-Judge Bench.
63.   In B.K. Pavitra (supra), the Hon'ble Supreme Court, observed that for
equality to be truly effective or substantive, the principle must recognize
existing inequalities in society to over come them. Reservations are thus not
an exception to the rule of equality of opportunity. They are rather the
fulfilment of effective and substantive equality by accounting for the structural
conditions into which people are born. If Article 16(1) merely postulates the
principle of formal equality of opportunity, then Article 16(4), by enabling
reservations due to existing inequalities, becomes an exception to the strict
rule of formal equality in Article 16(1). However, Article 16(1) itself sets out the
principle of substantive equality including the recognition of existing
inequalities, then Article 16(4) becomes the enunciation of one particular facet
of the rule of substantive equality set out in Article 16(1). With regard to
adequacy of representation, it was observed that the same has to be
assessed with reference to a benchmark on adequacy, which conventionally,
the same is linked by the State and Central Governments the percentage of
reservation for the SCs and STs to their percentage of population and
accordingly it was held that it is open to the State to make reservation in
promotion for SCs and STs proportionate to their representation in general
population.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

64.   In Dr. Jaishri Laxmanrao Patil (supra), six questions were formulated
which read as follows:
         "(1) Whether judgment in Indra Sawhney v. Union of India needs to
                               60
be referred to a larger Bench or requires a re-look by the larger
Bench in the light of subsequent constitutional amendments,
judgments and changed social dynamics of the society, etc.?
(2) Whether Maharashtra State Reservation (of Seats for Admission
in Educational Institutions in the State and for Appointments in the
Public Services and Posts under the State) for Socially and
Educationally Backward Classes (SEBC) Act, 2018 as amended in
2019 granting 12% and 13% reservation for Maratha community in
addition to 50% social reservation is covered by exceptional
circumstances as contemplated by the Constitution Bench in Indra
Sawhney case?
(3) Whether the State Government on the strength of Maharashtra
State Backward Class Commission Report chaired by M.C.Gaikwad
has made out a case of existence of extraordinary situation and
exceptional circumstances in the State to fall within the exception
carved out in the judgment of Indra Sawhney case?
(4) Whether the Constitution (One Hundred and Second) Amendment
deprives the State Legislature of its power to enact a legislation
determining the socially and economically backward classes and
conferring the benefits of the said community under its enablingDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

power?
(5) Whether, State power to legislate in relation to "any backward
class" under Article 15(4) and 16(4) is anyway abridged by Article
342-A read with Article 366(26-C) of the Constitution of India?
                                          61
           (6) Whether, Article 342-A of the Constitution abrogates States'
           power to legislate or classify in respect of "any backward class of
           citizens" and thereby affects the federal policy/structure of the
           Constitution of India? "
65.   Hon'ble Justice L. Nageswara Rao, Hon'ble Justice Hemant Gupta and
Hon'ble Justice S. Ravindra Bhatt, concurred with Hon'ble Justice Ashok
Bhushan and Hon'ble Justice S. Abdul Nazir in respect of question No. 1, 2
and 3 whereas, with regard to question No. 4, 5 and 6, Hon'ble Justice L.
Nageswara Rao and Hon'ble Justice Hemant Gupta concurred with Hon'ble
Justice S. Ravindra Bhatt.
66.   At paragraphs 10 and 194, Hon'ble Justice S. Ravindra Bhatt stated as
follows:
           "10.     A careful reading of the judgments in Indra Sawhney v.
           Union of India, clarifies that seven out of nine judges concurred that
           there exists a quantitative limit on reservation - spelt out at 50%. In
           the opinion of four judges, therefore, per the judgment of B.P. Jeevan
           Reddy, J., this limit could be exceeded under extraordinary
           circumstances and in conditions for which separate justification has
           to be forthcoming by the State or the agency concerned. However,Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

           there is unanimity in the conclusion by all seven judges that an outer
           limit for reservation should be 50%. Undoubtedly, the other two
           judges, Ratnavel Pandian and P.B. Sawant, JJ. indicated that there is
           no general rule of 50% limit on reservation. In these circumstances,
           given the general common agreement about the existence of an
                                62
outer limit, i.e. 50%, the petitioner's argument about the incoherence
or uncertainty about the existence of the rule or that there were
contrary observations with respect to absence of any ceiling limit in
other judgments (the dissenting judgments of K.Subbarao, in T.
Devadasan v Union of India, the judgments of S.M. Fazal Ali and
Krishna Iyer, JJ. in State of Kerala v N.M. Thomas and the judgment
of Chinnappa Reddy, J. in K.C. Vasanth Kumar v. State of
Karnataka) is not an argument compelling a review or reconsideration
of Indra Sawhney rule.
xxx           xxx        xxx
"194. In view of the above discussion, my conclusions are as follows:
194.1. Re Point (1): Indra Sawhney does not require to be referred to
a larger Bench nor does it require reconsideration in the light of
subsequent constitutional amendments, judgments and changed
social dynamics of the society, for the reasons set out by Ashok
Bhushan, J. and my reasons, in addition.
194.2. Re Point (2): The Maharashtra State Reservation (of Seats for
Admission   in   Educational    Institutions   in   the   State   and   forDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Appointments in the Public Services and Posts under the State) for
Socially and Educationally Backward Classes (SEBC) Act, 2018 as
amended in 2019 granting 12% and 13% reservation for Maratha
community in addition to 50% social reservation is not covered by
exceptional circumstances as contemplated by the Constitution
Bench in Indra Sawhney case. I agree with the reasoning and
                                       63
        conclusions of Ashok Bhushan, J. on this point.
        194.3. Re Point (3): I agree with Ashok Bhushan, J. that the State
        Government, on the strength of the Maharashtra State Backward
        Class Commission Report chaired by M.C. Gaikwad has not made
        out a case of existence of extraordinary situation and exceptional
        circumstances in the State to fall within the exception carved out in
        Indra Sawhney."
67.   Question Nos. 4, 5 and 6 essentially pertain to interpretation of Article
342-A of the Constitution of India, which is not relevant for the purpose of
these cases.
68.   It will also be relevant to take note of paragraphs 459, 474, 476, 480,
481, 515, 520 and 542 dealing with the first three questions rendered in the
judgment of Hon'ble Justice Ashok Bhushan.
        "459. We have noticed above that the majority judgment in Indra
        Sawhney has laid down that reservation shall not exceed 50% as a
        rule. In the majority opinion, however, it was held that looking to the
        diversity of the country there may be some extraordinary situations
        where reservation in exceptional cases is made exceeding 50% limit.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

        In this respect, we may again refer to paras 809 and 810 of the
        judgment of Indra Sawhney by which the above proposition of law
        was laid down. Paras 809 and 810 are to the following effect: (SCC p.
        735)
        "809. From the above discussion, the irresistible conclusion that
        follows is that the reservations contemplated in clause (4) of Article
        16 should not exceed 50%.
                                 64
810. While 50% shall be the rule, it is necessary not to put out of
consideration certain extraordinary situations inherent in the great
diversity of this country and the people. It might happen that in far-
flung and remote areas the population inhabiting those areas might,
on account of their being out of the mainstream of national life and in
view of conditions peculiar to and characteristical to them, need to be
treated in a different way, some relaxation in this strict rule may
become imperative. In doing so, extreme caution is to be exercised
and a special case made out."
xxx           xxx         xxx
474. We may revert back to para 810 where Indra Sawhney has
given illustration which illustration is regarding certain extraordinary
situations. The exact words used in para 810 are: (SCC p. 735)
"810. ... It might happen that in far-flung and remote areas the
population inhabiting those areas might, on account of their being out
of the mainstream of national life and in view of conditions peculiar to
and characteristical to them, need to be treated in a different way,
some relaxation in this strict rule may become imperative. In doingDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

so, extreme caution is to be exercised and a special case made out."
476. This Court in several judgments has noticed that what can be
the extraordinary situations as contemplated in para 810 in few other
cases. We have referred above the three-Judge Bench judgment in
Union of India v. Rakesh Kumar {(2010) 4 SCC 50}, where the three-
Judge Bench held that exceptional case of 50% ceiling can be in
regard to Panchayats in scheduled areas. The above three-Judge
                                  65
Bench has also been approved and reiterated by the Constitution
Bench of this Court in K. Krishna Murthy {(2010) 7 SCC 202} . In the
above cases this Court was examining the reservation in Panchayats.
In the context of Part IX of the Constitution, 50% ceiling principle was
applied but exception was noticed.
xxx            xxx         xxx
480. From the above, it is clear that both the Commission and the
High Court treated the extraordinary situations with regard to
exceeding 50% for granting separate reservation to Marathas, the
fact that population of backward class is 85% and reservation limit is
only 50%. The above extraordinary circumstances as opined by the
Commission and approved by the High Court is not extraordinary
situation as referred to in para 810 of Indra Sawhney judgment. The
Marathas are dominant forward class and are in the mainstream of
national life. The above situation is not an extraordinary situation
contemplated by Indra Sawhney judgment and both the Commission
and the High Court fell in error in accepting the above circumstances
as extraordinary circumstance for exceeding the 50% limit. At thisDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

stage, we may notice that what was said by Dr. Ambedkar in the
Constituent Assembly Debates dated 30-11-1948 while debating draft
Article 10(3) [Article 16(4) of the Constitution]. Dr Ambedkar by giving
an illustration said: (CAD Vol. VII)
"... Supposing, for instance, we were to concede in full the demand of
those communities who have not been so far employed in the public
services to the fullest extent, what would really happen is, we shall be
                                   66
completely destroying the first proposition upon which we are all
agreed, namely, that there shall be an equality of opportunity. Let me
give an illustration. Supposing, for instance, reservations were made
for a community or a collection of communities, the total of which
came to something like 70% of the total posts under the State and
only 30% are retained as the unreserved. Could anybody say that the
reservation of 30% as open to general competition would be
satisfactory from the point of view of giving effect to the first principle,
namely, that there shall be equality of opportunity? It cannot be in my
judgment. Therefore the seats to be reserved, if the reservation is to
be consistent with clause (1) of Article 10, must be confined to a
minority of seats. It is then only that the first principle could find its
place in the Constitution and effective in operation."
481. The illustration given by Dr Ambedkar that supposing 70% posts
are reserved and 30% may retain as unreserved, can anybody say
that 30% as open to general competition would be satisfactory from
point of view of giving effect to the first principle of equality, the
answer given by Dr Ambedkar was in the negative. Thus, ConstituentDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Assembly by giving illustration has already disapproved principle
which is now propounded by the High Court. We cannot approve the
view of the High Court based on the same view taken by the
Commission.
xxx            xxx          xxx
515. The reservation under Article 16(4) of the Constitution is
enabling power of the State to make any provision for reservation of
                                 67
appointment or posts in favour of other backward class of citizens
who in the opinion of the State is not adequately represented in the
services under the State. The condition precedent for exercise of
power under Article 16(4) are that the backward class is not
adequately represented in the services under the State.
xxx           xxx         xxx
520. The word "adequate" is a relative term used in relation to
representation of different caste and communities in public
employment. The objective of Article 16(4) is that backward class
should also be put in mainstream and they are to be enabled to share
power of the State by affirmative action. To be part of public service,
as accepted by the society of today, is to attain social status and play
a role in governance. The governance of the State is through service
personnel who play a key role in implementing government policies,
its obligation and duties. The State for exercising its enabling power
to grant reservation under Article 16(4) has to identify inadequacy in
representation of backward class who is not adequately represented.
For finding out adequate representation, the representation ofDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

backward class has to be contrasted with representation of other
classes including forward classes. It is a relative term made in
reference to representation of backward class, other caste and
communities in public services.
  xxx         xxx         xxx
542. Indra Sawhney has categorically held that what is required by
the State for providing reservation under Article 16(4) is not
                                         68
           proportionate representation but adequate representation. The
           Commission thus proceeds to examine the entitlement under Article
           16(4) on the concept of proportionate representation in the State
           services which is a fundamental error committed by the Commission."
69.   While dealing with the scope and reach of judicial scrutiny in Dr. Jaishri
Laxmanrao Patil (supra), at paragraphs 508, 509 and 515, it is stated as
follows:
           "508. Indra Sawhney had referred to the judgment of this Court in
           Barium Chemicals {AIR 1967 SC 295} for the scope and reach of
           judicial scrutiny. We need to refer the test enunciated in Barium
           Chemicals. The Constitution Bench in Barium Chemicals had
           occasion to consider the expression "if in the opinion of the Central
           Government occurring in Section 237 of the Companies Act, 1956".
           Hidayatullah, J. laid down that no doubt the formation of opinion is
           subjective but the existence of the circumstances relevant to the
           inference as the sine qua non for action must be demonstrable. The
           following observations were made in para 27: ( Barium Chemicals
           case, AIR p. 309)Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

             "27. ... No doubt the formation of opinion is subjective but the
             existence of circumstances relevant to the inference as the sine
             qua non for action must be demonstrable. If the action is
             questioned on the ground that no circumstances leading to an
             inference of the kind contemplated by the section exists, the action
             might be exposed to interference unless the existence of the
             circumstances is made out. As my Brother Shelat has put it
                              69
  trenchantly: (Barium Chemicals case, AIR p. 325, para 64)
 '64. ... It is not reasonable to say that the clause permitted the
  Government to say that it has formed the opinion on circumstances
  which it thinks exist....'
 Since the existence of "circumstances" is a condition fundamental
  to the making of an opinion, the existence of the circumstances, if
  questioned, has to be proved at least prima facie."
509.     Shelat, J. with whom Hidayatullah, J. has agreed in para 63
laid down the following: (Barium Chemicals case, AIR p. 324)
  "63. ... Therefore, the words, "reason to believe" or "in the opinion
  of" do not always lead to the construction that the process of
  entertaining "reason to believe" or "the opinion" is an altogether
  subjective process not lending itself even to a limited scrutiny by
  the court that such "a reason to believe" or "opinion" was not
  formed on relevant facts or within the limits or as Lord Radcliffe
  and Lord Reid called the restraints of the statute as an alternative
  safeguard to rules of natural justice where the function is
  administrative."Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

  515.    The reservation under Article 16(4) of the Constitution is
  enabling power of the State to make any provision for reservation
  of appointment or posts in favour of other backward class of
  citizens who in the opinion of the State is not adequately
  represented in the services under the State. The conditions
  precedent for exercise of power under Article 16(4) are that the
  backward class is not adequately represented in the services
                                        70
           under the State."
70.   At paragraph 688, conclusions in Dr. Jaishri Laxmanrao Patil (supra) is
recorded. Conclusions relevant for our purpose, namely, 688.1 to 688.21 are
reproduced here in below.
           "688. From our foregoing discussion and finding we arrive at the
           following conclusions:
           688.1. The greatest common measure of agreement in six
           separate judgments delivered in Indra Sawhney is:
           688.1.1. Reservation under Article 16(4) should not exceed 50%.
           688.1.2. For exceeding reservation beyond 50%, extraordinary
           circumstances as indicated in para 810 of B.P. Jeevan Reddy, J.
should exist for which extreme caution is to be exercised. 688.2. The 50% rule spoken in Balaji and
affirmed in Indra Sawhney is to fulfil the objective of equality as engrafted in Article 14 of which
Articles 15 and 16 are facets. 50% is reasonable and it is to attain the object of equality. To change
the 50% limit is to have a society which is not founded on equality but based on caste rule.
688.3. We are of the considered opinion that the cap on percentage of reservation as has been laid
down by the Constitution Bench in Indra Sawhney is with the object of striking a balance between
the rights under Articles 15(1) and 15(4) as well as Articles 16(1) and 16(4). The cap on percentage is
to achieve principle of equality and with the object to strike a balance which cannot be said to be
arbitrary or unreasonable.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

688.4. Providing reservation for advancement of any socially and educationally backward class in
public services is not the only means and method for improving the welfare of backward class. The
State ought to bring other measures including providing educational facilities to the members of
backward class free of cost, giving concession in fee, providing opportunities for skill development
to enable the candidates from the backward class to be self-reliant.
688.5. There can be no quarrel that society changes, law changes, people change but that does not
mean that something which is good and proven to be beneficial in maintaining equality in the
society should also be changed in the name of change alone. 688.6. When the Constitution Bench in
Indra Sawhney held that 50% is upper limit of reservation under Article 16(4), it is the law which is
binding under Article 141 and to be implemented. 688.7. We find that the Constitution Bench
judgment in Indra Sawhney is also fully applicable in reference to Article 15(4) of the Constitution of
India.
688.8. The setting aside of 50% ceiling by the eleven-Judge Bench in T.M.A. Pai Foundation
{(2002) 8 SCC 481} as was laid down by St. Stephen's case {(1992) 1 SCC 558} i.e. 50% ceiling in
admission in aided minority institutions has no bearing on the principle of 50% ceiling laid down by
Indra Sawhney with respect to reservation. The judgment of T.M.A. Pai was in reference to rights of
minority under Article 30 and is not relevant for reservation under Articles 16(4) and 15(4) of the
Constitution. 688.9. The Constitution (Eighty-first Amendment) Act, 2000 by which clause (4-B)
was inserted in Article 16 makes it clear that ceiling of 50% "has now received constitutional
recognition". 688.10. We fully endorse the submission of Shri Rohatgi that extraordinary situations
indicated in para 810 of Indra Sawhney case were only illustrative and cannot be said to be
exhaustive. We however do not agree with Mr Rohatgi that para 810 provided only a geographical
test. The use of the expression "on being out of the mainstream of national life", is a social test,
which also needs to be fulfilled for a case to be covered by exception.
688.11. We do not find any substance in any of the 10 grounds urged by Shri Rohatgi and Shri Kapil
Sibal for revisiting and referring the judgment of Indra Sawhney to a larger Bench. 688.12. What
was held by the Constitution Bench in Indra Sawhney on the relevance and significance of the
principle of stare decisis clearly binds us. The judgment of Indra Sawhney has stood the test of time
and has never been doubted by any judgment of this Court. The Constitution Bench judgment of this
Court in Indra Sawhney neither needs to be revisited nor referred to a larger Bench for
consideration.
688.13. The Constitution Bench in M. Nagaraj does not contain any ratio that ceiling of 50%
reservation may be exceeded by showing quantifiable contemporary data relating to backwardness.
The Commission has completely misread the ratio of the judgment, when the Commission took the
view that on the quantifiable data ceiling of 50% can be breached.
688.14. The Commission and the High Court found existence of the extraordinary situations with
regard to exceeding 50% ceiling in respect to grant of separate reservation to Marathas because the
population of backward class is 80% and reservation limit is only 50%, containing the Marathas in
pre-existing reservation for OBC shall not be justice to them, which circumstance is not coveredDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

under the parameters indicated in Indra Sawhney case as extraordinary circumstance to breach 50%
ceiling. 688.15. We have found that no extraordinary circumstances were made out in granting
separate reservation of Maratha community by exceeding the 50% ceiling limit of reservation. The
2018 Act violates the principle of equality as enshrined in Article 16. The exceeding of ceiling limit
without there being any extraordinary circumstances clearly violates Articles 14 and 16 of the
Constitution which makes the enactment ultra vires. 688.16. The proposition is well settled that
Commissions' reports are to be looked into with deference. However, one of the parameter of
scrutiny of Commission's report as approved by this Court is that on the basis of data and materials
referred to in the report whether conclusions arrived at by the Commission are justified.
688.17. The measures taken under Articles 15(4) and 16(4) can be examined as to whether they
violate any constitutional principle, and are in conformity with the rights under Articles 14, 15 and
16 of the Constitution. The scrutiny of measures taken by the State, either executive or legislative,
thus, has to pass the test of constitutional scrutiny.
688.18. The word "adequate" is a relative term used in relation to representation of different castes
and communities in public employment. The objective of Article 16(4) is that backward class should
also be put in mainstream to enable to share power of the State by affirmative action. To be part of
public service, as accepted by the society of today, is to attain social status and play a role in
governance.
688.19. We have examined the issues regarding representation of Marathas in State services on the
basis of facts and materials compiled by Commission and obtained from the States and other
sources. The representation of Marathas in public services in Grades A, B, C and D comes to 33.23%,
29.03%, 37.06% and 36.53% computed from out of the open category filled posts, is adequate and
satisfactory representation of Maratha community. One community bagging such number of posts
in public services is a matter of pride for the community and its representation in no manner can be
said to be not adequate in public services. 688.20. The Constitutional precondition for providing
reservation as mandated by Article 16(4) is that the backward class is not adequately represented in
the public services. The Commission laboured under misconception that unless Maratha community
is not represented equivalent to its proportion, it is not adequately represented. Indra Sawhney has
categorically held that what is required by the State for providing reservation under Article 16(4) is
not proportionate representation but adequate representation. 688.21. The Constitutional
precondition as mandated by Article 16(4) being not fulfilled with regard to Maratha class, both the
Gaikwad Commission's Report/Report of the Gaikwad Commission and consequential legislation
are unsustainable."
71. In Jarnail Singh & Others-II (supra), with regard to proportionate representation as test of
adequacy in promotional posts, the Hon'ble Supreme Court had observed as follows:
"3) PROPORTIONATE REPRESENTATION AS TEST OF ADEQUACY
30. In R.K. Sabharwal (supra), it was observed that State Governments may take the
total population of a particular Backward Class and its representation in the StateDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

services for the purpose of coming to a conclusion that there is inadequate
representation in the State services. In M. Nagaraj (supra), this Court was of the
considered view that the exercise of collecting quantifiable data depends on
numerous factors, with conflicting claims to be optimised by the administration in
the context of local prevailing conditions in public employment. As equity, justice and
efficiency are variable factors and are context-specific, how these factors should be
identified and counter-balanced will depend on the facts and circumstances of each
case. The attempt of the learned Attorney General for India to impress upon this
Court that the proportion of SCs and STs in the population of India should be taken
as the test for determining whether they are adequately represented in promotional
posts, did not yield results. This Court in Jarnail Singh (supra) found no fault with M.
Nagaraj (supra) regarding the test for determining the adequacy of representation in
promotional posts in the State. While emphasising the contrast in the language used
between Article 330 and Articles 16(4-A) and 16(4-B) of the Constitution, this Court
declined the invitation of the learned Attorney General for India to hold that the
proportion of SCs and STs to the population of India should be the test for
determining inadequacy of representation in promotional posts. Therefore, we are
not persuaded to express any opinion on this aspect. It is for the State to assess the
inadequacy of representation of SCs and STs in promotional posts, by taking into
account relevant factors."
72. While striking down Rule 9.3 of the Madhya Pradesh Medical and Dental Graduate Entrance
Examination Rules, 2003, which increased the percent of reservation to 56.94%, the High Court of
Madhya Pradesh, in Mayank Jain (supra) had observed as follows:
"In this context we may refer with profit to the Constitution Bench decision rendered
in the case of Dr. Preeti Shrivastava v. State of M.P. and Ors., {AIR 1999 SC 2894},
wherein the Apex Court held as under:--
"...... While the object of Article 15(4) is to advance equality principle by providing for
protective discrimination in favour of the weaker sections so that they may become
stronger and be able to compete equality with others more fortunate, one can not also
ignore the wider interests of society while devising such special provisions.
Undoubtedly, protective discrimination in favour of backward, including Scheduled
Castes and Scheduled Tribes is as much in the interest of society as the protected
groups. At the same time, there may be other national interests, such as promoting
excellence at the highest level and providing the best talent in the country with the
maximum available facilities to excel and contribute to society, which have also to be
borne in mind. Special provisions must strike a reasonable balance between these
diverse national interests. Moreover, study and training at the level of specialities and
super-specialities in medicine involve discharging the duties attached to certain
specified medical posts in the hospitals attached to the medical institutions giving
education in specialities and super-specialities......."Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

We are conscious that the aforesaid decision was rendered in the context of reservation for
admission to the Post Graduate Course in various professional faculties but we have referred to the
aforesaid paragraph to indicate what is the view of the Apex Court in relation to weaker sections and
what their Lordships have stated therein. We may repeat at the cost of repetition that the cause put
forth by the State for advancement of the weaker section can not distort the dictum of the Apex
Court. It was contended before us that in certain exceptional cases extra reservation is permissible.
But, in our considered opinion, the present one does not fit into the said prism. When the students
are appearing in the examination harbouring hope that when they would qualify they would be
selected their hopes can not be marred or smothered by ushering in a rule of this type. The said Rule
does not subserve the constitutional philosophy and as we have noted earlier it runs contrary to the
principles laid down by the Apex Court. If we allow ourselves to say so, an innovative attempt has
been made to frame a rule to enhance the conception of reservation which the law prescribes. By no
stretch of rationalization or ratiocination it can be conceived that this is the field where this
innovative approach is warranted. On the contrary, it is absolutely unthinkable."
73. Grant of reservation under Articles 15(4) or 16(4), either by legislative measure or by an
executive order are measures which act as a tool and means to attain the constitutional goal of
fulfilment of the principle of equality. Such reservation are enabling provisions to facilitate the State
to make any provision for reservation for appointment on a post in favour of backward class of
citizens. Unless the educational and economic interest of the weaker sections of the people are
promoted by affirmative action, the constitutional goal of establishing social and economic equality
will not be attained and as such, while Article 15(4) provides for making any special provision for the
advancement of any socially and educationally backward classes of citizens or for the SCs and STs,
Article 15(5) provides for making any special provision for advancement of any socially and
educationally backward classes of citizens or for the SCs and STs relating to their admission to
educational institutions including aided or unaided private educational institutions other than
minority educational institutions referred to in Article 30(1). It is worth remembering that framers
of the Constitution intended the Constitution to bring in winds of social change in a caste-ridden
society. It needs no reiteration that equality has been recognized as a basic feature of our
Constitution and to preserve equality, a harmonious balance has to be struck to ensure that the
fundamental ethos and the spirit as encapsulated in Articles 14 and 16 reign supreme and at the
same time, to ensure that it galvanises social and economic upliftment of the backward classes. The
condition precedent for exercise of power under Article 16(4) is that backward class is not
adequately represented in the services under the State. Reservation can be made in service and
educational institutions only when the State is satisfied that representation of backward classes of
citizens therein is not adequate. In order to ascertain the extent of reservation, the State has to
justify the existence of compelling reasons, namely, backwardness, inadequacy in representation
and overall administrative efficiency before making provision for reservation.
74. The Hon'ble Supreme Court in Indra Sawhney (supra) had observed that not only should a class
be a backward class for meriting reservations, it should also be inadequately represented in the
services under the State. The language of Clause (4) makes it clear that the question whether a
backward class of citizens is not adequately represented in the services under the State is a matter
within the subjective satisfaction of the State. This opinion can be formed by the State on its own,Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

i.e., on the basis of the material it has in its possession already or it may gather such material
through a Commission/Committee, person or authority. There must be some material upon which
the opinion is formed. While observing that in a matter of the present nature, the Court should show
due deference to the opinion of the State, it does not, however, mean that the opinion formed is
beyond judicial scrutiny altogether. It was further held that Article 16(4) speaks about adequate
representation and not proportionate representation and adequate representation cannot be read as
proportionate representation. Accordingly, it was held that it was not possible to accept the theory of
proportionate representation, though the proportion of population of backward classes to the total
population would certainly be relevant. It was held that the power conferred by Article 16(4) should
be exercised reasonably and fairly, in a fair manner and within reasonably limits - and what is more
reasonable than to say that reservation under Clause 16(4) shall not exceed 50% of the
appointments or posts, barring certain extra-ordinary situations. Accordingly, it was held that it is
an irresistible conclusion that the reservation contemplated in Article 16(4) should not exceed 50%.
While holding 50% to be the rule, it was also observed that it is necessary to point out certain
extraordinary situations inherent in the great diversity of our country and the people. It might so
happen that in far-flung and remote areas the population inhabiting those areas might, on account
of their being out of the main stream of national life and in view of conditions peculiar to and
characteristical to them, they need to be treated in a different way, some relaxation in this strict rule
may become imperative. In doing so, extreme caution is to be exercised and a special case made out.
The Hon'ble Supreme Court also held that for the purpose of applying the rule of 50%, a year should
be taken as the unit and not the entire strength of the cadre, service or the unit, as the case may be.
75. It will be appropriate to extract from paragraph 6 of the return filed to the application for stay
wherein the number of posts for SCs, STs and OBCs in the State and the appointments made are
indicated.
"6..........It is humbly submitted that, in fact, the total number of vacancies with
respect to STs, SCs and OBCs in the State are currently as follows for the State-cadre
posts: for SCs there are 240 sanctioned Class I posts out of which 98 are filled
thereby resulting in a vacancy of 142 posts (i.e. 40.83%); for STs there are 483
sanctioned Class I posts out of which 155 are filled thereby resulting in a vacancy of
327 posts (i.e. 23.86%); for OBCs there are 230 sanctioned Class I posts out of which
103 are filled thereby resulting in a vacancy of 131 posts (i.e. 40.02%). Similarly, for
SCs there are 3283 sanctioned Class II posts out of which 2000 are filled thereby
resulting in a vacancy of 1283 posts (i.e. 60.92%); for STs there are 4758 sanctioned
Class II posts out of which 2594 are filled thereby resulting in a vacancy of 2164 posts
(i.e. 54.52%); for OBCs there are 3020 sanctioned Class II posts out of which 1545 are
filled thereby resulting in a vacancy of 1475 posts (i.e. 51.16%). Then, for SCs there
are 13948 sanctioned Class III posts out of which 9449 are filled thereby resulting in
a vacancy of 4499 posts (i.e. 67.74%); for STs there are 23816 sanctioned Class III
posts out of which 20662 are filled thereby resulting in a vacancy of 3154 posts (i.e.
86.76%); for OBCs there are 10971 sanctioned Class III posts out of which 12802 are
filled thereby resulting in a surplus of 1831 posts (i.e. 116.69%). Finally, for SCs there
are 1125 sanctioned Class IV posts out of which 768 are filled thereby resulting in aDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

vacancy of 357 posts (i.e. 68.27%); for STs there are 1817 sanctioned Class III posts
out of which 1158 are filled thereby resulting in a vacancy of 659 posts (i.e. 63.73%);
for OBCs there are 1336 sanctioned Class III posts out of which 880 are filled thereby
resulting in a vacancy of 456 posts (i.e. 65.87%).
Moreover, with respect to district-cadre posts in the State the figures are as follows:
for SCs there are 15540 sanctioned Class III posts out of which 9564 are filled thereby
resulting in a vacancy of 5976 posts (i.e. 61.54%); for STs there are 25290 sanctioned
Class III posts out of which 18149 are filled thereby resulting in a vacancy of 7141
posts (i.e. 71.76%); for OBCs there are 14027 sanctioned Class III posts out of which
10846 are filled thereby resulting in a vacancy of 3181 posts (i.e. 77.32%). Finally, for
SCs there are 3370 sanctioned Class IV posts out of which 2628 are filled thereby
resulting in a vacancy of 742 posts (i.e. 77.98%); for STs there are 13180 sanctioned
Class III posts out of which 6080 are filled thereby resulting in a vacancy of 7100
posts (i.e. 46.13%); for OBCs there are 4249 sanctioned Class III posts out of which
4894 are filled thereby resulting in a surplus of 645 posts (i.e. 115.18%).
In any event, it is humbly submitted that the State Government is duty bound to
implement the law enacted by the legislature, and thus the impugned amendment."
76. A perusal of the above would go to show that a large number of vacancies which are specifically
earmarked for STs, SCs and OBCs are not filled up. There is no explanation whatsoever as to why
such vacancies are lying unfilled and for how long.
77. In paragraph 17 of the said additional return, it is stated as follows:
"17. That the facts and figures encapsulated in the following tables, clearly provide
the basis and justification in the present form and manner in the State of
Chhattisgarh, considering the overall picture in the State, which is predominantly
populated by tribals and is socially, economically and educationally backward.
Table 1 SC, ST and OBC Representation among Candidates Selected by Chhattisgarh
State PSC through Open Competition (i.e., without the Aid of Reservation) Year Total
Number Number of SC Percentage of Number of Percentage Number of Percentage
of Candidates candidates SC candidates ST of ST OBC of OBC Selected Selected
through to total candidates candidates to candidates candidates Through Open Open
candidates Selected total Selected to total Competition Competition (3/2x100)
through candidates through candidates Open (5/2x100) Open (7/2x100)
Competition Competition (1) (2) (3) (4) (5) (6) (7) (8) 2007 150 1 0.67 0 0.00 22
14.67 2008 76 1 1.32 6 7.89 15 19.74 2009 422 30 7.11 73 17.30 76 18.01 2010 128 2
1.56 5 3.91 13 10.16 2011 41 3 7.32 2 4.88 9 21.95 2012 246 4 1.63 6 2.44 80 32.52
Total 1063 41 3.86 92 8.65 215 20.23 Population 11.6 31.8 Estimated proportions to
be 42% Table 2 SC, ST and OBC representation among Students selected for
MBBS/BDS course through Open Competition, i.e., without the aid of Reservation, inDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

Pre-Medical Test Year Total No. Seats No. of ST % age of ST No of SC % age of No. of
OBC % age of allotted for Open candidates candidates Candidates OBC Candidates
OBC Competition (i.e., selected Selected Selected candidates Selected candidates
Non-Reserved through through through Selected through Selected seats) open open
Open through Open through open competition competition Competition open
Competition competition competition 2008 153 1 0.65 1 0.65 26 16.99 2009 168 2
1.19 2 1.19 17 10.12 2010 190 0 0.00 1 0.53 21 11.05 2011 169 1 0.59 1 0.59 26 15.38
2012 136 0 0.00 0 0.00 27 19.85 Total 816 4 0.49 5 0.61 117 14.34 Table 3 SC, ST and
OBC representation among Students selected for Engineering Course through Open
Competition, i.e., without the aid of Reservation, in Pre-Engineering Test Year Total
No. Seats No of ST % age of ST No of SC % age of No. of OBC % age of OBC allotted
for candidates candidates Candidates OBC Candidates candidates Open selected
Selected Selected candidates Selected Selected Competition through open through
through Selected through through open (i.e., Non- competition open Open through
Open competition Reserved competition Competition open Competition seats)
competition 2008 3229 26 0.81 69 2.14 403 12.48 2009 6682 16 0.24 51 0.76 304
4.55 2010 8196 36 0.44 48 0.59 310 3.78 2011 7424 62 0.84 68 0.92 338 4.55 2012
6448 31 0.48 48 0.74 279 4.33 Total 31979 171 0.53 284 0.89 1634 5.11 Table 4
Distribution households of social groups in Chhattisgarh by employment status (as
per NSSO, 61 st round, 2004-05 survey) ST SC OBC Others All Rural I. Rural
Self-employed in agriculture 52.3 21.3 32.6 39.1 38.6 in non-agriculture 2.6 4.8 8.6
24.1 6.5 in all 54.9 26.1 41.2 63.2 45.1 II. Rural Labour Agricultural Labour 29.5 54.3
41.4 12.0 37.5 Other Labour 4.7 9.8 8.1 8.4 7.1 in all 34.2 64.1 49.5 20.4 44.6 URBAN
ST SC OBC Others All I. Casual Labour 12.0 19.9 26.1 1.3 14.2 Table 5 Distribution of
household of social groups in Chhattisgarh by monthly per capita expenditure (Rs.)
(as per NSSO, 61st round, 2004-05 survey) RURAL ST SC OBC OTHERS ALL Upto
Rs.510 79.1 73.3 64.2 56.1 70.8 Rs.510 and 20.8 26.6 36.0 43.9 29.2 above URBAN
1. Less than 14.5 5.9 7.4 0.1 5.5 Rs. 335
2. Rs. 2540 12.6 1.9 0.3 11.2 6.2 and above Table 6 Proportion of persons (15 yrs &
above) among social groups in Chhattisgarh by level of general education (rural +
urban) (as per NSSO, 61st round, 2004-05 survey) ST SC OBC Others All NOT
LITERATE 54.0 42.9 39.5 13.9 41.6 LITERATE & 28.9 30.6 30.7 20.8 29.0 UPTO
PRIMARY LEVEL MIDDLE 9.7 14.0 15.4 15.7 13.4 SECONDARY 2.8 3.8 4.8 11.0 4.7
HIGHER 2.7 4.8 6.0 16.3 5.9 SECONDARY DIPLOMA/ 0.2 0.4 0.5 3.7 0.8
CERTIFICATE GRADUATE & 1.9 3.4 3.2 18.4 4.5 ABOVE Table 7 Proportion of
persons (15 yrs & above) among social groups in Chhattisgarh by level of general
education (urban) (as per NSSO, 61st round, 2004-05 survey) ST SC OBC Others All
NOT LITERATE 34.4 28.5 25.7 7.3 19.8 LITERATE & 17.6 32.0 26.5 16.8 22.5 UPTO
PRIMARY LEVEL MIDDLE 11.7 14.5 17.8 12.6 14.6 SECONDARY 4.2 8.3 9.4 14.0
10.5 HIGHER 14.6 5.0 11.8 18.2 13.6 SECONDARY DIPLOMA/ 1.7 2.4 1.3 5.6 3.2
CERTIFICATE GRADUATE & 15.9 9.1 7.6 25.3 15.7 ABOVE Table 8 Proportion of
households with no literate adult (15 yrs & above)/adult female member among socialDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

groups in Chhattisgarh (as per NSSO, 61st round, 2004-05 survey) ST SC OBC
Others All RURAL No Literate Adult member 30.5 25.4 21.5 8.3 24.9 No Literate
Female adult 55.1 55.3 48.5 35.4 51.5 Member URBAN No Literate Adult Member
16.8 11.9 12.2 0.4 8.4 No Literate Female adult 30.6 34.6 29.7 4.5 21.4 Member
78. It will also be relevant to extract paragraphs 18 to 30, where explanations to the tables noted
above are given here in below:
"18. The explanations/interpretations of the aforesaid tables are as follows:
19. The answering respondent firstly submits that the correct meaning of the term
'adequacy' or 'inadequacy' of representation in the services of the State must be based
on the number of posts that the SCs, STs and OBCs have been able to secure in open
competition without the aid of reservation. It should not be measured on the basis of
the posts that they have obtained through reservation. This will be clear from the
rationale of providing reservation.
20. If, in Indian society, there was no historically inherited inequality and
deprivation, including denial or deprivation of education to any social class and
consequent impairment of competitive capacity, all social classes would have
obtained posts comparable to their proportion in the population. It is well-known
that Indian society has inherited many centuries of extreme social stratification and
rigid hierarchies through the caste system resulting in exploitation and deprivation of
certain classes and gross inequality in all aspects of life and denial or deprivation of
education and other means of advancement to these classes, who have been classified
by the Indian Constitution as Scheduled Castes, Scheduled Tribes and Socially and
Educationally Backward Classes (or OBCs).
Consequently, at the starting point, that is, prior to reservation, it was well-known that SCs, STs and
OBCs were not able to compete with the SACs and secure a reasonable number of posts in
comparison with their population percentage and, therefore, their representation in the services was
nil or very low. That is why reservation was introduced so that they could secure a reasonable
number of posts without being exposed to competition among unequal social classes. Since the
origin of reservation is in the inability of the SCs, STs and OBCs to secure a reasonable number of
posts in open competition for historical reasons, whether their representation in the services has
become inadequate or remains inadequate has to be seen on the basis of data which does not take
into account posts secured by reservation but only on data on posts secured through open
competition.
21. Table 1 shows the number of posts for which selections were made by the State Public Service
Commission and the number of SCs, STs and OBCs selected by the PSC on the basis of marks
obtained in open competition and without the aid of reservation, bringing out the factum of their
extreme inadequacy of representation. It may be observed from the Table that as against the
proportion of Scheduled Castes in the total population, only one- third of them are able to getDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

selected by the Commission in open competition; and, for the Scheduled Tribes even fewer i.e., less
than one-fourth are able to get selected in open competition as a proportion of their population
percentage.
22. Tables 2 and 3 which though not related to services corroborated the continuing inability of the
SCs, STs and OBCs to obtain their due seats in open competition i.e. without the aid of reservation,
in educational institutions. These tables show the number of students selected in pre-medical tests
(Table-2) and pre- engineering tests (Table-3) from 2008 onwards and the number of SCs, STs and
OBCs who were selected on the basis of marks obtained in open competition without the aid of
reservation. Their inability to compete with the SACs in securing seats in higher education, as a
result of factors such as the centuries-old caste system, naturally reflects in their inability to secure
adequate representation in various services. It was to remedy this unacceptable situation that the
Central Educational Institutions (Reservation in Admissions) Act, 2006 was enacted with near
unanimity by Parliament, which was later upheld by the Supreme Court alongwith the 93rd
Constitutional Amendment that inserted a new clause (5) in Article 15 of the Constitution in so far it
related to institutions covered by the Act.
23. The poor and grossly inadequate representation of SCs, STs and OBCs in access to post under
the State Government or seats in matters of admissions to professional courses of studies as shown
in Tables 1 to 3 is because of their historically inherited inequality over many centuries of
exploitation, deprivation and disadvantages which continue to a large extent even today.
24. Tables 4 to 8 throw light on the deprivation and disadvantages suffered by SCs, STs and OBCs
compared to the SACs in employment/occupational status, monthly per capita expenditure of these
four categories and the level of their general education.
25. Table 4 shows that only 12% of SACs are in rural agricultural labour, which is the most
disadvantaged occupational category. The presence of SACs in rural agricultural labour is the least
while the presence of SCs, OBCs and STs (in that order) in rural agricultural labour is 2½ to 4½
times more than the former's presence. Conversely, the proportion of SACs in cultivation of own
lands, which is the most advantageous occupational category in rural areas, is nearly double that of
SCs and considerably higher than that of OBCs; though a higher percentage of STs are owner
cultivators, their lands are located in remote areas and are so poorly developed and so poorly linked
to the market and have received so little of financial and modern technological inputs, including
irrigation, that the benefit from this for the STs is limited. This can be seen when this table is read
with Table 5 which shows that in rural Chhattisgarh the largest proportion of STs have the lowest
monthly per capita expenditure (MPCE) (which is the statistical method followed to have an idea of
income), followed closely by the SCs and then by the OBCs. The proportion of the SACs in the MPCE
category is the least. Conversely, in the MPCE classes of Rs. 510 and above, the proportion of STs is
the least, closely followed by the SCs, then by the OBCs while the SACs have the highest proportion.
26. Table 4 also shows the gross disadvantage and deprivation of the SCs, OBCs and STs in their
high proportion in urban casual labour which is the most disadvantaged occupational category in
the urban area. In this occupational category, the presence of SACs is almost nil, while OBCs, SCsDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

and STs in that order have higher proportion in this category - many multiples of the SACs, ranging
from multiples of 10 to 20.
27. Table 6 shows the high proportion of STs followed by the SCs and OBCs among non-literate
persons, both rural and urban put together, being about 3 to 4 times more than the SACs.
Conversely, among graduates and above, the proportion of STs, SCs and OBCs is minuscule while
the proportion of SACs is far higher than them, more than 6 to 9 times more than the three
disadvantaged social classes.
28. Table 7 shows the disparity between the SCs, STs and OBCs on one side, and the 'others' (i.e.
SACs) on the other side, at different levels of education in the urban area separately since greater
opportunities for advancement and upward occupational and social mobility exist in urban areas
compared to rural areas. In the lowest ladder of education, namely, illiteracy, the proportion of SACs
is in single digits (7.3%), while illiterate STs, SCs and OBCs are respectively about 5 times, 4 times
and 3½ times more than SAC illiterates. Conversely, in the highest ladder of graduates and above,
which is the educational level that helps most in advancement and upward occupational and social
mobility, the proportion of SACs at 25.3% is the highest, while the SCs, STs and OBCs are
represented in this urban educational category to a much lesser extent than the SACs.
28. Table 8 brings out the very high proportion of STs, SCs and OBCs and the low proportion of
SACs in the matter of proportion of households with no literate adult and no adult female member
for rural and urban areas separately. Among urban SACs, households without a single literate adult
member is virtually nil, while such households are about 40 times more among STs and about 30
times more among SCs and Obcs. More details can be seen in the table.
30. It is humbly submitted that, when examined in the light of the aforesaid positions in law and the
data produced by the answering respondent, it is self-evident that the impugned amendment (and
the consequent notification) is an entirely valid and legitimate exercise of legislative power."
79. The core issue is whether 58% reservation under the Act of 2011 and Act of 2012 is permissible.
Reservation of 76% in district Surguja, 64% in district Surajpur, 80% in district
Balrampur-Ramanujganj, 81% in district Jashpur, 66% in district Koria and 74% in Surguja Division
incorporated in Schedule II Model Roster in Rules of 1998 vide notification dated 29.11.2012, is also
an issue.
80. It was pleaded in a return by the State that the tables forming part of the return provide the
basis for revising the percentage of reservation.
81. A bare glance at table 1 and 2 would show that data incorporated in such table also include the
data for the year 2012. Obviously, the year 2012 could not have been in consideration when the
Amendment Act was enacted in the year 2011. Only on the basis of certain data of six years in
table-1, five years in table 2 and 3 and of the year 2004-2005 in respect of the other five tables,
increase of reservation from 50% to 58% is sought to be justified on the ground that there is
inadequacy of representation in the service of the State and in educational institutions. NoDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

particular reasoning is assigned why reservation in respect of SC is brought down to 12% from
earlier 16% and reservation in ST is increased to 32% from earlier 20%. It is also not the case
presented by the State that the data contained in the tables had been considered. The case presented
in the return is that SC population constitute 12% of the population of the State and ST population
constitute about 31.76%, which is almost 32%, as per 2001 Census and it would appear that
accordingly, reservation is fixed at 12% for SC and 32% for ST proportionate to their respective
percentage of population.
82. Special provisions contemplated by Article 15(4), 15(5) or 16(4) must be within reasonable
limits. As noted earlier, it was observed in Balaji (supra) that a special provision should be less than
50% and how much less than 50% would depend upon the relevant prevailing circumstances in each
case. Any reservation contemplated in Article 16(4) should not exceed 50% was held to be the rule in
Indra Sawhney (supra), which can be breached only on certain extraordinary situations and on a
special case made out. It was also observed that such power has to be exercised with extreme
caution. In Indra Sawhney (supra), it was categorically held what is required by the State for
providing reservation under Article 16 is not proportionate representation, but adequate
representation, which cannot be read as proportionate representation. The said principle was
reiterated in Dr. Jaishri Laxmanrao Patil (supra). In Nagaraj (supra) also, ceiling limit of 50% was
reiterated. It was also held that reservation under Article 16(4) should not exceed 50% and for
exceeding reservation beyond 50%, there has to be extraordinary circumstances as held in Indra
Sawhney (supra). It was further held that the judgment in Indra Sawhney (supra) is fully applicable
in reference to Article 15(4). It was further held that Constitution 81 st Amendment Act 2000 by
which clause 4(B) was inserted in Article 16 makes it clear that ceiling of 50% has now received
constitutional recognition.
83. In view of the above, the principles enunciated regarding the ceiling of 50% in Indra Sawhney
(supra) are also applicable in respect of Article 15(5) of the Constitution.
84. On the basis of materials on record, we are of the opinion that no special case is made out for
breaching the reservation ceiling limit of 50% while increasing the reservation to 58%. Inadequacy
of representation in services under the State or inadequacy of representation in educational
institutions is relevant to the extent reservation is sought to be pegged below 50% but if the ceiling is
to be crossed, then inadequacy in representation cannot be the sole determining factor and there has
to be exceptional circumstances. Failure to secure a job or a seat in an educational institution by a
reserve category candidate competing with candidates belonging to general category cannot be
construed as an exceptional circumstance. Tables 4 to 8 seek to project certain disadvantages
suffered by SCs, STs and OBCs compared to socially advanced castes. The tables do not explain in
any manner why reservation in SCs is to be lowered to 12%, reservation in STs to be increased to
32% and to maintain reservation of 14% in respect of OBCs. No exceptional circumstances is
brought on record and no special case is made out. There is no explanation also as to why
reservation had to be made to the extent of 76%, 80%, 81%, 66%, 74% in the districts of Surguja,
Surajpur, Balrampur-Ramanujganj, Jashpur, Koria and in Surguja Division, respectively.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

85. In view of the above discussion, Act of 2011 and Section 3 of Act of 2012, and notification dated
29.11.2012 in Rules of 1998 so far as it relates to reservation as indicated in Schedule II Model
Roster for districts of Surguja, Surajpur, Balrampur-Ramanujganj, Jashpur, Koria and Surguja
Division, are adjudged and declared unconstitutional.
86. In Madras Institute of Development Studies & Another v. K. Sivasubramaniyan & Others,
reported in (2016) 1 SCC 454, the question that had fallen for consideration was whether a candidate
who consciously takes part in the selection process can turn around and question the method of
selection. The decisions rendered in G. Sarana v. University of Lucknow, reported in (1976) 3 SCC
585, Manak Lal v. Prem Chand Singhvi, reported in AIR 1957 SC 425, Om Prakash Shukla v.
Akhilesh Kumar Shukla, reported in (1986) Supp. SCC 285, Madan Lal v. State of J&K, reported in
(1995) 3 SCC 486, Manish Kumar Sahu v. State of Bihar, reported in (2010) 12 SCC 576, Ramesh
Chandra Shah v. Anil Joshi, reported in (2013) 11 SCC 309, were taken note of. In the said cases, the
Hon'ble Supreme Court had taken a view that if a candidate takes a calculated chance and appears at
the interview, then, only because the result of the interview is not palatable to him, he cannot turn
round and subsequently contend that the process of interview was unfair or the Selection
Committee was not properly constituted.
87. In some of the writ petitions, where advertisements are under challenge, it was observed that the
selection and appointment would abide by the final outcome of the writ petitions. In some
advertisements, it is indicated that the selection would be governed by the outcome of the decision
pending in WPC Nos. 591/2012, 593/2012 and 594/2012. The selected candidates are in service for
a long period of time. In the interregnum period, it was submitted during the course of proceedings,
that many recruitments had taken place. However, none of the parties have brought on record
various recruitments that have taken place. In such circumstances, this Court is of the considered
opinion that setting at naught the selections made in terms of the Act of 2011 or setting aside
admissions on the basis of Section 3 of the Act of 2012 would cause great hardship and prejudice to
such candidates, besides resulting in administrative chaos. Therefore, we are of the opinion that it
will be appropriate for this Court to mould the relief inspite of declaring Act of 2011 and Section 3 of
Act of 2012 and the notification dated 29.11.2012 in Rules of 1998 so far as it relates to reservation
as indicated in Schedule II Model Roster for districts of Surguja, Surajpur,
Balrampur-Ramanujganj, Jashpur, Koria and Surguja Division as unconstitutional. Outcome of the
writ petition means the final verdict of the Court whereby relief may be moulded in a given situation
for ends of justice in exercise of powers under Article 226 of the Constitution of India. In Managing
Director, ECIL, Hyderabad (supra), it was held that it is now well settled that the Courts can make
the law laid down by them prospective in operation to prevent unsettlement of the settled position
to prevent administrative chaos and to meet the ends of justice.
88. Accordingly, we are not inclined to interfere with the admissions taken and appointments issued
on the basis of the impugned reservation.
89. In the result, WPC Nos. 591/2012, 592/2012, 593/2012, 594/2012, 652/2012, 653/2012,
936/2012, 1093/2012, 2072/2014 and WPC No. 4665/2019 are allowed. WPC No. 1067/2012, WPS
No. 5578/2012, WPC No. 1121/2012, WPC No. 1372/2012, WPS No. 5290/2021, WPS No.Dr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

7100/2021, WPS No. 2091/2018, WPS No. 4049/2018, WPS No. 6083/2018, are partly allowed.
WPS No. 4240/2014 is disposed of in terms of the directions and observations above.
90. No cost.
                   Sd/-                                            Sd/-
             (Arup Kumar Goswami)                          (Parth Prateem Sahu)
               CHIEF JUSTICE                                    JUDGE
AmitDr. Manmeet Thawait vs State Of C.G. And Ors on 19 September, 2022

