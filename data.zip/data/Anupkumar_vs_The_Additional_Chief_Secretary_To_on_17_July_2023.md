Anupkumar vs The Additional Chief Secretary To ... on 17 July,
2023
Author: M.Sundar
Bench: M.Sundar
                                                                                      H.C.P.No.128 of 2023
                                    IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                       DATED: 17.07.2023
                                                              Coram
                                      THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                     and
                                     THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                       H.C.P.No.128 of 2023
                     Anupkumar                                                            .. Petitioner
                                                                 vs
                     1.The Additional Chief Secretary to Government,
                       Home, Prohibition and Excise Department,
                       Secretariat, Chennai – 9.
                     2.The Commissioner of Police,
                       Avadi City
                       Office of the Commissioner of Police (Goondas Section)
                       Avadi, Chennai – 600 054
                     3.The Superintendent of Prison,
                       Central Prison, Puzhal
                       Chennai – 600 066
                     4. The Inspector of Police
                        E-5, Sholavaram Police Station
                        Chennai – 600 067                                     .. Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     for issuance of a writ of habeas corpus calling for the records connected
                     with          the     detention     order    of   the     2nd   respondent        in
                     No.10/BCDFGISSSV/2023 dated 11.01.2023 and quash the same and
https://www.mhc.tn.gov.in/judis
                     1/9
                                                                                             H.C.P.No.128 of 2023Anupkumar vs The Additional Chief Secretary To ... on 17 July, 2023

                     direct the respondents to produce the body and person of detenu namely
                     Aravinthkumar@ Aravinth, S/o.Karunakaran, aged about 39 years,
                     detained in Central Prison, Puzhal,Chennai before this Court and set him
                     at liberty forthwith.
                                  For Petitioner                :       Mr.B.M.Santharam
                                  For Respondents               :       Mr.E.Raj Thilak,
                                                                        Additional Public Prosecutor
                                                            ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
[hereinafter 'HCP' for the sake of convenience and clarity] was listed in the Admission Board on
31.01.2023, this Court made the following order:
' Captioned Habeas Corpus Petition has been filed in this Court on 20.01.2023 inter
alia assailing a detention order dated 11.01.2023 bearing reference Memo
No.10/BCDFGISSSV/2023 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, fourth respondent is
the Sponsoring Authority.
2. Brother of the detenu is the petitioner.
3. Mr.B.M.Santharam, learned counsel on record for habeas corpus petitioner is
before us. Learned counsel for https://www.mhc.tn.gov.in/judis petitioner submits
that ground case qua the detenu is for alleged offences under Sections 341, 294(b),
336, 427, 392, 397 and 506(ii) IPC in Crime No.1031 of 2022 on the file of E-5,
Sholavaram Police Station.
4. The aforementioned detention order has been made on the premise that the
detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous
Activities of Bootleggers, Cyber law offenders, Drug-
offenders, Forest-offenders, Goondas, Immoral traffic offenders, Sand-offenders, Sexual-offenders,
Slum- grabbers and Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of
1982' for the sake of convenience and clarity].
5. The detention order has been assailed inter alia on the ground that some of the pages of the
booklet furnished to the detenu were illegible and some pages were not properly translated
preventing the detenu from making effective representation.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.Anupkumar vs The Additional Chief Secretary To ... on 17 July, 2023

7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. ' https://www.mhc.tn.gov.in/judis
2. The aforementioned order made in the 31.01.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are four adverse cases and one ground case. The ground case which constitutes substantial
part of substratum of the impugned preventive detention order is Crime No.1031 of 2022 on the file
of E-5 Sholavaram Police Station for alleged offences under Sections 341, 294(b), 336, 427, 392, 397
and 506(ii) of IPC. Owing to the nature of the challenge to the impugned preventive detention order,
it is not necessary to delve into the factual matrix or be detained further by facts.
4. Mr.B.M.Santharam, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. At the time of admission i.e., in the Admission Board, the point that some of the pages of the
booklet furnished to the detenu were illegible and some pages were not properly translated which
prevented the detenu from making effective representation was projected, but in the final hearing
learned counsel predicated his campaign against the impugned preventive detention order on the
point that subjective https://www.mhc.tn.gov.in/judis satisfaction arrived at by the detaining
authority qua imminent possibility of detenu being enlarged on bail is impaired. Learned counsel
drew the attention of this Court to paragraph 4 of grounds of detention and the relevant portion
reads as follows:
'4. I am aware that Thiru.Aravinthkumar @ Aravinth is in remand in E-5 Sholavaram
Police Station Crime Nos.452/2022, 996/2022, 1004/2022, 1026/2022 and
1031/2022. He has not moved any bail applications for E-5 Sholavaram Police
Station Crime Nos. 452/2022, 996/2022, 1004/2022, 1026/2022 and 1031/2022
cases. The sponsoring authority has stated that it is learnt that the relatives of
Thiru.Aravindkumar@ Aravinth are taking action to take him out on bail in E-5
Sholavaram Police Station Crime Nos. 452/2022, 996/2022, 1004/2022, 1026/2022
and 1031/2022 cases by filing bail applications before the appropriate court, since in
a similar case, the bail was granted by the court after a lapse of time.......'
6. Adverting to the aforementioned portion of the grounds of impugned preventive detention order,
learned counsel submitted that Section 161(3) of 'The Code of Criminal Procedure, 1973 (2 of 1974)'
[hereinafter 'Cr.P.C' for the sake of brevity and clarity] statement recorded from the brother of the
detenu and a special report from the Sponsoring Authority are undated.
https://www.mhc.tn.gov.in/judis
7. The aforementioned point turns on records. A careful perusal of the grounds booklet says that
there is a Section 161(3) Cr.P.C statement from brother of the detenu one Thiru.Anopkumar (HCPAnupkumar vs The Additional Chief Secretary To ... on 17 July, 2023

petitioner before us) and a special report from the Sponsoring Authority at pages 180 and 181 of the
booklet but both do not contain a date. This means that it is not clear as to whether the Section
161(3) Cr.P.C statement and the special report are prior to the date of impugned preventive
detention order or after the date of the impugned preventive detention order. To be noted, date of
impugned preventive detention order is 11.01.2023 and the same was served on the detenu on the
same day and the grounds have been served on the detenu on 12.01.2023. Therefore, the benefit of
doubt has to be given to the detenu. If the benefit of doubt as regards the date of special report and
Section 161(3) Cr.P.C is given to the detenu, it follows as a sequitur that the subjective satisfaction
arrived at by the detaining authority qua imminent possibility of detenu being enlarged on bail is
impaired. Further sequitur is, impugned preventive detention order deserves to be dislodged.
https://www.mhc.tn.gov.in/judis
8. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 11.01.2023
bearing reference No.10/BCDFGISSSV/2023 made by the second respondent is set aside and the
detenu Thiru.Aravinthkumar @ Aravinth, aged 39 years, son of Thiru.Karunakaran, is directed to be
set at liberty forthwith, if not required in connection with any other case / cases. There shall be no
order as to costs.
(M.S.,J.) (R.S.V.,J.) 17.07.2023 Index : No Neutral Citation : No gpa P.S: Registry to forthwith
communicate this order to Jail authorities in Central Prison, Puzhal, Chennai.
https://www.mhc.tn.gov.in/judis To
1.The Additional Chief Secretary to Government, Home, Prohibition and Excise Department,
Secretariat, Chennai – 9.
2.The Commissioner of Police, Avadi City Office of the Commissioner of Police (Goondas Section)
Avadi, Chennai – 600 054
3.The Superintendent of Prison, Central Prison, Puzhal Chennai – 600 066
4. The Inspector of Police E-5, Sholavaram Police Station Chennai – 600 067
5.The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., gpa 17.07.2023
https://www.mhc.tn.gov.in/judisAnupkumar vs The Additional Chief Secretary To ... on 17 July, 2023

