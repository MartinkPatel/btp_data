Constitution of India
India
Constitution of India
CONTITUENTASSEMBLY 00 of 1950
Published in Gazette 00 on 26 January 1950• 
Assented to on 24 January 1950• 
Commenced on 26 January 1950• 
[This is the version of this document from 26 January 1950.]• 
Constitution Of IndiaWE, THE PEOPLE OF INDIA, having solemnly resolved to constitute India
into a SOVEREIGN SOCIALIST SECULAR DEMOCRATIC REPUBLIC and to secure to all its
citizens:JUSTICE, social, economic and political;LIBERTY of thought, expression, belief, faith and
worship;EQUALITY of status and of opportunity;and to promote among them all;FRATERNITY
assuring the dignity of the individual and the unity and integrity of the Nation;IN OUR
CONSTITUENT ASSEMBLY this twenty-sixth day of November, 1949, do HEREBY ADOPT, ENACT
AND GIVE TO OURSELVES THIS CONSTITUTION.[In the Preamble to the Constitution; (a)for the
words "SOVEREIGN DEMOCRATIC REPUBLIC" the words "SOVEREIGN SOCIALIST SECULAR
DEMOCRATIC REPUBLIC" and(b)for the words "unity of the Nation", the words "unity and
integrity of the Nation" shall be substituted through Constitution (Forty-Second Amendment) Act,
1976][[Editorial comment-The Constitution (Forty-Second Amendment) Act, 1976,made
significant changes to the Constitution such as the description of India from a "sovereign democratic
republic" to a "sovereign, socialist secular democratic republic", and also changed the words "unity
of the nation" to "unity and integrity of the nation" India by Also Refer ]
Part I – The Union and its Territory
1. Name and territory of the Union
(1)India, that is Bharat, shall be a Union of States.(2)The States and the territories thereof shall be
as specified in the First Schedule.(3)The territory of India shall comprise-(a)The territories of the
States;(b)the Union territories specified in the First Schedule; and(c)such other territories as may be
acquired.[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, it amended
Article 1 where the split of states based on Parts was eliminated as part of the revisions made. States
were used in place of Parts A and B. States in Parts C and D were replaced by Union territories.
There were added 14 states along with 5 union territories. Also Refer ]Constitution of India

2. Admission or establishment of new States
Parliament may by law admit into the Union, or establish, new States on such terms and conditions,
as it thinks fit.
2A. Sikkim to be associated with the Union
[After article 2 of the Constitution, the following article shall be inserted Constitution (Thirty-Fifth
Amendment) Act, 1974]Sikkim, which comprises the territories specified in the Tenth Schedule,
shall be associated with the Union on the terms and conditions set out in that Schedule.[Rep. by the
Constitution (Thirty-sixth Amendment) Act, 1975 , section 5 (w.e.f . 26. 4. 1975 ).][Editorial
comment-The Constitution (Thirty-Fifth Amendment) Act, 1974, deals with the appeal raised by
the Sikkim government to include them as an associate state in India. In simple words, the people of
Sikkim wanted to fill the gap between them and India and thus demanded the special status of an
associate state. The Amendment observed the insertion of Article 2A in the constitution. Article 2A
stated that Sikkim was associated with the Union while the tenth schedule emphasizes the special
conditions of association between the Union and Sikkim. It gives the Sikkim people the right to
represent themselves in the Legislative Assembly and various political institutions. This amendment
inculcated among the people a sense of belongingness and equal rights as any other
citizen.Important Verdicts- State of Sikkim vs Surendra Prasad SharmaAlso Refer][Editorial
Comment- The Constitution (Thirty-Sixth Amendment) Act, 1975,Remove article 2A:Formation of
Sikkim as a State within the Indian Union. Also Refer]
3. Formation of new States and alteration of areas, boundaries or names of
existing States
Parliament may by law-(a)Form a new State by separation of territory from any State or by uniting
two or more States or parts of States or by uniting any territory to a part of any State;(b)increase the
area of any State;(c)diminish the area of any State;(d)alter the boundaries of any State;(e)alter the
name of any State;Provided that no Bill for the purpose shall be introduced in either House of
Parliament except on the recommendation of the President and unless, where the proposal
contained in the B ill affects the area, boundaries or name of any of the States , the Bill has been
referred by the President to the Legislature of that State for expressing its views thereon within such
period as may be specified in the reference or within such further period as the President may allow
and the period so specified or allowed has expired.[In article 3 of the Constitution, for the proviso,
the following proviso shall be substituted through Constitution (Fifth Amendment) Act,
1955][Editorial Comment- The Constitution (Fifth Amendment) Act, 1955, which attempted to
modify Article 3 of the Indian Constitution. then-President Rajendra Prasad gave his approval to the
bill, which was then published in The Gazette of India on December 26, 1955. Originally, Article 3,
did not prescribe a time limit for expression of views by the States on the States reorganization laws.
It was feared that the States could forestall the passage of the State Reorganisation Act by not
expressing their views for any length of time. The amended Article now provides a time limit within
which the State has to express their views. If they do not express their views within the specifiedConstitution of India

time the Bill may be passed by Parliament. Important Verdict: Babulal Parate vs The State Of
Bombay And Another & Also Refer ]Explanation I.- In this article, in clauses (a) to (e), "State"
includes a Union territory, but in the proviso, "State" does not include a Union territory.Explanation
II.- The power conferred on Parliament by clause (a) includes the power to form a new State or
Union territory by uniting a part of any State or Union territory to any other State or Union
territory.[Editorial Comment- The Constitution (Eighteenth Amendment) Act, 1966, revised
Article 3 of the Constitution to give new meaning to the terms “State” and “Union territories”. The
modification clarified that in Article 3, the term “State” in clauses (a) to (e) must include “Union
territories”. However, this was not applicable in the proviso. It further explained that the power
under clause (a) involves the authority of the Parliament for the formation of a new State or Union
territory. This may be done by joining a part of any State or Union territory with some other State or
Union territory. Also refer ]
4. Laws made under articles 2 and 3 to provide for the amendment of the
First and the Fourth Schedules and supplemental, incidental and
consequential matters
(1)Any law referred to in article 2 or article 3 shall contain such provisions for the amendment of the
First Schedule and the Fourth Schedule as may be necessary to give effect to the provisions of the
law and may also contain such supplemental, incidental and consequential provisions (including
provisions as to representation in Parliament and in the Legislature or Legislatures of the State or
States affected by such law) as Parliament may deem necessary.(2)No such law as aforesaid shall be
deemed to be an amendment of this Constitution for the purposes of article 368.
Part II – Citizenship
5. Citizenship at the commencement of the Constitution
At the commencement of this Constitution every person who has his domicile in the territory of
India and—(a)who was born in the territory of India; or(b)either of whose parents was born in the
territory of India; or(c)who has been ordinarily resident in the territory of India for not less than five
years immediately preceding such commencement,shall be a citizen of India.
6. Rights of citizenship of certain persons who have migrated to India from
Pakistan
Notwithstanding anything in article 5, a person who has migrated to the territory of India from the
territory now included in Pakistan shall be deemed to be a citizen of India at the commencement of
this Constitution if—(a)he or either of his parents or any of his grand-parents was born in India as
defined in the Government of India Act, 1935 (as originally enacted); and(b)(i)in the case where
such person has so migrated before the nineteenth day of July, 1948, he has been ordinarily resident
in the territory of India since the date of his migration, or(ii)in the case where such person has so
migrated on or after the nineteenth day of July, 1948, he has been registered as a citizen of India byConstitution of India

an officer appointed in that behalf by the Government of theDominion of India on an application
made by him therefore to such officer before the commencement of this Constitution in the form
and manner prescribed by that Government:Provided that no person shall be so registered unless he
has been resident in the territory of India for at least six months immediately preceding the date of
his application.
7. Rights of citizenship of certain migrants to Pakistan
Notwithstanding anything in articles 5 and 6, a person who has after the first day of March, 1947,
migrated from the territory of India to the territory now included in Pakistan shall not be deemed to
be a citizen of India:Provided that nothing in this article shall apply to a person who, after having so
migrated to the territory now included in Pakistan, has returned to the territory of India under a
permit for resettlement or permanent return issued by or under the authority of any law and every
such person shall for the purposes of clause (b) of article 6 be deemed to have migrated to the
territory of India after the nineteenth day of July, 1948.
8. Rights of citizenship of certain persons of Indian origin residing outside
India
Notwithstanding anything in article 5, any person who or either of whose parents or any of whose
grand-parents was born in India as defined in the Government of India Act, 1935 (as originally
enacted), and who is ordinarily residing in any country outside India as so defined shall be deemed
to be a citizen of India if he has been registered as a citizen of India by the diplomatic or consular
representative of India in the country where he is for the time being residing on an application made
by him therefore to such diplomatic or consular representative, whether before or after the
commencement of this Constitution, in the form and manner prescribed by the Government of the
Dominion of India or the Government of India.
9. Persons voluntarily acquiring citizenship of a foreign State not to be
citizens
No person shall be a citizen of India by virtue of article 5, or be deemed to be a citizen of India by
virtue of article 6 or article 8, if he has voluntarily acquired the citizenship of any foreign State.
10. Continuance of the rights of citizenship
Every person who is or is deemed to be a citizen of India under any of the foregoing provisions of
this Part shall, subject to the provisions of any law that may be made by Parliament, continue to be
such citizen.Constitution of India

11. Parliament to regulate the right of citizenship by law
Nothing in the foregoing provisions of this Part shall derogate from the power of Parliament to make
any provision with respect to the acquisition and termination of citizenship and all other matters
relating to citizenship.
Part III – Fundamental Rights
12. Definition
In this part, unless the context otherwise requires, "the State" includes the Government and
Parliament of India and the Government and the Legislature of each of the States and all local or
other authorities within the territory of India or under the control of the Government of
India.Editorial Comment - This article provides the definition of the “state” in India and the various
organs which come under it. This definition of the State under Article 12 is applicable only for Part 3
(Fundamental Rights) and Part 4 (Directive Principles of State Policy) of the Constitution of India.
The meaning of “Other Authorities” under Article 12 can be understood by looking at leading case
laws such as In the case of Rajasthan State Electricity Board v. Mohanlal, AIR 1967wherein it was
decided that “other authorities is wide enough to include within it every authority created by a
statute on which powers are conferred to carry out governmental or quasi-governmental functions
and functioning within the territory of India or under the control of the Government of India.”
The court further laid down the guidelines for deciding ‘any authority’ as ‘Other Authority’ under
Article 12, In the case of Ramana Dayaram Shetty v. The International Airport (1979): “If the entire
shares are owned by the Government, “If almost the entire expenditure is done by the Government”,
“If there is a state conferred monopoly in that corporation”, “Whenever there is deep and pervasive
control by the Government” and “If the functions by the corporation are of Public importance” and
lastly, “If a department of the Government is transferred to a corporation.” 
Indian Courts have interpreted the meaning of 'State' in various contexts over time to extend the
dimension of Fundamental Rights. 
In the case of University of Madras v. Santa Bai, the Madras High Court evolved the principle of
ejusdem generis i.e. of the “like nature”. It means that those authorities are covered under the
expression 'other authorities’ which perform governmental or sovereign functions.
In Sukhdev v. Bhagatram, LIC (Life Insurance Corporation of India) , ONGC (Oil and Natural Gas
Corporation) and IFC (International Finance Corporation) were held to be state as they perform
very similar functions which seem to be governmental or sovereign functions. 
Another set of discussions have been around the fact of the Judiciary becoming part of the state.
Eminent Jurists like H.M.Seervai, V.N.Shukla consider judiciary to be State. Their view is supportedConstitution of India

by Articles 145 and 146 of the Constitution of India.
“It was held that the Supreme Court is empowered to make rules for regulating the practice and
procedure of Courts and is also empowered to make appointments of its staff and servants and
decide its service conditions.”
In Prem Garg v. Excise Commissioner H.P. The Supreme Court held that when rule making power of
the judiciary is concerned, it is ‘state’.
There have been contrary opinions on this subject too. In Rati Lal v. State of Bombay, it was held
that the judiciary is not state for the purpose of Article 12. In A.R.Antulay v. R.S.Nayak and
N.S.Mirajkar v. State of Maharashtra, it has been observed that “when rule making power of
judiciary is concerned it is state but when exercise of judicial power is concerned it is not state.”
Thus, the word 'state' under Article 12 jurisprudence has evolved in India through various
interpretations and discussions in the High courts and the Supreme court. It has been given a wider
meaning which ensures that Part-III of the constitution can be applied to a larger extent. 
References
Indiankanoon
ConstitutionofIndia.net
Know India Government Portal
Blog Ipleaders
Legal Service India
13. Laws inconsistent with or in derogation of the fundamental rights
(1)All laws in force in the territory of India immediately before the commencement of this
Constitution, in so far as they are inconsistent with the provisions of this Pan, shall, to the extent of
such inconsistency, be void.(2)The State shall not make any law which takes away or abridges the
rights conferred by this Part and any law made in contravention of this clause shall, to the extent of
the contravention, be void.(3)In this article, unless the context otherwise requires,-(a)"law" includes
any Ordinance, order, bye-law, rule, regulation, notification, custom or usage having in the territory
of India the force of law;(b)"laws in force" includes laws passed or made by Legislature or other
competent authority in the territory of India before the commencement of this Constitution and not
previously repealed, notwithstanding that any such law or any part thereof may not be then in
operation either at all or in particular areas.(4)Nothing in this article shall apply to any amendment
of this Constitution made under article 368.[Editorial comment - Article 13 (1) discusses the
laws which were made before the commencement of the Constitution (26 January 1950) and ArticleConstitution of India

13 (2) delves about the laws which are made after the Constitution is in place.
Article 13 (1) states that all the laws which are made before the Constitution will be void as long as
they are violating the provisions of the Fundamental Rights. It further states that only that part of
the law which will be void which is against the provisions of the constitution and not the whole law
itself. This guarantee is against the existing laws and future laws and not to the laws which are made
before the commencement of the constitution.
Article 13(2) states that all the laws which are made after the commencement of the Constitution
are void to the extent of the infringement of the Fundamental Rights given in part 3 of the
Constitution.
The ‘Doctrine of Eclipse’ asserts that all the Pre-Constitutional laws which are against the
fundamental rights of the Indian Constitution will become dormant and not dead. They will remain
dormant as long as the state does not amend the law and its infringing nature. So this doctrine
applies to only Article 13(1) of the Indian Constitution.
In Keshavan Madhvan Menon v. State of Bombay, the court said that the law which is infringing the
rights of the citizens after the commencement of the constitution is ‘void ab initio’ for the citizens of
the country but it will remain enforceable for the non-citizens and companies. The doctrine of
Eclipse makes the law unenforceable but it doesn’t make the law void ab initio.
The ‘doctrine of Waiver’ means that a person who is receiving a right or a privilege can waive that
right according to his will. Once the right is waived by the individual then they cannot claim it back.
In Behram v. State of Bombay, it was decided by the court that the rights which are given in part 3 of
the constitution cannot be waived by an individual.
The ‘Doctrine of Separability’ means that if a part of a law is against the provisions of the
constitution then only that offending part will be declared as void and not the whole statute. This
doctrine is applied in both Article 13 (1) and Article 13 (2) of the Indian Constitution. In R.M.D.C. v.
Union of India, AIR 1957, Supreme Court has given some rules relating to this doctrine:
“1. It is important to understand the intention of the legislature before using this doctrine.
2. When separation of invalid part of the statute is very difficult then the whole law will be held as
invalid.
3. If after deleting the invalid part, the valid part has no value left to it then the whole act will be
rejected in its entirety.”
Article 13(3) (a) defines “Law”. According to this section, Law includes any ordinance, order,
bye-Law, rule, regulation, notification, custom or usages. This definition of law is given a wide
meaning so that it can be added to a wide variety of state instrumentalities.Constitution of India

In Ahmedabad Women Action Group v. Union of India, AIR 1977, Supreme Court said that personal
laws (Hindu Law, Muslim Law, and Christian Law) are not part of the definition of Law under
Article 13. The Bye-Laws made by the Cooperative Societies are also not part of the definition of
Law.
There have also been other discussions on whether “Law” includes constitutional amendments.
This question was first decided in the case of Shankari Prasad v. Union of India AIR 1951. In that
case, the Supreme Court held that the word law under Article 13(2) doesn’t include a constitutional
amendment. This entailed that the Parliament has power to amend the Fundamental Rights
according to their will.
Later in the case of Golak Nath v. State of Punjab, AIR 1967, the Supreme Court overruled the
Shankari Prasad verdict and stated that the word ‘Law’ in Article 13(2) includes the constitutional
amendments. If any constitutional amendment is infringing the Fundamental rights then that
amendment will be void.
To nullify the Golak Nath decision the Parliament passed the 24th Amendment Act, 1971, wherein
parliament added Clause 4 in Article 13 which stated that nothing in Article 13 shall apply to any
amendment of this Constitution made under Article 368.
Later in the case of the Kesavananda Bharati v. the State of Kerala, AIR 1973, the constitutionality
of the 24th Amendment was held valid. So the present position of the word “Law” is that a
Constitutional Amendment does not include the word. This gives the Parliament the power to
amend the provisions of the Fundamental rights as long as they align with the basic structure
doctrine of the Indian Constitution.ReferencesIndianKanoonBlog
IpleadersConstitutionofIndia.netLawctopus AcademikeWikipedia[[Editorial comment-The
Constitution (Twenty-Four Amendment) Act, 1971, enables Parliament to dilute Fundamental
Rights through Amendments of the Constitution.Tthe 24th Amendment was effected to abrogate the
Supreme Court ruling in I.C. Golaknath and Ors. vs State of Punjab and Anrs. The Supreme Court
delivered its ruling, by a majority of 6-5 on 27 February 1967. The Court held that an amendment of
the Constitution is a legislative process, and that an amendment under article 368 is "law" within
the meaning of article 13 of the Constitution and therefore, if an amendment "takes away or
abridges" a Fundamental Right conferred by Part III, it is void. Article 13(2) reads, "The State shall
not make any law which takes away or abridges the right conferred by this Part and any law made in
contravention of this clause shall, to the extent of contravention, be void." The Court also ruled that
Fundamental Rights included in Part III of the Constitution are given a "transcendental position"
under the Constitution and are kept beyond the reach of Parliament. The Court also held that the
scheme of the Constitution and the nature of the freedoms it granted incapacitated Parliament from
modifying, restricting or impairing Fundamental Freedoms in Part III Also Refer ]
14. Equality before law
The State shall not deny to any person equality before the law or the equal protection of the laws
within the territory of India.Editorial Comment -Article 14 rejects any type of discriminationConstitution of India

based on caste, race, and religion, place of birth or sex. This Article is having a wide ambit and
applicability to safeguard the rights of people residing in India. 
This article is divided into two parts: 
Equality before the Law: This part of the article indicates that all are to be treated equally in the eyes
of the law. This is a negative concept as it implies the absence of any privilege in favor of any person.
This is a substantive part of the article. 
Equal protection of the Laws: This part means that the same law will be applied to all the people
equally across the society. This is a positive concept as it expects a positive action from the state.
This is a procedural part of article 14. 
“The dissent of Justice Subba Rao in the State of U.P. v. Deoman Upadhyaya 1960stated that Article
14 comprises both “positive content” as well as “negative content”. Whereas, equality before the law
is a negative content, equal protection of the laws exhibits a positive content of Article 14.”
The doctrine of Anti Arbitrariness: The scope of article 14 was drastically increased by the Supreme
Court by including the executive discretion under its ambit. In the case of E.P. Royappa v. State of
Tamil Nadu, 1974, the court said that Article 14 gives a guarantee against the arbitrary actions of the
State. The Right to Equality is against arbitrariness. They both are enemies to each other. So it is
important to protect the laws from the arbitrary actions of the Executive.
“The first landmark judgment which actually spotted the virtue of non-arbitrariness in Article 14
was S.G. Jaisinghani v. Union of India . The Court, for the first time held “absence of arbitrary
power” as sine qua non to rule of law with confined and defined discretion, both of which are
essential facets of Article 14.” In here Justice Subba Rao elaborating on the wide expanse of Article
14 , vide para 14 held thus: “In this context it is important to emphasize that the absence of arbitrary
power is the first essential of the rule of law upon which our whole constitutional system is based. In
a system governed by rule of law, discretion, when conferred upon executive authorities, must be
confined within clearly defined limits.”
In the Maneka Gandhi v. Union of India, 1978,  Justice Bhagwati said that Equality is against the
arbitrariness of State action. So this doctrine ensures equality of treatment. “The seven-Judge Bench
held that a trinity exists between Article 14, Article 19 and Article 21. All these articles have to be
read together. Any law interfering with personal liberty of a person must satisfy a triple test: (i) it
must prescribe a procedure; (ii) the procedure must withstand the test of one or more of the
fundamental rights conferred under Article 19 which may be applicable in a given situation; and (iii)
it must also be liable to be tested with reference to Article 14.”
Natural Justice as a part of Article 14: From the case of A.K. Kraipak v. Union of India, It is evident
that Natural Justice (natural justice is technical terminology for the rule against bias and the right to
a fair hearing (audi alteram partem)) is an integral part of Article 14.  The court held that “the
Principle of Natural Justice helps in the prevention of miscarriage of Justice, These Principles alsoConstitution of India

check the arbitrary power of the State.”
Classification Test: In the case of Ram Krishna Dalmia v. Justice Tendolkar, 1958 the Supreme
Court describes the jurisprudence of equality before the law. It simply permits the State to make
differential classification of subjects (which would otherwise be prohibited by Article 14) provided
that the classification is founded on intelligible differentia (i.e. objects within the class are clearly
distinguishable from those that are outside) and has a rational nexus with the objective sought to be
achieved by the classification.
In the case of Indra Sawhney v UOI, 1993 which is a landmark judgment on aspects of reservation in
India. “The Court interpreted the relation between Article 14 and Article 16. It was held that Article
16(1) is a facet of Article 14. Just as Article 14 permits reasonable classification, so does Article 16(1).
A classification may involve reservation of seats or vacancies. The principle aims of Article 14 and 16
is equality and equality of opportunity and Clause (4) of Article 16 is a means of achieving the very
same objective. Both the provisions have to be harmonized keeping in mind the fact that both are
the restatements of the principle of equality enshrined in Article 14.”
Further expansion of Article 14 was done in the case of Visakha v State of Rajasthan, 1997
“The judgment sought to enforce the fundamental rights of working women under Articles 14, 19
and 21 of the Constitution of India. Sexual Harassment violates the fundamental right of the women
of gender equality which is codified under Article 14 of Indian Constitution and also the
fundamental right to life and to live a dignified life. The Court held that even though there is no
express provision for sexual harassment at workplace under Indian Constitution, it is implicit
through these fundamental rights.” (references mentioned below)
Expansion of Article 14 in terms of defining Gender: In the case ofNational Legal Service Authority
[NALSA] v UOI, 2014.
“This case was filed by the National Legal Services Authority of India (NALSA) to legally recognize
persons who fall outside the male/female gender binary, including persons who identify as “third
gender”. While drawing attention to the fact that transgender persons were subject to “extreme
discrimination in all spheres of society”, the Court held that the right to equality (Article 14 of the
Constitution) was framed in gender-neutral terms (“all persons”). Consequently, the right to
equality would extend to transgender persons also.”
Further in Shayara Bano v UOI, 2016 “the 5 Judge Bench of the Supreme Court pronounced its
decision in the Triple Talaq Case, declaring that the practice of instantaneous triple talaq
[Talaq-ul-biddat] was unconstitutional. The Bench observed that the fundamental right to equality
guaranteed under Article 14 of the Constitution, manifested within its fold, equality of status.
Gender equality, gender equity and gender justice are values intrinsically entwined in the guarantee
of equality, under Article 14.” 
These above discussed landmark cases and many more have contributed to expand the ambit andConstitution of India

scope of Article 14 of the Constitution of India, to strive for a more equal and fair society.
References
SCC online
Blog Ipleaders
Wikipedia
Legal Service India
Equality Human Rights
15. Prohibition of discrimination on grounds of religion, race, caste, sex or
place of birth
(1)The State shall not discriminate against any citizen on grounds only of religion, race, caste, sex,
place of birth or any of them.(2)No citizen shall, on grounds only of religion, race, caste, sex, place of
birth or any of them, be subject to any disability, liability, restriction or condition with regard
to-(a)access to shops, public restaurants, hotels and places of public entertainment; or(b)the use of
wells, tanks, bathing ghats, roads and places of public resort maintained wholly or partly out of State
funds or dedicated to the use of the general public.(3)Nothing in this article shall prevent the State
from making any special provision for women and children.[Editorial comment- The
Constitution (First Amendment) Act, 1951, made several changes to the Fundamental Rights Part of
the Indian constitution. It made it clear that the right to equality does not preclude passing laws that
give special consideration to society’s most vulnerable groups.Article 15(3) was appropriately
expanded to prevent any special provisions made by the State for the social, economic, or
educational progression of any disadvantaged class of citizens from being contested based on
discrimination.Also Refer Also refer](4)Nothing in this article or in clause (2) of article 29 shall
prevent the State from making any special provision for the advancement of any socially and
educationally backward classes of citizens or for the Scheduled Castes and the Scheduled
Tribes.(5)Nothing in this article or in sub-clause (g) of clause (1) of article 19 shall prevent the State
from making any special provision, by law, for the advancement of any socially and educationally
backward classes of citizens or for the Scheduled Castes or the Scheduled Tribes in so far as such
special provisions relate to their admission to educational institutions including private educational
institutions, whether aided or unaided by the State, other than the minority educational institutions
referred to in clause (1) of article 30.[The Constitution (Ninety-third Amendment) Act, 2005,
adjoined a clause to Article 15 stating that the state has the authority to establish certain specific
Provisions concerning accommodations for the progress of any sociologically and academically
disadvantaged sectors of the society, as well as to the scheduled castes and scheduled tribes, with
respect to their enrollment to academic institutions, including private academic institutions,
whether assisted or unassisted by the state, except minority institutions.Also Refer](6)Nothing in
this article or sub-clause (g) of clause (1) of article 19 or clause (2) of article 29 shall prevent theConstitution of India

State from making,—(a)any special provision for the advancement of any economically weaker
sections of citizens other than the classes mentioned in clauses (4) and (5); and(b)any special
provision for the advancement of any economically weaker sections of citizens other than the classes
mentioned in clauses (4) and (5) in so far as such special provisions relate to their admission to
educational institutions including private educational institutions, whether aided or unaided by the
State, other than the minority educational institutions referred to in clause (1) of article 30, which in
the case of reservation would be in addition to the existing reservations and subject to a maximum
of ten per cent. of the total seats in each category.Explanation.—For the purposes of this article and
article 16, "economically weaker sections" shall be such as may be notified by the State from time to
time on the basis of family income and other indicators of economic disadvantage.[Editorial
Comment - Article 15 protects the citizens against various forms of discrimination based on
religion and gender. The Constitution of India guarantees various rights to its citizens, including no
discrimination on account of religion, race, caste, or place of birth. Article 15 restricts discrimination
on the ground of:
Religion – It means that no person should be discriminated against on the basis of religion from
accessing any public place or policy by the state or any group.
Race – Ethnic origin should not form a basis of discrimination. For example, a citizen of Afghan
origin should not be discriminated against those of an Indian origin.
Caste – Discrimination on the basis of caste is also prohibited to prevent atrocities on the lower
castes by the upper caste.
Sex – Gender of an individual shall not be a valid ground for discrimination in any matter.
Place of birth – A place where an individual is born should not become a reason for discriminating
among other members of the country.
In the case ofKathi Raning Rawat v. State of Saurashtra, the state of Saurashtra set up special courts
under Saurashtra State Public Safety Measures Ordinance 1949, to adjudicate on the matters
ofsection 302,section 307 andsection 392 read with section 34 of the Indian Penal Code, 1860. The
contention brought before the court was that these provisions are discriminatory for the residents
depending upon the territory.
The court stated that all kinds of legislative differentiation are not discriminatory. The legislation
did not refer to certain individual cases but to offenses of certain kinds committed in certain areas
and hence it is not discrimination.
In another significant case, John Vallamattom v. Union of India, AIR 2003 SC 2902 discussed that
The Indian Succession Act 1925 prevented the petitioners from bequeathing property for religious
and charitable purposes. The petitioner contended it to be discriminatory against the testamentary
dispositions by a Christian.Constitution of India

The court stated that the Act was to prevent people from making injudicious death-bed bequests
under religious influence, but had a great impact on a person desiring to dispose of his property
upon his death. Hence, the legislation is clearly discriminatory as the properties of any Hindu,
Muslim, Buddhist, Sikh, Jain or Parsi were excluded from the provisions of the Act. Further, no
acceptable reasoning was provided to show why the provision regulates religious and charitable
bequests of Christians alone.
Clause 1 of the Article prohibits the State from discriminating against citizens on five protected
grounds only. This means that if the discrimination is only on the basis of these 5 points then it will
be void.
One of the important points to remember under this clause is that the prohibition is against the
state and not against any private individuals. This clause is used to give horizontal reservations like
reservations for visually impaired people. The Supreme Court in D.P. Joshi v. State of Madhya
Pradesh, AIR 1955 has made it clear that the place of birth and place of residence are two different
things and States are allowed to differentiate on the basis of place of residence. In this case, the
residents of the State were allowed exemption from paying the capitation fee. But the non-residents
were asked to pay a capitation fee for admission in the medical college. This was held valid by the
Supreme Court.
Clause 2 discussed Access to Public Places. This clause gives access to shops, public restaurants,
hotels and places of public entertainment to all. This clause also makes wells, tanks, bathing Ghats,
roads and places of public resort accessible for every citizen. This clause is applied not only to the
state but also against the individuals. It is illegal and unjust to restrict or prevent access to a public
place established by the state exclusively for public use. 
Clause 3 discusses Special Provision for Women and Children. This clause is an exception to clause 1
and 2. This clause provides special preference to Women and Children as a matter of positive
discrimination. It entails that nothing in this Article can stop the state from giving special preference
to the Women and Children. In Revathi v. Union of India, AIR 1998 case, the court held that the
word ‘for’ which is given under this clause means that states can give special preference to Women
and Children in legislation.Clause 4 discusses Special Provisions for Backward Classes. This is the
second exception of clause 1 and 2 of Article 15. This clause was not part of the original Constitution
and was included through the 1st Constitutional Amendment. This clause makes special provision
for the advancement of any socially and educationally backward classes of citizens (SEBCs),
Schedule Caste (SC) and Schedule Tribes (STs). 
In Balaji v. State of Mysore, AIR 1963, the government of Mysore set up a reservation of 68% of the
total seats in Engineering and Medical colleges. These seats were reserved in the favor of SEBCs, STs
and SCs. The court held that this legislation breached the limit of reservation which should not be
more than 50% of the total seats. The court also stated that the backwardness must be both Social
and Economical. It can’t be either social or economical alone. 
It was also held by the Supreme Court inA. Periakaruppan v. State of Tamil Nadu  that classifyingConstitution of India

socially and educationally backward classes on the basis of caste was in violation of Article 15(4).
According to the Court, it was, however, necessary for the conditions of such a class of people to
change as that was the main reason for providing them with a reservation.
Clause 5 discusses Reservation in Educational institutions. This is the 3rd Exception of Article 15.
This exception was added by the 93rd Constitutional Amendment. This clause was added as a result
of a Judgment ofPA Inamdar and Ors. V. State of Maharashtra and Ors. In this judgment the court
held that different states cannot impose its reservation policy on minority and non-minority
unaided private colleges, including professional colleges. The validity of this act and 93rd
Constitutional Amendment was challenged in Ashok Kumar Thakur v. Union of India (2008)
Clause 6 lays down the Special Provisions for EWS category. This provision was added by the 103rd
Constitutional amendment Act, 2019. This is the latest exception that provides for special provisions
for the Economic Weaker Section (EWS). Several states have implemented schemes to enforce
reservations for Economically Weaker Sections (EWS) based on Clause (6). In 2021, the central
government issued a notification to introduce EWS reservation in the medical postgraduate
entrance exam. However, this decision was challenged in the Supreme Court.Multiple parties raised
concerns about the constitutionality of the 103rd Amendment and brought the matter before the
Supreme Court. They argued that it goes against the jurisprudence on reservations, which does not
permit reservations solely based on economic criteria. On November 7, 2022, a five-judge bench of
the Supreme Court of India, in the case of Janhit Abhiyan v. Union of India, ruled that the 103rd
Amendment does not violate the fundamental structure of the Constitution. Justices Maheshwari,
Trivedi, and Pardiwala delivered separate judgments in favor of the majority, while Justice Bhat
expressed a dissenting opinion on behalf of himself and Chief Justice U.U Lalit.
References
IndianKanoon
ConstitutionofIndia.net
EBC India
Blog Ipleaders
Human Rights Watch[Editorial comment- The Constitution (One Hundred and Third
Amendment) Act, 2019, introduces 10% reservation for Economically Weaker Sections (EWS) of
society for admission to Central Government-run educational institutions and private educational
institutions (except for minority educational institutions), and for employment in Central
Government jobs The Amendment does not make such reservations mandatory in State
Government-run educational institutions or State Government jobs. However, some states have
chosen to implement the 10% reservation for economically weaker sections. Currently, the quota can
be availed by persons with an annual gross household income of up to 8 lakh (US$10,000).
Families that own over 5 acres of agricultural land, a house over 1,000 square feet, a plot of over
100-yards in a notified municipal area or over a 200-yards plot in a non-notified municipal areaConstitution of India

cannot avail the reservation. Persons belonging to communities that already have reservations such
as Scheduled Castes, Scheduled Tribes and the "non creamy layer" of Other Backward Classes are
also not eligible for reservation under this quota(creamy layer of OBC crosses 8 lakh limit).Also
Refer]
16. Equality of opportunity in matters of public employment
(1)There shall be equality of opportunity for all citizens in matters relating to employment or
appointment to any office under the State,(2)No citizen shall, on grounds only of religion, race,
caste, sex, descent, place of birth, residence or any of them, be ineligible for, or discriminated
against in respect of, any employment or office under the State.(3)Nothing in this article shall
prevent Parliament from making any law prescribing, in regard to a class or classes of employment
or appointment to an officeunder the Government of, or any local or other authority within, a State
or Union territory, any requirement as to residence within that State or Union territory prior to such
employment or appointment.(4)Nothing in this article shall prevent the State from making any
provision for the reservation of appointments or posts in favour of any backward class of citizens
which, in the opinion of the State, is not adequately represented in the services under the
State.(4A)Nothing in this article shall prevent the State from making any provision for reservation
in matters of promotion, with consequential seniority, to any class or classes of posts in the services
under the State in favour of Scheduled Castes and the Scheduled Tribes which in the opinion of
State are not adequately represented in the services under the State.[In article 16 of the Constitution
after clause 4, the following clauses shall be inserted through Constitution (Seventy-seventh
Amendment) Act, 1995][Editorial comment -The Constitution (Seventy-seventh Amendment)
Act, 1995, broadened the reservation provisions for job promotions, encompassing individuals
belonging to Scheduled Castes and Tribes. Since 1955, the Scheduled Castes (SC) and Scheduled
Tribes (ST) have had access to the facility of reservation in the promotion. However, the Supreme
Court stated in its decision dated November 16, 1992, in the issue of Indra Sawhney and Others vs.
Union of India and Others that reservation of appointments or posts under Article 16(4) of the
Constitution is restricted to initial appointment. Further, it cannot extend to a reservation in
matters of promotion. The interests of the SC and STs will be harmed by this Supreme Court
decision. It is vital to continue the current dispensation of offering reservations in promotion for the
Scheduled Castes and the Scheduled Tribes since their representation in services in the States has
not achieved the requisite level. The government has chosen to maintain the prevailing policy of
reservations in the promotion of the Scheduled Castes and the Scheduled Tribes in light of its
commitment to safeguarding the interests of these groups. To achieve this, it is necessary to change
Article 16 of the Indian Constitution. This is accomplished by adding a new clause (4A) to the
aforementioned article that establishes a reservation in promotion for the Scheduled Castes (SCs)
and Scheduled Tribes (STs).Also refer][Editorial comment -The primary goal of the Constitution
(Eighty-fifth Amendment) Act, 2002, was to increase the benefits of reservation in favor of the
Scheduled Castes and Scheduled Tribes in matters of promotion, with consequential seniority, to
any class. The phrase 'in situations of promotion to any class' was replaced with 'in matters of
promotion, with consequential seniority, to any class' in clause (4A) of Article 16 of the Indian
Constitution.Also Refer][In article 16 of the Constitution after clause 4 (A), the following clauses
shall be inserted through Constitution (Eighty-first Amendment) Act, 2000](4B)Nothing in thisConstitution of India

article shall prevent the State from considering any unfilled vacancies of a year which are reserved
for being filled up in that year in accordance with any provision for reservation made under clause
(4) or clause (4A) as a separate class of vacancies to be filled up in any succeeding year or years and
such class of vacancies shall not be considered together with the vacancies of the year in which they
are being filled up for determining the ceiling of fifty per cent, reservation on total number of
vacancies of that year.[The Constitution (Eighty-first Amendment) Act, 2000, aimed to protect
reservations for SCs and STs in the backlog of vacancies. A new clause (4B) was added to Article 16
of the Constitution of India by the 81st Amendment Act of 2000, after clause (4A). This gave the
states the authority to treat unfilled reserved vacancies from one year as a separate class of
vacancies to be filled in the following year or years. The new provision stated that such vacancies
must not be included in the vacancies of the year in which they are filled, in order to calculate the
overall vacancy reservation ceiling of 50% for that year. This modification essentially eliminated the
50% cap on reservations for backlog vacancies.Also Refer](5)Nothing in this article shall affect the
operation of any law which provides that the incumbent of an office in connection with the affairs of
any religious or denominational institution or any member of the governing body thereof shall be a
person professing a particular religion or belonging to a particular denomination.(6)Nothing in this
article shall prevent the State from making any provision for the reservation of appointments or
posts in favour of any economically weaker sections of citizens other than the classes mentioned in
clause (4), in addition to the existing reservation and subject to a maximum of ten per cent. of the
posts in each category.Editorial Comment - Article 16 discusses equality in opportunity of
employment for all the citizens. There are 6 Clauses under this article. Starting clause 1 and 2 talks
about equality of Opportunity and clause 3 to 6 are the exceptions of clause 1 and 2. 
Clause 1 states that there shall be equal opportunity for the citizens in the matter of employment or
appointment to any office under the State. This clause does not provide the right to employment; it
only gives the right to equal opportunity in case of any available vacancy in public employment. This
clause also applies to promotions or termination and other aspects of state employment. This
equality is applied only to the people who are applying for the same employment opportunity or are
working in the same post. 
Clause 2 states that there will be no discrimination based on religion, race, caste, sex, descent, place
of birth, residence in employment. The state cannot discriminate only on the basis of the above
criterias.
It is stated in clause 3 of Article 16 that nothing in this article shall prevent Parliament from making
any law which prescribes to the citizens who are appointed to any office under the State in regard to
any requirements as to residence within that State or Union territory prior to employment or
appointment to any office under the State.
Article 16(4) of the Indian constitution provides for the reservation of services under the State in
favor of the backward class of citizens. Backward class includes Schedule Castes and Scheduled
Tribes. 
In the case of Balaji v. State of Mysore, AIR 1963 the court held that caste cannot be the soleConstitution of India

determining criteria for gauging the backwardness of a community. It can be their Poverty or the
place where they live also. In the case of T. Devadashan v. Union of India, AIR 1964, the court struck
down the carry forward rule for the vacancies of backward classes. The Court held that, following
Balaji, the reserve vacancies in any one year had risen to more than 50% because they were not
constitutional because of the carry-forward clause. The 50% rule only applies to proper reservations,
i.e., backward classes reservations made under Article 16(4). The law cannot be applied to
exemptions, concessions, or reliefs given to retroactive classes in compliance with Article 16(4).
In the landmark judgment,Indra Sawhney v. Union of India, AIR 1993 (Mandal case), the Supreme
Court dealt with the issue of “carry forward” reservations. The Second Backward Classes Committee,
headed by BP Mandal, submitted its report which recommended 27 percent reservation for Other
Backward Classes (OBCs) and 22.5 percent for the Scheduled Castes/Scheduled Tribes.
The Central government, however, acted on the report a decade later, by issuing an office
memorandum (OM), providing 27 percent vacancies for Socially and Educationally Backward
Classes to be filled by direct recruitment.
Indra Sawhney, the petitioner in this case, made three principal arguments against the Order- The
extension of reservation violated the Constitutional guarantee of equality of opportunity, caste was
not a reliable indicator of backwardness and that the efficiency of public institutions was at risk.
The Supreme Court upheld the government order that caste was an acceptable indicator of
backwardness. Thus, the recommendation of reservations for OBCs in central government services
was finally implemented in 1992. The Supreme Court states that 27% central government
reservation for OBCs is valid. However, some states denied the existence of the creamy layer, and a
report commissioned by the supreme court was implemented. The case was pressed again in 1999
and the supreme court reaffirmed the creamy layer exclusion and extended it to SCs and STs. This
judgment also overruled Rangachar v. General Manager Southern Railway and Akhil Bharatiya
Soshit Karamchari Sangh (Railway) v. Union of India verdicts, which said that reservations could be
made in promotions as well as appointments. Indra Sawhney v. Union of India held that
reservations cannot be applied in promotions.
Later, the Parliament enacted the 77th Amendment Act, 1995 and added clause (4A) to Article 16 of
the Constitution, thereby enabling the Parliament to make provisions for reservation for SCs and
STs in promotion posts. This simply meant that even after the judgment of mandal case, the
reservation in promotion in government jobs, shall continue.
Clause (4B) was added to the Indian Constitution by way of 81st Amendment Act, 2000. It was
added to the Constitution with the intent that the backlog vacancies which could not be filled due to
unavailability of eligible candidates of the SEBC category in a previous or preceding year, shall not
be clubbed with the 50 percent reservation for the SCs and STs and Other Backward Classes on the
total number of vacancies in the next year.
Clause (5) exempts a law from the application of clauses (1) and (2), which require the incumbent ofConstitution of India

any office to be religiously qualified for appointment.
The case M. Nagaraj v. Union of India dealt with Articles 16 (4A) and (4B) of the Constitution. It was
held in this case that in order to grant reservations to Scheduled Castes and Scheduled Tribes, the
State must collect ‘quantifiable data’ to demonstrate their backwardness. It was held that the
concept of the creamy layer will also apply to the Scheduled Castes and Scheduled Tribes and
therefore, they would not be entitled to any such reservations. Further, the decision was altered as it
was argued by the Attorney-General of India that both the holdings were incorrect as they were
contrary to the judgment which was given in Indra Sawhney v. Union of India (non-exclusion of
creamy layer in matters of reservations).
Clause (6) was added to Article 16 by the 103rd Amendment Act, 2019, which came into effect on
January 14, 2019, and empowers the State to make various provisions for reservation in
appointments of members of the Economically Weaker Sections (EWS) of society to government
posts. However, these provisions must be within the 10% ceiling, in addition to the existing
reservations.
In the case of Janhit Abhiyan v. Union of India (2022) the constitutionality of the 103rd
Amendment was contested, alleging that it violated the fundamental structure of the Indian
Constitution. However, the majority decision, with a 3:2 ratio, upheld the amendment as
constitutionally valid. Justice Maheshwari explained that reservations go beyond being mere
affirmative actions or measures to address social and educational backwardness; instead, they serve
to combat various forms of disadvantages. The majority also ruled that a 10% reservation for
Economically Weaker Sections (EWS) in addition to the existing 50% reservation limit, as
established in the Indra Sawhney Case, is constitutional. Additionally, all three judges agreed that
the 50% limit is not rigid and may be surpassed in exceptional circumstances.
References
Social Laws Today
IndianKanoon
News Article
Blog Ipleaders
17. Abolition of untouchability
"Untouchability" is abolished and its practice in any form is forbidden. The enforcement of any
disability arising out of "Untouchability" shall be an offence punishable in accordance with
law.Editorial Comment - The Indian Constitution, specifically Article 17, has abolished the
practice of untouchability in all its forms. This article explicitly declares the prohibition of
untouchability. Furthermore, the Untouchability Offences Act of 1955 (renamed as the Protection ofConstitution of India

Civil Rights Act in 1976) considers the practice of untouchability as a criminal offense, and
individuals engaging in such practices are subject to legal punishment. According to this Act,
anything accessible to the general public should be equally accessible to all Indian citizens. Article
17 is a very important part of the Right to Equality. It not only provides equality but also social
justice. Also the Schedule Caste and Scheduled Tribe (Prevention of Atrocities) Act, 1989 led to the
establishment of special courts to decide the cases related to the commission of offenses under this
act. Section 18 of this Act makes the commission of offenses under this Act a non-bailable offense. 
In Jai Singh v. Union of IndiaRajasthan High Court and in Devrajiah v. B. Padmana of Madras High
Court, the court defined the word untouchability.The court said that ‘The subject matter of Article 17
is not untouchable in its literal or grammatical sense but the ‘practice as it had developed
historically in the country’. It refers to the social disabilities imposed on certain classes of persons
because of their birth in certain castes. Hence, it does not cover the social boycott of a few
individuals or their exclusion from religious services, etc.
In the case of People’s Union for Democratic Rights v. Union of India, AIR 1982 the Supreme Court
held that when the rights under Article 17 are violated by any private individual then it will be the
responsibility of the state to take action immediately. 
Merely because the aggrieved person could themself protect or enforce their invaded fundamental
rights, did not absolve the State from its constitutional obligations.
In State of Karnataka v. Appa Balu Ingale, the Supreme Court expressing its concern on the
continuance of the practice of untouchability, held that it was an indirect form of slavery is only
extension of the caste system. In this case, the accusation against the respondents was that they had
forcibly restrained the complainant from taking water from a newly dug-up borewell because they
were untouchable.
References
Indian Kanoon
ConstitutionofIndia.net 
Blog Ipleaders 
Law and Other things
18. Abolition of titles
(1)No title, not being a military or academic distinction, shall be conferred by the State.(2)No citizen
of India shall accept any title from any foreign State.(3)No person who is not a citizen of India shall,
while he holds any office of profit or trust under the State, accept without the consent of the
President any title from any foreign State.(4)No person holding any office of profit or trust underConstitution of India

the State shall, without the consent of the President, accept any present, emolument, or office of any
kind from or under any foreign State.Editorial Comment - Article 18(1) of the Indian Constitution
abolishes all titles and prohibits the state from conferring titles on any individual, whether they are
a citizen or a non-citizen. However, military and academic distinctions are exceptions to this
prohibition. This means that universities, for instance, can grant titles or honors to individuals
based on their merit. Article 18(2) specifically prohibits Indian citizens from accepting titles from
foreign states. Article 18(3) states that non-citizens holding positions of profit or trust under the
Indian State require the President's consent to accept titles from foreign states. Additionally, Article
18(4) stipulates that no person, whether a citizen or a non-citizen, holding a position of profit or
trust, can accept any gifts, salary, or office from a foreign state without the President's consent.
Clauses (3) and (4) aim to ensure the loyalty of non-citizens towards the Indian State and prevent
any breach of trust.
A "title" refers to an attachment to one's name, such as a prefix or suffix (e.g., Sir, Nawab,
Maharaja). In a democracy, the creation of titles and titular glories is discouraged as it goes against
the principles of social equality.
However, it is argued that titles like "Bharat Ratna," "Padma Vibhushan," and "Padma Shri"
(introduced in 1954) are not prohibited under Article 18 because they signify state recognition of
exceptional work by citizens in various fields. It is important to note that Article 18 does not confer
any fundamental right but rather imposes restrictions on executive and legislative powers. The
conferral of titles is seen as contrary to the fundamental principle of equality guaranteed by Article
14, which ensures equal treatment of all citizens.
In the landmark judgment Balaji Raghavan v. Union of India, AIR 1996, the court held that National
awards aren’t titles under clause 1 of Article 18. A committee (High Level Review Committee:
chaired by the Vice-President) was set up by the Government in which it states that the awards
should be given based on recommendations of names given by various state governments. These
recommendations will be reviewed by the Centre government. After this committee, the names will
be sent to the Prime Minister’s Office and finally sent to the President for the final verdict. It is
important to remember that there are no guidelines given for the Bharat Ratna award. 
In the case of Indira Jaising v. Supreme Court of India (2017), a complaint was lodged in this matter
questioning the usage of the term ‘senior advocate’ before the names of the advocates. The Supreme
Court ruled that this is not the title, but rather a demarcation, and therefore does not violate Article
18 of the Indian Constitution.ReferencesIndianKanoonConstitutionofIndia.net Social Laws Today
19. Protection of certain rights regarding freedom of speech, etc.
(1)All citizens shall have the right-(a)to freedom of speech and expression;[Editorial comment
-The Constitution (First Amendment) Act, 1951, made several changes to the Fundamental Rights
Part of the Indian constitution where it amended Article 19(1)(a) of the Indian Constitution to
counteract the "abuse of freedom of speech and expression." This decision followed criticism in the
press regarding the government's response to issues like the West Bengal refugee crisis andConstitution of India

extrajudicial killings in Madras. Initial attempts to censor the press were ruled unconstitutional,
leading the government to employ judicial decisions as justification for limiting freedom of speech.
Despite opposition concerns about democratic principles, the Congress government proceeded with
the amendment, citing international examples of regulating speech to prevent abuse. Important
Verdicts: Brij Bhushan v State of Delhi, March 1950, and Romesh Thappar v State of Madras, May
1950. Also refer](b)to assemble peaceably and without arms;(c)to form associations or unions or
co-operative societies;(d)to move freely throughout the territory of India;(f)sub-clause (f) shall be
omitted;(e)to reside and settle in any part of the territory of India;and(g)to practise any profession,
or to carry on any occupation, trade or business.(2)Nothing in sub-clause (a) of clause (1) shall affect
the operation of any existing law, or prevent the State from making any law, in so far as such law
imposes reasonable restrictions on the exercise of the right conferred by the said sub-clause in the
interests ofthe sovereignty and integrity of India, the security of the State, friendly relations with
Foreign States, public order, decency or morality or in relation to contempt of court, defamation or
incitement to an offence.(3)Nothing in sub-clause (b) of the said clause shall affect the operation of
any existing law in so far as it imposes, or prevent the State from making any law imposing, in the
interests ofthe sovereignty and integrity of India or public order, reasonable restrictions on the
exercise of the right conferred by the said sub-clause.(4)Nothing in sub-clause (c) of the said clause
shall affect the operation of any existing law in so far as it imposes, or prevent the State from making
any law imposing, in the interests ofthe sovereignty and integrity of India or public order or
morality, reasonable restrictions on the exercise of the right conferred by the said
sub-clause.(5)Nothing in sub-clauses (d) and (e) of the said clause shall affect the operation of any
existing law in so far as it imposes, or prevents the State from making any law imposing, reasonable
restrictions on the exercise of any of the rights conferred by the said sub-clauses either in the
interests of the general public or for the protection of the interests of any Scheduled
Tribe.(6)Nothing in sub-clause (g) of the said clause shall affect the operation of any existing law in
so far as it imposes, or prevent the State from making any law imposing, in the interests of the
general public, reasonable restrictions on the exercise of the right conferred by the said sub-clause,
and, in particular, nothing in the said sub-clause shall affect the operation of any existing law in so
far as it relates to, or prevent the State from making any law relating to,- [The following clause was
substituted through Constitution (First Amendment) Act, 1951][Editorial comment -The
Constitution (First Amendment) Act, 1951, made several changes to the Fundamental Rights Part of
the Indian constitution.The privilege of Indian citizens to engage in any profession, occupation,
trade, or business as granted by Article 19(1)(g) is constrained by reasonable restrictions that the
State laws may impose "in the interests of the general public." Although the mentioned words are
inclusive enough to encompass any nationalization scheme, it was deemed necessary to eliminate
ambiguity by introducing a clarifying addition to Article 19(6).Also refer](i)the professional or
technical qualifications necessary for practising any profession or carrying on any occupation, trade
or business, or(ii)the carrying on by the State, or by a corporation owned or controlled by the State,
of any trade, business, industry or service, whether to the exclusion, complete or partial, of citizens
or otherwise.[Editorial Comment - Article 19(1) of the Constitution of India guarantees six
fundamental freedoms to every citizen of India. Though all of these six Fundamental Freedoms are
not absolute. They contain certain restraints and exceptions within them which are postulated in
Article 19(2) to 19(6). Constitution of India

Freedom of Speech and Expression - Article 19(1)(a) grants citizens the right to freely express
their thoughts, opinions, and ideas. This includes the freedom to express oneself through speech,
writing, printing, visual representations, or any other means. However, reasonable restrictions can
be imposed on this right for the interests of sovereignty and integrity of India, security of the State,
friendly relations with foreign nations, public order, decency or morality, contempt of court,
defamation, incitement to an offense, or the sovereignty and integrity of Parliament.
The first set of grounds, namely, the sovereignty and integrity of India, the security of the State,
friendly relations with foreign States and public order are all grounds referable to national interest.
Whereas the second set of grounds, namely, decency or morality, contempt of court, defamation and
incitement to an offense are all concerned with the interest of the society. However it is the
constitutional obligation of the judiciary to ensure that the restrictions imposed by a law on the
media are reasonable and relate to the purposes specified in Article 19(2).Because reasonable
restrictions contemplated under the Indian Constitution brings the matter in the domain of the
court as the question of reasonableness is a question primarily for the Court to decide. Freedom of
speech and expression is a crucial right which is recognized by Article 19(l)(a), It has been held to be
a basic and indivisible right for a democratic polity.
In Romesh Thappar v. State of Madras  ,Patanjali Shastri, C.J. observed:“Freedom of speech and of
the press lay at the foundation of all democratic organizations, for without free political discussion
no public education, so essential for the proper functioning of the process of popular government, is
possible”The expression ‘Freedom of press’ is part of the ambit of article 19 and it means the right to
print and publish without any interference from the state or any other public authority. But this
Freedom, like other freedoms, cannot be absolute but is subject to well known exceptions
acknowledged in the public interests, which in India are enumerated in Article 19(2) of the
constitution.
Thus, in Prabhu Dutt v. Union of India the Supreme Court has held that the right to know news and
information regarding administration of the Government is included in the freedom of press. But
this right is not absolute and restrictions can be imposed on it in the interest of the society and the
individual from which the press obtains information. They can obtain information from an
individual when he voluntarily agrees to give such information.
In Bennett Coleman & Co v. Union of India (1972), the Hon’ble Supreme Court held that the
freedom of the press embodies the right of the people to free speech and expression. It was held that
“Freedom of the press is both qualitative and quantitative. Freedom lies both in circulation and in
content.”
In the case of Shreya Singhal v. Union of India, 2015 Section 66A of the Information Technology Act
was challenged. Under this section, there were several arrests which were made due to which a wide
outrage was seen in society. The petitioners said that this Article is infringing the Freedom of Speech
and Expression. The Supreme Court stroked down this provision saying that this provision is too
vague and prone to misuse.Constitution of India

In the State of U.P. v. Raj Narain (1975), the Supreme Court observed that the right to know is
derived from the concept of freedom of speech. The Court further held that the people of this
country have a right to know every public act, everything that is done in a public way, by their public
functionaries.
Right to speak includes the right to not speak or the right to remain silent. In Bijoe Emmanuel v.
State of Kerala (1986), the Supreme Court upheld the right to silence of three students who were
expelled from school because they refused to sing the National Anthem. The Court held that no
person can be compelled to sing the National Anthem if he has genuine conscientious objections
based on his religious belief. Hence, the right to speak and the right to express includes the right not
to express and to be silent.
Freedom to Assemble Peacefully - Article 19(1)(b) ensures the right to peacefully assemble and
hold public meetings or processions without arms. This right allows citizens to come together for
various purposes, such as protests, demonstrations, or discussions. However, reasonable
restrictions can be imposed on this right in the interests of public order, sovereignty, and integrity of
India.
In Himmat Lal v. Police Commissioner, Bombay (1972), the Supreme Court struck down a rule that
empowered the police commissioner to impose a total ban on all public meetings and processions. It
was held that the state could only make regulations in aid of the right of assembly of citizens and
could impose reasonable restrictions in the interest of public order but no rule could be prescribed
prohibiting all meetings or processions altogether.
Freedom to Form Associations or Unions - Article 19(1)(c) guarantees the right to form
associations or unions. Citizens have the freedom to form social, cultural, economic, or political
associations or unions. This right allows individuals to collectively pursue common goals or
interests. However, reasonable restrictions can be imposed on this right in the interests of public
order, morality, or the sovereignty and integrity of India.
In Damyanti v. Union of India (1971), the Supreme Court upheld the right of the members of an
association to continue the association with its composition as voluntarily agreed upon by the
persons forming the association.
Freedom to Move Freely - Article 19(1)(d) ensures the right to move freely throughout the
territory of India. Citizens have the liberty to move within the country, reside in any part of India,
and settle in any place of their choice. However, reasonable restrictions can be imposed on this right
in the interests of public order, security of the State, or the sovereignty and integrity of India.
In Chambara soy v. Union of India (2007), some persons had blocked a road due to which the
petitioner was delayed in taking his ailing son to the hospital and his son died on arrival at the
hospital. The Supreme Court held that the right of the petitioner to move freely under Article
19(1)(d) has been violated due to the road blockage. The Court held that the State is liable to pay the
compensation for the death of the petitioner’s son due to the inaction on the part of the StateConstitution of India

authorities in removing the aforesaid blockage.
Freedom to Reside and Settle - Article 19(1)(e) guarantees the right to reside and settle in any
part of India. Citizens have the freedom to choose their place of residence and settle anywhere
within the country. However, reasonable restrictions can be imposed on this right in the interests of
public order, protection of scheduled tribes, or the sovereignty and integrity of India.
In the case of U.P. Avas Evam Vikas Parishad v. Friends Co-op. Housing Society Ltd.(1995), it was
held by the Supreme Court that the right to residence under Article 19(1)(e) includes the right to
shelter and to construct houses for that purpose.
Freedom to Practice Profession, Occupation, Trade, or Business - Article 19(1)(g)
provides the right to practice any profession, occupation, trade, or business. Citizens have the
freedom to choose and engage in their preferred livelihoods. However, reasonable restrictions can
be imposed on this right in the interests of the general public, professional qualifications, or the
sovereignty and integrity of India.
In the landmark judgment, Chindamanrao v. State of M.P. (AIR 1951), the Central Provinces
imposed a ban on the making of Bidis during the Agricultural Seasons. The manufacturing of Bidis
used to work as an additional income for the women of the local area. So the act by the government
of the Central province was challenged in the Supreme Court. Court decided that the act made by
the government is arbitrary and does not fall under the reasonable restrictions.
The Hon’ble Supreme Court inVishaka v. State of Rajasthan (1997) has observed that the sexual
harassment of working women in workplaces violates the fundamental right under Article 19(1)(g).
In this case, comprehensive guidelines and binding directions were issued by the court to prevent
the incidents of sexual harassment of women at workplaces in both public and private
sectors.]ReferencesIndianKanoonConstitutionofIndia.netBlog Ipleaders Legal Service
India Wikipedia[Editorial comment-The Constitution (Sixteenth Amendment) Act, 1963, it
amended the Clauses (2), (3), and (4) of Article 19. This was done to enable the state to make laws
that, in the interests of the sovereignty and integrity of India, place reasonable restrictions on the
enjoyment of the rights conferred by sub-clauses (a), (b), and (c) of clause 1 of the
article.][Editorial comment-The Constitution (Ninety-seventh Amendment) Act, 2011,was
proposed to overcome the difficulties faced by Cooperative societies and improve their performance
and status in the country. The extensive establishment of cooperatives was envisioned as one of the
attempts to achieve social and economic justice and the equitable distribution of the advantages of
progress. According to this Amendment, these societies are given constitutional status and are
legally protected while also maintaining their autonomous or democratic functioning. The
Constitution was amended to require that the states guarantee the autonomy of cooperatives, and as
a result, state governments are now required to support the voluntary formation, autonomous
decision-making, democratic control, and operation of cooperatives. The Act witnessed many
changes such as modification in Part III of Article 19(1)(c) with the insertion of the words “or
co-operative societies”, and the addition of Article 43B (working towards enhancing the
co-Operative Societies’ Voluntary formation, independent operation, and professional management)Constitution of India

and Part IX B to the Indian Constitution. However, the 97th Amendment faced challenges in the
High Court of Gujarat as the Parliament didn’t ask for approval from the state legislatures before
passing the bill. The ratification/approval is necessary for matters concerning states and since the
cooperative societies are a part of the state legislature, ratification was required. On July 20, 2021,
the Supreme Court of India declared the 97th Amendment Act Unconstitutional. According to the
Supreme Court ratification from states was necessary to pass the amendment which didn’t take
place. The Supreme Court also said that the responsibility of Multistate Co-Operative societies is of
the Centre while that of the State co-operative societies is of the state. As of the current scenario,
parts of the 97th Amendment on cooperatives are struck down.Also Refer][Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
20. Protection in respect of conviction for offences
(1)No person shall be convicted of any offence except for violation of a law in force at the time of the
commission of the act charged as an offence, nor be subjected to a penalty greater than that which
might have been inflicted under the law in force at the time of the commission of the offence.(2)No
person shall be prosecuted and punished for the same offence more than once.(3)No person accused
of any offence shall be compelled to be a witness against himself.Editorial Comment - Article 20
of the Indian Constitution safeguards certain rights in criminal proceedings. It provides protection
against self-incrimination, double jeopardy, and retrospective punishment. 
Article 20(1) prohibits the imposition of retrospective punishment. It states that no person shall be
punished for an act that was not an offense at the time it was committed. This provision ensures that
individuals cannot be held accountable for actions that were legal when they occurred but were later
made illegal by subsequent legislation.
In the landmark judgment, Kedar Nath v. State of West Bengal the Supreme Court held that when
an act is declared a criminal offense by the legislature and provides penalties for it, such declaration
is always prospective and cannot be applied retrospectively as per the provisions of Article 20(1)
However, it is important to note that this clause prohibits only the procedure of sentencing and
convicting, not the trial itself. Therefore, a person accused under a particular procedure cannot
claim protection under this clause or the doctrine of ex post facto law.
In the case of Mohan Lal v. State of Rajasthan involving the Narcotics, Drugs, and Psychotropic
Substances Act, the court opined that Article 20 prohibits only conviction and punishment under an
ex post facto law, not the trial or prosecution itself. Furthermore, a trial conducted under a different
procedure from the one existing at the time of the offense does not fall within the scope of thisConstitution of India

provision and cannot be deemed unconstitutional.
In another significant judgment, Maru Ram Etc. v. Union Of India & Anr (1980 AIR 2147), the Court
observed that Article 20(1) also encompasses the principle that penalties for an offense should not
be retrospectively increased beyond what existed at the time of the offense.
However, there is an exception to the restriction imposed by this provision. In the case of Rattan Lal
v. The State of Punjab, the Supreme Court allowed for retrospective application of criminal laws in
situations where the issue at hand concerns the reduction of punishment for the said offense.
Article 20(2) prohibits a person from being prosecuted and punished for the same offense more
than once. This principle of double jeopardy prevents individuals from being subjected to multiple
trials or punishments for the same offense. Once a person has been acquitted or convicted and
punished for a particular offense, they cannot be tried or punished again for the same offense.
In the case of Venkataraman v. Union of India, the Supreme Court of India established that this
provision deals exclusively with Judicial punishments and provides that no person is prosecuted
twice by the judicial authorities. The most crucial landmark judgement came in the case of Maqbool
Hussain v. State of Bombay, where the person accused was possessing some amount of gold, which
was against lex loci at the time and gold was confiscated by the customs authority. And, later when
the person was prosecuted before a criminal court, the court was confronted with the question
whether this amounts to Double Jeopardy.
But, the Supreme Court observed that departmental proceedings, i.e. by Customs Authority, in this
case, doesn’t amount to trial by a judicial tribunal, thus the proceedings before the criminal court is
not barred in this case and the proceedings can go on. In a nutshell Departmental Proceedings are
independent of trial by a judicial court or tribunal.
However, the prosecution may happen if the facts are distinct in subsequent proceedings. Same was
established by the Supreme Court of India in case of A.A. Mulla v. State of Maharashtra and was
observed that; Article 20 (2) would not be attracted in those cases where the facts are distinct in
subsequent offence or punishment.
Article 20(3) ensures that no person accused of an offense shall be compelled to be a witness against
themselves. This means that an individual cannot be forced to provide evidence or testimony that
may incriminate themselves. It is a fundamental right that protects individuals from being
compelled to be witnesses in their own criminal prosecution.
Prohibition against self-incrimination could only be put into effect if the person is accused of a
criminal offence. This doctrine could not be invoked for cases other than criminal cases. Also, as
held by the Hon’ble Supreme Court in Raja Narayanlal Bansilal vs Maneck Phiroz Mistry, to claim
the immunity from being self-incriminated, there must exist a formal accusation against the person
and mere general inquiry and investigation don’t form grounds for the same.Constitution of India

These safeguards provided under Article 20 are essential components of a fair and just legal system.
They uphold the principles of fairness, protection against self-incrimination, and the prevention of
arbitrary or excessive punishment. It's important to note that these protections are applicable in
criminal proceedings and serve as a shield against certain violations of individual rights. However,
reasonable restrictions and limitations can be imposed in the interests of public order, security of
the State, or the proper administration of justice.ReferencesIndianKanoonBlog
IpleadersLawctopusConstitutionofIndia.net
21. Protection of life and personal liberty
No person shall be deprived of his life or personal liberty except according to procedure established
by law.Editorial Comment - Article 21 of the Indian Constitution guarantees the fundamental
right to protection of life and personal liberty. It ensures certain safeguards against arbitrary
deprivation of life and liberty. 
Article 21 asserts that no person shall be deprived of their life except according to the procedure
established by law. This means that every individual has the right to live, and their life cannot be
taken away except in accordance with the prescribed legal procedures. The right to life encompasses
various aspects, including the right to live with dignity, the right to livelihood, and the right to a
healthy environment. Article 21 also protects the personal liberty of individuals. It states that no
person shall be deprived of their personal liberty except according to the procedure established by
law. Personal liberty includes the freedom to move freely, the freedom to choose one's place of
residence, and the freedom to engage in any lawful occupation or profession.
In the landmark judgment, A.K. Gopalan v. The State of Madras, the Supreme Court held that
personal liberty means the “liberty of the body” which is freedom from arrest and detention from
false detention. The Supreme Court added that the meaning of the word ‘law’ means state made law
only. So clearly this was a narrow interpretation of the word Personal freedom and Law. But in
later cases, this view was redressed by the Judiciary. In the case of R.C. Cooper v. Union of India
(1970) the court held that the word personal liberty would not only include Article 21 but also
includes the 6 Fundamental Freedoms given under Article 19 (1).
In the case of Kharak Singh v. State of Uttar Pradesh, AIR 1963, the court adopted a wider meaning
of personal liberty and said that it will include all the rights which are given under Article 19(1).
In the landmark judgment Maneka Gandhi v. Union of India (1978), Supreme Court held that the
right to life and personal liberty under Article 21 is not limited to mere animal existence but includes
the right to live with dignity. The court emphasized that the procedure established by law must be
fair, just, and reasonable, and it cannot be arbitrary, oppressive, or unreasonable.
In Olga Tellis v. Bombay Municipal Corporation (1985), the court recognized the right to livelihood
as an integral part of the right to life under Article 21. It held that the eviction of pavement dwellers
without providing alternative arrangements would violate their right to life and personal liberty.Constitution of India

In the landmark judgment, Vishaka v. State of Rajasthan (1997), the supreme court addressed the
issue of sexual harassment at the workplace. The court held that the right to a safe and secure
working environment is a fundamental right flowing from Article 21. It laid down guidelines to
prevent and redress sexual harassment at workplaces until appropriate legislation was enacted.
In, National Legal Services Authority v. Union of India and Ors (2014), The National Legal Services
Authority filed a PIL to protect the interests of transgendered persons. The court held that the
Gender of a person is to be decided by the person themself after looking into the Right to Life
Article. So all the rights which are given to normal people must be given to transgendered people
like Public toilets, medical care for transgendered persons and the provisions of reservations under
Article 15 and 16 must be extended to them as they classify as a minority section.
In the case, Animal Welfare Board v. A. Nagaraja (2014), rights which are given to animals were up
for contention (especially bulls used in Jallikattu festival). In this case, the Animal Welfare Board of
India (AWBI) brought the attention of the court towards the cruelty and inhuman behavior which is
faced by the animals which are used in the Jallikattu festival. 
The court held that they have a duty under the doctrine of ‘parens patriae’ to take care of the rights
of animals. Article 51A (g) of the Constitution also gives the principle of compassion towards living
beings and animals. So under this case, the Supreme Court ruled that Jallikattu is constitutionally
void.
In another landmark judgment, K.S. Puttaswamy v. Union of India (2017) (privacy judgment) the
Supreme Court recognized the right to privacy as a fundamental right protected under Article 21.
The court held that privacy is an essential aspect of personal liberty and dignity and is intrinsic to
the entire constitutional scheme.
In Common Cause v. Union of India (2018), the court legalized passive euthanasia and recognized
the right to die with dignity as a fundamental right under Article 21. The court held that individuals
have the right to refuse medical treatment or life support and can make an advance directive
specifying their wishes in case of terminal illness.
Article 21 also prohibits arbitrary or unlawful detention. It ensures that no person can be detained
without proper legal justification or without following the due process of law. It safeguards against
arbitrary arrests and protects individuals from being unlawfully deprived of their freedom. It also
encompasses the right to a fair trial. It guarantees that every person accused of an offense shall have
the right to a fair and impartial trial, including the right to legal representation, the right to be
heard, and the right to present evidence in their defense.
In the case, A.K. Roy v. Union of India (AIR 1982) (NSA case), the Supreme Court discussed
whether the provisions of Natural Justice should be applied to the National Security act or not. This
Act took away many important rights of a detained person like Right to be represented by a lawyer,
Right to cross-examine the detaining authority etc. The court held that Natural justice is important
but it cannot be applied in all the acts. It is important to look at the circumstances and the purposeConstitution of India

of making the Act. So based on this logic the court upheld the NSA Act (1980).
The interpretation and scope of Article 21 have evolved through various landmark judgments of the
Supreme Court, expanding its ambit to include protection against torture, custodial violence, and
the right to a clean and healthy environment. It's important to note that reasonable restrictions can
be imposed on the rights guaranteed under Article 21 in the interests of public order, national
security, public health, or morality. However, such restrictions must be fair, just, and in accordance
with the principles of reasonableness and proportionality.ReferencesIndianKanoon Legal Service
India Lawctopus Academike Wikipedia
21A. Right to education
The State shall provide free and compulsory education to all children of the age of six to fourteen
years in such manner as the State may, by law, determine.Editorial Comment- Article 21A of the
Indian Constitution guarantees the right to education as a fundamental right for children between
the ages of 6 and 14 years. It was introduced by the 86th Amendment Act of 2002 with the aim of
providing free and compulsory education to all children in the specified age group. The amendment
makes it the duty of the State to ensure that every child within the specified age group receives
compulsory education. It prohibits discrimination and ensures equal opportunities for education.
Article 21A guarantees that education provided by the State to children in the specified age group
should be free of charge. It aims to remove financial barriers that could hinder access to education.
The responsibility for implementing the provisions of Article 21A lies with the respective state
governments. They are tasked with ensuring that adequate infrastructure, facilities, and qualified
teachers are available to provide quality education to all children.
To give effect to the provisions of Article 21A, the Right to Education (RTE) Act was enacted in
2009. The RTE Act further elaborates on the specifics of free and compulsory education, including
the responsibilities of the government, admission processes, curriculum, and standards for schools,
and mechanisms for monitoring and enforcing the right to education.ReferencesMinistry of
Education [Editorial comment-The Constitution (Eighty-sixth Amendment) Act, 2002, provides
certain important provisions to strengthen the educational system of the country. It ensures that
children under the age of 14 have the right to free formal education and mandates the state to
provide suitable schooling and educational opportunities for them. This amendment is a significant
step toward ensuring that all children from the age of six to fourteen receive a free primary
education, while also protecting their rights to attain quality education in a safe environment.Also
Refer]
22. Protection against arrest and detention in certain cases
(1)No person who is arrested shall be detained in custody without being informed, as soon as may
be, of the grounds for such arrest nor shall he be denied the right to consult, and to be defended by,
a legal practitioner of his choice.(2)Every person who is arrested and detained in custody shall be
produced before the nearest magistrate within a period of twenty-four hours of such arrest
excluding the time necessary for the journey from the place of arrest to the court of the magistrateConstitution of India

and no such person shall be detained in custody beyond the said period without the authority of a
magistrate.(3)Nothing in clauses (1) and (2) shall apply—(a)to any person who for the time being is
an enemy alien; or(b)to any person who is arrested or detained under any law providing for
preventive detention.(4)No law providing for preventive detention shall authorise the detention of a
person for a longer period than three months unless—(a)an Advisory Board consisting of persons
who are, or have been, or are qualified to be appointed as, Judges of a High Court has reported
before the expiration of the said period of three months that there is in its opinion sufficient cause
for such detention:Provided that nothing in this sub-clause shall authorise the detention of any
person beyond the maximum period prescribed by any law made by Parliament under sub-clause
(b) of clause (7); or(b)such person is detained in accordance with the provisions of any law made by
Parliament under sub-clauses (a) and (b) of clause (7).(5)When any person is detained in pursuance
of an order made under any law providing for preventive detention, the authority making the order
shall, as soon as may be, communicate to such person the grounds on which the order has been
made and shall afford him the earliest opportunity of making a representation against the
order.(6)Nothing in clause (5) shall require the authority making any such order as is referred to in
that clause to disclose facts which such authority considers to be against the public interest to
disclose.(7)Parliament may by law prescribe—(a)the circumstances under which, and the class or
classes of cases in which, a person may be detained for a period longer than three months under any
law providing for preventive detention without obtaining the opinion of an Advisory Board in
accordance with the provisions of sub-clause (a) of clause (4);(b)the maximum period for which any
person may in any class or classes of cases be detained under any law providing for preventive
detention; and(c)the procedure to be followed by an Advisory Board in an inquiry under sub-clause
(a) of clause (4).Editorial Comment - Article 22 of the Indian Constitution provides certain
safeguards regarding arrests and detentions. It aims to protect the rights and liberties of individuals
who are arrested or detained by the authorities. 
Protection against Arrest and Detention - Article 22 safeguards individuals against arbitrary
arrest and detention. It ensures that no person can be arrested or detained without being informed
of the grounds for such arrest or detention.
Right to be Presented before Magistrate - Article 22 guarantees that an arrested person must
be produced before the nearest magistrate within 24 hours of their arrest. This provision aims to
prevent unlawful and prolonged detention without proper judicial oversight.
Right to Consult a Legal Practitioner - Article 22 grants the right to an arrested person to
consult and be defended by a legal practitioner of their choice. This right helps ensure that
individuals have proper legal representation during the process of arrest and detention.
Communication of Grounds for Arrest - An arrested person must be informed of the grounds
for their arrest and detention. They have the right to know the reasons behind their arrest, enabling
them to effectively exercise their legal rights.
Preventive Detention - Article 22 also addresses the issue of preventive detention, which allows
the authorities to detain individuals for preventive reasons, such as the maintenance of public orderConstitution of India

or national security. It imposes certain additional safeguards, such as the requirement for the
grounds of detention to be communicated and the provision for a review by an advisory board.
It's important to note that Article 22 provides certain exceptions during times of emergency, such as
during a proclamation of Emergency by the President of India. In such circumstances, certain
restrictions on the rights and safeguards under Article 22 may be imposed.
In the case, D.K. Basu v. State of West Bengal (1997),  A Public Interest Litigation was filed by Dr
Dilip Kumar Basu related to a case of Custodial violence. The Supreme Court laid down strict
guidelines related to custodial violence and deaths. These guidelines are to be followed in all cases of
arrest and detention until legal provisions are made for the safeguard of a person in
custody.ReferencesIndianKanoon Social Law Today Academic Article[Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
23. Prohibition of traffic in human beings and forced labour
(1)Traffic in human beings and beggar and other similar forms of forced labour are prohibited and
any contravention of this provision shall be an offence punishable in accordance with
law.(2)Nothing in this article shall prevent the State from imposing compulsory service for public
purpose, and in imposing such service the State shall not make any discrimination on grounds only
of religion, race, caste or class or any of them.Editorial Comment - Article 23 of the Indian
Constitution addresses the prohibition of trafficking in human beings and forced labor. Article 23
prohibits trafficking in human beings, including trafficking for the purpose of forced labor, slavery,
or exploitation. It recognizes the inherent dignity and rights of individuals, ensuring protection
against such practices. It also prohibits forced labor or any form of compulsory labor. It ensures that
no person can be compelled to work against their will or under exploitative conditions.
The prohibition on forced labor does not apply to work required as a part of a compulsory service for
public purposes, such as military service, or in cases of emergency or calamity threatening the life or
well-being of the community.
Article 23 emphasizes the importance of protecting individual freedom and dignity, ensuring that no
person is subjected to exploitation or degrading conditions of work. It safeguards the right to receive
fair and reasonable remuneration for work done.
The objective of Article 23 is to eradicate practices that exploit and subjugate individuals,
particularly vulnerable sections of society. It upholds the principles of equality, justice, and respect
for human rights.Constitution of India

It's important to note that to address the issues related to trafficking, forced labor, and other forms
of exploitation, the Indian government has enacted specific laws such as the Immoral Traffic
(Prevention) Act, Bonded Labor System (Abolition) Act, and other relevant legislation to provide
legal frameworks and mechanisms for preventing and combating such offenses.
In, Sanjit Roy v. The State of Rajasthan, AIR 1983, court held that payment of wages which is lower
than the minimum wage to a person who is working in famine relief work is against the provisions of
Article 23. The State cannot take advantage of the situation of the person who is engaged in famine
relief work.
In, Deena v. Union of India, AIR 1983, the court held that the labor which is taken from prisoners
without paying them proper remuneration of their work is against the provisions of Article 23. They
are entitled to reasonable wages according to their work.
In, Vishal Jeet v. Union of India (1990), the Supreme Court emphasized that the right to receive
timely and fair wages is an essential component of the prohibition on forced labor under Article 23.
The court held that delayed payment or non-payment of wages could be considered as forced labor,
violating the constitutional rights of workers.
Budhadev Karmaskar v. State of West Bengal, the Court directed for the rehabilitation of the sex
workers. The Supreme Court also directed to form the Sex workers rehabilitation panel and directed
the State and Central Government to provide funds for the working of this
panel.ReferencesIndianKanoon United Nations Blog Ipleaders Lawctopus
24. Prohibition of employment of children in factories, etc.
No child below the age of fourteen years shall be employed to work in any factory or mine or
engaged in any other hazardous employment.Editorial Comment - Article 24 of the Indian
Constitution pertains to the prohibition of child labor. It aims to protect the rights and welfare of
children by prohibiting their employment in certain hazardous occupations or processes. 
Article 24 prohibits the employment of children below the age of 14 years in any factory, mine, or
hazardous occupation. The intention is to prevent exploitation, safeguard the health and
development of children, and ensure their access to education. The article allows for certain
exceptions where child labor may be permitted, such as engaging children in non-hazardous
family-based work, work as part of a school's curriculum, or in any other harmless or innocent
occupation.
This article also empowers the government to enact legislation to determine the specific occupations
and processes that are considered hazardous for children. The government has the authority to
impose necessary restrictions and regulations to enforce this provision effectively.
Article 24 is closely linked to Article 21A, which guarantees the right to education for childrenConstitution of India

between the ages of 6 and 14 years. By prohibiting child labor, Article 24 promotes the realization of
the right to education and ensures that children have the opportunity to develop their potential and
skills through proper schooling.
In this landmark case, M.C. Mehta v. State of Tamil Nadu (1997), the Supreme Court addressed the
issue of child labor in the firecracker industry. The court prohibited the employment of children in
hazardous industries, including the manufacture of firecrackers. It emphasized the importance of
enforcing Article 24 to protect the rights and welfare of children and directed the government to
take necessary measures to eradicate child labor.
In People's Union for Democratic Rights v. Union of India (1982), The Supreme Court dealt with the
issue of child labor in matchbox factories. The court recognized that child labor in hazardous
industries was a violation of their fundamental rights. It held that the prohibition on child labor
under Article 24 must be effectively enforced to ensure the well-being and development of children.
In Bachpan Bachao Andolan v. Union of India (2011), the Supreme Court addressed the issue of
child labor in various industries, including carpet weaving. The court reiterated the importance of
implementing and enforcing the provisions of Article 24 to eradicate child labor and protect the
rights of children. It directed the government to take measures for the rescue, rehabilitation, and
education of children involved in labor.ReferencesIndianKanoonConstitutionofIndia.net Legal
Service India Academic Article
25. Freedom of conscience and free profession, practice and propagation of
religion
(1)Subject to public order, morality and health and to the other provisions of this Part, all persons
are equally entitled to freedom of conscience and the right freely to profess, practise and propagate
religion.(2)Nothing in this article shall affect the operation of any existing law or prevent the State
from making any law—(a)regulating or restricting any economic, financial, political or other secular
activity which maybe associated with religious practice;(b)providing for social welfare and reform or
the throwing open of Hindu religious institutions of a public character to all classes and sections of
Hindus.Explanation I.—The wearing and carrying of kirpans shall be deemed to be included in the
profession of the Sikh religion.Explanation II.—In sub-clause (b) of clause (2), the reference to
Hindus shall be construed as including a reference to persons professing the Sikh, Jaina or Buddhist
religion, and the reference to Hindu religious institutions shall be construed accordingly.Editorial
Comment - Article 25 of the Indian Constitution guarantees the fundamental right to freedom of
religion. It encompasses various aspects related to the freedom to profess, practice, and propagate
religion. The freedom of religion under this article is subject to reasonable restrictions imposed in
the interest of public order, morality, and health. This means that while individuals have the right to
practice their religion, it should not disrupt the harmony of society or infringe upon the well-being
of others.
Article 25 distinguishes between religious practices and secular activities associated with religious
institutions. The state has the authority to regulate or restrict secular activities that may beConstitution of India

associated with religious practices, such as social reforms, economic activities, and other activities
unrelated to the core aspects of religion. It also includes the right of religious denominations or any
section thereof to manage their own religious affairs, including establishing and maintaining
religious institutions, as long as they do not violate any other laws or public order.
In the case of Vaishno Devi Shrine, Board v. State of Jammu and Kashmir, AIR 1997, In this case,
the validity of Jammu and Kashmir Mata Vaishno Devi Shrine Act, 1988 was challenged. This act
was made for better management and governance of the temple. This act was challenged based on a
violation of the Fundamental right of Religion of the petitioner. It abolished the hereditary post of
the priests and gave the power to the state to make the appointment of priests. The Supreme Court
held that the service of a priest is a secular activity and it can be regulated by the state under clause
2 of Article 25.
In the case, Sardar Syedna Taher Saifuddin Saheb v. State of Bombay (1962), the Supreme Court
addressed the issue of religious freedom and held that the freedom to manage religious affairs
includes the right to determine the essential practices of a religious denomination. The court
emphasized that the state should not interfere in matters of religious faith unless such practices are
considered immoral or contrary to public order.
In the case, Commissioner, Hindu Religious Endowments, Madras v. Sri Lakshmindra Thirtha
Swamiar of Sri Shirur Mutt (1954), Supreme Court dealt with the power of the state to intervene in
the administration of religious institutions. The Supreme Court held that while the state can
regulate and supervise the administration of religious institutions, it should not interfere with the
essential religious practices and customs of a denomination unless they are deemed to be socially
harmful or against public order.
In the case of Acharya Jadishwaranand Avadhuta v. Commissioner of Police, Calcutta, 1984 (Anand
Marga Case), the Supreme Court held that the Tandava dance which is followed by the community
of Anand Marga is not an essential part of the religion. So an order can be passed for the prohibition
of Tandava dance in public and it will not violate Article 25 and 26 of the Indian Constitution.
In the case of Moulana Mufti Sayeed Mohd. Norrur Rehman Barkariq v. State of West Bengal, AIR
1999, the High Court said that the restriction imposed by the state on the use of Microphones and
loudspeakers at the time of Azaan is not against the Article 25 and 26 of the Indian Constitution.
In the case, Shyam Narayan Chouksey v. Union of India, the Supreme Court dealt with the question
of showing respect to the national anthem. The Supreme Court held that every citizen or persons are
bound to show respect to the National Anthem of India, whenever played or sung on specific
occasions the only exemption is granted to disabled people. It further held that playing of the
national anthem in cinema halls is not mandatory but optional and directory.
In the case, Shayara Bano v. Union of India (Triple Talaq case), a 5 judges bench of the Supreme
Court discussed whether the practice of Talaq-e-biddat (triple talaq) is a matter of faith to the
Muslims and whether it is constituent to their personal law. By a 3:2 majority, the court ruled thatConstitution of India

the practice of Talaq-e-biddat is illegal and unconstitutional. The court also held that an injunction
would continue to bar the Muslim male from practicing triple talaq till a legislation is enacted for
that purpose.ReferencesIndianKanoon ConstitutionofIndia.net Blog Ipleaders Wikipedia
26. Freedom to manage religious affairs
Subject to public order, morality and health, every religious denomination or any section thereof
shall have the right—(a)to establish and maintain institutions for religious and charitable
purposes;(b)to manage its own affairs in matters of religion;(c)to own and acquire movable and
immovable property; and(d)to administer such property in accordance with law.Editorial
Comment - Article 26 provides for the freedom to manage the religious affairs of the citizens and
is subject to Public order, morality and health. 
Article 26(a)  Right to establish and maintain institutions for religious and charitable purposes.The
right to establish and maintain religious institutions is given to every religious institution. The word
establishes and maintains must be read together. So it is important for a religious institution to first
establish a religious institution and only then the right to maintain an institution is to be given to
that group. It is to be noted that the right to maintain an institution will also include the right to
administer it.
In the case of TMA Pai Foundation v. The State of Karnataka, AIR 2003, the court held that the right
to establish and maintain a religious institution is given to every religion. It can be a majority
religion or even a minority religion.
Article 26(b) Right to manage its own affairs in matters of religion. Every religious institution has
the right to manage its own affairs in the matters of religion. The State has got no right to interfere
in these matters unless it is affecting the public order, morality and health of the citizens.
In the case of S.P. Mittal v. Union of India, AIR 1983, the validity of the Aurobindo (Emergency
Provisions) Act, 1980 was challenged on the ground that it was violative of their right to freedom of
religion. Sri Aurobindo founded the philosophy of cosmic salvation. He and his disciples formed the
Aurobindo Society. The court decided that the sayings of Sri Aurobindo were not religious
institutions. So the taking over of the Aurobindo Ashram by the Government did not infringe Article
25 and 26 of the Indian Constitution.
Article 26(c) details the right to own and acquire movable and immovable property. The state can
regulate the property of a religious denomination by law.
Article 26(d) is on the right to administer such property in accordance with law. The State can
regulate the administration of the property belonging to the religious entity. It is also important to
understand that the state cannot altogether take away the right of the administration from the
religious institution.
In the case of Seshammal v. State of Tamil Nadu, 1972, the hereditary post of Archakas andConstitution of India

Mathadhipatis of Hindu temples in Tamil Nadu challenged the validity of Tamil Nadu Religious and
Charitable Endowments Act, 1970 under Article 32 on the violation of Right to Freedom. The
Supreme Court decided that the post of Archaka is secular. The appointment of Archaka is not a
religious practice nor is it an integral part of a religion. So the court upheld the appointment of
Archakas according to prevailing usage and custom. The right to succession also remained valid.
In the case of N. Adithayan v. Travancore Devaswom Board, 2002, it was challenged if
non-Brahmins can be appointed as a pujari in a temple. The Supreme Court held that the Brahmins
do not have the monopoly over-performing puja in a temple. The court also added that
non-Brahmins can be appointed as a pujari as long as he is well versed in his
job.ReferencesIndianKanoonWikipediaBlog Ipleaders
27. Freedom as to payment of taxes for promotion of any particular religion
No person shall be compelled to pay any taxes, the proceeds of which are specifically appropriated in
payment of expenses for the promotion or maintenance of any particular religion or religious
denomination.Editorial Comment - Article 27 ensures that individuals are not forced to
contribute through taxes towards the promotion or maintenance of any specific religion or religious
denomination. It upholds the principle of religious neutrality and prevents the use of public funds
for the advancement of a particular religious belief or institution. The aim of Article 27 is to
maintain a secular state where the government remains impartial towards all religions and does not
favor or promote any specific religion using public funds. It ensures that taxpayers' money is not
utilized to endorse or support any particular religious agenda, thus preserving the religious freedom
and equality of citizens.
In Sri Jagannath v. the State of Orissa, AIR 1954, the court upheld the fee which was imposed. The
court stated that the annual contribution was a fee and not a tax. This payment was demanded to
meet the expenses of the Commissioner and his office which was set up for the administration of the
religious institution.

In Nasima Khatun v. State of West Bengal, AIR 1981, the Bengal Wakfs Act was amended in 1973.
Through this amendment, the contribution was to be asked by people for the education for
economically weaker and meritorious students. The court said that this tax does not fall under
Article 27 as a tax but it is a kind of Fee, which is not a prerogative of Article 27.

In P.M. Bhargava v. University Grants Commission, AIR 2004, the court said that the teaching of
Jyotish Vigyan in a University by University Grants Commission is not religious teaching. This is a
secular activity. So it does not fall under Article 27 of the Indian
Constitution.ReferencesIndianKanoonConstitutionofIndia.netLegal Service IndiaConstitution of India

28. Freedom as to attendance at religious instruction or religious worship in
certain educational institutions
(1)No religious instruction shall be provided in any educational institution wholly maintained out of
State funds.(2)Nothing in clause (1) shall apply to an educational institution which is administered
by the State but has been established under any endowment or trust which requires that religious
instruction shall be imparted in such institution.(3)No person attending any educational institution
recognised by the State or receiving aid out of State funds shall be required to take part in any
religious instruction that may be imparted in such institution or to attend any religious worship that
may be conducted in such institution or in any premises attached thereto unless such person or, if
such person is a minor, his guardian has given his consent thereto.Editorial Comment - Article
28 of the Indian Constitution pertains to the freedom of religion in educational institutions. It
safeguards the rights of individuals, religious groups, and educational institutions with regards to
religious instruction, religious worship, and attendance at religious ceremonies. 
No religious instruction can be provided in any educational institution wholly maintained by state
funds. This ensures that public educational institutions funded by the government remain secular
and do not impart religious teachings.
In educational institutions that are not wholly maintained by state funds, religious instruction is
allowed. However, it requires the consent of parents or guardians. Students attending these
institutions have the right to choose whether or not to receive religious instruction. In educational
institutions that are not wholly maintained by state funds, students belonging to a particular
religion have the right to attend religious worship or religious instruction conducted by the
institution. 
The purpose of Article 28 is to maintain the secular character of educational institutions funded by
the state and to uphold the freedom of individuals to pursue their own religious beliefs or choose not
to participate in religious activities.
In Aruna Roy v. Union of India, AIR 2002, a PIL was filed under Article 32 wherein it was
contended by the petitioner that the National Curriculum Framework for School Education
(NCFSE) is violative of the provisions of the constitution. It was contended that it was anti-secular
and it should be set aside. The court ruled that there is no violation of Article 28 and there is also no
prohibition to study religious philosophy for having value-based life in a
society.ReferencesIndianKanoon Blog Ipleaders
29. Protection of interests of minorities
(1)Any section of the citizens residing in the territory of India or any part thereof having a distinct
language, script or culture of its own shall have the right to conserve the same.(2)No citizen shall be
denied admission into any educational institution maintained by the State or receiving aid out of
State funds on grounds only of religion, race, caste, language or any of them.Editorial Comment -
Article 29 of the Indian Constitution safeguards the cultural and educational rights of minorities. ItConstitution of India

aims to protect the interests of religious, linguistic, and cultural minorities in India. 
Any section of citizens residing in India having a distinct language, script, or culture of its own has
the right to conserve and promote its language, script, or culture. This provision ensures the
preservation and development of the unique identity and heritage of minority communities.
Minority communities, whether based on religion or language, have the right to establish and
administer educational institutions of their choice. This enables minorities to establish educational
institutions that cater to their specific cultural and linguistic needs. Article 29 also prohibits
discrimination against any citizen on the grounds of religion, race, caste, language, or any of them
with respect to admission into educational institutions maintained or aided by the state.
In the case of D.A.V. College, Jalandhar v. The State of Punjab (1971), and the Supreme Court held
that setting up of University and teaching Punjabi language is not infringing clause 1 of Article 29.
In the case, St. Stephen's College v. University of Delhi (1992), the Supreme Court dealt with the
question of whether minority educational institutions can reserve seats for students belonging to
their own community. The court ruled that minority institutions have the right to admit students
from their own community, provided the admission process is fair and transparent.
In the case, T.M.A. Pai Foundation v. State of Karnataka, the Supreme Court addressed the issue of
the right of minority educational institutions to establish and administer their institutions. The
court upheld the autonomy of minority institutions in matters of admission and administration,
emphasizing that they have the right to preserve their own character and identity.
In the case, Animal Welfare Board v. Union of India (Jallikattu case), the Supreme Court dealt with
the question whether the sport of Jallikattu was protected as a cultural right under Article 29 of the
Constitution of India? The Supreme Court upheld the practice of Jallikattu, as permitted by the 2017
Tamil Nadu Amendment to the Prevention of Cruelty to Animals Act, 1960. The five-judge Bench in
2023 overruled the view taken by a two-judge Bench of the court in its 2014 ruling in Welfare Board
of India v. A. Nagaraja, banning such sports including Jallikattu.ReferencesIndianKanoon News
Article SC Observer Blog Ipleaders
30. Right of minorities to establish and administer educational institutions
(1)All minorities, whether based on religion or language, shall have the right to establish and
administer educational institutions of their choice.(1A)In making any law providing for the
compulsory acquisition of any property of an educational institution established and administered
by a minority, referred to in clause (1), the State shall ensure that the amount fixed by or determined
under such law for the acquisition of such property is such as would not restrict or abrogate the right
guaranteed under that clause.(2)The state shall not, in granting aid to educational institutions,
discriminate against any educational institution on the ground that it is under the management of a
minority, whether based on religion or language.Editorial Comment - Article 30 of the Indian
Constitution guarantees the right of minorities to establish and administer educational institutions
of their choice. All minorities, whether based on religion or language, have the right to establish andConstitution of India

administer educational institutions of their choice. This includes the right to determine the type of
institution, its affiliation, and the right to appoint staff. The state cannot discriminate against any
educational institution on the grounds of its minority status while granting aid. Minority institutions
should receive the same treatment and protection as institutions established by the majority.
While minorities have the right to establish and administer educational institutions, they must still
adhere to reasonable regulations that the state may impose in the interest of maintaining standards
of education, ensuring welfare, or preventing maladministration.
The purpose of Article 30 is to protect the educational rights of religious and linguistic minorities,
allowing them to preserve and promote their distinct culture, language, and religious identity
through educational institutions of their choice. It recognizes the importance of minority
communities in the nation's diversity and provides them with the freedom to establish and manage
educational institutions that cater to their specific needs and aspirations. Article 31(A) was added as
part of the 42nd Constitutional Amendment which states that in case of any property acquired by
the government of an educational institution then it is the duty of the government to give
appropriate compensation.
In this case, St. Xavier's College v. State of Gujarat (1974), the Supreme Court clarified that minority
educational institutions have the right to admit students belonging to their own community and can
give preference to them while making admissions, as long as the admission process is fair and
transparent.
In D.A.V. College, Jullundur v. State of Punjab (1971), the Supreme Court held that minority
institutions have the right to appoint teachers of their choice, subject to their qualifications and
suitability. It emphasized the importance of preserving the minority character of such institutions.
In this case, S.P. Mittal v. Union of India 1983, the court discussed Auroville, a township formed on
the ideals of Sri Aurobindo. Tamil Nadu government took management of this township and filed a
presidential ordinance which later on became The Auroville (Emergency Provisions) Act, 1980.
Seeing that the government took control of a ‘religious’ enterprise, the Constitutional validity of the
Act was challenged on 4 grounds. One of the grounds was that it was violative of Article 29 and 30.
It was held by the bench that the aforesaid Act does not violate Article 29 and 30. The court held
that it, in no way curtailed their right or prevented any citizen from conserving its own language,
script or culture and thus was not violative of Article 29.
Also in this case, in order to seek protection under Article 30, one must prove that they are a
linguistic or religious minority and the institution in question was established by them. Considering
that Auroville was not religious and was founded on the ideology of Sri Aurobindo, they could not
seek protection under these articles.
In the landmark case T.M.A. Pai Foundation v. State of Karnataka (2002), the Supreme Court dealt
with the autonomy of minority educational institutions and their right to establish and administerConstitution of India

institutions of their choice. The Supreme Court held that minority institutions have the right to
administer their affairs, including the right to appoint staff, but they must still operate within
certain reasonable regulations imposed by the
state.ReferencesIndianKanoonConstitutionofIndia.netBlog Ipleaders IndianKanoon[Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
31. Compulsory acquisition of property [REPEALED]
[Rep. by the Constitution (Forty-fourth Amendment) Act, 1978 , section. 6 (w.e.f.
20.6.1979).][Editorial Comment - Article 31 of the Indian Constitution was repealed and
replaced by the 44th Constitutional Amendment Act in 1978. The original Article 31 dealt with the
right to property, but it was repealed and replaced by Article 300A.
Article 300A states that no person shall be deprived of his or her property except by the authority of
law. It provides protection to individuals against arbitrary deprivation of their property by the state.
It ensures that if the state acquires private property for public purposes, it must do so in accordance
with the law and provide fair compensation to the affected individuals.](1)No person shall be
deprived of his property save by authority of law.(2)No property shall be compulsorily acquired or
requisitioned save for a public purpose and save by authority of a law which provides for
compensation for the property so acquired or requisitioned and either fixes the amount of the
compensation or specifies the principles on which, and the manner in which, the compensation is to
be determined and given; and no such law shall be called in question in any court on the ground that
the compensation provided by that law is not adequate. [In article 31 of the Constitution, for clause
(2), the following clauses shall be substituted through Constitution (Fourth Amendment) Act,
1955](2A) Where a law does not provide for the transfer of the ownership or right to possession of
any property to the State or to a corporation owned or controlled by the State, it shall not be deemed
to provide for the compulsory acquisition or requisitioning of property, notwithstanding that it
deprives any person of his property. [In article 31 of the Constitution, for clause (2-A), the following
clauses shall be substituted through Constitution (Fourth Amendment) Act, 1955][Editorial
Comment- The Constitution (Fourth Amendment) Act, 1955, did make changes to Article 31 of the
Indian Constitution, which deals with the right to property. The amendment aimed to address issues
related to the acquisition of property by the state for public purposes and the determination of
compensation for such acquired property.The changes introduced were intended to provide the
government with greater flexibility in acquiring land for public welfare, including land reform
measures, while ensuring that individuals affected by such acquisitions receive fair compensation.
Important Verdicts: State of West Bengal v. Bela banerjee & Saghir Ahmad v. The State of U.P. ](2B)
Nothing is sub-clause (f) of clause (1) of article 19 shall affect any such law as, is referred to in clause
(2).[Editorial comment-The Constitution (Twenty-Fifth Amendment) Act, 1971, this AmendmentConstitution of India

sought to overcome the restrictions imposed on the government by the Supreme Court ruling.
Article 31, as it stood prior to the Amendment, specially provided that no law providing for the
compulsory acquisition or requisitioning of property which either fixes or specifies on which and the
manner in which the compensation is to be determined and given, shall be called in question in any
court on the ground that the compensation provided by that law is inadequate. Also refer](3)No
such law as is referred to in clause (2) made by the Legislature of a State shall, have effect unless
such law, having been reserved for the consideration of the President, has received his assent.(4)If
any Bill pending at the commencement of this Constitution in the Legislature of a State has, after it
has been passed by such Legislature, been reserved for the consideration of the President and has
received his assent, then, notwithstanding anything in this Constitution, the law so assented to shall
not be called in question in any Court on the ground that it contravenes the provisions of clause
(2).[Editorial comment -The Constitution (First Amendment) Act, 1951, made several changes to
the Fundamental Rights Part of the Indian constitution. The Indian Parliament observed that the
legality of agrarian reform measures enacted by State Legislatures faced prolonged legal disputes
despite the provisions in clauses (4) and (6) of Article 31. This protracted litigation hindered the
implementation of crucial measures impacting a significant population. Consequently, a new
provision, Article 31A, was introduced to safeguard such measures going forward. Additionally,
another retrospective provision, Article 31B, was introduced to validate 13 enactments pertaining to
the abolition of zamindari. Also refer](5)Nothing in clause (2) shall affect-(a)the provisions of any
existing law other than a law to which the provisions of clause (6) apply, or(b)the provisions of any
law which the State may hereafter make-(i)for the purpose of imposing or levying any tax or penalty,
or(ii)for the promotion of public health or the prevention of danger to life or property, or(iii)in
pursuance of any agreement entered into between the Government of the Dominion of India or the
Government of India and the Government of any other country, or otherwise, with respect to
property declared by law to be evacuee property.(6)Any law of the State enacted not more than
eighteen months before the commencement of this Constitution may within three months from such
commencement be submitted to the President for his certification; and thereupon, if the President
by public notification so certifies, it shall not be called in question in any Court on the ground that it
contravenes the provisions of clause (2) of this article or has contravened the provisions of
sub-section (2) of section 299 of the Government of India Act, 1935."[Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
31A. Saving of laws providing for acquisition of estates, etc.
[After Article 31 of the Constitution, the following article shall be inserted through Constitution
(First Amendment) Act, 1951](1)Notwithstanding anything contained in article 13, no law providing
for- [for clause (1), the following clause shall be substituted Constitution (Fourth Amendment) Act,
1955](a)the acquisition by the State of any estate or of any rights therein or the extinguishments orConstitution of India

modification of any such rights, or(b)the taking over of the management of any property by the Stale
for a limited period either in the public interest or in order to secure the proper management of the
property, or(c)the amalgamation of two or more corporations either in the public interest or in order
to secure the proper management of any of the corporations, or(d)the extinguishment or
modification of any rights of managing agents, secretaries and treasurers, managing directors,
directors or managers of corporations, or of any voting rights of shareholders thereof, or(e)the
extinguishment or modification of any rights accruing by virtue of any agreement, lease or licence
for the purpose of searching for, or winning, any mineral or mineral oil, or the premature
termination or cancellation of any such agreement, lease or licence,shall be deemed to be void on
the ground that it is inconsistent with, or takes away or abridges any of the rights conferred byarticle
14 or article 19:Provided that where such law is a law made by the Legislature of a State, the
provisions of this article shall not apply thereto unless such law, having been reserved for the
consideration of the President, has received his assent:Provided further that where any law makes
any provision for the acquisition by the State of any estate and where any land comprised therein is
held by a person under his personal cultivation, it shall not be lawful for the State to acquire any
portion of such land as is within the ceiling limit applicable to him under any law for the time being
in force or any building or structure standing thereon or appurtenant thereto, unless the law relating
to the acquisition of such land, building or structure, provides for payment of compensation at a rate
which shall not be less than the market value thereof.(2)In this article,-(a)the expression "estate",
shall, in relation to any local area, have the same meaning as that expression or its local equivalent
has in the existing law relating to land tenures in force in that area and shall also include-(i)any
jagir, inam or muafi or other similar grant and in the States of Tamil Nadu and Kerala, any janmam
right;(ii)any land held under ryotwari settlement;(iii)any land held or let for purposes of agriculture
or for purposes ancillary thereto, including waste land, forest land, land for pasture or sites of
buildings and other structures occupied by cultivators of land, agricultural labourers and village
artisans;(b)the expression "rights", in relation to an estate, shall include any rights vesting in a
proprietor, sub-proprietor, under-proprietor, tenure-holder, raiyat, under-raiyat or other
intermediary and any rights or privileges in respect of land revenue.[Editorial Comment- The
Constitution (Fourth Amendment) Act, 1955, The entire Article 31A was realized to be unassailable
based on stare decisis, a quietus that should not allow being disturbed. This was declared during the
Minerva mills vs Union of India case. The First Amendment in which Article 31A was introduced.
While the Fourth Amendment which substituted new clauses to this Article has been held
constitutional, in Waman Rao and I R Coelho case. Section 3 of the Constitution (Fourth
Amendment) Act, 1955 substituted a new clause (1), sub-clauses (a) to (e) for the original clause (1)
with retrospective effect. It does not violate any of the basic or essential features of the Constitution
or its basic structure. It was held valid and constitutional within the constituent power of the
Parliament of India under the Constitution. ]}}[Editorial Comment-The Constitution
(Seventeenth Amendment) Act, 1964, modifies article 31A and schedule 9 of the Indian
Constitution. This revision prohibited the acquisition of land used for personal agriculture unless a
price equal to the property’s market value was paid. In addition, 44 more Acts were added to the
ninth schedule.][Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978,
repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a
separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of
speedy remedy under Article 32 for the violation of Right to Property because it is no more aConstitution of India

Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
31B. Validation of certain Acts and Regulations
[After Article 31-A of the Constitution, the following article 31-B shall be inserted through
Constitution (First Amendment) Act, 1951]Without prejudice to the generality of the provisions
contained in article 31A, none of the Acts and Regulations specified in the Ninth Schedule nor any of
the provisions thereof shall be deemed to be void, or ever to have become void, on the ground that
such Act, Regulation or provision is inconsistent with, or takes away or abridges any of the rights
conferred by any provisions of this Part, and notwithstanding any judgment, decree or order of any
court or tribunal to the contrary, each of the said Acts and Regulations shall, subject to the power of
any competent Legislature to repeal or amend it, continue in force.[Editorial comment - In the
case of I R Coelho v. State of Tamil Nadu (2007): It was held that all laws (including those in the
Ninth Schedule) would be open to Judicial Review if they violated the basic structure of the
constitution. The laws placed under Ninth Schedule after April 24, 1973 shall be open to challenge in
court if they violated fundamental rights guaranteed under Article 14, 19, 20 and 21 of the
Constitution. It was further held that if the constitutional validity of any law under the ninth
schedule has been upheld before, in future it cannot be challenged again.]
31C. Saving of laws giving effect to certain directive principles
Notwithstanding anything contained in article 13, no law giving effect to the policy of the State
towards securing all or any of the principles laid down in Part IV shall be deemed to be void on the
ground that it is inconsistent with, or takes away or abridges any of the rights conferred by article 14
or article 19 and no law containing a declaration that it is for giving effect to such policy shall be
called in question in any court on the ground that it does not give effect to such policy:Provided that
where such law is made by the Legislature of a State, the provisions of this article shall not apply
thereto unless such law, having been reserved for the consideration of the President, has received
his assent.[Editorial comment-The Constitution (Twenty-Fifth Amendment) Act, 1971, this
amendment would also to insert a new clause 31(C) in the Constitution, which would prevent a bill
from being challenged in the Court, either under Article 14 (equality before the law), Article 19 (right
to property, freedom of association, speech, religion etc.) or Article 31 (on deprivation of law except
under authority of law), if Parliament certified that the bill was intended to ensure equitable
distribution of material resources or to prevent concentration of economic power.Important
Verdict-Rustom Cavasjee Cooper v. Union Of India] The Court also held that a law which seeks to
acquire or requisition property for public purposes must satisfy the requirement of Article 19 (1)(f).
The 25th Amendment sought to overcome the restrictions imposed on the government by this
ruling.Also refer]][Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978,
repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a
separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of
speedy remedy under Article 32 for the violation of Right to Property because it is no more a
Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, itConstitution of India

gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
31D. Saving of laws in respect of anti-national activities [Repealed]
[After article 31C of the Constitution and before the sub-heading "Right to Constitutional
Remedies", the following article shall be inserted through Constitution (Forty-Second Amendment)
Act, 1976]Notwithstanding anything contained in article 13, no law providing for-(a)the prevention
or prohibition of anti-national activities; or(b)the prevention of formation of, or the prohibition of,
anti-national associations,shall be deemed to be void on the ground that it is inconsistent with, or
takes away or abridges any of the rights conferred by, article 14, article 19 or article
31.(2)Notwithstanding anything in this Constitution, Parliament shall have, and the Legislature of a
State shall not have, power to make laws with respect to any of the matters referred to in sub-clause
(a) or sub-clause (b) of clause (1).(3)Any law with respect to any matter referred to in sub-clause (a)
or sub-clause (b) of clause (1) which is in force immediately before the commencement of section 5
of the Constitution (Forty-second Amendment) Act, 1976, shall continue in force until altered or
repealed or amended by Parliament.(4)In this article,-(a)"association" means an association of
persons;(b)"anti-national activity", in relation to an individual or association, means any action
taken by such individual or association-(i)which is intended, or which supports any claim, to bring
about, on any ground whatsoever, the cession of a part of the territory of India or the secession of a
part of the territory of India or which in cities any individual or association to bring about such
cession or secession;(ii)which disclaims, questions, threatens, disrupts or is intended to threaten or
disrupt the sovereignty and integrity of India or the security of the State or the unity of the
nation;(iii)which is intended, or which is part of a scheme which is intended, to overthrow by force
the Government as by law established;(iv)which is intended, or which is part of a scheme which is
intended, to create internal disturbance or the disruption of public services;(v)which is intended, or
which is part of a scheme which is intended, to threaten or disrupt harmony between different
religious, racial, language or regional groups or castes or communities;(c)"anti-national association"
means an association---(i)which has for its object any anti-national activity;(ii)which encourages or
aids persons to undertake or engage in any anti-national activity;(iii)the members whereof
undertake or engage in any anti-national activity.'.[Article 31D of the Constitution shall be
omitted.][Editorial comment-The Constitution (Forty-Third Amendment) Act, 1977, this
amendment fundamental rights law that was passed during the Emergency. By eliminating Article
31D, it restores civil liberties. Under the cover of anti-national activity prevention legislation, this
gave Parliament of India the authority to restrict even legal union activity. Also Refer]
32. Remedies for enforcement of rights conferred by this Part
(1)The right to move the Supreme Court by appropriate proceedings for the enforcement of the
rights conferred by this Part is guaranteed.(2)The Supreme Court shall have power to issue
directions or orders or writs, including writs in the nature of habeas corpus, mandamus,
prohibition, quo warrant and certiorari, whichever may be appropriate, for the enforcement of any
of the rights conferred by this Part.(3)Without prejudice to the powers conferred on the Supreme
Court by clauses (1) and (2), Parliament may by law empower any other court to exercise within theConstitution of India

local limits of its jurisdiction ill or any of the powers exercisable by the Supreme Court under clause
(2).(4)The right guaranteed by this article shall not be suspended except as otherwise provided for
by this Constitution.Editorial Comment - Article 32 of the Indian Constitution is a fundamental
right that guarantees the right to constitutional remedies. It is considered one of the most crucial
provisions in the Constitution as it empowers individuals to seek protection and enforcement of
their fundamental rights directly from the Supreme Court of India.
Article 32 grants every individual the right to move the Supreme Court for the enforcement of their
fundamental rights. This means that if someone believes their fundamental rights have been
violated, they can approach the Supreme Court directly for relief. It also ensures that not only do
individuals have the right to move the Supreme Court, but the Court also has the power to issue
appropriate orders, directions, or writs for the enforcement of fundamental rights.
The Supreme Court can issue five types of writs under Article 32:
Habeas Corpus: To ensure the release of a person who has been unlawfully detained.
When Article 21 was suspended during the National Emergency, it was held in Addl. District
Magistrate, Jabalpur v. Shukla (Habeas Corpus Case) that an order of preventive detention could
not be challenged even if it violated the parent Act (i.e, the Act relating to preventive detention). The
44th Amendment, 1978, has provided that Article 21, relating to personal liberty cannot be
suspended even during an emergency.
The writ of Habeas Corpus is a check on the governmental powers to curtail the liberty of a person;
its fundamental purpose is to ensure timely review of illegal detention. The scope and extent of this
writ is enunciated by the Supreme Court in State of Maharashtra v. Bhaurao Punjabrao Gawande.
The Court stated that the writ of habeas corpus has been described as a "constitutional privilege or
the first security of civil liberty" as it provides a speedy remedy against illegal detention. By the
virtue of this writ, the Court directs the authority which has detained a person to produce the body
of the person before the Court so that it can assess the legitimacy of the arrest or detention.
Mandamus: To direct a public official or authority to perform a duty they are legally bound to
perform.
In the case of S.P. Gupta v. Union of India, the court entailed that a writ cannot be issued against the
President of India for fixing the number of judges in High Courts and filling vacancies. In E.A.
Co-operative Society v. Maharastra, A.I.R. 1966 S.C. 1449 case the Court opined that the writ of
mandamus can be issued when the government denies to itself a jurisdiction which it undoubtedly
has under the law
In Bombay Municipality v. Advance Builders, AIR 1972 SC 793 case, Bombay Municipality had
prepared a town planning scheme which had been also approved by the State Government.
However, no action was taken for a long time. The Court opined that the writ of mandamus can be
issued where an authority vested with a power improperly refuses to exercise it and directed theConstitution of India

municipality to implement a planning scheme.
In State of West Bengal v. Nuruddin(1998) 8 SCC 143 case, the Supreme Court held the writ of
mandamus is a personal action where the respondent has not done the duty they were prescribed to
do by law. The performance of the duty is the right of the applicant.
In The Praga Tools Corporation v. C.V. Imanual, 1969 and Sohanlal v. Union of India, (1957) the
Supreme Court held that mandamus might under certain circumstances lie against a private
individual if it is established that he has colluded with a public authority.
Then, in the case of Manjula Manjori v. Director of Public Instruction, the publisher of a book had
applied for the writ of mandamus against the Director of Public Instruction for the inclusion of his
book in the list of books which were approved as text-books in schools. But the writ was not allowed
as the matter was completely within the discretion of D.I.P and he was not bound to approve the
book.
In the case of Binny Ltd. & Anr v. V. Sadasivan & Ors (2005), the Supreme Court laid down the
scope of mandamus. It stated that a writ of mandamus is not applicable against any private wrong.
It can be issued only when any public authority exercises its duty unlawfully or refuses to perform
its duty within the ambit of the law.
In the case of Ramakrishna Mission v. Kago Kunya (2019), The Supreme Court ruled that where a
contract is of private nature or has no connection with any public authority, it does not fall within
the purview of the writ of mandamus.
Prohibition: To prevent a lower court or tribunal from exceeding its jurisdiction.
In, Brij Khandelwal v. India (1975) the Delhi High Court refused to issue a prohibition against the
Central Government from engaging in a boundary dispute agreement with Sri Lanka. The judgment
was founded on the basis that there is no bar against the government performing executive or
administrative duties. With the idea of natural justice and the growth of the concept of fairness,
there is no longer a tolerable view, even in administrative tasks. If any of the grounds on which the
writ of prohibition is issued is present, the writ can now be issued to anybody, regardless of the
nature of the duty fulfilled by it. Prohibition is currently considered as a broad remedy for judicial
control of impacting quasi-judicial as well as administrative actions.
In the case, S. Govind Menon v. Union of India (1967) a Writ of prohibition was issued by a higher
court, namely the Kerala High Court, to a lower court in order to take over jurisdiction that was not
initially vested, or in other words, to compel lower courts to retain their jurisdictional limitations.
The writ can be issued when there is an excess of jurisdiction as well as when there is an absence of
jurisdiction.
In the case, Hari Vishnu v. Syed Ahmed Ishaque (1955) dealt with distinctions between writs of
prohibition and certiorari. The verdict, in this case, distinguished between certiorari and prohibitionConstitution of India

writs and said that when the lower court issues a decision, the petitioner must file a certiorari
petition since prohibition writs can only be submitted when judgment has not yet been given.
In this case, Prudential Capital Markets Ltd v. The State of A.P. and others, (2000) it was
questionable whether the prohibition writ could be issued against the district forum/state
commission which had already passed judgments in the depositors’ consumer cases. The Court held
that after the execution of the order, the writ of prohibition cannot be issued, the judgment can
neither be prevented nor stopped.
Certiorari: To quash an order passed by a lower court, tribunal, or authority.
In Surya Dev Rai v. Ram Chander Rai & Ors., the Supreme Court has explained the meaning, ambit
and scope of the writ of Certiorari. Also, in this it was explained that Certiorari is always available
against inferior courts and not against equal or higher courts, i.e., it cannot be issued by a High
Court against any High Court or benches much less to the Supreme Court and any of its benches.
Then in the case of T.C. Basappa v. T. Nagappa & Anr., it was held by the constitution bench that
certiorari may and is generally granted when a court has acted (i) without jurisdiction or (ii) in
excess of its jurisdiction.
In Hari Bishnu Kamath v. Ahmad Ishaque the Supreme Court said that “the court issuing certiorari
to quash, however, could not substitute its own decision on the merits or give directions to be
complied with by the court or tribunal. Its work was destructive, it simply wiped out the order
passed without jurisdiction, and left the matter there.” In Naresh S. Mirajkar v. State of
Maharashtra , it was said that High Court’s judicial orders are open to being corrected by certiorari
and that writ is not available against the High Court.
Quo Warranto: To inquire into the legality of a person's claim to a public office.
In the case of G.D. Karkare v. T.L. Shevde, the High Court of Nagpur observed that “In proceedings
for a writ of quo-warranto, the applicant does not seek to enforce any right of his as such nor does he
complain of any non-performance of duty towards him. What is in question is the right of the
non-applicant to hold the office and an order that is passed is an order ousting him from that office.”
In the case of Bharati Reddy v. The State Of Karnataka (2018), the Hon’ble Supreme Court held that
a writ of quo warranto cannot be issued based on assumptions, inferences, or speculations
concerning the fact of accomplishment of qualifying conditions. There must be an establishment of
the fact that a public officer is abusing lawful powers not vested to him within the public authority. 
Direct Access to Supreme Court: Unlike Article 226, which pertains to the High Courts and enables
individuals to seek writs for enforcement of their fundamental rights, Article 32 provides a direct
avenue to the Supreme Court for this purpose.
Suspension During Emergency: During a proclamation of Emergency, the right to move theConstitution of India

Supreme Court under Article 32 can be suspended. However, the suspension does not extend to
fundamental rights guaranteed under Articles 20 and 21 (protections in case of conviction and
protection of life and personal liberty, respectively).ReferencesLegal Service IndiaThe Legal
QuotientBlog Ipleaders
32A. Constitutional validity of State laws not to be considered in proceedings
under article 32 [Repealed]
Notwithstanding anything in article 32, the Supreme Court shall not consider the constitutional
validity of any State law in any proceedings under that article unless the constitutional validity of
any Central law is also in issue in such proceedings.[Rep . b y the Constitution (Forty-third
Amendment) Act, 1977 , section 3 (w .e.f . 13. 4. 1978)][Editorial comment-The Constitution
(Forty-Third Amendment) Act, 1977, Article 32(A) of the Constitution said that the Supreme Court
would not look at the constitutionality of state laws during writ proceedings to enforce Fundamental
Rights. The said article has been omitted.Also Refer][Any proceedings pending before the Supreme
Court under article 32 of the Constitution immediately before the commencement of this Act may be
dealt with by the Supreme Court as if the said article 32A had been omitted with effect on and from
the 1st day of February, 1977.]
33. Power of Parliament to modify the rights conferred by this Part in their
application to Forces, etc.
Parliament may, by law, determine to what extent any of the rights conferred by this Part shall, in
their application to,-(a)the members of the Armed Forces; or(b)the members of the Forces charged
with the maintenance of public order; or(c)persons employed in any bureau or other organisation
established by the State for purposes of intelligence or counter intelligence; or(d)persons employed
in, or in connection with, the telecommunication systems set up for the purposes of any Force,
bureau or organisation referred to in clauses (a) to (c), be restricted or abrogated so as to ensure the
proper discharge of their duties and the maintenance of discipline among them.[[[Editorial
comment-The Constitution (Fiftieth Amendment) Act, 1984, dealt with the modification of Article
33 majorly. The Act has been amended to include employees working for the State for purposes of
intelligence and counterintelligence bureaus, as well as those hired for telecommunication systems
related to any Force, bureau, or organization. This amendment was made to ensure that employees
perform their duties properly and maintain discipline. The amendment recognizes the importance
of maintaining proper performance and discipline in these organizations.Also Refer]
34. Restriction on rights conferred by this Part while martial law is in force in
any area
Notwithstanding anything in the foregoing provisions of this Part, Parliament may by law indemnify
any person in the service of the Union or of a State or any other person in respect of any act done by
him in connection with the maintenance or restoration of order in any area within the territory of
India where martial law was in force or validate any sentence passed, punishment inflicted,Constitution of India

forfeiture ordered or other act done under martial law in such area.
35. Legislation to give effect to the provisions of this Part
Notwithstanding anything in this Constitution,—(a)Parliament shall have, and the Legislature of a
State shall not have, power to make laws—(i)with respect to any of the matters which under clause
(3) of article 16, clause (3) of article 32, article 33 and article 34 may be provided for by law made by
Parliament; and(ii)for prescribing punishment for those acts which are declared to be offences
under this Part;and Parliament shall, as soon as may be after the commencement of this
Constitution, make laws for prescribing punishment for the acts referred to in sub-clause (ii);(b)any
law in force immediately before the commencement of this Constitution in the territory of India with
respect to any of the matters referred to in sub-clause (i) of clause (a) or providing for punishment
for any act referred to in sub-clause (ii) of that clause shall, subject to the terms thereof and to any
adaptations and modifications that may be made therein under article 372, continue in force until
altered or repealed or amended by Parliament.Explanation.—In this article, the expression "law in
force" has the same meaning as in article 372.
35A. Saving of laws with respect to permanent residents and their rights. —
Notwithstanding anything contained in this Constitution, no existing law in force in the State of
Jammu and Kashmir, and no law hereafter enacted by the Legislature of the State:(a)defining the
classes of persons who are, or shall be, permanent residents of the State of Jammu and Kashmir;
or(b)conferring on such permanent residents any special rights and privileges or imposing upon
other persons any restrictions as respects—(i)employment under the State
Government;(ii)acquisition of immovable property in the State;(iii)settlement in the State;
or(iv)right to scholarships and such other forms of aid as the State Government may provide, shall
be void on the ground that it is inconsistent with or takes away or abridges any rights conferred on
the other citizens of India by any provision of this part.[Editorial Note-Article 370 of the
Constitution of India provided a special status to the state of Jammu and Kashmir, granting it a
degree of autonomy within the Indian union. Article 370 was incorporated into the Constitution of
India as a temporary provision, with the intention of providing a framework for negotiations
between the Indian government and the leadership of Jammu and Kashmir to determine the state's
final political status. This was done through the instrument of a Presidential Order in 1954, which
extended various provisions of the Indian Constitution to Jammu and Kashmir, subject to certain
modifications. Article 370 was incorporated into the Constitution of India as a temporary provision,
with the intention of providing a framework for negotiations between the Indian government and
the leadership of Jammu and Kashmir to determine the state's final political status. This was done
through the instrument of a Presidential Order in 1954, which extended various provisions of the
Indian Constitution to Jammu and Kashmir, subject to certain modifications. Article 370 and Article
35A were closely linked in terms of their impact on the constitutional and legal status of Jammu and
Kashmir. Article 370 was the constitutional provision that granted special status to Jammu and
Kashmir, while Article 35A was a legal provision that flowed from Article 370 and gave the state of
Jammu and Kashmir the power to define who is a "permanent resident" of the state, and to confer
special rights and privileges to these residents. Article 35A was added to the Indian ConstitutionConstitution of India

through a Presidential Order in 1954, which was issued under the authority of Article 370. The
provision allowed the Jammu and Kashmir state legislature to define permanent residents of the
state and provide them with special rights and privileges, such as the right to own property, access
to government jobs, and scholarships. The provision also prohibited non-permanent residents from
acquiring any of these rights or privileges. In April 2018, the Supreme Court of India ruled that
Article 370 had attained permanency since the state constituent assembly has ceased to exist. To
overcome this legal challenge, the Indian government instead rendered Article 370 as 'Inoperative'
even though it still exists in the constitution. On 5 August, issued a Presidential Order C.O. 272; the
Constitution (Application to Jammu and Kashmir) Order, 2019 which superseded the Constitution
(Application to Jammu and Kashmir) Order, 1954. This in effect meant that the separate
Constitution of Jammu and Kashmir stood inoperative, and a single constitution now applied to all
the Indian states. The order was issued using the third clause of Article 370, which authorized the
President of India to declare the article inoperative with exceptions and modifications, if
recommended by the (non-existent) state constituent assembly to do so. To circumvent the legal
issue of the non-existent state constituent assembly, the President used the Clause (1) of Article 370,
which conferred him with the power to modify the Indian Constitution on subjects related to
Jammu and Kashmir. So he first added a new clause to Article 367, which deals with interpretation
of the Constitution. He replaced the phrase 'Constituent Assembly of the State' with 'Legislative
Assembly of the State'. Since the state legislative assembly has been suspended, the order says that
any reference to the legislative assembly will be construed as a reference to the Governor of Jammu
and Kashmir. The governor is an appointee of the Central government. Therefore, the Indian
Parliament now functions for the state legislative assembly.]
Part IV – Directive Principles of State Policy
36. Definition
In this Part, unless the context otherwise requires, "the State" has the same meaning as in Part III.
37. Application of the principles contained in this Part
The provisions contained in this Part shall not be enforceable by any court, but the principles
therein laid down are nevertheless fundamental in the governance of the country and it shall be the
duty of (he Stale to apply these principles in making laws.
38. State to secure a social order for the promotion of welfare of the people
(1)The State shall strive to promote the welfare of the people by securing and protecting as
effectively as it may a social order in which justice, social, economic and political, shall inform all the
institutions of the national life.(2)The State shall, in particular, strive to minimize the inequalities in
income, and endeavor to eliminate inequalities in status, facilities and opportunities, not only
amongst individuals but also amongst groups of people residing in different areas or engaged in
different vocations.[Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978,Constitution of India

repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a
separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of
speedy remedy under Article 32 for the violation of Right to Property because it is no more a
Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
39. Certain principles of policy to be followed by the State
The State shall, in particular, direct its policy towards securing--(a)that the citizens, men and
women equally, have the right to an adequate means to livelihood;(b)that the ownership and control
of the material resources of the community are so distributed as best to sub serve the common
good;(c)that the operation of the economic system does not result in the concentration of wealth and
means of production to the common detriment;(d)that there is equal pay for equal work for both
men and women;(e)that the health and strength of workers, men and women, and the tender age of
children are not abused and that citizens are not forced by economic necessity to enter avocations
unsuited to their age or strength;[In article 39 of the Constitution, for clause (f), the following clause
shall be substituted through Constitution (Forty-Second Amendment) Act, 1976](f)that children are
given opportunities and facilities to develop in a healthy manner and in conditions of freedom and
dignity and that childhood and youth are protected against exploitation and against moral and
material abandonment.[Editorial comment-The Constitution (Forty-Second Amendment) Act,
1976, New DPSPs (Directive Principles of State Policy) had been added to the existing list, where it
secure opportunities for the healthy development of children. Important Verdict-Minerva Mills Ltd.
And Ors. vs Union Of India (Uoi) And Ors. Also Refer]
39A. Equal justice and free legal aid
[After article 39 of the Constitution, the following article shall be inserted through Constitution
(Forty-Second Amendment) Act, 1976]The State shall secure that the operation of the legal system
promotes justice, on a basis of equal opportunity, and shall, in particular, provide free legal aid, by
suitable legislation or schemes or in any other way, to ensure that opportunities for securing justice
are not denied to any citizen by reason of economic or other disabilities.[Editorial comment-The
Constitution (Forty-Second Amendment) Act, 1976,New DPSPs (Directive Principles of State Policy)
had been added to the existing list, where to promote equal justice and to provide free legal aid to
the poor. Important Verdict-Minerva Mills Ltd. And Ors. vs Union Of India (Uoi) And Ors. Also
Refer]
40. Organisation of village panchayats
The State shall take steps to organize village panchayats and endow them with such powers and
authority as may be necessary to enable them to function as units of self-government.Constitution of India

41. Right to work, to education and to public assistance in certain cases
The State shall, within the limits of its economic capacity and development, make effective provision
for securing the right to work, to education and to public assistance in cases of unemployment, old
age, sickness and disablement, and in other cases of undeserved want.
42. Provision for just and humane conditions of work and maternity relief
The State shall make provision for securing just and humane conditions of work and for maternity
relief.
43. Living wage, etc., for workers
The State shall endeavour to secure, by suitable legislation or economic organisation or in any other
way, to all workers, agricultural, industrial or otherwise, work, a living wage, conditions of work
ensuring a decent standard of life and full enjoyment of leisure and social and cultural opportunities
and, in particular, the State shall endeavour to promote cottage industries on an individual or
co-operative basis in rural areas.
43A. Participation of workers in management of industries
[After article 43 of the Constitution, the following article shall be inserted Constitution
(Forty-Second Amendment) Act, 1976]The State shall take steps, by suitable legislation or in any
other way, to secure the participation of workers in the management of undertakings,
establishments or other organisations engaged in any industry.[Editorial comment-The
Constitution (Forty-Second Amendment) Act, 1976, New DPSPs (Directive Principles of State
Policy) had been added to the existing list, where To take steps to secure the participation of workers
in the management of industries. Important Verdict-Minerva Mills Ltd. And Ors. vs Union Of India
(Uoi) And Ors. Also Refer]
43B. Promotion of cooperative societies
The State shall endeavour to promote voluntary formation, autonomous functioning, democratic
control and professional management of co-operative societies.[Editorial comment-The
Constitution (Ninety-seventh Amendment) Act, 2011,addition of Article 43B to the Constitution.
This article mainly deals with the development of Cooperative societies. It says that the state shall
strive to promote the voluntary formation, democratic control, and professional management of
cooperative societies. Also Refer]
44. Uniform civil code for the citizens
The State shall endeavour to secure for the citizens a uniform civil code throughout the territory of
India.Constitution of India

45. Provision for free and compulsory education for children
The State shall endeavour to provide, within a period of ten years from the commencement of this
Constitution, for free and compulsory education for all children until they complete the age of
fourteen years.
46. Promotion of educational and economic interests of Scheduled Castes,
Scheduled Tribes and other weaker sections
The State shall promote with special care the educational and economic interests of the weaker
sections of the people, and, in particular, of the Scheduled Castes and the Scheduled Tribes, and
shall protect them from social injustice and all forms of exploitation.
47. Duty of the State to raise the level of nutrition and the standard of living
and to improve public health
The State shall regard the raising of the level of nutrition and the standard of living of its people and
the improvement of public health as among its primary duties and, in particular, the State shall
endeavour to bring about prohibition of the consumption except for medicinal purposes of
intoxicating drinks and of drugs which are injurious to health.
48. Organisation of agriculture and animal husbandry
The State shall endeavour to organise agriculture and animal husbandry on modern and scientific
lines and shall, in particular, take steps for preserving and improving the breeds, and prohibiting the
slaughter of cows and calves and other milch and draught cattle.
48A. Protection and improvement of environment and safeguarding of
forests and wild life
[After article 48 of the Constitution, the following article shall be inserted Constitution
(Forty-Second Amendment) Act, 1976]The State shall endeavour to protect and improve the
environment and to safeguard the forests and wild life of the country.[Editorial comment-The
Constitution (Forty-Second Amendment) Act, 1976, New DPSPs (Directive Principles of State
Policy) had been added to the existing list, where to protect and improve the environment and to
safeguard forests and wildlife. Important Verdict-Minerva Mills Ltd. And Ors. vs Union Of India
(Uoi) And Ors. Also Refer]
49. Protection of monuments and places and objects of national importance
It shall be the obligation of the State to protect every monument or place or object of artistic or
historic interests,declared by or under law made by Parliament to be of national importance, fromConstitution of India

spoilation, disfigurement, destruction, removal, disposal or export, as the case may be.
50. Separation of judiciary from executive
The State shall take steps to separate the judiciary from the executive in the public services of the
State.
51. Promotion of international peace and security
The State shall endeavour to--(a)promote international peace and security;(b)maintain just and
honourable relations between nations;(c)foster respect for international law and treaty obligations
in the dealings of organised peoples with one another; and(d)encourage settlement of international
disputes by arbitration.
Part IVA – Fundamental Duties
51A. Fundamental duties
[After Part IV of the Constitution, the following Part shall be inserted Constitution (Forty-Second
Amendment) Act, 1976]It shall be the duty of every citizen of India--(a)to abide by the Constitution
and respect its ideals and institutions, the National Flag and the National Anthem;(b)to cherish and
follow the noble ideals which inspired our national struggle for freedom;(c)to uphold and protect the
sovereignty, unity and integrity of India;(d)to defend the country and render national service when
called upon to do so;(e)to promote harmony and the spirit of common brotherhood amongst all the
people of India transcending religious, linguistic and regional or sectional diversities; to renounce
practices derogatory to the dignity of women;(f)to value and preserve the rich heritage of our
composite culture;(g)to protect and improve the natural environment including forests, lakes, rivers
and wild life, and to have compassion for living creatures;(h)to develop the scientific temper,
humanism and the spirit of inquiry and reform;(i)to safeguard public properly and to abjure
violence;(j)to strive towards excellence in all spheres of individual and collective activity so that the
nation constantly rises to higher levels of endeavour and achievement.(k)who is a parent or
guardian to provide opportunities for education to hi s child or, as the case may be, ward between
the age of six and fourteen years.[Editorial comment-The Constitution (Forty-Second
Amendment) Act, 1976, defined the 10 Fundamental Duties of Citizens. This amendment was in line
with the Swaran Singh Committee modifications.Important Verdict-Minerva Mills Ltd. And Ors. vs
Union Of India (Uoi) And Ors. Also Refer]
Part V – The Union
52. The President of India
There shall be a President of India.Constitution of India

53. Executive power of the Union
(1)The executive power of the Union shall be vested in the President and shall be exercised by him
either directly or through officers subordinate to him in accordance with this
Constitution.(2)Without prejudice to the generality of the foregoing provision, the supreme
command of the Defense Forces of the Union shall be vested in the President and the exercise
thereof shall be regulated by law.(3)Nothing in this article shall--(a)be deemed to transfer to the
President any functions conferred by any existing law on the Government of any State or other
authority; or(b)prevent Parliament from conferring by law functions on authorities other than the
President.
54. Election of President
The President shall be elected by the members of an electoral college consisting of--(a)the elected
members of both Houses of Parliament; and(b)the elected members of the Legislative Assemblies of
the States.Explanation.--In this article and in article 55, "State" includes the National Capital
Territory of Delhi and the Union Territory of Pondicherry.[Editorial comment-The Constitution
(Seventieth Amendment) Act, 1992, incorporated the elected members of the Pondicherry
Legislative Assembly into the President’s Electoral College. The Electoral College for the presidential
election will now include the National Capital Territory of Delhi and the Union Territory of
Pondicherry.Also Refer]
55. Manner of election of President
(1)As far as practicable, there shall be uniformity in the scale of representation of the different States
at the election of the President.(2)For the purpose of securing such uniformity among the States
inter se as well as parity between the States as a whole and the Union, the number of votes which
each elected member of Parliament and of the Legislative Assembly of each State is entitled to cast
at such election shall be determined in the following manner:--(a)every elected member of the
Legislative Assembly of a State shall have as many votes as there are multiples of one thousand in
the quotient obtained by dividing the population of the State by the total number of the elected
members of the Assembly;(b)if, after taking the said multiples of one thousand, the remainder is not
less than five hundred, then the vote of each member referred to in sub-clause (a) shall be further
increased by one;(c)each elected member of either House of Parliament shall have such number of
votes as may be obtained by dividing the total number of votes assigned to the members of the
Legislative Assemblies of the States under sub-clauses (a) and (b) by the total number of the elected
members of both Houses of Parliament, fractions exceeding one-half being counted as one and other
fractions being disregarded.(3)The election of the President shall be held in accordance with the
system of proportional representation by means of the single transferable vote and the voting at
such election shall be by secret ballot.Explanation.--In this article, the expression "population"
means the population ascertained at the last preceding census of which the relevant figures have
been published:Provided that the reference in this Explanation to the last preceding census of which
the relevant figures have been published shall, until the relevant figures for the first census taken
after the year 2026 have been published, be construed as a reference to the 1971 census.[EditorialConstitution of India

comment-The Constitution (Eighty-fourth Amendment) Act, 2002, extended the bar on the
adjustment of seats in the Lok Sabha and State Legislative assemblies for the next 25 years with the
same goal of supporting population control measures. This meant that the 1971 national census
population data for the statewide distribution of parliamentary seats would be extended. This will
lead to the freezing or delimitation of Lok Sabha and State Assembly seats up till the first Census
after 2026. The number of Lok Sabha seats and State Assembly seats is based on the 1971 Census,
while the current boundaries are based on the 2001 Census. This means that the Lok Sabha and
assembly seats will be constant till the year 2026. Additionally, it demanded that territorial seats in
the states be adjusted and rationalized in light of population figures from the 1991 census.Also
Refer]
56. Term of office of President
(1)The President shall hold office for a term of five years from the date on which he enters upon his
office:Provided that-(a)the President may, by writing under his hand addressed to the
Vice-President, resign his office;(b)the President may, for violation of the Constitution, be removed
from office by impeachment in the manner provided in article 61:(c)the President shall,
notwithstanding the expiration of his term, continue to hold office until his successor enters upon
his office,(2)Any resignation addressed to the Vice-President under clause (a) of the proviso to
clause (1) shall forthwith be communicated by him to the Speaker of the House of the People.
57. Eligibility for re-election
A person who holds, or who has held, office as President shall, subject to the other provisions of this
Constitution, be eligible for re-election to that office.
58. Qualifications for election as President
(1)No person shall be eligible for election as President unless he--(a)is a citizen of India,(b)has
completed the age of thirty-five years, and(c)is qualified for election as a me member of the House of
the People.(2)A person shall not be eligible for election as President if he holds any office of profit
under the Government of India or the Government of any State or under any local or other authority
subject to the control of any of the said Governments.Explanation.--For the purposes of this article,
a person shall not be deemed to hold any office of profit by reason only that he is the President or
Vice President of the Union or the Governor of any State or is a Minister either for the Union or for
any State.
59. Conditions of President's office
(1)The President shall not be a member of either House of Parliament or of a House of the
Legislature of any State, and if a member of either House of Parliament or of a House of the
Legislature of any State be elected President, he shall be deemed to have vacated his seat in that
House on the date on which he enters upon his office as President.(2)The President shall not holdConstitution of India

any other office of profit.(3)The President shall be entitled without payment of rent to the use of his
official residences and shall be also entitled to such emoluments, allowances and privileges as may
be determined by Parliament by law and, until provision in that behalf is so made, such
emoluments, allowances and privileges as are specified in the Second Schedule.(4)The emoluments
and allowances of the President shall not be diminished during his term of office.
60. Oath or affirmation by the President
Every President and every person acting as President or discharging the functions of the President
shall, before entering upon his office, make and subscribe in the presence of the Chief Justice of
India or, in his absence, the senior most Judge of the Supreme Court available, an oath or
affirmation in the following form, that is to say-"I, A.B., do swear in the name of God/solemnly
affirm that I will faithfully execute the office of President (or discharge the functions of the
President) of India and will do the best of my ability preserve, protect and defend the Constitution
and the law and that I will devote myself to the service and well-being of the people of India."
61. Procedure for impeachment of the President
(1)When a President is to be impeached for violation of the Constitution, the charge shall be
preferred by either House of Parliament.(2)No such charge shall be preferred unless--(a)the
proposal to prefer such charge is contained in a resolution which has been moved after at least
fourteen days' notice in writing signed by not less than one-fourth of the total number of members
of the House has been given of their intention to move the resolution, and(b)such resolution has
been passed by a majority of not less than two-thirds of the total membership of the House.(3)When
a charge has been so preferred by either House of Parliament, the other House shall investigate the
charge or cause the charge to be investigated and the President shall have the right to appear and to
be represented at such investigation.(4)If as a result of the investigation a resolution is passed by a
majority of not less than two-thirds of the total membership of the House by which the charge was
investigated or caused to be investigated, declaring that the charge preferred against the President
has been sustained, such resolution shall have the effect of removing the President from his office as
from the date on which the resolution is so passed.
62. Time of holding election to fill vacancy in the office of President and the
term of office of person elected to fill casual vacancy
(1)An election to fill a vacancy caused by the expiration of the term of office of President shall be
completed before the expiration of the term.(2)An election to fill a vacancy in the office of President
occurring by reason of his death, resignation or removal, or otherwise shall be held as soon as
possible after, and in no case later than six months from, the date of occurrence of the vacancy, and
the person elected to fill the vacancy shall, subject to the provisions of article 56, be entitled to hold
office for the full term of five years from the date on which he enters upon his office.Constitution of India

63. The Vice-President of India
There shall be a Vice-President of India.
64. The Vice-President to be ex-officio Chairman of the Council of States
The Vice-President shall be ex-officio Chairman of the Council of States and shall not hold any other
office of profit:Provided that during any period when the Vice-President acts as President or
discharges the functions of the President under article 65, he shall not perform the duties of the
office of Chairman of the Council of Stales and shall not be entitled to any salary or allowance
payable to the Chairman of the Council of States under article 97.
65. The Vice-President to act as President or to discharge his functions
during casual vacancies in the office, or during the absence, of President
(1)In the event of the occurrence of any vacancy in the office of the President by reason of his death,
resignation or removal, or otherwise, the Vice-President shall act as President until the date on
which a new President elected in accordance with the provisions of this Chapter to fill such vacancy
enters upon his office.(2)When the President is unable to discharge his functions owing to absence,
illness or any other cause, the Vice-President shall discharge his functions until the date on which
the President resumes his duties.(3)The Vice-President shall, during, and in respect of, the period
while he is so acting as, or discharging the functions of, President, have all the powers and
immunities of the President and be entitled to such emoluments, allowances and privileges as may
be determined by Parliament by law and, until provision in that behalf is so made, such
emoluments, allowances and privileges as are specified in the Second Schedule.
66. Election of Vice-President
(1)The Vice-President shall be elected by themembers of an electoral college consisting of the
members of both Houses of Parliament in accordance with the system of proportional
representation by means of the single transferable vote and the voting at such election shall be by
secret ballot.(2)The Vice-President shall not be a member of either House of Parliament or of a
House of the Legislature of any State, and if a member of either House of Parliament or of a House
of the Legislature of any State be elected Vice-President, he shall be deemed to have vacated his seat
in that House on the date on which he enters upon his office as Vice-President.(3)No person shall be
eligible for election as Vice-President unless he--(a)is a citizen of India;(b)has completed the age of
thirty-five years; and(c)is qualified for election as a member of the Council of States.(4)A person
shall not be eligible for election as Vice-President if he holds any office of profit under the
Government of India or the Government of any State or under any local or other authority subject to
the control of any of the said Governments.Explanation.--For the purposes of this article, a person
shall not be deemed to hold any office of profit by reason only that he is the President or
Vice-President of the Union or the Governor of any State or is a Minister either for the Union or for
any State.Constitution of India

67. Term of office of Vice-President
The Vice-President shall hold office for a term of five years from the date on which he enters upon
his office:Provided that-(a)a Vice-President may, by writing under his hand addressed to the
President, resign his office;(b)a Vice-President may be removed from his office by a resolution of the
Council of States passed by a majority of all the then members of the Council and agreed to by the
House of the People; but no resolution for the purpose of this clause shall be moved unless at least
fourteen days' notice has been given of the intention to move the resolution;(c)a Vice-President
shall, notwithstanding the expiration of his term, continue to hold office until his successor enters
upon his office.
68. Time of holding election to fill vacancy in the office of Vice-President and
the term of office of person elected to fill casual vacancy
(1)An election to fill a vacancy caused by the expiration of the term of office of Vice-President shall
be completed before the expiration of the term.(2)An election to fill a vacancy in the office of
Vice-President occurring by reason of his death, resignation or removal, or otherwise shall be held
as soon as possible after the occurrence of the vacancy, and the person elected to fill the vacancy
shall, subject to the provisions of article 67, be entitled to hold office for the full term of five years
from the date on which he enters upon his office.
69. Oath or affirmation by the Vice-President
Every Vice-President shall, before entering upon his office, make and subscribe before the President,
or some person appointed in that behalf by him, an oath or affirmation in the following form, that is
to say"I, A.B., do swear in the name of God/solemnly affirm that I will bear true faith, and allegiance
to the Constitution of India as by law established and that I will faithfully discharge the duty upon
which I am about to enter."
70. Discharge of President's functions in other contingencies
Parliament may make such provision as it thinks fit for the discharge of the functions of the
President in any contingency not provided for in this Chapter.
71. Matters relating to, or connected with, the election of a President or
Vice-President
[Editorial comment-The Constitution (Thirty-Ninth Amendment) Act, 1975, was passed in
response to the Allahabad High Court’s decision invalidating PM Indira Gandhi’s election to the Lok
Sabha on Raj Narain’s petition. This exempted the president, vice president, prime minister, and
speaker from the jurisdiction of the courts. They are to be decided by whichever authority the
Parliament chooses. Amended articles 71, Important Verdict-State Of U.P vs Raj Narain & Ors Also
Refer ]SUBSEC (1)All doubts and disputes arising out of or in connection with the election of aConstitution of India

President or Vice-President shall be inquired into and decided by the Supreme Court whose decision
shall be final.SUBSEC (2)If the election of a person as President or Vice-President is declared void
by the Supreme Court, acts done by him in the exercise and performance of the powers and duties of
the office of President or Vice-President, as the case may be, on or before the date of the decision of
the Supreme Court shall not be invalidated by reason of that declaration.SUBSEC (3)Subject to the
provisions of this Constitution, Parliament may by law regulate any matter relating to or connected
with the election of a President or Vice-President.SUBSEC (4)The election of a person as President
or Vice-President shall not be called in question on the ground of the existence of any vacancy for
whatever reason among the members of the electoral college electing him.[Editorial comment-
The Constitution (Eleventh Amendment) Act, 1961, eliminates the prior need for members of both
Houses of Parliament to meet together to elect the vice president. Before this, members of both
Houses of Parliament were required to assemble to elect the Vice-President. This means that the
Vice-President can now be chosen by the members of this electoral college, and it is no longer
necessary for them to assemble in one place to carry out the election process. However, with this
change, a new electoral college was created, which comprises members from both Houses of
Parliament is a crucial step towards democratization and inclusivity in the Indian political system. It
adds a new clause (4) to Article 71 of the Constitution. By eliminating the requirement for members
of both Houses of Parliament to physically meet together to elect the Vice-President, the
amendment made the process more efficient and streamlined. Also refer ][Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
72. Power of President to grant pardons, etc., and to suspend, remit or
commute sentences in certain cases
(1)The President shall have the power to grant pardons, reprieves, respites or remissions of
punishment or to suspend, remit or commute the sentence of any person convicted of any
offence--(a)in all cases where the punishment or sentence is by a Court Martial;(b)in all cases where
the punishment or sentence is for an offence against any law relating to a matter to which the
executive power of the Union extends;(c)in all cases where the sentence is a sentence of
death.(2)Nothing in sub-clause (a) of clause (1) shall affect the power conferred by law on any officer
of the Armed forces of the Union to suspend, remit or commute a sentence by a court
martial.(3)Nothing in sub-clause (c) of clause (1) shall affect the power to suspend, remit or
commute a sentence of death exercisable by the Governor of a State under any law for the time being
in force.Constitution of India

73. Extent of executive power of the Union
(1)Subject to the provisions of this Constitution, the executive power of the Union shall
extend--(a)to the matters with respect to which Parliament has power to make laws; and(b)to the
exercise of such rights, authority and jurisdiction as are exercisable by the Government of India by
virtue of any treaty on agreement:Provided that the executive power referred to in sub-clause (a)
shall not, save as expressly provided in this Constitution or in any law made by Parliament, extend
in any State to matters with respect to which the Legislature of the State has also power to make
laws.(2)Until otherwise provided by Parliament, a State, and any officer or authority of a State may,
notwithstanding anything in this article, continue to exercise in matters with respect to which
Parliament has power to make laws for that State such executive power or functions as the State or
officer or authority thereof could exercise immediately before the commencement of this
Constitution.
74. Council of Ministers to aid and advise President
(1)There shall be a Council of Ministers with the Prime Minister at the head to aid and advise the
President who shall, in the exercise of his functions, act in accordance with such advice:Provided
that the President may require the Council of Ministers to reconsider such advice; either generally
or otherwise, and the President shall act in accordance with the advice tendered after such
reconsideration.(2)The question whether any, and if so what, advice was tendered by Ministers to
the President shall not be inquired into in any court.[Editorial comment-The Constitution
(Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has
been taken out of Part III and made a separate Article 300A in Chapter IV of Part XII. This
amendment may have taken away the scope of speedy remedy under Article 32 for the violation of
Right to Property because it is no more a Fundamental Right. Making it a legal right under the
Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism included in the
preamble and secondly, in doing so, it conformed to the doctrine of basic structure of the
Constitution. Also Refer]
75. Other provisions as to Ministers
(1)The Prime Minister shall be appointed by the President and the other Ministers shall be
appointed by the President on the advice of the Prime Minister.(1A)The total number of Ministers,
including the Prime Minister, in the Council of Ministers shall not exceed fifteen per cent. of the
total number of members of the House of the people.[Editorial comment-The Constitution
(Ninety-first Amendment) Act, 2003, aimed to reduce the number of members serving on the
Council of Ministers, prohibit traitors from holding public office and tighten the anti-betrayal
regulations that had been adopted by the fifty-second amendment. This Amendment added clause
1A in Article 164, which states “the total number of Ministers, including the Chief Minister, in the
Council of Ministers in a State shall not exceed 15% of the total number of members of the
Legislative Assembly of that State. It also mentioned that the number of Ministers, including the
Chief Minister in a State shall not be less than twelve”. Similarly, changes were made to article 75.
As mentioned in it, the PM shall be appointed by the president and the other Ministers shall beConstitution of India

appointed by the President on the advice of the PM. Lastly, The total number of ministers, including
the Prime Minister, in the COM shall not exceed 15% of the total strength of the Lok Sabha.Also
Refer)](1B)A member of either House of Parliament belonging to any political party who is
disqualified for being a member of that House under paragraph 2 of the tenth Schedule shall also be
disqualifies to be appointed as a Minister under Tenth Schedule shall also be disqualified to be
appointed as a Minister under clause (1) for duration of the period commencing from the date of his
disqualification till the date on which the term of his office as such member would expire or where
he contests any election to either House of Parliament before the expiry of such period, till the date
on which he is declared elected, whichever is earlier.(2)The Ministers shall hold office during the
pleasure of the President.(3)The Council of Ministers shall be collectively responsible to the House
of the People.(4)Before a Minister enters upon his office, the President shall administer to him the
oaths of office and of secrecy according to the forms set out for the purpose in the Third
Schedule.(5)A Minister who for any period of six consecutive months is not a member of either
House of Parliament shall at the expiration of that period cease to be a Minister.(6)The salaries and
allowances of Ministers shall be such as Parliament may from time to time by law determine and,
until Parliament so determines, shall be as specified in the Second Schedule.
76. Attorney-General for India
The Attorney-General for India(1)The President shall appoint a person who is qualified to be
appointed a Judge of the Supreme Court to be Attorney-General for India.(2)It shall be the duty of
the Attorney-General to give advice to the Government of India upon such legal matters, and to
perform such other duties of a legal character, as may from time to time be referred or assigned to
him by the President, and to discharge the functions conferred on him by or under this Constitution
or any other law for the time being in force.(3)In the performance of his duties the Attorney-General
shall have right of audience in all courts in the territory of India.(4)The Attorney-General shall hold
office during the pleasure of the President, and shall receive such remuneration as the President
may determine.
77. Conduct of business of the Government of India
(1)All executive actions of the Government of India shall be expressed to be taken in the name of the
President.(2)Orders and other instruments made and executed in the name of the President shall be
authenticated in such manner as may be specified in rules to be made by the President, arid the
validity of an order or instrument which is so authenticated shall not be called in question on the
ground that it is not an order or instrument made or executed by the President.(3)The President
shall make rules for the more convenient transaction of the business of the Government of India,
and for the allocation among Ministers of the said business.[clause (4) shall be omitted.][Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basicConstitution of India

structure of the Constitution. Also Refer]
78. Duties of Prime Minister as respects the furnishing of information to the
President, etc.
It shall be the duty of the Prime Minister--(a)to communicate to the President all decisions of the
Council of Ministers relating to the administration of the affairs of the Union and proposals for
legislation;(b)to furnish such information relating to the administration of the affairs of the Union
and proposals for legislation as the President may call for; and(c)if the President so requires, to
submit for the consideration of the Council of Ministers any matter on which a decision has been
taken by a Minister but which has not been considered by the Council.
79. Constitution of Parliament
There shall be a Parliament for the Union which shall consist of the President and two Houses to be
known respectively as the Council of States and the House of the People.
80. Composition of the Council of States
(1)The Council of States shall consist of-(a)twelve members to be nominated by the President in
accordance with the provisions of clause (3); and(b)not more than two hundred and thirty-eight
representatives of the States and of the Union territories.(2)The allocation of seats in the Council of
States to be filled by representatives of the States and of the Union territories shall be in accordance
with the provisions in that behalf contained in the Fourth Schedule.(3)The members to be
nominated by the President under sub-clause (a) of clause (1) shall consist of persons having special
knowledge or practical experience in respect of such matters as the following, namely:--Literature,
science, art and social service.(4)The representatives of each State in the Council of States shall be
elected by the elected members of the Legislative Assembly of the state in accordance with the
system of proportional representation by means of the single transferable vote.(5)The
representatives of the Union Territories in the Council of States shall be chosen in such manner as
Parliament may by law prescribe.
81. Composition of the House of the People
(1)Subject to the provisions of Article 331, the House of the People shall consist of-(a)not more than
five hundred and thirty members chosen by direct election from territorial constituencies in the
States, and(b)not more than twenty members to represent the Union territories, chosen in such
manner as Parliament may by law provide.(2)For the purposes of sub-clause (a) of clause
(1)--(a)there shall be allotted to each State a number of seats in the House of the People in such
manner that the ratio between that number and the population of the state is, so far as practicable,
the same for all States; and(b)each State shall be divided into territorial constituencies in such
manner that the ratio between the population of each constituency and number of seats allotted to it
is, so far as practicable, the same throughout the State:Provided that the provisions of sub-clause (a)Constitution of India

of this clause shall not be applicable for the purpose of allotment of seats in the House of the People
to any State so long as the population of that State does not exceed six millions.(3)In this article, the
expression "population" means the population as ascertained at the last preceding census of which
the relevant figures have been published:Provided that the reference in this clause to the last
preceding census of which the relevant figures have been published shall, until the relevant figures
for the first census taken after the year 2026 have been published,be construed-(i)for the purposes
of sub-clause (a) of clause (2) and the proviso to that clause, as a reference to the 1971 census;
and(ii)for the purposes of sub-clause (b) of clause (2) as a reference to the 2001 census.[Editorial
comment- The Constitution (Second Amendment) Act, 1952, it was suggested to merge and change
Clause 2 of 81 and 82. This was done to include requirements for Union Territories.Also
refer][Editorial comment-The Constitution (Seventh Amendment) Act, 1956, it t was suggested
to merge and change Clause 2 of 81 and 82. This was done to include requirements for Union
Territories. Also Refer ][Editorial comment- The Constitution (Fourteenth Amendment) Act,
1962, in article 81’s subclause (b) of clause (1) of the Indian Constitution, the greatest number of Lok
Sabha seats available for Union territory representatives must be raised from twenty to twenty-five
members. The Indian Constitution’s first schedule is modified to add the territories of “Pondicherry”
as the ninth Indian Union Territory as of August 16, 1962.Also refer ][Editorial comment-The
Constitution (Thirty-First Amendment) Act, 1973, primary objective was the Parliament seats and
thereby Articles 81, 330, and 332 were amended. The Amendment hailed as one of the more
impactful Amendments as it led to the number of representatives from both houses being equal.
That said, the number of representatives of either house, that is, the Lok Sabha or the Rajya Sabha is
not a fixed number. They may be increased or decreased if the situation requires. The government
has the authority to take a call on the same and make the necessary adjustments. Such changes are
usually brought about by the government when they believe that the inhabitants of a certain State
are not represented fairly at either of the houses. They are also instigated by a change in
demography.Also Refer][Editorial comment-The Constitution (Eighty-seventh Amendment) Act,
2003, amends the Delimitation Act, 2002, and is called the Delimitation (Amendment) Act of 2003.
Under this act, electoral constituencies, including the reserved seats for SCs and STs, may be
readjusted based on the 2001 population census without altering the number of seats reserved for
States in the legislative bodies. Also Refer]
82. Readjustment after each census
Upon the completion of each census, the allocation of seats in the House of the People to the States
and the division of each State into territorial constituencies shall be readjusted by such authority
and in such manner as Parliament may by law determine:Provided that such readjustment shall not
affect representation in the House of the People until the dissolution of the then existing
House:Provided further that such readjustment shall take effect from such date as President may, by
order, specify and until such readjustment takes effect, any election to the House may be held on the
basis of the territorial constituencies existing before such readjustment:Provided also that until the
relevant figures for the first census taken after the year 2026 have been published, it shall not be
necessary to readjust-(i)the allocation of seats in the House of the People to the States as readjusted
on the basis of the 1971 census; and(ii)the division of each State into territorial constituencies as
may be readjusted on the basis of the 2001 census, under this article.[Editorial comment-TheConstitution of India

Constitution (Seventh Amendment) Act, 1956, it was suggested to merge and change Clause 2 of 81
and 82. This was done to include requirements for Union Territories. Also Refer ]
83. Duration of Houses of Parliament
(1)The Council of States shall not be subject to dissolution, but as nearly as possible one-third of the
members thereof shall retire as soon as may be on the expiration of every second year in accordance
with the provisions made in that behalf by Parliament by law.(2)The House of the People, unless
sooner dissolved, shall continue for five years from the date appointed for its first meeting and no
longer and the expiration of the said period offive years shall operate as a dissolution of the
House:Provided that the said period may, while a Proclamation of Emergency is in operation, be
extended by Parliament by law for a period not exceeding one year at a time and not extending in
any case beyond a period of six months after the Proclamation has ceased to operate.[Editorial
comment-The Constitution (Forty-Second Amendment) Act, 1976, the amendment extended the
term of Lok Sabha and Legislative Assemblies members from five to six years, by amending
Clause(2) of Article 83 (for MPs). The Amendment repealed this change, shortening the term of the
aforementioned assemblies back to the original 5 years.Also Refer][Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
84. Qualification for membership of Parliament
A person shall not be qualified to be chosen to fill a seat in Parliament unless he--(a)is a citizen of
India, and makes and subscribes before some person authorised in that behalf by the Election
Commission an oath or affirmation according to the form set out for the purpose in the Third
Schedule;[Editorial comment-The Constitution (Sixteenth Amendment) Act, 1963, were
amended, to provide that every candidate for the membership of Parliament or state legislatures,
Union and state ministers, Judges of the supreme court and high courts, and the comptroller and
Auditor- General of India should swear an oath to uphold the sovereignty and integrity of India. The
forms of oath in the third schedule are amended.](b)is, in the case of a seat in the Council of States,
not less than thirty years of age and, in the case of a seat in the House of the People, not less than
twenty-five years of age; and(c)possesses such other qualifications as may be prescribed in that
behalf by or under any law made by Parliament.
85. Sessions of Parliament, prorogation and dissolution
(1)The President shall form lime to time summon each House of Parliament to meet at such time
and place as he thinks fit, but six months shall not intervene between its last sitting in one session
and the date appointed for its first sitting in the next session.(2)The President may from lime toConstitution of India

time--(a)prorogue the Houses or either House;(b)dissolve the House of the People.
86. Right of President to address and send messages to Houses
(1)The President may address either House of Parliament or both Houses assembled together, and
for that purpose require the attendance of members.(2)The President may send messages to either
House of Parliament, whether with respect to a Bill then pending in Parliament or otherwise, and a
House to which any message is so sent shall with all convenient dispatch consider any matter
required by the message to be taken into consideration.
87. Special address by the President
(1)At the commencement ofthe first session after each general election to the House of the People
and at the commencement of the first session of each year the President shall address both Houses
of Parliament assembled together and inform Parliament of the causes of its summons.(2)Provision
shall be made by rules regulating the procedure of either House for the allotment of time for
discussion of the matters referred to in such address.
88. Rights of Ministers and Attorney-General as respects Houses
Every Minister and the Attorney-General of India shall have the right to speak in, and otherwise to
take part in the proceedings of either House, any joint sitting of the Houses, and any committee of
Parliament of which he may be named a member, but shall not by virtue of this article be entitled to
vote.
89. The Chairman and Deputy Chairman of the Council of States
(1)The Vice-President of India shall be ex-officio Chairman of the Council of States.(2)The Council
of States shall, as soon as may be, choose a member of the Council to be Deputy Chairman thereof
and, so often as the office of Deputy Chairman becomes vacant, the Council shall choose
anothermember to be Deputy Chairman thereof.
90. Vacation and resignation of, and removal from, the office of Deputy
Chairman
A member holding office as Deputy Chairman of the Council of States--(a)shall vacate his office if he
ceases to be a member of the Council;(b)may at any time, by writing under his hand addressed to
the Chairman, resign his office; and(c)may be removed from his office by a resolution of the Council
passed by a majority of all the then members of the Council:Provided that no resolution for the
purpose of clause (c) shall be moved unless at least fourteen days' notice has been given of the
intention to move the resolution.Constitution of India

91. Power of the Deputy Chairman or other person to perform the duties of
the office of, or to act as, Chairman
(1)While the office of Chairman is vacant, or during any period when the Vice-President is acting as,
or discharging the functions of, President, the duties of the office shall be performed by the Deputy
Chairman, or, if the office of Deputy Chairman is also vacant, by such member of the Council of
States as the President may appoint for the purpose.(2)During the absence of the Chairman from
any sitting of the Council of States the Deputy Chairman, or, if he is also absent, such person as may
be determined by the rules of procedure of the Council, or, if no such person is present, such other
person as may be determined by the Council, shall act as Chairman.
92. The Chairman or the Deputy Chairman not to preside while a resolution
for his removal from office is under consideration
(1)At any sitting of the Council of States, while any resolution for the removal of the Vice-President
from his office is under consideration, the Chairman, or while any resolution for the removal of the
Deputy Chairman from his office is under consideration, the Deputy Chairman, shall not, though he
is present, preside, and the provisions of clause (2) of article 91 shall apply in relation to every such
sitting as they apply in relation to a sitting from which the Chairman, or, as the case may be, the
Deputy Chairman, is absent.(2)The Chairman shall have the right to speak in, and otherwise to take
part in the proceedings of, the Council of States while any resolution for the removal of the
Vice-President from his office is under consideration in the Council, but, notwithstanding anything
in article 100, shall not be entitled to vote at all on such resolution or on any other matter during
such proceedings.
93. The Speaker and Deputy Speaker of the House of the People
The House of the People shall, as soon as may be, choose two members of the House to be
respectively Speaker and Deputy Speaker thereof and, so often as the office of Speaker or Deputy
Speaker becomes vacant, the House shall choose another member to be Speaker or Deputy Speaker,
as the case may be.
94. Vacation and resignation of, and removal from, the offices of Speaker and
Deputy Speaker
A member holding office as Speaker or Deputy Speaker of the House of the People--(a)shall vacate
his office if he ceases to be a member of the House of the People;(b)may at any time, by writing
under his hand addressed, if such member is the Speaker, to the Deputy Speaker, and if such
member is the Deputy Speaker, to the Speaker, resign his office; and(c)may be removed from his
office by a resolution of the House of the People passed by a majority of all the then members of the
House:Provided that no resolution for the purpose of clause (c) shall be moved unless at least
fourteen days' notice has been given of the intention to move the resolution:Provided further that,
whenever the House of the People is dissolved, the Speaker shall not vacate his office untilConstitution of India

immediately before the first meeting of the House of the People after the dissolution.
95. Power of the Deputy Speaker or other person to perform the duties of the
office of, or to act as, Speaker
(1)While the office of Speaker is vacant; the duties of the office shall be performed by the Deputy
Speaker or, if the office of Deputy Speaker is also vacant, by such member of the House of the People
as the President may appoint for the purpose.(2)During the absence of the Speaker from any sitting
of the House of the People the Deputy Speaker or, if he is also absent, such person as may be
determined by the rules of procedure of the House, or, if no such person is present, such other
person as may be determined by the House, shall act as Speaker.
96. The Speaker or the Deputy Speaker not to preside while a resolution for
his removal from office is under consideration
(1)At any sitting of the House of the People, while any resolution for the removal of the Speaker
from his office is under consideration, the Speaker, or while any resolution for the removal of the
Deputy Speaker from his office is under consideration, the Deputy Speaker, shall not, though he is
present, preside, and the provisions of clause (2) of article 95 shall apply in relation to every such
sitting as they apply in relation to a sitting from which the Speaker, or, as the case may be, the
Deputy Speaker, is absent.(2)The Speaker shall have the right to speak in, and otherwise to take part
in the proceedings of, the House of the People while any resolution for his removal from office is
under consideration in the House and shall, notwithstanding anything in article 100, be entitled to
vote only in the first instance on such resolution or on any other matter during such proceedings but
not in the case of an equality of votes.
97. Salaries and allowances of the Chairman and Deputy Chairman and the
Speaker and Deputy Speaker
There shall be paid to the Chairman and the Deputy Chairman of the Council of States, and to the
Speaker and the Deputy Speaker of the House of the People, such salaries and allowances as may be
respectively fixed by Parliament by law and, until provision in that behalf is so made, such salaries
and allowances as are specified in the Second Schedule.
98. Secretariat of Parliament
(1)Each House of Parliament shall have a separate secretarial staff:Provided that nothing in this
clause shall be construed as preventing the creation of posts common to both Houses of
Parliament.(2)Parliament may by law regulate the recruitment, and the conditions of service of
persons appointed, to the secretarial staff of either House of Parliament.(3)Until provision is made
by Parliament under clause (2), the President may, after consultation with the Speaker of the House
of the People or the Chairman of the Council of States, as the case may be, make rules regulating the
recruitment, and the conditions of service of persons appointed, to the secretarial staff of the HouseConstitution of India

of the People or the Council of States, and any rules so made shall have effect subject to the
provisions of any law made under the said clause.
99. Oath or affirmation by members
Every member of either House of Parliament shall, before taking his seat, make and subscribe
before the President, or some person appointed in that behalf by him, an oath or affirmation
according to the form set out for the purpose in the Third Schedule.
100. Voting in Houses, power of Houses to act notwithstanding vacancies
and quorum
(1)Save as otherwise provided in this Constitution, all questions at any sitting of either House or
joint sitting of the Houses shall be determined by a majority of votes of the members present and
voting, other than the Speaker or person acting as Chairman or Speaker. The Chairman or Speaker,
or person acting as such, shall not vote in the first instance, but shall have and exercise a casting
vote in the case of an equality of votes.(2)Either House of Parliament shall have power to act
notwithstanding any vacancy in the membership thereof, and any proceedings in Parliament shall
be valid notwithstanding that it is discovered subsequently that some person who was not entitled
so to do sat or voted or otherwise took part in the proceedings.(3)Until Parliament by law otherwise
provides, the quorum to constitute a meeting of either House of Parliament shall be one-tenth of the
total number of members of the House.(4)If at any time during a meeting of a House there is no
quorum, it shall be the duty of the Chairman or Speaker, or person acting as such, either to adjourn
the House or to suspend the meeting until there is a quorum.
101. Vacation of seats
(1)No person shall be a member of both Houses of Parliament and provision shall be made by
Parliament by law for the vacation by a person who is chosen a member of both Houses of his scat in
one House or the other.(2)No person shall be a member both of Parliament and of a House of the
Legislature of a State and if a person is chosen a member both of Parliament and of a House of the
Legislature of a State, then, at the expiration of such period as may be specified in rulesmade by the
President, that person's seat in Parliament shall become vacant, unless he has previously resigned
his seat in the Legislature of the State(3)If a member of either House of Parliament--(a)becomes
subject to any of the disqualifications mentioned in clause (1) or clause (2) of article 102,
or(b)resigns his seat by writing under his hand addressed to the Chairman or the Speaker, as the
case may be, and his resignation is accepted by the Chairman or the Speaker, as the case may be,his
seat shall thereupon become vacant:Provided that in the case of any resignation referred to in
sub-clause (b), if from information received or otherwise and after making such inquiry as he thinks
fit, the Chairman or the Speaker, as the case may be, is satisfied that such resignation is not
voluntary or genuine, he shall not accept such resignation.(4)If for a period of sixty days a member
of either House of Parliament is without permission of the House absent from all meetings thereof,
the House may declare his seat vacant:Provided that in computing the said period of sixty days noConstitution of India

account shall be taken of any period during which the House is prorogued or is adjourned for more
than four consecutive days.[Editorial comment-The Constitution (Thirty-Third Amendment) Act,
1974, this amendment adds a proviso at the conclusion of article 101(3) and replaces the existing
subclause (b) with a new subclause. According to the new article 101(3)(b), a member of either
House of Parliament may resign from office by writing a letter in his own handwriting to the
Chairman or Speaker, as applicable, and if the letter is accepted by the Chairman or Speaker, as
applicable, the member’s seat would then become empty. In addition, if any of the aforementioned
resignations occur, the Chairman or Speaker, as the instance may be, will refuse to accept such
resignation if, after receiving information or otherwise, and following the investigation as he deems
appropriate, he is of the opinion that this resignation is not honest or voluntary.Also
Refer][Editorial comment-The Constitution (Fifty-Second Amendment) Act, 1985, introduced as
an anti-defection bill in the parliament to prohibit its members from hopping between different
political parties and inserted a new Schedule in the constitution i.e. the 10th schedule. It altered the
provisions of Articles 101, where it laid down the grounds of defection for members of either house
of Parliament or state assemblies or councils. It aims to prevent political defections for reasons of
office and other considerations from causing harm to democracy. Its proposed solution is to bar
Members of Parliament and State Legislatures who deviate from party politics from continuing to
hold their political office. This was not passed without a major change in the country’s political
landscape. Nevertheless, it is the highest-level document drafted by our democracy and has the
potential to make Indian politics more transparent. Aside from enhancing political freedoms, this
amendment also contains provisions to curb corruption. The constitution’s anti-defection provisions
were a result of a series of debates over the issue.Also Refer]
102. Disqualifications for membership
(1)A person shall be disqualified for being chosen as, and for being, a member of either House of
Parliament--(a)if he holds any office of profit under the Government of India or the Government of
any State, other than an office declared by Parliament by law not to disqualify its holder;(b)if he is of
unsound mind and stands so declared by a competent court;(c)if he is an undischarged
insolvent;(d)if he is not a citizen of India, or has voluntarily acquired the citizenship of a foreign
State, or is under any acknowledgement of allegiance or adherence to a foreign State;(e)if he is so
disqualified by or under any law made by Parliament.Explanation.-- For the purposes of this clause
a person shall not be deemed to hold an office of profit under the Government of India or the
Government of any State by reason only that he is a Minister either for the Union or for such
State.(2)A person shall be disqualified for being a member of either House of Parliament if he is so
disqualified under the Tenth Schedule.
103. Decision on questions as to disqualifications of members
(1)If any question arises as to whether a member of either House of Parliament has become subject
to any of the disqualifications mentioned in clause (1) of article 102, the question shall be referred
for the decision of the President and his decision shall be final.(2)Before giving any decision on any
such question, the President shall obtain the opinion of the Election Commission and shall act
according to such opinion.[Editorial comment-The Constitution (Forty-Fourth Amendment) Act,Constitution of India

1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and
made a separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the
scope of speedy remedy under Article 32 for the violation of Right to Property because it is no more
a Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
104. Penalty for sitting and voting before making oath or affirmation under
article 99 or when not qualified or when disqualified
If a person sits or votes as a member of either House of Parliament before he has complied with the
requirements of article 99, or when he knows that he is not qualified or that he is disqualified for
membership thereof, or that he is prohibited from so doing by the provisions of any law made by
Parliament, he shall be liable in respect of each day on which he so sits or votes to a penalty of five
hundred rupees to be recovered as a debt due to the Union.
105. Powers, privileges, etc., of the Houses of Parliament and of the members
and committees thereof
(1)Subject to the provisions of this Constitution and the rules and standing orders regulating the
procedure of Parliament, there shall be freedom of speech in Parliament.(2)No member of
Parliament shall be liable to any proceedings in any court in respect of anything said or any vote
given by him in Parliament or any committee thereof, and no person shall be so liable in respect of
the publication by or under the authority of either House of Parliament of any report, paper, votes or
proceedings.(3)In other respects, the powers, privileges and immunities of each House of
Parliament, and of the members and the committees of each House, shall be such as may from time
to time be defined by Parliament by law, and, until so defined,shall be those of that House and of its
members and committeesimmediately before the coming into force of section 15 of the Constitution
(Forty-fourth Amendment) Act 1978.(4)The provisions of clauses (1), (2) and (3) shall apply in
relation to persons who by virtue of this Constitution have the right to speak in, and otherwise to
take part in the proceedings of, a House of Parliament or any committee thereof as they apply in
relation to members of Parliament.[Editorial comment-The Constitution (Forty-Second
Amendment) Act, 1976, Article 105 was amended so as to grant each House of Parliament, its
members and committees the right to "evolve" their "powers, privileges and immunities", "from
time to time". Article 194 was amended to grant the same rights as Clause 21 to State Legislatures,
its members and committees.Also Refer][Editorial comment-The Constitution (Forty-Fourth
Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to Property
because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer]Constitution of India

106. Salaries and allowances of members
Members of either House of Parliament shall be entitled to receive such salaries and allowances as
may from time to time be determined by Parliament by law and, until provision in that respect is so
made, allowances at such rates and upon such conditions as were immediately before the
commencement of this Constitution applicable in the case of members of the Constituent Assembly
of the Dominion of India.
107. Provisions as to introduction and passing of Bills
(1)Subject to the provisions of articles 109 and 117 with respect to Money Bills and other financial
Bills, a Bill may originate in either House of Parliament.(2)Subject to the provisions of articles 108
and 109, a Bill shall not be deemed to have been passed by the Houses of Parliament unless it has
been agreed to by both Houses, either without amendment or with such amendments only as are
agreed by both Houses.(3)A Bill pending in Parliament shall not lapse by reason of the prorogation
of the Houses.(4)A Bill pending in the Council of States which has not been passed by the House of
the People shall not lapse on a dissolution of the House of the People.(5)A Bill which is pending in
the House of the People, or which having been passed by the House of the People is pending in the
Council of States, shall subject to the provisions of article 108, lapse on a dissolution of the House of
the People.
108. Joint sitting of both Houses in certain cases
(1)If after a Bill has been passed by one House and transmitted to the other House--(a)the Bill is
rejected by the other House; or(b)the Houses have finally disagreed as to the amendments to be
made in the Bill; or(c)more than six months elapse from the date of the reception of the Bill by the
other House without the Bill being passed by it.the President may, unless the Bill has lapsed by
reason of a dissolution of the House of the People, notify to me Houses by message if they are sitting
or by public notification if they are not sitting, his intention to summon them to meet in a joint
sitting for the purpose of deliberating and voting on the Bill:Provided that nothing in this clause
shall apply to a Money Bill.(2)In reckoning any such period of six months as is referred to in clause
(1), no account shall be taken of any period during which the House referred to in sub-clause (c) of
that clause is prorogued or adjourned for more than four consecutive days.(3)Where the President
has under clause (1) notified his intention of summoning the Houses to meet in a joint sitting,
neither House shall proceed further with the Bill, but the President may at any time after the date of
his notification summon the Houses to meet in a joint sitting for the purpose specified in the
notification and, if he does so, the Houses shall meet accordingly.(4)If at the joint sitting of the two
Houses the Bill, with such amendments, if any, as are agreed to in joint sitting, is passed by a
majority of the total number of members of both Houses present and voting, it shall be deemed for
the purposes of this Constitution to have been passed by both Houses:Provided that at a joint
sitting--(a)if the Bill, having been passed by one House, has not been passed by the other House
with amendments and returned to the House in which it originated, no amendment shall be
proposed to the Bill other than such amendments (if any) as are made necessary by the delay in the
passage of the Bill;(b)if the Bill has been so passed and returned, only such amendments asConstitution of India

aforesaid shall be proposed to the Bill and such other amendments as are relevant to the matters
with respect to which the Houses have not agreed;and the decision of the person presiding as to the
amendments which are admissible under this clause shall be final.(5)A joint sitting may be held
under this article and a Bill passed thereat, notwithstanding that a dissolution of the House of the
People has intervened since the President notified his intention to summon the Houses to meet
therein.
109. Special procedure in respect of Money Bills
(1)A Money Bill shall not be introduced in the Council of States.(2)After a Money Bill has been
passed by the House of the People it shall be transmitted to the Council of States for its
recommendations and the Council of States shall within a period of fourteen days from the date of
receipt of the Bill return the Bill to the House of the People with its recommendations and the House
of the People may thereupon either accept or reject all or any of the recommendations of the Council
of States.(3)If the House of the People accepts any of the recommendations of the Council of States,
the Money Bill shall be deemed to have been passed by both Houses with the amendments
recommended by the Council of States and accepted by the House of the People.(4)If the House of
the People does not accept any of the recommendations of the Council of States, the Money Bill shall
be deemed to have been passed by both Houses in the form in which it was passed by the House of
the People without any of the amendments recommended by the Council of States.(5)If a Money Bill
passed by the House of the People and transmitted to the Council of States for its recommendations
is not returned to the House of the People within the said period of fourteen days, it shall be deemed
to have been passed by both Houses at the expiration of the said period in the form in which it was
passed by the House of the People.
110. Definition of "Money Bills"
(1)For the purposes of this Chapter, a Bill shall be deemed to be a Money Bill if it contains only
provisions dealing with all or any of the following matters, namely:--(a)the imposition, abolition,
remission, alteration or regulation of any tax;(b)the regulation of the borrowing of money or the
giving of any guarantee by the Government of India, or the amendment of the law with respect to
any financial obligations undertaken or to be undertaken by the Government of India;(c)the custody
of the Consolidated Fund or the Contingency Fund of India, the payment of moneys into or the
withdrawal of moneys from any such Fund;(d)the appropriation of moneys out of the Consolidated
Fund of India;(e)the declaring of any expenditure to be expenditure charged on the Consolidated
Fund of India or the increasing of the amount of any such expenditure;(f)the receipt of money on
account of the Consolidated Fund of India or the public account of India or the custody or issue of
such money or the audit of the accounts of the Union or of a State; or(g)any matter incidental to any
of the matters specified in sub-clauses (a) to (f).(2)A Bill shall not be deemed to be a Money Bill by
reason only that it provides for the imposition of fines or other pecuniary penalties, or for the
demand or payment of fees for licences or fees for services rendered, or by reason that it provides for
the imposition, abolition, remission, alteration or regulation of any tax by any local authority or
body for local purposes.(3)If any question arises whether a Bill is a Money Bill or not, the decision of
the Speaker of the House of the People thereon shall be final.(4)There shall be endorsed on everyConstitution of India

Money Bill when it is transmit led to the Council of States under article 109, and when it is
presented to the President for assent under article 111, the certificate of the Speaker of the House of
the People signed by him that it is a Money Bill.
111. Assent to Bills
When a Bill has been passed by the Houses of Parliament, it shall be presented to the President and
the President shall declare either that he assents to the Bill, or that he withholds assent
therefrom:Provided that the President may, as soon as possible after the presentation to him of a
Bill for assent, return the Bill if it is not a Money Bill to the Houses with a message requesting that
they will reconsider the Bill or any specified provisions thereof and, in particular, will consider the
desirability of introducing any such amendments as he may recommend in his message, and when a
Bill is so returned, the Houses shall reconsider the Bill accordingly, and if the Bill is passed again by
the Houses with or without amendment and presented to the President for assent, the President
shall not withhold assent therefrom.
112. Annual financial statement
(1)The President shall in respect of every financial year cause to be laid before both the Houses of
Parliament a statement of the estimated receipts and expenditure of the Government of India for
that year, in this Part referred to as the "annual financial statement".(2)The estimates of
expenditure embodied in the annual financial statement shall show separately--(a)the sums
required to meet expenditure described by this Constitution as expenditure charged upon the
Consolidated Fund of India; and(b)the sums required to meet other expenditure proposed to be
made from the Consolidated Fund of India,and shall distinguish expenditure on revenue account
from other expenditure.(3)The following expenditure shall be expenditure charged on the
Consolidated Fund of India--(a)the emoluments and allowances of the President and other
expenditure relating to his office;(b)the salaries and allowances of the Chairman and the Deputy
Chairman of the Council of States and the Speaker and the Deputy Speaker of the House of the
People;(c)debt charges for which the Government of India is liable including interest, sinking fund
charges and redemption charges, and other expenditure relating to the raising of loans and the
service and redemption of debt;(d)(i)the salaries, allowances and pensions payable to or in respect
of Judges of the Supreme Court,(ii)the pensions payable to or in respect of Judges of the Federal
Court,(iii)the pensions payable to or in respect of Judges of any High Court which exercises
jurisdiction in relation to any area included in the territory of India or which at any time before the
commencement of this Constitution exercises jurisdiction in relation to any area included in a
Governor's Province of the Dominion of India;(e)the salary, allowances and pension payable to or in
respect of the Comptroller and Auditor- General of India;(f)any sums required to satisfy any
judgment, decree or award of any court or arbitral tribunal;(g)any other expenditure declared by
this Constitution or by Parliament by law to be so charged.Constitution of India

113. Procedure in Parliament with respect to estimates
(1)So much of the estimates as relates to expenditure charged upon the Consolidated Fund of India
shall not be submitted to the vote of Parliament, but nothing in this clause shall be construed as
preventing the discussion in either House of Parliament of any of those estimates.(2)So much of the
said estimates as relates to other expenditure shall be submitted in the form of demands for grants
to the House of the People, and the House of the People shall have power to assent, or to refuse to
assent, to any demand, or to assent to any demand subject to a reduction of the amount specified
therein.(3)No demand for a grant shall be made except on the recommendation of the President.
114. Appropriation Bills
(1)As soon as may be after the grants under article 113 have been made by the House of the People,
there shall be introduced a Bill to provide for the appropriation out of the Consolidated Fund of
India of all moneys required to meet--(a)the grants so made by the House of the People; and(b)the
expenditure charged on the Consolidated Fund of India but not exceeding in any case the amount
shown in the statement previously laid before Parliament.(2)No amendment shall be proposed to
any such Bill in either House of Parliament which will have the effect of varying the amount or
altering the destination of any grant so made or of varying the amount of any expenditure charged
on the Consolidated Fund of India, and the decision of the person presiding as to whether an
amendment is inadmissible under this clause shall be final.(3)Subject to the provisions of articles
115 and 116, no money shall be withdrawn from the Consolidated Fund of India except under
appropriation made by law passed in accordance with the provisions of this article.
115. Supplementary, additional or excess grants
(1)The President shall--(a)If the amount authorised by any law made in accordance with the
provisions of article 114 to be expended for a particular service for the current financial year is found
to be insufficient for the purposes of that year or when a need has arisen during the current financial
year for supplementary or additional expenditure upon some new service not contemplated in the
annual financial statement for that year, or(b)if any money has been spent on any service during a
financial year in excess of the amount granted for that service and for that year,cause to be laid
before both the Houses of Parliament another statement showing the estimated amount of that
expenditure or cause to be presented to the House of the People a demand for such excess, as the
case may be.(2)The provisions of articles 112, 113 and 114 shall have effect in relation to any such
statement and expenditure or demand and also to any law to be made authorising the appropriation
of moneys out of the Consolidated Fund of India to meet such expenditure or the grant in respect of
such demand as they have effect in relation to the annual financial statement and the expenditure
mentioned therein or to a demand for a grant and the law to be made for the authorisation of
appropriation of moneys out of the Consolidated Fund of India to meet such expenditure or grant.Constitution of India

116. Votes on account, votes of credit and exceptional grants
(1)Notwithstanding anything in the foregoing provisions of this Chapter, the House of the People
shall have power--(a)to make any grant in advance in respect of the estimated expenditure for a part
of any financial year pending the completion of the procedure prescribed in article 113 for the voting
of such grant and the passing of the law in accordance with the provisions of article 114 in relation to
that expenditure;(b)to make a grant for meeting an unexpected demand upon the resources of India
when on account of the magnitude or the indefinite character of the service the demand cannot be
stated with the details ordinarily given in an annual financial statement;(c)to make an exceptional
grant which forms no part of the current service of any financial year;and Parliament shall have
power to authorise by law the withdrawal of moneys from the Consolidated Fund of India for the
purposes for which the said grants are made.(2)The provisions of articles 113 and 114 shall have
effect in relation to the making of any grant under clause (1) and to any law to be made under that
clause as they have effect in relation to the making of a grant with regard to any expenditure
mentioned in the annual financial statement and the law to be made for the authorisation of
appropriation of moneys out of the Consolidated Fund of India to meet such expenditure.
117. Special provisions as to financial Bills
(1)A Bill or amendment making provision for any of the matters specified in sub-clauses (a) to (f) of
clause (1) of article 110 shall not be introduced or moved except on the recommendation of the
President and a Bill making such provision shall not be introduced in the Council of States:Provided
that no recommendation shall be required under this clause for the moving of an amendment
making provision for the reduction or abolition of any tax.(2)A Bill or amendment shall not be
deemed to make provision for any of the matters aforesaid by reason only that it provides for the
imposition of fines or other pecuniary penalties, or for the demand or payment of fees for licences or
fees for services rendered, or by reason that it provides for the imposition, abolition, remission,
alteration or regulation of any tax by any local authority or body for local purposes.(3)A Bill which, if
enacted and brought into operation, would involve expenditure from the Consolidated Fund of India
shall not be passed by either House of Parliament unless the President has recommended to that
House the consideration of the Bill.
118. Rules of procedure
(1)Each House of Parliament may make rules for regulations, subject to the provisions of this
Constitution, its procedure and the conduct of its business.(2)Until rules are made under clause (1),
the rules of procedure and standing orders in force immediately before the commencement of this
Constitution with respect to the Legislature of the Dominion of India shall have effect in relation to
Parliament subject to such modifications and adaptations as may be made therein by the Chairman
of the Council of States or the Speaker of the House of the People, as the case may be.(3)The
President, after consultation with the Chairman of the Council of States and the Speaker of the
House of the People, may make rules as to the procedure with respect to joint sittings of, and
communications between, the two Houses.(4)At a joint sitting of the two Houses the Speaker of the
House of the People, or in his absence such person as may be determined by rules of procedureConstitution of India

made under clause (3), shall preside.
119. Regulation by law of procedure in Parliament in relation to financial
business
Parliament may, for the purpose of the timely completion of financial business, regulate by law the
procedure of, and the conduct of business in, each House of Parliament in relation to any financial
matter or to any Bill for the appropriation of moneys out of the Consolidated Fund of India, and, if
and so far as any provision of any law so made is inconsistent with any rule made by a House of
Parliament under clause (1) of article 118 or with any rule or standing order having effect in relation
to Parliament under clause (2) of that article, such provision shall prevail.
120. Language to be used in Parliament
(1)Notwithstanding anything in Part XVII, but subject to the article 348, business in Parliament
shall be transacted in Hindi or in English:Provided that the Chairman of the Council of States or
Speaker of the House of the People, or person acting as such, as the case may be, may permit any
member who cannot adequately express himself in Hindi or in English to address the House in his
mother tongue.(2)Unless Parliament by law otherwise provides, this article shall, after the
expiration of a period of fifteen years from the commencement of this Constitution, have effect as if
the words "or in English" were omitted therefrom.
121. Restriction on discussion in Parliament
No discussions shall take place in Parliament with respect to the conduct of any Judge of the
Supreme Court or of a High Court in the discharge of his duties expect upon a motion for presenting
an address to the President praying for the removal of the Judge as hereinafter provided.
122. Courts not to inquire into proceedings of Parliament
(1)The validity of any proceedings in Parliament shall not be called in question on the ground of any
alleged irregularity of procedure.(2)No officer or member of Parliament in whom powers are vested
by or under this Constitution for regulating procedure or the conduct of business, or for maintaining
order, in Parliament shall be subject to the jurisdiction of any court in respect of the exercise by him
of those powers.
123. Power of President to promulgate Ordinances during recess of
Parliament
(1)If at any time, except when both Houses of Parliament are in session, the President is satisfied
that circumstances exist which render it necessary for him to take immediate action, he may
promulgate such Ordinance as the circumstances appear to him to require.(2)An Ordinance
promulgated under this article shall have the same force and effect as an Act of Parliament, butConstitution of India

every such Ordinance--(a)shall be laid before both Houses of Parliament and shall cease to operate
at the expiration of six weeks from the reassembly of Parliament, or, if before the expiration of that
period resolutions disapproving it are passed by both Houses, upon the passing of the second of
those resolutions; and(b)may be withdrawn at any time by the President.Explanation.--Where the
Houses of Parliament are summoned to reassemble on different dates, the period of six weeks shall
be reckoned from the later of those dates for the purposes of this clause.(3)If and so far as an
Ordinance under this article makes any provision which Parliament would not under this
Constitution be competent to enact, it shall be void.[Re-promulgation of Ordinances -Krishna
Kumar Singh v State of Bihar. A 7-judge Constitution bench has held that unfettered
re-promulgation of ordinances is not permissible by the Constitution. On 2nd January, 2017, a
seven-judge Constitution Bench of the Supreme Court held that re-promulgation of ordinances is a
fraud on the Constitution and a subversion of democratic legislative processes. The majority
Judgment, authored by Justice DY Chandrachud, held that the requirement of placing the ordinance
before the Legislature is mandatory; Justice Madan B Lokur observed that it is directory; Justice
Thakur, the Chief Justice of India as he was then, in his separate concurring opinion, preferred to
leave the ‘question of interpretation of Articles 123 (2) and 213(2) in so far as the obligation of the
Government to place the ordinance before the Parliament/legislature open. The Supreme Court of
India’s seven-judge Constitution Bench ruled that the “RE-PROMULGATION OF ORDINANCES”
must be taken to be a violation of our Indian Constitution as it undermines parliamentary legislative
procedures. This Bench furthermore ruled that: “The approval and gratification of the President of
India, under Article 123, and the Governor, under Article 213, when issuing an Ordinance is not
excluded from judicial process and legal challenge.”(https:indiankanoon.org/doc/107225908/,
https:blog.ipleaders.in
unconstitutionality-of-the-re-promulgation-of-ordinances-the-krishna-kumar-singh-conundrum/)][Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
124. Establishment and Constitution of Supreme Court
(1)There shall be a Supreme Court of India consisting of a Chief Justice of India and, until
Parliament by law prescribes a larger number, of not more than seven other Judges.(2)Every Judge
of the Supreme Court shall be appointed by the President by warrant under his hand and seal on the
recommendation of the National Judicial Appointments Commission referred to in article 124A and
shall hold office until he attains the age of sixty-five years:Provided that--(a)a Judge may, by writing
under his hand addressed to the President, resign his office(b)a Judge may be removed from his
office in the manner provided in clause (4).(2A)The age of a Judge of the Supreme Court shall be
determined by such authority and in such manner as Parliament may by law provide.[Editorial
comment-The Constitution (Fifteenth Amendment) Act, 1963, in Article 124, a new clause (2A)
was added. The age requirement for serving as a judge on the Supreme Court will be set by suchConstitution of India

power and in such way as Parliament may by legislation prescribe.](3)A person shall not be qualified
for appointment as a Judge of the Supreme Court unless he is a citizen of India and--(a)has been for
at least five years a Judge of a High Court or of two or more such Courts in succession; or(b)has
been for at least ten years an advocate of a High Court or of two or more such courts in succession;
or(c)is, in the opinion of the President, a distinguished jurist.Explanation I-- this clause "High
Court' means a High Court which exercises, or which at any lime before the commencement of this
Constitution exercised, jurisdiction in any part of the territory of India.Explanation II--In
computing for the purpose of this clause the period during which a person has been an advocate, any
period during which a person has held judicial office not inferior to that of a district Judge after he
became an advocate shall be included.(4)A Judge of the Supreme Court shall not be removed from
his office except by an order of the President passed after an address by each House of Parliament
supported by a majority of the total membership of that House and by a majority of not less than
two-third of the members of the House present and voting has been presented to the President in
the same session for such removal on the ground of proved misbehavior or incapacity.(5)Parliament
may by law regulate the procedure for the presentation of an address and for the investigation and
proof of the misbehavior or incapacity of a Judge under clause (4):(6)Every person appointed to be a
Judge of the Supreme Court shall, before he enters upon his office, make and subscribe before the
President, or some person appointed in that behalf by him, an oath or affirmation according to the
form set out for the purpose in the Third Schedule.(7)No person who has held office as a Judge of
the Supreme Court shall plead or act in any court or before any authority within the territory of
India.
124A. National Judicial Appointments Commission
(1)There shall be a Commission to be known as the National Judicial Appointments Commission
consisting of the following, namely:--(a)the Chief Justice of India, Chairperson, ex officio;(b)two
other senior Judges of the Supreme Court next to the Chief Justice of India.-Members, ex
officio;(c)the Union Minister in charge of Law and Justice--Member, ex officio;(d)two eminent
persons to be nominated by the committee consisting of the Prime Minister, the Chief Justice of
India and the Leader of Opposition in the House of the People or where there is no such Leader of
Opposition, then, the Leader of single largest Opposition Party in the House of the People.-
Members:Provided that one of the eminent person shall be nominated from amongst the persons
belonging to the Scheduled Castes, the Scheduled Tribes, Other Backward Classes, Minorities or
Women:Provided further that an eminent person shall be nominated for a period of three years and
shall not be eligible for renomination.(2)No act or proceedings of the National Judicial
Appointments Commission shall be questioned or be invalidated merely on the ground of the
existence of any vacancy or defect in the constitution of the Commission.
124B. Functions of Commission
It shall be the duty of the National Judicial Appointments Commission to-(a)recommend persons
for appointment as Chief Justice of India, Judges of the Supreme Court, Chief Justices of High
Courts and other Judges of High Courts;(b)recommend transfer of Chief Justices and other Judges
of High Courts from one High Court to any other High Court; and(c)ensure that the personConstitution of India

recommended is of ability and integrity.
124C. Power of Parliament to make law
Parliament may, by law, regulate the procedure for the appointment of Chief Justice of India and
other Judges of the Supreme Court and Chief Justices and other Judges of High Courts and
empower the Commission to lay down by regulations the procedure for the discharge of its
functions, the manner of selection of persons for appointment and such other matters as may be
considered necessary by it.[Editorial comment-The Constitution (Ninety-ninth Amendment) Act,
2012, specifies the ability of Parliament to enact laws. The Chief Justice of India, along with the
other Supreme Court and High Court justices, may be recommended by regulation that is to be
managed by the Indian Parliament. The committee may propose any rules and processes necessary
for this
arrangement.{>https://en.wikipedia.org/wiki/Ninety-ninth_Amendment_of_the_Constitution_of_India
Also Refer]}}
125. Salaries, etc., of Judges
(1)There shall be paid to the Judges of the Supreme Court such salaries as may be determined by
Parliament by law and, until provision in that behalf is so made, such salaries as are specified in the
Second Schedule.(2)Every Judge shall be entitled to such privileges and allowances and to such
rights in respect of leave of absence and pension as may from time to time be determined by or
under law made by Parliament and, until so determined, to such privileges, allowances and rights as
are specified in the Second Schedule:Provided that neither the privileges nor the allowances of a
Judge nor his rights in respect of leave of absence or pension shall be varied to his disadvantage
after his appointment.[Editorial comment-The Constitution (Fifty-Fourth Amendment) Act,
1986, was made to increase the salary of the respected Chief Justice of India and other Judges and
to determine future increases without the need for a constitutional amendment. Articles 221 and 125
within the Constitution have been amended with adequate provisions to provide that the Judges of
the top court, i.e. the Supreme Court and the High Court shall be paid such salaries as decided by
Parliament by law. This amendment substituted Clause (1) of Article 125 and Clause (1) of Article
221 to enable the determination of judges’ salaries by Parliament by law.Also Refer]
126. Appointment of acting Chief Justice
When the office of Chief Justice of India is vacant or when the Chief Justice is, by reason of absence
or otherwise, unable to perform the duties of his office, the duties of the office shall be performed by
such one of the other Judges of the Court as the President may appoint for the purpose.
127. Appointment of ad hoc Judges
(1)If at any time there should not be a quorum of the Judges of the Supreme Court available to hold
or continue any session of the Court, the National Judicial Appointments Commission on aConstitution of India

reference made to it by the Chief Justice of India, may with the previous consent of the President
and after consultation with the Chief Justice of the High Court concerned, request in writing the
attendance at the sittings of the Court, as an ad hoc Judge, for such period as may be necessary, of a
Judge of a High Court duly qualified for appointment as a Judge of the Supreme Court to be
designated by the Chief Justice of India.(2)It shall be the duty of the Judge who has been so
designated, in priority to other duties of his office, to attend the sittings of the Supreme Court at the
time and for the period for which his attendance is required, and while so attending he shall have all
the jurisdiction, powers and privileges, and shall discharge the duties, of a Judge of the Supreme
Court.[Editorial comment-The Constitution (Ninety-ninth Amendment) Act, 2012, the term “the
National Judicial Appointments Commission on a recommendation made to it by the Chief Justice
of India” shall be used instead of the phrase “the Chief Justice of India.”Also Refer]
128. Attendance of retired Judges at sittings of the Supreme Court
Not withstanding anything in this Chapter, the Chief Justice of India may at any time, with the
previous consent of the President, request any person who has held the office of a Judge of the
Supreme Court or of the Federal Court or who has held the office of a Judge of a High Court and is
duly qualified for appointment as a Judge of the Supreme Court to sit and act as a Judge of the
Supreme Court, and every such person so requested shall, while so sitting and acting, been titled to
such allowances as the President may by order determine and have all the jurisdiction, powers and
privileges of, but shall not otherwise be deemed to be, a Judge of that Court:Provided that nothing in
this article shall be deemed to require any such person as aforesaid to sit and act as a Judge of that
Court unless he consents so to do.[Editorial comment-The Constitution (Fifteenth Amendment)
Act, 1963, a revised version of Article 128 allows for the appointment of a retired judge from a High
Court to serve as a judge of the Supreme Court.]
129. Supreme Court to be a court of record
The Supreme Court shall be a court of record and shall have all the powers of such a court including
the power to punish for contempt of itself.
130. Seat of Supreme Court
The Supreme Court shall sit in Delhi or in such other place or places, as the Chief Justice of India
may, with the approval of the President, from time to time, appoint.
131. Original jurisdiction of the Supreme Court
Subject to the provisions of this Constitution, the Supreme Court shall, to the exclusion of any other
court, have original jurisdiction in any dispute--(a)Between the Government of India and one or
more Slates;(b)between the Government of India and any State or States on one side and one or
more other States on the other; or(c)between two or more States, if and in so far as the dispute
involves any question (whether of law or fact) on which the existence or extent of a legal rightConstitution of India

depends:Provided that the said jurisdiction shall not extend to a dispute arising out of any treaty,
agreement, covenant, engagement, named or other similar instrument which, having been entered
into or executed before the commencement of this Constitution, continues in operation after such
commencement, or which provides that the said jurisdiction shall not extend to such a
dispute.[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, it was
substituted due to the absence of Part B states the clause in this article needs to be amended. It
discusses the Supreme Court’s original jurisdiction. The jurisdiction of the Supreme Court needs to
be revised because the Part B states have changed. Also Refer ]
131A. Exclusive jurisdiction of the Supreme Court in regard to questions as
to constitutional validity of Central Laws [Repealed]
Every High Court, passing or making a judgment, decree, final order, or sentence, referred to in
clause (1) of article 132 or clause (1) of article 133, or clause (1) of article 134,—(a)may, if it deems fit
so to do, on its own motion; and(b)shall, if an oral application is made, by or on behalf of the party
aggrieved, immediately after the passing or making of such judgment, decree, final order or
sentence, determine, as soon as may be after such passing or making, the question whether a
certificate of the nature referred to in clause (1) of article 132, or clause (1) of article 133 or, as the
case may be, sub-clause (c) of clause (1) of article 134, may be given in respect of that case.[Article
131A of the Constitution shall be omitted.][Notwithstanding anything contained in sub-section (1),
where immediately before the commencement of this Act any reference made by a High Court under
the said article 131A is pending before the Supreme Court, the Supreme Court may, having regard
to-(a)the stage at which the reference is so pending; and(b)the ends of justice, either deal with the
case as if that article had not been omitted or return the case of the High Court for disposal as if that
article had been omitted with effect on and from the 1st day of February, 1977.][Rep. by the
Constitution (Forty-third Amendment Act, 1977, section 4 (w.e.f. 13.4.1978][Editorial
comment-The Constitution (Forty-Third Amendment) Act, 1977, Section 4 omits article 131(A)
relating to the exclusive jurisdiction of the Supreme Court in regard to questions as to the
constitutional validity of Central laws.Also Refer]
132. Appellate jurisdiction of Supreme Court in appeals from High Courts in
certain cases
(1)An appeal shall lie to the Supreme Court from any judgment, decree or final order of a High Court
in the territory of India, whether in a civil, criminal or other proceeding, if the High Court certifies
under article 134A that the case involves a substantial question of law as to the interpretation of this
Constitution.(3)Where such a certificate is given, any party in the case may appeal to the Supreme
Court on the ground that any such question as aforesaid has been wrongly decided
.Explanation--For the purposes of this article, the expression "final order" includes an order
deciding an issue which, if decided in favour of the appellant, would be sufficient for the final
disposal of the case.[Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978,
repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a
separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope ofConstitution of India

speedy remedy under Article 32 for the violation of Right to Property because it is no more a
Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
133. Appellate jurisdiction of Supreme Court in appeals from High Courts in
regard to civil matters
(1)An appeal shall lie to the Supreme Court from any judgment, decree or final order in a civil
proceeding of a High Court in the territory of India if the High Court certifies under article
134A-(a)that the case involves a substantial question of law of general importance; and(b)that in the
opinion of the High Court the said question needs to be decided by the Supreme
Court.(2)Notwithstanding anything in article 132, any party appealing to the Supreme Court under
clause (1) may urge as one of the grounds in such appeal that a substantial question of law as to the
interpretation of this Constitution has been wrongly decided.(3)Notwithstanding anything in this
article, no appeal shall, unless Parliament by law otherwise provides, lie to the Supreme Court from
the judgment, decree or final order of one Judge of a High Court.[Editorial comment-The
Constitution (Thirtieth Amendment) Act, 1972, changed the basis for appeals in civil cases before
the Supreme Court of India from a value criterion to one based on important legal issues. It came
into effect on June 9, 1972. This amendment modified Article 133 of the Constitution and enabled
the Law Commission of India to implement the suggestions provided in its 44th and 45th reports on
civil appeals to the Supreme Court regarding certificates of fitness. The purpose of this amendment
is to require appeals of civil matters to the Supreme Court to raise a substantial question of law in
order to be deemed fit for consideration. This change was based on the Law Commission's
recommendations and aims to streamline the process for hearing civil appeals in the Supreme
Court.Also
Refer](https://blog.examarly.com/upsc/30th-amendment-of-indian-constitution/)][Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
134. Appellate jurisdiction of Supreme Court in regard to criminal matters
(1)An appeal shall lie to the Supreme Court from any judgment, final order or sentence in a criminal
proceeding of a High Court in the territory of India if the High Court-(a)has on appeal reversed an
order of acquittal of an accused person and sentenced him to death; or(b)has withdrawn for trial
before itself any case from any court subordinate to its authority and has in such trial convicted the
accused person and sentenced him to death; or(c)certifies under article 134A that the case is a fit
one for appeal to the Supreme Court:Provided that an appeal under sub-clause (c) shall lie subject to
such provisions as may be made in that behalf under clause (1) of article 145 and to such conditionsConstitution of India

as the High Court may establish or require.(2)Parliament may by law confer on the Supreme Court
any further powers to entertain and hear appeals from any judgment, final order or sentence in a
criminal proceeding of a High Court in the territory of India subject to such conditions and
limitations as may be specified in such law.[Editorial comment-The Constitution (Forty-Fourth
Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to Property
because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer]
134A. Certificate for appeal to the Supreme Court
Every High Court, passing or making a judgment, decree, final order, or sentence, referred to in
clause (1) of article 132 or clause (1) of article 133, or clause (1) of article 134-(a)may, if it deems fit
so to do, on its own motion; and(b)shall, if an oral application is made, by or on behalf of the party
aggrieved, immediately after the passing or making of such judgment, decree, final order or
sentence, determine, as soon as may be after such passing or making, the question whether a
certificate of the nature referred to in clause (1) of article 132, or clause (1) of article 133 or, as the
case may be, sub-clause (c) of clause (1) of article 134, may be given in respect of that
case[Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article
19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a separate Article
300A in Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy
under Article 32 for the violation of Right to Property because it is no more a Fundamental Right.
Making it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the
value of socialism included in the preamble and secondly, in doing so, it conformed to the doctrine
of basic structure of the Constitution. Also Refer]
135. Jurisdiction and powers of the Federal Court under existing law to be
exercisable by the Supreme Court
Until Parliament by law otherwise provides, the Supreme Court shall also have jurisdiction and
powers with respect to any matter to which the provisions of article 133 or article 134 do not apply if
jurisdiction and powers in relation to that matter were exercisable by the Federal Court immediately
before the commencement of this Constitution under any existing law.
136. Special leave to appeal by the Supreme Court
(1)Not with standing anything in this Chapter, the Supreme Court may, in its discretion, grant
special leave to appeal from any judgment, decree, determination, sentence or order in any cause or
matter passed or made by any court or tribunal in the territory of India.(2)Nothing in clause (1) shall
apply to any judgment, determination, sentence or order passed or made by any court or tribunal
constituted by or under any law relating to the Armed Forces.Constitution of India

137. Review of judgments or orders by the Supreme Court
Subject to the provisions of any law made by Parliament or any rules made under article 145, the
Supreme Court shall have power to review any judgment pronounced or order made by it.
138. Enlargement of the jurisdiction of the Supreme Court
(1)The Supreme Court shall have such further jurisdiction and powers with respect to any of the
matters in the Union List as Parliament may by law confer.(2)The Supreme Court shall have such
further jurisdiction, and powers with respect to any matter as the Government of India and the
Government of any State may by special agreement confer, if Parliament by law provides for the
exercise of such jurisdiction and powers by the Supreme Court.
139. Conferment on the Supreme Court of powers to issue certain writs
Parliament may by law confer on the Supreme Court power to issue directions, orders or writs,
including writs in the nature of habeas corpus, mandamus, prohibition, quo warrant to and
certiorari, or any of them, for any purposes other than those mentioned in clause (2) of article 32.
139A. Transfer of certain cases
(1)Where cases involving the same or substantially the same questions of law are pending before the
Supreme Court and one or more High Courts or before two or more High Courts and the Supreme
Court is satisfied on its own motion or an application made by the Attorney-General of India or by a
party to any such case that such questions are substantial questions of general importance, the
Supreme Court may withdraw the case or cases pending before the High Court or the High Courts
and dispose of all the cases itself:Provided that the Supreme Court may after determining the said
questions of law return any case so withdrawn together with a copy of its judgment on such
questions to the High Court from which the case has been withdrawn, and the High Court shall on
receipt thereof, proceed to dispose of the case in conformity with such judgment.(2)The Supreme
Court may, if it deems it expedient so to do for the ends of justice, transfer any case, appeal or other
proceedings pending before any High Court to any other High Court.[Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]Constitution of India

140. Ancillary powers of Supreme Court
Parliament may by law make provision for conferring upon the Supreme Court such supplemental
powers not inconsistent with any of the provisions of this Constitution as may appear to be
necessary or desirable for the purpose of enabling the court more effectively to exercise the
jurisdiction conferred upon it by or under this Constitution.
141. Law declared by Supreme Court to be binding on all courts
The law declared by the Supreme Court shall be binding on all courts within the territory of India.
142. Enforcement of decrees and orders of Supreme Court and orders as to
discovery, etc
(1)The Supreme Court in the exercise of its jurisdiction may pass such decree or make such order as
is necessary for doing complete justice in any cause or matter pending before it, and any decree so
passed or order so made shall be enforceable throughout the territory of India in such manner as
may be prescribed by or under any law made by Parliament and, until provision in that behalf is so
made, in such manner as the President may by order prescribe.(2)Subject to the provisions of any
law made in this behalf by Parliament, the Supreme Court shall, as respects the whole of the
territory of India, have all and every power to make any order for the purpose of securing the
attendance of any person, the discovery or production of any documents, or the investigation or
punishment of any contempt of itself.
143. Power of President to consult Supreme Court
(1)If at any time it appears to the President that a question of law or fact has arisen, or is likely to
arise, which is of such a nature and of such public importance that it is expedient to obtain the
opinion of the Supreme Court upon it, he may refer the question to that Court for consideration and
the Court may, after such hearing as it thinks fit, report to the President its opinion thereon.(2)The
President may, notwithstanding anything in the proviso to article 131, refer a dispute of the kind
mentioned in the said proviso to the Supreme Court for opinion and the Supreme Court shall, after
such hearing as it thinks fit, report to the President its opinion thereon.
144. Civil and judicial authorities to act in aid of the Supreme Court
All authorities, civil and judicial, in the territory of India shall act in aid of the Supreme Court.
144A. Special provisions as to disposal of questions relating to
constitutional validity of laws [Repealed]
Notwithstanding anything contained in this Constitution, the provisions of the Constitution
(Twenty-fifth Amendment) Act, 1971, shall remain in force until the expiration of a period of sixConstitution of India

months after the 1st day of March, 1977.[Rep. by the Constitution (Forty-third Amendment) Act,
1977, section 5 (w.e.f. 13.4.1978).][Editorial comment-The Constitution (Forty-Third
Amendment) Act, 1977, A Central or State law could only be declared unconstitutional by the
Supreme Court under Article 144(A) with a bench of at least 7 justices. Moreover, a two-thirds
special majority of the bench is required.Also Refer]
145. Rules of court, etc.
(1)Subject to the provisions of any law made by Parliament, the Supreme Court may from lime to
time, with the approval of the President, make rules for regulating generally the practice and
procedure of the Court including--(a)rules as to the persons practising before the Court,(b)rules as
to the procedure for hearing appeals and other matters pertaining to appeals including the time
within which appeals to the Court are to be entered;(c)rules as to the proceedings in the Court for
the enforcement of any of the rights conferred by Part III;(cc)rules as to the proceedings in the
Court under article 139A;(d)rules as to the entertainment of appeals under sub-clause (c) of clause
(1) of article 134;(e)any judgment pronounced or order made by the Court may be received and rules
as to the conditions the procedure for such review including the time within which applications to
the Court for such review are to be entered;(f)rules as to the costs of and incidental to any
proceedings in the Court and as to the fees to be charged in respect of proceedings therein;(g)rules
as to the granting of bail;(h)rules as to stay of proceedings;(i)rules providing for the summary
determination of any appeal which appears to the Court to be frivolous or vexatious or brought for
the purpose of delay;(j)rules as to the procedure for inquiries referred to in clause (1) of article
317.(2)Subject to the provisions of clause (3), rules made under this article may fix the minimum
number of Judges who are to sit for any purpose, and may provide for the powers of single Judges
and Division Courts.(3)The minimum number of Judges who are to sit for the purpose of deciding
any case involving a substantial question of law as to the interpretation of this Constitution or for
the purpose of hearing any reference under article 143 shall be five:Provided that, where the Court
hearing an appeal under any of the provisions of this Chapter other than article 132 consists of less
than five Judges and in the course of the hearing of the appeal the Court is satisfied that the appeal
involves a substantial question of law as to the interpretation of this Constitution the determination
of which is necessary for the disposal of the appeal, such Court shall refer the question for opinion to
a Court constituted as required by this clause for the purpose of deciding any case involving such a
question and shall on receipt of the opinion dispose of the appeal in conformity with such
opinion.(4)No judgment shall be delivered by the Supreme Court save in open Court, and no report
shall be made under article 143 save in accordance with an opinion also delivered in open
Court.(5)No judgment and no such opinion shall be delivered by the Supreme Court save with the
concurrence of a majority of the Judges present at the hearing of the case, but nothing in this clause
shall be deemed to prevent a Judge who docs not concur from delivering a dissenting judgment or
opinion.[Editorial comment-The Constitution (Forty-Third Amendment) Act, 1977,According to
the Constitution’s article 145, The phrase “article 139(A)” shall be substituted for the words, figures,
and letters “articles 131(A) and 139(A)” in Sub-Clause (cc) of Clause (1); The words, figures, and
letter “article 144(A) and of” shall be deleted from clause (2); In clause (a), the phrases, numbers,
and letter “Subject to the limits of Article 144(A)” must be removed from Clause(3). Also Refer]Constitution of India

146. Officers and servants and the expenses of the Supreme Court
(1)Appointments of officers and servants of the Supreme Court shall be made by the Chief Justice of
India or such other Judge or officer of the court as he may direct:Provided that the President may by
rule require that in such cases as may be specified in the rule, no person not already attached to the
Court shall be appointed to any office connected with the Court, save after consultation with the
Union Public Service Commission.(2)Subject to the provisions of any law made by Parliament, the
conditions of service of officers and servants of the Supreme Court shall be such as may be
prescribed by rules made by the Chief Justice of India or by some other Judge or officer of the Court
authorised by the Chief Justice of India to make rules for the purpose:Provided that the rules made
under this clause shall, so far as they relate to salaries, allowances, leave or pensions, require the
approval of the President.(3)The administrative expenses of the Supreme Court, including all
salaries, allowances and pensions payable to or in respect of the offices and servants of the Court,
shall be charged upon the Consolidated Fund of India, and any fees or other moneys taken by the
Court shall form part of that Fund.
147. Interpretation
In this Chapter and in Chapter V of Part VI references to any substantial question of law as to the
interpretation of this Constitution shall be construed as including references to any substantial
question of law as to the interpretation of the Government of India Act, 1935 (including any
enactment amending or supplementing that Act), or of any order in Council or order made there
under, or of the Indian Independence Act, 1947, or of any order made there under.
148. Comptroller and Auditor-General of India
(1)There shall be a Comptroller and Auditor-General of India who shall be appointed by the
President by warrant under his hand and seal and shall only be removed from office in like manner
and on the like grounds as a Judge of the Supreme Court.(2)Every person appointed to be the
Comptroller and Auditor-General of India shall, before he enters upon his office, make and
subscribe before the President, or some person appointed in that behalf by him, an oath or
affirmation according to the form set out for the purpose in the Third Schedule.(3)The salary and
other conditions of service of the Comptroller and Auditor-General shall be such as may be
determined by Parliament by law and, until they are so determined, shall be as specified in the
Second Schedule:Provided that neither the salary of a Comptroller and Auditor-General nor his
rights in respect of leave of absence, pension or age of retirement shall be varied to his disadvantage
after his appointment.(4)The Comptroller and Auditor-General shall not be eligible for further office
either under the Government of India or under the Government of any State after he has ceased to
hold his office.(5)Subject to the provisions of this Constitution and of any law made by Parliament,
the conditions of service of persons serving in the Indian Audit and Accounts Department and the
administrative powers of the Comptroller and Auditor-General shall be such as may be prescribed
by rules made by the President after consultation with the Comptroller and Auditor-General.(6)The
Administrative expenses of the office of the Comptroller and Auditor-General, including all salaries,
allowances and pensions payable to or in respect of persons serving in that office, shall be chargedConstitution of India

upon the Consolidated Fund of India.
149. Duties and powers of the Comptroller and Auditor-General
The Comptroller and Auditor-General shall perform such duties and exercise such powers in
relation to the" accounts of the Union and of the States and of any other authority or body as may be
prescribed by or under any law made by Parliament and, until provision in mat behalf is so made,
shall perform such duties and exercise such powers in relation to the accounts of the Union and of
the States as were conferred on or exercisable by the Auditor-General of India immediately before
the commencement of this Constitution in relation to the accounts of the Dominion of India and of
the Provinces respectively.
150. Form of accounts of the Union and of the States
The accounts of the Union and of the States shall be kept in such form as the President may, on the
advice of the Comptroller and Auditor-General of India, prescribe.[Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
151. Audit reports
(1)The reports of the Comptroller and Auditor-General of India relating to the accounts of the Union
shall be submitted to the President, who shall cause them to be laid before each House of
Parliament.(2)The reports of the Comptroller and Auditor-General of India relating to the accounts
of a State shall be submitted to the Governor of the State, who shall cause them to be laid before the
Legislature of the State.
Part VI – The States
152. Definition
In this Part, unless the context otherwise requires, the expression "State"does not include the state
of Jammu and Kashmir.
153. Governors of States
There shall be a Governor for each State:Provided that nothing in this article shall prevent the
appointment of the same person as Governor for two or more States.[Editorial comment-TheConstitution of India

Constitution (Seventh Amendment) Act, 1956, it amended Article 153 where the selection of a
governor for each state turned into a problem with inefficiency. It was discovered that a governor
could oversee two or more states, doing away with the need to appoint governors for each state and
territory. The President was unable to proceed because of the article’s provision, thus, a
constitutional revision was required. This was changed to permit the allocation of more than one
state to a governor as needed. Also Refer ]
154. Executive power of State
(1)The executive power of the State shall be vested in the Governor and shall be exercised by him
either directly or through officers subordinate to him in accordance with this
Constitution.(2)Nothing in this article shall--(a)be deemed to transfer to the Governor any functions
conferred by any existing law on any other authority; or(b)prevent Parliament or the Legislature of
the State from conferring by law functions on any authority subordinate to the Governor.
155. Appointment of Governor
The Governor of a State shall be appointed by the President by warrant under his hand and seal.
156. Term of office of Governor
(1)The Governor shall hold office during the pleasure of the President.(2)The Governor may, by
writing under his hand addressed to the President, resign his office.(3)Subject to the foregoing
provisions of this article, a Governor shall hold for a term of five years from the date on which he
enters upon his office:Provided that a Governor shall, notwithstanding the expiration of his term,
continue to hold office until his successor enters upon his office.
157. Qualifications for appointment as Governor
No person shall be eligible for appointment as Governor unless he is a citizen of India and has
completed the age of thirty-five years.
158. Conditions of Governor's office
(1)The Governor shall not be a member of either House of Parliament or of a House of the
Legislature of any State specified in the First Schedule, and if a member of either House of
Parliament or of a House of the Legislature of any such State be appointed Governor, he shall be
deemed to have vacated his seat in that House on the date on which he enters upon his office as
Governor.(2)The Governor shall not hold any other office of profit.(3)The Governor shall be entitled
without payment of rent to the use of his official residences and shall be also entitled to such
emoluments, allowances and privileges as may be determined by Parliament by law and, until
provision in that behalf is so made, such emoluments, allowances and privileges as are specified in
the Second Schedule.(3A)Where the same person is appointed as Governor of two or more States,Constitution of India

the emoluments and allowances payable to the Governor shall be allocated among the States in such
proportion as the President may by order determine.(4)The emoluments and allowances of the
Governor shall not be diminished during his term of office.
159. Oath or affirmation by the Governor
Every Governor and every person discharging the functions of the Governor shall, before entering
upon his office, make and subscribe in the presence of the Chief Justice of the High Court exercising
jurisdiction in relation to the State, or, in his absence, the senior most Judge of that court available,
an oath or affirmation in the following form, that is to say--"I, A.B., do swear in the name of God /
solemnly affirm faithfully execute the office of Governor (or discharge the functions of the
Governor) of ..... (name of the State) and will to the best of my ability preserve, protect and defend
the Constitution and the law and that I will devote myself to the service and well-being of the people
of .......(name of the State)."
160. Discharge of the functions of the Governor in certain contingencies
The President may make such provision as he thinks fit for the discharge of the functions of the
Governor of a State in any contingency not provided for in this Chapter.
161. Power of Governor to grant pardons, etc., and to suspend, remit or
commute sentences in certain cases
The Governor of a State shall have the power to grant pardons, reprieves, respites or remissions of
punishment or to suspend, remit or commute the sentence of any person convicted of any offence
against any law relating to a matter to which the executive power of the State extends.
162. Extent of executive power of State
Subject to the provisions of this Constitution, the executive power of a State shall extend to the
matters with respect to which the Legislature of the State has power to make laws:Provided that in
any matter with respect to which the Legislature of a State and Parliament have power to make laws,
the executive power of the State shall be subject to, and limited by, the executive power expressly
conferred by the Constitution or by any law made by Parliament upon the Union or authorities
thereof.
163. Council of Ministers to aid and advise Governor
(1)There shall be a Council of Ministers with the Chief Minister at the head to aid and advise the
Governor in the exercise of his functions, except in so far as he is by or under this Constitution
required to exercise his functions or any of them in his discretion.(2)If any question arises whether
any matter is or is not a matter as respects which the Governor is by or under this Constitution
required to act in his discretion, the decision of the Governor in his discretion shall be final, and theConstitution of India

validity of anything done by the Governor shall not be called in question on the ground that he ought
or ought not to have acted in his discretion.(3)The question whether any, and if so what, advice was
tendered by Ministers to the Governor shall not be inquired into in any court.
164. Other provisions as to Ministers
(1)The Chief Minister shall be appointed by the Governor and the other Ministers shall be appointed
by the Governor on the advice of the Chief Minister, and the Ministers shall hold office during the
pleasure of the Governor:Provided that in the State of Chhattisgarh, Jharkhand, Madhya Pradesh
and Odisha, there shall be a Minister in charge of tribal welfare who may in addition be in charge of
the welfare of the Scheduled Castes and backward classes or any other work.(1A)The total number of
Ministers, including the Chief Minister, in the Council of Ministers in a State shall not exceed fifteen
per cent. of the total number of members of the Legislative Assembly of that State:Provided that the
number of Ministers, including the Chief Minister in a State shall not less than twelve:Provided
further that where the total number of Ministers including the Chief Minister in the Council of
Ministers in any State at the commencement of the Constitution (Ninety-first Amendment) Act,
2003 exceeds the said fifteen per cent. or the number specified in the first proviso, as the case may
be, then the total number of the Ministers in that State shall be brought in conformity with the
provisions of this clause within six months from such date as the President may by public
notification appoint.(1B)A member of the Legislative Assembly of a State or either House of the
Legislature of a State having Legislative Council belonging to any political party who is disqualified
for being a member of that House under paragraph 2 of the Tenth Schedule shall also be disqualified
to be appointed as a Minister under clause (1) for the duration of the period commencing from the
date of his disqualification till the date on which the term of his office as such member would expire
or where he contests any election to the Legislative Assembly of a State or either House of the
Legislature of a State having Legislative Council, as the case may be, before the expiry of such
period, till the date on which he is declared elected, whichever is earlier.(2)The Council of Ministers
shall be collectively responsible to the Legislative Assembly of the State.(3)Before a Minister enters
upon his office, the Governor shall administer to him the oaths of office and of secrecy according to
the forms set out for the purpose in the Third Schedule.(4)A Minister who for any period of six
consecutive months is not a member of the Legislature of the State shall at the expiration of that
period cease to be a Minister.(5)The salaries and allowances of Ministers shall be such as the
Legislature of the state may from time to lime by law determine and, until the Legislature of the
State so determines, shall be as specified in the Second Schedule.[Editorial comment-The
Constitution (Ninety-fourth Amendment) Act, 2006, mandates the appointment of a minister in
charge of tribal welfare in the states of Chhattisgarh and Jharkhand. Bihar was exempted from the
requirement to have a minister for tribal welfare under the Constitution, and Jharkhand and
Chhattisgarh were granted the same relief. As per Article 164, Jharkhand, Chhattisgarh, Madhya
Pradesh, and Odisha are now covered under the scope of this provision.Also Refer]
165. Advocate-General for the State
The Advocate-General for the State(1)The Governor of each State shall appoint a person who is
qualified to be appointed a Judge of a High Court to be Advocate-General for the State.(2)It shall beConstitution of India

the duty of the Advocate-General to give advice to the Government of the State upon such legal
matters, and to perform such other duties of a legal character, as may from time to time be referred
or assigned to him by the Governor, and to discharge the functions conferred on him by or under
this Constitution or any other law for the lime being in force.(3)The Advocate-General shall hold
office during the pleasure of the Governor, and shall receive such remuneration as the Governor
may determine.
166. Conduct of business of the Government of a State
(1)All executive action of the Government of a State shall be expressed to be taken in the name of the
Governor.(2)Orders and other instruments made and executed in the name of the Governor shall be
authenticated in such manner as may be specified in rules to be made by the Governor, and the
validity of an order or instrument which is so authenticated shall not be called in question on the
ground that it is not an order or instrument made or executed by the Governor.(3)The Governor
shall make rules for the more convenient transaction of the business of the Government of the State,
and for the allocation among Ministers of the said business in so far as it is not business with respect
to which the Governor is by or under this Constitution required to act in his discretion.[Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
167. Duties of Chief Minister as respects the furnishing of information to
Governor, etc.
It shall be the duty of the Chief Minister of each State--(a)to communicate to the Governor of the
State all decisions of the Council of Ministers relating to the administration of the affairs of the State
and proposals for legislation;(b)to furnish such information relating to the administration of the
affairs of the State and proposals for legislation as the Governor may call for; and(c)if the Governor
so requires, to submit for the consideration of the Council of Ministers any matter on which a
decision has been taken by a Minister but which has not been considered by the Council.
168. Constitution of Legislatures in States
(1)For every State there shall be a Legislature which shall consist of the Governor, and(a)in the
States of Bihar, Maharashtra, Karnataka and Uttar Pradesh, two houses:(b)in other States, one
House.(2)Where there are two Houses of the Legislature of a State, one shall be known as the
Legislative Council and the other as the Legislative Assembly, and where there is only one House, it
shall be known as the Legislative Assembly.[Editorial comment-The Constitution (Seventh
Amendment) Act, 1956, for some states it formulated clause to establish bicameral legislatures. AConstitution of India

bi-cameral legislature was added for the newly formed Madhya Pradesh. The word “Madras” was
followed by the word “Mysore.” Also Refer ]
169. Abolition or creation of Legislative Councils in States
(1)Notwithstanding anything in article 168, Parliament may by law provide for the abolition of the
Legislative Council of a State having such a Council or for the creation of such a Council in a state
having no such Council, if the Legislative Assembly of the State passes a resolution to that effect by a
majority of the total membership of the Assembly and by a majority of not less than two-thirds of
the members of the Assembly present and voting.(2)Any law referred to in clause (1) shall contain
such provisions for the amendment of this Constitution as may be necessary to give effect to the
provisions of the law and may also contain such supplemental, incidental and consequential
provisions as Parliament may deem necessary.(3)No such law as aforesaid shall be deemed to be an
amendment of this Constitution for the purposes of article 368.
170. Composition of the Legislative Assemblies
(1)Subject to the provisions of article 333, the Legislative Assembly of each State shall consist of not
more than five hundred, and not less than sixty, members chosen by direct election from territorial
constituencies in the State.(2)For the purposes of clause (1), each state shall be divided into
territorial constituencies in such manner that the ratio between the population of each constituency
and the number of seats allotted to it shall, so far as practicable, be the same throughout the
State.Explanation.--In this clause, the expression "population" means the population as ascertained
at the last preceding census of which the relevant figures have been published:Provided that the
reference in this Explanation to the last preceding census of which the relevant figures have been
published shall, until the relevant figures for the first census taken after the year 2026 have been
published, be construed as a reference to the 2001 census.(3)Upon the completion of each census,
the total number of seats in the Legislative Assembly of each State and the division of each State into
territorial constituencies shall be readjusted by such authority and in such manner as Parliament
may by law determine:Provided that such readjustment shall not affect representation in the
Legislative Assembly until the dissolution of the then existing Assembly:Provided further that such
readjustment shall take effect from such date as the President may, by order, specify and until such
readjustment takes effect, any election to the Legislative Assembly may be held on the basis of the
territorial constituencies existing before such readjustment:Provided also that until the relevant
figures for the first census taken after the year 2026 have been published, it shall not be necessary to
Readjust-(i)the total number of seats in the Legislative Assembly of each State as readjusted on the
basis of the 1971 census; and(ii)the division of such State into territorial constituencies as may be
readjusted on the basis of the 2001 census, under this clause
171. Composition of the Legislative Councils
(1)The total number of members in the Legislative Council of a State having such a Council shall not
exceedone-third of the total number of members in the Legislative Assembly of that State:Provided
that the total number of members in the Legislative Council of a State shall in no case be less thanConstitution of India

forty.(2)Until Parliament by law otherwise provides, the composition of the Legislative Council of a
State shall be as provided in clause (3).(3)Of the total number of members of the Legislative Council
of a State(a)as nearly as may be, one-third shall be elected by electorates consisting of members of
municipalities, district boards and such other local authorities in the State as Parliament may by law
specify;(b)as nearly as may be, one-twelfth shall be elected by electorates consisting of persons
residing in the State who have been for at least three years graduates of any university in the
territory of India or have been for at least three years in possession of qualifications prescribed by or
under any law made by Parliament as equivalent to that of a graduate of any such university;(c)as
nearly as may be, one-twelfth shall be elected by electorates consisting of persons who have been for
at least three years engaged in teaching in such educational institutions within the State, not lower
in standard than that of a secondary school, as may be prescribed by or under any law made by
Parliament;(d)as nearly as may be, one-third shall be elected by the members of the Legislative
Assembly of the State from amongst persons who are not members of the Assembly;(e)the
remainder shall be nominated by the Governor in accordance with the provisions of
clause(5).(4)The members to be elected under sub-clauses (a), (b) and (c) of clause (3) shall be
chosen in such territorial constituencies as may be prescribed by or under any law made by
Parliament, and the elections under the said sub-clauses and under sub-clause (d) of the said clause
shall be held in accordance with the system of proportional representation by means of the single
transferable vote.(5)The members to be nominated by the Governor under sub-clause (e) of clause
(3) shall consist of persons having special knowledge or practical experience in respect of such
matters as the following, namely:Literature, science, art, co-operative movement and social
service.[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, this amendment
pertains to the upper limit of the State’s Legislative Council’s membership. According to the
suggestion, the largest number of members was changed to one-third or 33% of the total number of
members of the legislative assembly. Also Refer ]
172. Duration of State Legislatures
(1)Every Legislative Assembly of every State, unless sooner dissolved, shall continue forfive years
from the date appointed for its first meeting and no longer and the expiration of the said period
offive years shall operate as a dissolution of the Assembly:Provided that the said period may, while a
Proclamation of Emergency is in operation, be extended by Parliament by law for a period not
exceeding one year at a time and not extending in any case beyond a period of six months after the
Proclamation has ceased to operate.(2)The Legislative Council of a State shall not be subject to
dissolution, but as nearly as possible one-third of the members thereof shall retire as soon as may be
on the expiration of every second year in accordance with the provisions made in that behalf by
Parliament by law.[Editorial comment-The Constitution (Forty-Second Amendment) Act, 1976,
the amendment extended the term of Lok Sabha and Legislative Assemblies members from five to
six years, by amending article 172 (relating to MLAs). The Amendment repealed this change,
shortening the term of the aforementioned assemblies back to the original 5 years.Also
Refer][Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed
Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a separate
Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of speedy
remedy under Article 32 for the violation of Right to Property because it is no more a FundamentalConstitution of India

Right. Making it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis
to the value of socialism included in the preamble and secondly, in doing so, it conformed to the
doctrine of basic structure of the Constitution. Also Refer]
173. Qualification for membership of the State Legislature
A person shall not be qualified to be chosen to fill a seat in the Legislature of a State unless he(a)is a
citizen of India, and makes and subscribes before some person authorised in that behalf by the
Election Commission an oath or affirmation according to the form set out for the purpose in the
Third Schedule;[Editorial comment-The Constitution (Sixteenth Amendment) Act, 1963, were
amended, to provide that every candidate for the membership of Parliament or state legislatures,
Union and state ministers, Judges of the supreme court and high courts, and the comptroller and
Auditor- General of India should swear an oath to uphold the sovereignty and integrity of India. The
forms of oath in the third schedule are amended.](b)is, in the case of a seat in the Legislative
Assembly, not less than twenty-five years of age and in the case of a seat in the Legislative Council,
not less than thirty years of age; and(c)possesses such other qualifications as may be prescribed in
that behalf by or under any law made by Parliament.
174. Sessions of the State Legislature, prorogation and dissolution
(1)The Governor shall from time to time summon the House or each House of the Legislature of the
State to meet at such time and place as he thinks fit, but six months shall not intervene between its
last sitting in one session and the date appointed for its first sitting in the next session.(2)The
Governor may from time to time-(a)prorogue the House or either House;(b)dissolve the Legislative
Assembly.
175. Right of Governor to address and send messages to the House or
Houses
(1)The Governor may address the Legislative Assembly or, in the case of a State having a Legislative
Council, either House of the Legislature of the State, or both Houses assembled together, and may
for that purpose require the attendance of members.(2)The Governor may send messages to the
House or Houses of the Legislature of the State, whether with respect to a Bill then pending in the
Legislature or otherwise, and a House to which any message is so sent shall with all convenient
despatch consider any matter required by the message to be taken into consideration.
176. Special address by the Governor
(1)At the commencement ofthe first session after each general election to the Legislative Assembly
and at the commencement of the first session of each year, the Governor shall address the
Legislative Assembly or, in the case of a State having a Legislative Council, both Houses assembled
together and inform the Legislature of the causes of its summons.(2)Provision shall be made by the
rules regulating the procedure of the House or either House for the allotment of time for discussionConstitution of India

of the matters referred to in such address.
177. Rights of Ministers and Advocate-General as respects the Houses
Every Minister and the Advocate-General for a State shall have the right to speak in, and otherwise
to take part in the proceedings of, the Legislative Assembly of the State or, in the case of a State
having a Legislative Council, both Houses, and to speak in, and otherwise to take part in the
proceedings of, any committee of the Legislature of which he may be named a member, but shall
not, by virtue of this article, be entitled to vote.
178. The Speaker and Deputy Speaker of the Legislative Assembly
Every Legislative Assembly of a State shall, as soon as may be, choose two members of the Assembly
to be respectively Speaker and Deputy Speakers thereof and, so often as the office of Speaker or
Deputy Speaker becomes vacant, the Assembly shall choose another member to be Speaker or
Deputy Speaker, as the case may be.
179. Vacation and resignation of, and removal from, the offices of Speaker
and Deputy Speaker
A member holding office as Speaker or Deputy Speaker of an Assembly—(a)shall vacate his office if
he ceases to be a member of the Assembly;(b)may at any time by writing under his hand addressed,
if such member is the Speaker, to the Deputy Speaker, and if such member is the Deputy Speaker, to
the Speaker, resign his office; and(c)may be removed from his office by a resolution of the Assembly
passed by a majority of all the then members of the Assembly:Provided that no resolution for the
purpose of clause (c) shall be moved unless al least fourteen days' notice has been given of the
intention to move the resolution:Provided further that, whenever the Assembly is dissolved, the
Speaker shall not vacate his office until immediately before the first meeting of the Assembly after
the dissolution.
180. Power of the Deputy Speaker or other person to perform the duties of
the office of, or to act as, Speaker
(1)White the office of Speaker is vacant, the duties of the office shall be performed by the Deputy
Speaker or, if the office of Deputy Speaker is also vacant, by such member of the Assembly as the
Governor may appoint for the purpose.(2)During the absence of the Speaker from any sitting of the
Assembly the Deputy Speaker or, if he is also absent, such person as may be determined by the rules
of procedure of the Assembly, or, if no such person is present, such other person as may be
determined by the Assembly, shall act as Speaker.Constitution of India

181. The Speaker or the Deputy Speaker not to preside while a resolution for
his removal from office is under consideration
(1)At any sitting of the Legislative Assembly, while any resolution for the removal of the Speaker
from his office is under consideration, the Speaker, or while any resolution for the removal of the
Deputy Speaker from his office is under consideration, the Deputy Speaker, shall not, though he is
present, preside, and the provisions of clause (2) of article 180 shall apply in relation to every such
sitting as they apply in relation to a sitting from which the Speaker or, as the case may be, the
Deputy Speaker, is absent.(2)The Speaker shall have the right to speak in, and otherwise to take part
in the proceedings of, the Legislative Assembly while any resolution for his removal from office is
under consideration in the Assembly and shall, notwithstanding anything in article 189, be entitled
to vote only in the first instance on such resolution or on any other matter during such proceedings
but not in the case of an quality of votes.
182. The Chairman and Deputy Chairman of the Legislative Council
The Legislative Council of every State having such Council shall, as soon as may be, choose two
members of the Council to be respectively Chairman and Deputy Chairman thereof and, so often as
the office of Chairman or Deputy Chairman becomes vacant, the Council shall choose another
member to be Chairman or Deputy Chairman, as the case may be.
183. Vacation and resignation of, and removal from, the offices of Chairman
and Deputy Chairman
A member holding office as Chairman or Deputy Chairman of a Legislative Council-(a)shall vacate
his office if he ceases to be a member of the Council;(b)may at any time by writing under his hand
addressed, if such member is the Chairman, to the Deputy Chairman, and if such member is the
Deputy Chairman, to the Chairman, resign his office; and(c)may be removed from his office by a
resolution of the Council passed by a majority of all the then members of the Council:Provided that
no resolution for the purpose of clause (c) shall be moved unless at least fourteen days' notice has
been given of the intention to move the resolution.
184. Power of the Deputy Chairman or other person to perform the duties of
the office of, or to act as, Chairman
(1)While the office of Chairman is vacant, the duties of the office shall be performed by the Deputy
Chairman or, if the office of Deputy Chairman is also vacant, by such member of the Council as the
Governor may appoint for the purpose.(2)During the absence of the Charman from any sitting of the
Council the Deputy Chairman or, if he is also absent, such person as may be determined by the rules
of procedure of the Council, or, if no such person is present, such other person as may be
determined by the Council, shall act as Chairman.Constitution of India

185. The Chairman or the Deputy Chairman not to preside while a resolution
for his removal from office is under consideration
(1)At any sitting of the Legislative Council, while any resolution for the removal of the Chairman
from his office is under consideration, the Chairman, or while any resolution for the removal of the
Deputy Chairman from his office is under consideration, the Deputy Chairman, shall not, though he
is present, preside, and the provisions of clause (2) of article 184 shall apply in relation to every such
sitting as they apply in relation to a sitting from which the Chairman or, as the case may be, the
Deputy Chairman is absent.(2)The Chairman shall have the right to speak in, and otherwise to take
part in the proceedings of, the Legislative Council while any resolution for his removal from office is
under consideration in the Council and shall, notwithstanding anything in article 189, be entitled to
vote only in the first instance on such resolution or on any other matter during such proceedings but
not in the case of an equality of votes.
186. Salaries and allowances of the Speaker and Deputy Speaker and the
Chairman and Deputy Chairman
There shall be paid to the Speaker and the Deputy Speaker of the Legislative Assembly, and to the
Chairman and the Deputy Chairman of the Legislative Council, such salaries and allowances as may
be respectively fixed by the Legislature of the State by law and, until provision in that behalf is so
made, such salaries and allowances as are specified in the Second Schedule.
187. Secretariat of State Legislature
(1)The House or each House of the Legislature of a State shall have a separate secretarial
staff:Provided that nothing in this clause shall, in the case of the Legislature of a State having
Legislative Council, be construed as preventing the creation of posts common to both Houses of
such Legislature.(2)The Legislature of a State may by law regulate the recruitment, and the
conditions of service of persons appointed, to the secretarial staff of the House or Houses of the
Legislature of the State.(3)Until provision is made by the Legislature of the State under clause (2),
the Governor may, after consultation with the Speaker of the Legislative Assembly or the Chairman
of the Legislative Council, as the case may be, make rules regulating the recruitment, and the
conditions of service of persons appointed, to the secretarial staff of the Assembly or the Council,
and any rules so made shall have effect subject to the provisions of any law made under the said
clause.
188. Oath or affirmation by members
Every member of the Legislative Assembly or the Legislative Council of a State shall, before taking
his seat, make and subscribe before the Governor, or some person Appointed in that behalf by him,
an oath or affirmation according to the form set out for the purpose in the Third Schedule.Constitution of India

189. Voting in Houses, power of Houses to act notwithstanding vacancies
and quorum
(1)Save as otherwise provided in this Constitution, all questions at any sitting of a House of the
Legislature of a State shall be determined by a majority of votes of the members present and voting,
other than the Speaker or Chairman, or person acting as such. The Speaker or Chairman, or person
acting as such, shall not vote in the first instance, but shall have and exercise a casting vote in the
case of an equality of votes.(2)A House of the Legislature of a State shall have power to act
notwithstanding any vacancy in the membership thereof, and any proceedings in the Legislature of a
State shall be valid notwithstanding that it is discovered subsequently that some person who was not
entitled so to do sat or voted or otherwise took part in the proceedings.(3)Until the Legislature of the
State by law otherwise provides, the quorum to constitute a meeting of a House of the Legislature of
a State shall be ten members or one-tenth of the total number of members of the House, whichever
is greater.(4)If at any time during a meeting of the Legislative Assembly or the Legislative Council of
a State there is no quorum, it shall be the duty of the Speaker or Chairman, or person acting as such,
either to adjourn the House or to suspend the meeting until there is a quorum.
190. Vacation of seats
(1)No person shall be a member of both Houses of the Legislature of a State and provision shall be
made by the Legislature of the State by law for the vacation by a person who is chosen a member of
both Houses of his seat in one House or the other.(2)No person shall be a member of the
Legislatures of two or more States specified in the First Schedule and if a person is chosen a member
of the Legislatures of two or more such States, then, at the expiration of such period as may be
specified in rulesmade by the President, that person's seat in the Legislatures of all such States shall
become vacant, unless he has previously resigned his seat in the Legislatures of all but one of the
States.(3)If a member of a House of the Legislature of a State--(a)becomes subject to any of the
disqualifications mentioned inclause (1) or clause (2) of article 191; or(b)resigns his seat by writing
under his hand addressed to the Speaker or the Chairman, as the case may be, and his resignation is
accepted by the Speaker or the Chairman, as the case may be, his seat shall thereupon becomes
vacant:Provided that in the case of any resignation referred to in sub-clause (b), if from information
received or otherwise and after making such inquiry as he thinks fit, the Speaker or the Chairman,
as the case may be, is satisfied that such resignation is not voluntary or genuine, he shall not accept
such resignation.(4)If for a period of sixty days a member of a House of the Legislature of a State is
without permission of the House absent from all meetings thereof, the House may declare his seat
vacant:Provided that in computing the said period of sixty days no account shall be taken of any
period during which the House is prorogued or is adjourned for more than four consecutive
days.[Editorial comment-The Constitution (Thirty-Third Amendment) Act, 1974, made
amendments in clause (3) of article 190 of the Constitution, which deals with the vacation of a seat
on account of resignation by a member of a House of the Legislature of a State.Also Refer]Constitution of India

191. Disqualifications for membership
(1)A person shall be disqualified for being chosen as, and for being, a member of the Legislative
Assembly or Legislative Council of a State(a)if he holds any office of profit under the Government of
India or the Government of any State specified in the First Schedule, other than an office declared
by the Legislature of the State by law not to disqualify its holder;(b)if he is of unsound mind and
stands so declared by a competent court;(c)if he is an undischarged insolvent;(d)if he is not a citizen
of India, or has voluntarily acquired the citizenship of a foreign State, or is under any
acknowledgement of allegiance or adherence to a foreign State;(e)if he is so disqualified by or under
any law made by Parliament.Explanation. For the purposes of this clause, a person shall not be
deemed to hold an office of profit under the Government of India or the Government of any State
specified in the First Schedule by reason only that he is a Minister either for the Union or for such
State.(2)A person shall be disqualified for being a member of the Legislative Assembly or Legislative
Council of a State if he is so disqualified under the Tenth Schedule.
192. Decision on questions as to disqualifications of members
(1)If any question arises as to whether a member of a House of the Legislature of a State has become
subject to any of the disqualifications mentioned in clause (1) of article 191, the question shall be
referred for the decision of the Governor and his decision shall be final.(2)Before giving any decision
on any such question, the Governor shall obtain the opinion of the Election Commission and shall
act according to such opinion.[Editorial comment-The Constitution (Forty-Fourth Amendment)
Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and
made a separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the
scope of speedy remedy under Article 32 for the violation of Right to Property because it is no more
a Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
193. Penalty for sitting and voting before making oath or affirmation under
article 188 or when not qualified or when disqualified
If a person sits or votes as a member of the Legislative Assembly or the Legislative Council of a State
before he has complied with the requirements of article 188, or when he knows that he is not
qualified or that he is disqualified for membership thereof, or that he is prohibited from so doing by
the provisions of any law made by Parliament or the Legislature of the State, he shall be liable in
respect of each day on which he so sits or votes to a penalty of five hundred rupees to be recovered
as a debt due to the State.
194. Powers, privileges, etc., of the House of Legislatures and of the
members and committees thereofConstitution of India

(1)Subject to the provisions of this Constitution and to the rules and standing orders regulating the
procedure of the Legislature, there shall be freedom of speech in the Legislature of every State.(2)No
member of the Legislature of a State shall be liable to any proceedings in any court in respect of
anything said or any vote given by him in the Legislature or any committee thereof, and no person
shall be so liable in respect of the publication by or under the authority of a House of such a
Legislature of any report, paper, votes or proceedings.(3)In other respects, the powers, privileges
and immunities of a House of the Legislature of a State, and of the members and the committees of a
House of such Legislature, shall be such as may from time to time be defined by the Legislature by
taw, and, until so defined,shall be those of that House and of its members and committees
immediately before the coming into force of section 26 of the Constitution forty-fourth Amendment)
Act, 1978.(4)The provisions of clauses (1), (2) and (3) shall apply in relation to persons who by virtue
of this Constitution have the right to speak in, and otherwise to take part in the proceedings of a
House of the Legislature of a State or any committee thereof as they apply in relation to members of
that Legislature.[Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978,
repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a
separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of
speedy remedy under Article 32 for the violation of Right to Property because it is no more a
Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer]
195. Salaries and allowances of members
Members of the Legislative Assembly and the Legislative Council of a State shall be entitled to
receive such salaries and allowances as may from time to time be determined, by the Legislature of
the State by law and, until provision in that respect is so made, salaries and allowances at such rates
and upon such conditions as were immediately before the commencement of the Constitution
applicable in the case of members of the Legislative Assembly of the corresponding province.
196. Provisions as to introduction and passing of Bills
(1)Subject to the provisions of articles 198 and 207 with respect to Money Bills and other financial
Bills, a Bill may originate in either House of the Legislature of a State which has a Legislative
Council.(2)Subject to the provisions of articles 197 and 198, a Bill shall not be deemed to have been
passed by the Houses of the Legislature of a State having a Legislative Council unless it has been
agreed to by both Houses, either without amendment or with such amendments only as are agreed
to by both Houses.(3)A Bill pending in the Legislature of a State shall not lapse by reason of the
prorogation of the House or Houses thereof.(4)A Bill pending in the Legislative Council of a State
which has not been passed by the Legislative Assembly shall not lapse on a dissolution of the
Assembly.(5)A Bill which is pending in the Legislative Assembly of a State, or which having been
passed by the Legislative Assembly is pending in the Legislative Council, shall lapse on a dissolution
of the Assembly.Constitution of India

197. Restriction on powers of Legislative Council as to Bills other than
Money Bills
(1)If after a Bill has been passed by the Legislative Assembly of a State having a Legislative Council
and transmitted to the Legislative Council--(a)the Bill is rejected by the Council; or(b)more than
three months elapse from the date on which the Bill is laid before the Council without the Bill being
passed by it; or(c)the Bill is passed by the Council with amendments to which (he Legislative
Assembly does not agree;the Legislative Assembly may, subject to the rules regulating its procedure,
pass the Bill again in the same or in any subsequent session with or without such amendments, if
any, as have been made, suggested or agreed to by the Legislative Council and then transmit the Bill
as so passed to the Legislative Council.(2)If after a Bill has been so passed for the second time by the
Legislative Assembly and transmitted to the Legislative Council(a)the Bill is rejected by the Council;
or(b) more than one month elapses from the date on which the Bill is laid before the Council
withoutthe Bill being passed by it; or(c)the Bill is passed by the Council with amendments to which
the Legislative Assembly does not agree;the Bill shall be deemed to have been passed by the Houses
of the Legislature of the State in the form in which it was passed by the Legislative Assembly for the
second time with such amendments, if any, as have been made or suggested by the Legislative
Council and agreed to by the Legislative Assembly.
198. Special procedure in respect of Money Bills
(1)A Money Bill shall not be introduced in a Legislative Council.(2)After a Money Bill has been
passed by the Legislative Assembly of a State having a Legislative Council, it shall be transmitted to
the Legislative Council for its recommendations, and the Legislative Council shall within a period of
fourteen days from the date of its receipt of the Bill return the Bill to the Legislative Assembly with
its recommendations, and the Legislative Assembly may thereupon either accept or reject all or any
of the recommendations of the Legislative Council(3)If the Legislative Assembly accepts any of the
recommendations of the Legislative Council, the Money Bill shall be deemed to have been passed by
both Houses with the amendments recommended by the Legislative Council and accepted by the
Legislative Assembly.(4)If the Legislative Assembly does not accept any of the recommendations of
the Legislative Council, the Money Bill shall be deemed to have been passed by both Houses in the
form in which it was passed by the Legislative Assembly without any of the amendments
recommended by the Legislative Council.(5)If a Money Bill passed by the Legislative Assembly and
transmitted to the Legislative Council for its recommendations is not returned to the Legislative
Assembly within the said period of fourteen days, it shall be deemed to have been passed by both .
Houses at the expiration of the said period in the form in which it was passed by the Legislative
Assembly.
199. Definition of "Money Bills"
(1)For the purposes of this Chapter, a Bill shall be deemed to be a Money Bill if it contains only
provisions dealing with all or any of the following matters, namely:--(a)the imposition, abolition,
remission, alteration or regulation of any tax;(b)the regulation of the borrowing of money or theConstitution of India

giving of any guarantee by the State, or the amendment of the law with respect to any financial
obligations undertaken or to be undertaken by the State;(c)the custody of the Consolidated Fund or
the Contingency Fund of the State, the payment of moneys into or the withdrawal of moneys from
any such Fund;(d)the appropriation of moneys out of the Consolidated Fund of the State;(e)the
declaring of any expenditure to be expenditure charged on the Consolidated Fund of the State, or
the increasing of the amount of any such expenditure;(f)the receipt of money on account of the
Consolidated Fund of the State or the public account of the State or the custody or issue of such
money; or(g)any matter incidental to any of the matters specified in sub-clauses (a) to (f).(2)A Bill
shall not be deemed to be a Money Bill by reason only that it provides for the imposition of fines or
other pecuniary penalties, or for the demand or payment of fees for licences or fees for services
rendered, or by reason that it provides for the imposition, abolition, remission, alteration or
regulation of any tax by any local authority or body for local purposes.(3)If any question arises
whether a Bill introduced in the Legislature of a State which has a Legislative Council is a Money Bill
or not, the decision of the Speaker of the Legislative Assembly of such State thereon shall be
final.(4)There shall be endorsed on every Money Bill when it is transmitted to the Legislative
Council under article 198, and when it is presented to the Governor for assent under article 200, the
certificate of the Speaker of the Legislative Assembly signed by him that it is a Money Bill.
200. Assent to Bills
When a Bill has been passed by the Legislative Assembly of a State or, in the case of a State having a
Legislative Council, has been passed by both Houses of the Legislature of the State, it shall be
presented to the Governor and the Governor shall declare either that he assents to the Bill or that he
withholds assent therefrom or that he reserves the Bill for the consideration of the
President:Provided that the Governor may, as soon as possible after the presentation to him of the
Bill for assent, return the Bill if it is not a Money Bill together with a message requesting that the
House or Houses will reconsider the Bill or any specified provisions thereof and, in particular, will
consider the desirability of introducing any such amendments as he may recommend in his message
and, when a Bill is so returned, the . House or Houses shall reconsider the Bill accordingly, and if
the Bill is passed again by the House or Houses with or without amendment and presented to the
Governor for assent, the Governor shall not withhold assent therefrom:Provided further that the
Governor shall not assent to, but shall reserve for the consideration of the President, any Bill which
in the opinion of the Governor would, if it became law, so derogate from the powers of the High
Court as to endanger the position which that Court is by this Constitution designed to fill.
201. Bills reserved for consideration
When a Bill is reserved by a Governor for the consideration of the President, the President shall
declare either that he assents to the Bill or that he withholds assent therefrom:Provided that, where
the Bill is not a Money Bill, the President may direct the Governor to return the Bill to the House or,
as the case may be, the Houses of the Legislature of the State together with such a message as it
mentioned in the first proviso to article 200 and, when a Bill is so returned, the House or Houses
shall reconsider it accordingly within a period of six months from the date of receipt of such
message and, if it is again passed by the House or Houses with or without amendment, it shall beConstitution of India

presented again to the President for his consideration.
202. Annual financial statement
(1)The Governor shall in respect of every financial year cause to be laid before the House or Houses
of the Legislature of the State a statement of the estimated receipts and expenditure of the State for
that year, in this Part referred as the "annual financial statement".(2)The estimates of expenditure
embodied in the annual financial statement shall show separately--(a)the sums required to meet
expenditure described by this Constitution as expenditure charged upon the Consolidated Fund of
the State; and(b)the sums required to meet other expenditure proposed to be made from the
Consolidated Fund of the State,and shall distinguish expenditure on revenue account from other
expenditure.(3)The following expenditure shall be expenditure charged on the Consolidated Fund of
each State--(a)the emoluments and allowances of the Governor and other expenditure relating to his
office;(b)the salaries and allowances of the Speaker and the Deputy Speaker of the Legislative
Assembly and, in the case of State having a Legislative Council, also of the Chairman and the Deputy
Chairman of the Legislative Council;(c)debt charges for which the State is liable including interest,
sinking fund charges and redemption charges, and other expenditure relating to the raising of loans
and the service and redemption of debt;(d)expenditure in respect of the salaries and allowances of
Judges of any High Court;(e)any sums required to satisfy any judgment, decree or award of any
court or arbitral tribunal;(f)any other expenditure declared by this Constitution, or by the
Legislature of the State by law, to be so charged.
203. Procedure in Legislature with respect to estimates
(1)So much of the estimates as relates to expenditure charged upon the Consolidated Fund of a State
shall not be submitted to the vote of the Legislative Assembly, but nothing in this clause shall be
construed as preventing the discussion in the Legislature of any of those estimates.(2)So much of
the said estimates as relates to other expenditure shall be submitted in the form of demands for
grants to the Legislative Assembly, and the Legislative Assembly shall have power to assent, or to
refuse to assent, to any demand, or to assent to any demand subject to a reduction of the amount
specified therein.(3)No demand for a grant shall be made except on the recommendation of the
Governor.
204. Appropriation Bills
(1)As soon as may be after the grants under article 203 have been made by the Assembly, there shall
be introduced a Bill to provide for the appropriation out of the Consolidated Fund of the State of all
moneys required to meet—(a)the grants so made by the Assembly; and(b)the expenditure charged
on the Consolidated Fund of the State but not exceeding in any case the amount shown in the
statement previously laid before the House or Houses.(2)No amendment shall be proposed to any
such Bill in the House or either House of the Legislature of the State which will have the effect of
varying the amount or altering the destination of any grant so made or of varying the amount of any
expenditure charged on the Consolidated Fund of the State, and the decision of the person presiding
as to whether an amendment is inadmissible under this clause shall be final.(3)Subject to theConstitution of India

provisions of articles 205 and 206, no money shall be withdrawn from the Consolidated Fund of the
State except under appropriation made by law passed in accordance with the provisions of this
article.
205. Supplementary, additional or excess grants
(1)The Governor shall--(a)if the amount authorised by any law made in accordance with the
provisions of article 204 to be expended for a particular service for the current financial year is
found to be insufficient for the purposes of that year or when a need has arisen during the current
financial year for supplementary or additional expenditure upon some new service not
contemplated in the annual financial statement for that year, or(b)if any money has been spent on
any service during a financial year in excess of the amount granted for that service and for that
year,cause to be laid before the House or the Houses of the Legislature of the State another
statement showing the estimated amount of that expenditure or cause to be presented to the
Legislative Assembly of the State a demand for such excess, as the case may be.(2)The provisions of
articles 202, 203 and 204 shall have effect in relation to any such statement and expenditure or
demand and also to any law to be made authorising the appropriation of moneys out of the
Consolidated Fund of the State to meet such expenditure or the grant in respect of such demand as
they have effect in relation to the annual financial statement and the expenditure mentioned therein
or to a demand for a grant and the law to be made for the authorisation of appropriation of moneys
out of the Consolidated Fund of the State to meet such expenditure or grant.
206. Votes on account, votes of credit and exceptional grants
(1)Notwithstanding anything in the foregoing provisions of this Chapter, the Legislative Assembly of
a State shall have power--(a)to make any grant in advance in respect of the estimated expenditure
for a part of any financial year pending the completion of the procedure prescribed in article 203 for
the voting of such grant and the passing of the law in accordance with the provisions of article 204
in relation to that expenditure;(b)to make a grant for meeting an unexpected demand upon the
resources of the State when on account of the magnitude or the indefinite character of the service
the demand cannot be stated with the details ordinarily given in an annual financial statement;(c)to
make an exceptional grant which forms no part of the current service of any financial year,and the
Legislature of the State shall have power to authorise by law the withdrawal of moneys from the
Consolidated Fund of the State for the purposes for which the said grants are made.(2)The
provisions of articles 203 and 204 shall have effect in relation to the making of any grant under
clause (1) and to any law to be made under that clause as they have effect in relation to the making
of a grant with regard to any expenditure mentioned in the annual financial statement and the law
to be made for the authorisation of appropriation of moneys out of the Consolidated Fund of the
State to meet such expenditure.
207. Special provisions as to financial Bills
(1)A Bill or amendment making provision for any of the matters specified in sub-clauses (a) to (f) of
clause (1) of article 199 shall not be introduced or moved except on the recommendation of theConstitution of India

Governor, and a Bill making such provision shall not be introduced in a Legislative
Council:Provided that no recommendation shall be required under this clause for the moving of an
amendment making provision for the reduction or abolition of any tax.(2)A Bill or amendment shall
not be deemed to make provision for any of the matters aforesaid by reason only that it provides for
the imposition of fines or other pecuniary penalties, or for the demand or payment of fees for
licences or fees for services rendered, or by reason that it provides for the imposition, abolition,
remission, alteration or regulation of any tax by any local authority or body for local purposes.(3)A
Bill which, if enacted and brought into operation, would involve expenditure from the Consolidated
Fund of a State shall not be passed by a House of the Legislature of the State unless the Governor
has recommended to that House the consideration of the Bill.
208. Rules of procedure
(1)A House of the Legislature of a State may make rules for regulating subject to the provisions of
this Constitution, its procedure and the conduct of its business.(2)Until rules are made under clause
(1), the rules of procedure and standing orders in force immediately before the commencement of
this Constitution with respect to the Legislature for the corresponding Province shall have effect in
relation to the Legislature of the State subject to such modifications and adaptations as may be
made therein by the Speaker of the Legislative Assembly, or the Chairman of the Legislative Council,
as the case may be.(3)In a State having a Legislative Council the Governor, after consultation with
the Speaker of the Legislative Assembly and the Chairman of the Legislative Council, may make
rules as to the procedure with respect to communications between the two Houses.
209. Regulation by law of procedure in the Legislature of the State in relation
to financial business
The Legislature of a State may, for the purpose of the timely completion of financial business,
regulate by law the procedure of, and the conduct of business in, the House or Houses of the
Legislature of the State in relation 10 any financial matter or to any Bill for the appropriation of
moneys out of the Consolidated Fund of the State, and, if and so far as any provision of any law so
made is inconsistent with any rule made by the House or either House of the Legislature of the State
under clause (1) of article 208 or with any rule or standing order having effect in relation to the
Legislature of the State under clause (2) of that article, such provision shall prevail.
210. Language to be used in the Legislature
(1)Notwithstanding anything in Part XVII, but subject to the provisions of article 348, business in
the Legislature of a State shall be transacted in the official language or languages of the State or in
Hindi or in English:Provided that the Speaker of the Legislative Assembly or Chairman of the
Legislative Council, or person acting as such, as the case may be, may permit any member who
cannot adequately express himself in any of the languages aforesaid to address the House in his
mother-tongue(2)Unless the Legislature of the State by law otherwise provides, this article shall,
after the expiration of a period of fifteen years from the commencement of this Constitution, haveConstitution of India

effect as if the words "or in English" were omitted here from:Provided that in relation to
theLegislatures of the States of Himachal Pradesh, Manipur, Meghalaya and Tripura this clause
shall have effect as if for the words "fifteen years" occurring therein, the words "twenty-five years"
were substituted:Provided further that in relation to theLegislature of the States ofArunachal
Pradesh, Goa and Mizoram, this clause shall have effect as if for the words "fifteen years" occurring
therein, the words "forty years" were substituted.
211. Restriction on discussion in the Legislature
No discussion shall take place in the Legislature of a Stale with respect to the conduct of any Judge
of the Supreme Court or of a High Court in the discharge of his duties.
212. Courts not to inquire into proceedings of the Legislature
(1)The validity of any proceedings in the Legislature of a State shall not be called in question on the
ground of any alleged irregularity of procedure.(2)No officer or member of the Legislature of a State
in whom powers are vested by or under this Constitution for regulating procedure or the conduct of
business, or for maintaining order, in the Legislature shall be subject to the jurisdiction of any court
in respect of the exercise by him of those powers.
213. Power of Governor to promulgate Ordinances during recess of
Legislature
(1)If at any time, except when the Legislative Assembly of a State is in session, or where there is a
Legislative Council in a State, except when both Houses of the Legislature are in session, the
Governor is satisfied that circumstances exist which render it necessary for him to take immediate
action, he may promulgate such Ordinances as the circumstances appear to him to require:Provided
that the Governor shall not, without instructions from the President, promulgate any such
Ordinance if--(a)a Bill containing the same provisions would under this Constitution have required
the previous sanction of the President for the introduction thereof into the Legislature; or(b)he
would have deemed it necessary to reserve a Bill containing the same provisions for the
consideration of the President; or(c)an Act of the Legislature of the State containing the same
provisions would under this Constitution have been invalid unless, having been reserved for the
consideration of the President, it had received the assent of the President.(2)An Ordinance
promulgated under this article shall have the same force and effect as an Act of Legislature of the
State assented to by the Governor, but every such Ordinance--(a)shall be laid before the Legislative
Assembly of the State, or where there is a Legislative Council in the State, before both the Houses,
and shall cease to operate at the expiration of six weeks from the reassembly of the Legislature, or if
before the expiration of that period a resolution disapproving it is passed by the Legislative
Assembly and agreed to by the Legislative Council, if any, upon the passing of the resolution or, as
the case may be, on the resolution being agreed to by the Council; and(b)may be withdrawn at any
time by the Governor.Explanation.--Where the Houses of the Legislature of a State having a
Legislative Council are summoned to reassemble on different dates, the period of six weeks shall beConstitution of India

reckoned from the later of (hose dates for the purposes of this clause.(3)If and so far as an
Ordinance under this article makes any provision which would not be valid if enacted in an Act of
the Legislature of the State assented to by the Governor, it shall be void:Provided that, for the
purposes of the provisions of this Constitution relating to the effect of an Act of the Legislature of a
Slate which is repugnant to an Act of Parliament or an existing law with respect to a matter
enumerated in the Concurrent List, an Ordinance promulgated under this article in the Concurrent
List, an Ordinance promulgated under this article in pursuance of instructions from the President
shall be deemed to be an Act of the Legislature of the State which has been reserved for the
consideration of the President and assented to by him.[Re-promulgation of Ordinances -Krishna
Kumar Singh v State of Bihar. A 7-judge Constitution bench has held that unfettered
re-promulgation of ordinances is not permissible by the Constitution. On 2nd January, 2017, a
seven-judge Constitution Bench of the Supreme Court held that re-promulgation of ordinances is a
fraud on the Constitution and a subversion of democratic legislative processes. The majority
Judgment, authored by Justice DY Chandrachud, held that the requirement of placing the ordinance
before the Legislature is mandatory; Justice Madan B Lokur observed that it is directory; Justice
Thakur, the Chief Justice of India as he was then, in his separate concurring opinion, preferred to
leave the ‘question of interpretation of Articles 123 (2) and 213(2) in so far as the obligation of the
Government to place the ordinance before the Parliament/legislature open. The Supreme Court of
India’s seven-judge Constitution Bench ruled that the “RE-PROMULGATION OF ORDINANCES”
must be taken to be a violation of our Indian Constitution as it undermines parliamentary legislative
procedures. This Bench furthermore ruled that: “The approval and gratification of the President of
India, under Article 123, and the Governor, under Article 213, when issuing an Ordinance is not
excluded from judicial process and legal challenge.”(https:indiankanoon.org/doc/107225908/,
https:blog.ipleaders.in
unconstitutionality-of-the-re-promulgation-of-ordinances-the-krishna-kumar-singh-conundrum/)][Editorial
comment-The Constitution (Thirty-Eighth Amendment) Act, 1975, codified the declaration of
Emergency and empowered the State to remove fundamental rights during a state of emergency.
This made the Emergency final and inclusive, giving the State the power to suspend certain rights of
its citizens. Currently, there is an ongoing amendment procedure aimed at eliminating obsolete and
unproductive portions of the Constitution and integrating new ones to address evolving social
requirements. Any changes made should aim to improve people’s living conditions and foster social
peace, rather than demolishing the current framework."Also Refer][Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
214. High Courts for States
There shall be a High Court for each State.Constitution of India

215. High Courts to be courts of record
Every High Court shall be a court of record and shall have all the powers of such a court including
the power to punish for contempt of itself.
216. Constitution of High Courts
Every High Court shall consist of a Chief Justice and such other Judges as the President may from
time to time deem it necessary to appoint.[Editorial comment-The Constitution (Seventh
Amendment) Act, 1956, this amendment sets the number of judges for each High Court. This
enables the President to propose as many judges as required for a High Court. Since the largest
number can be altered at any time, it was deemed unnecessary and left out. Also Refer ]
217. Appointment and conditions of the office of a Judge of a High Court
(1)Every Judge of a High Court shall be appointed by the President by warrant under his hand and
seal on the recommendation of the National Judicial Appointments Commission referred to in
article 124A, and shall hold office, in the case of an additional or acting Judge, as provided in article
224, and in any other case, until he attains the age of sixty-two years:Provided that--(a)a Judge may,
by writing under his hand addressed to the President, resign his office;(b)a Judge may be removed
from his office by the President in the manner provided in clause (4) of article 124 for the removal of
a Judge of the Supreme Court;(c)the office of a Judge shall be vacated by his being appointed by the
President to be a Judge of the Supreme Court or by his being transferred by the President to any
other High Court within the territory of India.(2)A person shall not be qualified for appointment as
a Judge of a High Court unless he is a citizen of India and--(a)has for at least ten years held a
judicial office in the territory of India; or(b)has for at least ten years been an advocate of a High
Court ' or of two or more such courts in succession;Explanation: For the purposes of this
clause--(a)in computing the period during which a person has held judicial office in the territory of
India, there shall be included any period, after he has held any judicial office, during which the
person has been an advocate of a High Court or has held the office of a member of a tribunal or any
post, under the Union or a State, requiring special knowledge of law;(aa)in computing the period
during which a person has been an advocate of a High Court, there shall be included any period
during which the person has held judicial office or the office of a member of a tribunal or any post,
under the Union or a State, requiring special knowledge of law after he became an advocate;(b)in
computing the period during which a person has held judicial office in the territory of India or been
an advocate of High Court, there shall be included any period before the commencement of this
Constitution during which he has held judicial office in any area which was comprised before the
fifteenth day of August, 1947, within India as defined by the Government of India Act,1935, or has
been an advocate of any High Court in any such area, as the case may be.(3)If any question arises as
to the age of a Judge of a High Court, the question shall be decided by the President after
consultation with the Chief Justice of India and the decision of the President shall be
final.--[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, it amended Article
217 (1) where it added the words “in the case of an additional or acting Judge, as provided in Article
224, and in any other case” to the existing words of the provision “shall hold office until he attainsConstitution of India

the age of sixty years” Also Refer ][Editorial comment-The Constitution (Fifteenth Amendment)
Act, 1963, through this amendment to Article 217, Clause (1), a High Court Judge’s retirement age
has been raised from 60 to 62. With retroactive effect, a new clause (3) was added to Article 217.
That allows the President to decide the age of a judge of a High court after consulting with the Chief
Justice of India.][Editorial comment-The Constitution (Ninety-ninth Amendment) Act, 2012,
starts with the words “after consultation” and ends with the words “the High Court” shall be
replaced with the words, figures, and letter “on the proposal of the National Judicial Appointments
Commission” as mentioned in Article 124A.Also Refer][Editorial comment-The Constitution
(Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has
been taken out of Part III and made a separate Article 300A in Chapter IV of Part XII. This
amendment may have taken away the scope of speedy remedy under Article 32 for the violation of
Right to Property because it is no more a Fundamental Right. Making it a legal right under the
Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism included in the
preamble and secondly, in doing so, it conformed to the doctrine of basic structure of the
Constitution. Also Refer]
218. Application of certain provisions Application of certain provisions
relating to Supreme Court to High Courts
The provisions of clauses (4) and (5) of article 124 shall apply in relation to a High Court as they
apply in relation to the Supreme Court with the substitution of references to the High Court for
references to the Supreme Court.
219. Oath or affirmation by Judges of High Courts
Every person appointed to be a Judge of a High Court shall, before he enters upon his office, make
and subscribe before the Governor of the State, or some person appointed in that behalf by him, an
oath or affirmation according to the form set out for the purpose in the Third Schedule.
220. Restriction on practice after being a permanent Judge
No person who, after the commencement of this Constitution, has held office as a permanent Judge
of a High Court shall plead or act in any court or before any authority in India except the Supreme
Court and the other High Courts.Explanation.-- In this article, the expression "High Court" does not
include a High Court for a State specified in Part B of the First Schedule as it existed before the
commencement of the Constitution (Seventh Amendment) Act, 1956.[Editorial comment-The
Constitution (Seventh Amendment) Act, 1956, the old clause in Article 220 of the Constitution
forbade retired judges from continuing their legal careers. As a result of the reform, retired High
Court judges are now eligible to serve on the Supreme Court and in High Courts, but not the ones
where they served as permanent judges.Also Refer ]Constitution of India

221. Salaries etc., of Judges
(1)There shall be paid to the Judges of each High Court such salaries as may be determined by
Parliament by law and, until provision in that behalf is so made, such salaries as are specified in the
Second Schedule.(2)Every Judge shall be entitled to such allowances and to such rights in respect of
leave of absence and pension as may from time to time be determined by or under law made by
Parliament and, until so determined, to such allowances and rights as are specified in the Second
Schedule:Provided that neither the allowances of a Judge nor his rights in respect of leave of
absence shall be varied to his disadvantage after his appointment.
222. Transfer of a Judge from one High Court to another
(1)The President may, on the recommendation of the National Judicial Appointments Commission
referred to in article 124A, transfer a Judge from one High Court to any other High Court .(2)When
a Judge has been or is so transferred, he shall, during the period he serves, after the commencement
of the Constitution (Fifteenth Amendment) Act, 1963, as a Judge of the other High Court, be entitled
to receive in addition to his salary such compensatory allowance as may be determined by
Parliament by law and, until so determined, such compensatory allowance as the President may by
order fix.[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, this has been
changed to exclude clause (2). Additionally, it removes the phrase “within the territory of India”
from clause (1). It relates to the President’s authority to move judges among the High Courts. Since
providing a transfer allowance wasn’t essential, clause (2) was removed.Also Refer ][Editorial
comment-The Constitution (Fifteenth Amendment) Act, 1963, according to new clause (2) of
Article 222, judges who are transferred from one High court to another must get
compensation.][Editorial comment-The Constitution (Ninety-ninth Amendment) Act, 2012,
clause (1) of Article 222 of the Constitution shall be modified to read “on the recommendation of the
National Judicial Appointments Commission referred to in Article 124A” in place of the wording
“after consultation with the Chief Justice of India.”Also Refer]
223. Appointment of acting Chief Justice
When the office of Chief Justice of a High Court is vacant or when any such Chief Justice is, by
reason of absence or otherwise, unable to perform the duties of his office, the duties of the office
shall be performed by such one of the other Judges of the court as the President may appoint for the
purposes.
224. Appointment of additional and acting Judges
(1)If by reason of any temporary increase in the business of High Court or by reason of arrears of
work therein, it appears to the President that the number of the Judges of that Court should be for
the time being increased,the President may, in consultation with the National Judicial
Appointments Commission, appoint duly qualified persons to be additional Judges of the Court for
such period not exceeding two years as he may specify .(2)When any Judge of a High Court otherConstitution of India

than the Chief Justice is by reason of absence or for any other reason unable to perform the duties of
his office or is appointed to act temporarily as Chief Justice, the President may, in consultation with
the National Judicial Appointments Commission, appoint a duly qualified person to act as a Judge
of that Court until the permanent Judge has resumed his duties.(3)No person appointed as an
additional or acting Judge of a High Court shall hold office after attaining the age ofsixty-two
years.[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, the replacement
article concerns the appointment of extra and acting judges. This is required when a High Court’s
Chief Justice is absent or unavailable.Also Refer ][Editorial comment-The Constitution
(Ninety-ninth Amendment) Act, 2012, by amending the existing Article 224, the term “the President
may, in agreement with the National Judicial Appointments Commission, appoint” will be used in
place of the phrases “the President may appoint” in clauses (1) and (2).Also Refer]
224A. Appointment of retired Judges at sittings of High Courts
Notwithstanding anything in this Chapter, the National Judicial Appointments Commission on a
reference made to it by the Chief Justice of a High Court for any State, may with the previous
consent of the President, request any person who has held the office of Judge of that Court or of any
other High Court to sit and act as a Judge of the High Court for that State, and every such person so
requested shall, while so sitting and acting, be entitled to such allowances as the President may by
order determine and have all the jurisdiction, powers and privileges of, but shall not otherwise be
deemed to be, a Judge of that High Court:Provided that nothing in this article shall be deemed to
require any such person as aforesaid to sit and act as a Judge of that High Court unless he consents
so to do.[Editorial comment-The Constitution (Fifteenth Amendment) Act, 1963, it allows for the
appointment of a former High Court judge to serve as a High Court judge with the previous consent
of the President..][Editorial comment-The Constitution (Ninety-ninth Amendment) Act, 2012, in
Article 224A of the Constitution, the phrase “the Chief Justice of a High Court for any State may at
any time, with the previous consent of the President” should be replaced with the phrase “National
Judicial Appointment Commission on a reference made to it by the Chief Justice of a High Court for
any State, with the previous consent of the President.”Also Refer]
225. Jurisdiction of existing High Courts
Subject to the provisions of this Constitution and to the provisions of any law of the appropriate
Legislature made by virtue of powers conferred on that Legislature by this Constitution, the
jurisdiction of, and the law administered in, any existing High Court, and the respective powers of
the Judges thereof in relation to the administration of justice in the Court, including any power to
make rules of Court and to regulate the sittings of the court and of members thereof sitting alone or
in Division Courts, shall be the same as immediately before the commencement of this Constitution
:Provided that any restriction to which the exercise of original jurisdiction by any of the High Courts
with respect to any matter concerning the revenue or concerning any act ordered or done in the
collection thereof was subject immediately before the commencement of this Constitution shall no
longer apply to the exercise of such jurisdiction.[Editorial comment-The Constitution
(Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has
been taken out of Part III and made a separate Article 300A in Chapter IV of Part XII. ThisConstitution of India

amendment may have taken away the scope of speedy remedy under Article 32 for the violation of
Right to Property because it is no more a Fundamental Right. Making it a legal right under the
Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism included in the
preamble and secondly, in doing so, it conformed to the doctrine of basic structure of the
Constitution. Also Refer]
226. Power of High Courts to issue certain writs
(1)Notwithstanding anything in article 32 every High Court shall have powers, throughout the
territories in relation to which it exercise jurisdiction, to issue to any person or authority, including
in appropriate cases, any Government, within those territories directions, orders or writs, including
writs in the nature of habeas corpus, mandamus, prohibition, quo warrantor and certiorari, or any
of them, for the enforcement of any of the rights conferred by Part III and for any other
purpose.[(1-A) The power conferred by clause (1) to issue directions, orders or writs to any
Government, authority or person may also be exercised by any High Court exercising jurisdiction in
relation to the territories within which the cause of action, wholly or in part, arises for the exercise of
such power, notwithstanding that the seat of such Government or authority or the residence of such
person is not within those territories."; was inserted after 15th Amendment][Editorial
comment-The Constitution (Fifteenth Amendment) Act, 1963, this was amended to include clause
(1A). It states that the High Court, whose territorial jurisdiction the cause of action originates under,
may also have the ability to issue directives, orders, or writs to any government, authority, or
person, even if their seat or place of abode is beyond the high court’s territorial jurisdiction.](2)The
power conferred by clause (1) to issue directions, orders or writs to any Government, authority or
person may also be exercised by any High Court exercising jurisdiction in relation to the territories
within which the cause of action, wholly or in part, arises for the exercise of such power,
notwithstanding that the scat of such Government or authority or the residence of such person is not
within those territories.(3)Where any party against whom an interim order, whether by way of
injunction or stay or in any other manner, is made on, or in any proceedings relating to, a petition
under clause (1), without--(a)furnishing to such party copies of such petition and all documents in
support of the plea for such interim order; and(b)giving such party an opportunity of being heard,
makes an application to the High Court for the vacation of such order and furnishes a copy of such
application to the party in whose favour such order has been made or the counsel of such party, the
High Court shall dispose of the application within a period of two weeks from the date on which it is
received or from the date on which the copy of such application is so furnished, whichever is later, or
where the High Court is closed on the last day of that period, before the expiry of the next day
afterwards on which the High Court is open; and if the application is not so disposed of, the interim
order shall, on the expiry of that period, or, as the case may be, the expiry of the said next day, stand
vacated.(4)The power conferred on a High Court by this article shall not be in derogation of the
power conferred on the Supreme Court by clause (2) of article 32.[Editorial comment-The
Constitution (Forty-Third Amendment) Act, 1977, * The Constitution’s Article 226(A) shall be
deleted.
* Before the implementation of this Act, the High Court may handle any cases that were pending
before it under article 226 of the Constitution. As if the aforementioned article 226(A) had been
deleted as of February 1st, 1977.Also Refer][Editorial comment-The Constitution (Forty-FourthConstitution of India

Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to Property
because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer]
226A. Constitutional validity of Central laws not to be considered in
proceedings under 226
(1)All proclamations, ordinances, orders, rules, bye-laws and regulations made by the President or
the Governor of a State or by any person or authority under the authority of the President or the
Governor of a State, whether before or after the commencement of the Constitution (Forty-second
Amendment) Act, 1976, in so far as such proclamations, ordinances, orders, rules, bye-laws or
regulations seek to deal with or provide for the prevention of, or punishment for, any action deemed
to be prejudicial to the maintenance of public order or the maintenance of supplies and services
essential to the community, shall, notwithstanding any judgment, decree or order of any court or
tribunal to the contrary, be deemed to be and to have always been validly made, and shall not be
called in question on any ground whatsoever.(2)For the removal of doubts, it is hereby declared that
no Act of any Legislature made after the commencement of the Constitution (Forty-second
Amendment) Act, 1976, shall be called in question in any court on the ground that it contravenes
any provision of the Constitution, including any of the provisions of this Part (including Article 13)
or any amendment made by this Constitution or that the power of the Legislature to make such Act
is in any way limited, whether because of a matter enumerated in the List or for any other
reason.[Rep . by the Constitution (Forty-third Amendment) Act, 1977, section 8 (w.e.f.
13.4.1978)][Editorial comment-The Constitution (Forty-Third Amendment) Act, 1977, A similar
ban on High Courts deliberating the constitutionality of Central laws was imposed by Article 226(A).
The said article has been omitted.Also Refer]
227. Power of superintendence over all courts by the High Court
(1)Every High Court shall have superintendence over all courts and tribunals throughout the
territories interrelation to which it exercises jurisdiction.(2)Without prejudice to the generality of
the foregoing provisions, the High Court may--(a)call for returns from such courts;(b)make and
issue general rules and prescribe forms for regulating the practice and proceedings of such courts;
and(c)prescribe forms in which books, entries and accounts shall be kept by the officers of any such
courts.(3)The High Court may also settle tables of fees to be allowed to the sheriff and all clerks and
officers of such courts and to attorneys, advocates and pleaders practising therein:Provided that any
rules made, forms prescribed or tables settled under clause (2) or clause (3) shall not be inconsistent
with the provision or any law for the time being in force, and shall require the previous approval of
the Governor.(4)Nothing in this article shall be deemed to confer on a High Court powers of
superintendence over any court or tribunal constituted by or under any law relating to the Armed
Forces.[Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed
Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a separateConstitution of India

Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of speedy
remedy under Article 32 for the violation of Right to Property because it is no more a Fundamental
Right. Making it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis
to the value of socialism included in the preamble and secondly, in doing so, it conformed to the
doctrine of basic structure of the Constitution. Also Refer]
228. Transfer of certain cases to High Court
If the High Court is satisfied that a case pending in a court subordinate to it involves a substantial
question of law as to the interpretation of this Constitution the de termination of which is necessary
for the disposal of the case,it shall withdraw the case and may--(a)either dispose of the case itself,
or(b)determine the said question, of law and return the case to the court from which the case has
been so withdrawn together with a copy of its judgment on such question, and the said court shall
on receipt thereof proceed to dispose of the case in conformity with such judgment.[Editorial
comment-The Constitution (Forty-Third Amendment) Act, 1977,The phrase “, subject to the
restrictions of article 131(A)” and its modifiers shall be removed from the first clause of article 228
of the Constitution.Also Refer]
228A. Special provisions as to disposal of question relating to constitutional
validity of State Laws
Notwithstanding anything contained in this Constitution, -(a)all proceedings pending in any court
immediately before the commencement of the Constitution (Forty-second Amendment) Act, 1976,
in so far as they relate to matters specified in the Concurrent List, shall, if they have been stayed by
any order of any court, be deemed to have been stayed by the Supreme Court;(b)no court (other
than the Supreme Court or a High Court exercising jurisdiction under any law relating to the Armed
Forces) shall have any jurisdiction in respect of any such matter as is referred to in clause (a);(c)no
appeal or application for revision or review arising out of any judgment, decree or order made by
any court in any such proceedings shall be entertained by any court, except the Supreme Court.[Any
case pending before a High Court immediately before the commencement of this Act may be dealt
with by the High Court as if the said article 228A had been omitted with effect on and from the 1st
day of February, 1977.][Rep . by the Constitution (Forty-third Amendment) Act, 1977, section 10,
(w.e.f. 13-4-1978)][Editorial comment-The Constitution (Forty-Second Amendment) Act, 1976, A
new article 228A was inserted in the Constitution which would give High Courts the authority to
"determine all questions as to the constitutional validity of any State law". The amendment's
fifty-nine clauses stripped the Supreme Court of many of its powers and moved the political system
toward parliamentary sovereignty. The 43rd and 44th Amendments reversed these changes.Also
Refer][Editorial comment-The Constitution (Forty-Third Amendment) Act, 1977, Under Article
228(A), a High Court could only declare a State law invalid if the decision was made by a bench of at
least five judges. Additionally, a special majority of two-thirds of the bench voted in favor of the
motion.Also Refer]Constitution of India

229. Officers and servants and the expenses of High Courts
(1)Appointments of officers and servants of a High Court shall be made by the Chief Justice of the
Court or such other Judge or officer of the Court as he may direct:Provided that the Governor of the
State may by rule require that in such cases as may be specified in the rule no person not already
attached to the Court shall be appointed to any office connected with the Court save after
consultation with the State Public Service Commission.(2)Subject to the provisions of any law made
by the Legislature of the State, the conditions of service of officers and servants of a High Court shall
be such as may be prescribed by rules made by the Chief Justice of the Court or by some other Judge
or officer of the Court authorised by the Chief Justice to make rules for the purpose:Provided that
the rules made under this clause shall, so far as they relate to salaries, allowances, leave or pensions,
require the approval of the Governor of the State.(3)The administrative expenses of a High Court,
including all salaries, allowances and pensions payable to or in respect of the officers and servants of
the court, shall be charged upon the Consolidated Fund of the State, and any fees or other moneys
taken by the Court shall form part of that Fund.
230. Extension of jurisdiction of High Courts to Union territories
(1)Parliament may by law extend the jurisdiction of a High Court to, or exclude the jurisdiction of a
High Court from, any Union territory.(2)Where the High Court of a State exercises jurisdiction in
relation to a Union territory:(a)nothing in this Constitution shall be construed as empowering the
Legislature of the State to increase, restrict or abolish that jurisdiction; and(b)the reference in
article 227 to the Governor shall, in relation to any rules, forms or tables for subordinate courts in
that territory, be construed as a reference to the President.[Editorial comment-The Constitution
(Seventh Amendment) Act, 1956, this amendement is for the creation of state high courts is the
subject of these.After the changes, a High Court’s jurisdiction could be expanded to a Union
territory if needed. Also Refer ]
231. Establishment of a common High Court for two or more States
(1)Notwithstanding anything contained in the preceding provisions of this Chapter, Parliament may
by law establish a common High Court for two or more state or for two or more States and a Union
territory.(2)In relation to any such High Court,-[* * *](b)the reference in article 227 to the Governor
shall, in relation to any rules, forms or tables for subordinate courts, be construed as a reference to
the Governor of the State in which the Subordinate Courts are situate; and(c)the reference in articles
219 and 229 to the State shall be construed as a reference to the State in which the High Court has
its principal seat:Provided that if such principal seat is in a Union territory, the references in articles
210 and 229 to the Governor, Public Service Commission, Legislature and Consolidated Fund of the
State shall be construed respectively as references to the President, Union Public Service
Commission, Parliament and Consolidated Fund of India.[Editorial comment-The Constitution
(Seventh Amendment) Act, 1956, this amendement is for the creation of state high courts is the
subject of these.After the changes, a High Court’s jurisdiction could be expanded to a Union
territory if needed. Also Refer ][Editorial comment-The Constitution (Ninety-ninth Amendment)
Act, 2012, clause (a) of Article 231’s 2nd clause, which is required under that provision, shall beConstitution of India

omitted.Also Refer]
232. Articles 230, 231 and 232 substituted with articles 230 and 231
Omitted vide Constitution (Seventh Amendment) Act, 1956.[Editorial comment-The
Constitution (Seventy-second Amendment) Act, 1992, provides the reservation of seats to the
Scheduled tribes (ST) in the legislative assembly of the State of Tripura. It is valid till the date of
re-adjustment of seats based on the first census after the year 2000, as provided for in Article 170 of
the Indian Constitution for the state of Tripura.Also Refer]
233. Appointment of district judges
(1)Appointments of persons to be, and the posting and promotion of, district judges in any State
shall be made by the Governor of the State in consultation with the High Court exercising
jurisdiction in relation to such State,(2)A person not already in the service of the Union or of the
State shall only be eligible to be appointed a district judge if he has been for not less than seven
years an advocate or a pleader and is recommended by the High Court for appointment.
233A. Validation of appointments of, and judgments, etc., delivered by,
certain district judges
Notwithstanding any judgment, decree or order of any court,(a)(i)no appointment of any person
already in the judicial service of a State or of any person who has been for not less than seven years
an advocate or a pleader, to be a district judge in that State, and(ii)no posting, promotion or transfer
of any such person as a district judge, made at any time before the commencement of the
Constitution (Twentieth Amendment) Act, 1966, otherwise than in accordance with the provisions
of article 233 or article 235 shall be deemed to be illegal or void or ever to have become illegal or
void by reason only of the fact that such appointment, posting, promotion or transfer was not made
in accordance with the said provisions;(b)no jurisdiction exercised, no judgment, decree, sentence
or order passed or made, and no other act or proceeding done or taken, before the commencement
of the Constitution (Twentieth Amendment) Act, 1966 by, or before, any person appointed, posted,
promoted or transferred as a district judge in any State otherwise than in accordance with the
provisions of article 233 or article 235 shall be deemed to be illegal or invalid or ever to have become
illegal or invalid by reason only of the fact that such appointment, posting, promotion or transfer
was not made in accordance with the said provisions.[Editorial comment-The Constitution
(Twentieth Amendment) Act, 1966, inserted a new Article 233A, among other things such as
validating the appointments, postings, promotions, and transfer of District judges. This amendment
establishes new jurisdictions that have the power to certify the appointments, promotions and
transfers of District judges and judgments made before the enactment of current law in States that
have not complied with the corresponding provisions of Article 233 of the Indian Constitution. The
amendment act is primarily concerned with the appointment, secondment, promotion, and transfer
of district judges to the effective date of existing laws enacted in states that do not comply with the
provisions of Article 233 or Article 235 of the Constitution. Also refer ]Constitution of India

234. Recruitment of persons other than district judges to the judicial service
Appointment of persons other than district judges to the judicial service of a State shall be made by
the Governor of the State in accordance with rules made by him in that behalf after consultation
with the Slate Public Service Commission and with the High Court exercising jurisdiction in relation
to such State.
235. Control over subordinate courts
The control over district courts and courts subordinate thereto including the posting and promotion
of, and the grant of leave to, persons belonging to the judicial service of a State and holding any post
inferior to the post of district judge shall be vested in the High Court, but nothing in this article shall
be construed as taking away from any such person any right of appeal which he may under the law
regulating the conditions of his service or as authorising the High Court to deal with him otherwise
than in accordance with the conditions of his service prescribed under such law.
236. Interpretation
In this Chapter:(a)the expression "district judge" includes judge of a city civil court, additional
district judge, joint district judge, assistant district judge, chief judge of a small cause court, chief
presidency magistrate, additional chief presidency magistrate, sessions judge, additional sessions
judge and assistant sessions judge;(b)the expression "judicial service" means a service consisting
exclusively of persons intended to fill the post of district judge and other civil judicial posts inferior
to the post of district judge.
237. Application of the provisions of this Chapter to certain class or classes
of magistrates
The Governor may by public notification direct that the foregoing provisions of this Chapter and any
rules made thereunder shall with effect from such date as may be fixed by him in that behalf apply in
relation to any class or classes of magistrates in the State as they apply in relation to persons
appointed to the judicial service of the State subject to such exceptions and modifications as may be
specified in the notification.
Part VII – The states in part B of the First Schedule
Repealed by the Constitution (Seventh Amendment) Act, 1956, section 29 and Schedule.
Part VIII – The Union TerritoriesConstitution of India

239. Administration of Union territories
(1)Save as otherwise provided by Parliament by law, every Union territory shall be administered by
the President acting, to such extent as he thinks fit, through an administrator to be appointed by
him with such designation as he may specify.(2)Notwithstanding anything contained in Part VI, the
President may appoint the Governor of a State as the administrator of an adjoining Union territory,
and where a Governor is so appointed, he shall exercise his functions as such administrator
independently of his Council of Ministers.[Editorial comment-The Constitution (Seventh
Amendment) Act, 1956,this amendment substituted the president’s authority to enact laws
governing the Union territory of the Andaman and Nicobar Islands as well as the Minicoy,
Laccadive, and Amindivi Islands is covered by these articles. A president-selected administrator will
also be in charge of the administration of Union territory. Also Refer ]
239A. Creation of local Legislatures or Council of Ministers or both for
certain Union territories
(1)Parliament may by law create for the Union territory of Pondicherry. [In article 239A of the
Constitution, in clause (1), for the words "Goa, Daman and Diu, and Pondicherry", the words "Goa,
Daman and Diu, Pondicherry and Mizoram" shall be substituted through Constitution
(Twenty-Seventh Amendment) Act, 1971](a)a body, whether elected or partly nominated and partly
elected, to function as a Legislature for the Union territory, or.(b)a Council of Ministers, or both
with such Constitution, powers and functions, in each case, as may be specified in the law.(2)Any
such law as is referred to in clause (1) shall not be deemed to be an amendment of this Constitution
for the purposes of article 368 notwithstanding that it contains any provision which amends or has
the effect of amending this Constitution.[Editorial comment- The Constitution (Fourteenth
Amendment) Act, 1962, this article 239A was added when the French colonies of Pondicherry,
Mahé, Yanam, and Karikal became part of the Indian Union on August 16, 1962. This followed the
ratification of the Treaty of Cession by both France and India. The integration of the colonies into
the Indian Union was formalized through the Treaty of Cession.The President, however, shall no
longer promulgate regulations or take other actions with effect from the date set for the first meeting
of any legislature established under the new article 239A to serve the union territories of Goa,
Daman, and Diu, or Pondicherry.Also refer ][Editorial comment-The Constitution
(Twenty-Seventh Amendment) Act, 1971 in Article 239A, a slight change was made to the sentence
containing “Goa, Daman and Diu, and Pondicherry” by adding the word “Mizoram”. That is, part of
Article 239A now became “Goa, Daman and Diu, Pondicherry and Mizoram”.Also Refer ][Editorial
comment-The Constitution (Thirty-Seventh Amendment) Act, 1975, a new Article 239A was
inserted which deals with the power of Parliament to create local legislatures or councils of
ministers or both for certain Union Territories. Originally, the UTs present in this Article were
Mizoram and Pondicherry. By this amendment, the UT of Arunachal Pradesh was given the same
status as the other two.Also Refer]Constitution of India

239AA. Special provisions with respect to Delhi
(1)As from the date of commencement of the Constitution (Sixty-ninth Amendment) Act, 1991, the
Union territory of Delhi shall be called the National Capital Territory of Delhi (hereafter in this Part
referred to as the National Capital Territory) and the administrator thereof appointed under article
239 shall be designated as the Lieutenant Governor.(2)(a)There shall be a Legislative Assembly for
the National Capital Territory and the seals in such Assembly shall be filled by members chosen by
direct election from territorial constituencies in the National Capital Territory.(b)The total number
of seats in the Legislative Assembly, the number of seats reserved for Scheduled Castes, the division
of the National Capital Territory into territorial constituencies (including the basis for such division)
and all other matters relating to the functioning of the Legislative Assembly shall be regulated by
law made by Parliament.(c)The provisions of articles 324 to 327 and 329 shall apply in relation to
the National Capita! Territory, the Legislative Assembly of the National Capital Territory and the
members thereof as they apply, in relation to a State, the Legislative Assembly of a State and the
members thereof respectively; and my reference in articles 326 and 329 to "appropriate Legislature"
shall be deemed to be a reference to Parliament.(3)(a)Subject to the provisions of this Constitution,
the Legislative Assembly shall have power to make laws for the whole or any part of the National
Capital Territory with respect to any of the matters enumerated in the State List or in the
Concurrent List in so far as any such mailer is applicable to Union territories except matters with
respect to Entries 1, 2 and 18 of the State List and Entries 64, 65 and 66 of that List in so far as they
relate to the said Entries 1, 2, and 18.(b)Nothing in sub-clause (a) shall derogate from the powers of
Parliament under this Constitution to make laws with respect to any matter for a Union territory or
any part thereof.(c)If any provision of a law made by the Legislative Assembly with respect to any
matter is repugnant to any provision of a law made by Parliament with respect to that matter,
whether passed before or after the law made by the Legislative Assembly, or of an earlier law, other
than a law made by the Legislative Assembly, then, in either case, the law made by Parliament, or, as
the case may be, such earlier law, shall prevail and the law made by the Legislative Assembly shall,
to the extent of the repugnancy, be void:Provided that if any such law made by the Legislative
Assembly has been reserved for the consideration of the President and has received his assent, such
law shall prevail in the National Capital Territory:Provided further that nothing in this sub-clause
shall prevent Parliament from enacting at any time any law with respect to the same matter
including a law adding to, amending, varying or repealing the law so made by the Legislative
Assembly.(4)There shall be a Council of Ministers consisting of not more than ten per cent, of the
total number of members in the Legislative Assembly, with the Chief Minister at the head to aid and
advise the Lieutenant Governor in the exercise of his functions in relation to matters with respect to
which the Legislative Assembly has power to make laws, except in so far as he is, by or under any
law, required to act in his discretion:Provided that in the case of difference of opinion between the
Lieutenant Governor and his Ministers on any matter, the Lieutenant Governor shall refer it to the
President for decision and act according to the decision given thereon by the President and pending
such decision it shall be competent for the Lieutenant Governor in any case where the mailer, in his
opinion, is so urgent that it is necessary for him to take immediate action, to take such action or to
given such direction in the matter as he deems necessary.(5)The Chief Minister shall be appointed
by the President and the other Ministers shall be appointed by the President on the advice of the
Chief Minister and the Ministers shall hold office during the pleasure of the President.(6)TheConstitution of India

Council of Ministers shall be collectively responsible to the Legislative assembly.(7)(a)Parliament
may, by law, make provisions for giving effect to, or supplementing the provisions contained in the
foregoing clauses and for all matters incidental or consequential thereto.(b)Any such law as is
referred to in sub-clause (a) shall not be deemed to be an amendment of this Constitution for the
purposes of article 368 notwithstanding that it contains any provision which amends or has the
effect of amending, this Constitution.(8)The provisions of article 239B shall, so far as may be, apply
in relation to the National Capital Territory, the Lieutenant Governor and the Legislative Assembly,
as they apply in relation to the Union territory of Pondicherry, the administrator and its Legislature,
respectively; and any reference in that article to "clause (1) to article 239A" shall be deemed to be a
reference to this article or article 239AB, as the case may be.[Editorial comment-The
Constitution (Sixty-ninth Amendment) Act, 1991, conferred special status to Delhi, making it a
separate state above other Union Territories and below States. It also established a legislature with a
70-member assembly and seven members of the council of ministers. The Constitution has many
provisions relating to Delhi, including the role of the Lt. Governor. These provisions will allow the
citizens of Delhi to shape the laws, policies, and procedures affecting their city.Also
Refer][Editorial comment-The Constitution (Seventieth Amendment) Act, 1992, Include
National Capital Territory of Delhi and Union Territory of Pondicherry in Electoral College for
presidential election. Also Refer][Editorial comment-The Constitution (One Hundred and Sixth
Amendment) Act, 2023, where New clauses have been inserted in Article 239-AA that focuses on
Reservation of seats for women in Legislative Assembly of Delhi, 1/3rd of the seats for Scheduled
Castes will be reserved for women, 1/3rd of the seats that have to be filled by direct election will be
reserved for women (including women belonging to Scheduled Castes).Also Refer ]
239AB. Provisions in case of failure of constitutional machinery
If the President, on receipt of a report from the Lieutenant Governor or otherwise, is satisfied(a)that
a situation has arisen in which the administration of the National Capital Territory cannot be carried
on in accordance with the provisions or article 239AA or of any law made in pursuance of that
article; or(b)that for the proper administration of the National Capital Territory it is necessary or
expedient so to do, the President may by order suspend the operation of any provision of article
239AA or of all or any of the provisions of any law made in pursuance of that article for such period
and subject to such conditions as may be specified in such law and make such incidental and
consequential provisions as may appear to him to be necessary or expedient for administering the
National Capital Territory in accordance with the provisions of article 239 and article 239
AA.[Editorial comment-The Constitution (Sixty-ninth Amendment) Act, 1991, To provide for a
legislative assembly and council of ministers for National Capital Territory of Delhi. Delhi continues
to be a Union Territory Also Refer]
239B. Power of administrator to promulgate Ordinances during recess of
Legislature
[After article 239A of the Constitution, the following article shall be inserted through Constitution
(Twenty-Seventh Amendment) Act, 1971](1)If at any time, except when the Legislature ofthe Union
territory of Pondicherry is in session, the administrator thereof is satisfied that circumstances existConstitution of India

which render it necessary for him to take immediate action, he may promulgate such Ordinances as
the circumstances appear to him to require:Provided that no such Ordinance shall be promulgated
by the administrator except after obtaining instructions from the President in that behalf:Provided
further that whenever the said legislature is dissolved, or its functioning from the President shall be
deemed to be an Act of the Legislature of the Union territory which has been duly enacted after
complying with the provisions in that behalf contained in any such law as is referred to in clause (1)
of article 239A, the administrator shall not promulgate any Ordinance during the period of such
dissolution or suspension.(2)An Ordinance promulgated under this article in pursuance of
instructions from the President shall be deemed to be an Act of the Legislature of the Union territory
which has been duly enacted after complying with the provisions in that behalf contained in any
such law as is referred to in clause (1) of article 239A, but every such Ordinance(a)shall be laid
before the Legislature of the Union territory and shall cease to operate at the expiration of six weeks
from the reassembly of the Legislature or if, before the expiration of that period, a resolution
disapproving it is passed by the Legislature, upon the passing of the resolution; and(b)may be
withdrawn at any time by the administrator after obtaining instructions from the President in that
behalf.(3)If and so far as an Ordinance under this article makes any provision which would not be
valid if enacted in an Act of the Legislature of the Union territory made after complying with the
provisions in that behalf contained in any such law as is referred to in clause (1) of article 239A, it
shall be void.[Editorial comment-The Constitution (Twenty-Seventh Amendment) Act, 1971 the
addition of Article 239B gave the Administrator of a Union Territories with legislature the authority
to promulgate ordinances when the Legislature is not in session. After receiving instructions from
the President, the power of the Administrator will help issue such an ordinance. The administrator,
however, shall not issue ordinances during recess or during any period of any dissolution or
suspension of the Legislature.Also Refer ][Editorial comment-The Constitution (Forty-Fourth
Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to Property
because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer]
240. Power of President to make regulations for certain Union territories
(1)The President may make regulations for the peace, progress and good Government of the Union
territory of(a)the Andaman and Nicobar Islands;(b)Lakshadweep;(c)Dadra and Nagar
Haveli;(d)Daman and Diu;(e)Pondicherry;(f)*** [Mizoram;](g)*** [Puducherry;]Provided that
when any body is created under article 239A to function as a Legislature for the Union territories of
Pondicherry, the President shall not make any regulation for the peace, progress and good
Government of that Union territory with effect from the date appointed for the first meeting of the
Legislature:Provided further that whenever the body functioning as a Legislature for the Union
territory ofPondicherry is dissolved, or the functioning of that body as such Legislature remains
suspended on account of any action taken under any such law as is referred to in clause (1) of article
239A, the President may, during the period of such dissolution or suspension, make regulations for
the peace, progress and good Government of that Union territory.(2)Any regulation so made mayConstitution of India

repeal or amend any Act made by Parliament orany other law which is for the time being applicable
to the Union territory and, when promulgated by the President, shall have the same force and effect
as an Act of Parliament which applies to that territory.[Editorial comment-The Constitution
(Seventh Amendment) Act, 1956, this amendment substituted the president’s authority to enact
laws governing the Union territory of the Andaman and Nicobar Islands as well as the Minicoy,
Laccadive, and Amindivi Islands is covered by these articles. A president-selected administrator will
also be in charge of the administration of Union territory. Also Refer ][Editorial comment- The
Constitution (Tenth Amendment) Act, 1961, incorporated Dadra and Nagar Haveli as the seventh
Union territory of India, by amending the First Schedule to the Constitution to include the Union
territory of Dadra and Nagar Haveli in order to enable the President to “make regulations for the
peace, progress and good government of the territory”. Also refer ][Editorial comment-The
Constitution (Twelfth Amendment) Act, 1962, one of the prominent ones for the country as in
December 1961, India acquired Goa, Daman, and Diu from Portugal. To bring this integration into
effect, the First Schedule of the Indian Constitution was amended in 1962. This amendment
integrated Goa, Daman, and Diu as India’s eighth Union territory. It also included these areas under
clause (1) of Article 240 of the Constitution. It allowed the President of India to “establish rules for
the peace, progress, and good governance of the territory.” Also refer ][Editorial comment- The
Constitution (Fourteenth Amendment) Act, 1962, to provide the President with the authority to
“establish regulations for the peace, progress, and good governance” of the territory, clause (1) of
article 240 of the Constitution was amended to include the Union territory of Pondicherry. Also
refer ][Editorial comment-The Constitution (Twenty-Seventh Amendment) Act, 1971 this
amendment to Article 240 retained the President’s authority to establish rules for the North-East
Frontier Agency even after it has become the Union Territory of Arunachal Pradesh. It gave the
President similar authority over the Union Territory of Mizoram.Also Refer ][Editorial
comment-The Constitution (Thirty-Seventh Amendment) Act, 1975, a new Article 240 was
inserted which deals with the power of the President to make regulations for certain UTs. Here, a
new entry (g) was added which empowered the President of India to make regulations for the Union
Territory of Arunachal Pradesh.Also Refer ]
241. High Courts for Union territories
(1)Parliament may by law constitute a High Court for aUnion territory or declare any court in
anysuch territory to be a High Court for all or any of the purposes of this Constitution.(2)The
provisions of Chapter V of Part VI shall apply in relation to every High Court referred to in clause (1)
as they apply in relation to a High Court referred to in article 214 subject to such modifications or
exceptions as Parliament may by law provide.(3)Subject to the provisions of this Constitution and to
the provisions of any law of the appropriate Legislature made by virtue of powers conferred on that
Legislature by or under this Constitution, every High Court exercising jurisdiction immediately
before the commencement of the Constitution (Seventh Amendment) Act, 1956, in relation to any
Union territory shall continue to exercise such jurisdiction in relation to that territory after such
commencement.(4)Nothing in this article derogates from the power of Parliament to extend or
exclude the jurisdiction of a High Court for a State to, or from, any Union territory or part thereof.Constitution of India

242. Coorg
Repealed by the Constitution (Seventh Amendment) Act, 1956, section 29 and Schedule
Part IX – The Panchayats
243. Definitions
In this Part, unless the context otherwise requires,--(a)'district' means a district in a State;(b)'Gram
Sabha' means a body consisting of persons registered in the electoral rolls relating to a village
comprised within the area of Panchayat at the village level;(c)'intermediate level' means a level
between the village and district levels specified by the Governor of a State by public notification to
be the intermediate level for the purposes of this Part;(d)'Panchayat' means an institution (by
whatever name called) of self-government constituted under article 243B , for the rural
areas;(e)'Panchayat area' means the territorial area of a Panchayat;(f)'population' means the
population as ascertained at the last preceding census of which the relevant figures have been
published;(g)'village' means a village specified by the Governor by public notification to be a village
for the purposes of this Part and includes a group of villages so specified.[Editorial comment-The
Constitution (Seventy-third Amendment) Act, 1992, was a significant reform in the Constitution of
India. It introduced the concept of gram panchayats, which is a third-level government that deals
directly with the public and works to address problems at the grass-roots level. Article 243 (b)
defines the gram sabha, which consists of persons registered on the electoral rolls. It is the basic unit
of the Panchayati Raj Institution. This institution is empowered to perform various functions at the
village level, including establishing schools and health facilities. This act granted constitutional
status to panchayats and democratized decentralization. It also empowered panchayats at all levels
to levy taxes and collect duties. It further ensures that people at the grassroots level are more
engaged in the governance process. It focused on improving rural political structures and the rights
of vulnerable populations. The Act emphasized the need for women to be a part of local government
structures. This law made it simpler for women to get involved in politics by giving them greater
possibilities. The act also made women eligible to serve as Panchayat members. This amendment
Act of Indian Constitution also made provisions for reserving seats for SC/ST/OBC communities
and women in the legislature. In addition, it removed the upper population limit in parliamentary
constituencies.Also Refer]
243A. Gram Sabha
A Gram Sabha may exercise such powers and perform such functions at the village level as the
Legislature of a State may by law, provide.
243B. Constitution of Panchayats
(1)There shall be constituted in every State, Panchayats at the village, intermediate and district
levels in accordance with the provisions of this Part.(2)Notwithstanding anything in clause (1),Constitution of India

Panchayats at the intermediate level may not be constituted in a State having a population not,
exceeding twenty lakhs.
243C. Composition of Panchayats
(1)Subject to the provisions of this Part, the Legislature of a State may, by law, make provisions with
respect to the composition of Panchayats;Provided that the ratio between the population of the
territorial area of a Panchayat at any level and the number of seats in such Panchayat to be filled by
election shall, so far as practicable, be the same throughout the State,(2)All the seats in a Panchayat
shall be filled by persons chosen by direct election from territorial constituencies in the Panchayat
area and, for this purpose, each Panchayat area shall be ided into territorial constituencies in such
manner that the ratio between the population of each constituency and the number of seats allotted
to it shall, so far as practicable, be the same throughout the Panchayat area.(3)The Legislature of a
State may, by law, provide for the representation--(a)of the Chairpersons of the Panchayats at the
village level, in the Panchayats at the intermediate level or, in the case of a State not having
Panchayats at the intermediate level, in the Panchayats at the district level;(b)if the Chairpersons of
the Panchayats at the intermediate level, in the Panchayats at the district level;(c)of the members of
the House of the People and the members of the Legislative Assembly of the State representing
constituencies which comprise wholly or partly a Panchayat area at a level other than the village
level, in such Panchayat;(d)of the members of the Council of States and the members of the
Legislative Council of the State, where they are registered as electors within—(i)a Panchayat area at
the intermediate level, in Panchayat at the intermediate level;(ii)a Panchayat area at the district
level, in Panchayat at the district level.(4)The Chairperson of a Panchayat and other members of a
Panchayat whether or not chosen by direct election from territorial constituencies in the Panchayat
area shall have the right to vote in the meetings of the Panchayats.(5)The Chair person
of--(a)Panchayat at the village level shall be elected in such manner as the Legislature of a State
may, by law, provide; and(b)a Panchayat at the intermediate level or district level, shall be elected
by, and from amongst, the elected members thereof.
243D. Reservation of seats
(1)Seats shall be reserved for--(a)the Scheduled Castes; and(b)the Scheduled Tribes,in every
Panchayat and the number of seats so reserved shall bear, as nearly as may be, the same proportion
to the, total number of seats to be filled by direct election in that Panchayat as the population of the
Scheduled Castes in that Panchayat area or of the Scheduled Tribes in that Panchayat area bears to
the total population of that area and such seats may be allotted by rotation to different
constituencies in a Panchayat.(2)Not less than one-third of the total number of seats reserved under
clause (1) shall be reserved for women belonging, to the Scheduled Castes or, as the case may be, the
Scheduled Tribes.(3)Not less than one-third (including the number of seats reserved for women
belonging to the Scheduled Castes and the Scheduled Tribes) of the total number of seats to be filled
by direct election in every Panchayat shall be reserved for women and such seats may be allotted by
relation to different constituencies in a Panchayat.(4)The offices of the Chairpersons in the
Panchayats at the village or any other level shall be reserved for the Scheduled Castes the Scheduled
Tribes and women in such manner as the Legislature of a State may, by law, provide:Provided thatConstitution of India

the number of offices of Chairpersons reserved for the Scheduled Castes and the Scheduled Tribes in
the Panchayats at each level in any State shall bear, as nearly as may be, the same proportion to the
total number of such offices in the Panchayats at each level as the population of the Scheduled
Castes in the State or of the Scheduled Tribes in the State bears to the total population of the
State:Provided further that not less than one-third of the total number of offices of Chairpersons in
the Panchayats at each level shall be reserved for women:Provided also that the number of offices
reserved under this clause shall be allotted by rotation to different Panchayats at each level.(5)The
reservation of seats under clauses (1) and (2) and the reservation of offices of Chairpersons (other
than the reservation for women) under clause (4) shall cease to have effect on the expiration of the
period specified in article 334 .(6)Nothing in this Part shall prevent the Legislature of a State from
making any provision for reservation of seats in any Panchayat or offices of Chairpersons in the
Panchayats at any level in favour of backward class of citizens.
243E. Duration of Panchayats, etc.
(1)Every Panchayat, unless sooner dissolved under any law for the time being in force, shall
continue for five years from the date appointed for its first meeting and no longer.(2)No amendment
of any law for the time being in force shall have the effect of causing dissolution of a Panchayat at
any level, which is functioning immediately before such amendment, till the expiration of its
duration specified in clause (1).--(3)An election to constitute a Panchayat shall be
completed(a)before the expiry of its duration specified in clause (1);(b)before the expiration of a
period of six months from the date of its dissolution:Provided that where the remainder of the
period for which the dissolved Panchayat would have continued is less than six months, it shall not
be necessary to hold any election under this clause for constituting the Panchayat.(4)A Panchayat
constituted upon the dissolution of a Panchayat before the expiration of its duration shall continue
only for the remainder of the period for which the dissolved Panchayat would have continued under
clause (1) had it not been so dissolved.
243F. Disqualifications for membership
(1)A person shall be disqualified for being chosen as, and for being, a member of a Panchayat--(a)if
he is so disqualified by or under any law for the time being in force for the purposes of elections to
the Legislature of the State concerned:Provided that no person shall be disqualified on the ground
that be is less than twenty-five years of age, if he has attained the age of twenty-one years;(b)if he is
so disqualified by or under any law made by the Legislature of the State.(2)If any question arises as
to whether a member of a Panchayat has become subject to any of the disqualifications mentioned
in clause (1), the question shall be referred for the decision of such authority and in such manner as
the Legislature of a State may, by law, provide.
243G. Powers, authority and responsibilities of Panchayats
Subject to the provisions of this Constitution the Legislature of a State may, by law, endow the
Panchayats with such powers and authority and may be necessary to enable them to function as
institutions of self-government and such law may contain provisions for the devolution of powersConstitution of India

and responsibilities upon Panchayats, at the appropriate level, subject to such conditions as may be
specified therein, with respect to--(a)the preparation of plans for economic development and social
justice;(b)the implementation of schemes for economic development and social justice as may be
entrusted to them including those in relation to the matters listed in the Eleventh Schedule.
243H. Powers to impose taxes by, and funds of, the Panchayats
The Legislature of a State may, by law,--(a)authorize a Panchayat to levy, collect and appropriate
such taxes, duties, tolls and fees in accordance with such procedure and subject to such
limits;(b)assign to a Panchayat such taxes, duties, tolls and fees levied and collected by the State
Government for such purposes and subject to such conditions and limits;(c)provide for making such
grants-in-aid to the Panchayats from the Consolidated Fund of the State; and(d)provide for
constitution of such Funds for crediting all moneys received, respectively, by or on behalf of the
Panchayats and also for the withdrawal of such moneys therefrom, as may be specified in the law.
243I. Constitution of Finance Commissions to review financial position
(1)The Governor of a State shall, as soon as may be within one year from the commencement of the
Constitution (Seventy-third Amendment) Act, 1992, and thereafter at the expiration of every fifth
year, constitute a Finance Commission to review the financial position of the Panchayats and to
make recommendations to the Governor as to--(a)the principles which should govern--(i)the
distribution between the State and the Panchayats of the net proceeds of the taxes, duties, tolls and
fees leviable by the State, which may be ided between them under this Part and the allocation
between the Panchayats at all levels of their respective shares of such proceeds;(ii)the determination
of the taxes, duties, tolls and fees which may be assigned to, or appropriated by, the
Panchayats;(iii)the grants-in-aid to the Panchayats from the Consolidated Fund of the State;(b)the
measures needed to improve the financial position of the Panchayats;(c)any other matter referred to
the Finance Commission by the Governor in the interests of sound finance of the Panchayats.(2)The
Legislature of a State may, by law, provide for the composition of the Commission, the qualifications
which shall be requisite for appointment as members thereof and the manner in which they shall be
selected.(3)The Commission shall determine their procedure and shall have such powers in the
performance of their functions as the Legislature of the State may, by law, confer on them,(4)The
Governor shall cause every recommendation made by the Commission under this article together
with an explanatory memorandum as to the action taken thereon to be laid before the Legislature of
the State.
243J. Audit of accounts of Panchayats
The Legislature of a State may, by law, make provisions with respect to the maintenance of accounts
by the Panchayats and the auditing of such accounts.Constitution of India

243K. Elections to the Panchayats
(1)The superintendence, direction and control of the preparation of electoral rolls for, and the
conduct of, all elections to the Panchayats shall be vested in a State Election Commission consisting
of a State Election Commissioner to be appointed by the Governor.(2)Subject to the provisions of
any law made by the Legislature of a State the conditions of service and tenure of office of the State
Election Commissioner shall be such as the Governor may by rule determine:Provided that the State
Election Commissioner shall not be removed from his office except in like manner and on the like
ground as a Judge of a High Court and the conditions of service of the Slate Election Commissioner
shall not be varied to his disadvantage after his appointment.(3)The Governor of a State shall, when
so requested by the State Election Commission, make available to the State Election Commission
such staff as may be necessary for the discharge of the functions conferred on the State Election
Commission by clause (1).(4)Subject to the provisions of this Constitution, the Legislature of a State
may, by law, make provision with respect to all matters relating to, or in connection with, elections
to the Panchayats.
243L. Application to Union Territories
The provisions of this Part shall apply to the Union territories and shall, in their application to a
Union territory, have effect as if the references to the Governor of a State were references to the
Administrator of the Union territory appointed under 239 and references to the Legislature or the
Legislative Assembly of a State were references, in relation to a Union territory having a Legislative
Assembly, to that Legislative Assembly:Provided that the President may, by public notification,
direct that the provisions of this Part shall apply to any Union territory or part thereof subject to
such exceptions and modifications as he may specify in the notification.
243M. Part not to apply to certain areas
(1)Nothing in this Part shall apply to the Scheduled Areas referred to in clause (1), and the tribal
areas referred to in clause (2), of article 244.(2)Nothing in this Part shall apply to--(a)the States of
Nagaland, Meghalaya and Mizoram;(b)the Hill areas in the State of Manipur for which District
Councils exist under any law for the time being in force.(3)Nothing in this Part--(a)relating to
Panchayats at the district level shall apply to the Hill areas of the District of Darjeeling in the State
of West Bengal for which Darjeeling Gorkha Hill Council exists under any law for the time being in
force;(b)shall be construed to affect the functions and powers of the Darjeeling Gorkha Hill Council
constituted under such law.[Editorial comment-The Constitution (Eighty-third Amendment)
Act,2000, removed the requirement for reservation of seats in Panchayats for members of
Scheduled Castes or Scheduled Tribes in the state of Arunachal Pradesh. This state is exclusively
composed of members of tribal societies. Under the new law, the state's name was changed to
Arunachal Pradesh Tribal Development Council.Also Refer](3A)Nothing in article 243D, relating to
reservation of seats for the Scheduled Castes, shall apply to the State of Arunachal
Pradesh.(4)Notwithstanding anything in this Constitution--(a)the Legislature of a State referred to
in sub-clause (a) of clause (2) may, by law, extend this Part to that State, except the areas, if any,
referred to in clause (1), if the Legislative Assembly of that State passes a resolution to that effect byConstitution of India

a majority of the total membership of that House and by a majority of not less than two-thirds of the
members of that house present and voting;(b)Parliament may, by law, extend the provisions of this
Part to the Scheduled Areas and the tribal areas referred to in clause (1) subject to such exceptions
and modifications as may be specified in such law, and no such law shall be deemed to be an
amendment of this Constitution for the purposes of article 368.
243N. Continuance of existing laws and Panchayats
Notwithstanding anything in this Part, any provision of any law relating to Panchayats in force in a
State immediately before commencement of the Constitution (Seventy-third Amendment) Act, 1992,
which is inconsistent with the provisions of this pan, shall continue to be in force until amended or
repealed by a competent Legislature, other competent authority or until the expiration of one year
from such commencement whichever is earlier:Provided that all the Panchayats existing
immediately before such commencement shall continue till the expiration of their duration, unless
sooner dissolved by a resolution passed to that effect by the Legislative Assembly of that State or, in
the case of a State having a Legislative Council, by each house of the Legislature of that State.
243O. Bar to interference by courts in electoral matters
Notwithstanding anything in this Constitution--(a)the validity of any law relating to the delimitation
of constituencies or the allotment of seals to such constituencies made or purporting to be made
under article 243K, shall not be called in question in any court;(b)no election to any Panchayat shall
be called in question except by an election petition presented to such authority and in such manner
as is provided for by or under any Law made by the legislature of a State.
Part IXA – The Municipalities
243P. Definitions
In this Part, unless the context otherwise requires,--(a)'Committee' means a Committee constituted
under article 243S;(b)'district' means a district in a State;(c)'Metropolitan area' means an area
having a population of ten lakhs or more, comprised in one or more districts and consisting of two
or more Municipalities or Panchayats or other contiguous areas, specified by the Governor by public
notification to be Metropolitan area for the purposes of this Part;(d)'Municipal area' means the
territorial area of a Municipality as is notified by the Governor;(e)'Municipality' means an
institution of self-government constituted under 243Q ;(f)'Panchayat' means a Panchayat
constituted under 243B;(g)'population' means the population as ascertained at the last preceding
census of which the relevant figures have been published.[Editorial comment-The Constitution
(Seventy-fourth Amendment) Act, 1992, dealt with the devolution of power into the systems of
Municipalities or Urban Local Governments. It mandated the setting up and devolution of powers to
Urban local bodies (ULBs) or city governments as the lowest unit of governance in cities and towns.
This landmark initiative of the Government of India was built upon the premise that all ‘power’ in a
democracy rightfully belongs to ‘the people’. Power was mandated to be given to the people via theConstitution of India

local bodies (referred to as municipalities), namely Municipal Corporations, Councils and Nagar
Panchayats, which would have representatives that are elected regularly and have a decisive role in
planning, provision and delivery of services. This Act prescribes institutional changes as well, with
the setting up of Ward Committees, District Planning Committees and Metropolitan Planning
Committees to coordinate planning across jurisdictions, as well as the setting up of State Election
Commissions and State Financial Commissions. Effectively, this act gives ULBs a role much larger
than just that of service providers that provide water, waste management, electricity, and so on.Also
Refer]
243Q. Constitution of Municipalities
(1)There shall be constituted in every State,--(a)a Nagar Panchayat (by whatever name called) for a
transitional area, that is to say, an area in transition from a rural area to an urban area.(b)a
Municipal Council for a smaller urban area; and(c)a Municipal Corporation for a larger urban
area,in accordance with the provisions of this Part:Provided that a Municipality under this clause
may not be constituted in such urban area or part thereof as the Governor may, having regard to the
size of the area and the municipal services being provided or proposed to be provided by an
industrial establishment in that area and such other factors as he may deem fit, by public
notification, specify to be an industrial township.(2)In this article, 'a transitional area', 'a smaller
urban area' or 'a larger urban area' means such area as the Governor may, having regard to the
population of the area, the density of the population therein, the revenue generated for local
administration, the percentage of employment in non-agricultural activities, the economic
importance or such other factors as he may deem fit, specify by public notification for the purposes
of this Part.
243R. Composition of Municipalities
(1)Save as provided in clause (2), all the seats in a Municipality shall be filled by persons chosen by
direct election from the territorial constituencies in the Municipal area and for this purpose each
Municipal area shall be divided into territorial constituencies to be known as wards.(2)The
Legislature of a State may, by law, provide--(a)for the representation in a Municipality
of--(i)persons having special knowledge or experience in Municipal administration;(ii)the members
of the House of the People and the members of the Legislative Assembly of the State representing
constituencies which comprise wholly or partly the Municipal area;(iii)the members of the Council
of States and the members of the Legislative Council of the State registered electors within tile
Municipal area;(iv)the Chairpersons of the Committees constituted under clause (5) of article
243S:Provided that the persons referred to in paragraph (i) shall not have the right to vole in the
meetings of the Municipality;(b)the manner of election of the Chairperson of a Municipality.
243S. Constitution and Composition of Wards Committees, etc.
(1)There shall be constituted Wards Committees, consisting of one or more Wards, within the
territorial area of a Municipality having a population of three lakhs or more.(2)The Legislature of a
State may, by law, make provision with respect to--(a)the composition and the territorial area of aConstitution of India

Wards Committee;(b)the manner in which the seats in a Wards Committee shall be filled.(3)A
member of a Municipality representing a ward within the territorial area of the Wards Committee
shall be a member of that Committee.(4)Where a Wards Committee consists of--(a)one ward, the
member representing that ward in the Municipality; or(b)two or more wards, one of the members
representing such wards in the Municipality elected by the members of the Wards Committee, shall
be the Chairperson of that Committee.(5)Nothing in this article shall be deemed to prevent the
Legislature of a State from making any provision for the Constitution of Committees in addition to
the Wards Committees.
243T. Reservation of seats
(1)Seats shall be reserved for the Scheduled Castes and the Scheduled Tribes in every Municipality
and the number of seats so reserved shall bear, as nearly as may be, the same proportion to the total
number of seats to be filled by direct election in that Municipality as the population of the Scheduled
Castes in the Municipal area or of the Scheduled Tribes in the Municipal area bears to the total
population of that area and such seats may be allotted by rotation to different constituencies in a
Municipality.(2)Not less than one-third of the total number of seats reserved under clause (1) shall
be reserved for women belonging to the Scheduled Castes or, as the case may be, the Scheduled
Tribes(3)Not less than one-third (including the number of seats reserved for women belonging to
the Scheduled Castes and the Scheduled Tribes) of the total number of seats to be filled by direct
election in every Municipality shall be reserved for women and such seats may be allotted by
rotation to different constituencies in a Municipality.(4)The offices of Chairpersons in the
Municipalities shall be reserved for the Scheduled Castes, the Scheduled Tribes and women in such
manner as the Legislature of a State may, by law, provide.(5)The reservation of seats under clauses
(1) and (2) and the reservation of offices of Chairpersons (other than the reservation for women)
under clause (4) shall cease to have effect on the expiration of the period specified in article
334.(6)Nothing in this Part shall prevent the Legislature of a State from making any provision for
reservation of seats in any Municipality or offices of Chairpersons in the Municipalities in favour of
backward class of citizens.
243U. Duration of Municipalities, etc.
(1)Every Municipality, unless sooner dissolved under any law for the time being in force, shall
continue for five years from the date appointed for its first meeting and no longer:Provided that a
Municipality shall be given a reasonable opportunity of being heard before its dissolution.(2)No
amendment of any law for the time being in force shall have the effect of causing dissolution of a
Municipality at any level, which is functioning immediately before such amendment, till the
expiration of its duration specified in clause (1).(3)An election to Constitute a Municipality shall be
completed,--(a)before the expiry of its duration specified in clause (1);(b)before the expiration of a
period of six months from the date of its dissolution:Provided that where the remainder of the
period for which the dissolved Municipality would have continued is less than six months, it shall
not be necessary to hold any election under this clause for constituting the Municipality for such
period.(4)A Municipality constituted upon the dissolution of a Municipality before the expiration of
its duration shall continue only for the remainder of the period for which the dissolved MunicipalityConstitution of India

would leave continued, under, clause (1) had it not been so dissolved.
243V. Disqualifications for membership
(1)A person shall be disqualified for being chosen as, and for being a member of a Municipality--(a)if
he is so disqualified by or under any law for the time being in force for the purposes of elections to
the Legislature of the State concerned: Provided that no person shall be disqualified on the ground
that he is less than twenty-five years of age, if he has attained the age, of twenty-one years;(b)if he is
so disqualified by or under any law made by the Legislature of the State.(2)If any question arises as
to whether a member of a Municipality has become subject to any of the disqualifications mentioned
in clause (1), the question shall be referred for the decision of such authority and in such manner as
the Legislature of a State may, by law, provide.
243W. Powers, authority and responsibilities of Municipalities, etc.
Subject to the provisions of this Constitution, the Legislature of a State may, by law, endow--(a)the
Municipalities with such powers and authority as may be necessary to enable them to function as
institutions of self-government and such law may contain provisions for the devolution of powers
and responsibilities upon Municipalities, subject to such conditions as may be specified therein,
with respect to—(i)the preparation of plans for economic development and social justice;(ii)the
performance of functions and the implementation of schemes as may be entrusted to them including
those in relation to the matters listed in the Twelfth Schedule;(b)the Committees with such powers
and authority as may be necessary to enable them to carry out the responsibilities conferred upon
them including those in relation to the matters listed in the Twelfth Schedule.
243X. Power to impose taxes by, and Funds, of, the Municipalities
The Legislature of a State may, by law--(a)authorise a Municipality to levy, collect and appropriate
such taxes, duties, tolls and fees in accordance with such procedure and subject to such
limits;(b)assign to a Municipality such taxes, duties, tolls and fees levied and collected by the
State-Government for such purposes and subject to such conditions and limits;(c)provide for
making, such grants-in-aid to the Municipalities from the Consolidated Fund of the State;
and(d)provide for constitution of such Funds for crediting all moneys received. respectively, by or
on behalf of the Municipalities and also for the withdrawal of such moneys therefrom, as may be
specified in the law.
243Y. Finance Commission
(1)The Finance Commission constituted under article 243-1 shall also review the financial position
of the Municipalities and make recommendations to the Governor as to-(a)the principles which
should govern--(i)the distribution between the State and the Municipalities of the net proceeds of
the taxes, duties, tolls and fees leviable by the State, which may be divided between them under this
Part and the allocation between the Municipalities at all levels of their respective shares of suchConstitution of India

proceeds;(ii)the determination of the taxes, dudes, tolls and fees which may be assigned to, or
appropriated by, the Municipalities;(iii)the grants-in-aid to the Municipalities from the
Consolidated Fund of the State;(b)the measures needed to improve the financial position of the
Municipalities;(c)any other matter referred to the Finance Commission by the Governor in the
interests of sound finance of the Municipalities.(2)The Governor shall cause every recommendation
made by the Commission under this article together with an explanatory memorandum as to the
action taken thereon to be laid before the Legislature of the State.
243Z. Audit of accounts of Municipalities
The Legislature of a State may, by law, make provisions with respect to the maintenance of accounts
by the Municipalities and the auditing of such accounts.
243ZA. Elections to the Municipalities
(1)The superintendence, direction and control of the preparation of electoral rolls for, and the
conduct of, all elections to the Municipalities shall be vested in the State Election Commission
referred to in article 243K.(2)Subject to provisions of this Constitution, the Legislature of a State
may, bylaw, make provision with respect to all matters relating to, or in connection with, elections to
the Municipalities.
243ZB. Application to Union territories
The Provisions of this Part shall apply to the Union territories and shall, in their application to a
Union territory, have effect as if the references to the Governor of a State were references to the
Administrator of the Union territory appointed under article 239 and references to the Legislature
or the Legislative Assembly of a State were references in relation to a Union territory having a
Legislative Assembly, to that Legislative Assembly:Provided that the President may, by public
notification, direct that the provisions of this Part shall apply to any Union territory or part thereof
subject to such exceptions and modifications as he may specify in the notification.
243ZC. Part not to apply to certain areas
(1)Nothing in this Part shall apply to the Scheduled Areas referred to in Clause (1), and the tribal
areas referred to in Clause (2), of article 244.(2)Nothing in this part shall be construed to affect the
functions and powers of the Darjeeling Gorkha Hill Council constituted under any law for the time
being in force for the hill areas of the district of Darjeeling in the State of West
Bengal.(3)Notwithstanding anything in this Constitution, Parliament may, by law, extend the
provisions of this Part to the Scheduled Areas and the Tribal Areas referred to in clause (1) subject to
such exceptions and modifications as may be specified in such law, and no such law shall be deemed
to be an amendment of this Constitution for the purposes of article 368.Constitution of India

243ZD. Committee for district planning
(1)There shall be constituted in every State at the district level a District Planning Committee to
consolidate the plans prepared by the Panchayats and the Municipalities in the district and to
prepare a draft development plan for the district as a whole.(2)The Legislative of a State may, by
law, make provision with respect to--(a)the composition of the District Planning Committees;(b)the
manner in which the seats in such Committees shall be filled:Provided that not less than four-fifths
of the total number of members of such Committee shall be elected by, and from amongst, the
elected members of the Panchayat at the district level and of the Municipalities in the district in
proportion to the ratio between the population of the rural areas and of the urban areas in the
district;(c)the functions relating to district planning which may be assigned to such
Committees;(d)the manner in which the Chairpersons of such Committees be chosen.(3)Every
District Planning Committee shall, in preparing the draft development plan,--(a)have regard
to--(i)matters of common interest between the Panchayats and the Municipalities including spatial
planning, sharing of water and other physical and natural resources, the integrate development of
infrastructure and environmental conservation;(ii)the extent and type of available resources
whether financial or otherwise;(b)consult such institutions and organizations as the Governor may,
by order, specify.(4)The Chairperson of every District Planning Committee shall forward the
development plan, as recommended by such Committee, to the Government of the State.
243ZE. Committee for Metropolitan Planning
(1)There shall be constituted in every Metropolitan, area a Metropolitan Planning Committee to
prepare a draft development plan for the Metropolitan area as a whole.(2)The Legislature of a State
may, by law, make with respect to--(a)the composition of the Metropolitan Planning
Committees;(b)the manner in which the seats in such Committees shall be filled:Provided that not
less than two-thirds of the members of such Committee shall be elected by, and from amongst, the
elected members of the Municipalities and Chairpersons of the Panchayats in the, Metropolitan area
in proportion to the ratio between the population of the Municipalities and of the Panchayats in that
area;(c)the representation, in such Committees of the Government of India and the Government of
the State and of such organisations and institutions as may be deemed necessary for carrying out the
functions assigned to such Committees;(d)the functions relating to planning and coordination for
the Metropolitan area which may be assigned to such Committees;(e)the manner in which the
Chairpersons of such Committees shall be chosen.(3)Every Metropolitan Planning Committee shall,
in preparing the draft development plan,--(a)have regard to--(i)the plans prepared by the
Municipalities and the Panchayats in the Metropolitan area;(ii)matters of common interest between
the Municipalities and the Panchayats, including co-ordinated spatial planning of the area, sharing
of water and other physical and natural resources, the integrated development of infrastructure and
environmental conservation;(iii)the overall objectives and priorities set by the Government of India
and the Government of the State;(iv)the extent and nature of investments likely to be made in the
Metropolitan area by agencies of the Government of India and of the Government of the State and
other available resources whether financial or otherwise;(b)consult such institutions and
organisations as the Governor may, by order, specify.(4)The Chairperson of every Metropolitan
Planning Committee shall forward the development plan, as recommended by such Committee, toConstitution of India

the Government of the State.
243ZF. Continuance of existing laws and Municipalities
Notwithstanding anything in this Part, any provision of any law relating to Municipalities in force in
a State immediately before the commencement of the Constitution (Seventy-fourth Amendment)
Act, 1992, which is inconsistent with the provisions of this Part, shall continue to be in force until
amended or repealed by a competent Legislature or other competent authority or until the
expiration of one year from such commencement, whichever is earlier:Provided that all the
Municipalities existing immediately before such commencement shall continue till the expiration of
their duration, unless sooner dissolved by a resolution passed to that effect by the Legislative
Assembly of that State or, in the case of a State having a Legislative Council, by each House of the
Legislature of that State.
243ZG. Bar to interference by courts in electoral matters
Notwithstanding anything in this Constitution,--(a)the validity of any law relating to the
delimitation of constituencies or the allotment of seats to such constituencies, made or purporting to
be made under article 243ZF shall not be called in question in any court;(b)no election to any
Municipality shall be called in question expect by an election petition presented to such authority
and in such manner as is provided for by or under any law made by the Legislature of a State.
Part IXB – The Cooperative Societies
243ZH. Definitions
In this Part, unless the context otherwise requires,--(a)"authorised person" means a person referred
to as such in article 243ZQ;(b)"board" means the board of directors or the governing body of a
co-operative society, by whatever name called, to which the direction and control of the
management of the affairs of a society is entrusted to;(c)"co-operative society" means a society
registered or deemed to be registered under any law relating to co-operative societies for the time
being in force in any Stale;(d)"multi-State co-operative society" means a society with objects not
confined to one State and registered or deemed to be registered under any law for the time being in
force relating to such co-operatives;(e)"officer bearer" means a President, Vice-President,
Chairperson, Vice-Chairperson, Secretary or Treasurer of a co-operative society and includes any
other person to be elected by the board of any co-operative society;(f)"Registrar" means the Central
Registrar appointed by the Central Government in relation to the multi-State co-operative societies
and the Registrar for co-operative societies appointed by the State Government under the law made
by the Legislature of a State in relation to co-operative societies;(g)"State Act" means any law made
by the Legislature of a State;(h)"State level co-operative society" means a co-operative society
having its. area of operation extending to the whole of a State and defined as such in any law made
by the Legislature of a State[Editorial comment-The Constitution (Ninety-seventh Amendment)
Act, 2011,defines different terms associated with co-operative societies, namely multi-stateConstitution of India

co-operative society and state-level co-operative society.Also Refer]
243ZI. Incorporation of co-operative societies
Subject to the provisions of this Part, the Legislature of a State may, by law, make provisions with
respect to the incorporation, regulation and winding up of co-operative societies based on the
principles of voluntary formation, democratic member-control, member-economic participation and
autonomous functioning.[Editorial comment-The Constitution (Ninety-seventh Amendment)
Act, 2011,the provision of management, incorporation and ceasing of co-operative society is a matter
of state legislature. Also Refer]
243ZJ. Number and term of members of board and its office bearers
(1)The board shall consist of such number of directors as may be provided by the Legislature of a
State, by law:Provided that the maximum number of directors of a co-operative society shall not
exceed twenty-one:Provided further that the Legislature of a State shall, by law, provide for the
reservation of one seat for the Scheduled Castes or the Scheduled Tribes and two seats for women on
board of every co-operative society consisting of individuals as members and having members from
such class or category of persons.(2)The term of office of elected members of the board and its office
bearers shall be five years from the date of election and the term of office bearers shall be
conterminous with the term of the board:Provided that the board may fill a casual vacancy on the
board by nomination out of the same class of members in respect of which the casual vacancy has
arisen, if the term of office of the board is less than half of its original term.(3)The Legislature of a
State shall, by law, make provisions for co-option of persons to be members of the board having
experience in the field of banking, management, finance or specialisation in any other field relating
to the objects and activities undertaken by the co-operative society, as members of the board of such
society:Provided that the number of such co-opted members shall not exceed two in addition to
twenty-one directors specified in the first proviso to clause (1):Provided further that such co-opted
members shall not have the right to vote in any election of the co-operative society in their capacity
as such member or to be eligible to be elected as office bearers of the board:Provided also that the
functional directors of a co-operative society shall also be the members of the board and such
members shall be excluded for the purpose of counting the total number of directors specified in the
first proviso to clause (1).[Editorial comment-The Constitution (Ninety-seventh Amendment)
Act, 2011,the co-operative societies cannot have more than 21 directors and all the elected office
bearers and members have a fixed term of five years as of the date of the election in respect. Also,
one seat for SC/ST and two seats for women are reserved on every cooperative society’s board. Also
Refer]
243ZK. Election of members of board
(1)Notwithstanding anything contained in any law made by the Legislature of a State, the election of
a board shall be conducted before the expiry of the term of the board so as to ensure that the newly
elected members of the board assume office immediately on the expiry of the office of members of
the outgoing board.(2)The superintendence, direction and control of the preparation of electoralConstitution of India

rolls for, and the conduct of, all elections to a co-operative society shall vest in such an authority or
body, as may be provided by the Legislature of a State, by law:Provided that the Legislature of a
State may, by law, provide for the procedure and guidelines for the conduct of such
elections.[Editorial comment-The Constitution (Ninety-seventh Amendment) Act, 2011,it
ensures that a board election must take place before the end of the board’s term to ensure that the
recently appointed board members take over immediately after the term of the outgoing board
members expires.Also Refer]
243ZL. Supersession and suspension of board and interim management
(1)Notwithstanding anything contained in any law for the time being in force, no board shall be
superseded or kept under suspension for a period exceeding six months:Provided that the board
may be superseded or kept under suspension in case--(i)of its persistent default; or(ii)of negligence
in the performance of its duties; or(iii)the board has committed any act prejudicial to the interests of
the co-operative society or its members; or(iv)there is stalemate in the constitution or functions of
the board; or(v)the authority or body as provided by the Legislature of a State, by law, under clause
(2) of article 243ZK., has failed to conduct elections in accordance with the provisions of the State
Act:Provided further that the board of any such co-operative society shall not be superseded or kept
under suspension where there is no Government shareholding or loan or financial assistance or any
guarantee by the Government:Provided also that in case of a co-operative society carrying on the
business of banking, the provisions of the Banking Regulation Act, 1949(10 of 1949) shall also
apply:Provided also that in case of a co-operative society, other than a multi-State co-operative
society, carrying on the business of banking the provisions of this clause shall have the effect as if for
the words "six months", the words "one year" had been substituted.(2)In case of super session of a
board, the administrator appointed to manage the affairs of such co-operative society shall arrange
for conduct of elections within the period specified in clause (1) and handover the management to
the elected board.(3)The Legislature of a State may, by law, make provisions for the conditions of
service of the administrator.[Editorial comment-The Constitution (Ninety-seventh Amendment)
Act, 2011,the board of directors of the Co-operative Society may be suspended or put on
supersession for up to six months.Also Refer]
243ZM. Audit of accounts of co-operative societies
(1)The Legislature of a Stale may, by law, make provisions with respect to the maintenance of
accounts by the co-operative societies and the auditing of such accounts at least once in each
financial year.(2)The Legislature of a State shall, by law, lay down the minimum qualifications and
experience of auditors and auditing firms that shall be eligible for auditing accounts of the
co-operative societies.(3)Every co-operative society shall cause to be audited by an auditor or
auditing firms referred to in clause (2) appointed by the general body of the cooperative
society:Provided that such auditors or auditing firms shall be appointed from a panel approved by a
State Government or an authority authorised by the State Government in this behalf.(4)The
accounts of every co-operative society shall be audited within six months of the close of the financial
year to which such accounts relate.(5)The audit report of the accounts of an apex co-operative
society, as may be defined by the State Act, shall be laid before the State Legislature in the manner,Constitution of India

as may be provided by the State Legislature, by law.[Editorial comment-The Constitution
(Ninety-seventh Amendment) Act, 2011,the state legislature may include measures requiring
cooperative societies to maintain accounts and have those accounts audited at least once every fiscal
year.Also Refer]
243ZN. Convening of general body meetings
The Legislature of a State may, by law, make provisions that the annual general body meeting of
every co-operative society shall be convened within a period of six months of close of the financial
year to transact the business as may be provided in such law.[Editorial comment-The
Constitution (Ninety-seventh Amendment) Act, 2011,the Society’s General Body Meeting must be
held within six months of the financial year’s end to do any business that may be specified under
such legislation.Also Refer]
243ZO. Right of a member to get information
(1)The Legislature of a State may, by law, provide for access to every member of a co-operative
society to the books, information and accounts of the co-operative society kept in regular transaction
of its business with such member.(2)The Legislature of a State may, by law, make provisions to
ensure the participation of members in the management of the co-operative society providing
minimum requirement of attending meetings by the members and utilising the minimum level of
services as may be provided in such law.(3)The Legislature of a State may, by law, provide for
co-operative education and training for its members.[Editorial comment-The Constitution
(Ninety-seventh Amendment) Act, 2011,the members of cooperative societies have all the right to
access information.Also Refer]
243ZP. Returns
Every co-operative society shall file returns, within six months of the close of every financial year, to
the authority designated by the State Government including the following matters,
namely:--(a)annual report of its activities;(b)its audited statement of accounts;(c)plan for surplus
disposal as approved by the general body of the co-operative society;(d)list of amendments to the
bye-laws of the co-operative society, if any;(e)declaration regarding date of holding of its general
body meeting and conduct of elections when due; and(f)any other information required by the
Registrar in pursuance of any of the provisions of the State Act.[Editorial comment-The
Constitution (Ninety-seventh Amendment) Act, 2011,every member of the cooperative society is
likely to provide file returns to the authorized personnel within six months of the financial year’s
end.Also Refer]
243ZQ. Offences and penalties
(1)The Legislature of a State may, by law, make provisions for the offences relating to the
co-operative societies and penalties for such offences.(2)A law made by the Legislature of a StateConstitution of India

under clause (1) shall include the commission of the following act or omission as offences,
namely:--(a)a co-operative society or an officer or member thereof willfully makes a false return or
furnishes false information, or any person willfully not furnishes any information required from him
by a person authorized in this behalf under the provisions of the State Act;(b)any person willfully or
without any reasonable excuse disobeys any summons, requisition or lawful written order issued
under the provisions of the State Act;(c)any employer who, without sufficient cause, fails to pay to a
cooperative society amount deducted by him from its employee within a period of fourteen days
from the date on which such deduction is made;(d)any officer or custodian who willfully fails to
handover custody of books, accounts, documents, records, cash, security and other property
belonging to a co-operative society of which he is an officer or custodian, to an authorised person;
and(e)whoever, before, during or after the election of members of the board or office bearers, adopts
any corrupt practice.[Editorial comment-The Constitution (Ninety-seventh Amendment) Act,
2011,the provision to offer a penalty for any offence against the cooperative societies.Also Refer]
243ZR. Application to multi-State cooperative societies
The provisions of this Part shall apply to the multi-State co-operative societies subject to the
modification that any reference to "Legislature of a State", "State Act" or "State Government" shall
be construed as a reference to "Parliament", "Central Act" or "the Central Government"
respectively.[Editorial comment-The Constitution (Ninety-seventh Amendment) Act, 2011,
multi-State Cooperative Societies are subject to the provisions of Article 243ZR with the amendment
that State Government, State Act, and State Legislature shall be interpreted as Parliament, Central
Government, or State Act, as applicable.Also Refer]
243ZS. Application to Union territories
The provisions of this Part shall apply to the Union territories and shall, in their application to a
Union territory, having no Legislative Assembly as if the references to the Legislature of a State were
a reference to the administrator thereof appointed under article 239 and, in relation to a Union
territory having a Legislative Assembly, to that Legislative Assembly:Provided that the President
may, by notification in the Official Gazette, direct that the provisions of this Part shall not apply to
any Union territory or part thereof as he may specify in the notification.[Editorial comment-The
Constitution (Ninety-seventh Amendment) Act, 2011,it makes provision for the Union territories
and states that the references to the Legislature of a State in a Union territory with a Legislative
Assembly refer to that Legislative Assembly and that references to the Administrator of that
territory appointed under Article 239 in a Union territory without a Legislative Assembly refer to
that Administrator.Also Refer]
243ZT. Continuance of existing laws
Notwithstanding anything in this Part, any provision of any law relating to co-operative societies in
force in a State immediately before the commencement of the Constitution (Ninety-seventh
Amendment) Act, 2011, which is inconsistent with the provisions of this Part, shall continue to be in
force until amended or repealed by a competent Legislature or other competent authority or untilConstitution of India

the expiration of one year from such commencement, whichever is less.[Editorial comment-The
Constitution (Ninety-seventh Amendment) Act, 2011,no matter what is stated in this Part, any
provision of a law relating to cooperative societies that were in effect in a State before the
Constitution (Ninety-seventh Amendment) Act of 2011 went into effect and conflicts with the
provisions of this Part shall continue to be in effect until revised or revoked by a competent
Legislature or any other authorized person or until the passing of one year after such
commencement, whichever is shorter.Also Refer]
Part X – The Scheduled and Tribal Areas
244. Administration of Scheduled Areas and Tribal Areas
(1)The provisions of the Fifth Schedule shall apply to the administration and control of the
Scheduled Areas and Scheduled Tribes in any State other than the States of Assam Meghalaya,
Tripura and Mizoram.(2)The provisions of the Sixth Schedule shall apply to the administration of
the tribal areas in the state of Assam, Meghalaya, Tripura and Mizoram.[Editorial comment-The
Constitution (Forty-Ninth Amendment) Act, 1984, modifies article 244. The Governor has the
authority to change the titles of the autonomous districts. Furthermore, he also has the authority to
expand or contract their boundaries. The sixth schedule is concerned with managing the tribal lands
in the four northeastern states. Meghalaya, Assam, Tripura, and Mizoram are among these states.
Additionally, it has 10 autonomous district councils spread throughout 4 states. With this
constitutional amendment, Tripura will be recognized as a tribal state. Additionally, permit the
establishment of a Tripura Tribal Areas Autonomous District Council.Also Refer]
244A. Formation of an autonomous State comprising certain tribal areas in
Assam and creation of local Legislature or Council of Ministers or both
therefor
(1)Notwithstanding anything in this Constitution, Parliament may, by law, form within the State of
Assam an autonomous State comprising (whether wholly or in part) all or any of the tribal areas
specified in Part I of the table appended to paragraph 20 of the Sixth Schedule and create
therefor--(a)a body, whether elected or partly nominated and partly elected, to function as a
Legislature for the autonomous Stale, or(b)a Council of Ministers,or both with such constitution,
powers and functions, in each case, as may be specified in the law.(2)Any such law as is referred to
in clause (1) may, in particular,--(a)specify the matters enumerated in the State List or the
Concurrent List with respect to which the Legislature of the autonomous State shall have power to
make laws for the whole or any part thereof, whether to the exclusion of the Legislature of the State
of Assam or otherwise;(b)define the matters with respect to which the executive power of the
autonomous State shall extend;(c)provide that any tax levied by the State of Assam shall be assigned
to the autonomous State in so far as the proceeds thereof are attributable to the autonomous
State;(d)provide that any reference to a Stale in any article of this Constitution shall be construed as
including a reference to the autonomous State; and(e)make such supplemental, incidental and
consequential provisions as may be deemed necessary.(3)An amendment of any such law asConstitution of India

aforesaid in so far as such amendment relates to any of the mailers specified in sub-clause (a) or
sub-clause (b) of clause (2) shall have no effect unless the amendment is passed in each House of
Parliament by not less than two-thirds of the members present and voting.(4)Any such law as is
referred to in this article shall not be deemed to be an amendment of this Constitution for the
purposes of article 368 notwithstanding that it contains any provision which amends or has the
effect of amending this Constitution.[ Editorial comment- The Constitution (Twenty-Two
Amendment) Act, 1969, inserted new article 244A in the Constitution to empower Parliament to
enact a law for constituting an autonomous State within the State of Assam and also to provide the
autonomous State with Legislature or a Council of Ministers or both with such powers and functions
as may be defined by that law. Also refer ]
Part XI – Relations between the Union and the States
245. Extent of laws made by Parliament and by the Legislatures of States
(1)Subject to the provisions of this Constitution, Parliament may make laws for the whole or any
part of the territory of India, and the Legislature of a State may make laws for the whole or any part
of the State.(2)No law made by Parliament shall be deemed to be invalid on the ground that it would
have extra-territorial operation.
246. Subject-matter of laws made by Parliament and by the Legislatures of
States
(1)Notwithstanding anything in clauses (2) and (3), Parliament has exclusive power to make laws
with respect to any of the matters enumerated in List 1 in the Seventh Schedule (in this Constitution
referred to as the "Union List").(2)Notwithstanding anything in clause (3), Parliament and subject
to clause (1), the Legislature of any State also, have power to make laws with respect to any of the
matters enumerated in List III in the Seventh Schedule (in this Constitution referred to as the
"Concurrent List").(3)Subject to clauses (1) and (2), the Legislature of any State has exclusive power
to make laws for such State or any part thereof with respect to any of the matters enumerated in List
II in the Seventh Schedule (in this Constitution referred to as the 'State List').(4)Parliament has
power to make laws with respect to any matter for any part of the territory of India not included in a
State notwithstanding that such matter is a matter enumerated in the State List.
246A. Special provision with respect to goods and services tax.—
(1)Notwithstanding anything contained in articles 246 and 254, Parliament, and, subject to clause
(2), the Legislature of every State, have power to make laws with respect to goods and services tax
imposed by the Union or by such State.(2)Parliament has exclusive power to make laws with respect
to goods and services tax where the supply of goods, or of services, or both takes place in the course
of inter-State trade or commerce.Explanation.—The provisions of this article, shall, in respect of
goods and services tax referred to in clause (5) of article 279A, take effect from the date
recommended by the Goods and Services Tax Council.]Constitution of India

247. Power of Parliament to provide for the establishment of certain
additional courts
Notwithstanding anything in this Chapter, Parliament may by law provide for the establishment of
any additional courts for the better administration of laws made by Parliament or of any existing
laws with respect to a matter enumerated in the Union List.
248. Residuary powers of legislation
(1)Parliament has exclusive power to make any law with respect to any matter not enumerated in
the Concurrent List or State List.(2)Such power shall include the power of making any law imposing
a tax not mentioned in either of those Lists.
249. Power of Parliament to legislate with respect to a matter in the State List
in the national interest
(1)Notwithstanding anything in the foregoing provisions of this Chapter, if the Council of States has
declared by resolution supported by not less than two-thirds of the members present and voting that
it is necessary or expedient in national interest that Parliament should make laws with respect to
[goods and services tax provided under article 246A or] any matter enumerated in the Stale List
specified in the resolution, it shall be lawful for Parliament to make laws for the whole or any part of
the territory of India with respect to that matter while the resolution remains in force.(2)A
resolution passed under clause (1) shall remain in force for such period not exceeding one year as
may be specified therein:Provided that, if and so often as a resolution approving the continuance in
force of any such resolution is passed in the manner provided in clause (1), such resolution shall
continue in force for a further period of one year from the date on which under this clause it would
otherwise have ceased to be in force.(3)A law made by Parliament which Parliament would not but
for the passing of are solution under clause (1) have been competent to make shall, to the extent of
the in competency, cease to have effect on the expiration of a period of six months after the
resolution has ceased to be in force, except as respects things done or omitted to be done before the
expiration of the said period.
250. Power of Parliament to legislate with respect to any matter in the State
List if a Proclamation of Emergency is in operation
(1)Notwithstanding anything in this Chapter, Parliament shall, while a Proclamation of Emergency
is in operation, have, power to make laws for the whole or any part of the territory of India with
respect to [goods and services tax] any of the matters enumerated in the State List.(2)A law made by
Parliament which Parliament would not but for the issue of a Proclamation of Emergency have been
competent to make shall, to the extent of the in competency, cease to have effect on the expiration of
a period of six months after the Proclamation has ceased to operate, except as respects things done
or omitted to be done before the expiration of the said period.Constitution of India

251. Inconsistency between laws made by Parliament under articles 249 and
250 and laws made by the Legislatures of States
Nothing in articles 249 and 250 shall restrict the power of the Legislature of a State to make any law
which under this Constitution it has power to make, but if any provision of a law made by the
legislature of a State is repugnant to any provision of a law made by Parliament which Parliament
has under either of the said articles power to make, the law made by Parliament, whether passed
before or after the law made by the legislature of the State, shall prevail, and the law made by the
Legislature of the State shall to the extent of the repugnancy, but so long only as the law made by
Parliament continues to have effect, be inoperative.
252. Power of Parliament to legislate for two or more States by consent and
adoption of such legislation by any other State
(1)If it appears to the Legislatures of two or more States to be desirable that any of the matters with
respect to which Parliament has no power to make laws for the States except as provided in articles
249 and 250 should be regulated in such States by Parliament by law, and if resolutions to that
effect are passed by all the Houses of the Legislatures of those States, it shall be lawful for
Parliament to pass an Act for regulating that matter accordingly, and any Act so passed shall apply
to such States and to any other State by which it is adopted afterwards by resolution passed in that
behalf by the House or, where there are two Houses, by each of the Houses of the Legislature of that
State.(2)Any Act so passed by Parliament may be amended or repealed by an Act of Parliament
passed or adopted in like manner but shall not, as respects any State to which it applies, be amended
or repealed by an Act of the Legislature of that State.
253. Legislation for giving effect to international agreements
Notwithstanding anything in the foregoing provisions of this Chapter, Parliament has power to
make any law for the whole or any part of the territory of India for implementing any treaty,
agreement or convention with any other country or countries or any decision made at any
international conference, association or other body.
254. Inconsistency between laws made by Parliament and laws made by the
Legislatures of States
(1)If any provision of a law made by the Legislature of a State is repugnant to any provision of a law
made by Parliament which Parliament is competent to enact, or to any provision of an existing law
with respect to one of the matters enumerated in the Concurrent List, then, subject to the provisions
of clause (2), the law made by Parliament, whether passed before or after the law made by the
Legislature of such State, or, as the case may be, the existing law, shall prevail and the law made by
the Legislature of the State shall, to the extent of the repugnancy, be void.(2)Where a law made by
the Legislature of a State with respect to one of the matters enumerated in the Concurrent List
contains any provision repugnant to the provisions of an earlier law made by Parliament or anConstitution of India

existing law with respect to that matter, then, the law so made by the Legislature of such State shall,
if it has been reserved for the consideration of the President and has received his assent, prevail in
that State:Provided that nothing in this clause shall prevent Parliament from enacting at any time
any law with respect to the same matter including a law adding to, amending, varying or repealing
the law so made by the Legislature of the State.
255. Requirements as to recommendations and previous sanctions to be
regarded as matters of procedure only
No Act of Parliament or of the Legislature of a State and no provision in any such Act, shall be
invalid by reason only that some recommendation or previous sanction required by this
Constitution was not given, if assent to that Act was given-(a)where the recommendation required
was that of the Governor, either by the Governor or by the President;(b)where the recommendation
required was that of the Rajpramukh, either by the Rajpramukh or by the President;(c)where the
recommendation or previous sanction required was that of the President, by the President.
256. Obligation of States and the Union
The executive power of every State shall be so exercised as to ensure compliance with the laws made
by Parliament and any existing laws which apply in that State, and the executive power of the Union
shall extend to the giving of such directions to a State as may appear to the Government of India to
be necessary for that purpose.
257. Control of the Union over States in certain cases
(1)The executive power of every State shall be so exercised as not to impede or prejudice the exercise
of the executive power of the Union, and the executive power of the Union shall extend to the giving
of such directions to a State as may appear to the Government of India to be necessary for that
purpose.(2)The executive power of the Union shall also extend to the giving of directions to a State
as to the construction and maintenance of means of communication declared in the direction to be
of national or military importance:Provided that nothing in this clause shall be taken as restricting
the power of Parliament to declare highways or waterways to be national highways or national
waterways so declared or the power of the Union to construct and maintain means of
communication as part of its functions with respect to naval, military and air force works.(3)The
executive power of the Union shall also extend to the giving of directions to a State as to the
measures to be taken for the protection of the railways within the State.(4)Where in carrying out any
direction given to a State under clause (2) as to the construction or maintenance of any means of
communication or under clause (3) as to the measures to be taken for the protection of any railway,
costs have been incurred in excess of those which would have been incurred in the discharge of the
normal duties of the State if such direction had not been given, there shall be paid by the
Government of India to the State such sum as may be agreed, or, in default of agreement, as may be
determined by an arbitrator appointed by the Chief Justice of India, in respect of the extra costs so
incurred by the State.Constitution of India

257A. Assistance to States by deployment of armed forces or other forces of
the Union [Repealed]
Notwithstanding anything in this Constitution, the Parliament may by law provide for the
establishment of any additional courts for the better administration of laws made by Parliament or
of any existing laws with respect to a matter enumerated in the Union List.[Repealed by the
Constitution (Forty-fourth Amendment) Act, 1978, section 33 (w.e.f. 20-6-1979).][Editorial
comment-The Constitution (Forty-Second Amendment) Act, 1976, he President of India was made
to be bound to the Cabinet of Ministers. Under this article Central Forces can be deployed by the
Central Government in states facing law and order discord.Also Refer][Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
258. Power of the Union to confer powers, etc., on States in certain cases
(1)Notwithstanding anything in this Constitution, the President may, with the consent of the
Governor of a Slate, entrust either conditionally or unconditionally to that Government or to its
officers functions in relation to any matter to which the executive power of the Union extends.(2)A
law made by Parliament which applies in any State may, notwithstanding that it relates to a matter
with respect to which the Legislature of the State has no power to make laws, confer powers and
impose duties, or authorise the conferring of powers and the imposition of duties, upon the State or
officers and authorities thereof.(3)Where by virtue of this article powers and duties have been
conferred or imposed upon a State or officers or authorities thereof, there shall be paid by the
Government of India to the State such sum as may be agreed, or, in default of agreement, as may be
determined by an arbitrator appointed by the Chief Justice of India, in respect of any extra costs of
administration incurred by the State in connection with the exercise of those powers and duties.
258A. Power of the States to entrust functions to the Union
Notwithstanding anything in this Constitution, the Governor of a State may, with the consent of the
Government of India, entrust either conditionally or unconditionally to that Government or to its
officers functions in relation to any matter to which the executive power of the State
extends.[Editorial comment-The Constitution (Seventh Amendment) Act, 1956, this deals with
the authority of the President to delegate Union duties to a State Government or its representatives.
The addition of this gave state governors the authority to delegate Union duties to the central
government or its representatives.Also Refer ]Constitution of India

259. Armed Forces in States in Part B of the First Schedule
Repealed by the Constitution (Seventh Amendment) Act, 1956, section 29 and Schedule
260. Jurisdiction of the Union in relation to territories outside India
The Government of India may by agreement with the Government of any territory not being part of
the territory of India undertake any executive, legislative or judicial functions vested in the
Government of such territory, but every such agreement shall be subject to, and governed by, any
law relating to the exercise of foreign jurisdiction for the time being in force.
261. Public acts, records and judicial proceedings
(1)Full faith and credit shall be given throughout the territory of India to public acts, records and
judicial proceedings of the Union and of every State.(2)The manner in which and the conditions
under which the acts, records and proceedings referred to in clause (1) shall be proved and the effect
thereof determined shall be as provided by law made by Parliament.(3)Final judgments or orders
delivered or passed by civil courts in any part of the territory of India shall be capable of execution
any where within that territory according to law.
262. Adjudication of disputes relating to waters, of inter-State rivers or river
valleys
Disputes relating to Waters(1)Parliament may by law provide for the adjudication of any dispute or
complaint with respect to the use, distribution or control of the waters of, or in, any inter-State river
or river valley.(2)Notwithstanding anything in this Constitution, Parliament may by law provide that
neither the Supreme Court nor any other court shall exercise jurisdiction in respect of any such
dispute or complaint as is referred to in clause (1).
263. Provisions with respect to an inter-State Council
Co-ordination between StatesIf at any time it appears to the President that the public interests
would be served by the establishment of a Council charged with the duty of--(a)inquiring into and
advising upon disputes which may have arisen between States;(b)investigating and discussing
subjects in which some or all of the Slates, or the Union and one or more of the States, have a
common interest; or(c)making recommendations upon any such subject and, in particular,
recommendations for the better co-ordination of policy and action with respect to that subject,it
shall be lawful for the President by order to establish such a Council, and to define the nature of the
duties to be performed by it and its organisation and procedure.Constitution of India

Part XII – Finance, Property, Contracts and Suits
264. Interpretation
In this Part, "Finance Commission" means a Finance Commission constituted under article 280.
265. Taxes not to be imposed save by authority of law
No tax shall be levied or collected except by authority of law.
266. Consolidated Funds and public accounts of India and of the States
(1)Subject to the provisions of article 267 and to the provisions of this Chapter with respect to the
assignment of the whole or part of the net proceeds of certain taxes and duties to States, all revenues
received by the Government of India, all loans raised by that Government by the issue of treasury
bills, loans or ways and money advances and all moneys received by that Government in repayment
of loans shall form one consolidated fund to be entitled "the Consolidated Fund of India", and all
revenues received by the Government of a State, all loans raised by that Government by the issue of
treasury bills, loans or ways and money advances and all moneys received by that Government in
repayment of loans shall form one consolidated fund to be entitled "the Consolidated Fund of the
State".(2)All other public moneys received by or on behalf of the Government of India or the
Government of a State shall be credited to the public account of India or the public account of the
State, as the case may be.(3)No moneys out of the Consolidated Fund of India or the Consolidated
Fund of a State shall be appropriated except in accordance with law and for the purposes and in the
manner provided in this Constitution.
267. Contingency Fund
(1)Parliament may by law establish a Contingency Fund in the nature of an imprest to be entitled
"the Contingency Fund of India" into which shall be paid from time to time such sums as may be
determined by such law, and the said Fund shall be placed at the disposal of the President to enable
advances to be made by him out of such Fund for the purposes of meeting unforeseen expenditure
pending authorisation of such expenditure by Parliament by law under article 115 or article
116.(2)The Legislature of a Slate may by law establish a Contingency Fund in the nature of an
imprest to be entitled "the Contingency Fund of the state" into which shall be paid from time to time
such sums as may be determined by such law, and the said Fund shall be placed at the disposal of
the Governor of the State to enable advances to be made by him out of such Fund for the purposes of
meeting unforeseen expenditure pending authorisation of such expenditure by the Legislature of the
State by law under article 205 or article 206.Constitution of India

268. Duties levied by the Union but collected and appropriated by the States
(1)Such stamp duties and such duties of excise on medicinal and toilet preparations as are
mentioned in the Union List shall be levied by the Government of India but shall be collected--(a)in
the case where such duties are leviable within anyUnion territory, by the Government of India,
and(b)in other cases, by the States within which such duties are respectively leviable.(2)The
proceeds in any financial year of any such duty leviable within any State shall not form part of the
Consolidated Fund of India, but shall be assigned to that State.
268A. Service tax levied by Union and collected and appropriated by the
Union and States
(1)Taxes on services shall be levied by Government of India and such tax shall be collected and
appropriated by the Government of India and the States in the manner provided in clause(2).(2)The
proceeds in any financial year of any such tax levies in accordance with the provisions of clause (1)
shall be-(a)collected by the Government of India and the States;(b)appropriated by the Government
of India and the States, in accordance with such principles of collection and appropriation as may be
formulated by Parliament by law.
269. Taxes levied and collected by the Union but assigned to the States
(1)Taxes on the sales or purchase of goods and taxes on the consignment of goods shall be levied and
collected by the Government of India but shall be assigned and shall be deemed to have been
assigned to the Slates on or after the 1st day of April, 1996 in the matter provided in clause
(2).Explanation--For the purposes of this clause,--(a)the expression "taxes on the sale or purchase of
goods" shall mean taxes on sale or purchase of goods other than newspapers, where such sale or
purchase takes place in the course of inter-State trade or commerce;(b)the expression "taxes on the
consignment of goods" shall mean taxes on the consignment of goods (whether the consignment is
to the person making it or to any other person), where such consignment lakes place in the course of
inter-State trade or commerce.(2)The net proceeds in any financial year of any such tax, except in so
far as those proceeds represent proceeds attributable to Union territories, shall not form part of the
Consolidated Fund of India, but shall be assigned to the States within which that tax is leviable in
that year, and shall be distributed among those States in accordance with such principles of
distribution as may be formulated by Parliament by law.[In article 269 of the Constitution, for
clauses (1) and (2), the following clauses shall be substituted through Constitution (Eightieth
Amendment) Act, 2000][The Constitution (Eightieth Amendment) Act, 2000, aims to implement
the Tenth Finance Commission's recommendation to streamline the tax systems by collecting and
distributing all taxes among the states and the federal government. Under the new scheme for
devolution of revenue between the states and the Union, the states will receive grants instead of
income taxes on railway passenger fares and twenty-six percent of the gross proceeds of Union taxes
and duties instead of their current share of income tax, excise duties, and special excise duties.Also
Refer](3)Parliament may by law formulate principles for determining when a sale or purchase of, or
consignment of, goods takes place in the course of inter-State or commerce.[Editorial comment-Constitution of India

The Constitution (Sixth Amendment) Act, 1956, it amendmended in Article 269 where the interstate
selling of commodities other than newspapers is covered by new Article 269(1)(g). Clause (3)
specifies that Parliament must determine what forms an interstate sale. Important Verdict: Bengal
Immunity Co. Ltd. vs State Of Bihar And Ors , The State Of Bombay And Another vs The United
Motors (India)Ltd & Also Refer ][Editorial comment- The Constitution (Forty-Sixth
Amendment) Act, 1982, this amendment modifies articles 269 where clause (1) was changed. This is
done in order for the States to receive the tax assessed on the consignment of commodities through
inter-state trade or commerce. A change is also suggested for that article’s clause (3). This is done to
allow Parliament to establish legal guidelines for identifying when a consignment of commodities
occurs during inter-state trade or commerce.Also Refer]
269A. Levy and collection of goods and services tax in course of inter-State
trade or commerce.—
(1)Goods and services tax on supplies in the course of inter-State trade or commerce shall be levied
and collected by the Government of India and such tax shall be apportioned between the Union and
the States in the manner as may be provided by Parliament by law on the recommendations of the
Goods and Services Tax Council.Explanation.—For the purposes of this clause, supply of goods, or of
services, or both in the course of import into the territory of India shall be deemed to be supply of
goods, or of services, or both in the course of interState trade or commerce.(2)The amount
apportioned to a State under clause (1) shall not form part of the Consolidated Fund of
India.(3)Where an amount collected as tax levied under clause (1) has been used for payment of the
tax levied by a State under article 246A, such amount shall not form part of the Consolidated Fund
of India.(4)Where an amount collected as tax levied by a State under article 246A has been used for
payment of the tax levied under clause (1), such amount shall not form part of the Consolidated
Fund of the State.(5)Parliament may, by law, formulate the principles for determining the place of
supply, and when a supply of goods, or of services, or both takes place in the course of inter-State
trade or commerce
270. Taxes levied and distributed between the Union and the States
(1)All taxes and duties referred to in the Union List, except the duties and taxes referred to in
articles 268 and 269, respectively, surcharge on taxes and duties referred to inarticle 271 and any
cess leviedfor specific purposes under any law made by Parliament shall believed and collected by
the Government of India and shall be distributed between the Union and the States in the manner
provided in clause (2).(2)Such percentage, as may be prescribed, of the net proceeds of any such tax
or duty in any financial year shall not form part of the Consolidated Fund of India, but shall be
assigned to the States within which that tax or duty is leviable in that year, and shall be distributed
among those States in such manner and from such time as may be prescribed in the manner
provided in clause (3).(3)In this article, "prescribed" means--(i)until a Finance Commission has
been constituted, prescribed by the President by order, and(ii)after a Finance Commission has been
constituted, prescribed by the President by order after considering the recommendations of the
Finance Commission;[In article 269 of the Constitution, for clauses (1) and (2), the following clauses
shall be substituted through Constitution (Eightieth Amendment) Act, 2000][EditorialConstitution of India

comment-The Constitution (Eighty-eighth Amendment) Act, 2003, aims to bring about positive
changes in India by strengthening the institutions of government, especially the judiciary, reducing
corruption, and promoting cooperative economic activities. It also gives greater power to the
Parliament to enact laws dealing with anti-national activities. The 88th Amendment of the Indian
Constitution introduces several important changes, including the addition of a new entry in the
Constitution's Seventh Schedule after entry 92B in List I-Union List, called 'Services taxation' (92C).
The suggested amendment aims to increase state revenues under planned regulation and pave the
way for the subsequent integration or inclusion of services under the purview of state-level VAT.Also
Refer][Editorial comment-The Constitution (Ninety-second Amendment) Act, 2003, was an
attempt toward providing national recognition to four languages, namely- Bodo, Dogri, Maithili, and
Santhali. To achieve this, the 8th Schedule of the Indian Constitution had to be revised. Four of
these languages were added to the existing list of languages recognized as official languages. With
this addition, the list now held 22 constitutionally recognized languages. It gave minority languages
the identity of an officially recognized language in the Constitution. This step was noteworthy as it
helped to safeguard not just the primitive and native languages but also the interests of the speakers
of the language.Also Refer]
271. Surcharge on certain duties and taxes for purposes of the Union
Notwithstanding anything in articles 269 and 270, Parliament may at any time increase any of the
duties or taxes referred to in those articles [except the goods and services tax under article 246A,] by
a surcharge for purposes of the Union and the whole proceeds of any such surcharge shall form part
of the Consolidated Fund of India.
272. Taxes which are levied and collected by the Union and may be
distributed between the Union and the States [Repealed ]
Taxes which are levied and collected by the Government of India, and such other duties of customs
and excise as are mentioned in the Union List, shall be levied and collected by the Government of
India and shall be distributed between the Union and the States in the manner provided in this
Chapter.[Repealed by the Constitution (Eightieth Amendment) Act, 2000 (w.e.f. 9-6-2000)]
273. Grants in lieu of export duty on jute and jute products
(1)There shall be charged on the Consolidated Fund of India in each year as grants-in-aid of the
revenues of the States of Assam, Bihar, Odisha and West Bengal, in lieu of assignment of any share
of the net proceeds in each year of export duty on jute and jute products to those States, such sums
as may be prescribed.(2)The sums so prescribed shall continue to be charged on the Consolidated
Fund of India so long as any export duty on jute or jute products continues to be levied by the
Government of India or until the expiration of ten years from the commencement of this
Constitution, whichever is earlier.(3)In this article, the expression "prescribed" has the same
meaning as in article 270.Constitution of India

274. Prior recommendation of President required to Bills affecting taxation in
which States are interested
(1)No Bill or amendment which imposes or varies any tax or duty in which States are interested, or
which varies the meaning of the expression "agricultural income" as defined for the purposes of the
enactments relating to Indian Income-tax, or which affects the principles on which under any of the
foregoing provisions of this Chapter moneys are or may be distributable to State, or which imposes
any surcharge for the purposes of the Union as is mentioned in the foregoing provisions of this
Chapter, shall be introduced or moved in either House of Parliament except on the recommendation
of the President.(2)In this article, the expression "tax or duty-in which States are interested"
means-(a)a tax or duty the whole or part of the net proceeds whereof are assigned to any State;
or(b)a tax or duly by reference to the net proceeds whereof sums are for the time being payable out
of the Consolidated Fund of India to any State.
275. Grants from the Union to certain States
(1)Such sums as Parliament may by law provide shall be charged on the Consolidated Fund of India
in each year as grants-in-aid of the revenues of such States as Parliament may determine to be in
need of assistance, and different sums may be fixed for different States:Provided that there shall be
paid out of the Consolidated Fund of India as grants-in-aid of the revenues of a State such capital
and recurring sums as may be necessary to enable that State to meet the costs of such schemes of
development as may be undertaken by the State with the approval of the Government of India for
the purpose of promoting the welfare of the Scheduled Tribes in that State or raising the level of
administration of the Scheduled Areas therein to that of the administration of the rest of the areas of
that State:Provided further that there shall be paid out of the Consolidated Fund of India as
grants-in-aid of the revenues of the State of Assam sums, capital and recurring, equivalent to--(a)the
average excess of expenditure over the revenues during the two years immediately preceding the
commencement of this Constitution in respect of the administration of the tribal areas specified
inPart I of the table appended to paragraph 20 of the Sixth Schedule; and(b)the costs of such
schemes of development as may be undertaken by that State with the approval of the Government of
India for the purpose of raising the level of administration of the said areas to that of the
administration of the rest of the areas of that State.(1A)On and from the formation of the
autonomous State under article 244A,--(i)any sums payable under clause (a) of the second proviso
to clause (1) shall, if the autonomous State therein, be paid to the autonomous State, and, if the
autonomous State comprises only some of those tribal areas, be apportioned between the State of
Assam and the autonomous State as the President may, by order, specify;(ii)there shall be paid out
of the Consolidated Fund of India as grants-in-aid of the revenues of the autonomous State sums,
capital and recurring, equivalent to the costs of such schemes of development as may be undertaken
by the autonomous State with the approval of the Government of India for the purpose of raising the
level of administration of that State to that of the administration of the rest of the State of
Assam.(2)Until provision is made by Parliament under clause (1), the powers conferred on
Parliament under that clause shall be exercisable by the President by order and any order made by
the President under this clause shall have effect subject to any provision so made by
Parliament:Provided that after a Finance Commission has been constituted no order shall be madeConstitution of India

under this clause by the President except after considering the recommendations of the Finance
Commission.[ Editorial comment- The Constitution (Twenty-Two Amendment) Act, 1969,the
22nd Amendment amended article 275 in regard to sums and grants payable to the autonomous
State on and from its formation under article 244A. Also refer ]
276. Taxes on professions, trades, callings and employments
(1)Notwithstanding anything in article 246, no law of the Legislature of a State relating to taxes for
the benefit of the State or of a municipality, district board, local board or other local authority
therein in respect of professions, trades, callings or employments shall be invalid on the ground that
it relates to a tax on income.(2)The total amount payable in respect of any one person to the State or
to any one municipality, district board, local board or other local authority in the State by way of
taxes on professions, trades, callings and employments shall not exceedtwo thousand and five
hundred rupees per annum:(3)The power of the Legislature of a State to make laws as aforesaid with
respect to taxes on professions, trades, callings and employments shall not be construed as limiting
in any way the power of Parliament to make laws with respect to taxes on income accruing from or
arising out of professions, trades, callings, and employments.[Editorial comment-The
Constitution (Sixtieth Amendment) Act, 1988,was amended for the revision of profession tax by
raising the annual cap from 250 rupees to 2500 rupees. It amended article 276 of the Constitution
relating to taxes on professions, trades, callings and employment. Section 2 of the Act amended
Clause (2) of article 276 of the Constitution to increase the ceiling of tax on professions, trades,
callings and employments from Rupees 250 (equivalent to Rupees 2,400 or US$30 in 2020) per
person per annum to Rupees 2500 per person per annum. It also omitted the proviso to clause (2) of
article 276. Also Refer ]
277. Savings
Any taxes, duties, cesses or fees which, immediately before the commencement of this Constitution,
were being lawfully levied by the Government of any State or by any municipality or other local
authority or body for the purposes of the State, municipality, district or other local area may,
notwithstanding that those taxes, duties, cesses or fees are mentioned in the Union List, continue to
be levied and to be applied to the same purposes until provision to the contrary is made by
Parliament by law.
278. Agreement with States in Part B of the First Schedule with regard to
certain financial matters Repealed
Rep. by the Constitution (Seventh Amendment) Act, 1956, section 29 and Schedule.
279. Calculation of "net proceeds", etc.
(1)In the foregoing provisions of this Chapter, "net proceeds" means in relation to any tax or duty
the proceeds thereof reduced by the cost of collection, and for the purposes of those provisions theConstitution of India

net proceeds of any tax or duty, or of any part of any tax or duty, in or attributable to any area shall
be ascertained and certified by the Comptroller and Auditor-General of India, whose certificate shall
be final.(2)Subject as aforesaid, and to any other express provision of this Chapter, a law made by
Parliament or an order of the President may, in any case where under this Part the proceeds of any
duly or tax are, or may be, assigned to any State, provide for the manner in which the proceeds are
to be calculated, for the lime from or at which and the manner in which any payments are to be
made, for the making of adjustment between one financial year and another, and for any other
incidental or ancillary matters.
279A. Goods and Services Tax Council.—
(1)The President shall, within sixty days from the date of commencement of the Constitution (One
Hundred and First Amendment) Act, 2016, by order, constitute a Council to be called the Goods and
Services Tax Council.(2)The Goods and Services Tax Council shall consist of the following members,
namely:—(a)the Union Finance Minister — Chairperson;(b)the Union Minister of State in charge of
Revenue or Finance — Member;(c)the Minister in charge of Finance or Taxation or any other
Minister nominated by each State Government — Members.(3)The Members of the Goods and
Services Tax Council referred to in sub-clause (c) of clause (2) shall, as soon as may be, choose one
amongst themselves to be the Vice-Chairperson of the Council for such period as they may
decide.(4)The Goods and Services Tax Council shall make recommendations to the Union and the
States on—(a)the taxes, cesses and surcharges levied by the Union, the States and the local bodies
which may be subsumed in the goods and services tax;(b)the goods and services that may be
subjected to, or exempted from, the goods and services tax;(c)model Goods and Services Tax Laws,
principles of levy, apportionment of Goods and Services Tax levied on supplies in the course of
inter-State trade or commerce under article 269A and the principles that govern the place of
supply;(d)the threshold limit of turnover below which goods and services may be exempted from
goods and services tax;(e)the rates including floor rates with bands of goods and services tax ;(f)any
special rate or rates for a specified period, to raise additional resources during any natural calamity
or disaster;(g)special provision with respect to the States of Arunachal Pradesh, Assam, Jammu and
Kashmir, Manipur, Meghalaya, Mizoram, Nagaland, Sikkim, Tripura, Himachal Pradesh and
Uttarakhand; and(h)any other matter relating to the goods and services tax, as the Council may
decide.(5)The Goods and Services Tax Council shall recommend the date on which the goods and
services tax be levied on petroleum crude, high speed diesel, motor spirit (commonly known as
petrol), natural gas and aviation turbine fuel.(6)While discharging the functions conferred by this
article, the Goods and Services Tax Council shall be guided by the need for a harmonised structure
of goods and services tax and for the development of a harmonised national market for goods and
services.(7)One-half of the total number of Members of the Goods and Services Tax Council shall
constitute the quorum at its meetings.(8)The Goods and Services Tax Council shall determine the
procedure in the performance of its functions.(9)Every decision of the Goods and Services Tax
Council shall be taken at a meeting, by a majority of not less than three-fourths of the weighted
votes of the members present and voting, in accordance with the following principles,
namely:—(a)the vote of the Central Government shall have a weightage of one-third of the total
votes cast, and(b)the votes of all the State Governments taken together shall have a weightage of
two-thirds of the total votes cast, in that meeting.(10)No act or proceedings of the Goods andConstitution of India

Services Tax Council shall be invalid merely by reason of—(a)any vacancy in, or any defect in, the
constitution of the Council; or(b)any defect in the appointment of a person as a Member of the
Council; or(c)any procedural irregularity of the Council not affecting the merits of the case.(11)The
Goods and Services Tax Council shall establish a mechanism to adjudicate any dispute—(a)between
the Government of India and one or more States; or(b)between the Government of India and any
State or States on one side and one or more other States on the other side; or(c)between two or more
States, arising out of the recommendations of the Council or implementation thereof.Ins. by the
Constitution (One Hundred and First Amendment) Act, 2016, s. 12 (w.e.f. 12-9-2016)
280. Finance Commission
(1)The President shall, within two years from the commencement of this Constitution and thereafter
at the expiration of every fifth year or at such earlier, time as the President considers necessary, by
order constitute a Finance Commission which shall consist of a Chairman and four other members
to be appointed by the President.(2)Parliament may by law determine the qualifications which shall
be requisite for appointment as members of the Commission and the manner in which they shall be
selected.(3)It shall be the duty of the Commission to make recommendations to the President as
to--(a)the distribution between the Union and the Stales of the net proceeds of taxes which are to be,
or may be, divided between them under this Chapter and the allocation between the States of the
respective shares of such proceeds;(b)the principles which should govern the grants-in-aid of the
revenues of the States out of the Consolidated Fund of India;(bb)the measures needed to augment
the Consolidated Fund of a State to supplement the resources of the Panchayats in the State on the
basis of the recommendations made by the Finance Commission of the State;(c)the measures
needed to augment the Consolidated Fund of a State to supplement the resources of the
Municipalities in the State on the basis of the recommendations made by the Finance Commission
of the State;(d)any other matter referred to the Commission by the President in the interests of
sound finance.(4)The Commission shall determine their procedure and shall have such powers in
the performance of their functions as Parliament may by law confer on them.
281. Recommendations of the Finance Commission
The President shall cause every recommendation made by the Finance Commission under the
provisions of this Constitution together with an explanatory memorandum as to the action taken
thereon to be laid before each House of Parliament.
282. Expenditure defrayable by the Union or a State out of its revenues
The Union or a State may make any grants for any public purpose, notwithstanding that the purpose
is not one with respect to which Parliament or, the Legislature of the State, as the case may be, may
make laws.Constitution of India

283. Custody, etc. of Consolidated Funds, Contingency Funds and moneys
credited to the public accounts
(1)The custody of the Consolidated Fund of India and the Contingency Fund of India, the payment
of moneys into such Funds, the withdrawal of moneys therefrom, the custody of public moneys
other than those credited to such Funds received by or on behalf of the Government of India, their
payment into the public account of India and the withdrawal of moneys from such account and all
other matters connected with or ancillary to matters aforesaid shall be regulated by law made by
Parliament, and, until provision in that behalf is so made, shall be regulated by rules made by the
President.(2)The custody of the Consolidated Fund of a State and the Contingency Fund of a State,
the payment of moneys into such Funds, the withdrawal of moneys therefrom, the custody- of public
moneys other than those credited (o such Funds, received by or on behalf of the Government of the
State, their payment into the public account of the State and withdrawal of moneys from such
account and all other matters connected with or ancillary to matters aforesaid shall be regulated by
law made by the Legislature of the State, and, until provision in that behalf is so made, shall be
regulated by rules made by the Governor of the State.
284. Custody of suitors' deposits and other moneys received by public
servants and courts
All moneys received by or deposited with--(a)any officer employed in connection with the affairs of
the Union or of a State in his capacity as such, other than revenues or public moneys raised or
received by the Government of India or the Government of the State, as the case may be, or(b)any
court within the territory of India to the credit of any cause, matter, account or persons,shall be paid
into the public account of India or the public account of the State, as the case may be.
285. Exemption of property of the Union from State taxation
(1)The property of the Union shall, save in so far as Parliament may by law otherwise provide, be
exempt from all taxes imposed by a State or by any authority within a State.(2)Nothing in clause (I)
shall, until Parliament by law otherwise provides, prevent any authority within a State from levying
any tax on any property of the Union to which such property was immediately before the
commencement of this Constitution liable or treated as liable, so long as that tax continues to be
levied in that State.
286. Restrictions as to imposition of tax on the sale or purchase of goods
(1)No law of a State shall impose, or authorise the imposition of, a tax on the sale or purchase of
goods where such sale or purchase takes place.-(a)outside the State; or(b)in the course of the import
of the goods into, or export of the goods out of, the territory of India.(2)Parliament may by law
formulate principles for determining when a sale or purchase of goods takes place in any of the ways
mentioned in clause (1).(3)Any law of a State shall, in so far as it imposes, or authorises the
imposition of,--(a)a tax on the sale or purchase of goods declared by Parliament by law to be ofConstitution of India

special importance in inter-State trade or commerce; or(b)a tax on the sale or purchase of goods,
being a tax of the nature referred to in sub-clause (b), sub-clause (c) or sub-clause (d) of clause
(29A) of article 366, be subject to such restrictions and conditions in regard to the system of levy,
rates and other incidents of the tax as Parliament may by law specify.[Editorial comment- The
Constitution (Sixth Amendment) Act, 1956, amended article 286 by introducing Clause 286(2),
stating parliament can enact a law to determine when the sale takes place under clause(1). Clause
286(3) was added, stating that any state law imposing a tax on goods deemed essential by the
legislature is bound by the restrictions of the legislation enacted by the Parliament in this regard.
Important Verdict: Bengal Immunity Co. Ltd. vs State Of Bihar And Ors , The State Of Bombay And
Another vs The United Motors (India)Ltd & Also Refer ][Editorial comment- The Constitution
(Forty-Sixth Amendment) Act, 1982, this amendment modifies article 286 where clause (3) was
changed. This is done to give Parliament the ability to set rules and conditions for the manner of
levy, rates, and other aspects of the tax on the delivery of goods under a hire-purchase agreement or
any other system of payment by installments, as well as on the authority to use any products, by
law.Also Refer]
287. Exemption from taxes on electricity
Save in so far as Parliament may by law otherwise provide, no law of a State shall impose, or
authorise the imposition of, a tax on the consumption or sale of electricity (whether produced by a
Government or other persons) which is.-(a)consumed by the Government of India, or sold to the
Government of India for consumption by that Government; or(b)consumed in the construction,
maintenance or operation of any railway by the Government of India or a railway company
operating that railway, or sold to that Government or any such railway company for consumption in
the construction, maintenance or operation of any railway, and any such law imposing, or
authorising the imposition of, a tax on the sale of electricity shall secure that the price of electricity
sold to the Government of India for consumption by that Government, or to any such railway
company as aforesaid for consumption in the construction, maintenance or operation of any
railway, shall be less by the amount of the tax than the price charged to other consumers of a
substantial quantity of electricity.
288. Exemption from taxation by States in respect of water or electricity in
certain cases
(1)Save in so far as the President may by order otherwise provide, no law of a State in force
immediately before the commencement of this Constitution shall impose, or authorise the
imposition of, a tax in respect of any water or electricity stored, generated, consumed, distributed or
sold by any authority established by any existing law or any law made by Parliament for regulating
or developing any inter-State river or river-valley.Explanation--The expression "law of a State in
force" in this clause shall include a law of a Stale passed or made before the commencement of this
Constitution and not previously repealed, notwithstanding that it or parts of it may not be then in
operation either at all or in particular areas.(2)The Legislature of a State may by law impose, or
authorise the imposition of, any such tax as is mentioned in clause (1), but no such law shall have
any effect unless it has, after having been reserved for the consideration of the President received hisConstitution of India

assent; and if any such law provides for the fixation of the rates and other incidents of such tax by
means of rules or orders to be made under the law by any authority, the law shall provide for the
previous consent of the President being obtained to the making of any such rule or order.
289. Exemption of property and income of a State from Union taxation
(1)The property and income of a State shall be exempt from Union taxation.(2)Nothing in clause (1)
shall prevent the Union from imposing, or authorising the imposition of, any tax to such extent, if
any, as Parliament may by law provide in respect of a trade or business of any kind carried on by, or
on behalf of, the Government of a State, or any operations connected therewith, or any property
used or occupied for the purposes of such trade or business, or any income accruing or arising in
connection therewith.(3)Nothing in clause (2) shall apply to any trade or business, or to any class of
trade or business, which Parliament may by law declare to be incidental to the ordinary functions of
Government.
290. Adjustment in respect of certain expenses and pensions
Where under the provisions of this Constitution the expenses of any court or Commission, or the
pension payable to or in respect of a person who has served before the commencement of this
Constitution under the Crown in India or after such commencement in connection with the affairs of
the Union or of a State, are charged on the Consolidated Fund of India orthe Consolidated Fund of a
State, then, if--(a)in the case of a charge on the Consolidated Fund of India, the court or
Commission serves any of the separate needs of a State, or the person has served wholly or in part in
connection with the affairs of a State; or(b)in the case of a charge on the Consolidated Fund of a
State, the court or Commission serves any of the separate needs of the Union or another State, or the
person has served wholly or in part in connection with the affairs of the Union or another State,
there shall be charged on and paid out of the Consolidated Fund of the State or, as the case may be,
the Consolidated Fund of India or the Consolidated Fund of the other State, such contribution in
respect of the expenses or pension as may be agreed, or as may in default of agreement be
determined by an arbitrator to be appointed by the Chief Justice of India.
290A. Annual payment to certain Devaswom Funds
A sum of forty-six lakhs and fifty thousand rupees shall be charged on, and paid out of, the
Consolidated Fund of the State of Kerala every year to the Travancore Devaswom Fund; and a sum
of thirteen lakhs and fifty thousand rupees shall be charged on, and paid out of the Consolidated
Fund of the State ofTamil Nadu, every year to the Devaswom Fund established in that State for the
maintenance of Hindu temples and shrines in the territories transferred to that State on the 1st day
of November, 1956, from the State of Travancore-Cochin.[Editorial comment- The Constitution
(Seventh Amendment) Act, 1956, to guarantee yearly payment to specific Devaswom Funds, this was
included. These funds came from the State of Kerala and the State of Madras’ Consolidated Fund.
This was done to keep the Hindu temples and shrines in the areas that were ceded to that State in
good condition. Also Refer ]Constitution of India

291. Privy purse sums of Rulers [REPEALED]
(1)Where under any covenant or agreement entered into by the Ruler of any Indian State before the
commencement of this Constitution, the payment of any sums, free of tax, has been guaranteed or
assured by the Government of the Dominion of India to any Ruler of such State as privy
purse—(a)such sums shall be charged on, and paid out of, the Consolidated Fund of India;
and(b)the sums so paid to any Ruler shall be exempt from all taxes on income.(2)Where the
territories of any such Indian State as aforesaid are comprised within a State specified in Part A or
Part B of the First Schedule, there shall be charged on, and paid out of, the Consolidated Fund of
that State such contribution, if any, in respect of the payments made by the Government of India
under clause (1) and for such period as may, subject to any agreement entered into in that behalf
under clause (1) of article 278, be determined by order of the President.[Repealed by the
Constitution (Twenty-sixth Amendment) Act, 1971.][Editorial comment-The Constitution
(Twenty-Sixth Amendment) Act, 1971, the 26th Amendment of Indian Constitution of 1971 removed
Articles 291. The former dealt with the details of privy purse sums and the latter guaranteed specific
rights and privileges to rulers of princely states. The ‘privy purse’ was guaranteed by Articles 291 in
the Indian constitution, which ensured that princes would receive tax-free privy purses, equivalent
to one-fourth of the money they earned earlier. Thus, with the omission of Articles 291, the privy
purse which was paid to former princely states was removed.Important Verdict-Shri Raghunathrao
Ganpatrao vs Union Of India ]
292. Borrowing by the Government of India
The executive power of the Union extends to borrowing upon the security of the Consolidated Fund
of India within such limits, if any, as may from time to time be fixed by Parliament by law and to the
giving of guarantees within such limits, if any, as may be so fixed.
293. Borrowing by States
(1)Subject to the provisions of this article, the executive power of a State extends to borrowing
within the territory of India upon the security of the Consolidated Fund of the State within such
limits, if any, as may from time to time be fixed by the Legislature of such State by law and to the
giving of guarantees within such limits, if any, as may be so fixed.(2)The Government of India may,
subject to such conditions as may be laid down by or under any law made by Parliament, make loans
to any State or, so long as any limits fixed under article 292 are not exceeded, give guarantees in
respect of loans raised by any State, and any sums required for the purpose of making such loans
shall be charged on the Consolidated Fund of India.(3)A State may not without the consent of the
Government of India raise any loan if there is still outstanding any part of a loan which has been
made to the State by the Government of India or by its predecessor Government, or in respect of
which a guarantee has been given by the Government of India or by its predecessor
Government.(4)A consent under clause (3) may be granted subject to such conditions, if any, as the
Government of India may think fit to impose.Constitution of India

294. Succession to property, assets, rights, liabilities and obligations in
certain cases
As from the commencement of this Constitution--(a)all property and assets which immediately
before such commencement were vested in His Majesty for the purposes of the Government of the
Dominion of India and all property and assets which immediately before such commencement were
vested in His Majesty for the purposes of the Government of each Governor's Province shall vest
respectively in the Union and the corresponding State, and(b)all rights, liabilities and obligations of
the Government of the Dominion of India and of the Government of each Governor's Province,
whether arising out of any contract or otherwise, shall be the rights, liabilities and obligations
respectively of the Government of India and the Government of each corresponding State,subject to
any adjustment made or to be made by reason of me creation before the commencement of this
Constitution of the Dominion of Pakistan or of the Provinces of West Bengal, West Punjab and East
Punjab.
295. Succession to property, assets, rights, liabilities and obligations in other
cases
(1)As from the commencement of this Constitution--(a)all property and assets which immediately
before such commencement were vested in any Indian State corresponding to a State specified in
Part B of the First Schedule shall vest in the Union, if the purposes for which such property and
assets were held immediately before such commencement will thereafter be purposes of the Union
relating to any of the matters enumerated in the Union List, and(b)all rights, liabilities and
obligations of the Government of any Indian State corresponding to a State specified in Part B of the
First Schedule, whether arising out of any contract or otherwise, shall be the rights, liabilities and
obligations of the Government of India, if the purposes for which such rights were acquired or
liabilities or obligations were incurred before such commencement will thereafter be purposes of the
Government of India relating to any of the matters enumerated in the Union List, subject to any
agreement entered into in that behalf by the Government of India with the Government of that
State.(2)Subject as aforesaid, the Government of each State specified in Part B of the First Schedule
shall, as from the commencement of this Constitution, be the successor of the Government of the
corresponding Indian State as regards all properly and assets and all rights, liabilities and
obligations, whether arising out of any contract or otherwise, other than those referred to in clause
(1).
296. Property accruing by escheat or lapse or as bona vacantia
Subject as hereinafter provided any property in the territory of India which, if this Constitution had
not come into operation, would have accrued to His Majesty or, as the case may be, to the Ruler of
an Indian State by escheat or lapse, or as bona vacantia for want of a rightful owner, shall, if it is
property situate in a State, vest in such State, and shall, in any other case, vest in the
Union:Provided that any property which at the date when it would have so accrued to His Majesty or
to the Ruler of an Indian State was in the possession or under the control of the Government ofConstitution of India

India or the Government of a State shall, according as the purposes for which it was then used or
held were purposes of the Union or a State, vest in the Union or in that State.Explanation.--In the
article, the expressions "Ruler" and "Indian Slate" have the same meanings as in article 363.
297. Things of value within territorial waters or continental shelf and
resources of the exclusive economic zone to vest in the Union
(1)All lands, minerals and other things of value underlying the ocean within the territorial waters, or
the continental shelf, or the exclusive economic zone, of India shall vest in the Union and be held for
the purposes of the Union.(2)All other resources of the exclusive economic zone of India shall also
vest in the Union and be held for the purposes of the Union.(3)The limits of the territorial waters,
the continental shelf, the exclusive economic zone, and other maritime zones, of India shall be such
as may be specified, from time to time, by or under any law made by Parliament.[Editorial
comment-The Constitution (Fifteenth Amendment) Act, 1963, by this amendment they revised the
phrase “or the continental shelf” will be added. This addition would follow the words “territorial
waters” from the previous version of the article.][Editorial comment-The Constitution (Fortieth
Amendment) Act, 1976, gave the Parliament the power to periodically define India's territorial seas,
continental shelf, exclusive economic zone (EEZ), and maritime zones. This amendment modified
Article 297 of the Constitution. It empowered the Parliament to periodically specify the boundaries
of India’s continental shelf, territorial seas, exclusive economic zone (EEZ), and marine zones."Also
Refer]
298. Power to carry on trade, etc.
The executive power of the Union and of each State shall extend to the carrying on of any trade or
business and to the acquisition, holding and disposal of property and the making of contracts for
any purpose:Provided that--(a)the said executive power of the Union shall, in so far as such trade or
business or such purpose is not one with respect to which Parliament may make laws, be subject in
each State to legislation by the State; and(b)the said executive power of each State shall, in so far as
such trade or business or such purpose is not one with respect to which the State Legislature may
make laws, be subject to legislation by Parliament.[Editorial comment- The Constitution
(Seventh Amendment) Act, 1956, it substitute strengthened the ability of the Union and State
governments to undertake trade and business. Also Refer ]
299. Contracts
(1)All contracts made in the exercise of the executive power of the Union or of a State shall be
expressed to be made by the President, or by the Governor of the State, as the case may be, and all
such contracts and all assurances of property made in the exercise of that power shall be executed
on behalf of the President or the Governor by such persons and in such manner as he may direct or
authorise.(2)Neither the President nor the Governor shall be personally liable in respect of any
contract or assurance made or executed for the purposes of this Constitution, or for the purposes of
any enactment relating to the Government of India heretofore in force, nor shall any person makingConstitution of India

or executing any such contract or assurance on behalf of any of them be personally liable in respect
thereof.
300. Suits and proceedings
(1)The Government of India may sue or be sued by the name of the Union of India and the
Government of a State may sue or be sued by the name of the State and may, subject to any
provisions which may be made by Act of Parliament or of the Legislature of such State enacted by
virtue of powers conferred by this Constitution, sue to be used in relation to their respective affairs
in the like cases as the Dominion of India and the corresponding Provinces or the corresponding
Indian States might have sued or been sued if this Constitution had not been enacted.(2)If at the
commencement of this Constitution--(a)any legal proceedings are pending to which the Dominion
of India is a party, the Union of India shall be deemed to be substituted for the Dominion in those
proceedings; and(b)any legal proceedings are pending to which a Province or an Indian State is a
party, the corresponding Slate shall be deemed to be substituted for the Province or the Indian State
in those proceedings.[Editorial comment-The Constitution (Thirty-First Amendment) Act, 1973,
Article 330 of the Indian Constitution was held inapplicable for the tribal areas of Meghalaya,
Mizoram, Nagaland, Arunachal Pradesh; and Assam due to their significant tribal population.Also
Refer]
300A. Persons not to be deprived of property save by authority of law
No person shall be deprived of his property save by authority of law.[Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
Part XIII – Trade, Commerce and Intercourse within the territory
of India
301. Freedom of trade, commerce and intercourse
Subject to the other provisions of this Part, trade, commerce and intercourse throughout the
territory of India shall be free.
302. Power of Parliament to impose restrictions on trade, commerce and
intercourseConstitution of India

Parliament may by law impose such restrictions on the freedom of trade, commerce or intercourse
between one State and another or within any part of the territory of India as may be required in the
public interest.
303. Restrictions on the legislative powers of the Union and of the States
with regard to trade and commerce
(1)Notwithstanding anything in article 302, neither Parliament nor the Legislature of a State shall
have power to make any law giving, or authorising the giving of, any preference to one State over
another, or making, or authorising the making of, any discrimination between one State and
another, by virtue of any entry relating to trade and commerce in any of the Lists in the Seventh
Schedule.(2)Nothing in clause (1) shall prevent Parliament from making any law giving, or
authorising the giving of, any preference or making, or authorising the making of, any
discrimination if it is declared by such law that it is necessary to do so for the purpose of dealing
with a situation arising from scarcity of goods in any part of the territory of India.
304. Restrictions on trade, commerce and intercourse among States
Notwithstanding anything in article 301 or article 303, the Legislature of a State may by
law--(a)impose on goods imported from other Statesor the Union territories any tax to which similar
goods manufactured or produced in that State are subject, so, however, as not to discriminate
between goods so imported and goods so manufactured or produced; and(b)impose such reasonable
restrictions on the freedom of trade, commerce or intercourse with or within that State as may be
required in the public interest:Provided that no Bill or amendment for the purposes of clause (b)
shall be introduced or moved in the Legislature of a State without the previous sanction of the
President.
305. Saving of existing laws and laws providing for State monopolies
[For article 305 of the Constitution, the following article shall be substituted through Constitution
(Fourth Amendment) Act, 1955]Nothing in articles 301 and 303 shall affect the provisions of any
existing law except in so far as the President may by order otherwise direct; and nothing in article
301 shall affect the operation of any law made before the commencement of the Constitution
(Fourth Amendment) Act, 1955 , in so far as it relates to, or prevent Parliament or the Legislature of
a State from making any law relating to, any such matter as is referred to in sub-clause (ii) of clause
( 6 ) of article 19 .[Editorial Comment- The Constitution (Fourth Amendment) Act, 1955,
amended Article 305, empowering the State to nationalize any trade. It allows for the State’s
monopoly of commerce, which is protected from criticism for violating paragraphs 301 and 303. ]}}
306. Power of certain States in Part B of the First Schedule to impose
restrictions on trade and commerce RepealedConstitution of India

Rep. by the Constitution (Seventh Amendment) Act, 1956, section 29 and Schedule (w.e.f.
01-11-1956)
307. Appointment of authority for carrying out the purposes of articles 301 to
304
Parliament may by law appoint such authority as it considers appropriate for carrying out the
purposes of articles 301, 302, 303 and 304, and confer on the authority so appointed such powers
and such duties as it thinks necessary.
Part XIV – Services under the Union and the States
308. Interpretation
In this Part, unless the context otherwise requires, the expression "State"does not include the State
of Jammu and Kashmir.
309. Recruitment and conditions of service of persons serving the Union or a
State
Subject to the provisions of this Constitution, Acts of the appropriate Legislature may regulate the
recruitment, and conditions of service of persons appointed, to public services and posts in
connection with the affairs of the Union or of any State:Provided that it shall be competent for the
President or such person as he may direct in the case of services and posts in connection with the
affairs of the Union, and for the Governor of a State or such person as he may direct in the case of
services and posts in connection with the affairs of the State, to make rules regulating the
recruitment, and the conditions of service of persons appointed, to such services and posts until
provision in that behalf is made by or under an Act of the appropriate Legislature under this article,
and any rules so made shall have effect subject to the provisions of any such Act.
310. Tenure of office of persons serving the Union or a State
(1)Except as expressly provided by this Constitution, every person who is a member of a defence
service or of a civil service of the Union or of an all-India service or holds any post connected with
defence or any civil post under the Union, holds office during the pleasure of the President, and
every person who is a member of a civil service of a State or holds any civil post under a State holds
office during the pleasure of the Governor of the State.(2)Notwithstanding that a person holding a
civil post under the Union or a State holds office during the pleasure of the President or, as the case
may be, of the Governor of the State, any contract under which a person, not being a member of a
defence service or of an all-India service or of a civil service of the Union or a State, is appointed
under this Constitution to hold such a post may, if the President or the Governor as the case may be,
deems it necessary in order to secure the services of a person having special qualifications, provide
for the payment to him of compensation, if before the expiration of an agreed period, that post isConstitution of India

abolished or he is, for reasons not connected with any misconduct on his part, required to vacate
that post.
311. Dismissal, removal or reduction in rank of persons employed in civil
capacities under the Union or a State
(1)No person who is a member of a civil service of the Union or an al l.India service or a civil service
of a State or holds a civil post under the Union or a Slate shall be dismissed or removed by a
authority subordinate to that by which he was appointed.(2)No such person as aforesaid shall be
dismissed or removed or reduced in rank except after an inquiry in which he has been informed of
the charges against hi m and given a reasonable opportunity of being heard in respect of those
charges;Provided that where it is proposed after such inquiry, to impose upon him any such penalty,
such penalty may be imposed on the basis of the evidence adduced during such inquiry and it shall
not be necessary to give such person any opportunity of making representation on the penalty
proposed:Provided further that this clause shall not apply--(a)where a person is dismissed or
removed or reduced in rank on the ground of conduct which has led to hi s conviction on a criminal
charge; or(b)where the authority empowered to dismiss or remove a person or to reduce him in rank
is satisfied that for some reason, to be recorded by that authority in writing, it is not reasonably
practicable to hold such inquiry; or(c)where the President or the Governor, as the case may be, is
satisfied that in the interest of the security of the State, it is not expedient to hold such inquiry.(3)If,
in respect of any such person as aforesaid, a question arises whether it is reasonably practicable to
hold such inquiry as is referred to in clause (2), the decision thereon of the authority empowered to
dismiss or remove such person or to reduce him in rank shall be final.[Editorial comment-The
Constitution (Fifteenth Amendment) Act, 1963, through this amendment a new clause was
introduced in place of the existing clauses (2) and (3). This was done to ensure that any civil servant
facing a proposed action of dismissal, removal, or reduction in rank on the ground of conduct is
informed of the charges and given a reasonable opportunity to be heard at the inquiry stage. But,
when the action is taking place, the civil servant’s reasonable opportunity would be limited to
making a representation based on the evidence presented.]
312. All-India Services
(1)Notwithstanding anything in Chapter VI of Part VI or Part XI, if the Council of States has
declared by resolution supported by not less than two-thirds of the members present and voting that
it is necessary or expedient in the national interest so to do, Parliament may by law provide for the
creation of one or more all-India services (including an all-India judicial service) common to the
Union and the States, and, subject to the other provisions of this Chapter, regulate the recruitment,
and the conditions of service of persons appointed, to any such service.(2)The services known at the
commencement of this Constitution as the Indian Administrative Service and the Indian Police
Service shall be deemed to be services created by Parliament under this article.(3)The all-India
judicial service referred to in clause (1) shall not include any post inferior to that of a district judge
as defined in article 236.(4)The law providing for the creation of the all-India judicial service
aforesaid may contain such provisions for the amendment of Chapter VI of Part VI as may be
necessary for giving effect to the provisions of that law and no such law shall be deemed to be anConstitution of India

amendment of this Constitution for the purposes of article 368.[Editorial comment-The
Constitution (Forty-Second Amendment) Act, 1976, which makes the provision for All India Services
was amended to include the All-India Judicial Service. Also Refer]
312A. Power of Parliament to vary or revoke conditions of service of officers
of certain services
[After article 312 of the Constitution, the following article shall be inserted Constitution
(Twenty-Eighth Amendment) Act, 1972](1)Parliament may by law--(a)vary or revoke, whether
prospectively or retrospectively, the conditions of service as respects remuneration, leave and
pension and the rights as respects disciplinary matters of persons who, having been appointed by
the Secretary of State or Secretary of State in Council to a civil service of the Crown in India before
the commencement of this Constitution, continue on and after the commencement of the
Constitution (Twenty-eighth Amendment) Act, 1972, to serve under the Government of India or of a
State in any service or post;(b)vary or revoke, whether prospectively or retrospectively, the
conditions of service as respects pension of persons who, having been appointed by the Secretary of
State or Secretary of State in Council to a civil service of the Crown in India before the
commencement of this Constitution, retired or otherwise ceased to be in service at any time before
the commencement of the Constitution (Twenty-eighth Amendment) Act, 1972:Provided that in the
case of any such person who is holding or has held the office of the Chief Justice or other Judge of
the Supreme Court or a High Court, the Comptroller and Auditor-General of India, the Chairman or
other members of the Union or a State Public Service Commission or the Chief Election
Commissioner, nothing in sub-clause (a) or sub-clause (b) shall be construed as empowering
Parliament to vary or revoke, after his appointment to such post, the condition of his service to his
disadvantage except in so far as such conditions of his service to his disadvantage except in so far as
such condition of service are applicable to him by reason of his being a person appointed by the
Secretary of State or Secretary of State in Council to a civil service of the Crown in India.(2)Except to
the extent provided for by Parliament by law under this article, nothing in this article shell affect the
power of any Legislature or other authority under any other provision of this Constitution to
regulate the conditions of service of persons referred to in clause (1).(3)Neither the Supreme Court
nor any other court shall have jurisdiction in--(a)any dispute arising out of any provision of, or any
endorsement on, any covenant, agreement or other similar instrument which was entered into or
executed by any person referred to in clause (1), or arising out of any letter issued to such person, in
relation to his appointment to any civil service of the Crown in India or his continuance in service
under the Government of the Dominion of India or a Province thereof;(b)any dispute in respect of
any right, liability or obligation under article 314 as originally enacted.(4)The provisions of the
article shall have effect notwithstanding anything in article 314 as originally enacted or in any other
provision of this Constitution.[Editorial comment-The Constitution (Twenty-Eighth
Amendment) Act, 1972, addressed the service conditions of All-India service officers, including
pensions, leave, remuneration, and other rights that had previously made these officials immutable.
As the social order in India changed in the two decades following independence, amendments were
necessary to update the conditions of service for these officials. The amendment inserted a new
Article 312A after Article 312 changing the service conditions and providing for disciplinary matters
related to people employed in the services.Also Refer]Constitution of India

313. Transitional provisions
Until other provision is made in this behalf under this Constitution, all the laws in force immediately
before the commencement of this Constitution and applicable to any public service or any post
which continues to exist after the commencement of service or post under the Union or a State shall
continue in force so far as consistent with the provisions of this Constitution.
314. Provision for protection of existing officers of certain services
[REPEALED]
Except as otherwise expressly provided by this Constitution, every person who having been
appointed by the Secretary of State or Secretary of State in Council to a civil service of the Crown in
India continues on and after the commencement of this Constitution to serve under the Government
of India or of a State shall be entitled to receive from the Government of India and the Government
of the State, which he is from time to time serving, the same conditions of service as respects
remuneration, leave and pension, and the same rights as respects disciplinary matters or rights as
similar thereto as changed circumstances may permit as that person was entitled to immediately
before such commencement.[Rep. by the Constitution (Twenty-eighth Amendment) Act, 7972,
section 3 (w.e.f. 29-8-1972).][Editorial comment-The Constitution (Twenty-Eighth Amendment)
Act, 1972, addressed the service conditions of All-India service officers, including pensions, leave,
remuneration, and other rights that had previously made these officials immutable. As the social
order in India changed in the two decades following independence, amendments were necessary to
update the conditions of service for these officials. The amendment repealed the original Article 314,
changing the service conditions and providing for disciplinary matters related to people employed in
the services.Also Refer]
315. Public Service Commissions for the Union and for the States
(1)Subject to the provisions of this article, there shall be a Public Service Commission for the Union
and a Public Service Commission for each State.(2)Two or more States may agree that there shall be
one Public Service Commission for that group of States, and if a resolution to that effect is passed by
the House or, where there are two Houses, by each House of the Legislature of each of those States,
Parliament may by law provide for the appointment of a Joint State Public Service Commission
(referred to in this Chapter as Joint Commission) to serve the needs of those States,(3)Any such law
as aforesaid may contain such incidental and consequential provisions as may be necessary or
desirable for giving effect to the purposes of the law.(4)The Public Service Commission for the
Union, if requested so to do by the Governor of a State, may, with the approval of the President,
agree to serve all or any of the needs of the State.(5)References in this Constitution to the Union
Public Service Commission or a State Public Service Commission shall, unless the context otherwise
requires, be construed as references to the Commission serving the needs of the Union or, as the
case may be, the State as respects the particular matter in question.Constitution of India

316. Appointment and term of office of members
(1)The Chairman and other members of a Public Service Commission shall be appointed, in the case
of the Union Commission or a Joint Commission, by the President, and in the case of a State
Commission, by the Governor of the State:Provided that as nearly as may be one-half of the
members of every Public Service Commission shall be persons who at the dates of their respective
appointments have held office for at least ten years either under the Government of India or under
the Government of a State, and in computing the said period of ten years any period before the
commencement of this Constitution during which a person has held office under the Crown in India
or under the Government of an Indian State shall be included.(1A)If the office of the Chairman of
the Commission becomes vacant or if any such Chairman is by reason of absence or for any other
reason unable to perform the duties of his office, those duties shall, until some persons appointed
under clause (1) to the vacant office has entered on the duties thereof or, as the case may be, until
the Chairman has resumed his duties, be performed by such one of the other members of the
Commission as the President, in the case of the Union Commission or a Joint Commission, and the
Governor of the State in the case of a State in the case of a State Commission, may appoint for the
purpose(2)A member of a Public Service Commission shall hold office for a term of six years from
the date on which he enters upon his office or until he attains, in the case of the Union Commission,
the age of sixty-five years, and in the case of a State Commission or a Joint Commission, the age of
sixty-two years, whichever is earlier:Provided that--(a)a member of a Public Service Commission
may, by writing under his hand addressed, in the case of the Union Commission or a Joint
Commission, to the President, and in the case of a State Commission, to the Governor of the State,
resign his office;(b)a member of a Public Service Commission may be removed from his office in the
manner provided in clause (1) or clause (3) of article 317.(3)A person who holds office as a member
of a Public Service Commission shall, on the expiration of his term of office, be ineligible for
re-appointment to that office.[Editorial comment-The Constitution (Fifteenth Amendment) Act,
1963, here they inserts a new clause (1A). As a result, a Public Service Commission may select an
acting chairman when the regular chairman is absent, on leave, or otherwise unable to perform his
duties..][Editorial comment-The Constitution (Forty-First Amendment) Act, 1976, changed the
retirement age of the Chairman and members of the State Public Service Commissions from 60 to
62 years, by amending Article 316(2) of the Constitution. However, it was later amended to 58 for
employees of the All-India Services, the Central Government, and many State governments.
Consequently, they are not interested in joining the Commission because they will only have two
years to serve, which is seen as undesirable for the efficient functioning of the Commission.Also
Refer]
317. Removal and suspension of member of a Public Service Commission
(1)Subject to the provisions of clause (3), the Chairman or any other member of a Public Service
Commission shall only be removed from his office by order of the President on the ground of
misbehaviour after the Supreme Court, on reference being made to it by the President, has, on
inquiry held in accordance with the procedure prescribed in that behalf under article 145, reported
that the Chairman or such other member, as the case may be, ought on any such ground to be
removed.(2)The President, in the case of the Union Commission or a Joint Commission, and theConstitution of India

Governor in the case of a State Commission, may suspend from office the Chairman or any other
member of the Commission in respect of whom a reference has been made to the Supreme Court
under clause (1) until the President has passed orders on receipt of the report of the Supreme Court
on such reference.(3)Notwithstanding anything in clause (1), the President may by order remove
from office the Chairman or any other member of a Public Service Commission if the Chairman or
such other member, as the case may be,--(a)is adjudged an insolvent; or(b)engages during his term
of office in any paid employment outside the duties of his office; or(c)is, in the opinion of the
President, unfit to continue in office by reason of infirmity of mind or body.(4)If the Chairman or
any other member of a Public Service Commission is or becomes in any way concerned or interested
in any contract or agreement made by or on behalf of the Government of India or the Government of
a State or participates in any way in the profit thereof or in any benefit or emolument arising
therefrom otherwise than as a member and in common with the other members of an incorporated
company, he shall, for the purposes of clause (1), be deemed to be guilty of misbehaviour.
318. Power to make regulations as to conditions of service of members and
staff of the Commission
In the case of the Union Commission or a Joint Commission, the President and, in the case of a
State Commission, the Governor of the State may by regulations-(a)determine the, number of
members of the Commission and their conditions of service; and(b)make provision with respect to
the number of members of the staff of the Commission and their conditions of service:Provided that
the conditions of service of a member of a Public Service Commission shall not be varied to his
disadvantage after his appointment.
319. Prohibition as to the holding of offices by members of Commission on
ceasing to be such members
On ceasing to hold office--(a)the Chairman of the Union Public Service Commission shall be
ineligible for further employment either under the Government of India or under the Government of
a State;(b)the Chairman of a State Public Service Commission shall be eligible for appointment as
the Chairman or any other member of the Union Public Service Commission or as the Chairman of
any other State Public Service Commission, but not for any other employment either under the
Government of India or under the Government of a State;(c)a member other than the Chairman of
the Union Public Service Commission shall be eligible for appointment as the Chairman of the
Union Public Service Commission or as the Chairman of a State Public Service Commission, but not
for any other employment either under the Government of India or under the Government of a
State;(d)a member other than the Chairman of a State Public Service Commission shall be eligible
for appointment as the Chairman or any other member of the Union Public Service Commission or
as the Chairman of that or any other State Public Service Commission, but not for any other
employment either under the Government of India or under the Government of a State.Constitution of India

320. Functions of Public Service Commissions
(1)It shall be the duty of the Union and the State Public Service Commissions to conduct
examinations for appointments to the services of the Union and the services of the State
respectively.(2)It shall also be the duty of the Union Public Service Commission, if requested by any
two or more States so to do, to assist those States in framing and operating schemes of joint
recruitment for any services for which candidates possessing special qualifications are
required.(3)The Union Public Service Commission or the State Public Service Commission, as the
case may be, shall be consulted--(a)on all matters relating to methods of recruitment to civil services
and for civil posts;(b)on the principles to be followed in making appointments to civil services and
posts and in making promotions and transfers from one service to another and on the suitability of
candidates for such appointments, promotions or transfers;(c)on all disciplinary matters affecting a
person serving under the Government of India or the Government of a State in a civil capacity,
including memorials or petitions relating to such matters;(d)on any claim by or in respect of a
person who is serving or has served under the Government of India or the Government of a State or
under the Crown in India or under the Government of an Indian State, in a civil capacity, that any
costs incurred by hi m in defending legal proceedings instituted against hi m in respect of acts done
or purporting to be done in the execution of hi s duty should be paid out of the Consolidated Fund of
India, or, as the case may be, out of the Consolidated Fund of the State;(e)on any claim for the
award of a pension in respect of injuries sustained by a person while serving under the Government
of India or the Government of a State or under the Crown in India or under the Government of an
Indian State, in a civil capacity, and any question as to the amount of any such award,and it shall be
the duty of a Public Service Commission to advise on any matter so referred to them and on any
other matter which the President, or, as the case may be, the Governor of the State, may refer to
them:Provided that the President as respects the all-India services and also as respects other
services and posts in connection with the affairs of the Union, and the Governor as respects other
services and posts in connection with the affairs of a State, may make regulations specifying the
matters in which either generally, or in any particular class of case or in any particular
circumstances, it shall not be necessary for a Public Service Commission to be consulted.(4)Nothing
in clause (3) shall require a Public Service Commission to be consulted as respects the manner in
which any provision referred to in clause (4) of article 16 may be made or as respects the manner in
which effect may be given to the provisions of article 335 .(5)All regulations made under the proviso
to clause ( 3 ) by the President or the Governor of a State shall be laid for not less than fourteen days
before each House of Parliament or the House or each House of the Legislature of the State, as the
case may be, as soon as possible after they are made, and shall be subject to such modifications,
whether by way of repeal or amendment, as both Houses of Parliament or the House or both Houses
of the Legislature of the State may make during the session in which they are so laid.
321. Power to extend functions of Public Service Commissions
An Act made by Parliament or, as the case may be, the Legislature of a State may provide for the
exercise of additional functions by the Union Public Service Commission or the State Public Service
Commission as respects the services of the Union or the State and also as respects the services of any
local authority or other body corporate constituted by law or of any public institution.Constitution of India

322. Expenses of Public Service Commissions
The expenses of the Union or a State Public Service Commission, including any salaries, allowances
and pensions payable to or in respect of the members or staff of the Commission, shall be charged
on the Consolidated Fund of India or, as the case may be, the Consolidated Fund of the State.
323. Reports of Public Service Commissions
(1)It shall be the duty of the Union Commission to present annually to the President a report as to
the work done by the Commission and on receipt of such report the President shall cause a copy
thereof together with a me morandum explaining, as respects the cases, if any, where the advice of
the Commission was not accepted, the reason for such non-acceptance to be laid before each House
of Parliament.(2)It shall be the duty of a State Commission to present annually to the Governor of
the State a report as to the work done by the Commission, and it shall be the duty of a Joint
Commission to present annually to the Governor of each of the States the needs of which are served
by the Joint Commission a report as to the work done by the Commission in relation to that State,
and in either case the Governor shall, on receipt of such report, cause a copy thereof together with a
memorandum explaining, as respects the cases, if any, where the advice of the Commission was not
accepted, the reasons for such non-acceptance to be laid before the Legislature of the State.
Part XIVA – Tribunals
323A. Administrative tribunals
(1)Parliament may, by law, provide for the adjudication or trial by administrative tribunals of
disputes and complaints with respect to recruitment and conditions of service of persons appointed
to public services and posts in connection with the affairs of the Union or of any State or of any local
or other authority within the territory of India or under the control of the Government of India or of
any corporation owned or controlled by the Government.(2)A law made under clause (1)
may--(a)provide for the establishment of an administrative tribunal for the Union and a separate
administrative tribunal for each State or for two or more States;(b)specify the jurisdiction, powers
(including the power to punish for contempt) and authority which may be exercised by each of the
said tribunals;(c)provide for the procedure (including provisions as to limitation and rules of
evidence) to be followed by the said tribunals;(d)exclude the jurisdiction of all courts, except the
jurisdiction of the Supreme Court under article 136, with respect to the disputes or complaints
referred to in clause (1);(e)provide for the transfer to each such administrative tribunal of any cases
pending before any court or other authority immediately before the establishment of such tribunal
as would have been within the jurisdiction of such tribunal if the cause of action on which such suits
or proceedings are based had arisen after such establishment;(f)repeal or amend any order made by
the President under clause (3) of article 371D;(g)contain such supplemental, incidental and
consequential provisions (including provisions as to fees) as Parliament may deem necessary for the
effective functioning of, and for the speedy disposal of cases by, and the enforcement of the orders
of, such tribunals.(3)The provisions of this article shall have effect notwithstanding anything in anyConstitution of India

other provision of this Constitution or in any other law for the time being in force.
323B. Tribunals for other matters
(1)The appropriate Legislature may, by law, provide for the adjudication or trial by tribunals of any
disputes, complaints, or offences with respect to all or any of the matters specified in clause (2) with
respect to which such Legislature has power to make laws.(2)The matters referred to in clause (1)
are the following, namely(a)levy, assessment, collection and enforcement of any tax;(b)foreign
exchange, import and export across customs frontiers;(c)industrial and labour disputes;(d)land
reforms by way of acquisition by the State of any estate as defined in article 31A or of any rights
therein or the extinguishments or modification of any such rights or by way of ceiling on agricultural
land or in any other way;(e)ceiling on urban property;-(f)elections to either House of Parliament or
the House or either House of the Legislature of a State, but excluding the matters referred to in
article 329 and article 329A;(g)production, procurement, supply and distribution of foodstuffs
(including edible oilseeds and oils) and such other goods as the President may, by public
notification, declare to be essential goods for the purpose of this article and control of prices of such
goods;(h)rent, its regulation and control and tenancy issues including the rights, title and interest of
landlords and tenants--,(i)offences against laws with respect to any of the matters specified in
sub-clause (a) to (h) and fees in respect of any of those matters;(j)any mailer incidental to any of the
matters specified in sub-clause (a) to (i).(3)A law made under clause (1) may--(a)provide for the
establishment of a hierarchy of tribunals;(b)specify the jurisdiction, powers (including the power to
punish for contempt) and authority which may be exercised by each of the said tribunals;(c)provide
for the procedure (including provisions as to limitation and rules of evidence) to be followed by the
said tribunals;(d)exclude the jurisdiction of all courts except the jurisdiction of the Supreme Court
under article 136 with respect to all or any of the matters falling within the jurisdiction of the said
tribunals;(e)provide for the transfer to each such tribunal of any cases pending before any court or
any other authority immediately before the establishment of such tribunal as would have been
within the jurisdiction of such tribunal if the causes of action on which such suits or proceedings are
based had arisen after such establishment;(f)contain such supplemental, incidental and
consequential provisions (including provisions as to fees) as the appropriate Legislature may deem
necessary for the effective functioning of, and for the speedy disposal of cases by, and the
enforcement of the orders of, such tribunals.(4)The provisions of this article shall have effect
notwithstanding anything in any other provision of this Constitution or in any other law for the time
being in force.Explanation--In this article, "appropriate Legislature", in relation to any matter,
means Parliament or, as the case may be, a State Legislature competent to make laws with respect to
such matter in accordance with the provisions of Part XI.[Editorial comment-The Constitution
(Seventy-fifth Amendment) Act, 1993, contains provisions for the establishment of rent control
tribunals and amended article 323B. The Indian Constitution has made provisions for setting up
State-level Rent Tribunals, which will provide timely relief to rent litigants. These tribunals will be
able to decide disputes on rent and will be independent of all courts, except the Supreme Court.Also
Refer]Constitution of India

Part XV – Elections
324. Superintendence, direction and control of elections to be vested in an
Election Commission
(1)The superintendence, direction and control of the preparation of the electoral rolls for, and the
conduct of, all elections to Parliament and to the Legislature of every State and of elections to the
offices of President and Vice-President held under this Constitution shall be vested in a Commission
(referred to in this Constitution as the Election Commission).(2)The Election Commission shall
consist of the Chief Election Commissioner and such number of other Election Commissioners, if
any, as the President may from time to time fix and the appointment of the Chief Election
Commissioner and other Election Commissioners shall, subject to the provisions of any law made in
that behalf by Parliament, be made by the President.(3)When any other Election Commissioner is so
appointed the Chief Election Commissioner shall act as the Chairman of the Election
Commission.(4)Before each general election to the House of the People and to the Legislative
Assembly of each State, and before the first general election and thereafter before each biennial
election to the Legislative Council of each State having such Council, the President may also appoint
after consultation with the Election Commission such Regional Commissioners as he may consider
necessary to assist the Election Commission in the performance of the functions conferred on the
Commission by clause (1).(5)Subject to the provisions of any law made by Parliament, the
conditions of service and tenure of office of the Election Commissioners and the Regional
Commissioners shall be such as the President may by rule determine:Provided that the Chief
Election Commissioner shall not be removed from his office except in like manner and on the like
grounds as a Judge of the Supreme Court and the conditions of service of the Chief Election
Commissioner shall not be varied to his disadvantage after his appointment:Provided further that
any other Election Commissioner or a Regional Commissioner shall not be removed from office
except on the recommendation of the Chief Election Commissioner.(6)The President, or the
Governor of a State, shall, when so requested by the Election Commission, make available to the
Election Commission or to a Regional Commissioner such staff as may be necessary for the
discharge of the functions conferred on the Election Commission by clause (1).[Editorial
comment- The Constitution (Nineteenth Amendment) Act, 1966, nullified the tribunals in India
and instead gave the authority to the High Court to hear the trial of election petitions. The abolition
of tribunals and the restoring of their powers to the High Court proved to be a turning point in the
matters having a connection with elections in India. This made the High Court superior and their
hold stronger. It also amended Article 324, subclause (1) and accordingly the Election Commission
is given the authority to supervise, direct, and oversee elections.The Representation of the People
Act of 1951 was also modified and it rendered the electoral tribunals’ appointment and authority null
and void. A special provision concerning the ability to appoint election tribunals for the adjudication
of uncertainties and issues coming out of or concerning elections to Parliament and the Legislatures
of States was eliminated.]Constitution of India

325. No person to be ineligible for inclusion in, or to claim to be included in a
special, electoral roll on grounds of religion, race, caste or sex
There shall be one general electoral roll for every territorial constituency for election to either House
of Parliament or to the House or either House of the Legislature of a State and no person shall be
ineligible for inclusion in any such roll or claim to be included in any special electoral roll for any
such constituency on grounds only of religion, race, caste, sex or any of them.
326. Elections to the House of the People and to the Legislative Assemblies
of States to be on the basis of adult suffrage
The elections to the House of the People and to the Legislative Assembly of every State shall be on
the basis of adult suffrage; that is to say, every person who is a citizen of India and who is not less
thaneighteen years of age on such date as may be fixed in that behalf by or under any law made by
the appropriate Legislature and is not otherwise disqualified under this Constitution or any law
made by the appropriate Legislature on the ground of non-residence, unsoundness of mind, crime
or corrupt or illegal practice, shall be entitled to be registered as a voter at any such
election.[Editroial comment-The Constitution (Sixty-first Amendment) Act, 1988, reduced the
voting age for elections for Indian citizens from 21 years to 18 years. The voting age for an Indian
citizen was decided as 21 years on the basis of adult suffrage. In simple words, any person below the
age of 21 was not allowed to cast a vote in the elections for the Lok Sabha and the Legislative
Assembly of each State. With the introduction of this Amendment, a chance was given to
unrepresented youths to express their views and emotions out in the open, thus inspiring them to
participate in the political process.Also Refer]
327. Power of Parliament to make provision with respect to elections to
Legislatures
Subject to the provisions of this Constitution, Parliament may from time to time by law make
provision with respect to all matters relating to, or in Connection with, elections to either House of
Parliament or to the House or either House of the Legislature of a State including the preparation of
electoral rolls, the delimitation of constituencies and all other matters necessary for securing the due
constitution of such House or Houses.
328. Power of Legislature of a State to make provision with respect to
elections to such Legislature
Subject to the provisions of this Constitution and in so far as provision in that behalf is not made by
Parliament, the Legislature of a State may from time to time by law make provision with respect to
all matters relating to, or in connection with, the elections to the House or either House of the
Legislature of the State including the preparation of electoral rolls and all other matters necessary
for securing the due constitution of such House or Houses.Constitution of India

329. Bar to interference by courts in electoral matters
Notwithstanding anything in this Constitution(a)the validity of any law relating to the delimitation
of constituencies or the allotment of seats to such constituencies, made or purporting to be made
under article 327 or article 328, shall not be called in question in any court;(b)no election to either
House of Parliament or to the House or either House of the Legislature of a State shall be called in
question except by an election petition presented to such authority and in such manner as may be
provided for by or under any law made by the appropriate Legislature.[Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer]
329A. Special provision as to elections to Parliament in the case of Prime
Minister and Speaker [REPELED]
[In Part XV of the Constitution, after article 329, the following article shall be inserted through
Constitution (Thirty-Ninth Amendment) Act, 1975](1)Subject to the provisions of Chapter II of Part
V [except sub-clause (e) of clause (1) of article 102], no election-(a)to either House of Parliament of a
person who holds the office of Prime Minister at the time of such election or is appointed as Prime
Minister after such election;(b)to the House of the People of a person who holds the office of
Speaker of that House at the time of such election or who is chosen as the Speaker for that House
after such election,shall be called in question, except before such authority [not being any such
authority as is referred to in clause (b) of article 329] or body and in such manner as may be
provided for by or under any law made by Parliament and any such law may provide for all other
matters relating to doubts and disputes in relation to such election including the grounds on which
such election may be questioned.(2)The validity of any such law as is referred to in clause (1) and the
decision of any authority or body under such law shall not be called in question in any
court.(3)Where any person is appointed as Prime Minister or, as the case may be, chosen to the
office of the Speaker of the House of the People, while an electionpetition referred to in clause (b) of
article 329 in respect of his election to either House of Parliament or, as the case may be, to the
House of the People is pending, such election petition shall abate upon such person being appointed
as Prime Minister or, as the case may be, being chosen to the office of the Speaker of the House of
the People, but such election may be called in question under any such law as is referred to in clause
(1).(4)No law made by Parliament before the commencement of the Constitution (Thirty-ninth
Amendment) Act, 1975, in so far as it relates to election petitions and matters connected therewith,
shall apply or shall be deemed ever to have applied to or in relation to the election to any such
person as is referred to in clause (1) to either House of Parliament and such election shall not be
deemed to be void or ever to have become void on any ground on which such election could be
declared to be void or has, before such commencement, been declared to be void under any such law
and notwithstanding any order made by any court, before such commencement, declaring suchConstitution of India

election to be void, such election shall continue to be valid in all respects and any such order and any
finding on which such order is based shall be and shall be deemed always to have been void and of
no effect.(5)Any appeal or cross appeal against any such order of any court as is referred to in clause
(4) pending immediately before the commencement of the Constitution (Thirty-ninth Amendment)
Act, 1975, before the Supreme Court shall be disposed of in conformity with the provisions of clause
(4).(6)The provisions of this article shall have effect notwithstanding anything contained in this
Constitution.".[Editorial comment-The Constitution (Thirty-Ninth Amendment) Act, 1975,
Insertion of new article 329A, Later, clauses (4) and (5) of Article 329A were struck down by the
Supreme Court in-State Of U.P vs Raj Narain & Ors Also Refer ][Editorial comment-The
Constitution (Forty-Second Amendment) Act, 1976,it provided Prime Minister and Lok Sabha
Speaker with special discretionary powers. Directive Principles were kept above
Fundamental/Human Rights. The Court’s judicial review can’t intervene in any
Parliament-approved legislation. Also Refer][Rep. by the Constitution (Forty-fourth Amendment)
Act, 1978, section 36 (w.e.f. 20-6-1979)][Editorial comment-The Constitution (Forty-Fourth
Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to Property
because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer]
Part XVI – Special Provisions Relating to Certain Classes
330. Reservation of seats for Scheduled Castes and Scheduled Tribes in the
House of the People
(1)Seats shall be reserved in the House of the People for-(a)the Scheduled Castes;(b)the Scheduled
Tribes except the Scheduled Tribes in the autonomous districts of Assam; and(c)the Scheduled
Tribes in the autonomous districts of Assam.(2)The number of seats reserved in any State or Union
territory for the Scheduled Castes or the Scheduled Tribes under clause (1) shall bear, as nearly as
may be, the same proportion to the total number of seats allotted to that State or Union territory in
the House of the People as the population of the Scheduled Castes in the State or Union territory or
of the Scheduled Tribes in the State or Union territory or part of the State or Union territory, as the
case may be, in respect of which seats are so reserved, bears to the total population of the State or
Union territory.(3)Notwithstanding anything contained in clause (2), the number of seats reserved
in the House of the People for the Scheduled Tribes in the autonomous districts of Assam shall bear
to the total number of seats allotted to that State a proportion not less than the population of the
Scheduled Tribes in the said autonomous districts bears to the total population of the
State.Explanation-- In this article 332, the expression "population" means the population as
ascertained at the last preceding census of which the relevant figures have been published:Provided
that the reference in this Explanation to the last preceding census of which the relevant figures have
been published shall, until the relevant figures for the first census taken after the year 2026 have
been published, be construed as a reference to the 2001 census.[Editorial comment- TheConstitution of India

Constitution (Twenty-Three Amendment) Act, 1969,this amendment was added where the
scheduled tribes in Nagaland is no longer entitled to reservations in the Lok Sabha and the State
Legislative Assembly, according to sections 2 and 3 of the act amending Articles 330 and 332 of the
Constitution.Also refer ][Editorial comment-The Constitution (Fifty-First Amendment) Act,
1984, it wаs enасted tо рrоvide fоr reservаtiоn оf seats in the house of the реорle for scheduled
tribes in nаgаlаnd, meghаlаyа, mizоrаm аnd аrunасhаl рrаdesh аnd аlsо fоr reservаtiоn оf seаts
fоr sсheduled tribes in the legislative assemblies of nаgаlаnd and meghаlаyа by suitably amending
articles 330 аnd 332. The number оf seаts reserved fоr sсheduled саstes and scheduled tribes in
the legislative assembly оf аny stаte under аrtiсle 332 оf the соnstitutiоn will hаve to be
determined having regаrd tо the provisions of article 332 (3) оf the соnstitutiоn.Also
refer][Editorial comment-The Constitution (One Hundred and Sixth Amendment) Act, 2023,
Article 330-A has been inserted relating to Reservation of seats for women in Lok Sabha or House of
the People. 1/3rd of the total number of seats reserved under Article 330 (2) will be reserved for
women belonging to Scheduled Castes or the Scheduled Tribes. 1/3rd of the seats that have to be
filled by direct election will be reserved for women (including the number of seats reserved for
women belonging to Scheduled Castes and Scheduled Tribes)Also Refer]
331. Representation of the Anglo-Indian community in the House of the
People
Notwithstanding anything in article 81, the President may, if he is of opinion that the Anglo-Indian
community is not adequately represented in the House of the people, nominate not more than two
members of that community to the House of the People.
332. Reservation of seats for Scheduled Castes and Scheduled Tribes in the
Legislative Assemblies of the State
(1)Seats shall be reserved for the Scheduled Castes and the Scheduled Tribes,except the Scheduled
Tribes in the autonomous districts of Assam, in the Legislative Assembly of every State.(2)Seats
shall be reserved also for the autonomous districts in the Legislative Assembly of the State of
Assam.(3)The number of seats reserved for the Scheduled Castes or the Scheduled Tribes in the
Legislative Assembly of any State under clause ( 1 ) shall bear, as nearly as may be, the same
proportion to the total number of seats in the Assembly as the population of the Scheduled Castes in
the State or of the Scheduled Tribes in the State or part of the State, as the case may be, in respect of
which seats are so reserved bears to the total population of the State.(3A)Notwithstanding anything
contained in clause ( 3 ), until the taking effect, under article 170 , of the re-adjustment, on the basis
of the first census after the year2026 , of the number of seats in the Legislative Assemblies of the
States of Arunachal Pradesh, Meghalaya, Mizoram and Nagaland, the seats which shall be reserved
for the Scheduled Tribes in the Legislative Assembly of any such State shall be--(a)if all the seats in
the Legislative Assembly of such State in existence on the date of coming into force of the
Constitution (Fifty-seventh Amendment) Act, 1987 (hereafter in this clause referred to as the
existing Assembly) are held by members of the Scheduled Tribes, all the seats except one;(b)in any
other case, such number of seats as bears to the total number of seats, a proportion not less than theConstitution of India

number (as on the said date) of members belonging to the Scheduled Tribes in the existing
Assembly bears to the total number of seats in existing Assembly.(3B)Notwithstanding anything
contained in clause ( 3 ), until the re-adjustment, under article 170 , takes effect on the basis of the
first census after the year2026 , of the number of seats in the Legislative Assembly of the State of
Tripura, the seats which shall be reserved for the Scheduled Tribes in the legislative Assembly, shall
be, such number of scats as bears to the total number of seats, a proportion not less than the
number, as on the date of coming into force of the Constitution (Seventy-second Amendment) Act,
1992 , of members belonging to the Scheduled Tribes in the Legislative Assembly in existence on the
said date bears to the total number of seats in that Assembly.(4)The number of seats reserved for an
autonomous district in the Legislative Assembly of the State of Assam shall bear to the total number
of seats in that Assembly a proportion not less than the population of the district bears to the total
population of the State.(5)The constituencies for the seats reserved for any autonomous district of
Assam shall not comprise any area outside that district.(6)No person who is not a member of a
Scheduled Tribe of any autonomous district of the State of Assam shall be eligible for election to the
Legislative Assembly of the State from any constituency of that district.Provided that for elections to
the Legislative Assembly of the State of Assam, the representation of the Scheduled Tribes and
non-Scheduled Tribes in the constituencies included in the Bodoland Territorial Areas District, so
notified, and existing prior to the constitution of the Bodoland Territorial Areas District, shall be
maintained.[Editorial comment- The Constitution (Twenty-Three Amendment) Act, 1969, this
amendment was added where the scheduled tribes in Nagaland is no longer entitled to reservations
in the Lok Sabha and the State Legislative Assembly, according to sections 2 and 3 of the act
amending Articles 330 and 332 of the Constitution. Also refer ][Editorial comment-The
Constitution (Thirty-First Amendment) Act, 1973, Assam, Nagaland, and Meghalaya’s tribal regions
were also found to be under the exclusionary rule of Article 332.Also Refer][Editorial
comment-The Constitution (Fifty-First Amendment) Act, 1984, it wаs enасted tо рrоvide fоr
reservаtiоn оf seats in the house of the реорle for scheduled tribes in nаgаlаnd, meghаlаyа,
mizоrаm аnd аrunасhаl рrаdesh аnd аlsо fоr reservаtiоn оf seаts fоr sсheduled tribes in the
legislative assemblies of nаgаlаnd and meghаlаyа by suitably amending articles 330 аnd 332. The
number оf seаts reserved fоr sсheduled саstes and scheduled tribes in the legislative assembly оf
аny stаte under аrtiсle 332 оf the соnstitutiоn will hаve to be determined having regаrd tо the
provisions of article 332 (3) оf the соnstitutiоn.Also refer][Editorial comment-The Constitution
(Fifty-seventh Amendment) Act, 1987, dealt with the reservation of seats for tribal people of the
North-Eastern states ( Mizoram, Nagaland, Meghalaya and Arunachal Pradesh ) in the Lower House
of Parliament and State legislatures. This cannot be considered to be one of the major amendments
but it was an important move for the upliftment of the weaker sections or those sections of society
that were neglected for a very long time. The Act decided the rule of reservation or the rule for
calculating the number of seats that were to be reserved for the Scheduled Tribes.Also
Refer][Editorial comment-The Constitution (Ninetieth Amendment) Act, 2003, is an additional
act that modifies the Indian Constitution by reserving seats for members of the Scheduled Castes
and Scheduled Tribes in state legislatures under Article 332 of the Indian Constitution (90th
Amendment Act). It aimed to bring about comprehensive changes in Indian politics and help the
Bodo people get their due. Under this law, Bodo speakers are able to vote in the Bodoland territorial
region, and the Constitution includes provisions to support their development.Also Refer]Constitution of India

332A. Reservation of seats for women in the Legislative Assemblies of the
States
1Seats shall be reserved for women in the Legislative Assembly of every State.2As nearly as may be,
one-third of the total number of seats reserved under clause (3) of article 332 shall be reserved for
women belonging to the Scheduled Castes or the Scheduled Tribes.3As nearly as may be, one-third
(including the number of seats reserved for women belonging to the Scheduled Castes and the
Scheduled Tribes) of the total number of seats to be filled by direct election in the Legislative
Assembly of every State shall be reserved for women.[Editorial comment-The Constitution (One
Hundred and Sixth Amendment) Act, 2023, Article 332-A has been inserted relating to: Reservation
of seats for women in the Legislative Assembly of every State. 1/3rd of the total number of seats
reserved under Article 332 (3) will be reserved for women belonging to Scheduled Castes or the
Scheduled Tribes. 1/3rd of the seats that have to be filled by direct election will be reserved for
women (including the number of seats reserved for women belonging to Scheduled Castes and
Scheduled Tribes) Also Refer]
333. Representation of the Anglo-Indian community in the Legislative
Assemblies of the States
Notwithstanding anything in article 170, the Governor of a State may, if he is of opinion that the
Anglo-Indian community needs representation in the Legislative Assembly of the State and is not
adequately represented therein, nominate one member of that community to the
Assembly.[Editorial comment- The Constitution (Twenty-Three Amendment) Act, 1969, this
amendment provides that the Governor may designate no more than one member of the
Anglo-Indian community to serve in any State Legislative Assembly. There shall be no consequence
on the representation of the Anglo-Indian community in the Legislative Assembly of any State that
existed at the beginning of this act until such time as that Assembly is dissolved as a result of the
application of the provisions of sub-section (1).Also refer ]
334. Reservation of seats and special representation to cease aftercertain
period.
Notwithstanding anything in the foregoing provisions of this Part, the provisions of this
Constitution relating to—(a)the reservation of seats for the Scheduled Castes and the Scheduled
Tribes in the House of the People and in the Legislative Assemblies of the States; and(b)the
representation of the Anglo-Indian community in the House of the People and in the Legislative
Assemblies of the States by nomination, shall cease to have effect on the expiration of a period of 2
[eighty years in respect of clause (a) and seventy years in respect of clause (b)] from the
commencement of this Constitution: Provided that nothing in this article shall affect any
representation in the House of the People or in the Legislative Assembly of a State until the
dissolution of the then existing House or Assembly, as the case may be.(Subs. by the Constitution
(One hundred and fourth Amendment) Act, 2019, s. 2, (w.e.f. 25-1-2020))[Editorial Comment-
The Constitution (Eighth Amendment) Act, 1959, which changed Article 334 of the Constitution, isConstitution of India

an important milestone in Indian history. It amended Article 334 of the Constitution in order to
extend the period of reservation of seats for the Scheduled Castes and Scheduled Tribes and
representation of the Anglo-Indians in the Lok Sabha and the State Legislative Assemblies for ten
years, i.e. up to 26 January 1970. Article 334 had stipulated that the reservation of seats should
expire within a period of ten years from the commencement of the Constitution (i.e. 26 January
1960). However, the extension of the reservation was necessary to give these marginalized
communities a greater opportunity to participate in the political process and have their voices heard.
The Amendment extended the period for reservations to 1970. The period of reservation was
extended to 1980, 1990, 2000, 2010, 2020 and 2030 by the 23rd, 45th, 62nd, 79th, 95th and 104th
Amendments respectively. Also Refer ][Editorial comment- The Constitution (Twenty-Three
Amendment) Act, 1969, this amendment to Article 334 made Anglo-Indian community by
nomination will continue to be represented in the Lok Sabha and the State’s Legislative Assemblies
for a further ten years.Also refer ][Editorial comment- The Constitution (Forty-Fifth
Amendment) Act, 1980, increased the time of seat reservations for the Scheduled Castes (SC) and
Scheduled Tribes (ST) as well as gave the special representation of the Anglo-Indian community in
the Lok Sabha and the State Legislative Assemblies for a further duration of ten years, or up to
January 26, 1990. Article 334 of the Constitution had originally required the reservation of seats to
cease in 1960, but this was extended to 1970 by the 8th Amendment, and the 23rd Amendment
extended this period to 1980. The 45th Amendment extended the period of reservation to 1990.The
period of reservation was extended to 2000, 2010, 2020 and 2030 by the 62nd, 79th, 95th and
104th Amendments respectively. Also Refer][Editorial comment- The Constitution (Sixty-second
Amendment) Act, 1989, extended the period of reservation of seats for the Scheduled Castes and
Scheduled Tribes and representation of the Anglo-Indians in the Lok Sabha and the State Legislative
Assemblies for another ten years, i.e. up to 26 January 2000. Article 334 of the Constitution had
originally required the reservation of seats to cease in 1960, but this was extended to 1970 by the 8th
Amendment. The period of reservation was extended to 1980 and 1990 by the 23rd and 45th
Amendments respectively. This Amendment extended the period of reservation to 2000. The period
of reservation was further extended to 2010, 2020 and 2030 by the 79th and 95th and 104th
Amendments respectively.Also Refer ][Editorial comment-The Constitution (Seventy-ninth
Amendment) Act, 1999, extended the period of reservation of seats for the Scheduled Castes and
Scheduled Tribes and representation of the Anglo-Indians in the Lok Sabha and the State Legislative
Assemblies for another ten years, i.e. up to 26 January 2010. Article 334 of the Constitution had
originally required the reservation of seats to cease in 1960, but this was extended to 1970 by the 8th
Amendment. The period of reservation was extended to 1980, 1990, and 2000 by the 23rd, 45th and
62nd Amendments respectively. The 79th Amendment extended this period to 2010. The period of
reservation was further extended to 2020 and 2030 by the 95th and 104th Amendments.Also Refer
][Editorial comment-The Constitution (Ninety-fifth Amendment) Act, 2009, extended the
reservation of seats for the Scheduled Castes and Scheduled Tribes, and representation of the
Anglo-Indians in the Lok Sabha and the State Legislative Assemblies for another ten years, i.e., up to
26 January 2020. Article 334 of the Constitution had originally mandated that the reservation of
elected seats must cease in 1960, but this was extended to 1970 by the 8th Amendment. The period
of reservation was subsequently extended to 1980, 1990, 2000, and 2010 by the 23rd, 45th, 62nd,
and 79th Amendments, respectively. The 95th Amendment further extended the period of
reservation to 2020, and the 104th Amendment extended it to 2030.Also Refer][EditorialConstitution of India

comment-The Constitution (One Hundred and Fourth Amendment) Act, 2019, ensures that
individuals from socially and educationally backward classes have equal opportunities for education
and public employment, thereby promoting social and economic equality. The Act extends the
reservation for socially and educationally backward classes in educational institutions and public
employment until 2030. The socially and educationally backward classes under the Act include
Scheduled Castes, Scheduled Tribes, and Other Backward Classes. The cessation of reservation of
the Anglo-Indian group in Lok Sabha and state Legislative Assemblies is a debated topic. BJP-led
government has scrapped it stating appropriate representation of the community is achieved. Other
than this policy or the rule of reservation for SCs and Scheduled Tribes has always been a bone of
contention. Special Protection provided, reservations in legislature granted to them, etc are hot
topics for debates.Also Refer]
334A. Reservation of seats for women take effect.
1Notwithstanding anything in the foregoing provision of this Part or Part VIII, the provisions of the
Constitution relating to the reservation of seats for women in the House of the People, the
Legislative Assembly of a State and the Legislative Assembly of the National Capital Territory of
Delhi shall come into effect after an exercise of delimitation is undertaken for this purpose after the
relevant figures for the first census taken after commencement of the Constitution (One Hundred
and Sixth Amendment) Act, 2023 have been published and shall cease to have effect on the
expiration of a period of fifteen years from such commencement.2Subject to the provisions of
articles 239AA, 330A and 332A, seats reserved for women in the House of the People, the
Legislative Assembly of a State and the Legislative Assembly of the National Capital Territory of
Delhi shall continue till such date as the Parliament may by law determine.3Rotation of seats
reserved for women in the House of the People, the Legislative Assembly of a State and the
Legislative Assembly of the National Capital Territory of Delhi shall take effect after each
subsequent exercise of delimitation as the Parliament may by law determine.4Nothing in this article
shall affect any representation in the House of the People, the Legislative Assembly of a State or the
Legislative Assembly of the National Capital Territory of Delhi until the dissolution of the then
existing House of the People, Legislative Assembly of a State or the Legislative Assembly of the
National Capital Territory of Delhi.
335. Claims of Scheduled Castes and Scheduled Tribes to services and posts
The claims of the members of the Scheduled Castes and the Scheduled Tribes shall be taken into
consideration, consistently with the maintenance of efficiency of administration, in the making of
appointments to services and posts in connection with the affairs of the Union or of a State:[ In
Article 335 of the Constitution, the following proviso shall be inserted at the end]Provided that
nothing in this article shall prevent in making of any provision in favour of the members of the
Scheduled Castes and the Scheduled Tribes for relaxation in qualifying marks in any examination or
lowering the standards of evaluation, for reservation in matters of promotion to any class or classes
of services or posts in connection with the affairs of the Union or of a State.[Editorial
comment-The Constitution (Eighty-second Amendment) Act, 2000, provides that nothing in
Article 355 shall prevent the state from making any provisions in favor of members of SC/ST forConstitution of India

relaxation of qualifying scores for exams, services, or promotions. Members of the Scheduled Castes
and Scheduled Tribes have benefited from the relaxation of qualifying marks as well as assessment
requirements in areas of reservation in promotion. In the case of S. Vinod Kumar vs Union of India,
the Supreme Court ruled that, in light of the directive in Article 335 of the Constitution, such
relaxations in the rules governing reservations in promotions were not permissible under Article
16(4) of the Constitution. The Supreme Court's Constitution Bench of nine judges heard the case of
Indira Sawhney and others vs Union of India and others, and established that exemptions of
qualifying marks and norms of evaluation in matters of reservation in promotion were not allowed,
according to the decision of the Supreme Court.Also Refer ]
336. Special provision for Anglo-Indian community in certain services
(1)During the first two years after the commencement of this Constitution, appointments of
members of the Anglo-Indian community to posts in the railway, customs, postal and telegraph
services of the Union shall be made on the same basis as immediately before the fifteenth day of
August, 1947.During every succeeding period of two years, the number of posts reserved for the
members of the said community in the said services shall, as nearly as possible, be less by ten per
cent than the numbers so reserved during the immediately preceding period of two years:Provided
that at the end of ten years from the commencement of this Constitution all such reservations shall
cease.(2)Nothing in clause (1) shall bar the appointment of members of the Anglo-Indian
community to posts other than, or in addition to, those reserved for the community under that
clause if such members are found qualified for appointment on merit as compared with the
members of other communities.
337. Special provision with respect to educational grants for the benefit of
Anglo-Indian community
During the first three financial years after the commencement of this Constitution, the same grants,
if any, shall be made by the Union and by each State for the benefit of the Anglo-Indian community
in respect of education as were made in the financial year ending on the thirty-first day of March,
1948 .During every succeeding period of three years the grants may be less by ten per cent than
those for the immediately preceding period of three years:Provided that at the end of ten years from
the commencement of this Constitution such grants, to the extent to which they are a special
concession to the Anglo-Indian community, shall cease:Provided further that no educational
institution shall be entitled to receive any grant under this article unless at least forty per cent of
annual admissions therein are made available to members of communities other than the
Anglo-Indian community.
338. National Commission for Scheduled Castes
(1)There shall be a Commission for the Scheduled Castes to be known as the National Commission
for the Scheduled Castes.(2)Subject to the provisions of any law made in this behalf by Parliament,
the Commission shall consist of a Chairperson, Vice-Chairperson and three other Members and theConstitution of India

conditions of service and tenure of office of the Chairperson, Vice-Chairperson and other Members
so appointed shall be such as the President may by rule determine.(3)The Chairperson,
Vice-Chairperson and other Members of the Commission shall be appointed by the President by
warrant under his hand and seal.(4)The Commission shall have the power to regulate its own
procedure.(5)It shall be the duty of the Commission--(a)to investigate and monitor all matters
relating to the safeguards provided for the Scheduled Castes under this Constitution or under any
other law for the time being in force or under any order of the Government and to evaluate the
working of such safeguards;(b)to inquire into specific complaints with respect to the deprivation of
rights and safeguards of the Scheduled Castes ;(c)to participate and advise on the planning process
of socio-economic development of the Scheduled Castes and to evaluate the progress of their
development under the Union and any State; the Scheduled Castes and to evaluate the progress of
their development under the Union and any State;(d)to present to the President, annually and at
such other times as the Commission may deem fit, reports upon the working of those safeguards;
deem fit, reports upon the working of those safeguards;(e)to make in such reports recommendations
as to the measures that should be taken by the Union or any State for the effective implementation
of those safeguards and other measures for the protection, welfare and socio-economic development
of the Scheduled Castes ; and(f)to discharge such other functions in relation to the protection,
welfare and development and advancement of the Scheduled Castes as the President may, subject to
the provisions of any law made by Parliament, by the rule specify.(6)The President shall cause all
such reports to be laid before each House of Parliament along with a memorandum explaining the
action taken or proposed to be taken on the recommendations relating to the Union and the reasons
for the non-acceptance, if any, of any of such recommendations.(7)Where any such report, or any
part thereof, relates to any mailer with which any State Government is concerned, a copy of such
report shall be forwarded to the Governor of the State who shall cause it to be laid before the
Legislature of the State along with a memorandum explaining the action taken or proposed to be
taken on the recommendations relating to the State and the reasons for the non-acceptance, if any,
of any of such recommendations.(8)The Commission shall, while investigating any matter referred
to in sub-clause (a) or inquiring into any complaint referred to in sub-clause (b) of clause (5), have
all the powers of a civil court trying a suit and in particular in respect of the following matters,
namely:--(a)summoning and enforcing the attendance of any person from any part of India and
examining him on oath;(b)requiring the discovery and production of any documents;(c)receiving
evidence on affidavits;(d)requisitioning any public or copy thereof from any court or
office;(e)issuing commissions for the examination of witnesses and documents;(f)any other matter
which the President may by rule determine.(9)The Union and every State Government shall consult
the Commission on all major policy matters affecting Scheduled Castes .(10)In this article,
references to the Scheduled Castes shall be construed as including references to such other
backward classes as the President may, on receipt of the report of a Commission appointed under
clause (1) of article 340 by order specify and also to the Anglo-Indian community.[Editorial
comment-The Constitution (Sixty-fifth Amendment) Act, 1990, changed the Constitution’s Article
338 to create a National Commission for Scheduled Castes and Tribes. The Commission shall
consist of a Chairperson, Vice-Chairperson, and five other Members. The conditions of service and
tenure of the Chairperson, Vice-Chairperson, and other Members shall be determined by the
President through rules, subject to the provisions of any law made by Parliament that is in the best
interests of the country. The President is required to appoint the Chairperson, Vice-Chairperson,Constitution of India

and other Members of the National Commission established under the 65th amendment of the
Indian constitution by warrant duly signed by the President and sealed. A Special Officer for
Scheduled Castes and Scheduled Tribes is established under Original Article 338 of the Constitution
to look into any issues about the constitutional protections for SCs and STs. This special officer is
also mandated to work for the SC’s and STs’ welfare.Also Refer]
338A. National Commission for Scheduled Tribes
(1)There shall be a Commission for the Scheduled Tribes to be known as the National Commission
for the Scheduled Tribes.(2)Subject to the provisions of any law made in this behalf by Parliament,
the Commission shall consist of a Chairperson, Vice-Chairperson and three other Members and the
conditions of service and tenure of office of the Chairperson, Vice-Chairperson and other Members
so appointed shall be such as the President may by rule determine.(3)The Chairperson.
Vice-Chairperson and other Members of the Commission shall be appointed by the President by
warrant under his hand and seal,(4)The Commission shall have the power to regulate its own
procedure.(5)It shall be the duty of the Commission--(a)to investigate and monitor all matters
relating to the safeguards provided for the Scheduled Tribes under this Constitution or under any
other law for the time being in force or under any order of the Government and to evaluate the
working of such safeguards;(b)to inquire into specific complaints with respect to the deprivation of
rights and safeguards of the Scheduled Tribes;(c)to participate and advise on the planning process
of socio-economic development of the Scheduled Tribes and to evaluate the progress of their
development under the Union and any State;(d)to present to the President, annually and at such
other times as the Commission may deem fit, reports upon the working of those safeguards;(e)to
make in such reports recommendations as to the measures that should be taken by the Union or any
State for the effective implementation of those safeguards and other measures for the protection,
welfare and socio-economic development of the Scheduled Tribes; and(f)to discharge such other
functions in relation to the protection, welfare and development and advancement of the Scheduled
Tribes as the President may, subject to the provisions of any law made by Parliament, by rule
specify.(6)The President shall cause all such reports to be laid before each House of Parliament
along with a memorandum explaining the action taken or proposed to be taken on the
recommendations relating to the Union and the reasons for the non-acceptance, if any, of any of
such recommendations.(7)Where any such report, or any part thereof, relates to any matter with
which any State Government is concerned, a copy of such report shall be forwarded to the Governor
of the State who shall cause it to be laid before the Legislature of the State along with a
memorandum explaining the action taken or proposed to be taken on the recommendations relating
to the State and the reasons for the non-acceptance, if any, of any of such recommendations.(8)The
Commission shall, while investigating any matter referred to in sub-clause (a) or inquiring into any
complaint referred to in sub-clause (b) of clause (5), have all the powers of a civil court trying a suit
and in particular in respect of the following matters, namely:--(a)summoning and enforcing the
attendance of any person from any part of India and examining him on oath;(b)requiring the
discovery and production of any document;(c)receiving evidence on affidavits;(d)requisitioning any
public record or copy thereof from any court or office;(e)issuing commissions for the examination of
witnesses and documents;(f)any other matter which the President may, by rule, determine.(9)The
Union and every State Government shall consult the Commission on all major policy mattersConstitution of India

affecting Scheduled Tribes.[Editorial comment-The Constitution (Eighty-ninth Amendment) Act,
2003, created the National Commission for Scheduled Tribes, a constitutional authority that
promotes the economic advancement of India's Scheduled Tribes. This act provided for the
establishment of a separate body called the National Commission for Scheduled Tribes (NCST) and
inserted a new Article 338A under Article 338, giving the NCST constitutional status. The body
works for the protection, welfare, and socio-economic development of the tribal communities.Also
Refer]
338B. National Commission for Backward Classes.—
(1)There shall be a Commission for the socially and educationally backward classes to be known as
the National Commission for Backward Classes.(2)Subject to the provisions of any law made in this
behalf by Parliament, the Commission shall consist of a Chairperson, Vice-Chairperson and three
other Members and the conditions of service and tenure of office of the Chairperson,
Vice-Chairperson and other Members so appointed shall be such as the President may by rule
determine.(3)The Chairperson, Vice-Chairperson and other Members of the Commission shall be
appointed by the President by warrant under his hand and seal.(4)The Commission shall have the
power to regulate its own procedure.(5)It shall be the duty of the Commission—(a)to investigate and
monitor all matters relating to the safeguards provided for the socially and educationally backward
classes under this Constitution or under any other law for the time being in force or under any order
of the Government and to evaluate the working of such safeguards;(b)to inquire into specific
complaints with respect to the deprivation of rights and safeguards of the socially and educationally
backward classes;(c)to participate and advise on the socio-economic development of the socially and
educationally backward classes and to evaluate the progress of their development under the Union
and any State;(d)to present to the President, annually and at such other times as the Commission
may deem fit, reports upon the working of those safeguards;(e)to make in such reports the
recommendations as to the measures that should be taken by the Union or any State for the effective
implementation of those safeguards and other measures for the protection, welfare and
socio-economic development of the socially and educationally backward classes; and(f)to discharge
such other functions in relation to the protection, welfare and development and advancement of the
socially and educationally backward classes as the President may, subject to the provisions of any
law made by Parliament, by rule specify.(6)The President shall cause all such reports to be laid
before each House of Parliament along with a memorandum explaining the action taken or
proposed to be taken on the recommendations relating to the Union and the reasons for the
non-acceptance, if any, of any such recommendations.(7)Where any such report, or any part thereof,
relates to any matter with which any State Government is concerned, a copy of such report shall be
forwarded to the State Government which shall cause it to be laid before the Legislature of the State
along with a memorandum explaining the action taken or proposed to be taken on the
recommendations relating to the State and the reasons for the non-acceptance, it any, of any of such
recommendations.(8)The Commission shall, while investigating any matter referred to in sub-clause
(a) or inquiring into any complaint referred to in sub-clause (b) of clause (5), have all the powers of
a civil court trying a suit and in particular in respect of the following matters, namely
:—(a)summoning and enforcing the attendance of any person from any part of India and examining
him on oath;(b)requiring the discovery and production of any document;(c)receiving evidence onConstitution of India

affidavits;(d)requisitioning any public record or copy thereof from any court or office;(e)issuing
commissions for the examination of witnesses and documents;(f)any other matter which the
President may by rule, determine.(9)The Union and every State Government shall consult the
Commission on all major policy matters affecting the socially and educationally backward
classes:][Provided that nothing in this clause shall apply for the purposes of clause (3) of article
342A.]Ins. by the Constitution (One Hundred and Fifth Amendment) Act, 2021, s. 2 (w.e.f.
15-9-2021)[Editorial comment-The Constitution (One Hundred and Second Amendment) Act,
2018, according to the information presented in the article, the chairman, vice-chairperson, and
three other members of the committee are all appointed by the president.The National Commission
for Backward Classes (NCBC) is responsible for overseeing issues related to the safeguards afforded
to the socially and educationally Backward Classes (SEBCs), investigating complaints of violations of
their rights, and proposing measures to incorporate safeguards and welfare measures.NCBC also
presents an annual report to the President. As part of its investigation into allegations that members
of socially and educationally disadvantaged groups had their rights violated, the Commission was
granted the jurisdiction to perform the functions of a civil court according to an article in the
constitution. Also Refer][Editorial comment-The Constitution (One Hundred and Five
Amendment) Act, 2021, restored state governments’ authority to recognize economically and
socially disadvantaged groups (SEBCs). A community for which the State in India may give “special
provisions” or equality is classified as SEBCs, which contains the categories generally referred to as
Other Backward Classes (OBCs). The Supreme Court ruled that the separate State lists were exempt
from the authority and obligations of the National Commission for Backward Classes. State
governments’ ability to create the Socially and Educationally Backward Classes (SEBC) list was
reinstated by the 105th Amendment of Indian constitution. It said that States are exempt from the
National Commission’s requirement for consultation. Consequently, over one-fifth of all OBC
communities benefitted from this. It reinstated a Supreme Court literal interpretation that took
away the States’ ability to keep a state list of OBCs. States were granted the power to react swiftly to
socioeconomic needs that are unique to a state or region. India already had a federal structure, and
the Bill that was passed strengthened it much more.Also refer]
339. Control of the Union over the administration of Scheduled Areas and the
welfare of Scheduled Tribes
(1)The President may at any time and shall, at the expiration of ten years from the commencement
of this Constitution by order appoint a Commission to report on the administration of the Scheduled
Areas and the welfare of the Scheduled Tribes in the States.The order may define the composition,
powers and procedure of the Commission and may contain such incidental or ancillary provisions as
the President may consider necessary or desirable.(2)The executive power of the Union shall extend
to the giving of directions toa State as to the drawing up and execution of schemes specified in the
direction to be essential for the welfare of the Scheduled Tribes in the State.
340. Appointment of a Commission to investigate the conditions of backward
classesConstitution of India

(1)The President may by order appoint a Commission consisting of such persons as he thinks fit to
investigate the conditions of socially and educationally backward classes within the territory of India
and the difficulties under which they labour and to make recommendations as to the steps that
should be taken by the Union or any State to remove such difficulties and to improve their condition
and as to the grants that should be made for the purpose by the Union or any State and the
conditions subject to which such grants should be made, and the order appointing such Commission
shall define the procedure to be followed by the Commission.(2)A Commission so appointed shall
investigate the matters referred to them and present to the President a report setting out the facts as
found by them and making such recommendations as they think proper.(3)The President shall
cause a copy of the report so presented together with a memorandum explaining the action taken
thereon to be laid before each House of Parliament.
341. Scheduled Castes
(1)The President may with respect to any State or Union territory, and where it is a State after
consultation with the Governor thereof, by public notification,specify the castes, races or tribes or
parts of or group within castes, races or tribes which shall for the purposes of this Constitution be
deemed to be Scheduled Castes in relation to that State or Union territory, as the case may
be.(2)Parliament may by law include in or exclude from the list of Scheduled Castes specified in a
notification issued under clause (1) any caste, race or tribe or part of or group within any caste, race
or tribe, but save as aforesaid a notification issued under the said clause shall not be varied by any
subsequent notification.
342. Scheduled Tribes
(1)The President may with respect to any State or Union territory, and where it is a State after
consultation with the Governor thereof, by public notificationspecify the tribes or tribal
communities or parts of or groups within tribes or tribal communities which shall for the purposes
of this Constitution be deemed to be Scheduled Tribes in relation to that State or Union territory, as
the case may be.(2)Parliament may by law include in or exclude from the list of Scheduled Tribes
specified in a notification issued under clause (1) any tribe or tribal community or part of or group
within any tribe or tribal community, but save as aforesaid a notification issued under the said
clause shall not be varied by any subsequent notification.
342A. Socially and educationally backward classes.
(1)The President may with respect to any State or Union territory, and where it is a State, after
consultation with the Governor thereof, by public notification, specify the socially and educationally
backward classes which shall for the purposes of this Constitution be deemed to be socially and
educationally backward classes in relation to that State or Union territory, as the case may
be.(2)Parliament may by law include in or exclude from the Central List of socially and
educationally backward classes specified in a notification issued under clause (1) any socially and
educationally backward class, but save as aforesaid a notification issued under the said clause shall
not be varied by any subsequent notification.".[Editorial comment-The Constitution (OneConstitution of India

Hundred and Second Amendment) Act, 2018, grants powers to the President to declare a caste as an
SEBC, and the President may make an amendment to the list with a law passed by the Parliament.
But states cannot declare a new caste. All they can do is recommend it. This means that the state
government cannot declare a new caste as a BC (Backward Class).The 102 amendment of the Indian
constitution (i.e. 102 caa) seeks to give the National Commission for Backward Classes a
constitutional status, making it a quasi-independent body that examines welfare measures and
complaints for socially and educationally backward classes. The commission was to be equal to the
National Commission for Scheduled Castes and the National Commission for Scheduled Tribes.
Also Refer]
Part XVII – Official Language
343. Official language of the Union
(1)The official language of the Union shall be Hindi in Devanagari script.The form of numerals to be
used for the official purposes of the Union shall be the international form of Indian
numerals.(2)Notwithstanding anything in clause (1), for a period of fifteen years from the
commencement of this Constitution, the English language shall continue to be used for all the
official purposes of the Union for which it was being used immediately before such
commencement:Provided that the President may, during the said period, by orderauthorise the use
of the Hindi language in addition to the English language and of the Devanagari form of numerals in
addition to the international form of Indian numerals for any of the official purposes of the
Union.(3)Notwithstanding anything in this article, Parliament may by law provide for the use, after
the said period of fifteen years, of--(a)the English language, or(b)the Devanagari form of
numerals,for such purposes as may be specified in the law.
344. Commission and Committee of Parliament on official language
(1)The President shall, at the expiration of five years from the commencement of this Constitution
and thereafter at the expiration of ten years from such commencement, by order constitute a
Commission which shall consist of a Chairman and such other members representing the different
languages specified in the Eighth Schedule as the President may appoint, and the order shall define
the procedure to be followed by the Commission.(2)It shall be the duty of the Commission to make
recommendations to the President as to--(a)the progressive use of the Hindi language for the official
purposes of the Union; .(b)restrictions on the use of the English language for all or any of the official
purposes of the Union;(c)the language to be used for all or any of the purposes mentioned in article
348;(d)the form of numerals to be used for any one or more specified purposes of the Union;(e)any
other matter referred to the Commission by the President as regards the official language of the
Union and the language for communication between the Union and a State or between one State
and another and their use.(3)In making their recommendations under clause (2), the Commission
shall have due regard to the industrial, cultural and scientific advancement of India, and the just
claims and the interests of persons belonging to the non-Hindi speaking areas in regard to theConstitution of India

public services.(4)There shall be constituted a Committee consisting of thirty members, of whom
twenty shall be members of the House of the People and ten shall be members of the Council of
States to be elected respectively by themembers of the House of the People and the members of the
Council of States in accordance with the system of proportional representation by means of the
single transferable vote.(5)It shall be the duty of the Committee to examine the recommendations of
the Commission constituted under clause (1) and to report to the President their opinion
thereon.(6)Notwithstanding anything in article 343, the President may, after consideration of the
report referred to in clause (5), issue directions in accordance with the whole or any part of that
report.
345. Official language or languages of a State
Subject to the provisions of articles 346 and 347, the Legislature of a State may by law adopt any one
or more of the languages in use in the State or Hindi as the language or languages to be used for all
or any of the official purposes of that State:Provided that, until the Legislature of the State otherwise
provides by law, the English language shall continue to be used for those official purposes within the
State for which it was being used immediately before the commencement of this Constitution.
346. Official language for communication between one State and another or
between a State and the Union
The language for the time being authorised for use in the Union for official purposes shall be the
official language for communication between one State and another State and between a State and
the Union:Provided that if two or more States agree that the Hindi language should be the official
language for communication between such States, that language may be used for such
communication.
347. Special provision relating to language spoken by a section of the
population of a State
On a demand being made in that behalf the President may, if he is satisfied that a substantial
proportion of the population of a State desire the use of any language spoken by them to be
recognised throughout that State or any part thereof for such purpose as he may specify.
348. Language to be used in the Supreme Court and in the High Courts and
for Acts, Bills, etc.
(1)Notwithstanding anything in the foregoing provisions of this Part, until Parliament by law
otherwise provides--(a)all proceedings in the Supreme Court an in every High Court,(b)the
authoritative texts--(i)of all Bills to be introduced or amendments thereto to be moved in either
House of Parliament or in the House or either House of the Legislature of a State,(ii)of all Acts
passed by Parliament or the Legislature of a State and of all Ordinances promulgated by the
President or the Governor of a State, and(iii)of all orders, rules, regulations and bye-laws issuedConstitution of India

under this Constitution or under any law made by Parliament or the Legislature of a State,shall be in
the English language.(2)Notwithstanding anything in sub-clause (a) of clause (1), the Governor of a
State may, with the previous consent of the President, authorise the use of the Hindi language, or
any other language used for any official purposes of the State, in proceedings in the High Court
having its principal seat in- that State:Provided that nothing in this clause shall apply to any
judgment, decree or order passed or made by such High Court.(3)Notwithstanding anything in
sub-clause (b) of clause (1), where the Legislature of a State has prescribed any language other than
the English language for use in Bills introduced in, or Acts passed by, the Legislature of the State or
in Ordinances promulgated by the Governor of the State or in any order, rule, regulation or bye-law
referred to in paragraph (iii) of that sub-clause, a translation of the same in the English language
published under the authority of the Governor of the State in the Official Gazette of that State shall
be deemed to be the authoritative text thereof in the English language under this article.
349. Special procedure for enactment of certain laws relating to language
During the period of fifteen years from the commencement of this Constitution, no Bill or
amendment making provision for the language to be used for any of the purposes mentioned in
clause (1) of article 348 shall be introduced or moved in either House of Parliament without the
previous sanction of the President, and the President shall not give his sanction to the introduction
of any such Bill or the moving of any such amendment except after he has taken into consideration
the recommendations of the Commission constitution under clause (1) of article 344 and the report
of the Committee constituted under clause (4) of that article.
350. Language to be used in representations for redress of grievances
Every person shall be entitled to submit a representation for the redress of any grievance to any
officer or authority of the Union or a State in any of the languages used in the Union or in the State,
as the case may be.
350A. Facilities for instruction in mother-tongue at primary stage
It shall be the endeavour of every State and of every local authority within the State to provide
adequate facilities for instruction in the mother-tongue at the primary stage of education to children
belonging to linguistic minority groups; and the President may issue such directions to any State as
he considers necessary or proper for securing the provision of such facilities.[Editorial comment-
The Constitution (Seventh Amendment) Act, 1956, every State must offer linguistic minority
children facilities for instruction in the mother tongue at primary-level learning. Also Refer ]
350B. Special Officer for linguistic minorities
(1)There shall be a Special Officer for linguistic minorities to be appointed by the President.(2)It
shall be the duty of the Special Officer to investigate all matters relating to the safeguards provided
for linguistic minorities under this Constitution and report to the President upon those matters atConstitution of India

such intervals as the President may direct, and the President shall cause all such reports to be laid
before each House of Parliament, and sent to the Governments of the States concerned.[Editorial
comment- The Constitution (Seventh Amendment) Act, 1956, this has been added to allow the
President to designate Special Officers, whose responsibility it is to look into any issues relating to
the protections the Constitution offers for language minorities.Also Refer ]
351. Directive for development of the Hindi language
It shall be the duty of the Union to promote the spread of the Hindi language, to develop it so that it
may serve as a medium of expression for all the elements of the composite culture of India and to
secure its enrichment by assimilating without interfering with its genius, the forms, style and
expressions used in Hindustani and in the other languages of India specified in the Eighth Schedule,
and by drawing, wherever necessary or desirable, for its vocabulary, primarily on Sanskrit and
secondarily on other languages.
Part XVIII – Emergency Provisions
352. Proclamation of Emergency
(1)If the President is satisfied that a grave emergency exists whereby the security of India or of any
part of the territory thereof is threatened, whether by war or external aggression or armed rebellion,
he may, by Proclamation, make a declaration to that effect in respect of the whole of India or of such
part of the territory thereof as may be specified in the Proclamation.Explanation--A Proclamation of
Emergency declaring that the security of India or any part of the territory thereof is threatened by
war or by external aggression or by armed rebellion may be made before theactual occurrence of war
or of any such aggression or rebellion, if the President is satisfied that there is imminent danger
thereof.(2)A Proclamation issued under clause (1) may be varied or revoked by a subsequent
Proclamation.(3)The President shall not issue a Proclamation under clause (1) or a Proclamation
varying such Proclamation unless the decision of the Union Cabinet (that is to say, the Council
consisting of the Prime Minister and other Ministers of Cabinet rank under article 75) that such a
Proclamation may be issued has been communicated to him in writing.(4)Every Proclamation
issued under this article shall be laid before each House of Parliament and shall, except where it is a
Proclamation revoking a previous Proclamation, cease to operate at the expiration of one month
unless before the expiration of that period it has been approved by resolutions of both Houses of
Parliament:Provided that if any such Proclamation (not being a Proclamation revoking a previous
Proclamation) is issued at a time when the House of the People has been dissolved, or place during
the period of one month referred to in this clause, and if a resolution approving the Proclamation
has been passed by the Council of States, but no resolution with respect to such Proclamation has
been passed by the House of the People before the expiration of that period, the Proclamation shall
cease to operate at the expiration of thirty days from the date on which the House of the People first
sits after its reconstitution, unless before the expiration of the said period of thirty days a resolution
approving the Proclamation has been also passed by the House of the People.(5)A Proclamation so
approved shall, unless revoked, cease to operate on the expiration of a period of six months from theConstitution of India

date of the passing of the second of the resolutions approving the proclamation under clause
(4):Provided that if and so often as a resolution approving the continuance in force of such a
Proclamation is passed by both Houses of Parliament the Proclamation shall, unless revoked,
continue in force for a further period of six months from the date on which it would otherwise have
ceased to operate under this clause.Provided further that if the dissolution of the House of the
People takes place during any such period of six months and a resolution approving the continuance
in force of such Proclamation has been passed by the House of the People during the said period, the
Proclamation shall cease to operate at the expiration of thirty days from the date on which the
House of the People first sits after its reconstitution unless before the expiration of the said period of
thirty days, a resolution approving the continuance in force of the proclamation has been also
passed by the House of the People.(6)For the purpose of clause (4) and (5), a resolution may be
passed by either House of Parliament only by a majority of the total membership of that House and
by a majority of not less than two-thirds of themembers of that House present and
voting.(7)Notwithstanding anything contained in the foregoing clauses, the President shall revoke a
Proclamation issued under clause (1) or a Proclamation varying such Proclamation if the House of
the People passes a resolution disapproving, or, as the case may be, disapproving the continuance in
force of, such Proclamation.(8)Where a notice in writing signed by not less than one-tenth of the
total number of members of the House of the People has been given of, their intention to move a
resolution for disapproving, or, as the case may be, for disapproving the continuance in force of, a
Proclamation issued under clause (I) or a Proclamation varying such Proclamation,--(a)to the
Speaker, if the House is in session; or(b)10 the President, if the House is not in session,a special
sitting of the House shall be held within fourteen days from the dale on which such notice is received
by the Speaker, or as the case may be, by the President, for the purpose of considering such
resolution.(9)The power conferred on the President by this article shall include the power to issue
different Proclamations on different grounds, being war or external aggression or armed rebellion or
imminent danger of war or external aggression or armed rebellion, whether or not there is a
Proclamation already issued by the President under clause (1) and such Proclamation is in
operation.[Editorial comment-The Constitution (Thirty-Eighth Amendment) Act, 1975,
Amended Article 352 of the Constitution of India, has been amended by adding two clauses that say
the president has the power to declare an emergency to issue a different proclamation on different
grounds, such as war or external aggression, or internal disturbance."Also Refer][Editorial
comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and
also took out Article 31(1) has been taken out of Part III and made a separate Article 300A in
Chapter IV of Part XII. This amendment may have taken away the scope of speedy remedy under
Article 32 for the violation of Right to Property because it is no more a Fundamental Right. Making
it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis to the value of
socialism included in the preamble and secondly, in doing so, it conformed to the doctrine of basic
structure of the Constitution. Also Refer]
353. Effect of Proclamation of Emergency
While a Proclamation of Emergency is in operation, then--(a)notwithstanding anything in this
Constitution, the executive power of the Union shall extend to the giving of directions to any State as
to the manner in which the executive power thereof is to be exercised;(b)the power of Parliament toConstitution of India

make laws with respect to any matter shall include power to make laws conferring powers and
imposing duties, or authorising the conferring of powers and the imposition of duties, upon the
Union or officers and authorities of the Union as respects that matter, notwithstanding that it is one
which is not enumerated in the Union List;Provided that where a Proclamation of Emergency is in
operation only in any part of the territory of India,--(i)the executive power of me Union to give
directions under clause (a), and(ii)the power of Parliament to make laws under clause (b), shall also
extend to any State other than a State in which or in any part of which the Proclamation of
Emergency is in operation if and in so far as the security of India or any part of the territory thereof
is threatened by activities in or in relation to the part of the territory of India in which the
Proclamation of Emergency is in operation.
354. Application of provisions relating to distribution of revenues while a
Proclamation of Emergency is in operation
(1)The President may, while a Proclamation of Emergency is in operation, by order direct that all or
any of the provisions of articles 268 to 279 shall for such period, not extending in any case beyond
the expiration of the financial year in which such Proclamation ceases to operate, as may be
specified in the order, have effect subject to such exceptions or modifications as he thinks
fit.(2)Every order made under clause (1) shall, as soon as may be after it is made, be laid before each
House of Parliament.
355. Duty of the Union to protect States against external aggression and
internal disturbance
It shall be the duty of the Union to protect every State against external aggression and internal
disturbance and to ensure that the Government of every State is carried on in accordance with the
provisions of this Constitution.
356. Provisions in case of failure of constitutional machinery in State
(1)If the President, on receipt of report from the Governor of the State or otherwise, is satisfied that
a situation has arisen in which the government of the State cannot be carried on in accordance with
the provisions of this Constitution, the President may by Proclamation-(a)assume to himself all or
any of the functions of the Government of the State and all or any of the powers vested in or
exercisable by the Governor or any body or authority in the State other than the Legislature of the
State;(b)declare that the powers of the Legislature of the State shall be exercisable by or under the
authority of Parliament;(c)make such incidental and consequential provisions as appear to the
President to be necessary or desirable for giving effect to the objects of the Proclamation, including
provisions for suspending in whole or in part the operation of any provisions of this Constitution
relating to any body or authority in the State:Provided that nothing in this clause shall authorise the
President to assume to himself any of the powers vested in or exercisable by a High Court, or to
suspend in whole or in part the operation of any provision of this Constitution relating to High
Courts.(2)Any such Proclamation may be revoked or varied by a subsequent Proclamation.(3)EveryConstitution of India

Proclamation under this article shall be laid before each house of Parliament and shall, except where
it is a Proclamation revoking a previous Proclamation, cease to operate at the expiration of two
months unless before the expiration of that period it has been approved by resolutions of both
Houses of Parliament:Provided that if any such Proclamation (not being a Proclamation revoking a
previous Proclamation) is issued at a time when the House of the People is dissolved or the
dissolution of the House of the People takes place during the period of two months referred to in
this clause, and if a resolution approving the Proclamation has been passed by the Council of States,
but no resolution with respect to such Proclamation has been passed by the House of the People
before the expiration of that period, the Proclamation shall cease to operate at the expiration of
thirty days from the date on which the House of the People first sits after its reconstitution unless
before the expiration of the said period of thirty days a resolution approving the Proclamation has
been also passed by the House of the People.(4)A Proclamation so approved shall, unless revoked,
cease to operate on the expiration of a period of six months from the date of issue of the
Proclamation:Provided that if and so often as a resolution approving the continuance in force of
such a Proclamation is passed by both Houses of Parliament, the Proclamation shall, unless
revoked, continue in force for a further period of six months from the date on which under this
clause it would otherwise have ceased to operate, but no such Proclamation shall in any case remain
in force for more than three years:Provided further that if the dissolution of the House of the People
takes place during any such period of six months and a resolution approving the continuance in
force of such Proclamation has been passed by the Council of States, but no resolution with respect
to the continuance in force of such Proclamation has been passed by the House of the People during
the said period, the Proclamation shall cease to operate at the expiration of thirty days from the date
on which the House of the People first sits after its reconstitution unless before the expiration of the
said period of thirty days a resolution approving the continuance in force of the Proclamation has
been also passed by the House of the People:Provided also that in the case of the Proclamation
issued under clause (1) on the 11th day of May, 1987 with respect to the State of Punjab, the
reference in the first proviso to this clause to "three years" shall be construed as a reference to five
years.(5)Notwithstanding anything contained in clause (4), a resolution with respect to the
continuance in force of a Proclamation approved under clause (3) for any period beyond the
expiration of one year from the date of issue of such proclamation shall not be passed by either
House of Parliament unless--(a)a Proclamation of Emergency is in operation, in the whole of India
or, as the case may be, in the whole or any part of the State, at the time of the passing of such
resolution, and(b)the Election Commission certifies that the continuance in force of the
Proclamation approved under clause (3) during the period specified in such resolution is necessary
on account of difficulties in holding general elections to the Legislative Assembly of the State
concerned:Provided that nothing in the clause shall apply to the Proclamation issued under clause
(1) on the 11th day of May, 1987 with respect to the State of Punjab.[Editorial comment-The
Constitution (Thirty-Eighth Amendment) Act, 1975, Amendment of Article 356 of the constitution
has been amended by inserting a new clause. By this insertion, the satisfaction of the president
mentioned in clause (1) shall be final and conclusive and shall not be questioned in any court on any
ground."Also Refer][Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978,
repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a
separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of
speedy remedy under Article 32 for the violation of Right to Property because it is no more aConstitution of India

Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer][Editorial
comment-The Constitution (Forty-Eighth Amendment) Act, 1984, inserted a new proviso in clause
(5) of article 356 of the Constitution in order to provide that in the case of the Proclamation issued
by the President on 6 October 1983 with respect to the State of Punjab, Parliament may pass any
resolution with respect to the continuance in force of the Proclamation for a period up to two
years.Also Refer ][Editorial comment-The Constitution (Sixty-fourth Amendment) Act, 1990,
aimed to address the pressing issues in the State of Punjab and proposed to amend Article 356 to
facilitate the extension of Proclamations related to the region. The amendment of the Indian
Constitution added a proviso to Article 356(4) to allow for the extension of the President’s Rule for a
total period of three years and six months in the state of Punjab.Also Refer][Editorial
comment-The Constitution (Sixty-Seventh Amendment) Act of 1990 , amended clause (5) of
Article 356 and lengthened the three-year time frame in the particular instance of the Declaration
made available on May 11, 1987, with regard to the State of Punjab to 3 years and 6 months. In the
hope that the State’s Legislative Assembly polls were indeed able to go ahead. Unfortunately, the
then-current state of affairs in the State still didn’t offer much hope for fair and peaceful election
polls to the State Legislative Assembly. Therefore it was recommended to change clause (4) of
Article 356 of the Indian Constitution to make it easier to extend the Proclamation mentioned above
in reference to the State of Punjab for a maximum of four years.Also Refer][Editorial
comment-The Constitution (Sixty-eighth Amendment) Act, 1991, altered Clause (4) of Article 356
of the Constitution for the third time. It enabled the aforementioned Proclamation regarding the
State of Punjab to be prolonged for a total of five years. However, under clause (5) of the said article,
a resolution approving the continuance in force of a Proclamation issued under clause (1) of that
article beyond a period of one year cannot be passed by either House of Parliament unless the two
conditions relating to a Proclamation of Emergency being in operation in the whole or any part of
the State and the certificate by the Election Commission that the continuation of the Proclamation
issued under clause (1) is necessary on account of difficulties in holding general elections to the
Legislative Assembly of the State as specified in that clause are met. Therefore, the prevailing
circumstances still do not hold out prospects for fair, free and peaceful elections to the Legislative
Assembly of Punjab.Also Refer]
357. Exercise of legislative powers under Proclamation issued under article
356
(1)Where by a Proclamation issued under clause (1) of article 356, it has been declared that the
powers of the Legislature of the State shall be exercisable by or under the authority of Parliament, it
shall be competent-(a)for Parliament to confer on the President the power of the Legislature of the
State to make laws, and to authorise the President to delegate, subject to such conditions as he may
think fit to impose, the power so conferred to any other authority to be specified by him in that
behalf;(b)for Parliament, or for the President or other authority in whom such power to make laws
is vested under sub-clause (a), to make laws conferring powers and imposing duties, or authorising
the conferring of powers and the imposition of duties, upon the Union or officers and authorities
thereof;(c)for the President to authorise when the House of the People is not in session expenditureConstitution of India

from the Consolidated Fund of the State pending the sanction of such expenditure by
Parliament.(2)Any law made in exercise of the power of the Legislature of the State by Parliament or
the President or other authority referred to in sub-clause (a) of clause (1) which Parliament or the
President or such other authority would not, but for the issue of a Proclamation under article 356,
have been competent to make shall, after the Proclamation has ceased to operate, continue in force
until altered or repealed or amended by a competent Legislature or other authority.[Editorial
comment-The Constitution (Forty-Second Amendment) Act, 1976,  Article 357 was amended so as
to ensure that laws made for a State, while it was under Article 356 emergency, would not cease
immediately after the expiry of the emergency, but would instead continue to be in effect until the
law was changed by the State Legislature.Also Refer]
358. Suspension of provisions of article 19 during emergencies
(1)While a Proclamation of Emergency declaring that the security of India or any part of the
territory thereof is threatened by war or by external aggression is in operation, nothing in article 19
shall restrict the power of the State as defined in Part III to make any law or to take any executive
action which the State would but for the provisions contained in that Part be competent to make or
to take, but any law so made shall, to the extent of the incompetency, cease to have effect as soon as
the Proclamation ceases to operate, except as respects things done or omitted to be done before the
law so ceases to have effect:Provided that where such Proclamation of Emergency is in operation
only in any part of the territory of India, any such law may be made, or any such executive action
may be taken, under this article in relation to or in any State or Union territory in which or in any
part of which the Proclamation of Emergency is not in operation, if and in so far as the security of
India or any part of the territory thereof is threatened by activities in or in relation to the part of the
territory of India in which the Proclamation of Emergency is in operation.(2)Nothing in clause (1)
shall apply--(a)to any law which does not contain a recital to the effect that such law is in relation to
the Proclamation of Emergency in operation when it is made; or(b)to any executive action taken
otherwise than under a law containing such a recital.[Editorial comment-The Constitution
(Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has
been taken out of Part III and made a separate Article 300A in Chapter IV of Part XII. This
amendment may have taken away the scope of speedy remedy under Article 32 for the violation of
Right to Property because it is no more a Fundamental Right. Making it a legal right under the
Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism included in the
preamble and secondly, in doing so, it conformed to the doctrine of basic structure of the
Constitution. Also Refer][Editorial comment-The Constitution (Forty-Second Amendment) Act,
1976, Articles 358 were amended, to allow suspension of Fundamental Rights, and suspension of
enforcement of any of the rights conferred by the Constitution during an Emergency.Also Refer]
359. Suspension of the enforcement of the rights conferred by Part III during
emergencies
(1)Where a Proclamation of Emergency is in operation, the President may by order declare that the
right to move any court for the enforcement of such of the rights conferred by Part III (except
articles 20 and 21) as may be mentioned in the order and all proceedings pending in any court forConstitution of India

the enforcement of the rights so mentioned shall remain suspended for the period during which the
Proclamation is in force or for such shorter period as may be specified in the order.(1A)While an
order made under clause (1) mentioning any of the rights conferred by Part III (except articles 20
and 21) is in operation, nothing in that Part conferring those rights shall restrict the power of the
State as defined in the said Part to make any law or to take any executive action which the State
would but for the provisions containing in that Part be competent to make or to take, but any law so
made shall, to the extent of the incompetency, cease to have effect as soon as the order aforesaid
ceases to operate, except as respects things done or omitted to be done before the law so ceases lo
have effect.Provided that where a Proclamation of Emergency is in operation only in any part of the
territory of India, any such law may be made, or any such executive action may be taken, under this
article in relation to or in any State or Union territory in which or in any part of which the
Proclamation of Emergency is not in operation, if and in so far as the security of India or any part of
the territory thereof is threatened by activities in or in relation to the part of the territory of India in
which the Proclamation of Emergency is in operation.(1B)Nothing in clause (1A) shall apply-(a)to
any law which does not contain a recital to the effect that such law is in relation to the Proclamation
of Emergency in operation when it is made; or(b)to any executive action taken otherwise than under
a law containing such a recital.(2)An order made as aforesaid may extend to the whole or any part of
the territory of India:Provided that where a Proclamation of Emergency is in operation only in a part
of the territory of India, any such order shall not extend to any other part of the territory of India
unless the President, being satisfied that the security of India or any part of the territory thereof is
threatened by activities in or in relation to the part of the territory of India in which the
Proclamation of Emergency is in operation, considers such extension to be necessary.(3)Every order
made under clause (1) shall, as soon may be after it is made, be laid before each House of
Parliament.[Editorial comment-The Constitution (Thirty-Eighth Amendment) Act, 1975,
Amendment of article 359 of the constitution by inserting therein a new clause. it states that while
an order issued by the President under clause (1) suspends enforcement of any of the rights
conferred by Part III of the Constitution during emergencies, nothing in that Part shall limit the
State’s power to make any law or take any executive action that the State would be competent to
make or take but for the provisions contained in Part III. It also states that any legislation thus
enacted must, to the degree of incompetence, cease to have force as soon as the Presidential order
ceases to function, save in respect of actions done or omitted to be done before the law so ceases to
have an effect.Also Refer][Editorial comment-The Constitution (Forty-Fourth Amendment) Act,
1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and
made a separate Article 300A in Chapter IV of Part XII. This amendment may have taken away the
scope of speedy remedy under Article 32 for the violation of Right to Property because it is no more
a Fundamental Right. Making it a legal right under the Constitution serves two purposes: Firstly, it
gives emphasis to the value of socialism included in the preamble and secondly, in doing so, it
conformed to the doctrine of basic structure of the Constitution. Also Refer][Editorial
comment-The Constitution (Forty-Second Amendment) Act, 1976, artyicle 359 were amended, to
allow suspension of Fundamental Rights, and suspension of enforcement of any of the rights
conferred by the Constitution during an Emergency. Also Refer]Constitution of India

359A. Application of this Part to the State of Punjab [Repealed]
Notwithstanding anything in this Constitution, the President may by order declare that the right to
move any court for the enforcement of such of the rights conferred by Part III as may be mentioned
in the order and all proceedings pending in any court for the enforcement of the rights so mentioned
shall remain suspended for the period during which the proclamation of emergency declaring that
the security of India or any part of the territory thereof is threatened by war or external aggression
or armed rebellion is in operation, except where an order of suspension is made by the President
under this article in relation to the enforcement of any of the rights conferred by Article 20 or Article
21.[Editorial comment-The Constitution (Fifty-Ninth Amendment) Act, 1988, rendered power in
the hands of the Central Government to declare an Emergency in the state of Punjab. Under this act,
Article 356 of the Indian Constitution was amended to allow the President’s rule in the state of
Punjab for a period of up to three years as previously, the maximum period for this rule was two
years. It also added Article 359A to the Indian Constitution.Also Refer][Repealed by the
Constitution (Sixty-third Amendment) Act, 19S9, (w.e.f. 6-1-1990).][Editorial comment-The
Constitution (Sixty-Third Amendment) Act of 1989, nullified the 59th Amendment of the Indian
Constitution of 1988, which granted the governmental power to declare a state of emergency in
Punjab. To address the deteriorating terrorist threat in Punjab, the government intended to declare
an emergency under the 59th Amendment to the Constitution, which was hurriedly passed by both
houses of Parliament. When considered essential, it gave the Central Government the power to
declare an emergency in Punjab. The amendment guarantees an extension of a maximum of three
years of the President’s rule. Previously, two years was the previous maximum time frame.Also
Refer]
360. Provisions as to financial emergency
(1)If the President is satisfied that a situation has arisen whereby the financial stability or credit of
India or of any part of the territory thereof is threatened, he may by a Proclamation make a
declaration to that effect.(2)A Proclamation issued under clause (1)--(a)may be revoked or varied by
a subsequent Proclamation;(b)shall be laid before each House of Parliament;(c)shall cease to
operate at the expiration of two months unless before the expiration of that period it has been
approved by resolutions of both Houses of Parliament:Provided that if any such Proclamation is
issued at a time when the House of the People has been dissolved or the dissolution of the House of
the People takes place during the period of two months referred to in sub-clause (c), and if a
resolution approving the Proclamation has been passed by the Council of States, but no resolution
with respect to such Proclamation has been passed by the House of the People before the expiration
of that period, the Proclamation shall cease to operate at the expiration of thirty days from the date
on which the House of the People first sits after its reconstitution, unless before the expiration of the
said period of thirty days a resolution approving the Proclamation has been also passed by the
House of the People.(3)During the period any such Proclamation as is mentioned in clause (1) is in
operation, the executive authority of the Union shall extend to the giving of directions to any State to
observe such canons of financial propriety as may be specified in the directions, and to the giving of
such other directions as the President may deem necessary and adequate for the
purpose.(4)Notwithstanding anything in this Constitution--(a)any such direction may include--(i)aConstitution of India

provision requiring the reduction of salaries and allowances of all or any class of persons serving in
connection with the affairs of a State;(ii)a provision requiring all Money Bills or other Bills to which
the provisions of article 207 apply to be reserved for the consideration of the President after they are
passed by the Legislature of the State;(b)it shall be competent for the President during the period
any Proclamation issued under this article is in operation to issue directions for the reduction of
salaries and allowances of all or any class of persons serving in connection with the affairs of the
Union including the Judges of the Supreme Court and the High Courts.[Editorial comment-The
Constitution (Thirty-Eighth Amendment) Act, 1975, Amendment of article 360, The article has been
updated with a new clause. By virtue of this provision, the satisfaction of the President expressed in
clause (1) regarding the proclamation of Financial Emergency is final and conclusive and is not
justiciable in any Court for any reason."Also Refer][Editorial comment-The Constitution
(Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has
been taken out of Part III and made a separate Article 300A in Chapter IV of Part XII. This
amendment may have taken away the scope of speedy remedy under Article 32 for the violation of
Right to Property because it is no more a Fundamental Right. Making it a legal right under the
Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism included in the
preamble and secondly, in doing so, it conformed to the doctrine of basic structure of the
Constitution. Also Refer]
Part XIX – Miscellaneous
361. Protection of President and Governors and Rajpramukhs
(1)The President, or the Governor or Rajpramukh of a State, shall not be answerable to any court for
the exercise and performance of the powers and duties of hi s office or for any act done or
purporting to be done by hi m in the exercise and performance of those powers and duties :Provided
that the conduct of the President may be brought under review by any court, tribunal or body
appointed or designated by either House of Parliament for the investigation of a charge under article
61 :Provided further that nothing in this clause shall be construed as restricting the right of any
person to bring appropriate proceedings against the Government of India or the Government of a
State.(2)No criminal proceedings whatsoever shall be instituted or continued against the President,
or the Governor of a State, in any court during hi s term of office.(3)No process for the arrest or
imprisonment of the President, or the Governor of a State, shall issue from any court during hi s
term of office.(4)No civil proceedings in which relief is claimed against the President, or the
Governor of a State, shall be instituted during hi s term of office in any court in respect of any act
done or purporting to be done by hi m in hi s personal capacity, whether before or after he entered
upon hi s office as President, or as Governor of such State, until the expiration of two months next
after notice in writing has been delivered to the President or the Governor, as the case may be, or left
at hi s office stating the nature of the proceedings, the cause of action therefor, the name,
description and place of residence of the party by whom such proceedings are to be instituted and
the relief which he claims.Constitution of India

361A. Protection of publication of proceedings of Parliament and State
Legislatures
(1)No person shall be liable to any proceedings, civil or criminal, in any court in respect of the
publication in a newspaper of a substantially true report of any proceedings of either House of
Parliament or the Legislative Assembly, or, as the case may be, either House of the Legislature of a
State, unless the publication is proved to have been made with malice:Provided that nothing in this
clause shall apply to the publication of any report of the proceedings of a secret sitting of either
House of Parliament or the Legislative Assembly, or, as the case may be, either House of the
Legislature, of a State.(2)Clause (1) shall apply in relation to reports or matters broadcast, by means
of wireless telegraphy as part of any programme or service provided by means of a broadcasting
station as it applies in relation to reports or matters published in a newspaper.Explanation.--In this
article, "newspaper" includes a news agency report containing material for publication in a
newspaper.[Editorial comment-The Constitution (Forty-Fourth Amendment) Act, 1978, repealed
Article 19 (1) (f) and also took out Article 31(1) has been taken out of Part III and made a separate
Article 300A in Chapter IV of Part XII. This amendment may have taken away the scope of speedy
remedy under Article 32 for the violation of Right to Property because it is no more a Fundamental
Right. Making it a legal right under the Constitution serves two purposes: Firstly, it gives emphasis
to the value of socialism included in the preamble and secondly, in doing so, it conformed to the
doctrine of basic structure of the Constitution. Also Refer]
361B. Disqualification for appointment on remunerative political post
A member of a house belonging to any political party who is disqualified for being a member of a
House under paragraph 2 of the Tenth Schedule shall also be disqualified to hold any remunerative
political post for duration of the period commencing from the date of his disqualification till the date
on which he contests an election to a House and is declared elected, whichever is
earlier.Explanation--For the purpose of this article,-(a)the expression "House" has the meaning
assigned to it in clause (a) of paragraph 1 of the Tenth Schedule;(b)the expression "remunerative
political post" means any office-(i)Under the Government of India or the Government of a State
where the salary or remuneration for such office is paid out of the public revenue of the Government
of India or the Government of the State, as the case may be; or(ii)Under a body, whether
incorporated or not, which is wholly or partially owned by the Government of India or the
Government of a State and the salary or remuneration for such office is paid by such body, except
where such salary or remuneration paid is compensatory in nature.
362. Rights and privileges of Rulers of Indian States [REPEALED]
In the exercise of the power of Parliament or of the Legislature of a State to make laws or in the
exercise of the executive power of the Union or of a State, due regard shall be had to the guarantee
or assurance given under any such covenant or agreement as is referred to in clause (1) of article 291
with respect to the personal rights, privileges and dignities of the Ruler of an Indian
State.[[Editorial comment-[Repealed by the Constitution (Twenty-sixth Amendment) Act,Constitution of India

1971.][Editorial comment-The Constitution (Twenty-Sixth Amendment) Act, 1971, the 26th
Amendment of Indian Constitution of 1971 removed Articles 362. The former dealt with the details
of privy purse sums and the latter guaranteed specific rights and privileges to rulers of princely
states. The ‘privy purse’ was guaranteed by Articles 362 in the Indian constitution, which ensured
that princes would receive tax-free privy purses, equivalent to one-fourth of the money they earned
earlier. Thus, with the omission of 362, the privy purse which was paid to former princely states was
removed. Important Verdict-Shri Raghunathrao Ganpatrao vs Union Of India ]
363. Bar to interference by courts in disputes arising out of certain treaties,
agreements, etc.
(1)Notwithstanding anything in this Constitution but subject to the provisions of article 143, neither
the Supreme Court nor any other court shall have jurisdiction in any dispute arising out of any
provision of a treaty, agreement, covenant, engagement, sanad or other similar instrument which
was entered into or executed before the commencement of this Constitution by any Ruler of an
Indian State and to which the Government was a party and which has or has been continued in
operation after such commencement, or in any dispute in respect of any right accruing under or any
liability or obligation arising out of any of the provisions of this Constitution relating to any such
treaty, agreement, covenant, engagement, sanad or other similar instrument.(2)In this
article--(a)"Indian State" means any territory recognised before the commencement of this
Constitution by his Majesty or the Government of the Dominion of India as being such a State;
and(b)"Ruler" includes the Prince, Chief or other person recognised before such commencement by
his Majesty or the Government of the Dominion of India as the Ruler of any Indian State.
363A. Recognition granted to Rulers of Indian States to cease and privy
purses to be abolished
[After article 363 of the Constitution, the following article shall be inserted through Constitution
(Twenty-Sixth Amendment) Act, 1971]Notwithstanding anything in this Constitution or in any law
for the time being, in force--(a)the Prince, Chief or other person who, at any time before the
commencement of me Constitution (Twenty-sixth Amendment) Act, 1971, was recognised by the
President as the Ruler of an Indian State or any person who, at any time before such
commencement, was recognised by the President as the successor of such Ruler shall, on and from
such commencement, cease to be recognised as such Ruler or the successor of such Ruler;(b)on and
from the commencement of the Constitution (Twenty-sixth Amendment) Act, 1971, privy purse is
abolished and all rights, liabilities and obligations in respect of privy purse are extinguished and
accordingly the Ruler or, as the case may be, the successor of such Ruler, referred to in clause (a) or
any other person shall not be paid any sum as privy purse.[Editorial comment-The Constitution
(Twenty-Sixth Amendment) Act, 1971, the 26th amendment to the Indian constitution adds Article
363A to the Constitution which stripped any princely state ruler of their title and privileges. ]}}Constitution of India

364. Special provisions as to major ports and aerodromes
(1)Notwithstanding anything in this Constitution, the President may by public notification direct
that as from such date as may be specified in the notification--(a)any law made by Parliament or by
the Legislature of a State shall not apply to any major port or aerodrome or shall apply thereto
subject to such exceptions or modifications as may be specified in the notification, or(b)any existing
law shall cease to have effect in any major port or aerodrome except as respects things done or
omitted to be done before the said date, or shall in its application to such port or aerodrome have
effect subject to such exceptions or modifications as may be specified in the notification.(2)In this
article--(a)"major port" means a port declared to be a major port by or under any law made by
Parliament or any existing law and includes all areas for the time being included within the limits of
such port;(b)"aerodrome" means aerodrome as defined for the purposes of the enactment's relating
to airways, aircraft and air navigation.
365. Effect of failure to comply with, or to give effect to, directions given by
the Union
Where any State has failed to comply with or to give effect to any directions given in the exercise of
the executive power of the Union under any of the provisions of this Constitution, it shall be lawful
for the President to hold that a situation has arisen in which the Government of the State cannot be
carried on in accordance with the provisions of this Constitution.
366. Definitions
In this Constitution, unless the context otherwise requires, the following expressions have, the
meanings hereby respectively assigned to them, that is to say--(1)"agricultural income" means
agricultural income as defined for the purposes of the enactments relating to Indian
income-tax;(2)"an Anglo-Indian" means a person whose father or any of whose other male
progenitors in the male line is or was of European descent but who is domiciled within the territory
of India and is or was born within such territory of parents habitually resident therein and not
established there for temporary purposes only;(3)"article" means an article of this
Constitution;(4)"borrow" includes the raising of money by the grant of annuities, and "loan" shall be
construed accordingly;(4A)In this Constitution, unless the context otherwise requires, 'State'
includes the Union territories and the National Capital Territory of Delhi, but does not include the
States of Jammu and Kashmir, Nagaland, Manipur, Tripura, Mizoram and Arunachal Pradesh.[In
article 366 of the Constitution, clause (4A) shall be omitted.][The Constitution (Forty-Third
Amendment) Act, 1977, Clauses 4(A) and 26(A) of Article 366 of the Constitution must be
deleted.Also Refer](5)"clause" means a clause of the article in which the expression
occurs;(6)"corporation tax" means any tax on income, so far as that tax is payable by companies and
is a tax in the case of which the following conditions are fulfilled:--(a)that it is not chargeable in
respect of agricultural income;(b)that no deduction in respect of the tax paid by companies is, by
any enactments which may apply to the tax, authorised to be made from dividends payable by the
companies to individuals;(c)that no provision exists for taking the tax so paid into account inConstitution of India

computing for the purposes of Indian income-tax the total income of individuals receiving such
dividends, or in computing the Indian income-tax payable by, or refundable to, such
individuals;(7)"corresponding Province", "corresponding Indian State" or "corresponding State"
means in cases of doubt such Province, Indian State or State as may be determined by the President
to be the corresponding Province, the corresponding Indian State or the corresponding State, as the
case may be, for the particular purpose in question;(8)"debt" includes any liability in respect of any
obligation to repay capital sums by way of annuity and any liability under any guarantee, and "debt
charges" shall be construed accordingly;(9)"estate duty" means a duty to be assessed on or by
reference to the principal value, ascertained in accordance with such rules as may be prescribed by
or under laws made by Parliament or the Legislature of a State relating to the duty, of all property
passing upon death or deemed, under the provisions of the said laws, so to pass;(10)"existing law"
means any law, Ordinance, order, bye-law, rule or regulation passed or made before the
commencement of this Constitution by any Legislature, authority or person having power to make
such a law, Ordinance, order, bye-law, rule or regulation;(11)"Federal Court" means the Federal
Court constituted under the Government of India Act, 1935;(12)"goods" includes all materials,
commodities, and articles;(12A)“goods and services tax” means any tax on supply of goods, or
services or both except taxes on the supply of the alcoholic liquor for human
consumption.(13)"guarantee" includes any obligation undertaken before the commencement of this
Constitution to make payments in the event of the profits of an undertaking falling short of a
specified amount;(14)"High Court" means any court which is deemed for the purposes of this
Constitution to be a High Court for any State and includes--(a)any Court in the territory of India
constituted or reconstituted under this Constitution as a High Court, and(b)any other Court in the
territory of India which may be declared by Parliament by law to be a High Court for all or any of the
purposes of this Constitution;(15)"Indian State" means any territory which the Government of the
Dominion of India recognised as such a State;(16)"Part" means a part of this
Constitution;(17)"pension" means a pension, whether contributory or not, of any kind whatsoever
payable to or in respect of any person, and includes retired pay so payable, a gratuity so payable and
any sum or sums so payable by way of the return, with or without interest thereon or any other
addition thereto, of subscriptions to a provident fund;(18)"Proclamation of Emergency" means a
Proclamation issued under clause (1) of article 352;(19)"public notification" means a notification in
the Gazette of India, or, as the case may be, the Official Gazette of a State;(20)"railway" does not
include--(a)a tramway wholly within a municipal area, or(b)any other line of communication wholly
situate in one State and declared by Parliament by law not to be a railway;[In article 366 of the
Constitution, for clause (22), the following clause shall be substituted through Constitution
(Twenty-Sixth Amendment) Act, 1971](22)"Ruler" means the Prince, Chief or other person who, at
any time before the commencement of the Constitution (Twenty-sixth Amendment) Act, 1971, was
recognised by the President as the Ruler of an Indian State or any person who, at any time before
such commencement, was recognised by the President as the successor of such Ruler;[Editorial
comment-The Constitution (Twenty-Sixth Amendment) Act, 1971, this amendment was concerned
with the substitution for Clause (22) in Article 366 with a more clear definition of “ruler”. Under this
amendment, “ruler” refers to any prince, chief, or other person acknowledged by the President as
the Ruler of an Indian State prior to the initiation of the Indian Constitution, as well as any person
acknowledged by the President as the ruler’s successor at that time.Important Verdict-Shri
Raghunathrao Ganpatrao vs Union Of India](23)"Schedule" means a Schedule to thisConstitution of India

Constitution;(24)"Scheduled Castes" means such castes, races or tribes or parts of or groups within
such castes, races or tribes as are deemed under article 341 to be Scheduled Castes for the purposes
of this Constitution;(25)"Scheduled Tribes" means such tribes or tribal communities or parts of or
groups within such tribes or tribal communities as are deemed under article 342 to be Scheduled
Tribes for the purposes of this Constitution;(26)"securities" includes stock;[In article 366 of the
Constitution, clause (26A) shall be omitted.](26-A) "Services" means anything other than
goods;(26-B) "State" with reference to Articles 246-A, 268, 269, 269-A and Article 279-A includes a
Union territory with Legislature;(26C)"socially and educationally backward classes" means such
backward classes as are so deemed under article 342A for the purposes of this
Constitution;[Editorial comment-The Constitution (One Hundred and Second Amendment) Act,
2018, was amended to include the words “socially and educationally backward classes” to define the
backward classes deemed by the Central Government and States and Union Territories of India.Also
Refer][In article 366 of the Constitution, for clause (26C), the following clause shall be
substituted Constitution (One Hundred and Five Amendment) Act, 2021](26C)[socially
and educationally backward classes” means such backward classes as are so deemed under article
342A for the purposes of the Central Government or the State or Union territory, as the case may
be](27)"sub-clause" means a sub-clause of the clause in which the expression occurs;(28)"taxation"
includes the imposition of any tax or impost, whether general or local or special, and "tax" shall be
construed accordingly;(29)"tax on income" includes a tax in the nature of an excess profits
tax;(29A)"tax on the sale or purchase of goods" includes--(a)a tax on the transfer, otherwise than in
pursuance of a contract, of property in any goods for cash, deferred payment or other valuable
consideration;(b)a tax on the transfer of property in goods (whether as goods or in some other form)
involved in the execution of a works contract;(c)a tax on the delivery of goods on hire-purchase or
any system of payment by installments;(d)a tax on the transfer of the right to use any goods for any
purpose (whether or not for a specified period) for cash, deferred payment or other valuable
consideration;(e)a tax on the supply of goods by any unincorporated association or body of persons
to a member thereof for cash, deferred payment or other valuable consideration;(f)a tax on the
supply, by way of or as part of any service or in any other manner whatsoever, of goods, being food
or any other article for human consumption or any drink (whether or not intoxicating), where such
supply or service, is for cash, deferred payment or other valuable consideration, and such transfer,
delivery or supply of any goods shall be deemed to be a sale of those goods by the person making the
transfer, delivery or supply and a purchase of those goods by the person to whom such transfer,
delivery or supply is made;[Editorial comment- The Constitution (Forty-Sixth Amendment) Act,
1982, this amendment modifies article 336 where amendment was made to negate judicial
pronouncements on scope and applicability on Sales Tax. Also Refer](30)"Union territory" means
any Union territory specified in the First Schedule and includes any other territory comprised within
the territory of India but not specified in that Schedule.
367. Interpretation
(1)Unless the context otherwise requires, the General Clauses Act, 1897, shall, subject to any
adaptations and modifications that may be made therein under article 372, apply for the
interpretation of this Constitution as it applies for the interpretation of an Act of the Legislature of
the Dominion of India.(2)Any reference in this Constitution to Acts or laws of, or made by,Constitution of India

Parliament, or to Acts or laws of, or made by, the Legislature of a State , shall be construed as
including a reference to an Ordinance made by the President or, to an Ordinance made by a
Governor , as the case may be.(3)For the purposes of this Constitution "foreign State" means any
State other man India:Provided that, subject to the provisions of any law made by Parliament, the
President may by orderdeclare any State not to be a foreign State for such purposes as may be
specified in the order.
Part XX – Amendment of the Constitution
368. Power of Parliament to amend the Constitution and procedure therefor
(1)Notwithstanding anything in this Constitution, Parliament may in exercise of its constituent
power amend by way of addition, variation or repeal any provision of this Constitution in
accordance with the procedure laid down in this article.(2)An amendment of this Constitution may
be initiated only by the introduction of a Bill for the purpose in either House of Parliament, and
when the Bill is passed in each House by a majority of the total membership of that House and by a
majority of not less than two-thirds of the members of that House present and voting, it shall be
presented to the President who shall give his assent to the Bill and thereupon the Constitution shall
stand amended in accordance with the terms of the Bill:Provided that if such amendment seeks to
make any change in--(a)article 54, article 55, article 73, article 162 or article 241, or(b)Chapter IV of
Part V, Chapter V of Part VI, or Chapter I of Part XI, or(c)any of the Lists in the Seventh Schedule,
or(d)the representation of States in Parliament, or(e)the provisions of this article.the amendment
shall also require to be ratified by the Legislatures of not less than one-half of the States by
resolution to that effect passed by those Legislatures before the Bill making provision for such
amendment is presented to the President for assent.(3)Nothing in article 13 shall apply to any
amendment made under this article.(4)No amendment of this Constitution (including the
provisions of Part III) made or purporting to have been made under this article whether before or
after the commencement of section 55 of the Constitution (Forty-second Amendment) Act, 1976
shall be called in question in any court on any ground.(5)For the removal of doubts, it is hereby
declared that there shall be no limitation whatever on the constituent power of Parliament to amend
by way of addition, variation or repeal the provisions of this Constitution under this
article.[Editorial comment-The Constitution (Twenty-Four Amendment) Act, 1971, the judgment
reversed the Supreme Court's earlier decision which had upheld Parliament's power to amend all
parts of the Constitution, including Part III related to Fundamental Rights. It amended Article 368
to provide expressly that Parliament has power to amend any provision of the Constitution. The
amendment further made it obligatory for the President to give his assent, when a Constitution
Amendment Bill was presented to him. The government has argued that the 24th Amendment will
help to implement the Directive Principles of State Policy. However, a large section of constitutional
experts would believe that the undisputed authority of Parliament is a threat to the democratic
process in the country. In the Indian Constitution, the balance of legislative power is vital, and the
power of amendment conferred to parliament to alter such regulations is often considered an
important one. Important Verdict-Kesavananda Bharati v. State of Kerala I.C. Golaknath and Ors. vs
State of Punjab and Anrs.. However, the Supreme Court has ruled that the 24th Amendment Act is
Constitutional. The ruling has several important implications. While it confirms that the 24thConstitution of India

Amendment Act is valid, it establishes some significant constituent features like Judicial review and
basic features of the Constitution. Also refer]
Part XXI – Temporary, Transitional and Special Provisions
369. Temporary power to Parliament to make laws with respect to certain
matters in the State List as if they were matters in the Concurrent List
Notwithstanding anything in this Constitution, Parliament shall, during a period of five years from
the commencement of this Constitution, have power to make laws with respect to the following
matters as if they were enumerated in the Concurrent List, namely:--(a)trade and commerce within
a State in, and the production, supply and distribution of, cotton and woollen textiles, raw cotton
(including ginned cotton and unginned cotton or kapas), cotton seed, paper (including newsprint),
foodstuffs (including edible oilseeds and oil), cattle fodder (including oil-cakes and other
concentrates), coal (including coke and derivatives of coal), iron, steel and mica;(b)offences against
laws with respect to any of the matters mentioned in clause (a), jurisdiction and powers of all courts
except the Supreme Court with respect to any of those matters, and fees in respect of any of those
matters but not including fees taken in any court,but any law made by Parliament, which Parliament
would not but for the provisions of this article have been competent to make, shall, to the extent of
the in competency, cease to have effect on the expiration of the said period, except as respects things
done or omitted to be done before the expiration thereof.
370. Temporary provisions with respect to the State of Jammu and Kashmir
(1)Notwithstanding anything in this Constitution,--(a)the provisions of article 238 shall not apply in
relation to the State of Jammu and Kashmir;(b)the power of Parliament to make laws for the said
State shall be limited to-(i)those matters in the Union List and the Concurrent List which, in
consultation with the Government of the State, are declared by the President to correspond to
matters specified in the Instrument of Accession governing the accession of the State to the
Dominion of India as the matters with respect to which the Dominion Legislature may make laws
for that State; and(ii)such other matters in the said Lists as, with the concurrence of the
Government of the State, the President may by order specify.Explanation.--For the purposes of this
article, the Government of the State means the person for the time being recognised by the President
as the Maharaja of Jammu and Kashmir acting on the advice of the Council of Ministers for the time
being in office under the Maharaja's Proclamation dated the fifth day of March, 1948;(c)the
provisions of article 1 and of this article shall apply in relation to that State;(d)such of the other
provisions of this Constitution shall apply in relation to that State subject to such exceptions and
modifications as the President may by orderspecify:Provided that no such order which relates to the
matters specified in the Instrument of Accession of the State referred to in paragraph (i) of
sub-clause (b) shall be issued except in consultation with the Government of the State:Provided
further that no such order which relates to matters other than those referred to in the last preceding
proviso shall be issued except with the concurrence of that Government.(2)If the concurrence of the
Government of the State referred to in paragraph (ii) of sub-clause (b) of clause (1) or in the secondConstitution of India

proviso to sub-clause (d) of that clause be given before the Constituent Assembly for the purpose of
framing the Constitution of the State is convened, it shall be placed before such Assembly for such
decision as it may take thereon.(3)Notwithstanding anything in the foregoing provisions of this
article, the President may, by public notification, declare that this article shall cease to be operative
or shall be operative only with such exceptions and modifications and from such date as he may
specify:Provided that the recommendation of the Constituent Assembly of the State referred to in
clause (2) shall be necessary before the President issues such a notification.[Editorial Note-Article
370 of the Constitution of India provided a special status to the state of Jammu and Kashmir,
granting it a degree of autonomy within the Indian union. Article 370 was incorporated into the
Constitution of India as a temporary provision, with the intention of providing a framework for
negotiations between the Indian government and the leadership of Jammu and Kashmir to
determine the state's final political status. This was done through the instrument of a Presidential
Order in 1954, which extended various provisions of the Indian Constitution to Jammu and
Kashmir, subject to certain modifications. Article 370 was incorporated into the Constitution of
India as a temporary provision, with the intention of providing a framework for negotiations
between the Indian government and the leadership of Jammu and Kashmir to determine the state's
final political status. This was done through the instrument of a Presidential Order in 1954, which
extended various provisions of the Indian Constitution to Jammu and Kashmir, subject to certain
modifications. Article 370 and Article 35A were closely linked in terms of their impact on the
constitutional and legal status of Jammu and Kashmir. Article 370 was the constitutional provision
that granted special status to Jammu and Kashmir, while Article 35A was a legal provision that
flowed from Article 370 and gave the state of Jammu and Kashmir the power to define who is a
"permanent resident" of the state, and to confer special rights and privileges to these residents.
Article 35A was added to the Indian Constitution through a Presidential Order in 1954, which was
issued under the authority of Article 370. The provision allowed the Jammu and Kashmir state
legislature to define permanent residents of the state and provide them with special rights and
privileges, such as the right to own property, access to government jobs, and scholarships. The
provision also prohibited non-permanent residents from acquiring any of these rights or privileges.
In April 2018, the Supreme Court of India ruled that Article 370 had attained permanency since the
state constituent assembly has ceased to exist. To overcome this legal challenge, the Indian
government instead rendered Article 370 as 'Inoperative' even though it still exists in the
constitution. On 5 August, issued a Presidential Order C.O. 272; the Constitution (Application to
Jammu and Kashmir) Order, 2019 which superseded the Constitution (Application to Jammu and
Kashmir) Order, 1954. This in effect meant that the separate Constitution of Jammu and Kashmir
stood inoperative, and a single constitution now applied to all the Indian states. The order was
issued using the third clause of Article 370, which authorized the President of India to declare the
article inoperative with exceptions and modifications, if recommended by the (non-existent) state
constituent assembly to do so. To circumvent the legal issue of the non-existent state constituent
assembly, the President used the Clause (1) of Article 370, which conferred him with the power to
modify the Indian Constitution on subjects related to Jammu and Kashmir. So he first added a new
clause to Article 367, which deals with interpretation of the Constitution. He replaced the phrase
'Constituent Assembly of the State' with 'Legislative Assembly of the State'. Since the state legislative
assembly has been suspended, the order says that any reference to the legislative assembly will be
construed as a reference to the Governor of Jammu and Kashmir. The governor is an appointee ofConstitution of India

the Central government. Therefore, the Indian Parliament now functions for the state legislative
assembly.]
371. Special provision with respect to the States of Maharashtra and Gujarat
(2)Notwithstanding anything in this Constitution, the President may by order made with respect
tothe State of Maharashtra or Gujarat, provide for any special responsibility of the Governor
for-(a)the establishment of separate development boards for Vidarbha, Marathwada,and the rest of
Maharashtra or, as the case may be, Saurashtra, Kutch and the rest of Gujarat with the provision
that a report on the working of each of rest of these boards will be placed each year before the State
Legislative Assembly;(b)the equitable allocation of funds for developmental expenditure over the
said areas, subject to the requirements of the State as a whole; and(c)an equitable arrangement
providing adequate facilities for technical education and vocational training, and adequate
opportunities for employment in service under the control of the State Government, in respect of all
the said areas, subject to the requirements of the State as a whole.[Editorial comment- The
Constitution (Seventh Amendment) Act, 1956, this Article was replaced with a new one that applies
to the states of Andhra Pradesh, Punjab, and Bombay. This introduced a special provision that
enables the President to direct the creation of regional committees within a state’s Legislative
Assembly. Also Refer ]
371A. Special provision with respect to the State of Nagaland
(1)Notwithstanding anything in this Constitution,--(a)no Act of Parliament in respect of--(i)religious
or social practices of the Nagas,(ii)Naga customary law and procedure,(iii)administration of civil
and criminal justice involving decisions according to Naga customary law,(iv)ownership and
transfer of land and its resources,shall apply to the State of Nagaland unless the Legislative
Assembly of Nagaland by a resolution so decides;(b)the Governor of Nagaland shall have special
responsibility with respect to law and order in the State of Nagaland for so long as in his opinion
internal disturbances occurring in the Naga Hills-Tuensang Area immediately before the formation
of that State continue therein or in any part thereof and in the discharge of his functions in relation
thereto the Governor shall, after consulting the Council of Ministers, exercise his individual
judgment as to the action to be taken:Provided that if any question arises whether any matter is or is
not a matter as respects which the Governor is under this sub-clause required to act in the exercise
of his individual judgment, the decision of the Governor in his discretion shall be final, and the
validity of anything done by the Governor shall not be called in question on the ground that he ought
or ought not to have acted in the exercise of his individual judgment:Provided further that if the
President on receipt of a report from the Governor or otherwise is satisfied that it is no longer
necessary for the Governor to have special responsibility with respect to law and order in the State
of Nagaland, he may by order direct that the Governor shall cease to have such responsibility with
effect from such date as may be specified in the order;(c)in making his recommendation with
respect to any demand for a grant, the Governor of Nagaland shall ensure that any money provided
by the Government of India out of the Consolidated Fund of India for any specific service or purpose
is included in the demand for a grant relating to that service or purpose and not in any other
demand;(d)as from such date as the Governor of Nagaland may by public notification in this behalfConstitution of India

specify, there shall be established a regional council for the Tuensang district consisting of
thirty-five members and the Governor shall in his discretion make rules providing for--(i)the
composition of the regional council and the manner in which the members of the regional council
shall be chosen:Provided that the Deputy Commissioner of the Tuensang district shall be the
Chairman ex officio of the regional council and the Vice-Chairman of the regional council shall be
elected by the members thereof from amongst themselves;(ii)the qualifications for being chosen as,
and for being, members of the regional council;(iii)the term of office of, and the salaries and
allowances, if any, to be paid to members of, the regional council;(iv)the procedure and conduct of
business of the regional council;(v)the appointment of officers and staff of the regional council and
their conditions of services; and(vi)any other matter in respect of which it is necessary to make rules
for the constitution and proper functioning of the regional council.(2)Notwithstanding anything in
this Constitution, for a period of ten years from the date of the formation of the State of Nagaland or
for such further period as the Governor may, on the recommendation of the regional council, by
public notification specify in this behalf--(a)the administration of the Tuensang district shall be
carried on by the Governor;(b)where any money is provided by the Government of India to the
Government of Nagaland to meet the requirements of the State of Nagaland as a whole, the
Governor shall in his discretion arrange for an equitable allocation of that money between the
Tuensang district and the rest of the State;(c)no Act of the Legislature of Nagaland shall apply to the
Tuensang district unless the Governor, on the recommendation of the regional council, by public
notification so directs and the Governor in giving such direction with respect to any such Act may
direct that the Act shall in its application to the Tuensang district or any part thereof have effect
subject to such exceptions or modifications as the Governor may specify on the recommendation of
the regional council:Provided that any direction given under this sub-clause may be given so as to
have retrospective effect;(d)the Governor may make regulations for the peace, progress and good
government of the Tuensang district and any regulations so made may repeal or amend with
retrospective effect, if necessary, any Act of Parliament or any other law which is for the time being
applicable to that district;(e)(i)one of the members representing the Tuensang district in the
Legislative Assembly of Nagaland shall be appointed Minister for Tuensang affairs by the Governor
on the advice of the Chief Minister and the Chief Minister in tendering his advice shall act on the
recommendation of the majority of the members as aforesaid;(ii)the Minister for Tuensang affairs
shall deal with, and have direct access to the Governor on, all matters relating to the Tuensang
district but he shall keep the Chief Minister informed about the same;(f)notwithstanding anything
in the foregoing provisions of this clause, the final decision on all matters relating to the Tuensang
district shall be made by the Governor in his discretion;(g)in articles 54 and 55 and clause (4) of
article 80, references to the elected members of the Legislative Assembly of a State or to each such
member shall include references to the members or member of the Legislative Assembly of
Nagaland elected by the regional council established under this article;(h)in article 170--(i)clause (1)
shall, in relation to the Legislative Assembly of Nagaland, have effect as if for the word "sixty", the
words "forty-six" had been substituted;(ii)in the said clause, the reference to direct election from
territorial constituencies in the State shall include election by the members of the regional council
established under this article;(iii)in clauses (2) and (3), references to territorial constituencies shall
mean references to territorial constituencies in the Kohima and Mokokchung districts.(3)If any
difficulty arises in giving effect to any of the foregoing provisions of this article, the President may by
order do anything (including any adaptation or modification of any other article) which appears toConstitution of India

him to be necessary for the purpose of removing that difficulty:Provided that no such order shall be
made after the expiration of three years from the date of the formation of the State of
Nagaland.Explanation.--In this article, the Kohima, Mokokchung and Tuensang districts shall have
the same meanings as in the State of Nagaland Act, 1962.[Editorial comment- The Constitution
(Thirteenth Amendment) Act, 1962, is one of the most comprehensive amendments in the history of
Indian Constitutional Amendments. Here, Nagaland was given specific constitutional provisions
and status of a state, with special protection provided for in Article 371A. Within the State of Assam,
Nagaland existed as a tribal region. The leaders of the Naga People’s Convention and the
Government of India reached an agreement in July 1960. The amendment’s objective was to
incorporate the state of Nagaland into the Union of India.]
371B. Special provision with respect to the State of Assam
Notwithstanding anything in this Constitution, the President may, by order made with respect to the
State of Assam, provide for the constitution and functions of a committee of the Legislative
Assembly of the State consisting of members of that Assembly elected from the tribal areas specified
in Part I of the table appended to paragraph 20 of the Sixth Schedule and such number of other
members of that Assembly as may be specified in the order and for the modifications to be made in
the rules of procedure of that Assembly for the constitution and proper functioning of such
committee.[ Editorial comment- The Constitution (Twenty-Two Amendment) Act, 1969, it also
inserted new article 371B which provided for constitution and functions of a committee of the
Legislative Assembly of the State of Assam consisting of members of that Assembly elected from the
tribal areas specified in Part A of the Table appended to Paragraph 20 of the Sixth Schedule, and
such number of other members of that Assembly as may be specified in the order. Also refer ]
371C. Special provision with respect to the State of Manipur
[After article 371B of the Constitution, the following article shall be inserted through Constitution
(Twenty-Seventh Amendment) Act, 1971](1)Notwithstanding anything in this Constitution, the
President may, by order made with respect to the State of Manipur, provide for the constitution and
functions of a committee of the Legislative Assembly of the State consisting of members of that
Assembly elected from the Hill Areas of that State, for the modifications to be made in the rules of
business of the Government and in the rules of procedure of the Legislative Assembly ofme State
and for any special responsibility of the Governor in order to secure the proper functioning of such
committee.(2)The Governor shall annually, or whenever so required by the President, make a report
to the President regarding the administration of the Hill Areas in the State of Manipur and the
executive power of the Union shall extend to the giving of directions to the State as to the
administration of the said areas.Explanation.--In this article, the expression "Hill Areas" means
such areas as the President may, by order, declare to be Hill Areas.[Editorial comment-The
Constitution (Twenty-Seventh Amendment) Act, 1971 added this article 371C deals with Manipur
and the suitable provisions and special responsibilities related to its administration. The
proclamation under Article 371C authorizes the President to arrange for the formation and functions
of a Committee of Legislative Assembly of the State of Manipur which is made up of members of that
Assembly elected from the State’s Hill Areas. The purpose is to guarantee that changes are made toConstitution of India

the Government’s rules of business and the rules of procedure of the State Legislative Assembly, and
the Governor is responsible for the appropriate operation of such a committee.Also Refer]
371D. Special provisions with respect to the State of Andhra Pradesh
[After article 371C of the Constitution, the following articles shall be inserted through Constitution
(Thirty-Second Amendment) Act, 1973](1)The President may, by order made with respect to the
State of Andhra Pradesh, provide, having regard to the requirements of the State as a whole, for
equitable opportunities and facilities for the people belonging to different parts of the State, in the
matter of public employment and in the matter of education, and different provisions may be made
for various parts of the State.(2)An order made under clause (1) may, in particular,--(a)require the
State Government to organise any class or classes of posts in a civil service of, or any class or classes
of civil posts under the State into different local cadres for different parts of the State and allot in
accordance with such principal and procedure as may be specified in the order the persons holding
such post to the local cadres so organised;(b)specify any part or parts of the State which shall be
regarded as the local area--(i)for direct recruitment to posts in any local cadre (whether organised in
pursuance of an order under this article or constituted otherwise) under the State
Government;(ii)for direct recruitment to posts in any cadre under any local authority within the
State; and(iii)for the purposes of admission to any University within the State or to any other
educational institution which is subject to the control of the State Government;(c)specify the extent
to which, the manner in which and the conditions subject to which, preference or reservation shall
be given or made-(i)in the matter of direct recruitment to posts in any such cadre referred to in
sub-clause (b) as may be specified in this behalf in the order;(ii)in the matter of admission to any
such University or other educational institution referred to in sub-clause (b) as may be specified in
this behalf in the order, to or in favour of candidates who have resided or studied for any period
specified in the order in the local area in respect of such cadre, University or other educational
institution, as the case may be.(3)The President may, by order, provide for the constitution of an
Administrative Tribunal for the State of Andhra Pradesh to exercise such jurisdiction, powers and
authority including any jurisdiction, power and authority which immediately before the
commencement of the Constitution (Thirty-second Amendment) Act, 1973, was exercisable by any
court (other than the Supreme Court) or by any tribunal or other authority as may be specified in
the order with respect to the following matters, namely:-(a)appointment, allotment or promotion to
such class or classes of posts in any civil service of the State, or to such class or classes of civil posts
under the State, or to such class or classes of posts under the control of any local authority within
the State, as may be specified in the order;(b)seniority of persons appointed, allotted or promoted to
such class or classes of posts in any civil service of the State, or to such class or classes of civil posts
under the State, or to such class or classes of posts under the control of any local authority within
the State, as may be specified in the order;(c)such other conditions of service of persons appointed,
allotted or promoted to such class or classes of civil posts in any civil service of the State, or to such
class or classes of civil posts under the State or to such class or classes of posts under the control of
any local authority within the State, as may be specified in the order.(4)An order made under clause
(3) may--(a)authorise the Administrative Tribunal to receive representations for the redress of
grievances relating to any matter within its jurisdiction as the President may specify in the order and
to make such orders thereon as the Administrative Tribunal deems fit;(b)contain such provisionsConstitution of India

with respect to the powers and authorities and procedure of the Administrative Tribunal (including
provisions with respect to the powers of the Administrative Tribunal to punish for contempt of
itself) as the President may deem necessary;(c)provide for the transfer of the Administrative
Tribunal of such classes of proceedings, being proceedings relating to matters within its jurisdiction
and pending before any court (other than the Supreme Court) or tribunal or other authority
immediately before the commencement of such order, as may be specified in the order;(d)contain
such supplemental, incidental and consequential provisions (including provisions as to fees and as
to limitation, evidence or for the application of any law for the time being in force subject to any
exceptions or modifications) as the President may deem necessary.(5)The order of the
Administrative Tribunal finally disposing of any case shall become effective upon its confirmation by
the State Government or on the expiry of three months from the date on which the order is made,
whichever is earlier:Provided that the State Government may, by special order made in writing and
for reasons to be specified therein, modify or annul any order of the Administrative Tribunal before
it becomes effective and in such a case, the order of the Administrative Tribunal shall have effect
only in such modified form or be of no effect, as the case may be.(6)Every special order made by the
State Government under the proviso to clause (5) shall be laid, as soon as may be after it is made,
before both Houses of the State Legislature.(7)The High Court for the State shall not have any
powers of superintendence over the Administrative Tribunal and no court (other than the Supreme
Court) or tribunal shall exercise any jurisdiction, power or authority in respect of any matter subject
to the jurisdiction, power or authority of, or in relation to, the Administrative Tribunal.(8)If the
President is satisfied that the continued existence of the Administrative Tribunal is not necessary,
the President may by order abolish the Administrative Tribunal and make such provisions in such
order as he may deem fit for the transfer and disposal of cases pending before the Tribunal
immediately before such abolition.(9)Notwithstanding any judgment, decree or order of any court,
tribunal or other authority,--(a)no appointment, posting, promotion or transfer of any
person--(i)made before the 1st day of November, 1956, to any post under the Government of, or any
local authority within, the State of Hyderabad as it existed before that date; or(ii)made before the
commencement of the Constitution (Thirty-second Amendment) Act, 1973, to any post under the
Government of, or any local or other authority within, the State of Andhra Pradesh; and(b)no action
taken or thing done by or before any person referred to in sub-clause (a), shall be deemed to be
illegal or void or ever to have become illegal or void merely on the ground that the appointment,
posting, promotion or transfer of such person was not made in accordance with any law, then in
force, providing for any requirement as to residence within the State of Hyderabad or, as the case
may be, within any part of the State of Andhra Pradesh, in respect of such appointment, posting,
promotion or transfer.(10)The provisions of this article and of any order made by the President
thereunder shall have effect notwithstanding anything in any other provision of this Constitution or
in any other law for the time being in force.[Editorial comment-The Constitution (Thirty-Second
Amendment) Act, 1973, had the primary goal of protecting regional rights in the Telangana and
Andhra regions of Andhra Pradesh state. It included special rules for enrollment in educational
institutions and the establishment of an administrative tribunal to handle disagreements and
complaints involving public services, particularly in civil services. The Amendment added Articles
371D which are specific to the state of Andhra Pradesh. Also Refer]Constitution of India

371E. Establishment of Central University in Andhra Pradesh
[After article 371C of the Constitution, the following articles shall be inserted through Constitution
(Thirty-Second Amendment) Act, 1973]Parliament may by law provide for the establishment of a
University in the State of Andhra Pradesh.[Editorial comment-The Constitution (Thirty-Second
Amendment) Act, 1973, had the primary goal of protecting regional rights in the Telangana and
Andhra regions of Andhra Pradesh state. It included special rules for enrollment in educational
institutions and the establishment of an administrative tribunal to handle disagreements and
complaints involving public services, particularly in civil services. The Amendment added 371E as
part of the 1987 amendments. The intention behind the enactment of Article 371E was to enable the
building of a Central University in the Indian state of Andhra Pradesh. Additionally, the
Constitution's Seventh Schedule was also amended. Also Refer]
371F. Special provisions with respect to the State of Sikkim
Notwithstanding anything in this Constitution,--(a)the Legislative Assembly of the State of Sikkim
shall consist of not less than thirty members;(b)as from the date of commencement of the
Constitution (Thirty-sixth Amendment) Act, 1975 (hereafter in this article referred to as the
appointed day)--(i)the Assembly for Sikkim formed as a result of the elections held in Sikkim in
April, 1974 with thirty-two members elected in the said elections) hereinafter referred to as the
sitting members) shall be deemed to be the Legislative Assembly of the State of Sikkim duly
constituted under this Constitution;(ii)the sitting members shall be deemed to be the members of
the Legislative Assembly of the State of Sikkim duly elected under this Constitution; and(iii)the said
Legislative Assembly of the State of Sikkim shall exercise the powers and perform the functions of
the Legislative Assembly of a State under this Constitution;(c)in the case of the Assembly deemed to
be the Legislative Assembly of the State of Sikkim under clause (b), the references to the period of
five years in clause (1) of article 172 shall be construed as references to a period of four years and the
said period of four years shall be deemed to commence from the appointed day;(d)until other
provisions are made by Parliament by law, there shall be allotted to the State of Sikkim one seat in
the House of People and the State of Sikkim shall form one Parliamentary (constituency to be called
the Parliamentary constituency for Sikkim;(e)the representative of the State of Sikkim in the House
of the people in existence on the appointed day shall be elected by the members of the Legislative
Assembly of the State of Sikkim;(f)Parliament may, for the purpose of protecting the rights and
interests of the different sections of the population of Sikkim make provision for the number of seats
in the Legislative Assembly of the State of Sikkim which may be filled by candidates belonging to
such sections and for the delimitation of the Assembly constituencies from which candidates
belonging to such sections alone may stand for election to the Legislative Assembly of the State of
Sikkim;(g)the Governor of Sikkim shall have special responsibility for peace and for an equitable
arrangement for ensuring the social and economic advancement of different sections of the
population of Sikkim and in the discharge of his special responsibility under this clause, the
Governor of Sikkim shall, subject to such directions as the President may, from time to time, deem
fit to issue, act in his direction;(h)all property and assets (whether within or outside the territories
comprised in the State of Sikkim) which immediately before the appointed day were vested in the
Government of Sikkim or in any other authority or in any person for the purposes of theConstitution of India

Government of Sikkim shall, as from the appointed day, vest in the Government of the State of
Sikkim;(i)the High Court functioning as such immediately before the appointed day in the
territories comprised in the State of Sikkim shall, on and from the appointed day, be deemed to be
the High Court for the State of Sikkim;(j)all courts of civic, criminal and revenue jurisdiction, all
authorities and all officers, judicial, executive and ministerial, throughout the territory of the State
of Sikkim shall continue on and from the appointed day to exercise their respective functions subject
to the provision of this Constitution;(k)all laws in force immediately before the appointed day in the
territories comprised in the State of Sikkim or any part thereof shall continue to be in force therein
until amended or repealed by a competent Legislature or other competent authority;(l)for the
purpose of facilitating the application of any such law as is referred to in clause (k) in relation to the
administration of the State of Sikkim and for the purpose of bringing the provisions of any such law
into accord with the provisions of this Constitution, the President may, within two years from the
appointed day, by order, make such adaptations and modifications of the law, whether by way of
repeal or amendment, as may be necessary or expedient, and thereupon, every such law shall have
effect subject to the adaptations and modifications so made, and any such adaptation or
modification shall not be questioned in any court of law;(m)neither the Supreme Court nor any
other court shall have jurisdiction in respect of any dispute or other matter arising out of any treaty,
agreement, engagement or other similar instrument relating to Sikkim which was entered into or
executed before the appointed day and to which the Government of India or any of its predecessor
Governments was a party, but nothing in this clause shall be construed to derogate from the
provisions of article 143;(n)the president may, by public notification, extend with such restrictions
or modifications as he thinks fit to the State of Sikkim any enactment which is in force in a State in
India at the date of the notification;(o)if any difficulty arises in giving effect to any of the foregoing
provisions of this article, the President may, by order , do anything (including any adaptation or
modification of any other article) which appears tohim to be necessary for the purpose of removing
the difficulty:Provided that no such order shall be made after the expiry of two years from the
appointed day;(p)all things done and all actions taken in or in relation to the State of Sikkim or the
territories comprised therein during the period commencing on the appointed day and ending
immediately before the date on which the Constitution (Thirty-sixth Amendment) Act, 1975,
received the assent of the President shall, in so far as they are in conformity with the provisions of
this Constitution as amended by the Constitution (Thirty-sixth Amendment) Act, 1975, be deemed
for all purposes to have been validly done or taken under this Constitution as so
amended.[Editorial Comment- The Constitution (Thirty-Sixth Amendment) Act, 1975, Insert
article 371F, was added after article 371E to the Constitution, which included important
requirements pertaining to the State of Sikkim. Also Refer][Editorial comment-The Constitution
(Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has
been taken out of Part III and made a separate Article 300A in Chapter IV of Part XII. This
amendment may have taken away the scope of speedy remedy under Article 32 for the violation of
Right to Property because it is no more a Fundamental Right. Making it a legal right under the
Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism included in the
preamble and secondly, in doing so, it conformed to the doctrine of basic structure of the
Constitution. Also Refer]Constitution of India

371G. Special provision with respect to the State of Mizoram
Notwithstanding in this Constitution.--(a)no Act of Parliament in respect of--(i)religious or social
practices of the Mizos,(ii)Mizo customary law and procedure,(iii)administration of civil and criminal
justice involving decisions according to Mizo customary law,(iv)ownership and transfer of land,
shall apply to the State of Mizoram unless the Legislative Assembly of the State of Mizoram by a
resolution so decides:Provided that nothing in this clause shall apply to any Central Act in force in
the Union Territory of Mizoram immediately before the commencement of the Constitution
(Fifty-third Amendment) Act, 1986;(b)the Legislative Assembly of the State of Mizoram shall consist
of not less than forty members.[Editorial comment-The Constitution (Fifty-Third Amendment)
Act, 1986, aimed to prevent unwanted interference by the Central Government and protect the
interests of the Mizoram community by upholding their social relationship laws. Before the
amendment, Mizoram had been declared a separate Union Territory under the Northeast Areas
(Reorganization) Act, 1971, in response to violent insurgencies. The only way to establish peace and
harmony in the state was to sign a peace accord with the Mizo National Front (MNF). This treaty
was finalized on June 30, 1986, and resulted in the insertion of Article 371G into the Indian
Constitution through The Constitution (Fifty-Third Amendment), 1986. As a result, Mizoram
became the 23rd state of India in 1987, and the interests of the Mizo community were
safeguarded.Also Refer]
371H. Special provision with respect to the State of Arunachal Pradesh
Notwithstanding anything in this Constitution-(a)the Governor of Arunachal Pradesh shall have
special responsibility with respect to law and order in the State of Arunachal Pradesh and in the
discharge of hi s functions in relation thereto, the Governor shall, after consulting the Council of
Ministers, exercise hi s individual judgment as to the action to be taken:Provided that if any
question arises whether any matter is or is not a matter as respects which the Governor is under this
clause required to act in the exercise of hi s individual judgment, the decision of the Governor in hi s
discretion shall be final, and the validity of anything done by the Governor shall not be called in
question on the ground that he ought or ought not to have acted in the exercise of hi s individual
judgment:Provided further that if the President on receipt of a report from the Governor or
otherwise is satisfied that it is no longer necessary for the Governor to have special responsibility
with respect to law and order in the State of Arunachal Pradesh, he may by order direct that the
Governor shall cease to have such responsibility with effect from such date as may be specified in
the order;(b)the Legislative Assembly of the State of Arunachal Pradesh shall consist of not less than
thirty members.[Editorial comment-The Constitution (Fifty-fifth Amendment) Act,
1986,introduced Article 371H into the Constitution of India. Article 371H contained adequate
provisions for the newly designated State of Arunachal Pradesh. Being located at a sensitive spot, it
is the fundamental duty of the concerned government to ensure the special protection of the
societies, the people, and their rights. It can be achieved through the aid of government support. The
Legislative powers along with the duties of the Governor, Council of Ministers, the authority of the
President, etc. would help in the protection and maintenance of law and order. This would ensure
that cooperative societies thrive in the newly formed State of Arunachal Pradesh, despite being
geographically in a sensitive zone.Also Refer]Constitution of India

371I. Special provision with respect to the State of Goa
Notwithstanding anything in this Constitution, the Legislative Assembly of the State of Goa shall
consist of not less than thirty members.[Editorial comment-The Constitution (Fifty-sixth
Amendment) Act, 1987, helped in changing the status of Goa from a Union territory to a full-fledged
state. The introduction of Article371-I played a crucial role in assigning statehood identity to Goa. It
helped the place become one of India’s most resided-in states and the most visited tourist
attractions on a global level. As an independent state, personal growth, education, and tourism were
emphasized as part of developmental projects. Konkani language was promoted. There was a
gradual increase in the population. This Amendment Act also allowed Daman and Diu to attain the
status of the separate Union territory of the Union of India.Also Refer]
371J. Special provisions with respect to State of Karnataka
(1)The President may, by order made with respect to the State of Karnataka, provide for any special
responsibility of the Governor for--(a)establishment of a separate development board for
Hyderabad-Karnataka region with the provision that a report on the working of the board will be
placed each year before the State Legislative Assembly;(b)equitable allocation of funds for
developmental expenditure over the said region, subject to the requirements of the State as a whole;
and(c)equitable opportunities and facilities for the people belonging to the said region, in matters of
public employment, education and vocational training, subject to the requirements of the State as a
whole.(2)An order made under sub-clause (c) of clause (1) may provide for(a)reservation of a
proportion of seats in educational and vocational training institutions in the Hyderabad-Karnataka
region for students who belong to that region by birth or by domicile; and(b)identification of posts
or classes of posts under the State Government and in any body or organisation under the control of
the State Government in the Hyderabad-Karnataka region and reservation of a proportion of such
posts for persons who belong to that region by birth or by domicile and for appointment thereto by
direct recruitment or by promotion or in any other manner as may be specified in the
order.[Editorial comment-The Constitution (Ninety-eighth Amendment) Act, 2012, was an
important step towards providing a separate administration for the Hyderabad-Karnataka region of
the State of Karnataka. Article 371-J provided special provisions for the people of the said region.
Provisions were put in place under Article 317-J for reservations of a certain proportion of seats in
educational institutions, vocational training institutions, public employment, etc. A separate
Development Board was also established to prioritize the progress of the region under this
amendment act. Also Refer]
372. Continuance in force of existing laws and their adaptation
( 1 ) Notwithstanding the repeal by this Constitution of the enactments referred to in article 395 but
subject to the other provisions of this Constitution, all the laws in force in the territory of India
immediately before the commencement of this Constitution shall continue in force therein until
altered or repealed or amended by a competent legislature or other competent authority.( 2 ) For the
purpose of bringing the provisions of any law in force in the territory of India into accord with the
provisions of this Constitution, the President may by ordermake such adaptations and modificationsConstitution of India

of such law, whether by way of repeal or amendment, as may be necessary or expedient and provide
that the law shall, as from such date as may be specified in the order, have effect subject to the
adaptations and modifications so made, and any such adaptation or modification shall not be
questioned in any court of law.( 3 ) Nothing in clause ( 2 ) shall be deemed--(a)to empower the
President to make any adaptation or modification of any law after the expiration ofthree years from
the commencement of this Constitutions; or(b)to prevent any competent Legislature or other
competent authority from repealing or amending any law adapted or modified by the President
under the said clause.Explanation I.--The expression 'law in force' in this article shall include a law
passed or made by a Legislature or other competent authority in the territory of India before the
commencement of this Constitution and not previously repealed, notwithstanding that it or parts of
it may no! be then in operation either at all or in particular areas.Explanation II.--Any law passed or
made by a Legislature or other competent authority in the territory of India which immediately
before the commencement of this Constitution had extra-territorial effect as well as effect in the
territory of India shall, subject to any such adaptations and modifications as aforesaid, continue to
have such extra-territorial effect.Explanation III.--Nothing in this article shall be construed as
continuing any temporary law in force beyond the date fixed for its expiration or the date on which it
would have expired if this Constitution had not come into force.Explanation IV.--An Ordinance
promulgated by the Governor of a Province under section 88 of the Government of India Act, 1935 ,
and in force immediately before the commencement of this Constitution shall, unless "withdrawn by
the Governor of the corresponding State earlier, cease to operate at the expiration of six weeks from
the first meeting after such commencement of the Legislative Assembly of that State functioning
under clause ( 1 ) of article 382 , and nothing in this article shall be construed as continuing any
such Ordinance in force beyond the said period.
372A. Power of the President to adapt laws
( 1 ) For the purposes of bringing the provisions of any law in force in India or in any part thereof,
immediately before the commencement of the Constitution (Seventh Amendment) Act, 1956 , into
accord with the provisions of this Constitution as amended by that Act, the President may by
ordermade before the first day of November, 1957 , make such adaptations and modifications of the
law, whether by way of repeal or amendment, as may be necessary or expedient, and provide that
the law shall, as from such date as may be specified in the order, have effect subject to the
adaptations and modifications so made, and any such adaptation or modification shall not be
questioned in any court of law.( 2 ) Nothing in clause ( 1 ) shall be deemed to prevent a competent
Legislature or other competent authority from repealing or amending any law adapted or modified
by the President under the said clause.
373. Power of President to make order in respect of persons under
preventive detention in certain cases
Until provision is made by Parliament under clause (7) of article 22, or until the expiration of one
year from the commencement of this Constitution, whichever is earlier, the said article shall have
effect as if for any reference to Parliament in clauses (4) and (7) thereof there were substituted a
reference to the President and for any reference to any law made by Parliament in those clausesConstitution of India

there were substituted a reference to an order made by the President.
374. Provisions as to Judges of the Federal Court and proceedings pending
in the Federal Court or before His Majesty in Council
(1)The Judges of the Federal Court holding office immediately before the commencement of this
Constitution shall, unless they have elected otherwise, become on such commencement the Judges
of the Supreme Court and shall thereupon be entitled to such salaries and allowances and to such
rights in respect of leave of absence and pension as are provided for under article 125 in respect of
the Judges of the Supreme Court.(2)All suits, appeals and proceedings, civil or criminal, pending in
the Federal Court at the commencement of this Constitution shall stand removed to the Supreme
Court, and the Supreme Court shall have jurisdiction to hear and determine the same, and the
judgments and orders of the Federal Court delivered or made before the commencement of this
Constitution shall have the same force and effect as if they had been delivered or made by the
Supreme Court.(3)Nothing in this Constitution shall operate to invalidate the exercise of jurisdiction
by His Majesty in Council to dispose of appeals and petitions from, or in respect of, any judgment,
decree or order of any court within the territory of India in so far as the exercise of such jurisdiction
is authorised by law, and any order of His Majesty in Council made on any such appeal or petition
after the commencement of this Constitution shall for all purposes have effect as if it were an order
or decree made by the Supreme Court in the exercise of the jurisdiction conferred on such Court by
this Constitution.(4)On and from the commencement of this Constitution the jurisdiction of the
authority functioning as the Privy Council in a State specified in Part B of the First Schedule to
entertain and dispose of appeals and petitions from or in respect of any judgment, decree or order of
any court within that State shall cease, and all appeals and other proceedings pending before the
said authority at such commencement shall be transferred to, and disposed of by, the Supreme
Court.(5)Further provision may be made by Parliament by law to give effect to the provisions of this
article.
375. Courts, authorities and officers to continue to function subject to the
provisions of the Constitution
All courts of civil, criminal and revenue jurisdiction, all authorities and all officers, judicial executive
and ministerial, throughout the territory of India, shall continue to exercise their respective
functions subject to the provisions of this Constitution.
376. Provisions as to Judges of High Courts
( 1 ) Notwithstanding anything in clause ( 2 ) of article 217 , the Judges of High Court in any
Province holding office immediately before the commencement of this Constitution shall, unless
they have elected otherwise, become on such commencement the Judges of the High Court in the
corresponding State, and shall thereupon be entitled to such salaries and allowances and to such
rights in respect of leave of absence and pension as are provided for under article 221 in respect of
the Judges of such High Court.Any such Judge shall, notwithstanding that he is not a citizen ofConstitution of India

India, be eligible for appointment as Chief Justice of such High Court, or as Chief Justice or other
Judge of any other High Court.( 2 ) The Judges of a High Court in any Indian State corresponding to
any State specified in Part B of the First Schedule holding office immediately before the
commencement of this Constitution shall, unless they have elected otherwise, become on such
commencement the Judges of the High Court in the State so specified and shall, notwithstanding
anything in clauses ( 1 ) and ( 2 ) of article 217 but subject to the proviso to clause ( 1 ) of that article,
continue to hold office until the expiration of such period as the President may by order determine.(
3 ) In this article, the expression 'Judge' does not include an acting Judge or an additional Judge.
377. Provisions as to Comptroller and Auditor-General of India
The Auditor-General of India holding office immediately before the commencement of this
Constitution shall, unless he has elected otherwise, become on such commencement the
Comptroller and Auditor-General of India and shall thereupon be entitled to such salaries and to
such rights in respect of leave of absence and pension as are provided for under clause (3) or article
148 in respect of the Comptroller and Auditor-General of India and be entitled to continue to hold
office until the expiration of his term of office as determined under the provisions which were
applicable to him immediately before such commencement.
378. Provisions as to Public Service Commissions
(1)The members of the Public Service Commission for the Dominion of India holding office
immediately before the commencement of this Constitution shall, unless they have elected
otherwise, become on such commencement the members of the Public Service Commission for the
Union and shall, notwithstanding anything in clauses (1) and (2) of article 316 but subject to the
Proviso to clause (2) of that article, continue to hold office until the expiration of their term of office
as determined under the rules which were applicable immediately before such commencement to
such members.(2)The members of a Public Service Commission of a Province or of a Public Service
Commission serving the needs of a group of Provinces holding office immediately before the
commencement of this Constitution shall, unless they have elected otherwise, become on such
commencement the members of the Public Service Commission for the Corresponding State or the
members of the Joint State Public Service Commission serving the needs of the Corresponding
States, as the case may be, and shall, notwithstanding anything in clauses (1) and (2) of article 316
but subject lo the proviso to clause (2) of that article, continue to hold office until the expiration of
their term of office as determined under the rules which were applicable immediately before such
commencement to such members.
378A. Special provisions as to duration of Andhra Pradesh Legislative
Assembly
Notwithstanding anything contained in article 172 , the Legislative Assembly of the State of Andhra
Pradesh as constituted under the provisions of section 28 and 29 of the State Reorganisation Act,
1956 , shall, unless sooner dissolved, continue for a period of five years from the date referred to inConstitution of India

the said section 29 and no longer and the expiration of the said period shall operate as a dissolution
of that Legislative Assembly.
379. to 391. Repealed
Rep. by the Constitution (Seventh Amendment) Act, 1956, sec, 29 and Schedule (w.e.f. 1-11-1956).
392. Power of the President to remove difficulties
(1)The President may, for the purpose of removing any difficulties, particularly in relation to the
transition from the provisions of the Government of India Act, 1935, to the provisions of this
Constitution, by order direct that this Constitution shall, during such period as may be specified in
the order, have effect subject to such adaptations, whether by any of modification, addition or
omission, as he may deem to be necessary or expedient:Provided that no such order shall be made
after the first meeting of Parliament duly constituted under Chapter II of Part V.(2)Every order
made under clause (1) shall be laid before Parliament.(3)The powers conferred on the President by
this article, by article 324, by clause (3) of article 367 and by article 391 shall, before the
commencement of the Constitution, be exercisable by the Governor-General of the Dominion of
India.
Part XXII – Short Title, Commencement, Authoritative Text in
Hindi and Repeals
393. Short Title
This Constitution may be called the Constitution of India.
394. Commencement
This article and articles 5, 6, 7, 8, 9, 60, 324, 366, 367, 379, 380, 388, 391, 392 and 393 shall come
into force at once, and the remaining provisions of this Constitution shall come into force on the
twenty-sixth day of January, 1950, which day is referred to in this Constitution as the
commencement of this Constitution.
394A. Authoritative text in the Hindi language
(1)The President shall cause to be published under his authority-(a)the translation of this
Constitution in the Hindi language signed by members of the Constituent Assembly, with such
modifications as may be necessary to bring it in conformity with the language style and terminology
adopted in the authoritative texts of Central Acts in the Hindi language, and incorporating therein
all the amendments of this Constitution made before such publication; and(b)the translation in the
Hindi language of every amendment of this Constitution made in the English language.(2)TheConstitution of India

translation of this Constitution and of every amendment thereof published under clause (1) shall be
construed to have the same meaning as the original thereof and if any difficulty arises in so
construing any part of such translation, the President shall cause the same to be revised
suitably.(3)The translation of this Constitution and of every amendment thereof published under
this Article shall be deemed to be, for all purposes, the authoritative text thereof in the Hindi
language.[Editorial comment-The Constitution (Fifty-eighth Amendment) Act, 1987, brings
about changes in the way the Constitution was written. Initially, the whole constitution was written
in English, but with the introduction of the 58th Amendment, the provision to have a Hindi version
of the Constitution came into force. Moreover, every subsequent amendment shall also be written in
Hindi along with the English language and should have the same sanctity as that of the English
version. The President holds the authority to bring about any changes in the Hindi translation if it
does not obey the criteria set by Central Acts regarding the language, style, and terminology.Also
Refer]
395. Repeals
The Indian Independence Act, 1947 and the Government of India Act, 1935, together with all
enactments amending or supplementing the latter Act, but not including the Abolition of Privy
Council Jurisdiction Act, 1949 are hereby repealed.
Schedule 1
Articles 1 and 4I. THE STATES
Name Territories
1. Andhra
PradeshThe territories specified in sub-section (1) of section 3 of the Andhra State Act, 1953,
sub-section (1) of section 3 of the States Reorganisation Act, 1956, the First Schedule
to the Andhra Pradesh and Madras (Alteration of Boundaries) Act, 1959, and the
Schedule to the Andhra Pradesh and Mysore (Transfer of Territory) Act, 1968, but
excluding the territories specified in the Second Schedule to the Andhra Pradesh and
Madras (Alteration of Boundaries) Act, 1959.
2. AssamThe territories which immediately before the commencement of this Constitution
were comprised in the Province of Assam, the Khasi States and the Assam Tribal
Areas, but excluding the territories specified in the Schedule to the Assam
(Alteration of Boundaries) Act, 1951,and the territories specified in sub-section (1) of
section 3 of the State of Nagaland Act, 1962 and the territories specified in sections
5, 6 and 7 of the North-Eastern Areas (Reorganisation) Act, 1971and the territories
referred to in Part I of the Second Schedule to the Constitution (One Hundredth
Amendment) Act, 2015, notwithstanding anything contained in clause (a) of section
3 of the Constitution (Ninth Amendment) Act, 1960, so far as it relates to the
territories referred to in Part I of the Second Schedule to the Constitution (One
Hundredth Amendment) Act, 2015
3. BiharConstitution of India

The territories which immediately before the commencement of this Constitution
were either comprised in the Province of Bihar or were being administered as if they
formed part of that Province and the territories specified in clause (i) of sub-section
(1) of section 3 of the Bihar and Uttar Pradesh (Alteration of Boundaries) Act, 1968,
but excluding the territories specified in sub-section(1) of section 3 of the Bihar and
West Bengal (Transfer of Territories) Act, 1956, and the territories specified in
clause (b) of sub-section (1) of section 3 of the first mentioned Actand the territories
specified in section 3 of the Bihar Reorganisation Act, 2000Name Territories
4. GujaratThe territories referred to in sub-section (1) of section 3 of the Bombay
Reorganisation Act, 1960.
5. KeralaThe territories specified in sub-section (1) of section 5 of the States Reorganisation
Act, 1956.
6. Madhya
PradeshThe territories specified in sub-section (1) of section 9 of the States Reorganisation
Act, 1956and the First Schedule to the Rajasthan and Madhya Pradesh (Transfer of
Territories) Act, 1959but excluding the territories specified in section 3 of the
Madhya Pradesh Reorganisation Act, 2000.
7. Tamil NaduThe territories which immediately before the commencement of this Constitution
were either comprised in the Province of Madras or were being administered as if
they formed part of that Province and the territories specified in section 4 of the
States Reorganisation Act, 1956,and the Second Schedule to the Andhra Pradesh and
Madras (Alteration of Boundaries) Act, 1959 but excluding the territories specified
in sub-section (1) of section 3 and sub-section (1) of section 4 of the Andhra State
Act, 1953 andthe territories specified in clause (b) of sub-section (1) of section 5,
section 6 and clause (d) of sub-section (1) of section 7 of the States Reorganisation
Act, 1956 and the territories specified in the First Schedule to the Andhra Pradesh
and Madras (Alteration of Boundaries) Act, 1959.
8.
MaharashtraThe territories specified in sub-section (1) of section 8 of the States Reorganisation
Act, 1956, but excluding the territories referred to in sub-section (1) of section 3 of
the Bombay Reorganisation Act, 1960.
9. KarnatakaThe territories specified in sub-section (1) of section 7 of the States Reorganisation
Act, 1956but excluding the territory specified in the Schedule to the Andhra Pradesh
and Mysore (Transfer of Territory) Act, 1968.
10.OdishaThe territories which immediately before the commencement of this Constitution
were either comprised in the Province of Orissa or were being administered as if
they formed part of that Province.
11. PunjabThe territories specified in section 11 of the States Reorganisation Act, 1956and the
territories referred to in Part II of the First Schedule to the Acquired Territories
(Merger) Act, 1960but excluding the territories referred to in Part II of the First
Schedule to the Constitution (Ninth Amendment) Act, 1960and the territories
specified in sub-section (1) of section 3, section 4 and sub-section (1) of section 5 of
the Punjab Reorganisation Act, 1966.Constitution of India

Name Territories
12. RajasthanThe territories specified in section 10 of the States Reorganisation Act, 1956but
excluding the territories specified in the First Schedule to the Rajasthan and Madhya
Pradesh (Transfer of Territories) Act, 1959.
13. Uttar
PradeshThe territories which immediately before the commencement of this Constitution
were either comprised in the Province known as the United Provinces or were being
administered as if they formed part of that Province, the territories specified in
clause (b) of sub-section (1) of section 3 of the Bihar and Uttar Pradesh (Alteration
of Boundaries) Act, 1968and the territories specified in section 3 of the Uttar
Pradesh Reorganisation Act, 2000, and the territories specified in clause (b) of
sub-section (1) of section 4 of the Haryana and Uttar Pradesh (Alteration of
Boundaries) Act, 1979, but excluding the territories specified in clause (a) of
sub-section (1) of section 3 of the Bihar and Uttar Pradesh (Alteration of
Boundaries) Act, 1968, and the territories specified in clause (a) of sub−section (1) of
section 4 of the Haryana and Uttar Pradesh (Alteration of Boundaries) Act, 1979.
14. West
BengalThe territories which immediately before the commencement of this Constitution
were either comprised in the Province of West Bengal or were being administered as
if they formed part of that Province in the territory of Chandernagore as defined in
clause (c) of section 2 of the Chandernagore (Merger) Act, 1954, and also the
territories specified in sub-section (1) of section 3 of the Bihar and West Bengal
(Transfer of Territories) Act, 1956and also the territories referred to in Part III of the
First Schedule but excluding the territories referred to in Part III of the Second
Schedule to the Constitution (One Hundredth Amendment) Act, 2015,
notwithstanding anything contained in clause (c) of section 3 of the Constitution
(Ninth Amendment) Act, 1960, so far as it relates to the territories referred to in Part
III of the First Schedule and the territories referred to in Part III of the Second
Schedule to the Constitution (One Hundredth Amendment) Act, 2015.
15. Jammu
and KashmirThe territory which immediately before the commencement of this Constitution are
comprised in the Indian Slate of Jammu and Kashmir.
16. NagalandThe territories specified in sub-section (1) of section 3 of the State of Nagaland Act,
1962.
17. HaryanaThe territories specified in sub-section (1) of section 3 of the Punjab Reorganisation
Act, 1966 and the territories specified in clause (a) of sub-section (1) of section 4 of
the Haryana and Uttar Pradesh (Alteration of Boundaries) Act, 1979, but excluding
the territories specified in clause (b) of sub-section (1) of section 4 of that Act.
18. Himachal
PradeshThe territories which immediately before the commencement of this Constitution
were being administered as if they were Chief Commissioners' Provinces under the
names of Himachal Pradesh and Bilaspur and the Territories specified in
sub-section (1) of section 5 of the Punjab Reorganisation Act, 1966.
19. ManipurThe territory which immediately before the commencement of this Constitution was
being administered as if it were a Chief Commissioner's Province under the name of
Manipur.Constitution of India

Name Territories
20. TripuraThe territory which immediately before the commencement of this Constitution was
being administered as if it were a Chief Commissioner's Province under the name of
Tripuraand the territories referred to in Part II of the First Schedule to the
Constitution (One Hundredth Amendment) Act, 2015, notwithstanding anything
contained in clause (d) of section 3 of the Constitution (Ninth Amendment) Act,
1960, so far as it relates to the territories referred to in Part II of the First Schedule
to the Constitution (One Hundredth Amendment) Act, 2015.
21. MeghalayaThe territories specified in section 5 of the North-Eastern Areas (Reorganisation)
Act, 1971and the territories referred to in Part I of the First Schedule but excluding
the territories referred to in Part II of the Second Schedule to the Constitution (One
Hundredth Amendment) Act, 2015.
22. SikkimThe territories which immediately before the commencement of the Constitution
(Thirty-sixth Amendment) Act, 1975, were comprised in Sikkim
23. MizoramThe territories specified in section 6 of the North Eastern Areas (Reorganisation)
Act, 1971.
24. Arunachal
PradeshThe territories specified in section 7 of the North Eastern Areas (Reorganisation)
Act, 1971.
25. GoaThe territories specified in section 3 of the Goa, Daman and Diu Reorganisation Act,
1987.
26.
ChhattisgarhThe territories specified in section 3 of the Madhya Pradesh Reorganisation Act,
2000.
27.
UttaranchalThe territories specified in section 3 of the Uttar Pradesh Reorganisation Act, 2000.
28.
JharkhandThe territories specified in section 3 of the Bihar Reorganisation Act, 2000.
[Editorial Comment- The Constitution (Ninth Amendment) Act, 1960, clarified the extent of
Parliament’s power to reduce the area of a state and addressed the issue of ceding Indian territory to
foreign nations. As stipulated in the Indo-Pakistan Agreement of 1958, the amendment made it
easier for India to cede the land of the Berubari Union to Pakistan. However, the West Bengal
government did not agree to this agreement. Subsequently, the matter was taken to the Supreme
Court, which declared that the transfer of Indian territory to a foreign country is not within
Parliament’s authority to reduce a state’s area, as outlined in Article 3 of the Indian Constitution. It
helped to resolve the conflicts by redrawing the boundaries and adjusting the territorial claims of
each state. Important verdict under this : In Re: The Berubari Union And ... vs Unknown
][Editorial Comment- The Constitution (Thirty-Sixth Amendment) Act, 1975, Amended
schedules 1"Also Refer][Editorial Comment- The Constitution (One Hundredth Amendment)
Act, 2015, used to refer to this legislation. An Act further amending the Indian Constitution to give
effect to Bangladesh’s transfer of some Indian territories to that country and India’s acquisition of
others by the agreement and protocol signed by the governments of Bangladesh and India. Also
Refer]II. THE UNION TERRITORIES
Name TerritoriesConstitution of India

Name Territories
1. DelhiThe territory which immediately before the commencement of this
Constitution was comprised in the Chief Commissioner's Province of Delhi.
2. The Andaman and
Nicobar IslandsThe territory which immediately before the commencement of this
Constitution was comprised in the Chief Commissioner's Province of the
Andaman and Nicobar Islands.
3.Lakshadweep The territory specified in section 6 of the States Reorganisation Act, 1956.
4. Dadra and Nagar
HaveliThe territory which immediately before the eleventh day of August, 1961
was comprised in Free Dadra and Nagar Haveli.
5. Daman and DiuThe territories specified in section 4 of the Goa, Daman and Diu
Reorganisation Act, 1987.
6. PondicherryThe territories which immediately before the sixteenth day of August, 1962,
were comprised in the French Establishments in India known as
Pondicherry, Karikal, Mahe and Yanam.
7. ChandigarhThe territories specified in section 4 of the Punjab Reorganisation Act,
1966.
[Editorial comment- The Constitution (Tenth Amendment) Act, 1961, incorporated Dadra and
Nagar Haveli as the seventh Union territory of India, by amending the clause (1) of article 240 of the
Constitution to include the Union territory of Dadra and Nagar Haveli in order to enable the
President to “make regulations for the peace, progress and good government of the territory”. Also
refer ][Editorial comment- The Constitution (Fourteenth Amendment) Act, 1962, provided
Parliament with the power to enact laws establishing legislatures and ministerial councils in specific
Union regions. These certain Union Territories are Puducherry, Goa, Himachal Pradesh, Tripura,
Daman and Diu, and Manipur. It wanted to change the First and Fourth Schedules to the
Constitution. Also refer ]
Schedule 2
Articles 59(3), 65(3), 75(6), 97, 125, 148(3), 158(3),164(5),186 and 221A - Provisions as to the
president and the governors of states'1. There shall be paid to the President and to the Governors of
the States the following emoluments per mensem, that is to say:-
The President 10,000 rupees
The Governor of a State 5,500 rupees
'2. There shall also be paid to the President and to the Governors of the States such allowances as
were payable respectively to the Governor-General of the Dominion of India and to the Governors of
the corresponding Provinces immediately before the commencement of this Constitution.'3. The
President and the Governors of the States throughout their respective terms of office shall be
entitled to the same privileges to which the Governor-General and the Governors of the
corresponding Provinces were respectively entitled immediately before the commencement of this
Constitution.'4. While the Vice-President or any other person is discharging the functions of, or is
acting as, President, or any person is discharging the functions of the Governor, he shall be entitled
to the same emoluments, allowances and privileges as the President or the Governor whoseConstitution of India

functions he discharges or for whom he acts, as the case may be.C - Provisions as to the speaker and
the deputy speaker of the house of the people and the chairman and the deputy chairman of the
council of states and the speaker and the deputy speaker of the legislative assembly and the
chairman and the deputy chairman of the legislative council of a state.'7. There shall be paid to the
Speaker of the House of the People and the Chairman of the Council of States such salaries and
allowances as were payable to the Speaker of the Constituent Assembly of the Dominion of India
immediately before the commencement of this Constitution, and there shall be paid to the Deputy
Speaker of the House of the People and to the Deputy Chairman of the Council of States such
salaries and allowances as were payable to the Deputy Speaker of the Constituent Assembly of the
Dominion of India immediately before such commencement.'8. There shall be paid to the Speaker
and the Deputy Speaker of the Legislative Assembly and to the Chairman and the Deputy Chairman
of the Legislative Council of a State. Such salaries and allowances as were payable respectively to the
Speaker and the Deputy Speaker of the Legislative Assembly and the President and the Deputy
President of the Legislative Council of the corresponding Province immediately before the
commencement of this Constitution and, where the corresponding Province had no Legislative
Council immediately before such commencement, there shall be paid to the Chairman and the
Deputy Chairman of the Legislative Council of the State such salaries and allowances as the
Governor of the State may determine.D - Provisions as to the judges of the supreme court and of the
high courts'9. (1) There shall be paid to the Judges of the Supreme Court, in respect of time spent on
actual service, salary at the following rates per mensem, that is to say:-
The Chief Justice 10,000 rupees
Any other Judge 9,000 rupees
Provided that if a Judge of the Supreme Court at the time of his appointment is in receipt of a
pension (other than a disability or wound pension) in respect of any previous service under the
Government of India or any of its predecessor Governments or under the Government of a State or
any of its predecessor Governments, his salary in respect of service in the Supreme Court shall be
reduced-(a)by the amount of that pension, and(b)if he has, before such appointment, received in
lieu of a portion of the pension due to him in respect of such previous service the commuted value
thereof, by the amount of that portion of the pension, and(c)if he has, before such appointment,
received a retirement gratuity in respect of such previous service, by the pension equivalent of that
gratuity.(2)Every Judge of the Supreme Court shall be entitled without payment of rent to the use of
an official residence.(3)Nothing in sub-paragraph (2) of this paragraph shall apply to a Judge who,
immediately before the commencement of this Constitution,-(a)was holding office as the Chief
Justice of the Federal Court and has become on such commencement the Chief Justice of the
Supreme Court under clause (1) of article 374, or(b)was holding office as any other Judge of the
Federal Court and has on such commencement become a Judge (other than the Chief Justice) of the
Supreme Court under the said clause, during the period he holds office as such Chief Justice or other
Judge, and every Judge who so becomes the Chief Justice or other Judge of the Supreme Court
shall, in respect of time spent on actual service as such Chief Justice or other Judge, as the case may
be, be entitled to receive in addition to the salary specified in sub-paragraph (1) of this paragraph as
special pay an amount equivalent to the difference between the salary so specified and the salary
which he was drawing immediately before such commencement.(4)Every Judge of the Supreme
Court shall receive such reasonable allowances to reimburse him for expenses incurred in travelling
on duty within the territory of India and shall be afforded such reasonable facilities in connectionConstitution of India

with travelling as the President may from time to time prescribe.(5)The rights in respect of leave of
absence (including leave allowances) and pension of the Judges of the Supreme Court shall be
governed by the provisions which, immediately before the commencement of this Constitution, were
applicable to the Judges of the Federal Court.'10. (1) There shall be paid to the Judges of High
Courts, in respect of time spent on actual service, salary at the following rates per mensem, that is to
say,-
The Chief Justice 9,000 rupees
Any other Judge 8,000 rupees
Provided that if a Judge of a High Court at the time of his appointment is in receipt of a pension
(other than a disability or wound pension) in respect of any previous service under the Government
of India or any of its predecessor Governments or under the Government of a State or any of its
predecessor Governments, his salary in respect of service in the High Court shall be reduced-(a)by
the amount of that pension, and(b)if he has, before such appointment, received in lieu of a portion
of the pension due to him in respect of such previous service the commuted value thereof, by the
amount of that portion of the pension, and(c)if he has, before such appointment, received a
retirement gratuity in respect of such previous service, by the pension equivalent of that
gratuity.(2)Every person who immediately before the commencement of this Constitution-(a)was
holding office as the Chief Justice of a High Court in any Province and has on such commencement
become the Chief Justice of the High Court in the corresponding State under clause (1) of article
376, or(b)was holding office as any other Judge of a High Court in any Province and has on such
commencement become a Judge (other than the Chief Justice) of the High Court in the
corresponding State under the said clause,shall, if he was immediately before such commencement
drawing a salary at a rate higher than that specified in sub-paragraph (1) of this paragraph, be
entitled to receive in respect of time spent on actual service as such Chief Justice or other Judge, as
the case may be, in addition to the salary specified in the said sub-paragraph as special pay an
amount equivalent to the difference between the salary so specified and the salary which he was
drawing immediately before such commencement.(3)Any person who, immediately before the
commencement of the Constitution (Seventh Amendment) Act, 1956, was holding office as the Chief
Justice of the High Court of a State specified in Part B of the First Schedule and has on such
commencement become the Chief Justice of the High Court of a State specified in the said Schedule
as amended by said Act, shall, if he was immediately before such commencement drawing any
amount as allowance in addition to his salary, be entitled to receive in respect of time spent on
actual service as such Chief Justice, the same amount as allowance in addition to the salary specified
in sub-paragraph (1) of this paragraph.'11. In this Part, unless the context otherwise requires-(a)the
expression 'Chief Justice' includes an acting Chief Justice, and a 'Judge' includes an ad hoc
Judge;(b)'actual service' includes-(i)time spent by a Judge on duty as a Judge or in the performance
of such other functions as he may at the request of the President undertake to
discharge;(ii)vacations, excluding any time during which the Judge is absent on leave;
and(iii)joining time on transfer from a High Court to the Supreme Court or from one High Court to
another.E - Provisions as to the comptroller and auditor-general of india'12. (1) There shall be paid
to the Comptroller and Auditor-General of India a salary at the rate of four thousandrupees per
mensem,(2)The person who was holding office immediately before the commencement of this
Constitution as Auditor-General of India and has become on such commencement the Comptroller
and Auditor-General of India under article 377 shall in addition to the salary specified inConstitution of India

sub-paragraph (1) of this paragraph be entitled to receive as special pay an amount equivalent to the
difference between the salary so specified and the salary which he was drawing as Auditor-General
of India immediately before such commencement.(3)The rights in respect of leave of absence and
pension and the other conditions of service of the Comptroller and Auditor-General of India shall be
governed or shall continue to be governed, as the case may be, by the provisions which were
applicable to the Auditor-General of India immediately before the commencement of this
Constitution and all references in those provisions to the Governor-General shall be construed as
references to the President.
Schedule 3
Articles 75(4), 99, 124(6), 148(2), 164(3), 188 and 219Forms of Oaths or AffirmationsIForm of oath
of office for a Minister for the Union:'I, A.B., do swear in the name of God / solemnly affirm, that I
will bear true faith and allegiance to the Constitution of India as by law established, that I will
uphold the sovereignty and integrity of India that I will faithfully and conscientiously discharge my
duties as a Minister for the Union and that I will do right to all manner of people in accordance with
the Constitution and the law, without fear or favour, affection or ill-will.'IIForm of oath of secrecy
for a Minister for the Union:'I, A.B., do swear in the name of God / solemnly affirm, that I will not
directly or indirectly communicate or reveal to any person or persons any matter which shall be
brought under my consideration or shall become known to me as a Minister for the Union except as
may be required for the due discharge of my duties as such Minister.'IIIAForm of oath or
affirmation to be made by a candidate for election to Parliament:'I, A.B., having been nominated as
a candidate to fill a seat in the Council of States (or the House of the People) do swear in the name of
God / solemnly affirm, that I will bear true faith and allegiance to the Constitution of India as by law
established and that I will uphold the sovereignty and integrity of India.'BForm of oath or
affirmation to be made by a member of Parliament:'I, A.B., having been elected (or nominated) a
member of the Council of States (or the House of the People) do swear in the name of God solemnly
affirm that I will bear true faith and allegiance to the Constitution of India as by law established,
that I will uphold the sovereignty and integrity of India and that I will faithfully discharge the duty
upon which I am about to enter.IVForm of oath or affirmation to be made by the Judges of the
Supreme Court and the Comptroller and Auditor-General of India:'I, A.B., having been appointed
Chief Justice (or a Judge) of the Supreme Court of India (or Comptroller and Auditor-General of
India) do swear in the name of God / solemnly affirm, that I will bear true faith and allegiance to the
Constitution of India as by law established, that I will uphold the sovereignty and integrity of India,
that I will duly and faithfully and to the best of my ability, knowledge and judgment perform the
duties of my office without fear or favour, affection or ill-with and that I will uphold the Constitution
and the laws.'VForm of oath of office for a Minister for a State:'I, A.B., do swear in the name of God
/ solemnly affirm, that I will bear true faith and allegiance to the Constitution of India as by law
established, that I will uphold the sovereignty and integrity of India, that I will faithfully and
conscientiously discharge my duties as a Minister for the State of....... and that I will do right to all
manner of people in accordance with the Constitution and the law without fear or favour, affection
or ill-will.'VIForm of oath of secrecy for a Minister for a State:I, A.B., do swear in the name of God /
solemnly affirm, that I will not directly or indirectly communicate or reveal to any person or persons
any mailer which shall be brought under my consideration or shall become known to me as a
Minister for the State of........ except as may be required for the due discharge of my duties as suchConstitution of India

Minister.'VIIAForm of oath or affirmation to be made by a candidate for election to the Legislature
of a State:'I, A.B., having been nominated as a candidate to fill a seat in Legislative Assembly (or
Legislative Council) , do swear in the name of God / solemnly affirm, that I will bear true faith and
allegiance to the Constitution of India as by law established and that I will uphold the sovereignty
and integrity of India.'BForm of oath or affirmation to be made by a member of the Legislature of a
State:'I, A.B., having been elected (or nominated) a member of the Legislative Assembly (or
Legislative Council), do swear in the name of God / Solemnly affirm, that I will bear true faith and
allegiance to the Constitution of India as by law established, that I will uphold the sovereignty and
integrity of India and (hat I will faithfully discharge the duty upon which I am about to
enter.'VIIIForm of oath or affirmation to be made by the Judges of a High Court:'I, A.B., having
been appointed Chief Justice (or a Judge) of the High Court at (or of)........do swear in the name of
God / solemnly affirm, that I will bear true faith and allegiance to the Constitution of India as by law
established, that I will uphold the sovereignty and integrity of India, that I will duly and faithfully
and to the best of my ability, knowledge, and judgment perform the duties of my office without fear
or favour, affection or ill-will and that I will uphold the Constitution and the laws.[Editorial
comment-The Constitution (Sixteenth Amendment) Act, 1963, this amendment require that all
candidates for membership in the Parliament or State Legislature, as well as Union and State
Ministers, Members of Parliament and State Legislatures, Judges of the Supreme Court and High
Courts, and the Comptroller and Auditor-General of India, take an oath to uphold the sovereignty
and integrity of India.]
Schedule 4
Articles 4(1) and 80(2)Allocation of seats in the Council of StatesTo each State or Union territory
specified in the first column of the following table, there shall be allotted the number of seats
specified in the second column thereof opposite to that State or that Union territory, as the case may
be.
NAME OF STATE/UNION TERRITORY NO. OF SEATS
1. Andhra Pradesh 18
2. Assam 7
3. Bihar 16
4. Jharkhand 6
5. Goa 1
6. Gujarat 11
7. Haryana 5
8. Kerala 9
9. Madhya Pradesh 11
10. Chattisgarh 5
11. Tamil Nadu 18
12. Maharashtra 19
13. Karnataka 12Constitution of India

NAME OF STATE/UNION TERRITORY NO. OF SEATS
14.Odisha 10
15. Punjab 7
16. Rajasthan 10
17. Uttar Pradesh 31
18. Uttaranchal 3
19. West Bengal 16
20. Jammu and Kashmir 4
21 Nagaland 1
22. Himachal Pradesh 3
23 Manipur 1
24. Tripura 1
25. Meghalaya 1
26. Sikkim 1
27. Mizoram 1
28. Arunachal Pradesh 1
29. Delhi 3
30. Pondicherry. 1
Total Total 233
[Editorial comment- The Constitution (Fourteenth Amendment) Act, 1962, provided Parliament
with the power to enact laws establishing legislatures and ministerial councils in specific Union
regions. These certain Union Territories are Puducherry, Goa, Himachal Pradesh, Tripura, Daman
and Diu, and Manipur. It wanted to change the First and Fourth Schedules to the Constitution. Also
refer ][Editorial Comment- The Constitution (Thirty-Sixth Amendment) Act, 1975, Amended
schedules 4 "Also Refer]
Schedule 5
Article 244(1)PROVISIONS AS TO THE ADMINISTRATION AND CONTROL OF SCHEDULED
AREAS AND SCHEDULED TRIBES
Part A – General
1. Interpretation
In this Schedule, unless the context otherwise requires, the expression 'State' does not include the
States of Assam Meghalaya, Tripura and Mizoram.Constitution of India

2. Executive power of a State in Scheduled Areas
Subject to the provisions of this Schedule, the executive power of a State extends to the Scheduled
Areas therein.
3. Report by the Governor to the President regarding the administration of
Scheduled Areas
The Governor of each State having Scheduled Areas therein shall annually, or whenever so required
by the President, make a report to the President regarding the administration of the Scheduled
Areas in that State and the executive power of the Union shall extend to the giving of directions to
the State as to the administration of the said areas.
Part B – Administration and control of scheduled areas and
scheduled tribes
4. Tribes Advisory Council
(1)There shall be established in each State having Scheduled Areas therein and, if the President so
directs, also in any State having Scheduled Tribes but not Scheduled Areas therein, a Tribes
Advisory Council consisting of not more than twenty members of whom, as nearly as may be,
three-fourths shall be the representatives of the Scheduled Tribes in the Legislative Assembly of the
State:Provided that if the number of representatives of the Scheduled Tribes in the Legislative
Assembly of the State is less than the number of seats in the Tribes Advisory Council to be filled by
such representatives, the remaining seats shall be filled by other members of those tribes.(2)It shall
be the duty of the Tribes Advisory Council to advise on such matters pertaining to the welfare and
advancement of the Scheduled Tribes in the State as may be referred to them by the
Governor.(3)The Governor may make rules prescribing or regulating, as the case may be,(a)the
number of members of the Council, the mode of their appointment and the appointment of the
Chairman of the Council and of the officers and servants thereof,(b)the conduct of its meetings and
its procedure in general; and(c)all other incidental matters.
5. Law applicable to Scheduled Areas
(1)Notwithstanding anything in this Constitution, the Governor may by public notification direct
that any particular Act of Parliament or of the Legislature of the State shall not apply to a Scheduled
Area or any part thereof in the Stale or shall apply to a Scheduled Area or any part thereof in the
State subject to such exceptions and modifications as he may specify in the notification and any
direction given under this sub-paragraph may be given so as to have retrospective effect.(2)The
Governor may make regulations for the peace and good government of any area in a State which is
for the time being a Scheduled Area.In particular and without prejudice to the generality of the
foregoing power, such regulations may-(a)prohibit or restrict the transfer of land by or amongConstitution of India

members of the Scheduled Tribes in such area;(b)regulate the allotment of land to members of the
Scheduled Tribes in such area;(c)regulate me carrying on of business as money-lender by persons
who lend money to members of the Scheduled Tribes in such area.(3)In making any such regulation
as is referred to in sub-paragraph (2) of this paragraph, the Governor may repeal or amend any Act
of Parliament or of the Legislature of the State or any existing law which is for the time being
applicable to the area in question.(4)All regulations made under this paragraph shall be submitted
forthwith to the President and, until assented to by him, shall have no effect.(5)No regulation shall
be made under this paragraph unless the Govern making the regulation has, in the case where there
is a Tribes Advisory Council for the State, consulted such Council.
Part C – Scheduled areas
6. Scheduled Areas
(1)In this Constitution, the expression 'Scheduled Areas' means such areas as the President may by
order declare to be Scheduled Areas.(2)The President may at any time by order.(a)direct that the
whole or any specified part of a Scheduled Area shall cease to be a Scheduled Area or a part of such
an area;(aa)increase the area of any Scheduled Area in a State after consultation with the Governor
of that State;(b)alter, but only by way of rectification of boundaries, any Scheduled Area;(c)on any
alteration of the boundaries of a State or on the admission into the Union or the establishment of a
new State, declare any territory not previously included in any State to be, or to form part of, a
Scheduled Area;(d)rescind, in relation to any State or States, any order or orders made under this
paragraph, and in consultation with the Governor of the State concerned, make fresh orders
redefining the areas which are as to be Scheduled Areasand any such order may contain such
incidental and consequential provisions as appear to the President to be necessary and proper, but
save as aforesaid, the order made under sub-paragraph (1) of this paragraph shall not be varied by
any subsequent order.
Part D – Amendment of the schedule
7. Amendment of the Schedule
(1)Parliament may from time to time by law amend by way of addition, variation or repeal any of the
provisions of this Schedule and, when the Schedule is so amended, any reference to this Schedule in
this Constitution shall be construed as a reference to such Schedule as so amended.(2)No such law
as is mentioned in sub-paragraph (1) of this paragraph shall be deemed to be an amendment of this
Constitution for the purposes of article 368.
Schedule 6
s244(2) and 275(1)PROVISIONS AS TO THE ADMINISTRATION OF TRIBAL AREAS IN THE
STATES OF ASSAM, MEGHALAYA, TRIPURA AND MIZORAM[Editorial comment-The
Constitution (Forty-Ninth Amendment) Act, 1984, modifies 5 and 6. The sixth schedule isConstitution of India

concerned with managing the tribal lands in the four northeastern states. Meghalaya, Assam,
Tripura, and Mizoram are among these states. Additionally, it has 10 autonomous district councils
spread throughout 4 states.Also Refer]
1. Autonomous districts and autonomous regions
(1)Subject to the provisions of this paragraph, the tribal areas in each item of Parts I, II and IIA and
in Part III of the table appended to paragraph 20 of this Schedule shall be an autonomous
district.(2)If there are different Scheduled Tribes in an autonomous district, the Governor may, by
public notification, divide the area or areas inhabited by them into autonomous regions.(3)The
Governor may, by public notification, -(a)include any area in any of the Parts of the said
table,(b)exclude any area from any of the Parts of the said table,(c)create a new autonomous
district,(d)increase the area of any autonomous district,(e)diminish the area of any autonomous
district,(f)unite two or more autonomous districts or parts thereof so as to form one autonomous
district,(off)alter the name of any autonomous district,(g)define the boundaries of any autonomous
district:Provided that no order shall be made by the Governor under clauses (c), (d), (c) and (f) of
this sub-paragraph except after consideration of the report of a Commission appointed under
sub-paragraph (1) of paragraph 14 of this Schedule:Provided further that any order made by me
Governor under this sub-paragraph may contain such incidental and consequential provisions
(including any amendment of paragraph 20 and of any item in any of the Parts of the said table) as
appear to the Governor to be necessary for giving effect to the provisions of the order.
2. Constitution of District Councils and Regional Councils
(1)There shall be a District Council for each autonomous district consisting of not more than thirty
members, of whom not more than four persons shall be nominated by the Governor and the rest
shall be elected on the basis of adult suffrage.(2)There shall be a separate Regional Council for each
area constituted an autonomous region under sub-paragraph (2) of paragraph 1 of this
Schedule.(3)Each District Council and each Regional Council shall be a body corporate by the name
respectively of 'the District Council of (name of district)' and 'the Regional Council of (name of
region)', shall have perpetual succession and a common seal and shall by the said name sue and be
sued.(4)Subject to the provisions of this Schedule, the administration of an autonomous district
shall, in so far as it is not vested under this Schedule in any Regional Council within such district, be
vested in the District Council for such district and the administration of an autonomous region shall
be vested in the Regional Council for such region.(5)In an autonomous district with Regional
Councils, the District Council shall have only such powers with respect to the areas under the
authority of the Regional Council as may be delegated to it by the Regional Council in addition to the
powers conferred on it by this Schedule with respect to such areas.(6)The Governor shall make rules
for the first constitution of District Councils and Regional Councils in consultation with the existing
tribal Councils or other representative tribal organizations within the autonomous districts or
regions concerned, and such rules shall provide for-(a)the composition of the District Councils and
Regional Councils and the allocation of seats therein;(b)the delimitation of territorial constituencies
for the purpose of elections to those Councils;(c)the qualifications for voting at such elections and
the preparation of electoral rolls therefore;(d)the qualifications for being elected at such elections asConstitution of India

members of such Councils;(e)the term of office of members of Regional Councils;(f)any other matter
relating to or connected with elections or nominations to such Councils;(g)the procedure and the
conduct of business including the power to act notwithstanding any vacancy in the District and
Regional Councils;(h)the appointment of officers and staff of the District and Regional
Councils.(6A)The elected members of the District Council shall hold office for a term of five years
from the date appointed for the first meeting of the Council after the general elections to the
Council, unless the District Council is sooner dissolved under paragraph 16 and a nominated
member shall hold office at the pleasure of the Governor:Provided that the said period of five years
may, while a Proclamation of Emergency is in operation or if circumstances exist which, in the
opinion of the Governor, render the holding of elections impracticable, be extended by the Governor
for a period not exceeding one year at a time and in any case where a Proclamation of Emergency is
in operation not extending beyond a period of six months after the Proclamation has ceased to
operate:Provided further that a member elected to fill a casual vacancy shall hold office only for the
remainder of the term of office of the member whom he replaces.(7)The District or the Regional
Council may after its first constitution make rules with the approval of the Governor with regard to
the matters specified in sub-paragraph (6) of this paragraph and may also make rules with like
approval regulating-(a)the formation of subordinate local Councils or Boards and their procedure
and the conduct of their business; and(b)generally all matters relating to the transaction of business
pertaining to the administration of the district or region, as the case may be:Provided that until
rules are made by the District or the Regional Council under this sub-paragraph the rules made by
the Governor under sub-paragraph (6) of this paragraph shall have effect in respect of elections to,
the officers and staff of, and the procedure and the conduct of business in, each such Council.
3. Powers of the District Councils and Regional Councils to make laws
(1)The Regional Council for an autonomous region in respect of all areas within such region and the
District Council for an autonomous district in respect of all areas within the district except those
which are under the authority of Regional Councils, if any, within the district shall have power to
make laws with respect to-(a)the allotment, occupation or use, or the setting apart, of land, other
than any land which is a reserved forest for the purposes of agriculture or grazing or for residential
or other non-agricultural purposes or for any other purpose likely to promote the interests of the
inhabitants of any village or town:Provided that nothing in such laws shall prevent the compulsory
acquisition of any land, whether occupied or unoccupied, for public purposes by the Government of
the State concerned in accordance with the law for the time being in force authorising such
acquisition;(b)the management of any forest not being a reserved forest;(c)the use of any canal or
water-course for the purpose of agriculture;(d)the regulation of the practice of jhum or other forms
of shifting cultivation;(e)the establishment of village or town committees or councils and their
powers;(f)any other matter relating to village or town administration, including village or town
police and public health and sanitation;(g)the appointment or succession of Chiefs or
Headmen;(h)the inheritance of property;(i)marriage and divorce;(j)social customs.(2)In this
paragraph, a 'reserved forest' means any area which is a reserved forest under the Assam Forest
Regulation, 1891, or under any other law for the time being in force in the area in question.(3)All
laws made under this paragraph shall be submitted forthwith to the Governor and, until assented to
by him, shall have no effect.Constitution of India

4. Administration of justice in autonomous districts and autonomous regions
(1)The Regional Council for an autonomous region in respect of areas within such region and the
District Council for an autonomous district in respect of areas within the district other man those
which are under the authority of the Regional Councils, if any, within the district may constitute
village councils or courts for the trial of suits and cases between the parties all of whom belong to
Scheduled Tribes within such areas, other than suits and cases to which the provisions of
sub-paragraph (1) of paragraph 5 of this Schedule apply, to the exclusion of any court in the State,
and may appoint suitable persons to be members of such village councils or presiding officers of
such courts, and may also appoint such officers as may be necessary for the administration of the
laws made under paragraph 3 of this Schedule.(2)Notwithstanding anything in this Constitution, the
Regional Council for an autonomous region or any court constituted in that behalf by the Regional
Council or, if in respect of any area within an autonomous district there is no Regional Council, the
District Council for such district, or any court constituted in that behalf by the District Council, shall
exercise the powers of a court of appeal in respect of all suits and cases triable by a village councilor
court constituted under sub-paragraph (1) of this paragraph within such region or area, as the case
may be, other than those to which the provisions of sub-paragraph (1) of paragraph 5 of this
Schedule apply, and no other court except the High Court and the Supreme Court shall have
jurisdiction over such suits or cases.(3)The High Court shall have and exercise such jurisdiction over
the suits and cases to which the provisions of sub-paragraph (2) of this paragraph apply as the
Governor may from time to time by order specify.(4)A Regional Council or District Council, as the
case may be, may with the previous approval of the Governor make rules regulating-(a)the
constitution of village councils and courts and the powers to be exercised by them under this
paragraph;(b)the procedure to be followed by village councils or courts in the trial of suits and cases
under sub-paragraph (1) of this paragraph;(c)the procedure to be followed by the Regional or
District Council or any court constituted by such Council in appeals and other proceedings under
sub-paragraph (2) of this paragraph;(d)the enforcement of decisions and orders of such Councils
and courts:(e)all other ancillary matters for the carrying out of the provisions of sub-paragraphs (1)
and (2) of this paragraph.(5)On and from such date as the President may, after consulting the
Government of the State concerned, by notification appoint in this behalf, this paragraph shall have
effect in relation to such autonomous district or region as may be specified in the notification, as
if-(i)in sub-paragraph (1), for the words "between the parties all of whom belong to Scheduled
Tribes within such areas, other than suits and cases to which the provisions of sub-paragraph (1) of
paragraph5 of this Schedule apply,", the words "not being suits and cases of the nature referred to in
sub- paragraph (1) of paragraph (5) of this Schedule, which the Governor may specify in this behalf,"
had been substituted;(ii)sub-paragraphs (2) and (3) had been omitted;(iii)in sub-paragraph
(4)-(a)for the words "A Regional Council or District Council, as the case may be, may with the
previous approval of the Governor make rules regulating', the words "the Governor may make rules
regulating had been substituted; and(b)for clause (a), the following clause had been substituted,
namely: -(a)the constitution of village councils and courts, the powers to be exercised by them under
this paragraph and the courts to which appeals from the decisions of village councils and courts
shall lie;"(c)for clause (c), the following clause had been substituted, namely: -"(c) the transfer of
appeals and other proceedings pending before the Regional or District Council or any court
constituted by such Council immediately before the date appointed by the President underConstitution of India

sub-paragraph (5);" and(d)in clause (e), for the words, brackets and figures "sub-paragraphs (1) and
(2)", the word, brackets and figure "sub-paragraph (1)" had been substituted.
5. Conferment of powers under the Code of Civil Procedure, 1898 on the
Code of Criminal Procedure, 1898, on the Regional and District Councils and
on certain courts and officers for the trial of certain suits, eases and offences
(1)The Governor may, for the trial of suits or cases arising out of any law in force in any autonomous
district or region being a law specified in that behalf by the Governor, or for the trial of offences
punishable with death, transportation for life, or imprisonment for a term of not less than five years
under the Indian Penal Code or under any other law for the time being applicable to such district or
region, confer on the District Council or the Regional Council having authority over such district or
region or on courts constituted by such District Council or on any officer appointed in that behalf by
the Governor, such powers under the Code of Civil Procedure, 1908, or, as the case may be, the Code
of Criminal Procedure, 1898 , as he deems appropriate, and thereupon the said Council, court or
officer shall try the suits, cases or offences in exercise of the powers so conferred.(2)The Governor
may withdraw or modify any of the powers conferred on a District Council, Regional Council, court
or officer under sub-paragraph (1) of this paragraph.(3)Save as expressly provided in this paragraph,
the Code of Civil Procedure, 1908, and the Code of Criminal Procedure, 1898, shall not apply to the
trial of any suits, cases or offences in an autonomous district or in any autonomous region to which
the provisions of this paragraph apply.(4)On and from the date appointed by the President under
sub-paragraph (5) of paragraph 4 in relation to any autonomous district or autonomous region,
nothing contained in this paragraph shall, in its application to that district or region, be deemed to
authorize the Governor to confer on the District Council or Regional Council or on courts
constituted by the District Council any of the powers referred to in sub-paragraph (1) of this
paragraph.
6. Powers of the District Council to establish primary schools, etc.
(1)The District Council for an autonomous district may establish, construct, or manage primary
schools, dispensaries, markets, cattle pounds, ferries, fisheries, roads, road transport and waterways
in the district and may, with the previous approval of the Governor, make regulations for the
regulation and control thereof and, in particular, may prescribe the language and the manner in
which primary education shall be imparted in the primary schools in the district.(2)The Governor
may, with the consent of any District Council, entrust either conditionally or unconditionally to that
Council or to its officer’s functions in relation to agriculture, animal husbandry, community
projects, co-operative societies, social welfare, village planning or any other matter to which the
executive power of the State extends.
7. District and Regional Funds
(1)There shall be constituted for each autonomous district, a District Fund for each autonomous
region, a Regional Fund to which shall be credited all moneys received respectively by the DistrictConstitution of India

Council for that district and the Regional Council for that region in the course of the administration
of such district or region, as the case may be, in accordance with the provisions of this
Constitution.(2)The Governor may make rules for the management of the District Fund, or, as the
case may be, the Regional Fund and for the procedure to be followed in respect of payment of money
into the said Fund, the withdrawal of moneys there from, the custody of moneys therein and any
other matter connected with or ancillary to the matters aforesaid.(3)The accounts of the District
Council or, as the case may be, the Regional Council shall be kept in such form as the Comptroller
and Auditor-General of India may, with the approval of the President, prescribe.(4)The Comptroller
and Auditor-General shall cause the accounts of the District and Regional Councils to be audited in
such manner as he may think fit, and the reports of the Comptroller and Auditor General relating to
such accounts shall be submitted to the Governor who shall cause them to be laid before the
Council.
8. Powers to assess and collect land revenue and to impose taxes
(1)The Regional Council for an autonomous region in respect of all lands within such region and the
District Council for an autonomous district in respect of all lands within the district except those
which are in the areas under the authority of Regional Councils, if any, within the district, shall have
the power to assess and collect revenue in respect of such lands in accordance with the principles for
the time being followed by the Government of the State in assessing lands for the purpose of land
revenue in the State generally.(2)The Regional Council for an autonomous region in respect of areas
within such region and the District Council for an autonomous district in respect of all areas in the
district except those which are under the authority of Regional Councils, if any, within the district,
shall have power to levy and collect taxes on lands and buildings, and tolls on persons resident
within such areas.(3)The District Council for an autonomous district shall have the power to levy
and collect all or any of the following taxes within such district, that is to say —(a)taxes on
professions, trades, callings and employments;(b)taxes on animals, vehicles and boats;(c)taxes on
the entry of goods into a market for sale therein, and tolls on passengers and goods carried in
ferries;(d)taxes for the maintenance of schools, dispensaries or roads; and(e)taxes on entertainment
and amusements.(4)A Regional Council or District Council, as the case may be, may make
regulations to provide for the levy and collection of any of the taxes specified in sub-paragraphs (2)
and (3) of this paragraph and every such regulation shall be submitted forthwith to the Governor
and, until assented to by him, shall have no effect.
9. Licences or leases for the purpose of prospecting for, or extraction of,
minerals
(1)Such share of the royalties accruing each year from licences or leases for the purpose of
prospecting for, or the extraction of, minerals granted by the Government of the State in respect of
any area within an autonomous district as may be agreed upon between the Government of the State
and the District Court or such district shall be made over to that District Council.(2)If any dispute
arises as to the share of such royalties to be made over to a District Council, it shall be referred to the
Governor for determination and the amount determined by the Governor in his discretion shall be
deemed to be the amount payable under sub-paragraph (1) of this paragraph to the District CouncilConstitution of India

and the decision of the Governor shall be final.
10. Power of District Council to make regulations for the control of
money-lending and trading by non-tribals
(1)The District Council of an autonomous district may make regulations for the regulation and
control of money-lending or trading within the district by persons other than Scheduled Tribes
resident in the district.(2)In particular and without prejudice to the generality of the foregoing
power, such regulations may-(a)prescribe that no one except the holder of a licence issued in that
behalf shall carry on the business of money-lending;(b)prescribe the maximum rate of interest
which may be charged or be recovered by a money-lender;(c)provide for the maintenance of
accounts by money-lenders and for the inspection of such accounts by officers appointed in that
behalf by the District Council;(d)prescribe that no person who is not a member of the Scheduled
Tribes resident in the district shall carry on wholesale or retail business in any commodity except
under a licence issued in that behalf by the District Council:Provided that no regulations may be
made under this paragraph unless they are passed by a majority of not less than three-fourths of the
total membership of the District Council:Provided further that it shall not be competent under any
such regulations to refuse the grant of a licence to a money-lender or a trader who has been carrying
on business within the district since before the time of making of such regulations.(3)All regulations
made under this paragraph shall be submitted forthwith to the Governor and, until assented to by
him, shall have no effect.
11. Publication of laws, rules and regulations made under the Schedule
Allows, rules and regulations made under this Schedule by a District Council or a Regional Council
shall be published forthwith in the Official Gazette of the State and shall on such publication have
the force of law.
12. Application of Acts of Parliament and of the Legislature of the State of
Assam to autonomous districts and autonomous regions in the State of
Assam
(1)Notwithstanding anything in this Constitution-(a)no Act of the Legislature of the State of Assam
in respect of any of the matters specified in paragraph3 of this Schedule as matters with respect to
which a District Council or a Regional Council may make laws, and no Act of the Legislature of the
State of Assam prohibiting or restricting the consumption of any non-distilled alcoholic liquor shall
apply to any autonomous district or autonomous region in the State unless in either case the District
Council for such district or having jurisdiction over such region by public notification so directs, and
the District Council in giving such direction with respect to any Act may direct that the Act shall in
its application to such district or region or any part thereof have effect subject to such exceptions or
modifications as it thinks fit;(b)the Governor may, by public notification, direct that any Act of
Parliament or of the Legislature of the State of Assam to which the provisions of clause (a) of this
sub-paragraph do not apply shall not apply to an autonomous district or an autonomous region inConstitution of India

that State, or shall apply to such district or region or any part thereof subject to such exceptions or
modifications as he may specify in the notification.(2)Any direction given under sub-paragraph (1)
of this paragraph may be given so as to have retrospective effect.
12A. Application of Acts of Parliament and of the Legislature of the State of
Meghalaya to autonomous districts and autonomous regions in the State of
Meghalaya
Notwithstanding anything in this Constitution, -(a)if any provision of a law made by a District or
Regional Council in the State of Meghalaya with respect to any matter specified in sub-paragraph (1)
of paragraph 3 of this Schedule or if any provision of any regulation made by a District Council or a
Regional Council in that State under paragraph8 or paragraph 10 of this Schedule, is repugnant to
any provision of a law made by the Legislature of the State of Meghalaya with respect to that matter,
then, the law or regulation made by the District Council or, as the case may be, the Regional Council
whether made before or after the law made by the Legislature of the Stale of Meghalaya, shall, to the
extent of repugnancy, be void and the law made by the Legislature of the State of Meghalaya shall
prevail;(b)the President may, with respect to any Act of Parliament, by notification, direct that it
shall not apply to an autonomous district or an autonomous region in the State of Meghalaya, or
shall apply to such district or region or any part thereof subject to such exceptions or modifications
as he may specify in the notification and any such direction may be given so as to have retrospective
effect
12AA. Application of Acts of Parliament and of the Legislature of the State of
Tripura to the autonomous district and autonomous regions in the State of
Tripura
Notwithstanding anything in this Constitution-(a)no Act of the Legislature of the State of Tripura in
respect of any of the matters specified in paragraph 3 of this Schedule as matters with respect to
which a District Council or a Regional Council may make laws, and no Act of the Legislature of the
State of Tripura prohibiting or restricting the consumption of any non-distilled alcoholic liquor shall
apply to the autonomous district or an autonomous region in that State unless, in either case, the
District Council for that district or having jurisdiction over such region by public notification so
directs, and the District Council in giving such direction with respect to any Act direct that the Act
shall, in its application to that district or such region or any part thereof, have effect subject to such
exceptions or modifications as it thinks fit;(b)the Governor may, by public notification, direct that
any Act of the Legislature of the State of Tripura to which the provisions of clause (a) of this
sub-paragraph do not apply, shall not apply to the autonomous district or an autonomous region in
that State, or shall apply to that district or such region, or any part thereof, subject to such
exceptions or modifications, as he may specify in the notification;(c)the President may, with respect
to any Act of Parliament, by notification, direct that it shall not apply to the autonomous district or
an autonomous region in the State of Tripura, or shall apply to such district or region or any part
thereof, subject to such exceptions or modifications as he may specify in the notification and any
such direction may be given so as to have retrospective effect.Constitution of India

12B. Application of Acts of Parliament and of the Legislature of the State of
Mizoram to autonomous districts and autonomous regions in the State of
Mizoram
Notwithstanding anything in this Constitution, -(a)no Act of the Legislature of the State of Mizoram
in respect of any of the matters specified in paragraph 3 of this Schedule as matters with respect to
which a District Council or a Regional Council may make laws, and no Act of Legislature of the State
of Mizoram prohibiting or restricting the consumption of any non-distilled alcoholic liquor shall
apply to any autonomous district or autonomous region in that Slate unless, in either case, the
District Council for such district or having jurisdiction over such region, by public notification, so
directs, and the District Council, in giving such direction with respect to any Act, may direct that the
Act shall, in its application to such district or region or any part thereof, have effect subject to such
exceptions or modifications as it thinks fit;(b)the Governor may, by public notification, direct that
any Act of the Legislature of the State of Mizoram to which the provisions of clause (a) of this
sub-paragraph do not apply, shall not apply to an autonomous district or an autonomous region in
that Stale, or shall apply to such district or region, or any part thereof, subject to such exceptions or
modifications, as he may specify in the notification;(c)the President may, with respect to any Act of
Parliament, by notification, direct that it shall not apply to an autonomous district or an
autonomous region in the State of Mizoram, or shall apply to such district or region or any part
thereof, subject to such exceptions or modifications as he may specify in the notification and any
such direction may be given so as to have retrospective effect.
13. Estimated receipts and expenditure pertaining to autonomous districts to
be shown separately in the annual financial statement
The estimated receipts and expenditure pertaining to an autonomous district which are to be
credited to, or is to be made from, the Consolidated Fund of the State shall be first placed before the
District Council for discussion and then after such discussion be shown separately in the annual
financial statement of the State to be laid before the Legislature of the State under article 202.
14. Appointment of Commission to inquire into and report on the
administration of autonomous districts and autonomous regions
(1)The Governor may at any time appoint a Commission to examine and report on any matter
specified by him relating to the administration of the autonomous districts and autonomous regions
in the State, including matters specified in clauses (c), (d), (e) and (f) of sub- paragraph (3) of
paragraph 1 of this Schedule, or may appoint a Commission to inquire into and report from time to
time on the administration of autonomous districts and autonomous regions in the State generally
and in particular on-(a)the provision of educational and medical facilities and communications in
such districts and regions;(b)the need for any new or special legislation in respect of such districts
and regions; and(c)the administration of the laws, rules and regulations made by the District and
Regional Councils; and define the procedure to be followed by such Commission.(2)The report of
every such Commission with the recommendations of the Governor with respect thereto shall be laidConstitution of India

before the Legislature of the State by the Minister concerned together with an explanatory
memorandum regarding the action proposed to be taken thereon by the Government of the
State.(3)In allocating the business of the Government of the State among his Ministers the Governor
may place one of his Ministers specially in charge of the welfare of the autonomous districts and
autonomous regions in the State.
15. Annulment or suspension of acts and resolutions of District and Regional
Councils
(1)If at any time the Governor is satisfied that an act or resolution of a District or a Regional Council
is likely to endanger the safety of India or is likely to be prejudicial to public order, he may annul or
suspend such act or resolution and take such steps as he may consider necessary (including the
suspension of the Council and the assumption to himself of all or any of the powers vested in or
exercisable by the Council) to prevent the commission or continuance of such act, or the giving of
effect to such resolution.(2)Any order made by the Governor under sub-paragraph (1) of this
paragraph together with the reasons therefore shall be laid before the Legislature of the State as
soon as possible and the order shall, unless revoked by the Legislature of the State, continue in force
for a period of twelve months from the date on which it was so made:Provided that if and so often as
a resolution approving the continuance in force of such order is passed by the Legislature of the
State, the order shall unless cancelled by the Governor continue in force for a further period of
twelvemonths from the date on which under this paragraph it would otherwise have ceased to
operate.
16. Dissolution of a District or a Regional Council
(1)The Governor may on the recommendation of a Commission appointed under paragraph14 of this
Schedule by public notification order the dissolution of a District or a Regional Council,
and-(a)direct that a fresh general election shall be held immediately for the reconstitution of the
Council, or(b)subject to the previous approval of the Legislature of the State assume the
administration of the area under the authority of such Council himself or place the administration of
such area under the Commission appointed under the said paragraph or any other body considered
suitable by him for a period not exceeding twelve months:Provided that when an order under clause
(a) of this paragraph has been made, the Governor may take the action referred to in clause (b) of
this paragraph with regard to the administration of the area in question pending the reconstitution
of the Council on fresh general election:Provided further that no action shall be taken under clause
(b) of this paragraph without giving the District or the Regional Council, as the case may be, an
opportunity of placing its views before the Legislature of the State.(2)If at any time the Governor is
satisfied that a situation has arisen in which the administration of an autonomous district or region
cannot be carried on in accordance with the provisions of this Schedule, he may, by public
notification assume to himself all or any of the functions or powers vested in or exercisable by the
District Council or, as the case may be, the Regional Council and declare that such functions or
powers shall be exercisable by such person or authority as he may specify in this behalf, for a period
not exceeding six months:Provided that the Governor may by a further order or orders extend the
operation of the initial order by a period not exceeding six months on each occasion.(3)Every orderConstitution of India

made under sub-paragraph (2) of this paragraph with the reasons therefor shall be laid before the
Legislature of the State and shall cease to operate at the expiration of thirty days from the date on
which the State Legislature first sits after the issue of the orders, unless, before the expiry of that
period it has been approved by the State Legislature.
17. Exclusion of areas from autonomous districts in forming constituencies
in such districts
For the purposes of elections to the Legislative Assembly of Assam or Meghalaya or Tripura or
Mizoram, the Governor may by order declare that any area within an autonomous district in the
State of Assam or Meghalaya or Tripura 42 or Mizoram, as the case may be, shall not form part of
any constituency to fill a seat or seats in the Assembly reserved for any such district but shall form
part of a constituency to fill a seat or seats in the Assembly not so reserved to be specified in the
order.
19. Transitional provisions
(1)As soon as possible after the commencement of this Constitution the Governor shall take steps for
the constitution of a District Council for each autonomous district in the State under this Schedule
and, until a District Council is so constituted for an autonomous district, the administration of such
district shall be vested in the Governor and the following provisions shall apply to the
administration of the areas within such district instead of the foregoing provisions of this Schedule,
namely:-(a)no Act of Parliament or of the Legislature of the State shall apply to any such area unless
the Governor by public notification so directs; and the Governor in giving such a direction with
respect to any Act may direct that the Act shall, in its application to the area or to any specified part
thereof, have effect subject to such exceptions or modifications as he thinks fit;(b)the Governor may
make regulations for the peace and good government of any such area and any regulations so made
may repeal or amend any Act of Parliament or of the Legislature of the State or any existing law
which is for the time being applicable to such area.(2)Any direction given by the Governor under
clause (a) of sub-paragraph (1) of this paragraph may be given so as to have retrospective
effect.(3)All regulations made under clause (b) of sub-paragraph (1) of this paragraph shall be
submitted forthwith to the President and, until assented to by him, shall have no effect.
20. Tribal areas
(1)The areas specified in Parts I, II, IIA. and III of the table below shall respectively be the tribal
areas within the State of Assam, the State of Meghalaya, the State of Tripura and the State of
Mizoram.(2)Any reference in Part I, Part II or Part III of the table below to any district shall be
construed as a reference to the territories comprised within the autonomous district of that name
existing immediately before the day appointed under clause (b) of section 2 of the North-Eastern
Areas (Reorganisation) Act, 1971:Provided that for the purposes of clauses (e) and (f) of
sub-paragraph (1) of paragraph3, paragraph 4, paragraph 5, paragraph 6, sub-paragraph (2), clauses
(a), (b), and (d) of sub-paragraph (3) and sub-paragraph (4) of paragraph 8 and clause (d) ofConstitution of India

sub-paragraph (2) of paragraph 10 of this Schedule, no part of the area comprised within the
municipality of Shillong shall be deemed to be within the Khasi Hills District.(3)The reference in
Part IIA in the table below to the 'Tripura Tribal Areas District' shall be construed as a reference to
the territory comprising the tribal areas specified in the First Schedule to the Tripura Tribal Areas
Autonomous District Council Act, 1979.TABLE
Part I
(1)The North Cachar Hills District.(2)The Karbi Anglong District.(3)The Bodol and Territorial Areas
District.
Part II
(1)Khasi Hills District.(2)Jaintia Hills District.(3)The Garo Hills District.
Part IIA
Tripura Tribal Areas District.
Part III
(1)The Chakma District.(2)The Mara District.(3)The Lai District.
20A. Dissolution of the Mizo District Council
(1)Notwithstanding anything in this Schedule, the District Council of the Mizo District existing
immediately before the prescribed date (hereinafter referred to as the Mizo District Council) shall
stand dissolved and cease to exist.(2)The Administrator of the Union territory of Mizoram may, by
one or more orders, provide for all or any of the following matters, namely:-(a)the transfer, in whole
or in part, of the assets, rights and liabilities of the Mizo District Council (including the rights and
liabilities under any contract made by it) to the Union or to any other authority;(b)the substitution
of the Union or any other authority for the Mizo District Council, or the addition of the Union or any
other authority, as a party to any legal proceedings to which the Mizo District Council is a
party;(c)the transfer or re-employment of any employees of the Mizo District Council to or by the
Union or any other authority, the terms and conditions of service applicable to such employees after
such transfer or re-employment;(d)the continuance of any laws, made by the Mizo District Council
and in force immediately before its dissolution, subject to such adaptations and modifications,
whether by way of repeal or amendment, as the Administrator may make in this behalf, until such
laws are altered, repealed or amended by a competent Legislature or other competent
authority;(e)such incidental, consequential and supplementary matters as the Administrator
considers necessary.Explanation.- In this paragraph and in paragraph 20B of this Schedule, the
expression 'prescribed date' means the date on which the Legislative Assembly of the Union territoryConstitution of India

of Mizoram is duly constituted under and in accordance with the provisions of the Government of
Union Territories Act, 1963.
20B. Autonomous regions in the Union territory of Mizoram to be
autonomous districts and transitory provisions consequent thereto
(1)Notwithstanding anything in this Schedule,-(a)every autonomous region existing immediately
before the prescribed date in the Union territory of Mizoram shall, on and from that date, be an
autonomous district in that Union territory (hereafter referred to as the corresponding new district)
and the Administrator thereof may, by one or more orders, direct that such consequential
amendments as are necessary to give effect to the provisions of this clause shall be made in
paragraph 20 of this Schedule (including Part III of the table appended to that paragraph) and
thereupon the said paragraph and the said Part III shall be deemed to have been amended
accordingly;(b)every Regional Council of an autonomous region in the Union territory of
Mizoramexisting immediately before the prescribed date (hereafter referred to as the existing
Regional Council) shall, on and from that date and until a District Council is duly constituted for the
corresponding new district, be deemed to be the District Council of that district (here after referred
to as the corresponding new District Council).(2)Every member whether elected or nominated of an
existing Regional Council shall be deemed to have been elected or, as the case may be, nominated to
the corresponding new District Council and shall hold office until a District Council is duly
constituted for the corresponding new district under this Schedule.(3)Until rules are made under
sub-paragraph (7) of paragraph 2 and sub-paragraph(4) of paragraph 4 of this Schedule by the
corresponding new District Council, the rules made under the said provisions by the existing
Regional Council and in force immediately before the prescribed date shall have effect in relation to
the corresponding new District Council subject to such adaptations and modifications as may be
made therein by the Administrator of the Union territory of Mizoram.(4)The Administrator of the
Union territory of Mizoram may, by one or more orders, provide for all or any of the following
matters, namely:-(a)the transfer in whole or in part of the assets, rights and liabilities of the existing
Regional Council (including the rights and liabilities under any contract made by it) to the
corresponding new District Council;(b)the substitution of the corresponding new District Council
for the existing Regional Council as a party to the legal proceedings to which the existing Regional
Council is a party;(c)the transfer or re-employment of any employees of the existing Regional
Council to or by the corresponding new District Council, the terms and conditions of service
applicable to such employees after such transfer or re-employment;(d)the continuance of any laws
made by the existing Regional Council and in force immediately before the prescribed date, subject
to such adaptations and modifications, whether byway of repeal or amendment, as the
Administrator may make in this behalf until such laws are altered, repealed or amended by a
competent Legislature or other competent authority;(e)such incidental, consequential and
supplementary matters as the Administrator considers necessary.
20C. Interpretation
Subject to any provision made in this behalf, the provisions of this Schedule shall, in their
application to the Union territory of Mizoram, have effect-(1)as if references to the Governor andConstitution of India

Government of the State were references to the Administrator of the Union territory appointed
under article 239, references to State (except in the expression 'Government of the State') were
references to the Union territory of Mizoram and references to the State Legislature were references
to the Legislative Assembly of the Union territory of Mizoram;(2)as if-(a)in sub-paragraph (5) of
paragraph 4, the provision for consultation with the Government of the State concerned had been
omitted;(b)in sub-paragraph (2) of paragraph 6, for the words 'to which the executive power of the
State extends', the words 'with respect to which the Legislative Assembly of the Union territory of
Mizoram has power to make laws' had been substituted;(c)in paragraph 13, the words and figures
'under article 202' had been omitted.
21. Amendment of the Schedule
(1)Parliament may from time to time by law amend by way of addition, variation or repeal any of the
provisions of this Schedule and, when the Schedule is so amended, any reference to this Schedule in
this Constitution shall be construed as a reference to such Schedule as so amended.(2)No such law
as is mentioned in sub-paragraph (1) of this paragraph shall be deemed to be an amendment of this
Constitution for the purposes of article 368.
Schedule 7
[Editorial comment-The Constitution (Forty-Second Amendment) Act, 1976, Transfer of five
subjects from the state list to the concurrent list: Administration of Justice Forests Protection of
Wild Animals and Birds Education Weights & Measures. Also Refer]
1. List I - Union List
(1)Defence of India and every part thereof including preparation for defence and all such acts as may
be conducive in times of war to its prosecution and after its termination of effective
demobilisation.(2)Naval, military and air forces; any other armed forces of the
Union.(2A)Deployment of any armed force of the Union or any other force subject to the control of
the Union or any contingent or unit thereof in any State in aid of the civil power; powers,
jurisdiction, privileges and liabilities of the members of such forces while on such
deployment.(3)Delimitation of cantonment areas, local self-government in such areas, the
constitution and powers within such areas of cantonment authorities and the regulation of house
accommodation (including the control of rents) in such areas.(4)Naval, military and air force
works.(5)Arms, firearms, ammunition and explosives.(6)Atomic energy and mineral resources
necessary for its production.(7)Industries declared by Parliament by law to be necessary for the
purpose of defence or for the prosecution of war.(8)Central Bureau of Intelligence and
Investigation.(9)Preventive detention for reasons connected with Defence, Foreign Affairs, or the
security of India; persons subjected to such detention.(10)Foreign affairs; all matters which bring
the Union into relation with any foreign country.(11)Diplomatic, consular and trade
representation.(12)United Nations Organisation.(13)Participation in international conferences,
associations and other bodies and implementing of decisions made thereat.(14)Entering into
treaties and agreements with foreign countries and implementing of treaties, agreements andConstitution of India

conventions with foreign countries.(15)War and peace.(16)Foreign jurisdiction.(17)Citizenship,
naturalisation and aliens.(18)Extradition.(19)Admission into, and emigration and expulsion from,
India; passports and visas.(20)Pilgrimages to places outside India.(21)Piracies and crimes
committed on the high seas or in the air; offences against the law of nations committed on land or
the high seas or in the air.(22)Railways.(23)Highways declared by or under law made by Parliament
to be national highways.(24)Shipping and navigation on inland waterways, declared by Parliament
by law to be national waterways, as regards mechanically propelled vessels; the rule of the road on
such waterways.(25)Maritime shipping and navigation, including shipping and navigation on tidal
waters; provision of education and training for the mercantile marine and regulation of such
education and training provided by States and other agencies.(26)Lighthouses, including lightships,
beacons and other provisions for the safety of shipping and aircraft.(27)Ports declared by or under
law made by Parliament or existing law to be major ports, including their delimitation and the
constitution and powers of port authorities therein.(28)Port quarantine, including hospitals
connected therewith; seamen's and marine hospitals.(29)Airways; aircraft and air navigation;
provision of aerodromes; regulation and organisation of air traffic and of aerodromes; provision for
aeronautical education and training and regulation of such education and training provided by
States and other agencies.(30)Carriage of passengers and goods by railway, sea or air, or by national
waterways in mechanically propelled vessels.(31)Posts and telegraphs; telephones, wireless,
broadcasting and other like forms of communication.(32)Property of the Union and the revenue
therefrom, but as regards property situated in a State subject to legislation by the State, save in so
far as Parliament by law otherwise provides.(33)(34)Courts of wards for the estates of Rulers of
Indian States.(35)Public debt of the Union.(36)Currency, coinage and legal tender; foreign
exchange.(37)Foreign loans.(38)Reserve Bank of India.(39)Post Office Savings Bank.(40)Lotteries
organised by the Government of India or the Government of a State.(41)Trade and commerce with
foreign countries; import and export across customs frontiers; definition of customs
frontiers.(42)Inter-State trade and commerce.(43)Incorporation, regulation and winding up of
trading corporations, including banking, insurance and financial corporations but not including
co-operative societies.(44)Incorporation, regulation and winding up of corporations, whether
trading or not, with objects not confined to one State, but not including
universities.(45)Banking.(46)Bills of exchange, cheques, promissory notes and other like
instruments.(47)Insurance.(48)Stock exchanges and futures markets.(49)Patents, inventions and
designs; copyright; trade-marks and merchandise marks.(50)Establishment of standards of weight
and measure.(51)Establishment of standards of quality for goods to be exported out of India or
transported from one State to another.(52)Industries, the control of which by the Union is declared
by Parliament by law to be expedient in the public interest.(53)Regulation and development of oil
fields and mineral oil resources; petroleum and petroleum products; other liquids and substances
declared by Parliament by law to be dangerously inflammable.(54)Regulation of mines and mineral
development to the extent to which such regulation and development under the control of the Union
is declared by Parliament by law to be expedient in the public interest.(55)Regulation of labour and
safely in mines and oilfields.(56)Regulation and development of inter-State rivers and river valleys
to the extent to which such regulation and development under the control of the Union is declared
by Parliament by law to be expedient in the public interest.(57)Fishing and fisheries beyond
territorial waters.(58)Manufacture, supply and distribution of salt by Union agencies, regulation
and control of manufacture, supply and distribution of salt by other agencies.(59)Cultivation,Constitution of India

manufacture, and sale for export, of opium.(60)Sanctioning of cinematograph films for
exhibition.(61)Industrial disputes concerning Union employees.(62)The institutions known at the
commencement of this Constitution as the National Library, the Indian Museum, the Imperial War
Museum, the Victoria Memorial and the Indian War Memorial, and any other like institution
financed by the Government of India wholly or in part and declared by Parliament by law to be an
institution of national importance.(63)The institutions known at the commencement of this
Constitution as the Banaras Hindu University, the Aligarh Muslim University and the Delhi
University; the University established in pursuance of article 371E; any other institution declared by
Parliament by law to be an institution of national importance.(64)Institutions for scientific or
technical education financed by the Government of India wholly or in part and declared by
Parliament by law to be institutions of national importance.(65)Union agencies and institutions
for-a. professional, vocational or technical training, including the training of police officers; orb. the
promotion of special studies or research; orc. scientific or technical assistance in the investigation or
detection of crime.(66)Co-ordination and determination of standards in institutions for higher
education or research and scientific and technical institutions.(67)Ancient and historical
monuments and records, and archaeological sites and remains, declared by or under law made by
Parliament to be of national importance.(68)The Survey of India, the Geological, Botanical,
Zoological and Anthropological Surveys of India; Meteorological
organisations.(69)Census.(70)Union Public Services; All-India Services; Union Public Service
Commission.(71)Union pensions, that is to say, pensions payable by the Government of India or out
of the Consolidated Fund of India.(72)Elections to Parliament, to the Legislatures of States and to
the offices of President and Vice-President; the Election Commission.(73)Salaries and allowances of
members of Parliament, the Chairman and Deputy Chairman of the Council of States and the
Speaker and Deputy Speaker of the House of the People.(74)Powers, privileges and immunities of
each House of Parliament and of the members and the Committees of each House; enforcement of
attendance of persons for giving evidence or producing documents before committees of Parliament
or commissions appointed by Parliament.(75)Emoluments, allowances, privileges, and rights in
respect of leave of absence, of the President and Governors; salaries and allowances of the Ministers
for the Union: the salaries, allowances, and rights in respect of leave of absence and other conditions
of service of the Comptroller and Auditor-General.(76)Audit of the accounts of the Union and of the
States.(77)Constitution, organisation, jurisdiction and powers of the Supreme Court (including
contempt of such Court), and the fees taken therein; persons entitled to practise before the Supreme
Court.(78)Constitution and Organisation (including vacations) of the High Courts except provisions
as to officers and servants of High Courts; persons entitled to practise before the High
Courts.[Editorial comment-The Constitution (Fifteenth Amendment) Act, 1963, they added
Entry 78 in List 1 has been changed to clarify that “vacations” is included in the definition of
“organization” there.](79)Extension of the jurisdiction of a High Court to, and exclusion of the
jurisdiction of a High Court from, any Union territory.(80)Extension of the powers and jurisdiction
of members of a police force belonging to any State to any area outside that State, but not so as to
enable the police of one State to exercise powers and jurisdiction in any area outside that State
without the consent of the Government of the State in which such area is situated; extension of the
powers and jurisdiction of members of a police force belonging to any State to railway areas outside
that State.(81)Inter-State migration; inter-Stale quarantine.(82)Taxes on income other than
agricultural income.(83)Duties of customs including export duties.(84)Duties of excise on theConstitution of India

following goods manufactured or produced in India, namely:—(a)petroleum crude;(b)high speed
diesel;(c)motor spirit (commonly known as petrol);(d)natural gas;(e)aviation turbine fuel;
and(f)tobacco and tobacco products.[Editorial comment-The Constitution (One Hundred and
First Amendment) Act, 2016, instituted a nationwide Goods and Services Tax (GST) in India on July
1, 2017. It is the Constitution of India’s One Hundred and Twenty-Second Amendment Bill. GST is a
Value Added Tax (VAT) proposed at the national level to be a comprehensive indirect tax levy on the
manufacture, sale, and consumption of goods and services. It would replace all indirect taxes levied
by the Indian Central and state governments on goods and services. It is intended to be
comprehensive for the majority of goods and services. In the past, a person was required to pay a
significant amount of taxes, including Central Excise Duty, Additional Excise Duty, Service Tax,
Additional Customs Duty, State VAT, Entertainment Tax, and Entry Tax. The calculation of tax was
significantly simplified with the introduction of the Goods and Services Tax. The Constitution
Amendment Bill 122, often known as the 101 Amendment to the Indian Constitution, advocated for
the implementation of GST. To prevent tax escalation and establish a single market for goods and
services, the goods and services tax will replace numerous indirect taxes levied by the federal and
state governments.Also Refer](85)Corporation tax.(86)Taxes on the capital value of the assets,
exclusive of agricultural land, of individuals and companies; taxes on the capital of
companies.(87)Estate duty in respect of property other than agricultural land.(88)Duties in respect
of succession to property other than agricultural land.(89)Terminal taxes on goods or passengers,
carried by railway, sea or air; taxes on railway fares and freights.(90)Taxes other than stamp duties
on transactions in stock exchanges and futures markets.(91)Rates of stamp duty in respect of bills of
exchange, cheques, promissory notes, bills of lading, letters of credit, policies of insurance, transfer
of shares, debentures, proxies and receipts.(92)Taxes on the sale or purchase of newspapers and on
advertisements published therein.(92A)Taxes on the sale or purchase of goods other than
newspapers, where such sale or purchase takes place in the course of inter-State trade or
commerce.[In the Union List, after entry 92, the following entry shall be inserted through
Constitution (Sixth Amendment) Act, 1956][Editorial comment- The Constitution (Sixth
Amendment) Act, 1956, amendment in Schedule 7 by inserting of entry 92A catering taxes on
inter-state commerce and trade excluding newspaper. According to the guidelines of entry 92A of
List 1, entry 54 of the state list details, the taxes levied on the acquisition or sale of commodities
other than newspapers. Important Verdict: Bengal Immunity Co. Ltd. vs State Of Bihar And Ors ,
The State Of Bombay And Another vs The United Motors (India)Ltd & Also Refer ](92B)Taxes on
the consignment of goods (whether the consignment is to the person making it or to any other
person), where such consignment takes place in the course of inter-State trade or
commerce.{{*[Editorial comment-The Constitution (Forty-Sixth Amendment) Act, 1982, states
that it is the responsibility of the State to prioritize and promote the upliftment of weaker sections of
society, especially Scheduled Castes and Scheduled Tribes, in the areas of education and economic
interests. Across the country, different classes of society vary in their concentration of wealth and
access to facilities. Access to a decent standard of living and humane conditions is a fundamental
right for all citizens. Therefore, Article 46 of the Indian Constitution aims to provide a better
standard of life and equal opportunities to weaker sections of society, particularly Scheduled Castes
and Scheduled Tribes, by ensuring education and progressive economic conditions for them.Also
Refer]](92C)Taxes on services.Not yet in force.(93)Offences against laws with respect to any of the
matters in this List.(94)Inquiries, surveys and statistics for the purpose of any of the matters in thisConstitution of India

List.(95)Jurisdiction and powers of all courts, except the Supreme Court, with respect to any of the
matters in this List; admiralty jurisdiction.(96)Fees in respect of any of the matters in this List, but
not including fees taken in any court.(97)Any other matter not enumerated in List II or List III
including any tax not mentioned in either of those Lists.
2. List II-State List
(1)Public order (but not including the use of any naval, military or Air force or any other armed force
of the Union or of any other force subject to the control of the Union or of any contingent or unit
thereof in aid of the civil power).(2)Police (including railway and village police) subject to the
provisions of entry 2A of List I.(3)Officers and servants of the High Court; procedure in rent and
revenue courts; fees taken in all courts except the Supreme Court.(4)Prisons, reformatories, Borstal
institutions and other institutions of a like nature, and persons detained therein; arrangements with
other States for the use of prisons and other institutions.(5)Local government, that is to say, the
constitution and powers of municipal corporations, improvement trusts, district boards, mining
settlement authorities and other local authorities for the purpose of local self-government or village
administration.(6)Public health and sanitation; hospitals and dispensaries.(7)Pilgrimages, other
than pilgrimages to places outside India.(8)Intoxicating liquors, that is to say, the production,
manufacture, possession, transport, purchase and sale of intoxicating liquors.(9)Relief of the
disabled and unemployable.(10)Burials and burial grounds; cremations and cremation
grounds.(11)(12)Libraries, museums and other similar institutions controlled or financed by the
State; ancient and historical monuments and records other than those declared by or under law
made by Parliament to be of national importance.(13)Communications, that is to say, roads, bridges,
ferries, and other means of communication not specified in List I; municipal tramways; ropeways;
inland waterways and traffic thereon subject to the provisions of List I and List III with regard to
such waterways; vehicles other than mechanically propelled vehicles.(14)Agriculture, including
agricultural education and research, protection against pests and prevention of plant
diseases.(15)Preservation, protection and improvement of stock and prevention of animal diseases;
veterinary training and practice.(16)Pounds and the prevention of cattle trespass.(17)Water, that is
to say, water supplies, irrigation and canals, drainage and embankments, water storage and water
power subject to the provisions of entry 56 of List I.(18)Land, that is to say, right in or over land,
land tenures including the relation of landlord and tenant, and the collection of rents; transfer and
alienation of agricultural land; land improvement and agricultural loans;
colonization.(19)(20)(21)Fisheries(22)Courts of wards subject to the provisions of entry 34 of List I;
encumbered and attached estates(23)Regulation of mines and mineral development subject to the
provisions of List I with respect to regulation and development under the control of the
Union(24)Industries subject to the provisions of entries 7 and 52 of List I(25)Gas and
gas-works(26)Trade and commerce within the State subject to the provisions of entry 33 of List
III(27)Production, supply and distribution of goods subject to the provisions of entry 33 of List
III(28)Markets and fairs(29)(30)Money-lending and money-lenders; relief of agricultural
indebtedness(31)Inns and inn-keepers(32)Incorporation, regulation and winding up of corporation,
other than those specified in List I, and universities; unincorporated trading, literacy, scientific,
religious and other societies and associations; co-operative societies(33)Theaters and dramatic
performances; cinemas subject to the provisions of entry 60 of List 1; sports, entertainments andConstitution of India

amusements(34)Betting and gambling(35)Works, lands and buildings vested in or in the possession
of the State(36)(37)Elections to the Legislature of the State subject to the provisions of any law
made by Parliament(38)Salaries and allowances of members of the Legislature of the State, of the
Speaker and Deputy Speaker of the Legislative Assembly and, if there is a Legislative Council, of the
Chairman and Deputy Chairman thereof(39)Powers, privileges and immunities of the Legislative
Assembly and of the members and the committees thereof, and, if there is a Legislative Council, of
that Council and of the members and the committees thereof; enforcement of attendance of persons
for giving evidence or producing documents before committees of the Legislature of the
State(40)Salaries and allowances of Ministers for the State(41)Stale public services; State Public
Service Commission(42)State pensions, that is to say, pensions payable by the Slate or out of the
Consolidated Fund of the State(43)Public debt of the State(44)Treasure trove(45)Land revenue,
including the assessment and collection of revenue, the maintenance of land records, survey for
revenue purposes and records of rights, and alienation of revenues(46)Taxes on agricultural
income(47)Duties in respect of succession to agricultural land(48)Estate duty in respect of
agricultural land(49)Taxes on lands and buildings(50)Taxes on mineral rights subject to any
limitations imposed by Parliament by law relating to mineral development(51)Duties of excise on
the following goods manufactured or produced in the State and countervailing duties at the same or
lower rates on similar goods manufactured or produced elsewhere in India:-(a)alcoholic liquors for
human consumption;(b)opium, Indian hemp and other narcotic drugs and narcotics;but not
including medicinal and toilet preparations containing alcohol or any substance included in
sub-paragraph (b) of this entry.(52)Taxes on the entry of goods into a local area for consumption,
use or sale therein(53)Taxes on the consumption or sale of electricity(54)Taxes on the sale or
purchase of goods other than newspapers, subject to the provisions of entry 92A of List I. [In the
State List, for entry 54, the following entry shall be substituted,through Constitution (Sixth
Amendment) Act, 1956]Taxes on the sale of petroleum crude, high speed diesel, motor spirit
(commonly known as petrol), natural gas, aviation turbine fuel and alcoholic liquor for human
consumption, but not including sale in the course of inter-State trade or commerce or sale in the
course of international trade or commerce of such goods. [for Entry 54, the following entry shall be
substituted through Constitution (One Hundred and First Amendment) Act, 2016](55)Taxes on
advertisements other than advertisements published in the newspapers and advertisements
broadcast by radio or television [Entry 55 shall be omitted](56)Taxes on goods and passengers
carried by road or on inland waterways(57)Taxes on vehicles, whether mechanically propelled or
not, suitable for use on roads, including tramcars subject to the provisions of entry 35 of List
III(58)Taxes on animals and boats(59)Tolls(60)Taxes on professions, trades, callings and
employments(61)Captivation taxes(62)Taxes on luxuries, including taxes on entertainments,
amusements, betting and gambling [for Entry 62, the following entry shall be substituted through
Constitution (One Hundred and First Amendment) Act, 2016](63)Rates of stamp duty in respect of
documents other than those specified in the provisions of List I with regard to rates of stamp
duty(64)Offences against laws with respect to any of the matters in this List(65)Jurisdiction and
powers of all courts, except the Supreme Court, with respect to any of the matters in this
List(66)Fees in respect of any of the matters in this List, but not including fees taken in any courtConstitution of India

3. List III-Concurrent List
(1)Criminal law, including all matters included in the Indian Penal Code at the commencement of
this Constitution, but excluding offences against laws with respect to any of the matters specified in
List I or List II and excluding the use of naval, military or air forces or any other armed forces of the
Union in aid of the civil power(2)Criminal procedure, including all matters included in the Code of
Criminal Procedure at the commencement of this Constitution(3)Preventive detention for reasons
connected with the security of a State, the maintenance of public order, or the maintenance of
supplies and services essential to the community; persons subjected to such detention(4)Removal
from one State to another State of prisoners, accused persons and persons subjected to preventive
detention for reasons specified in entry 3 of this List(5)Marriage and divorce; infants and minors;
adoption; wills, intestacy and succession; joint family and partition; all matters in respect of which
parties in judicial proceedings were immediately before the commencement of this Constitution
subject to their personal law(6)Transfer of property other than agricultural land; registration of
deeds and documents(7)Contracts, including partnership, agency, contracts of carriage, and other
special forms of contracts, but not including contracts relating to agricultural land(8)Actionable
wrongs(9)Bankruptcy and insolvency(10)Trust and Trustees(11)Administrators-general and official
trustees(11A)Administration of justice; constitution and organisation of all courts, except the
Supreme Court and the High Courts(12)Evidence and oaths; recognition of laws, public acts and
records, and judicial proceedings(13)Civil procedure, including all matters included in the Code of
Civil Procedure at the commencement of this Constitution, limitation and arbitration(14)Contempt
of court, but not including contempt of the Supreme Court(15)Vagrancy; nomadic and migratory
tribes(16)Lunacy and mental deficiency, including places for the reception or treatment of lunatics
and mental deficients(17)Prevention of cruelty to animals(17A)Forests(17B)Protection of wild
animals and birds(18)Adulteration of foodstuffs and other goods(19)Drugs and poisons, subject to
the provisions of entry 59 of List I with respect to opium(20)Economic and social
planning(20A)Population control and family planning(21)Commercial and industrial monopolies,
combines and trusts(22)Trade unions; industrial and labour disputes(23)Social security and social
insurance; employment and unemployment(24)Welfare of labour including conditions of work,
provident funds, employers' liability, workmen's compensation, invalidity and old age pensions and
maternity benefits(25)Education, including technical education, medical education and universities,
subject to the provisions of entries 63, 64, 65 and 66 of List I; vocational and technical training of
labour(26)Legal, medical and other professions(27)Relief and rehabilitation of persons displaced
from their original place of residence by reason of the setting up of the Dominions of India and
Pakistan(28)Charities and charitable institutions, charitable and religious endowments and
religious institutions(29)Prevention of the extension from one State to another of infectious or
contagious diseases or pests affecting men, animals or plants(30)Vital statistics including
registration of births and deaths(31)Ports other than those declared by or under law made by
Parliament or existing law to be major ports(32)Shipping and navigation on inland waterways as
regards mechanically propelled vessels, and the rule of the road on such waterways, and the carriage
of passengers and goods on inland waterways subject to the provisions of List I with respect to
national waterways(33)Trade and commerce in, and the production, supply and distribution
of,-(a)the products of any industry where the control of such industry by the Union is declared by
Parliament by law to be expedient in the public interest, and imported goods of the same kind asConstitution of India

such products;(b)foodstuffs, including edible oilseeds and oils;(c)cattle fodder, including oilcakes
and other concentrates;(d)raw cotton, whether ginned or unginned, and cotton seed; and(e)raw
jute[Editorial comment- The Constitution (Third Amendment) Act, 1954, was a significant
milestone in the country’s economic development and political evolution. On September 6, 1954, the
bill of the 3rd amendment of the Indian Constitution was presented in the Lok Sabha and the Rajya
Sabha passed the bill on 28 September 1954. The amendment made changes to the Seventh
Schedule and widened the scope of Entry 33, List III, which lists the distribution of powers between
the central government and the state governments. Thus, empowering Parliament to control the
production, supply and distribution of all kinds of commodities. The 3rd Amendment of the Indian
constitution was introduced by Article 368, and it was ratified by several state legislatures like West
Bengal, Punjab, Rajasthan, Saurashtra, Patiala and East Punjab States Union, Madhya Pradesh,
Bihar, and Madras. Also refer.](33A)Weights and measures except establishment of
standards(34)Price control(35)Mechanically propelled vehicles including the principles on which
taxes on such vehicles are to be levied(36)Factories(37)Boilers(38)Electricity(39)Newspapers, books
and printing presses(40)Archaeological sites and remains other than those declared by or under law
made by Parliament to be of national importance(41)Custody, management and disposal of property
(including agricultural land) declared by law to be evacuee property(42)Acquisition and
requisitioning of property(43)Recovery in a Stale of claims in respect of taxes and other public
demands, including arrears of land-revenue and sums recoverable as such arrears, arising outside
that State(44)Stamp duties other than duties or fees collected by means of judicial stamps, but not
including rates of stamp duty(45)Inquiries and statistics for the purposes of any of the matters
specified in List II or List III(46)Jurisdiction and powers of all courts, except the Supreme Court,
with respect to any of the matters in this List(47)Fees in respect of any of the matters in this List, but
not including fees taken in any court
Schedule 8
Articles 344(1) and
351Languages(1)Assamese.(2)Bengali.(3)Bodo(4)Dogri.(5)Gujarati.(6)Hindi.(7)Kannada.(8)Kashmiri.(9)Konkani.(10)Mathilli.(11)Malayalam.(12)Manipuri.(13)Marathi.(14)Nepali.(15)Odia(16)Punjabi.(17)Sanskrit.(18)Santhali.(19)Sindhi.(20)Tamil.(21)Telugu.(22)Urdu.[Editorial
comment-The Constitution (Twenty-First Amendment) Act, 1967, added the Sindhi language to
the Eighth Schedule of the Constitution. Sindhi was now recognized as an official state language,
bringing the overall number of languages on the 8th schedule to fifteen. It was one of the most
consequential amendments to the Constitution of India. The eighth schedule of the Indian
Constitution lists the official languages of the Republic of India. The languages were qualified for
representation in the Commission for Official Languages if it was listed. Also refer ][Editorial
comment-The Constitution (Seventy-first Amendment) Act, 1992, amended the Eighth Schedule to
the Constitution so as to include Konkani, Meitei (officially called "Manipuri") and Nepali
languages, thereby raising the total number of languages listed in the schedule to eighteen. The
Eighth Schedule lists languages that the Government of India has the responsibility to develop. The
Eighth Schedule to the Constitution originally included 14 languages Sindhi was included by the 21st
Amendment, enacted in 1967. Bodo, Dogri, Santhali and Maithili were included in the Eighth
Schedule in 2004, through the 92nd Amendment, raising the total number of languages to 22. Also
Refer][Editorial comment-The Constitution (Ninety-sixth Amendment) Act, 2011, required the
Union government to fix the state’s misspelled name and language in the first and eighth schedules
of the Constitution. In the 8th schedule of the Indian Constitution, Orissa’s language was changedConstitution of India

from Oriya to Odia as a result of this modification, and its spelling was changed from Orissa to
Odisha as a legislative act. Amendment to Eighth Schedule: In Entry 15 of the Eighth Schedule to the
Constitution, the word “Oriya” shall be replaced by the word “Odia.” It was altered to Schedule 1. In
Schedule 1, Entry 10 was changed from Orissa to Odisha, for instance, if Orissa became Odisha. The
constitution has changed all places where the word “Orissa” has appeared (for example Article 164).
There was a change to the entry in the fourth schedule.Also Refer]
Schedule 9
Article 31B[After the Eighth Schedule to the Constitution, the following Schedule shall be added
through Constitution (First Amendment) Act, 1951](1)The Bihar Land Reforms Act, 1950 (Bihar Act
XXX of 1950).(2)The Bombay Tenancy and Agricultural Lands Act, 1948 (Bombay Act LXVII of
1948).(3)The Bombay Maleki Tenure Abolition Act, 1949 (Bombay Act LXI of 1949).(4)The Bombay
Taluqdari Tenure Abolition Act, 1949 (Bombay Act LXII of 1949).(5)The Panch Mahals, Mehwassi
Tenure Abolition Act, 1949 (Bombay Act LXIII of1949).(6)The Bombay Khoti Abolition Act, 1950
(Bombay Act VI of 1950).(7)The Bombay Paragana and Kulkarni Watan Abolition Act, 1950
(Bombay Act LX of 1950).(8)The Madhya Pradesh Abolition of Proprietary Rights (Estates, Mahals,
Alienated Lands) Act, 1950 (Madhya Pradesh Act 1 of 1951).(9)The Madras Estates (Abolition and
Conversion into Ryotwari) Act, 1948 (Madras Act XXVI of 1948).(10)The Madras Estates (Abolition
and Conversion into Ryotwari) Amendment Act, 1950(Madras Act 1 of 1950).(11)The Uttar Pradesh
Zamindari Abolition and Land Reforms Act, 1950 (Uttar PradeshAct 1 of 1951).(12)The Hyderabad
(Abolition of Jagirs) Regulation, 1358FC (No. LXIX of 1358,Fasli).(13)The Hyderabad Jagirs
(Commutation) Regulation, 1359FC (No. XXV of 1359, Fasli).(14)The Bihar Displaced Persons
Rehabilitation (Acquisition of Land) Act, 1950 (Bihar Act XXXVIII of 1950).(15)The United
Provinces Land Acquisition (Rehabilitation of Refugees) Act, 1948(U. P. Act XXVI of 1948).(16)The
Resettlement of Displaced Persons (Land Acquisition) Act, 1948 (Act LX of1948).(17)Sections 52A to
52G of the Insurance Act, 1938 (Act IV of 1938), as inserted by section 42 of the Insurance
(Amendment) Act, 1950 (Act XLVII of 1950).(18)The Railway Companies (Emergency Provisions)
Act, 1951 (Act LI of 1951).(19)'Chapter IIIA - of the Industries (Development and Regulation) Act,
1951 (Act LXV of 1951), as inserted by section 13 of the Industries (Development and Regulation)
Amendment Act, 1953 (Act XXVI of 1953).(20)The West Bengal Land Development and Planning
Act, 1948 (West Bengal Act XXI of1948), as amended by West Bengal Act XXIX of 1951.[In the
Ninth Schedule to the Constitution, after entry 13, the following entries shall be added through
Constitution (Fourth Amendment) Act, 1955][Editorial Comment- The Constitution (Fourth
Amendment) Act, 1955, introduced changes to the Ninth Schedule. The primary reason for
amending the Ninth Schedule was to overcome the Supreme Court's rulings that had subjected
certain land reform laws to constitutional scrutiny. ]}}(21)The Andhra Pradesh Ceiling on
Agricultural Holdings Act, 1961 (Andhra Pradesh Act X of 1961).(22)The Andhra Pradesh
(Telangana Area) Tenancy and Agricultural Lands (Validation) Act, 1961 (Andhra Pradesh Act XXI
of 1961).(23)The Andhra Pradesh (Telangana Area) Ijara and Kowli Land Cancellation of Irregular
Pattas and Abolition of Concessional Assessment Act, 1961 (Andhra Pradesh Act XXXVI of
1961).(24)The Assam State Acquisition of Lands belonging to Religious or Charitable Institution of
Public Nature Act, 1959 (Assam Act IX of 1961).(25)The Bihar Land Reforms (Amendment) Act,
1953 (Bihar Act XX of 1954).(26)The Bihar Land Reforms (Fixation of Ceiling Area and Acquisition
of Surplus Land) Act, 1961 (Bihar Act XII of 1962), (except section 28 of this Act).(27)The BombayConstitution of India

Taluqdari Tenure Abolition (Amendment) Act, 1954 (Bombay Act 1 of1955).(28)The Bombay
Taluqdari Tenure Abolition (Amendment) Act, 1957 (Bombay Act XVIII of1958).(29)The Bombay
Inams (Kutch Area) Abolition Act, 1958 (Bombay Act XCVIII of 1958).(30)The Bombay Tenancy
and Agricultural Lands (Gujarat Amendment) Act, 1960 (Gujarat Act XVI of 1960).(31)The Gujarat
Agricultural Lands Ceiling Act, 1960 (Gujarat Act XXVI of 1961).(32)The Sagbara and Meshwassi
Estates (Proprietary Rights Abolition, etc.) Regulation, 1962 (Gujarat Regulation 1 of 1962).(33)The
Gujarat Surviving Alienations Abolition Act, 1963 (Gujarat Act XXXIII of1963), except in so far as
this Act relates to an alienation referred to in sub-clause (d) of clause (3) of section 2
thereof.(34)The Maharashtra Agricultural Lands (Ceiling on Holdings) Act, 1961 (Maharashtra Act
XXVII of 1961).(35)The Hyderabad Tenancy and Agricultural Lands (Re-enactment, Validation and
Further Amendment) Act, 1961 (Maharashtra Act XLV of 1961).(36)The Hyderabad Tenancy and
Agricultural Lands Act, 1950 (Hyderabad Act XXI of1950).(37)The Jenmikaram Payment
(Abolition) Act, 1960 (Kerala Act III of 1961).(38)The Kerala Land Tax Act, 1961 (Kerala Act XIII of
1961).(39)The Kerala Land Reforms Act, 1963 (Kerala Act 1 of 1964).(40)The Madhya Pradesh Land
Revenue Code, 1959 (Madhya Pradesh Act XX of 1959).(41)The Madhya Pradesh Ceiling on
Agricultural Holdings Act, 1960 (Madhya Pradesh Act XX of 1960).(42)The Madras Cultivating
Tenants Protection Act, 1955 (Madras Act XXV of 1955).(43)The Madras Cultivating Tenants
(Payment of Fair Rent) Act, 1956 (Madras Act XXIV of 1956).(44)The Madras Occupants of
Kudiyiruppu (Protection from Eviction) Act, 1961 (Madras Act XXXVIII of 1961).(45)The Madras
Public Trust (Regulation of Administration of Agricultural Lands) Act, 1961 (Madras Act LVII of
1961).(46)The Madras Land Reforms (Fixation of Ceiling on Land) Act, 1961 (Madras Act LVIII of
1961).(47)The Mysore Tenancy Act, 1952 (Mysore Act XIII of 1952).(48)The Coorg Tenants Act,
1957 (Mysore Act XIV of 1957).(49)The Mysore Village Offices Abolition Act, 1961 (Mysore Act XIV
of 1961).(50)The Hyderabad Tenancy and Agricultural Lands (Validation) Act, 1961 (Mysore Act
XXXVI of 1961).(51)The Mysore Land Reforms Act, 1961 (Mysore Act X of 1962).(52)The Orissa
Land Reforms Act, 1960 (Orissa Act XVI of 1960).(53)The Orissa Merged Territories (Village Offices
Abolition) Act, 1963 (Orissa Act X of 1963).(54)The Punjab Security of Land Tenures Act, 1953
(Punjab Act X of 1953).(55)The Rajasthan Tenancy Act, 1955 (Rajasthan Act III of 1955).(56)The
Rajasthan Zamindari and Biswedari Abolition Act, 1959 (Rajasthan Act VIII of1959).(57)The
Kumaun and Uttarakhand Zamindari Abolition and Land Reforms Act, 1960 (Uttar Pradesh Act
XVII of 1960).(58)The Uttar Pradesh Imposition of Ceiling on Land Holdings Act, 1960 (Uttar
Pradesh Act I of 1961).(59)The West Bengal Estates Acquisition Act, 1953 (West Bengal Act 1 of
1954).(60)The West Bengal Land Reforms Act, 1955 (West Bengal Act X of 1956).(61)The Delhi
Land Reforms Act, 1954 (Delhi Act VIII of 1954).(62)The Delhi Land Holdings (Ceiling) Act, 1960
(Central Act 24 of I960).(63)The Manipur Land Revenue and Land Reforms Act, 1960 (Central Act
33 of 1960).(64)The Tripura Land Revenue and Land Reforms Act, 1960 (Central Act 43 of
1960).[In the Ninth Schedule to the Constitution, after entry 64 the following entries shall be
inserted through Constitution (Twenty-Ninth Amendment) Act, 1972](65)The Kerala Land Reforms
(Amendment) Act, 1969 (Kerala Act 35 of 1969).(66)The Kerala Land Reforms (Amendment) Act,
1971 (Kerala Act 25 of 1971).[Editorial Comment-The Constitution (Twenty-Ninth Amendment)
Act, 1972, which aimed to expand the ninth schedule of the Indian Constitution, included laws from
Kerala focused on land reform. Specifically, it added two acts to the schedule: the Kerala Land
Reforms (Amendment) Act, 1969 (Kerala Act 35 of 1969) and the Kerala Land Reforms
(Amendment) Act, 1971 (Kerala Act 25 of 1971). However, the legality of the 29th Amendment wasConstitution of India

challenged in a case brought by a petitioner whose land was subject to seizure under Kerala's Land
Reforms. The petitioner also questioned the validity of the 24th and 25th Constitutional
Amendments, which they claimed impacted their fundamental rights. This case led to the
development of the idea of the fundamental structure of the Constitution. Ultimately, seven judges
out of 13 ruled in favor of upholding the legitimacy of the 29th Amendment, although its validity was
not upheld completely. Important Verdict-Kesavananda Bharati vs State Of Kerala And Anr][In the
Ninth Schedule to the Constitution, after entry 66 the following entries shall be inserted through
Constitution (Thirty-Fourth Amendment) Act, 1974](67)The Andhra Pradesh Land Reforms (Ceiling
on Agricultural Holdings) Act, 1973(Andhra Pradesh Act I of 1973).(68)The Bihar Land Reforms
(Fixation of Ceiling Area and Acquisition of Surplus Land) (Amendment) Act, 1972 (Bihar Act I of
1973).(69)The Bihar Land Reforms (Fixation of Ceiling Area and Acquisition of Surplus Land)
(Amendment) Act, 1973 (Bihar Act IX of 1973).(70)The Bihar Land Reforms (Amendment) Act, 1972
(Bihar Act V of 1972).(71)The Gujarat Agricultural Lands Ceiling (Amendment) Act, 1972 (Gujarat
Act 2 of1974).(72)The Haryana Ceiling on Land Holdings Act, 1972 (Haryana Act 26 of
1972).(73)The Himachal Pradesh Ceiling on Land Holdings Act, 1972 (Himachal Pradesh Act 19of
1973).(74)The Kerala Land Reforms (Amendment) Act, 1972 (Kerala Act 17 of 1972).(75)The
Madhya Pradesh Ceiling on Agricultural Holdings (Amendment) Act, 1972(Madhya Pradesh Act 12
of 1974).(76)The Madhya Pradesh Ceiling on Agricultural Holdings (Second Amendment) Act,
1972(Madhya Pradesh Act 13 of 1974).(77)The Mysore Land Reforms (Amendment) Act, 1973
(Karnataka Act I of 1974).(78)The Punjab Land Reforms Act, 1972 (Punjab Act 10 of 1973).(79)The
Rajasthan Imposition of Ceiling on Agricultural Holdings Act, 1973(Rajasthan Act II of
1973).(80)The Gudalur Janmam Estates (Abolition and Conversion into Ryotwari) Act, 1969(Tamil
Nadu Act 24 of 1969).(81)The West Bengal Land Reforms (Amendment) Act, 1972 (West Bengal Act
XXII of1972).(82)The West Bengal Estates Acquisition (Amendment) Act, 1964 (West Bengal Act
XXII of 1964).(83)The West Bengal Estates Acquisition (Second Amendment) Act, 1973 (West
Bengal Act XXXIII of 1973).(84)The Bombay Tenancy and Agricultural Lands (Gujarat Amendment)
Act, 1972 (Gujarat Act 5 of 1973).(85)The Orissa Land Reforms (Amendment) Act, 1974 (Orissa Act
9 of 1974).(86)The Tripura Land Revenue and Land Reforms (Second Amendment) Act, 1974
(Tripura Act 7 of 1974).[The Constitution (Thirty-Fourth Amendment) Act, 1974, remains an
important milestone in the evolution of Indian democracy. The amendment brought about
significant changes to the constitutional framework of the country, particularly with respect to the
powers of the Parliament to amend the Constitution and the rights of the citizens. These proposals
were about the removal of exemptions, the reduction of the maximum on land holdings, and the
application of a ceiling based on the amount of land owned by a family. The Amendment added 20
more state laws (New entries 67 to 86) dealing with land reforms and ceilings to the Ninth Schedule
in order to make it clear that these laws cannot be challenged on the grounds that they conflict with
any sections of Part III of the Constitution’s Fundamental Rights clause.Also Refer ][In the Ninth
Schedule to the Constitution, after entry 86 and before the Explanation, the following entries shall
be inserted through Constitution (Thirty-Ninth Amendment) Act, 1975][Editorial comment-The
Constitution (Thirty-Ninth Amendment) Act, 1975, The amendment modified Schedule 9 of the
Indian constitution.Also Refer ](87)*** [Editorial comment-The Constitution (Forty-Fourth
Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to PropertyConstitution of India

because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer](88)The
Industries (Development and Regulation) Act, 1951 (Central Act 65 of 1951).(89)The Requisitioning
and Acquisition of Immovable Property Act, 1952 (Central Act30 of 1952).(90)The Mines and
Minerals (Regulations and Development) Act, 1957 (Central Act 67of 1957).(91)The Monopolies and
Restrictive Trade Practices Act, 1969 (Central Act 54 of1969).(92)*** [Editorial comment-The
Constitution (Forty-Fourth Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out
Article 31(1) has been taken out of Part III and made a separate Article 300A in Chapter IV of Part
XII. This amendment may have taken away the scope of speedy remedy under Article 32 for the
violation of Right to Property because it is no more a Fundamental Right. Making it a legal right
under the Constitution serves two purposes: Firstly, it gives emphasis to the value of socialism
included in the preamble and secondly, in doing so, it conformed to the doctrine of basic structure of
the Constitution. Also Refer](93)The Coking Coal Mines (Emergency Provisions) Act, 1971 (Central
Act 64 of 1971)(94)The Coking Coal Mines (Nationalisation) Act, 1972 (Central Act 36 of
1972)(95)The General Insurance Business (Nationalisation) Act, 1972 (Central Act 57
of1972)(96)The Indian Copper Corporation (Acquisition of Undertaking) Act, 1972 (Central Act 58
of 1972)(97)The Sick Textile Undertakings (Taking Over of Management) Act, 1972 (Central Act72 of
1972)(98)The Coal Mines (Taking Over of Management) Act, 1973 (Central Act 15 of 1973)(99)The
Coal Mines (Nationalisation) Act, 1973 (Central Act 26 of 1973)(100)The Foreign Exchange
Regulation Act, 1973 (Central Act 46 of 1973)(101)The Alcock Ashdown Company Limited
(Acquisition of Undertakings) Act, 1973(Central Act 56 of 1973)(102)The Coal Mines (Conservation
and Development) Act, 1974 (Central Act 28 of1974)(103)The Additional Emoluments (Compulsory
Deposit) Act, 1974 (Central Act 37 of1974)(104)The Conservation of Foreign Exchange and
Prevention of Smuggling Activities Act,1974 (Central Act 52 of 1974)(105)The Sick Textile
Undertakings (Nationalisation) Act, 1974 (Central Act 57 of1974)(106)The Maharashtra Agricultural
Lands (Ceiling on Holdings) (Amendment) Act, 1964(Maharashtra Act XVI of 1965)(107)The
Maharashtra Agricultural Lands (Ceiling on Holdings) (Amendment) Act, 1965(Maharashtra Act
XXXII of 1965)(108)The Maharashtra Agricultural Lands (Ceiling on Holdings) (Amendment) Act,
1968(Maharashtra Act XVI of 1968)(109)The Maharashtra Agricultural Lands (Ceiling on Holdings)
(Second Amendment) Act(110)The Maharashtra Agricultural Lands (Ceiling on Holdings)
Amendment) Act, 1969(Maharashtra Act XXXVII of 1969),(111)The Maharashtra Agricultural Lands
(Ceiling on Holdings) (Second Amendment) Act,1969 (Maharashtra Act XXXVIII of 1969)(112)The
Maharashtra Agricultural Lands (Ceiling on Holdings) (Amendment) Act, 1970(Maharashtra Act
XXVII of 1970(113)The Maharashtra Agricultural Lands (Ceiling on Holdings) (Amendment) Act,
1972(Maharashtra Act XIII of 1972)(114)The Maharashtra Agricultural Lands (Ceiling on Holdings)
(Amendment) Act, 1973(Maharashtra Act L of 1973)(115)The Orissa Land Reforms (Amendment)
Act, 1965 (Orissa Act 13 of 1965)(116)The Orissa Land Reforms (Amendment) Act, 1966 (Orissa Act
8 of 1967)(117)The Orissa Land Reforms (Amendment) Act, 1967 (Orissa Act 13 of 1967)(118)The
Orissa Land Reforms (Amendment) Act, 1969 (Orissa Act 13 of 1969)(119)The Orissa Land Reforms
(Amendment) Act, 1970 (Orissa Act 18 of 1970)(120)The Uttar Pradesh Imposition of Ceiling on
Land Holdings (Amendment) Act, 1972(Uttar Pradesh Act 18 of 1973)(121)The Uttar Pradesh
Imposition of Ceiling on Land Holdings (Amendment) Act, 1974(Uttar Pradesh Act 2 of
1975)(122)The Tripura Land Revenue and Land Reforms (Third Amendment) Act, 1975 (Tripura ActConstitution of India

3 of 1975)(123)The Dadra and Nagar Haveli Land Reforms Regulation, 1971 (3 of 1971)(124)The
Dadra and Nagar Haveli Land Reforms (Amendment) Regulation, 1973 (5 of1973)[In the Ninth
Schedule to the Constitution, after entry 124 and before the Explanation, the following entries shall
be inserted through Constitution (Forteith Amendment) Act, 1976][Editorial comment-The
Constitution (Fortieth Amendment) Act, 1976, Place land reform & other acts and amendments to
these act under Schedule 9 of the constitution. This amendment modified the 9th Schedule of the
Constitution. It empowered the Parliament to periodically specify the boundaries of India’s
continental shelf, territorial seas, exclusive economic zone (EEZ), and marine zones. Additionally,
64 more Central and state laws, most of which dealt with land reforms, were added to the 9th
Schedule."Also Refer](125)Section 66A and Chapter IVA of the Motor Vehicles Act, 1939 (Central
Act 4 of1939)(126)The Essential Commodities Act, 1955 (Central Act 10 of 1955)(127)The Smugglers
and Foreign Exchange Manipulators (Forfeiture of Property) Act,1976 (Central Act 13 of
1976)(128)The Bonded Labour System (Abolition) Act, 1976 (Central Act 19 of 1976)(129)The
Conservation of Foreign Exchange and Prevention of Smuggling Activities (Amendment) Act, 1976
(Central Act 20 of 1976)(130)*** [Editorial comment-The Constitution (Forty-Fourth
Amendment) Act, 1978, repealed Article 19 (1) (f) and also took out Article 31(1) has been taken out
of Part III and made a separate Article 300A in Chapter IV of Part XII. This amendment may have
taken away the scope of speedy remedy under Article 32 for the violation of Right to Property
because it is no more a Fundamental Right. Making it a legal right under the Constitution serves two
purposes: Firstly, it gives emphasis to the value of socialism included in the preamble and secondly,
in doing so, it conformed to the doctrine of basic structure of the Constitution. Also Refer](131)The
Levy Sugar Price Equalisation Fund Act, 1976 (Central Act 31 of 1976)(132)The Urban Land (Ceiling
and Regulation) Act, 1976 (Central Act 33 of 1976)(133)The Departmentalisation of Union Accounts
(Transfer of Personnel) Act, 1976(Central Act 59 of 1976)(134)The Assam Fixation of Ceiling on
Land Holdings Act, 1956 (Assam Act 1 of 1957)(135)The Bombay Tenancy and Agricultural Lands
(Vidarbha Region) Act, 1958 (Bombay Act XCIX of 1958)(136)The Gujarat Private Forests
(Acquisition) Act, 1972 (Gujarat Act 14 of 1973)(137)The Haryana Ceiling on Land Holdings
(Amendment) Act, 1976 (Haryana Act 17 of1976)(138)The Himachal Pradesh Tenancy and Land
Reforms Act, 1972 (Himachal Pradesh Act 8of 1974)(139)The Himachal Pradesh Village Common
Lands Vesting and Utilization Act, 1974(Himachal Pradesh Act 18 of 1974)(140)The Karnataka Land
Reforms (Second Amendment and Miscellaneous Provisions) Act,1974 (Karnataka Act 31 of
1974)(141)The Karnataka Land Reforms (Second Amendment) Act, 1976 (Karnataka Act 27
of1976)(142)The Kerala Prevention of Eviction Act, 1966 (Kerala Act 12 of 1966)(143)The
Thiruppuvaram Payment (Abolition) Act, 1969 (Kerala Act 19 of 1969)(144)The Sreepadam Lands
Enfranchisement Act, 1969 (Kerala Act 20 of 1969)(145)The Sree Pandaravaka Lands (Vesting and
Enfranchisement) Act, 1971 (Kerala Act20 of 1971)(146)The Kerala Private Forests (Vesting and
Assignment) Act, 1971 (Kerala Act 26 of1971)(147)The Kerala Agricultural Workers Act, 1974 (Kerala
Act 18 of 1974)(148)The Kerala Cashew Factories (Acquisition) Act, 1974 (Kerala Act 29 of
1974)(149)The Kerala Chitties Act, 1975 (Kerala Act 23 of 1975)(150)The Kerala Scheduled Tribes
(Restriction on Transfer of Lands and Restoration of Alienated Lands) Act, 1975 (Kerala Act 31 of
1975)(151)The Kerala Land Reforms (Amendment) Act, 1976 (Kerala Act 15 of 1976)(152)The Kanam
Tenancy Abolition Act, 1976 (Kerala Act 16 of 1976)(153)The Madhya Pradesh Ceiling on
Agricultural Holdings (Amendment) Act, 1974(Madhya Pradesh Act 20 of 1974)(154)The Madhya
Pradesh Ceiling on Agricultural Holdings (Amendment) Act, 1975(Madhya Pradesh Act 2 ofConstitution of India

1976)(155)The West Khandesh Meshwari Estates (Proprietary Rights Abolition, etc(156)The
Maharashtra Restoration of Lands to Scheduled Tribes Act, 1974 (Maharashtra Act XIV of
1975)(157)The Maharashtra Agricultural Lands (Lowering of Ceiling on Holdings) and Amendment)
Act, 1972 (Maharashtra Act XXI of 1975)(158)The Maharashtra Private Forests (Acquisition) Act,
1975 (Maharashtra Act XXIX of1975)(159)The Maharashtra Agricultural Lands (Lowering of Ceiling
on Holdings) and (Amendment) Act, 1975 (Maharashtra Act XLVII of 1975)(160)The Maharashtra
Agricultural Lands (Ceiling on Holdings) (Amendment) Act, 1975(Maharashtra Act II of
1976)(161)The Orissa Estates Abolition Act, 1951 (Orissa Act I of 1952)(162)The Rajasthan
Colonisation Act, 1954 (Rajasthan Act XXVII of 1954)(163)The Rajasthan Land Reforms and
Acquisition of Landowners' Estates Act, 1963(Rajasthan Act 11 of 1964)(164)The Rajasthan
Imposition of Ceiling on Agricultural Holdings (Amendment) Act,1976 (Rajasthan Act 8 of
1976)(165)The Rajasthan Tenancy (Amendment) Act, 1976 (Rajasthan Act 12 of 1976)(166)The
Tamil Nadu Land Reforms (Reduction of Ceiling on Land) Act, 1970 (Tamil NaduAct 17 of
1970)(167)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Amendment Act, 1971(Tamil
Nadu Act 41 of 1971)(168)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Amendment
Act, 1972(Tamil Nadu Act 10 of 1972)(169)The Tamil Nadu Land Reforms (Fixation of Ceiling on
Land) Second Amendment Act,1972 (Tamil Nadu Act 20 of 1972)(170)The Tamil Nadu Land
Reforms (Fixation of Ceiling on Land) Third Amendment Act,1972 (Tamil Nadu Act 37 of
1972)(171)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Fourth Amendment
Act,1972 (Tamil Nadu Act 39 of 1972)(172)The Tamil Nadu Land Reforms (Fixation of Ceiling on
Land) Sixth Amendment Act,1972, (Tamil Nadu Act 7 of 1974)(173)The Tamil Nadu Land Reforms
(Fixation of Ceiling on Land) Fifth Amendment Act,1972 (Tamil Nadu Act 10 of 1974)(174)The
Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Amendment Act, 1974(Tamil Nadu Act 15
of 1974)(175)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Third Amendment
Act,1974 (Tamil Nadu Act 30 of 1974)(176)The Tamil Nadu Land Reforms (Fixation of Ceiling on
Land) Second Amendment Act,1974 (Tamil Nadu Act 32 of 1974)(177)The Tamil Nadu Land
Reforms (Fixation of Ceiling on Land) Amendment Act, 1975(Tamil Nadu Act 11 of 1975)(178)The
Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Second Amendment Act,1975 (Tamil Nadu
Act 21 of 1975)(179)Amendments made to the Uttar Pradesh Zamindari Abolition and Land Reforms
Act,1950 (Uttar Pradesh Act I of 1951) by the Uttar Pradesh Land Laws (Amendment) Act, 1971
(Uttar Pradesh Act 21 of 1971) and the Uttar Pradesh Land Laws (Amendment) Act, 1974 (Uttar
Pradesh Act 34 of 1974)(180)The Uttar Pradesh Imposition of Ceiling on Land Holdings
(Amendment) Act, 1976(Uttar Pradesh Act 20 of 1976)(181)The West Bengal Land Reforms (Second
Amendment) Act, 1972 (West Bengal Act XXVIII of 1972)(182)The West Bengal Restoration of
Alienated Land Act, 1973 (West Bengal Act XXIII of 1973)(183)The West Bengal Land Reforms
(Amendment) Act, 1974 (West Bengal Act XXXIII of1974)(184)The West Bengal Land Reforms
(Amendment) Act, 1975 (West Bengal Act XXIII of1975)(185)The West Bengal Land Reforms
(Amendment) Act, 1976 (West Bengal Act XII of1976)(186)The Delhi Land Holdings (Ceiling)
Amendment Act, 1976 (Central Act 15 of 1976)(187)The Goa, Daman and Diu Mundkars (Protection
from Eviction) Act, 1975 (Goa, Daman and Diu Act I of 1976)(188)The Pondicherry Land Reforms
(Fixation of Ceiling on Land) Act, 1973(Pondicherry Act 9 of 1974)[In the Ninth Schedule to the
Constitution, after entry 188 and before the Explanation, the following entries shall be inserted
Constitution (Forty-Seventh Amendment) Act, 1984](189)The Assam (Temporarily Settled Areas)
Tenancy Act, 1971 (Assam Act XXIII of1971)(190)The Assam (Temporarily Settled Areas) TenancyConstitution of India

(Amendment) Act, 1974 (Assam Act XVIII of 1974)(191)The Bihar Land Reforms (Fixation of Ceiling
Area and Acquisition of Surplus Land) (Amendment) Amending Act, 1974 (Bihar Act 31 of
1975)(192)The Bihar Land Reforms (Fixation of Ceiling Area and Acquisition of Surplus Land)
(Amendment) Act, 1976 (Bihar Act 22 of 1976)(193)The Bihar Land Reforms (Fixation of Ceiling
Area and Acquisition of Surplus Land) (Amendment) Act, 1978 (Bihar Act VII of 1978)(194)The
Land Acquisition (Bihar Amendment) Act, 1979 (Bihar Act 2 of 1980)(195)The Haryana Ceiling on
Land Holdings (Amendment) Act, 1977 (Haryana Act 14 of1977)(196)The Tamil Nadu Land Reforms
(Fixation of Ceiling on Land) Amendment Act, 1978(Tamil Nadu Act 25 of 1978)(197)The Tamil
Nadu Land Reforms (Fixation of Ceiling on Land) Amendment Act, 1979(Tamil Nadu Act 11 of
1979)(198)The Uttar Pradesh Zamindari Abolition Laws (Amendment) Act, 1978 (Uttar Pradesh Act
15 of 1978)(199)The West Bengal Restoration of Alienated Land (Amendment) Act, 1978 (West
Bengal Act XXIV of 1978)(200)The West Bengal Restoration of Alienated Land (Amendment) Act,
1980 (West Bengal Act LVI of 1980)(201)The Goa, Daman and Diu Agricultural Tenancy Act, 1964
(Goa, Daman and Diu Act 7of 1964)(202)The Goa, Daman and Diu Agricultural Tenancy (Fifth
Amendment) Act, 1976 (Goa, Daman and Diu Act 17 of 1976)[The Constitution (Forty-Seventh
Amendment) Act, 1984, amended the Ninth Schedule to the Constitution, and added 14 legislations
relating to land reforms, enacted by the States of Assam, Bihar, Haryana, Tamil Nadu, Uttar
Pradesh and West Bengal and the union territory of Goa, Daman and Diu with a view to provide that
the enactments shall not be deemed to be void on the ground that they are inconsistent with any of
the provisions of Part III of the Constitution relating to Fundamental Rights.Also Refer](203)The
Andhra Pradesh Scheduled Areas Land Transfer Regulation, 1959 (Andhra Pradesh Regulation I of
1959)(204)The Andhra Pradesh Scheduled Areas Laws (Extension and Amendment)
Regulation,1963 (Andhra Pradesh Regulation 2 of 1963)(205)The Andhra Pradesh Scheduled Areas
Land Transfer (Amendment) Regulation, 1970(Andhra Pradesh Regulation 1 of 1970)(206)The
Andhra Pradesh Scheduled Areas Land Transfer (Amendment) Regulation, 1971(Andhra Pradesh
Regulation 1 of 1971)(207)The Andhra Pradesh Scheduled Areas Land Transfer (Amendment)
Regulation, 1978(Andhra Pradesh Regulation 1 of 1978)(208)The Bihar Tenancy Act, 1885 (Bihar
Act 8 of 1885)(209)The Chhota Nagpur Tenancy Act, 1908 (Bengal Act 6 of 1908) (Chapter
VIII-sections 46, 47, 48, 48A and 49; Chapter X-sections 71, 71A and 71B; and Chapter
XVIII-sections 240, 241 and 242)(210)The Santhal Parganas Tenancy (Supplementary Provisions)
Act, 1949 (Bihar Act 14of 1949) except section 53(211)The Bihar Scheduled Areas Regulation, 1969
(Bihar Regulation 1 of 1969)(212)The Bihar Land Reforms (Fixation of Ceiling Area and Acquisition
of Surplus Land) (Amendment) Act, 1982 (Bihar Act 55 of 1982)(213)The Gujarat Devasthan Inams
Abolition Act, 1969 (Gujarat Act 16 of 1969)(214)The Gujarat Tenancy Laws (Amendment) Act, 1976
(Gujarat Act 37 of 1976)(215)The Gujarat Agricultural Lands Ceiling (Amendment) Act, 1976
(President's Act 43of 1976)(216)The Gujarat Devasthan Inams Abolition (Amendment) Act, 1977
(Gujarat Act 27 of1977)(217)The Gujarat Tenancy Laws (Amendment) Act, 1977 (Gujarat Act 30 of
1977)(218)The Bombay Land Revenue (Gujarat Second Amendment) Act, 1980 (Gujarat Act 37
of1980)(219)The Bombay Land Revenue Code and Land Tenure Abolition Laws (Gujarat
Amendment) Act, 1982 (Gujarat Act 8 of 1982)(220)The Himachal Pradesh Transfer of Land
(Regulation) Act, 1968 (Himachal Pradesh Act 15 of 1969)(221)The Himachal Pradesh Transfer of
Land (Regulation) (Amendment) Act, 1986(Himachal Pradesh Act 16 of 1986)(222)The Karnataka
Scheduled Castes and Scheduled Tribes (Prohibition of Transfer of certain Lands) Act, 1978
(Karnataka Act 2 of 1979)(223)The Kerala Land Reforms (Amendment) Act, 1978 (Kerala Act 13 ofConstitution of India

1978)(224)The Kerala Land Reforms (Amendment) Act, 1981 (Kerala Act 19 of 1981)(225)The
Madhya Pradesh Land Revenue Code (Third Amendment) Act, 1976 (Madhya Pradesh Act 61 of
1976)(226)The Madhya Pradesh Land Revenue Code (Amendment) Act, 1980 (Madhya Pradesh
Act15 of 1980)(227)The Madhya Pradesh Akrishik Jot Uchachatam Seema Adhiniyam, 1981
(Madhya Pradesh Act 11 of 1981)(228)The Madhya Pradesh Ceiling on Agricultural Holdings
(Second Amendment) Act, 1976 (Madhya Pradesh Act I of 1984)(229)The Madhya Pradesh Ceiling
on Agricultural Holdings (Amendment) Act, 1984 (Madhya Pradesh Act 14 of 1984)(230)The
Madhya Pradesh Ceiling on Agricultural Holdings (Amendment) Act, 1989 (Madhya Pradesh Act 8
of 1989)(231)The Maharashtra Land Revenue Code, 1966 (Maharashtra Act 41 of 1966), sections36,
36A and 36B(232)The Maharashtra Land Revenue Code and the Maharashtra Restoration of Lands
to Scheduled Tribes (Second Amendment) Act, 1976 (Maharashtra Act 30 of 1977)(233)The
Maharashtra Abolition of Subsisting Proprietary Rights to Mines and Mineralsin certain Lands Act,
1985 (Maharashtra Act 16 of 1985)(234)The Orissa Scheduled Areas Transfer of Immovable
Property (By Scheduled Tribes) Regulation, 1956 (Orissa Regulation 2 of 1956)(235)The Orissa Land
Reforms (Second Amendment) Act, 1975 (Orissa Act 29 of 1976)(236)The Orissa Land Reforms
(Amendment) Act, 1976 (Orissa Act 30 of 1976)(237)The Orissa Land Reforms (Second
Amendment) Act, 1976 (Orissa Act 44 of 1976)(238)The Rajasthan Colonisation (Amendment) Act,
1984 (Rajasthan Act 12 of 1984)(239)The Rajasthan Tenancy (Amendment) Act, 1984 (Rajasthan
Act 13 of 1984)(240)The Rajasthan Tenancy (Amendment) Act, 1987 (Rajasthan Act 21 of
1987)(241)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Second Amendment
Act,1979 (Tamil Nadu Act 8 of 1980)(242)The Tamil Nadu Land Reforms (Fixation of Ceiling on
Land) Amendment Act, 1980 (Tamil Nadu Act 21 of 1980)(243)The Tamil Nadu Land Reforms
(Fixation of Ceiling on Land) Amendment Act, 1981 (Tamil Nadu Act 59 of 1981)(244)The Tamil
Nadu Land Reforms (Fixation of Ceiling on Land) Second Amendment Act,1983 (Tamil Nadu Act 2
of 1984)(245)The Uttar Pradesh Land Laws (Amendment) Act, 1982 (Uttar Pradesh Act 20
of1982)(246)The West Bengal Land Reforms (Amendment) Act, 1965 (West Bengal Act 18 of
1965)(247)The West Bengal Land Reforms (Amendment) Act(248)The West Bengal Land Reforms
(Second Amendment) Act, 1969 (West Bengal Act 23 of1969)(249)The West Bengal Estate
Acquisition (Amendment) Act, 1977 (West Bengal Act 36 of1977)(250)The West Bengal Land
Holding Revenue Act, 1979 (West Bengal Act 44 of 1979)(251)The West Bengal Land Reforms
(Amendment) Act, 1980 (West Bengal Act 41 of 1980)(252)The West Bengal Land Holding Revenue
(Amendment) Act, 1981 (West Bengal Act 33of 1981)(253)The Calcutta Thikka Tenancy (Acquisition
and Regulation) Act, 1981 (West Bengal Act 37 of 1981)(254)The West Bengal Land Holding
Revenue (Amendment) Act, 1982 (West Bengal Act 23of 1982)(255)The Calcutta Thikka Tenancy
(Acquisition and Regulation) (Amendment) Act, 1984(West Bengal Act 41 of 1984)(256)The Mahe
Land Reforms Act, 1968 (Pondicherry Act 1 of 1968)(257)The Mahe Land Reforms (Amendment)
Act, 1980 (Pondicherry Act 1 of 1981)[Editorial comment-The Constitution (Sixty-sixth
Amendment) Act, 1990, was enacted in 1990 by amending the 9th schedule, which was added by the
1st Amendment and established by Article 31B. According to the 9th schedule, all the Central and
State laws in the list cannot face legal challenges. As per this amendment of the Indian constitution
Act, 55 land reforms were included in the 9th schedule by various States to protect them from
judicial scrutiny. Considering the fact that amendment to Acts currently in the Ninth Schedule is
also not exempt from the judicial challenge, some modifying Acts are also recommended to be
incorporated into the Ninth Schedule. By including them in the 9th Schedule to the Constitution, theConstitution of India

Act shields 55 State acts relating to land reforms and caps on agricultural land holdings that were
passed by the States of Bihar, Himachal Pradesh, Gujarat, Kerala, Maharashtra, Andhra Pradesh,
Orissa, Madhya Pradesh, Rajasthan, Karnataka, Uttar Pradesh, West Bengal, Tamil Nadu and
administration of the Union Territory of Puducherry from legal challenge.Also Refer](257A)The
Tamil Nadu Backward Classes, Scheduled Castes and Scheduled Tribes (Reservation of Seats in
Educational Institutions and of appointments or posts in the Services under the State) Act 1993
(Tamil Nadu Act 45 of 1994)[Editorial comment -The Constitution (Seventy-sixth Amendment)
Act, 1994, allows the continuation of the 69% reservation in Tamil Nadu by adding the relevant
Tamil Nadu Act to the Constitution’s 9th Schedule.This constitutional amendment modifies
schedule 9 of the Indian Constitution. It deals with reserving seats in educational institutions and
appointments or posts in state-run services for members of backward classes, scheduled castes, and
scheduled tribes. On November 16, 1992, the Supreme Court of India established a ceiling of 50% on
the total percentage of reservations permitted under Article 16(4) of the Constitution.Also
Refer](258)The Bihar Privileged persons Homestead Tenancy Act, 1947 (Bihar Act 4 of
1948)(259)The Bihar Consolidation of Holdings and Prevention of Fragmentation Act, 1956 (Bihar
Act 22 of 1956)(260)The Bihar Consolidation of Holdings and Prevention of Fragmentation
(Amendment) Act, 1970 (Bihar Act 7 of 1970)(261)The Bihar Privileged Persons Homestead
Tenancy (Amendment) Act, 1970 (Bihar Act9 of 1970)(262)The Bihar Consolidation of Holdings and
Prevention of Fragmentation (Amendment) Act, 1973 (Bihar Act 27 of 1975)(263)The Bihar
Consolidation of Holdings and Prevention of Fragmentation (Amendment) Act, 1981 (Bihar Act 35
of 1982)(264)The Bihar Land Reforms (Fixation of Ceiling Area and Acquisition of Surplus Land)
(Amendment) Act, 1987 (Bihar Act 21 of 1987)(265)The Bihar Privileged Persons Homestead
Tenancy (Amendment) Act, 1989 (Bihar Act11 of 1989)(266)The Bihar Land Reforms (Amendment)
Act, 1989 (Bihar Act 11 of 1990)(267)The Karnataka Scheduled Castes and Scheduled Tribes
(Prohibition of Transfer of Certain Lands) (Amendment) Act, 1984 (Karnataka Act 3 of
1984)(268)The Kerala land Reforms (Amendment) Act, 1989 (Kerala Act 16 of 1989)(269)The
Kerala land Reforms (Second Amendment) Act, 1989 (Kerala Act 2 of 1990)(270)The Orissa Land
Reforms (Amendment Act, 1989 (Orissa Act 9 of 1990)(271)The Rajasthan Tenancy (Amendment)
Act, 1979 (Rajasthan Act 16 of 1979)(272)The Rajasthan Colonisation (Amendment) Act, 1987
(Rajasthan Act 2 of 1987)(273)The Rajasthan Colonisation (Amendment) Act, 1989 (Rajasthan Act
12 of 1989)(274)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land) Amendment Act, 1983
(Tamil Nadu Act 3 of 1984)(275)The Tamil Nadu Land Reforms (Fixation of Ceiling on Land)
Amendment Act, 1986 (Tamil Nadu Act 57 of 1986)(276)The Tamil Nadu Land Reforms (Fixation of
Ceiling on Land) Second Amendment Act,1987 (Tamil Nadu Act 4 of 1988)(277)The Tamil Nadu
Land Reforms (Fixation of Ceiling on Land) Amendment Act, 1989 (Tamil Nadu Act 30 of
1989)(278)The West Bengal Land Reforms (Amendment) Act, 1981 (West Bengal Act 50 of
1981)(279)The West Bengal Land Reforms (Amendment) Act, 1986 (West Bengal Act 5 of
1986)(280)The West Bengal Land Reforms (Second Amendment) Act, 1986 (West Bengal Act 19
of1986)(281)The West Bengal Land Reforms (Third Amendment) Act, 1981 (West Bengal Act 35
of1986)(282)The West Bengal Land Reforms (Amendment) Act, 1989 (West Bengal Act 23 of
1989)(283)The West Bengal Land Reforms (Amendment) Act, 1990 (West Bengal Act 24 of
1990)(284)The West Bengal Land Reforms (Tribunal Act, 1991 (West Bengal Act 12 of
1991)[Editorial Comment-The Constitution (Seventy-eighth Amendment) Act, 1995, is legislation
aimed at amending the incorporation of land reform laws in states like Bihar, Orissa, Tamil Nadu,Constitution of India

West Bengal, Rajasthan, and Kerala in the ninth schedule of the Constitution of India. This
amendment gives immunity to legal challenges being faced in the court of law, meaning that laws
present in the 9th schedule of the Indian Constitution cannot be challenged in court. The
Constitution (1st Amendment) Act of 1951 added 13 statutes that could not be challenged in court
even if they violated individuals' basic rights. Later revisions added 284 laws to the Indian
Constitution's ninth schedule, which cannot be contested.Also Refer]Explanation.- Any acquisition
made under the Rajasthan Tenancy Act, 1955 (Rajasthan Act III of1955), in contravention of the
second proviso to clause (1) of article 31 A shall, to the extent of the contravention, be void.
Schedule 10
Articles 102(2) and 191(2)[Editorial comment-The Constitution (Thirty-Fifth Amendment) Act,
1974, deals with the appeal raised by the Sikkim government to include them as an associate state in
India. In simple words, the people of Sikkim wanted to fill the gap between them and India and thus
demanded the special status of an associate state. The Amendment observed the insertion of the
tenth Schedule (10th schedule) in the constitution.This amendment inculcated among the people a
sense of belongingness and equal rights as any other citizen.Important Verdicts- State of Sikkim vs
Surendra Prasad SharmaAlso Refer]PROVISIONS AS TO DISQUALIFICATION ON GROUND OF
DEFECTION
1. Interpretation
In this Schedule, unless the context otherwise requires,-(a)'House' means either House of
Parliament or the Legislative Assembly or, as the case may be, either House of the Legislature of a
State;(b)'legislature party', in relation to a member of a House belonging to any political party in
accordance with the provisions of paragraph 2 , or paragraph 4, means the group consisting of all
the members of that House for the time being belonging to that political party in accordance with
the said provisions;(c)'original political party', in relation to a member of a House, means the
political party to which he belongs for the purposes of sub-paragraph (1) of paragraph
2;(d)'paragraph' means a paragraph of this Schedule.
2. Disqualification on ground of defection
(1)Subject to the provisions of paragraphs 4 and 5, a member of a House belonging to any political
party shall be disqualified for being a member of the House-(a)if he has voluntarily gives up his
membership of such political party; or(b)if he votes or abstains from voting in such House contrary
to any direction issued by the political party to which he belongs or by any person or authority
authorised by it in this behalf, without obtaining, in either case, the prior permission of such
political party, person or authority and such voting or abstention has not been condoned by such
political party, person or authority within fifteen days from the date of such voting or
abstention.Explanation.-For the purposes of this sub-paragraph,-(a)an elected member of a House
shall be deemed to belong to the political party, if any, by which he was set up as a candidate for
election as such member;(b)a nominated member of a House shall,-(i)where he is a member of any
political party on the date of his nomination as such member, be deemed to belong to such politicalConstitution of India

party;(ii)in any other case, be deemed to belong to the political party of which he becomes, or, as the
case may be, first becomes, a member before the expiry of six months from the date on which he
takes his seat after complying with the requirements of article 99 or, as the case may be, article
188.(2)An elected member of a House who has been elected as such otherwise than as a candidate
set up by any political party shall be disqualified for being a member of the House if he joins any
political party after such election.(3)A nominated member of a House shall be disqualified for being
a member of the House if he joins any political party after the expiry of six months from the date on
which he takes his seat after complying with the requirements of article 99 or, as the case may be,
article 188.(4)Notwithstanding anything contained in the foregoing provisions of this paragraph, a
person who, on the commencement of the Constitution (Fifty-second Amendment) Act, 1985, is a
member of a House (whether elected or nominated as such) shall,-(i)where he was a member of
political party immediately before such commencement, be deemed, for the purposes of
sub-paragraph (1) of this paragraph, to have been elected as a member of such House as a candidate
set up by such political party;(ii)in any other case, be deemed to be an elected member of the House
who has been elected as such otherwise than as a candidate set up by any political party for the
purposes of sub-paragraph (2) of this paragraph or, as the case may be, deemed to be a nominated
member of the House for the purposes of sub-paragraph (3) of this paragraph.[Paragraph 3 omitted
by the Constitution (Ninety-first Amendment) Act, 2003, s. 5 (w.e.f. 1-1-2004).]
4. Disqualification on ground of defection not to apply in case of merger
(1)A member of a House shall not be disqualified under sub-paragraph (1) of paragraph 2 where his
original political party merges with another political party and he claims that he and any other
members of his original political party-(a)have become members of such other political party or, as
the case may be, of a new political party formed by such merger; or(b)have not accepted the merger
and opted to function as a separate group,and from the time of such merger, such other political
party or new political party or group, as the case may be, shall be deemed to be the political party to
which he belongs for the purposes of sub-paragraph (1) of paragraph 2 and to be his original
political party for the purposes of this sub-paragraph.(2)For the purposes of sub-paragraph (1) of
this paragraph, the merger of the original political party of a member of a House shall be deemed to
have taken place if, and only if, not less than two-thirds of the members of the legislature party
concerned have agreed to such merger.
5. Exemption
Notwithstanding anything contained in this Schedule, a person who has been elected to the office of
the Speaker or the Deputy Speaker of the House of the People or the Deputy Chairman of the
Council of States or the Chairman or the Deputy Chairman of the Legislative Council of a State or
the Speaker or the Deputy Speaker of the Legislative Assembly of a State, shall not be disqualified
under this Schedule,-(a)if he, by reason of his election to such office, voluntarily gives up the
membership of the political party to which he belonged immediately before such election and does
not, so long as he continues to hold such office thereafter, rejoin that political party or become a
member of another political party; or(b)if he, having given up by reason of his election to such office
his membership of the political party to which he belonged immediately before such election, rejoinsConstitution of India

such political party after he ceases to hold such office.
6. Decision on questions as to disqualification on ground of defection
(1)If any question arises as to whether a member of a House has become subject to disqualification
under this Schedule, the question shall be referred for the decision of the Chairman or, as the case
may be, the Speaker of such House and his decision shall be final:Provided that where the question
which has arisen is as to whether the Chairman or the Speaker of a House has become subject to
such disqualification, the question shall be referred for the decision of such member of the House as
the House may elect in this behalf and his decision shall be final.(2)All proceedings under
sub-paragraph (1) of this paragraph in relation to any question as to disqualification of a member of
a House under this Schedule shall be deemed to be proceedings in Parliament within the meaning of
article 122 or, as the case may be, proceedings in the Legislature of a State within the meaning of
article 212.
7. Bar of jurisdiction of courts
Notwithstanding anything in this Constitution, no court shall have any jurisdiction in respect of any
matter connected with the disqualification of a member of a House under this Schedule.** The
Supreme Court decision in Kihoto Hollohon v. Zachilhu, (1992) 1 SCC 309 has declared paragraph 7
of the Tenth Schedule invalid.
8. Rules
(1)Subject to the provisions of sub-paragraph (2) of this paragraph, the Chairman or the Speaker of
a House may make rules for giving effect to the provisions of this Schedule, and in particular, and
without prejudice to the generality of the foregoing, such rules may provide for-(a)the maintenance
of registers or other records as to the political parties if any, to which different members of the
House belong;(b)the report which the leader of a legislature party in relation to a member of a
House shall furnish with regard to any condonation of the nature referred to in clause (b) of
sub-paragraph (1) of paragraph 2 in respect of such member, the time within which and the
authority to whom such report shall be furnished;(c)the reports which a political party shall furnish
with regard to admission to such political party of any members of the House and the officer of the
House to whom such reports shall be furnished; and(d)the procedure for deciding any question
referred to in sub-paragraph (1) of paragraph 6 including the procedure for any inquiry which may
be made for the purpose of deciding such question.(2)The rules made by the Chairman or the
Speaker of a House under sub-paragraph (1) of this paragraph shall be laid as soon as may be after
they are made before the House for a total period of thirty days which may be comprised in one
session or in two or more successive sessions and shall take effect upon the expiry of the said period
of thirty days unless they are sooner approved with or without modifications or disapproved by the
House and where they are so approved, they shall take effect on such approval in the form in which
they were laid or in such modified form, as the case may be, and where they are so disapproved, they
shall be of no effect.(3)The Chairman or the Speaker of a House may, without prejudice to the
provisions of article 105 or, as the case may be, article 194, and to any other power which he mayConstitution of India

have under this Constitution direct that any wilful contravention by any person of the rules made
under this paragraph may be dealt with in the same manner as a breach of privilege of the
House.[Editorial Comment- The Constitution (Thirty-Sixth Amendment) Act, 1975,Also,
eliminated the 10th schedule "Also Refer]
Schedule 11
Article 243G.(1)Agriculture, including agricultural extension.(2)Land improvement,
implementation of land reforms, land consolidation and soil conservation.(3)Minor irrigation, water
management and watershed development.(4)Animal husbandry, dairying and
poultry.(5)Fisheries.(6)Social forestry and farm forestry.(7)Minor forest produce.(8)Small scale
industries, including food processing industries.(9)Khadi, village and collage industries.(10)Rural
housing.(11)Drinking water.(12)Fuel and fodder.(13)Roads, culverts, bridges, ferries, waterways and
other means of communication.(14)Rural electrification, including distribution of
electricity.(15)Non-conventional energy sources.(16)Poverty alleviation programme.(17)Education,
including primary and secondary schools.(18)Technical training and vocational education.(19)Adult
and non-formal education.(20)Libraries.(21)Cultural activities.(22)Markets and fairs.(23)Health
and sanitation, including hospitals, primary health centres and dispensaries.(24)Family
welfare.(25)Women and child development.(26)Social welfare, including welfare of the handicapped
and mentally retarded.(27)Welfare of the weaker sections, and in particular, of the Scheduled Castes
and the Scheduled Tribes.(28)Public distribution system.(29)Maintenance of community assets.
Schedule 12
Article 243W.(1)Urban planning including town planning.(2)Regulation of land-use and
construction of buildings.(3)Planning for economic and social development.(4)Roads and
bridges.(5)Water supply for domestic, industrial and, commercial purposes.(6)Public health,
sanitation conservancy and solid waste management.(7)Fire services.(8)Urban forestry protection of
the environment and promotion of ecologicalaspects.(9)Safeguarding the interests of weaker
sections of society, including thehandicapped and mentally retarded.(10)Slum improvement and
upgradation.(11)Urban poverty alleviation.(12)Provision of urban amenities and facilities such as
parks, gardens,play-grounds.(13)Promotion of cultural, educational and aesthetic
aspects.(14)Burials and burial grounds; cremations, cremation grounds and
electriccrematoriums.(15)Cattle ponds; prevention of cruelty to animals.(16)Vital statistics including
registration of births and deaths.(17)Public amenities including street lighting, parking lots, bus
stops and public conveniences.(18)Regulation of slaughter houses and tanneries.Constitution of India

