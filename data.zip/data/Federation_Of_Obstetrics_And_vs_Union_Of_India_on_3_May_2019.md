Federation Of Obstetrics And ... vs Union Of India on 3 May,
2019
Equivalent citations: AIR 2019 SUPREME COURT 2214, 2019 (6) SCC 283,
2019 (5) ABR 97, 2019 (3) AKR 210, (2019) 2 CRILR(RAJ) 561, (2019) 2
CRIMES 211, (2019) 4 ANDHLD 210, (2019) 4 MAD LJ 448, (2019) 7 SCALE
314, 2019 CRILR(SC MAH GUJ) 561, AIR 2019 SC (CIV) 1797, AIRONLINE 2019
SC 227
Author: Arun Mishra
Bench: Vineet Saran, Arun Mishra
                                                        1
                                                                             REPORTABLE
                                 IN THE SUPREME COURT OF INDIA
                                    CIVIL ORIGINAL JURISDICTION
                               WRIT PETITION (CIVIL) NO.129 OF 2017
         Federation of Obstetrics and
         Gynecological Societies of India (FOGSI)                            ..Petitioner
                                                   Versus
         Union of India and others                                           ..Respondents
                                             JUDGMENT
Arun Mishra, J.
1. The instant writ petition has been filed by the Federation of Obstetrics and Gynaecological
Societies of India (FOGSI) (hereinafter referred to as ‘the Society’) highlighting the issues and
problems affecting the practice of obstetricians and gynaecologists across the country under the
Pre−conception and Pre−natal Diagnostic Techniques (Prohibition of Sex Selection) Act, 1994
(hereinafter referred to as ‘the Act’) and challenging the constitutional validity of Sections 23(1) and
23(2) of the Act and seeking direction in the nature of certiorari/mandamus for decriminalising
anomalies in paperwork/record keeping/clerical errors in regard of the provisions of the Act for
being violative of Articles 14, 19(1)(g) and 21 of the Constitution of India. The Society is the apexFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

body of obstetricians and gynaecologists of the country and is concerned for the welfare of its
members.
2. The case set up on behalf of the petitioner−Society is that the Act was enacted with the objective
to prohibit pre−natal diagnostic techniques for determination of sex of the foetus leading to female
foeticide. But unfortunately, its implementation is more in letter and less in spirit. The problem of
sex determination and gender selection is a serious issue and is one of the biggest social problems
faced by our society. Despite enactment of the Act and subsequent amendments, the Child Sex Ratio
has not shown significant improvement, hence, putting sufficient concern and questions on the
proper implementation of the Act. It is contended that equating clerical errors on the same footing
with the actual offence of sex determination shows the inherent weakness in the language of the Act.
3. It is further contended that the Appropriate Authority appointed under the Act conducts
inspections and raids in various districts and cities and even if there are mere anomalies in the
paperwork, it seals the sonography machine and files a criminal case under the Act. As a result,
doctors who do not conduct sex determination and gender selection are being targeted on the basis
of aforesaid anomalies. The inherent infirmity in the Act as it stands currently in its present form
amounting to treating unequals as equals. The Act has failed to distinguish between criminal
offences and the anomalies in paperwork like incomplete ‘F’−Forms, clerical mistakes such as
writing NA or incomplete address, no mentioning of the date, objectionable pictures of Radha
Krishna in sonography room, incomplete filling of Form ‘F’, indication for sonography not written,
faded notice board and not legible, striking out details in the Form ‘F’ etc., thereby charging the
members of the petitioner− Society for heinous crime of female foeticide and sex determination and
that too merely for unintentional mistakes in record keeping. The Act provides same punishment for
the contravention of any provision of the Act, thus equating the anomalies in paperwork and the
offence of sex determination and gender selection on the same pedestal. The sealing of machines
directly deprives a woman in that vicinity of a critical medical aid and thereby putting the lives of
the women in danger. The unreasonable sealing of the sonography machine not only impacts the
welfare of the women as such, but it also amounts to undue harassment and mental torture of the
members of the petitioner−Society.
4. It is further contended that the ambiguous wording of Section 23(1) of the Act has resulted in
grave miscarriage of justice and the members of the petitioner−Society have faced grave hardships
and have undergone criminal prosecution for act, which cannot be equated with the acts of sex
determination.
5. It is averred that even the smallest anomaly in paperwork which is in fact an inadvertent and
unintentional error has made the obstetricians and gynaecologists vulnerable to the prosecution by
the Authorities all over the country.
6. Section 23(2) of the Act empowers the State Medical Council to suspend the registration of any
doctor indefinitely, who is reported by the Appropriate Authority for necessary action, during the
pendency of trial. The petitioner−Society submitted that Section 23(2) of the Act is ultra vires the
Constitution as it assumes the guilt of the alleged accused even before his/her conviction by aFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

competent court and hence violates the fundamental right guaranteed under Article 21 of the
Constitution.
7. It is contended that presumption of innocence is a cardinal principle of rule of law for which
petitioner−Society has placed reliance on Article 14(2) of the International Covenant on Civil and
Political Rights, 1966, which states that everyone charged with a criminal offence shall have the
right to be presumed innocent until proved guilty according to law. Article 14(2) of the International
Covenant on Civil and Political Rights, 1966 reads thus:
“Article 14
1. ***
2. Everyone charged with a criminal offence shall have the right to be presumed
innocent until proved guilty according to law.”
8. It is contended that the Act fails to distinguish between the cases of presence and absence of mens
rea during the commission of minor clerical mistakes. Mens rea is not be presumed at the time of
taking cognizance and must be established as held by this Court in Arun Bhandari v. State of U.P.,
(2013) 2 SCC 801.
9. The petitioner−Society has further placed reliance on the decisions rendered by this Court in
cases of penal statues to give proper effect to the scheme of the Act concerned and to balance various
interests involved by striking down/reading down/ diluting the concerned penal provisions.
10. It is further contended that suspension of the medical licence at the stage of framing of charges is
highly improper and harsh, which results in loss of livelihood of not only the members of the
Society, but also his family as well as the dependents, who are deprived of financial security and
well−being. The vague and ambiguous wordings of Section 23(1) renders Section 25 totally
redundant.
11. It is further submitted that Form−F as it stands today does not serve the purpose for which it was
made and there is no substantive evidence which proves that errors in Form−F have any direct
nexus with the offence of sex selection and determination.
12. Respondent Nos.1 to 4 has refuted the claims of the petitioner−Society altogether. It is
contended that the Act is a social welfare legislation with a social objective to prevent elimination of
girls before birth and it is not a general law providing any general right to practice medicine. The
specific choice of legislature cannot be called arbitrary and is in no way ultra vires or violative of the
Constitution. The Act is a Central legislation; however, its implementation lies primarily with the
States, who are required to enforce the law through the statutory bodies in the State, constituted
under the Act. The Act empowers the Central Government to regulate the use of pre−natal
diagnostic techniques. The proliferation of the technology is resulting in a catastrophe in the form of
female foeticide leading to severe imbalance in child sex ratio and sex ratio at birth. The Centre isFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

duty bound to intervene in such a case to uphold the welfare of the society, especially of the women
and the children. The Act was enacted with a purpose to ban the use of sex selection techniques
before or after conception; prevent the misuse of pre−natal diagnostic techniques for sex selection
abortions and to regulate such techniques. It is mandatory to maintain proper record in respect of
use of ultrasound machines under the Act. For effective implementation of the Act, a hierarchy of
Appropriate Authority at State, District and Sub− District level is created.
13. It is contended that ultrasonography test on a pregnant woman is considered to be an important
part of a pre−natal diagnostic test and the person conducting such test has to maintain a complete
record thereof in the manner prescribed in the rules and a deficiency or inaccuracy in maintaining
such records would amount to an offence. Chapter VII of the Act prescribes offences and penalties
and there is no gradation of offences under the Act as it does not classify offences. Equating the
clerical errors on same footing with the actual offence of sex determination is in compliance with the
provisions of the Act and rules thereunder. The Act does not differentiate among the violations
committed by doctors and provides for punishment for all violations under the Act. The Act
prescribes punishment in furtherance of its object and purposes which is to prevent detection of
female foetus which is in the larger public interest, hence Section 23 of the Act does not violate
Articles 14 and 21. It is further averred that right to practice a profession under Article 19(1)(g) of
the Constitution is not an absolute right.
14. It is contended that petitioner−Society in the garb of social cause is trying to mislead this Court
and a criminal act cannot be protected under the umbrella of the Article 19. The offences under the
Act are per se criminal and no exemption can be sought for criminal violations in the guise of public
interest or right to freedom.
15. It is contended that the Appropriate Authority conducts inspection pursuant to the directions
issued by this Court in Centre for Enquiry into Health & Allied Themes (CEHAT) v. Union of India,
(2003) 8 SCC 398, wherein it was directed to constitute National Inspection and Monitoring
Committee for conducting inspections. As the sex determination is hatched in secrecy and
committed in privacy and as both the parties are hand in glove with each other, therefore it becomes
difficult to detect the commission of the offence, hence traps are usually laid or raids are conducted
by the inspecting authorities and sometimes non− maintenance of records or incomplete records
may provide substantial evidence towards the commission of offence. It is further submitted that the
Act specifically provides for the record keeping under Rule 9 of the Pre−conception and Pre−natal
Diagnostic Techniques (Prohibition of Sex Selection) Rules, 1996 (hereinafter referred to as ‘the
Rules’) and any deficiency or inaccuracy in record keeping amounts to violation of Sections 5 and 6
of the Act.
16. The respondents contend that record keeping is important for proper implementation of the Act
and the stringent provisions with regard to maintenance of records and punishment for non−
compliance cannot be equated or considered as infirmity of the Act. If it is exempted from the
mandatory requirement, the probably involvement in sex determination and sex selection in the
guise of use of diagnostic techniques would continue unabated.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

17. It is also contended that the purpose of Form ‘F’ is to maintain personal and medical record of
the patient visiting the Pre−Natal Diagnostic Clinic to avail the services and confirmation regarding
the consent of the patient/pregnant woman with regard to the prohibition of communication of the
sex of foetus so as to avoid abuse of the technology. Section 4(3) of the Act requires every Genetic
Counselling Centre/Genetic Clinic to fill Form ‘F’. The filling of Form ‘F’ is commensurate with the
objects of the Act which is to regulate the technology and to avoid the abuse of the technology for the
purpose of sex determination. It gives the insight into the reasons for conducting ultrasonography
and incomplete Form ‘F’ raises presumption of doubt against the medical practitioner and in the
absence of Form ‘F’, the Appropriate Authority will have no means to supervise the usage of the
ultrasonography machine and shall not be able to regulate the use of the technique. The non−
maintenance of records is not merely a technical or procedural lapse in the context of sex
determination, it is the most significant piece of evidence for identifying the accused. It is further
contended that clerical errors in Form ‘F’ fall under Section 4 of the Act and any deficiency or
inaccuracy found therein shall amount to contravention of the provisions of Section 5 or 6 of the Act
unless contrary is proved by the person conducting such ultrasonography.
18. It is contended that every aggrieved person, who suffered from any procedural irregularity, can
avail legal remedy as provided under Section 21 of the Act and Rule 19 of the Rules.
19. The respondents have placed reliance on decision rendered by High Court of Gujarat in Suo
Motu v. State of Gujarat, (2009) 1 GLR 64, which dealt with the issue of proper maintenance of
records and to the decision rendered by High Court of Rajasthan in S.K. Gupta v. Union of India,
wherein it was observed that female infants have also right to live. There is right of still born child to
be looked after properly during pregnancy. Once a child is conceived, it has to be treated with
dignity. Such right cannot be denied and practice of female foeticide/infanticide is prevailing at
large which is illegal and unconstitutional.
20. The respondents have also drawn our attention to the provisions of Regulation 1.3 of the Indian
Medical Council (Professional Conduct, Etiquette and Ethics) Regulations, 2002; Regulation 6.2 of
Pharmacy Practice Regulation, 2015; and Transplantation of Human Organs and Tissues Act, 1994,
which contains the provisions with respect to maintenance of proper records.
21. It is submitted that Section 23 and Section 25 are complimentary to each other, not
contradictory as contended by the petitioner−Society. It is lastly contended that no case for striking
down the proviso to Section 4(3) is made out.
22. Shri Soli J. Sorabjee and Shri Shyam Divan, learned senior counsel urged that present is the
classic example of unequals being treated as equals. Due to inherent infirmity in the Act,
whereunder members of the petitioner−Society are treated unequally as mere clerical errors has
resulted in breach of personal liberties. The Act fails to classify offence of actual sex determination
vis−à−vis clerical error in maintenance of record. There is no gradation of offence.
23. The presumption of innocence ought not to be disposed away with under the Act. The same is
part of human rights. Presumption of innocence continues until conviction. The provisions ofFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

suspension under Section 23(2) is draconian. Any deficiency or inaccuracy in maintenance of
records ought not to amount to contravention under Section 5 or Section 6 and the proviso to
Section 4(3) accordingly be diluted. It may be clarified that contravention of proviso to Section 4(3),
Section 29 and Rule 9 or technical lapses attracting minor penalty should not attract Section 27 of
the Act. The provision of Section 23(2) be read down so that suspension should not fall under
Section 23(2) in the case of clerical mistakes or inadvertent technical errors/lapses. Issuance of
notice be made mandatory under Section 20. No action be taken on technical grounds such as
writing short forms, writing ‘NA’ instead of “not applicable”, writing initials of the doctors etc. while
filing up Form ‘F’. The competent authority should consider each case on merits with the aid of legal
advisor. Denial of renewal of registration of Centre of a running unit on the ground of pendency of
criminal trial is illegal and harsh. There should not be seizure of any equipment etc. as ultrasound
machine are necessary for human use. It is not appropriate to keep such utilitarian instruments
sealed.
24. Ms. Pinki Anand, Additional Solicitor General appearing on behalf of respondents countering
the submission raised on behalf of petitioner−Society contended that there is alarming decline in the
child sex ratio in India and in several districts it is worse as the ratio per thousand is below 800. She
has also relied upon the purpose and legislative history of enactment of the Act including
amendments made thereunder and the Rules. It has been made mandatory to maintain proper
records in respect of use of ultrasound machines. The Act provides for prohibition of sex
selection/determination as well as regulation of pre−natal diagnostic techniques. The rate of
conviction is extremely poor, despite 24 years of the existence of the Act, it is only 586 out of 4202
cases registered, resulting into action against 138 medical licenses. Emphasis has been laid by this
Court in several decisions on proper maintenance of records. Section 23 is the central provision in
the scheme of the Act. Form ‘F’ is very important as it gives the details and the reasons for
conducting ultrasonography and incomplete Form ‘F’ raises the presumption of doubt against the
medical practitioner. Section 23 and Form ‘F’ are inter−linked, thus, the provisions cannot be
diluted. She further contended that the non−maintenance of records is not merely procedural lapse,
it is key evidence given the collusive nature of the crime. There exist effective and efficacious
remedies to the instances cited by the petitioner−Society. She also relied upon a case study on
record keeping as an implementation tool of Prabhakar Hospital in Panipat. The Act enjoys a
presumption of constitutionality and no case of violation of fundamental rights has been made out
by the petitioner− Society. The Act is regulatory and is for the wholesome purpose same advances
the intendment of other provisions applicable to medical fraternity, which requires rigorous
maintenance of records. Considering the wide prevalence of violence against women and children in
different forms, the Legislature has enacted several Acts in order to ensure gender justice and to
take care of cry of female foetus. No case for striking down, dilution or issuance of any guidelines is
made out by the petitioner−Society.
25. It was urged on behalf of intervenor that Section 28 of the Act makes it clear that no court shall
take cognizance of an offence unless on a complaint made by Appropriate Authority. The
composition of Appropriate Authority is provided under Section 17(3)(a), which is a High−Powered
Body. The Supervisory Board shall review the activities of the Appropriate Authorities as provided
under Section 16A(1)(ii). The Supervisory Committee consists of large body. Thus, there areFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

adequate safeguards to maintain check and balance provided within the Act.
26. Before we dilate upon various aspects, we take note of provisions of the Act. The Act was
introduced by Parliament with the following Statement of Objects and Reasons:
“STATEMENT OF OBJECTS AND REASONS It is proposed to prohibit pre−natal
diagnostic techniques for determination of sex of the foetus leading to female
foeticide. Such abuse of techniques is discriminatory against the female sex and
affects the dignity and status of women. A legislation is required to regulate the use of
such techniques and to provide deterrent punishment to stop such inhuman act.
The Bill, inter alia, provides for:—
(i) prohibition of the misuse of pre−natal diagnostic techniques for determination of
sex of foetus, leading to female foeticide;
(ii) prohibition of advertisement of pre−natal diagnostic techniques for detection or
determination of sex;
(iii) permission and regulation of the use of pre−natal diagnostic techniques for the
purpose of detection of specific genetic abnormalities or disorders;
(iv) permitting the use of such techniques only under certain conditions by the
registered institutions; and
(v) punishment for violation of the provisions of the proposed legislation.
2. The Bills seeks to achieve the above objectives.” The concern of the Legislature was that the
female child is not welcomed with open arms in most of Indian families and the diagnostic
technique is being used to commit female foeticide.
27. The female foeticide is not only the concern of India, but of various countries. The United
Nations General Assembly had adopted Resolution No.52/106 on 11.2.1998 expressing concern
about pre−natal sex selection, female infanticide and female genital mutilation. The said Resolution
also urged all States to enact and enforce legislation protecting girls from all forms of violence,
including female infanticide and prenatal sex selection. The United Nations Fourth World
Conference on Women in September, 1995 adopted the Beijing Declaration and Platform for Action.
Beijing Declaration and Platform for Action identified “violence against women” to “include forced
sterilization and forced abortion, coercive/forced use of contraceptives, female infanticide and pre−
natal sex selection”. It further urged Governments to “enact and enforce legislation against the
perpetrators of practices and acts of violence against women, such as female genital mutilation,
female infanticide, prenatal sex selection and dowry−related violence”. Further urged Governments
to “Eliminate all forms of discrimination against the girl child and the root causes of son preference,
which result in harmful and unethical practices such as pre−natal sex selection and femaleFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

infanticide; this is often compounded by the increasing use of technologies to determine foetal sex,
resulting in abortion of female foetuses”.
28. Beijing Declaration and Platform for Action was adopted at the 16th Plenary Meeting of the
Fourth World Conference on Women held on 15.9.1995 at Beijing. The relevant extract relating to
violence against women and actions to be taken is reproduced hereunder:
“115. Acts of violence against women also include forced sterilization and forced
abortion, coercive/forced use of contraceptives, female infanticide and prenatal sex
selection.
Strategic objective L.2. Eliminate negative cultural attitudes and practices against
girls Actions to be taken
276. By Governments:
(a) Encourage and support, as appropriate, non−governmental organizations and
community−based organizations in their efforts to promote changes in negative
attitudes and practices towards girls;
(b)**
(c)**
(d) Take steps so that tradition and religion and their expressions are not a basis for
discrimination against girls.
277. By Governments and, as appropriate, international and non−governmental organizations:
(a)**
(b)**
(c) Eliminate all forms of discrimination against the girl child and the root causes of
son preference, which result in harmful and unethical practices such as prenatal sex
selection and female infanticide; this is often compounded by the increasing use of
technologies to determine foetal sex, resulting in abortion of female foetuses”
29. The 1994 Programme of Action of the International Conference on Population
and Development (ICPD) resolved to eliminate all forms of discrimination against the
girl child and the root causes of son preference, which result in harmful and unethical
practices regarding female infanticide and prenatal sex selection, and also to increase
public awareness of the value of the girl child. Further urged Governments to take
necessary measures to prevent infanticide, prenatal sex selection, trafficking of girlFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

children and forcing of girls in prostitution and pornography. The International
Conference on Population and Development adopted the Programme of Action of the
International Conference on Population and Development and passed the resolution
at the 14th Plenary meeting held on 13.9.1994. The relevant portion of the aforesaid
resolution is extracted hereunder:
“4.15. Since in all societies discrimination on the basis of sex often starts at the
earliest stages of life, greater equality for the girl child is a necessary first step in
ensuring that women realize their full potential and become equal partners in
development. In a number of countries, the practice of prenatal sex selection, higher
rates of mortality among very young girls, and lower rates of school enrolment for
girls as compared with boys, suggest that "son preference" is curtailing the access of
girl children to food, education and health care. This is often compounded by the
increasing use of technologies to determine foetal sex, resulting in abortion of female
foetuses. Investments made in the girl child's health, nutrition and education, from
infancy through adolescence, are critical.
Objectives 4.16. The objectives are:
(a) To eliminate all forms of discrimination against the girl child and the root causes
of son preference, which results in harmful and unethical practices regarding female
infanticide and prenatal sex selection;
(b) To increase public awareness of the value of the girl child, and concurrently, to
strengthen the girl child's self−image, self−esteem and status;
(c) To improve the welfare of the girl child, especially in regard to health, nutrition
and education.
4.23. Governments are urged to take the necessary measures to prevent infanticide, prenatal sex
selection, trafficking in girl children and use of girls in prostitution and pornography.”
30. The Resolution 56/139 adopted by the U.N. General Assembly, on 26.2.2002 expressed deep
concern about discrimination against the girl child, including practices such as female infanticide,
incest, early marriage, prenatal sex selection etc. The Resolution also urged States to enact and
enforce legislation to protect girls from all forms of violence, including female infanticide and
prenatal sex selection, female genital mutilation, rape, domestic violence, incest, sexual abuse,
sexual exploitation, child prostitution and child pornography, and to develop age−appropriate safe
and confidential programmes and medical, social and psychological support services to assist girls
who are subjected to violence. The General Assembly of United Nations adopted the following
resolution no.56/139 on 26.2.2002:
“Deeply concerned about discrimination against the girl child and the violation of the
rights of the girl child, which often result in less access for girls to education,Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

nutrition and physical and mental health care and in girls enjoying fewer of the
rights, opportunities and benefits of childhood and adolescence than boys and often
being subjected to various forms of cultural, social, sexual and economic exploitation
and to violence and harmful practices, such as female infanticide, incest, early
marriage, prenatal sex selection and female genital mutilation.
10. Also urges all States to enact and enforce legislation to protect girls from all forms
of violence, including female infanticide and prenatal sex selection, female genital
mutilation, rape, domestic violence, incest, sexual abuse, sexual exploitation, child
prostitution and child pornography, and to develop age− appropriate safe and
confidential programmes and medical, social and psychological support services to
assist girls who are subjected to violence.”
31. Resolution 70/138, adopted by the U.N. General Assembly on 17.12.2015, also
expressed its concern at discrimination against girl child including pre−natal sex
selection, and urged states “to enact and enforce legislation to protect girls from all
forms of violence, discrimination, exploitation and harmful practices in all settings,
including female infanticide and prenatal sex selection”.
32. The General Assembly of United Nations in the 80 th Plenary Meeting adopted
resolution no.70/138 dated 17.12.2015 concerning the girl child, the relevant portion
of the said resolution reads thus:
“…Deeply concerned also about discrimination against the girl child and the violation
of the rights of the girl child, including girls with disabilities, which often result in
less access for girls to education, and to quality education, nutrition, including food
allocation, and physical and mental health−care services, in girls enjoying fewer of
the rights, opportunities and benefits of childhood and adolescence than boys, and in
leaving them more vulnerable than boys to the consequences of unprotected and
premature sexual relations and often being subjected to various forms of cultural,
social, sexual and economic exploitation and violence, abuse, rape, incest, honour−
related crimes and harmful practices, such as female infanticide, child, early and
forced marriage, prenatal sex selection and female genital mutilation.
20.Urges all States to enact and enforce legislation to protect girls from all forms of
violence, discrimination, exploitation and harmful practices in all settings, including
female infanticide and prenatal sex selection, female genital mutilation, rape,
domestic violence, incest, sexual abuse, sexual exploitation, child prostitution and
child pornography, trafficking and forced migration, forced labour and child, early
and forced marriage, and to develop age−appropriate, safe, confidential and
disability− accessible programmes and medical, social and psychological support
services to assist girls who are subjected to violence and discrimination.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

29.Calls upon Governments, civil society, including the media, and non−
governmental organizations to promote human rights education and full respect for
and the enjoyment of the human rights of the girl child, inter alia, through the
translation, production and dissemination of age−appropriate and gender− sensitive
information material on those rights to all sectors of society, in particular to children.
30.Requests the Secretary−General, as Chair of the United Nations System Chief
Executives Board for Coordination, to ensure that all organizations and bodies of the
United Nations system, individually and collectively, in particular the United Nations
Children’s Fund, the United Nations Educational, Scientific and Cultural
Organization, the World Food Programme, the United Nations Population Fund, the
United Nations Entity for Gender Equality and the Empowerment of Women (UN−
Women), the World Health Organization, the Joint United Nations Programme on
HIV/AIDS, the United Nations Development Programme, the Office of the United
Nations High Commissioner for Refugees and the International Labour Organization,
take into account the rights and the particular needs of the girl child in country
programmes of cooperation in accordance with national priorities, including through
the United Nations Development Assistance Framework.”
33. The General Assembly of United Nations adopted the following resolution
no.52/106 on 12.12.1997 keeping in view the discrimination against the girl child and
violation of her rights:
“Deeply concerned about discrimination against the girl child and the violation of the
rights of the girl child, which often result in less access for girls to education,
nutrition, physical and mental health care and in girls enjoying fewer of the rights,
opportunities and benefits of childhood and adolescence than boys and often being
subjected to various forms of cultural, social, sexual and economic exploitation and to
violence and harmful practices such as incest, early marriage, female infanticide,
prenatal sex selection and female genital mutilation.
3. Also urges all States to enact and enforce legislation protecting girls from all forms
of violence, including female infanticide and prenatal sex selection, female genital
mutilation, incest, sexual abuse, sexual exploitation, child prostitution and child
pornography, and to develop age−appropriate safe and confidential programmes and
medical, social and psychological support services to assist girls who are subjected to
violence.”
34. The concern world over as to female foeticide and infanticide is writ large from
aforesaid resolution. It is worthwhile to quote the statistics of World Factbook, 2016
of the Central Intelligence Agency of the United States of America on female
foeticide/infanticide across the world, which is to the following effect:
            Rank     Name of the country            Sex ratio at birthFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

            1.    Liechtenstein                  126 males/100 females
            2.    China                          115 males/100 female
            3.    Armenia                        113 males/100 females
            4.    India                          112 males/100 females
            5.    Azerbaijan                     111 males/100 females
            5.    Viet Nam                       111 males/100 females
            6.    Albania                        110 males/100 females
            7.    Georgia                        108 males/100 females
            8.    South Korea                    107 males/100 females
            8.    Tunisia                        107 males/100 females
            9.    Nigeria                        106 males/100 females
           10.    Pakistan                       105 males/100 females
           11.    Nepal                          104 males/100 females
35. There is sharp decline in the sex ratio in India. In the year 1901 where 972
females as against 1000 males were recorded.
In 1961, it was recorded as 941; in 1971 it was 930; in 1981 it was reported 934; in 1991 it was 927; in
2001 it was 933 and in 2011 it was 943. On behalf of respondent−Union of India following State wise
data has been furnished:
“Sex Ratio (Female per 1000 Male) at Birth by residence, India and bigger States,
SRS 2012−14 to 2014−16 S.N. India and 2012− 2013− Change 2013− 2014− Change
India 906 900 −6 900 898 −2
1. Andhra 919 918 −1 918 913 −5 Pradesh
2. Assam 918 900 −18 900 896 −4
3. Bihar 907 916 9 916 908 −8
4. Chhattisgarh 973 961 −12 961 963 2
5. Delhi 876 869 −7 869 857 −12
6. Gujarat 907 854 −53 854 848 −6
7. Haryana 866 831 −35 831 832 1
8. Himachal 938 924 −14 924 917 −7
9. Jammu & 899 899 0 899 906 7 KashmirFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

10. Jharkhand 910 902 −8 902 918 16
11. Karnataka 950 939 −11 939 935 −4
12. Kerala 974 967 −7 967 959 −8
13. Madhya 927 919 −8 919 922 3 Pradesh
14. Maharashtra 896 878 −18 878 876 −2
15. Orissa 953 950 −3 950 948 −2
16. Punjab 870 889 19 889 893 4
17. Rajasthan 893 861 −32 861 857 −4
18. Tamil Nadu 921 911 −10 911 915 4
19. Telangana N.A. N.A. N.A. N.A. 901 N.A.
20. Uttar 869 879 10 879 882 3 Pradesh
21. Uttarakhand 871 844 −27 844 850 6
22. West Bengal 952 951 −1 951 937 −14 The aforesaid table indicates decline in 18
States and maximum decline of 53 points was recorded in Gujarat followed by
Haryana by 35 points and Rajasthan by 32 points. Sex ratio of the States in 2014−
2016 indicates decline in 13 States. The maximum decline of 14 points was recorded
in West Bengal followed by Delhi recorded at 12 points. In a publication of United
Nations (UNFPA), it was published that 0.46 million girls were missing at birth on an
average annually during the period 2001−2012 as a result of sex−selective abortions.
The fall in sex ratios does not only have an impact on the demography of the nation,
but it also gives rise to violent practices such as trafficking of women and bride
buying. The Act was conceived out of the urgency for the prohibition of sex selection
practices and prohibition of the advertisement of the pre−natal diagnostic techniques
for detection/determination of sex. It came into force in the year 1996. It was
amended in 2003 following a PIL which was filed in 2000 to improve regulation of
technology capable of sex selection. By way of amendment in the Act, the name of the
Act has been changed to Pre−Conception and Pre−natal Diagnostic Techniques
(Prohibition of Sex Selection) Act, 1994.
The main purpose of the Act is to ban the use of sex selection and misuse of pre−natal diagnostic
technique for sex selective abortions and to regulate such techniques. The amendments have
brought techniques of pre−conception sex selection within the ambit of the Act and have alsoFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

brought use of ultrasound machines under its umbrella. It has further provided for constitution of
Central and State Level Supervisory Board. More stringent punishments have been provided. The
Appropriate Authorities have been given powers of civil court for search, seizure and sealing. The
maintenance of record has been made mandatory in respect of use of ultrasound machines. It has
also regulated the sale of ultrasound machines only to the registered bodies. The Act provides for
prohibition of sex selection/determination and regulate pre−natal diagnostic technology. Several
important amendments were notified in the Rules. Rule 11(2) was amended in 2011 to provide for
confiscation of the unregistered machines and Section 23(1) prescribes imprisonment upto three
years and with fine upto ten thousand rupees against the unregistered clinic/facilities and on any
subsequent conviction, the imprisonment may extend to five years and with fine which may extend
to fifty thousand rupees and Section 23(3) prescribes imprisonment upto three years of
imprisonment and with fine upto fifty thousand rupees against the unregistered clinic/facilities for
the first offence and for any subsequent offence, the imprisonment may extend to five years and
with fine which may extend to one lakh rupees. Rule 3A(3) has been inserted in 2012 to restrict the
registration of medical practitioners qualified under the Act to conduct ultrasonography in
maximum of two ultrasound facilities within a district only. Number of hours during which the
Registered Medical Practitioner would be present in each clinic would be specified clearly to the
Appropriate Authority. The amendment made to Rule 13 in 2012 requires every Genetic Counselling
Centres, Genetic Laboratory, Genetic Clinic, Ultrasound Clinic and Imaging Centre to intimate every
change of employee, place, address and equipment installed to the Appropriate Authority 30 days in
advance of the expected date of such change and seeks issuance of a new certificate with the changes
duly incorporated. Rules for six months’ training in ultrasound for the MBBS doctors have been
notified vide GSR 14(E) dated 10.1.2014. The Rules include the training curriculum, criteria for
accreditation of institutions which will impart training and procedure for Competency Based
Evaluation Test for such trained medical practitioners. Revised Form ‘F’ has been notified vide GSR
77 (E) date 4.2.2014. The revised format is more simplified as the details of invasive and non−
invasive diagnostic procedures have been separated and made more simplified.
36. There are only 586 convictions out of 4202 cases registered even after 24 years of existence. It
reflects the challenges being faced by the Appropriate Authority in implementing this social
legislation. Below is the chart showing State wise status of implementation of the Act as on
September 2018 submitted on behalf of respondents:
State wise status of implementation of the PC&PNDT Act as on SEPTEMBER, 2018
S.No. States/UTs No. of No. of No. of Convictions* Medical Number registered
ongoing Machines licenses of cases bodies Court/ seized/ cancelled/ decided/ Police
sealed suspended closed cases Pradesh
2. Arunachal 97 0 − 0 0 − Pradesh
4. Bihar 2761 132 38 6 0 32
5. Chhattisgar 700 14 0 0 0 7 hFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

6. Goa 174 1 1 0 0
7. Gujarat 5994 235 2 18 7 99
8. Haryana 2144 313 562 85 21 157
9. Himachal 464 0 4 1 0 3 Pradesh
10. Jammu & 493 3 13 1 0 − Kashmir
11. Jharkhand 761 32 0 2 0 −
12. Karnataka 4711 49 58 38 0 41
13. Kerala 1737 0 − 0 0 −
14. Madhya 1723 50 17 4 3 9 Pradesh
15. Maharashtra 8672 587 462 99 79 358
16. Manipur 130 0 − 0 0 −
17. Meghalaya 50 0 − 0 0 −
18. Mizoram 61 0 − 0 0 −
19. Nagaland 49 0 0 0 0 −
20. Odisha 1001 66 − 5 0 4
21. Punjab 1603 147 38 31 1 93
22. Rajasthan 3039 701 506 149 21 368
23. Sikkim 27 0 0 0 0 −
24. Tamil Nadu 6717 123 − 109 2 83
25. Telangana 3547 24 108 3 0 25
26. Tripura 48 1 − 0 0 −
27. Uttarakhand 647 47 12 4 0 16Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

28. Uttar 6031 139 39 20 1 10 Pradesh
29. West Bengal 3238 24 29 0 0 1
30. A & N Island 17 0 − 0 0 −
31. Chandigarh 183 1 − 0 0 2
32. D & N Haveli 16 0 0 0 0 −
33. Daman & 10 0 0 0 0 − Diu
34. Delhi 1584 104 170 10 3 57
35. Lakshadeep 9 0 − 0 0 −
36. Puducherry 109 1 − 0 0 − TOTAL 62596 2825 2081 586 138 1377 Note:
*Convictions and Medical licenses data up to June 2018
37. In the light of aforesaid, we examine the submission raised on behalf of petitioner
based upon clerical errors. It was urged that the license of members of noble
charitable profession are being suspended on account of clerical errors/mistakes in
paper work under the Act and the Rules made thereunder. On account of clerical
errors in filling up of the forms, it would not be appropriate to inflict the punishment.
In case of actual offence of sex determination, the provisions of the Act may govern
the field.
As submission appears to be attractive and it requires deep scrutiny whether it is a clerical error in
filling up of the forms or is foundation of substantial breach of the provisions of the Act and Rules
framed thereunder. It was urged that Section 23 of the Act treats unequals as equals and there is
infirmity in the Act as the clerical error in filling up of the Form ‘F’ cannot be treated at par with
actual offence of sex determination. There is no gradation of the offence under the Act. Learned
senior counsel has placed reliance on Uttar Pradesh Power Corporation Ltd. vs. Ayodhya Prasad
Mishra, (2008) 10 SCC 139, wherein this Court held that unequals cannot be treated equally.
Treating of unequals as equals would as well offend the doctrine of equality enshrined in Articles 14
and 16 of the Constitution. The same is extracted hereunder:
“40. It is well settled that equals cannot be treated unequally. But it is equally well
settled that unequals cannot be treated equally. Treating of unequals as equals would
as well offend the doctrine of equality enshrined in Articles 14 and 16 of the
Constitution. The High Court was, therefore, right in holding that Executive
Engineers placed in Category I must get priority and preference for promotion to the
post of Superintendent Engineer over Executive Engineers found in Category II.”Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

38. It is contended that merely clerical error cannot be equated with offences as
mentioned in Sections 5 and 6 of the Act. The main purpose and the object of the Act
is being misused and more than 60 per cent cases registered under the Act, are
pertaining to non−maintenance of record.
39. In order to appreciate whether it is clerical omission or otherwise, we have to
delve on the provisions of the Act what is mandated thereunder. Section 3 provides
for regulation of Genetic Counselling Centres, Genetic Laboratories and Genetic
Clinics, Section 3A deals with prohibition of sex−selection and Section 3B deals with
prohibition on sale of ultrasound machine, etc. to persons, laboratories, clinics, etc.
not registered under the Act. The same are extracted hereunder:
“3. Regulation of Genetic Counselling Centres, Genetic Laboratories and Genetic
Clinics.— On and from the commencement of this Act, — (1) no Genetic Counselling
Centre, Genetic Laboratory or Genetic Clinic unless registered under this Act, shall
conduct or associate with, or help in, conducting activities relating to pre−natal
diagnostic techniques;
(2) no Genetic Counselling Centre or Genetic Laboratory or Genetic Clinic shall
employ or cause to be employed or take services of any person whether on honorary
basis or on payment who does not possess the qualifications as may be prescribed;
(3) no medical geneticist, gynaecologist, paediatrician, registered medical
practitioner or any other person shall conduct or cause to be conducted or aid in
conducting by himself or through any other person, any pre−natal diagnostic
techniques at a place other than a place registered under this Act.
3A. Prohibition of sex−selection.— No person, including a specialist or a team of specialists in the
field of infertility, shall conduct or cause to be conducted or aid in conducting by himself or by any
other person, sex selection on a woman or a man or on both or on any tissue, embryo, conceptus,
fluid or gametes derived from either or both of them.
3B. Prohibition on sale of ultrasound machine, etc., to persons, laboratories, clinics, etc., not
registered under the Act.— No person shall sell any ultrasound machine or imaging machine or
scanner or any other equipment capable of detecting sex of foetus to any Genetic Counselling
Centre, Genetic Laboratory, Genetic Clinic or any other person not registered under the Act.”
(emphasis supplied)
40. Section 4 deals with regulation of pre−natal diagnostic techniques, which is extracted
hereunder:
“4. Regulation of pre−natal diagnostic techniques. — On and from the
commencement of this Act,— (1) no place including a registered Genetic Counselling
Centre or Genetic Laboratory or Genetic Clinic shall be used or caused to be used byFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

any person for conducting pre−natal diagnostic techniques except for the purposes
specified in clause (2) and after satisfying any of the conditions specified in clause
(3);
(2) no pre−natal diagnostic techniques shall be conducted except for the purposes of
detection of any of the following abnormalities, namely: —
(i) chromosomal abnormalities;
(ii) genetic metabolic diseases;
(iii) haemoglobinopathies;
(iv) sex−linked genetic diseases;
(v) congenital anomalies;
(vi) any other abnormalities or diseases as may be specified by the Central
Supervisory Board;
(3) no pre−natal diagnostic techniques shall be used or conducted unless the person
qualified to do so is satisfied for reasons to be recorded in writing that any of the
following conditions are fulfilled, namely:—
(i) age of the pregnant woman is above thirty−five years;
(ii) the pregnant woman has undergone of two or more spontaneous abortions or
foetal loss;
(iii) the pregnant woman had been exposed to potentially teratogenic agents such as
drugs, radiation, infection or chemicals;
(iv) the pregnant woman or her spouse has a family history of mental retardation or
physical deformities such as, spasticity or any other genetic disease;
(v) any other condition as may be specified by the Board;
Provided that the person conducting ultrasonography on a pregnant woman shall keep complete
record thereof in clinic in such manner, as may be prescribed, and any deficiency or inaccuracy
found therein shall amount to contravention of the provisions of section 5 or section 6 unless
contrary is proved by the person conducting such ultrasonography; (4) no person including a
relative or husband of the pregnant woman shall seek or encourage the conduct of any pre−natal
diagnostic techniques on her except for the purposes specified in clause (2).Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(5) no person including a relative or husband of a woman shall seek or encourage the conduct of any
sex−selection technique on her or him or both.” (emphasis supplied) There is prohibition created
under Section 4(1) to use any registered Genetic Counselling Centre or Genetic Laboratory or
Genetic Clinic for conducting pre−natal diagnostic techniques except for the purposes specified in
sub−section (2) of Section 4. Wrong expression has been used as clause (2) in the Act, where it
should be sub−section (2). Be that as it may. Section 4(2) provides for conducting of pre−natal
diagnostic techniques for the purpose of detection of abnormalities.
Section 4(3) provides that no pre−natal diagnostic techniques shall be used unless the person
qualified to do so is satisfied for the reasons to be recorded in writing that prescribed conditions are
fulfilled such as age of the pregnant women is above thirty−five years; the pregnant woman has
undergone two or more spontaneous abortions or foetal loss; she had been exposed to potentially
teratogenic agents such as drugs, radiation, infection or chemicals; the pregnant woman or her
spouse has a family history of mental retardation or physical deformities as prescribed therein; or
any other condition as may be specified by the Board.
In the absence of aforesaid fulfilment of the aforesaid conditions provided in Section 4(3) and in the
absence of abnormality as provided in Section 4(2), no such test can be performed. Proviso to
Section 4(3) makes it mandatory that person conducting ultrasonography on a pregnant woman
shall keep complete record as may be prescribed and any deficiency or inaccuracy found therein
shall amount to contravention of the provisions of Section 5 or Section 6 unless contrary is proved
by the person conducting such ultrasonography. Section 5 provides for written consent of pregnant
woman and prohibition of communicating the sex of foetus, whereas Section 6 provides that
determination of sex is prohibited. Sections 5 and 6 are extracted below:
“5. Written consent of pregnant woman and prohibition of communicating the sex of
foetus.— (1) No person referred to in clause (2) of section 3 shall conduct the pre−
natal diagnostic procedures unless—
(a) he has explained all known side and after effects of such procedures to the
pregnant woman concerned;
(b) he has obtained in the prescribed form her written consent to undergo such
procedures in the language which she understands; and
(c) a copy of her written consent obtained under clause (b) is given to the pregnant
woman.
(2) No person including the person conducting pre−natal diagnostic procedures shall
communicate to the pregnant woman concerned or her relatives or any other person
the sex of the foetus by words, signs, or in any other manner.
6. Determination of sex prohibited.— On and from the commencement of this Act, —Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(a) no Genetic Counselling Centre or Genetic Laboratory or Genetic Clinic shall conduct or cause to
be conducted in its Centre, Laboratory or Clinic, pre−natal diagnostic techniques including
ultrasonography, for the purpose of determining the sex of a foetus;
(b) no person shall conduct or cause to be conducted any pre− natal diagnostic techniques including
ultrasonography for the purpose of determining the sex of a foetus.
(c) no person shall, by whatever means, cause or allow to be caused selection of sex before or after
conception.” (emphasis supplied)
41. Independently, specific provisions have been made barring use of technology i.e., pre−natal
diagnostic techniques for determination of sex of foetus under Section 6 of the Act. The use of
technology can only be for the purposes as provided in Section 4(2) and with the pre−conditions as
provided in Section 4(3).
42. As a safeguard to arbitrary use of powers by concerned authorities the constitution of State
Supervisory Board and Union Territory Supervisory Board is provided in Section 16A, which is a
large body consisting of various representatives. It has to create public awareness, review the
activities of the Appropriate Authorities and to monitor the implementation of the provisions of the
Act and to send the periodical report. Relevant portion of Section 16A of the Act reads thus:
“16A. Constitution of State Supervisory Board and Union territory Supervisory
Board.— (1) Each State and Union territory having Legislature shall constitute a
Board to be known as the State Supervisory Board or the Union territory Supervisory
Board, as the case may be, which shall have the following functions:—
(i) to create public awareness against the practice of pre− conception sex selection
and pre−natal determination of sex of foetus leading to female foeticide in the State;
(ii) to review the activities of the Appropriate Authorities functioning in the State and
recommend appropriate action against them;
(iii) to monitor the implementation of provisions of the Act and the rules and make
suitable recommendations relating thereto, to the Board;
(iv) to send such consolidated reports as may be prescribed in respect of the various
activities undertaken in the State under the Act to the Board and the Central
Government; and
(v) any other functions as may be prescribed under the Act.
(2) The State Board shall consist of,—Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(a) the Minister in charge of Health and Family Welfare in the State, who shall be the
Chairperson, ex−officio;
(b) Secretary in charge of the Department of Health and Family Welfare who shall be
the Vice−Chairperson, ex− officio;
(c) Secretaries or Commissioners in charge of Departments of Women and Child
Development, Social Welfare, Law and Indian System of Medicines and
Homoeopathy, ex−officio, or their representatives;
(d) Director of Health and Family Welfare or Indian System of Medicines and
Homoeopathy of the State Government, ex−officio;
(e) three women members of Legislative Assembly or Legislative Council;
(f) ten members to be appointed by the State Government out of which two each shall
be from the following categories:
—
(i) eminent social scientists and legal experts;
(ii) eminent women activists from non−governmental organizations or otherwise;
(iii) eminent gynaecologists and obstetricians or experts of stri−roga or prasuti−
tantra;
(iv) eminent paediatricians or medical geneticists;
(v) eminent radiologists or sonologists;
(g) an officer not below the rank of Joint Director in charge of Family Welfare, who
shall be the Member Secretary, ex−officio.
(3) The State Board shall meet at least once in four months.”
43. The constitution of Appropriate Authority and Advisory Committee is provided in Section 17. It
consists of an officer of or above the rank of the Joint Director of Health and Family Welfare as
Chairperson, an eminent woman representing women’s organization and an officer of Law
Department of the State or the Union Territory as members as the case may be. The functions of the
Appropriate Authority are prescribed in Section 17(4). It empowers the Appropriate Authority to
grant, suspend or cancel the registration, enforce standards, investigate complaints and to do other
acts as provided therein. Constitution of Advisory Committee is also provided under Section 17(6),
to aid and advise the Appropriate Authority, consisting of three medical experts from amongstFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

gynaecologists, obstetricians, paediatricians and medical geneticists, one legal expert, an officer as
provided thereunder, and three eminent social workers. No person who has been associated with the
use or promotion of pre−natal diagnostic techniques for determination of sex or sex selection can be
member of the Advisory Committee. Section 17 is extracted hereunder:
“17. Appropriate Authority and Advisory Committee.— (1) The Central Government
shall appoint, by notification in the Official Gazette, one or more Appropriate
Authorities for each of the Union territories for the purposes of this Act.
(2) The State Government shall appoint, by notification in the Official Gazette, one or
more Appropriate Authorities for the whole or part of the State for the purposes of
this Act having regard to the intensity of the problem of pre−natal sex determination
leading to female foeticide.
(3) The officers appointed as Appropriate Authorities under sub− section (1) or sub−
section (2) shall be,—
(a) when appointed for the whole of the State or the Union territory, consisting of the
following three members:—
(i) an officer of or above the rank of the Joint Director of Health and Family
Welfare—Chairperson;
(ii) an eminent woman representing women’s organization; and
(iii) an officer of Law Department of the State or the Union territory concerned:
Provided that it shall be the duty of the State or the Union territory concerned to
constitute multi−member State or Union territory level Appropriate Authority within
three months of the coming into force of the Pre−natal Diagnostic Techniques
(Regulation and Prevention of Misuse) Amendment Act, 2002:
Provided further that any vacancy occurring therein shall be filled within three
months of the occurrence.
(b) when appointed for any part of the State or the Union territory, of such other rank
as the State Government or the Central Government, as the case may be, may deem
fit.
(4) The Appropriate Authority shall have the following functions, namely:—
(a) to grant, suspend or cancel registration of a Genetic Counselling Centre, Genetic
Laboratory or Genetic Clinic;Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(b) to enforce standards prescribed for the Genetic Counselling Centre, Genetic
Laboratory and Genetic Clinic;
(c) to investigate complaints of breach of the provisions of this Act or the rules made
thereunder and take immediate action;
(d) to seek and consider the advice of the Advisory Committee, constituted under
sub−section (5), on application for registration and on complaints for suspension or
cancellation of registration;
(e) to take appropriate legal action against the use of any sex selection technique by
any person at any place, suo motu or brought to its notice and also to initiate
independent investigations in such matter;
(f) to create public awareness against the practice of sex selection or pre−natal
determination of sex;
(g) to supervise the implementation of the provisions of the Act and rules;
(h) to recommend to the Board and State Boards modifications required in the rules
in accordance with changes in technology or social conditions;
(i) to take action on the recommendations of the Advisory Committee made after
investigation of complaint for suspension or cancellation of registration.
(5) The Central Government or the State Government, as the case may be, shall
constitute an Advisory Committee for each Appropriate Authority to aid and advise
the Appropriate Authority in the discharge of its functions, and shall appoint one of
the members of the Advisory Committee to be its Chairman.
(6) The Advisory Committee shall consist of—
(a) three medical experts from amongst gynaecologists, obstericians, paediatricians
and medical geneticists;
(b) one legal expert;
(c) one officer to represent the department dealing with information and publicity of
the State Government or the Union territory, as the case may be;
(d) three eminent social workers of whom not less than one shall be from amongst
representatives of women’s organisations.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(7) No person who has been associated with the use or promotion of pre−natal
diagnostic techniques for determination of sex or sex selection shall be appointed as a
member of the Advisory Committee.
(8) The Advisory Committee may meet as and when it thinks fit or on the request of
the Appropriate Authority for consideration of any application for registration or any
complaint for suspension or cancellation of registration and to give advice thereon:
Provided that the period intervening between any two meetings shall not exceed the
prescribed period.
(9) The terms and conditions subject to which a person may be appointed to the
Advisory Committee and the procedure to be followed by such Committee in the
discharge of its functions shall be such as may be prescribed.”
44. Section 17A empowers Appropriate Authority to summon any person who is in possession of any
information relating to violation of the provisions of the Act and production of documents, issue
search warrant etc. It is mandatory that such Genetic Counselling Centres, Laboratories or Clinics
should be registered under Section 18 of the Act.
45. Section 20 deals with cancellation or suspension of registration. An action can be taken as
provided under Section 20(2) after giving reasonable opportunity of being heard. In case there is
breach of provisions of the Act or the Rules, and the same is without prejudice to any criminal action
that it may take against such Centres, Laboratory or Clinic, the Appropriate Authority in public
interest for reasons to be recorded in writing, can suspend the registration of any Genetic
Counselling Centres, Laboratories or Clinics under Section 20(3) of the Act without issuing any
notice referred to in sub−section (1) of Section 20. The provisions of appeal against the order of
suspension or cancellation of registration passed by Appropriate Authority has been provided in
Section 21. Sections 20 and 21 are extracted hereunder:
“20. Cancellation or suspension of registration.— (1). The Appropriate Authority may
suo moto, or on complaint, issue a notice to the Genetic Counselling Centre, Genetic
Laboratory or Genetic Clinic to show cause why its registration should not be
suspended or cancelled for the reasons mentioned in the notice.
(2) If, after giving a reasonable opportunity of being heard to the Genetic Counselling
Centre, Genetic Laboratory or Genetic Clinic and having regard to the advice of the
Advisory Committee, the Appropriate Authority is satisfied that there has been a
breach of the provisions of this Act or the rules, it may, without prejudice to any
criminal action that it may take against such Centre, Laboratory or Clinic, suspend its
registration for such period as it may think fit or cancel its registration, as the case
may be.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(3) Notwithstanding anything contained in sub−sections (1) and (2), if the
Appropriate Authority is of the opinion that it is necessary or expedient so to do in
the public interest, it may, for reasons to be recorded in writing, suspend the
registration of any Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic
without issuing any such notice referred to in sub−section (1).
21. Appeal.— The Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic may, within
thirty days from the date of receipt of the order of suspension or cancellation of registration passed
by the Appropriate Authority under section 20, prefer an appeal against such order to—
(i) the Central Government, where the appeal is against the order of the Central Appropriate
Authority; and
(ii) the State Government, where the appeal is against the order of the State Appropriate Authority,
in the prescribed manner.” (emphasis supplied)
46. Section 22 deals with prohibition of advertisement relating to pre−conception and pre−natal
determination of sex and punishment for contravention.
47. Section 23 deals with offences and penalties. Section 23(1) provides for contravention of any
provisions of the Act or Rules made thereunder, punishment with imprisonment for a term which
may extend to three years and with fine which may extend to ten thousand rupees. Section 23(2)
contains provision with respect to reporting of name of the registered medical practitioner by the
Appropriate Authority to the State Medical Council concerned for passing appropriate order
including suspension of the registration, if the charges are framed by the Court and till the case is
disposed of and on conviction for removal of his name from the register of the Council for a period
of five years for the first offence and permanently for the subsequent offence. Any person who seek
aid of any Genetic Counselling Centre, Laboratory, Clinic or ultrasound clinic or imaging clinic etc.
for sex selection, shall be punishable with imprisonment which may extend to three years and with
fine which may extend to fifty thousand rupees for the first offence and for any subsequent offence
with imprisonment which may extend to five years and with fine which may extend to one lakh
rupees. If a woman is compelled by her husband or any other relative to undergo pre− natal
diagnostic technique for the purpose of Section 4(2), such person shall be liable for abetment of
offence under Section 23(3). Sections 23 and 24 are extracted hereunder:
“23. Offences and penalties.— (1) Any medical geneticist, gynaecologist, registered
medical practitioner or any person who owns a Genetic Counselling Centre, a Genetic
Laboratory or a Genetic Clinic or is employed in such a Centre, Laboratory or Clinic
and renders his professional or technical services to or at such a Centre, Laboratory
or Clinic, whether on an honorary basis or otherwise, and who contravenes any of the
provisions of this Act or rules made thereunder shall be punishable with
imprisonment for a term which may extend to three years and with fine which may
extend to ten thousand rupees and on any subsequent conviction, with imprisonment
which may extend to five years and with fine which may extend to fifty thousandFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

rupees.
(2) The name of the registered medical practitioner shall be reported by the
Appropriate Authority to the State Medical Council concerned for taking necessary
action including suspension of the registration if the charges are framed by the court
and till the case is disposed of and on conviction for removal of his name from the
register of the Council for a period of five years for the first offence and permanently
for the subsequent offence.
(3) Any person who seeks the aid of any Genetic Counselling Centre, Genetic
Laboratory, Genetic Clinic or ultrasound clinic or imaging clinic or of a medical
geneticist, gynaecologist, sonologist or imaging specialist or registered medical
practitioner or any other person for sex selection or for conducting pre−natal
diagnostic techniques on any pregnant women for the purposes other than those
specified in sub−section (2) of section 4, he shall be punishable with imprisonment
for a term which may extend to three years and with fine which may extend to fifty
thousand rupees for the first offence and for any subsequent offence with
imprisonment which may extend to five years and with fine which may extend to one
lakh rupees.
(4) For the removal of doubts, it is hereby provided, that the provisions of sub−
section (3) shall not apply to the woman who was compelled to undergo such
diagnostic techniques or such selection.
24. Presumption in the case of conduct of pre−natal diagnostic techniques.—Notwithstanding
anything contained in the Indian Evidence Act, 1872 (1 of 1872), the court shall presume unless the
contrary is proved that the pregnant woman was compelled by her husband or any other relative, as
the case may be, to undergo pre−natal diagnostic technique for the purposes other than those
specified in sub−section (2) of section 4 and such person shall be liable for abetment of offence
under sub−section (3) of section 23 and shall be punishable for the offence specified under that
section.” (emphasis supplied)
48. Section 25 of the Act deals with the penalty for contravention of the provisions of the Act or rules
for which no specific punishment is provided. Any contravention under this Section shall be
punishable with imprisonment for a term which may extend to three months or with fine which may
extend to one thousand rupees or both and in case of continuing contravention with an additional
fine which may extend to five hundred rupees for every day.
49. Section 27 makes offence to be cognizable, non−bailable and non−compoundable. Section 27 is
extracted hereunder:
“27. Offence to be cognizable, non−bailable and non− compoundable.−Every offence
under this Act shall be cognizable, non−bailable and non−compoundable.”Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

50. The mode of taking cognizance of offence is provided in Section 28 on a complaint made by the
Appropriate Authority or any officer authorised in this behalf; or by a person who has given notice of
not less than fifteen days to the Appropriate Authority of the alleged offence and of his intention to
make a complaint to the court. The Metropolitan Magistrate or a Judicial Magistrate is competent to
try any offence punishable under this Act. Maintenance of records is provided in Section 29 and that
has to be preserved for two years. In case any criminal or other proceedings are instituted against
any Genetic Counselling Centre, Laboratory or Clinic, the records shall be preserved till the final
disposal of such proceedings. Section 30 empowers Appropriate Authority to search and seize
records etc. Section 31 provides for protection of action taken in good faith.
51. Section 32 empowers the Central Government to make rules for carrying out the provisions of
the Act. Section 33 gives power to the Board to make regulations with the previous sanction of the
Central Government. Rules and regulations are required to be laid before the Parliament as
provided in Section 34.
52. Rule 9 of the Rules provides for maintenance and preservation of records. The same is extracted
hereunder:
9. Maintenance and preservation of records.— (1) Every Genetic Counselling Centre,
Genetic Laboratory and Genetic Clinic including a mobile Genetic Clinic, Ultrasound
Clinic and Imaging Centre shall maintain a register showing, in serial order, the
names and addresses of the men or women given genetic counselling, subjected to
pre−natal diagnostic procedures or pre−natal diagnostic tests, the names of their
spouse or father and the date on which they first reported for such counselling,
procedure or test.
(2) The record to be maintained by every Genetic Counselling Centre, in respect of each woman
counselled shall be as specified in Form D. (3) The record to be maintained by every Genetic
Laboratory, in respect of each man or woman subjected to any pre−natal diagnostic
procedure/technique/test, shall be as specified in Form E. (4) The record to be maintained by every
Genetic Clinic including a mobile Genetic Clinic, in respect of each man or woman subjected to any
pre−natal diagnostic procedure/technique/test, shall be as specified in Form F. (5) The Appropriate
Authority shall maintain a permanent record of applications for grant or renewal of certificate of
registration as specified in Form H. Letters of intimation of every change of employee, place,
address and equipment installed shall also be preserved as permanent records.
(6) All case related−records, forms of consent, laboratory results, microscopic pictures, sonographic
plates or slides, recommendations and letters shall be preserved by the Genetic Counselling Centre,
Genetic Laboratory or Genetic Clinic, Ultrasound Clinic or Imaging Centre for a period of two years
from the date of completion of counselling, pre−natal diagnostic procedure or pre−natal diagnostic
test, as the case may be. In the event of any legal proceedings, the records shall be preserved till the
final disposal of legal proceedings, or till the expiry of the said period of two years, whichever is
later.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(7) In case the Genetic Counselling Centre or Genetic Laboratory or Genetic Clinic or Ultrasound
Clinic or Imaging Centre maintains records on computer or other electronic equipment, a printed
copy of the record shall be taken and preserved after authentication by a person responsible for such
record. (8) Every Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic, Ultrasound Clinic
and Imaging Centre shall send a complete report in respect of all pre−conception or pregnancy
related procedures/techniques/tests conducted by them in respect of each month by 5th day of the
following month to the concerned Appropriate Authority.” Rule 9 makes it mandatory to maintain a
register showing in serial order the names and addresses of the men or women given genetic
counselling, subjected to pre−natal diagnostic procedures or pre−natal diagnostic tests, the name of
their spouse or father and the date on which they first reported for such counselling. Rule 9(2) states
that record to be maintained uniformly. Rule 9(4) provides that record to be maintained by every
Genetic Clinic in respect of each man or woman subjected to any pre−natal diagnostic
procedure/technique/test, shall be specified in Form ‘F’. Rule 10 deals with conditions for
conducting pre−natal diagnostic procedures. Rule 10(1A) provides that it is mandatory for every
person conducting ultrasonography to declare that he/she has neither detected nor disclosed the sex
of foetus of the pregnant woman to anybody. The pregnant woman shall declare before undergoing
the test that she does not want to know the sex of her foetus. Rule 19 provides for an appeal against
the decision of Appropriate Authority. Form ‘F’, which is the bone of contention of the learned
counsel for the parties, is extracted hereunder:
“FORM F FORM FOR MAINTENANCE OF RECORD IN RESPECT OF PREGNANT
WOMAN BY GENETIC CLINIC/ULTRASOUND CLINIC/IMAGING CENTRE
1. Name and address of the Genetic Clinic/Ultrasound Clinic/Imaging Centre.
2. Registration No.
3. Patient’s name and her age
4. Number of children with sex of each child
5. Husband’s/Father’s name
6. Full address with Tel. No., if any
7. Referred by (full name and address of Doctor(s) / Genetic Counselling Centre
(referral note to be preserved carefully with case papers)/self referral
8. Last menstrual period/weeks of pregnancy
9. History of genetic/medical disease in the family (specify) Basis of diagnosis:
(a) ClinicalFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(b) Bio−chemical
(c) Cytogenetic
(d) Other (e.g. radiological, ultrasonography etc. specify)
10. Indication for pre−natal diagnosis A. Previous child/children with:
(i) Chromosomal disorders
(ii) Metabolic disorders
(iii) Congenital anomaly
(iv) Mental retardation
(v) Haemoglobinopathy
(vi) Sex linked disorders
(vii) Single gene disorder
(viii) Any other (specify) B. Advanced maternal age (35 years) C.
Mother/father/sibling has genetic disease (specify) D. Other (specify)
11. Procedures carried out (with name and registration No. of Gynaecologist/
Radiologist/ Registered Medical Practitioner) who performed it.
Non−Invasive
(i) Ultrasound (specify purpose for which ultrasound is to done during pregnancy) [List of
indications for ultrasonography of pregnant women are given in the note below] Invasive
(ii) Amniocentesis
(iii) Chorionic Villi aspiration
(iv) Foetal biopsy
(v) Cordocentesis
(vi) Any other (specify)
12. Any complication of procedure – please specifyFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

13. Laboratory tests recommended
(i) Chromosomal studies
(ii) Biochemical studies
(iii) Molecular studies
(iv) Preimplantation genetic diagnosis
14. Result of
(a) pre−natal diagnostic procedure (give details)
(b) Ultrasonography Normal/Abnormal (specify abnormality detected, if any).
15. Date(s) on which procedures carried out.
16. Date on which consent obtained. (In case of invasive)
17. The result of pre−natal diagnostic procedure were conveyed to ……….on ……………
18. 18. Was MTP advised/conducted?
19. Date on which MTP carried out Date …………….. Name, Signature and Registration number
Place…………….. of the Gynaecologist/Radiologist/Director of the Clinic DECLARATION OF
PREGNANT WOMAN I, Ms…………………..(name of the pregnant woman) declare that by
undergoing ultrasonography /image scanning etc. I do not want to know the sex of my foetus.
Signature/Thump impression of pregnant woman DECLARATON OF DOCTOR/PERSON
CONDUCTING ULTRASONOGRAPHY/IMAGE SCANNING I,……………………(name of the person
conducting ultrasonography/image scanning) declare that while conducting ultrasonography/image
scanning on Ms…………………..(name of the pregnant woman), I have neither detected nor disclosed
the sex of her foetus to any body in any manner.
Name and signature of the person conducting ultrasonography/image scanning/Director or owner
of genetic clinic/ultrasound clinic/imaging centre. Important Notes:—
(i) Ultrasound is not indicated/advised/performed to determine the sex of foetus except for
diagnosis of sex−linked diseases such as Duchenne Muscular Dystrophy, Haemophilia A & B, etc.
(ii) During pregnancy Ultrasonography should only be performed when indicated. The following is
the representative list of indications for ultrasound during pregnancy.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(1) To diagnose intra−uterine and/or ectopic pregnancy and confirm viability.
(2) Estimation of gestational age (dating).
(3) Detection of number of foetuses and their chorionicity. (4) Suspected pregnancy with IUCD in−
situ or suspected pregnancy following contraceptive failure/MTP failure. (5) Vaginal bleeding /
leaking.
(6) Follow−up of cases of abortion.
(7) Assessment of cervical canal and diameter of internal os. (8) Discrepancy between uterine size
and period of amenorrhoea.
(9) Any suspected adenexal or uterine pathology / abnormality.
(10) Detection of chromosomal abnormalities, foetal structural defects and other abnormalities and
their follow− up.
(11) To evaluate foetal presentation and position. (12) Assessment of liquor amnii.
(13) Preterm labour / preterm premature rupture of membranes.
(14) Evaluation of placental position, thickness, grading and abnormalities (placenta praevia,
retroplacental haemorrhage, abnormal adherence etc.).
(15) Evaluation of umbilical cord – presentation, insertion, nuchal encirclement, number of vessels
and presence of true knot.
(16) Evaluation of previous Caesarean Section scars. (17) Evaluation of foetal growth parameters,
foetal weight and foetal well being.
(18) Colour flow mapping and duplex Doppler studies. (19) Ultrasound guided procedures such as
medical termination of pregnancy, external cephalic version etc. and their follow−up.
(20) Adjunct to diagnostic and therapeutic invasive interventions such as chorionic villus sampling
(CVS), amniocenteses, foetal blood sampling, foetal skin biopsy, amnioinfusion, intrauterine
infusion, placement of shunts etc. (21) Observation of intra−partum events.
(22) Medical/surgical conditions complicating pregnancy. (23) Research/scientific studies in
recognised institutions. Person conducting ultrasonography on a pregnant woman shall keep
complete record thereof in the clinic/centre in Form F and any deficiency or inaccuracy found
therein shall amount to contravention of provisions of section 5 or section 6 of the Act, unless
contrary is proved by the person conducting such ultrasonography.”Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

53. The Act and Rules are not the only regulatory framework which requires the medical fraternity
to keep proper record. The medical profession has highly specialised nature and considering the
nature of services rendered by medical professional, proper maintenance of records is an integral
part of the medical services. It is contended on behalf of Medical Council of India that the Medical
Council of India (MCI) under Section 33 of the Indian Medical Council Act, 1956 has framed the
Indian Medical Council (Professional Conduct, Etiquette and Ethics) Regulations, 2002, which also
placed a burden on physicians to observe the law of the country. By the said Regulations, it is
mandatory for every doctor to maintain the records of the patients treated by him/her and non−
maintaining of records is a misconduct. MCI Regulation 1.3 deals with maintenance of medical
records, which reads thus:
“1.3 Maintenance of medical records:
1.3.1 Every physician shall maintain the medical records pertaining to his / her
indoor patients for a period of 3 years from the date of commencement of the
treatment in a standard proforma laid down by the Medical Council of India and
attached as Appendix 3.
1.3.2. If any request is made for medical records either by the patients / authorised
attendant or legal authorities involved, the same may be duly acknowledged and
documents shall be issued within the period of 72 hours.
1.3.3 A Registered medical practitioner shall maintain a Register of Medical
Certificates giving full details of certificates issued.
When issuing a medical certificate he / she shall always enter the identification marks of the patient
and keep a copy of the certificate. He / She shall not omit to record the signature and/or thumb
mark, address and at least one identification mark of the patient on the medical certificates or
report. The medical certificate shall be prepared as in Appendix 2. 1.3.4 Efforts shall be made to
computerize medical records for quick retrieval.” (emphasis supplied)
54. Regulation 7.1 under Chapter 7 deals with misconduct committed by a doctor by violating any
provisions of the Regulations, whereas Regulation 7.2 provides that the failure to maintain the
medical records of indoor patient for a period of three years and refusal to provide the medical
record to a patient on request within 72 hours is a misconduct. Regulation 7.6 deals with
misconduct relating to sex determination and termination of pregnancy. The relevant portion of
Regulation 7 is reproduced hereunder:
“7. MISCONDUCT The following acts of commission or omission on the part of a
physician shall constitute professional misconduct rendering him/her liable for
disciplinary action.
7.1 Violation of the Regulations: If he/she commits any violation of these
Regulations.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

7.2 If he/she does not maintain the medical records of his/her indoor patients for a
period of three years as per regulation 1.3 and refuses to provide the same within 72
hours when the patient or his/her authorised representative makes a request for it as
per the regulation 1.3.2.
*** *** *** 7.6 Sex Determination Tests: On no account sex determination test shall
be undertaken with the intent to terminate the life of a female foetus developing in
her mother’s womb, unless there are other absolute indications for termination of
pregnancy as specified in the Medical Termination of Pregnancy Act, 1971. Any act of
termination of pregnancy of normal female foetus amounting to female foeticide shall
be regarded as professional misconduct on the part of the physician leading to penal
erasure besides rendering him liable to criminal proceedings as per the provisions of
this Act.”
55. Regulation 8 of the MCI Regulation deals with punishment and disciplinary action for
misconduct committed by a doctor. The relevant portion of Regulation 8 reads thus:
“8. PUNISHMENT AND DISCIPLINARY ACTION 8.1 It must be clearly understood
that the instances of offences and of Professional misconduct which are given above
do not constitute and are not intended to constitute a complete list of the infamous
acts which calls for disciplinary action, and that by issuing this notice the Medical
Council of India and or State Medical Councils are in no way precluded from
considering and dealing with any other form of professional misconduct on the part
of a registered practitioner. Circumstances may and do arise from time to time in
relation to which there may occur questions of professional misconduct which do not
come within any of these categories. Every care should be taken that the code is not
violated in letter or spirit. In such instances as in all others, the Medical Council of
India and/or State Medical Councils have to consider and decide upon the facts
brought before the Medical Council of India and/or State Medical Councils.
8.2 It is made clear that any complaint with regard to professional misconduct can be
brought before the appropriate Medical Council for Disciplinary action. Upon receipt
of any complaint of professional misconduct, the appropriate Medical Council would
hold an enquiry and give opportunity to the registered medical practitioner to be
heard in person or by pleader. If the medical practitioner is found to be guilty of
committing professional misconduct, the appropriate Medical Council may award
such punishment as deemed necessary or may direct the removal altogether or for a
specified period, from the register of the name of the delinquent registered
practitioner.
Deletion from the Register shall be widely publicized in local press as well as in the publications of
different Medical Associations/ Societies/Bodies.”Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

56. It is further pointed out that Pharmacy Practice Regulations, 2015 also require pharmacists to
maintain records. The relevant portion of the Regulations is extracted hereunder:
“6.2 Maintenance of patient records.—
(a) Every registered pharmacist shall maintain the medical/ prescription records
pertaining to his / her patients for a period of 5 years from the date of
commencement of the treatment as laid down by the Pharmacy Council of India in
Appendix II.
(b) If any request is made for medical records either by the patients/authorised
attendant or legal authorities involved, the same may be duly acknowledged and
documents shall be issued within the period of 72 hours.
(c) Efforts shall be made to computerize medical/prescription records for quick
retrieval.”
57. Reference has also been made to the provisions of the Transplantation of Human Organs and
Tissues Act, 1994 and Rules, which contain provisions that are similar to the Act. Section 20 of the
Transplantation of Human Organs and Tissues Act, 1994, reads thus:
“20. Punishment for contravention of any other provision of this Act.— Whoever
contravenes any provision of this Act or any rule made, or any condition of the
registration granted, thereunder for which no punishment is separately provided in
this Act, shall be punishable with imprisonment for a term which may extend to five
years or with fine which may extend to twenty lakh rupees.”
58. Reference has also been made to the Medical Termination of Pregnancy Act, 1971, which also
places an obligation on medical professional to maintain proper records.
59. When we scrutinise the Form ‘F’ with the provisions of the Act/Rules and there cannot be any
dispute with respect to serial Nos.1 and 2 wherein name and address of Genetic Laboratory and its
registration number is required to be mentioned in the Form as it is necessary to have a registration
under Section 18 of the Act. It cannot be said to be a clerical requirement. Patient name and her age
at serial No.3 is also absolutely necessary so as to identify a person who is undergoing the test and
before the age of 35 years, it cannot be conducted as provided under Section 4(3)(i). The same is as
per the mandatory requirement of Section 4. Husband’s/father’s name is also necessary as per the
statutory mandate for the purpose of identification of patient. Full address is also mandatory so as
to ascertain the identity who is undergoing such test. In case these information are kept vague, the
violation of the Act would be blatant and unchecked and offence can never be detected. Information
at serial No.8 of the Form ‘F’ requires last menstrual period/weeks of pregnancy to be mentioned,
same is also necessary to be mentioned as it has co−relation with the investigations and provisions
of the Act and the rules framed thereunder. The column in Form at serial No.9 requires history of
genetic/medical disease in the family to be specified which is as per the mandate of Section 4(3)(iv)Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

of the Act. Form ‘F’ at serial No.10 requires indication for pre−natal diagnosis which is mandatory as
per the provisions contained in Section 4(2) as except for the purposes as mentioned in Sections
4(2) and 4(3) no such tests/procedures can be performed. Thus, what is mandated by the Sections
and in Rule 9 has been mentioned in the Form ‘F’. Procedure carried whether invasive or non−
invasive has to be obviously mentioned and in case any laboratory tests have been recommended
that is to be mentioned along with the result. The note attached to Form ‘F’ also contains the
representative list of indications when ultrasound during pregnancy can be performed. Thus,
though the submission that Form ‘F’ is clerical requirement urged by learned counsel appearing for
the petitioner−Society appears at the first blush to be worthy examination, but on close scrutiny it is
found that in case any information in the Form is avoided, it will result in the blatant violation of the
provisions of Section 4 and may lead to result which is prohibited under Section 6. It cannot be said
to be a case of clerical error as doctor has to fulfil pre− requisites for undertaking the procedure in
case the conditions precedent for undertaking pre−natal diagnostic test is not specifically
mentioned, it would be violative of provisions contained in Section 4. The Form ‘F’ has to be
prepared and signed by either Gynaecologist/Medical Geneticist / Radiologist / Paediatrician /
Director of the Clinic/Centre/Laboratory. In case the indications and the information are not
furnished as provided in the Form ‘F’ it would amount that condition precedent to undertake the
test/procedure is absent. There is no other barometer except Form ‘F’ to find out why the diagnostic
test/procedure was performed. In case such an important information beside others is kept vague or
missing from the Form, it would defeat the very purpose of the Act and the safeguards provided
thereunder and it would become impossible to check violation of provisions of the Act. It is not the
clerical job to fill the form, it is condition precedent for undertaking test/procedure. With all due
regards to the submission advanced on behalf of petitioner−Society that it is a clerical job, is wholly
without substance but it is a responsible job of the person who is undertaking such a test i.e., the
Gynaecologist/ Medical Geneticist/ Radiologist / Paediatrician / Director of the
Clinic/Centre/Laboratory to fill the requisite information. In case he keeps it vague, he knows fully
well that he is violating the provisions of the Act and undertaking the test without existence of the
conditions precedent which are mandatory to exist he cannot undertake test/procedure without
filling such information in the form. There is no other way to ensure that test is undertaken on
fulfilment of the prescribed conditions. There is nothing else but the record which required to be
maintained and on the basis of which counter−check can be made. There is no other barometer or
criteria to find out the violation of the provisions of the Act. Rule 9(4) also requires that every
Genetic Clinic to fill Form ‘F’ wherein information with regard to details of the patient, referral notes
with indication and case papers of the patient are required to be filled and preserved. Form ‘F’ lays
down the indicative list for conducting ultrasonography during pregnancy. Form ‘F’ being technical
in nature gives the insight into the reasons for conducting ultrasonography and incomplete Form ‘F’
raises the presumption of doubt against the medical practitioner. In the absence of Form ‘F’,
Appropriate Authorities will have no tool to supervise the usage of ultrasound machine and shall not
be able to regulate the use of the technique which is the object of the Act.
60. It is rightly contended on behalf of respondents that there are different forms for record keeping
prescribed under the Act and the Rules they are important and interlinked, operate in tandem with
one another. These records have to be maintained only when the procedure or tests are conducted
on pregnant woman or when patient may have been advised to use pre− conception diagnostic toolsFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

to conceive a child. It is required for Genetic Counselling Centre advising the procedure/test with a
potential of detecting or determining the sex of the foetus and referring a person to a Genetic
Clinic/Imaging Centre/Ultrasound Clinic to record the details of Genetic Clinic to which patient is
referred at point 15 of the Form ‘D’ along with the details of the diagnosis and relevant medical
details of the person. Accordingly, Genetic Clinic/Imaging Centre/Ultrasound Clinic conducting the
aforesaid referred procedure has to record the name and address of Genetic Counselling Centre with
the referral slip along with the relevant medical record of the person on whom
procedure/test/technique is conducted. The aforesaid record keeping procedure shall be followed by
Genetic Laboratories also. The scheme of the Act makes it evident that record keeping is meant to
track/monitor and regulate the use of technology that has potential of sex selection and sex
determination. Section 23 is not stand−alone Section. It is rather used in the enforcement of other
provisions of the Act and violations of Section 23 are often accompanied by violations of provisions
of Sections 4, 5, 6 and 18 of the Act. It is submitted that non−maintenance of record in the context of
sex determination is not merely a technical or procedural lapse. It is most significant piece of
evidence for identifying offence and the accused. The inspection of records is crucial to identify
wrong−doers as the crime of sex determination being a collusive crime given the nexus between the
patients and the doctors. Accordingly, punishment is provided in Section 23 for not maintaining the
records.
61. Ms. Pinki Anand, learned Additional Solicitor General has relied upon a case study on record
keeping as an implementation tool of Prabhakar Hospital in Panipat. In this case Hospital had not
sent the report of IVF done at its Centre to the Appropriate Authority despite meeting held on
10.10.2013 and subsequent reminders. After thirteenth reminder dated 27.11.2014, a show cause
notice was issued to the Hospital on 2.2.2015. The aforesaid case study reads thus:
“In the case of this Hospital the report of IVF done at the centre was not sent to the
Appropriate Authority despite meetings held on 10.10.2013 and reminders sent on
6.3.2014, 14.3.2014, 20.3.2014, 21.3.2014, 25.3.2014, 28.3.2014, 31.3.2014 and
finally with a thirteenth reminder on 27.11.2014.
During inspection following discrepancies were found− a. In form no.9338, In−vitro Fertilization
(IVF) was done on patient with 2 female children with repeated history of 4 abortions.
b. In form no.9700, woman with 8 female children received IVF.
c. In form no.10385, patient Santosh with 7 female children received IVF but did not fill the section
C in F−Form. Section C in form F pertains to the records of the invasive procedures which requires
records of all diagnostic procedures done on men and women which has potential of sex
determination/selection to be recorded. d. Form no.10389, woman with 3 female children received
IVF, form F Section C not filled in.
e. Form no.9338, woman had 2 female children and 6 abortions, and received IVF.
f. Form no.9700, a woman with 8 female children received IVF.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

The hospital was asked why patients who had female children underwent IVF as evident from the
records. In several of the cases it is inexplicable why the samples were sent to Delhi and Bombay. In
many F forms many female patients with wrong phone numbers were mentioned. Similarly in other
Form F, patients with wrong identity proofs, address proof and no identity proofs were found. In
another set of form F wrong Obstetric and Abortion history was mentioned as confirmed from the
patients. Difference history on referral slip and Form F was observed. Signature of patient was
found to be missing in the consent form in many forms. The Signature of the witness
Doctor/Counsellor was missing in all consent forms of IVF patients. Accordingly a complaint has
been filed in the court.” (emphasis supplied)
62. It is submitted that the record keeping provide information on individual patients who could
have potentially undergone sex selection/determination techniques, which is an offence under this
Act. If record keeping is diluted or exempted from the mandatory requirement of the Act, the
probable involvement in sex determination and sex selection in the guise of use of diagnostic
techniques would continue unbated.
63. The way in which the non−maintenance of record can be used for violating the provisions of the
Act, is apparent from the aforesaid example. The aforesaid facts have been mentioned in the show
cause notice that had been issued. In many Form ‘F’ female patients with wrong phone numbers
were mentioned. In other Form ‘F’ patients with wrong identity, proof of address and no identity
proof were found. In another set of Form ‘F’ wrong obstetric and abortion history was mentioned.
Signature of patient was also found missing in the consent forms. Thus, the non−filling of
information cannot be termed to be clerical error, but in case it is kept vague that itself facilitates an
offence. It would definitely a blatant and intentional violation of the provisions of the Act in order to
prevent the mischief which is intended to by maintenance of record, filling up details of the forms is
mandated by Sections 4 and 5. The wholesome social legislation would be defeated in case Form is
not filled which is sine qua non toto undertake tests/procedures if such condition does not exist, no
such procedure can be performed and diluting the provisions would be against the gender justice. It
is in order to create the equality that the provisions have been enacted not that unequals are being
treated equally. The non−maintenance of form/not reflecting correct medical condition is offence,
not mentioning it would also be an offence or keeping it vague.
64. It was pointed on behalf of petitioner−Society by filing certain affidavits of the medical
practitioners raising grievances with regard to the criminal cases filed against them by the
Appropriate Authority on certain grounds. Acquittals have also been recorded, but they are not
attributable to the deficiency in the Act. The provision of the law cannot be struck down on the
ground of allegation of such exercise of power in arbitrary manner, especially when 0.46 million
girls were stated to be missing at birth as a result of sex selective abortions.
65. In Voluntary Health Association of Punjab v. Union of India, (2016) 10 SCC 265, this Court
observed as under:
“46. Now, we shall advert to the prayers in Writ Petition (Civil) No. 575 of 2014. The
writ petition has been filed by Indian Medical Association (IMA). It is contended thatFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

Sections 3−A, 4, 5, 6, 7, 16, 17, 20, 23, 25, 27 and 30 of the Act and Rules 9(4), 10 &
Form "F" (including foot−note), which being the subject matter of concern in the
instant writ petition, are being misused and wrongly interpreted by the authorities
concerned thereby causing undue harassment to the medical professionals all over
the country under the guise of the 'so−called implementation'. It is also urged that,
implementation of steps and scrutiny of records was started at large scale all over the
country and lot of anomalies were found in records maintained by doctors
throughout the country. It is however pertinent to mention here that the majority of
the defaults were of technical nature as they were merely minor and clerical errors
committed occasionally and inadvertently in the filing of Form "F". It is also put forth
that the Act does not classify the offences and owing to the liberal and vague
terminology used in the Act, it is thrown open for misuse by the implementing
authorities concerned and has resulted into taking of cognizance of non−bailable
(punishable by three years) offences against doctors even in the cases of clerical
errors, for instance non−mentioning of N.A. (Not Applicable) or leaving of any
column in the Form "F" concerned as blank. It is further submitted that the said
unfettered powers in the hands of implementing authority have resulted into turning
of this welfare legislation into a draconian novel way of encouraging demands for
bribery as well as there is no prior independent investigation as mandated Under
Section 17 of the Act by these Authorities. It is also set forth that the Act states merely
that any contravention with any of the provisions of the Act would be an offence
punishable Under Section 23(1) of the said Act and further all offences under the Act
have been made non−bailable and non− compoundable and the misuse of the same
can only be taken care of by ensuring that the Appropriate Authority applies its mind
to the fact of each case/complaint and only on satisfaction of a prima facie case, a
complaint be filed rather than launching prosecution mechanically in each case. With
these averments, it has been prayed for framing appropriate guidelines and safeguard
parameters, providing for classification of offences as well, so as to prohibit the
misuse of the PCPNDT Act during implementation and to read down this Sections 6,
23, 27 of the PCPNDT Act. That apart, it has been prayed to add certain
provisos/exceptions to Sections 7, 17, 23 and Rule 9 of the Rules.
47. In our considered opinion, whenever there is an abuse of the process of the law,
the individual can always avail the legal remedy. As we find, neither the validity of the
Act nor the Rules has been specifically assailed in the writ petition. What has been
prayed is to read out certain provisions and to add certain exceptions. We are of the
convinced view that the averments of the present nature with such prayers cannot be
entertained and, accordingly, we decline to interfere.” (emphasis supplied)
66. The emphasis of this Court is on the proper maintenance of records. In Centre for Enquiry into
Health and Allied Themes (CEHAT) v. Union of India, (2001) 5 SCC 577, this Court observed thus:
“3. It is apparent that to a large extent, the PNDT Act is not implemented by the
Central Government or by the State Governments. Hence, the petitioners areFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

required to approach this Court under Article 32 of the Constitution of
India……Prima facie it appears that despite the PNDT Act being enacted by
Parliament five years back, neither the State Governments nor the Central
Government has taken appropriate action for its implementation. Hence, after
considering the respective submissions made at the time of hearing of this matter, as
suggested by the learned Attorney−General for India, Mr Soli J. Sorabjee, the
following directions are issued on the basis of various provisions for the proper
implementation of the PNDT Act:
II. Directions to the Central Supervisory Board (CSB)
1. ***
2. ***
3. CSB shall issue directions to all State/UT appropriate authorities to furnish
quarterly returns to CSB giving a report on the implementation and working of the
Act. These returns should inter alia contain specific information about:
(i) survey of bodies specified in Section 3 of the Act;
(ii) registration of bodies specified in Section 3 of the Act;
(iii) action taken against non−registered bodies operating in violation of Section 3 of
the Act, inclusive of search and seizure of records;
(iv) complaints received by the appropriate authorities under the Act and action
taken pursuant thereto;
(v) number and nature of awareness campaigns conducted and results flowing
therefrom.….”
67. In Voluntary Health Association of Punjab v. Union of India, (2013) 4 SCC 1, the Court dealt
with the issue of maintenance of record and issued the following directions:
“9.4. The authorities should ensure also that all genetic counselling centres, genetic
laboratories and genetic clinics, infertility clinics, scan centres etc. using
preconception and pre− natal diagnostic techniques and procedures should maintain
all records and all forms, required to be maintained under the Act and the Rules and
the duplicate copies of the same be sent to the district authorities concerned, in
accordance with Rule 9(8) of the Rules.
9.6. There will be a direction to all genetic counselling centres, genetic laboratories,
clinics etc. to maintain Forms A, E, H and other statutory forms provided under theFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

Rules and if these forms are not properly maintained, appropriate action should be
taken by the authorities concerned.”
68. The High Court of Gujarat in Suo Motu v. State of Gujarat, (2009) 1 Gujarat Law Reporter 64,
dealt at length with the issue of proper maintenance of record and observed as under:
“5. A conjoint reading of the above provisions would clearly indicate a well−knit
legislative scheme for ensuring a strict and vigilant enforcement of the provisions of
the Act directed against female foeticide and misuse of pre−natal diagnostic
techniques….
*** *** ***
7. As seen earlier, the Act and the Rules made thereunder provide for an elaborate
scheme to ensure proper implementation of the relevant legal provisions and the
possible loopholes in strict and full compliance are sought to be plugged by detailed
provisions for maintenance and preservation of records. In order to fully
operationalise the restrictions and injunctions contained in the Act in general and in
Secs. 4, 5 and 6 in particular, to regulate the use of pre−natal diagnostic technique, to
make the pregnant woman and the person conducting the pre−natal diagnostic tests
and procedures aware of the legal and other consequences and to prohibit
determination of sex, the Rules prescribe the detailed forms in which records have to
be maintained. Thus, the Rules are made and forms are prescribed in aid of the Act
and they are so important for implementation of the Act and for prosecution of the
offenders, that any improper maintenance of such record is itself made equivalent to
violation of the provisions of Secs. 5 and 6, by virtue of the proviso to sub− sec. (3) of
Sec. 4 of the Act. It must, however, be noted that the proviso would apply only in
cases of ultra−sonography conducted on a pregnant woman. And any deficiency or
inaccuracy in the prescribed record would amount to contravention of the provisions
of Secs. 5 and 6 unless and until contrary is proved by the person conducting such
ultra−sonography. The deeming provision is restricted to the cases of ultra−
sonography on pregnant women and the person conducting ultra−sonography is,
during the course of trial or other proceeding, entitled to prove that the provisions of
Secs. 5 and 6 were, in fact, not violated.
8. It needs to be noted that improper maintenance of the record has also
consequences other than prosecution for deemed violation of Secs. 5 or 6. Section 20
of the Act provides for cancellation or suspension of registration of Genetic
Counselling Centre, Genetic Laboratory or Genetic Clinic in case of breach of the
provisions of the Act or the Rules. Therefore, inaccuracy or deficiency in maintaining
the prescribed record shall also amount to violation of the prohibition imposed by
Sec. 6 against the Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic
and expose such clinic to proceedings under Sec. 20 of the Act.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

Where, by virtue of the deeming provisions of the proviso to sub− sec. (3) of Sec. 4, contravention of
the provisions of Secs. 5 or 6 is legally presumed and actions are proposed to be taken under Sec. 20,
the person conducting ultra−sonography on a pregnant woman shall also have to be given an
opportunity to prove that the provisions of Secs. 5 or 6 were not violated by him in conducting the
procedure. Thus, the burden shifts on to the person accused of not maintaining the prescribed
record, after any inaccuracy or deficiency is established, and he gets the opportunity to prove that
the provisions of Secs. 5 and 6 were not contravened in any respect. Although it is apparently a
heavy burden, it is legal, proper and justified in view of the importance of the Rules regarding
maintenance of record in the prescribed forms and the likely failure of the Act and its purpose if
procedural requirements were flouted. The proviso to sub−sec. (3) of Sec. 4 is crystal clear about the
maintenance of the record in prescribed manner being an independent offence amounting to
violation of Secs. 5 or 6 and, therefore, the complaint need not necessarily also allege violation of the
provisions of Secs. 5 or 6 of the Act. A rebuttable presumption of violation of the provisions of Secs.
5 or 6 will arise on proof of deficiency or inaccuracy in maintaining the record in the prescribed
manner and equivalence with those provisions would arise for punishment as well as for disproving
their violation by the accused person. That being the scheme of these provisions, it would be wholly
inappropriate to quash the complaint leging inaccuracy or deficiency in maintenance of the
prescribed record only on the ground that violation of Secs. 5 or 6 of the Act was not alleged or made
out in the complaint. It would also be improper and premature to expect or allow the person accused
of inaccuracy or deficiency in maintenance of the relevant record to show or prove that provisions of
Secs. 5 or 6 were not violated by him, before the deficiency or inaccuracy were established in Court
by the prosecuting agency or before the authority concerned in other proceedings.”
69. The Act enjoys a presumption of constitutionality. We find no violation of the constitutional
principles. The problem of female foeticide is worldwide and the matters of common knowledge,
reports and history are the basis of the legislation, provisions of which cannot be termed to be illegal
or arbitrary in any manner. In Namit Sharma v. Union of India, (2013) 1 SCC 745, this Court has
laid down as under:
“18. The principles for adjudicating the constitutionality of a provision have been
stated by this Court in its various judgments. Referring to these judgments and more
particularly to Ram Krishna Dalmia v. Justice S.R. Tendolkar, AIR 1958 SC 538 and
Budhan Choudhry v. State of Bihar, AIR 1955 SC 191, the author Jagdish Swarup in
his book Constitution of India (2nd Edn., 2006) stated the principles to be borne in
mind by the courts and detailed them as follows: (Ram Krishna Dalmia case, AIR pp.
547−48, para 11) “(a)**
(b) that there is always a presumption in favour of the constitutionality of an
enactment and the burden is upon him who attacks it to show that there has been a
clear transgression of the constitutional principles;
(c) that it must be presumed that the legislature understands and correctly
appreciates the need of its own people, that its laws are directed to problems made
manifest by experience and that its discriminations are based on adequate grounds;Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

(d)**
(e) that in order to sustain the presumption of constitutionality the court may take
into consideration matters of common knowledge, matters of common report, the
history of the times and may assume every state of facts which can be conceived
existing at the time of legislation; and
(f)**”
70. The petitioner has not shown which of the entry is not mandatory in the form. As the entries are
mandatory and sine qua non for undertaking a test/procedure, the assertion that their fundamental
rights are being violated by not providing requisite information is not germane and is without
substance.
71. The Act intends to prevent mischief of female foeticide and the declining sex ratio in India. When
such is the objective of the Act and the Rules and mischief which it seeks to prevent, violation of the
rights under Part III of the Constitution is not found. This Court in Hamdard Dawakhana v. The
Union of India, AIR 1960 SC 554, has laid down the following principles:
“8. Therefore, when the constitutionality of an enactment is challenged on the ground
of violation of any of the articles in Part III of the Constitution, the ascertainment of
its true nature and character becomes necessary i.e. its subject matter, the area in
which it is intended to operate, its purport and intent have to be determined. In order
to do so it is legitimate to take into consideration all the factors such as history of the
legislation, the purpose thereof, the surrounding circumstances and conditions, the
mischief which it intended to suppress, the remedy for the disease which the
legislature resolved to cure and the true reason for the remedy; Bengal Immunity co.
Ltd. v. State of Bihar, 1955− 2 SCR 603 at pp. 632, 633 ( (S) AIR 1955 SC 661 at
p.674);
R.M.D. Chamarbaughwala v. Union of India, 1957 SCR 930 at p. 936: ( (S) AIR 1957 SC 628 at
p.631); Mahant Moti Das v. S.P. Sahi, AIR 1959 SC 942 at p. 948.
9. Another principle which has to borne in mind in examining the constitutionality of a statute is
that it must be assumed that the legislature understands and appreciates the need of the people and
the laws it enacts are directed to problems which are made manifest by experience and that the
elected representatives assembled in a legislature enact laws which they consider to be reasonable
for the purpose for which they are enacted. Presumption is, therefore, in favour of the
constitutionality of an enactment. Charanjit Lal v. Union of India, 1950 SCR 869: (AIR 1951 SC 41);
State of Bombay v. F.N. Bulsara, 1951 SCR 682 at p. 708: (AIR 1951 SC 318 at p. 326); AIR 1959 SC
942.”
72. The mischief sought to be remedied is grave and the effort is being made to meet the challenge to
prevent the birth of the girl child. Whether Society should give preference to male child is a matterFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

of grave concern. The same is violative of Article 39A and ignores the mandate of Article 51A(e)
which casts a duty on citizens to renounce practices derogatory to the dignity of women. When sex
selection is prohibited by virtue of provisions of Section 6, the other interwoven provisions in the
Acts to prevent the mischief obviously their constitutionality is to be upheld.
73. The provisions of MTP Act came up for consideration before the High Court of Delhi in Raj
Bokaria v. Medical Council of India (W.P. (C) No.795 of 2010), it observed:
“11. On a reading of Section 5 of the MTP Act, it appears to this Court that the opinion
formed by the medical practitioner to go for either MTP or pre−term inducement of
labour when the pregnancy is beyond 20 weeks, has necessarily to be in writing and
in the prescribed format. There was no question of there not being any record
whatsoever of the forming of such opinion of the medical practitioner. The argument
advanced by Ms. Acharya that in a case of emergency there may be no time for
recording such opinion cannot explain the failure to record an opinion in the present
case. The facts narrated by the Petitioner herself show that a very conscious decision
was taken of going for a pre− term inducement of labour sometime around 6th
October 2003 when the deceased was admitted to Respondent No. 3 hospital.
Even at that time the opinion of the Petitioner should have been recorded. The pre−
term induced delivery took place on 8th October 2003. There was sufficient time,
therefore, for the Petitioner to record her opinion, mandatorily required by Section
5(1). In terms of Rule 3(1) of the Medical Termination of Pregnancy Regulations,
2003 the medical practitioner has to record her opinion in Form I. The non−
maintenance of records to show the basis on which an opinion was formed to going in
for a pre−term inducement in a case where the pregnancy is beyond the 20th week is
indeed a very serious lapse. There can be no excuse whatsoever for a medical
practitioner seeking to defend herself with reference to Section 5 of the MTP Act not
maintaining any record of the formation of the opinion in terms of Section 5(1) read
with the Regulations of 2003. In the considered view of this Court, the above factor
alone is enough to demonstrate the gross negligence on the part of the Petitioner.”
(emphasis supplied)
74. On behalf of petitioner−Society, reliance has been placed regarding mens rea on Arun Bhandari
v. State of Uttar Pradesh, (2013) 2 SCC 801, wherein the Court observed as under:
“22. In G.V. Rao v. L.H.V. Prasad,(2000) 3 SCC 693, this Court has held thus: (SCC
pp. 696−97, para 7) “7. As mentioned above, Section 415 has two parts. While in the
first part, the person must ‘dishonestly’ or ‘fraudulently’ induce the complainant to
deliver any property; in the second part, the person should intentionally induce the
complainant to do or omit to do a thing. That is to say, in the first part, inducement
must be dishonest or fraudulent. In the second part, the inducement should be
intentional. As observed by this Court in Jaswantrai Manilal Akhaney v. State of
Bombay, AIR 1956 SC 575, a guilty intention is an essential ingredient of the offenceFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

of cheating. In order, therefore, to secure conviction of a person for the offence of
cheating, ‘mens rea’ on the part of that person, must be established. It was also
observed in Mahadeo Prasad v. State of W.B., AIR 1954 SC 724, that in order to
constitute the offence of cheating, the intention to deceive should be in existence at
the time when the inducement was offered.” No sustenance can be drawn from the
aforesaid decision as keeping the information blank is definitely a violation of the Act
and very basic fundamental requisite for undertaking the test.
Thus, when form has not been filled up, obviously the act is dishonest, fraudulent and
can be termed intentional also. Such case cannot be classified into clerical error.
75. Reliance has also been placed on the decision of this Court in Dr. Subhash Kashinath Mahajan v.
State of Maharashtra, (2018) 6 SCC 454, in which this Court observed that the Court has to balance
the right of liberty of the accused guaranteed under Article 21, which could be taken away only by
just, fair and reasonable procedure and to check abuse of power by police and injustice to a citizen.
Thus, some filters were required to be incorporated to meet the mandate of Articles 14 and 21. The
substantive as well as procedural laws must conform to Articles 14 and 21. The expression procedure
established by law under Article 21 implies just, fair and reasonable procedure. The court to make
purposive interpretation and consider the doctrine of proportionality. This Court has observed thus:
“12. The learned Amicus submitted that under the scheme of the Atrocities Act,
several offences may solely depend upon the version of the complainant which may
not be found to be true. There may not be any other tangible material. One sided
version, before trial, cannot displace the presumption of innocence. Such version may
at times be self−serving and for extraneous reason. Jeopardising liberty of a person
on an untried unilateral version, without any verification or tangible material, is
against the fundamental rights guaranteed under the Constitution. Before liberty of a
person is taken away, there has to be fair, reasonable and just procedure. Referring to
Section 41(1)(b) CrPC it was submitted that arrest could be effected only if there was
“credible” information and only if the police officer had “reason to believe” that the
offence had been committed and that such arrest was necessary. Thus, the power of
arrest should be exercised only after complying with the safeguards intended under
Sections 41 and 41−A CrPC. It was submitted that the expression “reason to believe”
in Section 41 CrPC had to be read in the light of Section 26 IPC and judgments
interpreting the said expression. The said expression was not on a par with suspicion.
Reference has been made in this regard to Joti Parshad v. State of Haryana, 1993
Supp (2) SCC 497, Badan Singh v. State of U.P., 2001 SCC OnLine All 973, Adri
Dharan Das v. State of W.B., (2005) 4 SCC 303, Tata Chemicals Ltd. v. Commr. of
Customs, (2015) 11 SCC 628 and Ganga Saran & Sons (P) Ltd. v. CIT, (1981) 3 SCC
143. In the present context, to balance the right of liberty of the accused guaranteed
under Article 21, which could be taken away only by just, fair and reasonable
procedure and to check abuse of power by police and injustice to a citizen, exercise of
right of arrest was required to be suitably regulated by way of guidelines by this Court
under Article 32 read with Article 141 of the Constitution. Some filters were requiredFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

to be incorporated to meet the mandate of Articles 14 and 21 to strengthen the rule of
law.
*** *** ***
31. We may, at the outset, observe that jurisdiction of this Court to issue appropriate
orders or directions for enforcement of fundamental rights is a basic feature of the
Constitution. This Court, as the ultimate interpreter of the Constitution, has to
uphold the constitutional rights and values. Articles 14, 19 and 21 represent the
foundational values which form the basis of the rule of law. Contents of the said
rights have to be interpreted in a manner which enables the citizens to enjoy the said
rights. Right to equality and life and liberty have to be protected against any
unreasonable procedure, even if it is enacted by the legislature.
The substantive as well as procedural laws must conform to Articles 14 and 21. Any abrogation of the
said rights has to be nullified by this Court by appropriate orders or directions. Power of the
legislature has to be exercised consistent with the fundamental rights. Enforcement of a legislation
has also to be consistent with the fundamental rights. Undoubtedly, this Court has jurisdiction to
enforce the fundamental rights of life and liberty against any executive or legislative action. The
expression “procedure established by law” under Article 21 implies just, fair and reasonable
procedure.
*** *** ***
53. It is well settled that a statute is to be read in the context of the background and its object.
Instead of literal interpretation, the court may, in the present context, prefer purposive
interpretation to achieve the object of law. Doctrine of proportionality is well known for advancing
the object of Articles 14 and 21. A procedural penal provision affecting liberty of citizen must be read
consistent with the concept of fairness and reasonableness.” (emphasis supplied) No sustenance can
be drawn from aforesaid decision as the procedure under the Act is due procedure of law with the
safeguards of not only of appeals under Section 21 and Rule 19, but there is a State Supervisory
Board in Section 16A. The constitution of multi−member Appropriate Authority is provided in
Section 17(3)(a) and the Advisory Committee as provided in Section 17(6) which is again also a
multi−member Committee. The Advisory Committee has to aid and advise the Appropriate
Authority in discharge of its functions. Thus, internal safeguards are provided in the Act and the
Rules which conform to Articles 14 and 21.
76. Reliance has also been placed on Gian Kaur v. State of Punjab, (1996) 2 SCC 648, wherein this
Court dealt with the provisions of right to die within the ambit of Article 21. While discussing the
aforesaid, this Court has observed thus:
“43. This caution even in cases of physician−assisted suicide is sufficient to indicate
that assisted suicides outside that category have no rational basis to claim exclusion
of the fundamental principles of sanctity of life. The reasons assigned for attacking aFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

provision which penalises attempted suicide are not available to the abettor of suicide
or attempted suicide. Abetment of suicide or attempted suicide is a distinct offence
which is found enacted even in the law of the countries where attempted suicide is
not made punishable. Section 306 IPC enacts a distinct offence which can survive
independent of Section 309 in the IPC. The learned Attorney General as well as both
the learned amicus curiae rightly supported the constitutional validity of Section 306
IPC.” (emphasis supplied)
77. In Subramanian Swamy v. Union of India, (2016) 7 SCC 221, it was observed that restriction that
goes beyond the requirement of public interest cannot be considered as a reasonable restriction and
would be arbitrary. The same reasonableness is not a static concept. Articles 14 and 19 are part of
Article 21. Misuse of a provision or its possibility of abuse is no ground to declare Section 499 IPC as
unconstitutional. If a provision of law is misused or abused, it is for the Legislature to amend,
modify or repeal it. This Court has observed thus:
“9.3. Section 499 IPC ex facie infringes free speech and it is a serious inhibition on
the fundamental right conferred by Article 19(1)(a) and hence, cannot be regarded as
a reasonable restriction in a democratic republic. A restriction that goes beyond the
requirement of public interest cannot be considered as a reasonable restriction and
would be arbitrary. Additionally, when the provision even goes to the extent of
speaking of truth as an offence punishable with imprisonment, it deserves to be
declared unconstitutional, for it defeats the cherished value as enshrined under
Article 51−A(b) which is associated with the national struggle for freedom. The added
requirement of the accused having to prove that the statement made by him was for
the public good is unwarranted and travels beyond the limits of reasonableness
because the words “public good” are quite vague as they do not provide any objective
standard or norm or guidance as a consequence the provisions do not meet the test of
reasonable restriction and eventually they have the chilling effect on the freedom of
speech.
9.4. “Reasonableness” is not a static concept, and it may vary from time to time. What
is considered reasonable at one point of time may become arbitrary and
unreasonable at a subsequent point of time. The colonial law has become
unreasonable and arbitrary in independent India which is a sovereign, democratic
republic and it is a well−known concept that provisions once held to be reasonable,
become unreasonable with the passage of time.
*** *** *** 10.3. Reasonable restriction is founded on the principle of reasonableness
which is an essential facet of constitutional law and one of the structural principles of
the Constitution is that if the restriction invades and infringes the fundamental right
in an excessive manner, such a restriction cannot be treated to have passed the test of
reasonableness. The language employed in Sections 499 and 500 IPC is clearly
demonstrative of infringement in excess and hence, the provisions cannot be granted
the protection of Article 19(2) of the Constitution.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

Freedom of expression is quintessential to the sustenance of democracy which requires debate,
transparency and criticism and dissemination of information and the prosecution in criminal law
pertaining to defamation strikes at the very root of democracy, for it disallows the people to have
their intelligent judgment. The intent of the criminal law relating to defamation cannot be the lone
test to adjudge the constitutionality of the provisions and it is absolutely imperative to apply the
“effect doctrine” for the purpose of understanding its impact on the right of freedom of speech and
expression, and if it, in the ultimate eventuality, affects the sacrosanct right of freedom, it is ultra
vires. The basic concept of “effect doctrine” would not come in the category of exercise of power, that
is, use or abuse of power but in the compartment of direct effect and inevitable result of law that
abridges the fundamental right.
*** *** *** 17.2. Articles 14 and 19 have now been read to be a part of Article 21 and, therefore, any
interpretation of freedom of speech under Article 19(1)(a) which defeats the right to reputation
under Article 21 is untenable. The freedom of speech and expression under Article 19(1)(a) is not
absolute but is subject to constrictions under Article 19(2). Restrictions under Article 19(2) have
been imposed in the larger interests of the community to strike a proper balance between the liberty
guaranteed and the social interests specified under Article 19(2). One’s right must be exercised so as
not to come in direct conflict with the right of another citizen. The argument of the petitioners that
the criminal law of defamation cannot be justified by the right to reputation under Article 21
because one fundamental right cannot be abrogated to advance another, is not sustainable. It is
because (i) the right to reputation is not just embodied in Article 21 but also built in as a restriction
placed in Article 19(2) on the freedom of speech in Article 19(1)(a); and (ii) the right to reputation is
no less important a right than the right to freedom of speech.
*** *** *** 18.2. Misuse of a provision or its possibility of abuse is no ground to declare Section 499
IPC as unconstitutional. If a provision of law is misused or abused, it is for the legislature to amend,
modify or repeal it, if deemed necessary. Mere possibility of abuse of a provision cannot be a ground
for declaring a provision procedurally or substantively unreasonable.
*** *** ***
76. The submission is that Sections 499 and 500 IPC are not confined to defamation of the State or
its components but include defamation of any private person by another private person totally
unconnected with the State. In essence, the proponement is that the defamation of an individual by
another individual can be a civil wrong but it cannot be made a crime in the name of fundamental
right as protection of private rights qua private individuals cannot be conferred the status of
fundamental rights. If, argued the learned counsel, such a pedestal is given, it would be outside the
purview of Part III of the Constitution and run counter to Articles 14, 19 and 21 of the Constitution.
It is urged that defamation of a private person by another person is unconnected with the
fundamental right conferred in public interest by Article 19(1)(a); and a fundamental right is
enforceable against the State but cannot be invoked to serve a private interest of an individual.
Elucidating the same, it has been propounded that defamation of a private person by another person
cannot be regarded as a “crime” under the constitutional framework and hence, what is permissible
is the civil wrong and the remedy under the civil law. Section 499 IPC, which stipulates defamationFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

of a private person by another individual, has no nexus with the fundamental right conferred under
Article 19(1)(a) of the Constitution, for Article 19(2) is meant to include the public interest and not
that of an individual and, therefore, the said constitutional provision cannot be the source of
criminal defamation. This argument is built up on two grounds: (i) the common thread that runs
through the various grounds engrafted under Article 19(2) is relatable to the protection of the
interest of the State and the public in general and the word “defamation” has to be understood in the
said context, and (ii) the principle of noscitur a sociis, when applied, “defamation” remotely cannot
assume the character of public interest or interest of the crime inasmuch a crime remotely has
nothing to do with the same.
*** *** ***
90. In R. Sai Bharathi v. J. Jayalalitha, (2004) 2 SCC 9, while opining about crime, it has been
observed as under: (SCC pp. 54− 55, para 56) “56. Crime is applied to those acts, which are against
social order and are worthy of serious condemnation. Garafalo, an eminent criminologist, defined “
crime” in terms of immoral and anti−social acts. He says that:
‘crime is an immoral and harmful act that is regarded as criminal by public opinion
because it is an injury to so much of the moral sense as is possessed by a community
— a measure which is indispensable for the adaptation of the individual to society’.
The authors of the Indian Penal Code stated that:
‘… We cannot admit that a Penal Code is by any means to be considered as a body of
ethics, that the legislature ought to punish acts merely because those acts are
immoral, or that, because an act is not punished at all, it follows that the legislature
considers that act as innocent. Many things which are not punishable are morally
worse than many things which are punishable. The man who treats a generous
benefactor with gross ingratitude and insolence deserves more severe reprehension
than the man who aims a blow in passion, or breaks a window in a frolic; yet we have
punishment for assault and mischief, and none for ingratitude. The rich man who
refuses a mouthful of rice to save a fellow creature from death may be a far worse
man than the starving wretch who snatches and devours the rice; yet we punish the
latter for theft, and we do not punish the former for hard−heartedness.’” *** *** ***
96. We have referred to this facet only to show that the submission so astutely
canvassed by the learned counsel for the petitioners that treating defamation as a
criminal offence can have no public interest and thereby it does not serve any social
interest or collective value is sans substratum. We may hasten to clarify that creation
of an offence may be for some different reason declared unconstitutional but it
cannot be stated that the legislature cannot have a law to constitute an act or
omission done by a person against the other as a crime. It depends on the legislative
wisdom. Needless to say, such wisdom has to be in accord with constitutional wisdom
and pass the test of constitutional challenge. If the law enacted is inconsistent withFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

the constitutional provisions, it is the duty of the Court to test the law on the
touchstone of the Constitution.
*** *** ***
122. In State of Madras v. V.G. Row, AIR 1952 SC 196, the Court has ruled that the
test of reasonableness, wherever prescribed, should be applied to each individual
statute impugned and no abstract standard, or general pattern of reasonableness can
be laid down as applicable to all cases. The nature of the right alleged to have been
infringed, the underlying purpose of the restrictions imposed, the extent and urgency
of the evil sought to be remedied thereby, the disproportion of the imposition, the
prevailing conditions at the time, should all enter into the judicial verdict.
*** *** ***
127. In Sahara India Real Estate Corpn. Ltd. v. SEBI, (2012) 10 SCC 603, this Court
reiterated the principle of social interest in the context of Article 19(2) as a facet of
reasonable restriction. In Dwarka Prasad Laxmi Narain v. State of U.P., AIR 1954 SC
224, while deliberating upon “reasonable restriction” observed that it connotes that
the limitation imposed upon a person in enjoyment of a right should not be arbitrary
or of an excessive nature beyond what is required in the interest of the public. It was
also observed that to achieve quality of reasonableness a proper balance between the
freedom guaranteed under Article 19(1)( g) and the social control permitted by clause
(6) of Article 19 has to be struck.” (emphasis supplied) When we consider the
aforesaid dictum and apply to the Act, nothing can be more sinister, immoral and
anti−social act allowing female foeticide. In R. Sai Bharathi v. J. Jayalalitha (supra) it
has been observed that crime is against social order, immoral and harmful act. It has
also been observed by this Court that legislature can have a law to constitute an act or
omission done by a person against the other as a crime.
Considering the evils sought to be remedied it cannot be said that the imposition in the Act in
question is disproportionate. The restrictions and the provisions of punishment have close nexus
with the object sought to be achieved. It is not possible to term action as merely clerical one as that
is pre−requisite for the test/procedure and that is what is intended by the Act, if it is given a go−bye
under the guise of clerical error, the Act would be rendered otiose. Restriction cannot be said to be
excessive and beyond what is required in the public interest, they cater to the felt need of the society
and the complex issues facing people which the legislature intends to solve.
78. In Shreya Singhal v. Union of India, (2015) 5 SCC 1, the Court dealt with provisions of Section
66−A of Information Technology Act, 2000. This Court has observed thus:
55. The US Supreme Court has repeatedly held in a series of judgments that where no
reasonable standards are laid down to define guilt in a section which creates an
offence, and where no clear guidance is given to either law abiding citizens or toFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

authorities and courts, a section which creates an offence and which is vague must be
struck down as being arbitrary and unreasonable. Thus, in Musser v. Utah, 92 L Ed
562 a Utah statute which outlawed conspiracy to commit acts injurious to public
morals was struck down.
*** *** ***
59. It was further held that a penal law is void for vagueness if it fails to define the
criminal offence with sufficient definiteness.
Ordinary people should be able to understand what conduct is prohibited and what is permitted.
Also, those who administer the law must know what offence has been committed so that arbitrary
and discriminatory enforcement of the law does not take place.
*** *** ***
66. In Federal Communications Commission v. Fox Television Stations Inc., 132 S Ct 2307 it was
held: (S Ct p. 2317) “A fundamental principle in our legal system is that laws which regulate persons
or entities must give fair notice of conduct that is forbidden or required. See Connally v. General
Construction Co., 269 US 385, US 391 (“[A] statute which either forbids or requires the doing of an
act in terms so vague that men of common intelligence must necessarily guess at its meaning and
differ as to its application, violates the first essential of due process of law”); Papachristou v.
Jacksonville, 405 US 156, US 162 {“Living under a rule of law entails various suppositions, one of
which is that ‘[all persons] are entitled to be informed as to what the State commands or forbids’”
[quoting Lanzetta v. New Jersey, 306 US 451, US 453 (alteration in original)]}. This requirement of
clarity in regulation is essential to the protections provided by the Due Process Clause of the Fifth
Amendment. See United States v. Williams, 553 US 285, US 304. It requires the invalidation of laws
that are impermissibly vague. A conviction or punishment fails to comply with due process if the
statute or regulation under which it is obtained “fails to provide a person of ordinary intelligence fair
notice of what is prohibited, or is so standardless that it authorizes or encourages seriously
discriminatory enforcement.” Ibid. As this Court has explained, a regulation is not vague because it
may at times be difficult to prove an incriminating fact but rather because it is unclear as to what
fact must be proved. See id., at
306. Even when speech is not at issue, the void for vagueness doctrine addresses at least two
connected but discrete due process concerns: first, that regulated parties should know what is
required of them so they may act accordingly; second, precision and guidance are necessary so that
those enforcing the law do not act in an arbitrary or discriminatory way. See Grayned v. Rockford,
33 L Ed 2d 222, US 108−109. When speech is involved, rigorous adherence to those requirements is
necessary to ensure that ambiguity does not chill protected speech.”” (emphasis supplied) It is
apparent from the aforesaid discussion in Shreya Singhal (supra) in a case where no reasonable
standards are laid down to define guilt in a section which creates an offence, it would be arbitrary
and unconstitutional. It is absolutely clear that the provisions in the Act in question cannot be
termed as arbitrary or illegal or unreasonable. The provisions are not vague. A responsible doctor isFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

supposed to know before undertaking such pre−natal diagnostic test etc. what is he undertaking and
what his responsibilities are. If he cannot understand the form he is required to fill and the impact
of medical findings and its consequences which is virtually the pre− requisite for undertaking a test,
he is not fit to be a member of a noble medical profession. Such culpable negligence is not warranted
from a doctor. It is crystal clear from the provisions of the Act which can be gathered by a person of
ordinary intelligence and they can have fair notice of what is prohibited and what omission they
should not make. The principles deliberated upon in Shreya Singhal (supra) rather supports the
constitutionality of the Act and the Rules framed thereunder.
79. The reliance has also been placed by the petitioner in Nikesh Tarachand Shah v. Union of India,
(2018) 11 SCC 1, in which Court observed thus:
“10. On the other hand, the learned Attorney General Shri K.K. Venugopal impressed
upon us the fact that the Parliamentary legislation qua money laundering is an
attempt by Parliament to get back money which has been siphoned off from the
economy. According to the learned Attorney General, scheduled offences and
offences under Sections 3 and 4 of the 2002 Act have to be read together and the said
Act, therefore, forms a complete code which must be looked at by itself. According to
the learned Attorney General, it is well settled that classification which is punishment
centric has been upheld by a catena of judgments and so have the twin conditions
been upheld by various decisions which were referred to by him. According to him,
the expression “any offence” in Section 45(1)(ii) would mean offence of a like nature
and not any offence, which would include a traffic offence as well. According to the
learned Attorney General, Section 45 can easily be read down to make it
constitutional in two ways. First, the expression “there are reasonable grounds for
believing that he is not guilty of such offence” must be read as the making of a prima
facie assessment by the court of reasonable guilt. Secondly, according to the learned
Attorney General, in any case the conditions contained in Section 45(1)(ii) are there
in a different form when bail is granted ordinarily insofar as offences generally are
concerned and he referred to State of U.P. v. Amarmani Tripathi, (2005) 8 SCC 21 for
this purpose. According to the learned Attorney General, if harmoniously construed
with the rest of the Act, Section 45 is unassailable. He relied upon Section 24 of the
Act, which inverts the burden of proof, and strongly relied upon Gautam Kundu v.
Directorate of Enforcement, (2015) 16 SCC 1 and Rohit Tandon v. Directorate of
Enforcement, (2018) 11 SCC 46. In answer to Shri Rohatgi’s argument on the object
of the 2012 Amendment Act, according to the learned Attorney General, it is well
settled that where the language of the Act is plain, no recourse can be taken to the
object of the Act and he cited a number of judgments for this proposition. He referred
us to Section 106 of the Evidence Act, 1872 and argued that when read with Section
24 of the 2002 Act, it would be clear that the twin conditions contained in Section 45
are only in furtherance of the object of unearthing black money and that we should,
therefore, be very slow to set at liberty persons who are alleged offenders of the
cancer of money laundering. Ultimately, according to the learned Attorney General,
Section 45 being part of a complete code must be upheld in order that the 2002 ActFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

work, so that money that is laundered comes back into the economy and persons
responsible for the same are brought to book.
*** *** ***
46. We must not forget that Section 45 is a drastic provision which turns on its head
the presumption of innocence which is fundamental to a person accused of any
offence. Before application of a section which makes drastic inroads into the
fundamental right of personal liberty guaranteed by Article 21 of the Constitution of
India, we must be doubly sure that such provision furthers a compelling State
interest for tackling serious crime. Absent any such compelling State interest, the
indiscriminate application of the provisions of Section 45 will certainly violate Article
21 of the Constitution. Provisions akin to Section 45 have only been upheld on the
ground that there is a compelling State interest in tackling crimes of an extremely
heinous nature.
*** *** ***
49. The learned Attorney General relied heavily on Section 24 of the 2002 Act to
show that the burden of proof in any proceeding relating to proceeds of crime is upon
the person charged with the offence of money laundering, and in the case of any other
person i.e. a person not charged with such offence, the court may presume that such
proceeds are involved in money laundering. Section 45 of the Act only speaks of the
scheduled offence in Part A of the Schedule, whereas Section 24 speaks of the offence
of money laundering, and raises a presumption against the person prosecuted for the
crime of money laundering. This presumption has no application to the scheduled
offence mentioned in Section 45, and cannot, therefore, advance the case of the
Union of India.” (emphasis supplied) Considering the compelling general public
interest and gender justice and declining sex ratio, we have no hesitation in
upholding the validity of the provisions of Section 23(1) of the Act.
80. Reliance has also been placed in P. Rathinam v. Union of India, (1994) 3 SCC 394, this Court
observed thus:
48. The aforesaid show that law has many promises to keep including granting of so
much of liberty as would not jeopardise the interest of another or would affect him
adversely, i.e., allowing of stretching of arm up to that point where the other fellow’s
nose does not begin. For this purpose, law may have “miles to go”. Then, law cannot
be cruel, which it would be because of what is being stated later, if persons
attempting suicide are treated as criminals and are prosecuted to get them punished,
whereas what they need is psychiatric treatment, because suicide basically is a “call
for help”, as stated by Dr (Mrs) Dastoor, a Bombay Psychiatrist, who heads an
organisation called “Suicide Prevent”. May it be reminded that a law which is cruel
violates Article 21 of the Constitution, a la, Deena v.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

Union of India, (1983) 4 SCC 645.
*** *** ***
51. A crime presents these characteristics: (1) it is a harm, brought about by human conduct which
the sovereign power in the State desires to prevent; (2) among the measures of prevention selected
is the threat of punishment; and (3) legal proceedings of a special kind are employed to decide
whether the person accused did in fact cause the harm, and is, according to law, to be held legally
punishable for doing so. (See pp. 1 to 5 of Kenny’s Outlines of Criminal Law, 19th Edn., for the above
propositions.) (emphasis supplied)
81. We find that Act intends not to jeopardise the female foetus. As such curtailment of the liberty in
cause of such a violation cannot be said to be disproportionate.
82. Reliance has also been placed on State of Uttar Pradesh v. Wasif Haider, (2019) 2 SCC 303, in
which it has been laid down that an offence has to be proved beyond reasonable doubt. The relevant
portion of the decision is extracted hereunder:
“22. In the instant appeals before us, the prosecution has failed to link the chain of
circumstances so as to dispel the cloud of doubt about the culpability of the
respondent−accused. It is a well−settled principle that a suspicion, however grave it
may be cannot take place of proof i.e. there is a long distance between "may be" and
"must be", which must be traversed by the prosecution to prove its case beyond
reasonable doubt [See Narendra Singh v. State of M.P., (2004) 10 SCC 699].” There is
no dispute with the aforesaid proposition, but that is not the question before us.
When trial takes place obviously the commission of the offence has to be proved as
required under the relevant applicable law.
83. There can be a legislative provision for imposing burden of proof in reverse order relating to
gender justice. In the light of prevalent violence against women and children, the Legislature has
enacted various Acts, and amended existing statutes, reversing the traditional burden of proof.
Some examples of reversed burden of proof in statutes include Sections 29 and 30 of the Protection
of Children from Sexual Offences (POCSO) Act in which there is presumption regarding commission
and abetment of certain offences under the Act, and presumption of mental state of the accused
respectively. In Sections 113−A and 113−B of the Indian Evidence Act there is presumption
regarding abetment of suicide and dowry death, and in Section 114−A of the Indian Evidence Act
there is presumption of absence of consent of prosecutrix in offence of rape.
84. These provisions are a clear indication of the seriousness with which crimes against women and
children have been viewed by the Legislature. It is also evident from these provisions that due to the
pervasive nature of these crimes, the Legislature has deemed it fit to employ a reversed burden of
proof in these cases. The presumption in the proviso to Section 4(3) of the Act has to be viewed in
this light.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

85. The Act is a social welfare legislation, which was conceived in light of the skewed sex−ratio of
India and to avoid the consequences of the same. A skewed sex−ratio is likely to lead to greater
incidences of violence against women and increase in practices of trafficking, ‘bride−buying’ etc. The
rigorous implementation of the Act is an edifice on which rests the task of saving the girl child.
86. In view of the aforesaid discussion and in our opinion, no case is made out to hold that
deficiency in maintaining the record mandated by Sections 5, 6 and the proviso to Section 4(3)
cannot be diluted as the aforesaid provisions have been incorporated in various columns of the
Form ‘F’ and as already held that it would not be a case clerical mistake but absence of sine qua non
for undertaking a diagnostic test/procedure. It cannot be said to be a case of clerical or technical
lapse. Section 23(1) need not have provided for gradation of offence once offence is of non−
maintenance of the record, maintenance of which itself intend to prevent female foeticide. It need
not have graded offence any further difference is so blur it would not be possible to prevent crime.
There need not have been any gradation of offence on the basis of actual determination of sex and
non−maintenance of record as undertaking the test without the pre−requisites is totally prohibited
under the Act. The non− maintenance of record is very foundation of offence. For first and second
offences, gradation has been made which is quite reasonable.
87. Provisions of Section 23(2) has also been attacked on the ground that suspension on framing the
charges should not be on the basis of clerical mistake, inadvertent clerical lapses. As we found it is
not what is suggested to be clerical or technical lapse nor it can be said to be inadvertent mistakes as
existence of the particular medical condition is mandated by Sections 4 and 5 including the age etc.
Thus, suspension on framing of charges cannot be said to be unwarranted. The same intends to
prevent mischief. We are not going into the minutes what can be treated as a simple clerical mistake
that has to be seen case wise and no categorization can be made of such mistakes, if any, but with
respect to what is mandatory to be provided in the Form as per provisions of various sections has to
be clearly mentioned, it cannot be kept vague, obscure or blank as it is necessary for undertaking
requisite tests, investigations and procedures. There are internal safeguards in the Act under the
provisions relating to appeal, the Supervisory Board as well as the Appropriate Authority, its
Advisory Committee and we find that the provisions cannot be said to be suffering from any vice as
framing of the charges would mean prima facie case has been found by the Court and in that case,
suspension cannot be said to be unwarranted.
88. It was also prayed that action should be taken under Section 20 after show cause notice and
reasonable opportunity of being heard. There is already a provision in Section 20(1) to issue a show
cause and in Section 20(2) contains the provision as to reasonable opportunity of being heard. Thus,
we find no infirmity in the aforesaid provision.
89. There also the Appropriate Authority to consider each case on merits with the help of Advisory
Body which has legal expert. The Advisory Committee consists of one legal expert which has to aid
and advise the Appropriate Authority as provided in Sections 16 and 17(5)(6). Thus, the submission
that legal advice should be taken before prosecution, in view of the provisions, has no legs to stand.Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

90. It was also contended that action of seizure of ultrasonography machine and sealing the
premises cannot be said to be appropriate. The submission is too tenuous and liable to be rejected.
Section 30 of the Act enumerates the power of search and seizure and Rules 11 and 12 of the Rules
provide for the power of the Appropriate Authority to seal equipment, inspect premises and conduct
search and seizure. It was pointed out by the respondents that a “Standard Operational Procedure”,
detailing the procedure for search and seizure has been developed by the Ministry of Health and
Family Welfare. Further, regular training of Appropriate Authorities is being carried out at both the
National and State level. All the States have also been directed to develop online MIS for monitoring
the implementation of the Act. It is settled proposition that when offence is found to be committed,
there can be seizure and sealing of the premises and equipment during trial as no license can be
given to go on committing the offence. Such provisions of seizure/sealing, pending trial are to be
found invariably in various penal legislations. The impugned provisions contained in the Act
constitute reasonable restrictions to carry on any profession which cannot be said to be violative of
Right to Equality enshrined under Article 14 or right to practise any profession under Article
19(1)(g). Considering the Fundamental Duties under Article 51A(e) and considering that female
foeticide is most inhumane act and results in reduction in sex ratio, such provisions cannot be said
to be illegal and arbitrary in any manner besides there are various safeguards provided in the Act to
prevent arbitrary actions as discussed above.
91. In light of the nature of offences which necessitated the enactment of the Act and the grave
consequences that would ensue otherwise, suspension of registration under Section 23(2) of the Act
serves as a deterrent. The individual cases cited by the petitioner−Society cannot be a ground for
passing blanket directions, and the individuals have remedies under the law which they can avail.
Moreover, the concept of double jeopardy would have no application here, as it provides that a
person shall not be convicted of the same offence twice, which is demonstrably not the case here.
Suspension is a step−in−aid to further the intendment of act. It cannot be said to be double
punishment. In case an employee is convicted for an offence, he cannot continue in service which
can be termed to be double jeopardy.
92. Non maintenance of record is spring board for commission of offence of foeticide, not just a
clerical error. In order to effectively implement the various provisions of the Act, the detailed forms
in which records have to be maintained have been provided for by the Rules. These Rules are
necessary for the implementation of the Act and improper maintenance of such record amounts to
violation of provisions of Sections 5 and 6 of the Act, by virtue of proviso to Section 4(3) of the Act.
In addition, any breach of the provisions of the Act or its Rules would attract cancellation or
suspension of registration of Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic, by
the Appropriate Authority as provided under Section 20 of the Act.
93. There is no substance in the submission that provision of Section 4(3) be read down. By virtue of
the proviso to Section 4(3), a person conducting ultrasonography on a pregnant woman, is required
to keep complete record of the same in the prescribed manner and any deficiency or inaccuracy in
the same amounts to contravention of Section 5 or Section 6 of the Act, unless the contrary is proved
by the person conducting the said ultrasonography. The aforementioned proviso to Section 4(3)
reflects the importance of records in such cases, as they are often the only source to ensure that anFederation Of Obstetrics And ... vs Union Of India on 3 May, 2019

establishment is not engaged in sex−determination.
94. Section 23 of the Act, which provides for penalties of offences, acts in aid of the other Sections of
the Act is quite reasonable. It provides for punishment for any medical geneticist, gynecologist,
registered medical practitioner or a person who owns a Genetic Counselling Centre, a Genetic Clinic
or a Genetic Laboratory, and renders his professional or technical services to or at said place,
whether on honorarium basis or otherwise and contravenes any provisions of the Act, or the Rules
under it.
95. Therefore, dilution of the provisions of the Act or the Rules would only defeat the purpose of the
Act to prevent female foeticide, and relegate the right to life of the girl child under Article 21 of the
Constitution, to a mere formality.
96. In view of the above, no case is made out for striking down the proviso to Section 4(3),
provisions of Sections 23(1), 23(2) or to read down Section 20 or 30 of the Act. Complete contents of
Form ‘F’ are held to be mandatory. Thus, the writ petition is dismissed. No costs.
.……......................J. (Arun Mishra) .……......................J. (Vineet Saran) New Delhi;
May 03, 2019Federation Of Obstetrics And ... vs Union Of India on 3 May, 2019

