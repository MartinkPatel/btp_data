Balaji @ Loduku Balaji @ Woodwharf ... vs The State Of Tamil
Nadu on 4 July, 2023
Author: M.Sundar
Bench: M.Sundar
                                                                                           H.C.P.No.630 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                     DATED: 04.07.2023
                                                            Coram
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                       and
                                      THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                    H.C.P.No.630 of 2023
                     Balaji @ Loduku Balaji @ Woodwharf Balaji                                .. Petitioner
                                                              vs
                     1.The State of Tamil Nadu
                       Rep. by its Secretary to Government,
                       Prohibition and Excise Department,
                       Secretariat, Chennai – 600 009.
                     2.The Commissioner of Police,
                       Greater Chennai, Chennai.
                     3.The Inspector of Police,
                       C3, Seven Wells Police Station, Chennai.
                     4.The Superintendent,
                       Central Prison, Puzhal, Chennai.                               ..     Respondents
                                  Petition filed under Article 226 of the Constitution of India
                     praying for issuance of a writ of habeas corpus to call for the entire
                     records relating to the petitioner's detention under Tamil Nadu Act
                     14 of 1982 vide detention order, dated 30.12.2022 on the file of the
                     second            respondent         herein    made         in           proceedings
                     No.494/BCDFGISSSV/2022 and quash the same as illegal and
                     consequently          direct   the   respondents   herein    to        produce       the
                     petitioner namely Balaji @ Loduku Balaji @ Woodwhard Balaji, agedBalaji @ Loduku Balaji @ Woodwharf ... vs The State Of Tamil Nadu on 4 July, 2023

https://www.mhc.tn.gov.in/judis
                     1/8
                                                                                      H.C.P.No.630 of 2023
                     37 years, son of Sagayam, before this Court and set him at liberty,
                     now petitioner detained at Central Prison, Puzhal, Chennai - 66.
                                  For Petitioner           :      Mr.C.C.Chellappan
                                  For Respondents          :      Mr.E.Raj Thilak,
                                                                  Additional Public Prosecutor
                                                          ORDER
[Order of the Court was made by M.SUNDAR, J.] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
20.04.2023, this Court made the following order:
'Captioned Habeas Corpus Petition has been filed in this Court on 12.04.2023 inter
alia assailing a detention order dated 30.12.2022 bearing reference
No.494/BCDFGISSSV/2022 made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience and clarity]. To be noted, third respondent is
the Sponsoring Authority.
2. Detenu is the petitioner.
3. Learned counsel for petitioner submits that ground case qua the detenu is for alleged offences
under Sections 341, 294(b), 336, 427, 392 read with 397, 506(ii) of 'The Indian Penal Code (45 of
1860)' [hereinafter 'IPC' for the sake of convenience and clarity] in Crime No.319 of 2022 on the file
of C3 Seven Wells Police Station.
4. The aforementioned detention order has been made on the premise that the detenu is a 'Goonda'
under Section 2(f) of 'The Tamil Nadu Prevention of Dangerous Activities of Bootleggers, Cyber law
offenders, Drug- offenders, Forest-offenders, Goondas, Immoral traffic
https://www.mhc.tn.gov.in/judis offenders, Sand-offenders, Sexual-offenders, Slum- grabbers and
Video Pirates Act, 1982 (Tamil Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of
convenience and clarity].
5. The detention order has been assailed inter alia on the ground that non-furnishing of correct
Tamil translation of remand orders in Crime Nos.272/2022, 293/2022, 305/2022 and 319/2022 to
the detenu which prevented the detenu from making an effective representation.
6. Prima facie case made out for admission. Admit. Issue Rule nisi returnable by four weeks.Balaji @ Loduku Balaji @ Woodwharf ... vs The State Of Tamil Nadu on 4 July, 2023

7. Mr.R.Muniyapparaj, learned Additional Public Prosecutor, State of Tamil Nadu accepts notice for
all respondents. List the captioned Habeas Corpus Petition accordingly.'
2. The aforementioned order made in the 20.04.2023 Admission listing shall be read as an integral
part and parcel of this order which means that the short forms, short references and abbreviations
used in the order in the Admission listing shall be used in the instant order also.
3. There are six adverse cases. The ground case which constitutes substantial part of substratum of
the impugned detention order is Crime No.319 of 2022 on the file of C3 Seven Wells Police Station
for the alleged offences under Sections 341, 294(b), 336, 427, 392 r/w 397, 506(ii) IPC. Owing to the
nature of the challenge to the impugned detention order, it is not necessary to delve into the factual
matrix or be detained further by facts. https://www.mhc.tn.gov.in/judis
4. Mr.C.C.Chellappan, learned counsel on record for petitioner and Mr.E.Raj Thilak, learned State
Additional Public Prosecutor for all respondents are before us.
5. In the support affidavit qua captioned HCP several grounds have been raised but in the final
hearing today, learned counsel for petitioner pivoted his campaign against the impugned detention
order on one point and that one point turns on incorrect/improper translation. The remand order
pertaining to ground case at page No.343 of the grounds booklet says 'investigation pending, legal
aid explained' whereas in the Tamil translation at page No.345 of the grounds booklet, both are
absent. The remand order in English and Tamil read as follows:
'English Version:
Accused produced before me on 25.11.2022 at 21.00 hours. No complaints against
police. Grounds of arrest and legal aid explained. Arrest informed.
Copy of Arrest Memo furnished to accused. Remand reason being satisfactory remanded to judicial
custody till 09.12.2022.' 'Tamil Version:
25/11/2022 Mk; njjp 21/00 kzpf;F vjphp M$h;gLj;jg;gl;lhh;/ g[yd; tprhuiz epYitapy;
cs;sJ/ milg;g[ fhtYf;fhd fhuz';fs; tpsf;fg;gl;ld/ Jd;g[Wj;jg;gl;ljhf g[fhh; vJt[k; ,y;iy/
09/12/2022 tiu ePjpkd;w fhtYf;F cl;gLj;jg;gl;lhh;/'
6. We had the benefit of perusing the grounds booklet served https://www.mhc.tn.gov.in/judis on
the detenu. As pointed out by learned counsel for petitioner, the words 'investigation pending' are
absent in Tamil translation. Likewise, the words 'legal aid explained' are also absent in Tamil
translation. These are only illustratives and we find that there are multiple errors in the Tamil
translation.
7. We are informed that the detenu is unlettered and the detenu has affixed his Left Thumb
Impression (LTI) in the grounds of impugned preventive detention order.Balaji @ Loduku Balaji @ Woodwharf ... vs The State Of Tamil Nadu on 4 July, 2023

8. In this view of the matter, we find that flaw in the translation is very serious and it certainly
affects the rights of the detenu to make an effective representation which are rights and
constitutional safeguard enshrined in Article 22(5) of the Constitution of India. We remind
ourselves of Powanammal case which also on facts arose out of the preventive detention case. In
Powanammal case in similar circumstances i.e., similar fact situation, Honourable Supreme Court
addressed to itself the issue of providing a detenu with translated copies in a language in which the
detenu is conversant with and answered the same interalia by saying that it is imperative and not
providing translated copy in a language which the detenu is conversant with vitiates preventive
https://www.mhc.tn.gov.in/judis detention. Powanammal case i.e., Powanammal Vs. State of Tamil
Nadu is reported in (1999) 2 SCC 413 and the relevant paragraphs wherein the question which the
Honourable Supreme Court addressed to itself and the manner in which the question was answered
are paragraphs 6 and 16 which read as follows:
'6. The short question that falls for our consideration is whether failure to supply the
Tamil version of the order of remand passed in English, a language not known to the
detenue, would vitiate her further detention.
16. For the above reasons, in our view, the non-supply of the Tamil version of the
English document, on the facts and in the circumstances, renders her continued
detention illegal. We, therefore, direct that the detenue be set free forthwith unless
she is required to be detained in any other case. The appeal is accordingly allowed. '
9. Applying Powanammal principle, we have no hesitation in saying that the impugned detention
order in the case on hand deserves to be dislodged.
10. Ergo, the sequitur is, captioned HCP is allowed. Impugned detention order dated 30.12.2022
bearing reference No.494/BCDFGISSSV/2022 made by the second respondent is set
https://www.mhc.tn.gov.in/judis aside and the detenu Thiru.Balaji @ Loduku Balaji @ Woodwharf
Balaji, aged 37 years, son of Thiru.Sagayam, is directed to be set at liberty forthwith, if not required
in connection with any other case / cases. There shall be no order as to costs.
(M.S.,J.) (R.S.V.,J.) 04.07.2023 Index : Yes/No Neutral Citation : Yes/No mmi P.S: Registry to
forthwith communicate this order to Jail authorities in Central Prison, Puzhal, Chennai - 66. To
1.The Secretary to Government, Prohibition and Excise Department, Secretariat, Chennai – 600
009.
2.The Commissioner of Police, Greater Chennai, Chennai.
3.The Inspector of Police, C3, Seven Wells Police Station, Chennai.
4.The Superintendent, Central Prison, Puzhal, Chennai.
5.The Public Prosecutor, High Court, Madras.Balaji @ Loduku Balaji @ Woodwharf ... vs The State Of Tamil Nadu on 4 July, 2023

https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL , J., mmi 04.07.2023
https://www.mhc.tn.gov.in/judisBalaji @ Loduku Balaji @ Woodwharf ... vs The State Of Tamil Nadu on 4 July, 2023

