Bihar Electricity Grid Code, 2010
BIHAR
India
Bihar Electricity Grid Code, 2010
Rule BIHAR-ELECTRICITY-GRID-CODE-2010 of 2010
Published on 23 July 2010• 
Commenced on 23 July 2010• 
[This is the version of this document from 23 July 2010.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Electricity Grid Code, 2010Published vide Notification No. BERC/Regl-1/2009 02-238, dated
23.07.2010Last Updated 26th December, 2019Notification No. BERC/Regl-1/2009 02-238. - In
exercise of powers conferred under Section 181 read with Clause (h) sub-section (1) of Section 86 of
the Electricity Act, 2003 and all powers enabling it on that behalf, the Bihar Electricity Regulatory
Commission hereby specifies the following Grid Code to be known as Bihar Electricity Grid Code,
2010 which shall come into force from the date of notification.This Grid Code is applicable for the
grids in the State of Bihar only.
1. Introduction.
- 1.1. (1) The Grid Code lays down the Rules, Guidelines and Standards to be followed by all Users of
Grid in the State of Bihar to plan, develop, operate and maintain the power system in the State in
the most efficient, reliable, economic and secure manner in integration with the Eastern Regional
Grid as per the provisions of Indian Electricity Grid Code (IEGC) notified by the Central Electricity
Regulatory Commission (CERC) from time to time.(2)In terms of Section 39(1) of the Electricity Act
2003, the State Government is required to notify the Board or a Government Company as State
Transmission Utility (STU). State Government has notified the Bihar State Electricity Board (BSEB)
as the State Transmission Utility (STU) which is a deemed licensee at present in terms of Section
172 of the Electricity Act, 2003.(3)As per Section 39(2) of the Electricity Act, 2003 the functions of
State Transmission Utility are as follows(a)to undertake transmission of energy through the
Intra-State Transmission System(b)to discharge all functions of planning and coordination relating
to Intra-State Transmission System with(i)Central Transmission Utility;(ii)State
Governments;(iii)Generating Companies;(iv)Regional Power
Committee;(v)Authority;(vi)Licensees;(vii)Any other person notified by the State Government in
this behalf(c)to ensure development of an efficient, coordinated and economical system of
intra-state transmission lines for smooth flow of electricity from a generating station to load
centres;(d)to provide non-discriminatory open access to its transmission system for use by -(i)any
licensee or generating company on payment of the transmission charges;(ii)any consumer as andBihar Electricity Grid Code, 2010

when such open access is provided by the State Commission under sub-section (2) of Section 42, on
payment of the transmission charges and a surcharge thereon, as may be specified by the State
Commission.(4)STU shall not engage in the business of trading of electricity.(5)As per the Section 31
of Electricity Act, 2003, the State Government shall establish a centre to be known as the State Load
Despatch Centre (SLDC) and the State Load Despatch Centre shall be operated by a Government
company or any authority or corporation established or constituted by or under any State Act, as
may be notified by the State Government. Until a Government Company or any Authority or
Corporation is notified by the State Government, the State Transmission Utility shall operate the
State Load Despatch Centre, which shall:(a)be responsible for optimum scheduling and despatch of
electricity within a State, in accordance with the contracts entered into with the licensees or the
generating companies operating in that State;(b)monitor the grid operations;(c)keep accounts for
the quantity of electricity transmitted through the State Grid;(d)exercise supervision and control
over the Intra State Transmission system;(e)be responsible for carrying out real time operations for
grid control and despatch of electricity within the State through secure and economic operation of
the State Grid in accordance with the Grid Standards and the State Grid Code.(6)The SLDC and
licensees shall comply with; the directions of Regional Load Despatch Centre in connection with
integrated grid operation of the power system or in regard to matter which may affect the operation
of the Inter State Transmission System.(7)SLDC shall not engage in the business of trading of
electricity.1.2Objective. - The Grid Code is designed to facilitate the development, operation
maintenance and planning of an efficient, coordinated and economical power grid by specifying
principles and procedures for STU and all the Users connected to that system. It seeks to be
non-discriminatory and ensures that interfaces are not areas of weakness in the supply
chain.1.3Structure of the Grid Code. - The Grid Code comprises of following chapters:I. General
Code. - General Code includes Sections on:(a)Management intended to ensure that all other
Sections of the Grid Code work together in the management of the Grid Code(b)Review Principles:
specify a procedure for review of Grid Code to cater to inadvertent omissions and any modifications
needed from time to time.II. Planning Code. - Planning Code includes Sections on:(a)System
Planning: specifies the procedures to be applied by STU in the planning and development of the
State Transmission System and by other Users connected or seeking Connection to the State
Transmission System.(b)Principles: specify procedures to be followed by STU in the development of
the State Transmission System in the long term taking into account the requirements for new
connection of generation and demand.(c)Connection conditions: specifies the technical
requirements and standards to be complied with by STU and other Users connected or seeking
connection to the State Transmission System.III. System Operation Code. - System Operation Code
includes Sections on:(a)System Operation: Specifies the conditions under which STU shall operate
the State Transmission System, the Generating Companies shall operate their Power Stations and
the Distribution Licensees shall operate their Distribution Systems in so far as necessary to ensure
the security and quality of supply and safe operation of the State Transmission System under both
normal and abnormal operating conditions.(b)Outage Planning: Specifies the procedures relating to
the coordination of outages for scheduled maintenance of the State Transmission System,
Generating Units, embedded within the State system and not classified as regional utilities, Captive
Power Plant (CPP) and Distribution System that will use the State Transmission System.The
Generating stations based on non-conventional/renewable energy sources with generating power
capacity of above 10 MW will also come under this purview.IV. Schedule and Despatch Code. -Bihar Electricity Grid Code, 2010

Schedule and Despatch. - Specifies the procedures relating to the scheduling and despatch of
Generating Units and drawal by Distribution Licensees / Open Access Customers to meet State
demand and drawal allocation.V. Protection Code. - Protection Code specifies the co-ordination
responsibility and minimum standards of protection that are required to be installed by Users of the
State Transmission System.VI. Metering Code. - Metering Code specifies the minimum operational
and commercial metering to be provided for each User. It also sets out the requirement and
procedures for metering.VII. Data Registration Code. - This contains the details of all the data
required by STU, which is to be provided by the Users and vice versa.1.4Scope of Grid Code. - 1. Grid
Code defines the boundary between STU and Users and establishes the procedures for operation of
facilities connected to the State Grid.
2. All Users that connect with and/or utilize the State Grid are required to
abide by the principles and procedures as laid down in the Grid Code in so
far as they apply to that User.
3. The Grid Code shall be enforced by STU. Users must provide STU
reasonable rights of access, service and facilities necessary to discharge its
responsibilities in the users premises and to comply with instructions as
issued by STU to implement and enforce the Grid code.
1.5Non-Compliance. - 1. If any User fails to comply with any provision of the Grid Code, the User
shall inform the SLDC and Grid Code Review Panel without delay the reason for its non-compliance
and shall remedy its non-compliance promptly.
2. SLDC shall bring the non-compliance to the notice of BERC.
3. Consistent failure to comply with the Grid Code provisions may lead to
disconnection of the User's plant and /or facilities.
1.6Code Responsibilities. - 1. In discharging its duties under the Grid Code, STU has to rely on
information which Users shall supply regarding their requirements and intentions.
2. STU shall not be held responsible for any consequences that arise from its
reasonable and prudent actions on the basis of such information.
1.7Confidentiality. - 1. Under the terms of the Grid Code, STU will receive information from Users
relating to their intentions in respect of their Generation or Supply businesses.
2. STU shall not, other than as required by the Grid Code, disclose such
information to any person other than Central or State Government and BERC
without the prior written consent of the provider of the information.Bihar Electricity Grid Code, 2010

1.8Dispute Settlement Procedures. - 1. In the event of any dispute regarding interpretation of any
part/section of the Grid Code provision between any User and STU, the matter may be referred to
the Commission for its decision.The Commission's decision shall be final and binding.
2. In the event of any conflict between any provision of the Grid Code and
any contract or agreement between STU and Users, the provision(s) of the
Grid Code will prevail.
1.9Directive. - State Government may issue policy directives in certain matters as per Section 37 of
the Electricity Act 2003. STU shall promptly inform the Commission and all Users of the
requirement of such directives.1.10Compatibility with Indian Electricity Grid Code. - This Grid Code
is consistent/compatible with the IEGC. However, in matters relating to Inter-State Transmission, if
any provision of the State Electricity Grid Code are inconsistent with the provisions of the IEGC,
then the provisions of IEGC as notified by CERC shall prevail.1.11The Board functioning as
integrated Utility. - The functions of STU, SLDC, Generating Stations, Distribution Licensees shall
be performed by the concerned officers authorised by the Board as long as it continues to function as
an integrated Utility. Till such time the Board is functioning as an integrated utility, Ring fencing of
SLDC shall be done separating manpower and accounts for SLDC functions.1.12Exemptions. - Any
exemption from the provisions of the Grid Code shall be effective only after the approval of the
BERC for which the agencies will have to file a petition in advance.
2. Glossary and Definition.
-In the Grid Code the following words and expressions shall, unless the subject matter or context
otherwise requires or is inconsistent therewith, bear the following meanings:
ABT Availability Based Tariff
Act The Electricity Act, 2003 (Act No. 36 of 2003)
Active EnergyThe electrical energy produced, flowing or supplied by anelectric
circuit during a time interval, being the integral withrespect to time of
the instantaneous power, measured in units ofwatt-hours or standard
multiples thereof,
Active PowerThe product of voltage and the in phase component of
alternatingcurrent measured in units of watts and standard
multiplesthereof,
ApparatusAll the electrical apparatus like machines, fittings, accessoriesand
appliances in which electrical conductors are used.
Apparent PowerThe product of voltage and alternating current measured in unitof
volt-amperes and standard multiples thereof,
Area of SupplyArea within which a Distribution Licensee is authorized by hislicence
to supply electricity.Bihar Electricity Grid Code, 2010

Automatic
VoltageRegulatory (AVR)A continuously acting automatic excitation system to control
aGenerating Unit terminal voltage.
Authority Central Electricity Authority (CEA)
AuxiliariesAll the plant and machinery required for the generating
unit'sfunctional operation that do not form part of the generatingunit.
Availability"Fully Available" shall mean that the Generating Unitis available to its
contracted capacity. In respect of theTransmission System,
"Availability " shall mean thetime in hours the Transmission System
is capable of transmittingelectricity at its rated voltage from the
supply point to thedelivery point and expressed as a percentage of
AnnualAvailability.
Bulk Power TransmissionAgreements made between the STU and its H.T customers and
betweenthe Board and CTU.
Agreement Backing DownReduction of generation on instructions from SLDC / ERLDC by
agenerating unit under abnormal conditions.
Black start procedure The procedure necessary to recover from partial or totalblackout.
Black start capabilityAn ability in respect of a Black Start Station, for at least oneof its
generating units or CCGT units to start up from shut downand to
energize a part of the system and be synchronized to thesystem upon
instruction from the State Load Dispatch Centre,within two hours,
without any external supply.
Black start stations Generating stations having Black Start Capability.
Captive Power Plant(CPP)A Power Plant set up by any person to generate electricityprimarily
for his own use and includes a power plant set up byany co-operative
society or association of persons for generatingelectricity primarily for
use of members of such co-operativesociety or association.
CEA Central Electricity Authority
Central TransmissionUtility
(CTU)Any Government Company which the Central Government may
notifyunder sub Section (1) of Section 38 of the Electricity Act, 2003.
CERC Central Electricity Regulatory Commission.
ConnectionThe electric power lines and electrical equipment used to effecta
connection of a user's system to the Transmission System.
Connection conditionsThose conditions mentioned in Section 5 ("connectionconditions")
which have to be fulfilled before the User'sSystem is connected to the
State Grid
Connection pointAn electrical point of connection between the Transmission
Systemand the User's System.
Consumer Any person who is supplied with electricity for his own use by
alicensee or the Government or by any other person engaged in
thebusiness of supplying electricity to public under the ElectricityAct,
2003 or any other law for the time being in force andincludes anyBihar Electricity Grid Code, 2010

person whose premises are for the time beingconnected for the
purpose of receiving electricity with the worksof a licensee, the
Government or such other person, as case maybe and shall include a
person whose electricity supply has beendisconnected.
DemandThe demand of Active Power in MW and Reactive Power in MVAR
ofelectricity unless otherwise stated.
Demand control Any of the following methods of achieving a load reduction:
 (a) Consumer Load Management initiated by Users.
 (b) Consumer Load reduction by Disconnection initiated by
Users(other than following an instruction from Load Despatch
Centre).
 (c) Consumer Load reduction instructed by the Load DespatchCentre
 (d) Automatic under Frequency Load Disconnection
 (e) Emergency manual Load Disconnection
DespatchOperation control of an integrated electricity system
involvingoperations such as:
 (a) Assignment of levels of output to specific Generating Plantor Load
control devices to effect the most reliable andeconomical supply as
the load vary.
 (b) The control of the operation of Extra High Voltage lines,associated
sub stations and equipment.
 (c) The scheduling of various types of transactions with theelectric
utilities over the interconnecting Transmission Lines.
De-synchronizeThe act of taking a generating unit off a system to which it hasbeen
synchronized.
Disconnection The physical separation of Users or Consumers from the system.
DiscriminationThe quality where a relay or protective system is enabled to pickout
and cause to be disconnected only the faulty apparatus.
Distribution LicenseesA licensee authorized under Section 14 of the Act to operate
andmaintain a distribution system for supplying electricity to
theconsumers in his area of supply.
Distribution systemThe system of wires and associated facilities between thedelivery
points on the transmission lines or the generatingstation connection
and the point of connection to theinstallation of the consumers.
Drawal The import / export of electrical energy from / to the grid
EarthingConnecting the conducting parts of an equipment or machinery
withthe general mass of earth, in such a manner ensuring at all
timesan immediate discharge of energy without danger, by
maintainingthe same efficiently at earth's potential.
Earthing device A means of providing connection between a conductor and earthbeingBihar Electricity Grid Code, 2010

of adequate strength and capability.
EHV Extra High Voltage equal to and greater than 66 kV
FrequencyThe number of alternating current cycles per second (expressed
inHertz) at which the system is operating.
Generating companyAny company or body corporate or association or body ofindividuals,
whether incorporated or not, or artificial juridicalperson, which owns
or operates or maintains a generating station.
Generating stationAny station for generating electricity, including any buildingand plant
with step-up transformer, switch-yard, switch gear,cables or other
appurtenant equipment, if any used for thatpurpose and the site
thereof, a site intended to be used for agenerating station, and any
building used for housing theoperating staff of a generating station
and where electricity isgenerated by water - power, includes,
penstocks, head and tailworks, main and regulatory reservoirs, dams
and other hydraulicworks, but does not in any case include any sub
station.
Generating unitThe combination of an electric power generator and its primemover
and all of its associated equipment, which togetherconstitutes a single
generating machine.
Generating schedule The despatch schedule of a generating station
BERC Bihar Electricity Regulatory Commission
GridHigh Voltage backbone system of inter-connected TransmissionLines,
Sub Stations and Generating Stations.
Grid Code" Bihar Electricity Grid Code", a document describingthe procedures
and the responsibilities for planning andoperation of Bihar Grid.
Grid Code Review Panelor
'Panel'The Panel with the functions set out in the Grid Code*
High Voltage or HV IEGCVoltage greater than 440 V and lower than 33 kV. IndianElectricity
Grid Code, a document describing the philosophy andthe
responsibilities for planning and operation of Indian PowerSystem
specified by the Central Electricity Regulatory Commission(CERC) in
accordance with sub-section 1 (h) of Section 79 of theAct.
Indian Standards ("IS")Those Standards and specifications approved by the Bureau ofIndian
Standards.
 Inter-State Transmission System (ISTS)
 Inter-State Transmission System includes :
 (a) Any system for the conveyance of electricity by means of amain
Transmission Line from the territory of one State to anotherState;
 (b) the conveyance of electricity across the territory of anintervening
State as well as conveyance within a State, which isincidental to such
Inter-State transmission of electricity.Bihar Electricity Grid Code, 2010

 (c) The transmission of electricity within the territory of aState built,
owned, operated maintained or controlled by theCentral
Transmission Utility.
InterconnectingTransformer
(ICT)Transformer connecting EHV lines of different voltage systems.
Independent PowerProducer
(IPP)Power Station within the State owned by a generator who is notpart of
BSEB.
Inter tripping(a) The tripping of circuit - breaker(s) by commands initiatedfrom
protection at a remote location independent of the state oflocal
protection; or
 (b) Operational intertripping.
Intra-State
TransmissionSystemAny system for transmission of electricity other than an Inter -State
Transmission System.
IsolationThe disconnection of EHV / HV Apparatus from the remainder of
theSystem in which that EHV / HV Apparatus is situated.
Lean PeriodThat period in a day for a few hours when the electrical powerdemand
remains less than the average demand.
LicenceAny licence granted by BERC under provisions of the relevant lawsin
force
LoadThe Active, Reactive or Apparent power as the context
requires,generated, transmitted or distributed.
Load FactorLoad Factor is the ratio of the average power to the
maximumdemand. The load factor depends on the interval of time of
themaximum demand and the period over which the average is taken.
 {|
Load Factor =| Units
consumed in a given
periodMaximum demand X
No. of hours in the period
|-| Low Voltage or LV| Voltage not exceeding 440 volts|-| Main protection| Protection equipment or
system expected to have priority ininitiating either a fault clearance or an action to terminate
anabnormal condition in a power system.|-| NTPC| National Thermal Power Corporation Limited|-|
Operating Margin| Aggregate available capacity of generating station in the systemon real time
basis, which is over and above the operating levelto the maximum capacity of the generating units
limited bytechnical parameters for short duration.|-| Operation| A scheduled or planned action
relating to the operation of asystem.|-| Operational procedure| Management instructions and
procedures, both for the safety Rulesand for the local and remote operation of plant and
apparatus,issued in connection with the actual operation of plant and/orapparatus at or from a
connecting site.|-| Open Access| The non-discriminatory provision for the use of transmissionlines
or distribution system or associated facilities with suchlines or system by any licensee or consumer
or a person engagedin generation in accordance with the regulations specified by theCommission.|-|
Outage| A total or partial regulation in availability due to repair andmaintenance of theBihar Electricity Grid Code, 2010

Transmission or Distribution or Generationfacility or defect in Auxiliary System.|-| Part Load| The
condition of a generating station which is loaded but is notrunning at its declared availability.|-|
Partial shutdown| A shutdown of a part of the system resulting in failure of powersupply, either
from external connections or from the healthy partof the system.|-| Peak period| That period in a
day when the electrical power demand is highest.|-| Person| Any company or body corporate or
association or body ofindividuals, whether incorporated or not, or artificial juridicalperson.|-|
PGCIL| Power Grid Corporation of India Limited|-| Planned outage| An outage of generating plant
or part of the Transmission system,or part of a User's System coordinated by SLDC.|-| Power factor|
The ratio of Active Power (kW) to Apparent Power (KVA).|-| Protection| The scheme and Apparatus
for detecting abnormal conditions on asystem and initiating fault clearance or actuating signals
orindications.|-| Rated MW| The "rating plate" MW output of a Generating Unit,being that output
up to which the generating unit is designed tooperate.|-| Reactive Power| The product of voltage and
current and the sine of the phaseangle between them measured in units of volt-amperes reactive
andstandard multiples thereof;|-| Regulating Margin| The system voltage and frequency beyond
which the system shouldnot be operated.|-| Re-Synchronization| The bringing of parts of the system
which has gone out ofsynchronism with each other, back into synchronism.|-| Safety-Rules| The
Rules framed by the Users and the transmission licensee toensure safety to persons working on
plant /apparatus.|-| SLDC| State Load Despatch Centre|-| Standing Instructions| An instruction
issued by SLDC to a generating company whereby, inspecified circumstances, the generating
company should takespecified action, as though a valid dispatch instruction has beenissued by
SLDC.|-| Start-Up| The action of bringing a generating unit from shutdown tosynchronous speed.|-|
State TransmissionUtility (STU)| The utility notified by the Government under subjection (1)
ofSection 39 of the Electricity Act, 2003 and whose functions havebeen outlined under subsection
(2) of Section 39 of theElectricity Act 2003.|-| Station Transformer| A transformer supplying
electrical power to the auxiliaries of agenerating station, which is not directly connected to
agenerating unit terminal.|-| Sub station| Station for transforming or converting electricity for
thetransmission or distribution thereof and includes transformers,converters, switchgears,
capacitors, synchronous condensers,structures, cable and other appurtenant equipment and
anybuildings used for that purpose and the site thereof.|-| Supervisory Control andData Acquisition
or(SCADA)| The communication links and data processing systems, whichprovide information to
enable implementation of requisitesupervisory and control actions.|-| Synchronized| Those
conditions where an incoming generating unit or system isconnected to the bus bars of another
system so that thefrequencies and phase relationships of that generating unit orsystem as the case
may be, and the system to which it isconnected are identical.|-| System| Any transmission and
distribution system and / or transmissionsystem, as the case may be.|-| Total system| The
transmission system and all user systems in Bihar.|-| Transmission licensee| A licensee authorized
to establish and operate transmission lines|-| Transmission lines| All high pressure cables and
overhead lines (not being anessential part of the distribution system of a licensee)transmitting
electricity from a generating station to anothergenerating station or a sub station, together with any
step up andstep-down transformers, switch-gear and other works necessary toand used for the
control of such cables or overhead lines, andsuch buildings or part thereof as may be required to
accommodatesuch transformers, switchgear and other works.|-| Transmission system| The system
consisting of high pressure cables and overhead linesof transmission licensee for transmission of
electrical powerfrom the generating station upto connection point / interfacepoint with theBihar Electricity Grid Code, 2010

distribution system. This shall not include any
Part of – the distribution system.
|-| Under Frequency Relay| An electrical measuring relay intended to operate when itscharacteristic
quantity reaches the relay settings by decrease infrequency.|-| User| A term utilized in various
Sections of Grid Code to refer to thepersons using the Bihar Grid, as more particularly identified
ineach Section of the Grid Code. In the general conditions the termmeans any person to whom the
Grid Code applies.|}Words and expressions used and not defined in this code but defined in the Acts
shall have the meanings assigned to them in the said Acts. Expressions used herein but not
specifically defined in this Code or in the said Acts but defined under any law passed by a competent
legislature and applicable to the electricity industry in the State shall have the meaning assigned to
them in such law. Subject to the above, expressions used herein but not specifically defined in this
Code or in the Acts or any law passed by a competent legislature shall have the meaning as is
generally assigned in the electricity industry.
3. Management of Grid Code.
- 3.1. Introduction.
1. The State Transmission Utility (STU) is required to implement and comply
with the Bihar Electricity Grid Code and to carry out periodic review and
amendments of the same with the approval of Bihar Electricity Regulatory
Commission (BERC). A Review Panel shall be constituted by STU, as
required in this Section, comprising of the representatives of the Users of the
Transmission System.
2. No change in this Grid Code, however small or large, shall be made
without being deliberated and agreed by the Grid Code Review Panel and
thereafter approved by BERC. However, in an unusual situation where
normal day to day operation is not possible without revision of some clauses
of Grid Code, a provisional revision may be implemented before approval of
BERC is received, but only after discussion at a special Review Panel
Meeting convened on emergency basis. BERC should promptly be intimated
about the provisional revision. BERC may issue directions requiring STU to
revise the Grid Code accordingly as may be specified in those directions and
STU shall promptly comply with any such direction.
3.2Objective. - The objective of this Section is to define the method of management of Grid Code
documents, implementing any changes / modifications required and the responsibilities of theBihar Electricity Grid Code, 2010

constituents (Users) to effect the change.3.3Grid Code Review Panel. - 1 .The Chairperson of the
Grid Code Review Panel shall be an Engineer of the STU not below the rank of Chief Engineer. The
Member Secretary of the Panel shall also be nominated by STU. The Grid Code Review Panel shall
consist of the following members in addition to above on the recommendations of the heads of the
respective organizations:(a)One member from SLDC (head of SLDC)(b)One Chief Engineer
(Generation) of Bihar State Electricity Board.(c)One member from Transmission licensee in the
State other than STU(d)One representative at senior executive level from system operation from
National Thermal Power Corporation Limited (NTPC),(e)One member at senior level from ERPC
Secretariat(f)One representative at senior executive level from Eastern Regional Load Despatch
Centre (ERLDC)(g)One representative at senior executive level from Distribution Licensee.(h)One
representative at senior executive level from each of the generating companies feeding not less than
50 MW to the Grid in the State.(i)One representative from all Captive Power Plants (CPPs), which
are in parallel operation with Bihar State Grid, on rotation basis.(j)One representative from all the
generating companies of small generating stations of less than 50 MW capacity on rotation basis.
2. Any other member can be co-opted as a member of the panel when
directed by BERC.
3. The functioning of the Committee shall be co-ordinated by STU. The
Member Secretary nominated by STU shall be the convener.
4. STU shall inform all the Users, the names and addresses of the Review
Panel, Chairperson and the Member Secretary at least 15 days before the first
Review Panel meeting. Any subsequent changes shall also be informed to all
the Users by STU. Similarly, each user shall inform the names and
designations of their representatives to the Member Secretary of the Review
Panel, at least three days before the first Review Panel meeting, and shall
also inform the Member Secretary in writing regarding any subsequent
changes.
3.4Functions of the Review Panel. - The functions of the Review Panel are as follows:(a)Review and
Maintenance of the Grid Code and its working.(b)Consideration of all requests for review made by
any user and make recommendations for changes in the Grid Code together with reasons for such
changes.(c)Provide guidance on interpretation and implementation of the Grid
Code.(d)Examination of the problems raised by any user as well as resolution of the
problems.(e)Ensuring that the changes / modifications proposed in the Grid Code are consistent
and compatible with Indian Electricity Grid Code (IEGC). The Review Panel may hold any number
of meetings as required subject to the condition that at least one meeting shall be held in every three
months. Sub-meetings may be held by STU with the Users to discuss individual requirements and
with groups of Users to prepare proposals for Co-ordination Committee's consideration.3.5Review
and Revisions. - 1. The Users seeking any amendment to the Grid Code shall send written requests
to the Member Secretary of the Review Panel. If the request is sent to BERC directly, the same shallBihar Electricity Grid Code, 2010

be forwarded to STU. STU shall examine the proposed changes / modifications in line with IEGC
stipulations and circulate the same along with its comments to all Review Panel members for their
written comments within a reasonable time frame. Whenever it is observed that a certain clause of
Grid Code is not consistent with the IEGC, then the same will be discussed in the Review Panel and
the clause will be revised to make it consistent with IEGC.
2. All the comments received shall be scrutinized and compiled by
STU.These along with STU's comments shall be sent to all the members for
their response for the proposed change / modification. If necessary, STU
shall convene a meeting of the Review Panel for deliberations. The Member
Secretary shall present all the proposed revisions of the Grid Code to the
Review Panel for its consideration.
3. Based on the response received, STU shall finalise its recommendation
regarding the proposed modification / amendment and submit the same
along with all the related correspondence to BERC for approval.
4. STU shall send the following reports to the BERC at the conclusion of each
review meeting of the Committee:
(a)Report on the outcome of such review.(b)Any proposed revision to the Grid Code.(c)All written
representations and objections submitted by the Users at the time of review.
5. All revisions to the Grid Code require the approval of BERC. STU shall
publish revisions to the Grid Code, after the approval of BERC. STU may
submit proposals for relaxation in such cases where Users have difficulties
in meeting the requirements of the Grid Code.
6. Any change from the previous version shall be clearly marked in the
margin. In addition, a revision sheet shall be placed at the front of the revised
version noting the number of every changed sub-section, together with
reasons for such change.
7. STU shall maintain copies of the Grid Code with the latest amendments
and shall make it available at a reasonable cost to any person requiring it.
This may also be made available on the website.The STU shall keep an up to
date list of recipients of all the copies of the Grid Code, if found necessary to
ensure that the latest version of Grid Code is reached to all the relevant
recipients.Bihar Electricity Grid Code, 2010

8. The Commission, may, on the application of the Users or otherwise, call
the emergency meeting of the Review Panel as and when the situation so
dictates and make such alterations or amendments in the Grid Code as it
thinks fit.
Chapter 2
Planning Code
4. System Planning.
- 4.1. Introduction -
1. This Section specifies the methods for data submission by Users to STU
for planning and development of the State Transmission System. This
Section also specifies the procedures to be adopted by STU in the planning
and development of the State Transmission System.
2. Requirement for reinforcement or extension of the State Transmission
system arise due to many reasons of which a few are mentioned below:
(i)Development on a User's system already connected to the State Transmission
System.(ii)Introduction of a new connection point between the User's system and the State
Transmission System.(iii)Evacuation system for generating stations within or outside
State(iv)Reactive compensation.(v)A general increase in system capacity due to addition of
generation or system load.(vi)Transient or steady state stability considerations(vii)Cumulative effect
of any of the above
3. The reinforcement or extension of the State Transmission System may
involve work at an entry or exit point (connection point) of a User to the State
Transmission System. Since development of all User's systems must be
planned well in advance to ensure consents and way leaves to be obtained
and detailed engineering design / construction work to be completed, STU
will require information from Users and vice versa. To this effect, the
planning code imposes time scale for exchange of necessary information
between STU and Users.
4.2Objective. - This Section formulates the procedures for the 'System Planning' to enable STU in
consultation with the Users, to evolve an efficient, coordinated, secure and economical State
Transmission System to satisfy requirements of future demand.4.3Planning Policy. - 1. STU wouldBihar Electricity Grid Code, 2010

develop a prospective transmission plan for next 10 years for the State Transmission System. These
plans shall be updated every year to take care of the revisions in load projections and generation
capacity additions. The perspective plans shall be submitted to the Commission for approval.
2. STU shall carry out network studies and review fault levels for planning
system strengthening and augmentation.
3. STU shall follow the following steps in planning:
(i)Forecast the demand for power within the area of supply based on the forecasts provided by
Distribution Licensees. These shall include details of demand forecasts, data methodology and
assumptions on which forecasts are based.These forecasts would be annually reviewed and updated,
and also whenever major changes are made in the existing system.(ii)Prepare a proposal for the
requirement of generation for the State to meet the load demand as per the forecast taking into
account the existing contracted generation resources.(iii)Prepare a transmission plan for the State
Transmission System compatible with the above load forecast and generation plan. VAR
compensation needed will also be included.(iv)Necessary load flow studies shall be carried out for
short circuit and transient stability study and relay coordination study for transmission system
planning.(v)STU shall be responsible to prepare and submit a long term (10 years) plan to BERC for
generation expansion and transmission system expansion to fully meet both energy and peak
demand.(vi)STU shall extend support to Central Transmission Utility (CTU) to finalise the annual
planning corresponding to a 5 years forward term for identification of major Inter-State
Transmission System including inter-regional schemes which shall fit in with the long term plan
developed by CEA.
4. All Users shall supply to STU, the planning data prescribed in Appendix A
and Appendix B of Data Registration Code within 3 months from the effective
date of the Grid Code and thereafter such data shall be furnished by 31st
March every year to enable STU to formulate/ finalise the updated plan by
30th September each year for the next 5 years.
4.4Planning Criterion. - 1. The planning criterion shall be based on the security philosophy on which
both Inter State Transmission System (ISTS) and the State Transmission System (STS) have been
planned.The security philosophy shall be as per the Transmission Planning criteria and guidelines
as given by Central Electricity Authority (CEA).
2. The State Transmission System planning and generation expansion
planning shall be in accordance with the provisions of the planning criterion
as per IEGC Clause 3.5.
4.5Planning responsibility. - 1 .The primary responsibility of load forecasting within distribution
licensee's area of supply rests with the respective Distribution Licensee. The Distribution LicenseeBihar Electricity Grid Code, 2010

shall determine peak load and energy forecast of their areas for each category of loads for each of the
succeeding 5 years and submit the same annually by 31st March to STU along with details of
demand forecasts, data, methodology and assumptions on which forecasts are based along with
their proposals for transmission system augmentation. The load forecasts shall be made for each of
the prevalent as well as proposed inter connection points between STU and Distribution Licensees
and shall include annual peak load and energy projections.
2. Generating stations shall provide their generation capacity to STU for
evacuating power from their power stations for each of the succeeding 5
years along with their proposals for augmentation of transmission proposals
and submit the same annually by 31st March to STU.
3. The planning for strengthening the State Transmission System for
evacuation of power from outside State Stations shall be initiated by STU.
4.6Planning data. - 1. To enable STU to conduct system studies and prepare perspective plans for
electricity demand, generation and transmission, the Users shall furnish data to STU from time to
time as detailed under Data Registration Section as under:(a)Standard Planning Data
(Generation)/Standard Planning Data (Distribution) as per Appendix A.(b)Detailed Planning Data
(Generation)/Detailed Planning Data (Distribution) as per Appendix B.
2. To enable the Users to co-ordinate planning design and operation of their
plants and systems with the State Transmission System, they may seek
certain data of transmission system as applicable to them, which the STU
shall supply from time to time as detailed under Data Registration Section
categorized as;
(a)Standard Planning Data (Transmission) as per Appendix A.(b)Detailed Planning Data
(Transmission) as per Appendix B.4.7Implementation. - The actual programme of implementation
of transmission lines, inter - connecting transformers, reactors/capacitors and other transmission
elements will be determined by STU in consultation with the concerned Users.The completion of
these works in the required time frame shall be ensured by STU through the concerned users.
STU/SLDC may periodically inform RLDC of their plans as well as stages of implementation.
5. Connection Conditions.
- 5.1. Introduction -This Section specifies the technical, design and operational criteria which shall
be complied with by every User connected or seeking connection to the State Transmission
System.Any user seeking connection to or connected with the Intra-State System shall comply with
the CEA Regulations 2007 "Technical Standards for connectivity to the Grid".This applies to all
users seeking connection or connected to the Intra-State System.5.2Objective. - The objective of this
Section is to ensure the following:(i)All Users or prospective Users are treated in aBihar Electricity Grid Code, 2010

non-discriminatory manner(ii)Any new or modified connection when established shall neither
suffer unacceptable effects due to its connection to State Transmission System nor impose any
unacceptable effect on the system of existing Users and new connection shall not suffer adversely
due to existing Users.(iii)A system of acceptable quality is ensured by specifying the required
minimum standards for the design and operational criteria to assist the Users in their requirement
to comply with the licence obligations.(iv)The ownership and responsibility for all equipments is
clearly specified in the "Site Responsibility Schedule" for every site, where a connection is
made.5.3Procedure for application for connection to Transmission System. - The procedure for any
new connection or modification of an existing connection with the State Transmission System shall
consist of following:
1. The User shall meet all necessary conditions as specified in the State Grid
Code and submit the application to STU containing all the information as
may be specified.
2. STU shall make a formal offer within 60 days of the receipt of the
application. The offer shall specify and take into account any work required
for the extension or reinforcement of the State Transmission System
necessitated by the applicant's proposal and for obtaining any consent
necessary for the purpose. STU shall process the application in accordance
with the CEA Regulations on Grid Connectivity
3. If the specified time limit for making the offer against any application is not
adequate, STU shall make a preliminary offer within the specified time
indicating the extent of further time required for detailed analysis.
4. Any offer made by STU shall remain valid for a period of 60 days and
unless accepted before the expiry of such period, shall lapse thereafter.
5. In the event of offer becoming invalid or not accepted by the applicant,
STU shall not be bound to consider any further application from the same
applicant within 12 months unless the new application is substantially
different from the original application.
6. The applicant shall furnish the Detailed Planning Data as per Appendix-B.
5.4Rejection of application. - STU shall be entitled to reject any application for connection to or use
of the State Transmission System due to the following reasons apart from others as considered
reasonable:(i)If such proposed connection is likely to cause breach of any provision of its Licence or
any provision of the Grid Code or any provision of IEGC or any criteria or covenants or deeds orBihar Electricity Grid Code, 2010

Regulations by which STU is bound.(ii)If the applicant does not undertake to be bound, in so far as
applicable, by the terms of the Grid Code.(iii)If the applicant fails to give confirmation and
undertakings according to this Section.(iv)The reason for rejection of connection to or use of the
State Transmission System will be communicated to the applicant by STU within 60 days of the
receipt of application.5.5Connection Agreement. - 1. A connection agreement, or the offer for a
connection agreement shall include (but not limited) within its terms and conditions the
following:(i)A condition requiring both agencies to comply with the Grid Code.(ii)Details of
connection technical requirements and commercial arrangements(iii)Details of any capital related
payments arising from necessary reinforcement or extension of the system, data communication,
RTU etc and demarcation of the same between the concerned parties.(iv)A Site Responsibility
Schedule (Appendix-D).(v)General Philosophy, Guidelines etc on protection and telemetry
2. Model Connection agreement /-This shall be prepared by STU and
submitted to the Commission for approval.
5.6Site responsibility schedule. - 1. For every connection to the State Transmission System for which
a connection agreement is required, STU shall prepare a schedule of equipment with information
supplied by the respective Users. This schedule, called 'Site Responsibility Schedule' shall indicate
the following for each item of equipment installed at the connection site.(i)Ownership of the
equipment(ii)Responsibility for control of equipment(iii)Responsibility for maintenance of
equipment(iv)Responsibility for operation of equipment(v)Responsibility for all matters relating to
safety of persons and site.(vi)Management of the site.
2. The format to be used in the preparation of Site Responsibility Schedule is
given in Appendix - D.
5.7System Performance. - 1. All equipment connected to the State Transmission System shall be of
such design and construction that enable STU to meet the requirement of standards of performance
specified by BERC under Section 57 of the Electricity Act, 2003.
2. Installation of all electrical equipment shall comply with IE Rules, 1956
which are in force for time being and will be replaced by new Rules made
under Electricity Act, 2003.
3. For every new/modified connection sought the STU shall specify the
connection point, technical requirements and the voltage to be used, along
with metering, telemetering and protection requirements as specified in the
Metering Code and Protection Code.Bihar Electricity Grid Code, 2010

4. Insulation coordination of the User's equipment shall conform to the
applicable values as specified by STU from time to time out of those
applicable as per Indian Standards / Code of Practices. Rupturing capacity of
the switch gear shall not be less than that specified by STU from time to time.
5. Protection schemes and metering schemes shall be as detailed in the
Protection Code and Metering Code.
6. The State Transmission System rated frequency shall be 50.00 Hz and
shall be regulated by the provisions of IEGC as given below:
Target Range
Upper limit -50.20 Hz
Lower limit -49.50 Hz
7. The Users shall be subject to the Grid discipline prescribed by SLDC and
ERLDC.
8. The variation of voltage at the interconnected point should not be more
than voltage range specified below:
Nominal (KV) % limit of variation Maximum (KV)Minimum
(KV)
400 +5%/- 5% 420 380
220 +/-10% 245 198
132 +/-10% 145 122
5.8Connection Points/interface points. - 1. State Generating Stations (SGS)(i)Voltage may be
220/132/33 KV or as agreed with STU.(ii)Unless specifically agreed with STU, the Connection point
with generating station shall be the terminal isolator provided just before the outgoing gantry of the
feeders.(iii)SGS shall operate and maintain all terminals, communication and protection
equipments provided within the generating station.(iv)The provisions for the metering between
generating station and STU system shall be as per the Metering Code.(v)Respective Users shall
maintain their equipments from the out going feeders' gantry onwards emanating from generating
station'(vi)All entities embedded within BSEB system and interfacing the Intra/ State Transmission
System shall provide adequate and reliable communication facility so that SLDC is able to record in
its SCADA system the MW/ MVAR flows, bus voltages at all the interface points with the intra-state
system.Bihar Electricity Grid Code, 2010

2. Distribution Licensee. - (i) Voltage may be LV side of power transformer i.e.
33 KV or 11 KV or a agreed with STU. For EHV consumers directly connected
to transmission system, voltage may be 220 KV/132 KV
(ii)Unless specifically agreed with Distribution Licensee, the Connection point with STU shall be the
terminal isolator provided just before the outgoing gantry of the feeder to Distribution Licensee or
individual EHV consumer as the case may be, from STU sub-station(iii)STU shall operate and
maintain all terminals, communication and protection equipments provided within its sub-station.
The provisions for the metering between STU and Distribution Licensee systems shall be as per the
Metering Code. Respective Users shall maintain their equipment beyond the out going gantry of
feeders emanating from STU sub-station onwards.
3. Eastern Regional Transmission System. - The Connection, protection
scheme, metering scheme and the voltage shall be in accordance with the
provisions of IEGC.
4. Independent Power Producers (IPPs), Captive Power Plants (CPPs), Extra
High Voltage (EHV) Consumers and Open Access Customers. -
(i)Voltage may be 220/132/33 KV or as agreed with STU.(ii)When IPPs, CPPs, EHV Consumers or
the Open Access Customers own sub-stations, the Connection point shall be the terminal isolator
provided just before the gantry of outgoing/incoming feeder in their premises.
Chapter 3
System Operation Code
6. Operation Planning.
- 6.1. Introduction -This Section describes the process by which the SLDC carries out the operational
planning and demand control procedures to permit reduction in demand for any
reason.6.2Objective. - Operational Planning is aimed at integrated, economic and reliable operation
of the State Grid.Operating Policy:(i)Overall real time operation of the State Grid shall be supervised
by the SLDC and the STU in accordance with Grid Code.(ii)Distribution Licensee shall monitor grid
operation of its distribution system and coordinate with the SLDC.(iii)All State entities shall comply
with the operation guidelines specified hereinafter and co-ordinate with each other, for deriving
maximum benefits from the integrated operation and for equitable sharing of obligations.(iv)A set of
detailed internal operating procedures for the State Grid shall be developed and maintained by the
SLDC in consideration with the entities and same shall be consistent with Grid Code. The control
rooms of the SLDC, Area LDC, Generating Stations, and EHV substations and any other control
centers of all the entities shall be manned round the clock by qualified personnel with adequate
training.6.3System security. - 1. All Users shall operate their respective power system andBihar Electricity Grid Code, 2010

generating stations in synchronization with each other at all times so that the whole State
Transmission System operates as a synchronized system as well as integrated part of Eastern Region
Gird. STU shall operate the Inter-State links so that Inter State transfer of power can be achieved
smoothly when required.
2. No part of the State Transmission System shall be isolated from the
integrated grid except under the following conditions;
(i)Emergency situations that may result in total grid collapse.(ii)Isolation of the system to prevent
serious damage to important/costly equipment.(iii)When such isolation is specifically instructed by
SLDC.(iv)On operation of under frequency / islanding scheme as approved at Eastern Region level.
3. Complete synchronization shall be restored as soon as conditions permit.
The restoration process shall be supervised by SLDC.
4. The 132 KV and above transmission lines (except radial lines which do not
affect the operation of the Grid) and the inter connecting power transformers
should not be opened or removed from service without instruction or prior
clearance from the SLDC. Under emergencies where prior clearance from
SLDC is not possible, it should be intimated to SLDC at the earliest possible
time after the incident and get the clearance, while bringing back these lines
into service.
5. Any tripping, whether manual or automatic of transmission lines by 132 KV
and above or power transformers of 132 KV class and above and 50 MVA and
above shall be promptly reported to the SLDC at the earliest along with the
reasons for such tripping and the likely time required for restoration. The
information / data including that down loaded from disturbance recorder,
sequential event recorder etc. required for the purpose of analysis shall be
sent to SLDC. For restoration of tripped equipment / line, SLDC shall be
informed and get its clearance.
6. All generating units of 200 MW and above in case of thermal and 10 MW
and above in case of hydro which are synchronized with the grid irrespective
of their ownership shall have their governors in normal operation at all times.
If any generating unit of over 50 MW size is required to be operated without
its governor in normal operation, the ERLDC through SLDC shall be
immediately intimated about the reason and duration of such operation. The
exemption from free governor mode operation in respect of run of river hydroBihar Electricity Grid Code, 2010

stations without any pondage, steam turbine of thermal and gas based power
stations not having free governor mode facility shall be obtained from CERC
under clause 1.6 of IEGC.
7. Facilities available with / in Load limiter, Automatic Turbine Run-up System
(ATRS), Turbine Supervisory Coordinated Control System etc., shall not be
used to bye pass the normal governor action in any manner. No dead bands
and time delays shall be deliberately introduced.
8. All generating units operating in Free Governor Mode Operation (FGMO) at
or upto 100% of their maximum continuous rating shall normally be capable
of (and shall not be prevented from) picking upto 5% extra load, more than
the declared maximum continuous rating, for atleast five minutes or within
the technical limits specified by the manufacturers, when the frequency falls
due to a system contingency. In case any generating unit of 50 MW and
above size does not meet this requirement for any period, the generating
company should intimate the same to SLDC along with reasons thereof. Any
generating unit not capable of complying with above provisions either due to
not having requisite facilities or otherwise shall seek exemption from Central
Electricity Regulatory Commission (CERC) under clause 1.6 of IEGC.
9. In case frequency falls below 49.5 Hz, all partly loaded Generating Units
shall pick up additional load at a faster rate, according to their capability.
SLDC in consultation with ERLDC and Distribution Licensees shall prepare a
plan for automatic load relief during the low frequency conditions. In case
frequency rises to 50.5 Hz or higher, neither any generating unit shall be
synchronized with the Grid nor shall generation at any generating station
(irrespective of type or ownership) be increased without obtaining approval
from SLDC.
10. Except under an emergency, or to prevent an imminent damage to costly
equipment, no User shall suddenly decrease/increase its generation without
prior intimation to the SLDC. Similarly, no User shall cause a sudden
decrease/increase in its load due to imposition/lifting of power cuts etc.,
without prior intimation to and consent of SLDC, particularly when frequency
is deteriorating.Bihar Electricity Grid Code, 2010

11. All Generating Units shall normally have their Automatic Voltage
Regulators (AVRs) in operation, with appropriate settings. In particular, if a
Generating Unit of over 50 MW capacity is required to be operated without its
AVR in service, the same should be operated only after prior concurrence of
SLDC.
12. Each Generating Unit must be fitted with a turbine speed governor having
an overall droop characteristic within the range of 3% to 6%, which shall
always be in service.
13. State Generating Stations and other generating stations connected to the
Grid shall follow the instructions of SLDC for backing down/boxing up
(ramping-down) and shutting down the generating unit(s). SLDC shall
provide the certificate for the period of the backing down/boxing up or
shutting down for the purpose of computing the deemed generation, if
required.
14. Various steps shall be taken for frequency management and voltage
management so as to ensure system security from these considerations.
6.4Demand Estimation. - 1. The Distribution Licensee shall formulate a short-term demand forecast
considering the previous financial year as base and projecting the demand for the succeeding 5
years.
2. It shall be the responsibility of all Distribution Licensees to fully cooperate
with STU in preparation of. demand forecast for the entire State.
3.
The long term demand estimation / load forecast (for more than 1 year) shall be done by STU and
SLDC shall be provided with a copy of the same as and when it is finalized.SLDC shall inform its
load projections (both peak and off - peak) in ERPC forum for three months, to be reviewed every
month ahead.
4. The Distribution Licensees shall provide to the STU and SLDC their
estimates of demand for each inter connection point for the next financial
year by 31st January of each year Distribution Licensees shall also provide
daily demand for the month ahead at each inter connection point by 25th of
the month.Bihar Electricity Grid Code, 2010

5. Based on the data furnished by the Distribution Licensees, STU shall make
monthly peak and lean period demand estimates for year ahead and daily
peak and lean period demand estimates for the month ahead and furnish the
same to SLDC.
6.
The Distribution Licensee shall provide to SLDC on day ahead basis, at 9.00 hrs, each day their
estimated demand for each 15 minute block for the ensuing day. The Distribution Licensee shall also
provide to SLDC estimates of loads that may be shed, when required, in discreet blocks with details
of arrangement of such load shedding.
7. The SLDC would update demand forecast (in MW as well as kWh) on
quarterly, monthly, weekly and ultimately on daily basis which would be used
in the day - ahead scheduling.
6.5Demand Control. - 1. Automatic load shedding shall be resorted to by means of installation of the
Under Frequency Relays at the sub stations of the STU as per the directions of the SLDC to preserve
the overall integrity of the power system. The number and size of the discrete blocks using
Automatic Under Frequency Relays for Load Shedding shall be determined on rotational basis in
consultation with every Distribution Licensee. The frequency settings of these relays shall be
coordinated in consultation with the RLDC.
2. Whenever restoration of large portions of the total demand disconnection
effected by the automatic load shedding is not possible within a reasonable
time, the SLDC shall implement additional disconnection manually, to restore
an equivalent amount of demand disconnected automatically.
Each Distribution Licensee shall help the SLDC in identifying such load blocks.Load shed by the
operation of automatic load shedding devices shall not be restored without specific directions from
the SLDC.
3. Planned manual disconnections shall be implemented by the SLDC when
there is a shortfall in generation, or constraints in Transmission System, or
reduction of imports through external connection etc., requiring demand
control to control the over-drawl of power from Inter State Generating State
(ISGS) when the system frequency falls below 49.5 Hz. In such cases a
rotational load shedding scheme shall be adopted to ensure equitable
treatment for all consumers as far as practicable.Bihar Electricity Grid Code, 2010

4. Emergency Manual Disconnection to deal with unacceptable voltage and
frequency levels etc. shall be implemented by the SLDC when loss of
generation, mismatch of generation with the demand, constraints in the
transmission system, over-drawal from the grid in excess of respective
schedule affecting the frequency of the regional grid below 49 Hz, requiring
load shedding at short notice or no notice, to maintain a regulating margin.
5. These control measures shall not be withdrawn till the system frequency
improves and when the SLDC issues such instructions after review of the
situation.
6.6Load Crash. - 1. In the event of load crash in the system due to weather disturbance or any other
reasons, the situation would be controlled by SLDC by the following methods in descending
priorities:i. Lifting of the load restrictions, if anyii. Exporting the power to neighbouring
Regions/States provided the same does not endanger the security of the ISTSiii. Backing down of
thermal stations with a time lag of 5-10 minutes for short period in merit order.iv. Closing down of
hydel units (subject to non spilling of water and effect on irrigation) keeping in view the inflow of
water into canals and safety of canals/hydel channels.
2. While implementing the above, the system security aspects should not be
violated as per provisions in Section 5.2 of IEGC and Section 6.3 of the Grid
Code.
7. Outage Planning.
- 7.1. Introduction -This Section describes the procedure for preparation of outage schedules for the
elements of the State Grid in a coordinated and optimal manner keeping in view the State Grid
operating conditions and the balance of generation and load.7.2Objective. - The objective of this
Section is to define the process which will allow STU to optimise transmission outages with SGS
(other than CPP) and Distribution Licensees, Outages in co-ordination with outage planning of
regional system while maintaining system security to the extent possible.7.3Outage Planning
Process. - 1. Each User shall provide their outage programme for ensuing financial year to SLDC for
preparing an overall outage plan for the State Transmission System as a whole. SLDC shall be
responsible for analyzing the outage schedules of all Users including SGS, Distribution Licensees,
STU and Transmission Licensee(s) schedules for outage of Transmission network and preparing a
draft annual Outage Plan for the State Transmission System in coordination with the Outage Plan
prepared for the region by ERLDC. The Users shall furnish the information to SLDC as per
Appendix-C.Bihar Electricity Grid Code, 2010

2. SLDC is however authorised to defer the outage in case of any of the
following events:
• Major grid disturbance• System Isolation• Black out in the State• Any other event in the system
that may have an adverse impact on system security by the proposed outage
3. Each User shall obtain approval of SLDC, prior to availing the Outage.
SLDC while permitting any circuit for outage shall issue specific code.
Similarly, no inter user boundary circuits shall be connected back to the
State Transmission System without specific code/approval by SLDC.
This restriction shall however not be applicable to individual Generating Unit(s) of a CPP.7.4Annual
Outage Planning. - 1. Scheduled outage of power stations of capacity 25 MW and above as notified
by SLDC from time to time, will be subject to annual planning.
2. Scheduled outage of power station of 50 MW and above and EHV lines as
notified by ERLDC, will also be subject to annual planning of ERPC
Secretariat in co-ordination with SLDC.
3. SGS (except CPPs) connected to the State Grid shall furnish their
proposed Outage programme for the next financial year in writing by 15th
November each year.
4. SGS Outage programme shall contain details like identification of unit,
reason for outage, generation availability affected due to such outage,
outage start date and duration of outage. SLDC shall review the outage
programme received from SGS on monthly basis to chalk out the outage of
the State Transmission System.
5. SLDC shall also obtain from STU, the proposed outage programme for
Transmission lines, equipments and sub-stations etc. for next financial year
by 15th November each year. STU outage programme shall contain
identification of lines/ substations, reasons for outage, outage start date and
duration of outage.
6. Scheduled outage of power stations and EHV transmission lines affecting
regional power system shall be affected only with the approval of ERPC in
coordination with SLDC.Bihar Electricity Grid Code, 2010

7. Scheduled outage of power stations of capacity 25 MW and above, of all
EHV lines and HV lines forming interconnection between two EHV
substations (and those notified as such by SLDC) shall be approved by
SLDC, 24 hours in advance based on prevalent operating conditions.
8. In respect of scheduled outage referred in this Section a calendar shall be
formulated in respect of annual outage planning for the ensuing financial
year. Such outage plan shall be deliberated and finalised in the meeting of
the Operation and Co-ordination Committee (OCC). to be constituted by
SLDC at the State level.
a. SLDC shall submit the proposed annual outage plan of the next financial year to ERPC Secretariat
by 30th November of preceding year.b. Final annual outage plan shall be communicated to ERPC
Secretariat by 15th January of each year.7.5Availing of shutdowns schedule. - SLDC would review on
daily basis the outage schedule for the next two days and in case of any contingency or conditions
described in Section 5.7.4(g) of the IEGC, defer any planned outage as deemed fit clearly stating the
reasons thereof. The revised dates in such cases would be finalized in consultation with the User.
8. Contingency Planning.
- 8.1. Introduction -This Section describes the steps in the recovery process to be followed by all
Users in the event of total or partial blackouts of the State Transmission System or Regional
System.8.2Objective. - The objective of this Section is to define the responsibilities of all Users to
achieve the fastest recovery in the event of the State Transmission System or Regional System
blackout, taking into account essential loads, generator capabilities and system
constraints.8.3Contingency Planning Procedure. - 1. SLDC shall be prepared to efficiently handle
the following types of contingencies and restoration of system back to normal:• Partial system black
out in the State due to multiple tripping of the Transmission lines emanating from power
stations/sub-stations• Total black out in the State/Region• Synchronisation of system islands and
system split
2. In case of partial black out in the system/State, priority is to be given for
early restoration of power station units, which have tripped. Start up power
for the power station shall be extended through shortest possible route and
within shortest possible time from adjoining substation/ power station where
the supply is available. Synchronising facility at all power stations and 220
kV sub-station having interconnection with ISTS shall be available.Bihar Electricity Grid Code, 2010

3. In case of total regional black out, SLDC In-charge shall co-ordinate and
follow the instructions of ERLDC for early restoration of the entire grid.
Startup power to the thermal stations shall be given by the hydel stations or
through interstate supply, if available. All possible efforts shall be made to
extend the hydel supply to the thermal power stations through shortest
transmission network so as to avoid high voltage problem due to low load
conditions. For safe and fast restoration of supply, SLDC shall formulate the
proper sequence of operation for major generating units, lines, transformers
and load within the State in consultation with ERLDC.The sequence of
operation shall include opening, closing/tripping of circuit breakers,
isolators, on-load tap-changers etc.
8.4Restoration Procedure. - 1. Detailed procedure for restoration of the State Transmission System
shall be prepared by SLDC for the following contingencies and shall be in conformity with the
System Restoration Procedure of the Eastern Region prescribed under IEGC.- Total System Black
out- Partial System Blackout- Synchronisation of System Islands and System Split
2. The restoration process shall take into account the generator capabilities
and the operational constraints of Regional and the State Transmission
System with the object of achieving normalcy in the shortest possible time.
All Users should be aware of the steps to be taken during major Grid
Disturbance and system restoration process.
8.5Special Considerations. - 1. During restoration process following the State Transmission System
or Regional System blackout conditions, normal standards of voltage and frequency need not be
applied and left to the discretion of the SLDC.
2. Distribution Licensees with essential loads shall separately identify
non-essential components of such loads, which may be kept off during
system contingencies. They shall also draw up an appropriate schedule with
corresponding load blocks in each case. The nonessential loads can be put
on only when system normalcy is restored, as advised by SLDC.
3. All Users shall pay special attention to carry out the procedures so that
secondary collapse due to undue haste or inappropriate loading is avoided.
4. Despite the urgency of the situation, careful, prompt and complete logging
of all operations and operational messages shall be ensured by all Users to
facilitate subsequent investigation into the incident and the efficiency of theBihar Electricity Grid Code, 2010

restoration process. Such investigation shall be conducted promptly after
the incident and placed before the Grid Code Review Panel in its next
meeting.
9. Cross Boundary Safety.
- 9.1. Introduction -This Section specifies the requirements for safe working practices for
maintenance of equipment associated with cross boundary operations. It lays down the procedure to
be followed when work is required to be carried out on electrical equipment that is connected to
another User's system.9.2Objective. - The objective of this Section is to achieve an agreement and
consistency on the principles of safety as prescribed in the Indian Electricity Rules 1956 which are in
force for time being and will be replaced by the Rules made under Electricity Act, 2003 when
working across the inter user boundary between one User and another User.9.3Designated Officers.
- STU and all Users shall nominate suitable authorized persons to be responsible for the
co-ordination of safety across their boundary. These persons shall be referred to as Designated
Officer(s) (or control person(s).9.4Procedure. - 1. STU shall issue a list of Designated Officers
(names, designations and telephone numbers) to all Users who have a direct inter user boundary
with STU or other Users. This list shall be updated promptly whenever there is change of name,
designation or telephone number.
2. All Users with a direct inter user boundary with STU or other User system
shall issue a similar list of their Designated Officers to STU or other User(s),
which shall be updated promptly whenever there is a change in the list.
3. Whenever work across a cross boundary / an inter-user boundary is to be
carried, the Designated Officer of the User including STU itself, wishing to
carry out work shall personally contact the other relevant Designated Officer.
If the Permit to Work (PTW) cannot be obtained personally, the Designated
Officers shall contact through telephone and exchange Code words to
ensure correct identification of both agencies.
4. Should the work extend over more than one shift, the Designated Officer
shall ensure that the relief Designated Officer is fully briefed on the nature of
the work and the code words in operation.
5. The Designated Officer(s) shall co-operate to establish and maintain the
precautions necessary for the required work to be carried out in a safe
manner. Both the established isolation and the established earth shall be
locked in position, where such facilities exist, and shall be clearly identified.Bihar Electricity Grid Code, 2010

6. Work shall not commence until the Designated Officer of the User
including STU itself, wishing to carry out the work, is satisfied that all the
safety precautions have been established. This Designated Officer shall
issue agreed safety documentation (PTW) to the working party to allow work
to commence. The PTW in respect of specified EHV lines and other
interconnections shall be issued with the consent of SLDC.
7. When work is completed and safety precautions are no longer required,
the Designated Officer who has been responsible for the work being carried
out shall make direct contact with the other Designated Officer to return the
PTW and for removal of those safety precautions. Return of PTW in respect
of specified EHV lines and interconnections shall be informed to SLDC.
8. The equipment shall only be considered as suitable for connecting back to
service when all safety precautions are confirmed as removed, by direct
communication using code word contact between the two Designated
Officers, and after ensuring that the return of agreed safety documentation
(PTW) from the working party has taken place.
9. STU shall develop an agreed written procedure for inter-user boundary
safety and continually update it.
10. Any dispute concerning inter user Boundary Safety shall be resolved at
the level of STU, if STU is not a party. In case STU is a party, the dispute shall
be referred to BERC for resolution of the dispute.
9.5Special Consideration. - 1. For inter-user boundary between STU and other User's circuits, all
Users shall comply with the agreed safety Rules, which must be in accordance with IE Rules or Rules
framed under the Act.
2. Each Designated Officer shall maintain a legibly written safety logbook, in
chronological order, of all operations and messages relating to safety
co-ordination sent and received by him. All safety logs shall be retained for a
period of not less than 10 years.
10. Operational Event/Accident Reporting.
- 10.1. Introduction -This Section describes the reporting procedure of reportable events in the State
Transmission SystemThis Section applies to SLDC, STU and all entities embedded within StateBihar Electricity Grid Code, 2010

power system that are under the control and supervision of SLDC.10.2Objective. - The objective of
this Section is to define the events/ incidents to be reported, the reporting route to be followed and
the information to be supplied to ensure a consistent approach in reporting of incidents and
accidents in the State Transmission System.10.3Reportable Events. - Any of the following events
that could affect the State Transmission System requires reporting:a. Exceptionally high / low
system voltage or frequency.b. Serious equipment problem relating to major circuit breaker,
transformer or bus bar.c. Loss of major Generating Unit. System split, State Transmission System
breakaway or Black Start.d. Tripping of Transmission Line, ICT (Interconnecting transformer) and
capacitor banks.e. Major fire incidents.f. Force-Majeure condition like flooding or lightning etc.g.
Major failure of protection.h. Equipment and Transmission Line overload.i. Accidents-Fatal and
Non-Fatal.j. Load Crash / Loss of Loadk. Excessive Drawal deviations.I. Minor equipment
alarms.The last two reportable incidents are typical examples of those which are of lesser
consequence, but which still affect the State Transmission System and can be reasonably classed as
minor. They will require corrective action but may not warrant management reporting until these
are repeated for sufficient time.10.4Reporting Procedure. - 1. Reporting Time for events and
accidents. - All reportable incidents occurring on lines and equipment of 33 kV and above and all the
lines on which there is the inter user flow affecting the State Transmission System shall promptly be
reported orally by the User whose equipment has experienced the incident (the reporting User) to
any other significantly affected Users and to SLDC.The reporting user should submit a written
confirmation to SLDC within one hour of such oral report.If the reporting incident is of major
nature then the Reporting User shall submit an initial written report within two hours to SLDC. This
has to be further followed up by the submission of a comprehensive report within 48 hours of the
submission of the initial written report. In other cases the Reporting User shall submit a report
within 5 (five) days to SLDC.
2. SLDC shall call for a report from any User on any reportable incident
affecting other Users and STU, in case the same is not reported by such User
whose equipment might have been source of the reportable incident.
The above shall not relieve any User from the obligation to report events in accordance with IE
Rules 1956 - (Language used in the Code to be used). The format of such a report shall be as agreed
by the State Grid Code Review Panel, but will typically contain the following information:i. Location
of incident.ii. Date and time of incident.iii. Plant or equipment involved.iv. Details of relay
indications with nature of fault implications, Antecedent conditions like line flows, bus voltage,
generation and demandv. Supplies and quantum interrupted and duration if applicable.vi. Amount
of generation lost if applicable and its durationvii. Brief description of incident.viii. Estimate of time
to return to service.ix. Name of Organisationx. Possibility of alternate arrangement of
supply10.5Reporting Form. - The standard reporting Form other than for accidents shall be as
agreed from time to time by the Grid Code Review Panel. A typical form is attached
(APPENDIX-E).10.6Major Grid Incidence. - (a) Following a major grid incident, SLDC and other
Users shall cooperate to enquire and establish the cause of such failure and make appropriate
recommendations. SLDC shall report the occurrence of such major grid failure to the Commission in
writing as well as ERLDC immediately for information and shall submit the enquiry report to the
Commission within two months of the incident. Analysis of major grid disturbance in the Intra StateBihar Electricity Grid Code, 2010

Power System soon after their occurrence shall be done by a Protection subcommittee constituted by
STU.(b)Periodic Reports - All distribution licensees shall send a weekly report to SLDC on the
performance of their respective systems which should cover the following information:(i)Voltage
profile at all Sub/Stations (66KV) 132KV and above.(ii)Average, maximum, minimum demand
(both MW and MVAR) met at such S/Stns.(iii)Quantum and duration of load shed, with
reasons(iv)Outage of major elements(v)Network constraints(vi)Daily energy consumed and energy
exchanged by the DISCOM(c)SLDC shall post in its website a monthly performance report of the
State as a whole covering:(i)Hourly demand met and generation for peak any and minimum
demand met day. Also the average daily off-peak and peak demands met.(ii)Daily average
consumption(iii)Station-wise daily maximum, minimum and average generation (MW), together
with daily energy generation(iv)Instances of non-compliance of the State Grid Code(v)Progress of
construction of new generating units, lines and transformers. Details of generation and transmission
outages during the month.10.7Accident Reporting. - Report of accidents shall be in accordance with
the Section 161 of the Electricity Act, 2003 and the Rules framed thereunder. Receipt of accident
and failure of supply or transmission of electricity shall be in the specified Form to the Commission
and the Electrical Inspector.
Chapter 4
Scheduling and Despatch Code
11. Scheduling and Despatch.
- 11.1. Introduction -This Section specifies the procedure to be adopted for the scheduling and
despatch of State Generating Station (SGS) and Inter-State Generating Station (ISGS) to meet
system demand and drawal allocation requirements of Distribution Licensees.11.2Objective. - The
objective of this Section is to detail the actions and responsibilities of SLDC in preparing and issuing
a daily schedule of generation to the SGSs within its ambit, drawal schedule of various distribution
licensees and other entities utilizing the Intra-State Transmission System, furnishing requisition
from Eastern Region ISGS to ERLDC, including details of bilateral transactions to be scheduled with
other regional entities.11.3General. - The following specific points would be taken into consideration
while preparing and finalising the schedules:
1. SLDC will issue despatch instructions required to regulate all generation
and imports from IPPs / CPPs according to the 15-minute day ahead
generation schedule. In the absence of any despatch instruction by SLDC,
SGS shall generate/ export according to the day ahead generation schedule.
2. The SLDC shall regulate the overall State generation in such a manner that
generation from following types of power stations shall not be curtailed
except under abnormal operating conditions.Bihar Electricity Grid Code, 2010

(i)Run of river or canal based hydro stations.(ii)Storage type hydro-stations when water level is at
peak reservoir level or expected to touch peak reservoir level as per inflows.(iii)Generation from
non-conventional sources like wind, solar that cannot be stored/ controlled.
3. Despatch instructions to SGS shall be in standard format to be finalized by
SLDC.
4. The algebraic sum of scheduled drawals from ISGS, long term open
access, and short term open access arrangements shall be the net drawal
schedule for the control area of the utility.
11.4Generation Scheduling. - (1) Steps in Scheduling. - Step by step procedure for scheduling of
ISGS and SGS/IPP/CPP embedded in the State power system (not having the status of regional
entity shall be as described below:i. By 9.00 hours every day each SGS shall intimate to SLDC the
station wise ex- power plant MW and MWh capabilities foreseen for the next day i.e. between 00.00
to 24.00 hrs of the following day, at 15 minutes interval.ii. By 9.00 hours every day each
Distribution Licensees bulk power consumer shall intimate SLDC the overall requirement in MW
and MWh for the next day at 15 minutes interval.iii. After receipt of the information in regard to the
availability from different sources, the SLDC shall review aggregate generating capability of ISGS,
SGS and the bilateral interchanges, if any, vis-a-vis Distribution Licensees requirements.iv. By 15.00
hrs, SLDC shall finalise (a) generation schedule of SGS and (b) drawal schedule of each Distribution
Licensees. It shall accordingly advise each Distribution Licensees of their drawal schedule and will
workout and convey to ERLDC for net drawal schedule in each of the ISGS along with the bilateral
exchanges agreed or intended to be had with the other State/States and the estimates of demand /
availability in the State and additional power it would like to draw subject to availability.v. By 1700
hrs, ERLDC shall convey to SLDC the drawal schedule for Bihar State from each of the ISGS and
other short-term bilateral, medium term and long-term schedules and SLDC shall convey to SGS the
generation schedule and drawal schedule to Distribution Licensees by 1900 hrs.vi. SGS and each
Distribution Licensees may inform the modifications / changes to be made, if any, in the above
schedule to SLDC by 21.30 hours.vii. SLDC after considering the same shall convey revised schedule
to ERLDC by 22.00 hrs.viii. On receipt of information and after due consultations, the ERLDC shall
issue the final generation and drawal schedule by 23.00 hrs, and SLDC shall inform the same to all
concerned.(2)SLDC shall prepare the day ahead generation schedule keeping in view the
following:(i)Transmission System constraints from time to time.(ii)15 minute load requirements as
estimated by SLDC.(iii)The need to provide operating margins and reserves required to be
maintained.(iv)The availability of generation from SGS, Central Sector Generators and others
together with any constraint in each case.(3)During the day of operation, the generation schedule
may be revised under following conditions:i. In case of forced outage of a unit of any SGS, SLDC
may revise the generation schedule on the basis of revised declared capability by the affected SGS.ii.
ERLDC may revise the schedule of drawal from Eastern Region and consequently SLDC shall
enforce the revisions within Bihar.11.5Drawal Scheduling. - SLDC is responsible for collection,
examination and compilation of drawal Schedule for each Distribution Licensee in prescribed
manner and at the prescribed time. Each Distribution Licensee shall supply to SLDC 15- minuteBihar Electricity Grid Code, 2010

average demand estimates in MW for the day ahead.11.6Generation Despatch. - 1. SGS and
embedded CPP/IPP shall comply promptly with a despatch instruction issued by SLDC unless this
action would compromise the safety of plant or personnel. SGS and embedded CPP/IPP shall
promptly inform SLDC in the event of any unforeseen difficulties in carrying out an instruction.
2. Despatch instructions shall be issued by E-Mail /Fax/ telephone, confirmed
by exchange of name of operators sending and receiving the same and
logging the same at each end. All such oral instructions shall be complied
with forthwith and written confirmation shall be issued promptly by FAX,
tele-printer or otherwise
11.7Responsibilities. - 1. SLDC shall monitor actual power drawal against scheduled power drawal
and regulate internal generation and demand to maintain this schedule. SLDC shall also monitor
reactive power drawal and availability of capacitor banks.
2. Generating Stations within the State shall follow the despatch instructions
issued by SLDC.
3. Distribution Licensees and Open Access Customers shall comply with the
instructions of SLDC for managing load & reactive power drawal as per
system requirement.
12. Frequency and Voltage Management.
- 12.1. Introduction -This Section describes the method by which all Users of the State Transmission
System shall co-operate with SLDC and STU in contributing towards effective control of the system
frequency and managing the voltage of the State Transmission System. The State Transmission
System normally operates in synchronism with the Eastern Region Grid and ERLDC has the overall
responsibility of the integrated operation of the Eastern Regional Power System. The constituents of
the Region are required to follow the instructions of ERLDC for backing down generation,
regulating loads, MVAR drawal etc. to meet the objective. SLDC shall accordingly instruct
Generating Units to regulate Generation/Export and adhere to active and reactive power generation
within their respective declared parameters. SLDC shall also regulate the load as may be necessary
to meet the objective. The State Transmission System voltage levels can be affected by Regional
operation. The STU/SLDC shall optimize voltage management by adjusting transformer taps (On
Line Tap Changers) to the extent available and switching of circuits/ capacitors/ reactors and other
operational steps. SLDC will instruct SGS to regulate MVAr generation within their declared
parameters. SLDC shall also instruct Distribution Licensees to regulate demand, if necessary by
operating reactors/ capacitor banks nearest to load point in 33KV system.12.2Objective. - The
objectives of this Section are as follows:(1)To define the responsibilities of all Users in contributing
to frequency and voltage management.(2)To define the actions required to enable SLDC and STU to
maintain the State Transmission System voltages and frequency within acceptable levels inBihar Electricity Grid Code, 2010

accordance with IEGC guidelines as well as Planning and Security Standards for the State
Transmission System specified by the Commission, if any.12.3Frequency Management. - (1) The
rated frequency of the system shall be 50 Hz and shall normally be regulated within the limits
prescribed in IEGC Clause 4.6(b) as also specified in Connection Conditions. STU and SLDC shall
make all possible efforts to ensure that grid frequency remains within 49.5 Hz- 50.2 Hz
band.(2)Falling frequency. - Under falling frequency conditions, SLDC shall take appropriate action
to issue instructions, in co-ordination with ERLDC to arrest the falling frequency and restore
frequency within permissible range. Such instructions may include despatch instruction to SGS
and/or instruction to Distribution Licensees and Open Access Customers to reduce load demand by
appropriate manual and/or automatic load shedding.(3)Rising frequency. - Under rising frequency
conditions, SLDC shall take appropriate action to issue instructions to SGS in co-ordination with
ERLDC to arrest the rising frequency and restore frequency within permissible range. SLDC shall
also issue instructions to Distribution Licensees and Open Access Customers in coordination with
ERLDC to lift Load shedding (if exists) in order to take additional load. In case of Load Crash, SLDC
shall take steps as per Clause 6.6 of the Grid Code.12.4Voltage Management. - (1) Users using the
State Transmission System shall make all possible efforts to ensure that the grid voltage always
remains within the limits specified in IEGC at clause 5.2 (r) and IE Rules 1956 as re-produced
below:
Voltage (KV r ms)  
Nominal Maximum Minimum
400 420 380
220 245 198
132 145 122
(2)STU and/or SLDC shall carry out load flow studies based on operational data from time to time
to predict where voltage problems may be encountered and to identify appropriate measures to
ensure that voltages remain within the defined limits. On the basis of these studies, SLDC shall
instruct SGS to maintain specified voltage level at interconnecting points.SLDC shall continuously
monitor 220/132kV voltage levels at strategic substations.(3)SLDC shall take appropriate measures
to control State Transmission System voltages, which may include but not be limited to transformer
tap changing, capacitor/reactor switching including capacitor switching by Distribution Licensees at
66 KV & 33 KV substations, operation of Hydro unit as synchronous condenser and use of MVAr
reserves with State Generating Stations within technical limits agreed to between STU and
Generators. Generators shall inform SLDC of their reactive reserve capability promptly on
request.(4)Distribution Licensees and Open Access Customers shall participate in voltage
management by providing Local VAR compensation (as far as possible in low voltage system close to
load points) such that they do not depend upon EHV grid for reactive support.
13. Monitoring of Generation and Drawal.
- 13.1. Introduction - The monitoring of SGS output, active and reactive reserve capacity is
important to evaluate the performance of generation plants.The monitoring of actual drawal against
schedule is important to ensure that STU and Distribution Licensees contribute towards improvingBihar Electricity Grid Code, 2010

system performance and observe Grid discipline.13.2Objective. - The objective of this Section is to
define the responsibilities of all SGS in monitoring of Generating Unit's reliability and performance,
and STU's/ Discoms' compliance with the scheduled Drawal to assist SLDC in managing voltage and
frequency.13.3Monitoring Procedure. - (1) For effective operation of the State Transmission System,
it is important that a SGS's declared availability is realistic and that any departures are continually
and invariably fed back to the Generator to help effect improvement.(2)The SLDC shall continuously
monitor Generating Unit outputs and Bus voltages. More stringent monitoring may be performed at
any time when there is reason to believe that a SGS's declared availability may not match the actual
availability or declared output does not match the actual output.(3)SLDC can ask for putting a
generating station to demonstrate the declared availability by instructing the generating station to
come up to the declared availability within time specified by Generators.(4)SLDC shall inform SGS,
in writing, if the continual monitoring demonstrates an apparent persistent or material mismatch
between the despatch instructions and the Generating Unit output or breach of the Connection
Conditions. Continued discrepancies shall be resolved by the Grid Code Review Panel with a view to
either improve performance in future, providing more realistic declarations or initiate appropriate
actions for any breach of Connectivity Conditions. Continued default by a generating station entails
penalty as may be determined by the Commission.(5)SGS (excluding CPPs) shall provide to SLDC
15-minute block-wise generation summation outputs where no automatically transmitted metering
or SCADA/RTU equipment exists. CPPs shall provide to SLDC 15-minute block-wise export / import
MW and MVAr.(6)The SGS shall provide any other logged readings that SLDC may reasonably
require, for monitoring purposes where SCADA data is not available.13.4Generating Unit Trippings.
- (1) SGS shall promptly inform SLDC of the tripping of a Generating Unit, with reasons in
accordance with Section 10 'Operational Event/Accident Reporting'. SLDC shall intimate ERLDC
about the trippings and their restoration. SLDC shall keep a written log of all such trippings,
including the reasons with a view to demonstrating the effect on system performance and
identifying the need for remedial measures.(2)SGS shall submit a more detailed report of
Generating Unit tripping to SLDC on monthly basis.13.5Monitoring of Drawal. - (1) SLDC shall
continuously monitor actual MW Drawal by Distribution Licensees and other users against their
schedules through use of SCADA equipment wherever available, or otherwise using available
metering. SLDC shall request ERLDC and adjacent States as appropriate to provide any additional
data required to enable this monitoring to be carried out.(2)SLDC shall continuously monitor the
actual MVAr drawal to the extent possible. This will be used to assist in State Transmission System
voltage management.13.6Data Requirement. - SGS shall submit data to SLDC as listed in Data
Registration Section (Appendix C-2)
Chapter 5
Protection Code
14. Protection.
- 14.1. introduction -In order to safeguard the State Transmission System and Users' system from
faults occurring in other User's system, it is essential that certain minimum standards for protection
be adopted. This Section describes these minimum standards.14.2Objective. - The objective of thisBihar Electricity Grid Code, 2010

Section is to define the minimum protection requirements for any equipment connected to the State
Transmission System and thereby minimise disruption due to faults. This code applies to all users of
the STU.14.3General Principles. - STU, SGS, other embedded generators DISCOMS and other bulk
consumers shall abide by the provisions contained in Section 6, Part-1 of the CEA regulations on
Technical Standards for connectivity to the grid.(1)No item of electrical equipment shall be allowed
to remain connected to the State Transmission System unless it is covered by minimum specified
protection aimed at reliability, selectivity, speed, stability and sensitivity.(2)All Users shall
co-operate with STU to ensure correct and appropriate settings of protection to achieve effective,
discriminatory removal of faulty equipment within the target clearance time specified in this
Section.(3)Protective Relay settings shall not be altered, or protection relays bye-passed and/or
disconnected without consultation and agreement between all affected Users. In a case where
protection is bye-passed and/or disconnected by an agreement, then the cause must be rectified and
the protection restored to normal condition as quickly as possible. If agreement has not been
reached, the electrical equipment shall be removed from service forthwith.14.4Protection
Coordination. - The settings of protective relays starting from the generating unit upto the remote
end of 132 kV / 33 kV lines shall be such that only the faulty Section is isolated under all
circumstances.The STU /Transmission Licensee shall notify the initial settings and any subsequent
changes to the Users from time to time. Routine checks on the performance of the protective relays
shall be conducted and any malfunction shall be noted and corrected as soon as possible. The STU /
Transmission Licensee shall conduct the required studies for deciding the relay settings, with the
data collected from the Users. If necessary, Protection Coordination Committee with representatives
from the generating companies, STU and Distribution Licensees and bulk consumers connected to
STU shall be constituted to meet periodically to discuss any malfunctions, changes in the system
configuration, if any, and possible revised settings of relays.14.5Fault Clearance Times & Short-time
Ratings. - (1) From stability consideration, the minimum short circuit current rating and time and
the maximum fault clearance times for faults on any User's system directly connected to the
StateTransmission System, or any faults on the State Transmission System itself, are as follows:
Nominal
VoltageMinimum Short Circuit current rating &duration for
SwitchgearTarget Fault clearance
Time
KV KA(rms) Seconds msec.
220 KV 40 1 160
132 KV 40 1 160
(2)Slower fault clearance times for faults on a Users system if it already exists, may be agreed to but
only if, in STU's opinion, system conditions allow this. STU shall specify the required opening time
and rupturing capacity of the circuit breakers at various locations for STU and Distribution
Licensees / Open Access Customers directly connected to Transmission System. At generating
stations, line faults should be cleared at the generation station end within the critical clearing time
so that the generators remain in synchronism.14.6Generator Requirements. - All Generating Units
and all associated electrical equipment of the Generating Units connected to the State Transmission
System shall have adequate protection so that the State Transmission System does not suffer due to
any disturbances originating from the Generation units. The generator protection schemes shall
cover at least Differential protection, back up protection, Stator & Rotor Earth fault protection, fieldBihar Electricity Grid Code, 2010

ground/field failure protection (not applicable to brush-less excitation system), negative sequence
protection, under frequency, over flux protection, inter-turn Differential protection for generator,
restricted E/F for Generator Transformer, back- up impedance protection, pole slipping protection
(applicable to units above 200MW), reverse power protection etc.14.7Transmission Line
Requirements. - (1) General. - Every EHV line taking off from a Generating Station or a sub-station
or a switching station shall have protection and back up protection as mentioned below. STU. shall
notify Users of any changes in its policy on protection. Switchgear equipment and Relay Panels for
the protection of lines of STU taking off from a Generating Station shall be owned and maintained
by the Generator. Any transmission line related relay settings or any change in relay settings will be
carried out by the Generator in close co-ordination and consultation with STU.. Carrier cabinets /
equipment, Line matching units including wave traps and communication cable shall be owned and
maintained by STU. All Generators shall provide space, connection facility, and access to STU for
such purpose.(2)220 KV Transmission Lines. - All 220 KV transmission lines owned by STU shall
have two fast acting protection schemes.Main 1 Protection scheme shall be numeric, three zone,
non-switched fast acting distance protection scheme with permissible inter-trip at remote end (in
case of zone-2 fault). The scheme shall have power swing blocking, location of fault recording,
disturbance recording, event logger, communication port, as well as Local Breaker Backup
(LBB).Main 2 Protection scheme shall be preferably numeric, three zone, switched/ non-switched
fast acting distance protection scheme having all features as main-1 except auto reclosing and Local
Breaker Backup (LBB). This protection should preferably be fed from separate core of CT and DC
source.For back-up protection, three directional IDMTL over current relays and unidirectional earth
fault relay shall be provided.(3)132 KV Lines. -• A single scheme three zone, non-switched numeric
distance protection with standard built in features like single and three phase tripping, carrier
inter-tripping, IDMT over current and earth fault, power swing blocking and LBB protection shall be
provided as main protection.• The backup protection shall be at least two directional IDMTL over
current relays and one directional earth fault relay.• For short transmission radial lines, appropriate
alternative protection schemes may be adopted.• For 33 KV feeders, emanating from Grid S/S,
adequate protection with proper co-ordination should be provided at Grid S/S.14.8Transformer
Requirements. - (1) The protection of EHV Transformers, Power Transformers shall be as per
revised manual on transformers published by Central Board of Irrigation and Power (CBIP)
Publication No. 275.The following minimum protections should be provided for transformers:i. All
220 KV class power transformers shall be provided with numeric fast acting differential, REF, open
delta (Neutral Displacement Relay) and over-fluxing relays. In addition, there shall be back up
IDMTL over current and earth fault protection with directional features. For parallel operation, such
back up protection shall have inter-tripping of both HV and LV breakers. For protection against
heavy short circuits, the over current relays should incorporate a high set instantaneous element. In
addition to electrical protection, transformer own protection viz. Buchholz, OLTC oil surge, gas
operated relays, winding temperature protection, oil temperature protection, PRV relay shall be
provided for alarm and trip functions.ii. For 132 KV and 33 KV class transformers of capacity 10
MVA and above, the protection shall be same as mentioned in 14.8 (1) (i) except over-fluxing, REF
and PRV relays.iii. For 132 KV and 33 KV class power transformers less than or equal to 10 MVA
provided on either Transmission or Distribution System, over current and E/F with high set
instantaneous element along with auxiliary relays for transformer trip and alarm functions as per
transformer requirements, shall be provided.Transformer shall be protected from lightningBihar Electricity Grid Code, 2010

arrestors from H.V and L.V both sides.Pressure Release Valve (PRV) and differential protection
should be installed for protection of 132 KV class Transformer of Capacity 10 MVA and above.(2)In
addition to electrical protection, gas operated relays, winding temperature protection and oil
temperature protection shall be provided in all transformers.14.9Sub-Station Fire Protection. -
Adequate precautions shall be taken and protection shall be provided against fire hazards to all
Apparatus of the Users conforming to relevant Indian Standard Specification and provisions in I.E.
Rules 1956 or Rules framed under Electricity Act 2003.14.10Calibration and Testing. - The
protection scheme shall be tested at each 220 KV, 132 KV substation by STU once in a year or
immediately after any major fault, which ever is earlier.Setting, co-ordination, testing and
calibration of all protection schemes pertaining to generating units/stations shall be responsibility
of respective SGC.
Chapter 6
Metering Code
15. Metering Code.
- 15.1. Introduction -This code prescribes a uniform policy in respect of electricity metering in the
State Transmission System amongst the utilities i.e. STU, Generating Companies, Distribution
Licensees and for the Open Access Customers on the State Transmission system and EHV
Consumers (of Distribution Licensees) directly connected to the State Transmission
System.15.2Objective. - The objective of this Section is to define minimum acceptable standards of
metering which shall provide proper metering of various operating system parameters for the
purpose of accounting, commercial billing and settlement of electrical energy and to provide
information which shall enable to operate the system in economic manner.15.3Scope. - (1) The scope
of this code covers the practices that shall be employed and the facilities that shall be provided for
the measurement and recording of various parameters like active/reactive/apparent power/energy,
power factor, voltage, frequency etc.(2)This code sets out or refers to the requirements of metering
at generating stations, sub-stations and interfaces for tariff and operational metering.(3)This code
also specifies the requirement for calibration, testing and commissioning of metering equipments
viz. energy meters with associated accessories, current transformers and voltage transformers. The
code broadly indicates the technical features of various elements of the metering, data
communication and testing system.15.4Applicability. - This Metering Code shall apply
to:(ii)STU/Transmission Licensees(iii)Generating Stations connected to State Transmission
System(iv)Distribution Licensees connected with State Transmission System(v)EHV Consumers of
Distribution Licensee(s) directly connected to State Transmission System(vi)Open Access
Customers availing Open Access on State Transmission system(vii)Captive Generators connected to
State Transmission System15.5Reference Standards. - All the equipment installed under this Code
shall necessarily conform to the relevant standards as specified in the Central Electricity Authority's
Standards/Regulations on Installation and Operation of Meters notified on 17/03/200715.6Meter
Installation. - 1. Ownership. - The ownership of the metering system shall be as provided in relevant
agreement governing exchange of power and if no agreement exists then the ownership of the
metering system shall belong to the User in whose premises the metering equipment is installed.Bihar Electricity Grid Code, 2010

2. Right to Install Energy Meters. - Each User shall extend necessary
assistance and make available the required space to the other User for
installation of the metering equipment and provide required outputs of the
specified current and voltage transformers to facilitate installation of Meters,
RTUs and associated equipment in their premises.
3. Access to Equipment and Data. - Each User on request, shall grant full
right to install metering equipments and RTUs to other User's employees,
agents/duly authorized representative. The other Users shall also have
access to metering locations for inspecting, testing, calibrating, sealing,
replacing the damaged equipment, collecting the data, joint readings of
meters and metering equipments, and other functions necessary jointly or
otherwise as mutually agreed.
4. Operation and Maintenance of the Metering System. - The operation and
maintenance of the metering system includes proper installation, regular
maintenance of the metering system and RTUs, checking of errors of the
CTs, VTs and meters, proper laying of cables and protection thereof,
cleaning of connections/joints, checking of voltage drop in the CT/VT leads,
condition of meter box and enclosure, condition of seals, regular/daily
reading meters and regular data retrieved through CMRI, attending any
breakdown/fault on the metering system etc.
5. Type of Meters and Metering Capability. - The meters shall be all electronic
(static) poly phase tri-vector type having facility to measure active, reactive
and apparent energy/power in all four quadrants i.e. a true import-export
meter. All inter user meters shall be bi-directional while capacitor bank
meters and substation aux. meters may be unidirectional. ABT compliant
energy meters shall be provided at such interface points, wherever the
energy exchange is based on Availability Based Tariff (ABT).
15.7Various Standards for Metering Equipment. - (1) The minimum specifications for the metering
equipment are given below.
SI. No. ParticularsMeter
Type
Main &
CheckBack up Capacitor
BankSub-Station
AuxiliaryInter
DistributionSecondary
Back upBihar Electricity Grid Code, 2010

Licensees
1 2 3 4 5 6 7 8
(1) Accuracy class       
 (a) Meter 0.2 S 0.2 S 0.5 S 1.0 0.2 S 0.2 S
 (b) CTs 0.2 0.2 0.2 0.2 0.2 0.2
 (c) PTs / CVTs 0.2 0.2 0.2 0.2 0.2 0.2
 (d) CT-PT sets for 33
KV & 11 KV feeders0.2 Existing Existing Existing Existing Existing
(2)Salient aspect of
meters
 (a) Phase angle and
ratio error
compensation ofCTs
& PTsNo No No No No No
 (b) Communication
port
 (i) Optical port Yes Yes No No Yes Yes
 (ii) For remote
readingYes Yes No No Yes Yes
 (c) Whether both
Import & Export
featuresrequiredYes Yes No No Yes Yes
 (d) Meter memory for
45 daysYes Yes No No Yes Yes
(2)Minimum Technical Requirements for Energy Meteri. Operating System Parameters (for
balanced and unbalanced load):a. Operating Voltage Range: The meter shall work satisfactorily on
110 Volts AC (Line-Line) or 415 Volts AC (Line-Line) with variation range of -40% to +20%.b
Operating Frequency Range: The meter shall work satisfactorily on 50 Hertz with variation range of
-5% to +5%.c. Operating Power Factor Range: The meter shall work satisfactorily over a power
factor range of zero lag to unity to zero lead.ii. Measuring Elements:a The meter shall be 3 phase 4
wire type, capable to record and display import and export kWh, kVArh, kVAh and maximum
demand in kW and kVA for 3 phase 4 wire AC balanced/unbalanced load for a power factor having
range of zero lagging to unity to zero leading in all 4 quadrants. In addition, meter shall also be
capable of displaying, on demand, the present status of supply/load, missing potential, CT polarity,
current unbalance, anomaly occurrence and logging of occurrences as well as load survey data etc.
which shall be down loaded to a user friendly Base Computer System (BCS) through portable data
collection devices or CMRI which shall be connected to optical communication port of the meter.
Meter shall be equipped with self-diagnostic features also and be capable of recording average
values based on their integration on time base for kWh, kVArh, kVAh for at least 45 days. Meter
shall be capable of measuring fundamental as well as total energy including harmonics separately.b.
Energy measurement during demand period shall be such that sampling in the meter is
synchronized with the end of the time block otherwise energy measured in a demand period but notBihar Electricity Grid Code, 2010

stored in that period shall be carried forward. An LED glow or pulse output coincident with end of
each demand period need be provided in the meter so as to ensure that demand integration
coincided the preset time block.iii. Display. - Present meter status, real time and date, cumulative
energy registers, voltage, currents, power factor, present demand, frequency and meter serial
number shall be available on demand through push button. Any interrogation/read operation shall
not delete or alter any stored meter data.iv. Memory. - Numerical values of voltage/current, power
factor and cumulative energy registers as well as anomalies/tampered details alongwith date and
time of logging of and restoration of anomalies (subject to the meter memory space) shall be logged
in the meter memory and shall be available for retrieving with the help of the data collection devices
(CMRI) through meter optical port and down loading to BCS.a. Memory in a static tri-vector meter
shall not get 'erased' after reading or retrieving of data through CMRI. Data shall be retained for a
minimum of 45 days or shall not get erased from meter until replaced by fresh data. However,
desired data can be erased from CMRI, when memory of a CMRI becomes full after downloading of
readings of a number of meters, as there is fixed space made available in CMRI for:i. Energy
registers.ii. Load survey data.iii. Anomaly data etc.When a fresh data is logged in the memory, the
oldest data shall disappear automatically.v. Test terminal blocks . - The test terminal blocks shall be
provided on all meters to facilitate testing of meters in service. Main & back up meters of inter state
/ major generating stations shall be having the feature of draw out type modular units and shall
have automatic CT short circuiting so that meter can be taken out for testing without shut down
requirements.vi. Meter Power Supply. - Meters of inter state / major generating stations shall be
capable of powered with 230 volt alternating current auxiliary supply and 110 volt or 220 volt DC
supply of the substation so that metering core of PT/ CVT is never loaded and in case of shut down
on feeder/breaker, meter can be interrogated locally or remotely. It shall normally be powered by
AC auxiliary supply and shall be switched over to DC supply only when AC auxiliary supply fails.vii.
Battery back-up . - The meter shall have battery back up for its Real Time Clock (RTC).viii. Meter
Programmability. - The meters shall be equipped with necessary hardware/software to suit tariff
requirements such as ABT, TOD, two-part tariff based on SMD as may be called for from time to
time.(3)Minimum Technical Requirement for Current Transformer (CT)a. Three single-phase type
current transformers shall be used for 3 phase 4 wire and 3 phase 3 wire measurement system. The
secondary current rating of the CTs shall be 1 Ampere particularly for 220 KV, 132 KV, 66 KV
measurements. However existing CTs with 5-Ampere secondary current shall also be acceptable
provided the connected meters and instrument have base 5 Ampere current rating. For other
voltages, 1 Ampere or 5 Ampere shall be employed.b. The current transformers shall have dedicated
core for metering and wherever feasible, the cores feeding to main meters and check meters shall be
separate. The errors of the current transformers shall be checked in the laboratory or at site.
However if such facilities are not available, CT test certificates issued by a Government test house or
Government recognized test agency shall be referred to.c. The total burden connected to each
current transformer shall not exceed the rated burden of CT.Total circuit burden shall be kept close
to rated burden of CT for minimum error.(4)Minimum Technical Requirement for Voltage
Transformers (VT)a. Either Electromagnetic Voltage Transformers (EVT) or Capacitive Voltage
transformer (CVT) should be used for metering purpose. Generally, term VT is used to cover either
EVT or CVT. The secondary voltage per phase shall be 110/31/2 volts or 415/31/2 volts. Either
dedicated VTs or dedicated core of VTs shall be provided for metering and that wherever feasible,
VTs (or their cores) feeding to main meters and backup/check meters shall be separate. Fuses ofBihar Electricity Grid Code, 2010

proper rating shall be provided at appropriate locations in the VT circuit,b. The errors of the VTs
shall be checked in the lab or at site. However if such facilities are not available, VT test certificates
issued by Government test house or Government recognized test agency should be referred to.c. The
total burden connected to each VT shall not exceed the rated burden of VT. Voltage drop in VT leads
shall be within the permissible limits.d. The current transformers and voltage transformers shall
meet the requirements as per the relevant standards. Where a combined CT/PT unit is provided, the
accuracy shall be as specified under relevant IS.15.8Testing Arrangement. - (1) Two types of test
facilities shall be available:a. Meter test bench with high accuracy, static source and 0.02S class
electronic reference standard meter (RS Meter) shall be used for testing and calibration of meters.
Meter Testing Laboratories duly equipped with testing benches and other equipments shall be
established at suitable locations for testing and calibration of meters by SGS, STU and Distribution
Licensee. The Meter Testing benches with 0.02S-class reference standard meter shall also be used
for checking and calibration of portable testing equipments.Testing, calibration and maintenance of
Energy Meters shall conform to the requirement of IS: 9792 and Testing equipments shall conform
to Indian Standards Specification IS: 12346.b. Portable test set with static source and electronic
reference meter of 0.1 class shall be used for verification and joint testing of accuracy of static
tri-vector meters at site on regular/routine basis.(2)Separate test terminal blocks for testing of main
and check meters shall be provided so that when one meter is under testing, the other meter
continues to record actual energy during testing period. Where only one/main meter exists, an
additional meter shall be put in circuit to record energy during the testing period of the main meter
so that while the main meter is under testing, the other meter continues to record energy during the
period of meter remaining under testing.(3)Testing at site shall be carried out for all meters once in
a year.(4)The Licensee shall allow the testing of Open Access Customers' meters at third party
(NABL approved) Testing Labs in case the Customers so request for the same. In case of testing by
third party (NABL approved) Testing Labs, the Open Access Customers shall apply with prescribed
fee to the Licensee.15.9Meter Reading. - The STU and concerned Generating Companies, CPP
/Distribution Licensees, Open Access Customers as the case may be shall jointly read the meters
through their authorized representatives preferably on 1st of every month at 12.00 Hrs. / retrieve
meter reading data using CMRV Tele metering.15.10Joint Inspection, Testing, Calibrations. - (1) The
metering system located at metering points between Generating Companies, STU and Distribution
Licensees shall be regularly inspected at least once in a year or at an interval lesser than 1 year as
mutually agreed by both the agencies involved for despatch and receipt of energy. Since the static
tri-vector meters are calibrated through software at the manufacturers' works, only accuracy of the
meters and functioning shall be verified during joint inspection and certified jointly by both the
agencies. After testing, the meter shall be properly sealed and a joint report shall be prepared giving
details of testing work carried out, details of old seals removed and new seals affixed, test results,
further action to be taken (if any) etc. The agency in whose premises the meter is located shall be
responsible for proper security and protection of the metering equipment and sealing
arrangement.(2)Joint inspection shall also be carried out as and when difference in meter readings
exceeds the sum of maximum error as per accuracy class of main and check meter. The meters
provided at the sending end as well as at the receiving end shall be jointly tested/ calibrated on all
loads and power factors as per relevant standards through static phantom load.15.11Sealing. - i.
Tariff metering systems shall be jointly sealed by the authorized representatives of the concerned
agencies as per the procedure agreed upon.ii. Any seal, applied, shall not be broken or removedBihar Electricity Grid Code, 2010

except in the presence of or with the prior consent of the agency affixing the seal or on whose behalf
the seal has been affixed unless it is necessary to do so in circumstances where (a) both main and
check meters are malfunctioning or there occurs a fire or similar hazard and such removal is
essential and such consent can not be obtained immediately (b) such action is required for the
purpose of attending to the meter failure. In such circumstances, verbal consent shall be given
immediately and it must be confirmed in writing forthwith.iii. Each agency shall control the issue of
its own seals and sealing pliers, and shall keep proper register/record of all such pliers and the
authorized persons to whom these are issued.iv. Sealing of the metering system shall be carried out
in such a manner so as not to hamper downloading of the data from the meter using CMRI or a
remote meter reading system.15.12Interface Metering Arrangement. - The metering system shall
comprise of main, check, backup and secondary backup meters. In the event of main meter
becoming defective the order of precedence for billing shall be (a) main (b) check (c) backup (d)
secondary backup.Generating Stations:a. Meters shall be installed on each Generator terminal, at
each Unit Auxiliary Transformer (UAT), and all outgoing feeders at Generating Stations to work out
energy generated and net energy delivered by the Power Station in the Grid.b. For measurement of
energy supplied by major generating stations within the state, meters shall be provided on each
outgoing feeder at the power station designated as main meter for billing purpose as per commercial
agreement and/or Grid Code Connectivity Conditions.c. A Check Meter shall also be provided along
with the Main Meter. Meters on each generator and each auxiliary transformer shall work as backup
meters.(2)Interstate Transmission and Inter-Regional Transmission System. - Metering
arrangement for Inter-State Transmission Lines and for Inter- Regional Transmission System shall
be governed by IEGC. Special Energy Meters (SEM) capable of time-differentiated measurement (15
minutes) of active energy and voltage differentiated measurement of reactive energy as specified by
CTU/ERLDC shall be provided on interstate and inter-regional transmission lines. STU shall
comply with requirement for installation, meter reading & downloading and communication of
readings of Special Energy Meters (SEM) to ERLDC as per operating procedure of ERLDC. STU may
install its own Check Meters at inter-state/inter-regional transmission lines at the periphery of State
Transmission System.(3)Metering between STU-Distribution Licenseea For measurement of power
delivered by STU to Distribution Licensee, metering shall be provided on the LV side of EHV Power
Transformer i.e. 33 KV side of 220/33 KV and 33 KV side of 132/33 KV and 11 KV side of 132/33/11
KV and 11 KV side of 132/11 KV transformers installed in EHV sub-stations.b Operational meters
shall also be provided on all outgoing 33 KV and 11 KV feeders as back-up meter for energy audit on
feeder and reconciliation of energy with respect to energy measured on LV side of EHV Power
Transformer.c. In case of EHV industrial and other consumers directly fed from 220 KV or 132 KV
sub-stations, tariff metering shall be provided on outgoing feeder emanating from EHV
sub-station.(4)Metering between two Distribution Licensee:a. The energy metering shall be
provided at such points of the power lines connecting any two Distribution Systems owned by
different Distribution Licensees so that the measured energy gives correct measurement of
consumption by either Distribution Licensee.b. If installation of metering at such point is not
feasible, it shall be provided at nearest sub-station feeding other Distribution System. In such case,
energy accounting may be in proportion to installed capacity of Distribution Transformers on the
line or as agreed mutually.(5)Sub-station Auxiliary Consumption Metering. - The STU sub-stations
auxiliary consumption shall be recorded on LV side of station auxiliary transformers. If such
transformer(s) is feeding other local load (colony quarters, streetlights etc.) apart from substationBihar Electricity Grid Code, 2010

auxiliary load, separate metering shall be provided on feeder feeding the colony quarters, street
lights, etc.(6)Open Access Customers. - The Inter-State Open Access Customers shall provide
Special Energy Meters. The embedded Open Access Customers within the State Transmission
System shall also provide Special Energy Meters both at the point of injection and point of drawal of
supply. Special Energy Meters (SEM) shall be capable of time-differentiated measurement (15
minutes) of active energy and voltage differentiated measurement of reactive energy as specified by
CTU/ RLDC. The Distribution licensee may provide Check Meters of the same specification as Main
Meters.(7)Operational Metering. - Operational metering shall be provided wherever reasonably
required by STU/ Generating Companies for applications other than tariff
metering.15.13Supervisory Control and Data Acquisition (SCADA). - (1)The STU shall install and
make operative an operational Metering Data Collection System under SCADA for storage, display
and processing of Operational Metering Data. All Users shall make available outputs of their
respective Operational meters to the SCADA interface equipment.(2)The data collection, storage
and display centre shall be the State Load Despatch Centre (SLDC).15.14ABT,Two part and TOD
Tariff Capability. - The metering arrangement for recording Distribution Licensee
consumption/power input in his area of supply shall consist of following:i. Frequency based ABT
compliant meters shall be provided on 33 kV or lower voltage lines feeding each Distribution
Licensee area of supply. The function of these meters will be as under:a. To measure Distribution
Licensee-wise Ul (Unscheduled Interchange) energy and corresponding average frequency during 15
minute block.b. The Distribution Licensee wise summation of kWh, kW, PF, demand, scheduled
interchange/ unscheduled interchange will be done at the main computer station provided at central
billing station or at Load Despatch Centre.c. For this purpose, the various parameters shall be
integrated at one centrally located station preferably at State Load Despatch Centre at Patna
through computer and suitable software.ii. Static tri-vector meters to be provided on LV secondary
side of all EHV transformers. The function/duty of this meter will be as under:a. Measurement of
kWh energy supplied to Distribution Licensee for billing purpose.b. kW/kVA demand and power
factor, 15 minute block-wise as well monthly caused by Discom on each EHV transformer.
Chapter 7
Data Registration Code
16. Data Registration.
- 16.1. Introduction -This Section specifies a list of all data required by STU and SLDC, which is to be
provided by the Users, and data required by Users to be provided by STU at times specified in the
Grid Code. Other Sections of the Grid Code contain the obligation to submit the data and define the
times when data is to be supplied by the Users.16.2Objective. - The objective of this Section is to list
out all the data required to be provided by Users to STU and vice versa, in accordance with the
provisions of the Grid Code.16.3Responsibility. - 1. All Users are responsible for submitting
up-to-date data to STU/ SLDC in accordance with the provisions of the Grid Code.Bihar Electricity Grid Code, 2010

2. All Users shall provide STU and SLDC with the name, address and
telephone number of the person responsible for sending the data.
3. STU shall inform all Users and SLDC of the name, address and telephone
number of the person responsible for receiving data.
4. STU shall provide up-to-date data to Users as provided in the relevant
Sections of the Grid Code.
5. Responsibility for the correctness of data rests with the concerned User
providing the data.
16.4Data to be registered. - 1. Data required to be exchanged has been listed in the Appendices to
this Section under various categories.
2. Changes to Users Data. - Whenever any User becomes aware of a change
to any items of data that is registered with STU, the User must promptly
notify STU of the changes. STU on receipt of intimation of the changes shall
promptly correct the database accordingly. This shall also apply to any data
compiled by STU regarding its own system.
3. Methods of Submitting Data. - a. The data shall be furnished in the
standard formats for data submission and such formats must be used for the
written submission of data to SLDC and STU.
Where standard formats are not appended they would be developed by SLDC or STU in consultation
with Users.b. All data to be submitted under the Schedule(s) must be submitted to SLDC / STU or to
such other department and/or entity as STU may from time to time notify to Users. The name of the
person who is submitting each schedule of data shall be indicated.c. Where a computer data link
exists between a User and SLDC/ STU, data may be submitted via this link. The data shall be in the
same format as specified for paper transmission except for electronic encoding for which some other
format may be more suited. The User shall specify the method to be used in consultation with the
SLDC/ STU and resolve issues such as protocols, transmission speeds etc. at the time of
transmission.
4. Data not supplied. - All Users are obliged to supply data as referred to in
the individual Sections of the State Grid Code and listed out in the Data
Registration Section Appendices. In case any data is not supplied by any
User or is not available, STU or SLDC may, acting reasonably, if and when
necessary, estimate such data depending upon the urgency of the situation.Bihar Electricity Grid Code, 2010

Similarly, in case any data is not supplied by STU, the concerned User may,
acting reasonably, if and when necessary, estimate such data depending
upon urgency of the situation. Such estimates will in each case, be based
upon corresponding data for similar Plant or Apparatus or upon such other
information, the User or STU or SLDC, as the case may be, deems
appropriate.
16.5Special Considerations. - STU and SLDC and any other User may at any time make reasonable
request for extra data as necessary. STU shall supply data, required/requested by SLDC for system
operation, from data bank to SLDC.Appendix AStandard Planning DataA-1 Standard Planning Data
(Generation)For Sgs-ThermalA. 1.1 Thermal (Coal / Gas/Fuel Linked)(1)General
i SiteFurnish location map to scale showing roads,railway lines,
Transmission lines, canals, pondage and reservoirsif any.
iiCoal linkage/ Fuel (Like
Liquefied Natural
Gas,Naphtha etc.) linkageGive information on means of coaltransport/carriage. In
case of other fuels, give details ofsource of fuel and their
transport.
iii Water SourcesGive information on availability of water foroperation of the
Power Station.
iv Environmental State whether forest or other land areas areaffected.
v Site Map (To Scale)Showing area required for Power Station coallinkage, coal
yard, water pipe lines, ash disposal area, colonyetc.
viApproximate period of
construction 
 (2) Connection
i Point of ConnectionFurnish single line diagram of the proposedConnection with
the system.
iiStep up voltage for
Connection (kV) 
 (3) Station Capacity
iTotal Generating Station
capacity (MW)State whether development will be carried out inphases and
if so, furnish details.
iiNo. of units & unit size
(MW) 
 (4) Generating Unit Data
i Steam Generating Unit State type, capacity, steam pressure, streamtemperature etc.
ii Steam turbine State type, capacity.
iii Generator TypeRating (MVA)Speed (RPM)Terminal voltage (KV)Rated
Power FactorReactive PowerCapability(MVAr) in the
range0.95 of leading and 0.85 lagging Short CircuitBihar Electricity Grid Code, 2010

RatioDirect axis(saturated) transient reactance (% on MVA
rating)Direct axis(saturated) sub-transient reactance (% on
MVA rating)Auxiliary PowerRequirementMW and
MVArCapability curveRamp-up and
ramp-downrateGenerator Characteristic curve
iv GeneratorTransformerTypeRated capacity (MVA)Voltage Ratio
(HV/LV)Tap change Range (+ %to - %)Percentage
Impedance (Positive Sequence at Fullload)
A.1.2 Hydro Electric (For SGS)(1)General
iSiteGive location map to scale showing roads,railway lines, and
transmission lines.
iiSite map (To scale)Showing proposed canal, reservoir area, waterconductor system,
fore-bay, power house etc.
iiiSubmerged AreaGive information on area submerged, villagessubmerged,
submerged forest land, agricultural land etc
ivWhether storage type or run
of river type 
vWhether catchment receiving
discharges fromother
reservoir or power plant. 
viFull reservoir level  
viiMinimum draw down level.  
viiiTail race level  
ixDesign Head  
xReservoir level v/s energy
potential curve 
xiRestraint, if any, in water
discharges 
xiiApproximate period of
construction. 
 (2) Connection
iPoint of ConnectionGive single line diagram proposed Connectionwith the
Transmission System.
iiStep up voltage for
Connection (kV) 
 (3) Station Capacity
iTotal Power Station capacity
(MW)State whether development is carried out inphases and if so
furnish details.
iiNo. of units & unit size (MW)  
 (4) Generating Unit DataBihar Electricity Grid Code, 2010

iOperating Head (in Metres) a. Maximumb. Minimumc. Average
 Hydro UnitCapability to operate as synchronous condenserWater head
versus discharges curve (at full and part load) Powerrequirement
or water discharge while operating as synchronouscondenser
iTurbine State Type and capacity
iiiGeneratorTypeRating (MVA)Speed (RPM)Terminal voltage (KV)Rated
Power FactorReactive PowerCapability (MVAr) in the range 0.95
of leading and 0.85 oflagging MW & MVAr capability curve of
generating unitShort Circuit RatioDirect axis
transient(saturated) reactance (% on rated MVA)Direct
axissub-transient (saturated) reactance (% on rated
MVA)Auxiliary Power Requirement (MW)
ivGenerator-Transformera.Typeb. Rated Capacity(MVA)c. Voltage RatioHV/LVd. Tap
change Range(+% to -%)e. Percentage Impedance (Positive
Sequence atFull Load).
A.2 Standard Planning Data (Transmission)For STU and Transmission Licensees
STU shall make arrangements for getting therequired data from different Departments of
STU/othertransmission licensees (if any) to update its Standard PlanningData in the format given
below:
i. Name of line (Indicating Power Stations and substations to beconnected).
ii. Voltage of line (KV).
iii. No. of circuits.
iv. Route length (km).
v. Conductor sizes.
vi. Line parameters (PU values).
(a) Resistance/km
(b) Inductance/km
(c) Susceptance/ km
vii. Approximate power flow expected- MW & MVAr.
viii. Terrain of the route- Give information regarding nature ofterrain i.e. forest land, fallow land,
agricultural and riverbasin, hill slope etc.
ix. Route map (to scale) - Furnish topographical map showing theproposed route showing existing
power lines and telecommunicationlines.
x. Purpose of Connection- Reference to Scheme, wheeling to otherStates etc.
xi. Approximate period of Construction.
A.3. Standard Planning Data (Distribution)For distribution licensees
(1) General
iArea Map (to scale) Furnish map of Bihar dulymarked with the area of
supply relevant for the DistributionLicence. 
ii  Bihar Electricity Grid Code, 2010

Consumer Data Furnish categories of consumers,their numbers and
connected loads.
iii Reference to Electrical Divisions presently incharge of the Distribution.  
(2) Connection
iPoints of Connection Furnish single line diagramshowing points of
Connection 
ii Voltage of supply at points of Connection  
iii Names of Grid Sub-Station feeding the points ofConnection  
(3) Lines and
Substations
i Line Data Furnish lengths of line and voltageswithin the Area. '  
iiSub-station Data Furnish details of 132/11 KVsub-stations, 33/11 KV
sub-station, capacitor installations 
(4) Loads
i Loads drawn at points of Connection.  
iiDetails of loads fed at EHV, if any. Give nameof consumer, voltage of
supply, contract demand/load and name ofGrid Substation from which
line is drawn, length of EHV line fromGrid Sub-station to consumer's
premises. 
iii Reactive Power compensation installed  
(5) Demand Data (for
All Loads 1 Mw
andAbove)
iType of load State whether furnace loads,rolling mills, traction loads, other
industrial loads, pumpingloads etc. 
ii Rated voltage and phase  
iiiElectrical loading of equipment State number andsize of motors, types of
drive and control arrangements. 
iv Sensitivity of load to voltage and frequency ofsupply.  
v Maximum Harmonic content of load.  
vi Average and maximum phase unbalance of load.  
vii Nearest sub-station from which load is to befed.  
viiiLocation map to scale Showing location of loadwith reference to lines and
sub-stations in the vicinity. 
(6) Load Forecast
Data
iPeak load and energy forecast for each categoryof loads for each of the
succeeding 5 years.
ii Details of methodology and assumptions on whichforecasts are based.Bihar Electricity Grid Code, 2010

iiiDetails of loads 1 MWand above.a. Name ofprospective consumer.b.
Location andnature of load.c. Sub-Station fromwhich to be fed.d. Voltage
of supply.e. Phasing of load. 
Appendix BDetailed Planning DateB.1 Detailed Planning Data (Generation)B.1.1Thermal Power
Stations (For SGS)(1)Generali. Name of Power Station.ii. Number and capacity of Generating Units
(MVA).iii. Ratings of all major equipments (Boilers and major accessories, Turbines, Alternators,
Generator Unit Transformers etc).iv. Single line Diagram of Power Station and switch-yard.v.
Relaying and metering diagram.vi. Neutral Grounding of Generating Units.vii. Excitation control-
(What type is used? e.g. Thyristor, Fast Brushless Excitors)viii. Earthing arrangements with earth
resistance values.(2)Protection and Meteringi. Full description including settings for all relays and
protection systems installed on the Generating Unit, Generator unit Transformer, Auxiliary
Transformer and electrical motor of major equipments listed, but not limited to, under Sec. 3
(General).ii. Full description including settings for all relays installed on all outgoing feeders from
Power Station switchyard, Tie circuit breakers, and incoming circuit breakers.iii. Full description of
inter-tripping of circuit breakers at the point or points of Connection with the Transmission
System.iv. Most probable fault clearance time for electrical faults on the User's System.v. Full
description of operational and commercial metering schemes.(3)Switch-Yardi. In relation to
interconnecting transformers:
1. Rated MVA.
2. Voltage Ratio.
3. Vector Group.
4. Positive sequence reactance for maximum, minimum, normal Tap. (% on
MVA).
5. Positive sequence resistance for maximum, minimum, normal Tap. (% on
MVA).
6. Zero sequence reactance (% on MVA).
7. Tap changer Range (+% to -%) and steps.
8. Type of Tap changer, (off/on load).
ii. In relation to switchgear including circuit breakers, isolators on all circuits connected to the
points of Connection:Bihar Electricity Grid Code, 2010

1. Rated voltage (kV).
2. Type of circuit breaker (MOCB/ABCB/SF6).
3. Rated short circuit breaking current (kA) 3 phase.
4. Rated short circuit breaking current (kA) 1 phase.
5. Rated short circuit making current (kA) 3 phase.
6. Rated short circuit making current (kA) 1 -phase.
7. Provisions of auto reclosing with details.
iii. In relation to the Lightning Arresters -Technical dataiv. In relation to the Communication -
Details of communication equipment installed at points of connections.v. In relation to the Basic
Insulation Level (kV) -
1. Busbar.
2. Switchgear.
3. Transformer bushings.
4. Transformer windings.
(4)Parameters of Generating Unitsi. Rated terminal voltage (kV).ii. Rated MVA.iii. Rated MW.iv.
Speed (rpm) or number of poles.v. Inertia constant H (MW Sec./MVA).vi. Short circuit ratio.vii.
Direct axis synchronous reactance (% on MVA) Xd.viii. Direct axis (saturated) transient reactance
(% on MVA) Xd'.ix. Direct axis (saturated) sub-transient reactance (% on MVA) Xd".x. Quadrature
axis synchronous reactance (% on MVA) Xq .xi. Quadrature axis (saturated) transient reactance (%
on MVA) Xq'.xii. Quadrature axis (saturated) sub-transient reactance (% on MVA) Xq".xiii. Direct
axis transient open circuit time constant (Sec) T'do.xiv. Direct axis sub-transient open circuit time
constant (See) T"do.xv. Quadrature axis transient open circuit time constant (Sec) T'qo.xvi.
Quadrature axis sub-transient open circuit time constant (Sec) T"qo.xvii. Stator Resistance
(Ohm)Ra.xviii. Neutral grounding details.xix. Stator leakage reactance (Ohm) X1.xx. Stator time
constant (Sec).xxi. Rated Field current (A).xxii. Open Circuit saturation characteristic for various
terminal Voltages giving the compounding current to achieve the same.xxiii. MW and MVAr
Capability curve(5)Parameters of Excitation Control Systemi. Type of Excitation.ii. Maximum Field
Voltage.iii. Minimum Field Voltage.iv. Rated Field Voltage.v. Details of excitation loop in block
diagrams showing transfer functions i of individual elements using I.E.E.E. symbols.vi. Dynamic
characteristics of over - excitation limiter.vii. Dynamic characteristics of under-excitationBihar Electricity Grid Code, 2010

limiter.(6)Parameters of Governori. Governor average gain (MW/Hz).ii. Speeder motor setting
range.iii. Time constant of steam or fuel Governor valve.iv. Governor valve opening limits.v.
Governor valve rate limits.vi. Time constant of Turbine.vii. Governor block diagram showing
transfer functions of individual elements using I.E.E.E. symbols.(7)Operational
ParametersMinimum notice required to synchronize a Generating Unit from desynchronization.i.
Minimum time between synchronizing different Generating Units in a Power Station.ii. The
minimum block load requirements on synchronizing.iii. Time required for synchronizing a
Generating Unit for the following conditions:
1. Hot
2. Warm
3. Cold
iv. Maximum Generating Unit loading rates for the following conditions:
1. Hot
2. Warm
3. Cold
v. (v) Minimum load without oil support (MW).(8)General Statusi. Detailed Project report.ii. Status
Report
1. Land
2. Coal
3. Water
4. Environmental clearance
5. Rehabilitation of displaced persons
iii. Techno-economic approval by Central Electricity Authority (CEA).iv. Approval of State
Government/Government of India.v. Financial Tie-up.(9)Connectioni. Reports of Studies for
parallel operation with the State Transmission System.ii. Short Circuit studiesiii. Stability Studies.iv.
Load Flow Studies.v. Proposed Connection with the State Transmission System.a. Voltageb. No. of
circuitsc. Point of Connection.B.1.2 Hydro-Electric Stations (For SGS)(1)Generali. Name of Power
Station.ii. No and capacity of units. (MVA)iii. Ratings of all major equipment.a. Turbines (HP)b.Bihar Electricity Grid Code, 2010

Generators (MVA)c. Generator Transformers (MVA)d. Auxiliary Transformers (MVA)iv. Single line
diagram of Power Station and switch-yard.v. Relaying and metering diagram.vi. Neutral grounding
of Generator.vii. Excitation control.viii. Earthing arrangements with earth resistance values.ix.
Reservoir Data.a. Salient featuresb. Type of Reservoir
1. Multipurpose
2. For Power
c. Operating Table with
1. Area capacity curves and
2. Unit capability at different net heads
(2)Protectioni. Full description including settings for all relays and protection systems installed on
the Generating Unit, Generator transformer, auxiliary transformer and electrical motor of major
equipment included, but not limited to those listed, under Sec. 3 (General).ii. Full description
including settings for all relays installed on all outgoing feeders from Power Station switch-yard,
tiebreakers, and incoming breakers.iii. Full description of inter-tripping of breakers at the point or
points of Connection with the Transmission System.iv. Most Probable fault clearance time for
electrical faults on the User's System.(3)Switch-Yardi. Interconnecting transformers:
1. Rated MVA
2. Voltage Ratio
3. Vector Group
4. Positive sequence reactance for maximum, minimum and normal Tap.(%
on MVA).
5. Positive sequence resistance for maximum, minimum and normal Tap.(%
on MVA).
6. Zero sequence reactance (% on MVA)
7. Tap changer range (+% to -%) and steps.Bihar Electricity Grid Code, 2010

8. Type of Tap changer (off/on load).
9. Neutral grounding details.
ii. Switchgear (including circuit breakers, Isolators on all circuits connected to the points of
Connection).
1. Rated voltage (KV).
2. Type of Breaker (MOCB/ABCB/SF6).
3. Rated short circuit breaking current (KA) 3 phase.
4. Rated short circuit breaking current (KA) 1 phase.
5. Rated short circuit making current (KA) 3 phase.
6. Rated short circuit making current (KA) 1 phase.
7. Provisions of auto re-closing with details.
iii. Lightning ArrestersTechnical dataiv. CommunicationsDetails of Communications equipment
installed at points of connections.v. Basic Insulation Level (KV)
1. Bus bar.
2. Switchgear.
3. Transformer Bushings
4. Transformer windings.
(4)Generating Unitsi. Parameters of Generator
1. Rated terminal voltage (KV).
2. Rated MVA.Bihar Electricity Grid Code, 2010

3. Rated MW
4. Speed (rpm) or number of poles.
5. Inertia constant H (MW sec./MVA).
6. Short circuit ratio.
7. Direct axis synchronous reactance Xd (% on MVA).
8. Direct axis (saturated) transient reactance (% on MVA) X'd.
9. Direct axis (saturated) sub-transient reactance (% on MVA) X"d.
10. Quadrature axis synchronous reactance (% on MVA) Xq.
11. Quadrature axis (saturated) transient reactance (% on MVA) X'q.
12. Quadrature axis (saturated) sub-transient reactance (% on MVA) X"q.
13. Direct axis transient open circuit time constant (sec) T'do.
14. Direct axis sub-transient open circuit time constant (sec) T"do.
15. Quadrature axis transient open circuit time content (sec) T'qo.
16. Quadrature axis transient open circuit time constant (sec) T"qo.
17. Stator Resistance (Ohm) Ra.
18. Stator leakage reactance (Ohm) X1.
19. Stator time constant (Sec).
20. Rated Field current (A).
21. Neutral grounding details.Bihar Electricity Grid Code, 2010

22. Open Circuit saturation characteristics of the Generator for various
terminal voltages giving the compounding current to achieve this.
23. Type of Turbine.
24. Operating Head (Metres)
25. Discharge with full gate opening (cumecs)
26. Speed Rise on total Load throw off(%).
27. MW and MVAr Capability curve
ii. Parameters of excitation control system:iii. Parameters of governor:iv. Operational parameter:
1. Minimum notice required to Synchronise a Generating Unit from
desynchronisation.
2. Minimum time between Synchronising different Generating Units in a
Power Station.
3. Minimum block load requirements on Synchronising.
(5)General Statusi. Detailed Project Report.ii. Status Report.
1. Topographical survey
2. Geological survey
3. Land
4. Environmental Clearance
5. Rehabilitation of displaced persons.
iii. Techno-economic approval by Central Electricity Authority.iv. Approval of State
Government/Government of India.v. Financial Tie-up.(6)Connectioni. Reports of Studies for
parallel operation with the State Transmission System.Bihar Electricity Grid Code, 2010

1. Short Circuit studies
2. Stability Studies.
3. Load Flow Studies.
ii. Proposed Connection with the State Transmission System.
1. Voltage
2. No. of circuits
3. Point of Connection.
(7)Reservoir Datai. Dead Capacityii. Live CapacityB.2 Detailed System Data-TransmissionFor
STU/Transmission Licensees(1)Generali. Single line diagram of the Transmission System down to
66KV.33KV bus at Grid Sub-station detailing:
1. Name of Sub-station.
2. Power Station connected.
3. Number and length of circuits.
4. Interconnecting transformers.
5. Sub-station bus layouts.
6. Power transformers.
7. Reactive compensation equipment.
ii. Sub-station layout diagrams showing:
1. Bus bar layouts.
2. Electrical circuitry, lines, cables, transformers, switchgear etc.Bihar Electricity Grid Code, 2010

3. Phasing arrangements.
4. Earthing arrangements.
5. Switching facilities and interlocking arrangements.
6. Operating voltages.
7. Numbering and nomenclature:
8. Transformers.
9. Circuits.
10. Circuit breakers.
11. Isolating switches.
(2)Line Parameters (for all circuits)i. Designation of Line.
1. Length of line (km).
2. Number of circuits.Per Circuit values.
3. Operating voltage (KV).
4. Positive Phase sequence reactance (pu on 100 MVA) X1
5. Positive Phase sequence resistance (pu on 100 MVA) R1
6. Positive Phase sequence susceptance (pu on 100 MVA) B1
7. Zero Phase sequence reactance (pu on 100 MVA) X0
8. Zero Phase sequence resistance (pu on 100 MVA) R0
9. Zero Phase sequence susceptance (pu on 100 MVA) B0
(3)Transformer Parameters (For all transformers)i. Rated MVAii. Voltage Ratioiii. Vector Groupiv.
Positive sequence reactance, maximum, minimum and normal (pu on 100 MVA) X1v. Positive
sequence resistance, maximum, minimum and normal (pu on 100 MVA) R1vi. Zero sequenceBihar Electricity Grid Code, 2010

reactance (pu on 100 MVA).vii. Tap change range (+% to -%) and steps.viii. Details of Tap changer.
(Off/On load).(4)Equipment Details (For all substations)i. Circuit Breakersii. Isolating switchesiii.
Current Transformersiv. Potential Transformers /CVTs(5)Relaying and Meteringi. Protection relays
installed for all transformers and feeders along with their settings and level of co-ordination with
other Users.ii. Metering Details.(6)System Studiesi. Load Flow studies (Peak and lean load for
maximum hydro and maximum thermal generation).ii. Transient stability studies for three-phase
fault in critical lines.iii. Dynamic Stability Studiesiv. Short circuit studies (three-phase and single
phase to earth)v. Transmission and Distribution Losses in the Transmission System.(7)Demand
Data (For all substations)Demand Profile (Peak and lean load) for next 5 years.(8)Reactive
Compensation Equipmenti. Type of equipment (fixed or variable).ii. Capacities and/or Inductive
rating or its operating range in MVAr.iii. Details of control.iv. Point of Connection to the System.B.3
Detailed Planning Data (Distribution)For Distribution Licensees(1)Generali. Distribution map (To
scale). Showing all lines up to 11KV and substations belonging to the Supplier.ii. Single line diagram
of Distribution System (showing distribution lines from points of Connection with the Transmission
System, 132/11 kV sub stations 66/11 KV substations, 33/11 KV substations, and consumer bus in
case of consumers fed directly from the Transmission System).iii. Numbering and nomenclature of
lines and sub-stations (Identified with feeding Grid sub-stations of the Transmission and concerned
220/ 11 kV, 132/11 kV, 66/11 kV and 33/11 KV sub-station of Licensee).(2)Connectioni. Points of
Connection (Furnish details of existing arrangement of Connection).ii. Details of metering at points
of Connection.(3)Loadsi. Details of major loads of 1 MW and above to be contracted for next 5
years.ii. Demand profile of Distribution System (Current & Forecast)Appendix COperational
Planning DataC.1 Outage Planning DataC.1.1 Demand EstimatesFor Distribution Licensees
 Item Due date/Time
(a)Estimated aggregate month-wise annual sales ofEnergy in Million Units and
peak and lean demand in MW & MVArat each Connection point for the next
financial year.15th November of
current year
(b)Estimated aggregate day-wise monthly sales ofEnergy in million Units and
peak and lean demand in MW & MVArat each Connection point for the next
month.25th of current
month
(c)15 Minute block-wise demand estimates for theday ahead.9.00 Hours every
day.
 (2) Estimates of Load Shedding for DistributionLicensee
 Item Due date/Time
(a)Details of discrete load blocks that may beshed to comply with instructions
issued by SLDC when required,from each connection point.Soon after
connection is
made.
 (3) Year ahead outageprogramme (For the financial year)(i) Generation
outage programme for (SGS)
 Item Due date/Time
(a)Identification of Generating Unit.15th November
each yearBihar Electricity Grid Code, 2010

(b)MW, Which will not be available as a result ofOutage.
(c)Preferred start date and start-time or rangesof start dates and start times
and period of outage.
(d)If outages are required to meet statutoryrequirement, then the latest - date
by which outage must betaken.
 (ii) Year ahead outage programme (Affecting Transmission System)
 Item Due date /Time
(a)MW, which will not be available as a result ofOutage from Imports through
external connections.1st November each
year
(b)Start date and start time and period of Outage.
 (iii) Year ahead CPP's outage programme (Affecting TransmissionSystem)
 Item Due date/Time
(a)MW, which will not be available as a result ofOutage from Imports through
external connections.30th November
each year
(b)Start date and start time and period of Outage.  
 (iv) Year ahead Distribution Licensees outage programme(Affecting
Transmission System)
 Item Due date/Time
(a)Loads in MW not available from any connectionpoint. Identification of
connection point.15th November
each year
(b)Period of suspension of drawal with start dateand start time.  
 (v) STU's Overall outage programme
 Item Due date/Time
(a)Report on proposed outage programme to ERPC15th February
each year
(b)Release of finally agreed outage plan15th February
each year
C-2. Generation Scheduling DataFor SGS
 ItemDue
date/
Time
(a)Day ahead 15-minute block-wise MW/MVAravailability (00.00 - 24.00 Hours) of
SGS.9.00 hrs
(b) Day ahead 15-minute block-wise MW import/exportfrom CPP's. 9.00 hrs
(c) Status of Generating Unit Excitation AVR inservice (Yes/No). 9.00 hrs
(d) Status of Generating Unit Speed Control System.Governor in service (Yes/No). 9.00 hrs
(e) Spinning reserve capability (MW). 9.00 hrs
(f) Backing down capability with/without oilsupport (MW). 9.00 hrs
(g) Hydro reservoir levels and restrictions. 9.00 hrsBihar Electricity Grid Code, 2010

(h) Generating Units 15-minute block-wise summationoutputs (MW) 9.00 hrs
(i)Day ahead 15-minute block-wise MW entitlementsfrom Central Sector Generation
Power Stations from ERLDC.10.00
hrs
C-3 Capability DataFor SGS
 Item  
(a)Generators and IPPs shall submit to STUup-to-date capability curves
for all Generating Unit.On receipt of request
from STU/SLDC.
(b)CPPs shall submit to STU net return capabilitythat shall be available
for export /import from TransmissionSystemOn receipt of request
from STU/SLDC.
C-4 Response to Frequency ChangeFor SGS
 Item  
(a)Primary Response in MW at different levels ofloads ranging from
minimum generation to registered capacity forfrequency changes
resulting in fully opening of governor valve.On receipt of request
from STU/SLDC.
(b)Secondary response in MW to frequency changesOn receipt of request
from STU /SLDC.
C-5 Monitoring of GenerationFor SGS
Item  
(a) SGS shall provide 15-minute block-wisegeneration
summation to SLDC.Real time basis
(b) CPPs shall provide 15-minute block-wiseexport / import
MW to SLDC.Real time basis
(c) Logged readings of Generators to SLDC. As required
(d) Detailed report of generating unit trippingon monthly
basis.In the first week of the succeeding
month
C-6 Essential and Non Essential Load DataFor SGS
 Item Due date/Time
(a)Schedule of essential and non-essential loadson each discrete load
block for purposes of load shedding.As soon as possible after
connection
Appendix D:Site Responsibility ScheduleName of Power Station / Sub - Station:Site Owner:Site
Manager:Tel. Number:Fax Number:
Item of Plant /
ApparatusPlant
OwnerSafety
responsibilityControl
responsibilityOperation
responsibilityMaintenance
responsibilityRemarks
________KV
Switch-yard      
All equipment
including bus
bars      
feeders       
       Bihar Electricity Grid Code, 2010

       
       
Generating units       
       
       
       
       
Appendix E:Incident ReportingFirst
reportDate:___________________Time:___________________
S.No. Item Details
1 Date and time of incident  
2 Location of incident  
3 Type of incident  
4 System parameters before the incident (voltage, frequency, flows,generation etc.)  
5 Relay indications received and performance of protection  
6 Damage to equipment  
7 Supplies interrupted and duration, if applicable  
8 Amount of generation lost, if applicable  
9 Possibility of alternate supply arrangement  
10 Estimate of time to return to service  
11 Cause of incident  
12 Any other relevant information and remedial action taken  
13 Recommendations for future improvement / repeat incident  
14 Name of the organization  Bihar Electricity Grid Code, 2010

