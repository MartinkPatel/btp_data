Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021
Equivalent citations: AIR 2021 SUPREME COURT 2881, AIRONLINE 2021 SC
280
Author: A.M. Khanwilkar
Bench: B.R. Gavai, A.M. Khanwilkar
                                               1
                                                                REPORTABLE
                                IN THE SUPREME COURT OF INDIA
                                    INHERENT JURISDICTION
                         CONTEMPT PETITION (CIVIL) NOS. 625−626 OF 2019
                                               IN
                             CIVIL APPEAL NOS. 11017−11018 OF 2018
          Abhishek Kumar Singh                                  … Petitioner
                                             Versus
          G. Pattanaik & Ors.                                   …Respondents
                                             WITH
                         CONTEMPT PETITION (CIVIL) NOS. 642−643 OF 2019
                                               IN
                             CIVIL APPEAL NOS. 11017−11018 OF 2018
                         CONTEMPT PETITION (CIVIL) NOS. 671−672 OF 2019
                                               IN
                             CIVIL APPEAL NOS. 11017−11018 OF 2018
                         CONTEMPT PETITION (CIVIL) NOS. 395−396 OF 2020
                                               IN
                             CIVIL APPEAL NOS. 11017−11018 OF 2018
                         CONTEMPT PETITION (CIVIL) NOS. 408−409 OF 2020
Signature Not Verified
Digitally signed by
                                               IN
DEEPAK SINGHAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

Date: 2021.06.03
13:28:00 IST
                             CIVIL APPEAL NOS. 11017−11018 OF 2018
Reason:
                                             2
        CONTEMPT PETITION (CIVIL) NOS. 598−599/2020
                            IN
            CIVIL APPEAL NOS. 11017−11018/2018
      CONTEMPT PETITION (CIVIL) NOS. 669−670 OF 2020
                            IN
          CIVIL APPEAL NOS. 11017−11018 OF 2018
      CONTEMPT PETITION (CIVIL) NOS. 671−672 OF 2020
                            IN
          CIVIL APPEAL NOS. 11017−11018 OF 2018
               WRIT PETITION (CIVIL) NO. 491 OF 2020
                                          AND
            TRANSFER PETITION (CIVIL) NO. 1209/2020
                                 JUDGMENT
A.M. Khanwilkar, J.
1. These cases essentially assail the orders dated 4.12.2018 and 2.3.2020 issued by the Chief
Engineer (A−2−1), Uttar Pradesh Jal Nigam, Lucknow1, pursuant to the judgment of this Court
dated 15.11.2018 in Civil Appeal Nos. 11017−11018/2018 2. This Court by the aforesaid judgment,
had directed the Uttar Pradesh For short, “the Chief Engineer” or “respondents” Uttar Pradesh Jal
Nigam & Ors. v. Ajit Singh Patel & Ors., (2019) 12 SCC 285 Jal Nigam (the respondent corporation)
to comply with the judgment of the High Court of Judicature at Allahabad 3 dated 28.11.2017 in a
batch of writ petitions (leading case being Writ−A No. 37143/2017) and pass a fresh, reasoned order.
2. In pursuance of the aforementioned decision of this Court, the Chief Engineer issued order dated
4.12.2018, thereby reengaging the petitioners and other appointees to their previous place of
posting. However, with a caveat that the said appointment was subject to the liberty granted by this
Court and that no arrears would be paid by the respondent corporation. The order of the Chief
Engineer dated 4.12.2018 is reproduced thus:
“The order dated 11.8.2017 passed by the Chief Engineer (A−2−1) U.P. Jal Nigam
Lucknow has been set aside by Hon’ble High Court Allahabad by its order dated
28.11.2017 in W.P. No. A−37143/2017 and Review Application No. 2/2018 is also
rejected by Hon’ble High Court in its order dated 25.07.2018. The Hon’ble SupremeAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

Court has upheld [sic] the above order passed by Hon’ble High Court in Civil Appeal
No. 11017−11018/2018 titled as U.P. Jal Nigam & Ors. v. Ajit Singh & Ors.
In the above context you are expected to perform your duty at your previous posting place within 15
days from issuing of this order.
That it is being clarified that the said appointment will be subject to the liberty granted to Nigam, by
the Hon’ble Supreme Court of India vide judgment dated 15.11.2018 in Civil Appeal No. 11017−
11018/2018. The concerning paragraphs are extracted below:
For short, “the High Court” “15. In view of the above, the challenge to the impugned
judgment dated 28th November, 2017 and 25th July, 2017 must fail but with a
clarification that the competent authority is free to pass a fresh, reasoned order in
accordance with law.
16. We may not be understood to have expressed any opinion either way on the merits of the course
of action open to the appellants against the respondents including against the other appointees
under the same selection process. All questions in that behalf are left open.”4 That no Arrears prior
to the fresh date of appointment will be granted by Nigam.” (emphasis supplied)
3. This order, according to the contempt petitioners, is in the teeth of the decision of this Court
dated 15.11.2018 and, therefore, the respondents be proceeded for having committed wilful
disobedience of the order of this Court.
4. Thereafter, in terms of the liberty granted by this Court in the aforementioned judgment, the
respondent corporation passed a fresh order dated 2.3.2020, annulling the appointment of the
petitioners and similarly placed Assistant Engineers. In arriving at the fresh decision, reliance was
placed upon the two internal inquiry reports dated 29.5.2017 and 7.7.2017; expert reports — of IIIT
Allahabad dated 11.9.2018 and IIT Kanpur dated 15.9.2018; CFSL report dated 11.12.2019; and
recommendation made by the Special Investigation Team (SIT) in its final report extracted in
paragraph 14 ibid dated 22.1.2020 received by the respondent corporation on 18.2.2020, to cancel
the recruitment process due to corruption involved. The two expert reports given by Assistant
Professor at IIT Kanpur and Associate Professor at IIIT Allahabad dated 15.9.2018 and 11.9.2018
respectively, pointed out that the audit trail/checksum and time stamps of the candidates were not
made available and therefore, segregation of tainted and untainted candidates was not possible, in
absence of primary data. The operative portion of the order dated 2.3.2020 is reproduced below:
“20. …..
After the investigation conducted by the department in the case, the reports of both
the experts, the relevant recommendation/conclusion of the SIT investigation and
after examination of the records, it has become clear that the selection process in
question is void ab initio for the above reasons.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

In view of the above, the office memo number 08/A−2− 1/2151−0201/17 dated
03.01.2017, memo no. 09/ A−2−1 / 2151−0201/17 dated 03.01.2017 and memo
number 10/A− 2−1/2151−0201/17 dated 03.01.2017 is cancelled with effect from the
date of issue i.e. date 03.01.2017 and the appointments in question are declared void
from the said date.
Due to the cancellation of the above office memorandum issued on dated 03.01.2017,
the orders which were circulated on 04.12.2018 to contribute again are effectively
annuled.
The Assistant Engineer appointed under this process will get the protection of salary
allowances etc. received so far and no recovery will be made from them. In the
discharge of departmental responsibilities, the administrative and financial functions
performed by them so far will remain valid.” (emphasis supplied)
5. This order has been assailed by the writ petitioner(s) directly in this Court by way
of Writ Petition (Civil) No. 491/2020. We are informed that the same order has been
assailed by similarly placed persons governed by the impugned order by way of writ
petition(s) before the High Court of Judicature at Allahabad and also at its Bench at
Lucknow. Some of them have filed transfer petition before this Court, to transfer
their Writ Petition No. 13083/2020 (S/S) filed at Lucknow Bench of the High Court
and to hear it along with contempt petitions pending in this Court involving
overlapping issues. Accordingly, the assail in these petitions is to the aforementioned
order dated 4.12.2018, as well as, order dated 2.3.2020 passed by the respondents.
6. In Contempt Petition (C) Nos. 625−626/2019, 642−643/2019 and 671−672/20195,
the grievance of the petitioners is that the respondents have appointed them afresh
instead of reinstatement with continuity of service along with arrears of wages and
thus, have wilfully violated the direction of this Court in judgment Collectively,
“contempt petitions against non−payment of arrears” 15.11.2018, to give full effect to
the High Court’s judgment dated 28.11.2017.
7. Whereas, in Contempt Petition (C) Nos. 395−396/2020, 408− 409/2020, 598−
599/2020, 669−670/2020 and 671−672/2020 6, the grievance is that the order of the
respondents dated 2.3.2020, have annulled the appointment of the petitioners,
without affording opportunity of hearing to the petitioners in violation of the
judgment of this Court dated 15.11.2018 in Civil Appeal No. 11017−11018/2018.
8. In W.P. (C) No. 491/2020, the petitioners have prayed for quashing of order dated
2.3.2020 passed by the respondent and to reinstate the petitioners with continuity of
service and full back wages. While, in T.P. (C) No. 1209/2020, the petitioners seek to
withdraw and transfer to this Court, Writ Petition (C) No. 13083/2020 (Service
Single), which is pending before the Lucknow Bench of the High Court, as the order
dated 2.3.2020 (impugned therein) is already subject matter in second set ofAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

contempt petitions including W.P.(C) No. 491/2020 before this Court.
Collectively, “contempt petitions against termination” CONTEMPT PETITIONS AGAINST
REENGAGEMENT WITHOUT CONTINUITY OF SERVICE AND ARREARS OF BACK WAGES
VIDE ORDER DATED 4.12.2018:
9. The factual background leading to filing of these contempt petitions is that the
respondents, vide order dated 11.8.2017, annulled the recruitment process pursuant
to which the petitioners were employed, thereby terminating services of the
petitioners. The said order was challenged before the High Court and came to be set
aside by way of common judgment dated 28.11.2017. The above judgment also
directed that the petitioners be permitted to work and be paid regular monthly salary.
The relevant extract of this decision is reproduced thus: − “…..
In view of the above, we are of the considered opinion that the impugned order dated 11.8.2017 has
been passed in violation of principles of natural justice without issuing notice and without affording
opportunity of hearing to the petitioners, no exercise was undertaken to distinguish the case of
tainted and non−tainted candidates to arrive at the conclusion while passing the impugned order as
such the impugned order dated 11.8.2017 is not sustainable and is liable to be set aside.
Accordingly, the impugned order dated 11.8.2017 passed by the Chief Engineer Jal Nigam
(Annexure−9 to the writ petition) is here by set aside.
The writ petitions succeed and are allowed with the further direction to permit the petitioners to
work on the post of Assistant Engineer (Civil); Assistant Engineer (Electrical/Mechanical) and
Assistant Engineer (Computer Science/Electronics and Communication/Electrical and Electronics)
and to pay them regular salary month by month with the liberty to the respondents to pass a fresh,
reasoned order after providing opportunity of hearing to the petitioners and other affected parties
on the basis of observations made above. No order as to costs.” (emphasis supplied)
10. Another writ petition filed by some of the petitioners before Lucknow bench of the High Court,
being Service Bench No. 19863/2017 was also disposed of on 12.12.2017, in terms of the judgment
dated 28.11.2017, in the following words:
“…..
Accordingly, this writ petition is also allowed in terms of the judgment and order
dated 28.11.2017 passed by this Court at Allahabad in the bunch of Writ Petitions,
leading Writ Petition being Writ−A No. 37143 of 2017, Ajit Singh Patel and others vs.
State of U.P. and others with a further direction to permit the petitioners to work on
the post of Assistant Engineer (Civil), Assistant Engineer (Electrical/ Mechanical)
and Assistant Engineer (Computer Science/ Electronics and Communication /
Electrical and Electronics) and pay them regular salary as and when the same accrues
to them with a liberty to the respondents to pass a fresh reasoned order afterAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

providing opportunity of hearing to the petitioners and other parties on the basis of
the observations made by this Court at Allahabad in the judgment and order dated
28.11.2017 (supra).
…..” (emphasis supplied)
11. Upon failure of the respondents to act upon the directions passed in judgment dated 28.11.2017,
the petitioner(s) filed Contempt Application (Civil) No. 6218/2017 before the High Court.
Meanwhile, the respondents preferred SLP (C) Nos. 5410− 5419/2018 before this Court assailing the
judgment dated 28.11.2017. The said special leave petitions were disposed of by an order dated
16.3.2018, holding that the respondents may approach High Court for a liberty to re−work the
answer sheets on the basis of corrections. The said order reads thus: − “ORDER Mr. Rakesh
Dwivedi, learned senior counsel appearing for the petitioners, points out that the petitioners having
found out that there were defective questions and incorrect answer keys, the High Court should have
permitted the petitioners to re−work the merit list. He submitted that the High Court has gone
wrong in insisting for an individual notice in the factual matrix of this case. In this regard he has
also placed reliance on a judgment of this Court in Vikas Pratap Singh and Others v. State of
Chhattisgarh and Others, reported in (2013) 14 SCC 494.
Mr. Mukul Rohatgi, learned senior counsel appearing for the respondent(s), however, points out
that whether the questions were defective or key answers were incorrect are disputed question and,
therefore, liberty should be granted to the respondents to participate in the inquiry. He further
submits that the decision of this Court referred to by the learned senior counsel for the petitioners
may not apply to the facts of this case.
Be that as it may, having gone through the impugned judgment, we do not find that the door is yet
closed. It is for the petitioners, if they are so advised, to approach the High Court itself for a liberty
to re−work the answer sheets on the basis of the corrections, in case the High Court is also of the
view that the corrections need to be made.
The special leave petitions are, accordingly, disposed of.
Pending application(s), if any, shall stand disposed of.” (emphasis supplied)
12. Upon disposal of the said special leave petitions, the respondents furnished an undertaking to
the High Court in the Contempt Application (Civil) No. 6218/2017 that the judgment dated
28.11.2017 will be complied with on or before 15.5.2018. In the meantime, the respondents preferred
a Review Application No. 2/2018 in Writ − A No. 37143/2017, wherein the High Court, vide order
dated 25.7.2018, refused to interfere with the judgment dated 28.11.2017 and reiterated that it was
open to the respondents to pass a fresh order. This order dated 25.7.2018 reads thus: − “The
Managing Director, U.P. Jal Nigam, Lucknow and the Chief Engineer, U.P. Jal Nigam, Lucknow
have both filed an application for the review of the judgement and order dated 28.11.2017 by which a
bunch of these writ petitions were finally decided.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

The submission of learned Advocate General of State of U.P. is that the applicants be granted liberty
to segregate tainted and untainted candidates in passing a fresh order for which liberty has been
given.
The order impugned in the writ petitions was of 11.08.2017 passed by the Chief Engineer, Jal Nigam
which cancels the entire selection.
In allowing the petition, we have held that the order impugned in the writ petition has been passed
in violation of principles of natural justice and that the selection as a whole was not liable to be
cancelled without undertaking any exercise to separate the tainted candidates from the untainted
one's. The court in the end while allowing the writ petitions had permitted the applicants to pass a
fresh reasoned order after providing opportunity of hearing to the petitioners and the other affected
parties keeping in view the observations made in the judgment.
The applicants till date have not passed any fresh order. In passing the fresh order they may
consider each and every aspect of the matter and they do not require any permission of the court for
the manner in which they would pass the fresh order.
In view of above, we do not consider that any liberty for the above purpose is needed from the court.
We do not find any apparent error in the judgment and order which is sought to be reviewed.
The Review Application stands disposed of.” (emphasis supplied)
13. Since the undertaking filed in Contempt Application (Civil) No. 6218/2017 was not complied
with even after the disposal of the review petition, the High Court by order dated 6.8.2018, directed
that upon failure to file compliance affidavit before next date of hearing, the presence of the
respondents would be required for framing of charges of contempt. Likewise, in another contempt
petition before the Lucknow bench of the High Court (against non−compliance of judgment dated
12.12.2017), a similar order was passed on 7.8.2018.
14. The respondents carried the matter in appeal before this Court vide Civil Appeal Nos. 11017−
11018/2018, impugning the judgment and orders dated 28.11.2017 passed in Writ−A No.
37143/2017 and also dated 25.7.2018 in Review Application No. 2/2018. It may be useful to advert
to an interim order passed by this Court in the stated appeal, dated 20.8.2018, which may have
some bearing on the grounds under consideration. The same reads thus: − “The only liberty granted
to the petitioners and as rightly understood by the learned Advocate General appearing for the State
was to segregate the tainted from the untainted as per Order dated 16.03.2018.
We direct the petitioners to file a report, in a sealed cover, within one month from today, as to what
steps have been taken pursuant to the Judgment dated 28.11.2017 passed by the High Court and the
order dated 16.03.2018 by this Court in the Special Leave Petition.
List on 20.09.2018.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

The petitioners may approach the High Court and seek for extension of time.” (emphasis supplied)
Be that as it may, the decisions of the High Court referred to above stood confirmed by this Court
vide order dated 15.11.2018, giving liberty to the respondent(s) to pass a fresh, reasoned order. The
relevant portion of the decision of this Court reads thus: − “14. The limited plea taken before this
Court as noted in the first paragraph of order dated 16 th March, 2018 was to allow the appellants to
re−work the question and answer sheets and revise the merit list and issue fresh, reasoned order
after providing opportunity of hearing to the affected candidates. That option has been kept open. It
is for the appellants to pursue the same. In other words, the appellants must, in the first place, act
upon the decision of the High Court dated 28 th November, 2017 whereby the order passed by the
Chief Engineer dated 11th August, 2017 has been quashed and set aside. The appellants may then
proceed in the matter in accordance with law by passing a fresh, reasoned order. Indeed, while
doing so, the appellants may take into consideration the previous inquiry reports as also all other
relevant material/documents which have become available to them. We make it clear that we have
not dilated on the efficacy of the opinion given by the experts of the “IIIT Allahabad and IIT
Kanpur”.
15. In view of the above, the challenge to the impugned judgment dated 28th November, 2017 and
25th July, 2017 must fail but with a clarification that the competent authority of Nigam is free to
pass a fresh, reasoned order in accordance with law.
16. We may not be understood to have expressed any opinion either way on the merits of the course
of action open to the appellants against the respondents including against the other appointees
under the same selection process. All questions in that behalf are left open.” (emphasis supplied)
15. After the judgment of this Court dated 15.11.2018, the High Court in the Contempt Application
(Civil) No. 6218/2017, vide order dated 26.11.2018, directed the respondents to comply with the
judgment dated 28.11.2017 in the first instance. An order of even date was made in Contempt No.
1428/2018 by the Lucknow bench of the High Court on similar lines.
16. In terms of the directions of this Court in judgment dated 15.11.2018 and that of High Court in
the two orders dated 26.11.2018, the respondents passed the impugned order dated 4.12.2018
(reproduced in paragraph No. 2 above), reengaging the petitioners, albeit, without continuity of
service and arrears. The respondents also filed affidavit of compliance before the High Court.
17. In Contempt Application No. 6218/2017, the petitioner filed objections to the said affidavit of
compliance on 10.12.2018 on the ground that withholding the payment of arrears is directly in teeth
of the judgment dated 28.11.2017, as confirmed by this Court vide judgment dated 15.11.2018 and
thus, it amounts to wilful and deliberate disobedience of the order of the Court.
18. Similarly, in Contempt No. 1428/2018, the objections were first noted in order dated 17.12.2018
and then, a detailed affidavit of objections was filed on 21.1.2019. The High Court, vide order dated
22.1.2019, observed that the reinstatement should be followed by payment of full back wages and
directed the respondents to pay the same within three months. The relevant portion of the said
order is reproduced thus:Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

“.....
The Supreme Court has observed in the case of Deepali Gundu Surwase7 that
reinstatement ordinarily should be followed by payment of full back wages.
It is not the case of the respondents that the termination order has not been set aside
by this Court. It is also not the case of the respondents that the petitioners have been
gainfully employee during the period that they remained out of service due to
termination order which has Deepali Gundu Surwase v. Kranti Junior Adhyapak
Mahavidyalaya (D. Ed.) & Ors. (2013) 10 SCC 324 ultimately been set aside.
Therefore, the respondents are directed to give arrears of salary as are due to the
petitioner after termination order is set aside by this Court.
The back wages of the petitioners in compliance of the orders passed by this Court in writ
jurisdiction shall be paid to the petitioner within a period of three months. List this matter after
three months on 29.4.2019 by which date if all arrears of salary are not paid, then the Managing
Director of U.P. Jal Nigam shall appear in person to assist this Court.”
19. Thereafter, by order dated 1.4.2019, the High Court recorded that the respondents are prima
facie guilty of wilful and deliberate disobedience and directed their presence before the Court on
next date of hearing, for framing charge. The respondents assailed the said order by way of SLP(C)
No. 10774/2019. This Court, vide order dated 7.5.2019, observed that after the decision in Civil
Appeal No. 11017−11018/2018, the contempt petitions cannot be continued before the High Court
and be deemed to have been withdrawn to this Court. Liberty was granted to the petitioners to
pursue other remedies as per law against the impugned orders.
20. The respondents had challenged the High Court’s order dated 22.1.2019 by way of SLP (C) Diary
No. 15756/2019, wherein this Court by order dated 10.5.2019, had followed the order passed in SLP
(C) No. 10774/2019 to withdraw the contempt petition.
21. In these circumstances, the present contempt petitions in reference to the order dated 4.12.2018
regarding reengagement without continuity of service and arrears of back wages, arise for our
consideration.
22. The thrust of the argument of the petitioners in these petitions is that the effect of judgment of
High Court in setting aside the termination order dated 11.8.2017, as upheld by this Court is that the
termination order stood effaced in its entirety. As such, it was necessary to issue a formal order of
reinstatement along with continuity in service and arrears of pay for the relevant period. It is not
open to the respondents to give any other interpretation. It was then urged that the petitioners were
not gainfully employed elsewhere between the dates of termination and reinstatement and
therefore, were entitled to back wages. In support, reliance has been placed upon the decision of this
Court in Deepali Gundu Surwase8. Further, it was submitted that denial of back wages would
amount to giving premium to the respondents for their wrongdoings. It was also pointed out that in
Deepali Gundu Surwase9, the judgment of this Court in J.K. Synthetics Ltd. v. K.P. Agrawal &Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

Anr.10, which has been relied upon by the respondents, was held to be not a good law.
23. On the other hand, the respondents would submit that neither the High Court in its judgment
dated 28.11.2017 nor this Court in its judgment dated 15.11.2018 had directed payment of arrears.
Reliance was then placed on the decisions of this Court in J.K. Synthetics Ltd.11 and U.P. State
Brassware Corpn. Ltd. & Anr. v. Uday Narain Pandey 12, to submit that arrears cannot be claimed as
a matter of right upon reinstatement, unless it has been expressly granted by the Court. In that, the
petitioners are not entitled to arrears. Further, the petitioners cannot now claim arrears as it would
amount to claiming a fresh relief and is beyond the scope of contempt proceedings, whilst placing
reliance upon the decision of this Court in Director of Education, Uttaranchal & Ors. v. Ved Prakash
Joshi & Ors.13 It is urged that the petitioners had accepted the terms of (2007) 2 SCC 433 (2006) 1
SCC 479 (2005) 6 SCC 98 re−engagement without any demur and therefore it was not open to them
to claim back wages.
CONTEMPT PETITIONS AGAINST FRESH TERMINATION ORDER DATED 2.3.2020:
24. The fresh termination order dated 2.3.2020 came to be passed pursuant to the liberty given by
this Court, leading to filing of the present petitions. The background facts are that there were several
lapses by few officials of the respondent corporation and M/s. Aptech Private Limited (the testing
agency) in relation to the selection process for filling up 122 posts of Assistant Engineers (113 − Civil,
5 − Electrical/Mechanical and 4 − Electrical and Electronics/Electronics and
Communication/Computer Science). That as per the agreement between the respondent corporation
and the testing agency, the testing agency was required to display the answer key for three days and
to take remedial action on the objections received. Further, the testing agency was also required to
retain the data pertaining to the examination for at least one year. The testing agency breached the
aforesaid conditions and interviews were conducted, without confirming if the answer key was
uploaded or not. The interviews of 34,158 candidates were conducted in tearing haste on 30.12.2016
and 31.12.2016 and the final result was released on 3.1.2017, and the appointments were made on
the same day i.e., 3.1.2017. Since non uploading of the answer key had deprived the candidates of
the opportunity to file objections, the unsuccessful candidates approached the High Court alleging
that the recruitment process was not transparent and was replete with several illegalities and
irregularities. The High Court, in Writ Petition Nos. A/15948/2017 and 9794/S.B./2017 (preferred
by unsuccessful or non−selected candidates), directed the respondent corporation to inquire into
the said grievance and ensure that appropriate action is taken. Accordingly, two separate inquiries
were conducted by the officers wherein several irregularities were found. On the basis of these
inquiries, the entire selection process was declared void−ab− initio and an order to that effect was
passed on 11.8.2017. The said order later on came to be set aside vide judgment dated 28.11.2017 of
the High Court.
25. Meanwhile, a complaint was received by the U.P. Government (Home Department) in regard to
various examinations pertaining to recruitment to several posts (including the present recruitment
process). The government forwarded the same to SIT for investigation. The SIT in its initial enquiry
found that the testing agency had removed the entire data pertaining to the present recruitment
process from the main server, in violation of the condition to store it for a year. The said fact wasAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

also admitted by the testing agency. Therefore, in absence of original data, assistance of the
Directors of IIT Kanpur and IIIT Allahabad was sought to segregate the tainted and untainted
candidates. The finding in the two expert reports, inter alia, was that the response sheet was
uploaded after a long gap after the conclusion of the test which casts a doubt of manipulation in the
response sheets. Further, the data provided by the testing agency did not contain the Timestamps
and Mouse Clicks of the candidates and there is no mention of the Audit Trail/Checksum. Therefore,
the authenticity of the answers of the candidates could not be verified and certified. Moreover, since
primary data was not available and the data stored in the CD could not be authenticated, it was not
possible to segregate the tainted and untainted candidates.
26. In the meantime, this Court in Civil Appeal No. 11017− 11018/2018 (against judgment dated
27.11.2017 and judgment in review dated 25.7.2018), had observed that the expert reports were not
available while passing order dated 11.8.2017 and gave liberty to pass a fresh reasoned order by
considering the previous inquiry reports and other data that becomes available to the respondents.
27. In separate proceedings pending before the High Court in W.P. No. 12222/2017 (against
recruitment for other posts), the Court passed an order dated 21.5.2019 that it was for the
respondent corporation to decide to annul the entire selection process if the segregation cannot be
undertaken. The said order was upheld by the High Court in Special Appeal (Defective) No.
625/2019 and 626/2019 (intra court appeals) by an order dated 31.7.2019. Furthermore, the SIT
sent its final report dated 22.1.2020 to the Government, which was made available to the
respondent corporation on 18.2.2020. The said report mentions that the testing agency had
removed primary data from the cloud server in furtherance of a criminal conspiracy and
recommended to consider cancelling all the appointments made in the exams conducted by the
testing agency (including for the post of Assistant Engineer). In view of the aforesaid, and in exercise
of the liberty granted by this Court, the order dated 2.3.2020 was passed on the aforesaid findings.
Aggrieved therefrom, the present contempt petitions have been filed.
28. The case of the petitioners is that the High Court and also this Court had held that the
termination order dated 11.8.2017, terminating the services of the petitioners (and other appointees)
en masse, was invalid as it was passed without adhering to the principles of natural justice.
However, the respondent corporation had yet again passed the order dated 2.3.2020 without
following the principles of natural justice. By doing so, the respondent corporation in effect has
restored the termination order dated 11.8.2017, under the guise of the liberty granted by this Court.
The same cannot be countenanced.
29. It was urged that the decision of this Court dated 15.11.2018 contained a categorical direction for
the respondent corporation to pass a fresh reasoned order after providing an opportunity of hearing
to the affected parties. However, the impugned order had been passed in violation thereof. In
support, reliance is placed on the decision of this Court in Haryana Financial Corporation & Anr. v.
Jagdamba Oil Mills & Anr. 14 to contend that the judgments are not to be read like statutes. It was
then urged that liberty to pass a fresh order ‘in accordance with law’ cannot be stretched to such an
extent that would circumvent compliance with principles of natural justice.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

30. It was contended that the reliance placed by the respondents upon decisions of High Court in
W.P. No. 12222/2017 and Special Appeal (Defective) No. 625/2019 and 626/2019 is misplaced and
untenable as the same has been done only to overcome the orders of this Court. It was submitted
that the executive cannot sit in appeal or revision over the judicial orders. Reliance is placed on the
decision of this Court in Union of India & Anr. v. K.M. Shankarappa 15 and Union of India v. Ashok
Kumar Aggarwal16, to contend that an attempt to renew an order which had been quashed by the
Court, would amount to legal malice.
31. Per contra, the respondents would submit that the judgment dated 15.11.2018 had directed the
respondents to act (2002) 3 SCC 496 (2001) 1 SCC 582 (2013) 16 SCC 147 upon the High Court’s
judgment dated 28.11.2017, wherein the petitioners were permitted to work on the post of Assistant
Engineers. The respondents duly complied with the aforementioned judgment of this Court, by
appointing the petitioners vide order dated 4.12.2018. It was then urged that this Court had granted
liberty to the respondents to proceed in the matter in accordance with law. Therefore, contempt
action cannot be maintained in respect of order dated 2.3.2020 in absence of any specific direction
to afford opportunity to the petitioners despite the conclusion and opinion recorded by the
competent authority that segregation of tainted and the untainted was not possible. The
respondents contend that in such a case the entire selection process stood vitiated and no
notice/opportunity need be given to the petitioners. Reliance is placed upon decisions of this Court
in Union of India & Ors. v. O. Chakradhar17, Veerendra Kumar Gautam & Ors. v. Karuna Nidhan
Upadhyay & Ors.18, M.P. State Coop. Bank Ltd., Bhopal v. Nanuram Yadav & Ors.19, Nidhi Kaim v.
State of Madhya Pradesh & Ors.20, Kunhayammed & Ors. v. (2002) 3 SCC 146 (2016) 14 SCC 18
(2007) 8 SCC 264 (2016) 7 SCC 615 State of Kerala & Anr. and Khoday Distilleries Limited v. Sri
Mahadeshwara Sahakara Sakkare Karkhane Limited, Kollegal22 to contend that the respondents
have not violated the judgment dated 15.11.2018. In law, the decision of High Court dated 28.11.2017
had merged in the judgment of this Court dated 15.11.2018. It was then submitted that no additional
direction can be given in a contempt proceeding as the same would amount to exercise of review
jurisdiction. In support of this plea, reliance is placed upon the decisions in Bihar Finance Service
House Construction Cooperative Society Ltd. v. Gautam Goswami & Ors.23 and Sudhir Vasudeva,
Chairman and Managing Director, Oil and Natural Gas Corporation Limited & Ors. v. M. George
Ravishekaran & Ors.24. It was then urged that civil contempt would require wilful disobedience.
Passing of order dated 2.3.2020, assuming it to be a case of disobedience, the same cannot be
termed as wilful. Thus, no contempt action can be maintained. Reliance was placed on decision of
this Court in Ram Kishan v. Tarun Bajaj & Ors.25, (2000) 6 SCC 359 (2019) 4 SCC 376 (2008) 5
SCC 339 (2014) 3 SCC 373 (2014) 16 SCC 204 Dinesh Kumar Gupta v. United India Insurance
Company Limited & Ors.26 and Kapildeo Prasad Sah & Ors. v. State of Bihar & Ors.27. It was then
submitted that the implementation of orders can be insisted depending on its practicability. But, in
the fact situation of this case, giving notice to the petitioners was not practical. Reliance is placed
upon the decision of this Court in Mohd. Iqbal Khanday v. Abdul Majid Rather28.
32. W.P.(C) No. 491/2020 is filed for quashing and setting aside the termination order dated
2.3.2020 and to direct the respondents to reinstate the petitioners with full back wages and
continuity of service. Several applications were filed in the above petition seeking impleadment as
parties. I.A. No. 116777/2020, I.A. No. 106077/2020 and I.A. No. 93552/2020 have been filed byAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

the successful candidates. Whereas, I.A. No. 50899/2020 is filed by the candidates who were
declared unsuccessful or non− selected in the initial merit list, but whose score was revised after
considering the objections to the answer key, so as to enter the (2010) 12 SCC 770 (1999) 7 SCC 569
(1994) 4 SCC 34 merit list. An application for directions being I.A. No. 50896/2020 was filed by the
aforesaid unsuccessful candidates seeking to be appointed as per the revised merit list and to pay
arrears from January, 2017 when they ought to have been appointed. The applications of the
unsuccessful or non−selected candidates shall be dealt with a little later.
33. The ground for filing the above writ petition is that the termination order dated 2.3.2020 is
violative of Articles 14, 19(1)
(g) and Article 21 of the Constitution of India. That, the respondent corporation had malafidely tried
to improve its case at every stage by adding new grounds. For instance, in the first inquiry report
dated 29.5.2017, the Chief Engineer stated that the sanction for a few posts was made by Board of
Directors of the respondent corporation, which was not competent to do so, as only the Government
had authority to sanction posts. Further, the candidates with lower marks in the written test were
given higher marks in the interview and that the entire selection process was rushed through within
a period of less than one month from the date of advertisement issued on 13.12.2016 and
appointment orders issued on 3.1.2017, presumably because election code of conduct was about to
come into force. Thereafter, in second inquiry report dated 7.7.2017, the Chief Engineer added that
the respondent corporation could not have recruited without permission of the Finance Department
of the Government in view of the loan of Rs.300 crores given by the Government to the respondent
corporation. Further, the examination results were published without inviting objections, some of
the answers in the answer key and some questions in the question paper were wrong and that
answer sheets of 4 successful candidates were identical.
34. Then, in the termination order dated 11.8.2017, it was added that the permission of Election
Commission of India should have been taken as the Model Code of Conduct had come into effect
prior to joining date. Before the High Court, it was urged that the respondent corporation was facing
shortage of funds and was not in a position to pay so many additional employees and that provision
was not made for reservation of posts in accordance with law. Thereafter, in the review application,
the ground taken was that on the basis of revaluation, some of the selected candidates would not
even have been eligible for the interview.
35. The petitioners would submit that the writ petition is maintainable in view of violation of their
fundamental rights under Articles 14, 19(1)(g) and 21 of the Constitution. Reliance is placed upon
the decision of this Court in Romesh Thappar v. State of Madras29. It was urged that the action of
the respondents in adding new grounds at each stage shows that the respondent corporation despite
being ‘State’ under Article 12 of the Constitution, has been prosecuting the matter like a desperate
private litigant, under dictation.
36. The petitioners would then urge that the impugned order had been passed by the respondents
whilst relying upon the opinion of experts that there was a possibility that the response filed by
certain candidates ‘might have been doctored’, which is a mere speculation, without any data in itsAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

support. It was submitted that the data upon which the respondents relied, to pass the order dated
2.3.2020, was available even at the time of passing of the judgment dated 15.11.2018 by this Court;
and is in the nature of ‘being repacked in a fresh package’ and the same 1950 SCR 594 cannot be
permitted as per decision of this Court in Manohar Lal (Dead) by LRs. v. Ugrasen (Dead) by LRs. &
Ors.30.
37. It was urged that the respondents deliberately did not ask the testing agency for checksum data
until one year period of storing had expired. It was then pointed out that the testing agency, in an
affidavit before the High Court (in W.P. (S/S) No. 7647/2020 – relating to another examination),
had stated certain facts concerning the present selection process. Particularly, that the primary data
was not deleted but merely moved from the cloud server to data storage centre in accordance with
its Data Retention Policy and is still available with the testing agency and that the respondent
corporation had never approached them for obtaining the same. Therefore, the opinion given by the
two experts was based on conjectures and surmises that the primary data is not available.
38. It was submitted that the SIT Report dated 22.1.2020 and the reports of Central Forensic
Science Laboratory (CFSL) dated 28.8.2019, 19.11.2019, 11.12.2019 and 1.1.2020 (considered by the
SIT in its report) relied upon by the respondents in passing the impugned order ought to have been
served upon the (2010) 11 SCC 557 petitioners before taking any adverse action against them, in
light of dictum in Union of India & Ors. v. S.K. Kapoor31. Further, the SIT report is in the nature of
a final report by an investigative agency and cannot be treated as conclusive proof of malpractices.
Moreover, the petitioners cannot be made to suffer at the cost of any malfeasance by the testing
agency.
39. It was urged that the documents relied upon by the respondents have never been proved or
subjected to scrutiny by a fact−finding authority or tribunal, nor had the petitioners been given an
opportunity to meet the assertions made therein. That the testing agency had by letter dated
7.11.2017 intimated the SIT that primary data was stored in data storage facility and not the hard
drive, despite which, the SIT raided its office on 10.9.2018 and seized random hard drives of ‘dump
data’ and sent the same to CFSL. Therefore, the very basis of CFSL’s analysis is flawed.
40. Further, despite the finding in SIT report that the testing agency was a part of criminal
conspiracy for deleting the primary data, the respondents continued to engage the testing agency for
conducting examinations. The respondent corporation procured a (2011) 4 SCC 589 letter dated
31.8.2020 from the Addl. Chief Secretary, Government of U.P. recommending to the DGP, SIT that
the testing agency be blacklisted, about three years after the irregularities came to its knowledge,
which clearly demonstrates malafides. It was then submitted that there is no substance in the
argument that the selection process was hastily completed as the same was in full compliance with
the advertisement and applicable SoP and Rules of the respondent corporation. Moreover, the said
argument was rejected by the High Court in judgment dated 28.11.2017.
41. It was then urged that the only liberty granted to the respondents is to rework the answer sheets
based on the corrections, after giving candidates an opportunity of hearing. Further, the respondent
corporation had failed to discharge the burden that the response sheets were manipulated andAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

argued of inability to verify the veracity of examination process, which cannot be permitted.
42. The submission that principles of natural justice were violated was akin to the submissions made
in the above contempt petitions. It was submitted that there can be no exception to the principle of
audi alter partem. Reliance is placed upon decision of this Court in Nisha Devi v. State of Himachal
Pradesh & Ors.32 and Indian Institute of Information Technology, Deoghat Jhalwa, Allahabad &
Anr. v. Dr. Anurika Vaish & Ors.33 to submit that when termination order was set aside for not
hearing the affected parties before passing it and liberty is granted to pass a fresh reasoned order,
the employer−State cannot pass another fresh termination order without hearing the affected
persons yet again.
43. On the other hand, the respondents would raise a preliminary objection as regards the
maintainability of the Writ Petition as the alternate remedy under Article 226 of the Constitution
was not exhausted, whilst placing reliance on decisions of this Court in P.N. Kumar & Anr. v.
Muncipal Corporation of Delhi34, Kanubhai Brahmbhatt v. State of Gujarat35, Kunga Nima Lepcha
& Ors. v. State of Sikkim & Ors.36, Confederation of All Nagaland State Services (2014) 16 SCC 392
(2017) 5 SCC 660 (1987) 4 SCC 609 1989 Supp (2) SCC 310 (2010) 4 SCC 513 Employees’ Assn. &
Ors. v. State of Nagaland37 and Amrit Lal Berry v. Collector of Central Excise, New Delhi & Ors. 38.
It was also pointed out that parties similarly placed to that of the petitioners filed writ petition
before the High Court being W.P. (C) No. 13083/2020 (Service Single) and even the petitioners
ought to have approached High Court.
44. With reference to petitioners’ reliance on affidavit filed by the testing agency, the respondents
would submit that the onus was on the testing agency to give correct and complete data to the SIT
for investigation. It was pointed out that the SIT had recorded the statement of Mr. Vishvajeet
Singh, Technical and Delivery Head of the testing agency, wherein he stated that the examination
data was kept in the cloud only for a month, after disk. Further, the testing agency had itself
accepted in the certificate provided to the SIT under Section 65−B of the Indian Evidence Act,
187239, that the original primary data had been deleted and the backup data does not contain any
system logs. And that, the deletion of primary server data made it impossible (2006) 1 SCC 496
(1975) 4 SCC 714 For short, ‘the 1872 Act’ to re−analyse the response sheets using the secondary
data provided in the form of CDs, as the same is not accurate. It was then urged that the respondent
corporation had taken prompt action against its officials involved in the irregularities committed in
the recruitment process.
45. It was submitted that the respondents had rightly cancelled the entire recruitment process and
terminated the services of all the recruits in accordance with law as the illegality was of such nature
that the tainted candidates could not have been segregated from the untainted and the veracity of
the entire examination process was doubtful. Further, it was urged that if the tainted and untainted
candidates could be segregated, the show cause notice would have been issued to the concerned
candidate. However, since the segregation was not possible and did not take place, the entire
recruitment process had to be cancelled in view of O. Chakradhar40. Thus, no individual show cause
notice was necessary in law. This submission of the respondents is similar to the stand taken by
them in the above contempt petitions.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

46. It was then urged that even if an opportunity of hearing is given to the candidates, it would be an
empty formality as the respondents do not have primary data to compare actual correct answers
given by the candidates, as it would be impossible to segregate the tainted and untainted candidates
in absence of the primary data. Even if an opportunity of hearing is granted, the decision of the
respondent corporation would remain the same. Reliance in that regard was placed upon decision of
this Court in Dharampal Satyapal Limited v. Dy. Commissioner of Central Excise, Gauhati & Ors.41.
RE: IMPLEADMENT APPLICATIONS BY NON−SELECTED CANDIDATES:
47. Coming to the impleadment applications filed by non− selected candidates, their case is that
upon objections raised by the candidates that the answer key was not released, the respondents had
published the answer sheet and answer key on 28.2.2017. The applicants found various errors
therein and being aggrieved, they had filed W.P. Nos. 10667/2017 and 21876/2017 before the High
Court, wherein the High Court (2015) 8 SCC 519 directed the respondents to conduct an enquiry in
the alleged irregularities. Pursuant thereto, an inquiry was conducted wherein the errors were taken
note of and accordingly, the testing agency had submitted a revised list to the respondents. In that
revised merit list, these applicants had stood higher in the merit list than the appointees. The
respondents, instead of reworking the appointments in accordance with the revised list, had
annulled the entire selection process first vide order dated 11.8.2017 (which was later set aside) and
then again by order dated 2.3.2020.
48. These applicants would submit that various grounds noted by the respondents in the order
dated 2.3.2020 had already been rejected by the High Court in its judgment dated 28.11.2017,
whereby the earlier order dated 11.8.2017 was set aside. The High Court in the said judgment had
held that there was no prohibition imposed against appointment on regular selection in the model
code of conduct and the post of Assistant Engineers were regular in nature. That the requirement
mandating prior sanction of the State Government was not applicable to the present case as the
requirement was made by G.O. dated 13.12.2016 whereas the selection process in question had
commenced on 19.11.2016. That the permission to advertise the posts was made by the Chairman,
which was ratified by the Board of Directors of the respondent corporation. The argument of
malafide in the selection process was rejected by the High Court and the said judgment was upheld
by this Court.
49. It was urged that the testing agency undertook the exercise of rectification of incorrect entries in
the key and submitted a report to the respondents dated 8.8.2017 containing the revised merit list
and therefore, the only option available to the respondents was to act upon the revised merit list. It
was submitted that cancellation of entire selection process (by order dated 2.3.2020) when it was
merely a case of certain infirmities in the evaluation, would be unreasonable, arbitrary and
disproportionate. In support of this plea, reliance is placed upon decisions of this Court in Union of
India & Ors. v. Rajesh P.U. Puthuvalnikathu & Anr.42, Rajesh Kumar & Ors. v. State of Bihar &
Ors.43 and K. Channegowda & Ors. v. Karnataka Public Service Commission & Ors.44.
(2003) 7 SCC 285 (2013) 4 SCC 690 (2005) 12 SCC 688Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

50. It was then urged that the principle of proportionality has been recognised as an aspect of Article
14 by this Court in Modern Dental College and Research Centre & Ors. v. State of Madhya Pradesh &
Ors.45 and in view whereof, the cancellation of entire selection process, being disproportionate, is
violative of Article 14.
51. Further, it was urged that even in the case of malpractice and malafide, entire selection process
should not be cancelled but the tainted and untainted candidates ought to be segregated. In support
of this plea, reliance was placed on decisions of this Court in Inderpreet Singh Kahlon & Ors. v. State
of Punjab & Ors.46, Girjesh Shrivastava & Ors. v. State of Madhya Pradesh & Ors.47 and Joginder
Pal & Ors. v. State of Punjab & Ors.48. It was then urged that the mandate of decisions of High
Court dated 28.11.2017 and 25.7.2018 and of this Court dated 16.3.2018 and 15.11.2018 was to re−
work the answer sheets and a limited liberty to that effect was given to the respondents. The
applicants would then take a stand similar to (2016) 7 SCC 353 (2006) 11 SCC 356 (2010) 10 SCC
707 (2014) 6 SCC 644 that of the petitioners in the above contempt petitions, to submit that the
judgment of a court has to be understood in its entirety and cannot be read as a statute, whilst
relying upon the decision of this Court in Purnendu Mukhopadhyay & Ors. v. V.K. Kapoor & Anr.49.
Therefore, the order dated 2.3.2020 passed by the respondents is against the mandate of the above
judgments. RE: TRANSFER PETITION:
52. In T.P. (C) No. 1209/2020, the petitioners have approached this Court under Article 139A for
transfer/withdrawal of Writ Petition (C) No. 13083/2020 (Service Single) pending before the High
Court to this Court as the subject matter of the said writ petition (impugned order dated 2.3.2020)
is already pending challenge before this Court in W.P. No. 491/2020 and companion contempt
petitions. In W.P. (C) No. 13083/2020 (Service Single) before the High Court, the petitioners have
relied upon opinion of their own expert, Dr. A.V. Subrahmanyam, Assistant Professor at IIIT Delhi,
who had discredited the IIT and IIIT reports and opined that the ‘checksum’ method of
fingerprinting not having (2008) 14 SCC 403 been deployed shall have no bearing on the candidates
as they had no role to play in the same.
53. These petitioners would submit that the issue of veracity and weight of experts shall be
examined in a departmental inquiry and cannot be gone into before this Court. Further, the
petitioners urge that they would like to present their expert and to cross examine other experts, so
that the truth could be distilled. That the respondents ought to have had a departmental inquiry by
giving the petitioners an opportunity to hear, so that the parties could have led their evidence and
the decision should have been taken on the basis of the outcome of such inquiry.
54. We have heard Mr. Mukul Rohatgi, Ms. Meenakshi Arora, Mr. Ravindra Raizada, learned senior
counsel, Mr. Gaurav Mehrotra, Mr. Kumar Shivam and Mr. Rohit Anil Rathi, learned counsel − for
the petitioners; Mr. Nizam M. Pasha for the impleaded petitioners; Ms. Sanskriti Pathak, learned
counsel for applicants (candidates successful as per revised merit list); and Mr. Vikas Singh, learned
senior counsel for the respondents.
55. The broad points that arise for our consideration are:Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

1. Whether the order dated 4.12.2018 passed by the respondents is in the teeth of
judgment of this Court dated 15.11.2018, requiring compliance of judgment of High
Court dated 28.11.2017, for deliberate failure to reinstate with continuity of service
and to pay arrears to the petitioners?
2. Whether the termination order dated 2.3.2020 passed by the respondents is in
wilful disobedience of and in the teeth of judgment of this Court dated 15.11.2018, for
not following the principles of natural justice and is thus non− est in law?
CONSIDERATION
56. At the outset, we deem it appropriate to first answer the preliminary objection regarding
maintainability of writ petition under Article 32 of the Constitution of India. We have no hesitation
in rejecting this preliminary objection for more than one reason. It is well−established position that
if the termination order is assailed on the ground of violation of principles of natural justice or
fundamental rights guaranteed under Part III of the Constitution, such a grievance can be brought
before the constitutional Court including by way of writ petition under Article 32 of the Constitution
of India. It is a different matter that this Court may be loath in entertaining the grievance directly
under Article 32 and instead relegate the petitioner(s) before the High Court to first exhaust the
remedy under Article 226 of the Constitution of India. That is also because this Court will then have
the advantage of the judgment of the High Court on relevant aspects. In other words, it is not a
question of maintainability of writ petition, but one of exercise of discretion with circumspection in
entertaining writ petition under Article 32 in such matters. Further, in the present case, there are
other proceedings pending in the form of contempt petitions and a transfer petition wherein the
termination order dated 2.3.2020 is the subject matter. Thus, the arguments in these cases will be
overlapping. In that, the self−same order has been impugned in the writ petition filed before this
Court. The fact that other affected similarly placed persons have filed writ petitions directly before
the High Court and which are stated to be pending, can be no impediment for this Court in
entertaining and deciding the writ petition. For, the issue regarding the purport of orders passed by
this Court needs to be answered appropriately in contempt petitions only by this Court. It is not
open to the High Court to interpret or explain the order passed by this Court in previous
proceedings between the parties. The High Court can only follow the dictum of this Court which is
binding on it. Accordingly, we are not impressed by the preliminary objection taken by the
respondents regarding the maintainability of writ petition under Article 32 of the Constitution by
similarly placed persons directly filed before this Court to assail the impugned order dated 2.3.2020,
which is also subject matter of second set of contempt petitions.
57. As aforesaid, we are dealing with two sets of contempt petitions. The first set complains about
non−compliance of order dated 28.11.2017 passed by the High Court, which came to be upheld by
this Court consequent to disposal of special leave petitions being SLP(C) Nos. 5410−5419/2018 vide
order dated 16.3.2018, and more particularly, reiterated by this Court in its order dated
15.11.201850 directing the respondents to first act upon the decision of the High Court dated
28.11.2017 and only thereafter proceed in the matter in accordance with law by passing a fresh,
reasoned order. It is not in dispute that after the judgment of this Court dated 15.11.2018, aAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

consequential order was passed by the High Court on 26.11.2018. The respondents thus issued order
dated 4.12.2018 (reproduced in paragraph 2 above), reengaging the petitioners on the concerned
posts without continuity of service and arrears.
58. The grievance of the petitioners is that the unambiguous direction given by the High Court and
upheld by this Court was to reinstate the petitioners on the same position with full back wages. No
more and no less. The respondents were, therefore, obliged to issue order of reinstatement with
continuity of service and back wages. The argument is attractive at the first blush, but on deeper
scrutiny of the orders passed by the High Court and finally by this Court, it is noticed that the
direction is limited to permit the petitioners to work on the posts of Assistant Engineer (Civil),
Assistant Engineer (Electric/Mechanical) and Assistant Engineer (Computer Science and
Electronics and Communication/Electrical and Electronics) and to pay them regular salary month
by month as and when it becomes due and payable to them. That can be discerned from the last
paragraph of the order dated 28.11.2017 (reproduced in paragraph 9 above). On similar lines, the
High Court disposed of another writ petition challenging the termination order dated 11.8.2017
passed by the respondents, vide order dated 12.12.2017 (reproduced in paragraph 10 above). In
these orders, the expression used by the High Court is “to permit the petitioners to work on the
concerned posts and to pay them regular salary as and when the same accrues to them”. The order
dated 28.11.2017 passed by the High Court was upheld by this Court on 16.3.2018. In that order,
after recording contentions of both sides, while disposing of petitions it is observed as follows: − “…..
Be that as it may, having gone through the impugned judgment, we do not find that the door is yet
closed. It is for the petitioners, if they are so advised, to approach the High Court itself for a liberty
to re−work the answer sheets on the basis of the corrections, in case the High Court is also of the
view that the corrections need to be made. …..” The respondents had, therefore, pursued review
petition as per the liberty given by this Court. The same came to be disposed of by the High Court on
25.7.2018. On perusal of that order (reproduced in paragraph 12 above), there is nothing to indicate
that the High Court expressly directed reinstatement of petitioners with continuity of service and
back wages, as such. Even in the decision of this Court dismissing the appeals filed by respondents,
vide order dated 15.11.2018 (reproduced in paragraph 14 above), no such direction has been issued.
The limited direction is that the respondents must first act upon the decision of the High Court
dated 28.11.2017 and only thereafter proceed in the matter in accordance with law by passing a
fresh, reasoned order.
59. After cogitating over the orders passed by the High Court and this Court referred to above, it
becomes amply clear that the High Court had quashed and set aside the first termination order
dated 11.8.2017 solely on the ground that it was passed in violation of principles of natural justice
and further observed that the selection as a whole was not liable to be cancelled without undertaking
an exercise to separate the tainted candidates from the untainted. While so observing, it was made
clear that the respondents were free to pass a fresh, reasoned order in accordance with law.
60. In light of the aforesaid discussion, we have no hesitation in accepting the explanation offered by
the respondents that going by the text of the orders passed by the High Court and this Court, it was
open to the respondents to issue order (dated 4.12.2018) to reengage the petitioners on the sameAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

posts from the date of order and to pay them regular salary month by month thereafter or as and
when it would accrue to them. The orders passed by the High Court and this Court, as
aforementioned, do not contain explicit direction to reinstate the petitioners with continuity of
service and back wages as such. Instead, the expression used is only “to permit the petitioners to
work on the posts” which were held by them at the time of their termination and “to pay them
regular salary month by month” and “as and when the same accrues to them”. Thus understood, it is
not a case of wilful disobedience of the orders of the Court.
61. Arguendo, the interpretation as propagated by the petitioners of the stated orders dated
28.11.2017 passed by the High Court and 16.3.2018 of this Court, is a possible view. Being another
possible view, the benefit must then be given to the respondents. For, it would certainly not be a
case of wilful disobedience as enunciated by this Court in Sushila Raje Holkar v. Anil Kak
(Retired)51 which follows the dictum of this Court in State of Bihar v. Rani Sonabati Kumari52,
Purnendu (2008) 14 SCC 392 AIR 1961 SC 221 Mukhopadhyay and Maruti Udyog Limited v.
Mahinder C. Mehta & Ors.54.
62. It is well settled that contempt action ought to proceed only in respect of established wilful
disobedience of the order of the Court. This Court in paragraph 12 of the decision in Ram Kishan55
observed thus: − “12. Thus, in order to punish a contemnor, it has to be es− tablished that
disobedience of the order is “wilful”. The word “wilful” introduces a mental element and hence,
requires looking into the mind of a person/contemnor by gauging his actions, which is an indication
of one's state of mind. “Wilful” means knowingly intentional, conscious, calculated and deliberate
with full knowl− edge of consequences flowing therefrom. It excludes ca− sual, accidental, bona fide
or unintentional acts or genuine inability. Wilful acts does not encompass involuntarily or negligent
actions. The act has to be done with a “bad purpose or without justifiable excuse or stubbornly, ob−
stinately or perversely”. Wilful act is to be distinguished from an act done carelessly, thoughtlessly,
heedlessly or in− advertently. It does not include any act done negligently or involuntarily. The
deliberate conduct of a person means that he knows what he is doing and intends to do the same.
Therefore, there has to be a calculated action with evil motive on his part. Even if there is a
disobedi− ence of an order, but such disobedience is the result of some compelling circumstances
under which it was not possible for the contemnor to comply with the order, the contemnor cannot
be punished. “Committal or sequestra− tion will not be ordered unless contempt involves a degree of
default or misconduct.” (Vide S. Sundaram Pillai v. V.R. Pattabiraman56, Rakapalli Raja Ram
Gopala Rao v. Nara− (2007) 13 SCC 220 (1985) 1 SCC 591 gani Govinda Sehararao57, Niaz
Mohammad v. State of Haryana58, Chordia Automobiles v. S. Moosa59, Ashok Paper Kamgar Union
v. Dharam Godha60, State of Orissa v. Mohd. Illiyas61 and Uniworth Textiles Ltd. v. CCE62).”
(emphasis supplied) It is useful to recall the exposition in Director of Education, Uttaranchal63 and
also in K.G. Derasari & Anr. v. Union of India & Ors.64; wherein this Court observed that in
exercising contempt jurisdiction, the primary concern must be whether the acts of commission or
omission can be said to be contumacious conduct of the party who is alleged to have committed
default in complying with the directions given in the judgment and order of the Court. Further, the
Court ought not to take upon itself power to decide the original proceedings in a manner not dealt
with by the Court passing the judgment and order. It is also not open to go into the correctness or
otherwise of the order or give additional directions or delete any direction, which course could beAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

adopted only in review jurisdiction and not contempt proceedings.
(1989) 4 SCC 255 (1994) 6 SCC 332 (2000) 3 SCC 282 (2003) 11 SCC 1 (2006) 1 SCC 275 (2013) 9
SCC 753 (2001) 10 SCC 496
63. Reliance placed on Deepali Gundu Surwase65 by the petitioners is inapposite. It was a case of
wrongful termination and entitled the petitioner therein relief of back wages. The respondents have
instead relied upon the exposition in P. Karupaiah (Dead) through Legal Representatives v. General
Manager, Thruuvalluvar Transport Corporation Limited66 and J.K. Synthetics Ltd.67 which has
restated the legal position regarding back wages. It has been held that it is not automatic or natural
consequence of reinstatement. Suffice it to mention that for reasons already recorded hitherto
including that the limited direction given by the High Court and not disturbed by this Court was to
permit the petitioners to work on the concerned posts and to pay them regular salary as and when
the same accrues to them, the plea under consideration needs to be recorded only to be rejected.
64. Be that as it may, keeping in mind the settled legal position, we have no hesitation in concluding
that the case at hand does not qualify the test of contumacious, much less wilful disobedience of the
order of the Court by the officers of the respondents as such. In other words, the basis on which the
(2018) 12 SCC 663 (paragraph 10) contempt action against the respondents in reference to order
dated 4.12.2018 issued by the respondents, has been initiated is tenuous. Hence, the same is
rejected.
65. We would now revert to the second set of contempt petitions, which emanate from termination
order dated 2.3.2020 issued by the respondents. These petitions essentially proceed on the
allegation that the respondents committed wilful disobedience of the order of this Court dated
15.11.2018 passed in Civil Appeal Nos. 11017−11018/2018 in not affording prior opportunity of
hearing to the petitioners and similarly placed persons despite express direction contained in the
said order. For considering this grievance, we may reproduce the relevant portion of the order dated
15.11.2018, which reads thus: −
14. The limited plea taken before this Court as noted in the first paragraph of order dated 16th
March, 2018 was to allow the appellants to re−work the question and answer sheets and revise the
merit list and issue fresh, reasoned order after providing opportunity of hearing to the affected
candidates. That option has been kept open. It is for the appellants to pursue the same. In other
words, the appellants must, in the first place, act upon the decision of the High Court dated 28 th
November, 2017 whereby the order passed by the Chief Engineer dated 11th August, 2017 has been
quashed and set aside. The appellants may then proceed in the matter in accordance with law by
passing a fresh, reasoned order. Indeed, while doing so, the appellants may take into consideration
the previous inquiry reports as also all other relevant material/documents which have become
available to them. We make it clear that we have not dilated on the efficacy of the opinion given by
the experts of the “IIIT Allahabad and IIT Kanpur.” (emphasis supplied)
66. The Court had set aside the termination order dated 11.8.2017 issued by the respondents, solely
on the ground that it was in violation of principles of natural justice. At the same time, liberty wasAbhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

given to the respondents to pass a fresh order in accordance with law including by undertaking
exercise of segregating the tainted from the untainted candidates. Indeed, the Court expected that
before taking any precipitative action against the petitioners, the respondents must afford
opportunity of hearing to them. This observation is contextual. It would come into play dependent
upon the opinion eventually formed by respondents after due consideration of the material collated
by them to distinguish the tainted and untainted candidates, was possible or otherwise. Had the
respondents concluded that it was possible to segregate tainted from untainted candidates, they
would have been obliged to comply with the directions given by the High Court and restated by this
Court in order dated 15.11.2018, to afford prior opportunity of hearing to the petitioners and
similarly placed persons before passing fresh, reasoned order. However, from the subject
termination order dated 2.3.2020, which is a speaking order, it is crystal clear that after due enquiry
and taking into consideration all aspects of the matter, in particular the enquiry reports and the
opinion of the experts including final report of SIT, the respondents were of the considered opinion
that it was not possible to segregate tainted from the untainted candidates for reasons recorded in
that order. We are not inclined to go into the correctness of the said reasons, because it is subject
matter of challenge in writ petitions pending before the High Court (as pointed out in Annexure R−
29 of the Supplementary Affidavit), filed not only by Assistant Engineers, but also by Junior
Engineers, Routine Grade Clerks and others.
67. We would, therefore, confine our analysis as to whether the respondents were justified in
passing subject termination order dated 2.3.2020 without giving prior opportunity of hearing to the
petitioners. In light of the conclusion reached by the respondents in the stated order dated 2.3.2020
— that it was not possible to segregate the tainted from the untainted candidates, in law, it must
follow that the respondents could annul the entire selection process and pass the impugned order
without giving individual notices to the petitioners and similarly placed persons. We are fortified in
taking this view in terms of the exposition in O. Chakradhar68 and the subsequent decisions of this
Court in Joginder Pal69, Veerendra Kumar Gautam70 and Vikas Pratap Singh & Ors. v. State of
Chhattisgarh & Ors. 71, adverted to in paragraph 12 of the judgment dated 15.11.2018 72 of this
Court while disposing of earlier appeals between the parties.
68. In other words, since the respondents have concluded that it was not possible to segregate
tainted from the untainted candidates because of the reasons noted in the termination order dated
2.3.2020, in law, there was nothing wrong in respondents issuing the said termination order
without affording prior opportunity to the petitioners and similarly placed persons. Had it been a
case of even tittle of possibility in segregating the tainted from the untainted candidates, which
exercise the respondents were permitted to engage in, in terms of the decision of this Court dated
15.11.2018, it would have been a different matter. In that case alone, the petitioners and similarly
placed (2013) 14 SCC 494 persons could complain of wilful disobedience of the order passed by this
Court dated 15.11.2018.
69. Having said thus, we must conclude that even the second set of contempt petitions in reference
to the subject termination order dated 2.3.2020 being in violation of direction given by this Court to
afford opportunity to the petitioners vide order dated 15.11.2018, must fail.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

70. Considering the fact that multiple writ petitions have been filed by different groups of affected
persons before the High Court being similarly placed persons against the subject termination order
dated 2.3.2020 and as the same are pending, as aforesaid, to obviate even slightest of prejudice
being caused to the petitioners in those cases, who are not before us, we refrain from examining the
arguments regarding the justness and validity of the stated order and leave all other contentions
open to the parties to be pursued before the High Court in pending proceedings. Consequently, we
would dispose of the transfer petition, as well as, the writ petition by relegating the petitioners
therein including the applicants in intervention/impleadment applications, to pursue their
grievance in the form of writ petitions before the High Court, which could be heard by the High
Court analogously along with all other pending writ petitions involving overlapping issues to obviate
any inconsistency and conflicting findings regarding the same subject matter in any manner.
Indeed, in the event the High Court agrees with the conclusion recorded by the respondents in the
stated order dated 2.3.2020, that it is not possible to segregate the tainted from the untainted
candidates, the High Court would be bound by the observations made by us in this judgment. For, in
that eventuality, in law, it would not be necessary for the respondents to give prior hearing or afford
opportunity to the petitioners and similarly placed persons before annulling the entire selection
process and issuing the termination order under challenge.
71. Accordingly, while discharging the show−cause notices issued in the concerned contempt
petitions and disposing of all the contempt petitions, we deem it appropriate to relegate the
petitioners in the transfer petition and the writ petition filed in this Court, before the High Court to
pursue their remedy under Article 226 of the Constitution to assail the order dated 2.3.2020 with
further direction that all petitions involving overlapping issues and referred to in Annexure R−29 of
the Supplementary Affidavit or any other writ petition pending or to be filed, list whereof be
furnished by the parties to the High Court, for being heard analogously. We request the High Court
to expeditiously dispose of the writ petitions, leaving all contentions other than decided in this
judgment, open to the respective parties to be raised before the High Court. The same be decided on
its own merits as per law.
72. In view of the above, we pass the following order: − (1) Show−cause notices issued in the
respective contempt petitions stand discharged. Contempt petitions are dismissed;
(2) The transfer petition stands rejected, as a result of which the writ petitions referred to therein
will now proceed before the High Court in terms of this judgment;
(3) The writ petition is disposed of with liberty to the petitioners therein including applicants in
intervention/impleadment applications to pursue their remedy before the High Court by way of writ
petition under Article 226 of the Constitution, if so advised. That writ petition be decided on its own
merits in accordance with law keeping in mind the observations made in this judgment along with
other pending or fresh writ petitions involving similar issues; and (4) We request the High Court to
take up all writ petitions involving overlapping issues together for analogous hearing expeditiously.
We leave all contentions open except the issues decided in this judgment.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

73. There shall be no order as to costs. All pending interlocutory applications stand disposed of in
terms of this judgment.
………………………………J. (A.M. Khanwilkar) ………………………………J. (B.R. Gavai) New Delhi;
June 03, 2021.Abhishek Kumar Singh vs G. Pattanaik on 3 June, 2021

