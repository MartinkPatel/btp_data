Fateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954
Equivalent citations: AIR1955CAL465, 59CWN223
JUDGMENT
 Chakravartti, C.J. 
1. This is an appeal from an order of S.R. Das Gupta, J., dated 29-6-1953, by which the learned
Judge set aside an award in favour of the appellants on the ground that in making it without any
evidence in its support, the arbitrators had misconducted the proceedings.
2. The facts are as follows. On 3-11-1951, the appellants, Messrs. Fatehchand Murlidhar, agreed to
sell and the respondents, Messrs. Juggilal Kamlapat, agreed to buy, 15,000 pieces of Wool Packs at
the fate of Rs. 11/12/- per piece. The goods were to be delivered in three equal instalments of 5,000
pieces each on 25-11-1951, 15-12-1951, and 7-1-1952, respectively. Delivery of the first two
instalments was duly given and no question arises with regard to them.
With regard to the third instalment due to be delivered on the 7-1-1952, shipping instructions were
given on 20-12-1951, for placing the goods alongside a vessel, called "Pantakota". Admittedly, the
goods were not delivered and ordinarily there would be a breach of the contract on the part of the
appellants. On 11-1-1952, however, the respondents forwarded to the appellants further shipping
instructions which they had received from their own buyers and those instructions were for placing
the goods alongside another vessel, named S. S. "Purnea .
According to the appellants, the letter from the respondents buyers, Messrs. Jute & Gunny Brokers
Ltd., which had been endorsed in their favour, was received by them on the 12-1-1952, and the goods
were, in fact placed alongside the vessel on the the 13th of January following. The goods were,
however, not lifted. In those circumstances, the appellants began to write to the respondents to the
effect that they had made a valid tender of the goods, but the respondents had failed and neglected
to take delivery and that accordingly they had become responsible to pay them the full price of the
goods at the contract rate, or if they were compelled to sell the goods, to pay the difference.
The respondents, on the other hand, it appears treated the appellants to have been in default and on
21-1-1952, they sent them a bill, being Bill No. 2008/908, for a sum of Rs. 7,500/- which they
claimed to be entitled to recover as damages on account of the non-delivery of the goods. Earlier on
18-1-1952, the appellants had sent to the respondents their own bill for Rs. 58,750/- which was the
price of 5,000 pieces of Wool Packs at the rate of Rs. 11/12/- per pack.
Sundry correspondence followed and it appears that the respondents demanded from the appellants
proof of their having placed the goods alongside the "Purnea" on 13-1-1952, Such proof was
furnished, but no payment was yet made by the respondents. Their contention was that the goodsFateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

had been placed alongside the ship after it had closed loading. Thereafter, the appellants informed
the respondents that if they did not yet take delivery of the goods and pay the price, they would be
compelled to sell them on account of the respondents and at their risk.
There having been still no response from the respondents, except that they went on repeating their
own claim for Rs. 7,500/-, the appellants actually sold the goods on 1-3-1952, at the rate of Rs.
8/2/-per piece. Thereafter, they sent the respondents a bill for Rs. 18,328/2/- which was made up of
Rs. 18,125/- being the difference between the contract price and the auction price of the 5000 pieces
of Wool Packs and a sum of Rs. 203/2/- which was said to have been charged by the auction-broker
as his brokerage. The bill was not paid.
3. Thereafter, the appellants referred the dispute to the arbitration of the Bengal Chamber of
Commerce in accordance with an arbitration agreement contained in the contract. They claimed the
same sum of Rs. 18,328/2/- on the allegation that they had made a valid tender of the goods within
the time up to which the period of delivery had been extended and that the respondents had
wrongfully failed and neglected to take delivery. The period of delivery was said to have been
extended up to 21-1-1952.
The only defence set up by the respondents, which is material for the purpose of the present appeal,
was that the dispute between the parties had been settled on 18-3-1952, by the appellants having
paid to the respondents a sum of Rs. 5,000/-in full settlement of the respondents' claim of damages.
The appellants, admitted the payment of Rs. 5000/- in the course of a further statement which they
filed before the arbitrators, but they added that the payment did not "represent a normal or a willing
deal".
According to both the parties, no oral evidence was given before the arbitrators. They made and
published their award on 17-10-1952, and allowed the appellants' claim to the extent of Rs.
18,125/-which it will be recalled, is the precise sum claimed by the appellants as the difference
between the contract price and the auction price of the 5000 pieces of Wool Packs.
4. Thereafter, on 18-4-1953, the respondents made an application to this Court for setting aside the
award. Of the various grounds on which the award was assailed, only two are material for the
purposes of the present appeal. One was that the arbitrators had been guilty of misconduct,
inasmuch as they had completely ignored the settlement arrived at between the parties and
disbelieved it in the absence of any evidence to the contrary. The "other was that the quantum of
damages awarded by the arbitrators was in violation of the law prevalent in India. S. R. Das Gupta,
J., who heard the application accepted the first contention of the respondents, but he overruled the
second. As the award could -not stand if the first contention of the respondents succeeded, the
learned Judge necessarily set aside the award. It is against that order that the present appeal was
preferred.
5. In support of the appeal, Mr. A.K. Sen contended that the learned Judge had misconstrued the
so-called admission made by the appellants and thrown on them a burden of proof which did not lie
on them under the law. He contended further that the ground relating to the alleged settlement andFateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

the complaint that it had been disbelieved in the absence of evidence to the contrary ought not to
have been entertained at all, inasmuch as it had nowhere been taken in the petition.
6. I am unable to accept the second contention of Mr. Sen, The petition stated quite clearly in para. 7
that all disputes between the parties had been settled and a sum of Rs. 5,000/- had been paid by the
appellants in full settlement of the respondents' claim of damages and that no reference to
arbitration lay, inasmuch as there was no longer any dispute between the parties. Having thus
pleaded the alleged settlement, the petition proceeded to state in para, 10(g) that the arbitrators had
been guilty of misconduct, inasmuch as they had completely ignored the settlement arrived at
between the parties and the payment of Rs. 5,000/- by the appellants to the respondents.
In my view, the ground urged at the hearing before S.R. Das Gupta J., and entertained by him had
been sufficiently taken in the petition and no complaint can reasonably be made that the
respondents had been allowed to import something quite foreign to the case originally made in the
petition or wholly outside it. It is true that all the arguments with which the ground was sought to be
supported in the course of the hearing were not taken in the petition. But however strictly the
pleadings in arbitration cases may have to be scanned and however firmly parties may have to be
held to them, it cannot be reasonable to require that even arguments should be incorporated in the
petition.
7. The principal controversy in the case turns round the first contention urged by the respondents
before the learned Judge below and repeated before us by Mr. Kar. In order to appreciate what the
contention is and in what manner the learned Judge dealt with it, it is necessary to give a few details.
In doing so, I shall follow the example of the learned trial Judge and quote from what the parties
and the learned Judge actually said rather than give a paraphrase in my own words.
8. The respondents' contention regarding the alleged settlement was expressed in their statement
filed before the arbitrators in the following words:
"And for this breach as earlier informed we submitted our Difference Bill No.
2008/908 of 21-7- 52 for Rs. 7500 (Ex. 5) being the difference between the contract
rate and the rate prevailing on the due date. At first they were not willing to make any
payment but knowing fully well that we would go for arbitration they paid us cash Rs.
5000/- which as a result of their persuasion we accepted the said amount in full
settlement of our claim on them. Payment was made on 18-3-52 and a copy of our
receipt evidencing the said settlement is annexed hereto as reference."
9. The allegations made in the above passage were traversed by the appellants in the course of a
further statement filed by them in the following words :
"Regarding their allegations that we paid them a sum of Rs. 5000/- as cash we
submit that it was under very coercive conditions and it does not represent a normal
or a willing deal. It was a sort of blackmail. They wrongfully withheld the value of a P.Fateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

D. O. payable to us by "them on account of another contract, and demanded a sum of
Rs. 5000/- before they released the payment. We preferred to face lesser evil and
lesser risk, and that the letter and the receipts are theirs. They may issue anything,
write anything. They have not paid similar amount to their own buyers."
10. On the above statements and counter-statements the argument which appears to have been
advanced before the learned Judge was that, to start with, the respondents had alleged that there
had been a settlement and that in pursuance of a settlement a sum of Rs. 5,000/- had been paid to
them by the appellants. Dealing with that allegation, so it was argued, the appellants had admitted
that a sum of Rs. 5,000/- had, in fact, been paid by them, that they had also admitted that the
payment was made in pursuance of a purported deal and that they had only added that the deal had!
not been what they called "a willing deal", and that they had been coerced.
The position according to the respondents, therefore, was that a contract of settlement and payment
thereunder was admitted by the appellants, but they were pleading a special fact which would
invalidate the contract as a contract and relieve them of their liability or commitment under it. If so,
the argument was that the burden lay on the appellants to prove the special fact. They had not
adduced any evidence at all to prove it and, therefore, the settlement as alleged by the respondents
stood. The arbitrators, however, had nevertheless disbelieved the settlement, as was implied in their
award and in doing so, in the absence of any evidence that the settlement had been forced on the
appellants by coercion, the arbitrators had clearly misconducted the proceedings.
11. The whole question, therefore, turned upon the proper construction of the statement of the
appellants and a proper decision as to the party on whom the burden of proof lay. According to the
respondents they were entitled to take so much of the statement of the appellants as contained in
admission of the case made by them and then put the appellants to strict proof of the special case set
up. According to the appellants, the statement contained no admission at all and therefore the
burden of proving their case continued to lie on the respondents as the party who had set up the
case.
12. S.R. Das Gupta J., accepted the contention of the respondents and expressed himself in the
following words :
"It appears to me from the said statements that the case made by the petitioner
before the arbitrator viz., the sum of Rs. 5,000/- was paid in cash by the respondents
and the same was accepted by the petitioner in full settlement of his claim on the
contract has not been disputed.
But what has been said is that it was under a coercive condition that the said payment
was made. I should also mention that the fact that a receipt has been given by the
petitioner to the respondents has not been denied by the respondents in the said
statement of fact but all that has been said is that the petitioner may issue anything,
write anything.Fateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

In the premises, as aforesaid, I have come to the conclusion that if the matter is left
where they are and if no evidence is adduced by either party on the question of
settlement then the arbitrators have no choice but to come to the conclusion that the
contract in question between the parties was settled.
In other words, I hold that the decision of the arbitrators which is implied in their
award, viz., that the settlement in question was vitiated by coercive conditions as
mentioned by the respondents in its further statement of fact was not based on any
evidence. In other words, there was no evidence before the arbitrators on which they
could come to that conclusion and if that is so, then in my opinion, the arbitrators
have been guilty of misconduct."
13. It was contended by Mr. Sen that in construing the statement of the appellants and in holding
that if no evidence was adduced by either party on the question of the settlement, the arbitrators had
no choice but to come to the conclusion that the contract in question had been settled, the learnted
Judge was in error.
Mr. Sen contended that since the appellants had made a case of coercion, they had pleaded that they
had not been willing parties to the alleged settlement and that being so, they had denied that there
had been any legal settlement at all and, therefore, if no party adduced any evidence, it would be the
respondents who would fail -- they not having proved the settlement alleged by them. Mr. Kar, on
the other hand, contended that the view taken by the learned Judge was plainly right. The payment
was admitted and so was the fact that a form of a settlement, at least, had been gone through.
What had been pleaded further was a fact within the special knowledge of the appellants and
therefore the burden lay on them to prove that fact which they had not done.
14. Speaking for myself, I have great doubts as to whether in considering allegations of misconduct
regarding the carriage of the proceedings by a body of arbitrators, a Court would be justified in
going go far as the learned Judge did in this case.
It is quite true that the law is no longer at the point where it stood when the only ground on which
an award could be assailed for misconduct was that the arbitrators had misconducted themselves. A
further ground that the award will be liable to be set aside even when the arbitrators misconducted
the proceedings has now been added. It is, therefore, now open to the Courts to go a little beyond
the point at which their jurisdiction was halted under "the old decisions and look a little beyond the
face of the award in appropriate cases.
Still, however, I should think that when the pleadings of the parties before the arbitrators present a
problem of construction, it is not open to the Court to construe the pleadings for itself, then decide
on its own construction that a particular issue of fact arose out of them, then find that the burden of
proof in respect of that issue of fact lay on a particular party, then see whether the arbitrators could
he said to have placed the burden where in the Court's view it lay and if it found that the burden had
not been laid on the proper party or that the evidence required in the case had not even been calledFateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

for, conclude that the arbitrators had misconducted the proceedings and that the award made by
them cannot stand.
There may be cases where the perversity of the award appears on its very face or on the face of the
pleadings, as in the case instanced by Mr. Kar where the defendant admits the whole claim of the
plaintiff and yet the arbitrators dismiss the claim. Such cases must be exceptional. But where, as I
have said, the pleadings themselves require to be construed, it seems to me that if the Court
undertakes the construction and then decides in what manner the proceedings should have been
conducted, it takes upon itself a task which the parties by their agreement had entrusted to another
authority.
With great respect to S.R. Das Gupta J., I should hold that in taking it upon himself to construe the
pleadings and then deciding in what way the proceedings should have been conducted, he went a
little further than was warranted by the law.
15. I would not, however, base my decision in this case on the view I have expressed above. What I
have said was only in passing. In my view, assuming that a Court is entitled to construe the
pleadings and see whether the issues of fact or law arising out of them had been decided by the
arbitrators on proper materials the learned trial Judge was not right in the present case in his
construction of the pleadings and the view taken by him regarding the burden of proof.
16. I shall use a phrase which Mr. Kar repeatedly used and enquire whether the plea set up by the
appellants could be said to be a plea of confession and avoidance. Mr. Kar's argument, it will be
recalled, was that the appellants had confessed the contract, but they had sought to avoid it by
pleading coercion. The result, according to Mr. Kar was that his clients were entitled to take the
confession out of the pleading of the appellants and to reject the avoidance and to put the appellants
to strict proof of coercion by which they wanted to avoid the contract. In my view, that was precisely
what the respondents could not do.
17. I shall refer only to two old cases where the law was laid down with all the clarity and brevity of
Sir Barnes Peacock. Both the decisions are reported in Vol. IX of the Weekly Reporter. The first of
them is the case of -- 'Sooltan Ali v. Chand Bibee', 9 Suth WR 130 (A). The head-note of the case
which correctly summarises the decision is in the following words :
"A written statement is not a pleading in confession and avoidance whereby a
defendant is bound by the confession and compelled to prove the avoidance: if used
as evidence against a defendant, the whole statement must be taken together."
18. What the learned Chief Justice held in that case with the concurrence of Dwarkanath Mitter J.,
was what has subsequently been laid down in several decisions of the Judicial Committee notably
--'Motabhoy Mulla Essabhoy v. Mulji Haridas', AIR 1915 PC 2 (B). The principle is that while a Court
of law is entitled to accept a part of the evidence of a witness and to reject another part, a pleading
cannot be so dissected, but must be taken either as a whole or left alone altogether. In other words,
if a written statement contains an admission of certain facts which are favourable to the plaintiff butFateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

contains a denial of other facts favourable to him or an assertion of other facts which are
unfavourable, the plaintiff must, if he wants to avail himself of the admission, take not only the first
set of facts as truly stated, but also the second set of facts.
Applying that principle to the present case, the respondents, if they wanted to avail themselves of
the statement of the appellants were bound to take not only their admission that a sum of Rs.
5,000/-had been paid and that it had been paid in pursuance of a form of settlement, but also their
further statement that they had been compelled to submit! to the settlement by coercion.
In the case to which I have already referred, Sir Barnes Peacock illustrated the principle by a
hypothetical case.
"Suppose", the learned Chief Justice observed, "a man should be sued for goods sold
and delivered, and should state and swear to the statement that the goods were
bought and delivered to him in a shop by a person whom he did not know and that he
paid for them at the time."
If that statement were true, he could not honestly state that he had never bought the goods; and if
the statement that he had bought them, was to be taken against him without also taking his
statement that he paid for them at the time, the greater injustice might be done, for he would be
unable to compel the attendance of the man who sold the goods, inasmuch as he was unknown to
him; but if the plaintiff being unable to read one part of the statement as evidence against the
defendant without reading in his favour what he said as to payment, the plaintiff would have to cite
the man who sold the goods for the purpose of proving his case, and then if the witness should speak
the truth, the defendant would make out his defence by eliciting from the witness on
cross-examination the fact that the defendant had paid for the goods at the time."
19. It would thus appear that in the hypothetical case instanced by the learned Chief Justice, the
plaintiff would not be relieved of proving his case, although the defendant had admitted receipt of
the goods, since he had coupled that admission with the statement that he had paid for them
already. If the plaintiff wanted to utilise the statement of the defendant, he would have to take both
the admission of the receipt of the goods and the assertion of payment. If he was not prepared to
take both, he would have to prove his case, and not till he had made out a 'prima facie' case, would
the burden of proof shift.
20. It is interesting to note the observation made by the learned Chief Justice at the end of his
judgment. He said this :
"We have given this explanation of our view of the effect of a written statement,
inasmuch as we constantly see that there is a great misunderstanding as to the mode
in which it ought to be used, if intended to operate against the defendant as an
admission."Fateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

21. The other case to which I would refer is the Full Bench Decision in -- 'Poolin Beharee v. R.
Watson and Co.', 9 Suth WR 190 (C). The view expressed by Sir Barnes Peacock in the earlier case
was repeated by him in the course of the leading judgment delivered on behalf of the Full Bench. AH
the other learned Judges who were members of the Bench agreed with the Chief Justice and each
illustrated his meaning by instancing a hypothetical case of his own.
It is unnecessary for me to make a detailed reference to the observations made by the learned
Judges, but I might refer to the view expressed by Phear J., with regard to one contention advanced
before the Court which was identical with a contention urged before us by Mr. Kar. One of the
reasons for which, Mr. Kar said, the burden must be hold to lie on the appellants was that they were
pleading facts within "their special knowledge.
The same argument was advanced before the Full Bench. Dealing with it, Phear, J., said that there
could be no question of such a principle applying in cases of that kind, because actually no fact
within the special knowledge of the defendant was being pleaded. In any event, the learned Judge
added, the principle could not vary the principal rule of law which was that a party, setting up a case
must in the first instance give evidence in its support.
It is again interesting to note the remark of Phear J., that he was making those observations about
the argument of facts lying within the special knowledge of the defendant, because that was not the
first time that he had heard that particular principle attempted to be used by learned Counsel and
therefore he thought it was necessary to put a stop altogether to its erroneous application.
22. In view of the principles which I have endeavoured to explain above, it can by no means be said
that after the parties had pleaded in the manner I have already set out, the burden lay even from the
beginning on the appellants to prove their plea of coercion. They had not admitted the payment or
the alleged settlement without a qualification and the qualification was such as, if established, would
render the settlement no settlement at all.
In those circumstances, the burden lay on the respondents to lead evidence in support of their case,
unless they were prepared to take the admission of the appellants as a whole. The learned Judge,
therefore, was not right in holding that if no evidence was adduced by either party, the arbitrators
had no choice but to come to the conclusion that the contract in question had been settled..
The position was quite the contrary. If no evidence was adduced by either party, the respondents
would have no choice but to lead evidence in support of their case of a settlement and if they led no
such evidence, the arbitrators would have no choice but to hold that the alleged settlement had not
been proved. I am accordingly of opinion that the learned Judge, with great respect to him, set aside
the" award on an erroneous ground.
23. Mr. Kar next attempted to support the decision of the learned Judge on a ground which had
been decided against him. He said that in any event, the award could not stand, inasmuch as the
arbitrators had not followed the law but bad given the appellants the precise amount, which they
had claimed as the difference between the contract price and the auction price. Mr. Kar's point wasFateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

that, under Section 73 of the Contract Act, what the appellants were entitled to was only the
difference between the contract price and the market price and not the difference between the
contract price and the auction price. To that contention there are, in my view, two answers, one of
which was given by the learned Judge.
It is quite true that the amount of the award is exactly the same as had been claimed by the
appellants as the difference between the contract price and the auction price; but as the learned
Judge has pointed out, there is no evidence in the case at all as to what the market price on the due
data was and therefore no evidence to show that it was not the same as the auction price. In the
second place, the principle that for a breach of contract a party is entitled by way of damages to the
difference between the contract price and the market price, is not an absolute and inviolable
principle.
As has been said in the text books, it is only a presumptive test and therefore from the mere fact that
the amount of the damages awarded is not the amount of the difference between the contract price
and the market price, it does not necessarily follow that the arbitrators have not applied the law of
the land and have misguided themselves and been guilty of misconduct. I do not, therefore, think
that Mr. Kar can support the order of the learned Judge on the ground which the learned Judge
himself rejected.
24. It was lastly contended by Mr. Kar that the present appeal was incompetent or, at any rate,
bound to prove ineffective, inasmuch as no appeal had been preferred from the order rejecting the
appellants' application for a judgment on the award. In my view, there is no substance in that
contention. This is not a case where an award has been upheld and a judgment has been passed on
the award and a party has appealed against the order refusing to set aside the award, but has not
appealed against the decree.
It has generally been held in this Court that unless an appeal is preferred from the decree as well, an
appeal against the order refusing to set aside the award cannot be maintained to any purpose. That
position may have to be re-examined when a proper occasion arises, but even that is not the position
in the present case. Here the learned Judge never reached the stage of passing a judgment on the
award.
It will appear from Section 14(2) of the Act that when the arbitrators have made their award, they
must give to the parties a notice in writing and then cause the award to be filed in Court. When the
award has been filed in Court, a notice is given to the parties and the parties are free at that stage to
apply for the setting aside of the award or for its adjudgment as a nullity, if they are so advised. If no
such application is made and if the Court finds no reason either to set aside or to remit the award, it
becomes the duty of the Court to pass a judgment on the award and a decree in accordance
therewith.
If no application is made before the Court impugning the award it would appear that the Court
would be bound to pass a judgment on the award of its own motion and as a part of its own duty. As
I have said, the stage of passing a judgment upon the award never arrived in the present case. AfterFateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

the award had been filed, an application was made to the learned Judge for setting it aside and he
set it aside, dismissing the application for a judgment on the award by the same order.
The present appeal is against the order which contains both the directions of the learned Judge and
in those circumstances, I am unable to see that any other appeal was required or that any other
appeal would be maintainable under Section 39 or the Act. The last objection of Mr. Kar must also
fail.
25. For the reasons given above, this appeal is allowed. The order passed by S.R. Das Gupta J.
setting aside the award and purporting to dismiss an application for a judgment on award, is set
aside. The matter of a judgment on award will now be dealt with on the merits and we direct that the
same be now placed on the appropriate list.
26. The appellants will have their costs from the respondents both in this Court and in the Court
below. Certified for two Counsel, so far as this Court is concerned.
Lahiri J.
27. I agree.Fateh Chand Murlidhar vs Juggilal Kamlapat on 16 July, 1954

