Andhra Pradesh Electricity Regulatory Commission (Conduct of
Business) Regulations, 1999
ANDHRA PRADESH
India
Andhra Pradesh Electricity Regulatory Commission
(Conduct of Business) Regulations, 1999
Rule
ANDHRA-PRADESH-ELECTRICITY-REGULATORY-COMMISSION-CONDUCT-OF-BUSINESS-REGULATIONS-1999
of 1999
Published on 1 January 1999• 
Commenced on 1 January 1999• 
[This is the version of this document from 1 January 1999.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999Last
Updated 22nd October, 2019In exercise of the powers conferred by Section 9, sub-section 2 and
Section 54, sub-section (2) (a) of the Andhra Pradesh Electricity Reform Act, 1998 (Act No. 30 of
1998) the Andhra Pradesh Electricity Regulatory Commission makes the following Regulations for
conduct of its proceedings and discharge of its functions, viz., Business Rules of the Commission.
Chapter 1
General
1. Short title, commencement and interpretation.
(1)These Regulations maybe called the Andhra Pradesh Electricity Regulatory Commission (Conduct
of Business) Regulations, 1999.(2)They shall come into force on the date of their publication in the
Official Gazette.(3)They extend to the whole of the State of Andhra Pradesh.(4)The Andhra Pradesh
General Clauses Act shall apply to the interpretation of these Regulations.
2. Definitions.
(1)In these Regulations, unless the context otherwise requires :(a)"Act" means the Andhra Pradesh
Electricity Reform Act, 1998:(b)"Chairman" means the Chairman of the Andhra Pradesh Electricity
Regulatory Commission;(c)"Commission" means the Andhra Pradesh Electricity RegulatoryAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

Commission:(d)"Member" means a member of the Andhra Pradesh Electricity Regulatory
Commission;(e)"Officer" means an Officer of the Commission;(f)"Petition" shall means and include
petitions, applications, complaints, appeals, replies, rejoinder and supplemental
pleadings:(g)"Proceedings" shall include proceedings of all nature that the Commission may hold in
the discharge of its functions under the Act:(h)"Secretary" means the Secretary of the Andhra
Pradesh Electricity Regulatory Commission.(2)Words or expressions occurring in these Regulations
and not defined herein above shall bear the same meaning as in the Act.
3. Commission's offices, office hours and sittings.
(1)The place of the offices of the Commission may from time to time be specified by the
Commission, by an order made in that behalf.(2)Unless otherwise directed, the headquarters and
other offices of the Commission shall be open daily except on Second Saturday of each month,
Sundays and holidays notified by the Government of Andhra Pradesh. The headquarters and other
offices of the Commission shall be open at such times as the Commission may direct.(3)Where the
last day for doing of any act falls on a day on which the office of the Commission is closed and by
reason there of, the act cannot be done on that day, it may be done on the next day on which the
office is open.(4)The Commission may hold sittings for hearing matters at the headquarters or at
any other place on days and time to be specified by the Commission.
4. Language of the Commission.
(1)The proceedings of the Commission shall be conducted in English.(2)No petition, documents or
other matters contained in any language other than English shall be accepted by the Commission
unless the same is accompanied by a translation thereof in English.(3)Any translation which is
agreed to by the parties to the proceedings or which any of the parties may furnish with an
authenticity certificate of the person, who had translated to English, may be accepted by the
Commission in appropriate cases as a true translation.
5. Seal of the Commission.
(1)There shall be a separate seal indicating that it is the seal of the Commission.(2)Every order or
communication made, notice issued or certified copy granted by the Commission shall be stamped
with the seal of the Commission and shall be certified by an Officer designated for the purpose.
6. Officers of the Commission.
(1)The Secretary shall have the custody of the seal and records of the Commission and shall exercise
such functions as are assigned to him by these Regulations or otherwise by the Commission or the
Chairman.(2)The Secretary may, with the approval of the Commission, delegate to any other Officer
of the Commission any functions required by these Regulations or otherwise, to be exercised by the
Secretary.(3)In the absence of the Secretary, such other Officer of the Commission, as may be
nominated by the Chairman, may exercise all the functions of the Secretary.(4)The CommissionAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

shall always have the authority, either on an application made by any interested or affected party or
suo motu to review, revoke, revise, modify, amend, alter or otherwise change any order made or
action taken by the Secretary or other Officers of the Commission, if the Commission considers it to
be appropriate.(5)[ The Commission may delegate to its Officers such functions including functions
to be exercised by the Secretary on terms and conditions the Commission may specify for the
purpose.] [Inserted by Regulation No. 8, dated 28.8.2000.]
Chapter II
General Rules concerning the proceedings before the
Commission
7. Proceedings before the Commission.
- [(1) The Commission may from time to time hold such proceedings as it may consider appropriate
in the discharge of its functions under the Act. The Commission may appoint an Officer or any other
person whom the Commission considers appropriate to participate and assist the Commission in
such proceedings.] [Substituted by Regulation No. 8, dated 28.8.2000.](2)(i)All matters which the
Commission is required under the Act to undertake and discharge through hearings shall be done
through hearing in the manner specified under the Act and in these Regulations.(ii)Except where
the Commission may provide otherwise for reasons to be recorded in writing, all matters affecting
the rights or interests of the licensee or any other person or class of persons shall be undertaken and
discharged through hearing in the manner specified in these Regulations.(iii)The Commission may
hold hearings in matters other than those specified in sub-regulations (i) and (ii) of Regulation 7(2)
if the Commission considers it appropriate to do so.
8. Initiation of Proceedings.
(1)The Commission may initiate any proceeding suo motu or on a petition filed by any affected
person.(2)When the Commission initiates the proceedings it shall be by a notice issued by the Office
of the Commission and the Commission may give such orders and directions as may be deemed
necessary, for service of notices to the affected or interested parties, for the filing of replies and
rejoinders in opposition or in support of the petition in such form as the Commission may direct.
The Commission may, if it considers appropriate, issue orders for advertisement of the petition
inviting comments on the issue involved in the proceedings in such form as the Commission may
direct.(3)While issuing the notice of inquiry the Commission may, in suo motu proceedings and
other appropriate cases, designate an Officer of the Commission or any other person whom the
Commission considers appropriate to present the matter in the capacity of a petitioner in the case.
9. Petitions and pleadings before the Commission.
(1)All petitions to be filed before the Commission shall be type written, cyclostyled or printed neatly
and legibly on white paper and every page shall be consecutively numbered. The contents of theAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

petition should be divided appropriately into separate paragraphs which shall be numbered serially.
The petition shall be accompanied by such documents as the Commission may specify.(2)[ All
pleadings shall contain a clear and concise statement of the facts with material particulars, the
reliefs sought and the basis for such reliefs.] [Added by Regulation No. 8, dated 28.8.2000.]
10. General headings.
- The general heading in all petitions before the Commission and in all advertisements and notices
shall be in Form 1 (Annexure I).
11. Affidavit in support.
(1)Petitions filed shall be verified by an affidavit, if so directed by the Commission and every such
affidavit shall be in Form 2 (Annexure-II).(2)Every affidavit shall be drawn up in the first person
and shall state the full name, age, occupation and address of the deponent and the capacity in which
he is signing and shall be signed and sworn before a person lawfully authorised to take and receive
affidavits.(3)Every affidavit shall clearly and separately indicate the statements which are true to
the-(i)knowledge of the deponent:(ii)information received by the deponent: and(iii)belief of the
deponent.(4)Where any statement in affidavit is stated to be signature to the information received
by the deponent, the affidavit shall also disclose the source of the information and a statement that
the deponent believes that information to be true.
12. Presentation and scrutiny of the pleadings, etc.
(1)All petitions shall be filed in such number of copies as the Commission may specify and all such
copies shall be complete in all respects.(2)All petitions shall be presented in person or by any duly
authorised agent to an officer designated for the purpose by the Commission (hereinafter called the
Receiving Officer) at the headquarters or such other filing center or centers as may be notified by the
Commission from time to time and during the time notified. The petitions may also be sent by
Registered Post with Acknowledgement Due to the Commission at the places mentioned above. The
vakalatnama in favour of the Advocate and, in the event the petitions are presented by the
authorized agent or representative, the document authorizing the agent or representative shall be
filed along with the petition, if not already filed on the record of the case.(3)The presentation and
the receipt of the petition shall be duly entered in the register maintained for the purpose by the
office of the Commission.(4)Upon the receipt of the petition, the Receiving Officer shall
acknowledge the receipt by stamping and endorsing the date on which the petition has been
presented and shall issue an acknowledgement with stamp and date to the person filing the petition.
In case the petition is received by registered post the date on which the petition is actually received
at the office of Commission shall be taken as date of the presentation of the petition.(5)the Receiving
Officer may decline to accept any petition which is not in conformity with the provisions of the Act
or the Regulations or directions given by the Commission or otherwise defective or which is
presented otherwise than in accordance with the Regulations or directions of the
Commission:Provided however that no petition shall be refused for defect in the pleadings or in
their presentation, without giving an opportunity to the person filing the petition to rectify theAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

defect within the time which may be given for the purpose. The Receiving Officer shall advise in
writing the person filing the petition of the defects in the petition filed.(6)A part aggrieved by any
order of the Receiving Officer in regard to the presentation of the petition may request Me matter to
be placed before the Secretary of the Commission for appropriate orders.(7)The Chairman or any
Member as the Chairman may designate for the purpose shall be entitled to call for the petition
presented by the party and give such directions regarding the presentation and acceptance of the
petition as he considers appropriate.(8)If on scrutiny, the petition is not refused or any order of
refusal is rectified by the Secretary or by the Chairman or the Member of the Commission
designated for the purpose, the petition shall be duly registered and given a number in the manner
to be specified by the Commission.(9)As soon as the petition and all necessary documents are
lodged and the defects and objections, if any, are removed and the petition has been scrutinised and
numbered, the petition shall be put up before the Commission for admission.(10)The Commission
may admit the petition for hearing without requiring the attendance of the party filing the petition.
The Commission shall not, pass an order refusing admission without giving the party concerned an
opportunity of being heard. The Commission may if it considers appropriate, issue notice to such
person or persons as it may desire to hear the petition for admission.(11)If the Commission admits
the petition, it may give such orders and directions as may be deemed necessary, for service of
notices to the respondent and other affected or interested parties; for the filing of replies and
rejoinder in opposition or in support of the petition in such form as the Commission may direct.
13. Service of notices and processes issued by the Commission.
(1)Any notice or process to be issued by the Commission may be served by any one or more of the
following modes as may be directed by the Commission:-(i)service by the party itself;(ii)by hand
delivery through a messenger;(iii)by registered post with acknowledgement due; and(iv)by
publication in newspaper in cases where the Commission is satisfied that it is not reasonably
practicable to serve the notices, processes, etc., on any person in the manner mentioned
above.(2)Every notice or process required to be served on or delivered to any person may be sent to
the person or his agent empowered to accept service at the address furnished by him for service or at
the place where the person or his agent ordinarily resides or carries on business or personally works
for gain.(3)In the event any matter is pending before the Commission and the person to be served
has authorised an agent or representative to appear for or represent him or her in the matter, such
agent or representative shall be deemed to be duly empowered to takes service of the notices and
processes on behalf of the party concerned in all matters and the service on such agent or
representative shall be taken and due service on the person to be served.(4)Where a notice is served
by a party to the proceedings either in person or through registered post, an affidavit of service shall
be filed by the party the party with the Commission giving details of the date and manner of service
of notices and processes.(5)Where any petition is required to be advertised it shall be advertised
within such time as the Commission may direct and, unless otherwise directed by the Commission,
in one issue each of a daily newspaper in English language and in Telugu language having
circulation in the area specified by the Commission.(6)The Commission may also effect service or
give directions for effecting service in any other manner it considers appropriate. The Commission
shall be entitled to decide in each case the person(s) who shall bear the cost of such service and
publication.(7)In default of compliance with the requirements of the Regulations or directions of theAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

Commission as regards the service of notices, summons or processes or the advertisement and
publication thereof, the Commission may either dismiss the petition or give such other or further
directions, as it thinks fit.(8)No service or publication required to be done shall be deemed invalid
by reason of any defect in the name or description of a person provided that the Commission is
satisfied that such service is in other respects sufficient, and no proceeding shall be invalidated by
reason of any defect or irregularity in the service or publication unless the Commission, on an
objection taken, is of the opinion that substantial injustice has been caused by such defect or
irregularity or publication or there are otherwise sufficient reasons for doing so.
14. Filing of reply, opposition, objections, etc.
(1)Each person to whom the notice of inquiry or the petition is issued (hereinafter called the
respondent) who intends to oppose or support the petition shall file the reply and the documents
relied upon within such period and in such number of copies as may be fixed by the Commission. In
the reply filed, the respondent shall specifically admit, deny or explain the facts stated in the notice
of inquiry or the petition and may also state such additional facts as he considers necessary for a just
decision of the case. The reply shall be signed and verified and supported by affidavit in the same
manner as in the case of the petition. The respondent shall also indicate whether he wishes to
participate in the proceedings and be orally heard.(2)The respondent shall service a copy of the
reply along with the documents duly attested to be true copies on the petitioner or his authorised
representative and file proof of such service with the office of the Commission at the time of filing
the reply.(3)Where the respondent states additional facts as may be necessary for the just decision
of the case, the Commission may allow the petitioner to file a rejoinder to the reply filed by the
respondents. The procedure mentioned above for filing of the reply shall apply mutatis mutandis to
the filing of the rejoinder.(4)(i)Every person who intends to file objection or comments in regard to
a matter pending before the Commission, pursuant to the advertisement and publication issued for
the purpose (other than the persons to whom notices, processes, etc., have been issued calling for
reply) shall deliver to an Officer designated by the Commission for the purpose the statement of the
objection or comments with copies of the documents and evidence in support thereof within the
time fixed for the purpose.(ii)The Commission may permit such person or persons as it may
consider appropriate to participate in the proceedings before the Commission, if on the report
received from the Officer, the Commission considers that the participation of such person or
persons will facilitate the proceedings and the decision in the matter.(iii)Unless permitted by the
Commission, the person filing objections or comments shall not be entitled to participate in the
proceedings, However, the Commission shall be at liberty to take into account the objections and
comments filed after giving such opportunity to the parties in the proceedings as the Commission
considers appropriate to deal with the objections and comments.
15. Hearing of the matter.
(1)The Commission may determine the stage, the manner, the place, the date and the time of the
hearing of the matter as the Commission considers appropriate, consistent with such specific timing
requirements as are set forth in the Act or otherwise the need to expeditiously decide the
matter.(2)(i)The Commission may decide the matter on the pleadings of the parties or may call forAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

the parties to produce evidence by way of affidavit or lead oral evidence in the matter.(ii)If the
Commission directs evidence of a party to be led by way of affidavit, the Commission may, as and
when the Commission considers it to be necessary, grant an opportunity to the other party to
cross-examine the deponent of the affidavit.(iii)The Commission may, if considered necessary or
expedient, direct that the evidence of any of the parties be recorded by an Officer or person
designated for the purpose by the Commission.(iv)The Commission may direct the parties to file
written note of arguments or submissions in the matter.
16. Power of the Commission to call for further information, evidence, etc.
(1)The Commission may, at any time before passing orders on the matter, require the parties or any
one or more of them or any other person whom the Commission considers appropriate, to produce
such documentary or other evidence as the Commission may consider necessary for the purpose of
enabling it to pass orders.(2)The Commission may direct the summoning of the witnesses, discovery
and production of any document or other material objects producible in evidence, requisitioning any
public record from any office, examination by an officer of the Commission the books, accounts or
other documents or information in the custody or control of any person which the Commission
considers relevant for the matter.(3)[ The Commission may, if it considers appropriate, allow any of
the parties or others specified in clauses (1) or (2) above, to adduce such further documentary or
other evidence in regard to evidence made available by any of the parties or other persons under the
said clauses.] [Added by Regulation No. 8, dated 28.8.2000.]
17. Reference of issues to others.
(1)At any stage of the proceedings, the Commission shall be entitled to refer such issue or issues in
the matter as it considers appropriate to persons including, but not limited to, the Officers and
consultants of the Commission whom the Commission considers as qualified to give expert or
specialised advice or opinion.(2)The Commission may nominate from time to time any person
including, but not limited to, the Officers and consultants to visit any place or places for inspection
and report on the existence or status of the place or any facilities therein.(3)The Commission, if it
thinks fit, may direct the parties to appear before the persons designated in clause (1) or (2) above to
present their respective views on the issues or matters referred to.(4)The report or the opinion
received from such person shall form a part of the record of the case and parties shall be given the
copies of the report or opinion given by the person designated by the Commission. The parties shall
be entitled to file their version either in support or in opposition to the report or the opinion.(5)The
Commission shall duly take into account the report or the opinion * given by the person and the
reply filed by the parties while deciding the matter and if considered necessary, examine the person
giving the report or the opinion:Provided however that the Commission shall not be bound by the
report or the opinion given.
18. Procedure to be followed where any party does not appear.
(1)When, on the date fixed for hearing or any other date to which such hearing may be adjourned, if
any party or his authorized agent or representative does not appear when the matter is called forAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

hearing, the Commission may, in its discretion, either dismiss the petition for default when the
petitioner or the person who moves the Commission for hearing is absent or proceed ex-parte to
hear and decide the petition.(2)Where a petition is dismissed in default or decided ex-parte, the
person aggrieved may file an application within 30 days from the date of such dismissal or being
proceeded ex-parte, as the case maybe, for recall of the order passed, and the Commission may
recall the order on such terms as it thinks fit, if the Commission is satisfied that there was sufficient
cause for the non-appearance when the petition was called for hearing.
19. Orders of the Commission.
(1)The Commission shall pass orders on the petition and the Chairman and the Members of the
Commission, who heard the matter will sign the orders.(2)The reasons given by the Commission in
support of the orders, including those by the dissenting member, if any, shall from a part of the
order and shall be available for inspection and supply of copies in accordance with these
Regulations.(3)[Copies of] [Added by Regulation No. 8, dated 28.8.2000.] All orders and decisions
issued or communicated by the Commission shall be certified by the signature of the Secretary or an
Officer empowered in this behalf by the Chairman and bear the official seal of the
Commission.(4)[Copies of] [Added by Regulation No. 8, dated 28.8.2000.] All final orders of the
Commission shall be communicated to the parties in the proceeding under the signature of the
Secretary or an Officer empowered in this behalf by the Chairman or the Secretary.
20. Inspection of records and supply of certified copies.
(1)Records of every proceeding shall be open, as of right, to the inspection of the parties or their
authorized representatives at any time either during the proceeding or after the orders are passed,
subject to payment of fees and- compliance with such other terms as the Commission may
direct.(2)Records of every proceeding, except those parts which for reasons specified by the
Commission are confidential or privileged, shall be open to inspection by any person other than the
parties to the petition either during the proceeding or after the orders have been passed, subject to
such person complying with such terms as the Commission may direct from time to time including
in regard to time, place and manner of inspection and payment of fees.(3)Any person shall be
entitled to obtain certified copies of the orders, decisions, directions and reasons in support thereof
given by the Commission as well as the pleadings and papers and other parts of the records of the
Commission to which he is entitled, subject to payment of fees and compliance with such other
terms as the Commission may direct.
Chapter III
Arbitration of Disputes
21. Arbitration.
(1)The arbitration of disputes arising between the licensees under the Act may be commenced by the
Commission on the application of any of the licensees concerned.(2)The Commission shall issueAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

notice to-the concerned licensees to show cause as to why the disputes between the licensees should
not be adjudicated and settled through arbitration.(3)The Commission may, after hearing the
licensees to whom notices have been issued and if satisfied that no reason or cause has been shown
against the proposed arbitration, pass an order directing that the disputes or the matter be referred
for adjudication and settlement through arbitration either by the Commission or by a person or
persons to be nominated by the Commission.
22. Nomination of Arbitrators.
(1)If the Commission decides to refer the matter to arbitration by a person or persons other than the
Commission, the reference shall be:(i)to a sole arbitrator if the parties to the dispute agree on the
name of the arbitrator: or(ii)if the parties are unable to agree on the name of the arbitrator, to a sole
arbitrator to be designated by the Commission or to three persons as the Commission may direct
taking into account the nature of the dispute and the value Involved and, if the decision is to refer to
three arbitrators, one to be nominated by each of the parties to the dispute and the third by the
Commission:Provided that if any of the parties fails to nominate the arbitrator or if any of the
arbitrator nominated by the parties or the Commission, fails or neglects to act or continue as
arbitrator, the Commission shall be entitled to nominate any other person in his place.(2)The
Commission shall not nominate a person as arbitrator to whom any of the licensees in the
arbitration has a reasonable objection on grounds of possible bias or similar such reasons and the
Commission considers the objection to be valid and justified.
23. Procedure for adjudication, settlement and passing of award.
(1)In case the Commission acts as the arbitrator, the procedure for adjudication and settlement to be
followed shall be as far as possible the same as in the case of hearing before the Commission
provided for in Chapter II above.(2)In case the Commission nominates an arbitrator or arbitrators
to adjudicate and settle the dispute, such arbitrator or arbitrators may follow such procedure as they
may consider appropriate, but consistent with the principles of natural justice and fair opportunity
to be given to the parties to arbitration and also of specific directions if any, issued by the
Commission.(3)The arbitrator after hearing the parties shall pass a speaking award giving reasons
for the decision on all issues arising for adjudication and forward the award [with relevant
documents] [Inserted by Regulation No. 8, dated 28.8.2000.] to the Commission within such time
as the Commission may specify.(4)The Commission shall give notice of the award given by
arbitrator or arbitrators appointed by the Commission to the parties concerned and shall give a n
opportunity to the parties to file objections to the award and reply to the objections within such time
as the Commission may direct.(5)The Commission shall proceed to hear the parties on the award.
The procedure to be followed by the Commission shall be as far as possible the same as in the case of
hearing before the Commission provided for in Chapter II of these Regulations above, provided that
the hearing shall be confined to the objections raised to the award given by the arbitrator.(6)The
Commission shall be entitled to pass appropriate orders, as it thinks fit after giving an opportunity
of hearing to the parties.Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

24. Cost of arbitration and proceedings.
- The cost of the arbitration and proceedings before the Commission shall be borne by such parties
and in such sums as the Commission may direct.
Chapter IV
Licence
25. Application for licence.
(1)The Commission may, if considered appropriate, advertise in newspapers or otherwise notify in
such other appropriate manner as the Commission may decide, inviting applications for grant of
licence.(2)The applications for Transmission Licence and Supply Licence shall made in accordance
with the provision of the Act and these regulations.(3)Every application for a licence shall be signed
by on behalf of the applicant and addressed to such Officer as the Commission may designate in this
behalf and it shall be accompanied by:(i)such number of copies as the Commission may direct, in
print, of the draft licence as proposed by the applicant with the name and address of the applicant
and of his agent (if any) printed on the outside of the draft.(ii)such number of copies as the
Commission may direct, each signed by the applicant, of maps of proposed area of transmission or
supply and, in the case of supply of the streets or roads in which the supply of energy is to be made,
which shall be so marked or coloured as to define any portion of such area and streets or roads
which are under the administrative control of any local authority and shall be on such scale as may
be approved by the Commission.(iii)a list of any local authorities invested with the administration of
any portion of the area of supply:(iv)an approximate statement describing any lands which the
applicant proposes to acquire for the purpose of the licence and the means of such acquisition:(v)an
approximate statement of the capital proposed to be expended in connection with the utility and
such other particulars as the Commission may require;(vi)a copy of Memorandum and Articles of
Association, Annual Accounts for the last three years or other similar documents as maybe
required;(vii)a receipt for such processing fee, as the Commission may require.
26. Copies of maps and draft licence for public inspection.
- The applicant shall deposit at his own office and of his agents (if any) and at the office of every
local authority invested with the administration of any portion of the proposed area of
supply;(1)copies of the maps referred to in clause (3) (ii) of Regulation 25 for public inspection,
and(2)a sufficient number of copies of the draft licence to be furnished to all persons applying for
them at a price not exceeding normal photocopying charges per copy.
27. Contents of draft licence.
- The draft licence shall contain the following particulars:(1)A short title descriptive of the proposed
utility together with the address and description of the applicant, and if the applicant is a company,Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

the names of all the Directors of the company;(2)Type of licence applied for;(3)Location of the
proposed service area;(4)A description of the proposed area; and(5)Such other particulars as the
Commission may specify.
28. Form of draft licence.
- The Commission may, from time to time, prescribe the format of draft licence to be issued and the
applicant for licence shall prepare the draft licence in such format with such variation as the
circumstances of each case may require.
29. acknowledgement of application.
- On receipt of the application, the receiving Officer shall note thereon the date of its receipt and
shall send to the applicant an acknowledgement stating the date of receipt.
30. Calling for additional information.
- The Commission or the Secretary or any Officer designated for the purpose by the Commission
may upon scrutiny of the application, require the applicant to furnish within a period to be specified,
such additional information or particulars or documents as considered necessary for the purpose of
dealing with the application.
31. Notifying the due filing of the application.
- If the Commission finds the application to be complete and accompanied by the requisite
information, particulars and documents and applicant has complied with all the requirements for
making the application and furnishing of information, particulars and documents, the Commission
or the Secretary or the Officer designated for the purpose shall certify that the application is ready
for being considered for grant of licence in accordance with the procedure provided in the Act.
32. Advertisement of application and contents thereof.
(1)(i)The applicant shall, within fourteen days from the date of the application publish notice of his
application by public advertisement, and such advertisement shall publish such particulars as the
Commission may specify.(ii)The advertisement shall be headed by a short title corresponding to that
given at the head of the draft licence and shall give the addresses of the offices at which copies of
maps therein referred to may be inspected and the copies of draft licence perused or purchased and
shall state that every local authority, utility or person, desirous of making any representation with
reference to application to the Commission, may do so by letter addressed to such Officer as the
Commission may designate in this behalf, within three months of the date of issue of the first
advertisement.(2)The Commission may direct that notice of the application be served on the Central
Government, the State Government, the local authority or any other authority or person or body as
the Commission may direct in such other manner as the Commission may consider appropriate.Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

33. Amendment of draft licence.
- Any person who desires to have any amendment made in the draft licence shall deliver a statement
of the amendment to the applicant and to such Officer as the Commission may designate in this
behalf within the time allowed under Section 15(2)(b)(i) of the Act for the submission of
representations referring to the application.
34. Objections.
(1)Any person intending to object to the grant of the licence shall file objection within the time and
in the manner provided for in the Act, in these Regulations and as the Commission may direct. The
objection shall be filed in the form of reply and the provisions of Chapter II dealing with reply shall
apply to the filing of such objections.(2)The applicant shall apply for and obtain the no objection
certificate required from the Central Government in terms of Section 15(2) (b) (ii) of the Act before
the application can be placed for hearing by the Commission for grant of the licence.
35. Hearings and local inquires.
(1)If the applicant has duly arranged for the publication of the notice of the intended application and
the time for filing of the objection is over and after the applicant has furnished to the Commission
the no objection certificate, if any, required from the Central Government, the Commission may
proceed to set the application for regular hearing.(2)The Commission shall give the notice of in
quiry or hearing to the applicant, the persons who had filed objections, the Central Government, the
State Government and such other authority, person or body as the Commission considers
appropriate.(3)(i)If any person objects to the grant of a licence applied for under the Act the
Commission may if either the applicant or the objector so desires, cause a local in quiry to be held of
which the notice in writing shall be given to both the applicant and the objector:(ii)In case of such
local inquiry a memorandum of the results of the local in quiry made shall be prepared and shall be
signed by the applicant, the Officer or person designated for the purpose and such other person as
the Commission may direct.(4)The hearing on the application for grant of licence shall thereafter
proceed as far as possible in the same manner as provided in Chapter II.
36. Approval of draft licence.
(1)After inquiry if any, and the hearing, the Commission may decide to grant or refuse the licence
and if it decides to grant the licence it may do so by approving the draft licence with such
modification, changes or additions and subject to such other terms and conditions as the
Commission may direct.(2)When the Commission has approved a draft licence, either in its original
form or in a modified form, such Officer as the Commission may designate in this behalf, shall
inform the applicant of such approval and of the form in which it is proposed to grant the licence
and the conditions to be satisfied by the applicant including the fees to be paid for the grant of the
licence.Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

37. Notification of grant of licence.
- On receiving an intimation in writing from the applicant that he is willing to accept a licence in the
form approved by the Commission and after the applicant satisfies the condition specified for the
grant of the licence, the Commission shall publish the licence or such part or gist thereof as the
Commission considers appropriate.
38. Date of commencement of licence.
- The licence shall commence from the date the Commission may specify as the date of
commencement offence.
39. Deposit of maps.
- When a licence has been granted, three sets o! maps showing, as regards such licence, the
particulars specified in Regulation 25 shall be signed and dated to correspond with the date of the
notification of the grant of the licence by such Officer as the Commission may designate in this
behalf. One set of such maps shall be retained as the deposited maps by the said Officer and the
other two sets given to the licensee.
40. Deposit of Printed copies.
(1)Every person who is granted a licence shall within thirty days of the grant thereof:(i)have
adequate number of copies of the licence printed:(ii)have adequate number of maps prepared
showing the area of supply specified in the licence;(iii)arrange to exhibit a copy of such licence and
maps for public inspection at all reasonable times at his head office and at his local offices (if any)
within the area of supply.(2)Every such licensee shall, within the aforesaid period of thirty days,
supply free of charge one copy of the licence to every Municipal Corporation, Municipal Office and
Mandal Revenue Office within the area of supply and shall also make necessary arrangements for
the sale of printed copies of the licence to all persons applying for the same, at a price not exceeding
normal photocopying charges per copy.
41. Preparation and Submission of accounts.
(1)Every licensee shall cause the accounts of his utility to be made up to the thirty-first day of March
each year.(2)Such licensee shall prepare and render an annual statement of his accounts in
accordance with the provisions of the Act, within a period of six months from the aforesaid date, or
such extended period as the Commission may authorise after it is satisfied that the time allowed is
insufficient owing to any cause beyond the control of the licensee and the statement shall be
rendered in such numbers of copies as the Commission direct.(3)The accounts shall be made up in
such forms as the Commission may direct from time to time. All the forms shall be signed by the
licensee or his accredited and duly authorized agent or manager.(4)The commission may, by special
or general order direct that, in addition to the submission of the annual statements of accounts inAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

the forms prescribed in sub-rule (iii), a licensee shall submit to the Commission or such other
authority as it may designate in this behalf such additional information as it may require for the
purpose.
42. Model conditions of supply of power.
(1)(i)The Commission may check, from time to time, the model conditions of supply to be adopted
by the licensee, with such variations as the Commission may direct and the licensee shall furnish to
the Commission the finalised conditions of supply for approval.(ii)The licensee shall always keep in
his office an adequate number of printed copies of the sanctioned conditions of supply and shall, on
demand, sell such copies to any applicant at a price not exceeding normal photocopying
charges.(2)(i)The Commission may pass such orders as it thinks fit in accordance with Sections 28
to 31 of the Act for the contravention or the likely contravention of the licence tenns or conditions by
the licensee.(ii)Subject to the provisions of Sections 28 to 31 of the Act and the procedure prescribed
therein, the Commission may follow as far as possible the general procedure prescribed in Chapter
II of these Regulations in dealing with a proceeding arising out off a contravention or likely
contravention by a licensee.
43. [ Grant of exemption from licence. [Substituted by Regulation No. 8, dated
28.8.2000.]
(1)An exemption from licence under section 16 of the Act shall be granted consistent with the
provisions of the Act and in accordance with these regulations.(2)General Exemption: Until
otherwise specified in writing by the Commission, the following classes of persons engaged in the
supply of electricity in the State of Andhra Pradesh are exempted from the requirement to have
licence, subject to the fulfilment of the conditions specified herein:(i)Persons who supply electricity
generated by themselves and/or supplied to them by a licensed supplier, for the purposes of an
event or function not exceeding two months, and when the electricity is distributed through a
system owned by them.(ii)Persons who supply electricity to the residential colonies as a part of their
activity of maintaining such colonies for use and occupation of their employees and/or for use and
occupation of persons providing facilities and services to the employees, where such person
procures electricity from the licensee or from any other source approved by the Commission or
generates himself and distributes the electricity within the specified areas of residential colonies on
no-profit motive basis.(iii)Such other persons as the Commission may from time to time by order
notify, subject to such terms and conditions as the Commission may specify.Provided that the
general exemption granted under any of the clauses mentioned above shall not be taken as an
approval to set up a generating station, captive or otherwise or enabling generation of electricity,
and for this purpose the persons shall be required to comply with the provisions of the relevant Acts
and regulations dealing with generating stations.(3)It shall be a condition for eligibility of the
general exemption under clause (2) above that the person who avails such general exemption
accepts that:(i)if any difference or dispute arises as to whether the person is entitled to undertake
supply of electricity in terms of the general exemption or not, the decision thereon of the
Commission shall be final, subject however to the right of appeal under section 39 of the Act;
and(ii)the Commission shall be entitled to issue appropriate directions as it may consider necessaryAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

to ensure that the general exemption is properly availed and take appropriate actions against such
persons in accordance with the provisions of the Act and these regulations for any breach or non
compliance or otherwise for any unauthorised act in availing the general exemption by such
person.(4)All persons other than a supply licensee and those covered under general exemption
mentioned in clause (2) above, who intend to engage in the business of supplying electricity, shall
require specific order of exemption from the Commission and shall follow the procedure set out
hereunder.(i)A person seeking grant of exemption from the requirement to have a licence shall file
an application supported by an affidavit and shall furnish the particulars and documents set out in
Annexure - III.(ii)The applicant shall state in detail, the reasons for which the exemption is
considered necessary together with supporting documents including his capability in running the
business and eligibility for the exemption sought.(iii)The applicant shall file the consent required
from the local authority and the supply licensee as well as the Central Government (if required) in
terms of Section 16(1) of the Act before the application is placed for hearing.Provided that if the
applicant is of the view that the local authority or the supply licensee, as the case may be, is
unreasonably withholding the consent, the applicant shall file the relevant correspondence with
such local authority or the supply licensee with the reasons in support of the applicant's submission
that the consent is being withheld unreasonably.(iv)The applicant shall also furnish such other
particulars and documents as the Commission may require from time to time.(v)The application
shall be submitted in 5 (five) copies together with a processing fee of such amount as the
Commission may specify from time to time, in the form of a Bank Draft drawn in favour of APERC
payable on any scheduled bank at Hyderabad.(vi)Unless otherwise specified in writing by the
Commission, the procedure for grant of licence in so far as it can be applied shall be followed while
dealing with an application for exemption from requirement to have a licence.(5)The terms and
conditions of the grant of exemption by the Commission may include the following:(i)An exemption
granted shall be published by the applicant in such manner as the Commission considers
appropriate for bringing it to attention of the public.(ii)If so required by the Commission, the person
exempted shall be required to submit to the Commission within such time as the Commission may
specify, a complaint handling procedure for redressal of consumers' grievances and shall implement
the same with such modifications as the Commission may direct.(iii)The person exempted shall pay
to the Commission an annual fee of such amount as may be directed by the Commission from time
to time.(iv)The Commission, while granting the exemption, shall be entitled to impose any other
conditions as the Commission considers appropriate, including the terms for revocation or
modification of the exemption.(6)Unless the Commission otherwise directs by general or special
order, the persons exempted, whether by general exemption or by a specific exemption granted by
the Commission, shall:(i)furnish to the Commission such information required for the purposes of
the discharge of the functions of the Commission as the Commission may from time to time
direct;(ii)comply with the provisions of the Act including the applicable provisions of the Indian
Electricity Act, 1910, the Electricity (Supply) Act, 1948, the Indian Electricity Rules, 1956, the
Regulations of the Commission, technical codes such as Grid Code, Distribution Code, Standards of
performance and Overall Standards of Performance or any other guidelines issued by the
Commission ; and(iii)comply with any directions which the Commission may issue from time to
time in regard to the charges which such persons may levy on the consumers taking into account the
charges prevailing in the nearby area of supply of electricity supplied by a licensee;]Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

44. Revocation of the licence.
(1)The proceedings for revocation of the licence or for passing of any other orders specified in
Section 18 of the Act shall be initiated by an order passed by the Commission which the Commission
may initiate suo motu or on application of the licensee or on receiving any complaint or information
from any person.(2)The Commission may give notice of the proceedings for the revocation of the
licence to the licensee and to such other persons, authority or body as it may consider
necessary.(3)Subject to the provisions of Sections 28 to 31 of the Act and the procedure prescribed
therein, the inquiry by the Commission on the revocation of the licence, in so far it is applicable,
shall be in the same manner as provided in Chapter II of the Regulations :Provided that the licensee
shall be given not less than three months notice in writing to show cause against the proposed
revocation and the notice to show cause issued to the licensee shall clearly state the grounds on
which the Commission proposes to revoke the licence as provided in Section 18 of the Act.(4)If the
Commission decides to revoke the licence, the Commission shall serve the notice of revocation to the
licensee specifying the effective date from which such revocation shall take effect. The notice for
revocation of licence, shall be in such form as the Commission may direct. The Commission may, at
its discretion order refund in part, the annual licence fee in case of revocation of license.(5)The
Commission may instead of revoking the licence pass any other order imposing further terms and
conditions subject to which the licensee is permitted to operate thereafter.
45. Amendment of the licence granted.
(1)Application by the licensee or the local authority concerned for alteration or amendment to the
terms and conditions of the licence granted in terms of Section 19 of the Act shall be made in such
form as may be directed for the purpose by the Commission. The application shall be supported by
affidavit as provided in Chapter II of the Regulations.(2)Unless otherwise specified in writing by the
Commission each application for amendment or alteration in the licence shall be accompanied by a
receipt of such fee as the Commission may require, paid in the manner directed by the
Commission.(3)Unless otherwise specified in writing by the Commission, the procedure prescribed
in these Regulations for grant of licence, in so far it can be applied, shall be followed while dealing
with an application for amendment or alteration of the licence.[Chapter IV-A] [Inserted by
Regulation No. 8, dated 28.8.2000.] Tariffs
45A. Expected revenue from charges and tariff proposals.
(1)Subject to the provisions of the Act, each year, at the time required by the licence or otherwise as
may be directed by the Commission, each licensee (Transmission and Bulk Supply or Distribution
and Retail Supply, as the case may be) shall file with the Commission, in the format as may be
specified by the Commission, statements containing calculation for the ensuing financial year the
expected aggregate revenue from charges under its currently approved tariff and the expected cost
of providing services.(2)If a Licensee carries on more than one business, namely, Transmission and
Bulk Supply or Distribution and Retail Supply, the statement referred to in clause (1) above shall be
given separately for each of the separate businesses of the licensee and in such manner in respect of
each such business as the Commission may direct.(3)The statements referred to in clause (1) aboveAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

shall contain the following details:(i)the licensee's demand forecast by customer or consumer
category for the ensuing financial year and the basis of the forecast;(ii)a calculation of expected
aggregate revenue that would result from the above demand during the same period under the
currently approved tariff by customer or consumer category;(iii)a calculation of the licensee's
estimated costs of providing the service required by the level of demand indicated in sub-clause (i)
above for each customer or consumer category during the same period calculated in accordance with
the financial principles and their applications in the Sixth Schedule to the Electricity (Supply) Act,
1948 or such other principles the Commission may prescribe from time to time;(iv)The licensee's
proposal to deal with the divergence between the expected aggregate revenue and the expected cost
of services including proposal, if any, for revised tariff to be charged in the ensuing year, the
proposed scheme for reduction in losses, changes in the tariff structure for any specific category of
consumer;(v)In case the Licensee carries on any business or services other than those licensed
under the Act, the Licensee shall give separate revenue and expense statements together with such
details as the Commission may require in respect of such business or services; and(vi)Such other
information as the Commission may direct from time to time.(4)The licensee shall furnish to the
Commission such additional information, particulars and documents as the Commission may
require from time to time after such filing of revenue calculations and tariff proposals.(5)The
Commission may, from time to time, issue guidelines for filing statement of revenue calculations
and tariff proposals and unless waived by the Commission, the licensee shall follow such guidelines
issued by the Commission.(6)Unless otherwise directed by the Commission, the Commission shall
hold a proceeding on the revenue calculations and tariff proposals given by the licensee and may
hear such persons as the Commission may consider appropriate for making a decision on such
revenue calculations and tariff proposals.(7)The procedure of hearing on the revenue calculations
and tariff proposals of the licensee shall be in the manner as the Commission may decide from time
to time.(8)Upon hearing the licensee and such other parties as the Commission considers
appropriate and upon making such other inquiry, the Commission shall make an order and notify
the licensee of its decision on the revenue calculations and tariff proposals, as provided in
sub-section (5) of section 26 of the Act.(9)While making an order under clause (8) above or at any
time thereafter, the Commission may direct the publication of the tariff that the licensee shall charge
the different consumers or customers and categories thereof in the ensuing financial year.(10)The
licensee shall publish the tariff or tariffs approved by the Commission in the newspapers having
circulation in the area of supply as the Commission may direct from time to time. The publication
shall, besides such other things as the Commission may require, include a general description of the
tariff amendment and its effect on the classes of the consumers.(11)The tariffs so published under
clause (10) above shall become the notified tariffs applicable in the area of supply and shall take
effect only after such number of days as the Commission may direct which shall not be less than
seven days, from the date of first publication of the tariffs.(12)The licensee shall raise bills for the
energy supplied or transmitted or services rendered to the consumers in accordance with the
notified tariff.(13)No tariff determined and notified as above may be amended more frequently than
once in any financial year except that tariff rates shall be adjusted in accordance with any fuel
surcharge adjustment formula incorporated in the tariff with the approval of the
Commission.Provided that the consequential orders which the Commission may issue to give effect
to subsidy the State Government may provide under Sections 12 (3) and/or 27 (1) of the Act shall
not be construed as amendment of tariff notified. The Licensee shall, however, give appropriateAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

adjustments in the bills to be raised on the consumers for the subsidy amount in the manner the
Commission may direct.
45B. [ Fuel Surcharge Adjustment Formula. [Substituted by Regulation No. 3,
dated 9.7.2003.]
(1)Unless otherwise agreed by the commission, the fuel Surcharges adjustment (FSA) for the price
and mix variations in the quantity of energy to be purchased as per the tariff order during a quarter
'1' shall be determined as per the following formula aggregated for the quarter '1':-
F1=(P1x E1+ FC1+ Z + A1
-----------------------------------------------------
Q1
WhereP1 is the difference in the Weighted Average Variable Cost in Rupees adjusted to four decimal
points, of power purchase cost in quarter 1 for the power purchase quantity mentioned tn the
tariff order compared to the Weighted Average Variable Cost adopted in the tariff order.E1 is the
energy purchase as mentioned in the tariff order in K wh during the quarter to be submitted for each
of the generating stations.PC1 difference in Rupees, of the actual total fixed charges of the
generating stations from the base values adopted in the tariff order.Q1 is the actual energy sold to all
categories in K wh in the quarter in D1SCOM or RESCO, subject to condition No. 1, mentioned
hereunder.Z is the changes in the cost in Rupees as allowed by the Commission for a period
extending in the past beyond the relevant quarter.A1 adjustment in Rupees to account for the
financial impact of demonstrated Incidents of merit order violation on account of controllable
factors or any other events the financial impact of which, in the Commissions view, should be given
appropriate treatment.Condition:(1)The FSA as worked out will be distributed among all categories
of consumers that existed in the quarter. However the consumption by the agricultural sector will be
excluded till the Commission is satisfied that metering of agricultural consumption is complete, as
may be notified in the Tariff orders from time to time.(2)The licensee shall provide the Commission
with its calculation of each fuel surcharge adjustment required to be made pursuant to its tariff
before it is implemented with such documentation and other information as it may require, for
purpose of verifying the correctness of adjustments.(3)FSA billed to retail categories to be made
over to Bulk supplier by individual Distribution Companies and/or RESCOS as the case may
be.(4)APTRANSCO must file with the Commission all information (including sales data from the
DISCOMS/ RESCOS) required for calculation of the Fuel Surcharge Adjustment within 30 days of
the end of the respective quarter failing which it will forfeit any future claims on this account for
such quarter. DISCOMS/RESCOS should use actual consumption details of the relevant quarter
when levying FSA.(5)The licensee will report data for computing the total cost (split for fixed and
variable) for each of the generation stations that has supplied power in the respective quarter for
which fuel surcharge adjustment is being computed. The total amount eligible for recovery will be
computed on an aggregate basis.(6)Fuel cost data has to conform to the fuel costs to the allowed
level and no other charges other than the transportation cost can be included in the fuel cost. Every
statement has to be confirmed by the licensee to that effect. The costs arrived at will be compared to
the fuel cost indexation which will be developed by the Commission in the future.(7)Penalties areAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

leviable for furnishing wrong data.(8)The licensee shall publish the FSA approved by the
Commission in one English and one Telugu daily newspaper with circulation in the area of supply,
for general information of the consumers, and shall make available copies of the FSA order for the
relevant quarter to the public on request, at a reasonable cost.(9)The FSA shall be implemented
after 7 days of such publication.(10)The actual variable costs and Fixed costs computed for Central
Generating Stations (CGS) should exclude the effect of UI charges.(11)The FSA will include not only
fixed costs of two part tariff but also of single part tariff wherever applicable.]
45C. Subsidies.
(1)The State Government may, at any time as it considers appropriate, propose any subsidy to any
class or classes of consumers and upon receiving such proposal, the Commission shall determine the
amount to be paid as subsidy, the terms and conditions of such payment including the time and
manner of payment of subsidy amounts by the State Government.(2)While determining the tariff,
the Commission shall take into account any subsidies, which the State Government had agreed to
give to any class or classes of consumers. The tariff determined by the Commission shall be
published duly taking into account such subsidy offered by the State Government as on the date of
the decision of the Commission.(3)The licensee shall be required to furnish documents to the
satisfaction of the Commission that the subsidy amount received by the licensee from the State
Government is duly accounted for and utilised for the purpose for which the subsidy is given.
Chapter V
Investigation, Inquiry, Collection of Information, etc.
46. Collection of information.
(1)The Commission may make such order or orders as it thinks fit in terms of Section 10 of the Act
for collection of information, inquiry, investigation, entry, search, seizure and without prejudice to
the generality of its powers in regard to the following:(a)The Commission may, at any time, direct
the Secretary or any one or more Officers or consultants or any other person as the Commission
considers appropriate to study, investigate or furnish information with respect to any matter within
the purview of the Commission under the Act.(b)The Commission may for the above purpose give
such other directions as it may deem fit and specify the time within which the report is to be
submitted or information furnished.(c)The Commission may issue or authorise the Secretary or an
Officer to issue directions to any person to produce before it and allow to be examined and kept by
an Officer of the Commission specified in this behalf the books accounts, etc., or to furnish to an
Officer information, etc., as provided in sub-section (2) of Section 10 of the Act.(d)The Commission
may, for the purpose of collecting any Information particulars or documents which the Commission
consider necessary in connection with the discharge of its functions under the Act, issue such
directions and follow any one or more of the methods provided for in Section 10 of the Act.(e)If any
such report or information obtained as specified in Section 10 of the Act or in these Regulations
appears to the Commission to be insufficient or inadequate, the Commission or the Secretary or an
Officer authorised for the purpose may give directions for further inquiry, report and furnishing ofAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

information.(f)The Commission may direct such incidental, consequential and supplemental
matters which may be considered relevant in connection with the above, be attended to.(2)In
connection with the discharge of the functions under Section 10 of the Act and Regulation 51, the
Commission may, if it thinks fit, direct a notice of inquiry to be issued and proceed with the matter
in a manner provided under Chapter II of these Regulations.
47. Assistance of Experts.
(1)The Commission may, at any time, take the assistance of any institution, consultants, experts,
engineers, chartered accountants, advocates, surveyors and such other technical and professional
persons, as it may consider necessary, and ask them to study, investigate, inquire into any matter or
issue and submit report or reports or furnish any information. The Commission may determine the
terms and conditions for engagement of such professionals.(2)If the report or information obtained
in terms of the above Regulations or any part thereof is proposed to be relied upon by the
Commission in forming its opinion or view in any proceedings, the parties in the proceedings shall
be given a reasonable opportunity for filing objections and making submissions on the report or
information.
Chapter VI
Appeal Under Section 38
48. Hearing of Appeal.
- The Commission shall hear the appeal from the decision of the Electrical Inspector in the same
manner as applicable in the case of hearing before the Commission provided for in the Chapter II
above and if the Commission considers that the appeal has no merit, the Commission shall be
entitled to dismiss the appeal at the preliminary admission stage as provided in Regulation 12(10)
after giving an opportunity to the appellant concerned.
Chapter VII
Miscellaneous
49. Review of the decisions, directions and orders.
(1)The Commission may on its own motion, or on the application of any of the person or parties
concerned, within 90 days of the making of any decision, direction or order, review such decision,
directions or orders and pass such appropriate orders as the Commission thinks fit.(2)An
application for such review shall be filed in the same manner as a petition under Chapter II of these
Regulations.(3)[ In case any person wishes to bring on record the successors-in-interest, etc., the
application for the purpose shall be filed within 90 days from the event requiring the
successors-in-interest to come on record.Provided that the Commission may, if it is satisfied that
there is sufficient cause for not filing the application within the time prescribed, condone the delayAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

subject to such terms and conditions, as the Commission may consider appropriate.] [Inserted by
Regulation No. 8, dated 28.8.2000.]
50. Continuance of proceedings after death, etc.
(1)Where in any proceedings any of the parties to the proceedings dies or is adjudicated as an
insolvent or in the case of a Company under liquidation winding up, the proceedings shall continue
with the successors-in-interest, the executor, administrator, receiver, liquidator or other legal
representative of the party concerned.(2)The Commission may, for reasons to be recorded, treat the
proceedings as abated in case the Commission so directs and dispense with the need to bring the
successors-in-interest to come on record.
51. Proceedings to be open to public.
- The proceedings before the Commission shall be open to the public. However, admission to the
hearing room shall be subject to availability of sitting accommodation, provided that the
Commission may, if it thinks fit, and for reasons to be recorded in writing, order at any stage of the
proceedings of any particular case that the public generally or any particular person or group of
persons shall not have access to or be remain in, the room or building used by the Commission.
52. Publication of petition.
(1)Where any application, petition, or other matter is required to be published under the Act or
these Regulations or as per the directions of the Commission, it shall, unless the Commission
otherwise orders or the Act or Regulations otherwise provide be advertised not less than 5 days
before the date fixed for hearing.(2)Except as otherwise provided, such advertisements shall give a
heading describing the subject matter in brief.(3)Such advertisement to be published shall be
approved by the Officer of the Commission designated for the purpose.
53. Confidentiality.
(1)Records of the Commission, except those parts which for reasons specified by the Commission
are confidential or privileged, shall be open to inspection by all, subject to the payment of fees and
compliance with such other terms as the Commission may direct.(2)The Commission may, on such
terms and conditions as the Commission considers appropriate, provide for the supply of the
certified copies of the documents and papers available with the Commission to any person.(3)The
Commission may, by order, direct that any information, documents and other papers and materials
produced before the Commission or any of its Officers, consultants, representatives or otherwise
which may come into their possession or custody, shall be confidential or privileged and shall not be
available for inspection or supply of copies, and the Commission may also direct that such
document, papers or materials shall not be used in any manner except as specifically authorized by
the Commission.Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

54. Issue of orders and practice directions.
- Subject to the provisions of the Act and these Regulations, the Commission may, from time to
time, issue orders and practice directions in regard to the implementation of the Regulations and
procedure to be fallowed on various matters which the Commission has been empowered by these
Regulations to specify or direct.
55. Saving of inherent power of the Commission.
(1)Nothing in these Regulations shall be deemed to limit or otherwise affect the inherent power of
the Commission to make such orders as may be necessary for meeting the ends of justice or to
prevent the abuse of the process of the Commission.(2)Nothing in these Regulations shall bar the
Commission from adopting a procedure, which is at variance with any of the provisions of these
Regulations, if the Commission, in view oi the special circumstances of a matter or class of matters
and for reasons to be recorded in writing deems it necessary or expedient.(3)Nothing in these
Regulations shall, expressly or impliedly, bar the Commission to deal with any matter or exercise
any power under the Act for which no Regulations have been framed, and the Commission may deal
with such matters, powers and functions in a manner it thinks fit.
56. General power to amend.
- The Commission may, at any time amend any defect or error in any proceeding before it.
57. Power to remove difficulties.
- If any difficulty arises in giving effect to any of the provisions of these Regulations, the
Commission may, by general or special order, do anything not being inconsistent with the
provisions of the Act, which appears to it to be necessary or expedient for the purpose of removing
the difficulties.
58. Power to dispense with the requirement of the Regulations.
- The Commission shall have the power, for reasons to be recorded in writing and with notice to the
affected parties, dispense with the requirements of any of the Regulations in a specific case or cases
subject to such terms and conditions as may be specified.
59. Extension or abridgement of time prescribed.
- Subject to the provisions of the Act, the time prescribed by these Regulations or by order of the
Commission for doing any act may be extended (whether it has already expired or not) or abridged
for sufficient reason by order of the Commission.Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

60. Effect of non-compliance.
- Failure to comply with any requirement of these Regulations shall not invalidate any proceeding
merely by reason of such failure unless the Commission is of the view that such failure has resulted
in miscarriage of justice.
61. Costs.
(1)Subject to such conditions and limitations as may be directed by the Commission, the cost of all
proceedings shall be awarded at the discretion of the Commission and the Commission shall have
full power to determine by whom or out of what funds and to what extent such costs are to be paid
and give all necessary directions for the aforesaid purposes.(2)The costs shall be paid within 30 days
from the date of the order or within such time as the Commission may, by order, direct. The order of
the Commission awarding costs shall be executed In the same manner as the decree/order of a Civil
Court.
62. Enforcement of orders passed by the Commission.
- The Secretary shall ensure enforcement and compliance of the orders passed by the Commission,
by the persons concerned in accordance with the provisions of the Act and Regulations and if
necessary, may seek the orders of the Commission for directions.
63. [ Recognition for Consumer Association and consumer interest. [Inserted
by Regulation No. 8, dated 28.8.2000.]
(1)It shall be open to permit any recognised association, forum or other bodies corporate or any
group of consumers to participate in any proceedings before the Commission and permit them to
make such representation or participate in the proceedings before the Commission in such manner
as the Commission considers appropriate.(2)It shall be open to the Commission for the sake of
timely completion of proceedings, to direct grouping of the associations, forums referred to in clause
(1) above so that they can make collective representation.(3)The Commission may appoint any
officer or any other person to represent consumers' interest, if considered necessary.(4)The
Commission may, for the purpose of clauses (1) or (3) above direct payment of such fees, costs and
expense by such of the parties in the proceedings, as the Commission may consider appropriate.]
64. [ Authorised representative to appear before Commission. [Inserted by
Regulation No. 8, dated 28.8.2000.]
- A person may authorise an advocate or a member of any statutory professional body holding a
Certificate of practice as the Commission may from time to time specify to represent him and act
and plead on his behalf before the Commission. The person may also appear himself or may
authorise any of his employees to appear before the Commission and to act and plead on his behalf.
The Commission may from time to time specify the terms and conditions subject to which a personAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

may authorise any other person to represent him and act and plead on his behalf.]
65. [ Applicability of provisions of Indian Penal Code and Criminal Procedure
Code. [Inserted by Regulation No. 8, dated 28.8.2000.]
(1)In terms of Section 52 of the Reform Act, proceedings before the Commission shall be deemed to
be judicial proceedings and Commission shall be deemed to be a Civil Court as specified in the said
Section read with applicable provisions of the Indian Penal Code and the code of Criminal
Procedure 1973.(2)The extracts of the relevant provisions of the Indian Penal Code and Criminal
Procedure Code are as under:(i)Section 193.Punishment for false evidence: -Whoever intentionally
gives false evidence in any stage of a judicial proceeding, or fabricates false evidence for the purpose
of being used in any stage of judicial proceeding, shall be punished with imprisonment of either
description for a term which may extend to seven years, and shall also be liable to fine;And whoever
intentionally gives or fabricates false evidence in any other case, shall be punished with
imprisonment of either description for a term which may extend to three years, and shall also be
liable to fine.Explanation 1. - A trial before a Court-martial a [* * *] is a judicial
proceeding.Explanation 2. - An investigation directed by law preliminary to a proceeding before a
Court of Justice, is a stage of a judicial proceeding, though that investigation may not take place
before a Court of Justice.(ii)Section 219.Public servant in judicial proceeding corruptly making
report, etc.,contrary to law:-Whoever, being a public servant, corruptly or maliciously makes or
pronounces in any stage of a judicial proceeding, any report, order, verdict, or decision which he
knows to be contrary to law, shall be punished with imprisonment of either description for a term
which may extend to seven years, or with fine, or with both.(iii)Section 228.Intentional insult or
interruption to public servant sitting in judicial proceeding:-Whoever intentionally offers any insult,
or causes any interruption to any public servant, while such public servant is sitting in any stage of a
judicial proceeding, shall be punished with simple imprisonment for a term which may extend to six
months, or with fine which may extend to one thousand rupees, or with both.(iv)Section
345.Procedure in certain cases of contempt:-(a)When any such offence as is described in Section
175, Section 178, Section 179, Section 180 or Section 228 of the Indian Penal Code (45 of 1860) is
committed in the view or presence of any civil, criminal or revenue Court, the Court may cause the
offender to tbe detained in custody and may, at any time before the rising of the Court on the same
day, take cognizance of the offence and, after giving the offender a reasonable opportunity of
showing cause why the should not be punished under this section, sentence the offender to fine not
exceeding two hundred rupees, and, in default of payment of fine, to simple imprisonment for a
term which may extend to one month, unless such fine be sooner paid.(b)In every such case the
Commission shall record the facts constituting the offence, with the statement (if any) made by the
offender, as well as the finding and sentence.(c)If the offence is under Section 228 of the Indian
Penal Code (45 of 1860), the record shall show the nature and stage of the judicial proceeding in
which the Court interrupted or insulted was sitting, and the nature of the interruption or
insult.(v)Section 346.Procedure where Court considers that case should not be dealt with
underSection 345: -(a)If the Court in any case considers that a person accused of any of the offences
referred to in Section 345 and committed in its view of presence should be imprisoned otherwise
than in default of payment of fine, or that a fine exceeding two hundred rupees should be imposed
upon him, or such Court is for any other reason of opinion that the case should not be disposed ofAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

under Section 345, such Court, after recording the facts constituting the offence and the statement
of the accused as hereinbefore provided, may forward the case to a Magistrate having jurisdiction to
try the same, and may require security to be given for the appearance of such person before such
Magistrate, of if sufficient security is not given shall forward such person in custody to such
Magistrate.(b)The Magistrate to whom any case is forwarded under this section shall proceed to deal
with, as far as may be, as if it were instituted on a police report.]Annexure-1Form I(See Regulation
10)General Heading for ProceedingsBefore The Andhra Pradesh Electricity Regulatory Commission,
HyderabadFile No. :Case No. :(To be filled by the Office)In The Matter of :(Gist of the purpose of the
petition or application)AndIn The Matter of :(Names and full addresses of the
petitioners/applicants and names and full addresses of the respondents)Annexure - IIForm 2(See
Regulation 11)Before The Andhra Pradesh Electricity Regulatory Commission, HyderabadFile No.
:Case No. :(To be filled by the Office)In The Matter of :(Gist of the purpose of the petition or
application)AndIn The Matter of :(Names and full addresses of the petitioners/applicants and
names and full addresses of the respondents)Affidavit verifying the petition/reply/applicationI, AB,
son of...................................... aged................................ residing at...................do solemnly affirm and
say as follows:
1. I am a
Director/Secretary/............................................of.......................................... Ltd.,
the petitioner in the above matter and am duly authorised by the said
petitioner to make this affidavit on its behalf.
Note. - This paragraph is to be included in cases where the petitioner is the Company.
2. The statements made in paragraphs............................of the petition herein
now shown to me and marked with the letter "A" are true to my knowledge
and the statements made in paragraphs.....................................are based on
information and believe them to be true. Solemnly affirm, etc.
Note. - To be included when the affidavit is sworn to by any person other than a Director, Agent or
Secretary or other Officer of the Company.[Annexure - III] [Inserted by Regulation No. 8, dated
28.8.2000.]Form 3Particulars To Be Furnished By The Exemption Applicant(See Regulation 43
(4)(i))[Note. - The General heading of the application shall be the same as in Annexure - I and the
affidavit in Annexure - II]
1. Details of Applicant
(a)Full name of Applicant:(b)Full address of Applicant:Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

2. Details of Ownership
(a)Company/Firm/Co-op Society/Individual/Others:(b)When and where registered/registration
number/registered office:(c)Names and addresses of directors:
3. Principal shareholders/Partners/Members:
4. Principal Business Activity:
5. Details of Licence Exemption Application
(a)Type of licence exemption for which application is submitted:(b)Boundaries of proposed Area of
Supply (referring to the attached map when necessary):
6. Purpose and Nature of Supply
(a)Sourcing of Power(i)Voltage(s):(ii)Source of supply (Own generation/Purchase from
APTRANSCO/Purchase from Others (Name of
supplier_________________________)(iii)Quantum of electricity handled in last 12 monthsa.
Demand (MW):b. Energy (MU):(iv)Bulk purchase price at which electricity is procured:(b)Supply of
Power(i)Voltages of supply:(ii)Categories of supply (Domestic/Commercial/Agricultural etc. with
numbers, loads):(iii)Persons to whom electricity is intended to be supplied with full details of
categories of persons (members/employees' colonies/other concerns/general public, etc.):(iv)Tariff
at which electricity will be supplied:(c)Method and manner of handling consumer
grievances:(d)Funding arrangements for maintenance, operation, improvements and expansion to
meet supply obligations, future load growth, etc.:
7. Resume of the Organisation giving details of
(i)Management Capability:(ii)Financial Strength:(iii)Ability to discharge supply function in a
sustainable manner:
8. (a) Date from which exemption is sought:
(b)Period for which exemption is sought:
9. Detailed justification for seeking exemption:
List of Documents to Accompany Exemption Applications:(1)Copies of Company's
Memorandum/Articles of Association/Partnership deed etc.(2)Data Relating to management and
Financial Capability(a)Managerial:(i)Senior management's curriculum vitae(ii)Cadre strength for
different categories, technical and non-technical(b)Financial:(i)Bank references asserting that the
Applicant is financially solvent(ii)Most recent Balance Sheet(iii)Audited accounts for the ApplicantAndhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

and any Holding Company, Subsidiary or affiliated company for each of the three most recent
financial years(iv)Any accompanying notes and certifications on the above statements from a
reputable chartered accountant(3)Data Relating to the Applicant's future Business(i)Five year
Business Plan for the business for which the application relates(ii)Five year annual forecasts of
costs, sales, revenues and project financing stating the assumptions underlying the figures
provided(4)Detailed Map(s) of the proposed area of supply Detailed map(s) showing the area
supplied and the configuration of the Transmission/Sub-transmission and Distribution System,
including information on Substations. The map shall clearly distinguish between the existing System
and any new facilities that are or will be required for the purposes of providing Supply.The map
shall indicate the streets and roads in which the energy is supplied and distinguish between public
and private.
5. Copies of letters seeking consent from the local authority as per Section
16 (1)(i) of the AP Electricity Reform Act, 1998
6. Copies of letters seeking consent from the Central Government as per
Section 16
(1)(ii)of the AP Electricity Reform Act, 1998
7. Copies of letters seeking consent from the licensed supplier(s) as per
Section 16
(1)(iii)of the AP Electricity Reform Act, 1998
8. Proof of Service of the Copy of Application on APTRANSCO.Andhra Pradesh Electricity Regulatory Commission (Conduct of Business) Regulations, 1999

