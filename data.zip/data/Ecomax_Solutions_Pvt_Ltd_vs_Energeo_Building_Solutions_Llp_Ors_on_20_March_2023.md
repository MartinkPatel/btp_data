Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp &
Ors. on 20 March, 2023
Author: C. Hari Shankar
Bench: C. Hari Shankar
                                            Neutral Citation Number : 2023:DHC:2334
                          $~20 (Original)
                          *       IN THE HIGH COURT OF DELHI AT NEW DELHI
                          +       CS(COMM) 366/2022
                                  ECOMAX SOLUTIONS PVT. LTD.                ..... Plaintiff
                                              Through: Mr. Anirudha Valsangkar, Ms.
                                              Anjali Valsangkar, Ms. Namita, Ms. Jasleen
                                              Kaur and Mr. Abhilash Gupta, Advs.
                                                     versus
                                  ENERGEO BUILDING
                                  SOLUTIONS LLP & ORS.                      .... Defendants
                                                Through: Mr. Saikrishna Rajagopal, Ms.
                                                Sneha Jain, Ms. Priyam Lizmary Cherian,
                                                Mr. Saif Rahman Ansari, Ms. Shruti Jain
                                                and Mr. Shiraz Hasan Zaidi, Advs.
                                  CORAM:
                                  HON'BLE MR. JUSTICE C. HARI SHANKAR
                                                JUDGMENT (ORAL)
% 20.03.2023 IA 8575/2022 (under Order XXXIX Rules 1 and 2 of the CPC) and IA 10931/2022
(under Order XXXIX Rule 4 of the CPC) in CS(COMM) 366/2022
1. By this judgment, I proceed to decide IA 8575/2022, preferred by the plaintiff under Order
XXXIX Rules 1 and 2 of the Code of Civil Procedure, 1908 (CPC) and IA 10931/2022, preferred by
the defendants under Order XXXIX Rule 4 of the CPC. An ex parte ad interim injunctive order
already stands passed by this Court in IA 8575/2022 on 27th May 2022. As such, IA 10931/2022
seeks vacation of the said order.
Facts Neutral Citation Number : 2023:DHC:2334
2. The dispute in this suit pertains to patent IN 382118 (IN118 hereinafter), granted by the
Controller of Patents in respect of an Automatic Tube Cleaning System (ATCS) manufactured by the
plaintiff. The ATCS is, essentially, a system by which tubes and ducts in air-conditioning system are
kept clean. The following extracts, from the complete specifications, set out the particulars of the
ATCS:
"Background of the invention Shell and tube heat exchangers are integral part ofEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

various processes in the industrial applications. Practically, it is not always possible
to maintain the water quality in heat exchangers in perfect condition, resulting into
fouling of the tubes internally. The fouling agents for the water can be salts from use
of hard water or biological growth in water. Over a period, the accumulation of salts
or biological - growth in the tubes forms a non-conductive layer within the tubes
affecting heat transfer in the heat exchangers drastically. As a result, the efficiency
and performance of the equipment for which these shell and tube heat exchanges are
used drops drastically resulting into huge losses with respect to higher power
consumption, loss of production and the like.
Various types of tube cleaning systems are in existence for decades that use injection
of sponge rubber balls into the water stream at the heat exchanger inlet and
collection of sponge balls at the outlet of heat exchanger to ensure tha1 tube remain
clean during the operation.
However, the systems in existence have drawbacks as far as the operation is
concerned which are explained in the following paragraph.
The systems in existence have a recirculation pump which operates continuously
resulting into higher power consumption, the sponge rubber balls pass through a
pump impeller resulting into wear and tear of the sponge balls which in tum affects
cleaning efficiency and system becomes more maintenance prone. As the sponge balls
are injected through continuously running recirculation pump; the balls enter the
heat exchangers one by one and not simultaneously hence there exists the possibility
of the sponge balls passing through the middle tubes more frequently than the
peripheral tubes use the velocity in the middle tubes is higher than the peripheral
tubes and hence there exists the possibility of peripheral tubes not being properly
cleaned resulting into poor performance of heat exchangers. Because of the nature of
the ball trap designs, the balls get lost into the cooling water stream creating the need
to add sponge balls on regular basis and it even worsens the problems Neutral
Citation Number : 2023:DHC:2334 because the lost balls would go to the cooling
tower nozzles and block them thereby reducing cooling tower performance and
ultimately the equipment performance for which cooling tower is used. There are
systems available which overcome some of the drawbacks mentioned above but are
not full proof. There is no means for separating the undersized balls and hence the
cleaning performance gets affected. Also, the cleaning body counting systems are not
available because of the way the balls are injected and collected.
Also, water is drained/wasted during the cleaning bodies collection cycle. In such
kind of systems, initially during start up air needs to be purged out of the system
which is done with the help of air vent from the collector where the balls are housed.
During venting the air out, cleaning bodies tend to come out and operator has
problem retaining the cleaning bodies inside the collector because there is a single
vessel to keep cleaning bodies and to vent the air.Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

Object of the invention An object of the present invention is to provide reliable
system for cleaning tubes of a shell and tube heat exchanger having improved,
performance and efficiency of shell and tube neat exchangers.
Detail description of the invention The foregoing objects of the invention are
accomplished and the problems and shortcomings associated with the prior art
techniques and approaches are overcome by the present invention as described below
in the preferred embodiment.
The present invention provides a system for cleaning tubes of a shell and tube heat
exchangers. The system helps with little addition of components to clean multiple
heat exchangers at a time and the solution offered is cost effective compared to other
tube cleaning systems available in the market.
The present invention is illustrated with reference the accompanying drawings,
throughout which reference numbers indicate corresponding parts in the various
figures. These reference numbers are shown in bracket in the following description.
3. The claims in the suit patent read thus:
1. An online system for cleaning tubes of at least one shell and tube heat exchanger
using a plurality of cleaning bodies, the system comprising:
at least one first collector positioned upstream of the shell and tube heat exchanger
for holding the cleaning bodies in a rest Signing Date:04.04.2023 20:07:39 Neutral
Citation Number : 2023:DHC:2334 position;
at least one first pump providing a medium for pressurized pumping of the cleaning
bodies of the first collector into the shell and tube heat exchanger;
at least one trap positioned downstream the shell and tube heat exchanger to arrest
the cleaning bodies flowing therefrom;
at least one counting system for counting of cleaning bodies collected from the trap,
the counting system having a reducer portion for allowing to pass a single cleaning
body therethrough at a time and a expander portion to restore flow of the medium
along with the cleaning bodies;
at least one second collector capable of collecting the sorted undersized cleaning
bodies coming from the first collector;
at least one second pump positioned downstream of the second collector to collect
the cleaning bodies from the trap into the first collector and the undersized cleaning
bodies in the second collector; and at least one electronic controller controllingEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

operation of the system.
2. The system as claimed in claim 1, wherein the cleaning bodies are sponge balls.
3. The system as claimed in claim 1, wherein the first collector includes a conical
mesh positioned at a proximal end for holding the cleaning bodies.
4. The system as claimed in claim 1, wherein the trap is a split type trap.
5. The system as claimed in claim 1, wherein the trap encloses a perforated mesh and
an automatic sieve gate.
6. The system as claimed in claim 1, wherein the counting system includes a signal
transmitter and a signal receiver to count the number of cleaning bodies in
circulation.
7. The system as claimed in claim 1, wherein the counting system provides signal to
the electronic controller thereby providing an audio or a visual alert on reduction of
number of cleaning bodies below the minimum acceptable limit.
8. The system as claimed in claim 1, wherein the second collector includes a
perforated disc shaped mesh.
9. An online system for cleaning tubes of at least one shell and tube heat exchanger
using a plurality of cleaning bodies, the system comprising:
at least one dual collector positioned upstream of the shell and tube heat exchanger
including a first chamber for holding the Neutral Citation Number : 2023:DHC:2334
cleaning bodies in a rest position and a second chamber for collecting the sorted
undersized cleaning bodies coming from the first chamber;
at least one injection pump providing a medium for pressurized pumping of the
cleaning bodies of the first chamber into the shell and tube heat exchanger, at least
one trap positioned downstream the shell and tube heat exchanger to arrest the
cleaning bodies flowing therefrom;
at least one counting system for counting of cleaning bodies collected from the trap,
the counting system having a reducer portion for allowing to pass a single cleaning
body therethrough at a time and a expander portion to restore flow of the medium
along with the cleaning bodies;
at least one collection pump positioned downstream of the second chamber to collect
the cleaning bodies from the trap into the first chamber and the undersized cleaning
bodies in the second chamber and at least one electronic controller controllingEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

operation of the system.
10. The system as claimed in claim 9, wherein the dual collector includes a vertical
perforated mesh having a plurality of holes provided to separate undersize cleaning
bodies from the first chamber to the second chamber.
11. The system as claimed in claim 9, wherein the dual collector includes at least one
site glass facilitating insertion and removal of the cleaning bodies in the first chamber
and the second chamber.
12. The system as claimed in claim 9, wherein the first chamber of the dual collector
has a horizontal perforated mesh positioned at a bottom"
Rival Contentions
4. Case of the plaintiff 4.1 Mr. Aniruddha Valsangkar, appearing for the plaintiff, submitted that the
plaintiff is aggrieved both by the misuse, by the defendants, of information which was confidential
to the plaintiff and of piracy, by the defendant, of the plaintiffs registered suit patent.
4.2 Mr. Valsangkar charts the following chronology of events, in an Neutral Citation Number :
2023:DHC:2334 attempt to drive home his allegation of misuse of confidentiality:
(i) On 13th April 2012, Mohan Chavan, Chief Executive Officer (CEO) of the plaintiff,
applied, to the Indian Patent Office, for registration of the suit patent.
(ii) On 4th August 2017, Eco Green Systems LLP ("Ecogreen"), the
predecessor-in-title of the plaintiff executed a Confidentiality Agreement with
Carrier. At that time, Defendant 3 Vanshaj Dhawan ("Vanshaj", hereinafter) and
Defendant 4 Ashish Dangaych were employed with Carrier.
The relevant Clauses of the Confidentiality Agreement read thus:
"The Parties will or already have had discussions and exchanged information, and
may intend to continue having discussions and exchanging information, in
connection with a possible business co-operation between them. All such discussions
referred to the above hereafter will be called the "Discussions". During and in
connection with the Discussions, each Party may have need of information from the
other party that is regarded as Confidential. Accordingly, the Parties agree as follows:
1. "Confidential Information." is defined as any information that is disclosed in
connection with the Discussions and is furnished by a Party to the other Party in one
or more of the following forms:Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

A. Written information, including offering documents, reports, assessments,
drawings, documents relating to patents, other intellectual properties or proprietory
concepts, financial disclosures and projections, product and product cycle plans and
any other written information or machine readable data, including e-mails and
electronic transfers;
B. Information, including demonstrations, which is furnished orally; and Neutral
Citation Number : 2023:DHC:2334 C. Any item of hardware, including samples,
devices and any other physical embodiments delivered to the receiving Party.
*****
3. "Non-Disclosure, Non-Circumvention." The receiving Party shall, for a period
beginning with the first date of receipt of each respective disclosure, and continuing
for a period of thirty-six (36) months thereafter use reasonable care to maintain the
confidentiality of all Confidential Information and shall limit disclosure to such of its
directors, employees, agents, advisors, affiliates or subsidiaries as have a "Need to
Know" such Confidential Information in order that the objectives of the discussions
can be achieved. The receiving Party shall be responsible for the compliance by such
directors, employees, agents, advisors, affiliates, or subsidiaries with the provisions
of this Agreement.
Additionally, the Parties by entering into this Agreement shall not knowingly cause nor instigate a
cause to circumvent the other at any time during the respective thirty-six (36) month period of
which the Confidential Agreement is designated as effective and agreed to between the parties.
"Reasonable Care" shall mean the same degree of care exercised by the receiving Party with respect
to its own information of the same nature as Confidential Information.
4. "Exceptions to Confidentiality Obligations." The Confidentiality and Limited Use Obligations of
this Agreement will not apply to information received pursuant to this Agreement which:
a. Is or becomes publicly known other than through a breach of this Agreement by the receiving
Party; or b. Is already known to the receiving Party at the time of disclosure as evidenced by the
receiving Partys written documentation; or c. Is lawfully received by the receiving Party from a
third party without breach of this Agreement or breach of any other agreement between the
disclosing Party and such third party; or d. Is independently developed by employees of the
receiving Party who have not had access to or Neutral Citation Number : 2023:DHC:2334 received
any Confidential Information under this Agreement; or e. Is furnished to a third party by the
disclosing Party without restriction on the third partys right to disclose; or f. Is authorized in
writing by the disclosing Party to be released from the confidentiality, non- disclosure,
non-circumvention obligations herein.
Specific information shall not be deemed to be within the foregoing exceptions merely because it is
included within general information which is within the exceptions, nor will a combination ofEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

features be deemed to be within such exceptions merely because the individual features of the
combination are separately included within such exceptions. The Party relying on any of the
foregoing exceptions to the confidentiality obligations herein shall bear the burden of proving
applicability of the exception."
(iii) On 15th March 2019, Vanshaj, on behalf of Carrier, wrote to the plaintiff, seeking the prices of
its ATCS, which were provided by Mohan Chavan, writing for the plaintiff, on the same day.
(iv) On 28th August 2019, Vanshaj formed the Defendant 1- limited liability partnership EnerGeo
Building Solutions LLP ("Energeo LLP") with Sunanda Dhawan, even while he continued to remain
employed with Carrier.
(v) On 10th September 2019, at 9.05 a.m., Vanshaj, on behalf of Carrier, wrote to the plaintiff,
seeking the drawings of the Ball Collector and Ball Trap of the ATCS for submission to a customer.
Mohan Chavan immediately wrote, at 9.19 a.m., to Vinay, an employee of the plaintiff, to share the
said details. Vinay, thereupon, enclosed, with e-mail sent to Vanshaj at 1.36 p.m. on the same day,
the drawings of the Ball Collector and Ball Trap.
Neutral Citation Number : 2023:DHC:2334
(vi) In October 2019 itself, Vanshaj resigned from Carrier.
(vii) On 15th October 2019, Defendant 1 Energeo LLP filed Application No. 322555-001 for a design
registration for an "Inland Ball Trap".
(viii) In February 2020, Defendant 4 resigned from Carrier.
(ix) On 12th March 2020, Defendant 2 was incorporated.
(x) On 1st September 2020, at 1.37 p.m., Voltas addressed an e-mail to the plaintiff, seeking its best
offer, to which Energeo LLP, through its employee Zaheer Ahmed, responded at 3.32 p.m., enclosing
the offer for the AFCS of Energeo LLP, for use in the Central Vista Project. A copy of the e-mail was
addressed to the plaintiff. The plaintiff contends that it was from this e-mail that it came to know,
for the first time, of the AFCS of Defendant 1. Attached to the e-mail was the brochure of Energeo
LLP, which claimed to be "introducing Anti- Fouling Condenser System (AFCS)." According to Mr
Valsangkar, the AFCS of the defendants had been created by misusing the confidential information
of the plaintiff, and also infringed the suit patent.
(xi) On 18th November 2021, the suit patent was registered by the IPO, with effect from 13th April
2012, in view of Section 45(1)1 of the Patents Act.
45. Date of patent -Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

(1) Subject to the other provisions contained in this Act, every patent shall be dated as of the Neutral
Citation Number : 2023:DHC:2334
(xii) On 10th May 2022, Voltas addressed an e-mail to Vanshaj, enclosing the drawings of the
plaintiff. This, submits Mr Valsangkar, breached Memorandum of Understanding (MoU) dated 27th
February 2018 between Ecogreen (the plaintiffs predecessor-in-title) and Voltas, Clause 5 of which
required Voltas to maintain confidentiality with respect to confidential information provided to it by
Ecogreen.
4.3 Thus, submits Mr Valsangkar, confidential information, which was shared by the plaintiff with
Defendants 3 (Vanshaj) and 4 was misused by the said defendants, to fabricate and create their own
tube cleaning system, which they called the Anti Fouling Condenser System (AFCS). Mr. Valsangkar
submits that the sharing of the confidential information by Voltas with Vanshaj was in breach of the
Confidentiality Clause in the MoU dated 27th February 2018 between Voltas and Ecogreen. He
however, acknowledges the fact that the default in this regard, if any, would lie at the door of Voltas.
Mr. Valsangkar, however, seeks to emphasise on the aforesaid e-mail correspondence merely to
point out that, shortly prior to AFCS being devised by Defendants 3 and 4, the said defendants had
come into possession of confidential information of the plaintiff, which would facilitate fabrication
of the AFCS.
4.4 The misuse of the confidential information which had thus come into possession of the
defendants has, Mr Valsangkar submits, to be gleaned from their conduct. Having, by purporting to
require them for forwarding to a prospective customer, come into possession of the confidential
drawings of the appellants Ball Trap on 10th September 2019 when he was still an employee of
Carrier, Defendant Neutral Citation Number : 2023:DHC:2334 3 proceeded to resign from Carrier
in October 2019 itself and, on 15 th October 2019, himself apply, on behalf of Energeo LLC, for grant
of design for the Ball Trap. It is obvious, submits Mr Valsangkar, that the defendants have made use
of the drawings procured by them on 10th September 2019. He draws attention to the report of the
Local Commissioner, appointed by this Court in the present case, which noted the presence of the
plaintiffs confidential drawings in the defendants premises. Why, queries Mr Valsangkar, would
the plaintiffs confidential drawings be present in the defendants premises, unless the defendants
were making use of them?
4.5 The need to maintain confidentiality of material provided by one party to the other, submits Mr
Valsangkar, is not dependent on the existence, or non-existence, of any contractual stipulation
between them to that effect, for which purpose he relies on the decision of the Court of Appeal in
Saltman Engineering Co. v. Campbell Engineering Co.2 and Seager v. Copydex Ltd3. He also cites,
in this context, para 16, 18, 19 and 25 to 32 of the decision of a Division Bench of the High Court of
Calcutta in Sudipta Banerjee v. L.S. Davar & Co.4 and paras 2 and 9 to 11 of the decision of a
Division Bench of the High Court of Bombay in Zee Telefilms Ltd v. Sundial Communications Pvt
Ltd5.
4.6 Mr Valsangkar further submits that the AFCS infringed the suit patent, as all essential elements
of the suit patent were replicated in the AFCS. This, he submits, would become clear on aEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

comparison of the brochure of the defendants AFCS with the suit patent relating to the (1948) 65
RPC 203 (1967) 1 WLR 923 AIROnLine 2022 Cal 730 2003 (3) Mh LJ 695 Neutral Citation Number
: 2023:DHC:2334 plaintiffs ATCS. One may, therefore, at this point itself, reproduce the drawing
of the plaintiffs ATCS, as contained in the complete specifications of the suit patent, and the
drawing of the defendants AFCS:
Drawing of plaintiffs ATCS as contained in IN118 Drawing of defendants AFCS as
contained in its brochure 4.7 Mr Valsangkar has taken me through paras 37, 38, 40,
41, 42 and 49 of the defendants reply to the present application, which may,
therefore, be reproduced thus:
Neutral Citation Number : 2023:DHC:2334 "37. Absence of two-pump mechanism of
IN '118 in allegedly infringing product of the Defendants: As demonstrated above,
one of the alleged inventive features of the alleged invention of IN 118 is the
existence of two pump mechanism. The said pumps are clearly shown in the drawings
in the complete specification of IN 118 at page 84, Vol. I wherein the two pumps are
identified as (118) and (160).
38. The Defendants are demonstrably using a single pump technology as is readily
apparent from their product brochure and product listing on the website, Plaintiffs
Patent Defendants product and principle Neutral Citation Number :
2023:DHC:2334
40. Absence of Two Collectors for cleaning bodies of IN '118 in the allegedly
infringing product of the Defendants: The Defendants allegedly infringing product
does not employ any means to sort the cleaning bodies/ balls, does not use two
collectors nor there is any use of multiple meshes in the same collector as is required
by the independent claims and the dependent claims of IN 118. The Defendants are
demonstrably not using the alleged invention of IN 118 in as much as there is no
mechanism of sorting of cleaning bodies (balls) in the allegedly infringing product of
the Defendants. The Defendants technology is incapable of sorting and collecting
undersized and used balls and replacing them. In the allegedly infringing product of
the Defendants, all the cleaning bodies (balls) must be periodically changed together
without any means of changing only the undersized, worn-out or damaged cleaning
bodies (balls) while leaving the normal balls. This as the Plaintiff states in its
complete specification makes the existing art less economical than the alleged
invention of IN 118. It is stated for removal of all doubts that the Defendants
allegedly infringing product demonstrably does not use two collectors and there is no
collector in the accused product with two meshes, thus Defendants allegedly
infringing product has no means of sorting the cleaning bodies (balls) as done by the
alleged invention of IN 118. The same is readily apparent from their product
brochure and product listing on the website of the Defendants. Therefore, the
Defendants are yet again merely practicing the prior art/ technology in public
domain in their allegedly infringing product and not the alleged invention of IN 118.Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

It is trite that an entity practicing the technology already in the state of the art cannot
at the same time infringe the asserted patent.
41. Absence of Counting system of IN '118 in the allegedly infringing product of the
Defendants: The allegedly infringing product of the Defendants does not have the
counting system as claimed in the IN 118 Neutral Citation Number :
2023:DHC:2334 patent. It is submitted that since the Defendants allegedly
infringing product does not have two collectors/ dual collectors or dual/ multiple
meshes for cleaning bodies (balls) and does not have a mechanism of ball separation/
sorting/segregation, the Defendants product does not even require a ball counter
since undersized balls are not separated and requirement for counting of cleaning
balls in circulation does not arise.
Therefore, there is no counting system and no reducer portion or expander portion. Clearly since the
cleaning bodies (balls) in the allegedly infringing product of the Defendants remains constant and is
frequently replaced as a complete batch- an aspect which the alleged invention clearly identifies as
state of the art- nothing will be achieved in the Defendants allegedly infringing product by having a
counting system.
42. The trap used in the allegedly infringing product of the Defendants is materially different from
the trap of IN '118: As demonstrated above, the admitted case of the Plaintiff is that they provided a
split-design ball trap having a sieve gate which is allegedly an advance over the existing ball traps
that suffered from operational drawbacks and in this manner, they have achieved a system which is
more advantageous. It is submitted that the Defendants allegedly infringing product utilizes an
inline ball trap which is markedly different from a split-design trap and does not have any sieve in it.
Therefore, the trap design used by the Defendants in their allegedly infringing product is
demonstrably different from the claimed invention, as is readily apparent from their product
brochure and product listing on the website. The Defendants trap cannot be disassembled and is a
single unit unlike the allegedly claimed split-design ball trap of IN 118. Further, in respect of their
inline trap design, the Defendant No. 1 has filed a design application "322555" on 15th October 2019
as also admitted by the Plaintiff at paragraph 36, page 49 of its Plaint.
Plaintiffs drawing as part of Defendants in-line ball trap complete specification
49. The Defendants submit the following in view of the above case and allegation of Plaintiff in
relation to Plaintiffs confidential information, i. The Defendants submit and undertake that they
have never used and will not use any alleged confidential information of the Plaintiff in any manner.
***** iv. Further, since the allegedly infringing product of the Defendants is significantly, materially,
and completely different from the alleged invention of IN 118 as demonstrated in the preceding
paragraphs, there is no occasion or need for the Defendants to rely Neutral Citation Number :
2023:DHC:2334 on any drawings or other confidential information of the Plaintiff. It is logical that
if two technologies are different then their technical know-how, confidential drawings, photographs
and confidential working principles or other confidential information will be materially different asEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

well.
v. As demonstrated above, the alleged invention of IN 118 overcomes certain alleged "operational
drawbacks" over existing technology. As also demonstrated above, the Defendants are using
technology which is not part of the impugned patent and thus there is no occasion or requirement
for the Defendants to even rely or use the alleged confidential information of the Plaintiff. Without
prejudice, it is submitted that merely based on ball trap and ball collector drawings as purportedly
shared with Defendant No. 3, it is not possible to manufacture the said parts or the entire
equipment/product. Further, the software controlling any AFCS product is securely protected and
cannot be accessed by any party without breaking into the code/knowing the password or without
authorised access. It is not the case of the Plaintiff that they have shared any details which can
enable constructing the AFCS system with Carrier or with any of the Defendants. Therefore, on basis
of general drawings alone and without knowing or understanding complex code and program logic,
it is not possible to construct such complex systems.
vi. Simply because Defendants happen to be aware of Plaintiffs confidential information and
operate in the same field does not by itself mean that they will be using such information. In this
context, it is irrelevant if the broad customer bases are common, or the broad field of technology is
common since the actual technology used is completely different."
Apropos the assertions in these passages, Mr. Valsangkar submits that the distinctions that they
seek to draw between the AFCS and the ATCS are inconsequential, and that all essential features of
the ATCS are present in the AFCS. He submits that Defendants 3 and 4 had no engineering
background, or experience in fabricating tube cleaning systems whatsoever, and that, therefore, it
could not be believed that they had, by their own inventive faculties, created the AFCS from scratch.
Mr. Valsangkar submits that the only distinction that the defendants seek to draw, between their
AFCS and the plaintiffs ATCS, is the presence of two pumps in the ATCS as against one in the
AFCS and the absence, in the AFCS, of a ball counting system.
Neutral Citation Number : 2023:DHC:2334 Adverting to para 40 of the defendants reply, Mr.
Valsangkar submits that the number of ball collectors was relevant only for Claim 1 in the suit
patent, and not for Claim 9, which claimed a cleaning system with two compartments. Similarly,
submits Mr. Valsangkar, the distinction between the Ball Traps in the suit patent and the
defendants AFCS was of no consequence, as the plaintiff had patented, not the Ball Trap but the
entire ATCS, and there was, undeniably, a Ball Trap both in the ATCS and the AFCS. The number of
pumps, too, submits Mr. Valsangkar, makes no substantial difference to the system itself. Mr.
Valsangkar further submits, reiterating his earlier contention, that, even on the aspect of
infringement of the suit patent by the impugned AFCS of the defendants, the defendants conduct
was relevant. In the context of these submissions, Mr. Valsangkar has relied on paras 18 to 20 and
22 of F.M.C. Corporation v. Natco Pharma Ltd6, paras 22, 26, 29, 30, 32, 35, 37, 38, 40 and 41 of
Sotefin SA v. Indraprastha Cancer Society & Research Center7 and paras 24, 25 and 30-33 of the
decision of a Division Bench of this Court in F.M.C. Corporation v. Natco Pharma Ltd8, which
dismissed the appeal from the decision of the learned Single Judge in F.M.C. Corporation6. He
again relies on the report of the Local Commissioner in the present case, which did not distinguishEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

between the ATCS and the AFCS on the basis of the number of pumps, or the presence or absence of
the ball counting system. The learned Local Commissioners, he points out, were not mere Counsel,
but were patent agents, and their view was, therefore, entitled to weight and value.
4.8 Mr. Valsangkar has emphasised the following drawbacks which were found to exist in the tube
cleaning systems which were in vogue 2022 SCC OnLine Del 2994 2022 (89) PTC 602 (Del) Neutral
Citation Number : 2023:DHC:2334 on the date at the time when ATCS was conceptualised by the
plaintiff:
"a. The prior existing systems had a recirculation pump which operates continuously
resulting into high power consumption.
b. The sponge rubber balls pass through the pump impeller (i.e., the rotating part of
the pump) resulting into wear and tear of the sponge balls, which in tum affects
cleaning efficiency thereby increasing the frequency of maintenance.
c. The balls enter the heat exchangers one by one and not simultaneously, which
causes the sponge balls to pass through the middle tubes more frequently than the
peripheral tubes thereby leading the peripheral tubes not being properly cleaned
resulting in poor performance of heat exchangers.
d. The nature of the ball trap design causes the sponge balls to get lost into the
cooling water stream and blocking the cooling tower nozzles resultantly reducing the
performance of the cooling tower and the equipment drastically and also creating the
need to add sponge balls on regular basis.
e. There were no means for separating the undersized balls for the above method
which affects the cleaning performance. As also there was no availability of cleaning
body counting system because of the way the sponge balls were injected and collected
for the above method.
f. In the prior known systems, the water was drained or wasted during the cleaning
bodies' collection cycle. Additionally, initially, the air had to be purged out of the
system with the help of air vent from the collector where the balls are housed. During
that process, the cleaning bodies tend to come out which caused problem to the
operator in retaining the cleaning bodies inside the collector as there is a single vessel
to keep the cleaning bodies and to vent the air.
g. Additionally with such prior known methods there was limitation to operate
multiple heat exchangers using one system thereby increasing the effective cost."
4.9 Mr Valsangkar also pleads copyright infringement. He submits that the following photographs
used by the plaintiff, in the brochure for its ATCS, as representing the condition of the AC ducts
before and 2022 SCC OnLine Del 4249 (DB) Neutral Citation Number : 2023:DHC:2334 after use ofEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

the cleaning system, have been borrowed, as they are, by the defendant, in the brochure for the
AFCS:
5. Case of the defendant 5.1 Ms Sneha Jain argued for the defendant.
5.2 Ms. Jain acknowledges, at the outset, that, to make out a case of patent infringement, only the
essential elements of the suit patent need be copied. She submits, however, that the star integers of
the suit patent were set out in the complete specifications of the suit patent itself and that among
these star intriguers were at least two pumps, two ball collectors and one counting system. These,
therefore, were essential requirements of the invention as claimed in the suit patent, and it could not
be said that a system which had only one pump, one collector and no counting system was at all
similar to the suit patent. The differences could not be, therefore, regarded as inconsequential. Ms.
Jain points out that, in fact, all the six essential features of the ATCS, as delineated in Claim 1 of the
suit patent, were absent in the AFCS.
5.3 The ATCS, submits Ms. Jain, specifically envisaged the existence of two pumps, one to injunct
balls into the system and the Signing Date:04.04.2023 20:07:39 Neutral Citation Number :
2023:DHC:2334 other to suck out the balls from the system. Two ball collectors were also envisaged
in the suit patent so as to ensure that, at all points of time, a particular number of balls were
circulating in the system. She, therefore, reiterates her contention that the features specifically
mentioned in Claim 1 of the suit patent were essential features of the ATCS and that the AFCS,
which did not possess the said features, could not be said to infringe the suit patent.
5.4 Apropos the allegation of breach of confidentiality, Ms. Jain submits that the data which,
according to Mr. Valsangkar was confidential and was misused by the defendants, was already in the
public domain and was, therefore, outside the scope of the Confidentiality Agreement between the
plaintiff and Carrier. She has relied, in this context, on Clauses 4(a) and (b) of the Confidentiality
Agreement, which excepted, from the scope of confidentiality, information which, even though
received pursuant to the Confidentiality Agreement, was either publically known or was already
known to the receiving party at the time of disclosure, as evidenced by written documentation of the
receiving party. Viewed thus, she submits that the defendants could not be charged with having
breached any term of confidentiality between the plaintiff and the defendants.
5.5 On the allegation that the defendants Ball Trap infringed the suit patent, Ms. Jain has drawn
my attention to para 25 of the rejoinder of the defendants in IA 10931/2022 (preferred by the
defendants under Order XXXIX Rule 4 of the CPC). She points out that, in the said paragraph, the
defendants have referred to various prior arts which disclosed Ball Traps similar to that used by the
plaintiff in its Neutral Citation Number : 2023:DHC:2334 ATCS. Putting forward a Gillette defence,
Ms. Jain submits that, in fact, the Ball Trap of the defendants was similar to the Ball Traps at serial
nos. „e and „f in the said table. She submits that it is clear, from the said tabular statement, that Y
shaped Ball Traps were common to the trade and were regularly used in the industry to clean air
conditioning units. She submits, relying on the following passage from Saltman Engineering Co.2
that no party could claim confidentiality over something which was public property and public
knowledge:Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

"I think that I shall not be stating the principle wrongly, if I say this with regard to the
use of confidential information. The information, to be confidential, must, I
apprehend, apart from contract, have the necessary quality of confidence about it,
namely, it must not be something which is public property and public knowledge. On
the other hand, it is perfectly possible to have a confidential document, be it a
formula, a plan, a sketch, or something of that kind, which is the result of work done
by the maker on materials which may be available for the use of anybody; but what
makes it confidential is the fact that the maker of the document has used his brain
and thus produced a result which can only be produced by somebody who goes
through the same process.
What the defendants did in this case was to dispense in certain material respects with
the necessity of going through the process which had been gone through in compiling
these drawings, and thereby to save themselves a great deal of labour and calculation
and careful draughtsmanship. No doubt, if they had taken a finished article, namely,
the leather punch, which they might have bought in a shop, and given it to an expert
draughtsman, that draughtsman could have produced the necessary drawings for the
manufacture of machine tools required for making that particular finished article. In
at any rate a very material respect they saved themselves that trouble by obtaining
the necessary information either from the original drawings or from the tools made
in accordance with them. That, in my opinion, was a breach of confidence."
5.6 What the plaintiff was seeking to do, she submits, was to treat an ordinary Ball Trap, which was
a common fixture in AC tube cleaning systems, as confidential. Ms. Jain submits that the following
passages, from Seager3 also underscore this legal position:
Neutral Citation Number : 2023:DHC:2334 "I start with one sentence in the
judgment of Lord Greene M.R. in Saltman Engineering Co.2:
"If a defendant is proved to have used confidential information, directly or indirectly
obtained from the plaintiff, without the consent, express or implied, of the plaintiff,
he will be guilty of an infringement of the plaintiff's rights."
To this I add a sentence from the judgment of Roxburgh J. in Terrapin Ltd. v. Builders' Supply Co.
(Hayes) Ltd.9 which was quoted and adopted as correct by Roskill J. in Cranleigh Precision
Engineering Ltd. v. Bryant10:
"As I understand it, the essence of this branch of the law, whatever the origin of it
may be, is that a person who has obtained information in confidence is not allowed to
use it as a spring-board for activities detrimental to the person who made the
confidential communication, and spring- board it remains even when all the features
have been published or can be ascertained by actual inspection by any member of the
public."Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

The law on this subject does not depend on any implied contract. It depends on the broad principle
of equity that he who has received information in confidence shall not take unfair advantage of it.
He must not make use of it to the prejudice of him who gave it without obtaining his consent. The
principle is clear enough when the whole of the information is private. The difficulty arises when the
information is in part public and in part private. As, for instance, in this case. A good deal of the
information which Mr. Seager gave to Copydex was available to the public, such as the patent
specification in the Patent Office, or the "Klent" grip, which he sold to anyone who asked. If that was
the only information he gave them, he could not complain. It was public knowledge. But there was a
good deal of other information he gave them which was private, such as the difficulties which had to
be overcome in making a satisfactory grip; the necessity for a strong, sharp tooth; the alternative
forms of tooth; and the like. When the information is mixed, being partly public and partly private,
then the recipient must take special care to use only the material which is in the public domain. He
should go to the public source and get it: or, at any rate, not be in a better position than if he had
gone to the public source. He should not get a start over others by using the information which he
received in confidence. At any rate, he should not get a start without paying for it. It may not be a
case for injunction or even for an account, but only for damages, depending on the worth of the
confidential information to him in saving him time and trouble."
[1960] R.P.C. 128, 130, C.A. [1965] 1 W.L.R. 1293 Neutral Citation Number : 2023:DHC:2334 Ms.
Jain also submits that the plaintiff cannot simultaneously plead confidentiality and seek patent
protection.
5.7 Ms. Jain also disputes Mr. Valsangkars contention that Defendants 3 and 4 were novices in the
air conditioner cleaning industry. She submits that they had more than 15 years experience in the
field or in associated endeavours.
5.8 Adverting, again, to her submission that the AFCS did not possess the essential features of the
suit patent, Ms. Jain has once again referred me to Claim 1 in the suit patent. She, thereafter, draws
my attention to the "background of the invention", as set out in the complete specifications of the
suit patent, already reproduced in para 2 supra. Ms. Jain points out that, in the section relating to
the "background of the invention" with respect to the suit patent, it is specifically asserted that the
tube cleaning systems in existence (i) had a single circulation pump which operated continuously,
resulting in higher power consumption, (ii) did not have any material to separate under-sized balls,
which affected the cleaning performance, and (iii) did not contain cleaning body counting systems
because of the way in which the balls were injected and collected. Having thus set out the
disadvantages of the existing tube cleaning systems, the complete specifications of the suit patent
went on to summarise the invention thus:
"Accordingly, the present invention provides a system for cleaning tubes of a shell
and tube heat exchanger using a plurality of cleaning bodies, the system comprising a
first collector positioned upstream of the shell and tube heat exchanger for holding
the cleaning bodies in a rest position, a first pump providing a circulation medium for
pumping the cleaning bodies of the first collector into the shell and tube heat
exchanger, a trap positioned downstream the shell and tube heat exchanger to arrestEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

Signing Date:04.04.2023 20:07:39 Neutral Citation Number : 2023:DHC:2334 the
cleaning bodies flowing therefrom, a counting system for counting of cleaning bodies
flown out of the trap, an electronic controller monitoring and controlling the number
of the cleaning bodies passing through the shell and tube heat exchanger, a second
collector capable of being sorting undersized cleaning bodies coming out of the trap
and a second pump positioned downstream of the second collector to collect the
undersized cleaning bodies in the second collector."
Thus, the summary of the invention in the complete specifications relating to the suit patent
specifically emphasised the existence of (i) two collectors with two separate functions, (ii) two
pumps, (iii) a Ball Trap, (iv) a counting system, (v) a sorting system, and (vi) an electronic
controller. These components were intended to achieve the object of the invention which, to the
extent relevant, may be reproduced thus:
"An object of the present invention is to provide reliable system for cleaning tubes of
a shell and tube heat exchanger having improved, performance and efficiency of shell
and tube heat exchangers.
Another object of the present invention is to provide a system for cleaning tubes of a
shell and tube heat exchanger, such that system uses batch process for injection and
collection of the cleaning bodies and ensure proper cleaning of tubes.
Yet another object of the present invention is to provide almost simultaneous
injection of the cleaning bodies at the inlet of heat exchanger.
Still another object of the present invention is to provide a system for cleaning tubes
of a shell and tube heat exchanger, which uses a split design trap for catching the
cleaning bodies and also in case of maintenance, all the parts of the ball trap can be
dismantled and cleaned easily and for the ease of maintenance and to offer a
zero-ball loss system.
Further object of the present invention is to provide an automatic sieve gate which
can be opened in case the pressure drop in the trap increases beyond the specified
limit.
Furthermore object of the present invention is to provide a system for cleaning tubes
of a shell and tube heat exchanger, which uses a simple ball sorting arrangement to
sort the undersized balls to enhance the system performance.
Neutral Citation Number : 2023:DHC:2334 One more object of the present invention
is to provide a system for cleaning tubes of a shell and tube heat exchanger, which
includes a pump to create a positive pressure positioned upstream of the collector to
inject a plurality of cleaning bodies into the inlet of the heat exchanger and an
another pump to create suction at the downstream of the ball collector to collect theEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

cleaning bodies.
Another object of the invention is to provide means for counting of the cleaning
bodies, so that required number of cleaning bodies are maintained which will help to
maintain efficiency and performance of heat exchangers always at optimum level. As
the undersized cleaning bodies will be moved to the sorting chamber, the number of
cleaning bodies (balls) circulated through the heat exchanger would reduce; therefore
it is vital to have cleaning body counting mechanism which will give an alarm in the
event that the number of cleaning bodies re-circulated is reduced below the
minimum acceptable limit."
5.9 Ms. Jain has also invited my attention to the FER dated 22nd January 2020 issued by the
Controller of Patents in response to the application of the plaintiff for registration of the suit patent,
in which the plaintiff has differentiated the prior arts D1, D2, D3, D7, D8, D11, D12 and D14, cited in
the FER, thus:
Differentiator vis-à-vis D1 Differentiator 1) The invention in D1 relates to
impregnating balls with water. The invention explains an open to air hopper holding
the balls in a dry condition and an arrangement with piston/diaphragm to remove air
from the balls. However, the document does not disclose the concept of the first ball
collector and the second ball collector as that of the present patent application.
2) In D1, the deflecting worn balls by opening the valves (referred as 52, 6 and 15 in
said document) when the ball quantity is less to a separate ball sorting chamber by
diverting the water flow through worn ball collector, tank and water outlet duct.
During normal operation the valves (52, 6 and 15) are closed. In normal course of
operation, water doesnt flow through the sorting chamber. In said system, balls and
the water are always passing through the circulation pump.
Whereas the present patent application discloses push and pull mechanism with separate pumps
and parallel arrangement Neutral Citation Number : 2023:DHC:2334 with ball sorting arrangement
without balls passing through the pumps in due course of ball collection operation and without the
need of diverting the flow to the ball sorting chamber specifically by using complicated valve
diversion mechanism. Instead the present patent application discloses ball chamber cum sorter with
the single chamber/vessel.
3) The document D1 describes circulating pump directly connected to grid device wherein water and
cleaning bodies both pass through the pump. The circulation pump continuously runs.
Whereas the present patent application discloses a separate pump connected from trap through the
counting mechanism, non-return valve, the first collector and the second collector so that ball
sorting is naturally facilitated while collecting the cleaning bodies during the collection cycle.Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

4) The document D1 does not sufficiently disclose about the design of the ball counting arrangement
and the ball counting is done continuously. As the circulation pump runs continuously and the
number of balls in circulation are less, at a given time balls are spread everywhere i.e. in condenser
tubes, conduits, pump, ball collector, ball trap etc. and therefore chances of passing more than one
number of balls at a given time are very less.
Whereas the present patent application discloses the mechanical arrangement of ball counting
system consisting of convergent and divergent arrangement so that cleaning bodies are counted
accurately. As the ball collection is a batch process and more than one ball passing through the pipe
at a time while collection gives false count, the arrangement disclosed in present patent application
is very critical for proper functioning of the ball count. In addition, the present patent application
discloses ball sorting without using additional deflecting/diverting valves by connecting the ball
sorting chamber/collector to the suction of the collection pump.
5) The document D1 describes the ball sorting collector connected to a hopper arrangement which
uses diaphragm pump to impregnate the cleaning balls. Whereas, the present patent application
uses a separate collection pump which facilitates ball collection as well as ball sorting.
6) The document D1 discloses a collector with vertical grid arrangement and acts as sorting grid and
the balls cant be rested on this grid.
Whereas, the present patent application discloses the collector with horizontally mounted
perforated disc shaped mesh which facilitates resting of sorted undersized balls and facilitates
Neutral Citation Number : 2023:DHC:2334 eventually manual removal of undersized balls.
Differentiator vis-à-vis D2 Differentiator The document D2 document fails to disclose use of
transmitter and receiver in conjunction with other elements of the present patent application such
as convergent and divergent mechanical arrangement for ball counting, use of two pumps where
balls are never in contact with the pumps and the split design ball trap.
Differentiator vis-à-vis D3 Differentiator 1) The system mentioned in D3 has no separate pump to
facilitate collection and sorting of the balls. The document only describes operation through
differential pressure however, does not specify the exact position of the pump. The system employs a
secondary cyclone disposed within a primary cyclone and uses a cyclonic effect for separating a
plurality of balls below a predetermined diameter and separating debris from the fluid. Also the
system works on differential pressure.
Whereas the present patent application discloses an arrangement with dual collector separated by a
vertical mesh/grid and uses a separate injection pump and collection pump. The ball sorting is done
efficiently by using the pressurized movement of undersized bodies to the second collector and does
not function on the cyclonic effect.
2) The document D3 does not disclose the exact arrangement for ball counting in detail and claims
that the ball counter is a magnetic device for operating with balls having an asymmetrical weightedEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

metallic core.
Whereas the present patent application discloses the mechanical arrangement of ball counting
system consisting of convergent and divergent arrangement so that cleaning bodies are counted
accurately. As the ball collection is a batch process and more than one ball passing through the pipe
at a time while collection gives false count, the arrangement disclosed in present patent application
is very critical for proper functioning of the ball count.
Differentiator vis-à-vis D7 Neutral Citation Number : 2023:DHC:2334 Differentiator 1) The
document D7 discloses an inline heat-exchanger cleaning system that uses a single pump and
complicated arrangement of multiple automated valves to divert the flow of water to inject and
collect the balls.
Whereas, the present invention discloses the simple arrangement of injecting and collecting the
balls by using two separate pumps and with less number of automated valves.
2) The present application discloses the mechanical arrangement of ball counting system consisting
of convergent and divergent arrangement so that cleaning bodies are counted accurately and the
split design ball trap provides quick dismantling for easy cleaning and offer a zero-ball loss system.
But in D7, no mention of mechanical arrangement of ball counting system and the split design ball
trap is present.
Differentiator vis-à-vis D8 Differentiator The document D8 discloses a system which uses
pressurizing and depressurizing the ball collector with the help of compressed air. It involves
draining water in every cycle.
Whereas, the present patent application discloses the arrangement of injecting and collecting the
balls by using two separate pumps. Further, the present application discloses the mechanical
arrangement of ball counting system consisting of convergent and divergent arrangement so that
cleaning bodies are counted accurately and the split design ball trap provides quick dismantling for
easy cleaning and offer a zero-ball loss system.
However, document US5447193 does not disclose the mechanical arrangement of ball counting
system and the split design ball trap as that of the present patent application.
Differentiator vis-à-vis D11 Differentiator 1) The document D11 discloses use of two pumps but the
pumps are arranged in such a way that it needs more number of automated valves and a complex
mechanism of ball injection and collection. Total five numbers of automated valves need to be
operated for every injection and collection cycle.
Whereas, the present patent application discloses the arrangement of two pumps in such a way that
only one Signing Date:04.04.2023 20:07:39 Neutral Citation Number : 2023:DHC:2334 automated
valve needs to be operated for injection and another automated valve needs to be operated forEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

collection of balls and while collection of balls it naturally facilitates the sorting of undersized balls.
2) The document CN201184768 does not disclose a mechanism of sorting of undersize balls.
Whereas, the present application discloses the mechanical arrangement of ball counting system
consisting of convergent and divergent arrangement so that cleaning bodies are counted accurately,
the first collector and the second collector and the split design ball trap provides quick dismantling
for easy cleaning and offer a zero-ball loss system.
Differentiator vis-à-vis D12 Differentiator The document D12 discloses use of two pumps but
involves a complex mechanism of ball injection and collection.
Whereas, the present patent application discloses the simple arrangement of injecting and collecting
the balls by using two separate pumps with ball sorting, ball counting arrangement and with a split
ball trap design.
Differentiator vis-à-vis D14 Differentiator The document D14 discloses use of two pumps but not in
the same manner that is disclosed in the present patent application.
Document CN201285249 discloses use of two pumps and four numbers of automated valves with
the complex arrangement.
Further, document CN201285249 does not disclose a mechanism of sorting of undersize balls.
Whereas, the present patent application discloses the arrangement of two pumps in such a way that
only one automated valve needs to be operated for injection and another automated valve needs to
be operated for collection of balls and while collection of balls it naturally facilitates the sorting of
undersized balls. Further, the present application discloses the mechanical arrangement of ball
counting system consisting of convergent and divergent arrangement so that cleaning bodies are
counted accurately, the first collector and the second collector and the split design ball trap provides
quick dismantling Neutral Citation Number : 2023:DHC:2334 for easy cleaning and offer a zero-ball
loss system.
5.10 From the aforesaid assertions, in the plaintiffs reply to the FER, by which the plaintiff sought
to claim the existence of inventive step in the suit patent, vis-à-vis the prior art documents D1, D2,
D3, D7, D8, D11, D12 and D14, Ms. Jain points out that the existence of two pumps, two collectors, a
sorting mechanism, a counting mechanism, a split trap design and a controlling controller were all
cited by the plaintiff as inventive features vis-à-vis prior art, so as to obtain the suit patent. None of
these features, she submits, are present in the defendants AFCS. She has drawn my attention, in
this context, to the following tabular statement, provided by the defendants, to differentiate the
defendants AFCS from the suit patent relating to the plaintiffs ATCS:
S. Defendants' product Alleged Invention of IN ' 118 of the No. Plaintiff The working
principle (at page 25, The drawings with the Complete Document No. 8, List ofEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

Documents Specification filed with the Plaint filed (page 84), clearly with the Plaint,
Index Part IV) show that, that the Plaintiffs patent clearly shows that the Defendants'
IN '118 has, (numberings in product has, drawing explained at page 71 to 73 of the
complete specification filed with the Plaint, Part I) Neutral Citation Number :
2023:DHC:2334
(i) a single pump two pumps, identified as first pump (1 18) and second pump (160)
(ii) a single ball collector, with a single two collectors, identified as first mesh
incapable of ball sorting collector (112) and second collector
(iii) the first collector (112) has two meshes, identified as conical mesh (114) and disc
shaped perforated mesh (116)
(iv) no counting system (since there is no ball eounting system (130) sorting and
segregation of undersized cleaning bodies), and
(v) an in-line ball trap with a completely ball trap at (120), which as per the different
design from that of IN '118 patent is a split-design ball trap
(vi) The control logic of Defendants is electronic controller (140) which designed for
single circuit and single controls the operation of the system, pump monitors number
design and is completely different ,of cleaning bodies and monitors from the
electronic controller of the signals from counting system.
Plaintiff.
5.11 The controlling logic of the defendants AFCS is, therefore, totally distinct and different from
the plaintiffs ATCS. The manner in which the plaintiff has mapped its claim itself indicates that
there are some features of the plaintiffs suit patent which are not even present in the defendants
AFCS.
5.12 Ms. Jain has also referred, in this context, to the following infringement chart which was sought
to be introduced by the plaintiff by amending para 32 of the plaint, vide IA 19484/2022, and which
the plaintiff was permitted to rely upon, by order dated 23rd November 2022 passed by this Court in
the present proceedings:
Neutral Citation Number : 2023:DHC:2334 Patented ATC System Infringing System
An Online System for cleaning tubes of An Online System for cleaning tubes at least
one Shell and tube heat of at least one Shell and tube heat exchanger using plurality
of cleaning exchanger using plurality of cleaning bodies. bodies.
Atleast one first collector (Ball Ball collector of the Infringing system Collector)
positioned upstream; for holding the cleaning bodies in rest Atleast one secondEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

collector capable of position. collecting the sorted undersized cleaning bodies coming
from the first collector.
OR Atleast one Dual collector having first chamber for holding the cleaning bodies in
rest position and second chamber for collecting the sorted undersized cleaning
bodies.
A comparison of the Infringing system's ball collector with the Plaintiffs ATC system
reveals that the Infringing system's ball collector is an exact replica of the Plaintiffs
ATC system's Ball Collector.
The dual collector includes at least one Ball collector includes sight glass sight glass
facilitating insertion and facilitating insertion and removal of removal of the cleaning
bodies in the the cleaning bodies in the first first chamber and the second chamber.
chamber and the second chamber. The first chamber of the dual collector Ball
collector has a horizontal has a horizontal perforated mesh perforated mesh
positioned at a positioned at a bottom portion to hold bottom portion to hold the
cleaning the cleaning bodies in the rest position bodies in the rest position before
before injection into the plurality of injection into the plurality of tubes Neutral
Citation Number : 2023:DHC:2334 tubes Atleast one trap (Ball trap) positioned
downstream.
As can be seen from the images shared by the Defendants, the ball trap of the
Infringing System is a Ball trap positioned downstream.
Ball trap is a split type trap. Ball trap is a split type trap. The trap encloses a
perforated mesh The trap encloses a perforated mesh. and an automatic sieve gate.
Atleast one electronic controller Atleast one electronic controller.
Ms. Jain submits that, in the above infringement chart, as drawn up by the plaintiff,
the plaintiff has cherry picked elements from various claims in the suit patent to
allege infringement by the defendant. She submits that the plaintiff has nowhere
sought to contend that the defendants AFCS had any counting system; a feature
which was specifically identified by the plaintiff as conferring advantage to the suit
patent vis-à-vis prior art.
5.13 In support of her contention, Ms. Jain relies on paras 28 and 32 of the judgment
of the Coordinate Bench in Sotefin SA7, which read thus:
"28. On the basis of commonality in the claims and elements, and the differences
noticed during mapping by the scientific advisors, counsels have taken opposing
stands. Mr Lall has argued that the differences noted by the scientific advisors qua
sub-Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

Signing Date:04.04.2023 20:07:39 Neutral Citation Number : 2023:DHC:2334
elements would not avert infringement. Mr Saikrishna and Mr Malhotra on the other
hand apply all element test to conclude that in order to determine infringement, it is
imperative for the court to reach a finding that all the essential elements of the suit
patents claimed are present in the Smart Dollies. There is no quarrel on the
proposition that all the essential elements of the suit patents claimed are required to
be found in the Smart Dollies in order to establish an infringement. In Rodi &
Wienenberger Attorney General v. Henry Showell Ltd11., the judgment relied upon
by Mr Saikrishna, this principle has been well explained, as follows:
"If the language which the patentee has used in the claims which follow the
description upon its true construction specifies a number of elements or integers
acting in a particular relation to one another as constituting the essential features of
his claim, the monopoly which he obtains is for that specified combination of
elements or integers so acting in relation to one another and for nothing else. There is
no infringement of his monopoly unless each and every one of such elements is
present in the process or article which is alleged to infringe his patent and such
elements also act in relation to one another in the manner claimed. The law as to the
principles of construction of claims in specifications in the modern form seems to me
so laid down clearly and authoritatively in the judgment of Upjohn, L.I. in C. Van der
Lely NV v. Bamfords Ltd. [C. Van der Lely NV v. Bamfords Ltd.12,], which was
approved by the majority of the House of Lords on appeal [C. Van Der Lely NV v.
Bamfords Ltd.13] ."
*****
32. This aforenoted decision is strongly relied upon by Mr Saikrishna to contend that there is no
infringement in the instant case, as all elements of Claim 1 are not found in the infringing product.
In the opinion of the court, the afore noted legal proposition canvassed by Mr Saikrishna is not
entirely correct, although there is some merit in this submission. For patent infringement analysis,
comparison of elements of the suit patent's claims is to be done with the elements/claims of the
infringing product. On comparison, there can be a case of non-literal infringement, where each and
every component of patent specification is not found in the infringing products. In other words, all
the elements of a claim may not entirely correspond in the infringing product, as has been pointed
by the experts, in the instant case. However, it does not inevitably mean that there can be no
infringement. It is the pith and marrow of the invention claimed that is required to be looked into,
and we do not have to get lost 1966 RPC 441 1961 RPC 296 1963 RPC 61 Neutral Citation Number :
2023:DHC:2334 into the detailed specifications and do a meticulous verbal analysis which the
parties have engaged into the court."
Ms. Jain submits that the doctrine of equivalents would not apply in the present case as the plaintiff
did not identify any substitute by the defendant, substituting any of the essential elements of the
claim in the suit patent.Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

5.14 Apropos Mr. Valsangkars claim of copyright infringement, Ms. Jain submits that the claim
was completely bereft of necessary particulars such as specification of the author of the copyright
etc. Nonetheless, she submits, on instructions, that her client is willing not to make use of the
photographs in which the plaintiff claims copyright.
5.15 Predicated on these submissions, Ms. Jain prays for rejection of the plaintiffs application
under Order XXXIX Rules 1 and 2 of the CPC.
6. Case of plaintiff in rejoinder 6.1 Mr. Valsangkar submits in rejoinder, on the aspect of misuse of
confidential material of the plaintiff, that the defendant had failed to show any manner in which it
had obtained access to the plaintiffs confidential drawings except as provided by the plaintiff.
Equally, he submits, the defendant has failed to show that the said confidential drawings were in the
public domain, so as to be entitled to the benefit of Clause 4 of the Confidentiality Agreement dated
4th August 2017.
6.2 Mr. Valsangkar further submits that, having itself applied for Neutral Citation Number :
2023:DHC:2334 registration of the design for the inland Ball Trap, the defendant was estopped
from contending that the design was common to the trade or, therefore, not registrable. In any case,
as the plaintiff, in its claim in the suit patent, merely claimed the existence of a Ball Trap, the
distinction that the defendants attempt to distinguish between a split trap and a Y type Ball Trap
was irrelevant.
Analysis
7. I have heard learned Counsel for the parties and applied myself to the rival submissions made at
the Bar as well as the material on record. Lengthy though the arguments at the Bar were, the issues
in controversy are elementary, and capable of immediate resolution. I proceed, therefore, to address
the various issues raised by Mr. Valsangkar in the present case, seriatim, as under.
8. Re. allegation of misuse of confidential information 8.1 Mr. Valsangkars first contention is that
the defendants, particularly Defendants 3 and 4, misused the confidential information, in the form
of drawings relating to the plaintiffs ATCS, which were in their possession, both to seek a patent in
respect of the inline ball trap as well as to fabricate the AFCS which, according to Mr. Valsangkar,
infringes the suit patent.
8.2 At the very outset, I may note that it cannot possibly be alleged that the defendants had, in any
surreptitious fashion, come into possession of the confidential information of the plaintiff. The
e-mail correspondences cited in para 4.2 supra make it clear that Defendants Neutral Citation
Number : 2023:DHC:2334 3 and 4 came into possession of the plaintiffs confidential information
partly through e-mails addressed by the plaintiff itself to Defendants 3 and 4 and partly through
e-mails addressed by Voltas. If, in sharing the said information, Voltas violated any Confidentiality
Agreement with the plaintiff, the defendants, quite obviously, are not to blame. The clock could not
have been put back. Knowledge, once learned, cannot be unlearned. Indeed, Mr. Valsangkar, quite
fairly, did not dispute the fact that the manner in which the defendants came into possession of theEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

plaintiffs confidential information could not strictly be faulted.
8.3 Mr. Valsangkars contention is, however, that Defendants 3 and 4, through Defendants 1 and 2,
proceeded, having come into possession of the confidential drawings and information, of the
plaintiff, to misuse the said information so as to fabricate the AFCS and seek a patent for the inline
ball trap.
8.4 There is no material, whatsoever, to support the said allegation. To repeated queries from the
Court as to the basis on which the plaintiff was seeking to allege that the AFCS had been designed by
poaching on the confidential information of the plaintiff, the only submission that Mr. Valsangkar
offers is that, the coincidences were too many. He seeks to point out that, within less than a month
of coming into possession of the confidential information, of the plaintiff, Defendant 3 resigned
from the Carrier and, within 15 days thereof, applied for a patent for the Inline Ball Trap. The AFCS
was also fabricated, by the defendants, within a short span of time thereafter. Given the fact that the
defendants did not have prior history or experience in the matter of fabrication of cleaning systems,
Neutral Citation Number : 2023:DHC:2334 Mr. Valsangkar would seek to draw an inference that
the defendants had misused the confidential information of the plaintiff, available with them.
8.5 Ms. Sneha Jain has disputed the fact that the defendants did not have any prior experience in
fabricating air conditioning or heating systems. At a prima facie stage, it is not necessary for this
Court to travel down that path. It is axiomatic, in law, that suspicion, howsoever grave, is no
substitute for proof. Claims in commercial suits need evidence to back them up. The mere fact that,
very shortly after coming into possession of the confidential drawings of the plaintiff, Defendant 3
left Carrier, or applied for a patent for the Inline Ball Trap, cannot allow the Court to hold, even
prima facie, that Defendant 3 had misused the plaintiffs confidential drawings. The allegation of
misuse of confidential information cannot, therefore, be sustained, prima facie.
9. Re. allegation of patent infringement 9.1 Apropos the allegation of patent infringement, one needs
merely to refer to Claim 9 in the suit patent, which already stands reproduced hereinabove and
which delineates, explicitly, the essential features of the claimed invention. It has been set out, in the
said claim, in clear and unequivocal terms, that the claimed invention was a system comprising,
inter alia, of at least two collectors, two pumps, one trap, one sorting system and one counting
system.
9.2 Ms. Jain contends, and Mr. Valsangkar does not dispute, that, in the AFCS, there was in fact
only one pump, no sorting system and no Neutral Citation Number : 2023:DHC:2334 counting
system. Mr. Valsangkar sought to invoke, to contest this submission, the doctrine of pith and
marrow, for which purpose he has cited the decisions of the Single Bench and the Division Bench in
F.M.C. Corporation6 and F.M.C. Corporation8, the decision of a learned Single Judge in Sotefin7
and the decisions in Saltman2 and Seager3. "Pith and marrow", I may note, a mere felicitous
expression used for the principle, to which Ms. Jain acquiesces, that patent infringement requires
copying only of the essential features of the suit patent; its pith and marrow, as it were. Mr.
Valsangkar contends that the incidental differences between the AFCS and ATCS notwithstanding,
the pith and marrow of the ATCS stand replicated in the AFCS; ergo, patent infringement hasEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

occurred.
9.3 Learned Counsel being ad idem on the legal principle, the need to refer to these decisions stands
obviated. The question of applying the doctrine does not, however, arise in the present case as the
plaintiff has, in explicit terms, in the complete specifications of the suit patent, set out, precisely, the
essential features of the claimed invention. The manner in which claims in a patent are to be
construed has been thus explained by the Supreme Court in Bishwanath Prasad Radhey Shyam v.
Hindustan Metal Industries14:
"43. As pointed out in Arnold v. Bradbury15 the proper way to construe a
specification is not to read the claims first and then see what the full description of
the invention is, but first to read the description of the invention, in order that the
mind may be prepared for what it is, that the invention is to be claimed, for the
patentee cannot claim more than he desires to patent. In Parkinson v. Simon16 Lord
Esher, M.R. enumerated that as far as possible the claims must be so construed as to
give an effective meaning to each of them, but the specification and the claims must
be looked at and construed together.
(1979) 2 SCC 511 (1871) 6 Ch A 706 (1894) 11 RPC 483 Neutral Citation Number :
2023:DHC:2334
44. The learned trial Judge precisely followed this method of construction. He first
construed and considered the description of the invention in the provisional and
complete specifications and then dealt with each of the claims, individually.
Thereafter, he considered the claims and specifications as a whole, in the light of the
evidence on record."
(Emphasis supplied) The principle was enunciated, with even greater precision, in the judgement of
the Division Bench of this Court authored by S. Ravindra Bhat, J. (as he then was), in the following
passage from Merck Sharp & Dohme Corporation v. Glenmark Pharmaceuticals17 "48. At this
juncture, the Court notes that:-
"the construction of claims is not something that can be considered in isolation from
the rest of the specification, Claims are intended to be pithy delineations of the scope
of monopoly, and they are drafted in light of the much more detailed text of the
description. A specification must be read as a whole, just as any document is. It must
moreover be read as having been addressed to a person acquainted with the
technology in question. So it must take account of that person's state of knowledge at
the time."
(see, Cornish, Llewelyn and Aplin, Intellectual Property, Seventh Ed, Sweet and Maxwell, pages
182-3)."Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

(Emphasis supplied) Dichotomizing the claims and the accompanying specifications is, therefore,
contrary to the most fundamental canons of patent law.
9.4 Claim 1 in the suit patent has been reproduced in para 3 supra. It is worded in explicit and
unequivocal terms. It envisages "at least one first collector positioned upstream", "at least one first
pump", "at least one trap", "at least one counting system", "at least one second collector", "at least
one second pump" and "at least one electronic controller". These ingredients - or integers - of the
claim stand clearly reiterated in the Summary of the Invention provided in the 2015) 63 PTC 257
(Del-DB) Neutral Citation Number : 2023:DHC:2334 complete specifications, which postulates that
the ATCS "provides a system for cleaning tubes of a shell and tube heat exchanger using a plurality
of cleaning bodies, the system comprising a first collector positioned upstream of the shell and tube
heat exchanger for holding the cleaning bodies in a rest position, a first pump providing a
circulation medium for pumping the cleaning bodies of the first collector into the shell and tube heat
exchanger, a trap positioned downstream the shell and tube heat exchanger to arrest the cleaning
bodies flowing therefrom, a counting system for counting of cleaning bodies flown out of the trap, an
electronic controller monitoring and controlling the number of the cleaning bodies passing through
the shell and tube heat exchanger, a second collector capable of being sorting undersized cleaning
bodies coming out of the trap and a second pump positioned downstream of the second collector to
collect the undersized cleaning bodies in the second collector". The functional necessity of these
components of the ATCS also stands explained in the complete specifications, which envisages
"injection and collection of the cleaning bodies", "almost simultaneous injection of the cleaning
bodies at the inlet of the heat exchanger", "a simple ball sorting arrangement to sort the undersized
balls and enhance the system performance", "a pump to create a positive pressure positioned
upstream of the collector to inject a plurality of cleaning bodies into the inlet of the heat exchanger
and another pump to create suction at the downstream of the ball collector to collect the cleaning
bodies", and, as "another object of the invention, ... means for counting of the cleaning bodies so
that required number of cleaning bodies are maintained which will help to maintain efficiency and
performance of heat exchangers always at optimum level". The complete specifications go on, even
more unequivocally, to declare that "as the Neutral Citation Number : 2023:DHC:2334 undersized
cleaning bodies will be moved to the sorting chamber, the number of cleaning bodies (balls)
circulated through the heat exchanger would reduce, therefore it is vital to have cleaning body
counting mechanism which will give an alarm in the event that the number of cleaning bodies
re-circulated is reduced below the minimum acceptable limit". Each component was, therefore, an
integral and unalienable part of the ATCS.
9.5 Whether, therefore, one proceeds as per the claims in the suit patent, or the summary of the
invention as provided by the plaintiff itself in the complete specifications of the suit patent, two
collectors having two separate functions, two pumps, a Ball Trap, a counting system, a sorting
system and an electronic controller are identified and underscored as the essential features of the
suit patent. In an infringement proceeding, the complete specifications of the suit patent are
sacrosanct. Once the plaintiff has itself identified these features as essential to the suit patent, it
stands estopped from contending that they are not essential, so as to substantiate the case of
infringement that it seeks to make out against the defendant. Not only do the complete
specifications of the suit patent identify these essential features; as Ms. Jain correctly points out, inEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

response to the FER which was issued at the time when the plaintiff applied for grant of the suit
patent, and the various prior arts (D-1), the plaintiff had emphasised the existence of two pumps, a
counting system, and a sorting system as the essential features which distinguished the claim in the
suit patent from prior art. Patents are available only for inventions, and inventions have, statutorily,
to incorporate an inventive step vis-à-vis prior art. The inventive step is, therefore, the very raison
d'etre of the patent. The plaintiff is bound by what it Neutral Citation Number : 2023:DHC:2334
itself claimed to be inventive, in the ATCS, vis-à-vis prior art. No occasion arises, therefore, for the
Court to hyper analyse the suit patent and discern, for itself, its essential features.
9.6 It is also clear that the entire manner of working of the ATCS, as conceptualized and envisioned
by its inventor, involves a detailed process of cleaning the tubes of the A/c system, which requires an
integrated working of all these components. None of them is, therefore, dispensable. Ms. Jain is,
therefore, correct in her submission that the very method of working of the AFCS, which does not
require these components, is different from that of the ATCS, so that there can be no question of
infringement of the latter by the former.
9.7 The AFCS is, therefore, prima facie dissimilar both to Claim 1 and Claim 9 in the suit patent.
9.8 The allegation of patent infringement too, therefore, is, prima facie, devoid of substance.
10. Inasmuch as the prayers in the plaint seek injunctive reliefs qua the entire AFCS of the
defendants, I am not, at this prima facie stage, proceeding to examine the aspect of application of a
patent, by the defendants, for the Inland Ball Trap. The defendants claim that the Ball Trap used in
the AFCS and that used in the ATCS are different. Mr. Valsangkar, while disputing the contention,
submitted that, as the claim of infringement, in the suit, was qua the whole AFCS of the defendants,
the difference, if any, between the Ball Traps was not of much consequence. As I have found the
AFCS to be, prima facie, not Neutral Citation Number : 2023:DHC:2334 infringing the suit patent,
no prima facie findings need be returned on the distinction, if any, between the two Ball Traps.
11. Apropos the aspect of copyright infringement, Ms. Jain has, without prejudice to her contentions
in that regard, undertaken, on behalf of her client, not to use the allegedly infringing pictures
reproduced in para 4.9 supra, pending disposal of the suit. The defendants shall remain bound
thereby.
Conclusion
12. For the aforesaid reasons, these applications are disposed of thus:
                                  (i)     IA 8575/2022 is dismissed.
                                  (ii)    IA 10931/2022 is allowed.
(iii) The defendants are, however, directed to remove, within a week of uploading of this judgement
on the website of this Court, the photographs reproduced in para 4.9 supra, from all physical and
electronic locations.Ecomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

13. The Court appreciates the manner in which Ms. Sneha Jain, the young associate of Mr.
Saikrishna Rajagopal, argued this matter with considerable felicity, opposite a seasoned Mr.
Valsangkar.
C. HARI SHANKAR, J.
MARCH 20, 2023 rb/dsnEcomax Solutions Pvt. Ltd. vs Energeo Building Solutions Llp & Ors. on 20 March, 2023

