Bihar Electricity Supply Code, 2007
BIHAR
India
Bihar Electricity Supply Code, 2007
Rule BIHAR-ELECTRICITY-SUPPLY-CODE-2007 of 2007
Published on 31 December 2007• 
Commenced on 31 December 2007• 
[This is the version of this document from 31 December 2007.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Electricity Supply Code, 2007Published vide Notification No. BERC/Regl-6/2006/529, dated
31st December, 2007 in Bihar Gazette (Extraordinary) dated the 10th January, 2008Bihar
Electricity Regulatory CommissionNotification No. BERC/Regl-6/2006/529, the 31st December,
2007. - In exercise of power conferred by Section 181(1) and 181(2) read with Section *40 (sic ?) and
43(1), Section 44, Section 46, Section 47(4), Section 56 of the Electricity Act, 2003 (36 of 2003) and
all powers enabling it in this behalf and also in compliance of the Ministry of Power, Government of
India's (i) Notification No. S.O. 790(E) dated 8th June, 2005 issuing "Electricity (Removal of
difficulties) Order, 2005" for "Inclusions of measures to control theft of electricity in Electricity
Supply Code", and (ii) Notification No. S.O. 798(E) dated 9th June, 2005 issuing Electricity
(Removal of Difficulties) Eighth Order, 2005 for obtaining supply of electricity at single point from
the distribution licensee by the Co-operative Group Housing Societies or by any person for their
members or employees residing in the same premises, the Bihar Electricity Regulatory Commission
hereby makes the following Electricity Supply Code to govern supply and retail sale of electricity by
the licensees and procedure thereof, the powers, functions, and obligations of the licensees and the
rights and obligations of the consumers and matter connected therewith and incidental thereto.
Chapter 1
General
1.
1. Short Title, Extent and Commencement.
(1)This Code may be called the "Bihar Electricity Supply Code, 2007".(2)The Code shall come into
force from the date of its publication in the Official Gazette.(3)It shall extend to the whole State of
Bihar.(4)It shall apply to all distribution licensees engaged in the business of supplying electricity as
covered under Section 14 of the Electricity Act, 2003 and the consumers of electricity.1.2MechanismBihar Electricity Supply Code, 2007

for Review of Bihar Electricity Supply Code.(1)The Commission shall constitute an Electricity
Supply Code Review Panel (hereinafter called Review Panel) to review this Code on regular basis.
The review panel shall consist of such number of members, as the Commission may consider
necessary and adequate, to be appointed by the Commission including persons representing the
following interests.(a)Each Distribution Licensee of the State;(b)State Transmission Utility (STU)
and Transmission licensees;(c)LT consumers, HT consumers, EHT consumers, their associations
and interested groups;(d)Generating Company (by rotation if more than one);(e)Any other person
or interested group or organisation as the Commission may think fit.(2)The Commission shall
appoint one of the member amongst the above members as Chairman of the review panel. The
Commission shall also nominate an officer from the Commission to act as Member-Secretary to the
review panel. The Commission shall provide all the required support, administrative or
otherwise.(3)All members of the review panel shall be appointed for a period of two years.(4)The
review panel shall meet at least once every six (6) months. The Member-Secretary of review panel
shall convene meetings with the approval of the Chairman. He shall send meeting notice along with
agenda to all members ten days in advance.(5)The Chairman, Member-Secretary and all Members
shall be part-time officers of the review panel.They shall draw their salaries, allowances and
perquisites from their respective parent organizations.(6)The Member-Secretary of the review panel
shall send the proceedings of the meetings of the review panel to all the members of the panel and to
the Commission within 15 days of the meetings.(7)Any Licensee, Generating Company, consumer,
Industry or any interested parties or business organization may send their suggestion and requests
for revision of Code to the Member-Secretary of the review panel, the difficulties experienced in
implementation of code may also be communicated to the review panel. All these representations
shall be recorded and discussed in the review panel meetings. The Member-Secretary shall be the
custodian of the entire correspondence relating to the review panel.(8)The Commission may amend
the Electricity Supply Code suo-motu or on the recommendations of the review panel. However,
before any amendment is made in the Code, comments on the proposed changes shall be obtained
from all the Distribution Licensees, State Transmission Utility (STU),Transmission Licensees and
public.(9)A notice of the gist of amendment made in the Electricity Supply Code shall be published
by the Licensee in at least two newspapers having wide circulation in the area of supply stating that
copies of the Amended Electricity Supply Code are available for purchase in the offices mentioned in
clause (10) below.(10)Copies of the 'Bihar Electricity Supply Code' as duly amended from time to
time shall be kept at area offices, regional offices, circle offices, division and subdivision offices,
distribution centres of the licensees and such other offices as may be specified by the Commission.
The licensee shall also post it on their websites.
Chapter 2
2.
1. Definition.
- In this Code, unless it is repugnant to the context:(a)'Act' means The Electricity Act, 2003 (No. 36
of 2003)(b)'Agreement' with its grammatical variations and cognate expressions means anBihar Electricity Supply Code, 2007

agreement entered between the licensee and the consumer under this Code.(c)'Apparatus' means
electrical apparatus and includes all machines, fittings, accessories and appliances in which
conductors are used.(d)'Area of Supply' means the area within which a Licensee is authorized by his
licence to supply electricity.(e)'Authorised officer' means the officer authorized in this behalf by the
State Government under Section 135 of the Act.(f)'Breakdown' means an occurrence relating to the
equipment of the electric energy supply system including electrical line that prevents its normal
functioning.(g)'Code' means the Bihar Electricity Supply Code as in force from time to
time.(h)'Commission' means the Bihar Electricity Regulatory Commission constituted under Section
82 of the Electricity Act, 2003.(i)'Conductor' means any wire, cable, bar, tube, rail or plate used for
conducting electrical energy and so arranged as to be electrically connected to a
system.(j)'Connected Load' means aggregate of the manufacturer's rating of all energy consuming
devices, in the consumer's premises, which can be simultaneously used. This shall be expressed in
kW, kVA or HP units and shall be determined as per the procedure laid down in clauses 6.37 to 6.42
on 'Rating of Installations' in this Code. [If the rating of the energy consuming device is in KVA, the
same may be converted to KW by multiplying KVA with power factor of 0.9 and if the rating of
energy consuming device is in HP it shall be convered into KW by multiplying HP by 0.746.] [Added
by Notification No. 603, dated 18 August, 2010.](k)'Consumer' means any person who is supplied
with electricity for his own use by a licensee or the Government or by any other person engaged in
the business of supplying electricity to the public under this Act or any other law for the time being
in force and includes any person whose premises are for the time being connected for the purpose of
receiving electricity with the works of a licensee, the Government or such other person, as the case
may be;(i)'Low Tension Consumer (LT Consumer)' if he obtains supply from the licensee at Low
Voltage.(ii)'High Tension Consumer (HT Consumer)' if he obtains supply from the licensee at High
Voltage.(iii)'Extra High Tension Consumer (EHT Consumer)', if he obtain supply from the licensee
at Extra High Voltage.(l)'Consumer's installation' means any composite electrical unit including
electric wires, fittings, motors and apparatus, portable and stationary, erected and wired by or on
behalf of the consumer at the consumer's premises.(m)'Contract demand' means the maximum
Load in kW, kVA or HP, as the case may be, agreed to be supplied by the licensee and contracted by
the consumer and mentioned in the agreement.(n)'Cut-out' means any appliance for automatically
interrupting the supply or flow of electrical energy through any conductor when the current rises
above a predetermined quantum, and shall also include fusible cut-out.(o)'Date of commencement
of supply' means the day immediately following the date of expiry of a period of one month in case
of LT consumers and three months in case of HT or EHT consumer from the date of intimation to an
intending consumer of the availability of power or the date of actual availing of supply by such
consumer, whichever is earlier.(p)'Demand Charge' for a billing period means a charge levied on the
consumer based on the contract demand or maximum demand and shall be calculated as per the
procedure provided in the Tariff Order of the Commission.(q)'Distribution main' means the portion
of any main with which a service line is, or is intended to be, connected.(r)'Distribution System'
means the system of wires and associated facilities between the delivery points on the transmission
lines or the generating station connection and the point of connection to the installation of the
consumers.(s)'Earthed' or 'connected with earth' means connected with the general mass of earth in
such manner as to ensure at all times an immediate discharge of energy without danger.(t)'Electric
line' means any line which is used for carrying electricity for any purpose and includes-(i)any
support for any such line, that is to say, any structure, tower, pole or other thing in, on, by, or, fromBihar Electricity Supply Code, 2007

which any such line is or may be, supported, carried or suspended; and(i)Generated, transmitted or
supplied for any purpose, or(ii)Used for any purpose except the transmission of a message.(ii)any
Apparatus connected to any such line for the purpose of carrying electricity;(u)'Electrical Inspector'
or 'Inspector' means an Electrical Inspector appointed under sub-section 1 of Section 162 of the
Electricity Act, 2003 (36 of 2003), and also includes Chief Electrical Inspector.(v)'Energy' means
electrical energy-(w)'Energy charge' refers to a charge levied on the consumer based on the quantity
of electricity (units in kWh or kVAh as per tariff) supplied.(x)'Extra High Voltage (EHV)' or 'Extra
High Tension (EHT)' means the voltage, which exceeds 33,000 volts under normal conditions
subject, however, to the percentage variation allowed under the Indian Electricity Rules,
1956.(y)'Group User' means Co-operative Group Housing Society, registered under Bihar
Co-operative Societies Act or a person representing his employees.(z)'High Voltage (HV)' or 'High
Tension (HT)' means the voltage higher than 440 volts but which does not exceed 33,000 volts,
under normal conditions subject, however, to the percentage variation allowed under the Indian
Electricity Rules, 1956.(aa)'Initial period of agreement' means the period of one year in case of LT
supply and two years in case of HT supply starting from the date of commencement of supply. The
initial period of agreement shall continue till the end of the month, in which the end date of the
one/two years period expires.(bb)'Installation' means any composite electrical unit used for the
purpose of generating, transforming, transmitting, converting, distributing or utilizing electrical
energy.(cc)'Licensed Electrical Contractor' means a contractor licensed under Rule 45 of the Indian
Electricity Rules, 1956.(dd)'Low Voltage (LV)' or 'Low Tension (LT)' means the voltage, which does
not exceed 250 volts at single phase and 433 volts at three phase under normal conditions subject,
however, to the percentage variation allowed under the Indian Electricity Rules, 1956.(ee)'Maximum
demand' means the maximum demand of a consumer's system at a point of supply during a month
or a specified billing period) which is twice the largest number of kilo volt-ampere-hours supplied to
the consumer at that point of supply during any consecutive 30 minutes in the month (or a specified
billing period). (This is a measure of the peak power requirement of the consumer, depends on the
capacity of the licensee's equipment and is related to the initial capacity cost of the licensee's
system).(ff)'Meter' means an equipment used for measuring electrical quantities like energy in kWh
or kVAh, maximum demand in kW or kVA, reactive energy in kVAR etc. including accessories like
Current Transformers (CT) and Potential Transformers (PT), including cables, where used in
conjunction with such meter and any enclosure used for housing or fixing such meter or its
accessories and any devices like switches or MCB/load limiter or fuses used for protection and
testing purposes.(gg)'Occupier' means the owner or person in occupation of the premises where
electrical energy is used or proposed to be used.(hh)'Overhead line' means any electric supply-line,
which is placed above ground and in the open air but excluding live rails of traction
system.(ii)'Power Factor' means the average monthly power factor and shall be the ratio expressed
as a percentage of the total kilowatt hours to the total kilovolt ampere hours supplied during the
month; the ratio being rounded off to two decimal figures, 5 or above in the third place of decimal
being rounded off to the next higher figure in the second place. In case kWh or kVAh reading is not
available then power factor shall be calculated on the basis of kVARh reading, if the meter has
kVARh recording feature in the meter.(jj)'Premises' includes any land, building or
structure.(kk)'Service-line' means any electric supply-line through which electrical energy is, or is
intended to be, supplied:(i)to a single consumer either from a distribution main or immediately
from the supplier's premises, or(ii)from a distribution main to a group of consumers in the sameBihar Electricity Supply Code, 2007

premises or in adjoining premises supplied from the same point of the distribution main.(ll)'System'
means an electrical system in which all the conductors and apparatus are electrically connected to a
common source of electric supply.(mm)'Theft of Electricity' has the meaning assigned to it under
Section 135 of the Electricity Act, 2003.2.2All other expressions used herein although not
specifically defined herein, but defined in the Act, shall have the meaning assigned to them in the
Act. The other expressions used herein but not specifically defined in this Code or in the Act but
defined under any law passed by the Parliament applicable to electricity industry or stated in the
tariff order shall have the meaning assigned to them in such law. Subject to the above the expression
used herein but not specifically defined in this Code or in the Act or any law passed by the
Parliament shall have the meaning as is generally assigned in the electricity industry.In case of any
inconsistency between the Code and Tariff Order in force, the provisions and meanings contained in
Tariff Order in force at that time shall prevail.
Chapter 3
System of Supply and Classification of Consumers
System of Supply
3.
1.
The declared frequency of the alternating current (AC) shall be 50 cycles per second or Hz. The
Licensee shall as far as possible supply and maintain uninterrupted power supply in a frequency
band between 49.02 Hz to 50.5 Hz stipulated in the Indian Electricity Grid Code issued by the
Central Electricity Regulatory Commission.3.2The declared voltage of AC supply shall be as follows
:(a)Low Tension (LT)(i)Single Phase : 230 volts between phases and neutral.(ii)Three Phase : 400
volts between phases.(b)High Tension (HT)- three Phase: 11 kV or 33 kV between phases.The
existing 6.6 kV systems of supply, if any, shall be converted into 11 kV or 132 kV system of supply
respectively in a time bound programme.(c)Extra High Tension (EHT) - Three Phase : 132 kV or
220 kV between phases.For existing Railway Traction-Single/Two-phase/Three phase on
25kV/132kV3.3The licensee shall design and operate the distribution system in conjunction with the
transmission systems. The licensee shall maintain voltage at the point of commencement of supply
to the consumer within the limits with reference to the declared voltage as stipulated
hereunder;(a)Low voltage : (+) 6%; and (-) 6%(b)High voltage : (+) 6%; and (-) 9%(c)Extra high
voltage : (+) 10%; and (-) 12.5%Voltage of Supply to Consumers3.4The supply voltage for different
contract demands shall normally be as follows, or as otherwise specified in the Tariff order.
Supply Voltage Minimum Contract Demand Maximum Contract Demand
230 volts  Upto 5 kW
400 volts 5 kW & above 70 kW
11 kV 75 kVA 1500 kVABihar Electricity Supply Code, 2007

33 kV 1000 kVA 10000 kVA
132 kV 7500 kVA  
L.T. Agriculture and L.T. Industrial consumer of load between 2kW & 5kW have option to avail
supply at 230 volts or 400 volts.Classification of Consumers.3.5The classification of consumers,
tariff and conditions of supply applicable to each category shall be as fixed by the Commission from
time to time in the tariff order or otherwise.
Chapter 4
New Service Connection
Licensee's Obligation to Supply
4.
1.
The Licensee shall on an application by the owner or occupier of any premises, located in his area of
supply, give supply of electricity to such premises within one month after receipt of completed
application and requisite charges:Provided where such supply requires extension of distribution
mains, or commissioning of new sub-stations, the distribution Licensee shall supply the electricity
to such premises immediately after such extension or commissioning or within such period as
specified by the Commission in clause 4.80 of the code:Provided also in case of application for
supply from a village or hamlet or area wherein no provision for supply of electricity exists, the
Commission shall extend the time period for provision of supply appropriately on a case-to-case
basis :Provided that if there are arrears of electricity dues on a premises, a new connection shall not
be released to a new applicant/or the old consumer on the same premises, if-(i)The applicant (being
an individual) is an associate or relative (as defined in Section 2 and 6 respectively of the Companies
Act, 1956) of the defaulting consumer,(ii)Or where the applicant being a company or body corporate
or association or body of individuals, whether incorporated or not, or artificial juridical person, is
controlled, or having controlling interest in the defaulting consumer, provided, the Licensee shall
not refuse electric connection on this ground, unless an opportunity to present his case is provided
to the applicant and a reasoned order is passed by an officer as designated by the licensee.Licensee's
Obligation to Extend the Distribution System4.2The Licensee shall have obligation for ensuring that
its distribution system is upgraded, extended and strengthened to meet the demand for electricity in
its area of supply. Wherever the existing transformation capacity is loaded upto 80% of its capacity,
the licensee shall prepare a scheme for augmentation of such transformation capacity.4.3The
Licensee shall meet the cost for strengthening/upgradation of the distribution system to meet the
demand of the existing consumers as well as future growth in demand through its annual revenues
or funds arranged by the licensee and this cost shall be allowed to be recovered from the consumers
through tariff subject to prudence check by the Commission.4.4In all cases of new connections, the
consumer shall bear the Service Connection Charges, that is the cost of service connection from the
Distribution Mains to the point of supply as approved by the Commission from time to time.4.5For
uniformity and simplification in calculating the actual cost of extension, the licensee shall prepare aBihar Electricity Supply Code, 2007

ready reckoner to show the per-unit material cost of LT line, HT line, substation of different
capacities etc. The licensee may update the ready reckoner every year, and after every update,
submit the same to the Commission for information.4.6In case the connected/contracted load of
any new connection is projected to be 60 kW or more a separate transformer of adequate capacity
shall be installed at consumer's cost. The space/room with easy access required for housing the
transformer, sub-station, switch gears, meters and panels shall be provided by the consumer, free of
cost, for which rent or premium shall not be payable by the licensee.4.7The service
connection/extension of distribution mains, notwithstanding that it has been paid for by the
consumer, shall be the property of the licensee. The licensee shall maintain it at its cost and shall
also have the right to use the same service connection/extension for supply of energy to any other
person but such extension or service connection should not adversely affect the supply to the
consumer who paid for the extension of the distribution supply network.4.8When the licensee
completes the work of extension of distribution mains and is ready to give supply, the licensee shall
serve a notice on the consumer to take power supply within one month in case of LT and three
months in case of HT or EHT. If the consumer fails to avail supply within the notice period, the
agreement shall come into force from the day following the end of the notice period, and thereafter
the consumer shall be liable to pay charges as applicable, as per the agreement.Service
Connection/Extension Work Got Done by Consumers4.9The consumer shall have an option to get
the work of drawing of service line from the licensee's distribution mains up to his premises as per
the estimates and layout approved by the licensee through a 'C' or higher-class licensed electrical
contractor, and the work of extension of EHT and HT line, distribution or HT substation and LT line
through an 'A' class contractor as per the estimates and layout approved by the licensee. In such case
the consumer himself shall procure the materials. The material should, conform to relevant BIS
specification or its equivalent and should bear ISI mark wherever applicable.The licensee may ask
for documentary evidence to verify the quality of materials, used. The consumer shall be required to
pay the supervision charges as approved by the Commission on the cost of works as per the
estimates approved by the licensee. The rates of the materials shall be available in the ready
reckoner (refer clause 4.5).4.10The consumer shall get the work done within the time frame as
provided in clause 4.80. If he fails and needs more time he shall represent to the licensee with
reasonable ground for extension of time.New Connection4.11Application for a new connection of
electricity supply or for enhancement/ reduction of load shall be made in duplicate in the
appropriate prescribed form, copies of which shall be available free of cost from the local office of
the licensee. The format of the application forms is provided in Annexure-1 (LT connection) and
Annexure-2 (HT Connection). The licensee shall post the application forms on its website.
Photocopies of a blank Form or Form downloaded from the website of the licensee may also be used
by the applicant and shall be accepted by the licensee. Any assistance or information required in
filling up the form should be given to the consumer by the licensee.The Licensee may modify the
structure of the formats if so required to meet any requirement that may arise in consequence of the
provision of this Code so that the formats are consistent with the Act, prevailing Rules, Regulations
and provisions of the Code.4.12All information relating to procedure, fees, designated officers for
releasing new connection shall be displayed on the notice boards of Subdivision office, Divisional,
Circle and Area offices of licensee. Public information counters for new forms, filing, and
disseminating information status in the above offices, with computerized facilities in all towns with
a population greater than 10 lakhs shall be made operational within a time frame of oneBihar Electricity Supply Code, 2007

year.4.13The consumer shall furnish, along with the application form, attested true copies of
following documents (details at Annex-1 & Annex-2). The licensee may ask for the original
documents, from the consumer, if required, for verification.(a1)Proof of ownership of the premises
in the form of registered sale deed or partition deed or succession or heirship certificate or deed of
last will,ORProof of occupancy such as valid power of attorney or latest rent receipt or valid lease
deed or rent agreement or copy of allotment order issued by the owner of the property,ORIn case of
supply for agriculture/irrigation pump set, the copy of Land Revenue receipt 'khata nakal' giving the
Revenue Plot No. 'Khasara/khata' number of the field within which the supply is required.(a2)In
case of tenant permission of landlord along with proof of ownership of the
premises.(b)Approval/permission of the local/statutory authority, if required under any
law/statute.(c)In case of a partnership firm, partnership deed, authorization in the name of the
applicant for signing the requisition form and agreement.(d)In case of a Public or Private Limited
Company, Memorandum and Articles of Association and Certificate of Incorporation together with
an authorization in the name of the applicant for signing the requisition form and agreement.(e)In
case of application for power supply to stone crushers, stone polishing and hotmix plants, the
following additional information shall also be furnished.(e1)Documentary evidence from the
department concerned to show that he will be able to take requisitioned quantum of power supply
for at least two years, or as specified in the agreement.(f)His permanent address.The Consumer
shall also intimate whether the service line and extensions, if any, shall be laid by the consumer or
the licensee.4.14(a)The Licensee shall verify the application and the attached documents at the time
of receipt of application. Written acknowledgement shall be issued on the spot. If the application is
complete, otherwise it should mention the shortcomings, if the application is incomplete.(b)No
application for the new connection for an electrified area shall be refused under any circumstances if
it complies with statutory requirements and is in conformity with Act. In case consumer has not
been intimated within stipulated period about any deficiencies in his application, the application
shall be deemed to have been accepted for processing by the licensee.(c)Licensee shall not be
responsible if the reasons for delay are on account of right of way, acquisition of land, technical
feasibility and lack of transmission capacity etc, over which the licensee has no reasonable control,
provided the reasons for the expected delay are communicated to the applicant within the period
specified for energisation.(d)If any information furnished in application form is found wrong or the
installation is defective or the energisation would be in violation of provision of Act/ Electricity
Rules,/Tariff Order, the licensee shall not sanction the load and shall intimate the applicant the
shortcomings/reasons thereof in writing on the spot as far as possible.4.1No Dues Certificate.- (i) It
will be the duty of the seller to find out the outstanding electricity dues up to the date of sale, and
liable to pay the outstanding electricity dues/obtain no dues certificate.(ii)Before sale of a premise is
made, the outstanding dues will be cleared or alternatively the agreement/sale deed will specifically
mention the outstanding dues and the method of its payment. "Outstanding dues" means all dues
pending on a premise including late payment surcharge.(iii)In the event of non payment of the
outstanding dues, the dues shall be recoverable as public demand under the Bihar and Orissa Public
Demand Recovery Act, 1954 as amended from time to time.(iv)The outstanding dues will be first
charge on the assets of the defaulting consumer/company, and the licensee shall ensure that this is
entered in an agreement with new applicant.(v)The recovery proceedings against the defaulting
consumer, and where the defaulting consumer is a company, from the Directors of the company,
shall be ensured. Where a financial institution has auctioned the property without consideration toBihar Electricity Supply Code, 2007

licensees charge on assets, claims may be lodged with the concerned financial institution with
diligent pursuance.(vi)in case the electricity connection to the said premises was given with the
consent of house owner, such person shall ensure the payment of all arrears/dues of electricity by
the tenant before the tenant vacates the premises.However the conditions mentioned under clause
4.15 above shall not apply if inconsistent with the provision of any higher court order or an order as
a consequence to it.Supply to Different Categories of Consumers(A)LT Supply4.16The Licensee shall
verity the application and documents at the time of receipt of application. A written
acknowledgement shall be issued on the spot, if the application is complete. If the application is
incomplete, the shortcomings in the form shall be intimated to the applicant in writing within 3
working days. After complete application is received from the consumer, the licensee shall issue a
written acknowledgement to the consumer immediately. Within 2 working days of receipt of the
completed application form, the licensee shall intimate the consumer the proposed date of
inspection, which should be within the next 5 working days in urban areas and 10 working days in
rural areas.4.17On receipt of application the Licensee shall inspect the premises of the applicant and
the applicant along with the licensed contractor or his representative shall be present during the
inspection. During the inspection, the Licensee shall:(i)Fix the point of supply and the place where
meter and the cut-out/ MCB shall be fixed.(ii)Fix the layout of the proposed lines and sub-station
and estimate the distance between the point of supply and the nearest Distribution mains from
where supply could be given.(iii)Determine if the supply line shall go over any property belonging to
a third party, in such case the applicant shall obtain no objection certificate from the third party, in
absence of which licensee may adopt a different route for which the applicant shall bear the cost
differential.(iv)Verify other particulars mentioned in the application form, as required.(v)Satisfy
themselves regarding the work completion certificate and the test report submitted by the
applicant.(vi)If the licensee is not satisfied, he shall intimate to the applicant shortcomings on the
spot. The applicant shall be required to get the defects removed. Inspection shall again be conducted
and a fee, as prescribed, may be charged for such subsequent inspections.4.18It shall not be
incumbent on the licensee to ascertain the validity or adequacy of way leave, licence or sanction
obtained by the consumer.4.19(a)After sanction of load, an estimate shall be prepared, which shall
remain valid for three months from the date of sanction letter to the applicant.(b)The estimate shall
include security deposit, charges for laying the service line, distribution mains (if required) &
material, and service connection charges etc, as determined by the Licensee with the approval of the
Commission from time to time.(c)After approval of the Commission, the licensee shall publish a cost
data book, and make it available to any interested person at a reasonable charge, and shall also place
it on their website.(d)The above estimate shall be based on Rs./KW (or Rs./KVA) of the
sanctioned/contracted load, or on Rs. per service installation for specific bands of contractual load
applied for or sanctioned load at each voltage level up to 33 KV voltage on which supply is to be
given. Beyond 33 KV voltage level, the charges for laying shall be based on Actual estimates of the
licensees:Provided that the estimates for independent/dedicated feeder shall be in accordance to
requirements laid down in clause 5.3 of this Code.(e)If the work is to be done by the
developer/applicant/development authority, the Licensee shall charge supervision charges as a
percentage as given below, of the normative estimate arrived at on KVA or KW basis as specified in
cost data book, which shall be deposited with the licensee before work begins.
Load 30 KW (33 KVA) upto 3600 KW (4000 KVA) -15%Bihar Electricity Supply Code, 2007

Above 3600 KW upto 9000 KW (10,000 KVA) -8%
Above 9000 KW (10,000 KVA) -5%
In other cases, Licensee shall commence the work after the applicant, has deposited the full amount
of the estimate. Until the normative cost estimates are enforced, the supervision charges shall be
levied as percentage specified above on estimated material cost and shall also include the estimated
labour cost, cost of material handling and storage/inventory, and shall not include the system
loading charges and the establishment costs.(f)Disputes regarding the estimate may be referred to
the authority that is one level higher than the sanctioning authority and if the applicant is still
aggrieved he may approach the Consumer Grievance Redressal Forum established under Section
42(5) of the Act for adjudication.(g)A final bill shall be prepared after completion of the work by the
Licensee.-If the final bill exceeds the value of the estimate, the difference shall be deposited by the
applicant before connection is energized.-If the bill is less, the difference shall be adjusted in
subsequent electricity bills or refunded by cheque within 60 days:Provided further that, in case of
revision of charges, if the estimates were sanctioned prior to the date of revision, the estimates in
excess shall not be charged on completion of works on the basis of revised charge. However, if the
work is completed at an estimate less than that prepared in revised charges, the excess amount
deposited by the applicant on the basis of unrevised charges, shall be refunded within 60 days
:Provided also that, if the licensee has published updated normative charges in the cost data book,
and has included the same in preparing the estimate, the final bill and above proviso, shall not be
necessary.4.20In case it is possible to extend supply from the existing mains, the licensee will
forward to the Consumer, within 20 days or otherwise provided in the Standards of Performance for
Distribution Licensee Regulations an advice for the charges for laying the service line, the amount of
security deposit and any other charges as applicable. The amount shall be payable in full within 7
working days, after which only any work for laying the service line will be taken up. The licensee will
also intimate to consumer to execute the agreement.4.21In case it is necessary to extend distribution
mains for giving supply to the consumer, the licensee will forward to the consumer, within 15 days in
urban areas and within 20 days in rural areas or otherwise specified in the Standards of
Performance of Distribution Licensee Regulations, an advice containing the charges for extension of
the distribution main, laying the service line, the amount of security deposit, any other charges as
applicable and will also intimate if any additional formalities are required to be carried out by the
consumer. In cases where the consumer has to lay the service line and extension of mains, the
consumer shall pay the supervision charges on cost of extension of the distribution mains and laying
the service line in addition to payment of other charges as may be applicable. The amount shall be
payable in full within 7 working days along with completion of formalities, after which only any
work for laying the distribution mains and service line can be taken up. The licensee will also
intimate the consumer to furnish test report in the prescribed form.4.22Licensee on request of
consumer may extend the date of payment beyond 7 days, upto 15 days but this extended time shall
not be counted for delay in connection under Section 43 of Act, and no compensation shall be paid
during the said period. In case the consumer fails to complete the formalities within 15 days, the
licensee shall given him notice to complete the formalities within the next 15 days failing which, his
requisition for supply shall be cancelled. Thereafter the consumer shall have to apply afresh for
supply or additional supply as the case may be.4.23On deposit of charges as indicated above by the
consumer, execution of the agreement and receipt of test report and intimation that the service line
and extension work have been completed, the licensee shall intimate the consumer, within 3Bihar Electricity Supply Code, 2007

working days, the date of testing of the consumer's installation. The consumer shall ensure that the
licensed electrical contractor, who has carried out the wiring, is present during the testing.4.24On
testing the consumer's installation, if the licensee is satisfied with the test results, the licensee shall
arrange to install the meter with the cut-out or MCB, seal the meter in presence of the consumer and
provide supply. If the licensee is not satisfied, he shall intimate the consumer in writing, the
shortcomings in the wiring. The applicant shall be required to get the defects rectified. On payment
of the prescribed fee, testing shall again be conducted as per clause 6.29 of the Code. On payment of
the prescribed fee, testing shall again be conducted as per clause 6.29 of the Code.4.25All work shall
be completed within the time-frame specified in clause 4.80 of the Code or as specified in the
Standards of Performance of Distribution Licensee Regulations.(B)LT Supply to Multi-Consumer
Complex Including Commercial Complexes :4.26For the purpose of providing new power supply to
a building ora group of buildings having more than one connection with a total load exceeding 30
kW, the building shall be considered as a multi-consumer complex. Such new connection shall be
provided with single meter. However this shall not restrict the individual owner for applying for
individual connection and the licensee shall sanction such connection on LT. The applicant /
developer / development authority shall be responsible to develop, construct the entire
infrastructure required for distribution network from the licensee's sub station 33/11 KV or 11 /0.4
KV, upto the connection outlets in individual owner's premises, at his own cost.4.27In case it is not
possible to give supply to the Multi-Consumer Complex by augmentation of the existing 33/11 kV
sub-station capacity the developer/ builder/ society/ consumer shall bear the cost of the 33 kV line.
The cost of construction/augmentation of 33/11 kV power sub station if required shall be borne by
the licensee.Note :- The developer/ builder/ society/ consumer includes any agency whether
Government, local body or private that constructs the Multi-Consumer Complex.4.28Meters shall
normally be provided at the ground floor in accordance with the procedure stated in chapter 8 of the
Code.4.29The land/room required for housing the transformer sub-station and meters shall be
provided by the developer/ builder/ society/ consumer free of cost for which rent or premium shall
not be paid by the licensee. Transformers should preferably be placed in open areas. In case
installation of transformer in a room or closed area is unavoidable, all safety measures as per
prevailing rules and regulations should be taken.4.30Connections for common facilities like lift,
water pumps etc. shall be given in the name of the builder/developer/society.4.31In case the original
approved plan is for a multi-consumer complex, but the builder/developer/ society/ consumer
desires to avail connection for a portion of it, the connections shall be provided treating it as
multi-consumer complex.4.32Due to additional construction or additional requirement of load, if a
building comes under the category of multi-consumer complex and if a separate distribution
transformer of sufficient capacity, for giving supply to such building was not provided earlier, it will
be provided at the cost of builder/developer/society/ consumer. Alternatively, the
builder/developer/society/consumer shall arrange to suitably augment the capacity of the existing
11/0.4kV sub-station, if found feasible by the *licensee. (sic ?)4.33The load of a multi-consumer
complex for development of infrastructure for extension of distribution mains shall be calculated on
the following basis (area represents built up area of individual units:* (sic ?)
 Area Load
(a)Upto 400 sq ft 1.5 kW
(b)above 400 sq ft & upto 700 sq ft2.0
kWBihar Electricity Supply Code, 2007

(c)above 700 sq ft & upto 1000 sq ft3.0
kW
(d)above 1000 sq ft & upto 1300 sq ft4.0
kW
(e)above 1300 sq ft & upto 1600 sq ft5.0
kW
(f)above 1600 sq ft & upto 2000 sq ft7.0
kW
(g)above 2000 sq ft & upto 2500 sq ft 10 kW
(h)For every additional 500 sq ft or part thereof over 2500 sq ftof built up area, 1.0kW of
load shall be added.
The load of the common facilities like lift, water pump, parking lights etc shall be taken as declared
by the developer/builder/society/consumer.The aforesaid procedure for estimation of load is for the
purpose of bringing about uniformity in the assessment of the load of the multi-consumer complex.
However, security deposit etc. shall be worked out on the basis of the load as declared by the
consumer and supported by the test report at the time of providing connection to individual
consumer.4.34On receipt of requisition from the builder/ developer/ society/ consumer for supply
of electricity to multi-consumer or commercial complexes, the licensee shall take action for
extending the supply as per procedure given in clauses 4.16 to 4.25 of the Code, as applicable.(C)LT
Supply to Housing Colonies :4.35The developer/builder/ society/ consumers of a housing colony
shall bear the cost of extension including the cost of 11 kV line, distribution transformer and LT
lines/LT cables. The cost of construction/ augmentation of capacity of power sub-station of 33/11 kV
if required, shall be borne by the Licensee.[Note : The developer/builder/society/consumer includes
any agency whether Government local body or private that constructs the building/colony.]4.36The
load of a housing colony, for development of infrastructure for extention of distribution mains shall
be calculated on the following basis (area represents plot area):
 Area Load
(a)Upto 500 sq ft 1.0 kW
(b)above 500 sq ft & upto 1000 sq ft 2.0 kW
(c)above 1000 sq ft & upto 1500 sq ft 3.0 kW
(d)above 1500 sq ft & upto 2000 sq ft 4.0 kW
(e)above 2000 sq ft & upto 2400 sq ft 5.0 kW
(f)above 2400 sq ft & upto 3000 sq ft 7.0 kW
(g)above 3000 sq ft & upto 3500 sq ft 10.0 kW
(h)For every additional 500 sq ft or part thereof over 3500 sq ft 1.0 kW
The load of the common facilities like lift, water pump, parking lights, street lights etc may be taken
as declared by the developer/builder/society/ consumer. If, subsequently, the builder/ developer/
society/ consumer constructs houses or buildings for sale, instead of sale of plots, the load will be
reassessed on the basis of the guideline given in clause 4.33 The developer/ builder/
society/consumer will also be required to pay the cost of the additional infrastructure required for
the purpose excluding the cost of construction of new/augmentation of 33/11 kV power sub stationBihar Electricity Supply Code, 2007

which shall be borne by the licensee.The aforesaid procedure for estimation of load is for the
purpose of deciding the number and capacity of distribution transformers and the length of HT/LT
line required. However, the service connection charges, security deposit etc shall be worked out on
the basis of the load as declared by the consumer and supported by the test report at the time of
serving connection to individual consumer.4.37On receipt of requisition from the
builder/developer/ society/ consumer for supply to housing colony, the licensee shall take action for
extending the supply as given in clauses 4.16 to 4.25 of the Code, as applicable.Supply to Group
User4.38The Group user shall be eligible to opt supply by a distribution licensee at a single point
provided that the supply shall be primarily used for residential purpose including the loads of
common amenities for the group user like lift, pumps for pumping water supply and lighting of
common area. The use of electricity for more than 10% of the declared connected load for
commercial/non-domestic purposes shall not be permitted from this connection. The Group user
shall inform the details of every non-domestic activity along with the connected load to the licensee
at the time of seeking connection or at the time of enhancement in contract demand. The licensee
may undertake physical checking of non-domestic load for the purpose of ensuring that the
non-domestic load is within permissible limit i.e. 10% of declared connected load. In case the use for
commercial activity is observed for a load more than the permitted load, it shall be treated as
unauthorised use.4.39On receipt of requisition in manner specified under clauses 4.11 to 4.14 of the
Code from the applicant group user, the licensee shall verify the application and the attached
documents at the time of receipt of application. In case of a Cooperative Group Housing Society, a
certified copy of the registration of the applicant Co-operative Group Housing Society shall also be
annexed along with the application requiring supply at single point.System of Supply and
MeteringThe system of supply shall be either LT or HT or EHT according to the range of contract
demand specified in Chapter 3 of the Code.4.40The manner to process the application for single
point HT or EHT supply to Group user shall be followed as per clauses 4.71 or 4.76 of the Code,
respectively.4.41HT metering shall be installed at the point of supply to the Group user for the
purpose of recording of units sold by the licensee and billing to the Group user.(a)The Distribution
sub-station and other required infrastructure like LT lines, cables, feeder pillars, metering panels for
individual meters and service lines etc. shall be laid by the applicant Group user and the Group user
shall retain the ownership of all such assets.(b)The Group user shall be fully responsible for
maintenance of complete infrastructure network after the HT metering point i.e., point of supply.
The Group user shall also be responsible for maintaining all construction and safety standards in
respect of all assets and works being retained and executed by the Group user.4.42The Group user
shall be fully responsible for various commercial and technical activities related to distribution of
electricity.4.43The extension of lines and up-gradation of system up to the point of supply of the
Group user, notwithstanding that it has been paid for by the Group user, shall be the property of the
licensee. The licensee shall maintain it at its cost.4.44The Group user can execute the work of
extension of his own distribution network from the point of supply to the individual premises
through a 'C' or higher class licensed electrical contractor, and the work of extension of HT line and
/ or HT sub-station and LT lines through an 'A' class contractor. In such case, the group user itself
shall procure the material.4.45The land/accommodation required for installation of metering at
point of supply shall be provided by the Group user free of cost for which rent or premium shall not
be paid by the licensee.4.46For the purpose of considering the criteria of a Group user, for
development of infrastructure, if any, shall be calculated on the same basis as is provided in clauseBihar Electricity Supply Code, 2007

4.36 of the Code.4.47The electrical energy supply to the Group user shall not be utilized by the
Group user in any manner pre-judicial to the licensee and all usage must be in accordance with the
provisions of the agreement and the Act as applicable.4.48The Group user shall not divert the use of
energy other than purpose mentioned in the agreement. The Group user shall not extend the supply
beyond its premises other than that for which it was sanctioned by the licensee.4.49The map clearly
indicating the plots/ building and the electrical distribution network with indexing on each pole and
transformer or any other equipment shall be submitted by the group user, agreed upon and signed
by both the Group user and the licensee shall form a part of the agreement.4.50If there is a need to
modify/ amend the agreement signed between the licensee and the Group user, it will be done by a
supplementary agreement.4.51The licensee shall raise the electricity bills on the units sold to the
Group user at the applicable rate approved by the Commission.4.52The provisions of this regulation
shall not in any way affect the right of a person residing in the housing unit sold or leased by
Co-operative Group Housing Society to demand supply of electricity directly from the distribution
licensee of the area on the following terms and conditions :(i)The Co-operative Group Housing
Society must permit any person of the society to avail supply of electricity from the Distribution
licensee directly. The Co-operative Group Housing Society shall have no objection in respect of the
following:(a)The electricity supply by the licensee to such person shall be served from the licensee's
distribution network.(b)Extension of adequate distribution network by the licensee to release the
supply to such person.(c)Providing access for the licensee's representative to approach at any point
of time to network of licensee in the premises of the group user including the point of supply to such
consumer to discharge service obligations without any resistance.(ii)The meter shall be installed by
the licensee at the appropriate place of the premise of such consumer and the reading and billing of
electricity to such person shall be executed by the licensee.(iii)The licensee shall recover the charges
for the electricity consumed by such person at the approved applicable domestic rates.(D)LT Supply
for Agriculture/Irrigation Pumpsets :4.53The procedure laid down in clauses .4.16 to 4.25 of the
Code, as applicable, shall be followed for giving supply to agriculture/irrigation pump sets where
extension bf distribution mains and/or augmentation of distribution transformer is not
required.4.54Supply for agriculture/irrigation pump set, at one point, may also be given to a
registered co-operative society or to a group of farmers recognized by the licensee.4.55If on
inspection of the premises, it is found that extension of distribution mains and/or augmentation of
distribution transformer capacity is required, the possibility of taking up the work from financial
assistance available from the Government or financial institution like Rural Electrification
Corporation etc. shall be examined. Within 10 days of receipt of application if no extension of line is
required, and within 20 days of receipt of application or otherwise provided in the Standards of
Performance of Distribution Licensee Regulations. If extension of line is required, the consumer
shall be intimated whether the licensee can take up the work from funds available with the licensee
from other sources or whether the work can be taken up only after the full cost of the works is
deposited by the consumer. In case the work can be taken up only after the consumer deposits the
estimated expenses, the licensee shall specify the amount along with the intimation.The work of
electrification of such pump-set(s), for which the full cost of the work is deposited by the
consumer(s), will be taken up and completed within the period as laid down in clause 4.80 of the
Code of depositing the amount by the consumer(s) if extension work is involved. New connection
shall be taken up on the broad principle of first-come first serve basis. Within 3 working days of
completion of work, the licensee shall intimate the date of testing of the installation of the consumerBihar Electricity Supply Code, 2007

and request the consumer(s) to furnish the test report. In case he is satisfied with the test report and
the wiring in the premises of the consumer, the connection shall be served within 3 working days of
the inspection.4.56An agricultural consumer, if he so desires, may shift the location within his
premises of his connection, with the approval of the licensee, after payment of charges as
applicable.(E)LT Supply to Public Street Lightings :4.57Requisition for power supply to new or
additional public street lights shall be submitted in the prescribed format to the local office of the
licensee by the Municipal Corporation or Municipality or Municipal Board or Gram Panchayat or
Local Body or the Government Department or any other organization made responsible by the
Government or local body to maintain public street lights (in context of public street lights
hereinafter called 'local body').4.58The requisition for public lights shall be accompanied by
resolution of the local body and the sketch indicating the number of poles, existing or new, where
streetlights are required. Except otherwise directed by the Commission, the licensee may not
provide a new street light connection if the local body, applying for new street light connection, has
any electricity dues against it.4.59The fittings, brackets or any special fittings shall be in accordance
with the relevant BIS specifications or its equivalent, and shall maintain, required clearances, as per
prevailing rules and regulations. The local body shall bear the full cost of arranging of power supply
to public streetlights including complete fittings and brackets. In case, any special fittings are to be
provided, the local body shall arrange for it.4.60The licensee shall intimate the cost of extension in
writing within 20 days from the date of acceptance of application or otherwise provided in
Standards of Performance of Distribution Licensee Regulations.The work shall be taken up only
after deposit of the amount and execution of agreement by the local body.4.61A suitable double
compartment weatherproof metal box to house the energy meter and streetlight switch/M.C.B./
timers shall be provided by the licensee.4.62It shall be responsibility of municipal body/local body
to do maintenance and replacement of street light fittings and also to switch on and switch off the
streetlight. However the licensee may carry out the maintenance of street light fixtures on payment
basis and shall arrange to switch on fifteen minutes before sunset and switch off the street lights
fifteen minutes before sunrise as per local sunset/sunrise timings. The licensee shall also carry out
replacement of fixtures/ bulbs (of same wattage) etc. on the poles on request by the street light
consumers. The fixtures, bulbs etc. shall be supplied by the consumers and replaced by the licensee
within 7 days of receipt. All such services shall be chargeable. Such maintenance charges shall be
included in the schedule of miscellaneous charges.(F)Temporary Power Supply4.63Any person
requiring power supply for purpose that is temporary in nature, for a period of less than one year or
as provided in the tariff order of the Commission may apply for temporary power supply in the
prescribed form (Annex-1 or 2). The period of connection can be extended upto two years for
building construction activities and for purpose of installation of equipments by industrial
consumers for setting up their units. Application for temporary supply shall normally be given in
advance however in certain exceptional case like marriage, political meeting etc. the application can
be given on the day on which supply is required. Where no mains extension is required and where
mains extension is required in both the cases the time frame work specified in Standards of
Performance for Distribution Licensee Regulations will apply. The proof of ownership/occupation or
permission from the local authority or from the owner of the premises, as the case may be, where
temporary connection is required has also to be attached with the applications as specified in clause
4.13 of this Code.4.64In case temporary supply is required in premises/place where 100 or more
persons are likely to assemble, the consumer shall comply with the provisions of Section 54 of theBihar Electricity Supply Code, 2007

Act.4.65If supply is technically feasible, the licensee shall intimate the charges to be paid by the
consumer for the cost of service line, meter, cut-out/MCB and other charges etc, together with
charges for the estimated electricity consumption for the period of supply applied as per tariff order
of the commission in force. All the charges shall be payable in advance.The consumer shall have the
option either to receive the material used for temporary connection or receive credit, in the final bill,
for materials dismantled and returned to stores of the licensee after disconnection of supply.4.66In
case temporary supply is required for a period more than 90 days, the licensee may permit the
consumer to pay charges for estimated consumption for 90 days in advance and serve the bills for
monthly consumption. In case the consumer fails to pay the bills in time and the advance with the
licensee does not cover the charges for the balance period, the supply shall be liable for
disconnection.4.67If an agricultural consumer wishes, he may seek temporary connection for
agricultural use. In such case the consumer shall pay the entire amount of bill charges payable for
the period of proposed connection in advance. All charges and other conditions as applicable to
temporary connection shall be applicable. In case a consumer defaults in clearing any dues under
this provision, he shall not be provided new connection till previous dues are cleared. The licensee
shall have the right to remove any equipment specifically installed for providing supply under this
provision, after the period of supply is over.4.68The licensee shall release the supply within 3 days
of payment of charges and compliance of other requirements by the consumer for loads up to 10 KW
and within 15 days for load exceeding 10KW where extension of distribution mains is not required.
Where extension of distribution mains is required, the supply shall be released within 60 days in
case of LT consumers, 90 days for HT consumers and 180 days for EHT consumers.4.69The
readings of the meter may be taken during the period of the temporary connection to ensure that the
charges for actual consumption does not exceed the advance payment received.4.70After the period
of temporary supply is over and supply has been disconnected, the licensee shall send the final bill
to the consumer within 10 days from the date of disconnection of supply and refund the balance
amount, if any, within 20 days of surrender of original money receipt or submission of indemnity
bond by the consumer. On any delay beyond the said time limit the licensee will be liable to pay an
interest @ 1.5% per month on the amount of refund outstanding for the number of days beyond the
last date of payment, as specified above.(G)H.T. Supply4.71After receipt of application for supply of
electrical energy at H.T. in the prescribed format, the licensee shall intimate the consumer in writing
the date of inspection of the site to examine the feasibility. The licensee shall intimate the feasibility
or otherwise of supply within 10 days of receipt of the application or as otherwise specified in the
Standards of Performance of Distribution Licensee Regulations. The consumer or his authorized
representative shall remain present at the time of inspection. In case supply is found feasible, the
licensee shall fix the point of entry of the supplier's line, the position of meter, metering equipment
and other equipments of the supplier.The consumer may with the written permission of the licensee
house his own HT switchgear and other apparatus connected with the supply of electrical energy to
him under the agreement signed between the consumer and the licensee and as must necessarily be
placed therein; but such enclosure shall not be used for any other purpose. The licensee may insist
on use of 'Ariel Bunched Cable', wherever considered appropriate, for the last span. The difference
of cost of the last span on account of laying of Ariel Bunched Cable' with respect to overhead bare
conductor shall be borne by the licensee.4.72Supply to HT industrial consumers shall normally be
given through HT feeder exclusively meant for industries. It may be preferable to extend supply
through a separate feeder from the nearest 33/11 kV or EHT substation in case of consumers withBihar Electricity Supply Code, 2007

continuous process industry or load of 3 MVA or more.4.73Supply to new HT consumer (both at 11
kV or 33 kV) shall normally not be extended from the rural feeder. If due to the prohibitive cost of
extension of separate feeder from the nearest 33/11 kV or EHT sub-station, or for any other reason,
the supply is given from a rural feeder, the consumer shall be informed that the supply shall be
restricted and regulated in accordance with the restrictions imposed on the rural feeders as per grid
conditions. Such consumer may be required to furnish a declaration to the licensee indemnifying the
licensee for the restrictions in supply.4.74The licensee shall intimate the consumer within the time
limit as specified in the Standards of Performance of Distribution Licensee Regulations, the charges
required to be paid for the cost of extension, if any, and the amount of security deposit and other
charges if any. Copies of the draft agreement and the form of the required test report shall also be
forwarded simultaneously.4.75After the payment of charges including security deposit, and
execution of the agreement, the licensee shall take up the work of extension of mains. If the
consumer wishes, he may execute the job on his own after payment of due supervision charges to
the licensee. The work shall be completed within the time limit specified in the Standards of
Performance of Distribution Licensee Regulations. After completion of the installation, the
consumer shall furnish to the licensee the test report and the permission from the Electrical
Inspector to energize the installation. On receipt of the report(s), the licensee shall intimate the
consumer in writing the date (not later than 7 days) of inspection and testing of the consumer's
installation. In case the consumer's installation is found in order, the licensee shall seal the meter in
the presence of the consumer and serve the connection.(H)Supply at Extra High Tension :4.76After
receipt of application in the prescribed format for supply of electrical energy at E.H.T., the licensee
shall intimate the consumer in writing the date of inspection to check the feasibility of supply. The
licensee and the Transmission Licensee shall carry out the inspection jointly. The consumer or his
authorized representative shall remain present at the time of inspection. In case supply is found
feasible, the licensee shall fix the point of entry of the supplier's line, the position of meter, metering
equipment and other equipments of the supplier. The Licensee shall intimate the feasibility of
supply within 10 days of receipt of the application or as otherwise specified in the Standards of
Performance of Distribution Licensee Regulations.4.77The licensee shall intimate the consumer
within the time limit specified in the Standards of Performance of Distribution Licensee Regulations
the charges required to be paid for the cost of extension, if any, and the amount of security deposit
and other charges, if any. Copies of the draft agreement and the form of the required test report
shall also be forwarded simultaneously.4.78After the payment of charges including security deposit
and execution of the agreement, the licensee shall request the Transmission Licensee to take up the
work of extension required to give supply. If the consumer wishes he may execute the job on his own
after payment of due supervision charges to the licensee. The work shall be completed within 180
days or as specified in the Standards of Performance of Distribution Licensee Regulations.4.79After
the consumer executes his internal electrical works, he shall furnish to the licensee the test report
and the permission from the Electrical Inspector to energize the installation in accordance with
clause 47 of IE Rules. On receipt of the report(s), the licensee shall intimate the consumer in writing
the date of inspection and testing of the consumer's installation. It the consumer's installation is
found in order, the licensee shall seal the meter in the presence of the consumer and serve the
connection.4.80Target Period of Completion of Various ActivitiesThe following table provides the
target period of completion of various activities:
Type of Service Time Limit for Rendering theServiceBihar Electricity Supply Code, 2007

S.
No.
1. LT connection  
 (a)Acceptance and Notice of inspection on receipt
ofcomplete application5 days
 (b) Inspection after sending the notice  
  -Urban areas 3 days
  -Rural areas 7 days
  (i) if the extension work is not required andthe
connection is to be given from the existing network 
 (c)Issue of demand note to the applicant for paymentof
estimated charges 
  -Urban areas 3 days
  -Rural areas 5 days
 (d)Serving of power availability notice forcommencement
of supply after payment of necessary charges 
  -Urban areas 5 days
  -Rural areas 7 days
  (ii) If the extension work or enhancement
oftransformer capacity is required 
 (e)Issue of demand note to the applicant for paymentof
estimated charges 
  -Urban areas { 20 days }
  -Rural areas
 (f)After payment of necessary charges Serving ofpower
availability notice for commencement of
supply-Allconnections30 days
2.High Tension
Connection 
 (a) Informing feasibility after receipt of theapplication 10 days
 (b)Issue of demand note of estimated charges (afterissue
of notice of feasibility) 
  (i) If no extension of work is involved 7 days
  (ii) If extension work is involved 45 days
 (c)Serving of power availability notice forcommencement
of supply/release of connection after receipt
ofestimated charges subject to receipt of clearance
from ElectricalInspector 
  (i) If no extension of work is involved 7 daysBihar Electricity Supply Code, 2007

  (ii) If extension work is involved  
  -Construction of 11kV line 45 days
  -Construction of 33kV line 45 days
3.Extra High
Tension
Connection 
 (a) Informing feasibility after receipt of theapplication 10 days
 (b)Issue of demand note of estimate charges afterissue of
notice feasibility60 days
 (c)Serving of power availability notice forcommencement
of supply/release of connection after receipt
ofestimate 
  -involvingconstruction/extension of EHT line45 days (subject to
receipt ofclearance
from Electrical
Inspector)
  -Involvingconstruction/extension of EHT line and
additional transformer180 days
4.81The licensee shall maintain a priority register where type of connection will be categorised in
following categories:(a)Where no extension of distribution mains is required(b)Where extension of
distribution mains upto two poles is required(c)Where extension of distribution mains of more than
two poles is required.4.82The Commission may for reasons to be recorded, direct deviations from
the above clauses 4.1 to 4.81 if in the opinion of the Commission the circumstances warrants such
deviation. The Commission may issue such direction by an order to the licensee.4.83Nothing
contained in this chapter-4 shall be taken as requiring a licensee to give supply of electricity to any
premises if he is prevented from doing so due to Force Majeure conditions provided in clause 12.1
Chapter 5
Point of Supply and Licensee's Equipment in Premises
Point of Supply:
5.
1.
(a)Supply shall be given at a single point, in premises, at the outgoing terminal of the Licensee. The
Licensee shall determine the point of supply such that the meters and other equipment are always
accessible to the Licensee without obstruction for inspection.(b)All EHT & HT
consumers/applicants shall provide independent entry to the meter or metering cubicle.(c)However,
in special cases, the licensee may agree to give supply at more than one point in the installation ofBihar Electricity Supply Code, 2007

the consumer/applicant having regard to the physical layout of the installation and the
requirements of the consumer/applicant. The arrangement will be subject to the condition that
separate metering will be done and summation of demand and energy recorded at all points will be
taken as parameters for billing under the relevant tariff schedule.Installation of Equipment at Point
of Supply5.2(a)At the point of commencement of supply, the consumer/applicant shall provide a
main switch/circuit breaker from the outgoing terminal of the meter.(b)In addition, HT/EHT
consumers/applicants shall also provide suitable protective devices as per the provisions of Rule 56
and 64 of the Indian Electricity Rules, 1956 and thereafter as per regulations framed under Section
53 of the Electricity Act, 2003. The system of protection shall be got approved by the Licensee before
commencement of supply.(c)In case of HT/EHT consumer/applicant, Meter, circuit breakers and its
associated equipments shall be installed by the Licensee at the point (s) of supply.(d)HT/EHT
consumer/applicant shall install step down transformers with a vector group with delta winding on
the high voltage* (sic ?) side and star winding on the low voltage side, with the neutral terminal
brought out and duly earthed.(e)The licensee shall install and maintain the communication link
facility from the grid sub station supplying the railway traction through PLCC.Dedicated
Feeder5.3Consumers desirous of getting power supply from dedicated feeders may request for such
facility to the licensee. The dedicated feeder shall be extended from the power sub-station to the
consumer's point of supply. In such cases the consumers shall be liable to pay the cost of Bay and all
protection switch-gears and its accessories provided at the 'Power sub-station (sic ?) for this feeder
in addition to the cost of the feeder* (sic ?). On receipt of such application licensee will* (sic ?) check
the feasibility based on merit of providing a dedicated feeder to the consumer's premises. If found
feasible, the consumer will be provided with a dedicated feeder and the consumer will be liable to
pay additional charges such as supervision charges, etc. as approved by the Commission from time
to time.The Licensee shall not extend electric supply to any other consumer from the dedicated
feederLicensee's Equipment at Consumer's Premises5.4The consumer shall provide free of cost to
the licensee necessary land belonging to the consumer and afford all reasonable facilities for
bringing in not only the direct cables or overhead lines from the licensee's system for servicing the
consumer, but also cables or overhead lines connecting licensee's other consumers and shall permit
the licensee to install all requisite switchgears and connections thereto on the above premises and to
extend supply to such other consumers through the cables and terminals situated on the consumer's
premises, provided supply to the consumer in the opinion of the licensee is not thereby unduly
affected.Damage to Equipment at Consumer's Premises5.5The meter, cut-out/MCB, service mains
and other equipment belonging to the licensee, must on no account be handled or removed by any
one who is not an authorized employee/representative of the licensee. The seals, which are fixed on
the meters/ metering equipments, load limiters and the licensee's apparatus, must on no account be
tampered, damaged and broken. The responsibility for the safe custody of licensee's equipments and
seals on the meters/metering equipments within the consumer's premises shall be on the
consumer.5.6In the event of any damage caused to the licensee's equipments in the consumer's
premises by reason of any act, neglect or default of the consumer or his employees/representatives,
the cost thereof as claimed by the licensee shall be payable by the consumer. If the consumer fails to
do so on demand, it shall be treated as a contravention of the terms and conditions of supply
agreement and the supply shall be liable to be disconnected after due notice. The consumer shall
however be liable to pay the charges, as applicable. [In case of replacement of defective/ burnt
meters and metering units, the provision as contained in clause 8.20 of Chapter 8 of the code shallBihar Electricity Supply Code, 2007

apply.] [Added by Notification No. 603, dated 18 August, 2010.]5.7The licensee is responsible for
maintaining the meters and equipments, installed at consumer's premises from where electricity is
supplied to the consumer.Failure of Fuse/Supply:5.8In the event of failure of the licensee's service
fuse, at any time, complaint thereof should be lodged by the consumer to the licensee's local
office/call center and the Licensee shall ensure registration of complaints on round the clock basis.
Only authorized employees possessing the photo-identity card of the licensee shall be permitted to
replace these fuses in the licensee's cut-outs. Consumers are not allowed to replace these fuses. The
licensee should not allow its employees to carry out any repairs in the consumer's installations.
Chapter 6
Wiring and Apparatus in Consumer Premises
Wiring at Consumer's Premises
6.
1.
The work of wiring in the consumer's premises shall be carried out by a Licensed Electrical
Contractor and should conform to the Indian Electricity Rules, 1956 until Rules/Regulations are
framed under Section 53 of the Act as well as the Rules of the Fire Insurance Company in terms of
which the building is insured. The materials used for wiring shall conform to the relevant
specifications of the Bureau of Indian Standards or its equivalent. Where ever applicable the
materials used shall bear ISI or IEC mark. As soon as the consumer's installation is completed in all
respects and tested by the consumer's contractor, the consumer should submit, the contractor's test
report to the licensee. The test report form (Annexure-3) for this purpose shall be submitted to the
local office of the licensee.6.2As required by Rule 45 of the Indian Electricity Rules, 1956, no
electrical installation work, including addition, alteration, repair and adjustment to existing
installation - except the replacement of lamps, fans, fuses, switches and other component parts of
the installations-which in no way alter the capacity or character of the installation, shall be carried
out in the premises on behalf of any consumer or owner for the purpose of supply of energy to such
consumer or owner, except by an electrical contractor licensed by the State Government in this
behalf and under the direct supervision of a person holding a certificate of competency or by a
person holding a permit issued or recognized by the State Government.6.3Any person committing
breach of Rule 45 shall render himself liable to punishment under Rule 139 of the Indian Electricity
Rules, 1956.6.4Provisions of Rule 32 of the Indian Electricity Rules, 1956 should be complied with
in respect of consumer's installation. No cut-out, link or switch other than a linked switch arranged
to operate the earthed and live conductors simultaneously, shall be inserted in the conductor of the
consumer's installation to be connected to the neutral conductor of the licensee's system.General
Wiring Conditions :Mains :6.5The consumer's mains shall, in all cases, be brought up to the
licensee's point of supply and sufficient cable shall be provided for connecting up with the licensee's
apparatus.Switches and Fuses :6.6The consumer shall provide proper main switches of requisite
capacity to carry and break current in each conductor near the point of commencement of supply.Bihar Electricity Supply Code, 2007

The switches in the consumer's premises shall be on the live wire and the neutral conductor shall be
marked for identification where it leaves the consumer's main switch for connecting up to the meter.
No Single pole switch or cut-out should remain inserted in any neutral conductor.Balancing of Load
:6.7The consumer taking three-phase supply shall balance his load between the phases as per IE
Rules.Earthing :6.8Proper earthing with earthing pipe should be done and gas and water pipes shall
on no account be used for earthing purposes. All wiring shall be kept as far as possible away from
gas and water pipes.Domestic Appliances :6.9For the safety of the wiring at the consumer's
premises, separate circuit for heaters, geysers, air-conditioners and for cooking apparatus like oven,
microwave oven shall be run with adequate size of wire from the main distribution board of the
consumer. Wall plugs used on the circuits for domestic appliances shall be of the three-pin type, the
third pin being connected to "earth"Plugs :6.10All plugs shall be provided with switches on the live
wire and not on the neutral.Apparatus Interfering with Licensee's System6.11The licensee may
discontinue the supply giving reasons if the consumer installs any instrument, apparatus that are
likely to affect adversely, the supply to other consumers. Supply shall be restored on taking
appropriate remedial action to the satisfaction of the licensee.A.C. Motor Installations :6.12The
motor shall be provided with control gear so that the starting current of consumer's installation does
not in any case exceed the limits given in the following schedule :-
Nature of
supplySize of installation Limit of starting current
Single
PhaseUp to and including 1 HP Six times full load current
Three
phaseAbove 1 HP and upto 10HPAbove 10
HP and upto15 HPAbove 15 HPThree times full loadcurrentTwo times full
loadcurrentOne and a half times full load
current
Failure to comply with these regulations will render the consumer liable for disconnection
forthwith.Consumers Apparatus6.13The apparatus/appliances/gadgets used by consumers should
conform to the standards and specifications prescribed by the Bureau of Indian Standards or
equivalentAll new pumping set connections/reconnections shall ensure minimum losses and to
achieve the same, shall conform to the requirement of Bureau of Energy Efficiency, and shall not be
inferior, and shall also have the following:-(a)Friction less foot valve(b)HDPE piping suction and
delivery(c)ISI marked energy efficient monoblock pump set.(d)Capacitor of adequate rating for the
pump set, as provided in the tariff order.The licensee shall collect the data of water levels in the
areas from appropriate/ concerned authority/agency, and if this calls for enhancement of load, the
consumer shall be required to get the load enhanced.Power Factor of Apparatus :Welding
Transformers:6.14LT installations with welding transformers will be required to have suitable shunt
capacitor(s) installed so as to ensure power factor of not less than 90%. Such consumers shall be
liable to pay surcharge as specified by the Commission, from time to time, on account of poor power
factor.Low Tension Shunt Capacitor:6.15Every L.T. consumer, including irrigation pump set
consumer, whose connected load includes induction motor(s) of 3 HP and above or otherwise given
in Tariff Order in force, and other low power factor consuming appliances shall arrange to install
Low Tension Shunt Capacitors of appropriate capacity at his cost across the terminals of his
motor(s), as given in Clause 6.166.16(a)The consumer in whose LT connection the meter provided
by the licensee does not have the power factor recording feature, shall ensure installation of shuntBihar Electricity Supply Code, 2007

capacitors as per ratings indicated in the table given below and shall maintain these capacitors in
working condition :-
Sl. No. Rating of Individual Induction Motor KVAR Rating of LT Capacitors
1 3 HP and above up to 5 HP 1
2 Above 5 HP up to 7.5 HP 2
3 Above 7.5 HP up to 10 HP 3
4 Above 10 HP up to 15 HP 4
5 Above 15 HP up to 20 HP 5
6 Above 20 HP up to 30 HP 6
7 Above 30 HP up to 40 HP 7
8 Above 40 HP up to 50 HP 8
9 Above 50 HP up to 99 HP 9
The consumer in whose LT connection, the meter provided by the licensee has the power factor
recording feature, shall install shunt capacitors of adequate capacity to ensure power factor of 90%
and above.(b)Supply to LT installations with induction motor(s) of capacity of 3 HP and above will
not be given unless suitable capacitors to improve power factor are installed.6.17LT consumers in
whose case the meter installed does not have power factor recording feature and fails to provide LT
capacitors as specified hereinbefore and fails to maintain in working condition would be liable to
pay surcharge as may be specified in the tariff order from time to time. LT consumer in whose case,
the meter installed has power factor recording feature and who fails to maintain power factor within
specified limits, as recorded by meter, by installing appropriate capacitors would be liable to pay
surcharge as may be specified in the Tariff Order from time to time.6.18The licensee may
discontinue supply, after due notice of 15 days, to any installation where the average power factor in
a month is less than 70% where meter installed is having P.F. measuring feature. In case LT
capacitors are not installed or installed but not in working conditions then in that case also the
supply shall be disconnected after due notice of 15 days without prejudice to the right of the licensee
to levy demand/minimum charges as applicable during the period of disconnection.High Tension
Consumers:6.19The following controls shall be installed (refer Section 50 of IE Rules, 1956)(a)A
linked switch with fuse(s) or a circuit breaker for consumers having aggregate installed
transformer/apparatus capacity up to 1000 kVA if supplied at voltage of 11 kV and 2500 kVA if
supplied at a voltage of 33 kV.(b)A circuit breaker along with linked switch for consumers having an
aggregate installed transformer/apparatus capacity above 1000 kVA if supplied at 11 kV and above
2500 kVA if supplied at 33 kV.(c)In either case, suitable automatic circuit breakers shall be installed
on the low tension side of each transformer or on each feeder.Extra-High Tension
Consumer6.20Extra-High Tension consumer shall install a circuit breaker on HV side of the
transformer (refer Section 50 of IE Rules, 1956).HT/EHT Consumers6.21All transformers,
switch-gears and other electrical equipments in the installation of the consumer and also those
directly connected to the feeders or lines of the licensee shall be of suitable design and be
maintained by the consumer to the reasonable satisfaction of the licensee.The setting of fuses and
relays on the consumer's control gear, as well as the rupturing capacity of any of his circuit breakers,
shall be subject to the approval of the licensee.6.22Notwithstanding the provisions under clause 6.19
it is necessary that the consumer should obtain prior approval of the Electrical Inspector about theBihar Electricity Supply Code, 2007

suitability of protective devices or circuit breakers in accordance with the provisions of the
prevailing laws, rules and regulations.6.23The consumer shall maintain a power factor of 90% and
above. Consumers shall be liable to pay surcharge or receive incentive specified by the Commission,
from time to time, on account of variation from specified power factor. The Railway traction
consumers shall also maintain a power factor of 90% and above or as provided in Tariff Order. The
licensee may discontinue supply except Railway traction, after due notice of 15 days, to any
installation where the average power factor is less than 70% without prejudice to the right of the
licensee to levy demand/minimum charges as applicable during the period of
disconnection.Inspection and Testing of Consumer's Installation6.24Before any wiring or apparatus
in the case of low-tension consumer, and any transformer, switchgear or other electrical equipment
in the case of high-tension consumer is connected to the system, it shall be subject to inspection and
approval of the licensee and no connection shall be made without the licensee's approval. In
addition, all high-tension installations will have to be approved by the Electrical Inspector and all
electrical installations in mines will have to be approved by the Inspector of Mines.6.25Upon receipt
of the test report, the licensee will notify to the consumer the time and day when the licensee
proposes to inspect and test the installation. The consumer shall ensure that the Licensed Electrical
Contractor or his representative, technically qualified, employed by him is present at the time of
inspection to furnish to the licensee any information concerning the installation required by him.
The licensee shall provide a copy of the inspection report to the consumer and obtain the
acknowledgement of the consumer.6.26Manufacturer's test certificate in respect of all H.T.
apparatus shall be produced, if required, by the Licensee.6.27The licensee shall not connect the
conductors and fittings at the consumer's premises with its works unless it is reasonably satisfied
that the connection will not at the time of making connection cause a leakage from the installation
or apparatus of a magnitude detrimental to safety. The value of the insulation resistance should be
as provided in Rule 48 of I.E. Rules 1956.6.28If the consumer's installation is found to be not safe
for connection, the licensee shall advise the consumer in writing specifying the defects to be
rectified. On receipt of intimation of rectification of defects, the licensee shall retest the
installation.6.29The licensee shall levy no charge for the first test. Subsequent tests, necessitated
due to faults found at the initial test shall be charged for in accordance with the rates approved by
the Commission. The licensee will not accept any responsibility with regard to the maintenance or
testing of wiring on the consumer's premises.Extensions and Alterations :6.30No electrical
installation work, including additions, alterations, repairs and adjustments to existing installations,
except such replacement of lamps, fans, fuses, switches, low voltage domestic appliances and fittings
as in no way alters its capacity or character, shall be carried out upon the premises of or on behalf of
any consumer, for the purpose of supply to such consumer except by an electrical contractor
licensed in this behalf and under the direct supervision of a person holding a certificate of
competency. Extension or alteration of load to all high-tension installations will have to be approved
by the Electrical Inspector and similarly for all extensions and alterations of electrical installation in
mines will have to be approved by Inspector of Mines.6.31If as a result of such proposed extensions
and alterations, there is possibility of an increase in connected load or contract demand over
sanctioned connected load or contract demand, the consumer shall take steps to submit requisition
for additional supply. Failure to regularize the increase in connected load or contract demand may
not only result in billing at the penal rates, as provided for under the rules, but may also result in
disconnection of supply after due notice.Access to Consumer's Premises6.32The licensee or hisBihar Electricity Supply Code, 2007

authorized staff may, at any reasonable time, and on informing the occupier of their intention, enter
any premises to which electricity is supplied is or has been supplied by the licensee to any premises
or land under, over across, in or upon which the electric supply lines or other works have been
lawfully placed by the licensee for the purpose of (i) inspecting and reading meters (ii) for
disconnecting supply, (iii) for removing the licensee's apparatus, (iv) for inspecting testing, repairs,
replacing, altering and maintenance of its property or for doing all things necessary or incidental to
proper continuance and maintenance of supply to the consumer. All such persons visiting
consumer's premises must carry photo-identity cards issued by the licensee and shall produce the
same to the consumer or the occupier before entering the premises. The consumer should
immediately check with the licensee if the credentials of representatives are doubtful.6.33The
Licensee or his authorized staff shall be entitled to enter the premises immediately after informing
the consumer, for checking unauthorised use of energy, unauthorized additions and alterations to
equipment, theft and misappropriation of energy, diversion of power, by-passing or tampering of
the meter, or for general inspection and testing. On detection of unauthorised use of energy,
unauthorized addition and alteration to equipment, theft and misappropriation of energy, diversion
of power or bypassing or tampering of the meter the licensee may take actions as per prevailing
laws.6.34Provided that no inspection, testing or checking of any domestic premises shall be carried
out between sunset and sunrise except in the presence of an adult male member occupying such
premises.6.35If the consumer does not provide access to the licensee or its authorized
representatives to enter the premises for the reasons stated in clause 6.32 and clause 6.33, the
licensee may give a 24 hours notice in writing to the consumer, of its intention to discontinue the
supply. If the consumer still does not provide access, the licensee shall be entitled to discontinue
supply to the consumer.6.36If the insulation resistance of the consumer's installation is found to be
so low as to prevent safe use of energy, the licensee or his authorized representative after giving 48
hours notice shall, without prejudice to other actions as per law, disconnect the supply of power to
such premises till the defects are removed, in accordance with Rule 49 of Indian Electricity Rules,
1956.Rating of Installations:6.37The connected load of Domestic category of consumers shall be
determined as per the procedure given in [Annexure-4 and 4(1).] [Amended by Notification No.
603, dated 18 August, 2010.] Survey of load shall be carried out normally once in two years. The
licensee may also carry out verification of load in selected areas periodically. However, if the licensee
has reasons to believe that a particular domestic connection or a group of domestic connections
might be involved in unauthorised abstraction of power, the officer in-charge may conduct a survey
of the consumer's premises.6.38The licensee shall send formats of 'self declaration of connected
load' along with electricity bills to all consumers once in six months. The consumers may fill-up the
form, if his actual current connected load is at a variance from the recorded connected load and
submit to the licensee while making payment of the bill. The domestic consumers may also declare
enhanced connected load of his premises, any time during the year, by completing the format given
in Annexure-4A and submitting the same to the licensee along with an application for change in
connected load.On receipt of application/declaration the licensee may arrange to conduct a survey
of the premises of the consumer to determine the load of the premises. In case such a survey is not
carried out within thirty days from the date of submission and the load applied for is higher than the
recorded load of the consumer, the load declared by the consumer shall be deemed to have been
accepted. The licensee shall issue the demand note for additional charges, if any,
immediately.6.39The connected load of all categories other than Domestic category of consumersBihar Electricity Supply Code, 2007

shall be the aggregate of the manufacturer's rating plates of all energy consuming devices, in the
consumer's premises, which can be used simultaneously. This shall be expressed in kW, kVA or HP.
During the process of determination of connected load, if the manufacturer's rating plate is not
available, the licensee may use suitable apparatus to determine the load of such device. If, both air
conditioner and room heater are found in the same premises, the load of the item with higher rating
shall be taken into account., Items stocked for the purpose of sale/repair or genuinely as spare shall
not be considered for the purpose of determination of connected load. The licensee shall carryout
periodic survey of street lights and record the type of lamps being used along with their load.6.40All
installations other than those of Domestic category are subject to rating/re-rating by the licensee at
its discretion. If the consumer is not satisfied with the rating determined by the licensee, he may get
his apparatus rated by one of the recognized engineering institutes approved by the licensee for
determination of load of apparatus. Both the consumer and the licensee may appoint their
respective representatives to be present during the process of determination of load at the institute.
The final report issued by the institute shall be accompanied with the details of test(s)
conducted.The rating determined by the said institute shall be final and acceptable to both the
consumer and the licensee.6.41Where for any reason, it is not possible to determine the maximum
demand, power factor or any other electrical quantity in respect of an installation, the licensee shall
determine such quantities periodically by rating/re-rating, and the procedure for the same shall be
got approved by the Commission.6.42If a consumer applies to the licensee for re-rating his
installation due to additions or alternations in the installation, the procedure as stated in clause 6.37
to clause 6.41 shall apply.Parallel Operation with the Supply System of the Licensee6.43Operation of
generator in consumer's installation in parallel with the licensee's system is permissible only with
the written consent of the Licensee.However, the consumer may install generator, inverter to use
only in the case of failure of power supply, shall install double link switch changer so that the
current of generator/inverter and the consumer shall install double link switch changer so that the
current of generator/inverter may not be injected in the licensee's distribution system. The capacity
of the generator/inverter shall not be taken into account for calculation of connected
load.6.44Where no such consent has been given, the consumer shall arrange the plant, machinery
and apparatus of his generating units, including an extension of or addition to the same, to operate
in an isolated mode and the generator, in no case, should get connected to the licensee's system. The
licensee, on intimating the consumer, can enter the premises and inspect the arrangement to ensure
that at no time the generator gets connected to its system.6.45Where consent has been given for
parallel operation, the consumer shall arrange his installation to protect if from disturbances in the
licensee's system. The consumer should also ensure that his supply does not get incorrectly
connected to the licensee's system. The licensee shall not be liable for any damage caused to the
consumer's plant, machinery and apparatus on account of such parallel operation, or any adverse
consequence arising thereof. For parallel operation with the grid, the consumer shall have to follow
the provisions of the Bihar Electricity Grid Code and other relevant regulations. The actual
operations shall be carried out in coordination with both the State Transmission Utility and the
licensee.6.46In case the consumer's supply gets extended to the licensee's system from a generator
or inverter or from any other source, without appropriate approval from the licensee, causing
damage to the licensee's apparatus or to human life, the consumer shall be liable for the same and
shall duly compensate the licensee for all losses caused to the licensee or to the licensee's other
consumers.HarmoniesThe licensee shall publicise the need for installation of Harmonic filters. AllBihar Electricity Supply Code, 2007

HT consumers, and LT commercial consumers (above 15 KW) to begin with, shall be given a time
period of one year from the date of implementation of this Code, after which, Harmonic filters shall
become mandatory on such consumers.6.47If the licensee detects and proves to the consumer that
the consumer's system is generating harmonics above acceptable limits, the licensee shall request
the consumer to install appropriate harmonic filter. The consumer shall install such filters within a
period of six months from the date of request by the Licensee.
Chapter 7
Service Connection Related Matters
Contract Demand
7.
1.
The Contract Demand for LT consumers without Maximum Demand based (two part) tariff shall be
the connected load of the premises as per the agreement entered into between the consumer and the
Licensee.7.2The Contract Demand for LT Consumers with MD based tariff and all HT and EHT
consumers shall be as per the agreement entered into between the consumer and the Licensee and
having regard to the requirement of the consumer's installation.Procedure for Disconnection of
Supply7.3he supply may be disconnected temporarily or on a permanent basis as per the procedure
described below :-(i)The Licensee shall remove service line, meter etc after permanent
disconnection.(ii)However, the Licensee may not remove service line, meter etc in case of temporary
disconnection.(iii)The licensee may remove service line/cable if he has sufficient reason of
unauthorized use of electricity in case of temporary disconnection. However meter shall not be
removed in such cases.Temporary Disconnection7.4The supply shall be disconnected temporarily
only after due diligence, and if the cause of the disconnection is not removed within the number of
days indicated in notice served in the manner as described in Section 171 of the Act, in each of
following cases, within :-(a)The disconnection date indicated in the notice served to the consumer,
but not less than 15 days, if electricity bills on account of charges of electricity, or any sum other
than a charge for electricity, are not paid, provided further that the amount of bill indicated in notice
is not stayed by any court of law, else, the supply shall not be disconnected :Provided that the supply
of electricity shall not be cut off if such person deposits, under protest,-(i)an amount equal to the
sum claimed from him, or(ii)the electricity charges due from him for each month calculated on the
basis of average charge for electricity paid by him during the preceding six months,whichever is less,
pending disposal of any dispute between him and the licensee.(b)After a minimum period of seven
days, if of a particular business/ industry, any activity being carried out becomes unlawful due to
lack of necessary permission or withdrawal of permission from the authority competent in
law.(c)After a minimum period of seven days, if the power factor of consumer's installation other
than the following categories of consumer is less than 70% during any billing period unless
otherwise specified in the tariff order-(i)Domestic having connected load up to 10
KW(ii)Non-domestic having connected load up to 5 KW(d)Within 48 hours,* if the wiring,Bihar Electricity Supply Code, 2007

apparatus, equipment or installation at the premises of any consumer is found to be defective,* if
there is leakage of electricity,* if the consumer is found to have altered the position of the meter and
related apparatus,* if the consumer uses any apparatus or appliance or uses the energy in such
manner as to endanger the service lines, equipment, electric supply mains and other works of the
Licensee,* if the limits of Maximum current demand at the consumer installation is exceeded
beyond the limits indicated in table under clause 6.12,* if it is found that consumer is using
electricity in any manner which unduly or improperly interferes with the efficient supply of energy
to any other consumer.(e)The disconnection date indicated in the notice served to the consumer, but
not less than 15 days, if consumer defaults in making payment of the assessed amount as a result of
unauthorized use of electricity as per the procedure specified in clause 11.1 of the Code. Provided
that serving of notices before disconnection shall not be essential in cases of theft of electricity
where the licensee has a prima facie evidence and in such other cases wherever express provisions
for disconnection have been made.(f)At least 30 days, if the consumer fails to deposit the additional
security or the security has become insufficient.(g)After a minimum period of* (sic) - hours if the
consumer fails to give the Licensee or his authorized person reasonable facility for such entry or
performance as specified in clause 6.32 to 6.36 of the Code.(h)After a minimum period of seven days
in case of dishonouring of the cheque by the bank, non-encashment of cheque.7.5(a)The Licensee
shall, after a connection is temporarily disconnected, bill a consumer a minimum charges, and also
issue a notice, format given in Annexure-5, to the consumer, to remove the cause of disconnection
failing which, the supply shall be disconnected permanently and agreement shall be terminated after
the notice period for termination of agreement as specified in clause 7.13 of the Code or on
completion of initial period of agreement whichever comes later. Such connection shall be treated as
dormant connection (awaiting final account), and the billing shall be stopped after carrying out
inspections and duly informing the consumer, and final account of the consumer shall be
prepared.(b)Wherever licensee discovers that connection has been re-connected unauthorisedly
after temporary disconnection, licensee may initiate action as per provisions of Section 138 of the
Act.7.6Permanent Disconnection- (i) The supply shall be disconnected permanently in following
cases:(a)With the termination of the agreement.(b)If the cause for which the supply was temporarily
disconnected is not removed within the notice period specified in the agreement for termination of
agreement or initial period of agreement whichever is later.(c)On request of consumer as described
under clause 7.14(2) of the Code.(ii)If the dues are not paid by the consumers the delayed payment
surcharge payable by the consumer on dues shall be levied upto the period of issue of notice under
clause 7.5 of the Code.(iii)The security amount shall be adjusted first and after adjusting the security
amount the net arrear shall be calculated on which delayed payment surcharge shall be payable by
the consumer.7.7Procedure for Reconnection(a)A connection that is disconnected permanently shall
not be reconnected and the consumer shall have to apply for a new connection.(b)In case of
temporary disconnection, supply shall be reconnected after the cause of disconnection has been
removed.(c)If the disconnection was on account of non-payment of bill, the connection shall be
reconnected on an application of the consumer accompanied by the copy of the payment receipt of
the dues.(d)On receipt of payment of dues along with the prescribed disconnection and
reconnection fee. Supply shall be reconnected within 24 hours of the submission of the complete
application. Provided where service cable/conductor has to be re-erected, the connection shall be
reconnected within 48 hours.(e)If payment is made by Cheque (other than Banker's Cheque) supply
may be reconnected after realisation of the Cheque.(f)In other cases, the applicant shall apply forBihar Electricity Supply Code, 2007

reconnection after removal of the cause alongwith the prescribed disconnection & reconnection fee
and the following documents :-(i)Receipt of payment of disconnection/reconnection fee.(ii)Test
report by a Licensed Electrical Contractor (LEC), if the disconnection was made under clauses 7.4
(d) and 7.4 (e).(iii)Documentary evidence of removal of cause if the disconnection was made under
clause 7.4.(iv)An affidavit in cases covered under clause 7.4 (e).(v)Receipt of payment for
regularisation of excess load (security amount, system loading etc) in cases covered under clause 7.4
(f).The Licensee shall inspect the premises on intimation of removal of cause of disconnection by the
consumer and if he is satisfied that the cause of disconnection has been removed the supply shall be
reconnected within 24 hours of intimation and 48 hours where service connection are to be
re-erected.7.8Change of Category- (i) "Category of Consumer" means the Tariff Schedule under
which a consumer is billed as per latest applicable Tariff Order of the Commission. The applicant
shall apply for change of category from one tariff rate schedule to another in the format prescribed
at Annexure I or II. Tariff change from any L.T. category to Agriculture category shall not be
permissible. Tariff change from higher rate to lower rate shall be done only after completion of
compulsory period of availing supply.(ii)In case sanction of new category is not permitted under any
law in force, the licensee shall inform the consumer within 15 days from the date of acceptance of
application.(iii)The licensee shall inspect the premises to verity and shall change the category within
the time limit specified in the Standards of Performance of Distribution Licensee Regulations from
the date of receipt of application.(iv)Change of category shall be effective from next billing
cycle.(v)No case of unauthorized use of energy shall be booked by the Licensee if detected after the
consumer had applied for change of category and change is legally permissible.(vi)The application of
the consumer shall be treated as fresh application and accordingly he will deposit processing fees,
new additional security, if any, and execute supplementary agreement wherever necessary.(vii)In
case of Government residential quarter mutation in favour of any new occupant shall be allowed
after the new occupant furnishes the letter of allotment and proof of date of occupancy in such cases
mutation shall be allowed from date of occupancy.7.9Transfer of Connection and Mutation of
Names(a)A connection shall be transferred in the name of another person upon the death of the
consumer or in case of transfer of ownership or occupancy of the premises, upon an application of
the consumer.(b)Application for mutation shall be filed, in the prescribed format Annexure I or II,
along with prescribed fee by the transferee or the legal heir or successor of the deceased consumer
with the local office of the Licensee.(c)The application shall be accompanied by documentary
evidence of transfer or legal heirship or succession and proof of no arrears on account of electricity
charges on that connection.(d)The licensee shall decide the mutation case within the time limit
specified in the Standards of Performance of Distribution Licensee Regulations of the
Licensee.(e)However, if the mutation application is to be disallowed and mutation is refused the
orders shall be passed only after the applicant has been given an opportunity to present himself, by a
speaking order. Provided further, that in case where mutation is not allowed, the transferee seeking
the transfer, may agree to continue the connection in the old name (but not in case of consumer's
death), or may have choice to seek permanent disconnection and apply for new connection.(f)The
transferee or the legal heir shall submit a fresh agreement, in the prescribed format, along with
pending dues, if any, within 14 days. The transfer shall be affected and a copy of the agreement shall
be sent to the consumer within 7 days.(g)In case of Private Tubewell (PTW) consumers, suo-motu
mutation may be undertaken after taking the report from the Government revenue department.
However the legal heir shall be responsible for clearing the electricity dues, and shall submit anBihar Electricity Supply Code, 2007

affidavit to this effect.(h)In case of Government residential quarter mutation in favour of any new
occupant shall be allowed after the new occupant furnishes the letter of allotment and proof of date
of occupancy in such cases mutation shall be allowed from date of occupancy.7.10Procedure in Case
of Change in Wiring and/or Apparatus or Shifting of Service Line in the Premises of the Consumer-
The consumer may apply to the licensee for any changes in their premises related to
wiring/apparatus/service line, after clearing all dues pending if any provided the same are not
stayed by any court, subject to the following :(a)The consumer shall get all work relating to wiring
on his premises only by or under the supervision of a Licensed Electrical Contractor and obtain a
Work Completion certificate and Test report, as prescribed by Indian Electricity Rules, 1956 until
Regulations are issued under the Electricity Act, 2003. [If a consumer wants to shift his electric
connection to a new premises in the same billing area of the licensee, the same may be allowed
subject to technical feasibility, payment of all dues, shifting cost and after completion of all
formalities subject to the following conditions. [Added by Notification No. 603, dated 18 August,
2010.](i)that spare load is available on the distribution transformer.(ii)that the existing load of the
consumer does not exceed 5KW.](b)No reference shall be made to the Licensee if the change in
wiring of LT loads does not result in dislocation of the meter or other related apparatus and there is
no change in the load. However, the consumer shall produce the test report if required by the
Licensee in future.(c)In other cases, if the consumer desires to alter the wiring on his premises, or
change the location of meter or other related apparatus or shift the service line on his premises
notice thereof shall be sent in writing with the modified wiring diagram and other necessary details
to the licensee. The licensee shall after due enquiry grant approval, intimating the estimated charges
to be deposited by the consumer with or without modification to the proposal, or reject the request
stating reasons thereof, in writing, within the time limit specified in the Standards of Performance of
Distribution Licensee Regulations.(d)The work relating to change in wiring shall be done by the
consumer through a licensed electrical contractor and the work completion certificate along with
test results shall be provided to the licensee. The licensee shall inspect the premises to confirm that
the alteration(s) is in accordance with the approval given by him and the Indian Electricity Rules,
1956 until Regulations are issued under the Electricity Act, 2003.(e)The work of change in position
of point of supply, meter or related apparatus and shifting of service line shall be done by the
Licensee at the cost of the consumer. The estimate for this work shall be sent to the consumer along
with the approval and work shall be completed within the time specified in the Standards of
Performance of Distribution Licensee Regulations from the date of the money
deposited.7.11Procedure for Enhancement of Contract Demand/Connected Load(1)Applications for
enhancement of load shall be submitted in duplicate to the concerned officer of licensee in the
prescribed form (attached as Annex 1&2).(2)The licensee shall inspect the premise within seven
days of receipt of application or otherwise provided in the Standards of Performance of Distribution
Licensee Regulations to examine the feasibility of supply of the enhanced load and intimate the
consumer:(a)Whether the additional power can be supplied at the existing voltage or at a higher
voltage.(b)Whether any addition or alterations are required to be made to the system and the cost to
be borne by the consumer.(c)Amount of additional security deposit, cost of additional infrastructure
and the system strengthening charges if any, to be deposited.(d)Change in the classification of
consumer, if required.(3)The application for enhancement of the contract demand will not be
accepted if the consumer has any arrears of payment of the licensee's dues. However, the application
may be accepted if the payment of arrear due from the consumer has been stayed by a Court of law,Bihar Electricity Supply Code, 2007

or by the Commission or an authority appointed by the Commission.(4)If supply of enhanced load is
found feasible, the consumer shall be asked to:(a)Furnish work completion certificate of consumer's
installation and Test report from a licensed electrical contractor where alteration of installation is
involved.(b)Furnish Letter of approval for the electrical installation of the consumer from the
Electrical Inspector, if required.(c)Deposit additional security deposit, cost of addition or alteration
required to be made to the system, if any, and the system strengthening charges as
applicable.(d)Execute a fresh agreement as per enhanced load which shall be a new statutory
agreement period and the old agreement shall stand terminated.(5)If no addition or alteration to the
system including new/ alternate metering arrangement is required, the enhanced load will be
released within 20 days or as specified in the Standards of Performance of Distribution Licensee
Regulations subject to completion of the requisite formalities. If the system needs any alteration or
addition, the procedure as given for a new connection shall be followed.(6)In case of 'Railways
Traction', the consumer may be provided such additional supply in excess of contract demand as
may be agreed between the licensee and the consumer after the latter has given due notice of six
weeks in writing of his desire to have the contract demand altered.7.12Procedure for Reduction of
Contract Demand/Connected Load(1)Application for reduction of load, after the expiry of initial
period of agreement, upto the limit specified in clause 7.12(5) of the Code shall be made in duplicate
to the concerned officer of Licensee in the prescribed form along with the following
documents:(a)Details of alteration/modification/removal of the electrical installation along with
work completion certificate and Test report from a licensed electrical contractor where alteration of
the installation is involved.(b)Any other reason for reduction of contract demand.(c)Maximum
demand recorded in the last two billing cycles if the meter has facility to record maximum demand
along with the electricity bills for the same.(d)Details of generators, if any, installed by the consumer
along with copies of the safety clearance certificate issued by the competent authority for installation
of the generators.(2)On receipt of the application for reduction of load, the licensee after verification
shall sanction the reduction of load within thirty days or notice period for termination of agreement
as specified in the agreement whichever is later from the date of acceptance of application.(3)If the
sanction is not granted by the licensee within the period specified in clause 7.12(2) above, the
applicant may, by a written notice to the licensee, draw its attention to the matter and if the decision
is still not communicated to the applicant within the period of further thirty days, the permission of
reduction of contract demand shall be deemed to have been granted.(4)The reduced Contract
Demand shall take effect from the first day of the month following the month in which the sanction
is communicated or 'deemed permission is granted'.(5)The above reductions are subject to
permissible minimum contract demand specified in clause 3.4 of the Code. Request of the consumer
for reduction in contract demand of his connection shall not be refused by the licensee on the
ground that there are dues payable to the licensee against the connection.(6)In all existing
agreements executed prior to this Code coming into effect, if there is any provision regarding
restriction on reduction of Contract Demand, the same shall be deemed to have been modified to the
extent of the provision made in this Code.(7)When reduction of contract demand is agreed to, the
consumer shall execute a fresh agreement for reduced load. The licensee shall recalculate the
security deposit and any excess security deposit shall be adjusted in future bills not exceeding six
succeeding bills.(8)The reduction of Contract Demand load shall not be permitted in following
cases:(i)Arc/Induction furnaces, rolling and re-rolling mills and mini steel plants shall not be
allowed to reduce the load below the total rating of machines and furnaces installed in the premises,Bihar Electricity Supply Code, 2007

except in case of removal of any equipment or replacement of any old equipment by new equipment
and also to the extent of captive generation capacity that may be installed and is operating in
parallel. Auxiliary load shall be excluded.(ii)Contracted load shall not be reduced below the total
rating of installed machines in case of Small & Medium industrial and private tube wells consumers,
having no MDI meter.(iii)Load shall normally not be reduced within initial period of the agreement
from the date of commencement of supply. However, if the consumer is willing to pay the
fixed/minimum charge applicable for the quantum of contracted load surrendered/reduced for the
balance period of initial period of agreement or period of notice specified in the agreement for that
category of consumer, whichever is higher, reduction may be allowed.(iv)No application for
reduction of load shall be rejected without recording reasons and the decision shall be
communicated to the applicant.7.13Agreement(1)An agreement, in the format, approved by the
Commission, shall be executed by the applicant on a stamp paper of a prescribed value in duplicate,
for getting a new connection and for change in the agreed parameters like contract demand, etc. In
case of single phase domestic and non domestic consumers, the application form itself shall be
treated as agreement and the main ingredient of agreement shall be incorporated in the application
form. In any special circumstances, special clauses may be added to the agreement, if agreed to
between the licensee and the consumer, provided such clauses do not contravene the provisions of
the Electricity Act 2003 (36 of 2003), the Electricity Supply Code, and other Rules and regulations
in force.These special clauses shall form a part of the agreement. A copy of the stamped agreement
shall be given to the consumer after execution and commencement of supply. The maps submitted,
agreed upon and signed by both the consumer and the licensee shall form a part of the
agreement.(2)The compulsory period of availing supply from the date of commencement of supply
or initial period of agreement shall be one year for LT consumers and two years for HT consumers.
The licensee may modify the structure of the agreement formats presently in use with the approval
of the Commission in order to meet any requirement that may arise as a consequence of the
provisions of this Code so that the format is consistent with the Act and prevailing Rules,
Regulations and the provisions of this Code.(3)No consumer shall sell electricity supplied to him by
the licensee to any other person.(4)In case of breakdowns in electricity supply system of the
licensee, the supply of electricity to the consumer may be curtailed, staggered or cut-off as may be
warranted according to the situation. The licensee may also curtail, stagger or cut-off electricity
supply to consumers on account of periodical maintenance of electricity supply system, after giving
due notice to the consumers.(5)The licensee may resort to regulation (planned load-shedding) of
supply to the consumers, after due notice, if the Commission orders accordingly as per the
provisions of Section 23 of the Act.(6)The electricity supplied to the consumer shall not be utilized
by the consumer in any manner prejudicial to the licensee and all usage must be in accordance with
the provisions of the agreement and the Act as applicable.(7)No consumer shall divert the use of
electricity to any other purpose, other than that mentioned in the agreement or extend the line
beyond its premises other than that for which it was sanctioned by the licensee, until and unless
prior sanction of the licensee is obtained for such diversion or extension.(8)If there is a need to
modify/amend the agreement signed between the licensee and consumer, it will be done by a
supplementary agreement.(9)Where the consumer's installation is disconnected from the licensee's
supply as per direction of the Government or the Electrical Inspector, the supply shall be
reconnected on payment of prescribed reconnection fee with the approval of the Government or the
Electrical Inspector or other appropriate authority, as necessary. During the period of temporaryBihar Electricity Supply Code, 2007

disconnection the consumer shall be liable to pay the demand/minimum charges.(10)Any
amendment for the purpose of change of name, shifting of premises within the same billing area,
change in connected load/contracted load, change of tariff category, etc. shall be done and the same
shall be incorporated in the agreement by execution of a supplementary or a fresh agreement.(11)A
register of agreements executed by all LT and HT consumers shall be maintained by the Licensee at
its designated office.7.14Termination of Agreement(1)The agreement shall remain in force even after
completion of the initial period of agreement until it is terminated. Domestic and single-phase
Non-domestic category of consumers may terminate the agreement after giving one month's notice.
Consumers other than domestic and single phase non-domestic under LT category can terminate
the agreement on giving three month's notice. In case of HT six month's notice and one year in case
of EHT & Railway is required:Provided that the agreement shall normally be terminated after expiry
of the initial period, of agreement. However, if the agreement is to be terminated for reasons
whatsoever, before expiry of the initial period of agreement, the consumer shall be liable to pay
charges as per tariff order for the balance period of the said one-year in case of LT and two years in
case of HT or notice period specified in the agreement whichever is higher. The licensee shall
arrange for special meter reading, at a mutually acceptable date, to facilitate preparation of the final
bill of the consumer. The agreement shall be terminated on the last day of the billing month and the
licensee shall raise the final bill accordingly.(2)If power supply to a consumer remains disconnected
for a period more than notice period for non-payment of charges or dues or non-compliance of any
direction issued under this Code, the licensee shall issue a show cause notice, to be replied within
seven days, to the consumer for termination of the agreement. In case no effective steps are taken by
the consumer for removing the cause of disconnection and for restoration of power supply the
agreement of the licensee with the consumer for power supply shall be terminated on expiry of the
period of seven days, provided the initial period of the agreement is over. If initial period is not over
the provision given under Clause 7.14(1) above shall apply. During the period of temporary
disconnection the consumer shall be liable to pay the demand charges or minimum charges as
applicable.(3)On termination of the agreement, the licensee shall be entitled to remove the service
line and other equipment of the licensee for supply of power from the premises of the consumer.
After permanent disconnection, if the consumer wishes to revive the connection, then it would be
treated as an application for new connection and would be entertained only after all outstanding
dues have been cleared.7.15Security Deposit(1)The licensee may take a security deposit from the
consumers for consumption equivalent to the estimated consumption of specific period as indicated
in the table below or as otherwise provided in Tariff Order in force.
Sr
No.Nature of
ConsumerNo. (of
months)Remarks
1 Agricultural Three Annual average to be estimated/considered
2 Seasonal TwoConsumption during the season of operation to be
estimatedconsidered
3 Other consumers Two Annual average to be estimated/considered
(2)Consumer shall have the option to make advance payment and in such event security amount
shall be proportionately fixed. The procedure for determination of security deposit, for different
categories of consumers, shall be determined by the licensee and approved by the Commission. TheBihar Electricity Supply Code, 2007

deposit shall be accepted in the form of cash, cheque or draft in case of LT consumers and in the
form of draft or banker's cheque in case of HT consumers.The Licensee shall maintain separate head
of account of such security deposits. On termination of the agreement, the security deposit will be
refunded to the consumer after adjustment of the amount, if any, remaining payable by him.(3)The
amount of the security deposit obtained from the consumer will be reviewed by the licensee,
annually on the basis of consumption during the previous 12 months for LT consumers, and
half-yearly on the basis of consumption during the previous six months for HT/EHT consumers.
The consumer shall be required to pay an additional security deposit/shall be refunded based on his
average consumption during the period concerned and the tariff applicable etc. if it exceeds/ is
lower than the amount of the security deposit held by the licensee, by 20%.(4)In the case of
consumers who were sanctioned additional load, the additional security deposit shall be calculated
for the additional load as treating it a new service.(5)On the consumer's request, the licensee may
allow the consumer to pay additional security deposit in maximum three instalments.(6)The
licensee shall serve a notice of at least one month to deposit the additional security deposit. If the
consumer fails to pay the additional security deposit as per the notice, the licensee is entitled to
refuse or discontinue the supply of electricity so long as such failure continue. The consumer will be
liable to pay delayed payment surcharge on reducing balance in case of instalment system if he
delays payment of security deposit.(7)The distribution licensee shall pay interest, at the bank rate
notified by the Reserve Bank of India from time to time on such security deposits taken from the
consumer. In this regard it shall be the responsibility of the licensee to keep a watch on the bank
rate from time to time. The interest amount of previous financial year shall be adjusted in the energy
bill issued in May/June of each financial year depending on billing cycle.(8)The security deposit
along with interest thereon, if any, shall be returned to the consumer, upon termination of the
agreement and after adjustment of all dues, within 60 days of completion of formalities by the
consumer. In case of delay beyond 60 days period, additional interest at the rate mentioned at
Clause (7) above shall be payable to the consumer as approved by the Commission.(9)The
distribution licensee shall not take security deposit if the person requiring the supply is prepared to
take the supply through a pre-paid meter.
Chapter 8
Meters
Licensee's Obligation to Give Supply on Meters : Requirement of Meters
8.
1.
(a)No new connection shall be given without a Meter and Miniature Circuit Breaker (MCB) or
Circuit Breaker (CB) of appropriate specification from the date of notification of this Code.(b)All
unmetered connections including private tubewells street lights shall be metered by the
licensee.(c)The licensee shall not supply electricity to any person, except through installation of a
correct meter in accordance with the operation and installation of meters regulations issued by theBihar Electricity Supply Code, 2007

Central Electricity Authority under Electricity Act, 2003:Provided that the Commission may, by
notification, extend the said period for a class or classes of persons or for such area as may be
specified in that notification:Provided also that if a person makes default in complying with the
provisions contained in the clause 8.1 the Commission may make such order as it thinks fit for
requiring the default to be made good by the generating company or licensee or by any officer of a
company or other association or any person who is responsible for the default.8.2All consumers
shall have to accept the installation of an appropriate metering device, load-limiter, tamper proof
boxes or other apparatus when the licensee approaches them to install one, and the consumer shall
be required to provide appropriate and suitable site for placement of meter and related equipments
to the satisfaction of the licensee.8.3In case of HT supply, if HT metering cannot be readily
provided, LT metering may be provided on the LT side of the consumer's transformer. In such cases,
electrical quantities for billing purposes shall be computed by adding three percent to the reading
recorded on the LT meter towards transformation loss. This arrangement shall in no case continue
for more than three months and the licensee shall arrange to install a meter on the HT side of the
transformer within the said period including such existing connections/existing transformers. The
licensee shall inform such cases to the Commission.8.4If supply to an HT or EHT consumer is given
on an independent feeder for his exclusive use, the metering arrangement may be installed both at
the consumer's premises and at the Licensee's Sub-Station.8.5The licensee is authorised to review
the status of the meters already installed in the context of upgraded technology becoming available
and suitability of the site where meter is placed in the consumer's premises. The licensee may install
remote metering device in the consumer premises as per the technical requirements of the specific
device and in such cases the consumers shall provide access to the meter through his telephone line.
The licensee may also install maximum demand (MD) meter having MD recording feature or such
additional features in the consumer's premises. The licensee is also authorised to install 'check
meter' at one consumer's location or for a group of consumers. In case the difference in
consumption recorded by the 'check meter' and the 'billing meter' is found to be more than
permissible limits, the licensee shall be free to install the billing meter on electricity pole or pillar
boxes after giving due intimation in writing to the consumer. The licensee shall inform such cases to
the Commission.8.6Classification of Meters, etc.- The Meters for new connections shall be of
standard & make that is certified by BIS/IEC/CBIP or any other superior specification as specified
in Central Electricity Authority Regulations on Installation and operation of meters, and shall be of
following type(s):(a)For all domestic and other LT loads less than 25 kW loads in Urban and Rural
areas-Static meters(b)for LT (contracted load>25 KW)/HT/EHT consumers-- Static, 3 Phase
Tri-vector meters with MDI.- The meters shall have a facility for "Time of the Day Metering" with
sufficient memory for accommodating data for 12 months.- Three phase meters for HT/EHT
segment should be capable of recording with date and time stamping, the common system/
connection anomalies like phase wise missing potential, phase wise CT reversal, Current unbalance
& voltage unbalance.- The meters shall have anti-tamper features as per CEA regulations above and
duly approved by the Commission.- The meters shall have facility or remote communication for date
retrieval through GSM/Microwave/SCADA/VSAT, using standard protocol. The licensee shall
ensure the above within a definite time frame under intimation to the Commission.(c)The licensee
may install pre-paid meters for single phase metering and three-phase whole current supply which
should display the amount left, unit consumed, and the tariff applicable, with a disconnection/
tripping switch inside the meter.(d)Meter Seal should be made from high grade engineering plastic/Bihar Electricity Supply Code, 2007

polycarbonate material having permanent laser engraved unique serial number on seal, capable to
withstand the prescribed environmental tests. Sealing shall be done at the following points (as
applicable):º CT Secondary Boxes (in addition to locking arrangement)º PT Secondary Box (in
addition to the locking arrangement)º Meter CabinetNote : Seal of the consumer meter shall be
removed only by the licensee. No consumer shall tamper with, break or remove the seal under any
circumstances. Any tampering, breaking or removing the seal from the meter shall be dealt with as
per relevant provisions of the Act.(e)For all the 11 KV & 33 KV consumers, the licensee shall
introduce facility for taking remote meter reading (GSM technique), and for distribution
transformers, remote meter reading (with facility of low power Radio) to extract data from meter
centrally, in order to have access on data as and when required.(f)The accuracy class of meters for
EHT/HT/LT (whole current meters)/ LT/CT operated consumers, shall be as laid down* (sic ?)
regulations.8.7Supply, Installation and Ownership of Meters and Cut-outs/MCB's/CB's.- The
licensee shall supply the meter and metering equipments, cut-out/MCB/ CB/load limiter to
consumers at the time of serving new service connection or at any other time as required. The
licensee shall keep the meter in proper working condition and the consumer shall pay the monthly
rent, if any, for the meter and metering equipment at the rate approved by the Commission. If the
licensee fails, to keep the meter or metering equipment in proper working conditions, the consumer
shall not be liable to pay the meter rent for the period the meter remains defective.8.8At the time of
seeking a new connection the consumer shall indicate option in the application from to* (sic ?)
purchase the meter* (sic ?) MCB/CB and associated equipment himself from the authorized
vendor(s)/make or manufacturers of meter approved by the licensee, or require that such approved
meter, MCB/CB and associated equipment be supplied by the Licensee:Provided that it shall be the
responsibility of the licensee to ensure that meters of standard make only are used as specified in
clause 8.6 and CEA Regulation for installation and operation of meter. The licensee shall not restrict
the consumer's choice to 2-3 make/manufacturer only, but shall offer a wide ranging choice from
amongst the list of approved make/manufacturers.The Licensee shall put the list of approved
vendor(s)/make or manufacturers of meter, on their website/display on the notice board/and if
requested, supply the consumer with the list of approved vendor(s)/make or manufacturer:Provided
also that the licensee shall get the meter lots inspected by test labs having accreditation from
National Accreditation Board for testing and Calibrating laboratories, and also adhere to test
procedure specified in clause 8.12. The licensee shall put the list of such approved test labs, on their
website/display on the notice board/and if requested, supply the consumer with the list of approved
labs. The licensee shall also set up appropriate number of testing labs and get the accreditation from
NABL, if not already done.(b)HT and LT consumers, if they opt for procurement of meter and
related apparatus, shall provide a locked and weatherproof enclosure of a design approved by the
licensee to house the metering equipment including CTs and PTs. In other cases, these shall be
included in the estimate and provided by the licensee.(c)If meter is supplied by the licensee,
including the replacement of electromechanical by electronic meters, the security of the meter and
associated equipment may be realized as per the cost specified in cost data book. The licensee may
submit a proposal to this effect for the approval of the Commission.(d)In case of connections where
cost of the meter has been borne by the consumer, neither meter rent nor any security for the price
of meter, shall be charged from the consumer.(e)In case of a consumer, who has borne the cost of
the meter or purchased the meter himself, the Licensee shall have the option to either give to the
consumer the depreciated value of the cost of the meter borne by the consumer or the meter itselfBihar Electricity Supply Code, 2007

after claiming the dismantling charges at the time of termination of the agreement. Depreciation
shall be calculated by straight-line method taking a life span of ten years.(f)Meter shall be installed
by the licensee at the point of supply either at the consumer premises or outside the consumer
premises in such a manner that it is always accessible to the Licensee for meter reading and other
purposes:Provided that where the licensee installs the meter outside the premises of the consumer,
then the licensee shall provide real time display unit at the consumer premises for his information to
indicate the electricity consumed by the consumer:Provided further that for billing purpose, reading
of consumer meter and not the display unit shall be taken into account(g)Whenever a new meter is
installed (as a replacement or for a new connection) it shall be sealed in the presence of the
consumer and a Meter History card shall be prepared in two copies. The licensee shall retain a copy
and the second copy shall be tagged to the meter. Subsequently, details of any faults in the meter,
repairs etc. shall be entered into this card by the licensee. The seal, name plates and distinguishing
numbers or marks affixed on the said equipment or apparatus shall not in any way be broken,
erased or altered by the consumer.(j)[] [Corrigendum vide Notification No.
BERC-Regl-06/06-part-II/02/08, dated 24.04.08.] A consumer may get a check meter installed
conforming to the technical specifications as laid down in Rule 57 of the Indian Electricity Rules,
1956 until Regulations are framed under the Electricity Act, 2003. These check meters may be
calibrated by the licensee upon payment of prescribed fee. However, check meter readings shall not
be used for billing purpose by the licensee.8.9Meter should be ordinarily fixed outside the building
and inside the boundary wall of the premises in such a manner that it is protected from the elements
like weather etc. and can be read from outside. The meter box shall normally be mounted at such a
height that meter reading counter/display window is at eye level. In case of LT consumers meter and
the cut-out/MCB or, in case of HT/ EHT consumers, meter, circuit breakers and its associated
equipment including cables shall be installed by the Licensee at the point (s) of supply.8.10All new
meter should be installed in a tamper-proof meter box. The licensee shall prepare and implement a
phased plan to install tamper-proof metering boxes. The licensee shall prepare and implement a
phased plan to install tamper proof metering boxes for all the meters, which are at present installed
without meter boxes.8.11In case of semi-permanent (kuchha) houses the licensee shall ensure that
the meter is properly fixed on a wall and is accessible to the meter reader. In case the consumer does
not provide good quality wall for fixing the meter, the licensee shall be free to fix the meter on the
electricity pole or in a pillar-box to be provided by the licensee. The licensee shall also ensure that
the earthing of the installation is proper.Testing of Meters8.12The Licensee shall ensure tested
meters are installed at the consumer premises. Meters purchased by the consumer shall be tested,
installed and sealed by the licensee.The licensee shall also conduct periodical inspection/testing of
the meters as per the following schedule :
(a)LT Single phase meters: -at least once every five years
(b)LT 3 phase meters (above 50 KVA): -at least once every 3 years
(c)Other LT metering systems -at least once every 2 years
(d)HT meters including MDI:   
 - For EHT consumers (above 10MVA) -Once in three months
 - For loads between 5-10MVA -Once in six months
 - Other HT Consumer -at least once a year.Bihar Electricity Supply Code, 2007

CT and PT shall also be tested alongwith meters.Records of these test results shall be maintained in
accordance with Rule 57 of Indian Electricity Rules, 1956.If required, the licensee may remove the
existing meter for the purpose of testing. The representatives of the licensee must, however, produce
an authenticated notice to this effect and sign the document, mentioning his full name and
designation, as a receipt, before removing the meter. The consumer shall not object to such
removal.(e)The licensee may arrange for third party testing at NABL accredited test labs specified in
clause 8.8 and recalibrated if required at manufacturer's work, if the testing facility is not available
with them for periodical testing, or in case of consumer's request when meter is defective.Defective
Meters8.13The licensee shall have the right to test any meter and related apparatus if there is a
reasonable doubt about the accuracy of the meter, and the consumer shall provide the licensee
necessary assistance in conduct of the test. The consumer shall be allowed to be present during the
testing.8.14A consumer may request the licensee to test the meter, if he doubts its accuracy, or
meter reading not commensurate with his consumption, stoppage of meter, damage of seal by
applying to the licensee along with the requisite testing fee. The licensee shall test the meter within 7
days in urban area and 15 days in rural areas, or as otherwise provided in Standards of Performance
of Distribution Licensee Regulations of the receipt of the application. Preliminary testing of meters
can be carried out at the premises of the consumers through electronic testing equipment.(a)In case
of testing of meter at consumer's premises, the testing of meter shall be done for a minimum
consumption of 1 kWh. The meter testing team of the licensee shall carry heating load of sufficient
capacity to carry out the testing. Optical Scanner may be used for counting the pulses/revolutions or
meter shall be tested as per the procedure described in IS/IER 1956.(i)In case the meter is found
O.K., no further action shall be taken.(ii)In case the meter is found fast/slow by the licensee, and the
consumer agrees to the report, the meter shall be replaced by a new meter within 15 days, and bills
of previous three months prior to the month in which the dispute has arisen shall be revised in the
subsequent bill as per the test results. In case meter is found to be slow, the additional charges may
be recovered in installments not exceeding three, if the consumer shows his inability to pay at a
time.(iii)If the consumer disputes the results of testing, or testing at consumer's premises is difficult,
the defective meter shall be replaced by a new tested meter by the licensee, and, the defective meter
after sealing in presence of consumer, shall be tested at licensee's lab/Independent lab/Electrical
Inspector, as agreed by consumer in presence of the representative of both licensee and the
consumer. The option once exercised by consumer shall not be changed. The decision on the basis of
reports of the test lab shall be final on the licensee as well as the consumer.(b)In cases of testing of a
meter in the licensee's/independent test laboratory,(i)Consumer shall be informed of the proposed
date of testing at least 7 days in advance so that he may be present at the time of testing, personally
or through an authorized representative.(ii)The signature of the consumer or his authorized
representative, shall be obtained on the Test Result Sheet.8.15In all cases of testing of a meter in the
laboratory, the consumer shall be informed of the proposed date of testing in advance, so that he
may be present at the time of testing, personally or through an authorized representative.The
signature of the consumer or his authorized representative, if present, shall be obtained on the Test
Result Sheet.8.16If a consumer disputes the results of testing, he may make a representation to
Independent lab/Electrical Inspector till such time the licensee sets up its own independent meter
testing facilities at convenient locations. The licensee shall endeavour to identify and develop these
facilities in one year from the date of notification of this Code.Meter (Including Maximum Demand
Indicator) Not Recording8.17The consumer is expected to intimate the licensee in writing, as soonBihar Electricity Supply Code, 2007

as he notices that meter has stopped/is not recording. The licensee shall acknowledge the intimation
given by the consumer.8.18If during periodic or other inspection by the licensee, any meter is found
to be not recording, or a consumer makes a complaint in this regard, the licensee shall arrange to
test the meter within the time specified in the Standards of Performance of Distribution Licensee
Regulations. The meter should be repaired/ replaced within the time specified in the Standards of
Performance of Distribution Licensee Regulations.8.19Burnt Meters(a)In case a meter is found
burnt either on consumer's complaint or upon the inspection of the licensee:(i)Necessary preventive
action at site shall be taken as early as possible to avoid future damage.(ii)The licensee shall restore
the supply immediately after bypassing the burnt meter, if the wiring on consumer's premises is
found o.k.(iii)Excess loads found, shall be removed or regularized by asking consumer to deposit
charges as per clauses 7.11 (4) and 7.15 (3)(iv)A new meter shall be installed by the Licensee within 7
days or as specified in the Standards of Performance of Distribution Licensee Regulations as per
option exercised by consumer given in clause 8.8(b)If possible, the Licensee shall test the burnt
meter removed from the consumer premises and the procedure detailed in clause 8.14(b) shall be
followed. If it is not possible to test the meter, the consumer shall be billed as per the procedure
specified in clause 9.16.8.20Cost of Replacement of Defective/Burnt Meters- The cost of
replacement of meter shall be borne by the consumer or by the licensee subject to following
conditions:(a)(i)If, as a result of testing, it is established that the meter was burnt due to technical*
(sic ?) reasons viz. voltage fluctuation, transients etc. attributable to the licensee the cost of the
meter shall be borne by the licensee. However, if it is established that the meter was burnt due to
reasons attributable to the consumer viz. defect in consumer's installation, connection of
unauthorized load by the consumer etc. the cost shall be borne by the consumer.(ii)If it is
established, as a result of testing, that the meter was rendered defective due to tampering or any
other deliberate act by the consumer to interfere with the meter, the cost of the meter shall be borne
by the consumer as above. The consumer shall be assessed under Section 126 of the Electricity Act,
2003, and shall be punishable under Section 138 of the Electricity Act, 2003. In addition, action as
permissible under law shall be taken against the consumer for pilferage and tampering.(b)In case
the meter is found burnt and there is reason to believe that an official of the licensee gave a direct
connection, pending replacement of meter, a case of direct theft shall not be booked. Consumer's
complaint for replacement of burnt meter or the complaint regarding distruption in supply of energy
shall be considered sufficient for this purpose.(c)In all cases of replacement of a meter, where cost is
to be borne by the consumer, he shall have the option to procure the meter and associated
equipment himself in accordance with clause 8.10 (sic ?).
Chapter 9
Billing
Meter Reading and Billing
9.Bihar Electricity Supply Code, 2007

1.
In respect of domestic consumers meter should be read only during daylight hours.The periodicity
of the meter reading the billing for various categories of consumers is given below.The licensee may,
however, improve upon the schedule if it finds that necessary or useful.
Consumer Category Meter Reading and billing
Domestic - Rural & BPL Once in two months
Domestic - Urban Monthly  
Non-Domestic <5kW - Rural Once in two months
Non-Domestic - Others (Urban & Rural) Monthly
LT Industrial Monthly
Agriculture - Rural Once in two months
Agriculture - Urban Once in two months
Street light, Waterworks, X-Ray Plants, Electric
CrematoriumMonthly
HT, EHT & RTSMonthly (as far as practicable on the same day of
the month)
9.2The licensee shall notify for each category of consumer, in the beginning, the following(a)date on
which bill will be issued by the licensee every month to the consumer(b)date by which bill will be
delivered to the consumer and(c)due date for payment of bills.These will normally be the due dates
for all billing cycles for that consumer during that financial year.9.3Meter shall be read by an
authorized representative of the licensee once every billing cycle. The licensee shall provide proper
photo identity cards which shall be displayed on his dress so that it is visible. The meter reader shall
record the meter reading with date in the meter card to be kept at consumer's
premises.9.4Arrangements shall be made by the licensee to display the meter reading and payment
states of high value consumers on Internet.9.5he licensee may use hand held computer devices with
GSM connectivity, meter reading instrument (MRI) or wireless equipment for recording meter
readings and for generation of bills on the spot. If bills are prepared on the basis of *MRI downloads
(sic ?) or if meter reading is taken on the basis of remote meter-reading and the consumer wishes to
have a record of the reading taken, he shall be allowed so by the licensee's official taking the meter
reading.9.6In case, during spot billing procedure, the licensee's representative could not take meter
reading due to the absence of the consumer, the representative may leave a note and request the
consumer to inform the meter reading over telephone. The consumer may thereafter take the
delivery of the bill on any convenient date. However this procedure of receiving meter reading over
telephone shall not extend beyond one meter reading cycle at a stretch.9.7The licensee shall assign a
unique consumer number for each consumer and communicate the same to the concerned
consumer. The unique consumer number may include pole number, transformer number, 11kV
feeder number, distribution centre number and division number.9.8It shall be open to the licensee
to adopt a scheme for pre-payment of electricity charges till meters are provided as required under
the Act for such consumers who are getting un-metered supply and the details of such pre-payment
scheme shall be got approved by the licensee from the Commission.9.9Bill shall be prepared forBihar Electricity Supply Code, 2007

each category of consumers in accordance with prevailing tariff order.9.10When supply to a new
consumer is commenced in the middle of a month the Demand Charges, Minimum charges and/or
any other similar fixed charges shall be levied on pro rata basis for the number of days for which
supply is given. The units to be charged under various blocks or slabs shall also be accordingly pro
rated. For the purpose of this sub-clause, the month shall be computed as 30 days.9.11Separate bills
shall be issued for Audit Recovery and other recoveries except demand for additional security
deposit. Such bills should be accompanied with written details of basis of billing, period of billing
etc.9.12The licensee shall endeavour to take monthly Meter Reading Instrument (MRI) download
for all connections where meters with MRI download facility are installed.9.13If for any reason,
meter is not accessible for reading, the licensee shall issue a provisional bill on the basis of average
consumption of the previous three billing cycles and also send a notice to the consumer to keep the
meter accessible for reading at the time and date given in the notice.9.14The amount thus billed
shall be adjusted against the bill raised on the basis of actual meter reading during subsequent
billing cycle. Such provisional billing shall not continue for more than two consecutive billing cycles
at a stretch. If the meter remains inaccessible even during the next cycle, the consumer will be
served with a notice if available, or, affixed near any entrance of the premises, to either get the meter
read by the licensee within 7 days for reading of the meter at a fixed time and date failing which the
supply will be disconnected after serving a 24-hour notice under section 163(3) of the Act
[Electricity Act, 2003 (36 of 2003)]. The provisions of sub-clause (b) and (c) shall not apply in case
of a domestic consumer who has given an advance intimation to the Licensee of the inaccessibility of
the meter for reading due to the consumer being out of station and if he has deposited an amount
that covers the minimum/fixed charges for the duration of the proposed absence. Such provisional
payment shall be adjusted when subsequent bill is issued on the basis of actual meter reading.9.15It
shall be the responsibility of the meter reader to note down the details of every stopped/defective
meter, conditions of meter/seal and condition of LCD/ LED of electronic meter and in case of any
abnormality shall file a report to the concerned officer who shall be responsible to take immediate
steps to replace or repair the stopped/defective meter or action taken, if required, in accordance
with provisions of the Act.9.16In order to recover the energy charges for the duration when the
meter remains non-functional, average monthly consumption of previous three meter reading cycles
subject to minimum monthly charges or as otherwise provided in the tariff order of the Commission
in force shall be the basis of billing. In case a check-meter is available, the readings of the check
meter may also be used for assessment of consumption. In case of HT consumers if during the
period when the main meter is defective, the check meter is not installed or is also found defective,
the quantity of electricity supplied shall be determined as stated above.9.17The meter reader shall
furnish a list of connections where the meter reading could not be recorded or the meter has not
recorded any consumption of electricity, to the officer in charge of the Distribution Centre who shall
prepare a list of such consumers where meter reading could not be taken or the defective meter
could not be replaced within thirty days and report the same to the concerned Assistant Engineer
and Executive Engineer. The licensee shall develop and put in place a detailed document describing
systems, procedure and accountability regarding replacement of such defective meters.9.18he senior
officers shall carry out the sample checking of meter readings as per the schedule drawn out by the
officer in charge of the distribution circle of the area. It should be the endeavour of the licensee that
meter readings in case of at least 20% of LT meters are checked in a year by the team of officers, not
below the rank of Junior Engineer.9.19The licensee may send bills to consumers by hand or by post.Bihar Electricity Supply Code, 2007

In case of hand delivery of bills, proof of service of bill shall be maintained at the concerned office of
the licensee. On a written request from a consumer, the licensee shall send the bill by registered post
and the expenses of such delivery of bill shall be recoverable from the consumer.9.20The licensee
shall ensure distribution of bills to the consumers not less than 14 days before the due date for
payment. The bill shall invariably contain the following details and put in use within three months
from the notification of this Code.(a)Name and address of the consumer(b)Service Connection
Number(c)Bill number(d)Pole Number from which connection is served(e)Name, address and
telephone number of the distribution centre(f)Date of issue of bill(g)Period of Bill(h)Tariff
category(i)Tariff, rate of electricity duty and cess applicable, if any(j)Contracted/Connected load
demand(k)Single phase or three phase connection(l)Identification details of the meter(m)Meter
Reading date-past and present(n)Meter reading-past and present(o)Units consumed(p)Credit, if
any(q)Basis of bill(r)Meter rental(s)Current month's charges Energy Charges, fixed/demand charge,
Minimum Charges, Fuel Price and Power Cost Adjustment (FPPCA) Charges, Electricity Duty, Cess,
meter rent, Capacitor surcharge, security deposit instalment, Rebate allowed, others, if any(t)Arrear
Electricity Charges, Delayed Payment Surcharge arrears.(u)Bill delivery charges, if
applicable(v)Total charges(w)Delayed Payment Surcharge(x)Due date of payment.(y)Authority in
whose favour cheque/Bank draft is to be issued, (to be printed on reverse of the bill)(z)Security
Deposit held and required.(aa)Details of last three energy consumption details.(bb)Applicable tariff
rates for concerned categories of consumers.9.21The following details would also need to be
provided to the consumer as an attachment to the bills or printed on the reverse of the
bill(a)Name(s)/address(es) and telephone no.(s) of collection centres(b)Working hours for
collection of bills.(c)Designation(s), address(es) and telephone no.(s) of the authority with whom
complaints pertaining to bills, meter, meter reading etc. can be lodged(d)Address(es) and telephone
no.(s) of Consumer Grievance Redressal Forum.(e)Names of the concerned fuse call centre.(f)Any
other message that the licensee may like to give.9.22In case the licensee is unable to supply power
for a period of 10 days (each day shall consist of power cut from 00 hours to 24 hours) or more in a
calender month to a consumer who is not otherwise disconnected the licensee shall charge the
consumer in the following manner:(a)Energy charges shall be on the basis of actual meter reading
recorded in the energy meter.(b)Other charges shall be pro-rated on the basis of the number of days,
power was provided to the consumer.9.23The licensee shall make arrangements to provide guidance
and information to any consumer on telephone and for this purpose shall set-up call center(s). All
urban areas may be brought under this facility in the first phase and rural areas thereafter. Details of
payment status, arrear status, authorised load, contract demand etc may be provided to the
consumer if he discloses his connection number and address.Special Reading of Meters in cases of
Change of Occupancy/Vacation of Premises for Domestic Consumers9.24It shall be the
responsibility of the owner consumer to get his connection disconnected and get a special reading
done by the licensee at the time of change of occupancy or on the premises falling vacant.9.25The
owner/user of the connection shall make a request in writing to the licensee for disconnection and
special reading of meter at least 15 days in advance of the proposed date of vacation of the premises
or change of the occupancy, as the case may be. The licensee may however, accept a notice of shorter
period. The licensee shall dispose of the same within 15 days from the date of receipt of such
application.9.26The Licensee shall get done the special reading of meter and deliver the final bill,
including all arrears till the date of billing, at least 7 days before the vacation of the premises. The
final bill shall also include payment for the period between the date of special reading and date ofBihar Electricity Supply Code, 2007

vacancy of premises on pro rata basis.9.27Once the final bill is raised, the licensee shall not have any
right to recover any charge(s), other than those in the final bill, for any period prior to the date of
such bill. It will be responsibility of the consumer/owner to make the payment and on receipt of
payment licensee shall issue no dues certificate.
Chapter 10
Payment and Disconnection
Payment
10.
1.
Consumers are expected to make payment for the energy used by them as per the bill and licensee is
obliged to issue a proper receipt in token of having received the payment. In all cases payments shall
also be acknowledged in the next bill.10.2The licensee shall ensure adequate publicity of the
addresses/locations and working hours of the collection centres including those of banks where
consumers can make payments. The licensee shall provide a choice of maximum alternative modes
of payment to the consumers like payment though cash, local cheque, bank draft, banker's cheque,
Electronic Clearing System (ECS), Credit Card etc. A consumer shall be allowed to make payment
through cheque for amounts above Rs. two hundred.10.3The licensee may allow within a definite
time frame, Commercial, public and private Institutions, and Industrial consumers, to pay their bills
directly through electronic clearance system through their bankers. Such consumers shall inform
their respective bankers to pay bills directly to licensee's banks on presentation of bill. Consumers
shall authorize bankers to debit their account on payment of bill. The licensees may make
arrangements with the banks accordingly, and give wide publicity to the scheme.10.4During the
days when there is rush on the collection window, separate queueing arrangement should be made
for senior citizens, women and physically challenged persons and they should be attended on
priority.10.5The collection centres should have the facility of receiving payment from
consumers/representatives of consumers who wish to make payments on behalf of a number of
consumers. Separate counters should be provided for this purpose so that the waiting time for other
consumers is not more.10.6In order to reduce the workload of the collection counter payment of
bills, above Rupees ten thousand should be made through cheque/banker's cheque/ demand draft
payable at local branch.10.7The licensee should make arrangements to receive payment through
drop boxes where the consumer may drop his cheque (crossed account payee only). Licensee should
keep the drop boxes at the collection centres and at other locations as notified from time to
time.10.8The due date of payment for all consumers shall normally be fifteen days from the date of
issue of bill. If due date of payment mentioned in the bill is a public holiday the succeeding working
day shall be treated as the due date.10.9In the event of non-realisation of cheque, the licensee shall
have the right to increase the security deposit from the consumer. The licensee shall also have the
right to take steps such as levying cheque dishonour charges or initiating other actions as per Law
besides insisting on future payment by demand draft or by cash.10.10In case of non-receipt of billBihar Electricity Supply Code, 2007

within the specified date or receipt of bill as per clause 9.2, the consumer shall contact the bill
issuing office and obtain a duplicate bill and make payment of the bill. In case the licensee is not in a
position to provide duplicate bill, for any reason, the consumer shall pay on the basis of average bill
amount of previous three consecutive bills. The Licensee may in phased manner facilitate the
consumer to take out the duplicate bill from the licensee's website.10.11The consumer may also be
allowed to make advance payment of future bills, which shall be adjusted in the future months.
However, only the regular bill amount shall be adjusted from the advance payment. Before adjusting
any other amount, the consent of the consumer shall be sought. The licensee shall prepare and
submit a scheme for approval of the Commission for consumers with high value bills, who make
payment of monthly bill in advance.10.12All categories of consumers committing default in the
payment of the billed amount shall be liable to pay delayed payment surcharge, on the amount
outstanding, at rates as approved by the Commission from time to time.10.13The Licensee shall lay
down a policy for grant of instalment facility for the purpose of recovery of dues subject to approval
of the Commission. The said policy shall also designate the officer(s) authorized to grant* instalment
facility (sic ?). In case of grant of instalment, interest at the rate of equal to be D.P.S./ month* on
arrears shall be charged (sic ?). However rebate for timely payment of current bill shall be
allowed.10.14Disputed/Erroneous Bills(a)In the event of any objection in respect of the billed
amount, the consumer may lodge a complaint before the designated officer as mentioned in the
energy bill. The supply of electricity shall not be cut off if such person deposits, under 'protest (sic
?);(i)an amount equal to the sum claimed from him; or(ii)the electricity charges due from him for
each month calculated on the basis of average charge for electricity paid by him during the
preceding six months, whichever is less, pending disposal of any dispute between him and the
licensee.(b)Complaint shall be lodged with the designated officer of the Licensee in the complaint
receipt form available at the licensee's complaint receiving office. In case such form is not available
in the office, complaint may be lodged on plain paper along with the following details;(i)Name and
address of the consumer along with telephone number, if any(ii)Service connection
number(iii)Category of connection(iv)Complaint in briefThe designated officer shall resolve the
dispute within a maximum period as specified in the Standards of Performance of Distribution
Licensee Regulations from the date of receipt of written complaint and shall send a report to the
next higher officer giving reasons for the discrepancy, if any.(c)If on investigation, the licensee finds
the bill to be erroneous, a revised corrected bill shall be furnished to the consumer indicating the
revised due date not less than seven (7) days from the date of delivery of revised bill. Excess amount
paid by the consumer, if any, shall be adjusted in the subsequent bill(s).(d)In case it is established
that the meter reading recorded was incorrect, responsibility may be fixed and the licensee may take
suitable action.(e)In the event that investigations establish that the original bill was correct, the
consumer shall be intimated accordingly and notified to pay the balance, if any, with delayed
payment surcharge as applicable within 7 days.(f)The licensee shall provide quarterly feedback to
the Commission on the analysis of disputed/erroneous bills.(g)In case the consumer is not satisfied
with the decision on the dispute, he may take further action as provided in the Regulations for
Consumer Grievance Redressal Forum and Electricity Ombudsman notified by the
Commission.10.15In case of death of a consumer the legal heir shall be liable to pay the dues of such
consumer. The legal heir should also take steps to get the connection changed in his name within a
period of three months.Disconnection10.16The authorised official of the licensee will ensure that all
the cases pertaining to default in payment are monitored regularly and timely action is initiated asBihar Electricity Supply Code, 2007

per prescribed procedure for temporary or permanent disconnection. A report of cases of permanent
disconnection will be submitted to the Commission on a quarterly basis.10.17If a consumer fails in
payment of any bill in full, without approval of the licensee, by the due date, service connection of
the consumer will be liable to be disconnected on temporary basis. Before disconnection of a
consumer's installation, licensee would serve a written notice of fifteen clear days. Effort should be
made that before disconnecting a domestic connection; an adult member of the family should be
informed. If the proof of removal of the cause for disconnection is produced to the satisfaction of the
Licensee's employee deputed for the purpose, the supply shall not be disconnected. In this regard,
the licensee shall strictly follow provisions of Section 56 of the Act.10.18No sum due from any
consumer shall be recoverable after the period of two years from the date when such sum became
first due unless such sum has been shown continuously as recoverable as arrear of charges for
electricity supplied and the licensee shall not cut off the supply of electricity.10.19The licensee would
publish the details of such consumers, who are liable to be disconnected but have not been
disconnected, in such a manner as may be directed by the Commission.10.20After temporary
disconnection, the supply shall be restored only after the consumer pays the outstanding
charges/dues/amount of instalment fixed along with disconnection/reconnection charges as
applicable.10.21If a consumer wishes to get his connection temporarily disconnected for a period
upto six months, he shall make a written request to the office of the licensee. The consumer shall be
liable to pay in advance all the monthly fixed/ demand charge, meter rent etc for the said period.
The consumer shall also be liable to pay disconnection/reconnection charges as applicable to avail
the facility of temporary disconnection.
Chapter 11
Unauthorised use of Electricity and Theft of Electricity
11.
0.
Unauthorised use of Electricity (UUE) Section 126 of the Act provides that Assessment 126(1) If on
an inspection of any place or premises or after inspection of the equipments, gadgets, machines,
devices found connected or used, or after inspection of records maintained by any person, the
assessing officer comes to the conclusion that such person is indulging in unauthorized use of
electricity, he shall provisionally assess to the best of his judgement the electricity charges payable
by such person or by any other person benefited by such use.(2)The order of provisional assessment
shall be served upon the person in occupation or possession or in charge of the place or premises in
such manner as may be prescribed.(3)The person, on whom a notice has been served under
sub-section (2) shall be entitled to file objections, if any, against the provisional assessment before
the assessing officer, who shall, after affording a reasonable opportunity of hearing to such person,
pass a final order of assessment within thirty days from the date of service of such order of
provisional assessment, of the electricity *charges (sic ?) payable by such person.(4)Any person
served with the order of provisional assessment, may, accept such assessment and deposit the
assessed amount with the licensee within seven days of service of such provisional assessment orderBihar Electricity Supply Code, 2007

upon him.(5)If the assessing officer reaches to the conclusion that unauthorised use of electricity
has taken place, the assessment shall be made for the entire period during which such unauthorised
use of electricity has taken place and if, however, the period during which such unauthorised use of
electricity has taken place cannot be ascertained, such period shall be limited to a period of twelve
months immediately preceding the date of inspection.(6)The assessment under this section shall be
made at a rate equal to twice times the tariff rates applicable for the relevant category of services
specified in sub-section (5).Explanation. - For the purposes of this Section,-(a)"assessing officer"
means an officer of a State Government or Board or licensee, as the case may be, designated as such
by the State Government;(b)"unauthorised use of electricity" means the usage of electricity-(i)by any
artificial means; or(ii)by a means not authorised by the concerned person or authority or licensee;
or(iii)through a tampered meter; or(iv)for the purpose other than for which the usage of electricity
was authorized; or(v)for the premises or areas other than those for which the supply of electricity
was authorized.Section 127 of the Act provides that11.1Procedure for Inspection, Provisional
Assessment, Hearing and Final Assessment in case of unauthorised use of electricity (UUE) under
Section 126 of the Act-(a)Inspection(i)The Assessing Officer designated under Section 126 of the Act
by the State Government shall suo-motu, or on receipt of reliable information on unauthorized use
of electricity or on instruction from higher authority, promptly conduct inspection and search of
such place or premises, exercising due diligence.(ii)The Assessing Officer, if required to do so, shall
handover his business card to the person in occupation or possession or in charge of the place or
premises before entering the premises, Photo ID card shall be carried by each team
members.(iii)The access to premises shall be in accordance to clause 6.32 to 6.36 of the Code.
Provided that the occupant of the place or premises of inspection or any person on his behalf shall
remain present during the inspection.(iv)A report shall be prepared at site giving details of
connected load, condition and details of old seals and resealing done, working of meter, details of
new seals, etc. The report shall mention any irregularity noticed which may lead to an indulgence of
unauthorized use of electricity in the format given in Annexure-6. The Inspecting Officer shall carry
seals for this purpose.(v)The report shall clearly indicate whether or not conclusive evidence
substantiating the fact that UUE was found. The details of such evidence should be recorded in the
report. The report shall be signed by each member of the inspection team and handed over to the
person in occupation or possession or in charge of the place or premises at site immediately under
proper receipt. In case of refusal by such person or his/her representative to either accept or give a
receipt, a copy of inspection report shall be pasted at a conspicuous place in/outside the premises
and may be photographed. Simultaneously, the report shall be sent to such person under Registered
Post/Speed post on the day or the next day of the inspection.(vi)Within 3 working days of the date of
inspection, the Assessing Officer shall analyze the case after carefully considering all the evidence
including the consumption pattern, wherever available and the report of inspection. If it is
concluded that no unauthorized use of electricity has taken place, no further action will be
taken.(b)Provisional Assessment and Notice to the Consumer-(i)If the Assessing Officer comes to
the conclusion that Unauthorized Use of Electricity has taken place in the premises (as defined
under Explanation under Section 126 of the Act), he will serve a provisional assessment order upon
the person in occupation or in-charge of the premises, giving 7 days time under proper receipt for
filing objection if any, against the Provisional Assessment Order and fixing a date of hearing. The
assessment shall be done as per guidelines provided in Annexure-7, appended to the Code.(ii)Any
person served with the order of provisional assessment may accept such assessment and deposit theBihar Electricity Supply Code, 2007

assessed amount with the licensee within seven days of service of such provisional assessment order
upon him. Such payment made shall be subject to the final order.(c)Hearing & Final
Assessment(i)On the date of hearing, the Assessing Officer shall hear to the person in occupation or
possession or in-charge of the place or premises. The Assessing Officer shall give due consideration
to the facts submitted by such person and pass, within 7 working days, a speaking order as to
whether the case of UUE is established or not. The order shall contain the brief of inspection report,
submissions made by such person in his written reply and during hearing.(ii)A copy of the order
shall be served to such person under proper receipt, and in case of refusal to accept the order or in
absence of such person, shall be served on him under Registered Post/Speed Post. The person in
occupation within 15 days of receipt of final assessment order.(iii)If the Assessing Officer reaches to
the conclusion that unauthorized use of electricity has taken place, the assessment shall be made for
the entire period during which such unauthorized use of electricity has taken place or possession or
in charge of the place or premises shall be required to make the payment and if, however, the period
during which such unauthorized use of electricity has taken place cannot be ascertained, such period
shall be limited to a period of twelve months immediately preceding the date of inspection.(iv)The
assessment under (iii) above shall be made at a rate equal to twice the tariff applicable for the
relevant category of service.(d)Appeal to Appellate Authority Against the Final Assessment Under
Section 127 of the Act.(i)Any person aggrieved by a final order made under sub-clause 11.1(c) above,
may, within thirty (30) days of the said order, prefer an appeal to the Appellate Authority designated
by the State Government in the manner specified in Bihar Electricity Regulatory Commission
(Procedure for Preferring Appeal before the Appellate Authority) Regulations.(ii)No appeal against
the order of assessment under sub-clause (i) above shall be entertained unless the person deposits
one half of the amount assessed by the Assessing Officer in cash or by way of bank draft, along with
fees specified in the Bihar Electricity Regulatory Commission (Fees, Fines and Charges) Regulations
with the licensee and encloses documentary proof of such deposit.(iii)No appeal shall lie to the
Appellate Authority referred to sub-clause (d)(i) above against the final order made with the consent
of the assessed person in writing.(iv)The licensee shall not take any action for recovery of assessed
amount for the period of thirty (30) days, mentioned in sub-clause (d) (i) above, where the assessed
person intimates the Assessing Officer within this period of his intention of filing an appeal to the
appellate authority.(v)The order of the Appellate Authority referred to in sub-clause (d)(i) above
passed shall be final and shall contain the brief of inspection report, submissions made by the
person in his written reply and during personal hearing and reasons for acceptance or rejection of
the same.Note : Section 145 of the Electricity Act provides that no civil court shall have the
jurisdiction to entertain any suit or proceeding in respect of any matter, which an Assessing Officer,
or an Appellate Authority, is empowered to determine, and no injunction shall be granted by any
court or other authority in respect of any action taken or to be taken in pursuance of any power
conferred by or under the Act. It is also provided that nothing contained in the procedure laid in
clause 11.1 shall have effect in so far as it is inconsistent with provisions of Sections 126,127 & 145 of
the Act.(e)Default in Payment of Assessed Amount or Instalments thereof(i)In case of default in
payment of the assessed amount or any instalment granted or agreed by the licensee, the licensee
shall, after, giving a 15 days notice in writing, disconnect the supply of electricity, by any suitable
means such as disconnection from pole/transformer, removing meter, electric line, electric plant
and other apparatus. The reconnection shall be carried out as per the provisions of reconnection laid
down in clause 7.7 of the Code.(ii)When a person defaults in making payment of assessed amount,Bihar Electricity Supply Code, 2007

he shall be liable to pay an amount of interest at the rate of sixteen per cent per annum with effect
from the date of expiry of 30 days from the date of order of assessment, in addition to the assessed
amount, compounded every six months.11.2Theft of Electricity11.2.1Section 135 of the Act as
amended provides that - (1) Whoever, dishonestly,-(a)taps, makes or causes to be made any
connection with overhead, underground or under water lines or cables, or service wires, or service
facilities of a licensee; or supplier, as the case may be; or(b)tampers a meter, installs or uses a
tampered meter, current reversing transformer, loop connection or any other device or method
which interferes with accurate or proper registration, calibration or metering of electric current or
otherwise results in a manner whereby electricity is stolen or wasted; or(c)damages or destroys an
electric meter, apparatus, equipment, or wire or causes or allows any of them to be so damaged or
destroyed as to interfere with the proper or accurate metering of electricity; or(d)uses electricity
through a tampered meter; or(e)uses electricity for the purpose other than for which the usage of
electricity was authorised, so as to abstract or consume or use electricity shall be punishable with
imprisonment for a term which may extend to three years or with fine or with both:Provided that in
a case where the load abstracted, consumed, or used or attempted abstraction or attempted
consumption or attempted use-(i)does not exceed 10 kilowatt, the fine imposed on first conviction
shall not be less than three times the financial gain on account of such theft of electricity and in the
event of second or subsequent conviction the fine imposed shall not be less than six times the
financial gain on account of such theft of electricity;(ii)exceeds 10 kilowatt, the fine imposed on first
conviction shall not be less than three times the financial gain on account of such theft of electricity
and in the event of second or subsequent conviction, the sentence shall be imprisonment for a term
not less than six months but which may extend to five years and with fine not less than six times the
financial gain on account of such theft of electricity:Provided further that in the event of second and
subsequent conviction of a person where load extracted, consumed or used or attempted abstraction
or attempted consumption or attempted use exceeds 10 kilowatt, such person shall also be debarred
from getting any supply of electricity for a period which shall not be less than three months but may
extend to two years and shall also be debarred from getting supply of electricity for that period from
any other source or generating station:Provided also that if it is proved that any artificial means or
means not authorized by the Board or licensee or supplier, as the case may be, exist for the
abstraction, consumption or use of electricity by the consumer, it shall be presumed, until the
contrary is proved, that any abstraction, consumption or use of electricity has been dishonestly
caused by such consumer.(1A)Without prejudice to the provisions of this Act, the licensee or
supplier, as the case may be, may upon detection of such theft of electricity, immediately disconnect
the supply of electricity:Provided that only such officer of the licensee or supplier, as authorized for
the purpose by the Appropriate Commission or any other officer of the licensee of supplier, as the
case may be, of the rank higher than the rank so authorized shall disconnect the supply line of
electricity:Provided further that such officer of the licensee or supplier, as the case may be, shall
lodge a complaint in writing relating to the commission of such offence in police station having
jurisdiction within twenty-four hours from the time of such disconnection:Provided also that the
licensee or supplier, as the case may be, on deposit or payment of the assessed amount or electricity
charges in accordance with complaint as referred to in the second proviso to this clause, restore the
supply line of electricity within forty-eight hours of such deposit or payment.(2)Any officer of the
licensee or supplier as the case may authorised in this behalf by the State Government may-(a)enter,
inspect, break open and search any place or premises in which he has reason to believe thatBihar Electricity Supply Code, 2007

electricity has been, is being, or is likely to be, used unauthorisedly;(b)search, seize and remove all
such devices, instruments, wires and any other facilitator or article which has been, is being, or is
likely to be, used for unauthorized use of electricity;(c)examine or seize any books of account or
documents which in his opinion shall be useful for or relevant to, any proceedings in respect of the
offence under sub-section (1) and allow the person from whose custody such books of account or
documents are seized to make copies thereof or take extracts therefrom in his presence.(3)The
occupant of the place of search or any person on his behalf shall remain present during the search
and a list of all things seized in the course of such search shall be prepared and delivered to such
occupant or person who shall sign the list:Provided that no inspection, search and seizure of any
domestic places or domestic premises shall be carried out between sunset and sunrise except in the
presence of an adult male member occupying such premises.(4)The provisions of the Code of
Criminal Procedure, 1973, relating to search and seizure shall apply, as far as may be, to searches
and seizure under this Act.The theft of electricity shall be dealt as per the provisions stated
above.11.2.2. Section 138-Interference with meters or works of licensee-provides that - (1)
Whoever,(a)unauthorisedly connects any meter, indicator or apparatus with any electric line
through which electricity is supplied by a licensee or disconnects the same from any such electric
line; or(b)unauthorisedly reconnects any meter, indicator or apparatus with any electric line or
other works being the property of a licensee when the said electric line or other work has or have
been cut or disconnected; or(c)lays or causes to be laid, or connects up any works for the purpose of
communicating with any other works belonging to a licensee; or(d)maliciously injures any meter,
indicator, or apparatus belonging to a licensee or willfully or fraudulently alters the index of any
such meter, indicator or apparatus or prevents any such meter, indicator or apparatus from duly
registering,shall be punishable with imprisonment for a term which may extend to three years, or
with fine which may extend to ten thousand rupees, or with both, and, in the case of a continuing
offence, with a daily fine which may extend to five hundred rupees; and if it is proved that any
means exist for making such connection as is referred to in clause (a) or such re-connection as is
referred to in clause (b), or such communication as is referred to in clause (c), for causing such
alteration or prevention as is referred to in clause (d), and that the meter, indicator or apparatus is
under the custody or control of the consumer, whether it is his property or not, it shall be presumed,
until the contrary is proved, that such connection, reconnection, communication, alteration,
prevention or improper use, as the case may be, has been knowingly and willfully caused by such
consumer.11.2.3Procedure to be adopted by licensee for Inspection, Provisional Assessment,
Hearing and Final assessment in case of theft of electricity under Section 135 of the
Act.(a)Procedure(i)An Officer authorized under Section 135 of the Act by the State Government,
suo-motu or on receipt of reliable information regarding theft of electricity, shall promptly conduct,
inspection and search of such premises.(ii)The Authorized Officer shall, if required, handover his
business card to the person in occupation or possession or in charge of the premises or place. Photo
ID card may be carried by each team member and shown to such person before entering the
premises.(iii)The provisions of the Code of Criminal Procedure, 1973, relating to search and seizure
shall also apply, as far as may be, to searches and seizure under this Code.(iv)A list of all items
seized in course of search shall be prepared and signed by all persons present during the search and
seizure. The occupant of the place or premises or any person on his behalf shall remain present
during the inspection.(v)In all cases of inspection, a report shall be prepared at site giving details of
connected load, condition and details of old seals, working of meter, details of new seals and clearlyBihar Electricity Supply Code, 2007

mention any irregularity noticed which may lead to theft of electricity in the format given in
Annexure-8. The Authorized Officer shall carry seals for this purpose. Any damage/destruction to
the electric meter, metering equipments, apparatus, line, cable or electrical plant of the licensee
caused or allowed to be caused by the person so as to interfere with the proper or accurate metering
of electricity or for theft of electricity shall also be duly recorded in the report. The Authorized
officer shall also prepare a diagram illustrating the arrangements found to have been made for theft
of electricity, wherever feasible and such diagram shall form a part of inspection report.(vi)The
report shall clearly indicate whether prima-facie a case for theft of electricity can be inferred. The
report shall be signed by each member of the team and handed over to the occupant of the premises
or his/her representative at site immediately under proper receipt. In case of refusal by such person
or his/her representative to either accept or give a receipt, a copy of inspection report shall be
pasted at a conspicuous place in/ outside the premises and may be photographed. Simultaneously,
the report shall be sent to such person under Registered Post/ Speed post on the same day or the
next day of the inspection.(vii)The Authorized Officer of the licensee or supplier as the case may be
upon detection of such theft of electricity disconnect the supply of electricity immediately. Any other
officer of the licensee or supplier as the case may be of the rank higher than the rank of that of
Authorized Officer may also disconnect the supply of electricity.(viii)As per the provisions of the Act
the Authorized Officer of the licensee or supplier, as the case may be shall lodge a complaint in
writing relating to commission of offence in police station having jurisdiction within twenty four
hours from the time of disconnection of supply of electricity to the premises.(b)Provisional
Assessment and Notice to the Consumer-(i)If the Assessing Officer comes to the conclusion that
theft of Electricity has taken place in the premises (as defined under Section 135 of the Act), he will
serve a provisional assessment order upon the person in occupation or in-charge of the premises,
giving 7 days time under proper receipt for filing objections, if any, against the Provisional
Assessment Order and fixing a date of hearing.The assessment shall be done as per guidelines
provided in Annexure-6 (sic ?), appended to the Code.(ii)Any person served with the order of
provisional assessment may accept such assessment and deposit the assessed amount with the
licensee within seven days of service of such provisions assessment order upon him.(c)Hearing &
Final Assessment(i)On the date of hearing, the Assessing Officer shall hear to the person in
occupation or possession or in-charge of the place or premises. The Assessing Officer shall give due
consideration to the facts submitted by such person and pass, within 7 working days, a speaking
order. The order shall contain the brief of inspection report, submissions made by such person in his
written reply and during hearing.(ii)A copy of the order shall be served to such person under proper
receipt, and in case refusal to accept the order or in absence of such person, shall be served on him
under Registered Post/ Speed Post. The person in occupation or possession or in charge of the place
or premises shall be required to make the payment within 15 days of receipt of final assessment
order.(iii)If the Assessing Officer reaches to the conclusion that the theft of electricity has taken
place, the assessment shall be made for the entire period during which such theft of electricity has
taken place and if, however, the period during which such theft of electricity has taken place cannot
be ascertained, such period shall be limited to a period of twelve months immediate preceding the
date of inspection.(iv)The assessment under (iii) above shall be made at a rate equal to twice the
tariff applicable for the relevant category of service.(v)The licensee or supplier, as the case may be
on deposit or payment of the assessed amount or electricity charges in accordance with complaint as
referred to in the sub clause 11.2.3(1) (viii) restore the supply line of electricity within forty eightBihar Electricity Supply Code, 2007

hours of such deposit or payment.11.2.4. Compounding of Offence :(i)Section 152 of the Act, which
deals with compounding of offences, shall be applicable where the State Government or any officer
authorized by it in this behalf accepts from any consumer or person who committed or who is
reasonably suspected of having committed an offence of theft of electricity punishable under this
Act, a sum of money by way of compounding of the offence based on contracted load as specified in
the Act.(ii)The payment of the sum of money by way of compounding can be made with the officers
of the licensee or the police Inspector of Police station under whose jurisdiction the consumers
premises is situated, if specifically empowered by the State Government to accept the compounding
amount.(iii)After making the payments as above, and in accordance with Section 152 (1) of the Act,
any person if in custody, in connection with that offence, shall be set at liberty and no proceedings
shall be instituted or continued against such consumer or person in any criminal
court.(iv)Compounding of an offence shall be allowed only once for any consumer or
person:Provided that such compounding amount shall be deposited in the State Government
account by the above empowered authorities, and the licensee shall collect and retain the assessed
amount, if any.11.3Measures to prevent diversion of electricity, theft or unauthorized use of
electricity or tampering, distress or damage to electrical plant, electric lines or meter.- The licensees
are mandated to take following steps :(1)Arrange to provide pilfer proof meter boxes on meters of at
least 20% connections every year.(2)Review the status of service lines, to ensure that it is proper and
whatever required, it should be replaced to prevent theft/by passing of meter.(3)Regular inspection
of premises of persons and other persons-At least 5% of total connections should be inspected
annually and provisions of the Section 126 & 135 of the Act be effectively implemented.(4)Priority
shall be given to detection of direct theft cases by the vigilance teams of the licensee, particularly in
theft prone areas.(5)Regular monthly monitoring of consumption of high value consumer, which
shall include all the HT connections and LT connections having contract demand of 25HP & above
and arrange prompt inspection of doubtful cases. A system shall be evolved and put in place within 3
months and furnish the detail of such system to the Commission.(6)Work out all 33KV & 11 KV
feeder wise losses in next six months for big cities of the state. Losses for all 33KV & 11 KV feeders of
District Head quarter towns shall be worked out within next one year and for other areas within next
2 years. Suitable action to be taken against the concerned officers/ staff for
non-compliance.(7)Ensure GIS/GPS mapping, Consumer indexing, updating and brushing off
(ledgerise/regularise/update records) the consumers beginning from high loss feeders.(8)Install
remote metering devices on all HT and high value LT connections on priority for the purpose of
monitoring of consumption and prevention of theft of electricity.(9)Wide publicity through the
media, TV and newspaper to bring awareness amongst consumers about the level of commercial
losses, its implication on the honest consumers.(10)Seek the co-operation of Social and consumer
groups, NGO's for prevention of theft or unauthorized use of electricity or tampering, distress or
damage to electrical plant, electric lines or meter through independent agencies, and creation of
such groups feeder-wise.(11)Display boards containing the provisions of penalties, fines and other
information about the above at its consumer service related offices, and other important
places.(12)Display feeder-wise, area-wise, circle-wise, division-wise losses, efforts made for
prevention of diversion of electricity, theft or unauthorized use of electricity or tampering, distress
or damage to electrical plant, electrical lines, or meter and results obtained during the year, on its
website.(13)Provide requisite security force to the inspecting officers for their safety, and expenses
on such account shall be pass through in annual Revenue Requirement (ARR) of theBihar Electricity Supply Code, 2007

licensee.(14)Install meter of distribution transformers of the suspected area where the possibilities
of theft of electricity exists and monitor the consumption of such meters with the consumption of
individual consumer *meters (sic ?) connected to the distribution transformer and inspect the
abnormalities.(15)Replace overhead bare conductors with cables in theft prone areas, wherever
necessary, to prevent theft by *direct hooking (sic ?) with the licensees lines and expenditure on this
account shall be a pass through *in the (ARR) of (sic ?) the licensee.(16)Provide HV distribution
system (LT less system) in theft prone areas using small capacity distribution transformer, wherever
necessary, to prevent theft by direct hooking and expenditure on this account shall be a pass
through in the ARR of the licensee.(17)Relocate the meters of existing consumers to an appropriate
location so that it is outside the premises but within the boundary wall and easily accessible for
reading, inspection/testing and other related works. In doubtful cases and where continuous vigil is
not possible, install meter for such connection on its poles/ feeders pillars with display unit at
consumer premises. The consumption recorded in consumer meters should be reconciled with the
reading of meter installed at concerned power stations.(18)Ensure that meter readers are rotated in
such a manner that their area of meter reading is changed at least once in six months.(19)Maintain
list of cases where theft of electricity has been detected clearly indicating the case where first offence
or subsequent offence(s) of the theft has been detected. Action as per provision of the Act to be
taken.(20)Monitor case of theft and submission of abstract report to the Commission in respect of
recovery of assessment amount and bills.
11. [4. Voluntary Declaration of Tampered Meters [Substituted by Notification
No. 603, dated 18 August, 2010.]
- The licensee may launch area specific/whole of the area of jurisdiction of licensee, an Amnesty
Scheme of Voluntary Declaration of Tampered Meter for a limited period not exceeding 15 days with
the prior approval of the Commission.(a)The period of voluntary declaration shall be circulated and
widely published along with a format of application of voluntary declaration.(b)During the specified
period there will be no raid/inspection of the premises. However, consumers whose
premises/meters have been checked by Vigilance Cell/concerned officer of the licensee and where
meters have already been found to be tampered shall not be eligible under this scheme.(c)The
tampered meter/metering unit shall be replaced with a new meter by the licensee/consumer, as the
case may be, within 15 days.(d)The cost of the meter/metering unit will be borne by the
consumer.(e)The licensee shall raise half of the energy bill assessed in accordance with the
provisions of Section 126 of the Electricity Act, 2003 as per formula and procedure specified in
Annexure-7 of the Supply Code. The consumer shall be provided by the licensee the sheet of
calculation for the amount required to be deposited.(f)The consumer shall pay the assessed amount
in time. In case of default in payment action shall be initiated under provision 135 of the Electricity
Act, 2003.(g)The energy bill for the period from the date of voluntary declaration till replacement of
meter shall be assessed as per procedure specified for defective meter on normal tariff rate.(h)No
case shall be lodged in case a consumer voluntarily declares the tampering of meter and pays the bill
raised under (e) above.(i)Such facility to a consumer shall be available for one time
only.]11.5General- While making the assessment bill, the licensee shall give credit to the consumer
for the payments for energy consumption already made by the consumer for the period of the
assessment bill. The assessed bill shall be prepared after excluding the payment for energyBihar Electricity Supply Code, 2007

consumption already made by the consumer. The *bill shall (sic ?) clearly indicate the timing, days
and place where it is to be deposited.11.6Offences and penalties in respect of supply of electricity has
been dealt in detail under Sections 135 to 152 of the Electricity Act, 2003 amended from time to time
which shall be binding both for licensee or supplier as the case may be or the persons concerned. In
case of any deviation in any of the provision specified in the code from the provisions of the Act the
latter shall prevail.
Chapter 12
Miscellaneous
12.
1. Force Majeure and Restrictions on Supply of Power
- The Licensee may direct the consumer to curtail, stagger or altogether stop using supply in any of
the following conditions and the Licensee shall not be liable for any claim or compensation on
account of loss or damage arising out of failure of supply in such conditions.(i)When such failure is
due to cyclone, floods, storms or other occurrences beyond his control either directly or indirectly, to
war, mutiny, civil commotion, riot, strike, lockout, fire, flood, tempest, lightning, earthquake or
other forced incidents such as break down of equipments, overhead lines and cables or causes
beyond the control of the Licensee.(ii)In the event of restriction on power supply imposed by the
Commission under Section 23 of the Electricity Act, 2003.(iii)In case of a major breakdown in the
supply system of the licensee such as Grid Failure that warrants curtailment of load.12.2Demand
Side Management (DSM)- It shall be the duty of every consumer to stop wastage and inefficient use
of electricity and also to extend necessary co-operation to the licensee in implementation of the
programs for Demand Side Management, and energy efficiency as required by the Energy
Conservation Act and the Bureau of Energy Efficiency, and that may be launched by the licensee.
DSM programs may be undertaken for commercial, public lighting, water works and for energy
efficiency improvement in Government buildings, commercial buildings, railways, defence
establishments, etc.12.3Service of Notice(1)Service of any notice on the consumer may be effected
either by delivering the notice to the consumer in person by an official of the licensee or by
dispatching the notice by registered post or Courier post or by publication in daily newspaper
commonly read in the concerned locality. In the case of an individual consumer, service of notice to
the consumer's spouse or his representative, and in the case of a firm, company or corporation, on
the Managing Director, Director or Principal Officer or an authorised person of such a concern, shall
be taken as sufficient service for the purpose of this Code. E-mail facility shall be also additionally be
used without prejudice to the above, by the licensee wherever possible.(2)If a consumer refuses or
avoids receiving the notice, the service may be effected by affixing the notice at a conspicuous place
on the premises of the consumer, in the presence of two witness or by publication in daily
newspaper commonly read in the concerned locality, and in such cases an endorsement shall be
made on the copy of the notice. This affixture or publication shall be deemed as sufficient for service
of notice.12.4Jurisdiction of Court- All proceedings arising out of this Code and the agreement made
there under shall be filed only in the Court under whose jurisdiction the agreement was executed,Bihar Electricity Supply Code, 2007

subject to the overall jurisdiction of the Hon'ble Patna High Court.12.5Repeal- The "General Terms
and Conditions for Supply" with all its amendments made from time to time by the Bihar State
Electricity Board shall apply in respect of the period prior to coming into force of this Code and shall
be repealed on enforcement of this Code i.e. the date of its publication in the Official
Gazette.12.6Power to Remove Difficulties- (i) If any difficulty arises in giving effect to any of the
provisions of this Code or there is a dispute regarding interpretation of any provision, the
Commission shall pass necessary orders to remove such difficulties or disputes of
interpretation.12.7Savings- (i) Nothing in this Code shall be deemed to limit or otherwise affect the
inherent power of the Commission to make such orders as may be necessary for ends of justice to
meet or to prevent abuses of the process of the Commission.(ii)Nothing in this Code shall bar the
Commission from adopting in conformity with the provisions of the Act a procedure, which is at
variance with any of the provisions of this Code, if the Commission, in view of the special
circumstances of a matter or class of matters and for reasons to be recorded in writing, deems it
necessary or expedient for dealing with such a matter or class of matters.(iii)Nothing in this Code
shall, expressly or impliedly, bar the Commission dealing with any matter or exercising any power
under the Act for which no Codes have been framed, and the Commission may deal with such
matters, powers and functions in a manner it thinks fit.(iv)Where there is variance in time schedule
of completion of any work as provided in this Code with the time schedule specified in the Standards
of Performance of Distribution Licensee Regulations the latter shall prevail.Annexure-1(See Clause
4.11)Application for Supply of Electricity (Low Tension Supply)To,Assistant Electrical
EngineerElectrical Supply
Sub-Division..............................................................................................................................Sir,I/We
request you to supply electricity for the premises owned/occupied by me/us as mentioned below.
1.Name of the Customer in whose name connection is
required.
 {|
.............................S/O
orW/O............................
|-| 2.| Address for communication|-||
Address: Telephone No.
(a) Permanent(b) Present  
|-| 3.| (a) Location of premises where supply is required|-||
Plot No. ................ House No................ Holding No. .............Ward No. ................
Street.................P.O. .............. PS................ Town.............District...............
|-|| (b) Nearest Electric Pole No :|
 
|-|| (c) is wiring Completed :|
Yes  No 
|-| 4.| (a) Is any other service existing in the same premises :|
Yes  No 
|-|| (b) If Yes, please give S.C. No. and Connected Load|-||Bihar Electricity Supply Code, 2007

S.C. No. Category Connected Load
   
|-|| (c) Nature of Right & Title of the premises|-|| (i) Self owned byapplicant............ (enclose
supporting paper).|-|| Or,|-|| (ii) Occupied on rent..........(enclose supporting paper or permission of
the owner).|-| 5.| Details of Connected Load|-||
Sl. No. Details of Appliance No. of Points Wattage HP Total Wattage/ HP
(i) Lights    
(ii) Fans    
(iii) Small Power Appliances    
(iv) Heaters    
(v) AC's    
(vi) Motors    
(vii) Welding Sets    
(viii) Others if any    
(ix) Other Loads    
 Total Load    
|-| 6.| Total New Connected Load Applied for:|
 KW  HP
|-| 7.| Purpose of Supply :|
 
|-| 8.| Category of Supply :|-||
{|
Type Category
Domestic  
LT Industrial  
Public Lighting  
Temporary  
||
Type Category
Non-Domestic  
Irrigation  
Public Water  
Seasonal  
|}|-| 9.| Status of Consumer|
Individual  Registered Partnership  
|-|||
Unregistered Partnership  Public Limited Company  
|-|||
Pvt. ltd. Company  Any Others  Bihar Electricity Supply Code, 2007

|-| 10.| Social Group|
 SC ST Others
|-| 11.| (A) This requisition is for|-||
{|
1. A new service connection
2. Enhancement of connected load
3. Reduction of load
4. Change of Name of service connection
5. Change of Category
6. Shifting of service connection
||
 
 
 
 
 
 
|}|-|| Tick (√) the box which is applicable|-| 11.| (B) Details of requisition :-|-||
(i) A new service connection for............kW/HP
(ii) Enhancement of connected load from kW/HPto............kW/HP
(iii) Reduction of load from............kW/HPto............kW/HP
(iv) Change of Name of service connection fromSri............to Sri............
(v) Change of Category from............categoryto............category
(vi) Shifting of service connection from existinglocation............to location
|-| 12.| Meter to be provided by|
Licensee  Applicant  
|-| 13.| Undertaking|}(i)I/We............... am/are the statutorily bonafide owner for the premises for
which new service connection is applied fororI/We................am/are the person(s) authorized by the
statutorily bonafide owner to avail service connection on my name for the said premises for which
service connection is applied.(ii)All the required documents such as Ownership deed (ex. Tax
receipt, copy of registered document etc.) wiring certificate and necessary approvals are enclosed
hereunder to release the supply.(iii)I/We undertake and agree to avail supply of energy for the
above mentioned purpose for a period not less than one year from the date of commencement of
supply and to pay the Tariff and Miscellaneous charges approved by the Commission from time to
time. In the event of non-payment of the said charges it shall be recoverable from me/us as public
demand under the Bihar and Orissa Public Demand Recovery Act, 1944, amended from time to
time. I/we shall abide by the terms and conditions of Bihar Electricity Supply Code (ESC) notified by
the Commission from time to time, which shall govern the supply of electricity to me/us in all
respects.(iv)I/We shall undertake to execute an Agreement in the prescribed form *when (sic ?)
called upon by the licensee whether such an agreement is executed or not, this application itselfBihar Electricity Supply Code, 2007

shall oblige me/us conform to and abide by the terms and conditions of supply *notified (sic ?) by
the licensee and approved by the Commission from time to time.
Place  Signature of the Applicant
   
Date  Name
   
Acknowledgement
Sub Division   Date of Registration   
      
Registration No.   Signature of Receiving Officer With Stamp   
      
Prop. date of Inspection      
Annexure-2(See Clause 4.11)Application for Supply of Electricity at High Tension (to be submitted
in 5 sets)
Registration No. :   Date :   
      
Amount Paid Rs.   DD No./Date :   
To,____________________Designated Officer____________________Sir,I/We request
you to supply electricity at High Tension as mentioned below :
1.a. Name of the Customer in whose name connection is required :
 {|
 
|-| 1.b.| Status of the Customer:|-| 2.| Location of Premises where supply is required :|-||
Street: Block:
Village: District:
Plot No.: Pin Code:
|-| 3.| Addresses and Telephone Number for Communication .|-||
Address : Telephone No.
PermanentPresent  
|-| 4.| Type of Service Required (Please tick the service appliedfor):|-|| *| New Service|-|| *|
Additional Load (Alteration/Extension to existinginstallation)|-|| *| Reduction of load|-|| *| Title
Transfer|-|| *| Change of Category|-|| *| Existing
Category:..................ProposedCategory:...............|-| 5.| Category of Supply Requested (Please tick
the categoryrequired):|-||
Category Purpose
HT S I 11 kV High Tension Service
HT S II 33 kV High Tension Service
EHT 132kV Extra High Tension Service
HTSS 11 KV High Tension Specified ServiceBihar Electricity Supply Code, 2007

RTS 25 kV/132 kV Railway Traction Service
|-| 6.| Are any other services existing in the same Premises :|
Yes  No 
|-|| If yes, details thereof are asfollows.............................................|-||
SI. No. Particulars Details
i. Existing Service Connection Number  
ii. Existing Contracted Maximum Demand (kVA)  
iii. Existing Contracted Load (HP/kW)  
iv. Existing Connected Load (HP/kW)  
v. Date of conclusion of present HT Agreement  
vi. Date of release of supply  
vii. A.M.G. of the service, if any  
viii. Security Deposit  
|-| 7.| Are any other service existing elsewhere in the same name orin the names of sister
concerns.|-||
Yes  No 
|-|| If yes, the details thereof are as follows :|-||
Service Connection Number Category
  
|-| 8.a.| Requirement of New/Additional Load:|-||
i. Contracted Maximum Demand (kVA) (With Phasing if any)  
ii. Contracted Load (HP/kW)  
|-| 8.b.| Details of connected at the time of commencement of supply:|-| 9.| Total Load Requirement
(Existing + New / Additional Load):|-||
i. Contracted Maximum Demand (kVA) (With Phasing if any)  
ii. Contracted Load (HP/kW)  
|-| 10.| Nature of industry and product manufactured :|-| 11.| Number of running days in a month|-|
12.| Number of running shifts of the factory|-| 13.| Period of season if load is seasonal|-| 14.| Date by
which service is required|-| 15.| Power of Attorney|-| 16.| Whether the industry is availing/proposes
to avail power fromother sources. If so. please provide details:|-| 17.| (a) Whether the industry has
back up, captive generatingplant. If so, please provide details|-| 17.| (b) Any other information|-|
18.| Supporting documents enclosed (Please tick where applicable):|-|| Documents to be
furnished|-|| *| Details of Land, Survey Plot No., Mauza, Revenue Village No.,etc.............|-|| *|
Contracted Load Details (Where available)|-|| *| Memorandum of Understanding|-|| *| Articles of
Association, Partnership Deed|-|| *| Site plan indicating the Proposed Receiving Points of
PowerSupply from the Company|-|| *| General Power of Attorney|-|| *| NOC from Local Body (eg.
Gram Panchayat of MCH)|-|| *| Consent from Pollution *Control Board(sic ?)(IfApplicable)|-|| *|
SSI Certificate (if applicable)|-|| *| *Industrial licence(sic ?)|-|| *| Employment *Power(sic ?)|-|| *|
Financial Assistance(sic ?)|-|| *| Line of Manufacture|-|| *| Letter for Under *taking(sic ?)Capital
Works on*Turnkey Basis(sic ?)(Optional)|}I/We request the company to provide meter/metering
equipment for measuring electricity supplied to me.We undertake to execute an agreement in theBihar Electricity Supply Code, 2007

prescribed form, if so called upon by the Distribution licensee.
   
Signature of Applicant  Signature of Original Owner(in case of titletransfer)
   
Place  Date
Signed by the applicant in my presence :
Witness 1 Witness 2
Signature:Name and Address:Date: Signature:Name and Address:Date:
Acknowledge of Application
Registration No. :   Date of Registration :   
      
Signature of Receiving Officer With Stamp :   Total Amount Received :   
      
Designated :      
Annexure-3(See Clause 6.1)Test ReportTo be filled up by licensed Electrical Contractor
Book No. ............. Form No. ..................
To be filled up by the licenseeThis is being issued for providing electrical connection at the premises
of Mr./Mrs./Ms. ................ The address of the premises is................. The name and address of the
licensed electrical contractor is...................... The date of issue of this report is...................To be filled
up by the licensed electrical contractor
5. I hereby declare that-
(a)I have......................class licence valid till...............The licence number is..............................(b)I
have completed this work for Mr./Mrs./Ms......................................for his............................Details of
Job
SI No. Item 220/230 Volts 440/400 Volts
Red Phase Green Phase Blue Phase No. Total Watts
No. Total Watts No. Total Watts No. Total Watts
1          
2          
3          
4          
5          
6          
7          
(c)(i)The particulars of the employees who executed the job are tabulated below.
SI No. Name of the Wireman/Trainee Designation Period
From ToBihar Electricity Supply Code, 2007

     
     
     
     
     
     
     
     
(ii)The work was carried out under the supervision of.................... (Supervisor Wireman) whose
certificate number is........................... He is responsible for work carried out during the
period...................................(d)This installation specifications adhere to all the provisions of Indian
Electricity Rules, 1956.
6. I also declare/certify the following :
(a)The installed switches are of correct ratings : Yes/No
(b)All the switches and wiring are permanent and of correctspecifications Yes/No
(c)All plugs are of three pin type and controlled by separateswitches Yes/No
(d)All the Single Pole switches connected to the phase Yes/No
(e)Required permanent mark is provided on the main switch boardfor Neutral point Yes/No
(f)Arrangement for earthing is according to Rule 61 of IndianElectricity Rules, 1956 Yes/No
(g)In case of three phase installation  
(i)Danger board, fire extinguisher with buckets, shock chart andfirst aid kit have been
provided forYes/No
(ii)The installation specifications of the switch board is as perRule 15 of Indian Electricity
Rules, 1956Yes/No
7. Test results
Date of testing.....................
 Insulation to Earth Insulation between conductors
Phase 1   
Phase 2   
Phase 3   
Earth Resistance Date of testing
Electrode No.1 Electrode No. 2
  Bihar Electricity Supply Code, 2007

8. The date of registration according to form 'L' of Bihar Govt. Licensing
Board (Electricity) is as follows :
Sl. No....................Date..................Signature of the Licensed Electrical ContractorCertificate from
Supervisor wiremanIt is hereby certified that the aforesaid work has been undertaken by..................
who has a wireman permit number of that is valid till .................. It is also certified that testing of
the installation has been undertaken by........................ who has a permit number of................ that is
valid till....................Signature of the wiremanSignature of Supervisor, wiremanReceiptThe test form
number..........................for the installation at the premises of ........................ prepared by...............
has been received on.............Signature of Officer in-chargeNameDesignationDateAnnexure-4(See
Clause 6.37)Determination of Connected LoadDomestic Connection
1. Name of the consumer :.........................................
2. Address :..................................................................
3. Consumer Number (for existing connections) :.....................................
4. Electrical equipments proposed to be put to use : Please fill-up the
following table to enable determination of the connected load. Normally the
actual load of each item will be considered to determine the connected load
at the premises. In case of nonavailability of the rated capacity of any item,
the load shown below shall be considered.)
Item Load per item (Watts) No. Total load (Watts)
1 2 3 4 = 2x3
Bulb As per actual rating   
Tube light 40   
Fan 60   
Tape-recorder/Music system 25   
Television -Colour 100   
- Black &White 60   
Mixie 60   
Freeze 200 or actual   
Cooler 200 or actual  for 6 months April to
Sep
Heater (for cooking and water heating 1000   
Washing machine 750 or as actual   
Geyser1500/2000 or as
actual for 3 months only, Dec.
to Feb.Bihar Electricity Supply Code, 2007

Microwave Oven 2000   
* Air Conditioner (1 ton/1.5 ton /2.0 ton) 1500/2000/2250  for 6 months only Apr.
to Sep.
Split Air Conditioner 1.5 ton Computer 2250 100  for 6 months
Printer 150   
Water lifting Pump set 375 or actual   
Inverter to be used in case of power failure
for own useNIL   
  Total  
Note: - (a) Spare socket points holders shall not be counted towards connected load.(b)Defective
appliances like cooler, freeze, T.V. Iron, Oven, etc. which are not connected and hot working shall
not be taken into account.(c)In some domestic connections Geyser, Room Heater and
Air-conditioner (without heater) are installed. The load of Geyser(s) and Room Heater(s) shall be
accounted for billing for the month of December, January & February and the load of
Air-conditioner(s) (without heater shall be taken into account for the month of April to September.
The load of Air-conditioners(s) with heater (s) shall be accounted as connected load for full
year.(d)Any other item of load not included above shall be taken as per manufacturers
rating.(e)Fraction of load in kW shall be taken as next higher whole number for the purpose of
billing or as otherwise provided in the tariff order.
Signature of the Consumer Signature of the licensee's representative
Date:................... Date:......................
Place:.................. Place:.....................
Annexure-4A(See Clause 6.38)Self Declaration of Connected Load
1. Name and address of the Consumer..................................
2. Consumer No./Account No...................................................
3. Category of Consumer ........................................................
4. Purpose of Supply................................................................
5. Details of Load Connected.
SI. No. Name of Appliances Unit No. Total kW/HP
(i) (ii) (iii) (iv) (v) (vi) (vii) (viii) (ix) (x)
Total Aggregate Load ....................Note : In case of HT/EHT/Railways the details of transformer
installed and the Connected Load to be furnishedBihar Electricity Supply Code, 2007

6. Sanctioned Load............................................................
7. Extra Load......................................................................
DateSignature of the ConsumerAnnexure-5(See Clause 7.5 [a])Format for Intimation to Consumer
after Temporary Disconnection of SupplyFrom....................................................Dated
:............................No................................................(Name of
Consumer).........................(Address)Reference:Connection No. ...........................Consumer
Category....................Contracted Load..........................This is to inform you that your supply has
been temporarily disconnected with effect from ..................... due to following reasons :
......................... You are requested to remove the cause of disconnection and intimate this office at
the earliest, you are also requested to pay sum of Rs. ................... towards disconnection,
reconnection charges and................... (Pl. mention if any other dues is to be deposited. Pl. also give
break up of the total sum).If the cause of disconnection is not removed to the satisfaction of this
office, your supply shall be permanently disconnected as per clause 7.6 (i). Late payment Surcharge
shall be levied as per clause 7.6 (ii)Thanking you,Yours faithfullyName, Signature & Designation of
the representative of the LicehseeAnnexure-6(See Clause 11.1 (a) (iv)Inspection Report(Under
Section 126 of the Act)Sub Division:
I.Inspection notes of Sri
.................Dated..............200
 Time of Inspection : Total time of inspection :
II.(a) Name and address of the occupant
of the place/premises 
 (b) Person present at the time of
inspection:Name Signature
  (i)
........................................................................................
  (ii)
......................................................................................
  (iii)
.....................................................................................
  (iv)
......................................................................................
III.(a) Any other person available at the
time of inspection andhis/her
relationship with the occupant of the
place/premises: 
 (b) Any other departmental staff
present: 
IV. 1. Service Connection No.  
 2. Distribution :  Bihar Electricity Supply Code, 2007

 3. Nature of premises :  
 4. Category :  
V.(a) Meter diagram indicating the
seals position & theircondition : 
 Location of the meter Height of the meter
 Impression on Seals Impression on Seals
 Before Inspection After Inspection
VI. (a) Meter Reading :  
 (i) kWH  
 (ii) kVAH  
 (b) Status of Meter:  
 Running/Stop/Defective/Burnt  
 (c) CT/PT Connection details with
phase sequence 
VII. Details of Connected Load  
 1. kW/HP  
 2. kW/HP  
 3. kW/HP  
 4.  
 5.  
 6.  
 In case of HT Transformer detail and
connected load detailsare to be given
separately 
VIII.Findings and Conclusion of the
Inspecting Team 
IX.Signature of all members of the
inspecting team and occupantof the
premises or his representative. 
[Annexure-4] [Substituted the cAnnexure-7 by Bihar Gazette (Extraordinary), No. 603, dated 18
August, 2010.](See Clause 6.37)Determination of Connected LoadDomestic Connection
1Name of the consumer :------------------------------------------------------
2Address :------------------------------------------------------
   ------------------------------------------------------
   ------------------------------------------------------Bihar Electricity Supply Code, 2007

3. Consumer Number (for existing connection) :
-------------------------------------------------
4. Please fill-up the following table to enable determination of the connected
load. All items of load shall be taken as per manufacturer's rating. In case of
nonavailability of the manufacturer's rating of any item, the load as shown in
the Annexure -4(1) shall be considered.
Sl. No. Domestic appliance Load of each appliance (in Watt) No. Total load (Watts)
1 2 3 4 5 (3x4)
     
     
     
     
     
     
     
Note :-(a)Spare socket/points/holders shall not be counted towards connected load.(b)Defective
appliances like cooler, freeze, T.V., Iron, Oven, etc. which are not connected and not working shall
not be taken into account.(c)In some domestic connections Geyser, Room Heater and
Air-conditioner (without heater) are installed. The load of Geyser(s) and Room Heater(s) shall be
accounted for billing for the month of December, January & February and the load of
Air-conditioner(s) (without heater) shall be taken into account for the month of April to September.
The load of Airconditioner( s) with heater(s) shall be accounted as connected load for full
year.(d)Subject to the minimum load of 1 kw, the fraction of the load below 500 Watts shall be
rounded to its nearest lower level of whole number and 500 Watts and above shall be rounded to
nearest higher level of whole number.(e){||-| Signature of the consumer/His representative|
Signature of the licensee’s representative|-| Date:---------------------| Date:---------------------|-|
Place:----------------------| Place:----------------------|}Annexure-4(1)Typical Power Rating for
Domestic Appliances
Item  Power Rating
Bulb  as per actual rating
Tube light 2'/4'  20/40 watt
Fan  60 watt
Tape-recorder/Music system  25 watt
Vacuum cleaner  250 watt/ actual
Television-colour  100 watt
- Black &white  60 watt
Mixie  60 watt / actualBihar Electricity Supply Code, 2007

Freeze  200 watt or actual
Cooler  200 watt or actual
Heater (for cooking and water heating)  1000 watt/ actual
Washing machine without dryer  250 watt or actual
Geyser  1500/4000 watt or actual
Microwave Oven  2000 watt
Air Conditioner (1 ton/1.5 ton/2.0 ton)  1500/ 2000/ 2250 watt or actual
Split Air Conditioner 1.5 ton/ 2.0 ton  2250 watt/ actual
Computer  100 watt
Printer  150 watt
Water lifting Pump set  375 watt or actual
Inverter  Nil
Note. - Bureau of Energy Efficiency, Ministry of Power, Govt, of India hasspecified the rating of
various domestic appliances in terms of energy efficiency level (1 to 5 star) and such appliances have
lower rating which shall be accepted.Annexure-7(See Clause 11.1 [b][i] & 11.2.3(b)(i))Assessment of
Energy Charges in Case of Unauthorised use/ Theft of ElectricityAssessment of energy shall be done
based on the following formula:Units Assessed U = L x F x D x HWhere:U = Quantum of Energy
Assessed in UnitsL = Connected Load in KW found at the time of inspection/ raid at siteF = Load
factor as per chart given belowH = Number of average hours of supply made available per day on the
feeder supplying power to the consumer or person as the case may be.D = Number of days during
which unauthorised use of electricity has taken place. If the period during which such unauthorised
use of electricity has taken place can not be ascertained, such period shall be limited to 12 (twelve)
months immediately preceding the date of inspection.Load Factor Chart for Different Category of
Services
Sl. No  Category of Service Load Factor (F)
1  Domestic power consumer 0.3
2  Non-domestic consumer 0.5
3  Agriculture Consumer 0.3
4  LT Industrial Consumer 0.5
5  High Tension Consumer 0.75
6  Categories of consumers not covered above 0.5
In case of High Tension Supply, the Connected load L for the purpose of assessment of consumption
(units assessed) shall be calculated as follows;L (in kw) = Contracted demand, or actual recorded
demand in KVA found at the time of inspection / raid or eighty percent of permissible transformer
capacity whichever is higher x 0.90 (PF)(A)Assessment in Cases of Unauthorised Use of Electricity
(UUE):
1. The consumption so assessed as per L x F x D x H formula and after
deducting the units already billed/to be billed up to the date of inspection
shall be charged at twice the applicable tariff rate for the relevant category ofBihar Electricity Supply Code, 2007

service. The amount billed at this rate shall not be taken into consideration
for the purpose of computing consumer's liability to pay monthly/annual
minimum charges, wherever applicable.
2. If the connected load of the consumer is found in excess of load
contracted, then the fixed charge or the demand charge, as the case may be,
shall also be charged for the excess load at twice the applicable tariff rate.
The period for computation in such cases shall be as stated in 'D' above.
3. If the connected load of LT consumer is found in excess of contracted load
and no tampering or bypassing of the meter or theft is detected and meter is
found working satisfactorily, then in such cases the short fall in units in
Monthly Minimum Consumption (MMC) in energy consumption, if any, and
the fixed charge for the excess load detected during the inspection/raid shall
be charged at twice the applicable tariff rate for the period stated in 'D' above.
4. In cases where fixed monthly tariff exist, monthly assessment shall be
made at twice the normal rate for excess load.
5. (i) If it is found at any time that the energy supplied is used for a purpose
on which higher tariff is applicable, the assessment shall be made for the
entire period during which such unauthorised use of electricity has taken
place and if however the period during which such unauthorised use of
electricity has taken place cannot be ascertained such period shall be limited
to twelve months immediately preceding the date of inspection. The total
charges for energy consumption for such period shall be assessed on the
basis of twice the difference of higher and lower tariff rates:
Provided that if it is found at any time that the energy supplied is used fora purpose on which lower
tariff is applicable, it shall not be considered as UUE and no penal action will be taken,(ii)The
calculations above are subject to the condition that meter is working satisfactorily, else, the energy
will be calculated on the basis of L x F x D x H formula as stated above.
6. If it is found at any time that the connection has been shifted to a premises
or area other than for which supply of electricity was authorised, the
assessment shall be made for entire period during such unauthorised
shifting has taken place, however the period during which such unauthorised
use of electricity has taken place cannot be ascertained shall be limited to 12Bihar Electricity Supply Code, 2007

months immediately preceding the date of inspection. The assessment shall
be made at the rate equal to twice the applicable tariff rate.
(B)Assessment of Energy Charges in Cases of Theft of Electricity:(a)Assessment of energy in the
cases of theft shall be calculated based on the same formula U = L x F x D x H(b)In case of theft as
defined in section 135(1)(a) of the Electricity Act, 2003 F shall be taken as equal to 1 (100%).(c)The
consumption so assessed after adjusting the energy consumption of the assessment period shall be
charged at twice the tariff applicable for the relevant category of services for which load was found to
have been used.For demand charges, the maximum demand found at the time of inspection/raid at
site or eighty percent of the permissible transformer capacity whichever is higher after, adjusting the
KVA demand already billed or to be billed upto the date of inspection/raid, shall be charged at twice
the applicable tariff rate.(d)The period for computation shall be taken as stated in 'D' above.Note: In
case of tampered meters, the inspecting authority shall book the Consumer under Section 126 of the
Electricity Act, 2003 for UUE only where such tampered meters are found in use, but there is no
incriminating evidence available that implicate the consumer.The Inspecting Authority shall book
the consumer under Section 135 of the Electricity Act, 2003 only when incriminating evidence found
implicate such consumer(s) dishonestly committing theft of electricity through tampered
meters.Annexure-8(See Clause 11.2.3 (a) (v)Inspection/seizure Report(Under Section 135 of the
Act)Sub Division:
I.Inspection/Seizure notes of Sri
.................Dated..............200
 Time of Inspection/Seizure : Total time of inspection :
II.(a) Name and address of the occupant
of the place/premises 
 (b) Person present at the time of
inspection/Seizure:Name Signature
  (i)
........................................................................................
  (ii)
......................................................................................
  (iii)
.....................................................................................
  (iv)
......................................................................................
III.(a) Any other person available at the
time of inspection andhis/her
relationship with the occupant of the
place/premises: 
 (b) Any other departmental staff
present: 
IV. 1. Service Connection No., if any  Bihar Electricity Supply Code, 2007

 2. Distribution :  
 3. Nature of premises :  
 4. Category :  
V.(a) Meter diagram indicating the
seals position & theircondition, if
meter installed: 
 Location of the meter Height of the meter
 Impression on Seals Impression on Seals
 Before Inspection After Inspection
VI. (a) Meter Reading, if installed :  
 (i) KWH  
 (ii) KVAH  
 (b) Status of Meter, if installed:  
 Running/Stop/Defective/Burnt  
 (c) CT/PT Connection details with
phase sequence 
VII. Details of Connected Load  
 1. KW/HP  
 2. kW/HP  
 3. kW/HP  
 4.  
 5.  
 6.  
 In case of HT Transformer detail and
connected load detailsare to be given
separately 
VIII.List of items with full details seized
during inspection/search 
IX.Findings and Conclusion of the
Inspecting Team 
X.Signature of all members of the
inspecting team and occupantof the
premises or his representative. Bihar Electricity Supply Code, 2007

