230Th Report On Reforms In The Judiciary - Some Suggestions
          GOVERNMENT OF INDIA
        LAW COMMISSION OF INDIA
REFORMS IN THE JUDICIARY - SOME SUGGESTIONS
                Report No. 230
               August 2009
           LAW COMMISSION OF INDIA
              (REPORT NO. 230)
REFORMS IN THE JUDICIARY - SOME SUGGESTIONS
Submitted to the Union Minister of Law and Justice,
Ministry of Law and Justice, Government of India by
Dr. Justice AR. Lakshmanan, Chairman, Law
Commission of India, on the 5th day of August, 2009.
                      2
 The 18th Law Commission was constituted for a period
of three years from 1st September, 2006 by Order No.
A.45012/1/2006-Admn.III (LA) dated the 16th October,
2006, issued by the Government of India, Ministry of
Law and Justice, Department of Legal Affairs, New
Delhi.
The Law Commission consists of the Chairman, the
Member-Secretary, one full-time Member and seven
part-time Members.230Th Report On Reforms In The Judiciary - Some Suggestions

Chairman
Hon'ble Dr. Justice AR. Lakshmanan
Member-Secretary
Dr. Brahm A. Agrawal
Full-time Member
Prof. Dr. Tahir Mahmood
Part-time Members
Dr. (Mrs.) Devinder Kumari Raheja
Dr. K. N. Chandrasekharan Pillai
Prof. (Mrs.) Lakshmi Jambholkar
Smt. Kirti Singh
Shri Justice I. Venkatanarayana
Shri O.P. Sharma
Dr. (Mrs.) Shyamlha Pappu
                       3
 The Law Commission is located in ILI Building,
2nd Floor, Bhagwan Das Road,
New Delhi-110 001
Law Commission Staff
Member-Secretary
Dr. Brahm A. Agrawal
Research Staff
Shri Sushil Kumar          : Joint Secretary& Law Officer
Ms. Pawan Sharma           : Additional Law Officer
Shri J. T. Sulaxan Rao     : Additional Law Officer
Shri A. K. Upadhyay              : Deputy Law Officer
Dr. V. K. Singh            : Assistant Legal Adviser
Dr. R. S. Shrinet          : Superintendent (Legal)
Administrative Staff
Shri Sushil Kumar          : Joint Secretary& Law Officer230Th Report On Reforms In The Judiciary - Some Suggestions

Shri D. Choudhury          : Under Secretary
Shri S. K. Basu            : Section Officer
Smt. Rajni Sharma          : Assistant Library &
                             Information Officer
     The text of this Report is available on the Internet at:
                             4
 http://www.lawcommissionofindia.nic.in
©   Government of India
    Law Commission of India
The text in this document (excluding the Government
Logo) may be reproduced free of charge in any format
or medium provided that it is reproduced accurately
and not used in a misleading context. The material
must be acknowledged as Government copyright and
the title of the document specified.
Any enquiries relating to this Report should be
addressed to the Member-Secretary and sent either by
post to the Law Commission of India, 2nd Floor, ILI
Building, Bhagwan Das Road, New Delhi-110001, India
or by email to lci-dla@nic.in
                      5
 Dr. Justice AR. Lakshmanan                                   ILI Building (IInd Floor)
(Former Judge, Supreme Court of India),
Chairman, Law Commission of India                            Bhagwandas Road,
                                                             New Delhi - 110 001
                                                             Tel. 91-11-23384475
                                                             Fax. 91-11 - 23383564
D.O. No. 6(3)/163/2009-LC (LS)                               5 August, 2009
Dear Dr Veerappa Moily ji,
 Subject: REFORMS IN THE JUDICIARY - SOME SUGGESTIONS230Th Report On Reforms In The Judiciary - Some Suggestions

       I am forwarding herewith the 230th Report of the Law Commission
of India on the above subject.
2.      The Law Commission has already given varied recommendations
in its earlier reports on the subject of reforms in the judiciary, which is a
subject very dear to my heart. The present Report is in the continuum of
those reports and has drawn on my very recent book titled The Judge
Speaks.
3.    The recommendations in this Report are the suggestions made by
the Hon'ble Shri Justice Asok Kumar Ganguly, a Judge of the Supreme
Court, which are as under:
      [1]    There must be full utilization of the court working hours.
             The judges must be punctual and lawyers must not be
             asking for adjournments, unless it is absolutely necessary.
             Grant of adjournment must be guided strictly by the
             provisions of Order 17 of the Civil Procedure Code.
      [2]    Many cases are filed on similar points and one judgment can
             decide a large number of cases. Such cases should be
             clubbed with the help of technology and used to dispose
             other such cases on a priority basis; this will substantially
             reduce the arrears. Similarly, old cases, many of which have
             become infructuous, can be separated and listed for hearing
             and their disposal normally will not take much time. Same is
                                    6
             true for many interlocutory applications filed even after the
            main cases are disposed of. Such cases can be traced with
            the help of technology and disposed of very quickly.
      [3]   Judges must deliver judgments within a reasonable time and
            in that matter, the guidelines given by the apex court in the
            case of Anil Rai v. State of Bihar, (2001) 7 SCC 318 must
            be scrupulously observed, both in civil and criminal cases.
      [4]   Considering the staggering arrears, vacations in the higher
            judiciary must be curtailed by at least 10 to 15 days and the
            court working hours should be extended by at least half-an-
            hour.
      [5]   Lawyers must curtail prolix and repetitive arguments and
            should supplement it by written notes. The length of the oral
            argument in any case should not exceed one hour and thirty
            minutes, unless the case involves complicated questions of
            law or interpretation of Constitution.
      [6]   Judgments must be clear and decisive and free from
            ambiguity, and should not generate further litigation.230Th Report On Reforms In The Judiciary - Some Suggestions

      [7]   Lawyers must not resort to strike under any circumstances
            and must follow the decision of the Constitution Bench of
            the Supreme Court in the case of Harish Uppal (Ex-Capt.) v.
            Union of India reported in (2003) 2 SCC 45.
      With warm regards,
                                                        Yours sincerely,
                                                  (Dr AR. Lakshmanan)
Dr M. Veerappa Moily,
Union Minister of Law and Justice,
Government of India,
Shastri Bhawan,
New Delhi - 110 001.
                                  7
 REFORMS IN THE JUDICIARY - SOME SUGGESTIONS
      Contents                   Page Nos.
I.    THEMES AND THOUGHTS          9 - 35
II.   RECOMMENDATIONS             36 - 37
                   8
 I.     THEMES AND THOUGHTS
1.
1 The formation and functioning of the High Courts in India need drastic changes so that the people
of the country may have fair and speedy justice and more faith in the system.
Selection and appointment of High Court Judges 1.2 The post of the Judge of a High Court has
importance under our Constitution and the incumbent is supposed to be not only fair, impartial and
independent, but also intelligent and diligent. The general eligibility criterion is that a person should
have put in ten years of practice/service in the legal/judicial field.230Th Report On Reforms In The Judiciary - Some Suggestions

1.3 As a matter of practice, a person, who has worked as a District Judge or has practised in the High
Court in a State, is appointed as a Judge of the High Court in the same State. Often we hear
complaints about 'Uncle Judges'. If a person has practised in a High Court, say, for 20-25 years and
is appointed a Judge in the same High Court, overnight change is not possible. He has his colleague
advocates - both senior and junior - as well as his kith and kin, who had been practising with him.
Even wards of some District Judges, elevated to a High Court, are in practice in the same High
Court. There are occasions, when advocate judges either settle their scores with the advocates, who
have practised with them, or have soft corner for them. In any case, this affects their impartiality
and justice is the loser. The equity demands that the justice shall not only be done but should also
appear to have been done. In government services, particularly, Class II and upward, officers are not
given posting in their home districts except for very special reasons. In any case, the judges, whose
kith and kin are practising in a High Court, should not be posted in the same High Court. This will
eliminate "Uncle Judges".
1.4 Sometimes it appears that this high office is patronized. A person, whose near relation or
well-wisher is or had been a judge in the higher courts or is a senior advocate or is a political
high-up, stands a better chance of elevation. It is not necessary that such a person must be
competent because sometimes even less competent persons are inducted. There is no dearth of such
examples. Such persons should not be appointed and at least in the same High Court. If they are
posted in other High Courts, it will test their calibre and eminence in the legal field.
1.5 The post of Chief Justice should not be transferable. This practice was introduced in our country
after the 'Emergency' had been imposed. If we look back, we find that the High Courts earlier had
better reputation than what they have at present. The Chief Justice, who comes on transfer for a
short period of six months, one or two years, is a new man, rather alien for the place and passes his
time anyhow. He has to depend on others for policy decisions in administrative matters. If the Chief
Justice is from the same High Court, he will be in a better position to not only control the lower
judiciary but also to assess the persons both from the bench and the bar for elevation to the High
Court. This will also curtail the unnecessary delay in filling up the vacancies in the High Courts. If
the functioning of the High Courts is to be improved, the policy of transferring the Chief Justices
should be given up forthwith.
When the policy of transfer of Chief Justices was finally upheld by the Hon'ble Supreme Court, an
eminent jurist of the country commented that the judiciary had committed suicide. Now the time
has come when this policy needs re-evaluation.
Age of retirement 1.6 When we adopted and gave to ourselves the Constitution in 1949, the
retirement age of Judges was fixed at 60 years for High Courts and 65 years for the Supreme Court.
For the High Court Judges, 60 years was increased to 62 years in 1963. At that time the normal life
expectancy was about 60 years. With the changes in social and financial set-up as well as medical
facilities, the present normal life expectancy is about 70 years. Barring few exceptions, a person is fit
and fine at the age of 62 or even 65 years. In our country, except for the judges, the retirement age in
some quasi-judicial bodies has been increased. The retirement age in different tribunals has now
been increased to 70 for chairmen and 65 for members. In the circumstances, the constitutional230Th Report On Reforms In The Judiciary - Some Suggestions

provisions need a change for enhancing the age of retirement of High Court and Supreme Court
Judges at least by three years.
Increase in number of judges and creation of new Benches 1.7 In almost every High Court, there is
huge pendency of cases and the present strength of the judges can hardly be said to be sufficient to
cope with the alarming situation. The institution of cases is much more than the disposal and it adds
to arrears of cases. The litigating citizens have a fundamental right of life i.e. a tension-free life
through speedy justice-delivery system. Now it has become essential that the present strength of the
judges should be increased manifold according to the pendency, present and probable.
1.8 It is also necessary that the work of the High Courts is decentralized, that is, more Benches are
established in all States. If there is manifold increase in the strength of the judges and the staff, all
cannot be housed in one campus. Therefore, the establishment of new Benches is necessary. It is
also in the interest of the litigants. The Benches should be so established that a litigant is not
required to travel long.
1.9 It is true that the new establishments will require money, but it is necessary as a development
measure, particularly, when efforts are being made for all-round development of the country.
Therefore, the money should not be a problem. We have to watch and protect the interest of the
litigants. We must always keep in mind that the existence of judges and advocates is because of the
litigants and they are there to serve their cause only.
1.10 Sometimes, some advocates object to creation of new Benches and selection of new sites for
construction of new buildings. But they raise objections in their personal, limited interest. Creation
of new Benches is certainly beneficial for the litigants and the lawyers and a beginning has to be
made somewhere.
1.11 There is huge pendency of cases in the apex court also. Now the time has come when not only
the strength of the Hon'ble Judges in the Supreme Court should be increased and recommendations
are made to fill up the vacancies soon but new Benches be also established in southern and eastern
regions.
Number of working days and vacations 1.12 Considering the huge pendency of cases at all levels of
judicial hierarchy, it has become necessary to increase the number of working days.
1.13 It has to be introduced at all levels of judicial hierarchy and must start from the apex court.
With the increase in the salaries and perks of the Judges, it is their moral duty to respond
commensurately. Opportunities to attend conferences/legal seminars in foreign countries should be
given to all the Judges of the Supreme Court and Chief Justices of the High Court in turn. Frequent
visits by the Judges to foreign countries at very high cost should be avoided in view of the austerity
measures by the Government of India.
Work culture 1.14 Of late, there has been a general erosion of work culture throughout the country.
Government servants avoid discharging their duties and responsibilities. The Judiciary has also230Th Report On Reforms In The Judiciary - Some Suggestions

been affected by this evil.
1.15 It is high time when all the judges at different levels of judicial hierarchy must devote full time
to judicial work and should not be under any misconception that they are Lords or above the society.
Though this feeling should come from within, but some guidelines are necessary.
Once judgments are reserved on constitutional matters by larger bench or otherwise, the judgments
should be delivered within a reasonable time. There is long and inordinate delay in delivering
judgments which should be avoided in public interest. If these suggestions are implemented, the
functioning of the courts shall certainly improve.
Speedy justice 1.16 Speedy justice is the right of every litigating person. There is no denying the fact
that delay frustrates justice. In the present set-up it often takes 10 - 20 - 30 or even more years
before a matter is finally decided. In the recent past, litigation has increased immensely. The
population growth, improved financial conditions, lack of tolerance and materialistic way of life may
be some of the causes. But the delay in dispensation of justice has to be eliminated by taking
effective steps otherwise the day is not far when the whole system will collapse. Recently, one
Hon'ble Judge of Delhi High Court calculated that 464 years will be required to clear the arrears
with the present strength of the judges in that High Court. The position may not be that gloomy but
is still alarming.
1.17 In Allahabad High Court, more than eight and a half lacs of cases are pending. Criminal appeals
of the year 1980-82, criminal revisions of the year 1990-95 are still pending. In second civil appeals
and writ matters the position is almost same. The position is the same in all other High Courts.
Institution of cases is much more than disposal and it adds to the arrears almost at all levels of
judicial hierarchy. Even in subordinate courts, there is huge pendency of cases.
1.18 As stated above, in order to meet this contingency substantial increase in the number of judges
and corresponding infrastructure is required at the earliest. Even if the judges and class III and IV
employees are appointed, say, within three to six months basic infrastructure will need time.
However, the money should be not a problem. It should be treated as a developmental work, a work
to provide justice to all, a principle enshrined in the Preamble of our Constitution.
1.19 An effort has been made in Gujarat State and Delhi to have some evening courts. The same
system can be introduced in other States as well.
1.20 The constitutional promise of securing to all its citizens justice, social, economic and political,
as promised in the Preamble of the Constitution cannot be realized unless the three organs of the
State i.e. legislature, executive and judiciary join together to find ways and means for providing to
the Indian poor equal access to its justice system.
1.21 Speedy trial is guaranteed under article 21 of the Constitution of India. Any delay in expeditious
disposal of criminal trial infringes the right to life and personal liberty guaranteed under article 21 of
the Constitution. The debate on judicial arrears has thrown up number of ideas on how the judiciary230Th Report On Reforms In The Judiciary - Some Suggestions

can set its own house in order. Alarmed by the backlog of inordinate delay in disposal of cases, Fast
Track Courts or Special Courts have to be constituted. Thus, Fast Track Courts are to tackle the
section 138 Negotiable Instruments Act cases as the graph of such pendency is very high and
alarming. It is high time to restore the confidence of people in the judiciary by providing speedy
justice.
1.22 It is not uncommon for any criminal case to drag on for years. During this time, the accused
travels from the zone of "anguish" to the zone of "sympathy". The witnesses are either won over by
muscle or money power or they become sympathetic to the accused. As a result, they turn hostile
and prosecution fails. In some cases, the recollection becomes fade or the witnesses die. Thus, long
delay in courts causes great hardship not only to the accused but even to the victim and the State.
The accused, who is not let out on bail, may sit in jail for number of months or even years awaiting
conclusion of the trial. Thus, effort is required to be made to improve the management of
prosecution in order to increase certainty of conviction and punishment for most serious offenders.
It is experienced that there is increasing laxity in the court work by the police personnel, empowered
to investigate the case.
1.23 Judiciary today is more deserving of public confidence than ever before. The judiciary has a
special role to play in the task of achieving socio-economic goals enshrined in the Constitution while
maintaining their aloofness and independence. Judges have to be aware of the social changes in the
task of achieving socio-economic justice for the people.
Justice at easy reach 1.24 The Indian judicial system is constantly exposed to new challenges, new
dimensions and new signals and has to survive in a world in which perhaps the only real certainty is
that the circumstances of tomorrow will not be the same as those of today. The need of the hour is to
erase misconception about the Judiciary by making it more accessible by utilizing the resources
available to improve the service to the public, by reducing delays and making courts more efficient
and less daunting.
1.25 Regarding decongestion, greater responsibility lies on the shoulders of the Governments of
States or the Central Government. They are biggest litigants in the courts. They should approach the
courts or contest cases only if necessary and not just to pass on the buck or contest for the sake of
contesting. The time consumed in most of the cases by Courts of Sessions is somewhat under control
and most of the cases are decided in a reasonable time-schedule. Main problem is about huge
pendency in Magisterial Courts and the High Courts. It is absolutely essential to have additional
courts for specifically trying the complaint cases filed under section 138 of the Negotiable
Instruments Act. The present state of affairs defeats the very object with which the provision was
inserted in the Negotiable Instruments Act. Further, large numbers of petty offence cases should be
taken out of the normal court channel to be decided by the Special Magistrates by appointing retired
officers as Special Magistrates.
1.26 A speedy trial is not only required to give quick justice but it is also an integral part of the
fundamental right of life, personal liberty, as envisaged in article 21 of the Constitution. The Law
Commission is putting forth few suggestions to identify and remedy the causes of such delays in this230Th Report On Reforms In The Judiciary - Some Suggestions

Report, of course, after identifying major hurdles and impediments which cause delay in the
disposal of criminal cases.
1.27 The Law Commission of India is of the firm opinion that considering the alarming situation and
the pendency of cases and the constitutional rights of a litigant for a speedy and fair trial, the
Government of India should direct the State authorities to set up Fast Track Courts in the country,
which alone, in the opinion of the Law Commission, will solve the perennial problem of pendency of
cases.
Integrity, virtue and ethics 1.28 The term integrity when applied to human attributes refers to
honesty, reliability, purity, trustworthiness, incorruptibility, sincerity, honour, decency, etc.
Mahatma Gandhi at one time said that "purity of life is the highest and truest art".
1.29 And in the words of Marcus Aurelius, "a man should be upright, not be kept upright". A person
of integrity will do the right thing even when nobody is watching. Mahatma Gandhi said that "the
truest test of civilization, culture and dignity is character and not clothing".
Governance 1.30 The term 'governance' is derived from a Latin term that literally means steering. It
refers to the processes and systems by which an organization or society operates; the processes by
which decisions are made that define expectations, grant power, or verify performance.
1.31 The ideal concept of public officer, expressed by the words 'a public office is a public trust',
signifies that the officer has been entrusted with public power by the people; that the officer holds
this power in trust to be used only for their benefit and never for the benefit of himself or of a few;
and that the officer must never conduct his own affairs so as to infringe the public trust.
1.32 Citizens have a legitimate expectation that the public servants will serve the public interest with
fairness and manage public resources properly on a daily basis. The increased democratization and
globalization has resulted in increased visibility of the public officials. Critical questions are
nowadays asked about the way in which cases have been dealt with, the justice of the decisions, the
exercise of discretions, and the morals of public servants. Leaders are increasingly being called upon
to account for their actions by the communities affected by those actions.
Anti-corruption 1.33 Corruption in reference to public office has been defined as the abuse of power
for purposes of private gain.
1.34 In public affairs, there often arises a conflict between private wealth and public power. This is
often the result of selfishness and greed. Mahatma Gandhi said that the earth provides enough to
satisfy every man's needs, but not enough to satisfy every man's greed. The conflict needs to be
mediated upon. Institutions that fail to mediate between private wealth and public power run the
risk of becoming dysfunctional and trapped by wealthy interests. Corruption is one symptom of such
failure whereby personal interests overcome public goals.230Th Report On Reforms In The Judiciary - Some Suggestions

1.35 Fighting corruption is one of the facets of promoting good governance. But governance issues
are far much broader than anti- corruption alone. For example, a public officer may be honest and
yet inefficient or incompetent. Efforts to promote good governance must therefore be broader than
anti-corruption campaigns.
1.36 Article 14 of the 'Basic Principles on the Role of Lawyers' adopted by the Eighth United Nations
Congress on the Prevention of Crime and the Treatment of Offenders, Havana, Cuba, in 1990 states:
"Lawyers, in protecting the rights of their clients and in promoting the cause of
justice, shall seek to uphold human rights and fundamental freedoms recognized by
national and international law and shall at all time act freely and diligently in
accordance with the law and recognized standards and ethics of the legal profession."
1.37 Continuing professional development is necessary for all legal practitioners, State law officers
and judicial officers to improve and sustain their proficiency. There should be put in place
mechanism for refresher courses and attendance at them as a pre-condition for renewal of
practising certificates for advocates.
1.38 The Indian Constitution is the source of every law that was and is prevalent in our society. The
Constitution guarantees to all Indian citizens equal protection of public as well as personal rights.
But these rights are of no avail if an individual has no means to get them enforced.
The enforcement of the rights has to be through the courts, but judicial procedure is very complex,
costly and dilatory putting the poor at a distance from justice.
1.39 The Britishers established the current pattern of legal system present in India today, after the
establishment of the English rule in the country. In the year 1857, the first step was taken in the
direction of imparting formal legal education in the country. The Britishers began enacting statutes,
after the revolt of 1857, which resulted in the introduction of a legal system that was moulded along
the lines of the legal system then prevailing in the United Kingdom with an exception to laws
pertaining to religious denominations in India.
Access to justice 1.40 Traditional concept of "access to justice" as understood by common man is
access to courts of law. For a common man, a court is the place where justice is meted out to
him/her. But since the laws enacted were in English and the proceedings of all the courts were
highly complicated, confusing and expensive for the Indian public, the 'English' illiterate Indian
public found it difficult to get access to the justice-delivery system. As a solution, the need to have
lawyers was felt as an effective mediator between the legal world and the common man. Therefore,
we can see that a lawyer in addition to being champion at the various laws also has a social
responsibility of helping the ignorant and the underprivileged to attain justice.
1.41 The State in contemporary scenario is welfare-oriented. It is one of the most important duties of
a welfare state to provide judicial and non-230Th Report On Reforms In The Judiciary - Some Suggestions

judicial dispute resolution mechanisms to which all citizens have equal access, for the resolution of
their legal disputes and enforcement of their constitutionally guaranteed fundamental rights.
Poverty, ignorance or social inequalities should not become barriers to it.
1.42 Article 39A of the Constitution provides for equal justice and free legal aid. The said article
obligates the State to promote justice on a basis of equal opportunity and, in particular, provide free
legal aid by suitable legislation or schemes or in any other way, to ensure that opportunities for
securing justices are not denied to any citizen by reason of economic or other disabilities.
1.43 Lok Adalats, Nyaya Panchayats, Legal Services Authorities are also part of the campaign to take
justice to the people and ensure that all people have equal access to justice in spite of various
barriers like social and economic backwardness.
1.44 Large population, more litigation and lack of adequate infrastructure are the major factors that
hamper our justice system. Regular adjudication procedures through the constant efforts of Legal
Services Authorities will act as catalysts in curing these maladies of our system.
1.45 Disposal of legal disputes at pre-litigative stage by permanent and continuous Lok Adalats
would provide expense-free justice to the citizens of this country. It also saves the courts from
additional and avoidable burden of petty cases enabling them to divert their court-time to more
contentious and old matters. Legal literacy and legal awareness are the principal means to achieve
the objective for ensuring equality before law for the citizens of our country.
1.46 Legal profession of the country, as we know it today, is more than two centuries old. We can
legitimately expect that the future of this profession ought to be very bright, particularly in the
context of the enormous strides our country is making in various fields and human rights
awareness. Public interest has to be its motto and service in the cause of justice its creed. Mahatma
Gandhi was a barrister who practised law without compromising truth. Abraham Lincoln said:
"Discourage litigation, persuade your neighbours to compromise whenever you can. Point out to
them how the nominal winner is often a real loser in fees, expenses and time".
1.47 A stark reality that stares at our face is the fact that more than 70% of the people of this country
are illiterate. The noble objective flowing from the Preamble of the Constitution and the earnest
wish and hopes expressed in the Directive Principles shall remain on paper unless the people in this
country are educated.
Alternate Dispute Resolution 1.48 With the march of time, new demands emerge, which sometimes
make the existing system outdated or non-functional, requiring it to be replaced by a new one. Law
should also respond to the demands of the society. The alternate dispute resolution methods have
evolved as a result of this vision.
1.49 The first avenue where the conciliation has been effectively introduced and recognized by law is
labour law, namely, the Industrial Disputes Act, 1947. Conciliation has been statutorily recognized
as an effective method of dispute resolution in relation to disputes between workers and230Th Report On Reforms In The Judiciary - Some Suggestions

management. The only field where the courts in India have recognized Alternate Dispute Resolution
(ADR) is in the field of arbitration. Another area where ADR is recognized in India is family law. The
legislation which emphasizes ADR is the Legal Services Authorities Act 1987.
1.50 Provisions have been made in the Legal Services Authorities Act for settling cases through Lok
Adalats; a Lok Adalat generally comprises a judicial officer, serving or retired, a lawyer, and a
person of a social welfare association, preferably, a woman. Power has been given to Lok Adalats to
dispose of disputes referred to them by arriving at a compromise or settlement between the parties;
awards of Lok Adalats are deemed to be decrees of civil courts or orders of other courts or tribunals;
every award made by a Lok Adalat is treated as final and binding on all the parties to the dispute,
and no appeal lies to any court against the award.
Advantages of ADR 1.51 Advantages of ADR are many - it is less expensive, less time- consuming,
free from technicalities vis-à-vis conducting of cases in law courts, parties involved are free to
discuss their differences of opinion without any fear of disclosure before any law courts, and the last,
but not the least, there is no winning or losing for any of the parties involved; so, their grievances
are redressed without causing any damage to the relationship between them.
1.52 Another right and welcome step taken was the enactment of the Consumer Protection Act 1986
(CP Act) for settlement of consumer disputes and for matters connected therewith. The aim of the
CP Act is to provide for an effective, inexpensive, simple and speedy redressal of consumer
grievances, which civil courts are not able to provide.
1.53 The Family Courts Act 1984 (FC Act) was enacted to provide for the establishment of Family
Courts with a view to promote conciliation in, and secure speedy settlement of, disputes relating to
marriage and family affairs and for matters connected therewith.
1.54 The Law Commission of India in its 59th Report (1974) had also stressed that in dealing with
disputes concerning the family, the court ought to adopt a humane approach different from that
adopted in ordinary civil proceedings, and that it should make reasonable efforts at settlement
before commencement of the trial.
Appointment of judges 1.55 In selecting persons for appointment as judges, every endeavour should
be made to ensure that persons committed to the need to protect and preserve the institution of
marriage and to promote the welfare of children and qualified by reason of their experience and
expertise to promote settlement of disputes by conciliation and counselling are selected. Justice in
all its facets - social, economic and political - is to be rendered to the masses of this country without
any further loss of time - the need of the hour.
Three players in Judiciary 1.56 The first player is the Government. The Government is mostly at
fault by not filling up vacancies which they know well in advance. The Government fails in
appointing quality judges and providing proper infrastructure, including the basic things like a good
library, typists, etc. 1.57 The second player is the lawyers. We should realize that adjournments, even
if they are in favour of clients, are not in favour of the system. In a number of regulatory cases, there230Th Report On Reforms In The Judiciary - Some Suggestions

is no real need for appeals or adjournments. Given the huge backlog of cases, practical ways and
means need to be thought of, to solve such problems. Ethics of lawyers has also become
questionable. There is a Bar Council that has to look after ethics of lawyers, but it has rarely taken
action against tainted lawyers. Everything becomes customary and loses meaning.
1.58 The third player, of course, is the judges. Unless they display work-ethics, no recommendations
can be of use to them. Fairness, speed and quality should be key values for the judiciary, as for all
other sectors.
1.59 The Judiciary is under great pressure. We have about 10-11 judges per million population right
now. The Supreme Court has recently directed that we should have 5 times the number of judges we
currently have.1 All India Judges' Association v. Union of India, (2002) 4 SCC 247 Reforms 1.60 All
reforms need to take place in an integrated manner. The police, prosecution, lawyers and courts,
must be thought of as being cohesive. The topic of judicial reforms has of late become very
important because the public has lost faith in the system. Judicial accountability is connected with
the larger area of judicial reforms. Everyone is concerned about the large delays in disposal of cases,
and the agenda for judicial reforms must first tackle the problem of this backlog. We have seen a lot
of Law Commission Reports and various suggestions - one of which is the formation of tribunals to
take away some of the workload of High Courts, but still, High Courts are burdened with a large
number of cases. Increasing the manpower in judiciary is the need of the hour. Also, the problem
faced by the judiciary can be solved, if we have scientific data about the cases that clog the dockets.
Pendency 1.61 Pendency is a normal feature of any system but is assuming great proportions in
courts. This will necessitate courts to prescribe time-limits for all cases. To deal with this, there can't
be one prescribed limit, but the kinds of cases need to be identified and prioritized. So setting time-
standards is essential and it will vary for different cases, and also for different courts depending on
their disposal-capacity. This will be necessary to assess the performance of the courts and judicial
accountability.
Technology 1.62 We have modern technology, which facilitates us to collect a lot of information and
making it available to Chief Justices, so that they are able to allocate their manpower efficiently.
Digital techniques and tools are at our disposal, to collect information from an entire database from
the time a case is instituted in a court of law to the final stages of appeal. Building up a judicial
database will enable us to assess the performance of the courts as an institution, and the Chief
Justices will be able to use it to assess the individual performance of judges. This will go a long way
in identifying what the backlog is, what types of cases are clogging the dockets, etc. 1.63 As a part of
digital resource management, we have home pages and websites, where judgments of courts can be
instantly posted. At the moment, it takes a long time for courts to give copies of judgments; with
being instantly posted on the home page, they will be easily and readily available to everyone. This is
an important step for using the technology effectively, to expedite the process of judgments being
accessible.
1.64 Now, digital technology offers us new packages like database, ERP tools, court management
practices - these will help in increasing the productivity of courts; video-conferencing - through230Th Report On Reforms In The Judiciary - Some Suggestions

which we can record evidence. There is, therefore, vast technology available for the courtroom, for
enhancing the quality of justice, and finding the truth - after all, justice is the finding of truth.
Coming back to accountability, like any institution, judiciary is not devoid of vices, but still they are
akin to temples of justice. But still, corruption cannot be acceptable. How does one deal with
corruption? Impeachment was thought to be the remedy to deal with errant judges, but we found
that it is not working well; we have to find some internal institutional mechanism, a sort of peer
committee, enabling judges to deal with such issues. We are not very sure that increasing number of
courts and judges will ameliorate the situation, unless there is a simultaneous productivity increase
in courts! We feel strongly about the issue! 1.65 Judicial reform, as is being looked at, is essential for
the country's overall development, not just economic; in India, the problem is more human than
economic. Ninety per cent of the litigation is by rural people; parties are fighting for even half an
acre of land; families are being ruined. Therefore, there has to be an overall solution.
Computerization of lower courts 1.66 The government has proposed to computerize the lower courts
in future. A scheme for computerization of all the 13,000 district and subordinate courts, prepared
in accordance with the National Policy and Action Plan, has been approved by the government on
8th February, 2007 with National Informatics Centre (NIC) as the implementing agency. The
coverage of the project includes Information and Communication Technology (ICT) enablement of
all the district and subordinate courts and upgrading of the ICT infrastructure of the Supreme Court
and all the High Courts.
1.67 The first phase of the project is being implemented in all the States and Union territories at an
estimated cost of Rs.442 crores. All the lower courts in the country including the courts in the States
of Chhattisgarh, Madhya Pradesh, Orissa and Uttar Pradesh have been taken up for computerization
in the first phase.
1.68 Court records can be digitized to improve the productivity and efficiency of the courts.
Computerization of the Registry of the Supreme Court has had its beneficial effects in slashing down
arrears and facilitated scientific docket management.
1.69 E-filing and video-conferencing by dispensing with physical appearance saves precious time
and resources and makes justice more easily accessible and a less expensive option.
Fast Track Courts 1.70 The government has already taken several initiatives on the path of judicial
reforms. 1562 Fast Track Courts have been set up which have disposed of more than 18 lakh cases
transferred to them. 190 Family Courts, established in various parts of the country, have speedily
settled matrimonial disputes through reconciliation.
Reforms at the village level 1.71 The Gram Nyayalayas Bill has been enacted to set up more trial
courts at the intermediate Panchayat level. The welcome feature is that the procedures have been
kept simple and flexible so that cases can be heard and disposed of within six months. It is also
envisaged that these courts will be mobile, to achieve the goal of bringing justice to people's
doorsteps. Training and orientation of the judiciary, especially in frontier areas of knowledge, like
bio-genetics, IPR and cyber laws, need attention.230Th Report On Reforms In The Judiciary - Some Suggestions

1.72 The Constitutional promise of securing to all its citizens, justice, social, economic and political,
as promised in the Preamble of the Constitution, cannot be realized, unless the three organs of the
State i.e. legislature, executive and judiciary, join together to find ways and means for providing the
Indian poor, equal access to its justice system.
1.73 However, we are of the view that not an inch of change can be brought about if the advocates do
not work in accordance with the responsibility that is cast upon them by the Constitution. Every
lawyer is vested with the responsibility to foster the rule of law and dominance of the Constitution.
1.74 Thus, it cannot be gainsaid that economic development and law go hand in hand. We can't
think of economic progress, unless changing needs of the society are supported by appropriate law.
1.75 We need:
•Speedy justice •Reduction in costs of litigation •Systematic running of the courts
•Faith in the judicial system 1.76 The Indian Constitution provides a beautiful system
of checks and balances under articles 124(2) and 217(1) for appointment of Judges of
the Supreme Court and High Courts where both the executive and the judiciary have
been given a balanced role. This delicate balance has been upset by the 2nd Judges'
case (Supreme Court Advocates-on-Record Association v. Union of India)2 and the
Opinion of the Supreme Court in the Presidential Reference (Special Reference No.1
of 1998)3. It is time the original balance of power is restored. The Law Commission
has in its 214th Report (2008) recommended accordingly.
1.77 The above recommendation for the need for an urgent and immediate review of
the present procedure for appointment of judges is further fortified by his forthright
views expressed by Shri Justice J. S. Verma, a former Chief Justice of India, who had
written the lead judgment in the 2nd Judges' case, expressed in an interview to the
Frontline Magazine published in its issue of October 10, 2008. When asked: "You
said in one of your speeches that judicial appointments have become judicial
disappointments. Do you now regret your 1993 judgment?" Justice Verma
responded: "My 1993 judgment, which holds the field, was very much misunderstood
and misused. It was in that context I said the working of the judgment now for some
time is raising serious questions, which cannot be called unreasonable. Therefore,
some kind of rethink is required. My judgment says the appointment process of High
Court and Supreme Court Judges is basically a joint or participatory exercise between
the executive and the judiciary, both 1993 (4) SCC 441 1998 (7) SCC 739 taking part
in it. Broadly, there are two distinct areas. One is the area of legal acumen of the
candidates to adjudge their suitability and the other is their antecedents. It is the
judiciary, that is, the Chief Justice of India and his colleagues or, in the case of the
High Courts, the Chief Justice of the High Court and his colleagues (who) are the best
persons to adjudge the legal acumen. Their voice should be predominant. So far as
the antecedents are concerned, the executive is better placed than the judiciary to
know the antecedents of candidates. Therefore, my judgment said that in the area of230Th Report On Reforms In The Judiciary - Some Suggestions

legal acumen the judiciary's opinion should be dominant and in the area of
antecedents the executive's opinion should be dominant. Together, the two should
function to find out the most suitable (candidates) available for appointment."
1.78 The views of the Parliamentary Standing Committee on Law and Justice which
has recommended scrapping of the present procedure for appointments and transfers
of Supreme Court and High Court Judges are of great relevance in this context. The
Hindustan Times of October 20, 2008 reported: 'The Law Ministry has agreed to
review the 15-year-old system after the Parliamentary Standing Committee on Law
and Justice recommended doing away with the committee of judges (collegium).
Presently, the collegium decides the appointments and transfer of judges. Interestingly, the
recommendations come close on the heels of recent cases of corruption against judges of the top
courts in the country. Law Minister H. R. Bhardwaj told Hindustan Times that the House
Committee's recommendation had been accepted, and an action-taken report prepared by the
Ministry would now be placed before Parliament.
"Collegium system has failed. Its decisions on appointments and transfers lack
transparency and we feel courts are not getting judges on merit. (......) The
government cannot be a silent spectator on such a serious issue", Bhardwaj said. The
House Committee had said: "Through a Supreme Court judgment in 1993, the
judiciary wrested the control of judges' appointments and transfers. The collegium
system has been a disaster and needs to be done away with". H. R. Bhardwaj,
Minister for Law and Justice, said "It is the right time to review this important
matter". "There was no problem till 1993 when the judiciary tried to re- write the
Article of the Constitution dealing with appointments. They created a new law of
collegium which was wrong. In a democracy, the primacy of Parliament cannot be
challenged", he said.' 1.79 Dr. E. M. Sudarsana Natchiappan, Member of Parliament
and the Chairman of the Department Related Parliament Standing Committee on
Personnel, Public Grievances, Law and Justice, in its 28th Report presented to the
Hon'ble Chairman of Rajya Sabha on 4th August, 2008, has stated thus:
"I would like to conclude by saying that the Government should expeditiously see to it
that appointments of Judges in High Courts and Supreme Court are done in a
transparent way. We have recommended in two ways: One is, we have to see to it that
the collegium system has to be done away with. Instead we have suggested that an
Empowered Committee, which comprises representatives of the Judiciary, the
Executive and Parliament, should be set up. That was our recommendation in the
Judges (Inquiry) Bill. And, subsequently, since appointments will be delayed, we
have said that from the very beginning of identifying the eligible persons, the various
places of recommendations, be it at the level of the High Courts, or, at the Governor's
level or at the level of the Departments, and finally be the Supreme Court, should be
transparent, and this should be put up in the web site then and there so that the
person, who is going to occupy the Constitutional place, is known to the public, and230Th Report On Reforms In The Judiciary - Some Suggestions

their background should be allowed to be discussed by the public and, finally, it has
to go through the process of issuing warrant by the President of India. But, what is
happening presently is that from the day one of identifying the person till the
issuance of the warrant, nothing is known to anybody except to the persons who are
involved in it. Even the persons, who are identified and who are going to be made as
judges of the High Court or of the Supreme Court, may not know about it. This type
of secrecy is not good for democracy."
1.80 It may be noted in this context that in every High Court the Chief Justice is from outside the
State as per the policy of the Government. The senior-most Judges who form the collegium are also
from outside the State. The resultant position is that the judges constituting the collegium are not
conversant with the names and antecedents of the candidates and more often than not,
appointments suffer from lack of adequate information.
1.81 As recommended in the Law Commission's 214th Report, two alternatives are available to the
Government of the day. One is to seek a reconsideration of the three Judges' cases by the Hon'ble
Supreme Court. The other alternative is to enact a law restoring the primacy of the Chief Justice of
India and the power of the Executive in making the appointments.
II. RECOMMENDATIONS 2.1 Hon'ble Shri Justice Asok Kumar Ganguly, a Supreme Court Judge,
in his article titled "Judicial Reforms" published in Halsbury's Law Monthly of November 2008 has
suggested a few norms, which the judges and lawyers must agree to follow very rigorously, in order
to liquidate the huge backlog. The suggestions are quoted below:
'[1] There must be full utilization of the court working hours.
The judges must be punctual and lawyers must not be asking for adjournments,
unless it is absolutely necessary. Grant of adjournment must be guided strictly by the
provisions of Order 17 of the Civil Procedure Code.
[2] Many cases are filed on similar points and one judgment can decide a large
number of cases. Such cases should be clubbed with the help of technology and used
to dispose other such cases on a priority basis; this will substantially reduce the
arrears. Similarly, old cases, many of which have become infructuous, can be
separated and listed for hearing and their disposal normally will not take much time.
Same is true for many interlocutory applications filed even after the main cases are
disposed of. Such cases can be traced with the help of technology and disposed of
very quickly.
[3] Judges must deliver judgments within a reasonable time and in that matter, the
guidelines given by the apex court in the case of Anil Rai v. State of Bihar, (2001) 7
SCC 318 must be scrupulously observed, both in civil and criminal cases.230Th Report On Reforms In The Judiciary - Some Suggestions

[4] Considering the staggering arrears, vacations in the higher judiciary must be
curtailed by at least 10 to 15 days and the court working hours should be extended by
at least half-an- hour.
[5] Lawyers must curtail prolix and repetitive arguments and should supplement it by
written notes. The length of the oral argument in any case should not exceed one
hour and thirty minutes, unless the case involves complicated questions of law or
interpretation of Constitution.
[6] Judgments must be clear and decisive and free from ambiguity, and should not
generate further litigation. We must remember Lord Macaulay's statement made
about 150 years ago.
"Our principle is simply this -
Uniformity when you can have it, Diversity when you must have it, In all cases,
Certainty"
[7] Lawyers must not resort to strike under any circumstances and must follow the decision of the
Constitution Bench of the Supreme Court in the case of Harish Uppal (Ex-Capt.) v. Union of India
reported in (2003) 2 SCC 45.
Things I know are easier written, than done and for all these reforms, what is required is a lot of
discipline and introspection and a realization that without these reforms, the present system is
under threat. Both, judges and lawyers, have to change their mindsets. Unless our mental barriers to
reforms are mellowed, all doses of external remedies are bound to fail. We must remember what
Gandhiji said: "If you want to change anything, you be the change".' 2.2 We adopt the above
suggestions and recommend accordingly.
                     (Dr Justice AR. Lakshmanan)
                               Chairman
(Prof. Dr Tahir Mahmood)                    (Dr Brahm A. Agrawal)
        Member                                 Member-Secretary
                                                             ILI Building (IInd Floor),
Dr. Justice AR.                                                 Bhagwandas Road,
Lakshmanan                                                      New Delhi-110 001
                                                            Tel. : 91-11-23384475
(Former Judge, Supreme Court of India)                      Fax : 91-11-23383564
Chairman, Law Commission of India230Th Report On Reforms In The Judiciary - Some Suggestions

                                                                            11.8.2009
Hon'ble Minister Moily Ji,
In the Law Commission's 230th report on "Reforms in the Judiciary - Some Suggestions", at para
1.37, it has been stated as under:-
"1.37 - Continuing professional development is necessary for all legal Practitioners,
State Law Officers and judicial officers to improve and sustain their proficiency.
There should be put in place mechanism for refresher courses and attendance at
them as a pre-condition for renewal of practicing certificates for advocates."
2. Since Advocates have to enroll with the State Bar Council concerned before starting their practice
as is the case with other professions like doctors, etc. coupled with the fact that there is no provision
in the existing statute for renewal of their enrolment, the second para of the said para would not
apply to our Advocates. In fact, this was a citation culled out from: The Advocate - Magazine of the
Law Society of Kenya (para 28-43). This portion of the report under the heading "Themes and
Thoughts" is also not our recommendation. However, in order to avoid any controversy on the
point, we have decided to delete the same. Accordingly, the second part of the said para may be
treated as withdrawn.
With personal regards, Yours sincerely, (AR. Lakshmanan) Dr. M. Veerappa Moily, Minister of Law
& Justice, Shastri Bhawan, New Delhi.230Th Report On Reforms In The Judiciary - Some Suggestions

