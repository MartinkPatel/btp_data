Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors.
on 31 August, 2001
Equivalent citations: (2002)1BOMLR62, 2002(2)MHLJ631
Author: S. Radhakrishnan
Bench: B.P. Singh, S. Radhakrishnan
JUDGMENT
 S. Radhakrishnan, J. 
1. All the above petitions raise certain common issues of law and involve similar facts, hence we are
disposing of the same by this common judgment.
2. In Writ Petition No. 1749 of 1999 Cipla Limited and Anr. v. Union of India, and Ors. the brief facts
and submissions are as under :--
3. The First Petitioner Company is a domestic pharmaceutical company which manufactures and
sells various pharmaceutical bulk drugs and formulations. The present petition is filed challenging
:--
(a) The totally arbitrary, unjustified and mala fide refusal by the Respondents to issue
the exemption notification to the petitioners to which they are entitled, and which
has already been directed to be issued exempting Salbutamol and its formulations
manufactured by the first Petitioners from the ambit of price control in view of the
new process developed by the petitioners by virtue of its indigenous R & D, and in
view of Drugs (Price Control) Order of 1987 providing for such an exemption, under
Clause 28 thereof,
(b) The wrongful, illegal and arbitrary inclusion of the drugs Salbutamol and
Theophyline within the ambit of price control despite the fact that the new drug
policy 1994 of the Respondents provides specific parameters for the inclusion of
drugs within the ambit of price control and the aforesaid formulations of the
petitioners do not fall within the scope of the said drug policy.
(c) Totally in a discriminatory and arbitrary manner the Respondents have fixed the
price for the formulations of Salbutamol sold by the petitioners without fixing any
price for similar products generally, thus singling out the petitioners for coercive
action.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

4. It is the case of the petitioners that they manufacture Salbutamol which is a bronchodilator for
the treatment of asthma and also they manufacture formulations of Salbutamol along with
Theophyline. These products which are used for the treatment of Asthma are sold at prices ranging
from 30 paise to 90 paise per dose which prices are amongst the cheapest in the world. It is the
contention of the petitioners that the first petitioner company has begun manufacturing Salbutamol
since 1976, and the said Salbutamol is not a Scheduled drug, and that the price of the drug has
remained unchanged since 1976. The major formulation which was sold by the petitioners with
regard to the said drug is sold in a strip of 10 tablets costing barely Rs. 3.43 ps. It appears that for
the first time, the Drugs Price Control Order of 1979 classified the aforesaid Salbutamol as a bulk
drug and no sale price was fixed. In September, 1988 the first petitioner company M/s Cipla Limited
had developed a new and innovative process for the manufacture of Salbutamol and had
commenced the commercial production and by this time sale price was also fixed for Salbutamol.
Thereafter, it appears that on 10th October, 1990 the Respondents herein had issued a notification
exempting M/s Cipla Ltd. from price control in respect of Salbutamol and its formulations for a
period of 5 years from September, 1988 to 31st August, 1993. It is the contention of the petitioners
that in 1993, M/s Cipla Limited had developed through its own indigenous R & D, a newer, more
efficient and more cost effective process for the manufacture of Salbutamol. On 25th August, 1993
M/s Cipla Ltd. had applied to the first Respondent Union of India for exemption of Salbutamol from
the provisions of the DPCO on the ground of R & D based on its new process. On 10th December,
1993 Union of India had acknowledged the receipt of aforesaid application but had asked for a new
proforma from M/s Cipla Limited.
5. On 25th October, 1994 Union of India had formulated a new drug policy known as the New Drug
Policy, 1994 which contained the guidelines for the first time setting out the criteria by which the
drugs should or should not be included under the price control, and the petitioners had been
representing to the Respondents for the exclusion of Salbutamol from the ambit of price control
under the new policy. Broadly the said policy had prescribed that any drug with an annual turnover
of below Rs. 400 lacs should be excluded.
6. Meanwhile on 10th December, 1996 this Court by an interim order in Writ Petition No. 569/1996
had held that the value of exports will have to be excluded while determining minimum annual
turnover, and that the minimum annual turnover of Rs. 400 lacs must be determined on the basis of
annual sales figures as per ORG, and that the minimum annual turnover must not be determined on
the basis of any hpothetical calculation based on cost of production etc. And after laying down the
principles for determining inclusion and exclusion, this Court granted interim relief to the
manufacturer of drugs whose products had been wrongfully included in the ambit of price control. It
appears that the ORG Data for the relevant period prescribed under the Drug policy (i.e.89-90) for
the said drug Salbutamol shows a turnover of Rs. 171.03 lakhs. The Drug Policy had also prescribed
that if there were to be at least 5 bulk drug producers and at least 10 formulators and none have
more than 40% market share the drug should be excluded from price control. The policy had also
required that the market share should be determined with reference to ORG figures. It appears that
as per the ORG figures for the relevant period, there were at least 5 bulk drug producers and at least
10 formulators for Salbutamol and ORG had themselves certified that no one had more than 40%
market share. Similarly, it appears that, for Theophyline, there were at least 5 bulk drug producersCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

and at least 10 formulators and none of whom had more than 40% market share as per ORG. The
petitioners had specifically furnished the names and addresses of each of the said bulk drug
producers and formulators.
7. In December, 1997, one Writ Petition bearing No. 5578/1997 was filed in the Delhi High Court by
the Bulk Drug Manufacturers Association of which the first petitioner M/s Cipla Limited was a
member. The said petition interfalia had challenged the wrongful inclusion of several drugs within
the ambit of price control, two of these drugs being Salbutamol and Theophyline. On 10th June,
1997 one circular letter had been issued by the Respondents directly contrary to the orders of the
Bombay High Court as aforementioned. In the said letter it was mentioned that the exports would
be included in determining the turnover and that the ORG figures will not be considered. The
aforesaid petition being Writ Petition No. 5578/1997 has been admitted by the Delhi High Court and
is pending for final hearing. It appears that by an interim order passed in the aforesaid Writ Petition
on 7th January, 1999, the Delhi High Court had directed that no action should be taken against the
manufacturers of 8 drugs on the basis of their inclusion within the price control. These 8 drugs
include Salbutamol and Tehophyline. It further appears that by an affidavit dated 2nd February,
1999 filed in the Delhi High Court in the aforementioned proceedings, the third Respondents have
attempted to work out the turnover of Salbutamol based upon the alleged cost of production
ignoring actual sales figures as per ORG.
8. It appears that for the first time in the year 1979 the said drug Salbutamol has been brought
within the ambit of price control, and there was no price fixation for Salbutamol based formulations
until 1987. It appears that M/s Cipla Limited which manufacturers around 20 different formulations
based on Salbutamol of which 18 formulations have a price fixed for them.
9. In Writ Petition No. 3449 of 1996 Raj Medicals and Ors. v. Union of India, and Ors. the learned
Counsel Mr. Iqbal Chagla has submitted that the petitioner No. 2 "Ranbaxy" has from about May,
1989 had manufactured the bulk drug "Ciprofloxacin" which is captively consumed by Ranbaxy in
the manufacture of formulations marketed under the brandnarne "Cifran" from about 10th June,
1989. In this petition, the petitioners have challenged the inclusion of Ciprofloxacin (as Item 27) in
the First Schedule to the Drugs Price Control Order, 1995 ("DPCO 1995") and the subjecting of
Ciprofloxacin to price control. The petitioners have also challenged the consequential issue of the
notification dated 3rd April, 1996 fixing the maximum price of Ciprofloxacin under the DPCO 1995.
It is an admitted position that prior to the introduction of the DPCO 1995 neither the said bulk drug
Ciprofloxacin nor the formulations made therefrom were brought under price control.
10. The DPCO 1995 has been issued in exercise of powers under Section 3 of the Essential
Commodities Act, 1995 and pursuant to the New Drug Policy 1994 issued on 15th September, 1954
by the Ministry of Chemicals and Fertilizers, Government of India. Previously, the following drugs
price control orders had been issued :--
A. The Drug Price Control Order, 1970.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

B. The DPCO 1979 published on 3Ist March, 1979 had repealed the earlier DPCO 1970 and DPCO
1979 was issued pursuant to the statement on Drug Policy 1978. The Drugs Policy 1978 was
formulated based on the report of the Committee on Drugs and Pharmaceutical Industry made in
April, 1975 (the Hathi Committee Report), C. The DPCO 1987 published on 26th August, 1987
repealed the earlier DPCO 1979. The DPCO 1987 was issued pursuant to the Drug Policy 1986
"Measures for Rationalization, Quality Control and Growth of Pharmaceutical Industry 1986-1987."
Again DPCO 1987 was repealed by the DPCO 1995.
11. Mr. Chagla, the learned Counsel has submitted that as far as the Drugs Policy 1986 was
concerned, it recognized the considerable change in the pharmaceutical sector since the Drug Policy
1978 and had sought to give "new thrust and direction" to subserve the objective of growth of the
Pharmaceutical Industry. The objective of the Drugs Policy 1986 was to ensure abundant availability
at reasonable prices all essential life saying and prophylatic medicines of good quality, to strengthen
the system of quality control over drug production and promote the rational use of drugs in the
country, to create an environment conducive to channelising new investment into the
pharmaceutical industry, to encourage cost-effective production with economic sizes and to
introduce new technologies and new drugs and to strengthen the indigenous capability for
production of drugs. It appears that both the DPCO 1979 as well as the DPCO 1987 contained the
same provisions in para 3(1) thereof which reads as under:--
"3. Power to fix the sale price of indigenously manufactured bulk drugs specified in
the first or second schedule. -- (1) The Government with a view to regulate the
equitable distribution and increasing supply of an indigenously manufactured bulk
drug specified in the First or Second Schedule and making it available from different
manufacturers at fair prices, after making such inquiry as it deems fit, fix from time
to time by notification in the Official Gazette, a maximum sale price at which such a
bulk drug shall be sold;
Provided that for the purpose of enquiry, details in Form-1 of Fourth Schedule and
such additional details as may as required shall be provided by the manufacturers
twice a year viz. 31st January and 30th June, in a year or as and when required by the
Government:
Provided further, that where the Government fixes more than one price for a bulk
drug produced by different manufacturers, on account of different options exercised
by manufacturers of such bulk drug under sub-paragraph (2), Government may also
fix a weighted average price for such bulk drug which shall be considered in fixation
of prices of formulations containing such bulk drug."
12. The Respondents had established a Committee known as "Kelkar Committee" consisting of
representatives of the Department of Chemicals and Fertilizers the Ministry of Health and the
Bureau of Industrial Costs and Pricing as well as of the State Governments. The Committee was
chaired by the then Chairman of BICP Mr. Kelkar and was popularly known as the Kelkar
Committee. It was constituted to draw up the lists of drugs to be included in Category I and CategoryCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

II of the DPCO 1987 and adopted five criteria for inclusion/exclusion of drugs in Category II i.e.
drugs other than those in Category I but which were also considered essential for health needs and
would carry MAPE of 100%. It appears that in or about 1987 the Kelkar Commiteee was further
directed to review the aforesaid list and to consider the several representations made against
inclusion in the said lists which were contrary to the aforesaid five criteria. Upon such a review, the
Kelkar Committee had recommended the exclusion of 47 drugs from Category II out of the total of
139 recommended for price control by the Kelkar Committee itself. The Kelkar Committee had also
recommended the inclusion of 4 bulk drugs in the said list since they fulfilled the aforesaid inclusion
criteria. It further appears that on or about 27th February, 1990 the first Respondent - Union of
India had also included 21 further drugs under the price control. However, notably the Ciprofloxacin
was not included under the price control despite the aforesaid inclusions, as pointed out by Mr.
Chagla.
13. Mr. Chagla then submitted that as far as new Drugs Policy 1994 was concerned, it acknowledged
arbitrariness and lack of transparency in the inclusion/exclusion of bulk drugs under price control.
In this context paragraphs 9 and 10 thereof are relevant. In paragraph 22.7.2 under the heading of
"Span of Control" certain established criteria/guidelines were set out. Paragrapah 22.7.4 thereof
provided for a simplified procedure. The said Drugs Policy 1994 recognised the vastly improved
export performance of the Pharmaceutical Industry and noted that the industry had been a net
exporter during the last four years as well as that the Pharmaceutical Sector had been identified as
one of the thrust areas for exports.
14. So far as the DPCO 1995 was concerned, in keeping with the focus of the Drugs Policy 1994 viz.
the special emphasis on turnover as an index of the extent of usage of a drug and on ensuring the
equitable distribution and abundant availability of drugs of good quality as well as to introduce new
technologies and new drugs in India, Para 3(1) of the DPCO 1995 came to be modified. It was
submitted that the criteria for inclusion in the First Schedule of the DPCO 1995 which were
mandatorily required to be observed, were set out in para 22.7.2 of the Drugs Policy 1994, and the
said criteria was to operate as under:--
(i) a minimum annual turnover of Rs. 400 lakhs considered a sufficiently high
turnover as an index of extent of usage and therefore to be included under price
control:
Provided however where even though the turnover exceeds Rs. 400 lakhs but there is
sufficient market competition, i.e. at least 5 bulk drugs producers and at least 10
formulators, none having more than 40% market share in the retail trade (as per
ORG) the drug is excluded from price control.
(ii) Even where the annual turnover is less than Rs. 400 lakhs but where it is greater
than Rs. 100 lakhs then if the drug is of popular use in which there is a monopoly
situation, i.e. if there is a single formulator having 90% or more market share in the
retail trade (as per ORG) the drug is to be included under price control.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

15. It appears that as per ORG Data for the year ending in 31st March, 1990 as per the provisions of
para 22.7.2(v), the domestic sales turnover of the formulation from the bulk drug Ciproflozacin was
Rs. 867 lakhs. Working backwards, the aggregate turnover of the bulk drug Ciprofloxacin was Rs.
288 lakhs and there were several formulators of formulations from Ciprofloxacin and there was no
single formulator having 90% or more market share in the retail trade.
16. Mr. Chagla, the learned counsel submitted that the reference to "Annual turnover" in para 2.7.2.
(i) is a reference to domestic sales turnover of the bulk drug that is to say the aggregate quantity of
the bulk drugs sold in the domestic market (whether, produced in India or imported from abroad)
and cannot include the quantity of the bulk drugs imported or produced in India but exported. It is
further submitted that the DPCOs only exercise power under Section 3 of the Essential Commodities
Act, 1955 and cannot purport to nor are they intended to regulate prices of essential commodities,
i.e. drugs outside the territorial limits of India, Section 3(1) of the Act, provides as under :--
"3. Powers to control production, supply, distribution, etc. of essential commodities.
-- (1) If the Central Government is of the opinion that it is necessary or expedient so
to do for maintaining or increasing supplies of any essential commodity or for
securing their equitable distribution and availability at fair prices (or for securing any
essential commodity for the defence of India or the efficient conduct of military
operations), it may, by order, provide for regulating or prohibiting the production,
supply and distribution thereof and trade and commerce therein."
. 17. It is further submitted by the petitioners that the object and purpose of the Drugs Policy 1994
and the DPCO 1995 was to ensure cheap and ready availability of drugs in India by the use of
transparent and objective criteria. As stated in para 9 of the Policy the high turnover of a drug is an
index of its extent of usage and is considered to meet the requirement of objectivity justifiable on
economic considerations. The object was not to restrict foreign exchange earnings of Indian Drug
Companies whereby our Country was also benefitting. The intent and purpose of the word
"turnover" as used in para 9 of the Drugs Policy 1994 i.e. "to determine the extent of the usage of a
bulk drug in the country" has been emphasized in the Affidavit in Reply in para 3(v) at page 155. It is
submitted that this would mean that the emphasis is on determining the usage of the bulk drug in
the country that is to say the sales turnover, and in other words exports must necessarily be
excluded. It appears that the expression "turnover" and "sales turnover" are used interchangeably in
the Drug Policy 1994 and the DPCO 1995. It is further borne out by the fact that under para 20(1) of
the DPCO 1995 every manufacturer and importer is required to maintain records relating to the
"sales turnover of individual bulk drugs manufactured or imported by him as the case may be, and
the sales turnover of formulations pack-wise at the premises of the manufacturer or importer and
also such other records as may be directed from time to time by the Government and the
Government shall have the power to call for such records or to inspect such records". Para 20(2)
also requires such manufacturer or importer to submit to the Government within six months of the
close of the accounting year information in respect of "turnover and allocation of sales and expenses
for that year.....". Para 20(3) requires every dealer, manufacturer or importer to maintain the cash
memo or credit memo, books of account and records of purchase and sale of drugs......". So far as
para 25 of the DPCO 1995 is concerned it lays down the factors that are to be taken into accountCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

whilst granting exemption to any manufacturer from the operation of all or any of the provisions of
the DPCO 1995. One of the factors is "sales turnover" to be taken into account whilst granting
exemption. It is also submitted by the petitioners that it would be arbitrary and perverse to utilise
"production and imports" for deciding inclusion whilst only "sales turnover" granting exemption. It
appears that the Respondents in their affidavit in reply contend that whilst one standard is to be
adopted for the term "turnover" in para 22.7.2 (i) (viz. the value of the total production of the bulk
drugs in the country and the value of weighted landed cost of its total import into the country), a
different standard is to be applied for the criteria mentioned at para 22.7.2(ii) and (iii) viz. retail
sales data of formulations of bulk drugs as reported by the ORG. Therefore Mr. Chagla contended
that this would be against all the canons of construction. The term "turnover" must necessarily be
given the same meaning when used in the different sub-paragraphs of paragraph 22.7.2 of Drug
Policy, 1994.
18. Further, Mr. Chagla submitted that the ORG Sales Data is a recognised database for the retail
sales of formulations in the country and is accepted as determinative even by the Drug Policy 1994
itself. It is further submitted that the tunrover of bulk drugs can and has been derived by working
backwards from ORG sales data. This ORG Sales data ignores sales to hospital, Government
Organisations Exports etc., since presumably such data is not a part of the data of drugs sold in the
trade channel and therefore not an index of usage. It is further submitted that the first Respondent
Union of India has itself adopted such a method and an example is the case of Norfloxacin which
has been included in DPCO 1995 where the turnover for the bulk drug of about Rs. 500 lacs was
computed by working backwards from the retail sales turnover of formulations as taken from ORG
data for the period ending in March, 1990.
19. Mr. Chagla further submitted that a contextual and purposive interpretation of the term
"turnover" as used in the Drugs Policy 1994 should be adopted and that this Court should take into
account the objectives and purposes of the Drug Policy 1994 and the setting and context in which
the term "turnover" is used therein to give it a colour and meaning. The petitioners further submit
that the term "turnover" cannot be read in isolation from its context nor can different meanings be
attributed to the said term in respect of its use in different parts of the criteria as set out in para
22.7.2. It is contended that taking the aggregate production along with the imports cannot be the
correct computation of turnover. Turnover requires conversion of the aggregate turnover of
formulations into turnover of bulk drugs and what is required to be established is to determine the
usage of the drug in the country. It is therefore contended that based on the accepted principles of
Cost Accounting and Audit Rules, turnover, in the context in which it is used under the Drugs Policy
1994, must necessarily mean "Imports and Domestic Production (opening stock less closing stock)
less exports."
20. Mr. Chagla, the learned counsel for the petitioner then contended that Drug Ciprofloxacin would
today not satisfy the criteria for inclusion under para 22.7.2. Further, he submitted that today there
are 47 producers of the bulk drug and 117 formulators far in excess of the 5 bulk drug producers and
10 formulators as required by para 22.7.2 (iii). Thus, today, Ciprofloxacin would in any event be
excludable from price control as per the established criteria under para 22.7.2 (iii) of Drug Policy,
1994.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

21. The learned counsel on behalf of the petitioners further submitted that the entire decision
making process whereby drugs have been included or excluded in the First Schdule to DPCO 1995
has been arbitrary, irrational and not based on the said criteria and is therefore ultra vires and
without the authority of law. It is further submitted that as a result of representations made in
respect of 19 bulk drugs which were wrongly included in the First Schedule the Respondents had
established a Committee of Experts (the M. M. Sharma Committee) to consider and review the lists
of drugs included in the First Schedule. These representations included representations in respect of
Ciprofloxacin and Mefenamic Acid. Ranbaxy also made its representations to the M. M. Sharma
Committee by its letter dated 27th February, 1996. Despite the aforesaid, a price fixation order dated
3rd April, 1996 was issued in the case of Ciprofloxacin even before the M. M. Sharma Committee
could decide Ranbaxy's representations.
22. Mr. Chagla pointed out that in Writ Petition No. 569 of 1996 this Court had passed an interim
order on 10th December, 1996 in which a statement was made in an affidavit filed on behalf of the
Respondents which referred to the constitution and the ongoing work of the M. M. Sharma
Committee. This Court has held that implicit in the statement referred thereto, was an
understanding that the Respondents would not fix the price of the bulk drugs pending
determination by the M. M. Sharma Committee. Reference to the aforesaid, has been made by the
petitioners in para 5 of the present Writ Petition. It appears that the Respondents had first filed an
affidavit dated 16th September, 1996 to oppose admission of the present Writ Petition and in para 5
thereof dealt with the aforesaid, and inter alia had stated that "there was no nexus between the
process of fixation of the prices of bulk drugs and the examination of inclusion/exclusion of bulk
drugs by the Expert Committee which was a policy matter and both the issues were independent and
separate." It appears that the identical contentions were reiterated in the main affidavit in reply
dated 18th July, 2000. It is submitted by the petitioners that these affidavits suggest that far from
considering the representations made by various manufacturers including Ranbaxy, the M. M.
Sharma Committee had in fact been disbanded by the Respondents in May, 1996 after having held
five sittings. According to the petitioners, the said M. M. Sharma committee could not make any
recommendations as full data required by it was not furnished to it by the Respondents. The
petitioners have contended that, not only the aforesaid M. M. Sharma Committee was disbanded,
but the Respondents further did not for over three years after the said Drug Policy 1994, establish
the National Pharmaceutical Pricing Authority (NPPA) as contemplated by the said Policy. The
NPPA was finally notified by a resolution dated 29th August, 1997 and it actually commenced work
only in or about October, 1997.
23. Mr. Chagla contended on behalf of the Petitioners that significantly, however, the Respondents
even after finally constituting the NPPA on 29th August, 1997 had sought to pre-empt its
functioning by deleting the bulk drug Mefenamic Acid and Amikacin Sulphate (in respect of which
representations had been pending for over 15 months) from the First Schedule to the DPCO 1995 on
or about 2nd September, 1997 i.e. before the NPPA could consider these. These two drugs were two
of the drugs in respect of which representations had been made to M. M. Sharma Committee. The
sales turnover of Mefenamic Acid between 1988 and 1992 was over Rs. 400 lakhs. The import value
of Amikacin Sulphate in 1989-90 was Rs. 350 lakhs which rose to Rs. 475 lakhs in 1990-1991 and
touched a level of Rs. 845 lakhs in 1992-1993. It is further submitted that there are only twoCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

formulations of these drugs in the market and a single formulator has market share in excess of
40%.
24. The learned Counsel Mr. Chagla has contended that the arbitrary inclusion/exclusion of bulk
drugs by the Respondents on a "pick and choose" basis discloses a hostile discrimination,
subjectivity and a lack of transparency. It is further submitted that the objective of transparency has
also been observed only in its breach. It is submitted by the petitioners that the Respondents have
acted on the basis of the findings of a so called "Turnover Group" which consisted of officers in the
Ministry of Chemicals and Fertilizers. Neither the petitioners nor any others in the Industry had
been given a hearing by the Turnover Group, and it is further stated that the Turnover Group has
not even considered the various representations made including the Ranbaxy. No details or
particulars of the data has been considered by the Turnover Group nor any copy of the report of the
Turnover Group has been furnished to the petitioners despite requests from time to time. It is
further submitted that the petitioners have been denied relevant data which was with the
Respondents relating to production, exports and imports, and that no particulars or data considered
by the "Expert Group on Turnover Issues of the Standing Committee" constituted by the
Respondents prior to the DPCO 1995 had been made available to the petitioners. It is the case of the
petitioners that the Respondents have also not furnished all the documents and reports on the basis
of which drugs were included in the First Schedule. It is the contention of the petitioners that the
petitioners had addressed about sixteen letters to the Respondents between January, 1995 and
November, 1996 but none of the letters were replied to.
25. Mr. Chagla, the learned counsel for the petitioners made it explicitly clear that what the
petitioners are seeking is only a judicial review of the arbitrary, irrational and illegal inclusion of
Ciprofloxacm in the First Schedule to the DPCO 1995. Review is not sought in respect of fixation of
the price thereof. However, there is no bar to such a judicial review, according to the petitioners.
Relying on the decision of the Supreme Court in Union of India v. Cyanamide , it is submitted that
even in a case of price fixation the price fixed could be questioned in a Court on the ground of
arbitrariness or that the consideration stipulated by the said Order as relevant were not taken into
account or that irrelevant considerations were not kept out for the determination of the price. It is
submitted that the Court could inquire into whether the policy and the guiding factors for price
fixation were present in the mind of the authority. It is the submission of the petitioners that the
principles laid down in the aforesaid Cyanamide case do not restrict judicial review by a Court of the
wrongful inclusion of a drug under price control, which is a non legislative and an administrative
act.
26. In Writ Petition No. 3031 of 1996 USV Limited and Anr. v. Union of India and Ors. and in Writ
Petition No. 5219 of 1996 USV Limited and Anr. v. Union of India and Ors., Mr. Rohit Kapadia, the
learned Counsel for the petitioners has submitted that the petitioner USV limited is a 100%
domestic concern carrying on the business, inter alia, of the manufacture and sale of diverse
pharmaceutical products. By Writ Petition No. 3031/96 the petitioners are challenging the inclusion
of a bulk drug called "Doxcycline" at Item No. 26 in the Schedule to the Drug Price Control Order,
1995 (DPCO 1995) and by Writ Petition No. 5219/96 the petitioners are challenging inclusion of a
bulk drug called "Glipizide" at Item No. 57 of the DPCO 1995. The main grounds of challenge to theCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

inclusion of the aforesaid two drugs in the First Schedule to DPCO 1995 are that the inclusion of the
said drugs is contrary to the policy issued by the Government of India in the form of New Drug
Policy 1994, that the inclusion of the aforesaid bulk drugs in the First Schedule to DPCO 1995 is
completely arbitrary and based on criteria that are completely irrelevant and the same has been
done demonstrably without any application of mind. The petitioners contend, so far as drug
Doxycycline is concerned, the said drug does not even figure in the various drugs considered by the
"Standing Committee" for inclusion/exclusion. And that so far as Glipizide is concerned, similarly
placed drugs in the same therapeutic segment as Glipizide are kept out and there is a patent and
hostile discrimination in including the bulk drug, Glipizide, within the purview of price control.
27. Mr. Rohit Kapadia on behalf of the petitioners has contended that DPCO 1995 was issued in
exercise of the powers conferred under Section 3 of the Essential Commodities Act, 1955 and was
based on the New Drug Policy issued on 15th September, 1994, Prior to the same, the Drug Policy of
1986 coupled with the Drug Price Control Order 1986 which was in force, and the main objects of
the Drug Policy, 1986 were to ensure abundant availability, at a reasonable price all essential and
life saving and prohylactic medicines of good quality, to strengthen the system of quality control
over drug production and to promote the rational use of drugs in the country, to create an
environment conducive to channelising the new investment into the pharmaceutical industry to
encourage cost-effective production and to introduce new technologies and new drugs, and to
strengthen the indigenous capability for production of new drugs. Therefore, according to the
petitioners, the purpose of the drug policy has always been to ensure availability of quality drugs at
reasonable prices within our country.
28. Mr. Kapadia submitted that on behalf of the petitioners that the Government had acknowledged
the arbitrariness and lack of transparency in the inclusion/exclusion of bulk drug prevailing under
the Drug Policy 1986. It is further submitted by the petitioners that the Government had decided to
modify the Drug Policy 1986 and in the light of paragraph 9 of the New Drug Policy the criteria for
inclusion/exclusion of bulk drug were laid down in paragraph 22.7.2. paragraph 9 of the New Drug
Policy reads as under :--
"Pricing : The aberrations, which have come to notice, in the list of drugs and their
categorization for the purpose of price control, need to be eliminated by the use of
transparent criteria applied across the board of all the drugs with minimum use of
subjectivity. The high turnover of a drug is an index of its extent of usage and is
considered to meet the requirement of objectivity justifiable on economic
considerations. However, the monopoly situation in case of drugs with comparatively
lower turnover has also to be kept in view. Also, as an experimental measure, drugs
having adequate competition may not be kept under the price control and if this
proves successful, it would pave the way for further liberalization. In the event,
however, prices of these drugs not remaining within reasonable limits, the
Government would reclamp price control."
So far as paragraph 22.7.2 of new Drug Policy 1994 is concerned, it reads as under:--Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

"22.7.2. Span of Control
(i) The criteria for including drugs under price control will be the minimum annual
turnover of Rs. 400 lacs;
(ii) Drugs of popular use in which there is a monopoly situation will be kept under
Price Control. For this purpose, if for any bulk drug having an annual turnover of Rs.
100 lacs or more there is a single formulator having 90% or more market share in the
retail trade (as per ORG) a monopoly situation would be considered as existing.
(iii) Drugs in which there is sufficient market competition, viz. at least 5 bulk drug
producers and at least 10 formulators and none having more than 40% market share
in the retail trade (as per ORG) may be kept outside the Price Control. However, a
strict watch would be kept on the movement of prices as it is expected that their
prices would kept in check by the forces of market competitors. The Government may
determine the ceiling level beyond which increase in price will not be permissible.
(iv) Government will keep a close watch on the prices of medicines, which are taken
out of price control. In case, the price of these medicines rise unnecessarily, the
Government would take appropriate measures, including reclamping of price control;
(v) For applying the above criteria, to start with, the basis would be the data upto 31st
March, 1990 collected for the exercise of the review of the drug policy. The updating
of the data will be done by the National Pharmaceutical Pricing Authority as detailed
in paragraph 22.7.4(i);
(vi) Genetically engineered drugs produced by recombinant DNA technology and
specific cell/tissue targeted drug formulations will not be under Price Control for 5
years from the date of manufacture in India."
29. Mr. Kapadia, the learned counsel further submitted on behalf of the petitioners that an analysis
of the above span of control laid down in paragraph 22.7. 2 read in the context of the policy
contained in paragraph 9 of the New Drug Policy, would result in a turnover of Rs. 400 laps which
would be used as a yardstick. It is submitted that a minimum annual turnover of Rs. 400 lacs as on
31st March, 1990 was the yardstick/bench mark adopted by the Government for including a bulk
drug under price control, and therefore, under Clause 22.7.2(i) if there was a bulk drug whose
annual turnover as on 31st March, 1990 was Rs. 400 lacs or more, then prima-facie the drug would
become eligible for inclusion, and conversely, in respect of a drug if the annual turnover was less
than Rs. 400 lacs as on 31st March, 1990 then prima-facie the drug was eligible for being excluded
from Price Control. However, it is further submitted by the petitioners, that as an exception to the
above, there may be a bulk drug whose turnover is less than Rs. 400 lacs, but such a bulk drug may
still be under Price Control if a monopoly situation exists qua the said bulk drug. A monopoly
situation would exist if for a particular bulk drug there is a turnover of Rs. 100 lacs or more by a
single formulator having 90% or more market share in the retail trade as per ORG figures.
Accordingly, it is submitted by the petitioners that even though there may be a single manufactureCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

having 100% market share, but if the turnover of the bulk drug has on 31st March, 1990 was less
than Rs. 100 lacs, a monopoly situation would not exist and such a drug would remain outside
purview of price control and would not be included in DPCO 1995. Similarly, as an exception to the
benchmark of Rs. 400 lacs above, drugs in which the turnover as on 31st March, 1990 was more
than Rs. 400 lacs they may still be kept out of the purview of price control if there was sufficient
market competition qua the said bulk drug. Sufficient market competition would exist if there are at
least 5 bulk drug producers and at least 10 formulators and none of them have more than 40%
market share in retail trade as per ORG. The clear purport behind the above is that the Government
itself acknowledges that market forces themselves are capable of controlling the prices.
30. According to Mr. Kapadia, the word "turnover" has not been defined in the New Drug Policy
1994 and it has to be given a meaning that is normally and customarily understood in the
commercial field. Keeping in mind the objective of the New Drug Policy, 1994 and keeping in mind
the common sense meaning of the phrase "turnover" it is contended that the phrase "turnover" can
only mean "sales turnover" and nothing else. According to the petitioners, the phrase turnover can
never be compared to "production", and that the phrase production is something, which is wider
than sales turnover. It is submitted that when a particular bulk drug is produced some of it may be
wasted and some of it may be destroyed, and some of it may be kept as stock-in-trade and some of it
may even be used in the company itself besides some of it being exported. Such quantities of bulk
drugs which are not sold in India and therefore, such quantities of the bulk drug though produced,
have no effect whatsoever to a consumer and can never be encompassed under the phrase
"turnover" and only such bulk drug that is sold in India can come within the purview of the phrase
"turnover". It is the contention of the petitioners that keeping in mind the objective of the New Drug
Policy and the parent legislation under which the policy is introduced namely the Essential
Commodities Act, the phrase "turnover" should and can only mean the "sales turnover" with regard
to the sales in India, and for the purpose of New Drug Policy the figures of the sales of drug made
outside India namely export sales are necessarily to be excluded in arriving at the "turnover". It is
further submitted by the petitioners that it would be better for the economy of our Country if our
producers can export and sell drugs to countries outside India at higher prices so as to earn precious
foreign exchange and for that purpose the Drug Policy is not to have price control outside India, and
in the phrase "turnover" as appearing in the New Drug Policy exports have necessarily to be
excluded.
31. Mr. Kapadia further submitted that for calculating the turnover of a bulk drug, we must
uniformly look only to the ORG data for the relevant period and not to any other data. According to
the learned Counsel only the ORG data is acceptable and authentic which is transparent and is
readily available to any person. According to them, the "turnover" of a bulk drug and the "market
share" are intrinsically inter-related and inter-dependent on one another. According to them, the
market share is obviously arrived at on the basis of the sales turnover, and therefore, it would be
absurd to contend that though the market share of the formulation is to be calculated as per ORG
data, the turnover of the bulk drug is to be calculated on the basis of data other than ORG. Such an
interpretation would be totally contrary to the avowed representation of the use of the transparent
criteria promised in the New Drug Policy, and that such a construction would be opposed to the
settled rules of construction which require that a statute or a section must be uniformly construed asCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

a whole.
32. Mr. Kapadia submits that the phrase "annual turnover" can only mean domestic sales in the
Country and the same cannot include the quantity of the bulk drug exported out of India as is sought
to be contended by the Government. It is the submission of the petitioners that the effect of
including exports in the phrase "turnover" under the span of control would lead to a situation which
is not only absurd but will also be detrimental to the economic interests of the Country.
33. Mr. Kapadia further submitted on behalf of the petitioners that so far as drug Doxycycline is
concerned, the criteria for inclusion is not satisfied. According to the petitioners as per the ORG data
as on 31st March, 1990 the annual turnover of it amounted to Rs. 316 lacs, and at the relevant time,
there were at least 19 formulators and none of these formulators had more than 40% market share
in the retail trade. According to the petitioners, as per the ORG data there was no bulk drug
producer selling Doxycycline in the country. Ranbaxy was the only manufacturer manufacturing
Doxycycline but it captively consumed the same, and all other formulators of Doxycycline relied only
on imported bulk drug Doxycycline. It is further submitted that as on date there are 34 formulators
of Doxycycline none having more than 40% market share as per retail trade, and besides, there is no
manufacturer of the bulk drug Doxycycline today and only formulations are available in the market.
It is further submitted by the petitioners that so far as the drug Glipizide is concerned, the criteria
for inclusion is not satisfied. According to the petitioners, as per the ORG data, the annual turnover
of the bulk drug Glipizide as on 31st March, 1990 was merely Rs. 82 lacs, and even if the contention
of the Government that the petitioner as the only manufacturer of the bulk drug Glipizide having a
100% market share is found to be correct (which is denied by the petitioner) still, the turnover of the
said drug is falling below Rs. 100 lacs, the monopoly situation envisaged under paragraph 22.7.2 (ii)
does not apply and hence the said drug requires to be kept out of the purview of price control.
34. Mr. Kapadia therefore submitted on behalf of the petitioners that the entire decision making
process in the inclusion and exclusion of drugs has been arbitrary, irrational and not based on the
relevant criteria and is therefore ultra vires, illegal and bad. According to the petitioners, as a result
of the representations made by diverse manufacturers, a Committee headed by Prof. M. M. Sharma
was constituted for the review of the exclusion of 19 drugs from the DPCO 1995. One of the drugs
involved was Doxycycline in respect of which the petitioners had made representations dated 10th
March, 1995 and 26th February, 1996. The petitioners have further submitted that pending the
reconsideration by the said Sharma Committee, the prices have been fixed. The Government, in
Writ Petition No. 569 of 1996 (which deals with the inclusion of a drug called Mefenamic Acid), has
filed an affidavit stating that a final decision on the representations will be taken after the
recommendations of the Sharma Committee. However, in spite of the above, the Government has
fixed the prices in respect of drugs included amongst the 19 drugs pending their reconsideration.
Pending the representation of the petitioners in respect of Doxycycline, the Government has
proposed to fix prices in respect of the Doxycycline. It is further submitted on behalf of the
petitioners that the Sharma Committee has been disbanded in May, 1996 after having held six
sittings and it is understood that the said Sharma Committee has not made any recommendations.
It is further learnt by the petitioners that without any recommendations being there from the said
Sharma Committee, the Government has removed two drugs viz. Mafenamic Acid and AmikacinCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

Sulphate from the first Schedule even though they are required being included under the first
Schedule, as per their own criteria.
35. The learned counsel Mr. Kapadia on behalf of the petitioners submitted that the conduct of the
Government is dishonest. Being apprehensive that the Government will also fix price in respect of
the bulk drug Glipizide, the petitioners had filed the said petition and on 18th October, 1996 had
actually moved for urgent ad-interim reliefs. However, the Government at that time had opposed
the application for ad-interim relief on the ground that the apprehensions of the petitioners were
unfounded as there was no decision to fix any prices and accordingly ad-interim reliefs were refused
to the petitioners. It appears that on 22nd October, 1996 the petitioners had learnt that the
Government had on 18th October, 1996 fixed the price in respect of Glipizide. This fact was however
not disclosed to the Court and on the contrary an altogether a different impression was given to the
Court, which necessitated an amendment of the petition and which was granted by this Court.
36. It is further submitted on behalf of the petitioners that from the affidavit filed by the
Government in Writ Petition No. 3031 of 1996, particularly from paragraph 7, it appears that the
New Drug Policy which was first introduced in September, 1994 and that the Government has
formed the "Standing Committee" which would be entrusted with the task of compiling data for the
purpose of ascertaining whether the turnover of a bulk drug exceeded 400 lacs by keeping the
objectives of the New Drug Policy in mind, and that the said Standing Committee has given a
recommendation that the turnover of Doxycycline was over 400 lacs. It is submitted by the
petitioners that from the limited inspection given to the petitioners of the alleged "Standing
Committee Report" it was revealed that the Government had announced constitution of a "Standing
Committee on 5th February, 1990 to consider all matters connected with the review of DPCO 1987;
that to assist the above standing committee, three Expert Groups viz. Group I (Therapeutic Issues)
Group II (Technology Issues) and Group III (Production and Turnover Issues) were set up and these
groups were to examine all issues concerning DPCO 1987; that the said Group held 15 meetings and
considered various drugs to be included/excluded in Schedule II of DPCO 1987; that keeping the
objective of the 1986 drug policy, Group III had made certain recommendations which were
contained in the report produced for inspection. It was also revealed that for the purposes aforesaid,
the said Group III had considered several drugs (307 to be precise) as stated in the table contained
in the said recommendations under the heading "Issues considered" and sub heading "List of Drugs
Considered by the Group" and that in the aforesaid list of drugs apparently considered by the said
Group III, the drug Doxycycline was not included.
37. It is therefore the submissien of Mr. Kapadia that the Government is now trying to confuse and
mislead this Court by making a reference to the alleged recommendation of the alleged Standing
Committee Report. According to the petitioners, no Standing Committee was set up by the
Government pursuant to the New Drug Policy so as to consider/recommend data keeping in mind
the objectives of the New Drug Policy, and that the report relied upon by the Government was not a
report of the Standing Committee but was a report of the Expert Group III (Production and
Turnover Issues) which was set up to assist the Standing Committee, and that the report on which
the Government had relied upon had been prepared by keeping in mind the objectives not of the
New Drug Policy, but of the 1986 Drug Policy. It is further submitted by the petitioners that whilstCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

preparing the report of the Group III, which has been relied upon by the Government, the drug
Doxycycline has not even been considered.
38. Mr. Kapadia submitted on behalf of the petitioners that the petitioners had repeatedly called
upon the Government to produce the report of the Group III that is heavily relied upon by the
Government, however, the Government has chosen to ignore the aforesaid requests for the reasons
not far to see. According to the petitioners, the fact that the Government itself is refusing to produce,
the said report in Court leads to an inference that the Government is fully aware of the discrepancies
contained therein.
39. Mr. Kapadia further submitted that on behalf of the petitioners that all the anti-diabetic drugs
are removed from the purview of the DPCO 95 with the exception of Insulin and Glipizide.
Glibenclamide which initially was included in the DPCO 1987 was subsequently excluded under the
DPCO 1987 itself and continued to remain excluded from the DPCO 1995. According to the
petitioners the only other anti-diabetic drug included in the DPCO 1995 is Insulin. A chart shown at
Exhibit G-I to the petition shows the list of anti-diabetic drugs which were originally included under
price control but have now been excluded, to the arbitrary exception of the bulk drug Glipizide.
According to the petitioners, as per the ORG data the annual turnover of Insulin as on 31st March,
1990 was Rs. 441 lakhs and consequently Insulin squarely came within the purview of price control
under para 22.7 of the New Drug Policy and the only other bulk drug in the therapeutic group of
anti-diabetic drugs included in the DPCO 1995 is Glipizide even though its annual turnover was only
Rs. 82 lacs. According to the petitioners, thus, such an inclusion of Glipizide in the first Schedule to
the DPCO 1995 to the exclusion of all other similar drugs amounts to a clear hostile and invidious
discrimination and the same is ex facie ultra vires of Article 14 of the Constitution of India. It is
further submitted on behalf of the petitioners that as far as anti-diabetic drugs having an annual
turnover less than Rs. 100 lakhs are concerned, irrespective of market share, not a single drug,
except Glipizide is included in the DPCO 1995. It is therefore, submitted on behalf of the petitioners
that the inclusion of the above two bulk drugs is erroneous and accordingly the petitioners contend
that their petitions should be made absolute with costs.
40. Mr. Cooper, the learned counsel for the petitioners submitted that as far as Writ Petition No.
1749 of 1999 is concerned which deals with the drug Salbutamol, the turnover of drug at the relevant
time was Rs. 171.17 lakhs as such the drug does not meet the criteria as per para 22.7.2(i) for being
included in the drug price control. Mr. Cooper also submitted that as far as drug Salbutamol is
concerned, there is a substantial market competition inasmuch as there are 5 bulk drug producers
and 23 formulators at the relevant time and that no company having a market share of more than
40% in the retail trade as per the figures given by ORG. In view thereof even the said drug also
meets the criteria as contemplated under para 22.7.2 (iii) and as such, the said drug gets excluded
from the price control. Mr. Cooper has contended that the relevant data given hereinabove were for
the period ending on 31st March, 1990.
41. In the same petition as far as the other drug viz. Theophylline is concerned the market
competition is with 6 bulk drug producers and 31 formulators and no company is having the market
share of 40% in the retail trade as per ORG figures and as such the drug Theophylline meets criteriaCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

as per para 22.7.2(iii) for being excluded from price control. These figures are also based on data as
on 31st March, 1990.
42. As far as Writ Petition No. 1974 of 2000 is concerned Mr. Cooper has contended that the drug
involved in the said Writ Petition is Ciprofloxacin with a turnover of Rs. 243.05 lakhs and as such
the drug does not meet the criteria under paragraph 22.7.2(i) for being included in price control.
43. As far as Writ Petition No. 2019 of 2000 is concerned the drug Norfloxacin with a market
competition of 28 bulk drug producers and 20 formulators with no company having a market share
of 40% as per the figures of ORG, therefore, the same meets criteria under paragraph 22.7.2(iii) for
being excluded from price control and these figures are also based on data as on 31-3-1990.
44. As far as Writ Petition No. 2051 of 2000 is concerned the drug concerned is Cloxacillin and with
a market competition of 16 bulk drug producers and 23 formulators and that no company is having
40% retail trade as per ORG figures as such the same meets the criteria under paragraph 22.7.2(iii)
for being excluded from price control and the data is based on 31-3-1990.
45. As far as Writ Petition No. 2060 of 2000 is concerned the name of the drug Cloxacillin with a
market competition of 16 bulk drug producers, 23 formulators with no company having a market
share of over 40% in the retail trade as per ORG figures, and as such meets the criteria as per
22.7.2(iii) for being excluded from price control and the data is dated 31-3-1990.
46. With regard to Writ Petition No. 1758 of 2000 the drug involved is Cloxacillin with a market
competition of 16 bulk drug producers and 23 formulators with no company having market share of
over 40% in the retail trade as per ORG figures. Hence it meets criteria under paragraph 22.7.2(iii)
for exclusion from drug price control and the data is as on 31-3-1990.
47. Mr. Cooper referred to a judgment of Karnataka High Court with regard to a similar issue as
involved in these petitions:in the case of Remidex Pharmaceuticals Pvt. Ltd. v. Union of India, ILR
2000 Kar 2197, wherein the Kamataka High Court has deprecated that the Government had not
kept in mind all the relevant materials in the decision making process. It is also held that the
Government has not bothered to collect, before fixing the price, all the necessary materials required
in the decision making process. Therefore, Karnataka High Court has held that the Government has
kept out of consideration the relevant materials needed to form an opinion at the material stage. In
para 19 of the said judgment the Karnataka High Court has clearly ruled that there is nothing on
record to show that such an inquiry was undertaken before working out the formula and as such the
Government had eschewed all the relevant materials in the decision making process.
48. As far as the aspect of "turnover" is concerned, Mr. Cooper has contended that the "turnover" is
not defined in the DPCO. However, the word "Sale Turnover" is defined in Section 2(w) of the DPCO
to mean product of units of formulations sold multiplied by the retail price. Therefore, Mr. Cooper
contended that the concept of "turnover" is well understood in the context of various taxing statutes
especially the sales tax, that is to say total amount of goods sold. The learned Counsel Mr. Cooper
has contended that as the word "turnover" can never be equivalent to the quantum of drugCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

"produced" and "turnover" can only mean the quantum of drug sold and not produced. Therefore,
the learned counsel contended that if something is produced but not sold it can never be taken into
the concept of "turnover" that is to say the goods are produced but same cannot be sold either there
is no market or for any other reasons then they cannot enter into the concept of "turnover".
Therefore, the goods which are produced and lying as stock in trade can never form part of the
"turnover" of that product. Similarly the learned counsel has also emphasised the word
"production". This concept which is relevant when deciding upon the quantum of manufacture. The
same can become relevant for the purposes of excise which is a tax on manufacture of goods. This
can never be in a commercial or legal sense amount to "turnover". Therefore, Mr. Cooper contended
that the general turnover can only mean sales "turnover" and not production turnover. Therefore,
Mr. Cooper referred to Clause 27.7.2 of the DPCO which refers to only "turnover" of sales and it
obviously will have to exclude export. Mr. Cooper also pointed out that the word "turnover" in
Sub-cause (i) refers to sale. Similarly in Sub-clauses (ii) and (iii) refer exclusively of retail trade and
which will have to be determined with reference to ORG figures.
49. Mr. Cooper contended that according to the Respondents that the imports must be included in
determining turnover. Therefore, if that were to be so, logically production is not the criteria for
determining the "turnover". The criteria is the amount of units of drug which find a way into the
various formulations and are sold in the market in India. Therefore, Mr. Cooper has contended that
whatever formulations which are for domestic consumption which could only be converted into
formulations sold.
50. Mr. Cooper thereafter referred to and relied on a detailed interlocutory order dated 10th
December, 1996 passed by Division Bench of this Court wherein it has been observed as under :--
"10. It is thus clear to us in the light of the objectives of the Drug Policy as set out in
Para 1 of the Introductory Chapter of New Drug Policy (reproduced in para 3 above)
that the experts will have to be excluded while arriving at the figure of minimum
annual turnover Admittedly that has not been done. The basis for calculating the
annual minimum turnover of 400 lakhs as per Clause (i) of 22.7.2 has not been the
actual sale figures as per ORG but some other hypothetical calculation based on the
cost of production and cost of imports by adding notional import duty of 10.5% as set
out in para 5 of the Executive Summary reproduced above in para 9. Prima facie,
therefore, in our view, there is failure to take into account the relevant material while
applying the first criterion for imposing the price control and further irrelevant
considerations have been taken into account for exercising the said power."
51. Mr. Cooper, thereafter, pointed out that even the modifications made in the drug policy of 1986
were also mainly for local market and not for export at all. Mr. Cooper has also pointed out that
there is no specific denial by the * Respondents in their affidavit in reply with regard to the factual
data given in each of the petitions pointed out as to how these drugs are to be excluded from the
purview of Drugs Price Control. Under these circumstances, Mr. Cooper the learned counsel has
contended that the Respondents action of bringing the aforesaid drugs within DPC is totally
arbitrary, irrational and illegal. Mr. Cooper has contended that even factually these drugs couldCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

never have been brought under price control even as per existing policy apart from the fact that the
action of Respondents' bringing the drugs within DPC is without any application of mind and as
such contended that ail the petitions should be allowed.
52. Mr. Chagla, the learned counsel appearing in Writ Petition No. 3449 of 1996 had pointed out
that the drug involved was Ciprofloxacin and the said drug could not have been covered within the
DPCO and in fact it appears that on 2nd September, 1997 the necessary exemption was also granted.
Mr. Chagla also contended that what is relevant is to bring within the DPCO is only the local
consumption or sales figure and the Respondents should not at all be concerned with the export
figures inasmuch as the DPCO applies only with regard to local consumers and the DPCO of no
relevance with regard to a foreign buyer. In fact Mr. Chagla contended that if the price of the drug
were to be more as far as foreign buyers are concerned, it would be better in the sense India would
earn more foreign exchange and thus DPCO need not be made applicable for the drugs which have
been exported. In fact such an interpretation would be deleterious to Indian economy in the sense
Indian Government would not be earning sufficient foreign exchange. Mr. Chagla referred to a
judgment of the Apex Court with regard to principles of the interpretation in State of West Bengal v.
Union of India, wherein the Supreme Court has observed as under:--
"But the rule that the State is not bound, unless it is expressly named or by necessary
implication in the statute is one of interpretation. In considering the true meaning of
words of expression used by the Legislature the Court must have regard to the aim,
object and scope of the statute to be read in its entirety. The Court must ascertain the
intention of the Legislature by directing its attention not merely to the clauses to be
construed but to the entire Statute; it must compare the clause with the other parts of
the law, and the setting in which the clause to be interpreted occurs."
53. Thereafter Mr. Chagla referred to another judgment of the Apex Court in Reserve Bank of India
v. Peerless G. F. and I. Co. Ltd., AIR 2987 SC 1023 wherein the Supreme Court has laid down the
principle of interpretation as under:--
"33. Interpretation must depend on the text and the context. They are the bases of
interpretation. One may well say if the text is the texture, context is what gives the
colour. Neither can be ignored. Both are important. That interpretation is best which
makes the textual interpretation match the contextual. A statute is best interpreted
when we know why it was enacted. With this knowledge, the statute must be read,
first as a whole and then section by section, clause by clause, phrase by phrase and
word by word. If a statute is looked at, in the context of its enactment, with the
glasses of the statute-maker, provided by such context, its scheme, the sections,
clauses, phrases and words may take colour and appear different than when the
statute is looked at without the glasses provided by the context. With those glasses we
must look at the Act as a whole and discover what each section, each clause, each
phrase and each word is meant and designed to say as to fit into the scheme of the
entire Act. No part of a statute and no word of a statute can be construed in isolation.
Statutes have to be construed so that every word has a place and everything is in itsCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

place. It is by looking at the definition as a whole in the setting of the entire Act and
by reference to what preceded the enactment and the reasons for it that the Court
construed the expression "Prize Chit" in Srinivasa and we find no reason to depart
from the Court's construction."
54. Mr. Chagla referred to another judgment of Supreme Court in , Home Secretary, U. T. of
Chandigarh and Anr. v. Darshjit Singh Growal and Ors. wherein the Supreme Court has held that
when a policy is initiated for general application then the administration is bound by it. It can of
course change the policy but until it is changed, it is bound to adhere to the policy. In a similar line
in State of Bihar v. Suprabhat Steel Ltd., the Supreme Court has held that a policy will have to be
followed unless the same is revised.
55. Mr. Chagla then referred to Punjab Communications v. Union of India, with regard to
substantive legitimate expectation in the sense, the change in a policy can defeat a substantive
legitimate expectation if it can be justified on the principle of Wednesbury reasonableness.
Therefore, Mr. Chagla has contended that the petitioners and such other manufacturers had a
substantive legitimate expectation that there could be no change in the policy unless this change in
the policy could be justified by the concept of aforesaid reasonableness and in the instant case the
Respondents have failed to show any such justification whatsoever.
56. Mr. Chagla thereafter finally referred to a judgment of the Supreme Court in Shri Sitaram v.
Union of India, wherein the Apex Court was dealing with price control of sugar, wherein, in para 25,
the Supreme Court has clearly held that the price of sugar must be determined by the Central
Government having regard to the factors mentioned in Clauses (a) to (d) of Sub-section (3-C). This
is done with reference to the industry as a whole and not with reference to any individual seller. In
contradistinction to the "price of sugar", the "amount is calculated with reference to the particular
seller. The Central Government is authorised to determine different prices for different areas or for
different factories or for different kinds of sugar. In the said judgment the Supreme Court has also
interpreted the words "having regard to". These words are not a fetter or words of limitation but for
a general guidance to make an estimate.
57. Mr. Harish Salve, the learned Solicitor General of India appearing for the Respondents sought to
contend that in the instant case the petitioners have been rightly brought within the purview of the
DPCO 1995. Mr. Salve contended the word "turnover" will have to be given a natural meaning and as
per the Webster's dictionary the word "turnover" is not restricted to the domestic sales alone. In that
context the learned Solicitor General had referred to and relied upon a judgment of the Apex Court
in George Oakes v. State of Madras, wherein the word "turnover" has been interpreted and the
Supreme Court has held that the word should not be given a restricted meaning. Mr. Salve also
referred to and relied upon another Apex Court judgment in S. A. Venkataraman v. The State, ,
wherein the Supreme Court has expressed caution to the effect that the Court should not substitute
its own words for the words of statute as contained in the clause of the said Statute. Thereafter Mr.
Salve referred to and relied upon a judgment of the Supreme Court in Nohiria Ram v. Union of
India, of the said judgment the Supreme Court 'has referred to an English decision in Commissioner
for Special Purposes of Income-tax v. Pemsel, (1891) A.C. 531 (G) wherein it is held as under:--Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

"..........that it is not competent to any Court to proceed upon the assumption that the
Legislature has made a mistake. The Court must proceed on the footing that the
Legislature intended what it has said. Even if there is some defect in the phraseology
used by the Legislature the Court cannot, as pointed out in Crawford v. Spooner, 6
MOO P.C. 1(H), aid the Legislature's defective phrasing of an Act or add and amend
or, by construction make up deficiencies which are left in the Act."
58. The learned Solicitor General thereafter, referred to a decision of the Supreme Court in British
India General Insurance Co. Ltd. v. Captain Itbar Singh and Ors., wherein the Supreme Court has
held that rules of interpretation do not permit to interpret in a manner which would be meaningless
or doubtful meaning. Similarly the learned Solicitor General referred to a judgment of the Supreme
Court in Bihar Legal Support Society v. Chief Justice of India, , wherein the Supreme Court has held
that the interpretation should be purposeful and not to invoke other words and also that the
exemption should be construed strictly. '
59. Mr. Salve thereafter brought to our notice the judgment of the Supreme Court in The Union of
India v. Commercial Tax Officer, , wherein the Supreme Court has held in para 18 as under:--
"This exemption is the creation of the statute and must be construed strictly and
cannot be extended to sales to other departments. The fact that the section was not
amended until 1949 does not at all indicate that the Bengal Legislature intended to
extend the benefit of the section to any but the departments specifically mentioned in
the section..."
60. Mr. Salve, the learned Solicitor General of India further relied upon the judgment of the Apex
Court in Union of India v. Cynatnide India Ltd., . Mr. Salve contended that the price fixation is an
administrative or a quasi judicial character and as such judicial review, over the same ought to be
extremely limited. In the said judgment the Supreme Court has held that the Court cannot delve into
a question whether there has been an arbitrary assumption on facts and figures and that the Court
cannot sit in appeal over the Government policy or over a matter of price fixation. Therefore, Mr.
Salve has contended that the Court should be extremely reluctant to interfere in matters of price
fixation.
61. Mr. Salve has also contended that DPCO of 1995 is only a guideline. He also contended that it is
not only total sales figures that would come within the purview of "turnover" but the figures of entire
production. The learned Counsel contended that even export figures will have to be included. Mr.
Salve had laid a strong emphasis on the Apex Court judgment in Shri Sitaram Sugar Co. Ltd. v.
Union of India, wherein in para 29 the Supreme Court has held that the expression "having regard
to" do not act as a fetter and that they are not words of limitation, but of general guidelines to make
an estimate. Even in para 30 the observations are that the words "having regard to" are legislative
instructions for the general guidance of the Government in determining the price of sugar. They are
not strictly mandatory, but in essence directory. It is made clear in the said judgment that
reasonableness of the order made by the Government can be decided by the Court.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

62. Mr. Salve referred and relied upon a judgment of the Supreme Court in Barium Chemicals Ltd.
v. Company Law Board, , wherein the Supreme Court has observed that even if a statutory order is
passed in good faith and with the best of intention to further the purpose of the legislation which
confers the power, since the Authority has to act in accordance with and within the limits of that
legislation, its order can also be challenged if it is beyond those limits or is passed on grounds
extraneous to the legislation or if there are no grounds at all for passing it or if the grounds are such
that no one can reasonably arrive at the opinion or satisfaction requisite under the legislation. In
any one of these situations it can well be said that the authority did not honestly form its opinion or
that in forming it, it did not apply its mind to the relevant facts.
63. The Apex Court in the said judgment of Shri Sitaram Sugar Co. Ltd. v. Union of India has held
that any act of the repository of power, whether legislative or administrative or quasi-judicial, is
open to challenge if it is in conflict with the Constitution of India or the governing Act or the general
principles of the law of the land or it is so arbitrary or unreasonable that no fair minded authority
could ever have made it. Mr. Salve has very strongly relied on the above judgment and contended
that judicial review of price fixation is not within the province Of the Courts. Judicial intervention in
respect of such matters is limited to the extent when it is found to be an irrational basis on which the
conclusions were reached by the concerned authority.
64. Mr. Salve has further contended that the ORG figures are not final and that there cannot be any
automatic exclusion. Mr. Salve then contended that if the decision making process was reasonable
then this Court ought not to interfere.
65. All the learned counsel for the petitioners have contended that the Government cannot disobey
its own policy and the emphasis that the guidelines are important so as to avoid any apprehension
and decision should be objective and not subjective. The learned Counsel also contended that these
guidelines should not be interpreted in a manner to discriminate only certain manufacturers. Under
these circumstances the learned Counsel for the petitioners pray that all the petitions should be
allowed and the impugned actions of the Respondents ought to be struck down.
66. Mr. Cooper, the learned counsel for the petitioners in Cipla Limited and Anr. v. Union of India
and Ors. (Writ Petition No. 1749 of 1999) has contended that the Respondents had in a mala fide
manner refused to issue exemption notification in an arbitrary and unjustified way to the
petitioners, which was already directed to be issued for Salbutamol and its formulations, from the
price control, in view of the new process developed by the petitioner by virtue of its indigenous
Research and Development. Mr. Cooper has contended that there is ample correspondence and
documentary proof for grant of such an exemption, as mentioned in the petition. As the said issue is
not involved in all the other petitions, for the time being Mr. Cooper has not argued the above issue
and has reserved his right to argue the same, if need arises. Certain other issues are also raised in
the said petition. Presently we are also not considering the said issues, as they pertain only to the
above petition. It is made clear that the said Writ Petition No. 1749 of 1999 be heard on merits on
the other issues which we have not decided.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

67. After hearing all the learned counsel for the parties in the above petitions, broadly the following
points arise for our consideration and decision :--
(i) Scope of judicial review with regard to the inclusion of drugs within the purview of
price control ?
(ii) Interpretation of the words "turnover" occurring in paragraph 22.7.2 Drug Policy,
1994.
(iii) Whether all relevant factors and materials were not taken into account and
irrelevant factors and materials were taken into account, while bringing the
concerned drugs within the purview of Drug Policy, 1994?
(iv) Whether the Respondents have acted wrongfully, arbitrarily and irrationally in
an unreasonable manner to include the drugs manufactured by the petitioners as
mentioned in the petitions within the purview of Drug Price Control Order, 1995 ?
68. As far as the first point is concerned, regarding the scope of judicial review with regard to
inclusion of drugs within the purview of price control, the Apex Court in Union of India v. Cynamide
India Ltd., has dealt with the same. In the case before the Supreme Court, price fixation under Drug
Price Control Order was challenged, as the price fixed was arbitrary and unreasonable. In that
context the Supreme Court has held that "price fixation is neither the function nor the forte of the
Court." However the Apex Court has also made it clear with regard to its jurisdiction in paragraph 4,
as under :--
"But we do not totally deny ourselves the jurisdiction to enquire into the question, in
appropriate proceedings, whether relevant considerations have gone in and irrelevant
considerations kept out of the determination of the price."
69. Similarly in Cynamide India Ltd. case, the Apex Court in paragraph 31 has held as under with
regard to the scope of judicial review as far as price fixation is concerned :--
"We mentioned that the price fixed by the Government may be questioned on the
ground that the considerations, stipulated by the order as relevant were not taken
into account. It may also be questioned on any ground on which a subordinate
legislation may be questioned, such as, being contrary to constitutional or other
statutory provisions. It may be questioned on the ground of a denial of the right
guaranteed by Article 14, if it is arbitrary, that is if either the guidelines prescribed for
the determination are arbitrary or if, even though the guidelines are not arbitrary, the
guidelines are worked in an arbitrary fashion."
70. In the instant case, in all the petitions, the basic challenge is that the drugs concerned do not fall
within the purview of DPCO 1995. The challenge is also that an irrelevant factor like export sales
figures are being included within the term "turnover", which is irrational and arbitrary henceCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

violative of Article 14 of the Constitution of India. In these petitions, mere is also a challenge that
though some of the dings ought to have been included within DPCO, 1995, which have been left out
but the drugs manufactured by the petitioners have been wrongfully included in an arbitrary and
irrational manner. In the light of Cynamide India Ltd. case, all the above challenges squarely fall
within the scope of judicial review. Hence we hold that as far as the first point is concerned, this
Court can judicially review the inclusion of drugs within the purview of price control.
71. Now the second point is the interpretation of the word "turnover" occurring in Drug Price
Control Order, 1995. The word "turnover" has not been separately defined the above DPCO 1995.
However "sale turnover" is defined in paragraph 2(w) of DPCO 1995 as under :--
"(w) "Sale turnover" means the product of units of formulations sold by a
manufacturer or an importer, as the case may be, in an accounting year multiplied by
retail price inclusive of sales tax, if any, paid on direct sales by the manufacturer or
importer but does not include excise duty and local taxes, if any :--"
72. The main objectives of the Drug Policy are to ensure abundant availability at reasonable prices
all essential life saving and prophylactic medicines of good quality, to strengthen the system of
quality control over drug production and promote the rational use of drugs in the country, to create
an environment conducive to channelising new investment into the pharmaceutical industry, to
encourage cost effective production with economic sizes and to introduce new technologies and new
drugs and to strengthen the indigenous capability for production of drugs. In Drugs Policy, 1994, the
special emphasis was on turnover as an index of the extent of usage of a drug and on ensuring the
equitable distribution and abundant availability of drugs of good quality as well as to introduce new
technologies and new drugs in India.
73. The main contention of all the petitioners in these petitions is that "Annual turnover" occurring
in paragraph 22.7.2(i) of DPCO, 1995, is a reference to domestic sales turnover of the bulk drug that
is to say the aggregate quantity of bulk drugs sold in the domestic market (whether produced in
India or imported from abroad) and include the quantity of the bulk drugs exported. It was also
strongly emphasised that DPCO's have been issued under Section 3 of Essential Commodities Act,
1955, which can regulate prices of essential commodities within the territorial limits of India and not
outside the territorial limits of India. The main objective is to provide cheap drugs to; our Indian
Populance and not to restrict the foreign exchange earnings of Indian drug companies, whereby our
country benefits. Even in paragraph 3(v) of the affidavit in reply of the Respondent it is emphasised
that the "turnover" as used in paragraph 9 of Drug Policy, 1994, 'would be to determine the extent
and usage of a bulk drug in the country. Therefore export figures will have to be excluded. There is
no dispute that the ORG figures pertain only to sales figures within the territory of India. If one were
to have a look at paragraph 22.7.2. of Drug Policy, 1994, both in Sub-clauses (ii) and (iii) there is a
mention of retail trade as per ORG, while dealing with annual turnover. Whereas in Sub-clause (i) of
paragraph 22.7.2, one cannot add the export sales figures. This would lead to an absurd situation.
The word "turnover" will have to be given the same meaning in all Sub-clauses (i), (ii) and (iii) of the
said paragraph 22.7.2. If one, were to include export sales figures only in Clause (i) and not in
Clauses (ii) and (iii), the same would lead to an incongruous and absurd result. The entire purposeCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

of paragraph 22.7.2 is to prevent a monoply situation and to allow a healthy market competition to
stabilize the price at a reasonable level. The word "turnover" has to be interpreted in a contextual
and purposive manner.
74. The Apex Court has laid down in Reserve Bank of India v. Peerless G. F. and I. Co. Ltd., AIR 1987
SC 1023, the principle of contextual interpretation in the following words in paragraph 33,
"Interpretation must depend on the text and the context. They are the bases of interpretation. One
may well say if the text is the texture, context is what gives the colour. Neither can be ignored. Both
are important. That interpretation is best which makes the textual interpretation match the
contextual. A statute is best interpreted when we know why it was enacted. With this knowledge, the
statute must be read, first as a whole and then section by section, clause by clause, phrase by phrase
and word by word. If a statute is looked at, in the context of its enactment, with the glasses of the
statute-maker, provided by such context, its scheme, the sections, clauses, phrases and words may
take colour and appear different than when the statute is looked at without the glasses provided by
the context. With those glasses we must look at the Act as a whole and discover what each section,
each clause, each phrase and each word is meant and designed to say as to fit into the scheme of the
entire Act. No part of a statute and no word of a statute can be construed in isolation. Statutes have
to be construed so that every word has a place and everything is in its place. It is by looking at the
definition as a whole in the setting of the entire Act and by reference to what preceded the
enactment and the reasons for it that the Court construed the expression "Prize Chit" in Srinivasa
and we find no reason to depart from the Court's construction."
75. We agree with Mr. Salve that no restrictive meaning should be given to the word "turnover".
However, one cannot forget in what context the word "turnover" is used in paragraph 22.7.2, and
also the purpose of the said paragraph. In that context and purpose, we have no doubt in our mind
that export sales figures cannot be included within the word "turnover" in paragraph 22.7.2, as the
same is alien in the context and purpose of the said paragraph.
76. The Respondents have contended that as far as the interpretation of "turnover" is concerned, it
should include the export sales figures i.e. the value of the entire product produced should be taken
into account for the purpose of ascertaining the turnover as per the paragraph 22.7.2 of Drug Policy,
1994. On the contrary, the learned Counsel for the petitioners have submitted that the expression
"turnover" can only mean the domestic sales turnover and nothing else and the same can never be
compared to "production" and the word "production" is much wider than the sales turnover,
inasmuch as when a particular bulk drug is produced, some of it may be wasted, some of it may be
destroyed, some of it may be kept in as stock-in-trade and some of it may be used by the Company
itself, apart from some quantity being exported. Therefore, for the price control, only the drugs
which are sold within the domestic market would be relevant, and not the quantity of drugs
produced and not sold within the domestic market. The expression "turnover" of the bulk drug and
"market share" are intrinsically inter-related and inter-dependent on one another. Therefore, the
market share can only be arrived on the basis of sales turnover and that is why there is a reference of
ORG data. Therefore the expression "turnover" under paragraph 22.7.2 can only mean the domestic
sales and nothing else. Apparently, the export sales figures are totally irrelevant inasmuch as they do
not form part of any market share. The market share as contemplated under Drug Policy, 1994 isCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

only the share of "sales turnover" in the domestic market and the same has nothing to do with the
export or production, which figures are totally irrelevant.
77. If "export sales figures" have to be also taken into account with regard to "turnover", then even
the drugs which are exported from India will come within the price control, as a result even drugs
exported will have to be sold at a cheaper rate to foreigners and India will earn much lesser foreign
exchange. On the contrary in a contextual and purposive manner if the word "turnover" is
interpreted, the same cannot include export safes figures.
78. Therefore, we answer the second point to hold that the word "turnover" occurring in paragraph
22.7.2 of Drug Policy, 1994, cannot include any of export sales figures.
79. As far as the third point is concerned, as to whether all relevant materials were not taken into
account or that irrelevant materials were taken into account while bringing the concerned drugs
within the purview of Drug Policy, 1994, there is no dispute that export sales figures were included,
while deciding to bring the concerned drugs within the purview of price control. We have already
held that "export sales figures" are irrelevant for the purpose of computing "turnover" in paragraph
22.7.2 of Drug Policy, 1994 there is no doubt that the aforesaid irrelevant materials were taken into
account while bringing the concerned drugs within the purview of price control. By doing so the
Respondents have acted contrary to their own guidelines as per Drug Policy, 1994.
80. As indicated hereinabove, that the Respondents have wrongly taken into account the value of
entire production of bulk drug or formulations, as pointed out hereinabove, some part of it may be
wasted, some part of it may be damaged, some part of it may be used by the Company itself, and
apart from the above, some part may be exported, as far as for the purpose of determining whether,
the drug ought to be brought within the Drug Policy, 1994, what is relevant is only the domestic
sales turnover and not the other figures. Apparently, in the instant case, the Respondents have taken
into account all the irrelevant material viz. the sales figures of production without comprehending
that the same have no relevance for the purpose of Drug Policy, 1994. Apparently all the aforesaid
irrelevant material have been taken into account for the concerned drugs, and the same have been
wrongly brought within the purview of Drug Policy, 1994. Under these circumstances, we answer the
third point to the effect that all irrelevant factors and material have been taken into account while
bringing the concerned drugs within the purview of the Drug Policy, 1994.
81. As far as fourth Point is concerned, whether the Respondents have acted wrongfully, arbitrarily
and irrationally to include the drugs manufactured by the petitioners as mentioned in the petitions
within the purview of the Drug Policy, 1994, we have to consider the same with regard to the facts of
each petition.
82. As far as Writ Petition No. 1749 of 1999 is concerned, the drugs involved in the same are
Salbutamol and Theophyline. It appears from the pleadings that as far as the drug Salbutamol is
concerned, at the relevant time the annual sales turnover was Rs. 171.17 lakhs, and as such, the same
does not meet the criteria as per paragraph 22.7.2(i) for being included in the drug price control.
Another aspect to be noted herein is that as far as drug Salbutamol is concerned, there is also aCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

substantial market competition, inasmuch as there are 5 bulk drug producers and 23 formulators at
the relevant time and that none had a market share of more than 40% in the retail trade as per the
figures given by the ORG. In view thereof, the said drug Satbutamol meets the criteria as
contemplated in paragraph 22.7.2(iii) and as such, the said drug ought to get excluded from the drug
price control. The above sales figures were for the period ending on 31st March, 1990. It is pertinent
to note that though the Respondents have filed an affidavit in reply in this petition, as far as the
factual details and submissions are concerned, the Respondents have not controverted them at all.
In fact, the petitioners have given the names of all the bulk drug manufacturers as well as the
formulators and their respective market shares and even there domestic sales figures. Excepting a
bald denial, the Respondents have not given any details or particulars controverting the above.
Hence, we have to hold that as far as drug Salbutamol is concerned, it could not have been brought
within the purview of price control as per paragraph 22.7.2(i) of Drug Policy 1994 as at the relevant
time, the domestic sales figure was only Rs. 171.17 lakhs. In any event, the said drug Salbutamol had
to be excluded from the price control, in view of the fact that there are 5 bulk drug producers and 23
formulators and at the relevant time no one was having more than 40% share in the retail trade as
per the figures given by the ORG. In the same petition, the other drug involved is Theophyline. The
petitioners have alleged that with regard to the drug Theophyline, there is a market competition of 6
bulk drug producers and 31 formulators and no one is having market share of more than 40% in the
retail trade as per the ORG figures and as such the said drug Theophyline ought to be excluded from
the drug price control as per paragraph 22.7.2(iii), The details furnished in the petition with regard
to this drug were based on the data as on 31st March, 1999 which was the relevant date. With regard
to this drug also the Respondents have not been able to controvert factually, excepting a bald denial.
Under these circumstances, we have to hold that the said drug Theophyline could not have been
brought within the purview of price control and therefore same ought to be excluded as per the
provisions of paragraph 22.7.2(iii) of Drug Policy, 1994.
83. As far as Writ Petition No. 1974 of 2000 is concerned, the learned counsel for the petitioner has
submitted that the drug involved in this petition is Ciprofloxacin with a turnover of Rs. 243.05 lakhs
and as such, the said drug does not meet the necessary criteria as per para 22.7.2 (i) for being
included in the price control. In March, 1990, there were 7 bulk drug producers and 22 formulators
of Ciprofloxacin and today there are 47 bulk drug producers and 117 formulators of the said drug.
Hence the said drug has to be excluded as per paragraph 22.7.2(iii) of Drug Policy, 1994. So far as
this Writ Petition is concerned an affidavit in reply of the Respondents has been filed but there are
only bald denials, and no specific particulars and details are given to controvert the contentions of
the petitioners. As per the figures indicated hereinabove, apparently, the said drug could not have
been brought within the purview of the price control. Therefore, we hold that the said drug could not
have been brought within the purview of price control, and has to be excluded from price control.
84. In Writ Petition No. 2019 of 2000 the drug involved is Norfloxacin with a market competition of
28 bulk drug producers and 20 formulators with no one having a market share of more than 40% in
the retail trade as per the ORG figures and therefore the said drug meets the criteria for being
excluded from price control under para 22.7.2{iii), and these sales figures are also based as on 31st
March, 1990. So far as this Writ Petition is concerned on affidavit in reply has been filed by the
Respondents but there are only bald denials, and no specific particulars and details are given toCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

controvert the contentions of the petitioners. Hence we hold that the aforesaid bulk drug
Norfloxacin could not be brought within the purview of Price Control.
85. In Writ Petition No. 2051 of 2000 the drug involved is Cloxacillin with a market competition of
16 bulk drug producers and 23 formulators and that no one is having more than 40% share in the
retail trade as per the ORG figures as per the data based as on 31st March, 1990 and as such, the
same meets the criteria of para 22.7.2(iii) for being excluded from the price control. There is no
affidavit in reply controverting the aforesaid factual details and hence, we hold that the said drug
Cloxacillin could not be brought within the purview of the price control.
86. In Writ Petition No. 2060 of 2000 the drug involved is Cloxacillin with a market competition of
16 bulk drug producers and 23 formulators with no one is having a market share of more than 40%
in the retail trade as per the ORG figures and as per the data based as on 31st March, 1990 and as
such, the said drug meets the criteria as per paragraph 22.7.2 (iii) for being excluded from the price
control. There is no affidavit in reply controverting the factual details and hence, we hold that the
said drug Cloxacilling could not be brought within the purview of the price control.
87. As far as the Writ Petition No. 1758 of 2000 is concerned, the drug involved is Cloxacillin with a
market competition of 16 bulk drug producers and 23 formulators with no one having a market
share of more than 40% in the retail trade as per the ORG figures and as per the data based as on
31st March, 1990, and as such, the said drug meets the criteria as per paragraph 22.7.2 (iii) for being
excluded for the price control. In this Writ Petition an affidavit in reply has been filed by the
Respondents but there are only bald denials, and no specific particulars and details are given to
controvert the contentions of the petitioners, and hence, we hold that the said Drug Cloxacillin could
not be brought within the purview of the price control.
88. As far as Writ Petition No. 3449 of 1996 is concerned, Mr. Chagla, the learned Counsel for the
petitioners has contended that the drug involved in the said petition viz. the Ciprofloxacin was never
under the price control prior to DPCO 1995. Admittedly, there are 16 bulk drug producers and 23
formulators with no one having more than 40% market share in the retail trade as per the ORG
figures, and as such, the said drug meets the criteria as per paragraph 22.7.2(iii) for being excluded
from the price control and the data is based as on 31st March, 1990. We therefore, hold that the said
drug Ciprofloxacin could not have been brought within the purview of price control. Apart from the
above, Mr. Chagla has also contended that the Respondents have acted in an arbitrary and irrational
manner and he has further pointed out that the two bulk drugs viz. Mefenamic Acid and Amikacin
Sulphate were wrongly deleted from the DPCO 1995 whereas the said drug Ciprofloxacin was
erroneously included in the DPCO 1995. He has pointed out that the sales turnover of Mefenamic
Acid between the 1988-1992 was over Rs. 400 lakhs per year. Similarly, the import value of
Amikacin Sulphate in the year 1989-1990 was Rs. 350 lakhs which rose to Rs. 475 lakhs in the year
1990-1991 and touched a level of Rs. 845 lakhs in the year 1992-1993. Mr. Chagla therefore pointed
out that there are two formulators of these drugs in the market and a single formulator has a market
share in excess of 40% of retail trade as per ORG figures. Apparently, the Respondents had
originally included these two drugs in the DPCO 1995, whereas erroneously, arbitrarily and in an
irrational manner excluded these two drugs from the DPCO, 1995. Mr. Chagla has contended thatCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

the Respondents have adopted a "pick and choose" method, which clearly discloses the hostile
discrimination, subjectivity and a lack of transparency. Therefore, the learned counsel Mr. Chagla
has contended that the Respondents action of including the bulk drug Ciprofloxacin within the
DPCO 1995 would be violative of Article 14 of the Constitution of India. In this Writ Petition
Respondents have filed an affidavit in reply but there are only bald denials, and no specific
particulars and details are given to controvert the contentions of the petitioners. Hence we find
substance in the contention of Mr. Chagla that the Respondents have acted arbitrarily and in an
irrational manner in bringing the aforesaid drug Ciprofloxacin within the price control. Whereas,
the Respondents have wrongly excluded the aforesaid Mefenamic Acid and Amikacin Sulphate from
the price control.
89. In Writ Petition No. 3031 of 1996 the bulk drug involved is Doxycycline and in Writ Petition No.
5219 of 1996 the bulk drug involved is Glipizide. As far as drug Doxycycline is concerned, the
learned counsel for the petitioner has pointed out that as per ORG data as on 31st March, 1990 the
annual turnover of the said drug was only Rs. 316 lakhs and also at the relevant time there were at
least 19 formulators and none of the formulators had more than 40% market share in the retail
trade as per ORG figures. The learned counsel has pointed out that as per the ORG data there was
no bulk drug producer with regard to the drug Doxycycline in the Country. The only company was
Ranbaxy which was the manufacturer of the drug Doxycycline but it captively consumed the same,
and all the other formulators of Doxycycline had to depend on the imported bulk drug Doxycycline.
Mr. Kapadia, the learned counsel has pointed out that as far as the drug Doxycycline is concerned,
there were at least 34 formulators and none of them were having more than 40% market share in
the retail trade. So far as these two Writ Petitions are concerned, the Respondents have filed an
affidavit in reply but there are only bald denials, and no specific particulars and details are given to
controvert the contentions of the petitioners. Hence, we hold that the drug Doxycyline could not
have been brought within the purview of price control.
90. As far as the other drug Glipizine is concerned, at the relevant time as on 31st March, 1990, the
annual turnover of the said drug was Rs. 82 lakhs and even assuming that the petitioners were to be
the sole manufacturers of the said drug as the turnover was below Rs. 100 lakhs, the monopoly
situation as envisaged in para 22.7.2(ii) of Drug Policy, 1994 does not apply and as such, the said
drug Glipizide ought to be kept out of the purview of DPCO 1995. Mr. Kapadia, the learned counsel
has also pointed out that when the above petition No. 5219 of 1996 was filed in this Court, an
application for urgent relief was made on 18th October, 1996 as the petitioners had apprehended
that the Government might be fixing the price for the said drug Glipizide. The learned counsel
appearing on behalf of the Respondents had assured the Court that the apprehensions of the
petitioners were unfounded as there was no decision taken to fix the price. Accordingly, the
ad-interim relief was refused. However, the learned counsel for the petitioner has pointed out that
on 22nd October, 1996, the petitioners came to know that on 18th October, 1996 itself the
Government had fixed the price in respect of the drug Glipizide which fact was not disclosed to the
Court at the time when the ad-interim application was made.
91. As far as the drug Glipizide is concerned, the learned counsel Mr. Kapadia has pointed out that
the another drug known as Glibenclamide which was initially included in the DPCO 1987 wasCipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

subsequently excluded under DPCO 1987 and continued to remain excluded from DPCO 1995. The
learned counsel Mr. Kapadia has pointed out that the another anti-diabetic drug included in DPCO
1995 was Insulin whereas subsequently the same was excluded from the drug price control. The
learned counsel Mr. Kapadia has pointed out that as per the ORG data the annual turnover of the
Insulin was Rs. 441 lakhs as on 31st March, 1990 and as such, it was rightly included in DPCO 1995,
whereas the same was wrongly excluded from the price control. On the contrary, the learned
Counsel for the petitioner states that the Respondents have in an arbitrary and mala fide manner
have included the drug Glipizide which had only an annual turnover of Rs. 82 lakhs. Therefore the
contention of the learned counsel for the petitioner is that though all the aforesaid drugs are
anti-diabetic drugs, the some of which ought to have been included but have been excluded and,
whereas, some of which ought to have been excluded but have been included, therefore, there is a
hostile discrimination violative of Article 14 of the Constitution of India. Under these circumstances,
we hold that both the drugs; Doxycycline as well as Glipizide could not have been brought within the
purview of price control.
92. We therefore hold that the concerned drugs mentioned in respective petitions, do not fall within
the purview of DPCO 1995 and as a consequence, no fixation of price could be adopted with regard
to the said drugs mentioned in the aforesaid Writ Petitions. As a consequence all impugned notices
demanding "over charged amount" from the petitioners are also quashed and set-aside. Rule is
accordingly made absolute with costs in all the above petitions including Writ Petition No. 1749 of
1999 as far as the issue regarding inclusion of the drugs concerned therein within the purview of
DPCO 1995 and on other issues the petition is kept open to be decided on merits. In view of the
quahsing of notices demanding "over charged amount" nothing further survives in Contempt
Petition No. 96 of 2000.
93. Personal Assistant to issue an ordinary copy of the order to the parties. Parties to act on an
ordinary copy of this order duly authenticated by the Associate of this Court.
94. Issuance of certified copy is expedited.Cipla Limited, Mumbai And Anr. vs Union Of India (Uoi) And Ors. on 31 August, 2001

