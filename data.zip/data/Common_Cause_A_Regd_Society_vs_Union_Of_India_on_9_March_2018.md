Common Cause (A Regd. Society) vs Union Of India on 9 March,
2018
Equivalent citations: AIR 2018 SUPREME COURT 1665, AIR 2018 SC (CIV)
1683, (2018) 3 MAD LJ 503, (2018) 4 SCALE 1, (2018) 1 CRIMES 184, (2018) 1
CURCC 448, 2018 (5) SCC 1, 2018 (2) KLT SN 47 (SC), 2018 (1) KCCR SN 65
(SC)
Author: Chief Justice
Bench: Chief Justice, A.K. Sikri, A.M. Khanwilkar, D.Y. Chandrachud, Ashok
Bhushan
                                                      1
                                                                       REPORTABLE
                                       IN THE SUPREME COURT OF INDIA
                                         CIVIL ORIGINAL JURISDICTION
                                    WRIT PETITION (CIVIL) NO. 215 OF 2005
                         Common Cause (A Regd. Society)             ...Petitioner(s)
                                                  Versus
                         Union of India and Another                 …Respondent(s)
                                             J U D G M E N T
Dipak Misra, CJI [for himself and A.M. Khanwilkar, J.] INDEX S. No. Heading Page No.
applications for intervention D.1 P. Rathinam’s case – The question of 19 the Indian Penal Code D.2
Gian Kaur’s case – The question of 22 14:11:27 IST Reason:
unconstitutionality of Section 306 of the Indian Penal Code D.3 The approach in
Aruna Shanbaug qua 30 Passive Euthanasia vis-à-vis India legislation G. The
Distinction between Active and Passive 52 Euthanasia H.2 The Legal position in the
United 89 States H.6 International considerations and 107 decisions of the European
Court of Human Rights (ECHR) I The 241st Report of The Law Commission of 114
India on Passive Euthanasia K. Passive Euthanasia in the context of Article 126 21 of
the Constitution.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

K.1 Individual Dignity as a facet of Article 135 L Right of self-determination and individual 149
autonomy M. Social morality, medical ethicality and State 155 interest O. Submissions of the
Intervenor (Society for 159 the Right to Die with Diginity) P. Advance Directive/Advance Care
Directive/ 160 Advance Medical Directive and how preserved effect to
(e) What if permission is refused by the 179 Medical Board
(f) Revocation or inapplicability of 181 Advance Directive Q. Conclusions in seriatim A. Prologue:
Life and death as concepts have invited many a thinker, philosopher, writer and
physician to define or describe them.
Sometimes attempts have been made or efforts have been undertaken to gloriously
paint the pictures of both in many a colour and shade. Swami Vivekananda expects
one to understand that life is the lamp that is constantly burning out and further
suggests that if one wants to have life, one has to die every moment for it. John
Dryden, an illustrious English author, considers life a cheat and says that men favour
the deceit. No one considers that the goal of life is the grave. Léon Montenaeken
would like to describe life as short, a little hoping, a little dreaming and then good
night. The famous poet Dylan Thomas would state ―do not go gentle into that good
night. One may like to compare life with constant restless moment spent in fear of
extinction of a valued vapour;
and another may sincerely believe that it is beyond any conceivable metaphor. A
metaphysical poet like John Donne, in his inimitable manner, says:-
―One short sleep past, we wake eternally, And death shall be no more; death, thou
shalt die.
Some would say with profound wisdom that life is to be lived only for pleasure and
others with equal wise pragmatism would proclaim that life is meant for the
realization of divinity within one because that is where one feels the ―self, the
individuality and one‘s own real identity. Dharmaraj Yudhisthira may express that
though man sees that death takes place every moment, yet he feels that the silence of
death would not disturb him and nothing could be more surprising than the said
thought. Yet others feel that one should never be concerned about the uncertain
death and live life embracing hedonism till death comes. Charvaka, an ancient
philosopher, frowns at the conception of re-birth and commends for living life to the
fullest. Thus, death is complicated and life is a phenomenon which possibly intends
to keep away from negatives that try to attack the virtue and vigour of life from any
arena. In spite of all the statements, references and utterances, be it mystical,
philosophical or psychological, the fact remains, at least on the basis of conceptual
majority, that people love to live – whether at eighty or eighteen – and do not, in
actuality, intend to treat life like an ―autumn leaf. As Alfred Tennyson says:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

―No life that breathes with human breath has ever truly longed for death.
2. The perception is not always the same at every stage. There comes a phase in life when the spring
of life is frozen, the rain of circulation becomes dry, the movement of body becomes motionless, the
rainbow of life becomes colourless and the word ‗life‘ which one calls a dance in space and time
becomes still and blurred and the inevitable death comes near to hold it as an octopus gripping
firmly with its tentacles so that the person ―shall rise up never. The ancient Greet philosopher,
Epicurus, has said, although in a different context:-
―Why should I fear death?
If I am, then death is not.
If death is, then I am not.
Why should I fear that which can only exist when I do not? But there is a fallacy in
the said proposition. It is because mere existence does not amount to presence. And
sometimes there is a feebleness of feeling of presence in semi-reality state when the
idea of conceptual identity is lost, quality of life is sunk and the sanctity of life is
destroyed and such destruction is denial of real living. Ernest Hemingway, in his
book ‗The Old Man and the Sea‘, expounds the idea that man can be destroyed, but
cannot be defeated. In a certain context, it can be said, life sans dignity is an
unacceptable defeat and life that meets death with dignity is a value to be aspired for
and a moment for celebration.
3. The question that emerges is whether a person should be allowed to remain in such a stage of
incurable passivity suffering from pain and anguish in the name of Hippocratic oath or, for that
matter, regarding the suffering as only a state of mind and a relative perception or treating the
utterance of death as a ―word infinitely terrible to be a rhetoric without any meaning. In
contradistinction to the same, the question that arises is should he not be allowed to cross the doors
of life and enter, painlessly and with dignity, into the dark tunnel of death whereafter it is said that
there is resplendence. In delineation of such an issue, there emerges the question in law – should he
or she be given such treatment which has come into existence with the passage of time and progress
of medical technology so that he/she exists possibly not realizing what happens around him/her or
should his/her individual dignity be sustained with concern by smoothening the process of dying.
4. The legal question does not singularly remain in the set framework of law or, for that matter,
morality or dilemma of the doctors but also encapsulates social values and the family mindset to
make a resolute decision which ultimately is a cause of concern for all. There is also another
perspective to it. A family may not desire to go ahead with the process of treatment but is compelled
to do so under social pressure especially in a different milieu, and in the case of an individual, there
remains a fear of being branded that he/she, in spite of being able to provide the necessary
treatment to the patient, has chosen not to do so. The social psyche constantly makes him/her feel
guilty. The collective puts him at the crossroads between socially carved out ‗meaningful guilt‘ andCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

his constant sense of rationality and individual responsibility. There has to be a legalistic approach
which is essential to clear the maze and instill awareness that gradually melts the idea of
―meaningful guilt and ushers in an act of ―affirmative human purpose that puts humanness on a
high pedestal.
5. There is yet another aspect. In an action of this nature, there can be abuse by the beneficiaries
who desire that the patient‘s heart should stop so that his property is inherited in promptitude and
in such a situation, the treating physicians are also scared of collusion that may invite the wrath of
criminal law as well as social stigma. The medical, social and ethical apprehensions further cloud
their mind to take a decision. The apprehension, the cultural stigma, the social reprehension, the
allegation of conspiracy, the ethical dilemma and eventually the shadow between the individual
desire and the collective expression distances the reality and it is here that the law has to have an
entry to alleviate the agony of the individual and dispel the collective attributes and perceptions so
that the imbroglio is clear. Therefore, the heart of the matter is whether the law permits for
accelerating the process of dying sans suffering when life is on the path of inevitable decay and if so,
at what stage and to what extent. The said issue warrants delineation from various perspectives. B.
Contentions in the Writ Petition:
6. The instant Writ Petition preferred under Article 32 of the Constitution of India by the petitioner,
a registered society, seeks to declare ―right to die with dignity as a fundamental right within the
fold of ―right to live with dignity guaranteed under Article 21 of the Constitution; to issue
directions to the respondents to adopt suitable procedure in consultation with the State
Governments, where necessary; to ensure that persons of deteriorated health or terminally ill
patients should be able to execute a document titled ―My Living Will and Attorney Authorisation
which can be presented to the hospital for appropriate action in the event of the executant being
admitted to the hospital with serious illness which may threaten termination of the life of the
executant; to appoint a committee of experts including doctors, social scientists and lawyers to study
into the aspect of issuing guidelines as to the ―Living Wills; and to issue such further appropriate
directions and guidelines as may be necessary.
7. It is asserted that every individual is entitled to take his/her decision about the continuance or
discontinuance of life when the process of death has already commenced and he/she has reached an
irreversible permanent progressive state where death is not far away. It is contended that each
individual has an inherent right to die with dignity which is an inextricable facet of Article 21 of the
Constitution. That apart, it is set forth that right to die sans pain and suffering is fundamental to
one‘s bodily autonomy and such integrity does not remotely accept any effort that puts the
individual on life support without any ray of hope and on the contrary, the whole regime of
treatment continues in spite of all being aware that it is a Sisyphean endeavour, an effort to light a
bulb without the filament or to expect a situation to be in an apple pie order when it is actually in a
state of chaos.
8. It is put forth that the concept of sustenance of individual autonomy inheres in the right of
privacy and also comes within the fundamental conception of liberty. To sustain the stand of
privacy, reliance has been placed on the decisions in Kharak Singh v. State of U.P. and others 1 ,Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Gobind v. State of Madhya Pradesh and another 2 and People’s Union for Civil Liberties v. Union of
India and another3. Inspiration has also been drawn from the decision of the United States in
Cruzan v. Director, Missouri Department of Health 4 . It is averred that due to the advancement of
modern medical technology pertaining to medical science and respiration, a situation has been
created where the dying process of the patient is unnecessarily prolonged causing distress and agony
to the patient as well as to the near and dear ones and, consequently, the patient is in a persistent
vegetative state thereby allowing free intrusion. It is also contended that the petitioner-society is not
claiming that the right to die is a part of the right to life but asserting the claim that the right to die
with dignity is an inseparable (1964) 1 SCR 332 : AIR 1963 SC 1295 (1975) 2 SCC 148 (1997) 1 SCC
301 111 L Ed 2d 224 : 497 US 261 (1990) : 110 S.Ct. 2841 (1990) and inextricable facet of the right to
live with dignity. The execution of a living will or issuance of advance directive has become a
necessity in today‘s time keeping in view the prolongation of treatment in spite of irreversible
prognosis and owing to penal laws in the field that creates a dilemma in the minds of doctors to take
aid of the modern techniques in a case or not. A comparison has been made between the
fundamental rights of an individual and the State interest focusing on sanctity as well as quality of
life. References have been made to the laws in various countries, namely, United Kingdom, United
States of America, Australia, Denmark, Singapore, Canada, etc. The autonomy of the patient has
been laid stress upon to highlight the right to die with dignity without pain and suffering which may
otherwise be prolonged because of artificial continuance of life through methods that are really not
of any assistance for cure or improvement of living conditions.
C. Stand in the counter affidavit and the applications for intervention:
9. A counter affidavit has been filed by the Union of India contending, inter alia, that
serious thought has been given to regulate the provisions of euthanasia. A private
member‘s Bill and the 241st report of the Law Commission of India have been
referred to. It has been set forth that the Law Commission had submitted a report on
The Medical Treatment of Terminally-ill Patients (Protection of Patients and Medical
Practitioners) Bill, 2006 but the Ministry of Health and Family Welfare was not in
favour of the enactment due to the following reasons:-
―a) Hippocratic oath is against intentional/voluntary killings of patient.
b) Progression of medical science to relieve pain, suffering, rehabilitation and
treatment of so-called diseases will suffer a set back.
c) An individual may wish to die at certain point of time, his/her wish may not be
persistent and only a fleeting desire out of transient depression.
d) Suffering is a state of mind and a perception, which varies from individual to
individual and depends on various environmental and social factors.
e) Continuous advancement in medical science has made possible good pain
management in patients of cancer and other terminal illness. Similarly, rehabilitationCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

helps many spinal injury patients in leading near normal life and euthanasia may not
be required.
f) Wish of euthanasia by a mentally ill patient/in depression may be treatable by good
psychiatric care.
g) It will be difficult to quantify suffering, which may always be subject to changing
social pressures and norms.
h) Can doctors claim to have knowledge and experience to say that the disease is
incurable and patient is permanently invalid?
i) Defining of bed-ridden and requiring regular assistance is again not always
medically possible.
j) There might be psychological pressure and trauma to the medical officers who
would be required to conduct euthanasia.
10. The counter affidavit further states that after the judgment was delivered by this
Court in Aruna Ramachandra Shanbaug v. Union of India and others 5 , the Ministry
of Law and Justice opined that the directions given by this Court have to be followed
in such cases and the said directions should be treated as law. The Law Commission
in its 241st Report titled ―Passive Euthanasia – A Relook again proposed for
making a legislation on ―Passive Euthanasia and also prepared a draft Bill titled The
Medical Treatment of (2011) 4 SCC 454 Terminally Ill Patients (Protection of Patients
and Medical Practitioners) Bill. The said Bill was referred to the technical wing of the
Ministry of Health and Family Welfare (Directorate General of Health Services-Dte.
GHS) for examination in June 2014. It is the case of the Union of India that two
meetings were held under the chairmanship of Special Director General of Health
Service which was attended by various experts. A further meeting was held under the
chairmanship of Secretary, Ministry of Health and Family Welfare, on 22.05.2015 to
examine the Bill. Thereafter, various meetings have been held by experts and the
expert committee had proposed formulation of legislation on passive euthanasia.
11. Counter affidavits have been filed by various States. We need not refer to the same in detail.
Suffice it to mention that in certain affidavits, emphasis has been laid on Articles 37, 39 and 47
which require the States to take appropriate steps as envisaged in the said Articles for apposite
governance. That apart, it has been pronouncedly stated that the right to life does not include the
right to die and, in any case, the right to live with dignity guaranteed under Article 21 of the
Constitution means availability of food, shelter and health and does not include the right to die with
dignity. It is asseverated that saving the life is the primary duty of the State and, therefore, there is
necessity for health care. It is also contended that the introduction of the right to die with dignity as
a facet of the right under Article 21 will create a right that the said constitutional provision does not
envisage and further it may have the potential effect to destroy the said basic right.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

12. An application for intervention has been filed by the ―Society for the Right to Die with Dignity
whose prayer for intervention has been allowed. The affidavit filed by the said society supports the
concept of euthanasia because it is a relief from irrecoverable suffering of which pain is a factor. It
has cited many an example from various texts to support passive euthanasia and suggested certain
criteria to be followed. It has also supported the idea of introduction of living will and durable power
of attorney documents and has filed a sample of living will or advance health directive or advance
declaration provided by Luis Kutner. Emphasis has been laid on peaceful exit from life and the
freedom of choice not to live and particularly so under distressing conditions and ill-health which
lead to an irrecoverable state. The management of terminally ill patients has been put at the centre
stage. It has been highlighted that determination of the seemly criteria will keep the element of
misuse by the family members or the treating physician or, for that matter, any interested person at
bay and also remove the confusion.
We have heard Mr. Prashant Bhushan, learned counsel for the petitioner. Mr. P.S. Narasimha,
learned Additional Solicitor General for Union of India, Mr. Arvind P. Datar learned senior counsel
and Mr. Devansh A. Mohta, learned counsel who have supported the cause put forth in the writ
petition.
D. Background of the Writ Petition:
13. Before we engage ourselves with the right claimed, it is requisite to state that the present
litigation has a history and while narrating the same, the assertions made in the Writ Petition and
the contentions which have been raised during the course of hearing, to which we shall refer in due
course, are to be kept in mind.
D.1 P. Rathinam’s case – The question of unconstitutionality of Section 309 of the Indian Penal
Code:
14. Presently, it is necessary to travel backwards in time, though not very far. Two individuals,
namely, P. Rathinam and Nagbhushan Patnaik, filed two Writ Petitions under Article 32 of the
Constitution which were decided by a two- Judge Bench in P. Rathinam v. Union of India &
another6. The writ petitions assailed the constitutional validity of Section 309 of the Indian Penal
Code (IPC) contending that the same is violative of Articles 14 and 21 of the Constitution. The Court
posed 16 questions. The relevant ones read thus:-
―(1) Has Article 21 any positive content or is it merely negative in its reach?
(2) Has a person residing in India a right to die?
x x x x (12) Is suicide against public policy?
(1994) 3 SCC 394 (13) Does commission of suicide damage the monopolistic power of
the State to take life? (14) Is apprehension of ‗constitutional cannibalism‘ justified?Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(15) Recommendation of the Law Commission of India and follow-up steps taken, if
any.
(16) Global view. What is the legal position in other leading countries of the world
regarding the matter at hand?
15. Answering question No. (1), the Court, after referring to various authorities under
Article 21, took note of the authority in State of Himachal Pradesh and another v.
Umed Ram Sharma and others7 wherein it has been observed that the right to life
embraces not only physical existence but also the quality of life as understood in its
richness and fullness within the ambit of the Constitution. In the said case, the Court
had held that for residents of hilly areas, access to road was access to life itself and so,
necessity of road communication in a reasonable condition was treated as a
constitutional imperative. P. Rathinam perceived the elevated positive content in the
said ruling. Answering question No. (2), the Court referred to the decision of the
Bombay High Court in (1986) 2 SCC 68 : AIR 1986 SC 847 Maruti Shripati Dubal v.
State of Maharashtra 8 that placed reliance on R.C. Cooper v. Union of India9
wherein it had been held that what is true of one fundamental right is also true of
another fundamental right and on the said premise, the Bombay High Court had
opined that it cannot be seriously disputed that fundamental rights have their
positive as well as negative aspects. Citing an example, it had stated that freedom of
speech and expression includes freedom not to speak and similarly, the freedom of
association and movement includes freedom not to join any association or move
anywhere and, accordingly, it stated that logically it must follow that the right to live
would include the right not to live, i.e., right to die or to terminate one‘s life.
16. After so stating, this Court approved the view taken by the Bombay High Court in
Maruti Shripati Dubal and meeting the criticism of that judgment from certain
quarters, the two-Judge Bench opined that the criticism was only partially correct
because the negative aspect may not be 1987 Cri LJ 473 : (1986) 88 Bom LR 589
(1970) 2 SCC 298 : AIR 1970 SC 1318 inferable on the analogy of the rights conferred
by different clauses of Article 19 and one may refuse to live if his life, according to the
person concerned, is not worth living. One may rightly think that having achieved all
worldly pleasures or happiness, he has something to achieve beyond this life. This
desire for communion with God may rightly lead even a healthy mind to think that he
would forego his right to live and would rather choose not to live. In any case, a
person cannot be forced to enjoy the right to life to his detriment, disadvantage or
disliking. Eventually, it concluded that the right to live of which Article 21 speaks of
can be said to bring in its trail the right not to live a forced life.
17. Answering all the questions, the Court declared Section 309 IPC ultra vires and
held that it deserved to be effaced from the statute book to humanize our penal laws.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

D.2 Gian Kaur’s case – The question of unconstitutionality of Section 306 of the
Indian Penal Code:
18. The dictum laid down by the two-Judge Bench in P. Rathinam did not remain a
precedent for long. In Gian Kaur v. State of Punjab10, the Constitution Bench
considered the correctness of the decision rendered in P. Rathinam. In the said case,
the appellants were convicted by the trial Court under Section 306 IPC and the
conviction was assailed on the ground that Section 306 IPC is unconstitutional and to
sustain the said argument, reliance was placed on the authority in P. Rathinam
wherein Section 309 IPC was held to be unconstitutional being violative of Article 21
of the Constitution. It was urged that once Section 309 IPC had been held to be
unconstitutional, any person abetting the commission of suicide by another is merely
assisting in the enforcement of the fundamental right under Article 21 and, therefore,
Section 306 IPC penalizing abetment of suicide is equally violative of Article 21. The
two-Judge Bench before which these arguments were advanced in appeal referred the
matter to a Constitution Bench for deciding the same. In the course of arguments,
one of the amicus curiae, Mr. F.S. Nariman, learned senior counsel, had submitted
that the debate on euthanasia is not relevant for deciding the question (1996) 2 SCC
648 of constitutional validity of Section 309 and Article 21 cannot be construed to
include within it the so-called ―right to die since Article 21 guarantees protection of
life and liberty and not its extinction. The Constitution Bench, after noting the
submissions, stated:-
―17. … We, therefore, proceed now to consider the question of constitutional validity
with reference to Articles 14 and 21 of the Constitution. Any further reference to the
global debate on the desirability of retaining a penal provision to punish attempted
suicide is unnecessary for the purpose of this decision. Undue emphasis on that
aspect and particularly the reference to euthanasia cases tends to befog the real issue
of the constitutionality of the provision and the crux of the matter which is
determinative of the issue.
19. Thereafter, the Constitution Bench in Gian Kaur (supra) scrutinized the reasons
given in P. Rathinam and opined that the Court in the said case took the view that if a
person has a right to live, he also has a right not to live. The Court in Gian Kaur
(supra) observed that the Court in P. Rathinam (supra), while taking such a view,
relied on the decisions which relate to other fundamental rights dealing with different
situations and those decisions merely hold that the right to do an act also includes the
right not to do an act in that manner. The larger Bench further observed that in all
those decisions, it was the negative aspect of the right that was involved for which no
positive or overt act was to be done. The Constitution Bench categorically stated that
this difference has to be borne in mind while making the comparison for the
application of this principle.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

20. Delving into the facet of committing suicide, the larger Bench observed that when
a man commits suicide, he has to undertake certain positive overt acts and the
genesis of those acts cannot be traced to or be included within the protection of the
‗right to life‘ under Article 21. It also held that the significant aspect of ‗sanctity of
life‘ should not be overlooked.
The Court further opined that by no stretch of imagination, extinction of life can be read to be
included in protection of life because Article 21, in its ambit and sweep, cannot include within it the
right to die as a part of fundamental right guaranteed therein. The Constitution Bench ruled:-
―‗Right to life‘ is a natural right embodied in Article 21 but suicide is an unnatural
termination or extinction of life and, therefore, incompatible and inconsistent with
the concept of ―right to life. With respect and in all humility, we find no similarity in
the nature of the other rights, such as the right to ―freedom of speech etc. to provide
a comparable basis to hold that the ―right to life also includes the ―right to die.
With respect, the comparison is inapposite, for the reason indicated in the context of
Article 21. The decisions relating to other fundamental rights wherein the absence of
compulsion to exercise a right was held to be included within the exercise of that
right, are not available to support the view taken in P. Rathinam qua Article 21.
21. Adverting to the concept of euthanasia, the Court observed that protagonism of
euthanasia on the view that existence in persistent vegetative state (PVS) is not a
benefit to the patient of terminal illness being unrelated to the principle of ―sanctity
of life or the ―right to live with dignity is of no assistance to determine the scope of
Article 21 for deciding whether the guarantee of ―right to life therein includes the
―right to die. The ―right to life including the right to live with human dignity
would mean the existence of such a right up to the end of natural life. The
Constitution Bench further explained that the said conception also includes the right
to a dignified life up to the point of death including a dignified procedure of death or,
in other words, it may include the right of a dying man to also die with dignity when
his life is ebbing out. It has been clarified that the right to die with dignity at the end
of life is not to be confused or equated with the ―right to die an unnatural death
curtailing the natural span of life.
Thereafter, the Court proceeded to state:-
―25. A question may arise, in the context of a dying man who is terminally ill or in a
persistent vegetative state that he may be permitted to terminate it by a premature
extinction of his life in those circumstances. This category of cases may fall within the
ambit of the ―right to die with dignity as a part of right to live with dignity, when
death due to termination of natural life is certain and imminent and the process of
natural death has commenced. These are not cases of extinguishing life but only of
accelerating conclusion of the process of natural death which has already
commenced. The debate even in such cases to permit physician-assisted terminationCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

of life is inconclusive. It is sufficient to reiterate that the argument to support the
view of permitting termination of life in such cases to reduce the period of suffering
during the process of certain natural death is not available to interpret Article 21 to
include therein the right to curtail the natural span of life. [Emphasis supplied]
22. In view of the aforesaid analysis and taking into consideration various other
aspects, the Constitution Bench declared Section 309 IPC as constitutional.
23. The Court held that the "right to live with human dignity"
cannot be construed to include within its ambit the right to terminate natural life, at
least before the commencement of the process of certain natural death. It then
examined the question of validity of Section 306 IPC. It accepted the submission that
Section 306 is constitutional. While adverting to the decision in Airedale N.H.S. Trust
v. Bland11, the Court at the outset made it clear that it was not called upon to deal
with the issue of physician-assisted suicide or euthanasia cases. The decision in
Airedale‘s case (supra), was relating to the withdrawal of artificial measures for
continuance of life by a physician. In the context of existence in the persistent
vegetative state of no benefit to the patient, the principle of sanctity of life, which is
the concern of the State, was stated to be not an absolute one.
To bring home the distinction between active and passive euthanasia, an illustration
was noted in the context of administering lethal drug actively to bring the patient's
life to an end. The significant dictum in that decision has been extracted in Gian Kaur
(supra) wherein it is observed that it is not lawful for a doctor to administer a drug to
his patient to bring about (1993) 2 WLR 316: (1993) 1 All ER 821, HL his death even
though that course is promoted by a humanitarian desire to end his suffering and
however great that suffering may be. Further, to act so is to cross the rubicon which
runs between the care of the living patient on one hand and euthanasia - actively
causing his death to avoid or to end his suffering on the other hand. It has been
noticed in Airedale that euthanasia is not lawful at common law. In the light of the
demand of responsible members of the society who believe that euthanasia should be
made lawful, it has been observed in that decision that the same can be achieved by
legislation. The Constitution Bench has merely noted this aspect in paragraph 41 with
reference to the dictum in Airedale case.
24. Proceeding to deal with physician assisted suicide, the Constitution Bench observed:-
―42. The decision of the United States Court of Appeals for the Ninth Circuit in
Compassion in Dying v. State of Washington12, which reversed the decision of United
States District Court, W.D. Washington reported in 850 Federal Supplement 1454,
has also relevance. The constitutional validity of the State statute that banned
physician-assisted suicide by mentally competent, terminally ill adults was in
question. The District Court held 49 F 3d 586 unconstitutional the provisionCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

punishing for promoting a suicide attempt. On appeal, that judgment was reversed
and the constitutional validity of the provision was upheld. And again:-
―43. This caution even in cases of physician- assisted suicide is sufficient to indicate
that assisted suicides outside that category have no rational basis to claim exclusion
of the fundamental principles of sanctity of life. The reasons assigned for attacking a
provision which penalises attempted suicide are not available to the abettor of suicide
or attempted suicide. Abetment of suicide or attempted suicide is a distinct offence
which is found enacted even in the law of the countries where attempted suicide is
not made punishable. Section 306 IPC enacts a distinct offence which can survive
independent of Section 309 in the IPC. The learned Attorney General as well as both
the learned amicus curiae rightly supported the constitutional validity of Section 306
IPC. Eventually, the Court in Gian Kaur (supra), apart from overruling P. Rathinam
(supra), upheld the constitutional validity of Section 306 IPC.
D.3 The approach in Aruna Shanbaug qua Passive Euthanasia vis-à-vis India:
25. Although the controversy relating to attempt to suicide or abetment of suicide was put to rest,
yet the issue of euthanasia remained alive. It arose for consideration almost after a span of eleven
years in Aruna Shanbaug (supra). A writ petition was filed by the next friend of the petitioner
pleading, inter alia, that the petitioner was suffering immensely because of an incident that took
place thirty six years back on 27.11.1973 and was in a Persistent Vegetative State (PVS) and in no
state of awareness and her brain was virtually dead. The prayer of the next friend was that the
respondent be directed to stop feeding the petitioner and to allow her to die peacefully. The Court
noticed that there was some variance in the allegation made in the writ petition and the counter
affidavit filed by the Professor and Head of the hospital where the petitioner was availing treatment.
The Court appointed a team of three very distinguished doctors to examine the petitioner
thoroughly and to submit a report about her physical and mental condition. The team submitted a
joint report. The Court asked the team of doctors to submit a supplementary report by which the
meaning of the technical terms in the first report could be explained. Various other aspects were
also made clear. It is also worth noting that the KEM Hospital where the petitioner was admitted
was appointed as the next friend by the Court because of its services rendered to the petitioner and
the emotional bonding and attachment with the petitioner.
26. In Aruna Shanbaug (supra), after referring to the authority in Vikram Deo Singh Tomar v. State
of Bihar13, this Court reproduced paragraphs 24 and 25 from Gian Kaur‘s case and opined that the
said paragraphs simply mean that the view taken in Rathinam’s case to the effect that the ‗right to
life‘ includes the ‗right to die‘ is not correct and para 25 specifically mentions that the debate even
in such cases to permit physician-assisted termination of life is inconclusive. The Court further
observed that it was held in Gian Kaur that there is no ‗right to die‘ under Article 21 of the
Constitution and the right to life includes the right to live with human dignity but in the case of a
dying person who is terminally ill or in permanent vegetative state, he may be allowed a premature
extinction of his life and it would not amount to a crime. Thereafter, the Court took note of the
submissions of 1988 Supp. SCC 734 : AIR 1988 SC 1782 the learned amicus curiae to the effect thatCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

the decision to withdraw life support is taken in the best interests of the patient by a body of medical
persons. The Court observed that it is not the function of the Court to evaluate the situation and
form an opinion on its own. The Court further noted that in England, the parens patriae jurisdiction
over adult mentally incompetent persons was abolished by statute and the Court has no power now
to give its consent and in such a situation, the Court only gives a declaration that the proposed
omission by doctors is not unlawful.
27. After so stating, the Court addressed the legal issues, namely, active and passive euthanasia. It
noted the legislations prevalent in Netherlands, Switzerland, Belgium, U.K., Spain, Austria, Italy,
Germany, France and United States of America. It also noted that active euthanasia is illegal in all
States in USA, but physician-assisted death is legal in the States of Oregon, Washington and
Montana. The Court also referred to the legal position in Canada. Dealing with passive euthanasia,
the two-Judge Bench opined that passive euthanasia is usually defined as withdrawing medical
treatment with a deliberate intention of causing the patient‘s death. An example was cited by stating
that if a patient requires kidney dialysis to survive, not giving dialysis although the machine is
available is passive euthanasia and similarly, withdrawing the machine where a patient is in coma or
on heart-lung machine support will ordinarily result in passive euthanasia. The Court also put
non-administration of life saving medicines like antibiotics in certain situations on the same
platform of passive euthanasia. Denying food to a person in coma or PVS has also been treated to
come within the ambit of passive euthanasia. The Court copiously referred to the decision in
Airedale. In Airedale case, as has been noted in Aruna Shanbaug, Lord Goff observed that
discontinuance of artificial feeding in such cases is not equivalent to cutting a mountaineer‘s rope or
severing the air pipe of a deep sea diver. The real question has to be not whether the doctor should
take a course in which he will actively kill his patient but whether he should continue to provide his
patient with medical treatment or care which, if continued, will prolong his life.
28. Lord Browne–Wilkinson was of the view that removing the nasogastric tube in the case of
Anthony Bland cannot be regarded as a positive act causing death. The tube by itself, without the
food being supplied through it, does nothing. Its non-removal by itself does not cause death since by
itself, it does not sustain life. The learned Judge observed that removal of the tube would not
constitute the actus reus of murder since such an act by itself would not cause death.
29. Lord Mustill observed:-
―Threaded through the technical arguments addressed to the House were the strands
of a much wider position, that it is in the best interests of the community at large that
Anthony Bland’s life should now end. The doctors have done all they can. Nothing
will be gained by going on and much will be lost. The distress of the family will get
steadily worse. The strain on the devotion of a medical staff charged with the care of a
patient whose condition will never improve, who may live for years and who does not
even recognise that he is being cared for, will continue to mount. The large resources
of skill, labour and money now being devoted to Anthony Bland might in the opinion
of many be more fruitfully employed in improving the condition of other patients,
who if treated may have useful, healthy and enjoyable lives for years to come.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

30. The two-Judge Bench further observed that the decision in Airedale by the House of Lords has
been followed in a number of cases in U.K. and the law is now fairly well settled that in the case of
incompetent patients, if the doctors act on the basis of notified medical opinion and withdraw the
artificial life support system in the patient‘s best interest, the said act cannot be regarded as a crime.
The learned Judges posed the question as to who is to decide what is that patient‘s best interest
where he is in a PVS and, in that regard, opined that it is ultimately for the Court to decide, as
parens patriae, as to what is in the best interest of the patient, though the wishes of close relatives
and next friend and the opinion of medical practitioners should be given due weight in coming to its
decision. For the said purpose, reference was made to the opinion of Balcombe J. in Re J (A Minor)
(Wardship: Medical Treatment) 14 whereby it has been stated that the Court as representative of the
Sovereign and as parens patriae will adopt the same standard which a reasonable and responsible
parent would do.
[1991] 2 WLR 140: [1990] 3 All ER 930: [1991] Fam 33
31. The two-Judge Bench referred to the decisions of the Supreme Court of United States in
Washington v. Glucksberg15 and Vacco v. Quill16 which addressed the issue whether there was a
federal constitutional road to assisted suicide. Analysing the said decisions and others, the Court
observed that the informed consent doctrine has become firmly entrenched in American Tort Law
and, as a logical corollary, lays foundation for the doctrine that the patient who generally possesses
the right to consent has the right to refuse treatment.
32. In the ultimate analysis, the Court opined that the Airedale case is more apposite to be followed.
Thereafter, the Court adverted to the law in India and ruled that in Gian Kaur case, this Court had
approved the decision of the House of Lords in Airedale and observed that euthanasia could be
made lawful only by legislation. After so stating, the learned Judges opined:-
―104. It may be noted that in Gian Kaur case although the Supreme Court has quoted
with approval the view of the House of Lords in Airedale 138 L Ed 2d 772 : 521 US
702 (1997) 138 L Ed 2d 834 : 521 US 793 (1997) case, it has not clarified who can
decide whether life support should be discontinued in the case of an incompetent
person e.g. a person in coma or PVS.
This vexed question has been arising often in India because there are a large number of cases where
persons go into coma (due to an accident or some other reason) or for some other reason are unable
to give consent, and then the question arises as to who should give consent for withdrawal of life
support. This is an extremely important question in India because of the unfortunate low level of
ethical standards to which our society has descended, its raw and widespread commercialisation,
and the rampant corruption, and hence, the Court has to be very cautious that unscrupulous persons
who wish to inherit the property of someone may not get him eliminated by some crooked method.
33. After so stating, the two-Judge Bench dwelled upon the concept of brain dead and various other
aspects which included withdrawal of life support of a patient in PVS and, in that context, ruled
thus:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

―125. In our opinion, if we leave it solely to the patient‘s relatives or to the doctors or
next friend to decide whether to withdraw the life support of an incompetent person
there is always a risk in our country that this may be misused by some unscrupulous
persons who wish to inherit or otherwise grab the property of the patient.
Considering the low ethical levels prevailing in our society today and the rampant
commercialisation and corruption, we cannot rule out the possibility that
unscrupulous persons with the help of some unscrupulous doctors may fabricate
material to show that it is a terminal case with no chance of recovery. There are
doctors and doctors. While many doctors are upright, there are others who can do
anything for money (see George Bernard Shaw‘s play The Doctor’s Dilemma). The
commercialisation of our society has crossed all limits. Hence we have to guard
against the potential of misuse (see Robin Cook‘s novel Coma). In our opinion, while
giving great weight to the wishes of the parents, spouse, or other close relatives or
next friend of the incompetent patient and also giving due weight to the opinion of
the attending doctors, we cannot leave it entirely to their discretion whether to
discontinue the life support or not. We agree with the decision of Lord Keith in
Airedale case5 that the approval of the High Court should be taken in this connection.
This is in the interest of the protection of the patient, protection of the doctors,
relatives and next friend, and for reassurance of the patient‘s family as well as the
public. This is also in consonance with the doctrine of parens patriae which is a
well-known principle of law.
34. After so laying down, the Court referred to the authorities in Charan Lal Sahu v. Union of India
17 and State of Kerala and another v. N.M. Thomas and others 18 and further opined that the High
Court can grant approval for withdrawing life support of an incompetent person under Article 226
of the Constitution because Article 226 gives abundant power to the High Court to pass suitable
orders on (1990) 1 SCC 613 (1976) 2 SCC 310 the application filed by the near relatives or next friend
or the doctors/hospital staff praying for permission to withdraw the life support of an incompetent
person. Dealing with the procedure to be adopted by the High Court when such application is filed,
the Court ruled that when such an application is filed, the Chief Justice of the High Court should
forthwith constitute a Bench of at least two Judges who should decide to grant approval or not and
before doing so, the Bench should seek the opinion of a Committee of three reputed doctors to be
nominated by the Bench after consulting such medical authorities/medical practitioners as it may
deem fit. Amongst the three doctors, as directed, one should be a Neurologist, one should be a
Psychiatrist and the third a Physician. The Court further directed:-
―134. … The committee of three doctors nominated by the Bench should carefully
examine the patient and also consult the record of the patient as well as take the
views of the hospital staff and submit its report to the High Court Bench.
Simultaneously with appointing the committee of doctors, the High Court Bench
shall also issue notice to the State and close relatives e.g. parents, spouse, brothers/
sisters, etc. of the patient, and in their absence his/her next friend, and supply a copy
of the report of the doctor‘s committee to them as soon as it is available. After hearing
them, the High Court Bench should give its verdict.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

135. The above procedure should be followed all over India until Parliament makes
legislation on this subject.
136. The High Court should give its decision speedily at the earliest, since delay in the
matter may result in causing great mental agony to the relatives and persons close to
the patient. The High Court should give its decision assigning specific reasons in
accordance with the principle of ―best interest of the patient laid down by the
House of Lords in Airedale case. The views of the near relatives and committee of
doctors should be given due weight by the High Court before pronouncing a final
verdict which shall not be summary in nature.
35. We must note here that the two-Judge Bench declined to grant the permission after perusing the
medical reports. For the sake of completeness, we think it apt to reproduce the reasoning:-
―122. From the above examination by the team of doctors, it cannot be said that
Aruna Shanbaug is dead. Whatever the condition of her cortex, her brainstem is
certainly alive. She does not need a heart-lung machine. She breathes on her own
without the help of a respirator. She digests food, and her body performs other
involuntary functions without any help. From the CD (which we had screened in the
courtroom on 2-3-2011 in the presence of the counsel and others) it appears that she
can certainly not be called dead. She was making some sounds, blinking, eating food
put in her mouth, and even licking with her tongue morsels on her mouth. However,
there appears little possibility of her coming out of PVS in which she is in. In all
probability, she will continue to be in the state in which she is in till her death. D.4
The Reference:
36. The aforesaid matter was decided when the present Writ Petition was pending for consideration.
The present petition was, thereafter, listed before a three-Judge Bench which noted the submissions
advanced on behalf of the petitioner and also that of the learned Additional Solicitor General on
behalf of the Union of India. Reliance was placed on the decision in Aruna Shanbaug. The
three-Judge Bench reproduced paragraphs 24 and 25 from Gian Kaur and noted that the
Constitution Bench did not express any binding view on the subject of euthanasia, rather it
reiterated that the legislature would be the appropriate authority to bring the change.
37. After so holding, it referred to the understanding of Gian Kaur in Aruna Shanbaug by the
two-Judge Bench and reproduced paragraphs 21 and 101 from the said judgment:-
―21. We have carefully considered paras 24 and 25 in Gian Kaur case and we are of
the opinion that all that has been said therein is that the view in Rathinam case that
the right to life includes the right to die is not correct. We cannot construe Gian Kaur
case to mean anything beyond that. In fact, it has been specifically mentioned in para
25 of the aforesaid decision that ‘the debate even in such cases to permit
physician-assisted termination of life is inconclusive’. Thus it is obvious that no final
view was expressed in the decision in Gian Kaur case beyond what we haveCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

mentioned above.
x x x x ―101. The Constitution Bench of the Supreme Court in Gian Kaur v. State of
Punjab held that both euthanasia and assisted suicide are not lawful in India. That
decision overruled the earlier two-Judge Bench decision of the Supreme Court in P.
Rathinam v. Union of India. The Court held that the right to life under Article 21 of
the Constitution does not include the right to die (vide SCC para 33). In Gian Kaur
case the Supreme Court approved of the decision of the House of Lords in Airedale
case and observed that euthanasia could be made lawful only by legislation.
(Emphasis supplied)
38. Commenting on the said analysis, the three-Judge Bench went on to say:-
―13. Insofar as the above paragraphs are concerned, Aruna Shanbaug aptly
interpreted the decision of the Constitution Bench in Gian Kaur and came to the
conclusion that euthanasia can be allowed in India only through a valid legislation.
However, it is factually wrong to observe that in Gian Kaur, the Constitution Bench
approved the decision of the House of Lords in Airedale N.H.S. Trust v. Bland. Para
40 of Gian Kaur, clearly states that :
―40. … Even though it is not necessary to deal with physician-assisted suicide or
euthanasia cases, a brief reference to this decision cited at the Bar may be made.
(Emphasis supplied) Thus, it was a mere reference in the verdict and it cannot be
construed to mean that the Constitution Bench in Gian Kaur approved the opinion of
the House of Lords rendered in Airedale. To this extent, the observation in para 101
of Aruna Shanbaug is incorrect.
39. From the aforesaid, it is clear that the three-Judge Bench expressed the view that the opinion of
the House of Lords in Airedale has not been approved in Gian Kaur (supra) and to that extent, the
observation in Aruna Shanbaug (supra) is incorrect. After so stating, the three-Judge Bench opined
that Aruna Shanbaug (supra) upholds the authority of passive euthanasia and lays down an
elaborate procedure for executing the same on the wrong premise that the Constitution Bench in
Gian Kaur (supra) had upheld the same. Thereafter, considering the important question of law
involved which needs to be reflected in the light of social, legal, medical and constitutional
perspectives, in order to have a clear enunciation of law, it referred the matter for consideration by
the Constitution Bench of this Court for the benefit of humanity as a whole. The three-Judge bench
further observed that it was refraining from framing any specific questions for consideration by the
Constitution Bench as it would like the Constitution Bench to go into all the aspects of the matter
and lay down exhaustive guidelines. That is how the matter has been placed before us.
E. Our analysis of Gian Kaur:
40. It is the first and foremost duty to understand what has been stated by the Constitution Bench in
Gian Kaur‘s case. It has referred to the decision in Airedale (supra) that has been recapitulated inCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Aruna Shanbaug case which was a case relating to withdrawal of artificial measures of continuance
of life by the physician. It is relevant to mention here that the Constitution Bench in Gian Kaur
categorically noted that it was not necessary to deal with physician–assisted suicide or euthanasia
cases though a brief reference to the decisions cited by the Bar was required to be made. The
Constitution Bench noted that Airedale held that in the context of existence in the persistent
vegetative state of no benefit to the patient, the principle of sanctity of life, which is the concern of
the State, was not an absolute one. The larger bench further noticed that in Airedale, it had been
stated that in such cases also, the existing crucial distinction between cases in which a physician
decides not to provide or to continue to provide, for his patient, treatment or care which could or
might prolong his life, and those in which he decides, for example, by administering a lethal drug
actively to bring his patient‘s life to an end, was indicated. Thereafter, while again referring to
Airedale case, the larger bench observed that it was a case relating to withdrawal of artificial
measures for continuance of life by the physician. After so stating, the Court reproduced the
following passage from the opinion of Lord Goff of Chieveley:-
―... But it is not lawful for a doctor to administer a drug to his patient to bring about
his death, even though that course is prompted by a humanitarian desire to end his
suffering, however great that suffering may be : See Reg v. Cox, (unreported), 18
September (1992). So to act is to cross the Rubicon which runs between on the one
hand the care of the living patient and on the other hand euthanasia
- actively causing his death to avoid or to end his suffering. Euthanasia is not lawful
at common law. It is of course well known that there are many responsible members
of our society who believe that euthanasia should be made lawful; but that result
could, I believe, only be achieved by legislation which expresses the democratic will
that so fundamental a change should be made in our law, and can, if enacted, ensure
that such legalised killing can only be carried out subject to appropriate supervision
and control.... (Emphasis supplied in Gian Kaur)
41. After reproducing the said passage, the Court opined thus:-
―41. The desirability of bringing about a change was considered to be the function of
the legislature by enacting a suitable law providing therein adequate safeguards to
prevent any possible abuse.
42. At this stage, it is necessary to clear the maze whether the Constitution Bench in Gian Kaur had
accepted what has been held in Airedale. On a careful and anxious reading of Gian Kaur, it is
noticeable that there has been narration, reference and notice of the view taken in Airedale case. It is
also worth noting that the Court was concerned with the constitutional validity of Section 309 IPC
that deals with attempt to commit suicide and Section 306 IPC that provides for abetment to
commit suicide. As noted earlier, the Constitution Bench, while distinguishing the case of a dying
man who is terminally ill or in a persistent vegetative state and his termination or premature
extinction of life, observed that the said category of cases may fall within the ambit of right to die
with dignity as a part of right to life with dignity when death due to termination of natural life isCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

inevitable and imminent and the process of natural death has commenced. The Constitution Bench
further opined that the said cases do not amount to extinguishing the life but only amount to
accelerating the process of natural death which has already commenced and, thereafter, the
Constitution Bench stated that the debate with regard to physician assisted suicide remains
inconclusive. The larger Bench has reiterated that the cases pertaining to premature extinction of
life during the process of certain natural death of patients who are terminally ill or in persistent
vegetative state were of assistance to interpret Article 21 of the Constitution to include therein the
right to curtail the natural span of life. On a seemly understanding of the judgment in Gian Kaur, we
do not find that it has decried euthanasia as a concept. On the contrary, it gives an indication that in
such situations, it is the acceleration of the process of dying which may constitute a part of right to
life with dignity so that the period of suffering is reduced. We are absolutely conscious that a
judgment is not to be construed as a statute but our effort is to understand what has been really
expressed in Gian Kaur. Be it clarified, it is understood and appreciated that there is a distinction
between a positive or overt act to put an end to life by the person living his life and termination of
life so that an individual does not remain in a vegetative state or, for that matter, when the death is
certain because of terminal illness and he remains alive with the artificially assisted medical system.
In Gian Kaur, while dealing with the attempt to commit suicide, the Court clearly held that when a
man commits suicide, he has to undertake certain positive overt acts and the genesis of those acts
cannot be tested to or be included within the protection of the expression ―right to life under
Article 21 of the Constitution. It was also observed that a dignified procedure of death may include
the right of a dying man to also die with dignity when the life is ebbing out. This is how the
pronouncement in Gian Kaur has to be understood. It is also not the ratio of the authority in Gian
Kaur that euthanasia has to be introduced only by a legislation. What has been stated in paragraph
41 of Gian Kaur is what has been understood to have been held in Airedale‘s case. The Court has
neither expressed any independent opinion nor has it approved the said part or the ratio as stated in
Airedale. There has been only a reference to Airedale‘s case and the view expressed therein as
regards legislation. Therefore, the perception in Aruna Shanbaug that the Constitution Bench has
approved the decision in Airedale is not correct. It is also quite clear that Gian Kaur does not lay
down that passive euthanasia can only be thought of or given effect to by legislation. Appositely
understood, it opens an expansive sphere of Article 21 of the Constitution. Therefore, it can be held
without any hesitation that Gian Kaur has neither given any definite opinion with regard to
euthanasia nor has it stated that the same can be conceived of only by a legislation.
F. Our analysis of Aruna Shanbaug qua legislation:
43. Having said this, we shall focus in detail what has been stated in Aruna Shanbaug. In paragraph
101 which has been reproduced hereinbefore, the two-Judge Bench noted that Gian Kaur has
approved the decision of the House of Lords in Airedale and observed that euthanasia could be
made lawful only by legislation. This perception, according to us, is not correct. As already stated,
Gian Kaur does not lay down that passive euthanasia could be made lawful only by legislation. In
paragraph 41 of the said judgment, the Constitution Bench was only adverting to what has been
stated by Lord Goff of Chieveley in Airedale‘s case. However, this expression of view of Aruna
Shanbaug which has not been accepted by the referral Bench makes no difference to our present
analysis. We unequivocally express the opinion that Gian Kaur is not a binding precedent for theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

purpose of laying down the principle that passive euthanasia can be made lawful ―only by
legislation. G. The Distinction between Active and Passive Euthanasia:
44. As a first step, it is imperative to understand the concept of euthanasia before we enter into the
arena of analysis of the expanded right of Article 21 in Gian Kaur and the understanding of the
same. Euthanasia is basically an intentional premature termination of another person‘s life either by
direct intervention (active euthanasia) or by withholding life-prolonging measures and resources
(passive euthanasia) either at the express or implied request of that person (voluntary euthanasia)
or in the absence of such approval/consent (non-voluntary euthanasia). Aruna Shanbaug has
discussed about two categories of euthanasia - active and passive. While dealing with active
euthanasia, also known as ―positive euthanasia or ―aggressive euthanasia, it has been stated that
the said type of euthanasia entails a positive act or affirmative action or act of commission entailing
the use of lethal substances or forces to cause the intentional death of a person by direct
intervention, e.g., a lethal injection given to a person with terminal cancer who is in terrible agony.
Passive euthanasia, on the other hand, also called ―negative euthanasia or ―non-aggressive
euthanasia, entails withdrawing of life support measures or withholding of medical treatment for
continuance of life, e.g., withholding of antibiotics in case of a patient where death is likely to occur
as a result of not giving the said antibiotics or removal of the heart lung machine from a patient in
coma. The two-Judge Bench has also observed that the legal position across the world seems to be
that while active euthanasia is illegal unless there is a legislation permitting it, passive euthanasia is
legal even without legislation, provided certain conditions and safeguards are maintained. The Court
has drawn further distinction between voluntary euthanasia and non-voluntary euthanasia in the
sense that voluntary euthanasia is where the consent is taken from the patient and non-voluntary
euthanasia is where the consent is unavailable, for instances when the patient is in coma or is
otherwise unable to give consent. Describing further about active euthanasia, the Division Bench has
observed that the said type of euthanasia involves taking specific steps to cause the patient‘s death
such as injecting the patient with some lethal substance, i.e., sodium pentothal which causes, in a
person, a state of deep sleep in a few seconds and the person instantly dies in that state. That apart,
the Court has drawn a distinction between euthanasia and physician assisted dying and noted that
the difference lies in the fact as to who administers the lethal medication. It has been observed that
in euthanasia, a physician or third party administers it while in physician assisted suicide, it is the
patient who does it though on the advice of the doctor. Elaborating further, the two-Judge Bench
has opined that the predominant difference between ―active and ―passive euthanasia is that in
the former, a specific act is done to end the patient‘s life while the latter covers a situation where
something is not done which is necessary in preserving the patient‘s life. The main idea behind the
distinction, as observed by the Bench, is that in passive euthanasia, the doctors are not actively
killing the patient, they are merely not saving him and only accelerating the conclusion of the
process of natural death which has already commenced.
45. The two-Judge Bench, thereafter, elaborated on passive euthanasia and gave more examples of
cases within the ambit of passive euthanasia. The learned Judges further categorized passive
euthanasia into voluntary passive euthanasia and non-voluntary passive euthanasia. The learned
Judges described voluntary passive euthanasia as a situation where a person who is capable of
deciding for himself decides that he would prefer to die because of various reasons whereas non-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

voluntary passive euthanasia has been described to mean that a person is not in a position to decide
for himself, e.g., if he is in coma or PVS.
46. While scrutinizing the distinction between active and passive euthanasia, the paramount aspect
is ―foreseeing the hastening of death. The said view has been propagated in several decisions all
over the world. The Supreme Court of Canada, in the case of Rodriguez v. British Columbia
(Attorney General)19, drew the distinction between these two forms of euthanasia on the basis of
intention. Echoing a similar view, the Supreme Court of the United States affirmed the said
distinction on the basis of ―intention in the case of Vacco (supra) wherein Chief Justice Rehnquist
observed that the said distinction coheres with the fundamental legal principles of causation and
intention. In case when the death of a patient occurs due to removal of life-supporting measures, the
patient dies due to an underlying fatal disease without any intervening act on the part of the doctor
or medical practitioner, whereas in the cases coming within the purview of active euthanasia, for
example, when the patient ingests lethal medication, he is killed by that medication.
47. This distinction on the basis of ―intention further finds support in the explanation provided in
the case In the matter of Claire C. Conroy20 wherein the Court made an observation that people
who refuse life-sustaining medical treatment may not harbour a specific intent to die, rather they
may fervently 85 C.C.C. (3d) 15 : (1993) 3 S.C.R. 519 98 N.J. 321 (1985) : (1985) 486 A.2d 1209
(N.J.) wish to live but do so free of unwanted medical technology, surgery or drugs and without
protracted suffering.
48. Another distinction on the basis of ―action and non- action was advanced in the Airedale case.
Drawing a crucial distinction between the two forms of euthanasia, Lord Goff observed that passive
euthanasia includes cases in which a doctor decides not to provide, or to continue to provide, for his
patient, treatment or care which could prolong his life and active euthanasia involves actively ending
a patient‘s life, for example, by administering a lethal drug. As per the observations made by Lord
Goff, the former can be considered lawful either because the doctor intends to give effect to his
patient‘s wishes by withholding the treatment or care, or even in certain circumstances in which the
patient is incapacitated from giving his consent. However, active euthanasia, even voluntary, is
impermissible despite being prompted by the humanitarian desire to end the suffering of the
patient.
49. It is perhaps due to the distinction evolved between these two forms of euthanasia, which has
gained moral and legal sanctity all over, that most of the countries today have legalized passive
euthanasia either by way of legislations or through judicial interpretation but there remains
uncertainty whether active euthanasia should be granted legal status. H. Euthanasia : International
Position:
H.1 U.K. Decisions:
H.1.1 Airedale Case:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

50. In the obtaining situation, we shall now advert to the opinions stated in Airedale case. In the
said case, one Anthony Bland, a supporter of Liverpool Football Club, who had gone to Hillsborough
Ground, suffered severe injuries as a result of which supply to his brain was interrupted. Eventually,
he suffered an irreversible damage to the brain as a consequence of which he got into a condition of
persistent vegetative state (PVS). He became incapable of voluntary movement and could feel no
pain. He was not in a position to feel or communicate. To keep him alive, artificial means were taken
recourse to. In such a state of affairs, the treating doctors and the parents of Bland felt that no
fruitful purpose would be served by continuing the medical aid. As there were doubts with regard to
stoppage of medical care which may incur a criminal liability, a declaration from the British High
Court was sought to resolve the doubts. The Family Division of the High Court granted the
declaration which was affirmed by the Court of Appeal. The matter travelled to the House of Lords.
51. Lord Keith of Kinkel opined that regard should be had to the whole artificial regime which kept
Anthony Bland alive and it was incorrect to direct attention exclusively to the fact that nourishment
was being provided. In his view, the administration of nourishment by the means adopted involved
the application of a medical technique.
52. Lord Keith observed that in general, it would not be lawful for a medical practitioner who
assumed responsibility for the care of an unconscious patient simply to give up treatment in
circumstances where continuance of it would confer some benefit on the patient. On the other hand,
a medical practitioner is under no duty to continue to treat such a patient where a large body of
informed and responsible medical opinion is to the effect that no benefit at all would be conferred by
continuance of treatment. Existence in a vegetative state with no prospect of recovery is, by that
opinion, regarded as not being a benefit, and that, if not unarguably correct, at least forms a proper
basis for the decision to discontinue treatment and care. He was of the further opinion that since
existence in PVS is not a benefit to the patient, the principle of sanctity of life is no longer an
absolute one. It does not compel a medical practitioner to treat a patient, who will die if not treated,
contrary to the express wishes of the patient. It does not compel the temporary keeping alive of
patients who are terminally ill where to do so would merely prolong their suffering. On the other
hand, it forbids the taking of active measures to cut short the life of a terminally ill patient.
53. Lord Keith further stated that it does no violence to the principle of sanctity of life to hold that it
is lawful to cease to give medical treatment and care to a PVS patient who has been in that state for
over three years considering that to do so involves invasive manipulation of the patient's body to
which he has not consented and which confers no benefit upon him. He also observed that the
decision whether or not the continued treatment and care of a PVS patient confers any benefit on
him is essentially one for the practitioners in charge.
54. Lord Goff of Chieveley also held that the principle of sanctity of life is not an absolute one and
there is no absolute rule that the patient's life must be prolonged by such treatment or care, if
available, regardless of the circumstances.
55. Lord Goff observed that though he agreed that the doctor's conduct in discontinuing life support
can properly be categorised as an omission, yet discontinuation of life support is, for the presentCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

purposes, no different from not initiating life support in the first place as in such a case, the doctor is
simply allowing his patient to die in the sense that he is desisting from taking a step which might, in
certain circumstances, prevent his patient from dying as a result of his pre-existing condition; and
as a matter of general principle, an omission such as this will not be unlawful unless it constitutes a
breach of duty to the patient.
56. The learned Law Lord further observed that the doctor's conduct is to be differentiated from that
of, for example, an interloper who maliciously switches off a life support machine in the sense that
although the interloper performs the same act as the doctor who discontinues life support, yet the
doctor, in discontinuing life support, is simply allowing his patient to die of his pre-existing
condition, whereas the interloper is actively intervening to stop the doctor from prolonging the
patient's life, and such conduct cannot possibly be categorised as an omission. This distinction as
per Lord Goff appears to be useful in the context as it can be invoked to explain how discontinuance
of life support can be differentiated from ending a patient's life by a lethal injection. Lord Goff stated
that the reason for this difference is that the law considers discontinuance of life support to be
consistent with the doctor's duty to care for his patient, but it does not, for reasons of policy,
consider that it forms any part of his duty to give his patient a lethal injection to put the patient out
of his agony.
57. Emphasising on the patient's best interest principle, Lord Goff referred to F v. West Berkshire
Health Authority 21 wherein the House of Lords stated the legal principles governing the treatment
of a patient who, for the reason that he was of unsound mind or that he had been rendered
unconscious by accident or by illness, was incapable of stating whether or not he consented to the
treatment or care. In such circumstances, a doctor may lawfully treat such a patient if he acts in his
best interests, and indeed, if the patient is already in his care, he is under a duty so to treat him.
58. Drawing an analogy, Lord Goff opined that a decision by a doctor whether or not to initiate or to
continue to provide treatment or care which could or might have the effect of prolonging such a
patient's life should also be governed by the same fundamental principle of the patient's best
interest. The learned Law Lord further stated that the doctor who is caring for such a patient cannot
be put under an absolute obligation [1989] 2 All ER 545 : [1990] 2 AC 1 to prolong his life by any
means available to the doctor, regardless of the quality of the patient's life. Common humanity
requires otherwise as do medical ethics and good medical practice accepted in the United Kingdom
and overseas. Lord Goff said that the doctor's decision to take or not to take any step must be made
in the best interests of the patient (subject to his patient's ability to give or withhold his consent).
59. Lord Goff further stated that in such cases, the question is not whether it is in the best interests
of the patient that he should die, rather the correct question for consideration is whether it is in the
best interests of the patient that his life should be prolonged by the continuance of such form of
medical treatment or care. In Lord Goff‘s view, the correct formulation of the question is of
particular importance in such cases as the patient is totally unconscious and there is no hope
whatsoever of any amelioration of his condition. Lord Goff opined that if the question is asked
whether it is in the best interests of the patient to continue the treatment which has the effect of
artificially prolonging his life, that question can sensibly be answered to the effect that the patient'sCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

best interests no longer require such a treatment to be continued.
60. Lord Goff opined that medical treatment is neither appropriate nor requisite simply to prolong a
patient's life when such treatment has no therapeutic purpose of any kind and such treatment is
futile because the patient is unconscious and there is no prospect of any improvement in his
condition. Thereafter, the learned Law Lord observed that regard should also be had to the invasive
character of the treatment and to the indignity to which a patient is subjected by prolonging his life
by artificial means which, in turn, causes considerable distress to his family. In such cases, Lord Goff
said that it is the futility of the treatment which justifies its termination and in such circumstances, a
doctor is not required to initiate or to continue life- prolonging treatment or care keeping in mind
the best interests of the patient.
61. Lord Goff, referring to West Berkshire Health Authority (supra), said that it was stated therein
that where a doctor provides treatment to a person who is incapacitated from saying whether or not
he consents to it, the doctor must, when deciding on the form of treatment, act in accordance with a
responsible and competent body of relevant professional opinion on the principles set down in
Bolam v. Friern Hospital Management Committee 22 . Lord Goff opined that this principle must
equally be applicable to decisions to initiate or to discontinue life support as it is to other forms of
treatment. He also referred to a Discussion Paper on Treatment of Patients in Persistent Vegetative
State issued in September, 1992 by the Medical Ethics Committee of the British Medical Association
pertaining to four safeguards in particular which, in the Committee's opinion, should be observed
before discontinuing life support for such patients, which were: (1) every effort should be made at
rehabilitation for at least six months after the injury; (2) the diagnosis of irreversible PVS should not
be considered confirmed until at least 12 months after the injury with the effect that any decision to
withhold life-prolonging treatment will be delayed for that period; (3) the diagnosis should be
agreed by two other [1957] 1 W.L.R. 582 : [1957] 2 All ER 118 independent doctors; and (4)
generally, the wishes of the patient's immediate family will be given great weight.
62. According to him, the views expressed by the Committee on the subject of consultation with the
relatives of PVS patients are consistent with the opinion expressed by the House of Lords in West
Berkshire Health Authority (supra) that it is good practice for the doctor to consult relatives. Lord
Goff observed that the Committee was firmly of the opinion that the relatives' views would not be
determinative of the treatment inasmuch as if that would have been the case, the relatives would be
able to dictate to the doctors what is in the best interests of the patient which cannot be right. Even
so, a decision to withhold life-prolonging treatment such as artificial feeding must require close
cooperation with those close to the patient and it is recognised that, in practice, their views and the
opinions of doctors will coincide in many cases.
63. Thereafter, Lord Goff referred to American cases, namely, Re Quinlan 23 and Superintendent of
Belchertown State 355 A. 2d 647 : (1976) 70 NJ 10 School v. Saikewicz24 wherein the American
Courts adopted what is called the substituted judgment test which involves a detailed inquiry into
the patient's views and preferences. As per the substituted judgment test, when the patient is
incapacitated from expressing any view on the question whether life-prolonging treatment should be
withheld, an attempt is made to determine what decision the patient himself would have made hadCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

he been able to do so. In later American cases concerning PVS patients, it has been held that in the
absence of clear and convincing evidence of the patient's wishes, the surrogate decision-maker has
to implement as far as possible the decision which the incompetent patient would have made if he
was competent.
64. However, Lord Goff acknowledged that any such test (substituted judgment test) does not form
part of English law in relation to incompetent adults on whose behalf nobody has power to give
consent to medical treatment. In contrast, England followed a straightforward test based on the best
interests of the patient coined by the House of Lords in West (1977) 373 Mass 728 : 370 N.E. 2d 417
(1977) Berkshire Health Authority (supra). He opined that the same test (patient's best interest)
should be applied in the case of PVS patients where the question is whether life- prolonging
treatment should be withheld. The learned Law Lord further observed that consistent with the best
interests test, anything relevant to the application of the test may also be taken into account and if
the personality of the patient is relevant to the application of the test (as it may be in cases where the
various relevant factors have to be weighed), it may be taken into account as was done in Re J. (A
Minor) (Wardship: Medical Treatment) (supra). But where the question is whether life support
should be withheld from a PVS patient, it is difficult to see how the personality of the patient can be
relevant, though it may be of comfort to his relatives if they believe, as in the present case, and
indeed may well be so in many other cases, that the patient would not have wished his life to be
artificially prolonged if he was totally unconscious and there was no hope of improvement in his
condition.
65. As regards the extent to which doctors should, as a matter of practice, seek the guidance of the
court by way of an application for declaratory relief before withholding life- prolonging treatment
from a PVS patient, Lord Goff took note of the judgment of Sir Stephen Brown P, the President of
the Family Division, wherein he held that the opinion of the court should be sought in all cases of
similar nature. Lord Goff also noted that Sir Thomas Bingham M.R. in the Court of Appeal
expressed his agreement with Sir Stephen Brown P. in the following words:-
"This was in my respectful view a wise ruling, directed to the protection of patients,
the protection of doctors, the reassurance of patients' families and the reassurance of
the public. The practice proposed seems to me desirable. It may very well be that with
the passage of time a body of experience and practice will build up which will obviate
the need for application in every case, but for the time being I am satisfied that the
practice which the President described should be followed.
66. It is worthy to mention that Lord Goff was of the view that there was a considerable cost
involved in obtaining guidance from the court in cases of such nature. He took note of the
suggestions forwarded by Mr. Francis, the counsel for the respondents, to the effect that reference to
the court was required in certain specific cases, i.e., (1) where there was known to be a medical
disagreement as to the diagnosis or prognosis, and (2) problems had arisen with the patient‘s
relatives-disagreement by the next of kin with the medical recommendation; actual or apparent
conflict of interest between the next of kin and the patient; dispute between members of the
patient‘s family; or absence of any next of kin to give consent. Lord Goff said that the President ofCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

the Family Division should be able to relax the present requirement so as to limit applications for
declarations only to those cases in which there is a special need for the procedure to be invoked.
67. Lord Mustill observed that an argument had been advanced that it was in the best interest of the
community at large that Anthony Bland‘s life should end. The doctors had done all they could have
done. It was a lose-lose situation as nothing would be gained by continuing Bland‘s treatment and
much would be lost. The distress of Bland‘s family members would steadily get worse and so would
be the strain of the medical staff charged with the care of Bland despite the fact that Bland's
condition would never improve and he would never recognize that he was being cared for. Further,
the learned Law Lord observed that large resources in terms of skill, labour and money had been
applied for maintaining Bland in his present condition which, in the opinion of many, could be
fruitfully employed in improving the conditions of other patients who, if treated, may have useful,
healthy and enjoyable lives for years to come.
68. Lord Lowry, agreeing with the reasoning of Lord Goff of Chieveley with whom the other learned
Law Lords were also in general agreement, dismissed the appeal. In coming to this conclusion, Lord
Lowry opined that the court, in reaching a decision according to law, ought to give weight to
informed medical opinion both on the point whether to continue the artificial feeding regime of a
patient in PVS and also on the question of what is in the best interests of a patient. Lord Lowry
rejected the idea that informed medical opinion in these respects was merely a disguise which, if
accepted, would legalise euthanasia. Lord Lowry also rejected the Official Solicitor's argument that
the doctors were under a "duty to feed" their patients in PVS as in the instant case, the doctors
overwhelmingly held the opposite view which had been upheld by the courts below. The doctors
considered that it was in the patient's best interests that they should stop feeding him. Lord Lowry
observed that the learned Law Lords had gone further by saying that the doctors are not entitled to
feed a patient in PVS without his consent which cannot be obtained.
69. Lord Lowry further opined that there is no proposed guilty act in stopping the artificial feeding
regime inasmuch as if it is not in the interests of an insentient patient to continue the life-
supporting care and treatment, the doctor would be acting unlawfully if he continued the care and
treatment and would perform no guilty act by discontinuing it. There is a gap between the old law on
the one hand and new medicine and new ethics on the other. It is important, particularly in the area
of criminal law which governs conduct, that the society's notions of what the law is and what is right
should coincide. One role of the legislator, as per Lord Lowry, is to detect any disparity between
these notions and to take appropriate action to close the gap.
70. Lord Browne-Wilkinson observed that the ability to sustain life artificially is a relatively recent
phenomenon. Existing law may not provide an acceptable answer to the new legal questions which it
raises.
71. In the opinion of the learned Law Lord, there exists no doubt that it is for the Parliament and not
the courts to decide the broader issues raised by cases of such nature. He observed that recent
developments in medical science have fundamentally changed the meaning of death. In medicine,
the cessation of breathing or of heartbeat is no longer death because by the use of a ventilator, lungsCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

which in the unaided course of nature stop breathing can be made to breathe artificially thereby
sustaining the heartbeat. Thus, people like Anthony Bland, who would have previously died through
inability to swallow food, can be kept alive by artificial feeding. This has led the medical profession,
in Lord Browne- Wilkinson's view, to redefine death in terms of brain stem death, i.e., the death of
that part of the brain without which the body cannot function at all without assistance. He further
said that if the judges seek to develop new law to regulate the new circumstances, the law so laid
down will reflect the judges' views on the underlying ethical questions, questions on which there is a
legitimate division of opinion. He proceeded to state that where a case raises wholly new moral and
social issues, it is neither for the judges to develop new principles of law nor would it be legitimate
for the Judges to arrive at a conclusion as to what is for the benefit of one individual whose life is in
issue.
72. For the said reasons, the learned Law Lord observed that it is imperative that the moral, social
and legal issues raised by the case at hand should be considered by the Parliament and only if the
Parliament fails to act, the judge-made law will, by necessity, provide a legal answer to each new
question as and when it arises.
73. The function of the court, in Lord Browne-Wilkinson's view, in such circumstances is to
determine a particular case in accordance with the existing law and not to develop new law laying
down a new regimen. He held that it is for the Parliament to address the wider problems which such
a case raises and lay down principles of law generally applicable to the withdrawal of life support
systems. He explained why the removal of the nasogastric tube in the present case could not be
regarded as a positive act causing death since the tube itself, without the food being supplied
through it, does nothing. The removal of the tube by itself does not cause death since it does not
sustain life by itself. Therefore, the removal of the tube would not constitute the actus reus of
murder since such positive act would not be the cause of death.
74. Thus, Lord Browne-Wilkinson observed that in case of an adult who is mentally competent, the
artificial feeding regime would be unlawful unless the patient consented to it as a mentally
competent patient can, at any time, put an end to life support systems by refusing his consent to
their continuation. He also observed that the House of Lords in West Berkshire Health Authority
(supra) developed the principle based on the concept of necessity under which a doctor can lawfully
treat a patient who cannot consent to such treatment if it is in the best interests of the patient to
receive such treatment. The learned Law Lord opined that the correct answer to the case at hand
depends on the extent of the right to lawfully continue to invade the bodily integrity of Anthony
Bland without his consent. To determine the extent of the said right, Lord Browne-Wilkinson
observed that it can be deduced from West Berkshire Health Authority (supra) wherein both Lord
Brandon of Oakbrook and Lord Goff made it clear that the right to administer invasive medical care
is wholly dependent upon such care being in the best interests of the patient and moreover, a
doctor's decision whether to continue invasive care is in the best interests of the patient has to be
assessed with reference to the test laid down in Bolam (supra).
75. Lord Browne-Wilkinson held that if there comes a stage where a responsible doctor comes to the
reasonable conclusion (which accords with the views of a responsible body of medical opinion) thatCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

further continuance of an intrusive life support system is not in the best interests of the patient, the
doctor can no longer lawfully continue that life support system as to do so would constitute the
crime of battery and the tort of trespass.
76. In Lord Browne-Wilkinson‘s view, the correct legal question in such cases is not whether the
court thinks it is in the best interests of the patient in PVS to continue to receive intrusive medical
care but whether the doctor responsible has arrived at a reasonable and bona fide belief that it is not
in the best interests of the patient to continue to receive artificial medical regime.
77. Accordingly, Lord Browne-Wilkinson observed that on an application to the court for a
declaration that the discontinuance of medical care will be lawful, the sole concern of the courts is to
be satisfied that the doctor's decision to discontinue is in accordance with a respectable body of
medical opinion and that it is reasonable. Adverting to various passages, Lord Browne-Wilkinson
dismissed the appeal.
78. It is pertinent to mention here that in adopting the ―best interests principle in Airedale, the
House of Lords followed its earlier decision in In re F (Mental Patient :
Sterilisation] 25 and in adopting the omission/commission distinction, it followed
the approach of the Court of Appeal in [1990] 2 AC 1 : [1989] 2 WLR 1025 : [1989] 2
All ER 545 In re B (A Minor) (Wardship : Medical Treatment)26 and In re J (A
Minor) (Wardship : Medical Treatment) 27 which raised the question of medical
treatment for severely disabled children. In the context of cases where the patients
are unable to communicate their wishes, it is pertinent to mention the observations
made by Lord Goff in the Airedale case. As observed by Lord Goff, the correct
question in cases of this kind would be ―whether it is in his best interests that
treatment which has the effect of artificially prolonging his life should be continued.
Thus, it was settled in the case of Airedale that it was lawful for the doctors to
discontinue treatment if the patient refuses such treatment. And in case the patient is
not in a situation permitting him to communicate his wishes, then it becomes the
responsibility of the doctor to act in the ―best interest of the patient.
H.1.2 Later cases:
79. With reference to the ongoing debate pertaining to assisted dying, Lord Steyn in
the case of R (on the [1981] 1 WLR 1424 : [1990] 3 All ER 927 [1991] Fam 33 : [1990]
3 All ER 930 : [1991] 2 WLR 140 application of Pretty) v. Director of Public
Prosecutions28 explained that on one hand is the view which finds support in the
Roman Catholic Church, Islam and other religions that human life is sacred and the
corollary is that euthanasia and assisted suicide are always wrong, while on the other
hand, as observed by Lord Steyn, is the belief defended by millions that the personal
autonomy of individuals is predominant and it is the moral right of individuals to
have a say over the time and manner of their death. Taking note of the imminent risk
in legalizing assisted dying, Lord Steyn took note of the utilitarian argument that theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

terminally ill patients and those suffering great pain from incurable illnesses are
often vulnerable and not all families, whose interests are at stake, are wholly
unselfish and loving and there exists the probability of abuse in the sense that such
people may be persuaded that they want to die or that they ought to want to die.
Further, Lord Steyn observed that there is also the view that if the genuine wish of a
terminally ill patient to die is expressed by the patient, then they should not be forced
against their will to [2002] 1 All ER 1 : [2001] UKHL 61 endure a life that they no
longer wish to endure. Without expressing any view on the unending arguments on
either side, Lord Steyn noted that these wide-ranging arguments are ancient
questions on which millions have taken diametrically opposite views and still
continue to do. In the case of In re B (Consent to Treatment – Capacity)29, the
primacy of patient autonomy, that is, the competent patient‘s right to decide for
herself whether to submit to medical treatment over other imperatives, such as her
best interests objectively considered, was recognized thereby confirming the right of
the competent patient to refuse medical treatment even if the result is death and
thus, a competent, ventilator-dependent patient sought and won the right to have her
ventilator turned off.
80. Taking a slightly divergent view from Airedale, Lord Neuberger in R (on the
application of Nicklinson and another) v. Ministry of Justice30 observed that the
difference between administering fatal drug to a person and setting up a machine so
that the person can administer the drug to himself is not merely a legal distinction
but also a moral one and, [2002] 1 FLR 1090 : [2002] 2 All ER 449 [2014] UKSC 38
indeed, authorizing a third party to switch off a person‘s life support machine, as in
Airedale, is a more drastic interference and a more extreme moral step than
authorizing a third party to set up a lethal drug delivery system to enable a person,
only if he wishes, to activate the system to administer a lethal drug. Elaborating
further on this theory, the Law Lord explained that in those cases which are classified
as ―omission, for instance, switching off a life support machine as in Airedale and
Re B (Treatment), the act which immediately causes death is that of a third party
which may be wrong whereas if the final act is that of a person who himself carries it
out pursuant to a voluntary, clear, settled and informed decision, that may be the
permissible side of the line as in the latter case, the person concerned had not been
―killed by anyone but had autonomously exercised his right to end his life. The Law
Lord, however, immediately clarified that it is not intended to cast any doubt on the
correctness of the decisions in Airedale and Re B (Treatment).
81. Suffice it to say, he concurred with the view in Airedale case which he referred to
as Bland case. Lord Mance agreed with Lord Neuberger and Lord Sumption. In his
opinion, he referred to Airedale case and thereafter pointed out that a blanket
prohibition was unnecessary and stated in his observations that persons in tragic
position represent a distinct and relatively small group, and that by devising a
mechanism enabling careful prior review (possibly involving the Court as well as
medical opinion), the vulnerable can be distinguished from those capable of formingCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

a free and informed decision to commit suicide. Lord Mance acknowledged that the
law and courts are deeply engaged in the issues of life and death and made a
reference to the observations of Lord Neuberger.
82. We may note with profit that the prayer of Mr. Nicklinson and Mr. Lamb were
rejected by the Court of Appeal.
83. Lord Mance referred to the expression by Rehnquist CJ in Washington (supra) in
a slightly different context that there is ―an earnest and profound debate about the
morality, legality, and practicality of …. assisted suicide and ―our holding permits
this debate to continue as it should in a democratic society.
84. Lord Wilson concurred with the judgment rendered by Lord Neuberger, referred
to Airedale case and said:-
―As Hoffmann LJ suggested in his classic judgment in the Court of Appeal in
Airedale NHS Trust v Bland [1993] AC 789 at 826, a law will forfeit necessary support
if it pays no attention to the ethical dimension of its decisions. In para 209 below
Lord Sumption quotes Hoffmann LJ‘s articulation of that principle but it is worth
remembering that Hoffmann LJ then proceeded to identify two other ethical
principles, namely those of individual autonomy and of respect for human dignity,
which can run the other way. And further:-
―In the Pretty case, at para 65, the ECHR was later to describe those principles as of
the very essence of the ECHR. It was in the light (among other things) of the force of
those two principles that in the Bland case the House of Lords ruled that it was lawful
in certain circumstances for a doctor not to continue to provide life-sustaining
treatment to a person in a persistent vegetative state…
200. I agree with the observation of Lord Neuberger at para 94 that, in sanctioning a
course leading to the death of a person about which he was unable to have a voice, the
decision in the Bland case was arguably more extreme than any step which might be
taken towards enabling a person of full capacity to exercise what must, at any rate
now, in the light of the effect given to article 8 of the ECHR in the Haas case at para
51, cited at para 29 above, be regarded as a positive legal right to commit suicide.
Lord Sumption suggests in para 212-213 below that it remains morally wrong and contrary to public
policy for a person to commit suicide. Blackstone, in his Commentaries on the Laws of England,
Book 4, Chapter 14, wrote that suicide was also a spiritual offence ―in evading the prerogative of the
Almighty, and rushing into his immediate presence uncalled for. If expressed in modern religious
terms, that view would still command substantial support and a moral argument against committing
suicide could convincingly be cast in entirely non-religious terms. Whether, however, it can be
elevated into an overall conclusion about moral wrong and public policy is much more difficult.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

85. Lord Sumption commenced the judgment stating that English judges tend to avoid addressing
the moral foundations of law. It is not their function to lay down principles of morality and the
attempt leads to large generalisations which are commonly thought to be unhelpful. He further
observed that in some cases, however, it is unavoidable and this is one of them. He referred to the
opinion of Hoffmann LJ in Airedale case and the concept of sanctity of life and, eventually,
reproduced a passage from Hoffmann LJ and opined:-
―215. Why should this be so? There are at least three reasons why the moral position
of the suicide (whom I will call ―the patient from this point on, although the term
may not always be apt) is different from that of a third party who helps him to kill
himself. In the first place, the moral quality of their decisions is different. A desire to
die can only result from an overpowering negative impulse arising from perceived
incapacity, failure or pain. This is an extreme state which is unlikely to be shared by
the third party who assists. Even if the assister is moved by pure compassion, he
inevitably has a greater degree of detachment. This must in particular be true of
professionals such as doctors, from whom a high degree of professional objectivity is
expected, even in situations of great emotional difficulty. Secondly, whatever right a
person may have to put an end to his own life depends on the principle of autonomy,
which leaves the disposal of his life to him. The right of a third party to assist cannot
depend on that principle. It is essentially based on the mitigating effect of his
compassionate motive. Yet not everyone seeking to end his life is equally deserving of
compassion. The choice made by a person to kill himself is morally the same whether
he does it because he is old or terminally ill, or because he is young and healthy but
fed up with life. In both cases his desire to commit suicide may be equally justified by
his autonomy. But the choice made by a third party who intervenes to help him is
very different. The element of compassion is much stronger in the former category
than in the latter. Third, the involvement of a third party raises the problem of the
effect on other vulnerable people, which the unaided suicide does not. If it is lawful
for a third party to encourage or assist the suicide of a person who has chosen death
with a clear head, free of external pressures, the potential arises for him to encourage
or assist others who are in a less good position to decide. Again, this is a more
significant factor in the case of professionals, such as doctors or carers, who
encounter these dilemmas regularly, than it is in the case of, say, family members
confronting them for what will probably be the only time in their lives.
86. Dealing with the appeal by Nicklinson, Lord Sumption referred to the view of the Canadian
Supreme Court in Rodriguez (supra) and opined:-
―….the issue is an inherently legislative issue for Parliament, as the representative
body in our constitution, to decide. The question what procedures might be available
for mitigating the indirect consequences of legalising assisted suicide, what risks such
procedures would entail, and whether those risks are acceptable, are not matters
which under our constitution a court should decide.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

87. Dealing with Martin‘s appeal, Lord Sumption dismissed the same. While doing so, he said:-
―256. This state of English law and criminal practice does not of course resolve all of
the problems arising from the pain and indignity of the death which was endured by
Tony Nicklinson and is now faced by Mr Lamb and Martin. But it is worth reiterating
these well-established propositions, because it is clear that many medical
professionals are frightened by the law and take an unduly narrow view of what can
lawfully be done to relieve the suffering of the terminally ill under the law as it
presently stands. Much needless suffering may be occurring as a result. It is right to
add that there is a tendency for those who would like to see the existing law changed,
to overstate its difficulties. This was particularly evident in the submissions of Dignity
and Choice in Dying. It would be unfortunate if this were to narrow yet further the
options open to those approaching death, by leading them to believe that the current
law and practice is less humane and flexible than it really is.
88. Lord Hughes agreed with the reasoning of Lord Sumption and dismissed the private appeals and
allowed the Appeals preferred by the Director of Public Prosecutions. Lord Clarke concurred with
the reasoning given by Lord Sumption, Lord Reed and Lord Hughes. Lord Reed agreed with the
view with regard to the dismissal of the appeals but observed some aspects with regard to the issue
of compatibility.
89. Lord Lady Hale entirely agreed with the judgment of Lord Neuberger. Lord Kerr in his opinion
stated:-
―358. I agree with Lord Neuberger that if the store put on the sanctity of life cannot
justify a ban on suicide by the able-bodied, it is difficult to see how it can justify
prohibiting a physically incapable person from seeking assistance to bring about the
end of their life. As one of the witnesses for one of the interveners, the British
Humanist Association, Professor Blackburn, said, there is ‗no defensible moral
principle‘ in denying the appellants the means of achieving what, under article 8 and
by all the requirements of compassion and humanity, they should be entitled to do.
To insist that these unfortunate individuals should continue to endure the misery
that is their lot is not to champion the sanctity of life; it is to coerce them to endure
unspeakable suffering. And again:-
―360. If one may describe the actual administration of the fatal dose as active
assistance and the setting up of a system which can be activated by the assisted
person as passive assistance, what is the moral objection to a person actively assisting
someone‘s death, if passive assistance is acceptable? Why should active assistance
give rise to moral corruption on the part of the assister (or, for that matter, society as
a whole), but passive assistance not? In both cases the assister‘s aid to the person
who wishes to die is based on the same conscientious and moral foundation. That it is
that they are doing what the person they assist cannot do; providing them with the
means to bring about their wished-for death. I cannot detect the moral distinctionCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

between the individual who brings a fatal dose to their beloved‘s lips from the person
who sets up a system that allows their beloved to activate the release of the fatal dose
by the blink of an eye. Eventually, Lady Hale dismissed the appeal and allowed the
appeals of the Director of Public Prosecutions.
H.2 The legal position in the United States:
90. In the United States of America, active euthanasia is illegal but physician-assisted death is legal
in the States of Oregon, Washington and Montana. A distinction has been drawn between
euthanasia and physician-assisted suicide. In both Oregon and Washington, only self-assisted dying
is permitted. Doctor-administered assisted dying and any form of assistance to help a person
commit suicide outside the provisions of the legislation remains a criminal offence.
91. As far as the United States of America is concerned, we think it appropriate to refer to Cruzan
(supra). The said case involved a 30 year old Missouri woman who was lingering in a permanent
vegetative state as a result of a car accident. Missouri requires 'clear and convincing evidence' of
patients' preferences and the Missouri Supreme Court, reversing the decision of the state trial court,
rejected the parents' request to impose a duty on their daughter's physician to end life- support. The
United States Supreme Court upheld that States can require 'clear and convincing evidence' of a
patient's desire in order to oblige physicians to respect this desire. Since Nancy Cruzan had not
clearly expressed her desire to terminate life support in such a situation, physicians were not obliged
to follow the parents' request.
92. Chief Justice Rehnquist, in his opinion, stated:-
―Every human being of adult years and sound mind has a right to determine what
shall be done with his own body, and a surgeon who performs an operation without
his patient's consent commits an assault, for which he is liable in damages. He
further proceeded to state:-
―The logical corollary of the doctrine of informed consent is that the patient generally
possesses the right not to consent, that is, to refuse treatment. Until about 15 years
ago and the seminal decision in In re Quinlan, 70 N.J. 10, 355 A.2d 647, cert. denied
sub nom. Garger v. New Jersey, 429 U.S. 922 (1976), the number of
right-to-refuse-treatment decisions were relatively few. Most of the earlier cases
involved patients who refused medical treatment forbidden by their religious beliefs,
thus implicating First Amendment rights as well as common law rights of
self-determination. More recently, however, with the advance of medical technology
capable of sustaining life well past the point where natural forces would have brought
certain death in earlier times, cases involving the right to refuse life-sustaining
treatment have burgeoned.
93. Meeting the submissions on behalf of the petitioner, the learned Chief Justice opined:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

―The difficulty with petitioners' claim is that, in a sense, it begs the question: an
incompetent person is not able to make an informed and voluntary choice to exercise
a hypothetical right to refuse treatment or any other right. Such a "right" must be
exercised for her, if at all, by some sort of surrogate. Here, Missouri has in effect
recognized that, under certain circumstances, a surrogate may act for the patient in
electing to have hydration and nutrition withdrawn in such a way as to cause death,
but it has established a procedural safeguard to assure that the action of the surrogate
conforms as best it may to the wishes expressed by the patient while competent.
Missouri requires that evidence of the incompetent's wishes as to the withdrawal of
treatment be proved by clear and convincing evidence. The question, then, is whether
the United States Constitution forbids the establishment of this procedural
requirement by the State. We hold that it does not.
94. The learned Chief Justice came to hold that there was no clear and convincing evidence to prove
that the patient‘s desire was not to have hydration and nutrition. In the ultimate analysis, it was
stated:-
―No doubt is engendered by anything in this record but that Nancy Cruzan's mother
and father are loving and caring parents. If the State were required by the United
States Constitution to repose a right of "substituted judgment" with anyone, the
Cruzans would surely qualify. But we do not think the Due Process Clause requires
the State to repose judgment on these matters with anyone but the patient herself.
Close family members may have a strong feeling -- a feeling not at all ignoble or
unworthy, but not entirely disinterested, either -- that they do not wish to witness the
continuation of the life of a loved one which they regard as hopeless, meaningless,
and even degrading. But there is no automatic assurance that the view of close family
members will necessarily be the same as the patient's would have been had she been
confronted with the prospect of her situation while competent. All of the reasons
previously discussed for allowing Missouri to require clear and convincing evidence
of the patient's wishes lead us to conclude that the State may choose to defer only to
those wishes, rather than confide the decision to close family members. The
aforesaid decision has emphasized on ―bodily integrity and ―informed consent.
95. The question that was presented before the Court was whether New York‘s prohibition on
assisted suicide violates the Equal Protection Clause of the Fourteenth Amendment. The Court held
that it did not and in the course of the discussion, Chief Justice Rehnquist held:-
―The Court of Appeals, however, concluded that some terminally ill people—those
who are on life- support systems— are treated differently from those who are not, in
that the former may ―hasten death by ending treatment, but the latter may not
―hasten death through physician-assisted suicide. 80 F. 3d, at 729. This conclusion
depends on the submission that ending or refusing lifesaving medical treatment ―is
nothing more nor less than assisted suicide. Ibid. Unlike the Court of Appeals, we
think the distinction between assisting suicide and withdrawing life-sustainingCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

treatment, a distinction widely recognized and endorsed in the medical profession 6
and in our legal traditions, is both important and logical; it is certainly rational.
Dealing with the conclusion in Cruzan (supra), it was held:-
―This Court has also recognized, at least implicitly, the distinction between letting a
patient die and making that patient die. In Cruzan v. Director, Mo. Dept. of Health,
497 U. S. 261, 278 (1990), we concluded that ―[t]he principle that a competent
person has a constitutionally protected liberty interest in refusing unwanted medical
treatment may be inferred from our prior decisions, and we assumed the existence
of such a right for purposes of that case, id., at 279. But our assumption of a right to
refuse treatment was grounded not, as the Court of Appeals supposed, on the
proposition that patients have a general and abstract ―right to hasten death, 80 F.
3d, at 727–728, but on well- established, traditional rights to bodily integrity and
freedom from unwanted touching, Cruzan, 497 U. S., at 278–279; id., at 287– 288
(O‘Connor, J., concurring). In fact, we observed that ―the majority of States in this
country have laws imposing criminal penalties on one who assists another to commit
suicide. Id., at 280. Cruzan therefore provides no support for the notion that
refusing life- sustaining medical treatment is ―nothing more nor less than suicide.
From the aforesaid passages, it is crystal clear that the U.S. Supreme Court has
recognized that there is a distinction, in the context of the prevalent law, between
letting a patient die and making that patient die. Right to refuse treatment is not
grounded on the proposition that the patients have general and abstract right to
hasten death. The learned Chief Justice has also endorsed the view of the American
Medical Association emphasizing the fundamental difference between refusing
life-sustaining treatment and demanding a life-ending treatment.
96. In Vacco (supra), while ruling that a New York ban on physician assisted suicide was
constitutional, the Supreme Court of the United States applied the standard of intent to the matter
finding that a doctor who withdraws life support at the request of his patient intends only to respect
his patient‘s wishes. This, the Court said, is in sharp contrast to a doctor who honours a patient‘s
request to end life which necessarily requires more than an intent to respect the patient‘s wishes,
i.e., it requires the intent to kill the patient. A major difference, the Court determined, in the two
scenarios is that the former may cause the patient to die from underlying causes while the latter will
cause the patient to die. The Court noted that the law plainly recognized the difference between
―killing and ―letting die. It also recognised that the State of New York had, as a matter of policy, a
compelling interest in forbidding assisted suicide, while allowing a patient to refuse life support was
simply an act of protecting a common law right which was the right to retain bodily integrity and
preserve individual antonomy since the prevention of ―unwanted touching was, in the opinion of
the Court, a very legitimate right to protect. H.3 Australian Jurisdiction:
97. Moving to Australian jurisdiction, in Hunter and New England Area Health Service v. A31, the
Supreme Court of New South Wales considered the validity of a common law advance directive
(there being no legislative provisions for such directives in NSW) given by Mr. A refusing kidney
dialysis. One year after making the directive, Mr. A was admitted to a hospital emergencyCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

department in a critical state with decreased level of consciousness. His condition deteriorated to
the point that he was being kept alive by mechanical ventilation and kidney dialysis. The hospital
sought a judicial declaration to determine the validity of his advance directive. The Court, speaking
through McDougall J., confirmed the directive and held that the hospital must respect the advance
[2009] NSWSC 761 directive. Applying the common law principle, the Court observed:-
―A person may make an 'advance care directive': a statement that the person does not
wish to receive medical treatment, or medical treatment of specified kinds. If an
advance care directive is made by a capable adult, and it is clear and unambiguous,
and extends to the situation at hand, it must be respected. It would be a battery to
administer medical treatment to the person of a kind prohibited by the advance care
directive.
98. In Brightwater Care Group (Inc.) v. Rossiter 32 , the Court was concerned with an anticipatory
refusal of treatment by Mr. Rossiter, a man with quadriplegia who was unable to undertake any
basic human function including taking nutrition or hydration orally. Mr. Rossiter was not terminally
ill, dying or in a vegetative state and had full mental capacity. He had ‗clearly and unequivocally‘
indicated that he did not wish to continue to receive medical treatment which, if discontinued,
would inevitably lead to his death. Martin, CJ, considering the facts and the common law principle,
held :-
―At common law, the answers to the questions posed by this case are clear and
straightforward.
[2009] WASC 229 : 40 WAR 84 They are to the effect that Mr Rossiter has the right
to determine whether or not he will continue to receive the services and treatment
provided by Brightwater and, at common law, Brightwater would be acting
unlawfully by continuing to provide treatment [namely the administration of
nutrition and hydration via a tube inserted into his stomach] contrary to Mr
Rossiter's wishes.
99. In Australian Capital Territory v. JT33, an application to stop medical treatment, other than
palliative care, was rejected. The man receiving treatment suffered from paranoid schizophrenia and
was, therefore, held not mentally capable of making a decision regarding his treatment. Chief
Justice Higgins found that it would be unlawful for the service providers to stop providing
treatment. The Chief Justice distinguished this situation from Rossiter as the patient lacked ‗both
understanding of the proposed conduct and the capacity to give informed consent to it‘. It is clear
that mental capacity is the determining factor in cases relating to self- determination. Since the right
of self-determination requires the ability to make an informed choice about the future, the
requirement of mental capacity would be an obvious prerequisite. Chief Justice Higgins undertook a
detailed [2009] ACTSC 105 analysis and rightly distinguished Auckland Area Health Board v.
Attorney-General34 in which a court similarly bound to apply the human right to life and the
prohibition on cruel and degrading treatment found that futile treatment could be withdrawn from a
patient in a persistent vegetative state. He agreed with Howie J. in Messiha v. South East Health35Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

that futility of treatment could only be determined by consideration of the best interests of the
patient and not by reference to the convenience of medical cares or their institutions.
100. The above decision basically considered the circumstances in which technically futile treatment
may be withdrawn from patients at their direct or indirect request or in their best interests.
H.4 Legal Position in Canada:
101. In Canada, physician-assisted suicide is illegal as per Section 241(b) of the Criminal Code of
Canada. The Supreme Court of Canada in Rodriguez (supra) has drawn a distinction between
―intentional actor and ―merely foreseeing. Delivering the judgment on behalf of the majority,
Justice [1993] NZLR 235 [2004] NSWSC 1061 Sopinka rejected the argument that assisted suicide
was similar to the withdrawal of life-preserving treatment at the patient‘s request. He also rejected
the argument that the distinction between assisted suicide and accepted medical treatment was even
more attenuated in the case of palliative treatment which was known to hasten death. He observed:-
―The distinction drawn here is one based upon intention - in the case of palliative
care the intention is to ease pain, which has the effect of hastening death, while in the
case of assisted suicide, the intention is undeniably to cause death. He added:-
―In my view, distinctions based on intent are important, and in fact form the basis of
our criminal law. While factually the distinction may, at times, be difficult to draw,
legally it is clear.
102. The Supreme Court of Canada in Carter v. Canada (Attorney General)36 held that the
prohibition on physician- assisted death in Canada (in Sections 14 and 241(b) of the Canadian
Criminal Code) unjustifiably infringed the right to life, liberty and security of the person in Article 7
of the Charter of Rights and Freedoms in the Canadian Constitution.
2015 SCC 5
103. The Supreme Court declared the infringing provisions of the Criminal Code void insofar as they
prohibit physician- assisted death for a competent adult person who (1) clearly consents to the
termination of life; and (2) has a grievous and irremediable medical condition (including an illness,
disease or disability) that causes enduring suffering that is intolerable to the individual in the
circumstances of his or her condition. ‗Irremediable‘, it should be added, does not require the
patient to undertake treatments that are not acceptable to the individual.
104. After the Supreme Court‘s decision, the Canadian Government appointed a Special Joint
Committee on Physician-Assisted Dying to ‗make recommendations on the framework of a federal
response on physician assisted dying in consonance with the Constitution, the Charter of Rights and
Freedoms, and the priorities of Canadians‘. The Special Joint Committee released its report in
February 2016 recommending a legislative framework which would regulate ‗medical assistance in
dying‘ by imposing both substantive and procedural safeguards, namely:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Substantive Safeguards:
 A grievous and irremediable medical condition (including an illness, disease or
disability) is required;
 Enduring suffering that is intolerable to the individual in the circumstances of his
or her condition is required;
 Informed consent is required;
 Capacity to make the decision is required at the time of either the advance or
contemporaneous request; and  Eligible individuals must be insured persons
eligible for publicly funded health care services in Canada.
Procedural Safeguards:
 Two independent doctors must conclude that a person is eligible;
 A request must be in writing and witnessed by two independent witnesses;
 A waiting period is required based, in part, on the rapidity of progression and
nature of the patient‘s medical condition as determined by the patient‘s attending
physician;
 Annual report analyzing medical assistance in dying cases are to be tabled in
Parliament;
and  Support and services, including culturally and spiritually appropriate
end-of-life care services for indigenous patients, should be improved to ensure that
requests are based on free choice, particularly for vulnerable people.
105. It should be noted that physician assisted dying has already been legalized in the province of
Quebec. Quebec passed an Act respecting end-of-life care (the Quebec Act) in June 2014 with most
of the Act coming into force on 10 December, 2015. The Quebec Act provides a ‗framework for
end-of-life care‘ which includes ‗continuous palliative sedation‘ and ‗medical aid in dying‘ defined
as ‗administration by a physician of medications or substances to an end-of-life patient, at the
patient‘s request, in order to relieve their suffering by hastening death. In order to be able to access
medical aid in dying under the Quebec Act, a patient must:-
(1) be an insured person within the meaning of the Health Insurance Act (Chapter
A-29);
(2) be of full age and capable of giving consent to care;Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(3) be at the end of life;
(4) suffer from a serious and incurable illness;
(5) be in an advanced state of irreversible decline in capability; and (6) experience
constant and unbearable physical or psychological suffering (7) which cannot be
relieved in a manner the patient deems tolerable.
106. The request for medical aid in dying must be signed by two physicians. The Quebec Act also
established a Commission on end-of-life care to provide oversight and advice to the Minister of
Health and Social Services on the implementation of the legislation regarding end-of-life care. H.5
Other Jurisdictions:
107. Presently, we think it appropriate to deal with certain legislations in other countries and the
decisions in other jurisdictions. In Aruna Shanbaug, the Court has in detail referred to the
legislations in Netherlands, i.e., the Termination of Life on Request and Assisted Suicide (Review
Procedures) Act, 2002 that regulates euthanasia. The provisions of the said Act lay down that
euthanasia and physician-assisted suicide are not punishable if the attending physician acts in
accordance with the criteria of due care. As the two-Judge Bench has summarized, this criteria
concern the patient‘s request, the patient‘s suffering (unbearable and hopeless), the information
provided to the patient, the presence of reasonable alternatives, consultation of another physician
and the applied method of ending life. To demonstrate their compliance, the Act requires physicians
to report euthanasia to a Review Committee. It has been observed that the said Act legalizes
euthanasia and physician- assisted suicide in very specific cases under three specific conditions and
euthanasia remains a criminal offence in cases not meeting the laid down specific conditions with
the exception of several situations that are not subject to restrictions of law at all because they are
considered normal medical practice. The three conditions are : stopping or not starting a medically
useless (futile) treatment, stopping or not starting a treatment at the patient‘s request and speeding
up death as a side effect of treatment necessary for alleviating serious suffering.
108. Reference has been made to the Swiss Criminal Code where active euthanasia has been
regarded as illegal. Belgium has legalized the practice of euthanasia with the enactment of the
Belgium Act on Euthanasia of May 28th, 2002 and the patients can wish to end their life if they are
under constant and unbearable physical or psychological pain resulting from an accident or an
incurable illness. The Act allows adults who are in a ‗futile medical condition of constant and
unbearable physical or mental suffering that cannot be alleviated‘ to request voluntary euthanasia.
Doctors who practise euthanasia commit no offence if the prescribed conditions and procedure is
followed and the patient has the legal capacity and the request is made voluntarily and repeatedly
with no external pressure.
109. Luxembourg too has legalized euthanasia with the passing of the Law of 16th March, 2009 on
Euthanasia and Assisted Suicide (Lux.). The law permits euthanasia and assisted suicide in relation
to those with incurable conditions with the requirements including repeated requests and the
consent of two doctors and an expert panel.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

110. The position in Germany is that active assisted suicide is illegal. However, this is not the case
for passive assisted suicide. Thus, in Germany, if doctors stop life-prolonging measures, for
instance, on the written wishes of a patient, it is not considered as a criminal offence. That apart, it
is legal for doctors in Germany to administer painkillers to a dying patient to ease pain. The said
painkillers, in turn, cause low breathing that may lead to respiratory arrest and, ultimately, death.
H.6 International considerations and decisions of the European Court of Human Rights (ECHR):
111. Certain relevant obligations when discussing voluntary euthanasia are contained in the
International Covenant on Civil and Political Rights (ICCPR). The following rights in the ICCPR
have been considered by the practice of voluntary euthanasia:
 right to life (Article 6)  freedom from cruel, inhuman or degrading treatment
(Article 7)  right to respect for private life (Article 17)  freedom of thought,
conscience and religion (Article 18).
112. Right to life under Article 6(1) of the ICCPR provides:
Every human being has the inherent right to life. This right shall be protected by law.
No one shall be arbitrarily deprived of his life. The second sentence of Article 6(1)
imposes a positive obligation on the States to provide legal protection of the right to
life. However, the subsequent reference to life not being ‗arbitrarily deprived‘
operates to limit the scope of the right (and therefore the States‘ duty to ensure the
right).
Comments from the UN Human Rights Committee suggest that laws allowing for
voluntary euthanasia are not necessarily incompatible with the States‘ obligation to
protect the right to life.
113. The UN Human Rights Committee has emphasised that laws allowing for euthanasia must
provide effective procedural safeguards against abuse if they are to be compatible with the State‘s
obligation to protect the right to life. In 2002, the UN Committee considered the euthanasia law
introduced in the Netherlands. The Committee stated that:-
―where a State party seeks to relax legal protection with respect to an act deliberately
intended to put an end to human life, the Committee believes that the Covenant
obliges it to apply the most rigorous scrutiny to determine whether the State party‘s
obligations to ensure the right to life are being complied with (articles 2 and 6 of the
Covenant).
114. The European Court of Human Rights (ECHR) has adopted a similar position to the UN Human
Rights Committee when considering euthanasia laws and the right to life in Article 2 of the
European Convention for the Protection of Human Rights and Fundamental Freedoms (European
Convention). According to the ECHR, the right to life in Article 2 cannot be interpreted asCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

conferring a right to die or a right to self determination in terms of choosing death rather than life.
However, the ECHR has held that a State‘s obligation to protect life under that Article does not
preclude it from legalising voluntary euthanasia, provided adequate safeguards are put in place and
adhered to. In Pretty v. United Kingdom (application no. 2346/02) 37 , the ECHR ruled that the
decision of the applicant to avoid what she considered would be an undignified and distressing end
to her life was part of the private sphere covered by the scope of Article 8 of the Convention. The
Court affirmed that the right of an individual to decide how and when to end her life, provided that
the said individual was in a position to make up her own mind in that respect and to take the
appropriate action, was one aspect of the right to respect for private life under Article 8 of the
Convention. The Court, thus, recognised, with conditions, a [2002] ECHR 423 (29 April, 2002) sort
of right to self-determination as to one‘s own death, but the existence of this right is subject to two
conditions, one linked to the free will of the person concerned and the other relating to the capacity
to take appropriate action. However, respect for the right to life compels the national authorities to
prevent a person from putting an end to life if such a decision is not taken freely and with full
knowledge.
115. In Hass v. Switzerland (application no. 31322/07)38, the ECHR explained that:-
―creates for the authorities a duty to protect vulnerable persons, even against actions
by which they endanger their own lives… this latter Article obliges the national
authorities to prevent an individual from taking his or her own life if the decision has
not been taken freely and with full understanding of what is involved.
Accordingly, the ECHR concluded that:-
―the right to life guaranteed by Article 2 of the Convention obliges States to establish
a procedure capable of ensuring that a decision to end one‘s life does indeed
correspond to the free will of the individual concerned. [2011] ECHR 2422: (2011)
53 EHRR 33
116. In a recent decision regarding end of life issues, Lambert and others v. France (application no.
46043/14) 39 , the ECHR considered whether the decision to withdraw artificial nutrition and
hydration of Vincent Lambert violated the right to life in Article 2. Vincent Lambert was involved in
a serious road accident which left him tetraplegic and with permanent brain damage. He was
assessed in expert medical reports as being in a chronic vegetative state that required artificial
nutrition and hydration to be administered via a gastric tube.
117. Mr. Lambert‘s parents applied to the ECHR alleging that the decision to withdraw his artificial
nutrition and hydration breached, inter alia, the State‘s obligations under Article 2 of the European
Convention. The ECHR highlighted that Article 2 imposes on the States both a negative obligation
(to refrain from the ‗intentional‘ taking of life) and a positive obligation (to ‗take appropriate steps
to safeguard the lives of those within its jurisdiction‘). The Court held that the decision of a doctor to
discontinue life-sustaining treatment (or ‗therapeutic abstention‘) did not involve the State‘s
negative obligation [2015] ECHR 185 under Article 2 and, therefore, the only question for the CourtCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

under Article 2 was whether it was consistent with the State‘s positive obligation.
118. The ECHR emphasized that ‗the Convention has to be read as a whole‘, and, therefore:-
―in a case such as the present one reference should be made, in examining a possible
violation of Article 2, to Article 8 of the Convention and to the right to respect for
private life and the notion of personal autonomy which it encompasses.
119. The Court noted that there was a consensus among European member States ‗as to the
paramount importance of the patient‘s wishes in the decision-making process, however those wishes
are expressed‘. It identified that in dealing with end of life situations, States have some discretion in
terms of striking a balance between the protection of the patients‘ right to life and the protection of
the right to respect their private life and their personal autonomy. The Court considered that the
provisions of the Law of 22 April 2005 ‗on patients‘ rights and the end of life‘ promulgated in
France making changes in the French Code of Public Health, as interpreted by the Conseil d’Etat,
constituted a legal framework which was sufficiently clear to regulate with precision the decisions
taken by doctors in situations such as in Mr. Lambert‘s case. The Court found the legislative
framework laid down by domestic law, as interpreted by the Conseil d’État, and the decision-
making process which had been conducted in meticulous fashion, to be compatible with the
requirements of the State‘s positive obligation under Article 2. With respect to negative obligations,
the ECHR observed that the ―therapeutic abstention (that is, withdrawal and withholding of
medical treatment) lacks the intention to end the patient‘s life and rather, a doctor discontinuing
medical treatment from his or her patient merely intends to ―allow death to resume its natural
course and to relieve suffering. Therefore, as long as therapeutic abstention as authorised by the
French Public Health Code is not about taking life intentionally, the ECHR opined that France had
not violated its negative obligation to ―refrain from the intentional taking of life.
120. When considering the State‘s positive obligations to protect human life, the ECHR noted that
the regulatory framework developed in the Public Health Code and the decision of the Conseil d’
Etat established several ―important safeguards with respect to therapeutic abstention and the
regulation is, therefore, ―apt to ensure the protection of patients‘ lives.
121. All this compelled the ECHR to conclude that there was no violation of the State‘s positive
obligation to protect human life which, together with the absence of violation of negative
obligations, resulted in the conclusion that ―there would be no violation of Article 2 of the
Convention in the event of implementation of the Conseil d’ Etat judgment. Thus, the ECHR in the
Lambert (supra) case struck the balance between the sanctity of life on the one hand and the notions
of quality of life and individual autonomy on the other.
I. The 241st Report of The Law Commission of India on Passive Euthanasia:
122. After the judgment of Aruna Shanbaug was delivered, the Law Commission of India submitted
its 241st report which dealt with ‗Passive Euthanasia – A Relook‘. The report in its introduction has
dealt with the origin of the concept of euthanasia. It states that the word ―Euthanasia is derivedCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

from the Greek words ―eu and ―thanotos which literally mean ―good death and is otherwise
described as ―mercy killing. The word euthanasia, as pointed out in the Report, was used by
Francis Bacon in the 17th Century to refer to an easy, painless and happy death as it is the duty and
responsibility of the physician to alleviate the physical suffering of the body of the patient. A
reference has also been made in the Report to the meaning given to the term by the House of Lords.
The Select Committee on ―Medical Ethics in England defined Euthanasia as ―a deliberate
intervention undertaken with the express intention of ending a life to relieve intractable suffering.
Impressing upon the voluntary nature of euthanasia, the report has rightly highlighted the
clarification as provided by the European Association of Palliative Care (EAPC) Ethics Task Force in
a discussion on Euthanasia in 2003 to the effect that ―medicalised killing of a person without the
person‘s consent, whether non-voluntary (where the person is unable to consent) or involuntary
(against the person‘s will) is not euthanasia: it is a murder.
123. The Commission in its report referred to the observations made by the then Chairman of the
Law Commission in his letter dated 28th August, 2006 addressed to the Hon‘ble Minister which was
extracted. It is pertinent to reproduce the same:-
―A hundred years ago, when medicine and medical technology had not invented the
artificial methods of keeping a terminally ill patient alive by medical treatment,
including by means of ventilators and artificial feeding, such patients were meeting
their death on account of natural causes. Today, it is accepted, a terminally ill person
has a common law right to refuse modern medical procedures and allow nature to
take its own course, as was done in good old times. It is well-settled law in all
countries that a terminally ill patient who is conscious and is competent, can take an
‗informed decision‘ to die a natural death and direct that he or she be not given
medical treatment which may merely prolong life. There are currently a large number
of such patients who have reached a stage in their illness when according to
well-informed body of medical opinion, there are no chances of recovery. But modern
medicine and technology may yet enable such patients to prolong life to no purpose
and during such prolongation, patients could go through extreme pain and suffering.
Several such patients prefer palliative care for reducing pain and suffering and do not
want medical treatment which will merely prolong life or postpone death.
124. The report rightly points out that a rational and humanitarian outlook should have primacy in
such a complex matter. Recognizing that passive euthanasia, both in the case of competent and
incompetent patients, is being allowed in most of the countries subject to the doctor acting in the
best interests of the patient, the report summarized the broad principles of medical ethics which
shall be observed by the doctor in taking the decision. The said principles as obtained in the report
are the patient‘s autonomy (or the right to self- determination) and beneficence which means
following a course of action that is best for the patient uninfluenced by personal convictions,
motives or other considerations. The Report also refers to the observations made by Lord Keith in
Airedale case providing for a course to safeguard the patient‘s best interest. As per the said course,
which has also been approved by this Court, the hospital/medical practitioner should apply to the
Family Division of the High Court for endorsing or reversing the decision taken by the medicalCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

practitioners in charge to discontinue the treatment of a PVS patient. With respect to the ongoing
debates on ―legalizing euthanasia, the Report reiterates the observations made in Airedale that
euthanasia (other than passive euthanasia) can be legalized by means of legislation only.
125. The Report, in upholding the principle of the patient‘s autonomy, went on to state:-
―…the patient (competent) has a right to refuse medical treatment resulting in
temporary prolongation of life. The patient‘s life is at the brink of extinction. There is
no slightest hope of recovery. The patient undergoing terrible suffering and worst
mental agony does not want his life to be prolonged by artificial means. She/he would
not like to spend for his treatment which is practically worthless. She/he cares for his
bodily integrity rather than bodily suffering. She/he would not like to live 28 like a
‗cabbage‘ in an intensive care unit for some days or months till the inevitable death
occurs. He would like to have the right of privacy protected which implies protection
from interference and bodily invasion. As observed in Gian Kaur‘s case, the natural
process of his death has already commenced and he would like to die with peace and
dignity. No law can inhibit him from opting such course. This is not a situation
comparable to suicide, keeping aside the view point in favour of decriminalizing the
attempt to suicide. The doctor or relatives cannot compel him to have invasive
medical treatment by artificial means or treatment.
126. The Report supports the view of several authorities especially Lord Browne-Wilkinson (in
Airedale case) and Justice Cardozo that in case of any forced medical intervention on the body of a
patient, the surgeon/doctor is guilty of ‗assault‘ or ‗battery‘. The Report also laid emphasis on the
opinion of Lord Goff placing the right of self-determination on a high pedestal. The said relevant
observations of Lord Goff, as also cited in the Report, are as follows:-
―I wish to add that, in cases of this kind, there is no question of the patient having
committed suicide, nor therefore of the doctor having aided or abetted him in doing
so. It is simply that the patient has, as he is entitled to do, declined to consent to
treatment which might or would have the effect of prolonging his life, and the doctor
has, in accordance with his duty, complied with his patient's wishes.
127. We have referred to the report of the Law Commission post Aruna Shanbaug only to highlight
that there has been affirmative thought in this regard. We have also been apprised by Mr.
Narasimha, learned Additional Solicitor General appearing for the Union of India, that there is
going to be a law with regard to passive euthanasia.
J. Right to refuse treatment:
128. Deliberating on the issue of right to refuse treatment, Justice Cardozo in Schloendorff v. Society
of New York Hospital40 observed:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

―Every human being of adult years and sound mind has a right to determine what
shall be done with his own body; and a surgeon who performs the operation without
his patient‘s consent commits an assault for which he is liable in damages.
129. In a somewhat different context, King C.J. in F v. R41 identified ―the paramount consideration
that a person is entitled to make his own decisions about his life. The said statement was cited with
approval by Mason CJ, Brennan, Dawson, Toohey and McHugh, JJ. in Rogers v. Whitaker42.
Cardozo‘s statement has been cited and applied in many cases. Thus, in Malette v. Shulman43,
Robins J.A., speaking with the concurrence of Catzman and Canthy JJA, said:-
―A competent adult is generally entitled to reject a specific treatment or all
treatment, or to select an alternative form of treatment even if the decision may entail
risks as serious as death and may (1914) 105 NE 92 : (1914) 211 NY 125 (1983) 33
SASR 189 at 193 [1992] HCA 58 : (1992) 175 CLR 479 at 487 43 th 67 DLR (4 ) 321
(1990) : 72 OR (2d) 417 appear mistaken in the eyes of the medical profession or of
the community …. it is the patient who has the final say on whether to undergo the
treatment.
130. The recognition of the freedom of competent adults to make choices about their medical care
necessarily encompasses recognition of the right to make choices since individual free choice and
self-determination are themselves fundamental constituents of life. Robins J.A. further clarified in
Malette at page 334:-
―To deny individuals freedom of choice with respect to their health care can only
lessen and not enhance the value of life.
131. In the 21st century, with the advancement of technology in medical care, it has become possible,
with the help of support machines, to prolong the death of patients for months and even years in
some cases. At this juncture, the right to refuse medical treatment comes into the picture. A patient
(terminally ill or in a persistent vegetative state) exercising the right to refuse treatment may
ardently wish to live but, at the same time, he may wish to be free from any medical surgery, drugs
or treatment of any kind so as to avoid protracted physical suffering. Any such person who has come
of age and is of sound mind has a right to refuse medical treatment. This right stands on a different
pedestal as compared to suicide, physician assisted suicide or even euthanasia. When a terminally ill
patient refuses to take medical treatment, it can neither be termed as euthanasia nor as suicide.
Albeit, both suicide and refusal to take treatment in case of terminal ailment shall result in the same
consequences, that is, death, yet refusal to take treatment by itself cannot amount to suicide. In case
of suicide, there has to be a self initiated positive action with a specific intention to cause one‘s own
death. On the other hand, a patient‘s right to refuse treatment lacks his specific intention to die,
rather it protects the patient from unwanted medical treatment. A patient refusing medical
treatment merely allows the disease to take its natural course and if, in this process, death occurs,
the cause for it would primarily be the underlying disease and not any self initiated act.
132. In Rodriguez (supra), Justice Sopinka, speaking for the Supreme Court of Canada, held:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

―Canadian Court has recognized a common law right of patients to refuse to consent
to medical treatment or to demand that the treatment, once commenced, be
withdrawn or discontinued. This right has been specially recognized to exist even if
the withdrawal from or refusal of treatment may result in death.
133. In Secretary, Department of Health and Community Services (NT) v. JWB and SMB44, the
High Court of Australia acknowledged the fundamental right of personal inviolability. Justice
McHugh observed that the voluntary decision of an adult person of sound mind as to what should be
done to his or her body must be respected. It was further observed that under the doctrine of
trespass, the common law respects and protects the autonomy of adult persons and also accepts the
right to self-determination in respect of his or her body which can be altered only with the consent
of the person concerned.
134. There is a presumption of capacity whereby an adult is presumed to have the capacity to
consent to or to refuse medical treatment unless and until that presumption is rebutted. Butler-Sloss
LJ, in Re MB (Medical Treatment)45, stated that in deciding whether a person has the capacity to
(1992) 66 AJLR 300 : (1992) 175 CLR 218 [1997] EWCA Civ 3093 : [1997] 2 FLR 426 make a
particular decision, the ultimate question is whether that person suffers from some impairment or
disturbance of mental functioning so as to render him or her incapable of making the decision. The
consent may be vitiated if the individual concerned may not have been competent in law to give or
refuse that consent; or even if the individual was competent in law, the decision has been obtained
by undue influence or some other vitiating means; or the apparent consent or refusal does not
extend to the particular situation; or the terms of the consent or refusal are ambiguous or uncertain;
or if the consent or refusal is based on incorrect information or incorrect assumption. In
circumstances where it is practicable for a medical practitioner to obtain consent to treatment, then,
for the consent to be valid, it must be based on full information, including as to its risks and
benefits.
135. Where it is not practicable for a medical practitioner to obtain consent for treatment and where
the patient‘s life is in danger if appropriate treatment is not given, then the treatment may be
administered without consent. This is justified by what is sometimes called the ―emergency
principle or ―principle of necessity. Usually, the medical practitioner treats the patient in
accordance with his clinical judgment of what is in the patient‘s best interests. Lord Goff of
Chieveley has rightly pointed out in F v. West Berkshire Health Authority (supra) that for the
principle of necessity to apply, two conditions must be met:-
(a) There must be ―a necessity to act when it is not practicable to communicate with
the assisted person; and
(b) ―the action taken must be such as a reasonable person would in all the
circumstances take, acting in the best interests of the assisted person.
136. However, Lord Goff pointed out that the principle of necessity does not apply where the
proposed action is contrary to the known wishes of the assisted person to the extent that he/she isCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

capable of rationally forming such a wish. It follows that the principle of necessity cannot be relied
upon to justify a particular form of medical treatment where the patient has given an advance care
directive specifying that he/she does not wish to be so treated and where there is no reasonable
basis for doubting the validity and applicability of that directive.
K. Passive Euthanasia in the context of Article 21 of the Constitution:
137. We have to restrict our deliberation to the issue whether euthanasia can come within the ambit
and sweep of Article 21. Article 21 reads as follows:-
―21. Protection of life and personal liberty.—No person shall be deprived of his life or
personal liberty except according to procedure established by law.
138. The word ‗liberty‘ is the sense and realization of choice of the attributes associated with the
said choice; and the term ‗life‘ is the aspiration to possess the same in a dignified manner. The two
are intrinsically interlinked. Liberty impels an individual to change and life welcomes the change
and the movement. Life does not intend to live sans liberty as it would be, in all possibility, a
meaningless survival. There is no doubt that no fundamental right is absolute, but any restraint
imposed on liberty has to be reasonable. Individual liberty aids in developing one‘s growth of mind
and assert individuality. She/he may not be in a position to rule others but individually, she/he has
the authority over the body and mind. The liberty of personal sovereignty over body and mind
strengthens the faculties in a person. It helps in their cultivation. Roscoe Pound, in one of his
lectures, has aptly said:-
―… although we think socially, we must still think of individual interests, and of that
greatest of all claims which a human being may make, the claim to assert his
individuality, to exercise freely the will and the reason which God has given him. We
must emphasize the social interest in the moral and social life of the individual, but
we must remember that it is the life of a free-willing being.
139. Liberty allows freedom of speech, association and dissemination without which the society may
face hurdles in attaining the requisite maturity. History is replete with narratives how the thoughts
of individuals, though not accepted by the contemporaneous society, later on gained not only
acceptance but also respect. One may not agree with Kantian rigorism, but one must appreciate that
without the said doctrine, there could not have been dissemination of further humanistic principles.
There is a danger in discouraging free thinking and curtailing the power of imagination. Holmes in
Adkins v. Children’s Hospital46 has observed:-
―It is merely an example of doing what you want to do, embodied in the word
―liberty.
140. The concept of liberty perceives a hazard when it feels it is likely to become hollow. This
necessarily means that there would be liberty available to individuals subject to permissible legal
restraint and it should be made clear that in that restraint, free ideas cannot be imprisoned by someCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

kind of unknown terror. Liberty cannot be a slave because it constitutes the essential marrow of life
and that is how we intend to understand the conception of liberty when we read it in association
with the term ‗life‘ as used in Article 21 of the Constitution. The great American playwright
Tennessee Williams has said:-
―To be free is to have achieved your life.
141. Life as envisaged under Article 21 has been very broadly understood by this Court. In Board of
Trustees of the Port of Bombay v. Dilipkumar Raghavendranath Nadkarni and 261 US 525,
568(1923) others47, the Court has held that the expression ―life does not merely connote animal
existence or a continued drudgery through life. The expression ‗life‘ has a much wider meaning and,
therefore, where the outcome of a departmental enquiry is likely to adversely affect the reputation or
livelihood of a person, some of the finer graces of human civilization which make life worth living
would be jeopardized and the same can be put in jeopardy only by law which inheres fair
procedures.
142. In Maneka Gandhi v. Union of India and another48, Krishna Iyer J., in his own inimitable style,
states that among the great guaranteed rights, life and liberty are the first among equals carrying a
universal connotation cardinal to a decent human order and protected by constitutional armour.
Once liberty under Article 21 is viewed in a truncated manner, several other freedoms fade out
automatically. To sum up, personal liberty makes for the worth of the human person. Travel makes
liberty worthwhile. ‗Life‘ is a terrestrial opportunity for unfolding personality, rising to higher
status, moving to fresh woods and reaching out to reality which (1983) 1 SCC 124 (1978) 1 SCC 248
makes our earthly journey a true fulfilment – not a tale told by an idiot full of sound and fury
signifying nothing, but a fine frenzy rolling between heaven and earth. The spirit of man is at the
root of Article 21. In the absence of liberty, other freedoms are frozen.
143. In State of Andhra Pradesh v. Challa Ramkrishna Reddy and others49, this Court held that
right to life is one of the basic human rights and it is guaranteed to every person by Article 21 of the
Constitution and not even the State has the authority to violate that right. A prisoner, whether a
convict or under-trial or a detenu, does not cease to be a human being. Even when lodged in jail, he
continues to enjoy all his fundamental rights including the right to life guaranteed to him under the
Constitution. The Court further ruled that on being convicted of crime and deprived of their liberty
in accordance with the procedure established by law, prisoners still retain the residue of
constitutional rights.
144. Having said so, we are required to advert to the issue whether passive euthanasia can only be
conceived of through AIR 2000 SC 2083 : (2000) 5 SCC 712 legislation or this Court can, for the
present, provide for the same. We have already explained that the ratio laid down in Gian Kaur does
not convey that the introduction of passive euthanasia can only be by legislation. In Aruna
Shanbaug, the two-Judge Bench has placed reliance on the Constitution Bench judgment in Gian
Kaur to lay down the guidelines. If, eventually, we arrive at the conclusion that passive euthanasia
comes within the sweep of Article 21 of the Constitution, we have no iota of doubt that this Court can
lay down the guidelines.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

145. We may clearly state here that the interpretation of the Constitution, especially fundamental
rights, has to be dynamic and it is only such interpretative dynamism that breathes life into the
written words. As far as Article 21 is concerned, it is imperative to mention that dynamism can, of
course, infuse life into life and liberty as used in the said Article.
146. In this regard, we may reproduce a couple of paragraphs from Central Inland Water Transport
Corporation Limited and another v. Brojo Nath Ganguly and another50. They read as under:-
―25. The story of mankind is punctuated by progress and retrogression. Empires
have risen and crashed into the dust of history. Civilizations have nourished, reached
their peak and passed away. In the year 1625, Carew, C.J., while delivering the
opinion of the House of Lords in Re the Earldom of Oxford in a dispute relating to the
descent of that Earldom, said:
―... and yet time hath his revolution, there must be a period and an end of all
temporal things, finis rerum, an end of names and dignities, and whatsoever is
terrene.... The cycle of change and experiment, rise and fall, growth and decay, and
of progress and retrogression recurs endlessly in the history of man and the history of
civilization. T.S. Eliot in the First Chorus from ―The Rock said:
―O perpetual revolution of configured stars, O perpetual recurrence of determined
seasons, O world of spring and autumn, birth and dying; The endless cycle of idea
and action, Endless invention, endless experiment.
26. The law exists to serve the needs of the society which is governed by it. If the law
is to play its allotted role of serving the needs of the society, it must reflect the ideas
and ideologies of that society.
It must keep time with the heartbeats of the society and with the needs and aspirations of the
people. As (1986) 3 SCC 156 the society changes, the law cannot remain immutable. The early
nineteenth century essayist and wit, Sydney Smith, said: ―When I hear any man talk of an
unalterable law, I am convinced that he is an unalterable fool. The law must, therefore, in a
changing society march in tune with the changed ideas and ideologies [Emphasis added]
147. We approve the view in the aforesaid passages. Having approved the aforesaid principle, we are
obliged to state that the fundamental rights in their connotative expanse are bound to engulf certain
rights which really flow from the same. In M. Nagaraj and others v. Union of India and others51, the
Constitution Bench has ruled:-
―19. The Constitution is not an ephemeral legal document embodying a set of legal
rules for the passing hour. It sets out principles for an expanding future and is
intended to endure for ages to come and consequently to be adapted to the various
crises of human affairs. Therefore, a purposive rather than a strict literal approach to
the interpretation should be adopted. A constitutional provision must be construedCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

not in a narrow and constricted sense but in a wide and liberal manner so as to
anticipate and take account of changing conditions and purposes so that a
constitutional provision does not get fossilised but remains flexible enough to meet
the newly emerging problems and challenges. (2006) 8 SCC 212 And again:-
―29. … constitutionalism is about limits and aspirations. According to Justice
Brennan, interpretation of the Constitution as a written text is concerned with
aspirations and fundamental principles. In his article titled ―Challenge to the Living
Constitution by Herman Belz, the author says that the Constitution embodies
aspiration to social justice, brotherhood and human dignity. It is a text which
contains fundamental principles. …
148. In this context, we may make a reference to a three- Judge Bench decision in V.C. Rangadurai
v. D. Gopalan and others52 wherein the majority, while dealing with Section 35(3) of the Advocates
Act, 1961, stated:-
―8. … we may note that words grow in content with time and circumstance, that
phrases are flexible in semantics, that the printed text is a set of vessels into which
the court may pour appropriate judicial meaning. That statute is sick which is allergic
to change in sense which the times demand and the text does not countermand. That
court is superficial which stops with the cognitive and declines the creative function
of construction. So, we take the view that 'quarrying' more meaning is permissible
out of Section 35(3) and the appeal provisions, in the brooding background of social
justice, sanctified by Article 38, and of free legal aid enshrined by Article 39A of the
Constitution. (1979) 1 SCC 308 The learned Judges went on to say:-
―11. … Judicial 'Legisputation' to borrow a telling phrase of J. Cohen, is not
legislation but application of a given legislation to new or unforeseen needs and
situations broadly falling within the statutory provision. In that sense, 'interpretation
is inescapably a kind of legislation' (The Interpretation and Application of Statutes,
Read Dickerson, p.
238). Ibid. p. 238. This is not legislation stricto sensu but application, and is within
the court's province.
149. The aforesaid authorities clearly show the power that falls within the province of the Court. The
language employed in the constitutional provision should be liberally construed, for such provision
can never remain static. It is because stasticity would mar the core which is not the intent. K.1
Individual Dignity as a facet of Article 21:
150. Dignity of an individual has been internationally recognized as an important facet of human
rights in the year 1948 itself with the enactment of the Universal Declaration of Human Rights.
Human dignity not only finds place in the Preamble of this important document but also in Article 1
of the same. It is well known that the principles set out in UDHR are of paramount importance andCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

are given utmost weightage while interpreting human rights all over the world. The first and
foremost responsibility fixed upon the State is the protection of human dignity without which any
other right would fall apart. Justice Brennan in his book The Constitution of the United States:
Contemporary Ratification has referred to the Constitution as "a sparkling vision of the supremacy
of the human dignity of every individual."
151. In fact, in the case of Christine Goodwin v. the United Kingdom53 the European Court of
Human Rights, speaking in the context of the Convention for the Protection of Human Rights and
Fundamental Freedoms, has gone to the extent of stating that "the very essence of the Convention is
respect for human dignity and human freedom". In the South African case of S v. Makwanyane 54 O'
Regan J. stated in the Constitutional Court that "without dignity, human life is substantially
diminished."
152. Having noted the aforesaid, it is worthy to note that our Court has expanded the spectrum of
Article 21. In the latest [2002] ECHR 588 1995 (3) SA 391 nine-Judge Bench decision in K.S.
Puttaswamy and another v. Union of India and others55, dignity has been reaffirmed to be a
component under the said fundamental right. Human dignity is beyond definition. It may at times
defy description. To some, it may seem to be in the world of abstraction and some may even
perversely treat it as an attribute of egotism or accentuated eccentricity. This feeling may come from
the roots of absolute cynicism. But what really matters is that life without dignity is like a sound that
is not heard. Dignity speaks, it has its sound, it is natural and human. It is a combination of thought
and feeling, and, as stated earlier, it deserves respect even when the person is dead and described as
a ‗body‘. That is why, the Constitution Bench in M. Nagaraj (supra) lays down:-
―….It is the duty of the State not only to protect the human dignity but to facilitate it
by taking positive steps in that direction. No exact definition of human dignity exists.
It refers to the intrinsic value of every human being, which is to be respected. It
cannot be taken away. It cannot give (sic be given). It simply is. Every human being
has dignity by virtue of his existence. … (2017) 10 SCC 1
153. The concept and value of dignity requires further elaboration since we are treating it as an
inextricable facet of right to life that respects all human rights that a person enjoys. Life is basically
self-assertion. In the life of a person, conflict and dilemma are expected to be normal phenomena.
Oliver Wendell Holmes, in one of his addresses, quoted a line from a Latin poet who had uttered the
message, ―Death plucks my ear and says, Live- I am coming. That is the significance of living. But
when a patient really does not know if he/she is living till death visits him/her and there is constant
suffering without any hope of living, should one be allowed to wait? Should she/he be cursed to die
as life gradually ebbs out from her/his being? Should she/he live because of innovative medical
technology or, for that matter, should he/she continue to live with the support system as people
around him/her think that science in its progressive invention may bring about an innovative
method of cure? To put it differently, should he/she be ―guinea pig for some kind of experiment?
The answer has to be an emphatic ―No because such futile waiting mars the pristine concept of life,
corrodes the essence of dignity and erodes the fact of eventual choice which is pivotal to privacy.
Recently, in K.S. Puttaswamy (supra), one of us (Dr. Chandrachud J.), while speaking about life andCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

dignity, has observed:-
―118. Life is precious in itself. But life is worth living because of the freedoms which
enable each individual to live life as it should be lived. The best decisions on how life
should be lived are entrusted to the individual. They are continuously shaped by the
social milieu in which individuals exist. The duty of the State is to safeguard the
ability to take decisions — the autonomy of the individual — and not to dictate those
decisions. ―Life within the meaning of Article 21 is not confined to the integrity of
the physical body. The right comprehends one‘s being in its fullest sense. That which
facilitates the fulfilment of life is as much within the protection of the guarantee of
life.
119. To live is to live with dignity. The draftsmen of the Constitution defined their
vision of the society in which constitutional values would be attained by emphasising,
among other freedoms, liberty and dignity. So fundamental is dignity that it
permeates the core of the rights guaranteed to the individual by Part III. Dignity is
the core which unites the fundamental rights because the fundamental rights seek to
achieve for each individual the dignity of existence. Privacy with its attendant values
assures dignity to the individual and it is only when life can be enjoyed with dignity
can liberty be of true substance. Privacy ensures the fulfilment of dignity and is a core
value which the protection of life and liberty is intended to achieve.
154. In Mehmood Nayyar Azam v. State of Chhattisgarh and others56, a two-Judge Bench held
thus:-
―Albert Schweitzer, highlighting on Glory of Life, pronounced with conviction and
humility, "the reverence of life offers me my fundamental principle on morality". The
aforesaid expression may appear to be an individualistic expression of a great
personality, but, when it is understood in the complete sense, it really denotes, in its
conceptual essentiality, and connotes, in its macrocosm, the fundamental perception
of a thinker about the respect that life commands. The reverence of life is
insegragably associated with the dignity of a human being who is basically divine, not
servile. A human personality is endowed with potential infinity and it blossoms when
dignity is sustained. The sustenance of such dignity has to be the superlative concern
of every sensitive soul. The essence of dignity can never be treated as a momentary
spark of light or, for that matter, 'a brief candle', or 'a hollow bubble'. The spark of life
gets more resplendent when man is treated with dignity sans humiliation, for every
man is expected to lead an honourable life which is a splendid gift of "creative
intelligence"
155. The aforesaid authority emphasizes the seminal value of life that is inherent in the concept of
life. Dignity does not recognize or accept any nexus with the status or station in life. The singular
principle that it pleasantly gets beholden to is the integral human right of a person. Law gladly takes
cognizance (2012) 8 SCC 1 of the fact that dignity is the most sacred possession of a man. And theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

said possession neither loses its sanctity in the process of dying nor evaporates when death occurs.
In this context, reference to a passage from Vikas Yadav v. State of Uttar Pradesh and others57 is
note worthy. The two Judge Bench of this Court, while dealing with the imposition of a fixed term
sentence under Section 302 IPC, took note of the fact that the High Court had observed the
magnitude of vengeance of the accused and the extent to which they had gone to destroy the body of
the deceased. Keeping in view the findings of the High Court, this Court stated:-
―From the evidence brought on record as well as the analysis made by the High
Court, it is demonstrable about the criminal proclivity of the accused persons, for
they have neither the respect for human life nor did they have any concern for the
dignity of a dead person. They had deliberately comatosed the feeling that even in
death a person has dignity and when one is dead deserves to be treated with dignity.
That is the basic human right. The brutality that has been displayed by the accused
persons clearly exposes the depraved state of mind. (2016) 9 SCC 541 The aforesaid
passage shows the pedestal on which the Court has placed the dignity of an
individual.
156. Reiterating that dignity is the most fundamental aspect of right to life, it has been held in the
celebrated case of Francis Coralie Mullin v. The Administrator, Union Territory of Delhi58:-
"We think that the right to life includes the right to live with human dignity and all
that goes along with it, namely, the bare necessaries of life such as adequate
nutrition, clothing and shelter and facilities for reading, writing and expressing
one-self in diverse forms, freely moving about and mixing and commingling with
fellow human beings. Of course, the magnitude and content of the components of this
right would depend upon the extent of the economic development of the country, but
it must, in any view of the matter, include the right to the basic necessities of life and
also the right to carry on such functions and activities as constitute the bare
minimum expression of the human-self. Every act which offends against or impairs
human dignity would constitute deprivation protanto of this right to live and it would
have to be in accordance with reasonable, fair and just procedure established by law
which stands the test of other fundamental rights. Now obviously, any form of torture
or cruel, inhuman or degrading treatment would be offensive to human dignity and
constitute an inroad into this right to live and it would, on this view, be prohibited by
Article 21 unless it is in accordance with procedure prescribed (1981) 1 SCC 608 by
law, but no law which authorises and no procedure which leads to such torture or
cruel, inhuman or degrading treatment can ever stand the test of reasonableness and
non-arbitrariness: it would plainly be unconstitutional and void as being violative of
Articles 14 and 21. It would thus be seen that there is implicit in Article 21 the right to
protection against torture or cruel, inhuman or degrading treatment which is
enunciated in Article 5 of the Universal Declaration of Human Rights and guaranteed
by Article 7 of the International Covenant on Civil and Political Rights."Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

157. In National Legal Services Authority v. Union of India and others59, the Apex Court has held
that there is a growing recognition that the true measure of development of a nation is not economic
growth; it is human dignity.
158. In Shabnam v. Union of India and another60, it has been further held that:-
"This right to human dignity has many elements. First and foremost, human dignity
is the dignity of each human being 'as a human being'. Another element, which needs
to be highlighted, in the context of the present case, is that human dignity is infringed
if a person's life, physical or mental welfare is armed. It is in this sense torture,
humiliation, forced labour, etc. all infringe on human dignity. (2014) 5 SCC 438
(2015) 6 SCC 702
159. In Gian Kaur (supra), the Constitution Bench indicates acceleration of the conclusion of the
process of death which has commenced and this indication, as observed by us, allows room for
expansion. In the said case, the Court was primarily concerned with the question of constitutional
validity of Sections 306 and 309 of IPC. The Court was conscious of the fact that the debate on
euthanasia was not relevant for deciding the question under consideration. The Court, however, in
no uncertain terms expounded that the word "life" in Article 21 has been construed as life with
human dignity and it takes within its ambit the "right to die with dignity" being part of the "right to
live with dignity". Further, the "right to live with human dignity" would mean existence of such a
right upto the end of natural life which would include the right to live a dignified life upto the point
of death including the dignified procedure of death. While adverting to the situation of a dying man
who is terminally ill or in a persistent vegetative state where he may be permitted to terminate it by
a premature extinction of his life, the Court observed that the said category of cases may fall within
the ambit of "right to die with dignity" as part of the right to live with dignity when death due to the
termination of natural life is certain and imminent and the process of natural death has
commenced, for these are not cases of extinguishing life but only of accelerating the conclusion of
the process of natural death which has already commenced. The sequitur of this exposition is that
there is little doubt that a dying man who is terminally ill or in a persistent vegetative state can make
a choice of premature extinction of his life as being a facet of Article 21 of the Constitution. If that
choice is guaranteed being part of Article 21, there is no necessity of any legislation for effectuating
that fundamental right and more so his natural human right. Indeed, that right cannot be an
absolute right but subject to regulatory measures to be prescribed by a suitable legislation which,
however, must be reasonable restrictions and in the interests of the general public. In the context of
the issue under consideration, we must make it clear that as part of the right to die with dignity in
case of a dying man who is terminally ill or in a persistent vegetative state, only passive euthanasia
would come within the ambit of Article 21 and not the one which would fall within the description of
active euthanasia in which positive steps are taken either by the treating physician or some other
person. That is because the right to die with dignity is an intrinsic facet of Article 21. The concept
that has been touched deserves to be concretised, the thought has to be realized. It has to be viewed
from various angles, namely, legal permissibility, social and ethical ethos and medical values.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

160. The purpose of saying so is only to highlight that the law must take cognizance of the changing
society and march in consonance with the developing concepts. The need of the present has to be
served with the interpretative process of law. However, it is to be seen how much strength and
sanction can be drawn from the Constitution to consummate the changing ideology and convert it
into a reality. The immediate needs are required to be addressed through the process of
interpretation by the Court unless the same totally falls outside the constitutional framework or the
constitutional interpretation fails to recognize such dynamism. The Constitution Bench in Gian
Kaur, as stated earlier, distinguishes attempt to suicide and abetment of suicide from acceleration of
the process of natural death which has commenced. The authorities, we have noted from other
jurisdictions, have observed the distinctions between the administration of lethal injection or certain
medicines to cause painless death and non- administration of certain treatment which can prolong
the life in cases where the process of dying that has commenced is not reversible or withdrawal of
the treatment that has been given to the patient because of the absolute absence of possibility of
saving the life. To explicate, the first part relates to an overt act whereas the second one would come
within the sphere of informed consent and authorized omission. The omission of such a nature will
not invite any criminal liability if such action is guided by certain safeguards. The concept is based
on non-prolongation of life where there is no cure for the state the patient is in and he, under no
circumstances, would have liked to have such a degrading state. The words ―no cure have to be
understood to convey that the patient remains in the same state of pain and suffering or the dying
process is delayed by means of taking recourse to modern medical technology. It is a state where the
treating physicians and the family members know fully well that the treatment is administered only
to procrastinate the continuum of breath of the individual and the patient is not even aware that he
is breathing. Life is measured by artificial heartbeats and the patient has to go through this
undignified state which is imposed on him. The dignity of life is denied to him as there is no other
choice but to suffer an avoidable protracted treatment thereby thus indubitably casting a cloud and
creating a dent in his right to live with dignity and face death with dignity, which is a preserved
concept of bodily autonomy and right to privacy. In such a stage, he has no old memories or any
future hopes but he is in a state of misery which nobody ever desires to have. Some may also silently
think that death, the inevitable factum of life, cannot be invited. To meet such situations, the Court
has a duty to interpret Article 21 in a further dynamic manner and it has to be stated without any
trace of doubt that the right to life with dignity has to include the smoothening of the process of
dying when the person is in a vegetative state or is living exclusively by the administration of
artificial aid that prolongs the life by arresting the dignified and inevitable process of dying. Here,
the issue of choice also comes in. Thus analysed, we are disposed to think that such a right would
come within the ambit of Article 21 of the Constitution.
L. Right of self-determination and individual autonomy:
161. Having dealt with the right to acceleration of the process of dying a natural death which is
arrested with the aid of modern innovative technology as a part of Article 21 of the Constitution, it is
necessary to address the issues of right of self-determination and individual autonomy.
162. John Rawls says that the liberal concept of autonomy focuses on choice and likewise,
self-determination is understood as exercised through the process of choosing 61 . The respect for anCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

individual human being and in particular for his right to choose how he should live his own life is
individual autonomy or the right of self- determination. It is the right against non-interference by
others, which gives a competent person who has come of age the right to make decisions concerning
his or her own life and body without any Rawls, John, Political Liberalism 32, 33, New York:
Columbia University Press, 1993. control or interference of others. Lord Hoffman, in Reeves v.
Commissioner of Police of the Metropolis62 has stated:-
"Autonomy means that every individual is sovereign over himself and cannot be
denied the right to certain kinds of behaviour, even if intended to cause his own
death."
163. In the context of health and medical care decisions, a person's exercise of self-determination
and autonomy involves the exercise of his right to decide whether and to what extent he/she is
willing to submit himself/herself to medical procedures and treatments, choosing amongst the
available alternative treatments or, for that matter, opting for no treatment at all which, as per his or
her own understanding, is in consonance with his or her own individual aspirations and values.
164. In Airedale (supra), Lord Goff has expressed that it is established that the principle of
self-determination requires that respect must be given to the wishes of the patient so that if an adult
patient of sound mind refuses, however unreasonably, to consent to treatment or care by which 62
[2000] 1 AC 360, 379 his/her life would or might be prolonged, the doctors responsible for his/her
care must give effect to his/her wishes, even though they do not consider it to be in his/her best
interests to do so and to this extent, the principle of sanctity of human life must yield to the principle
of self-determination. Lord Goff further says that the doctor's duty to act in the best interests of his
patient must likewise be qualified with the patient's right of self determination. Therefore, as far as
the United Kingdom is concerned, it is generally clear that whenever there is a conflict between a
capable adult's exercise of the right of self-determination and the State's interest in preserving
human life by treating it as sanctimonious, the right of the individual must prevail.
165. In the United States, the aspect of self-determination and individual autonomy is concretised in
law as all fifty States along with the District of Columbia, the capital, which is commonly referred as
Washington D.C., have passed legislations upholding different forms of Advance Directives. In the
United States, even before the enactment of the said laws, a terminally ill person was free to assert
the right to die as an ancillary right to the constitutionally protected right to privacy. In In Re
Quinlan (supra), where a 21 year old girl in chronic PVS was on ventilator support, the Court, while
weighing Quinlan's right to privacy qua the State's interest in preserving human life, found that as
the degree of bodily invasion increases and the prognosis for the patient's recovery dims, the
patient's right to privacy increases and the State's interest weakens. The Supreme Court of New
Jersey finally ruled that the unwritten constitutional right of privacy was broad enough to
encompass a patient's decision to decline medical treatment in certain circumstances. Again, in Re
Jobes63, which was also a case concerned with a PVS patient, the Court, following the decision in In
Re Quinlan, upheld the principle of self determination and autonomy of an incompetent person.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

166. The Canadian Criminal Code asserts and protects the sanctity of life in a number of ways which
directly confront the autonomy of the terminally ill in their medical decision (1987) 108 N.J. 394
making. However, the Supreme Court of Canada in Reibl v. Hughes64 approved an oft-quoted
statement of Cardozo J. in Scholoendorf (supra) that "every human being of adult years and sound
mind has a right to determine what shall be done with his own body" and Chief Justice Laskin in
Reibl (supra) has further added that battery would lie where surgery or treatment was performed
without consent or where apart from emergency situations, surgery or medical treatment was given
beyond that to which there was consent. Thus, the Supreme Court of Canada suggested that
competent adults have the right to make their own medical decisions even if such decisions are
unwise.
167. In Aruna Shanbaug (supra), this Court has observed that autonomy means the right to
self-determination where the informed patient has a right to choose the manner of his treatment. To
be autonomous the patient should be competent to make decisions and choices. In the event that he
is incompetent to make choices, his wishes expressed in advance in the form of a Living Will, or the
wishes of surrogates acting on his behalf [1980 2 SCR 880 at 890-891 ('substituted judgment') are
to be respected. The surrogate is expected to represent what the patient may have decided had
he/she been competent or to act in the patient's best interest. It is expected that a surrogate acting
in the patient's best interest follows a course of action because it is best for the patient, and is not
influenced by personal convictions, motives or other considerations.
168. Thus, enquiring into common law and statutory rights of terminally ill persons in other
jurisdictions would indicate that all adults with the capacity to consent have the common law right
to refuse medical treatment and the right of self determination.
169. We may, however, add a word of caution that doctors would be bound by the choice of
self-determination made by the patient who is terminally ill and undergoing a prolonged medical
treatment or is surviving on life support, subject to being satisfied that the illness of the patient is
incurable and there is no hope of his being cured. Any other consideration cannot pass off as being
in the best interests of the patient. M. Social morality, medical ethicality and State interest:
170. Having dwelt upon the issue of self-determination, we may presently delve into three aspects,
namely, social morality, medical ethicality and the State interest. The aforesaid concepts have to be
addressed in the constitutional backdrop. We may clearly note that the society at large may feel that
a patient should be treated till he breathes his last breath and the treating physicians may feel that
they are bound by their Hippocratic oath which requires them to provide treatment and save life and
not to put an end to life by not treating the patient. The members of the family may remain in a
constant state of hesitation being apprehensive of many a social factor which include immediate
claim of inheritance, social stigma and, sometimes, the individual guilt. The Hippocratic oath taken
by a doctor may make him feel that there has been a failure on his part and sometimes also make
him feel scared of various laws. There can be allegations against him for negligence or criminal
culpability.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

171. In this regard, two aspects are to be borne in mind. First, withdrawal of treatment in an
irreversible situation is different from not treating or attending to a patient and second, once passive
euthanasia is recognized in law regard being had to the right to die with dignity when life is ebbing
out and when the prolongation is done sans purpose, neither the social morality nor the doctors‘
dilemma or fear will have any place. It is because the sustenance of dignity and self- respect of an
individual is inhered in the right of an individual pertaining to life and liberty and there is necessity
for this protection. And once the said right comes within the shelter of Article 21 of the Constitution,
the social perception and the apprehension of the physician or treating doctor regarding facing
litigation should be treated as secondary because the primacy of the right of an individual in this
regard has to be kept on a high pedestal.
172. It is to be borne in mind that passive euthanasia fundamentally connotes absence of any overt
act either by the patient or by the doctors. It also does not involve any kind of overt act on the part of
the family members. It is avoidance of unnecessary intrusion in the physical frame of a person, for
the inaction is meant for smooth exit from life. It is paramount for an individual to protect his
dignity as an inseparable part of the right to life which engulfs the dignified process of dying sans
pain, sans suffering and, most importantly, sans indignity.
173. There are philosophers, thinkers and also scientists who feel that life is not confined to the
physical frame and biological characteristics. But there is no denial of the fact that life in its
connotative expanse intends to search for its meaning and find the solution of the riddle of existence
for which some lean on atheism and some vouchsafe for faith and yet some stand by the ideas of an
agnostic. However, the legal fulcrum has to be how Article 21 of the Constitution is understood. If a
man is allowed to or, for that matter, forced to undergo pain, suffering and state of indignity because
of unwarranted medical support, the meaning of dignity is lost and the search for meaning of life is
in vain.
N. Submissions of the States
174. In this context, we may reflect on the submissions advanced on behalf of certain States. As
stated earlier, there is a categorical assertion that protection of human life is paramount and it is
obligatory on behalf of the States to provide treatment and to see that no one dies because of lack of
treatment and to realise the principles enshrined in Chapter IV of the Constitution. Emphasis has
been laid on the State interest and the process of abuse that can take place in treating passive
euthanasia as permissible in law. To eliminate the possibility of abuse, safeguards can be taken and
guidelines can be framed. But on the plea of possibility of abuse, the dignity in the process of dying
being a facet of Article 21 should not be curbed.
Mr. Datar, learned senior counsel in the course of arguments, has advanced submissions in support
of passive euthanasia and also given suggestions spelling out the guidelines for advance directive
and also implementation of the same when the patient is hospitalized. The said aspect shall be taken
into consideration while giving effect to the advance directive and also taking steps for withdrawal of
medical support.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

O. Submissions of Intervenor (Society for the Right to Die with Dignity):
175. Mr. Mohta, learned counsel appearing for the intervenor, that is, Society for the Right to Die
with Dignity, has drawn our attention to certain articles and submitted that from the days of Plato to
the time of Sir Thomas More and other thinkers, painless and peaceful death has been advocated.
He would also submit that ancient wisdom of India taught people not to fear death but to aspire for
deathlessness and conceive it as ―Mahaprasthana. It is his submission that in the modern State,
the State interest should not over-weigh the individual interest in the sphere of a desire to die a
peaceful death which basically conveys refusal of treatment when the condition of the individual
suffering from a disease is irreversible. The freedom of choice in this sphere, as Mr. Mohta would
put it, serves the cause of humanitarian approach which is not the process to put an end to life by
taking a positive action but to allow a dying patient to die peaceably instead of prolonging the
process of dying without purpose that creates a dent in his dignity.
176. The aforesaid argument, we have no hesitation to say, has force. It is so because it is in accord
with the constitutional precept and fosters the cherished value of dignity of an individual. It saves a
helpless person from uncalled for and unnecessary treatment when he is considered as merely a
creature whose breath is felt or measured because of advanced medical technology. His ―being
exclusively rests on the mercy of the technology which can prolong the condition for some period.
The said prolongation is definitely not in his interest. On the contrary, it tantamounts to destruction
of his dignity which is the core value of life. In our considered opinion, in such a situation, an
individual interest has to be given priority over the State interest. P. Advance Directive/Advance
Care Directive/Advance Medical Directive:
177. In order to overcome the difficulty faced in case of patients who are unable to express their
wishes at the time of taking the decision, the concept of Advance Medical Directives emerged in
various countries. The proponents of Advance Medical Directives contend that the concept of
patient autonomy for incompetent patients can be given effect to, by giving room to new methods by
which incompetent patients can beforehand communicate their choices which are made while they
are competent. Further, it may be argued that failure to recognize Advance Medical Directives would
amount to non-facilitation of the right to have a smoothened dying process. That apart, it accepts
the position that a competent person can express her/his choice to refuse treatment at the time
when the decision is required to be made.
178. Advance Directives for health care go by various names in different countries though the
objective by and large is the same, that is, to specify an individual's health care decisions and to
identify persons who will take those decisions for the said individual in the event he is unable to
communicate his wishes to the doctor.
179. The Black's Law Dictionary defines an advance medical directive as, "a legal document
explaining one's wishes about medical treatment if one becomes incompetent or unable to
communicate. A living will, on the other hand, is a document prescribing a person's wishes
regarding the medical treatment the person would want if he was unable to share his wishes with the
health care provider.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

180. Another type of advance medical directive is medical power of attorney. It is a document which
allows an individual (principal) to appoint a trusted person (agent) to take health care decisions
when the principal is not able to take such decisions. The agent appointed to deal with such issues
can interpret the principal's decisions based on their mutual knowledge and understanding.
181. Advance Directives have gained lawful recognition in several jurisdictions by way of legislation
and in certain countries through judicial pronouncements. In vast majority of the States in USA, it is
mandatory for the doctors to give effect to the wishes of the patients as declared by them in their
advance directives. California was the first State to legally sanction living will. The United States
Congress in 1990, with the objective of protecting the fundamental principles of self- autonomy and
self-determination, enacted the Patient Self- Determination Act (PSDA) which acknowledged the
rights of the patient to either refuse or accept treatment. Following this, all 50 States enacted
legislations adopting advance directives. Apart from this, several States of USA also permit the
patients to appoint a health care proxy which becomes effective only when the patient is unable to
make decisions.
182. In order to deal with the technicalities and intricacies associated with an instrument as complex
as an Advance Directive, several derivatives/versions have evolved over time. The National Right to
Life Committee (NRLC) in the United States came up with a version of a living will which was called
'Will to Live" which is a safeguard of the lives of patients who wish to continue treatment and not
refuse life-sustaining treatment. This form of active declaration gains importance in cases where the
will of the patient cannot be deciphered with certainty and the Courts order withdrawal of life
supporting treatment where they deem the life of the patient as not worthwhile.
183. Yet another measure for finding and accessing the patient's advance directive was the setting up
of the U.S. Living Will Registry. As per this model, it was obligatory on the part of the hospital
administration to ask a patient, who would be admitted, if he/she had an advance directive and
store the same on their medical file. A special power to the Advance Directives introduced by
Virginia was the "Ulysses Clause"
which accords protection in situations when the patient goes into relapse in his/her
condition, that is, schizophrenia and refuses treatment which they would not refuse if
not for the said relapse.
184. A new type of advance directive is the "Do Not Resuscitate Order" (DNRO) in Florida which is a
form of patient identification device developed by the Department of Health to identify people who
do not wish to be resuscitated in the event of respiratory or cardiac arrest. In Florida State of United
States, where an unconscious patient with the phrase "Do Not Resuscitate" tattooed on his chest was
brought in paramedics, the doctors were left in a conundrum whether the message was not to
provide any medical treatment to the patient and ultimately, the doctors opted not to perform any
medical procedure and the patient, thereafter, died. This case highlights the dynamics involved in
the concept of advanced directives due to the intricacies surrounding the concept.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

185. The Mental Capacity Act governs the law relating to advance directives in the UK. Specific
guidelines as to the manner in which the advance directive should be drafted and the necessary
conditions that need to be fulfilled in order to give effect to the directives have been categorically
laid out in the said piece of legislation. A few specific requirements in case of refusal of life
sustaining treatment is the verification of the decision-maker that the refusal operates even if life is
at risk and that the directive should be in the written form and signed and witnessed. However, an
advance directive refusing food and water has not been recognized under this statute. Further, the
Act recognizes the rights of the patient to appoint a health care proxy who is referred to as "lasting
power of attorney". In order for the proxy decision-maker so appointed to be competent to consent
or refuse life-sustaining treatment of the decision-maker, an express provision delegating the said
authority should be a part of the advance directive. In general, as per the settled law vide the
decision in Airedale, life sustaining treatment including artificial nutrition and hydration can be
withdrawn if the patient consents to it and in case of incompetent patients, if it is in their best
interest to do so.
186. Australia too, by way of legislation, has well established principles governing Advance Health
Directives. Except Tasmania, all states have a provision for Advance Directives. The Advance
Directives as postulated by the different legislations in each State in Australia differ in nature and
their binding effect but the objective of every type remains the same, that is, preservation of the
patient's autonomy. There are several circumstances when the advance health care directives or
certain provisions contained therein become inoperative.
187. In Queensland, the directive becomes inoperative if the medical health practitioner is of the
opinion that giving effect to the directive is inconsistent with good medical practice or in case of a
change in circumstances, including new advances in medicine, medical practice and technology, to
the extent that giving effect to the directive is inappropriate.
188. In the State of Victoria, an advance directive ceases to apply due to a change in the condition of
the patient to the extent that the condition in relation to which the advance directive was given no
longer exists. Further, South Australia permits a medical practitioner to refuse to comply with a
certain provision in an advance directive in case he/she has enough reason to believe that the
patient did not intend the provision to apply in certain conditions or the provision would not reflect
the present wishes of the patient. In Western Australia, the occurrence of a change in circumstances
which either the decision maker could have never anticipated at the time of making the directive or
which could have the effect on a reasonable person in the position of the decision maker to change
his/her mind regarding the treatment decision would invalidate the said treatment decision in the
directive. In Northern Territory, an advance consent direction is disregarded in case giving effect to
it would result in such unacceptable pain and suffering to the patient or would be so unjustifiable
and rather it is more reasonable to override the wishes of the patient. Furthermore, if the medical
practitioner is of the opinion that the patient would have never intended the advance consent
direction to apply in the circumstances, then the advance consent direction need not be complied
with.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

189. Canada does not have a federal legislation exclusively to regulate advance directives. Rather,
there are eleven different provincial approaches governing the law on passive euthanasia and
advance directives in Canada. The provinces of Alberta, Saskatchewan, Manitoba, Prince Edward
Island, Newfoundland and Labrador and Northwest Territories have a provision for both proxy and
instructional directives, whereas, the States of British Columbia, Ontario, Quebec and Yukon
provide only for appointment of a proxy while simultaneously recognizing the binding nature of
previously given instructions. The respective legislations of the provinces/territories differ from one
another on several criteria, for instance, minimum age requirement and other formalities to be
complied with, such as written nature of the advance directive, etc. Furthermore, some of the
provinces mandate a prior consultation with a lawyer. Wishes orally expressed have also been
recognized by some provinces.
190. Having dealt with the principles in vogue across the globe, we may presently proceed to deal
with the issue of advance medical directive which should be ideal in our country. Be it noted, though
the learned counsel for the petitioner has used the words ―living will, yet we do not intend to use
the said terminology. We have already stated that safeguards and guidelines are required to be
provided. First, we shall analyse the issue of legal permissibility of the advance medical directive. In
other jurisdictions, the concepts of ―living will and involvement of Attorney are stipulated. There is
no legal framework in our country as regards the Advance Medical Directive but we are obliged to
protect the right of the citizens as enshrined under Article 21 of the Constitution. It is our
constitutional obligation. As noticed earlier, the two-Judge Bench in Aruna Shanbaug (supra) has
provided for approaching the High Court under Article 226 of the Constitution. The directions and
guidelines to be given in this judgment would be comprehensive and would also cover the situation
dealt with Aruna Shanbaug case.
191. In our considered opinion, Advance Medical Directive would serve as a fruitful means to
facilitate the fructification of the sacrosanct right to life with dignity. The said directive, we think,
will dispel many a doubt at the relevant time of need during the course of treatment of the patient.
That apart, it will strengthen the mind of the treating doctors as they will be in a position to ensure,
after being satisfied, that they are acting in a lawful manner. We may hasten to add that Advance
Medical Directive cannot operate in abstraction. There has to be safeguards. They need to be spelt
out. We enumerate them as follows:-
(a) Who can execute the Advance Directive and how?
(i) The Advance Directive can be executed only by an adult who is of a sound and
healthy state of mind and in a position to communicate, relate and comprehend the
purpose and consequences of executing the document.
(ii) It must be voluntarily executed and without any coercion or inducement or
compulsion and after having full knowledge or information.
(iii) It should have characteristics of an informed consent given without any undue
influence or constraint.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(iv) It shall be in writing clearly stating as to when medical treatment may be
withdrawn or no specific medical treatment shall be given which will only have the
effect of delaying the process of death that may otherwise cause him/her pain,
anguish and suffering and further put him/her in a state of indignity.
(b) What should it contain?
(i) It should clearly indicate the decision relating to the circumstances in which
withholding or withdrawal of medical treatment can be resorted to.
      (ii)    It    should   be   in    specific   terms    and    the
              instructions    must      be   absolutely    clear   and
              unambiguous.
(iii) It should mention that the executor may revoke the instructions/authority at any
time.
(iv) It should disclose that the executor has understood the consequences of
executing such a document.
(v) It should specify the name of a guardian or close relative who, in the event of the
executor becoming incapable of taking decision at the relevant time, will be
authorized to give consent to refuse or withdraw medical treatment in a manner
consistent with the Advance Directive.
(vi) In the event that there is more than one valid Advance Directive, none of which
have been revoked, the most recently signed Advance Directive will be considered as
the last expression of the patient‘s wishes and will be given effect to.
(c) How should it be recorded and preserved?
(i) The document should be signed by the executor in the presence of two attesting
witnesses, preferably independent, and countersigned by the jurisdictional Judicial
Magistrate of First Class (JMFC) so designated by the concerned District Judge.
(ii) The witnesses and the jurisdictional JMFC shall record their satisfaction that the
document has been executed voluntarily and without any coercion or inducement or
compulsion and with full understanding of all the relevant information and
consequences.
(iii) The JMFC shall preserve one copy of the document in his office, in addition to
keeping it in digital format.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(iv) The JMFC shall forward one copy of the document to the Registry of the
jurisdictional District Court for being preserved. Additionally, the Registry of the
District Judge shall retain the document in digital format.
(v) The JMFC shall cause to inform the immediate family members of the executor, if
not present at the time of execution, and make them aware about the execution of the
document.
(vi) A copy shall be handed over to the competent officer of the local Government or
the Municipal Corporation or Municipality or Panchayat, as the case may be. The
aforesaid authorities shall nominate a competent official in that regard who shall be
the custodian of the said document.
(vii) The JMFC shall cause to handover copy of the Advance Directive to the family
physician, if any.
(d) When and by whom can it be given effect to?
(i) In the event the executor becomes terminally ill and is undergoing prolonged
medical treatment with no hope of recovery and cure of the ailment, the treating
physician, when made aware about the Advance Directive, shall ascertain the
genuineness and authenticity thereof from the jurisdictional JMFC before acting
upon the same.
(ii) The instructions in the document must be given due weight by the doctors.
However, it should be given effect to only after being fully satisfied that the executor
is terminally ill and is undergoing prolonged treatment or is surviving on life support
and that the illness of the executor is incurable or there is no hope of him/her being
cured.
(iii) If the physician treating the patient (executor of the document) is satisfied that
the instructions given in the document need to be acted upon, he shall inform the
executor or his guardian / close relative, as the case may be, about the nature of
illness, the availability of medical care and consequences of alternative forms of
treatment and the consequences of remaining untreated.
He must also ensure that he believes on reasonable grounds that the person in question understands
the information provided, has cogitated over the options and has come to a firm view that the option
of withdrawal or refusal of medical treatment is the best choice.
(iv) The physician/hospital where the executor has been admitted for medical treatment shall then
constitute a Medical Board consisting of the Head of the treating Department and at least three
experts from the fields of general medicine, cardiology, neurology, nephrology, psychiatry or
oncology with experience in critical care and with overall standing in the medical profession of atCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

least twenty years who, in turn, shall visit the patient in the presence of his guardian/close relative
and form an opinion whether to certify or not to certify carrying out the instructions of withdrawal
or refusal of further medical treatment. This decision shall be regarded as a preliminary opinion.
(v) In the event the Hospital Medical Board certifies that the instructions contained in the Advance
Directive ought to be carried out, the physician/hospital shall forthwith inform the jurisdictional
Collector about the proposal. The jurisdictional Collector shall then immediately constitute a
Medical Board comprising the Chief District Medical Officer of the concerned district as the
Chairman and three expert doctors from the fields of general medicine, cardiology, neurology,
nephrology, psychiatry or oncology with experience in critical care and with overall standing in the
medical profession of at least twenty years (who were not members of the previous Medical Board of
the hospital). They shall jointly visit the hospital where the patient is admitted and if they concur
with the initial decision of the Medical Board of the hospital, they may endorse the certificate to
carry out the instructions given in the Advance Directive.
(vi) The Board constituted by the Collector must beforehand ascertain the wishes of the executor if
he is in a position to communicate and is capable of understanding the consequences of withdrawal
of medical treatment. In the event the executor is incapable of taking decision or develops impaired
decision making capacity, then the consent of the guardian nominated by the executor in the
Advance Directive should be obtained regarding refusal or withdrawal of medical treatment to the
executor to the extent of and consistent with the clear instructions given in the Advance Directive.
(vii) The Chairman of the Medical Board nominated by the Collector, that is, the Chief District
Medical Officer, shall convey the decision of the Board to the jurisdictional JMFC before giving
effect to the decision to withdraw the medical treatment administered to the executor. The JMFC
shall visit the patient at the earliest and, after examining all aspects, authorise the implementation
of the decision of the Board.
(viii) It will be open to the executor to revoke the document at any stage before it is acted upon and
implemented.
(e) What if permission is refused by the Medical Board?
(i) If permission to withdraw medical treatment is refused by the Medical Board, it would be open to
the executor of the Advance Directive or his family members or even the treating doctor or the
hospital staff to approach the High Court by way of writ petition under Article 226 of the
Constitution. If such application is filed before the High Court, the Chief Justice of the said High
Court shall constitute a Division Bench to decide upon grant of approval or to refuse the same. The
High Court will be free to constitute an independent Committee consisting of three doctors from the
fields of general medicine, cardiology, neurology, nephrology, psychiatry or oncology with
experience in critical care and with overall standing in the medical profession of at least twenty
years.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(ii) The High Court shall hear the application expeditiously after affording opportunity to the State
counsel. It would be open to the High Court to constitute Medical Board in terms of its order to
examine the patient and submit report about the feasibility of acting upon the instructions
contained in the Advance Directive.
(iii) Needless to say that the High Court shall render its decision at the earliest as such matters
cannot brook any delay and it shall ascribe reasons specifically keeping in mind the principles of
"best interests of the patient".
(f) Revocation or inapplicability of Advance Directive
(i) An individual may withdraw or alter the Advance Directive at any time when he/she has the
capacity to do so and by following the same procedure as provided for recording of Advance
Directive. Withdrawal or revocation of an Advance Directive must be in writing.
(ii) An Advance Directive shall not be applicable to the treatment in question if there are reasonable
grounds for believing that circumstances exist which the person making the directive did not
anticipate at the time of the Advance Directive and which would have affected his decision had he
anticipated them.
(iii) If the Advance Directive is not clear and ambiguous, the concerned Medical Boards shall not
give effect to the same and, in that event, the guidelines meant for patients without Advance
Directive shall be made applicable.
(iv) Where the Hospital Medical Board takes a decision not to follow an Advance Directive while
treating a person, then it shall make an application to the Medical Board constituted by the Collector
for consideration and appropriate direction on the Advance Directive.
192. It is necessary to make it clear that there will be cases where there is no Advance Directive. The
said class of persons cannot be alienated. In cases where there is no Advance Directive, the
procedure and safeguards are to be same as applied to cases where Advance Directives are in
existence and in addition there to, the following procedure shall be followed:-
(i) In cases where the patient is terminally ill and undergoing prolonged treatment in
respect of ailment which is incurable or where there is no hope of being cured, the
physician may inform the hospital which, in turn, shall constitute a Hospital Medical
Board in the manner indicated earlier. The Hospital Medical Board shall discuss with
the family physician and the family members and record the minutes of the
discussion in writing. During the discussion, the family members shall be apprised of
the pros and cons of withdrawal or refusal of further medical treatment to the patient
and if they give consent in writing, then the Hospital Medical Board may certify the
course of action to be taken. Their decision will be regarded as a preliminary opinion.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(ii) In the event the Hospital Medical Board certifies the option of withdrawal or
refusal of further medical treatment, the hospital shall immediately inform the
jurisdictional Collector. The jurisdictional Collector shall then constitute a Medical
Board comprising the Chief District Medical Officer as the Chairman and three
experts from the fields of general medicine, cardiology, neurology, nephrology,
psychiatry or oncology with experience in critical care and with overall standing in
the medical profession of at least twenty years. The Medical Board constituted by the
Collector shall visit the hospital for physical examination of the patient and, after
studying the medical papers, may concur with the opinion of the Hospital Medical
Board. In that event, intimation shall be given by the Chairman of the Collector
nominated Medical Board to the JMFC and the family members of the patient.
(iii) The JMFC shall visit the patient at the earliest and verify the medical reports,
examine the condition of the patient, discuss with the family members of the patient
and, if satisfied in all respects, may endorse the decision of the Collector nominated
Medical Board to withdraw or refuse further medical treatment to the terminally ill
patient.
(iv) There may be cases where the Board may not take a decision to the effect of
withdrawing medical treatment of the patient on the Collector nominated Medical
Board may not concur with the opinion of the hospital Medical Board.
In such a situation, the nominee of the patient or the family member or the treating doctor or the
hospital staff can seek permission from the High Court to withdraw life support by way of writ
petition under Article 226 of the Constitution in which case the Chief Justice of the said High Court
shall constitute a Division Bench which shall decide to grant approval or not. The High Court may
constitute an independent Committee to depute three doctors from the fields of general medicine,
cardiology, neurology, nephrology, psychiatry or oncology with experience in critical care and with
overall standing in the medical profession of at least twenty years after consulting the competent
medical practitioners. It shall also afford an opportunity to the State counsel. The High Court in
such cases shall render its decision at the earliest since such matters cannot brook any delay.
Needless to say, the High Court shall ascribe reasons specifically keeping in mind the principle of
"best interests of the patient"..
193. Having said this, we think it appropriate to cover a vital aspect to the effect the life support is
withdrawn, the same shall also be intimated by the Magistrate to the High Court. It shall be kept in a
digital format by the Registry of the High Court apart from keeping the hard copy which shall be
destroyed after the expiry of three years from the death of the patient.
194. Our directions with regard to the Advance Directives and the safeguards as mentioned
hereinabove shall remain in force till the Parliament makes legislation on this subject. Q.
Conclusions in seriatim:
195. In view of the aforesaid analysis, we record our conclusions in seriatim:-Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(i) A careful and precise perusal of the judgment in Gian Kaur (supra) case reflects
the right of a dying man to die with dignity when life is ebbing out, and in the case of
a terminally ill patient or a person in PVS, where there is no hope of recovery,
accelerating the process of death for reducing the period of suffering constitutes a
right to live with dignity.
(ii) The Constitution Bench in Gian Kaur (supra) has not approved the decision in
Airedale (supra) inasmuch as the Court has only made a brief reference to the
Airedale case.
(iii) It is not the ratio of Gian Kaur (supra) that passive euthanasia can be introduced
only by legislation.
(iv) The two-Judge bench in Aruna Shanbaug (supra) has erred in holding that this
Court in Gian Kaur (supra) has approved the decision in Airedale case and that
euthanasia could be made lawful only by legislation.
(v) There is an inherent difference between active euthanasia and passive euthanasia
as the former entails a positive affirmative act, while the latter relates to withdrawal
of life support measures or withholding of medical treatment meant for artificially
prolonging life.
(vi) In active euthanasia, a specific overt act is done to end the patient‘s life whereas
in passive euthanasia, something is not done which is necessary for preserving a
patient's life. It is due to this difference that most of the countries across the world
have legalised passive euthanasia either by legislation or by judicial interpretation
with certain conditions and safeguards.
(vii) Post Aruna Shanbaug (supra), the 241st report of the Law Commission of India
on Passive Euthanasia has also recognized passive euthanasia, but no law has been
enacted.
(viii) An inquiry into common law jurisdictions reveals that all adults with capacity to
consent have the right of self- determination and autonomy. The said rights pave the
way for the right to refuse medical treatment which has acclaimed universal
recognition. A competent person who has come of age has the right to refuse specific
treatment or all treatment or opt for an alternative treatment, even if such decision
entails a risk of death. The 'Emergency Principle' or the 'Principle of Necessity' has to
be given effect to only when it is not practicable to obtain the patient's consent for
treatment and his/her life is in danger. But where a patient has already made a valid
Advance Directive which is free from reasonable doubt and specifying that he/she
does not wish to be treated, then such directive has to be given effect to.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(ix) Right to life and liberty as envisaged under Article 21 of the Constitution is
meaningless unless it encompasses within its sphere individual dignity.
With the passage of time, this Court has expanded the spectrum of Article 21 to include within it the
right to live with dignity as component of right to life and liberty.
(x) It has to be stated without any trace of doubt that the right to live with dignity also includes the
smoothening of the process of dying in case of a terminally ill patient or a person in PVS with no
hope of recovery.
(xi) A failure to legally recognize advance medical directives may amount to non-facilitation of the
right to smoothen the dying process and the right to live with dignity. Further, a study of the
position in other jurisdictions shows that Advance Directives have gained lawful recognition in
several jurisdictions by way of legislation and in certain countries through judicial pronouncements.
(xii) Though the sanctity of life has to be kept on the high pedestal yet in cases of terminally ill
persons or PVS patients where there is no hope for revival, priority shall be given to the Advance
Directive and the right of self-determination.
(xiii) In the absence of Advance Directive, the procedure provided for the said category hereinbefore
shall be applicable.
(xiv) When passive euthanasia as a situational palliative measure becomes applicable, the best
interest of the patient shall override the State interest.
196. We have laid down the principles relating to the procedure for execution of Advance Directive
and provided the guidelines to give effect to passive euthanasia in both circumstances, namely,
where there are advance directives and where there are none, in exercise of the power under Article
142 of the Constitution and the law stated in Vishaka and Others v. State of Rajasthan and Others 65
. The directive and guidelines shall remain in force till the Parliament brings a legislation in the
field.
(1997) 6 SCC 241
197. The Writ Petition is, accordingly, disposed of. There shall be no order as to costs.
………………………….CJI (Dipak Misra) ..…………….…………….J. (A.M. Khanwilkar) New Delhi;
March 09, 2018 REPORTABLE IN THE SUPREME COURT OF INDIA CIVIL ORIGINAL
JURISDICTION WRIT PETITION (CIVIL) NO. 215 OF 2005 COMMON CAUSE (A REGD.
SOCIETY) .....APPELLANT(S) VERSUS UNION OF INDIA AND ANOTHER .....RESPONDENT(S)
JUDGMENT A.K. SIKRI, J.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Michael Kirby, a former Judge of the Australian High Court, while discussing about the role of
judiciary in the context of HIV law1, talks about the consciousness with which the judiciary is
supposed to perform its role. In this hue, while discussing about the responsibility of leadership
which the society imposes upon Judges, he remarks: “Nowhere more is that responsibility tested
than when a completely new and unexpected problem presents itself to society. All the judges’
instincts for legality, fairness and reasonableness must then be summoned up, to help lead society
towards an informed, intelligent and just solution to the problem.” 1 ‘The Role of Judiciary and HIV
Law’ – Michael Kirby, published in the book titled ‘HIV Law, Ethics and Human Rights’, edited by
D.C. Jayasuriya. The problem at hand, just solution whereof is imminently needed, is that of
Euthanasia. This Court is required to summon up instincts for legality, fairness and reasonableness
in order to find just solution to the problem. In this process, the Court is duty bound to look into the
relevant provisions of the Constitution of India, particularly those pertaining to the fundamental
rights, and to discharge the task of expounding those basic human rights enshrined in the Chapter
relating to Fundamental Rights. The issue of euthanasia, with the seminal importance that is
attached to it, has thrown the challenge of exposition, development and obligation of the
constitutional morality and exhorts the Court to play its creative role so that a balanced approach to
an otherwise thorny and highly debatable subject matter is found.
2) The Courts, in dispensation of their judicial duties of deciding cases, come across all types of
problems which are brought before them. These cases may be broadly classified into three
categories: (i) the easy cases, (ii) the intermediate cases, and (iii) the hard cases. Professor Ronald
Dworkin2 has argued that each legal problem has one lawful solution and even in the hard cases, the
Judge is never free to choose among alternatives that are all inside the bounds of law. This may not
be entirely correct 2 Dworkin, “Judicial Discretion,” 6 J. of Phil. 624 (1963) inasmuch as judicial
discretion does exist. This is true, at least, in solving ‘hard cases’3. It is found that meaning of
certain legal norms, when applied with respect to a given system of facts, is so simple and clear that
their application involves no judicial discretion. These are termed as the ‘easy cases’. This may even
apply to ‘intermediate cases’. These would be those cases where both sides appear to have a
legitimate legal argument supporting their position and a conscious act of interpretation is noted,
before a Judge can conclude which side is right in law and there is only one lawful situation.
However, when it comes to the hard cases, the Court is faced with number of possibilities, all of
which appear to be lawful within the context of the system. In these cases, judicial discretion exists
as the choice is not between lawful and unlawful, but between lawful and lawful. A number of lawful
solutions exist. In this scenario, the Court is supposed to ultimately choose that solution which is in
larger public interest. In other words, there are limitations that find the Court with respect to the
manner in which it choses among possibilities (procedural limitations) and with respect to the
considerations it takes into account in the choice (substantive limitations). Thus, discretion when
applied to a cout of justice means sound 3 See Aharon Barak: Judicial Discretion, Yale University
Press. discretion guided by law. It must be govered by legal rules. To quote Justice Cardozo:
“Given freedom of choice, how shall the choice be guided? Complete freedom –
unfettered and undirected – there never is. A thousand limitations – the product
some of statute, some of precedent, some of vague tradition or of an immemorial
technique – encompass and hedge us even when we think of ourselves as rangingCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

freely and at large. The inscrutable force of professional opinion presses upon us like
the atmosphere, though we are heedless of its weight. Narrow at best is any freedom
that is allotted to us4
3) Thus, though the judicial discretion is with the Court, the same is limited and not
absolute. The Court is not entitled to weigh any factor as it likes. It has to act within
the framework of the limitations, and after they have been exhausted, there is a
freedom of choice which can also described as ‘sovereign prerogative of choice’5.
Instant case falls in the category of ‘hard cases’ and the Court has endeavoured to
make a choice, after evaluating all the pros and cons, which in its wisdom is the “just
result” of the contentious issue.
4) Adverting to the Indian precedents in the first instance, we have before us two
direct judgments of this Court which may throw some light on the subject and
demonstrate as to how this topic has been dealt with so far. The first judgment is that
of a
4 B. Cardozo: The Growth of the Law 144 (1924), at 60-61 5 Justice O. Holmes opined this
expression in ‘Collected Legal Papers’ 239 (1921) Constitution Bench in the case titled Gian Kaur v.
State of Punjab6. Second case is known as Aruna Ramachandra Shanbaug v. Union of India and
Others 7, which is a Division Bench judgment that takes note of Gian Kaur and premised thereupon
goes much farther in accepting passive euthanasia as a facet of Article 21 of the Constitution.
5) In the instant case, while making reference to the Constitution Bench vide its order dated
February 25, 2014 8, the three Judge Bench has expressed its reservation in the manner the ratio of
the Constitution Bench in Gian Kaur is applied by the Division Bench in Aruna Ramachandra
Shanbaug. This reference order accepts that Aruna Ramachandra Shanbaug rightly interpreted the
decision in Gian Kaur insofar as it held that euthanasia can be allowed in India only through a valid
legislation. However, the reference order declares that Aruna Ramachandra Shanbaug has
committed a factual error in observing that in Gian Kaur the Constitution Bench approved the
decision of the House of Lords in Airedale N.H.S. Trust v. Bland9. As per the reference order, Gian
Kaur merely referred to the said judgment which cannot be construed to mean that the Constitution
Bench in Gian Kaur 6 (1996) 2 SCC 648 7 (2011) 4 SCC 454 8 Reported as (2014) 5 SCC 338 9 (1993)
2 WLR 316 (HL) approved the opinion of the House of Lords rendered in Bland.
The reference order also accepts the position that in Gian Kaur the Constitution Bench approved
that ‘right to live with dignity’ under Article 21 of the Constitution will be inclusive of ‘right to die
with dignity’. However, it further notes that the decision does not arrive at a conclusion for validity
of euthanasia, be it active or passive. Therefore, the only judgment that holds the field in India is
Aruna Ramachandra Shanbaug, which upholds the validity of passive euthanasia and lays down an
elaborate procedure for executing the same on ‘the wrong premise that the Constitution Bench in
Gian Kaur had upheld the same’.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

6) The aforesaid discussion contained in the reference order prompted the reference court to refer
the matter to the Constitution Bench. No specific questions were framed for consideration by the
Constitution Bench. However, importance of the issue has been highlighted in the reference order in
the following manner:
“17. In view of the inconsistent opinions rendered in Aruna Shanbaug and also
considering the important question of law involved which needs to be reflected in the
light of social, legal, medical and constitutional perspectives, it becomes extremely
important to have a clear enunciation of law. Thus, in our cogent opinion, the
question of law involved requires careful consideration by a Constitution Bench of
this Court for the benefit of humanity as a whole.
18. We refrain from framing any specific questions for consideration by the
Constitution Bench as we invite the Constitution Bench to go into all the aspects of
the matter and lay down exhaustive guidelines in this regard. Accordingly, we refer
this matter to a Constitution Bench of this Court for an authoritative opinion.”
7) I have given a glimpse of the narratives for the simple reason that the Hon’ble the
Chief Justice, in his elaborate opinion, has already discussed this aspect in detail.
Likewise, it can be found in the separate judgments authored by my esteemed
brethren – Chandrachud, J. and Bhushan, J. Those judgments discuss in detail the
law laid down in Gian Kaur as well as Aruna Ramachandra Shanbaug, including
critique thereof. To avoid repetition, I have eschewed that part of discussion. For the
same reason, I have also not ventured to discuss the law in some other countries and
historic judgments rendered by the courts of foreign jurisdiction, as this aspect is also
taken care of by them.
However, my analysis of the above two judgments is limited to the extent it is necessitated for
maintaining continuum and clarity of thought.
8) At the outset, I say that I am in complete agreement with the conclusion and also the directions
given therein in the judgment of the Hon’ble the Chief Justice and also with the opinions and
reasoning of my other two learned brothers. My purpose is not to add my ink to the erudite opinion
expressed in otherwise eloquent opinions penned by my learned brothers. At the same time, having
regard to the importance of the issue involved, I am provoked to express my own few thoughts, in
my own way, which I express hereinafter.
9) In the writ petition filed by the petitioner – Common Cause, it has made the following prayers:
“a) declare ‘right to die with dignity’ as a fundamental right within the fold of Right to
Live with dignity guaranteed under Article 21 of the Constitution of India;
b) issue direction to the Respondent, to adopt suitable procedures, in consultation
with State Governments where necessary, to ensure that persons of deterioratedCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

health or terminally ill should be able to execute a document titled “MY LIVING
WILL & ATTORNEY AUTHORISATION” which can be presented to hospital for
appropriate action in event of the executant being admitted to the hospital with
serious illness which may threaten termination of life of the executants or in the
alternative, issue appropriate guidelines to this effect;
c) appoint an expert committee of experts including doctors, social scientists and
lawyers to study into the aspect of issuing guidelines as to the Living Wills;
d) pass such other and further order/s as this Hon’ble Court may deem fit and proper
on the facts and in the circumstances of the case.”
10) Having regard to the aforesaid prayers, the reference order and the arguments
which were addressed by Mr. Prashant Bhushan, learned counsel who appeared for
the petitioner, and Mr. Arvind Datar, learned senior counsel who made elaborate
submissions on behalf of the interveners – Vidhi Centre for Legal Policy, and Mr.
R.R. Kishore, Advocate, who gave an altogether new dimension to the seminal issue, I
find that following issues/questions of law of relevance need to be discussed:
(i) Whether the Right to Live under Article 21 of the Constitution includes the Right
to Die? {Now that attempt to commit suicide is not a punishable offence under
Section 309 of the Indian Penal Code, 1860 (for short, ‘IPC’) vide Section 115 of the
Mental Healthcare Act, 2017 (Act No. 10 of 2017)}
(ii) Whether the ‘right to die with dignity’ as a fundamental right falls within the folds
of the ‘right to live with dignity’ under Article 21 of the Constitution?
(iii) Whether the observations in Aruna Ramachandra Shanbaug that the Constitution Bench in
Gian Kaur permitted passive euthanasia stand correct?
(iv) Whether there exists inconsistency in the observations in Aruna Ramachandra Shanbaug with
regard to what has been held in Gian Kaur?
(v) Whether mere reference to verdict in a judgment can be construed to mean that the verdict is
approved? {with respect to Article 141 – What is binding?; whether the Constitution Bench in Gian
Kaur approved the decision of the House of Lords in Bland?}
(vi) Whether the law on passive euthanasia, as held valid in Aruna Ramachandra Shanbaug, holds
true in the present times as well? {The Treatment of Terminally-ill Patients Bill, 2016 is based on the
aforementioned judgment}
(vii) Whether active euthanasia is legal in India?Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(viii) Whether assisted suicide/physician administered suicide is legal in India? {The 2016 bill in the
current form, under Clause 5(3) permits for physician assisted suicide}
(ix) Whether there exists a right to a Living Will/Advance Directives? Whether there exists the
fundamental right to choose one’s own medical treatment? {With Right to Privacy now a
fundamental right under Article 21, the principle of self-determination in India stands on a higher
footing than before}
(x) Definition of ‘Terminal Illness’.
11) It is not necessary for me to answer all the aforesaid questions. I say so for the reason that all
these aspects are dealt with by the Hon’ble the Chief Justice in his opinion. Therefore, in this
‘addendum’, I would be focusing myself to the core issues. EUTHANASIA DEFINED
12) The Oxford English Dictionary defines ‘euthanasia’ as ‘the painless killing of a patient suffering
from an incurable and painful disease or in an irreversible coma’. The word appears to have come
into usage in the early 17 th century and was used in the sense of ‘easy death’. The term is derived
from the Greek ‘euthanatos’, with ‘eu’ meaning well, and ‘thanatos’ meaning death. In ancient
Greece and Rome, citizens were entitled to a good death to end the suffering of a terminal illness. To
that end, the City Magistrates of Athens kept a supply of poison to help the dying ‘drink the
hemlock’10.
13) The above Greek definition of euthanasia apart, it is a loaded term. People have been grappling
with it for ages. Devised for service in a rhetoric of persuasion, the term ‘euthanasia’ has no
generally accepted and philosophically warranted core meaning. It is also defined as: killing at the
request of the person killed. That is how the Dutch medical personnel and civil authorities define
euthanasia. In Nazi discourse, euthanasia was any killing carried out by medical means or medically
qualified personnel, 10 Michael Manning, Euthanasia and Physician-Assisted Suicide (Paulist Press,
1998). whether intended for the termination of suffering and/or of the burden or indignity of a life
not worth living (Lebensunwertes Leben), or for some more evidently public benefit such as
eugenics (racial purity and hygiene), Lebensraum (living space for Germans), and/or minimizing
the waste of resources on ‘useless mouths’. Understandably, in today’s modern democracies these
Nazi ideas and practices cannot be countenanced. Racist eugenics are condemned, though one
comes across discreet allusions to the burden and futility of sustaining the severely mentally
handicapped. The popular conception which is widely accepted is that some sorts of life are not
worth living; life in such a state demeans the patient’s dignity, and maintaining it (otherwise than at
the patient’s express request) insults that dignity; proper respect for the patient and the patient’s
best interests requires that that life be brought to an end. In this thought process, the basic Greek
ideology that it signifies ‘an easy and gentle death’ still remains valid. Recognition is to the Human
Rights principle that ‘right to life’ encompasses ‘right to die with dignity’.
14) In common parlance, euthanasia can be of three types, namely, ‘voluntary euthanasia’ which
means killing at the request of a person killed which is to be distinguished from ‘non-voluntary
euthanasia’, where the person killed is not capable of either making or refusing to make such aCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

request. Second type of euthanasia would be involuntary euthanasia where the person killed is
capable of making such a request but has not done so 11. These terms can be described as under:
(i) Voluntary Euthanasia: People concerned to legalize the termination of life on
medical grounds have always concentrated on Voluntary Euthanasia (this implies
that the patient specifically requests that his life be ended.) It is generally agreed that
the request must come from someone who is either; (a) in intolerable pain or (b) who
is suffering from an illness which is agreed as being terminal. It may be prior to the
development of the illness in question or during its course. In either case it must not
result from any pressure from relatives or those who have the patients in their care.
Both active and passive euthanasia can be termed as forms of voluntary euthanasia.
(ii) Non-Voluntary Euthanasia: Seen by some as sub-variety of voluntary euthanasia.
This involves the death, ostensibly for his own good, of someone who cannot express
any views on the matter and who must, therefore, use some sort of proxy request
11 These definitions of voluntary, non-voluntary and involuntary euthanasia correspond to those
employed by the House of Lords Select Committee on Medical Ethics (Walton Committee) that
his/her life be ended. This form of Euthanasia is that which most intimately concerns the medical
profession. Selective non- treatment of the new-born or the doctor may be presented with demented
and otherwise senilely incompetent patients. In practice, non-voluntary euthanasia presents only as
an arguable alternative to non treatment.
(iii) Involuntary Euthanasia: It involves ending the patient’s life in the absence of either a personal
or proxy invitation to do so. The motive ‘The relief of suffering’ may be the same as voluntary
euthanasia-but its only justification - “a paternalistic decision as to what is best for the victim of the
disease.” In extreme cases it could be against the patient’s wishes or could be just for social
convenience. It is examples of the latter which serve as warnings as to those who would invest the
medical professional with more or unfettered powers over life and death 12.
15) Contrary to the above, in legal parlance, euthanasia has since come to be recognised as of two
distinct types: the first is active euthanasia, where death is caused by the administration of a lethal
injection or drugs. Active euthanasia also includes physician-assisted suicide, where the injection or
drugs are supplied by the physician, but the act of administration is 12 See Euthanasia and Its
Legality and Legitimacy from Indian and International Human Right Instruments Perspectives
published in Human Rights & Social Justice by Muzafer Assadi undertaken by the patient himself.
Active euthanasia is not permissible in most countries. The jurisdictions in which it is permissible
are Canada, the Netherlands, Switzerland and the States of Colorado, Vermont, Montana,
California, Oregon and Washington DC in the United States of America. Passive euthanasia occurs
when medical practitioners do not provide life- sustaining treatment (i.e. treatment necessary to
keep a patient alive) or remove patients from life sustaining treatment. This could include
disconnecting life support machines or feeding tubes or not carrying out life saving operations or
providing life extending drugs. In such cases, the omission by the medical practitioner is not treated
as the cause of death; instead, the patient is understood to have died because of his underlyingCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

condition.
16) In Aruna Ramachandra Shanbaug, the Court recognised these two types of euthanasia i.e. active
and passive. It also noted that active euthanasia is impermissible, which was so held by the
Constitution Bench in Gian Kaur. Therefore, without going into further debate on differential that is
assigned to the term euthanasia, ethically, philosophically, medically etc., we would be confining
ourselves to the aforesaid legal meaning assigned to active and passive euthanasia. Thus, insofar as
active euthanasia is concerned, this has to be treated as legally impermissible, at least for the time
being. It is more so, as there is absence of any statutory law permitting active euthanasia. If at all,
legal provisions in the form of Sections 306 and 307 IPC etc. point towards its criminality. The
discussion henceforth, therefore, would confine to passive euthanasia. PASSIVE EUTHANASIA
AND ARUNA RAMACHANDRA SHANBAUG
17) In Aruna Ramachandra Shanbaug, a two Judges’ Bench of this Court discussed in much greater
detail various nuances of euthanasia by referring to active and passive euthanasia as well as
voluntary and involuntary euthanasia; legality and permissibility thereof; relationship of euthanasia
vis-a-vis offences concerned under the IPC and doctor assisted death; etc.
18) The Court also took note of legislations in some countries relating to euthanasia or physician
assisted death. Thereafter, it discussed in detail the judgment in Bland wherein the House of Lords
had permitted the patient to die. Ratio of Bland was culled out in the following manner:
“Airedale (1993) decided by the House of Lords has been followed in a number of
cases in UK, and the law is now fairly well settled that in the case of incompetent
patients, if the doctors act on the basis of informed medical opinion, and withdraw
the artificial life support system if it is in the patient’s best interest, the said act
cannot be regarded as a crime.”
19) The Court was of the opinion that this should be permitted when the patient is in
a Persistent Vegitative State (PVS) and held that it is ultimately for the Court to
decide, as parens patriae, as to what is in the best interest of the patient. The wishes
of the close relatives and next friends and opinion of the medical practitioners should
be given due weight by the Court in coming to its decision.
The Court then noted the position of euthanasia with reference to Section 306 (abetment of suicide)
and Section 309 (attempt to commit suicide) of the IPC, inasmuch as, even allowing passive
euthanasia may come in conflict with the aforesaid provisions which make such an act a crime.
While making a passing observation that Section 309 should be deleted by the Parliament as it has
become anachronistic, the Court went into the vexed question as to who can decide whether life
support should be discontinued in the case of an incompetent person, e.g. a person in coma or PVS.
The Court pointed out that it was a vexed question, both because of its likely misuse and also
because of advancement in medical science. It noted:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

“104. It may be noted that in Gian Kaur case although the Supreme Court has quoted
with approval the view of the House of Lords in Airedale case, it has not clarified who
can decide whether life support should be discontinued in the case of an incompetent
person e.g. a person in coma or PVS. This vexed question has been arising often in
India because there are a large number of cases where persons go into coma (due to
an accident or some other reason) or for some other reason are unable to give
consent, and then the question arises as to who should give consent for withdrawal of
life support. This is an extremely important question in India because of the
unfortunate low level of ethical standards to which our society has descended, its raw
and widespread commercialisation, and the rampant corruption, and hence, the
Court has to be very cautious that unscrupulous persons who wish to inherit the
property of someone may not get him eliminated by some crooked method.
105. Also, since medical science is advancing fast, doctors must not declare a patient
to be a hopeless case unless there appears to be no reasonable possibility of any
improvement by some newly discovered medical method in the near future. In this
connection we may refer to a recent news item which we have come across on the
internet of an Arkansas man Terry Wallis, who was 19 years of age and newly married
with a baby daughter when in 1984 his truck plunged through a guard rail, falling 25
feet. He went into coma in the crash in 1984, but after 24 years he has regained
consciousness. This was perhaps because his brain spontaneously rewired itself by
growing tiny new nerve connections to replace the ones sheared apart in the car
crash. Probably the nerve fibres from Terry Wallis' cells were severed but the cells
themselves remained intact, unlike Terri Schiavo, whose brain cells had died (see
Terri Schiavo case on Google). However, we make it clear that it is experts like
medical practitioners who can decide whether there is any reasonable possibility of a
new medical discovery which could enable such a patient to revive in the near future.”
20) It held that passive euthanasia would be permissible when a person is ‘dead’ in
clinical sense. It chose to adopt the standard of ‘brain death’, i.e. when there is an
‘irreversible cessation of all functions of the entire brain, including the brain stem’.
The Court took note of President’s Committee on Bioethics in the United States of
America which had come up with a new definition of ‘brain death’ in the year 2008,
according to which a person was considered to be braindead when he could no longer
perform the fundamental human work of an organism. Three such situations
contemplated in that definition are the following:
“(1) openness to the world, that is receptivity to stimuli and signals from the
surrounding environment, (2) the ability to act upon the world to obtain selectively
what it needs, and (3) the basic felt need that drives the organism to act ... to obtain
what it needs.”
21) The Court held that when the aforesaid situation is reached, a person can be
presumed to be dead. In paragraph 115 of the judgment, the position is summed upCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

as under:
“When this situation is reached, it is possible to assume that the person is dead, even
though he or she, through mechanical stimulation, may be able to breathe, his or her
heart might be able to beat, and he or she may be able to take some form of
nourishment. It is important, thus, that it be medically proved that a situation where
any human functioning would be impossible should have been reached for there to be
a declaration of brain death —situations where a person is in a persistent vegetative
state but can support breathing, cardiac functions, and digestion without any
mechanical aid are necessarily those that will not come within the ambit of brain
death.”
22) The Court clarified that brain death was not the same as PVS inasmuch as in PVS
the brain stem continues to work and so some degree of reactions may occur, though
the possibility of regaining consciousness is relatively remote.
23) The Court further opined that position in the case of euthanasia would be slightly
different and pointed out that the two circumstances in which it would be fair to
disallow resuscitation of a person who is incapable of expressing his or her consent to
the termination of his or her life. These are:
“(a) When a person is only kept alive mechanically i.e. when not only consciousness is
lost, but the person is only able to sustain involuntary functioning through advanced
medical technology— such as the use of heart-lung machines, medical ventilators, etc.
(b) When there is no plausible possibility of the person ever being able to come out of
this stage.
Medical “miracles” are not unknown, but if a person has been at a stage where his life is only
sustained through medical technology, and there has been no significant alteration in the person's
condition for a long period of time—at least a few years—then there can be a fair case made out for
passive euthanasia.”
24) Taking a clue from the judgment in Vishaka and Others v. State of Rajasthan and Others13, the
Court laid down the law, while allowing passive euthanasia, i.e. the circumstances when there 13
(1997) 6 SCC 241 could be withdrawal of life support of a patient in PVS. This is stated in paragraph
124 of the judgment, which we reproduce below:
“124. There is no statutory provision in our country as to the legal procedure for
withdrawing life support to a person in PVS or who is otherwise incompetent to take
a decision in this connection. We agree with Mr Andhyarujina that passive
euthanasia should be permitted in our country in certain situations, and we disagree
with the learned Attorney General that it should never be permitted. Hence, following
the technique used in Vishaka case [Vishaka v. State of Rajasthan, we are laying downCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

the law in this connection which will continue to be the law until Parliament makes a
law on the subject:
(i) A decision has to be taken to discontinue life support either by the parents or the
spouse or other close relatives, or in the absence of any of them, such a decision can
be taken even by a person or a body of persons acting as a next friend. It can also be
taken by the doctors attending the patient. However, the decision should be taken
bona fide in the best interest of the patient.
In the present case, we have already noted that Aruna Shanbaug's parents are dead and other close
relatives are not interested in her ever since she had the unfortunate assault on her. As already
noted above, it is the KEM Hospital staff, who have been amazingly caring for her day and night for
so many long years, who really are her next friends, and not Ms Pinki Virani who has only visited
her on few occasions and written a book on her. Hence it is for the KEM Hospital staff to take that
decision. KEM Hospital staff have clearly expressed their wish that Aruna Shanbaug should be
allowed to live.
Mr Pallav Shishodia, learned Senior Counsel, appearing for the Dean, KEM Hospital, Mumbai,
submitted that Ms Pinki Virani has no locus standi in this case. In our opinion it is not necessary for
us to go into this question since we are of the opinion that it is the KEM Hospital staff who is really
the next friend of Aruna Shanbaug.
We do not mean to decry or disparage what Ms Pinki Virani has done. Rather, we wish to express
our appreciation of the splendid social spirit she has shown. We have seen on the internet that she
has been espousing many social causes, and we hold her in high esteem. All that we wish to say is
that however much her interest in Aruna Shanbaug may be it cannot match the involvement of the
KEM Hospital staff who have been taking care of Aruna day and night for 38 years.
However, assuming that the KEM Hospital staff at some future time changes its mind, in our
opinion in such a situation KEM Hospital would have to apply to the Bombay High Court for
approval of the decision to withdraw life support.
(ii) Hence, even if a decision is taken by the near relatives or doctors or next friend to withdraw life
support, such a decision requires approval from the High Court concerned as laid down in Airedale
case. In our opinion, this is even more necessary in our country as we cannot rule out the possibility
of mischief being done by relatives or others for inheriting the property of the patient.”
25) It can be discerned from the reading of the said judgment that court was concerned with the
question as to whether one can seek right to die? This question has been dealt with in the context of
Article 21 of the Constitution, namely, whether this provision gives any such right. As is well-known,
Article 21 gives ‘right to life’ and it is guaranteed to all the citizens of India. The question was as to
whether ‘right to die’ is also an integral part of ‘right to life’. In Gian Kaur this ‘right to die’ had not
been accepted as an integral part of ‘right to life’. The Court in Aruna Ramachandra Shanbaug
maintained this position insofar as an active euthanasia is concerned. However, passive euthanasia,Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

under certain circumstances, has been accepted.
26) It may be pertinent to mention that the petitioner (Aruna) in the said case was working as a
nurse in the King Edward Memorial Hospital (KEM), Parel, Mumbai. The tragic incident happened
on the evening of 27th November, 1973. Aruna was attacked by a sweeper in the hospital who
wrapped a dog chain around her neck and yanked her back with it. He tried to rape her but on
finding that she was menstruating, he sodomized her. To immobilize her during this act, he twisted
the chain around her neck. She was found unconscious by one cleaner on the next day. Her body
was on the floor and blood was all over the floor. The incident did not allow oxygen to reach her
brain as a result of which her brain got damaged.
27) The petition was filed by Ms. Pinki Virani as next friend of Aruna Shanbaug. According to facts
of the case, Aruna has been surviving on mashed food as she was not able to chew or taste any food
and she could not move her hands or legs. It is alleged that there is not the slightest possibility of
any improvement in her condition and her body lies on the bed in the KEM Hospital like a dead
animal, and this has been the position for the last 36 years. The prayer of the petitioner was that the
respondents be directed to stop feeding Aruna, and let her die peacefully.
28) The court appointed a team of three eminent and qualified doctors to investigate and report on
the medical condition of Aruna. The team included, Dr. J.V. Divatia 14, Dr. Roop Gursahani15 and
Dr. Nilesh Shah16. The team of doctors studied her medical history and observed that Aruna would
get uncomfortable if the room in which she was located was over crowded, she was calm when fewer
people were around her. In fact, the hospital staff had taken care and was willing to continue to do
so. Moreover, Aruna’s body language did not suggest that she wants to die. Therefore, the doctors
opined that there is no need for euthanasia in the instant case.
29) Reliance was placed on the landmark judgment of the House of Lords in Bland, where for the
first time in the English history, the right to die was allowed through the withdrawal of life support
14 Professor and Head, Department of Anesthesia, Critical Care and Pain at Tata Memorial
Hospital, Mumbai.
15 Consultant Neurologist at P.D. Hinduja, Mumbai. 16 Professor and Head, Department of
Psychiatry at Lokmanya Tilak Municipal Corporation Medical College and General Hospital.
systems including food and water. This case placed the authority to decide whether a case is fit or
not for euthanasia in the hands of the court. In this case, Aruna did not have the capacity to consent
for the proposed medical process. Therefore, the next big question that was to be answered was who
should decide on her behalf.
30) Since, there was no relative traced directly, nor did she have any frequent visitor who could
relate to her, it was extremely crucial for the court to declare who should decide on her behalf. As
there was lack of acquaintance, it was decided by beneficence. Beneficence is acting in the interest
that is best for the patient, and is not influenced by personal convictions, motives or other
considerations. Public interest and the interests of the state were also considered in the said matter.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

31) On the aforesaid principle of beneficence and studying the position in some other countries, the
court in its judgment said, the right to take decision on behalf of Aruna was vested with the hospital
and its management and not Ms. Pinki. The court also said that allowing euthanasia would mean
reversing the efforts of the hospital and its staff. In order to ensure that there is no misuse of this
technique, the Supreme Court has vested the power with the High Court to decide if life is to be
terminated or not.
32) Thus, the Supreme Court allowed passive euthanasia in certain conditions, subject to the
approval by the High Court following the due procedure. It held that when an application for passive
euthanasia is filed the Chief Justice of the High Court should forthwith constitute a Bench of at least
two Judges who should decide to grant approval or not. Before doing so, the Bench should seek the
opinion of a committee of three reputed doctors to be nominated by the Bench after consulting such
medical authorities/medical practitioners as it may deem fit. Simultaneously with appointing the
committee of doctors, the High Court Bench shall also issue notice to the State and close relatives
e.g. parents, spouse, brothers/sisters etc. of the committee to them as soon as it is available. After
hearing them, the High Court Bench should give its verdict. The above procedure should be followed
all over India until Parliament makes legislation on this subject. I am not carrying out the critique of
this judgment at this stage and the manner in which it has been analysed by those who are the
proponents of passive euthanasia and those who are against it. It is, more so, when my Brother,
Chandrachud, J., has dealt with this aspect in detail in his discourse. In any case, as noted above, in
view of the reference order dated February 25, 2014, the validity of this aspect has to be examined,
which exercise is undertaken by me at an appropriate stage.
EUTHANASIA: A COMPLEX CONCEPT
33) As discussed hereinafter, issue of euthanasia is a complexed and complicated issue over which
there have been heated debates, not only within the confines of courts, but also among elites,
intelligentsia and academicians alike. Some of these complexities may be captured at this stage
itself.
34) The legal regime webbed by various judgments rendered by this Court would reflect that the
Indian position on the subject is somewhat complex and even complicated to certain extend. First,
let us touch the topic from the constitutional angle.
35) Article 21 of the Constitution mandates that no person shall be deprived of his life or personal
liberty, except according to the procedure established by law. This Article has been interpreted by
the Court in most expansive terms, particularly when it comes to the meaning that is assigned to
‘right to life’. It is not necessary to take stock of various faces of right to life defined by this Court.
What is important for our purpose is to point out that right to life has been treated as more than
‘mere animal existence’. In Kharak Singh v. State of U.P. & Ors.17 it was held that the word ‘life’ in
Article 21 means right to live with human dignity and it does not merely connote continued
drudgery. It takes within its fold “some of the finer graces of human civilisation, which makes life
worth living” and that the expanded concept of life would mean the “tradition, culture and heritage”
of the concerned person. This concept has been reiterated and reinforced, time and again, in a seriesCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

of judgments. It may not be necessary to refer to those judgments. Suffice is to mention that a nine
Judge Constitution Bench of this Court in K.S. Puttaswamy and Another v. Union of India and
Others18 has taken stock of all important judgments which have echoed the message enshrined in
Kharak Singh’s case. We may, however, point out that in the case of C.E.S.E. Limited and Others v.
Subhash Chandra Bose and Others19, Justice K. Ramaswamy observed that physical and mental
health have to be treated as integral part of right to life, because without good health the civil and
political rights assured by our Constitution cannot be (1964) 1 SCR 332 18 (2017) 10 SCC 1 19 (1992)
1 SCC 441 enjoyed. Though Justice Ramaswamy rendered minority opinion in that case, on the
aforesaid aspect, majority opinion was not contrary to the views expressed by Justice Ramaswamy.
Thus, Article 21 recognizes right to live with human dignity 20.
36) The question that arises at this juncture is as to whether right to life enshrined in Article 21 of
the Constitution includes right to die. If such a right is recognised, that would provide immediate
answer to the issue involved, which is pertaining to voluntary or passive euthanasia. However, the
judgments of this Court, as discussed hereinafter, would demonstrate that no straightforward
answer is discernible and, as observed above, the position regarding euthanasia is somewhat
complex in the process.
37) It would be interesting to point out that in Rustom Cavasjee Cooper v. Union of India21 the
Court held that what is true of one fundamental right is also true of another fundamental right. This
Court also made a specific observation that there cannot be serious dispute about the proposition
that fundamental rights have their positive as well as negative aspect. For example, freedom of
speech and expression includes freedom not to speak. Likewise, freedom of association and
movement includes 20 Aspects of human dignity as right to life in the context of euthanasia shall be
discussed in greater detail at the relevant stage.
21 (1970) 1 SCC 248 freedom not to join any association or move anywhere. Freedom of business
includes freedom not to do any business. In this context, can it be said that right to life includes
right to die or right to terminate ones own life? The Constitution Bench in Gian Kaur, however, has
taken a view that right to live will not include right not to live.
38) We have already pointed out that Section 306 of the IPC makes abetment to suicide as a
punishable offence. Likewise, Section 309 IPC makes attempt to commit suicide as a punishable
offence. Intention to commit suicide is an essential ingredient in order to constitute an offence
under this provision. Thus, this provision specifically prohibits a person from terminating his life
and negates right to die. Constitutional validity of this provision, on the touchstone of Article 21, was
the subject matter of Gian Kaur’s case22. The Court held Sections 306 and 309 IPC to be
constitutionally valid. While so holding, the Court observed that when a man commits suicide, he
has to undertake certain 22 It may be noted that the Delhi High Court in State v. Sanjay Kumar,
(1985) Crl.L.J. 931, and the Bombay High Court in Maruti Sharipati Dubai v. State of Maharashtra,
(1987) Crl.L.J. 743, had taken the view that Section 309 of IPC was unconstitutional, being violative
of Articles 14 and 21 of the Constitution. On the other hand, the Andhra Pradesh High Court in C.
Jagadeeswar v. State of Andhra Pradesh, (1983) Crl.L.J. 549, had upheld the validity of Section 309
holding that it did not offend either Article 14 or Article 21 of the Constitution. A Division Bench ofCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

this Court in R. Rathinam v. Union of India and Another, (1994) 3 SCC 394, had held that Section
309 IPC deserves to be effaced from the statute book to humanise our penal laws, terming this
provision as cruel and irrational, which results in punishing a person again who had already
suffered agony and would be undergoing ignominy because of his failure to commit suicide. It is in
this backdrop Gian Kaur’s case was referred to and decided by the Constitution Bench. positive overt
acts and the genesis of those acts cannot be traced to, or be included within the protection of the
‘right to life’ under Article 21. The significant aspect of ‘sanctity of life’ is also not to be overlooked.
Article 21 is a provision guaranteeing protection of life and personal liberty and by no stretch of
imagination can ‘extinction of life’ be read to be included in ‘protection of life’. Whatever may be the
philosophy of permitting a person to extinguish his life by committing suicide, the Court found it
difficult to construe Article 21 to include within it the ‘right to die’ as a part of the fundamental right
guaranteed therein. ‘Right to life’ is a natural right embodied in Article 21 but suicide is an unnatural
termination or extinction of life and, therefore, incompatible and inconsistent with the concept of
‘right to life’.
Thus, the legal position which stands as of today is that right to life does not include right to die. It is
in this background we have to determine the legality of passive euthanasia.
39) Matter gets further complicated when it is examined in the context of morality of medical
science (Hippocratic Oath). Every doctor is supposed to take specific oath that he will make every
attempt to safe the life of the patient whom he/she is treating and who is under his/her treatment.
The Hippocratic Oath goes on to say:
“I swear by Apollo the Healer, by Asclepius, by Hygieia, by Panacea, and by all the
gods and goddesses, making them my witnesses, that I will carry out, according to my
ability and judgment, this oath and this indenture.
To hold my teacher in this art equal to my own parents; to make him partner in my
livelihood; when he is in need of money to share mine with him; to consider his
family as my own brothers, and to teach them this art, if they want to learn it, without
fee or indenture; to impart precept, oral instruction, and all other instruction to my
own sons, the sons of my teacher, and to indentured pupils who have taken the
physician’s oath, but to nobody else.
I will use treatment to help the sick according to my ability and judgment, but never
with a view to injury and wrong-doing. Neither will I administer a poison to anybody
when asked to do so, nor will I suggest such a course. Similarly I will not give to a
woman a pessary to cause abortion. But I will keep pure and holy both my life and my
art. I will not use the knife, not even, verily, on sufferers from stone, but I will give
place to such as are craftsmen therein.
Into whatsoever houses I enter, I will enter to help the sick, and I will abstain from all
intentional wrong-doing and harm, especially from abusing the bodies of man or
woman, bond or free. And whatsoever I shall see or hear in the course of myCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

profession, as well as outside my profession in my intercourse with men, if it be what
should not be published abroad, I will never divulge, holding such things to be holy
secrets.
Now if I carry out this oath, and break it not, may I gain for ever reputation among all
men for my life and for my art; but if I break it and forswear myself, may the opposite
befall me.”
40) This oath, thus, puts a moral and professional duty upon a doctor to do
everything possible, till the last attempt, to save the life of a patient. If that is so,
would it not be against medical ethics to let a person die by withdrawing medical aid
or, even for that matter, life supporting instruments. Paradoxically, advancement in
medical science has compounded the issue further. There has been a significant
advancement in medical science. Medical scientists have been, relentlessly and
continuously, experimenting and researching to find out better tools for not only
curing the disease with which human beings suffer from time to time, noble attempt
is to ensure that human life is prolonged and in the process of enhancing the
expectancy of life, ailments and sufferings therefrom are reduced to the minimal.
There is, thus, a fervent attempt to impress the quality of life. It is this very
advancement in the medical science which creates dilemma at that juncture when, in
common perception, life of a person has virtually become unlivable but the medical
doctors, bound by their Hippocratic Oath, want to still spare efforts in the hope that
there may still be a chance, even if it is very remote, to bring even such a person back
to life. The issue, therefore, gets compounded having counter forces of medical
science, morality and ethical values, the very concept of life from philosophical angle.
In this entire process, as indicated in the beginning and demonstrated in detail at the
appropriate stage, the vexed question is to be ultimately decided taking into
consideration the normative law, and in particular, the constitutional values.
41) Then, there is also a possibility of misuse and it becomes a challenging task to
ensure that passive euthanasia does not become a tool of corruption and a convenient
mode to ease out the life of a person who is considered inconvenient. This aspect
would be touched upon at some length at the appropriate stage.
This point is highlighted at this juncture just to demonstrate the complexity of the issue.
42) I may add that the issue is not purely a legal one. It has moral and philosophical overtones. It
has even religious overtones. As Professor Upendra Baxi rightly remarks that judges are, in fact, not
jurisprudes. At the same time, it is increasingly becoming important that some jurisprudential
discussion ensues while deciding those cases which have such more and philosophical overtones as
well. Such an analyses provides not only legal basis for the conclusions arrived at but it also provides
logical commonsense justification as well. Obviously, whenever the court is entering into a new
territory and is developing a new legal norm, discussion on normative jurisprudence assumes
greater significance as the court is called upon to decide what the legal norm should be. At the sameCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

time, this normative jurisprudence discourse has to be preceded by analytical jurisprudence, which
is necessary for the court to underline existing nature of law.
That would facilitate knowing legal framework of what is the current scenario and, in turn, help in
finding the correct answers. When we discuss about the philosophical aspects of the subject matter,
it is the ‘value of life’ which becomes the foremost focus of discussion. The discussion which follows
hereinafter keeps in mind these parameters.
THE TWO ISSUES
43) As already stated above, as of now insofar ‘active euthanasia’ is concerned, it is legally
impermissible. Our discussion centres around ‘passive euthanasia’. Another aspect which needs to
be mentioned at this stage is that in the present petition filed by the petitioner, the petitioner wants
that ‘advance directive’ or ‘living will’ should be legally recognised. In this backdrop, two important
questions arise for considerations, viz., (I) whether passive euthanasia, voluntary or even, in certain
circumstances, involuntary, is legally permissible? If so under what circumstances (this question
squarely calls for answer having regards to the reference order made in the instant petition)? and
(II) whether a ‘living will’ or ‘advance directive’ should be legally recognised and can be enforced? If
so, under what circumstances and what precautions are required while permitting it?
44) Answers to these questions have been provided in the judgment of Hon’ble The Chief Justice,
with excellent discourse on all relevant aspects in an inimitable and poetic style. I entirely agree with
the reasoning and outcome. In fact, with the same fervour and conclusion, separate judgments are
written by my brothers, Dhananjay Chandrachud and Ashok Bhushan, JJ. exhibiting expected
eloquence and erudition. I have gone through those opinions and am in complete agreement
thereby. In this scenario, in my own way, I intend to deal with the aforesaid questions on the
following hypothesis:
(i) Issue of passive euthanasia is highly debatable, controversial and complex
(already indicated above).
(ii) It is an issue which cannot be put strictly within the legal confines, but has social,
philosophical, moral and even religious overtones.
(iii) When the issue of passive euthanasia is considered on the aforesaid parameters,
one would find equally strong views on both sides. That is the reason which makes it
a thorny and complex issue and brings within the category of ‘hard cases’.
(iv) In this entire scenario when the issue is considered in the context of dignity of the
person involved, one may tend to tilt in favour of permitting passive euthanasia.
(v) At the same time, in order to achieve a balance, keeping in view the competing
and conflicting interests, care can be taken to confine permissibility of passive
euthanasia only in rare cases, particularly, when the patient is declared ‘brain dead’Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

or ‘clinically dead’ with virtually no chances of revival.
(vi) In this process, as far as ‘living will’ or ‘advance directive’ is concerned, that
needs to be permitted, along with certain safeguards. It would not only facilitate
prevention of any misuse but take care of many apprehensions expressed about
euthanasia.
With the outlining of the structured process as aforesaid, I proceed to discuss these aspects in detail
hereinafter.
45) As pointed out above, Aruna Ramachandra Shanbaug decides that passive euthanasia, even
involuntary, in certain circumstances would be justified. The reference order in the instant case,
however, mentions that for coming to this conclusion, the Bench relied upon Gian Kaur, but that
case does not provide any such mandate. In this backdrop, we take up the first question about the
legality of passive euthanasia. FIRST ISSUE Whether passive euthanasia, voluntary or even, in
certain circumstances, involuntary, is legally permissible? If so under what circumstances (this
question squarely calls for answer having regards to the reference order made in the instant
petition)?
46) I intend to approach this question by discussing the following facets thereof:
               (a)     Philosophy of euthanasia
               (b)     Morality of euthanasia
               (c)     Dignity in euthanasia
               (d)     Economics of euthanasia
(A)     Philosophy of Euthanasia
“I am the master of my fate; I am the captain of my soul”
- William Ernest Henley23 “Death is our friend … he delivers us from agony. I do not want to die of
a creeping paralysis of my faculties – a defeated man.”
- Mahatma Gandhi24 “When a man’s circumstances contain a preponderance of things in
accordance with nature, it is appropriate for him to remain alive; when possess or sees in prospect a
majority of contrary, it is appropriate for him to depart from life.”
- Marcus Tullius Cicero 23 As quoted in P. Rathinam v. Union of India & Anr., (1994) 3 SCC 394 24
Same as in 14 above.
“Euthanasia, and especially physician-assisted suicide, appears as the ultimate post-modern
demand for dignity in an era of technologically-mediated death.”
- Dr. Jonathan MorenoCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

47) The afore-quoted sayings of some great persons bring out a fundamental truth with universal
applicability. Every persons wants to lead life with good health and all kinds of happiness. At the
same time, nobody wants any pain, agony or sufferings when his or her life span comes to an end
and that person has to meet death. The following opening stanza from a song in a film captures this
message beautifully:
    ,         
  “Every person in this world comes crying. However, that person who leaves
the world laughing/smiling will be the luckiest of all” (Hindi Film – Muqaddar Ka
Sikandar)
48) It became unbearable for young prince Siddharth when he, for the first time, saw
an old crippled man in agony and a dead body being taken away. He did not want to
encounter such a situation in his old life and desired to attain Nirvana which
prompted him to renounce the world so that he could find the real purpose of life;
could lead a life which is worth living; and depart this world peacefully. He successfully achieved
this purpose of life and became Gautam Buddha. There are many such similar examples.
Life is mortal. It is transitory. It is as fragile as any other object. It is a harsh reality that no human
being, or for that matter, no living being, can live forever. Every creature who takes birth on this
planet earth has to die one day. Life has a limited shelf age. In fact, unlike the objects and articles
which are produced by human beings and may carry almost same life span, insofar as humans
themselves are concerned, span of life is also uncertain. Nobody knows how long he/she will be able
to live. The gospel truth is that everybody has to die one day, notwithstanding the pious wish of a
man to live forever 25. As Woody Allen said once: ‘I do not want to achieve immortality through my
work. I want to achieve it through not dying’. At the same time, nobody wants to have a tragic end to
life. We all want to leave the world in a peaceful manner. In this sense, the term ‘euthanasia’ which
has its origin in Greek language signifies ‘an easy and gentle death’.
49) According to Charles I. Lugosi, the sanctity of life ethic no longer dominates American medical
philosophy. Instead, quality of life has become the modern approach to manage human life that is
25 It is well known that medical scientists are intensely busy in finding the ways to become ageless
and immortal, but till date have remained unsuccessful in achieving this dream. at the margin of
utility26. It is interesting to note that the issue of euthanasia was debated in India in 1928. Probably
this was the first public debate on euthanasia to be reported. A Calf in Gandhi’s ashram was ailing
under great pain. In spite of every possible treatment and nursing…the condition of the calf was so
bad that it could not even change its side or even it could not be lifted about in order to prevent
pressure ulcers/sores. It could not even take nourishment and was tormented by flies. The surgeon
whose advice was sought in this matter declared the case to be past help and past hope. After painful
days of hesitation and discussions with the managing committee of Goseva Sangh and the inmates
of the ashram, Gandhi made up his mind to end the life of the calf in a painless way as possible.
There was a commotion in orthodox circles and Gandhi critically examined the question through his
article which appeared in Navajivan (dated 30-9-1928) and Young India (4-10-1928). Probably thisCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

was the first public debate on euthanasia and animal/veterinary euthanasia and the debate also
covered the issue of human euthanasia. It is equally interesting to note that Gandhi and his critics
discussed the issue of ‘painlessly ending the life to end suffering’ without using the term
‘euthanasia’. But, he meant the 26 Charles I. Lugosi, ‘Natural Disaster, Unnatural Deaths: The
Killings on the Life Care Floors at Tenet’s Memorial Centre after Hurricane Katrina’, Issues in Law
and Medicine, Vol. 23, Summer, 2007.
same. Further it is more interesting to learn that at various instances Gandhiji had touched upon the
issues of the present day debates on Voluntary euthanasia, Non-voluntary euthanasia, Involuntary
euthanasia, as well as passive euthanasia, active euthanasia, physician-assisted euthanasia and the
rejection or ‘termination of treatment’. Gandhi advocated the development of positive outlook
towards life and strived for the humane nursing and medical care even when cure was impossible. It
was the way he analysed Karma and submitted to the will of the God.
50) Mahatma Gandhi said:
“In these circumstances I felt that humanity demanded that the agony should be
ended by ending life itself. The matter was placed before the whole ashram. At the
discussion a worthy neighbour vehemently opposed the idea of killing even to end
pain. The ground of his opposition was that one has no right to take away life which
one cannot create. His argument seemed to me to be pointless here. It would have
point if the taking of life was actuated by self-interest. Finally, in all humility but with
the clearest of convictions, I got in my presence a doctor kindly to administer the calf
a quietus by means of a position injection.
The whole thing was over in less than two minutes.
But the question may very legitimately be put to me: would I apply the same principle
to human beings? Would I like it to be applied in my own case? My reply is ‘yes’; the
same law holds good in both the cases. The law, ‘as with one so with all’, admits of no
exceptions, or the killing of the calf was wrong and violent.
In practice, however, we do not cut short the sufferings of our ailing dear ones by
death because, as a rule, we have always means at our disposal to help them and they
have the capacity to think and decide for themselves. But supposing that in the case
of an ailing friend, I am unable to render any aid whatever and recovery is out of
question and the patient is lying in an unconscious state in the throes of agony, then I
would not see any himsa in putting an end to his suffering by death.
Just as a surgeon does not commit himsa but practices the purest ahimsa when he
wields his knife, one may find it necessary, under certain imperative circumstances,
to go a step further and sever life from the body in the interest of the sufferer.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

It may be objected that whereas the surgeon performs his operation to save the life of
the patient, in the other case we do just the reverse. But on a deeper analysis it will be
found that the ultimate object sought to be served in both the cases is the same,
namely, to relieve the suffering soul within from pain. In the one case you do it by
severing the diseased portion from the body, in the other you do it by severing from
the soul the body that has become an instrument of torture to it. In either case it is
the relief of the soul within from pain that is aimed at, the body without the life
within being incapable of feeling either pleasure or pain.
To conclude then, to cause pain or wish ill to or to take the life of any living being out
of anger or a selfish intent, is himsa.
On the other hand, after a calm and clear judgment to kill or cause pain to a living
being from a pure selfless intent may be the purest form of ahimsa. Each such case
must be judged individually and on its own merits. The final test as to its violence or
non-violence is after all the intent underlying the act.”
51) Ethical Egoism propounded in modern times by Thomas Hobbes in “Leviathan”
also operates from the general rule that if any action increases my own good, then it
is right. Ethical egoism in the context of euthanasia would mean that if a person
wants or does not want to end his/her life using euthanasia, this desire is presumed
to be motivated by a need for self benefit, and is therefore an ethical action27. The
perspective of the world community is gradually shifting from sanctity of life to
quality of John Keown, Euthanasia, Ethics and Public Policy, (Cambridge: Cambridge
University Press, (2002) p. 37 life sustained and preserved.
52) Philosophers believe that we have to control switch that can end it all, on request.
In medical/legal parlance, it is called euthanasia: ‘an easy and gentle death’.
Philosophically, this debate is about our right, when terminally ill, to choose how to
die. It is about the right to control how much we have to suffer and when and how we
die. It is about having some control over our dying process in a system that can
aggressively prolong life with invasive technology. Luckily, we also have the
technology that allows us to experience a gentle death on our own terms, rather than
by medically set terms. In his famous essay on Liberty, John Stuart Mill argues
strongly for our right to self-
determination. He writes: “over himself, over his own body and mind, the individual is
sovereign...he is the person most interested in his own well being.” These words were written over a
century ago.
53) Philosophically, therefore, one may argue that if a person who is undergoing miserable and
untold sufferings and does not want to continue dreadful agony and is terminally ill, he should be
free to make his choice to terminate his life and to put an end to his life so that he dies peacefully.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

54) At the same time, Buddhism, Jainism and Hinduism are against euthanasia. However, their
concept of ‘good death’ is extremely interesting – specially principles of Buddhism as they are
echoed in the present day understanding of euthanasia. Without elaborating and to put it in
nutshell:
 Buddhism, Jainism, and Hinduism, in particular, embrace the concept of the good
death as a means of achieving dignity and spiritual fulfilment at the end of life
without resorting to artificially shortening its span.
 Buddhists believe that human existence is rare and rebirth as a human is rarer still.
Consequently it is best approached cautiously without attempting to exert control
over the dying process. At the point of dying, a Buddhist should ideally be conscious,
rational and alert.
 Traditional Hindu religious culture also emphasizes the good death as a reflection
of the quality of life that preceded it. If a good, dignified death is attained, it is
perceived as evidence of having lived a worthy life because “the manner of one’s
passing out-weighs all previous claims and intimations of one’s moral worth”28.
T N Madan, “Dying with Dignity” (1992) 35 (4) Social Science and Medicine 425–32.
              “a good death certifies a good life”29.
              The good death is achieved when death occurs in full
consciousness, in a chosen place and at a chosen time; and  As with Buddhism great
significance is attached to the element of choice and the maintenance of control, 30
so if at all possible, “one must be in command and should not be overtaken by death.
To be so overtaken is the loss of dignity”. 31 Thus the final moments of life should be
calm, easy and peaceful if dignity is to be preserved.
Many of the insights of these traditional religions are echoed in the modern Western
understanding of euthanasia, as a means of achieving death with dignity, which
focuses on avoiding dependence and loss of control. Choosing to deliberately end
one’s life allows control over the time, place and method of one’s dying and explains
why euthanasia appears to offer death with dignity. Rather than active euthanasia
these ancient religions advocate calm, control and compassion as a means of
achieving dignity.
(B) Morality of Euthanasia
55) At the outset, I would like to clarify that while discussing a 29 T N Madan, “Living
and Dying” in Non-Renunciation: Themes and Interpretations of the Hindu Culture
(New Delhi, Oxford University Press, 1987). 30 J Parry, Death and the RegenerationCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

of Life (Cambridge, Cambridge University Press, 1982) 31 T N Madan, “Dying with
Dignity” (1992) 35 (4) Social Science and Medicine 425–32.
particular norm of law, the law per se is to be applied and, generally speaking, it is not the function
of the Courts to look into the moral basis of law. At the same time, some legal norms, particularly
those which are jurisprudentially expounded by the Courts or developed as common law principles,
would have moral backing behind them. In that sense moral aspects of an issue may assume
relevance. This relevancy and rationale is quite evident in the discussion about euthanasia. In fact,
the very concept of dignity of life is substantially backed by moral overtones. We may remind
ourselves with the following classical words uttered by Immanuel Kant:
“We must not expect a good constitution because those who make it are moral men.
Rather it is because of a good constitution that we may expect a society composed of
moral men.”
56) It is well known that Justice Holmes’ legal philosophy revolved around its central
theme that law and morals are to be kept apart, maintaining a sharp distinction
between them. Notwithstanding, even he accepted that under certain circumstances
distinction between law and morals loses much of its importance. To quote:
“I do not say say that there is not a wider point of view from which the distinction
between law and morals becomes of secondary importance, as all mathematical
distinctions vanish in the presence of the infinite”.32 32 Justice Holmes: The Path of
the Law, 10 Harvard Law review 457-78, at p. 459 (1897)
57) Euthanasia is one such critical issue where the law relating to it cannot be
divorced from morality. Lon L. Fuller33 has argued with great emphasis that it is the
morality that makes the law possible.
He also points towards morality as the substantive aims of law. In fact, as would be noticed later, the
conceptualisation of doctrine of dignity by Ronald Dworkin is supported with moral ethos. With the
aid of dignity principle, he has argued in favour of euthanasia. Likewise, and ironically, John Finnis,
Professor of Law and Legal Philosophy Emeritus in the University of Oxford, while opposing
euthanasia, also falls back on the morality conception thereof. It is this peculiar feature which drives
us to discuss the issue of euthanasia from the stand point of morality.
58) Influenced primarily by the aforesaid considerations, I deem it relevant to indulge into
discussion on morality.
59) When we come to the moral aspects of ‘end of life’ issues, we face the situation of dilemma. On
the one hand, it is an accepted belief that every human being wants to die peacefully. Nobody wants
to undergo any kind of suffering in his last days. So much so a person who meets his destiny by
sudden death or easy death is often considered as a person who would have lived his life by
practicing moral and ethical values. Rightly or wrongly, it is 33 Lon L. Fuller: The Morality of LawCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(Revised Edition), Yale University Press perceived that such a person who exhibited graceful
behaviour while living his life is bestowed grace by the death when time to depart came. However, it
does not happen to most of the people. Ageing is a natural phenomena. No doubt, as the person
advances in age, he becomes mature in his wisdom. However, old age brings, along with it, various
ailments and diseases as well. Physical health and physical functioning declines over the life course,
particularly, in later life. A rise in chronic disease and other conditions such as arthritis, high blood
pressure and obesity can cause loss in function and lead to generally decreasing trajectory for health
over the lifespan. Thus, ageing has both positive and negative aspects. This ageing leads to
extinction of human life which may generally be preceded by grave sickness and disease.
60) Horace, Roman poet in his poem on the ‘Ages of Man’ wrote quiet scathingly of the attributes of
old age:
“Many ills encompass an old man, whether because he seeks, gain, and then
miserably holds aloof from His store and fears to use it, because, in all that he does,
he lacks fire and courage, is dilatory and slow to form hopes, is sluggish and greedy of
a longer life, peevish, surly, given to praising the days he spent as a boy, and to
reproving and condemning the young.
(Ars Poetica, pp.169-74) We find a more contemporary echo of this in William
Shakespeare’s (1564-1616) famous verse ‘All the World’s a Stage’:
all the word’s stage, and all the men and women merely players;
they have their exits and their entrances, and one man in his time plays many parts,
his acts being seven ages....Last scene of all, that ends this strange eventful history, is
second childishness and mere oblivion, sans teeth, sans eyes, sans taste, sans
everything.
(As You Like It, Act II, scene VII)” It may, however, be added (for the sake of
clarification) that advent of disease is not the confines of old age only. One may
become terminally ill at any age. Such a disease may be acquired even at birth.
61) The moral dilemma is that it projects both the sides--protracted as well as
intractable. On the one hand, it is argued by those who are the proponents of a liberal
view that a right to life must include a concomitant right to choose when the life
becomes unbearable and not so worth living, when such a stage comes and the
sufferer feels that that the life has become useless, he should have right to die.
Opponents, on the other hand, project ‘Sanctity of Life’ (SOL) as the most important
factor and argue that this ‘SOL’ principle is violated by self-styled angles of death.
Protagonists on ‘SOL’ principle believe that life should be preserved at all costs and the least which
is expected is that there should not be a deliberate destruction of human life, though it does not
demand that life should always be prolonged as long as possible.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

62) It might therefore be argued, as Emily Jackson (2008) cogently does, that the law’s recognition
that withdrawal of life-prolonging treatment is sometimes legitimate is not so much an exception to
the SOL principle, as an embodiment of it.
63) In the most secular judicial interpretation of the SOL doctrine yet, Denman J of the UKHL
explicated thus:
“in respect a person’s death, we are also respecting their life – giving it sanctity...A
view that life must be preserved at all costs does not sanctify life.,..to care for the
dying, to love and cherish them, and to free them from suffering rather than simply
to postpone death is to have fundamental respect for the sanctity of life and its end.”
64) Hence, as the process of dying is an inevitable consequence of life, the right to life
necessarily implies the right to have nature take its course and to die a natural death.
It also encompasses a right, unless the individual so wishes, not to have life
artificially maintained by the provision of nourishment by abnormal artificial means
which have no curative effect and which are intended merely to prolong life.
65) A moral paradox which emerges is beautifully described by Sushila Rao34, in the
following words:
“Several commentators have justified the active/passive distinction by averring that
there is an important moral difference between killing a patient by administering,
say, a lethal injection, and withdrawing treatment which is currently keeping her
alive. Active euthanasia, runs the argument, interferes with nature’s dominion,
whereas withdrawal of treatment restores to nature her dominion.
Here too, an absolutist version of the SOL principle rears its unseemly head. In a
plethora of cases in the UK, a course of action which would lead to the patient’s
action which would lead to the patient’s death was held to be compatible with the
“best interests” test. Indeed, a majority in the House of Lords in Bland explicitly
accepted that the doctor’s intention in withdrawing artificial nutrition and hydration
was, in Lord Browne- Wilkinson’s words, to “bring about the death of Anthony
Bland”. Lord Lowry said that “the intention to bring about the patient’s death is
there” and Lord Mustill admitted that “the proposed conduct has the aim.. of
terminating the life of Anthony Bland”. I each case, however, life could be brought to
an end only because the doctors had recourse to a course of action which could
plausibly be described as a “failure to prolong life”.
The SOL principle thus works insidiously to ensure that only certain types of
death—namely, those achieved by suffocation, dehydration, starvation and infection,
through the withdrawal or withholding of, respectively, ventilation, ratification
nutrition and hydration, and antibiotics-can lawfully be brought about. More
crucially, the SOL principle prohibits doctors from acting to achieve that end quickly,Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

and more humanly, by the administration of a single lethal injection.
Lord Browne-Wilkinson lamented this paradox in Bland in the following words:
“How can it be lawful to allow a patient to die slowly, though painlessly, over a period
of weeks from lack of food but unlawful to produce his immediate death by a lethal
injection, thereby saving his family from yet Sushila Rao : Economic and Political
Weekly, Vol. 46, No. 18 (April 30-May 6, 2011), pp. 13-16 another ordeal to add to the
tragedy that has already struck them? I find it difficult to find a moral answer to that
question.
As Simon Blackburn (2001) puts it, differentiating between withdrawal of treatment
and killing may salve some consciences, but it is very doubtful whether it ought to. It
often condemns the subject to a painful, lingering death, fighting for breath or dying
of thirst, while those who could do something stand aside, withholding a merciful
death.”
66) Interestingly, Sushila Rao concludes that even the active-passive distinction is
not grounded much in morality and ethics as in ‘reasons of policy’.
67) John Finnis strongly believes that moral norms rule out the central case of
euthanasia and discards the theory of terminating people’s life on the ground that
doing so would be benefecial by alleviating human suffering or burdens. He also does
not agree that euthanasia would benefit ‘other people’ at least by alleviating their
proportionately greater burdens35.
68) Moral discourse of John Finnis proceeds on the ‘intention of the person who is
facing such a situation’. He draws distinction between what one intends (and does)
and what one accepts as 35 According to John Finnis, there is no real and morally
relevant distinction between active euthanasia and passive euthanasia inasmuch as
one employs the method of deliberate omissions (or forbearances or abstentions) in
order to terminate life (passive euthanasia) and other employs ‘a deliberate
intervention’ for the same purpose (active euthanasia). In this sense, in both the
cases, it is an intentional act whether by omission or by intervention, to put an end to
somebody’s life and, therefore, morally wrong.
foreseen side effects is significant by giving importance to free choice. There would be free choice, he
argues, only when one is rationally motivated towards incompatible alternative possible purposes.
Therefore, there may be a possibility that a person may choose euthanasia but not as a free choice
and it would be morally wrong. In a situation where that person is not in a position to make a choice
(for e.g. when he is in comma) this choice shall be exercised by others which, according to him,
violates the autonomy of the person involved. It is significant to mention that Finnis accepts that
autonomy of the patient or prospective patient counts. It reads:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

“Is this to say that the autonomy of the patient or prospective patient counts for
nothing? By no means. Where one does not know that the requests are suicidal in
intent, one can rightly, as a healthcare professional or as someone responsible for the
care of people, give full effect to requests to withhold specified treatments or indeed
any and all treatments, even when one considers the requests misguided and
regrettable. For one is entitled and indeed ought to honour these people's autonomy,
and can reasonably accept their death as a side effect of doing so.”36
69) He, however, explains thereafter that even if such a decision is taken, said person
would be proceeding on one or both of two philosophically and morally erroneous
judgments: (i) that human life in certain conditions or circumstances retains no
intrinsic 36 John Finnis: “Human Rights and Common Good: Collected Essays”,
Volume III value and dignity; and/or (ii) that the world would be a better place if
one’s life were intentionally terminated. And each of these erroneous judgments has
very grave implications for people who are in poor shape and/or whose existence
creates serious burdens for others.
It is, thus, clear that taking shelter of same morality principles, jurists have reached opposing
conclusions. Whereas euthanasia is morally impermissible in the estimation of some, others treat it
as perfectly justified. As would be noted later, riding on these very moral principles, Dworkin
developed the dignity of life argument and justified euthanasia.
The aforesaid discussion on the philosophy of euthanasia, coupled with its morality aspect, brings
out the conflicting views. Though philosophical as well as religious overtones may indicate that a
person does not have right to take his life, it is still recognised that a human being is justified in his
expectation to have a peaceful and dignified death. Opposition to euthanasia, on moral grounds,
proceeds primarily on the basis that neither the concerned person has a right to take his own life,
which is God’s creation, nor anybody else has this right. However, one startling feature which is to
be noted in this opposition is that while opposing euthanasia, no segregated discussion on active
and passive euthanasia is made. It also does not take into consideration permissibility of passive
euthanasia under certain specific circumstances. Clarity on this aspect is achieved when we discus
the issue of euthanasia in the context of dignity.
(C) Dignity in Euthanasia
70) This Court acknowledges its awareness of the sensitive and emotional nature of euthanasia
controversy, and the vigours of opposing views, even within the medical fraternity, and seemingly
absolute convictions that the subject inspires. This is so demonstrated above while discussing
philosophical, moral, ethical and religious overtones of the subject involved. These valid aspects,
coupled with one’s attitude towards life and family and their values, are likely to influence and to
colour one’s thinking and conclusions about euthanasia. Notwithstanding the same, these aspects
make the case as ‘hard case’. However, at the end of the day, the Court is to resolve the issue by
constitutional measurements, free of emotion and of predilection. One has to bear in mind what
Justice Oliver Wendell Holmes Jr. said in his dissenting judgment in Lochner v. New York37, whichCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

is reproduced below:
“[The Constitution] is made for people of fundamentally differing views, and the
accident of our finding certain 37 198 US 45, 76 (1905) opinions natural and familiar
or novel and even shocking ought not to conclude our judgment upon the question
whether statutes embodying them conflict with the Constitution of the United
States.”
71) With these preliminary remarks we return to the doctrine of dignity as an aspect
of Article 21 of the Constitution, a brief reference to which has already been made
above.
72) Let me first discuss certain aspects of human dignity in general.
Insofar as concept of human dignity is concerned, it dates back to thousands of years. Historically,
human dignity, as a concept, found its origin in different religions which is held to be an important
component of their theological approach. Later, it was also influenced by the views of philosophers
who developed human dignity in their contemplations38. Jurisprudentially, three types of models
for determining the content of the constitutional value of human dignity are recognised. These are:
(i) Theological Model, (ii) Philosophical Model, and (iii) Constitutional Model. Legal scholars were
called upon to determine the theological basis of human dignity as a constitutional value and as a
constitutional right. Philosophers also came out with their views justifying human dignity as core
human value. Legal understanding is influenced by theological and philosophical 38 Though
western thinking is that the concept of human dignity has 2500 years' history, in many eastern
civilizations including India human dignity as core human value was recognised thousands of years
ago views, though these two are not identical. Aquinas, Kant as well as Dworkin discussed the
jurisprudential aspects of human dignity. Over a period of time, human dignity has found its way
through constitutionalism, whether written or unwritten. Theological Model of Dignity 'Amritasya
Putrah Vayam' [We are all begotten of the immortal.] This is how Hinduism introduces human
beings.
'Every individual soul is potentially divine' – proclaimed Swami Vivekananda
73) Hinduism doesn't recognize human beings as mere material beings. Its understanding of human
identity is more ethical- spiritual than material. That is why a sense of immortality and divinity is
attributed to all human beings in Hindu classical literature.
74) Professor S.D. Sharma, sums up the position with following analysis39:
“Consistent with the depth of Indian metaphysics, the human personality was given a
metaphysical interpretation. This is not unknown to the modern occidental
philosophy. The concept of human personality in Kant's philosophy of law is
metaphysical entity but Kant was not able to reach the subtler unobserved element of
personality, which was the basic theme of the concept of personality in Indian legalCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

philosophy”
39 Prof. S.D. Sharma : “Administration of Justice in Ancient Bharat”, (1988).
75) It is on the principle that the soul that makes the body of all living organisms its abode is in fact
an integral part of the Divine Whole – Paramaatman – that the Vedas declare unequivocally:
Ajyesthaaso Akanisthaasa Yete; Sam Bhraataro Vaavrudhuh Soubhagaya [No one is
superior or inferior; all are brothers; all should strive for the interest of all and
progress collectively] – RigVeda, Mandala-5, Sukta-60, Mantra-5
76) Even in Islam, tradition of human rights became evident in the medieval ages.
Being inspired by the tenets of the Holy Koran, it preaches the universal
brotherhood, equality, justice and compassion. Islam believes that man has special
status before God. Because man is a creation of God, he should not be harmed. Harm
to a human being is harm to a God. God, as an act of love, created man and he wishes
to grant him recognition, dignity and authority. Thus, in Islam, human dignity stems
from the belief that man is a creation of God – the creation that God loves more than
any other.
77) The Bhakti and Sufi traditions too in their own unique ways popularized the idea
of universal brotherhood. It revived and regenerated the cherished Indian values of
truth, righteousness, justice and morality.
78) Christianity believes that the image of God is revealed in Jesus and through him
to human kind. God is rational and determines his goals for himself. Man was created
in the image of God, and he too is rational and determines his own goals, subject to
the God as a rational creation. Man has freedom of will. This is his dignity. He is free
to choose his goals, and he himself is a goal.
His supreme goal is to know God. Thus he is set apart from a slave and from all the creations under
him. When a man sins, he loses his human dignity. He becomes an object 40. Philosophical Model
of Dignity
79) The modern conception of human dignity was affected by the philosophy of Kant41. Kant's
moral theory is divided into two parts: ethics and right (jurisprudence). The discussion of human
dignity took place within his doctrine of ethics and does not appear in his jurisprudence42. Kant's
jurisprudence features the concept of a person's right to freedom as a human being.
80) According to Kant, a person acts ethically when he acts by force of a duty that a rational agent
self-legislates onto his own will. This self-legislated duty is not accompanied by any right or
coercion, and is not correlative to the rights of others. For Kant, 40 Based on the approach of
Thomas Aquinas (1225-1274) in his work Summa Theologia 41 See Toman E. Hill, 'Humanity as an
End in itself' (1980) 91 Ethics 84 42 See Pfordten, 'On the Dignity of Man in Kant' ethics includesCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

duties to oneself (e.g. to develop one's talents) and to others (e.g. to contribute to their happiness).
This ability is the human dignity of man. This is what makes a person different than an object. This
ability makes a person into an end, and prevents her from being a mere means in the hands of
another.
81) Professor Upendra Baxi in his First Justice H.R. Khanna Memorial Lecture43, on the topic
Protection of Dignity of Individual under the Constitution of India has very aptly remarked that
dignity notions, like the idea of human rights, are supposed to be the gifts of the West to the Rest,
though, this view is based on the prescribed ignorance of the rich traditions of non-European
countries. He, then, explains Eurocentric view of human dignity by pointing out that it views dignity
in terms of personhood (moral agency) and autonomy (freedom of choice). Dignity here is to be
treated as 'empowerment' which makes a triple demand in the name of respect for human dignity,
namely:
1. Respect for one's capacity as an agent to make one's own free choices.
2. Respect for the choices so made.
3. Respect for one's need to have a context and conditions in which one can operate
as a source of free and informed
43 Delivered on 25th February, 2010 at Indian Institute of Public Administration, New Delhi.
choice.
82) To the aforesaid, Professor Baxi adds:
“I still need to say that the idea of dignity is a metaethical one, that is it marks and
maps a difficult terrain of what it may mean to say being 'human' and remaining
'human', or put another way the relationship between 'self', 'others', and 'society'. In
this formulation the word 'respect' is the keyword: dignity is respect for an individual
person based on the principle of freedom and capacity to make choices and a good or
just social order is one which respects dignity via assuring 'contexts' and 'conditions'
as the 'source of free and informed choice'. Respect for dignity thus conceived is
empowering overall and not just because it, even if importantly, sets constraints
state, law, and regulations.”
83) Jeremy Waldron44 opines that dignity is a sort of status-concept: it has to do
with the standing (perhaps the formal legal standing or perhaps, more informally, the
moral presence) that a person has in a society and in her dealings with others. He has
ventured even to define this term “dignity” in the following manner:
“Dignity is the status of a person predicated on the fact that she is recognized as
having the ability to control and regulate her actions in accordance with her own
apprehension of norms and reasons that apply to her; it assumes she is capable ofCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

giving and entitled to give an account of herself (and of the way in which she is
regulating her actions and organizing her life), an account that others are to pay
attention to; and it means finally that she has the wherewithal to demand that her
agency and her presence among us as human being be taken seriously and
accommodated in the lives of others, in others' attitudes and actions towards her, and
in social life generally”.
44 See Article of Jeremy Waldron : “How Law Protects Dignity”
84) Kant, on the other hand, has initially used dignity as a 'value idea', though in his later work he
also talks of 'respect' which a person needs to accord to other person, thereby speaking of it more as
a matter of status.
Constitutional Perspective of Dignity
85) The most important lesson which was learnt as a result of Second World War was the realization
by the Governments of various countries about the human dignity which needed to be cherished and
protected. It is for this reason that in the U.N. Charter, 1945, adopted immediately after the Second
World War, dignity of the individuals was mentioned as of core value. The almost contemporaneous
Universal Declaration of Human Rights (1948) echoed same sentiments.
86) Article 3 of the Geneva Conventions explicitly prohibits “outrages upon personal dignity”. There
are provisions to this effect in International Covenant on Civil and Political Rights (Article 7) and
the European Convention of Human Rights (Article 3) though implicit. However, one can easily
infer the said implicit message in these documents about human dignity. The ICCPR begins its
preamble with the acknowledgment that the rights contained in the covenant “derive from the
inherent dignity of the human person”. And some philosophers say the same thing. Even if this is
not a connection between dignity and law as such, it certainly purports to identify a wholesale
connection between dignity and the branch of law devoted to human rights. One of the key facets of
twenty-first century democracies is the primary importance they give to the protection of human
rights. From this perspective, dignity is the expression of a basic value accepted in a broad sense by
all people, and thus constitutes the first cornerstone in the edifice of human rights. Therefore, there
is a certain fundamental value to the notion of human dignity, which some would consider a pivotal
right deeply rooted in any notion of justice, fairness, and a society based on basic rights.
87) Aharon Barak, former Chief Justice of the Supreme Court of Israel, attributes two roles to the
concept of human dignity as a constitutional value, which are:
1. Human dignity lays a foundation for all the human rights as it is the central
argument for the existance of human rights.
2. Human dignity as a constitutional value provides meaning to the norms of the legal
system. In the process, one can discern that the principle of purposive interpretation
exhorts us to interpret all the rights given by the Constitution, in the light of theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

human dignity. In this sense, human dignity influences the purposive interpretation
of the Constitution. Not only this, it also influences the interpretation of every
sub-constitutional norm in the legal system. Moreover, human dignity as a
constitutional value also influences the development of the common law.
88) Within two years of the adoption of the aforesaid Universal Declaration of Human Rights that
all human beings are born free and equal in dignity and rights, India attained independence and
immediately thereafter Members of the Constituent Assembly took up the task of framing the
Constitution of this Country. It was but natural to include a Bill of Rights in the Indian Constitution
and the Constitution Makers did so by incorporating a Chapter on Fundamental Rights in Part III of
the Constitution. However, it would be significant to point out that there is no mention of “dignity”
specifically in this Chapter on Fundamental Rights. So was the position in the American
Constitution. In America, human dignity as a part of human rights was brought in as a Judge-made
doctrine. Same course of action followed as the Indian Supreme Court read human dignity into
Articles 14 and 21 of the Constitution.
89) Before coming to the interpretative process that has been developed by this Court in evolving
the aura of human dignity predicated on Articles 14 and 21 of the Constitution, I am provoked to
discuss as to how Dworkin perceives interpretative process adopted by a Judge.
90) Dworkin, being a philosopher – jurist, was aware of the idea of a Constitution and of a
constitutional right to human dignity. In his book, Taking Rights Seriously, he noted that everyone
who takes rights seriously must give an answer to the question why human rights vis-a-vis the State
exist. According to him, in order to give such an answer one must accept, as a minimum, the idea of
human dignity. As he writes:
“Human dignity....associated with Kant, but defended by philosophers of different
schgools, supposes that there are ways of treating a man that are inconsistent with
recognizing him as a full member of the human community, and holds that such
treatment is profoundly unjust.”45
91) In his Book, “Is Democracy Possible Here?”46 Dworkin develops two principles
about the concept of human dignity. First principle regards the intrinsic value of
every person, viz., every person has a special objective value which value is not only
important to that person alone but success or failure of the lives of every person is
important to all of us. The second principle, according to Dworkin, is that of personal
responsibility. According to this
45 Ibid., 1 46 Ronald Dworkin, Is Democracy Possible Here? Principles for a New Political Debate
(Princeton University Press, 2006).
principle, every person has the responsibility for success in his own life and, therefore, he must use
his discretion regarding the way of life that will be successful from his point of view. Thus,
Dworkin's jurisprudence of human dignity is founded on the aforesaid two principles which,Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

together, not only define the basis but the conditions for human dignity. Dworkin went on to
develop and expand these principles in his book, Justice for Hedgehogs (2011)47.
92) When speaking of rights, it is impossible to envisage it without dignity. In his pioneering and all
inclusive “Justice for Hedgehogs”, he proffered an approach where respect for human dignity,
entails two requirements; first, self-respect, i.e., taking the objective importance of one’s own life
seriously; this represents the free will of the person, his capacity to think for himself and to control
his own life and second, authenticity, i.e., accepting a “special, personal responsibility for identifying
what counts as success” in one’s own life and for creating that life “through a coherent narrative”
that one has chosen. 48 According to Dworkin, these principles form the fundamental criteria
supervising what we should do in order to live well. 49 They further explicate the 47 Ibid 13 48
Kenneth W. Simons, Dworkin’s Two Principle of Dignity: An unsatisfactory Nonconsequentialist
Account of Interpersonal Moral Duties, 90 Boston law Rev. 715 (2010) 49 Ibid rights that
individuals have against their political community, 50 and they provide a rationale for the moral
duties we owe to others. This notion of dignity, which Dworkin gives utmost importance to, is
indispensable to any civilised society. It is what is constitutionally recognised in our country and for
good reason. Living well is a moral responsibility of individuals; it is a continuing process that is not
a static condition of character but a mode that an individual constantly endeavours to imbibe. A life
lived without dignity, is not a life lived at all for living well implies a conception of human dignity
which Dworkin interprets includes ideals of self- respect and authenticity.
93) This constitutional value of human dignity, has been beautifully illustrated by Aharon Barak, as
under:
“Human dignity as a constitutional value is the factor that unites the human rights
into one whole. It ensures the normative unity of human rights. This normative unity
is expressed in the three ways: first, the value of human dignity serves as a normative
basis for constitutional rights set out in the constitution; second, it serves as an
interpretative principle for determining the scope of constitutional rights, including
the right to human dignity; third, the value of human dignity has an important role in
determining the proportionality of a statute limiting a constitutional right.”51
94) We have to keep in mind that while expounding the aforesaid notion of dignity,
Dworkin was not interpreting any Constitution.
50 Supra 15 51 Aharon Barak, Human Dignity : The Constitutional Value and the Constitutional
Right This notion of dignity, as conceptualised by Dworkin, fits like a glove in our constitutional
scheme. In a series of judgments, dignity, as an aspect of Article 21, stands firmly recognised. Most
of the important judgments have been taken note of and discussed in K.S. Puttaswamy52.
95) In K.S. Puttaswamy, the Constitution Bench has recognised the dignity of existence. Liberty and
autonomy are regarded as the essential attributes of a life with dignity. In this manner, sanctity of
life also stands acknowledged, as part of Article 21 of the Constitution. That apart, while holding the
right of privacy as an intrinsic part of right to life and liberty in Article 21, various facets thereof areCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

discussed by the learned Judges in their separate opinions. A common theme which flows in all
these opinions is that that privacy recognises the autonomy of the individual; every person has right
to make essential choices which affect the course of life; he has to be given full liberty and freedom
in order to achieve his desired goals of life; and the concept of privacy is contained not merely in
personal liberty, but also in the dignity of the individual. Justice Chelameshwar, in K.S. Puttaswamy,
52 Prem Shankar Shukla v. UT of Delhi, (1980) 3 SCC 526; Francis Coralie Mullin v. UT of Delhi,
(1981) 1 SCC 608; Bandhua Mukti Morcha v. Union of India, (1984) 3 SCC 161; Khedat Mazdoor
Chetna Sangath v. State of Madhya Pradesh, (1994) 6 SCC 260; M. Nagaraj v. Union of India,
(2006) 8 SCC 212, Maharashtra University of Health Sciences v. Satchikitsa Prasarak Mandal,
(2010) 3 SCC 786; Selvi v. State of Karnataka, (2010) 7 SCC 263; Mehmood Nayyar Azam v. State of
Chhattisgarh, (2012) 8 SCC 1; Shabnam v. Union of India, (2015) 6 SCC 702; Jeeja Ghosh v. Union
of India, (2016) 7 SCC 761. made certain specific comments which are reflective of euthanasia,
though this term is not specifically used. He observed: “forced feeding of certain persons by the
State raises concerns of privacy and individual’s right to refuse life prolonging medical treatment or
terminate his life is another freedom which falls within the zone of privacy.”
96) Liberty by itself, which is a facet of Article 21 of the Constitution, duly recognised in K.S.
Puttaswamy, ensures and guarantees such a choice to the individual. In fact, the entire structure of
civil liberties presupposes that freedom is worth fostering. The very notion of liberty is considered as
good for the society. It is also recognised that there are some rights, encompassing liberty, which are
needed in order to protect freedom. David Feldman53 beautifully describes as to why freedom (or
liberty) is given:
“The guiding principle for many liberal rights theorists may be seen as respect for
individuals’ own aspirations, as a means of giving the fullest expression to each
individual’s moral autonomy. A fundamental principle entailed by respect for moral
autonomy is that individuals should prima facie be free to select their own ideas of
the Good, and develop a plan for life, or day-to-day strategy, accordingly. Their
choice of goods should be constrained only to the extent necessary to protect society
and the similar liberties of other people. The law should protect at least the basic
liberties, that is, those necessary to the pursuit of any socially acceptable conception
of the good life. This is the approach which John Rawls adopts in A Theory of Justice.
It requires that basic liberties be given considerable respect, and
53 David Feldman: Civil Liberties & Human Rights in England & Wales that they should have
priority over the pursuit of social goods (such as economic development) perhaps even to the extent
of giving them the status of entrenched, constitutional rights, in order to shield them from challenge
in the day-to-day rough and tumble of political contention. This gives liberty a priority over other
values, which, whether viewed as a description of liberal society or as a prescription for its
improvement, is very controversial. Philosophers have doubted whether there are adequate grounds
for the priority of liberty. Professor H.L.A. Hart has argued that (at least in a society where there is
limited abundance of wealth and resources) it is rational to prefer basic freedoms to an
improvement I material conditions only if one harbours the ideal of ‘a public-spirited citizen who
prizes political activity and service to others as among the chief goods of life and could notCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

contemplate as tolerable an exchange of the opportunities of such activity for mere material goods
or contentment’.
A rather different thesis runs through Professor Joseph Raz’s book, The Morality of Freedom:
people are autonomous moral actors, and autonomy is given expression primarily through making
one’s own decisions, but such freedom is valuable partly because it advances social ends. Raz points
out that the identification of basic liberties therefore depends, in pat at least, on governmental
notions of the public good. In respect of rights to freedom of expression, privacy, freedom of
religion, and freedom from discrimination, for example, ‘one reason for affording special protection
to individual interests is that thereby one also protects a collective good, an aspect of a public
culture’. At the same time, certain social goods are needed if freedom is to have value. Freedom is
useful only if the social and economic structure of society provides a sufficient range of choices to
allow people’s capacity for choice to be exercised. Accordingly, freedom is seen as a collective rather
than an individual good. This may constrain the range of freedoms and the purposes to which they
may morally be put: a decision to make a freedom into a constitutional right is an expression of the
collective political culture of a community. This thesis does not make the morality of freedom
depend on people striving for perfection: individuals may not always, or ever, think about the moral
consequences of their decisions, or may consciously make decisions which do not make for self-
improvement. Instead, it looks only for a social commitment to the idea of the moral significance of
individual choice. Raz marries the idea of the individual to that of society by recognizing that
individual freedom of choice is contingent on social arrangements.”
97) In his Article, Life’s Dominion, Ronald Dworkin, while building the hypothesis on dignity
concept, exhorts that people must decide about their own death, or someone else’s in three main
kind of situations, namely, (i) conscious and competent: it is a situation where a person is suffering
from some serious illness because of which he is incapacitated but he is still conscious and also
competent to decide about his fate, he should be given a choice to decide as to whether he wants to
continue to get the treatment;
(ii) unconscious: where the patient is unconscious and dying, doctors are often forced to decide
whether to continue life support for him or not under certain circumstances relatives have to take a
decision. However, at times, unconscious patients are not about to die. At the same time, they are
either in coma or in PVS. In either case, they are conscious. In such a situation, where recovery is
impossible, it should be left to the relatives to decide as to whether they want the patient to remain
on life support (ventilator, etc.); and (iii) conscious but incompetent. These factors may support,
what is known as ‘living will’ or ‘advance directive’, which aspect is dealt with specifically while
answering the second issue.
98) When a person is undergoing untold suffering and misery because of the disease with which he
is suffering and at times even unable to bear the same, continuing to put him on artificial machines
to prolong his vegetable life would amount to violating his dignity. These are the arguments which
are raised by some jurists and sociologists54.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

99) There is a related, but interesting, aspect of this dignity which needs to be emphasised. Right to
health is a part of Article 21 of the Constitution. At the same time, it is also a harsh reality that
everybody is not able to enjoy that right because of poverty etc. The State is not in a position to
translate into reality this right to health for all citizens. Thus, when citizens are not guaranteed the
right to health, can they be denied right to die in dignity?
100) In the context of euthanasia, ‘personal autonomy’ of an individual, as a part of human dignity,
can be pressed into service. In National Legal Services Authority v. Union of India and Others55,
this Court observed:
“Article 21, as already indicated, guarantees the protection of “personal autonomy” of
an individual. In
54 (I) Morris: Voluntary Euthanasia
(ii) LW Sumner: Dignity through Thick and Thin, in Sebastian Muders, “Human Dignity and
Assisted Death (Oxford University Press, 2017). 55 (2014) 5 SCC 438 Anuj Garg v. Hotel Assn. of
India [(2008) 3 SCC 1] (SCC p. 15, paras 34-35), this Court held that personal autonomy includes
both the negative right of not to be subject to interference by others and the positive right of
individuals to make decisions about their life, to express themselves and to choose which activities
to take part in. Self-determination of gender is an integral part of personal autonomy and self-
expression and falls within the realm of personal liberty guaranteed under Article 21 of the
Constitution of India.”
101) In addition to personal autonomy, other facets of human dignity, namely, ‘self expression’ and
‘right to determine’ also support the argument that it is the choice of the patient to receive or not to
receive treatment.
102) We may again mention that talking particularly about certain hard cases involving moral
overtones, Dworkin specifically discussed the issues pertaining to abortion and euthanasia with
emphasis that both supporters and critics accept the idea of sanctity of life. Decisions regarding
death – whether by abortion or by euthanasia – affect our human dignity. In Dworkin's opinion,
proper recognition of human dignity leads to the recognition of the freedom of the individual.
Freedom is a necessary condition for self worth. Dworkin adds: “Because we cherish dignity, we
insist on freedom .… Because we honour dignity, we demand democracy.”56 56 Ibid., at 239
103) Dignity is, thus, the core value of life and dying in dignity stands recognised in Gian Kaur. It
becomes a part of right of self determination.
104) The important message behind Dworkin’s concept of human dignity can be summarised in the
following manner:
(1) He describes belief in individual human dignity as the most important feature of
Western political culture giving people the moral right “to confront the mostCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

fundamental questions about the meaning and value of their own lives”57.
(2) In an age when people value their independence and strive to live independent
and fulfilled lives it is important “that life ends appropriately, that death keeps faith
with the way we want to have lived”58.
(3) Death is “not only the start of nothing but the end of everything”59 and, therefore,
it should be accomplished in a manner compatible with the ideals sought during life.
105) Taking into consideration the conceptual aspects of dignity and the manner in
which it has been judicially adopted by various judgments, following elements of
dignity can be highlighted (in
57 R Dworkin, Life’s Dominion (London, Harper-Collins, 1993) at 166. 58 R Dworkin, Life’s
Dominion (London, HarperCollins, 1993) at 179. 59 Ibid.
the context of death with dignity):
(I) Encompasses self-determination; implies a quality of life consistent with the
ability to exercise self-determined choices;
(ii) Maintains/ability to make autonomous choices; high regard for individual
autonomy that is pivotal to the perceived quality of a person’s life;
(iii) Self-control (retain a similar kind of control over dying as one has exercised
during life – a way of achieving death with dignity);
(iv) Law of consent: The ability to choose - orchestrate the timing of their own death;
(v) Dignity may be compromised if the dying process is prolonged and involves
becoming incapacitated and dependent;
(vi) Respect for human dignity means respecting the intrinsic value of human life;
(vii) Avoidance of dependency;
(viii) Indefinite continuation of futile physical life is regarded as undignified;
(ix) Dignity commands emphatic respect60;
 Reason and emotion are both significant in treatment decisions, especially at the end of life where
compassion 60 A Kolnai, “Dignity”, in R S Dillon (ed.) Dignity, Character, and Self-Respect
(London, Routledge, 1995) 53–75, at 55. Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

is a natural response to appeals made on the basis of stifled self-determination;
 Compassion represents a collision of “imaginative insight” and empathy; and  Compassion is
here distinguished from pity, which is regarded as “inappropriate to the dignity of the autonomous
person, especially its overtones of paternalism”,61 because compassion is believed to provoke an
active, and by implication positive, response.62
(x) Dignity engenders a sense of serenity and powerfulness, fortified by “qualities of composure,
calmness, restraint, reserve, and emotions or passions subdued and securely controlled without
being negated or dissolved” 63; and
(x) Observer’s Dignity aspect:
 a person possessed of dignity at the end of life, might induce in an observer a sense
of tranquility and admiration which inspires images of power and self-
assertion through restraint and poised composure; and  dignity clearly does play a
valuable role in contextualizing
61 R S Downie, K S Calman, Healthy Respect: Ethics in Health Care (Oxford, Oxford University
Press, 1994) at 51–53.
62 Ibid.
63 A Kolnai, “Dignity”, in R S Dillon (ed.) Dignity, Character, and Self-Respect (London, Routledge,
1995) 53–75, at 56.
people’s perceptions of death and dying, especially as it appears to embody a spirit of
self-determination that advocates of voluntary euthanasia crave.
106) Once we examine the matter in the aforesaid perspective, the inevitable conclusion would be
that passive euthanasia and death with dignity are inextricably linked, which can be summed up
with the following pointers:
(i) The opportunity to die unencumbered by the intrusion of medical technology and
before experiencing loss of independence and control, appears to many to extend the
promise of a dignified death. When medical technology intervenes to prolong dying
like this it does not do so unobtrusively;
(ii) Today many patients insist on more than just a right to health care in general.
They seek a right to choose specific types of treatment, able to retain control
throughout the entire span of their lives and to exercise autonomy in all medical
decisions concerning their welfare and treatment;Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(iii) A dreadful, painful death on a rational but incapacitated terminally ill patient are
an affront to human dignity.
107) The aforesaid discussion takes care of those who oppose euthanasia on moral
and ethical principles. We feel that at least the case for passive euthanasia is made
out. Certain moral dilemma as to what is the exact stage when such a decision to
withdraw medical support, would still remain. At times, a physician would be filled
with profound ethical uncertainties when a person is suffering unbearable pain and
agony, the question would be as to whether such suffering has reached the stage
where it is incurable and, therefore, decision should be taken to allow such person to
pass away in peace and dignity of hastening the process of death or the situation may
be reversible, though chances thereof are far remote. Dr. R.R. Kishore, who possesses
medical as well as law degree at the same time, lists the following questions which a
physician will have to answer while taking such a decision:
(i) Is it professionally permissible to kill or to help in dying a terminally ill and
incurable patient?
(ii) How does such a decision affect the person concerned and the society in general?
(iii) What are the values that are attracted in such situations?
(iv) How to assess that the individual’s urge to die is based on cool and candid
considerations and is not an impulsive act reflecting resources constraints,
inadequate care or discrimination?
(v) What are the practical risks involved in case a decision is taken to terminate the
life of the patient?
(vi) Where should the physician look for guidance in situations of such moral
dilemma?
(vii) Does the physician’s or the patient’s religion play any role in decision making
process?
108) What are the parameters to be kept in mind and the dangers which may be
encountered while taking decision on the aforesaid questions, is beautifully explained
by Dr. R.R. Kishore64 in the following words:
“Contemporary world order is founded on reason, equity and dignity. Reason
envisages definition and distinctness. What is the distinction between ‘killing’ and
‘letting die’? or, in other words, what is the difference between ‘causing death’ and
‘denial to prevent death’? Also, can the prolongation of life be ever ‘unnecessary’?
And, if yes, what are the criteria to determine the life’s worth? Equity mandatesCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

equality of opportunity, balancing of interests and optimization of resources. This
means addressing questions such as; for how long one should live? Who should die
first? What should be the ideal method of terminating one’s life? Dignity imposes
obligation to preserve life at all costs and in the4 event of an individual’s conscious
expression to end his life, contemplates a valid purpose and truly informed consent.
Deo0ntologically, in the context of sanctity of life, there is not much of conflict
between secular and religious concepts as both consider life as sacred and worthy of
protection. But, the differences appear in the face of application of advanced
technology which has the
64 Dr.R.R. Kishore,MD, LLB – End of Life Issues and the Moral Certainty: A Discovery through
Hinduism potential of keeping alive the terminally ill and incurable persons who would have
otherwise died. Since the technological resources are not unlimited prioritization becomes a
functional imperative, bringing in the concepts of worth and utility. In other words, the questions
like whose life is more precious and worthy of protection have to be answered. This is a formidable
task, attracting multiple and diverse perspectives, moral as well as strategic, leading to
heterogeneous approaches and despite agreement on fundamental issue of value of life the decisions
may seem to be at variance. A fair and objective decision in such circumstances may be a difficult
exercise and any liberalization is fraught with following apprehensions:
 Danger of abuse  Enhanced vulnerability to the poor  Slippery slope outcome 
Weakening of protection of life notions Any ethical model governing end of life
decisions should therefore be impervious to all extraneous forces such as, the
utilitarian bias, poverty, and subjectivity i.e., inadequate appreciation of
socio-economic, family, cultural and religious perspectives of the individual. The
poor and resourceless are likely to face deeper and more severe pain and agony
before dying and as such may request their physicians to terminate their lives much
earlier than those who have better access to resource. This poverty-death nexus
makes an objective decision difficult, constituting a formidable challenge to
committed physicians and others involved with the end of life issues. Taking a
decision on case to case basis, depending on individual’s material constraints and
inadequacies, enhances the problem rather than solving it, as it reduces the life from
an eternal bliss to a worldly award, subjecting its preservation to socio-economic
exigencies. For these reasons many feel that the safer and more respectable course to
improve death is to provide good palliative care and emotional support rather than
assisting the end of life. The moral ambiguities notwithstanding, decision to assist or
not to assist the act of dying by correctly interpreting the patient’s wish and the
accompanying circumstances, including the moral dictates, constitutes a practical
problem. Let us see how Hinduism addresses these issues.”
109) In the article, End of Life Issues and the Moral Certainty 65, the author after
posing the moral dilemma, noted above, discusses the approach to find the solutions.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

110) I had indicated at the earlier stage that Hippocratic Oath, coupled with ethical
norms of medical profession, stand in the way of euthanasia. It brings about a
situation of dilemma insofar as medical practitioner is concerned. On the one hand
his duty is to save the life of a person till he is alive, even when the patient is
terminally ill and there are no chances of revival. On the other hand, the concept of
dignity and right to bodily integrity, which recognises legal right of autonomy and
choice to the patient (or even to his relations in certain circumstances, particularly
when the patient is unconscious or incapacitated to take a decision) may lead to
exercising his right of euthanasia.
111) Dignity implies, apart from a right to life enjoyment of right to be free of physical
interference. At common law, any physical interference with a person is, prima facie,
tortious. If it interferes with freedom of movement, it may constitute a false
imprisonment. If it involves physical touching, it may constitute a battery. If it puts a
person in fear of violence, it may amount to an
65 See Footnote 63.
assault. For any of these wrongs, the victim may be able to obtain damages.
112) When it comes to medical treatment, even there the general common law principle is that any
medical treatment constitutes a trespass to the person which must be justified, by reference either to
the patient’s consent or to the necessity of saving life in circumstances where the patient is unable to
decide whether or not to consent.
113) Rights with regard to medical treatment fall essentially into two categories: first, rights to
receive or be free of treatment as needed or desired, and not to be subjected involuntarily to
experimentation which, irrespective of any benefit which the subjects may derive, are intended to
advance scientific knowledge and benefit people other than the subject in the long term; secondly,
rights connected incidentally with the provision of medical services, such as rights to be told the
truth by one’s doctor.
114) Having regard to the aforesaid right of the patients in common law, coupled with the dignity
and privacy rights, it can be said that passive euthanasia, under those circumstances where patient
is in PVS and he is terminally ill, where the condition is irreversible or where he is braindead, can be
permitted. On the aforesaid reasoning, I am in agreement with the opinion of the other members of
this Bench in approving the judgment in Aruna Ramachandra Shanbaug.
(D) Economics of Euthanasia
115) This is yet another reason for arriving at the same conclusion.
116) When we consider the matter of euthanasia in the context of economic principles, it becomes
another reason to support the aforesaid conclusion. This aspect can be dealt with in two ways.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

117) First, because of rampant poverty where majority of the persons are not able to afford health
services, should they be forced to spend on medical treatment beyond their means and in the
process compelling them to sell their house property, household things and other assets which may
be means of livelihood Secondly, when there are limited medical facilities available, should a major
part thereof be consumed on those patients who have no chances of recovery? In Economic &
Political Weekly dated February 10, 2018, it is reported:
“India is one of the worst India is one of the worst countries to die in, especially for
those suffering from terminal illnesses. In 2015, the Economist Intelligence Unit
brought out a Quality of Death Index, which ranked India 67th out of the 80
countries it had surveyed. In December 2017, a joint report published by the World
Health Organization and the World Bank revealed that 49 million Indians are pushed
into poverty every year due to out-of-pocket expenditure on healthcare, accounting
for half of the 100 million who meet such a fate worldwide. India’s Central Bureau of
Health Intelligence data puts the figure even higher. This unconscionable situation is
the direct outcome of the sorry state of our public health system. India’s spending on
health is among the lowest in the world. The Economic Survey 2017–18shows that
the government spends only 1.4% of its gross domestic product (GDP) on health. The
2017 National Health Policy, which otherwise exudes piety in its abstractions, aims to
increase government expenditure to 2.5% of GDP by 2025. By all accounts, this is too
little too late.
The situation improves only marginally for the better- off sections. With over 90% of
intensive care units in the private healthcare sector, it is largely this section that can
access expensive treatments. But this does not improve end-of-life situations for
them. Awareness and training in palliative care remain grossly inadequate. For those
making profit in the private healthcare sector, there is no incentive to provide such
treatment. Instead, treatment for the terminally ill continues to involve prolonging
life with expensive, invasive, and painful treatment with very little concern for the
patients themselves or their families.”
118) Some of the apprehensions expressed in ethical debates about euthanasia can be
answered when the ethical debate about euthanasia is not divorced from an economic
consideration of cost and benefits of euthanasia to society. P.R. Ward66 argues that
ethics is concerned with individuals and, therefore, does not take into account the
societal perspective. On the other hand, economics is sought to be concerned with
relative costs and
66 Healthcare rationing: can we afford to ignore euthanasia? Health Services Management Research
1997; 10; 32-41 benefits to society and can help to determine if euthanasia is of benefit to the
majority in society. According to him, the net benefit to the individual (from ethical considerations)
can be compared with the net benefit to society (from economics), and that both can be included in
an overall decision rule for whether or not to legalise euthanasia. Ward draws on the health
economics literature (for example, Mooney67) to suggest that a positive answer to this question insCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

implicit in many health-rationing decisions and is applicable to the euthanasia decision. He also
asserts that ‘introducing an economic perspective is not incompatible with ethical issues’.
119) No doubt, protagonists of ethical aspects of euthanasia oppose the aforesaid view. According to
them, euthanasia also involves the specific act of a medical professional killing a patient and the
ethical status of this act has implications both for individuals and for society. Their counter
argument, therefore, is that to be able to make an economic assessment of euthanasia, we would
have to be able to evaluate the cost and benefits of this act of killing. However, even they accept that
if the act of killing by euthanasia is ethically acceptable in some circumstances, it would be
appropriate to consider the net benefits of the act to the individual 67 Mooney, G. The Valuation of
Human Life. London: Macmillan Press, 1977 patient along with the wider economic considerations
68. In the instant case, we have come to the conclusion that under certain circumstances, i.e. when
the patient is in PVS or braindead/ clinically dead, at least passive euthanasia would even be
ethically acceptable, on the application of doctrine of dignity. In such a situation, the economic
considerations would strengthen the aforesaid conclusion.
120) At times, for deciding legal issues, economic analysis of law assumes importance69. It is
advocated that one of the main reasons which should prompt philosophers of law to undertake
economic analysis seriously is that the most basic notion in the analysis – efficiency or Pareto
optimality 70 - was originally introduced to help solve a serious objection to widely held moral
theory, utilitarian. Utilitarians hold that the principle of utility is the criterion of the right conduct. If
one has to evaluate policies in virtue of their effect on individual welfare or utility, one norm of
utility has to be compared with that of another. We may clarify that this economic principle has been
applied in a limited sense only as a supporting consideration with the aim to promote 68 See –
Economics and Euthanasia by Stephen Heasell, Department of Economics and Politics, Nottingham
Trent University, and David Paton, Nottingham University Business School. 69 This aspect is
discussed in some detail by this Court in Shivashakti Sugars Ltd. v. Shree Renuka Sugar Limited and
Other, (2017) 7 SCC 729 70 Jeffrie G. Murphy & Jules L. Coleman: Philosophy of Law (An
introduction to Jurisprudence) efficiency.
121) If we understand correctly the logic behind opposition to euthanasia, particularly, passive
euthanasia, it proceeds on the basis that third person should not have right to take a decision about
one’s life and, more importantly, it is difficult to ascertain, at a particular stage, as to whether time
has come to take such a decision, namely, withdraw the medical support. Insofar as latter aspect is
concerned, we feel that in Aruna Ramachandra Shanbaug, this Court has taken due care in
prescribing the circumstances, namely, when the person is in a Permanent Vegetative State (PVS)
with no reversible chance or when he is ‘brain dead’ or ‘clinically dead’. Insofar as first aspect is
concerned, the subject matter of the present writ petition takes care of that.
THE SECOND ISSUE
122) With this, we advert to the second question formulated above, which is as under:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Whether a ‘living will’ or ‘advance directive’ should be legally recognised and can be
enforced? If so, under what circumstances and what precautions are required while
permitting it?
123) In this writ petition, the petitioner has sought a direction to the respondents to
adopt suitable procedures to ensure that persons of deteriorated health or terminally
ill should be able to execute a document titled ‘living will and/or advance
authorisation’ which can be presented to the hospital for appropriate action in the
event of the executant being admitted to the hospital with serious illness which may
threaten termination of life of the executant. In nutshell, the petitioner wants that
citizens should have right to decide in advance not to accept any kind of treatment at
a stage when they are terminally ill. Expressing this in advance in a document is
known as ‘living will’ or ‘advance directive’, whereby the aforesaid self-determination
of the person is to be acted upon when he reaches PVS or his brain dead/clinically
dead.
124) It is an undisputed that Doctors’ primary duty is to provide treatment and save
life but not in the case when a person has already expressed his desire of not being
subjected to any kind of treatment. It is a common law right of people, of any civilized
country, to refuse unwanted medical treatment and no person can force him/her to
take any medical treatment which the person does not desire to continue with. The
foundation of the aforesaid right has already been laid down by this Court in Aruna
Ramachandra Shanbaug while dealing with the issue of ‘involuntary passive
euthanasia’. To quote:
“66. Passive euthanasia is usually defined as withdrawing medical treatment with a
deliberate intention of causing the patient's death. For example, if a patient requires
kidney dialysis to survive, not giving dialysis although the machine is available, is
passive euthanasia. Similarly, if a patient is in coma or on a heart-lung machine,
withdrawing of the machine will ordinarily result in passive euthanasia. Similarly not
giving life-saving medicines like antibiotics in certain situations may result in passive
euthanasia. Denying food to a person in coma or PVS may also amount to passive
euthanasia.
67. As already stated above, euthanasia can be both voluntary or non-voluntary. In
voluntary passive euthanasia a person who is capable of deciding for himself decides
that he would prefer to die (which may be for various reasons e.g. that he is in great
pain or that the money being spent on his treatment should instead be given to his
family who are in greater need, etc.), and for this purpose he consciously and of his
own free will refuses to take life-saving medicines. In India, if a person consciously
and voluntarily refuses to take life-saving medical treatment it is not a crime...
xxx xxx xxxCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

78. ... First, it is established that the principle of self-
determination requires that respect must be given to the wishes of the patient, so that if an adult
patient of sound mind refuses, however unreasonably, to consent to treatment or care by which his
life would or might be prolonged, the doctors responsible for his care must give effect to his wishes,
even though they do not consider it to be in his best interests to do so [see Schloendorff v. Society of
New York Hospital [211 NY 125 : 105 NE 92 (1914)] , NE at p. 93, per Cardozo, J.; S. v. McC. (Orse
S.) and M (D.S. Intervener) [1972 AC 24 (HL)], W v. W; AC at p. 43, per Lord Reid; and Sidaway v.
Board of Governors of the Bethlem Royal Hospital [1985 AC 871 : (1985) 2 WLR 480 : (1985) 1 All
ER 643 (HL)] AC at p. 882, per Lord Scarman]. To this extent, the principle of the sanctity of human
life must yield to the principle of self-determination [see (Court of Appeal transcript in the present
case, at p. 38 F per Hoffmann, L.J.)], and, for present purposes perhaps more important, the
doctor's duty to act in the best interests of his patient must likewise be qualified. On this basis, it has
been held that a patient of sound mind may, if properly informed, require that life support should be
discontinued: see Nancy B. v. Hotel Dieu de Quebec [(1992) 86 DLR (4th) 385 (Que SC)] . Moreover
the same principle applies where the patient's refusal to give his consent has been expressed at an
earlier date, before he became unconscious or otherwise incapable of communicating it; though in
such circumstances especial care may be necessary to ensure that the prior refusal of consent is still
properly to be regarded as applicable in the circumstances which have subsequently occurred [see
e.g. T. (Adult:
Refusal of Treatment), In re [1993 Fam 95 : (1992) 3 WLR 782 : (1992) 4 All ER 649
(CA)] ]. I wish to add that, in cases of this kind, there is no question of the patient
having committed suicide, nor therefore of the doctor having aided or abetted him in
doing so. It is simply that the patient has, as he is entitled to do, declined to consent
to treatment which might or would have the effect of prolonging his life, and the
doctor has, in accordance with his duty, complied with his patient's wishes...”
125) The aforesaid principle has also been recognised by this Court in its Constitution
Bench judgment passed in Gian Kaur wherein it was held that although ‘Right to Life’
under Article 21 does not include ‘Right to Die’, but ‘Right to live with dignity’
includes ‘Right to die with dignity’. To quote:
“24. Protagonism of euthanasia on the view that existence in persistent vegetative
state (PVS) is not a benefit to the patient of a terminal illness being unrelated to the
principle of “sanctity of life” or the “right to live with dignity” is of no assistance to
determine the scope of Article 21 for deciding whether the guarantee of “right to life”
therein includes the “right to die”. The “right to life” including the right to live with
human dignity would mean the existence of such a right up to the end of natural life.
This also includes the right to a dignified life up to the point of death including a
dignified procedure of death. In other words, this may include the right of a dying
man to also die with dignity when his life is ebbing out. But the “right to die” with
dignity at the end of life is not to be confused or equated with the “right to die” an
unnatural death curtailing the natural span of life.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

25. A question may arise, in the context of a dying man who is terminally ill or in a
persistent vegetative state that he may be permitted to terminate it by a premature
extinction of his life in those circumstances.
This category of cases may fall within the ambit of the “right to die” with dignity as a part of right to
live with dignity, when death due to termination of natural life is certain and imminent and the
process of natural death has commenced. These are not cases of extinguishing life but only of
accelerating conclusion of the process of natural death which has already commenced. The debate
even in such cases to permit physician- assisted termination of life is inconclusive. It is sufficient to
reiterate that the argument to support the view of permitting termination of life in such cases to
reduce the period of suffering during the process of certain natural death is not available to interpret
Article 21 to include therein the right to curtail the natural span of life.”
126) In fact, the Law Commission of India was asked to consider on the feasibility of making
legislation on euthanasia, taking into account the earlier 196 th Report of the Law Commission as
well as the judgment of this Court in Aruna Ramachandra Shanbaug. In August, 2012, Law
Commission came out with a detailed 241st Report on the issue of passive euthanasia, wherein it
approved the concept of Right to Self Determination also. The Law Commission made some
important observations in its report such as:
“2.4 The following pertinent observations made by the then Chairman of the Law
Commission in the forwarding letter dated 28 August 2006 addressed to the Hon’ble
Minister are extracted below:
“A hundred years ago, when medicine and medical technology had not invented the
artificial methods of keeping a terminally ill patient alive by medical treatment,
including by means of ventilators and artificial feeding, such patients were meeting
their death on account of natural causes. Today, it is accepted, a terminally ill person
has a common law right to refuse modern medical procedures and allow nature to
take its own course, as was done in good old times. It is well-settled law in all
countries that a terminally ill patient who is conscious and is competent, can take an
‘informed decision’ to die a natural death and direct that he or she be not given
medical treatment which may merely prolong life. There are currently a large number
of such patients who have reached a stage in their illness when according to
well-informed body of medical opinion, there are no chances of recovery. But modern
medicine and technology may yet enable such patients to prolong life to no purpose
and during such prolongation, patients could go through extreme pain and suffering.
Several such patients prefer palliative care for reducing pain and suffering and do not
want medical treatment which will merely prolong life or postpone death.” xxx xxx
xxx 5.2 The 196th Report of the Law Commission stated the fundamental principle
that a terminally ill but competent patient has a right to refuse treatment including
discontinuance of life sustaining measures and the same is binding on the doctor,
“provided that the decision of the patient is an ‘informed decision’ ”.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

‘Patient’ has been defined as a person suffering from terminal illness. “Terminal illness” has also
been defined under Section 2 (m). The definition of a ‘competent patient’ has to be understood by
the definition of ‘incompetent patient’. ‘Incompetent patient’ means a patient who is a minor or a
person of unsound mind or a patient who is unable to weigh, understand or retain the relevant
information about his or her medical treatment or unable to make an ‘informed decision’ because of
impairment of or a disturbance in the functioning of the mind or brain or a person who is unable to
communicate the informed decision regarding medical treatment through speech, sign or language
or any other mode (vide Section 2(d) of the Bill, 2006). “Medical Treatment” has been defined in
Section 2(i) as treatment intended to sustain, restore or replace vital functions which, when applied
to a patient suffering from terminal illness, would serve only to prolong the process of dying and
includes life sustaining treatment by way of surgical operation or the administration of medicine etc.
and use of mechanical or artificial means such as ventilation, artificial nutrition and cardio
resuscitation. The expressions “best interests” and “informed decision” have also been defined in the
proposed Bill. “Best Interests”, according to Section 2(b), includes the best interests of both on
incompetent patient and competent patient who has not taken an informed decision and it ought
not to be limited to medical interests of the patient but includes ethical, social, emotional and other
welfare considerations. The term ‘informed decision’ means, as per Section 2 (e) “the decision as to
continuance or withholding or withdrawing medical treatment taken by a patient who is competent
and who is, or has been informed about – (i) the nature of his or her illness, (ii) any alternative form
of treatment that may be available, (iii) the consequences of those forms of treatment, and (iv) the
consequences of remaining untreated.
xxx xxx xxx 5.8 The Law Commission of India clarified that where a competent patient takes an
‘informed decision’ to allow nature to have its course, the patient is, under common law, not guilty
of attempt to commit suicide (u/s 309 IPC) nor is the doctor who omits to give treatment, guilty of
abetting suicide (u/s 306 IPC) or of culpable homicide (u/s 299 read with Section 304 of IPC).
xxx xxx xxx 7.2 In this context, two cardinal principles of medical ethics are stated to be patient
autonomy and beneficence (vide P. 482 of SCC in Aruna’s case):
1. “Autonomy means the right to self-determination, where the informed patient has
a right to choose the manner of his treatment. To be autonomous, the patient should
be competent to make decision and choices. In the event that he is incompetent to
make choices, his wishes expressed in advance in the form of a living will, OR the
wishes of surrogates acting on his behalf (substituted judgment) are to be respected.
The surrogate is expected to represent what the patient may have decided had she/she been
competent, or to act in the patient’s best interest.
2. Beneficence is acting in what (or judged to be) in the patient’s best interest. Acting in the patient’s
best interest means following a course of action that is best for the patient, and is not in influenced
by personal convictions, motives or other considerations……..Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

xxx xxx xxx 11.2 The discussion in the foregoing paras and the weighty opinions of the Judges of
highest courts as well as the considered views of Law Commission (in 196th report) would furnish
an answer to the above question in clearest terms to the effect that legally and constitutionally, the
patient (competent) has a right to refuse medical treatment resulting in temporary prolongation of
life. The patient’s life is at the brink of extinction. There is no slightest hope of recovery. The patient
undergoing terrible suffering and worst mental agony does not want his life to be prolonged by
artificial means. She/he would not like to spend for his treatment which is practically worthless.
She/he cares for his bodily integrity rather than bodily suffering. She/he would not like to live like a
‘cabbage’ in an intensive care unit for some days or months till the inevitable death occurs. He
would like to have the right of privacy protected which implies protection from interference and
bodily invasion. As observed in Gian Kaur’s case, the natural process of his death has already
commenced and he would like to die with peace and dignity. No law can inhibit him from opting
such course. This is not a situation comparable to suicide, keeping aside the view point in favour of
decriminalizing the attempt to suicide. The doctor or relatives cannot compel him to have invasive
medical treatment by artificial means or treatment. If there is forced medical intervention on his
body, according to the decisions cited supra (especially the remarks of Lord Brown Wilkinson in
Airdale’s case), the doctor / surgeon is guilty of ‘assault’ or ‘battery’. In the words of Justice Cardozo,
“every human being of adult years and sound mind has a right to determine what shall be done with
his own body and a surgeon who performs an operation without his patient’s consent commits an
assault for which he is liable in damages.” Lord Goff in Airedale’s case places the right to self
determination on a high pedestal. He observed that “in the circumstances such as this, the principle
of sanctity of human life must yield to the principle of self determination and the doctor’s duty to act
in the best interests of the patient must likewise be qualified by the wish of the patient.” The
following observations of Lord Goff deserve particular notice:
“I wish to add that, in cases of this kind, there is no question of the patient having
committed suicide, nor therefore of the doctor having aided or abetted him in doing
so. It is simply that the patient has, as he is entitled to do, declined to consent to
treatment which might or would have the effect of prolonging his life, and the doctor
has, in accordance with his duty, complied with his patient's wishes.”
127) And finally, the Law Commission in its 241 st Report gave Summary of
Recommendations as under:
“14. Summary of Recommendations 14.1 Passive euthanasia, which is allowed in
many countries, shall have legal recognition in our country too subject to certain
safeguards, as suggested by the 17th Law Commission of India and as held by the
Supreme Court in Aruna Ramachandra’s case [(2011) 4 SCC 454)]. It is not
objectionable from legal and constitutional point of view.
14.2 A competent adult patient has the right to insist that there should be no invasive
medical treatment by way of artificial life sustaining measures / treatment and such
decision is binding on the doctors / hospital attending on such patient provided that
the doctor is satisfied that the patient has taken an ‘informed decision’ based on freeCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

exercise of his or her will. The same rule will apply to a minor above 16 years of age
who has expressed his or her wish not to have such treatment provided the consent
has been given by the major spouse and one of the parents of such minor patient.
14.3 As regards an incompetent patient such as a person in irreversible coma or in
Persistent Vegetative State and a competent patient who has not taken an ‘informed
decision’, the doctor’s or relatives’ decision to withhold or withdraw the medical
treatment is not final. The relatives, next friend, or the doctors concerned / hospital
management shall get the clearance from the High Court for withdrawing or
withholding the life sustaining treatment. In this respect, the recommendations of
Law Commission in 196th report is somewhat different. The Law Commission
proposed an enabling provision to move the High Court.
14.4 The High Court shall take a decision after obtaining the opinion of a panel of
three medical experts and after ascertaining the wishes of the relatives of the patient.
The High Court, as parens patriae will take an appropriate decision having regard to
the best interests of the patient.
14.5 Provisions are introduced for protection of medical practitioners and others who
act according to the wishes of the competent patient or the order of the High Court
from criminal or civil action.
Further, a competent patient (who is terminally ill) refusing medical treatment shall not be deemed
to be guilty of any offence under any law.
14.6 The procedure for preparation of panels has been set out broadly in conformity with the
recommendations of 17th Law Commission.
Advance medical directive given by the patient before his illness is not valid.
14.7 Notwithstanding that medical treatment has been withheld or withdrawn in accordance with
the provisions referred to above, palliative care can be extended to the competent and incompetent
patients. The Governments have to devise schemes for palliative care at affordable cost to terminally
ill patients undergoing intractable suffering. 14.8 The Medical Council of India is required issue
guidelines in the matter of withholding or withdrawing of medical treatment to competent or
incompetent patients suffering from terminal illness.
14.9 Accordingly, the Medical Treatment of Terminally Ill Patients (Protection of Patients and
Medical Practitioners) Bill, 2006, drafted by the 17th Law Commission in the 196th Report has been
modified and the revised Bill is practically an amalgam of the earlier recommendations of the Law
Commission and the views / directions of the Supreme Court in Aruna Ramachandra case. The
revised Bill is at Annexure I.”Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

128) I am also of the view that such an advance authority is akin to well recognised common law
right to refuse medical treatment (See: Re T (Adult: Refusal of Medical Treatment71), Re B (Adult:
Refusal of Medical Treatment72), Crazan v. Director, Missouri Department of Health73, Malette v.
Shulam74.
129) In a recent landmark judgment of the nine Judge Constitution Bench in the case of K.S.
Puttaswamy authoritatively held that right to life enshrined in Article 21 includes right to privacy.
One 71 (1992) 4 All ER 649 72 (2002) 2 All ER 449 73 497 U.S. 261 (1990) 74 67 DLR (4th) 321 of
the facet of this right acknowledged is an individual’s decision to refuse life prolonging medical
treatment or terminate his life. Justice Chelameswar in his separate opinion has described the same
in the following manner:
“373. Concerns of privacy arise when the State seeks to intrude into the body of
subjects. [Skinner v. Oklahoma, 1942 SCC OnLine US SC 125 : 86 L Ed 1655 : 316 US
535 (1942)“20. There are limits to the extent to which a legislatively represented
majority may conduct biological experiments at the expense of the dignity and
personality and natural powers of a minority—even those who have been guilty of
what the majority defines as crimes.” (SCC OnLine US SC para 20)—Jackson, J.]
Corporeal punishments were not unknown to India, their abolition is of a recent
vintage. Forced feeding of certain persons by the State raises concerns of privacy. An
individual's rights to refuse life prolonging medical treatment or terminate his life is
another freedom which falls within the zone of the right to privacy. I am conscious of
the fact that the issue is pending before this Court. But in various other jurisdictions,
there is a huge debate on those issues though it is still a grey area. [ For the legal
debate in this area in US, See Chapter 15.11 of American Constitutional Law by
Laurence H. Tribe, 2nd Edn.] A woman's freedom of choice whether to bear a child or
abort her pregnancy are areas which fall in the realm of privacy. Similarly, the
freedom to choose either to work or not and the freedom to choose the nature of the
work are areas of private decision-making process. The right to travel freely within
the country or go abroad is an area falling within the right to privacy. The text of our
Constitution recognised the freedom to travel throughout the country under Article
19(1)(d). This Court has already recognised that such a right takes within its sweep
the right to travel abroad. [Maneka Gandhi v. Union of India, (1978) 1 SCC 248] A
person's freedom to choose the place of his residence once again is a part of his right
to privacy [Williams v. Fears, 1900 SCC OnLine US SC 211 : 45 L Ed 186 : 179 US 270
(1900) —“8. Undoubtedly the right of locomotion, the right to remove from one place
to another according to inclination, is an attribute of personal liberty….” (SCC
OnLine US SC para 8)] recognised by the Constitution of India under Article 19(1)(e)
though the predominant purpose of enumerating the above-mentioned two freedoms
in Article 19(1) is to disable both the federal and State Governments from creating
barriers which are incompatible with the federal nature of our country and its
Constitution. The choice of appearance and apparel are also aspects of the right to
privacy. The freedom of certain groups of subjects to determine their appearance and
apparel (such as keeping long hair and wearing a turban) are protected not as a partCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

of the right to privacy but as a part of their religious belief. Such a freedom need not
necessarily be based on religious beliefs falling under Article 25. Informational traces
are also an area which is the subject-matter of huge debate in various jurisdictions
falling within the realm of the right to privacy, such data is as personal as that of the
choice of appearance and apparel. Telephone tappings and internet hacking by State,
of personal data is another area which falls within the realm of privacy. The instant
reference arises out of such an attempt by the Union of India to collect biometric data
regarding all the residents of this country. The above-mentioned are some of the
areas where some interest of privacy exists. The examples given above indicate to
some extent the nature and scope of the right to privacy.” NATURE OF LIVING
WILL OR ADVANCE DIRECTIVE
130) Advance directives are instruments through which persons express their wishes
at a prior point in time, when they are capable of making an informed decision,
regarding their medical treatment in the future, when they are not in a position to
make an informed decision, by reason of being unconscious or in a PVS or in a coma.
A medical power of attorney is an instrument through which persons nominate
representatives to make decisions regarding their medical treatment at a point in
time when the persons executing the instrument are unable to make informed
decisions themselves. Clause 11 of the draft Treatment of Terminally-III Patients
(Protection of Patients and Medical Practitioners) Bill, 2016 states that advance
directives or medical power of attorney shall be void and of no effect and shall not be
binding on any medical practitioner. This blanket ban, including the failure even to
give some weight to advance directives while making a decision about the
withholding or withdrawal of life-
sustaining treatment is disproportionate. It does not constitute a fair, just or reasonable procedure,
which is a requirement for the imposition of a restriction on the right to life (in this case, expressed
as the right to die with dignity) under Article 21.
131) At this juncture, we may again reiterate that on the one hand autonomy of an individual gives
him right to choose his destiny and, therefore, he may decide before hand, in the form of advance
directive, at what stage of his physical condition he would not like to have medical treatment, and on
the other hand, there are dangers of misuse thereof as well. David Feldman explained the same in
the following manner:
“...However, while it is undoubtedly a criminal act to do anything intending to hasten
another person’s death, there is no absolute duty on a doctor to try to save the life of a
patient, for two reasons.
The first is that any treatment is prima facie a trespass to the person, and if the
patient is adult and competent to consent it will be unlawful without that consent. A
doctor therefore acts lawfully – indeed, could not lawfully act otherwise – when he
withholds treatment at the request of a terminally ill patient. This has been calledCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

passive, as distinct from active, euthanasia. To ensure that medical staff know of their
wishes, some people have executed what are sometimes called ‘living wills’, giving
directions to medical staff to withhold treatment in specified circumstances, and
making their wishes known to anyone who might be appointed as their representative
in the event that they become in capable for any reason. The efficacy of such prior
indications was accepted, obiter, by Lord Goff in Airedale NHS Trust v. Bland, above.
In such circumstances, the patient voluntarily accepts non-treatment while in a state
to do so rationally. However, where there is the slightest doubt about the wishes of a
patient, that patient should be treated, because the paternalism which decides for
someone else when it is best to die is effectively denying them the opportunity to
make the most of their lives as autonomous individuals. Furthermore, it would seem
to be wrong in principle to put pressure to bear on a patient to elect to die. In those
states of the USA where voluntary euthanasia is lawful, the ethical problems for
patients, doctors, next of kin, and nursing staff are immense. Where the patient is not
mentally competent to confirm the choice to die at the time when the choice is about
to be given effect, it will also be impossible to know whether the choice expressed
earlier was truly voluntary, whether the consent was informed, and whether or not
the patients would want to reconsider were he able to do so. In the Netherlands,
where it is lawful to practice voluntary euthanasia, it seems that the procedural
safeguards designed to protect people against involuntary euthanasia are very hard to
enforce and are regularly flouted.
Secondly, the doctrine of double effect allows the doctor to take steps which carry a
substantial risk to life in order to treat, in good faith and with the patient’s consent,
some disease or symptom. This is essential, because virtually any treatment carries
some risk to the patient. It is particularly relevant to the euthanasia issue in cases
where the primary object (e.g. pain control in terminal cancer treatment) can only be
achieved by administering drugs at a level which is likely to shorten life, but enhances
the quality of life while it lasts. A trade-off between length of life and quality of life is
permissible.”
132) At the same time, possibility of misuse cannot be held to be a valid ground for
rejecting advance directive, as opined by the Law Commission of India as well in its
196 th and 241st Report.
Instead, attempt can be made to provide safeguards for exercise of such advance directive. For
example, Section 5 of the Mental Healthcare Act, 2017 recognises the validity of advance directives
for the treatment of mental illness under the Mental Healthcare Act, 2017. The draft Mental
Healthcare Regulations have recently been made available for public comment by the Ministry of
Health and Family Welfare. These prescribe the form in which advance directives may be made. Part
II, Chapter 1 of the Regulations allow a Nominated Representative to be named in the Advance
Directive. An advance directive is to be in writing and signed by two witnesses attesting to the fact
that the Directive was executed in their presence. A Directive to be registered with the Mental
Health Review Board. It may be changed as many times as desired by the person executing it andCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

the treating mental health professional must be informed of such change. Similarly, Section 3 of the
Transplantation of Human Organs and Tissues Act, 1994 allows persons to authorise the removal of
human organs and tissues from their body before death. The form in which this authorisation is to
be made is prescribed in Form 7 of the Transplantation of Human Organs and Tissues Rules, 2014.
This is also to be in writing and in the presence of two witnesses. A copy of the pledge is to be
retained at the institution where the pledge is made and the person making the pledge has the
option to withdraw the pledge at any time. Where such authorisation had been made, the person
lawfully in charge of the donor’s body after his death is required to grant the concerned medical
practitioner all reasonable facilities for the removal of human organs or tissues, unless such person
has reason to believe that the donor had substantially revoked his authority.
133) Mr. Datar, learned counsel appearing for the intervenor, has also brought to our notice various
safeguards for advance directive provided in other jurisdiction in many ways i.e. by prescribing the
form that the directive must take, by specifying who may act as witnesses, by allowing the possibility
of amendment and by allowing the validity of the directive to be challenged. Some of these examples
are as follows:
(a) In U.K., under Section 24 of the Mental Capacity Act, 2005, a person above the
age of 18 years who has capacity may execute an advance directive. A person is said to
lack capacity if in relation to a matter at the material time, he is unable to make a
decision for himself because of an impairment of or disturbance in the functioning of
the mind or brain. In Netherlands, under Article 2 of the Termination of Life on
Request and Assisted Suicide (Review Procedures) Act, patients aged 16 or above
may make advance directives. In Germany, the authorisation of the court is required
for the termination of treatment in the case of minors. In Switzerland, persons with
mental illnesses are considered exceptions and cannot discontinue medical treatment
if it is an expression or symptom of their mental illness. In Hungary, pregnant
women may not refuse treatment if it is seen that they are able to carry the
pregnancy.
(b) Section 25 of the Mental Capacity Act, an advance decision to refuse life-sustaining treatment
must be in writing. It must be signed by the patient or someone on his behalf and signed by a
witness. It must also include a written statement by the patient that the decision will apply to the
specific treatment even if the patient’s life is at risk. Under Article 7: 450 of the Dutch Civil Code, an
advance directive should be in written form, dated and signed to be valid. Section 110Q of the
Western Australia Guardianship and Administration Act, 1990 requires advance directives to be
signed in the presence of two witnesses, who must both be at least 18 years of age and one of whom
must be a person authorised to witness legal documents under the relevant law. Section 15 of the
South Australia Advance Directives Act, 2013 sets out requirements for ‘suitable’ witnesses under
the Act. A person may not be a witness if she is appointed as a substitute decision-maker under the
advance directive, has a direct or indirect interest in the estate of the person executing the advance
directive or is a health practitioner responsible for the health care of the person executing the
advance directive. Similar disqualifications for witnesses are prescribed in the Oregon Death with
Dignity Act, 2002 when a person makes a written request for medication for the purpose of endingCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

her life in a humane and dignified manner.
(c) Under Section 24(3) of the UK Mental Capacity Act, 2005, a person may alter or withdraw an
advance decision at any time he has the capacity to do so. Under Section 25(2)(c), an advance
decision will not be applicable if a person has done anything else clearly inconsistent with the
advance decision. Under Section 3.06 of the Oregon Death with Dignity Act, 2005, a person may
rescind her written request for medicating at any time regardless of her mental state. To allow for a
change of mind, Section 3.08 also requires at least 15 days to lapse between the patient’s initial oral
request and the writing of a prescription, while a minimum of 48 hours must elapse between the
patient’s written request and the writing of a prescription. Under Section 110S of the Western
Australia Guardianship and Administration Act, 1990, a treatment decision in an advance directive
does not operate if circumstances exist or have arisen that the maker of that directive could not
reasonably have anticipated at the time of making the directive and that would have caused a
reasonable person in the maker’s position to have changed her mind about the directive. While
determining whether such circumstances have arisen, the age of the maker and the period that has
elapsed between the time at which the directive was made and the circumstances that have arisen
are factors that must be taken into account while determining the validity of the directive.
(d) Section 26(4) of the UK Mental Capacity Act permits courts to make a declaration as to whether
the advance decision exists, is valid, and applicable to a treatment. Under Article 373 of the Swiss
Civil Code, ‘any person closely related to the patient can contact the adult protection authority in
writing and claim that... the patient decree is not based on the patient’s free will.’ Under Section
110V, 110W, 110X, 110Y and 110Z of the Western Australia Guardianship and Administration Act,
1990, any person who has a ‘proper interest’ in the matter, in the view of the State Administrative
Tribunal, may apply to it for a declaration with respect to the validity of an advance directive. It can
also interpret the terms of the directive, give directions to give effect to it or revoke a treatment
decision in the directive.
134) Mr. Datar has suggested that this Court should frame the guidelines to cover the following
aspects:
(a) Who will be competent to execute an advance directive?
(b) In what form will an advance directive have to be issued in order to be valid?
(c) Who is to ensure that an advance directive is properly obeyed?
(d) What legal consequences follow from the non-obedience to an advance directive?
(e) In what circumstances can a doctor refuse to enforce an advance directive?
135) He has given the following suggestions on the aforesaid aspects:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(a) Only adult persons, above the age of eighteen years and of sound mind at the time
at which the advance directive is executed should be deemed to be competent. This
should include persons suffering from mental disabilities provided they are of sound
mind at the time of executing an advance directive.
(b) Only written advance directives that have been executed properly with the
notarised signature of the person executing the advance directive, in the presence of
two adult witnesses shall be valid and enforceable in the eyes of the law. The form
should require a reaffirmation that the person executing such directives has made an
informed decision. Only those advance directives relating to the withdrawal or
withholding of life-sustaining treatment should be granted legal validity. The
determination that the executor of the advance directive is no longer capable of
making the decision should be made in accordance with relevant medical
professional regulations or standard treatment guidelines, as also the determination
that the executor’s life would terminate in the absence of life-sustaining treatment.
The constitution of a panel of experts may also be considered to make this
determination. The use of expert committees or ethics committees in other
jurisdictions is discussed at Para 28 of these written submissions.
(c) Primary responsibility for ensuring compliance with the advance directive should
be on the medical institution where the person is receiving such treatment.
(d) If a hospital refuses to recognise the validity of an advance directive, the relatives
or next friend may approach the jurisdictional High Court seeking a writ or
mandamus against the concerned hospital to execute the directive. The High Court
may examine whether the directive has been properly executed, whether it is still
valid (i.e. whether or not circumstances have fundamentally changed since its
execution, making it invalid) and/or applicable to the particular circumstances or
treatment.
(e) No hospital or doctor should be made liable in civil or criminal proceedings for
having obeyed a validly executed advance directive.
(f) Doctors citing conscientious objection to the enforcement of advance directives on
the grounds of religion should be permitted not to enforce it, taking into account
their fundamental right under Article 25 of the Constitution. However, the hospital
will still remain under this obligation.
136) All these suggestions and various aspects of advance directives have been
elaborately considered and detailed directions are given by the Hon’ble the Chief
Justice in his judgment, with which I duly concur. In summation, I say that this Court
has, with utmost sincerity, summoned all its instincts for legality, fairness and
reasonableness in giving a suitable answer to the vexed issue that confronts the
people on daily basis, keeping in mind the competing interests and balancing thoseCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

interests. It will help lead society towards an informed, intelligent and just solution to
the problem.
137) My last remarks are a pious hope that the Legislature would step in at the
earliest and enact a comprehensive law on ‘living will/advance directive’ so that there
is a proper statutory regime to govern various aspects and nuances thereof which also
take care of the apprehensions that are expressed against euthanasia.
.....................................J. (A.K. SIKRI) NEW DELHI;
MARCH 09, 2018.
PART A IN THE SUPREME COURT OF INDIA CIVIL ORIGINAL JURISDICTION WRIT
PETITION (CIVIL) NO. 215 OF 2005 COMMON CAUSE (A REGD. SOCIETY) .... PETITIONER
VERSUS UNION OF INDIA & ANR ..... RESPONDENTS J U D G M E N T Dr D Y
CHANDRACHUD, J A Introduction: On Death and Dying 1 Life and death are inseparable. Every
moment of our lives, our bodies are involved in a process of continuous change. Millions of our cells
perish as nature regenerates new ones. Our minds are rarely, if ever, constant. Our thoughts are
fleeting. In a physiological sense, our being is in a state of flux, change being the norm. Life is not
disconnected from death. To be, is to die. PART A From a philosophical perspective, there is no
antithesis between life and death. Both constitute essential elements in the inexorable cycle of
existence. 2 Living in the present, we are conscious of our own mortality. Biblical teaching reminds
us that:
“There is a time for everything, and a season for every activity under the heavens : a
time to be born and a time to die, a time to plant, and a time to uproot, a time to kill
and a time to heal, a time to wear down and a time to build, a time to weep and a time
to laugh, a time to mourn and a time to dance.” (Ecclesiastes 3)
3 The quest of each individual to find meaning in life reflects a human urge to find fulfilment in the
pursuit of happiness. The pursuit of happiness is nurtured in creative pleasures and is grounded in
things as fundamental as the freedom to think, express and believe, the right to self-determination,
the liberty to follow a distinctive way of life, the ability to decide whether or not to conform and the
expression of identity.
4 Human beings through the ages have been concerned with death as much as with dying. Death
represents a culmination, the terminal point of life. Dying is part of a process: the process of living,
which eventually leads to death. The fear of death is a universal feature of human existence. The fear
is associated as much with the uncertainty of when death will occur as it is, with the suffering that
may precede it. The fear lies in the uncertainty of when an PART A event which is certain will occur.
Our fears are enhanced by the experience of dying that we share with those who were a part of our
lives but have gone before us. As human beings, we are concerned with the dignity of our existence.
The process through which we die bears upon that dignity. A dignified existence requires that the
days of our lives which lead up to death must be lived in dignity; that the stages through which lifeCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

leads to death should be free of suffering; and that the integrity of our minds and bodies should
survive so long as life subsists. The fear of an uncertain future confronts these aspirations of a
dignified life. The fear is compounded by the fact that as we age, we lose control over our faculties
and over our ability to take decisions on the course of our future. Our autonomy as persons is
founded on the ability to decide: on what to wear and how to dress, on what to eat and on the food
that we share, on when to speak and what we speak, on the right to believe or not to believe, on
whom to love and whom to partner, and to freely decide on innumerable matters of consequence
and detail to our daily lives. Ageing leaves individuals with a dilution of the ability to decide. The
fear of that loss is ultimately, a fear of the loss of freedom. Freedom and liberty are the core of a
meaningful life. Ageing brings dependency and a loss of control over our ability to shape what we
wish to happen to us. 5 The progression of life takes its toll on the human body and the mind. As we
age, simple tasks become less simple and what seemed to be a matter of course may become less so.
Human beings then turn ever more to the PART A substance that matters. As events, relationships,
associations and even memories fall by the way, we are left with a lonesome remnant of the person,
which defines the core of our existence. The quest of finding meaning in that core is often a matter
of confronting our fears and tragedies. 6 The fear of pain and suffering is perhaps even greater than
the apprehension of death. To be free of suffering is a liberation in itself. Hence the liberty to decide
how one should be treated when the end of life is near is part of an essential attribute of personhood.
Our expectations define how we should be treated in progressing towards the end, even when an
individual is left with little or no comprehension near the end of life. 7 Dilemmas relating to the end
of life have been on the frontline of debate across the world in recent decades. The debate has
presented “a complex maze of dilemmas for all - the doctor, the lawyer, the patient and the patient’s
relatives”1 and straddles issues of religion, morality, bio-medical ethics and constitutional law. It
has involved “issues ranging from the nature and meaning of human life itself, to the most
fundamental principles on which our societies are and should be based”2.
1 “The Dilemmas of Euthanasia”, Bio-Science (August 1973), Vol. 23, No. 8, at page 459 2 Margaret
A. Somerville, “Legalising euthanasia: why now?”, The Australian Quarterly (Spring 1996), Vol. 68,
PART A 8 There is an “ongoing struggle between technology and the law”; as “medical technology
has become more advanced, it has achieved the capability both to prolong human life beyond its
natural endpoint and to better define when that endpoint will occur”.3 Medical science has
contributed in a significant way to enhancing the expectancy of life. Diseases once considered fatal
have now become treatable. Medical research has redefined our knowledge of ailments – common
and uncommon; of their links with bodily functions and the complex relationship between mental
processes and physical well-being. Science which affects the length of life also has an impact on the
quality of the years in our lives. Prolonging life should, but does not necessarily result in, a reduction
of suffering. Suffering has a bearing on the quality of life. The quality of life depends upon the life in
our years. Adding to the length of life must bear a functional nexus with the quality of life. Human
suffering must have significance not only in terms of how long we live but also in terms of how well
we live.
9 Modern medicine has advanced human knowledge about the body and the mind. Equipped with
the tools of knowledge, science has shown the ability to reduce human suffering. Science has also
shown an ability to prolong life. Yet in its ability to extend life, medical science has an impact on theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

quality of life, as on the nature and extent of human suffering. Medical interventions come with
costs, both emotional and financial. The ability of science to 3Christopher N. Manning, “Live And
Let Die: Physician-Assisted Suicide And The Right To Die”, Harvard Journal of Law and Technology
(1996), Vol. 9, No. 2, at page 513 PART A prolong life must face an equally important concern over
its ability to impact on the quality of life. While medical science has extended longevity, it has come
with associated costs of medical care and the agony which accompanies an artificially sustained life.
Medical ethics must grapple with the need to bring about a balance between the ability of science to
extend life with the need for science to recognise that all knowledge must enhance a meaningful
existence.
10 There is “no consensus as to the rights and wrongs of helping someone to die”4, as the legal
status of euthanasia has been subjected to social, ethical and moral norms that have been handed
down to us. Decisions regarding the end of life can be ethically more problematic when the
individual is no longer mentally competent to make his or her own decisions.5 The existential and
metaphysical issues involved in this debate, include the fear of the unknown, the uncertainty of
when death will occur, the scarcity of health care, freedom or coercion in choosing to receive or not
to receive medical treatment, the dignity and degradation of ageing and being able to care for
oneself independently.6 11 Does the law have a role in these complex questions of life and death? If
it does, what are the boundaries which judges – as interpreters of law – 4 Alan Norrie, “Legal Form
and Moral Judgement: Euthanasia and Assisted Suicide” in R.A. Duff, et al (ed), The Structures of
the Criminal Law (Oxford University Press, 2011), at page 134 5 Elizabeth Wicks, The Right to Life
and Conflicting Interests (Oxford University Press, 2010), at page 199 6 Elizabeth M. Andal
Sorrentino, “The Right To Die?”, Journal of Health and Human Resources Administration PART A
must observe while confronting these issues of living and dying? The law, particularly constitutional
law, intervenes when matters governing freedom, liberty, dignity and individual autonomy are at
stake. To deny a role for constitutional law would be to ignore our own jurisprudence and the
primary role which it assigns to freedom and dignity. This case presents itself before the Court as a
canvass bearing on the web of life: on the relationship between science, medicine and ethics and the
constitutional values of individual dignity and autonomy. Among the issues which we confront are:
(i) Does an individual have a constitutionally recognized right to refuse medical
treatment or to reject a particular form of medical treatment;
(ii) If an individual does possess such a right, does a right inhere in the individual to
determine what course of action should be followed in the future if she or he were to
lose control over the faculties which enable them to accept or refuse medical
treatment;
(iii) Does the existence of a right in the individual impose a corresponding duty on a
medical professional who attends to the individual, to respect the right and what, if
any, are the qualifications of that duty;
(iv) Does the law permit a medical practitioner to withhold or refuse medical
treatment towards the end of life to an individual who is no longer in control of his orCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

her faculties in deference to a desire expressed while in a fit state of mind; and PART
A
(v) Would a withholding or refusal of medical treatment be permissible so as to allow
life to take its natural course, bereft of an artificial intervention, when there is no
realistic hope of return to a normal life.
12 This Court has to consider euthanasia and its impact “not only at an individual level”, but also at
the “institutional, governmental and societal levels”.7 The impact has to be analyzed not only in the
context of the present era, but has to be contemplated for the future as well. The judge is not a
soothsayer. Nor does the law have predictive tools at its command which can approximate those
available to a scientist. Constitutional principle must have an abiding value. It can have that value if
it is firmly grounded in the distilled experience of the past, is flexible to accommodate the concerns
of the present and allows room for the unforeseeable future. The possibility of the abuse of
euthanasia and the effect that legalising euthanasia would have on intangible societal fabrics and
institutions is of utmost concern. 13 Contemporary writing on the subject reminds us about how
serious these issues are and of how often they pose real dilemmas in medicine. They are poignantly
brought out by Dr Atul Gawande in his acclaimed book, “Being Mortal”:
“If to be human is to be limited, then the role of caring professions and institutions -
from surgeons to nursing homes
- ought to be aiding people in their struggle with those limits. Sometimes we can offer
a cure, sometimes only a salve, 7 Ibid PART A sometimes not even that. But whatever
we can offer, our interventions, and the risks and sacrifices they entail, are justified
only if they serve the large aims of a person's life.
When we forget that, the suffering we inflict can be barbaric. When we remember it, the good we do
can be breathtaking."8 He reminds us of how much people value living with dignity over merely
living longer:
“A few conclusions become clear when we understand this:
that our most cruel failure in how we treat the sick and the aged is the failure to
recognize that they have priorities beyond merely being safe and living longer; that
the chance to shape one’s story is essential to sustaining meaning in life; that we have
the opportunity to refashion our institutions, our culture, and our conversations in
ways that transform the possibilities for the last chapters of everyone’s lives.”9
14 Dr Henry Marsh, a neurosurgeon in the UK has significantly titled his provocative memoir
“Admissions” (2017). Speaking of euthanasia, he observes:
“We have to choose between probabilities, not certainties, and that is difficult. How
probable is it that we will gain how many extra years of life, and what might theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

quality of those years be, if we submit ourselves to the pain and unpleasantness of
treatment? And what is the probability that the treatment will cause severe side
effects that outweigh any possible benefits? When we are young it is usually easy to
decide – but when we are old, and reaching the end of our likely lifespan? We can
choose, at least in theory, but our inbuilt optimism and love of life, our fear of death
and the difficulty we have in looking at it steadily, make this very difficult. We
inevitably hope that we will be one of the lucky ones, one of the long-term survivors,
at the good and not the bad tail-end of the statisticians’ normal distribution. And yet
it has been estimated that in the developed world, 75 per cent of our lifetime medical
costs are incurred in the last six 8 Atul Gawande, Being Mortal: Medicine and What
Matters in the End (Hamish Hamilton, 2014), at page 260 9 Ibid, at page 243 PART
B months of our lives. This is the price of hope, hope which, by the laws of
probability, is so often unrealistic. And thus we often end up inflicting both great
suffering on ourselves and unsustainable expense on society.” 10 These are but a few
of the examples of emerging literature on the subject.
15 The central aspect of the case is the significance which the Constitution attaches to the ability of
every individual in society to make personal choices on decisions which affect our lives. Randy
Pausch, a Professor at Stanford had this to say in a book titled “The Last Lecture” (2008),11 a
discourse delivered by him in the shadow of a terminal illness.
“We cannot change the cards we are dealt, just how we play the hand”.
We may not be masters of our destiny. Nor can we control what life has in store. What we can
determine is how we respond to our trials and tribulations.
B          The reference
16         On 25 February 2014, three Judges of this Court opined that the issues
raised in this case need to be considered by a Constitution Bench. The referring order notes that the
case involves “social, legal, medical and constitutional” perspectives which should be considered by
five judges. At the heart of the proceeding, is a declaration which Common Cause seeks that the
right to die with dignity is a fundamental right which arises from the right to live 10 Henry Marsh,
Admissions: A Life in Brain Surgery, (Weidenfeld & Nicolson, 2017), at page 265-266 11 Randy
Pausch and Jeffrey Zaslow, The Last Lecture, (Hodder & Stoughton, 2008), at page 17 PART B with
dignity. Article 21 of the Constitution is a guarantee against the deprivation of life or personal liberty
except according to the procedure established by law. As our law has evolved, the right against the
violation of life and personal liberty has acquired much more than a formal content. It can have true
meaning, if only it includes the right to live with dignity. It is on this premise that the court is urged
to hold that death with dignity is an essential part of a life of dignity. A direction is sought to the
Union Government to adopt suitable procedures to ensure that persons with “deteriorated health”
or those who are terminally ill should be able to execute a document in the form of “a living will and
attorney authorization” which can be presented to a hospital for appropriate action if the personCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

who has made it, is hospitalized with a serious illness which may cause the end of life. The petitioner
also seeks, in the alternative, that this Court should issue guidelines and appoint an expert
committee consisting of doctors, social scientists and lawyers who will govern the making of ‘living
wills’.
17 Individuals who suffer from chronic disease or approach the end of the span of natural life often
lapse into terminal illness or a permanent vegetative state. When a medical emergency leads to
hospitalization, individuals in that condition are sometimes deprived of their right to refuse
unwanted medical treatment such as feeding through hydration tubes or being kept on a ventilator
and other life support equipment. Life is prolonged artificially resulting in human suffering. The
petition is founded on the right of each PART B individual to make an informed choice.
Documenting a wish in advance, not to be subjected to artificial means of prolonging life, should the
individual not be in a position later to comprehend or decline treatment, is a manifestation of
individual choice and autonomy. The process of ageing is marked by a sense of helplessness. Human
faculties decline as we grow older. Social aspects of ageing, such as the loss of friendships and
associations combine with the personal and intimate to enhance a sense of isolation. The boundaries
and even the limits of constitutional law will be tested as the needs of the ageing and their concerns
confront issues of ethics, morality and of dignity in death. 18 In support of its contention, the
petitioner relies upon two decisions: a decision rendered in 1996 by a Constitution Bench in Gian
Kaur v State of Punjab12 (“Gian Kaur”) and a decision of 2011 rendered by two judges in Aruna
Ramachandra Shanbaug v Union of India13 (“Aruna Shanbaug”). The decision in Gian Kaur arose
from a conviction for the abetment of suicide. In an earlier decision rendered by two judges in 1994 -
P Rathinam v Union of India14 (“Rathinam”), penalising an attempt to commit suicide was held to
violate Article 21 on the foundation that the right to life includes the right to die. The decision in
Rathinam was held not to have laid down the correct principle, in Gian Kaur. Hence the decision in
Aruna Shanbaug noted that Article 21 does not protect the right to die and an attempt to commit
suicide is a crime. However, in Aruna Shanbaug, the court held that since 12(1996) 2 SCC 648 13
(2011) 15 SCC 480 14 (1994) 3 SCC 394 PART B Gian Kaur rules that the right to life includes living
with human dignity, “in the case of a dying person who is terminally ill or in a permanent vegetative
state, he may be permitted to terminate by a premature extinction of his life”, and this would not be
a crime. The Bench which decided Aruna Shanbaug was of the view that Gian Kaur had “quoted with
approval” the view of the House of Lords in the UK in Airedale NHS Trust v Bland15 (“Airedale”). 19
When these judgments were placed before a Bench of three judges in the present case, the court
observed that there were “inherent inconsistencies” in the judgment in Aruna Shanbaug. The
referring order accordingly opined that:
“Aruna Shanbaug (supra) aptly interpreted the decision of the Constitution Bench in
Gian Kaur (supra) and came to the conclusion that euthanasia can be allowed in
India only through a valid legislation. However, it is factually wrong to observe that
in Gian Kaur (supra), the Constitution Bench approved the decision of the House of
Lords in Airedale v. Bland: (1993) 2 W.L.R. 316 (H.L.). Para 40 of Gian Kaur (supra),
clearly states that "even though it is not necessary to deal with physician assisted
suicide or euthanasia cases, a brief reference to this decision cited at the Bar may be
made..." Thus, it was a mere reference in the verdict and it cannot be construed toCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

mean that the Constitution Bench in Gian Kaur (supra) approved the opinion of the
House of Lords rendered in Airedale (supra). To this extent, the observation in Para
101 is incorrect.” The referring order goes on to state that:
“In Paras 21 & 101, the Bench [in Aruna Shanbaug] was of the view that in Gian Kaur
(supra), the Constitution Bench 15(1993) 2 WLR 316 (H.L) PART B held that
euthanasia could be made lawful only by a legislation. Whereas in Para 104, the
Bench contradicts its own interpretation of Gian Kaur (supra) in Para 101 and states
that although this Court approved the view taken in Airedale (supra), it has not
clarified who can decide whether life support should be discontinued in the case of an
incompetent person e.g., a person in coma or PVS. When, at the outset, it is
interpreted to hold that euthanasia could be made lawful only by legislation where is
the question of deciding whether the life support should be discontinued in the case
of an incompetent person e.g., a person in coma or PVS.” The reason why the case
merits evaluation by the Constitution Bench is elaborated in the Order dated 25
February 2014. Simply put, the basis of the reference to the Constitution Bench is
that:
(i) Gian Kaur affirms the principle that the right to live with dignity includes the right
to die with dignity;
(ii) Gian Kaur has not ruled on the validity of euthanasia, active or passive;
(iii) Aruna Shanbaug proceeds on the erroneous premise that Gian Kaur approved of
the decision of the House of Lords in Airedale;
(iv) While Aruna Shanbaug accepts that euthanasia can be made lawful only through
legislation, yet the court accepted the permissibility of passive euthanasia and set
down the procedure which must be followed;
and
(v) Aruna Shanbaug is internally inconsistent and proceeds on a misconstruction of the decision in
Gian Kaur.
20      This being the basis of the reference, it is necessary to consider the
decisions          in      Gian          Kaur          and         Aruna        Shanbaug.
                                                                                   PART C
C     Gian KaurCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

21    Gian Kaur and Harbans Singh were spouses. They were convicted of
abetting the suicide of Kulwant Kaur and were held guilty of an offence under Section 306 of the
Penal Code. They were sentenced to six years’ imprisonment. The conviction was upheld by the High
Court. The conviction was assailed before this Court on the ground that Section 306 is
unconstitutional. It was argued that the constitutionality of Section 306 rested on the two judge
Bench decision in Rathinam, where Section 309 (penalising the attempt to commit suicide) was held
to be unconstitutional. While Rathinam had rejected the challenge to the validity of Section 309 on
the ground that it was arbitrary (and violated Article 14), the provision was held to be
unconstitutional on the ground that it violated Article 21. The right to die was found to inhere in the
right to life, as a result of which Section 309 was found to be invalid. The challenge in Gian Kaur was
premised on the decision in Rathinam: abetment of suicide by another (it was urged) is merely
assisting in the enforcement of the fundamental right under Article 21 and hence Section 306 (like
Section 309) would violate Article 21. 22 The Constitution Bench in Gian Kaur disapproved of the
foundation of Rathinam, holding that it was flawed. The Constitution Bench held thus:
“When a man commits suicide he has to undertake certain positive overt acts and the
genesis of those acts cannot be traced to, or be included within the protection of the
'right to life' under Article 21. The significant aspect of 'sanctity of life' PART C is also
not to be overlooked. Article 21 is a provision guaranteeing protection of life and
personal liberty and by no stretch of imagination can 'extinction of life' be read to be
included in 'protection of life'. Whatever may be the philosophy of permitting a
person to extinguish his life by committing suicide, we find it difficult to construe
Article 21 to include within it the 'right to die' as a part of the fundamental right
guaranteed therein. 'Right to life' is a natural right embodied in Article 21 but suicide
is an unnatural termination or extinction of life, and therefore, incompatible and
inconsistent with the concept of 'right to life'. With respect and in all humility, we
find no similarity in the nature of the other rights, such as the right to 'freedom of
speech' etc. to provide a comparable basis to hold that the 'right to life' also includes
the 'right to die'. With respect, the comparison is inapposite, for the reason indicated
in the context of Article 21. The decisions relating to other fundamental rights
wherein the absence of compulsion to exercise a right was held to be included within
the exercise of that right, are not available to support the view taken in P. Rathinam
qua Article 21.” The Court further held that:
“To give meaning and content to the word 'life' in Article 21, it has been construed as
life with human dignity. Any aspect of life which makes it dignified may be read into
it but not that which extinguishes it and is, therefore, inconsistent with the continued
existence of life resulting in effacing the right itself. The 'right to die', if any, is
inherently inconsistent with the 'right to life' as is 'death' with 'life'.” Gian Kaur holds
that life within the meaning of Article 21 means a life of dignity. Extinguishment of
life is (in that view) inconsistent with its continued existence. Hence, as a matter of
textual construction, the right to life has been held not to include the right to die. InCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

coming to that conclusion, it appears that Gian Kaur emphasises two strands (which
the present judgment will revisit at a later stage). The first strand is the sanctity of
life, which Article 21 recognises. Extinction of life, would in this view, in the manner
which Rathinam allowed, violate the sanctity of life. The second strand that emerges
PART C from Gian Kaur is that the right to life is a natural right. Suicide as an
unnatural extinction of life is incompatible with it. The court distinguishes the right
to life under Article 21 from other rights which are guaranteed by Article 19 such as
the freedom of speech and expression. While free speech may involve the absence of a
compulsion to exercise the right (the right not to speak) this could not be said about
the right to life. The Constitution Bench noticed the debate on euthanasia in the
context of individuals in a permanent vegetative state. A scholarly article on the
decision notes that the Constitution Bench “seemed amenable to an exception being
made for euthanasia in cases of patients in a condition of PVS16. This view of the
decision in Gian Kaur does find support in the following observations of the
Constitution Bench:
“Protagonism of euthanasia on the view that existence in persistent vegetative state
(PVS) is not a benefit to the patient of a terminal illness being unrelated to the
principle of ‘Sanctity of life' or the 'right to live with dignity' is of no assistance to
determine the scope of Article 21 for deciding whether the guarantee of 'right to life'
therein includes the 'right to die'. The 'right to life' including the right to live with
human dignity would mean the existence of such a right up to the end of natural life.
This also includes the right to a dignified life up to the point of death including a
dignified procedure of death. In other words, this may include the right of a dying
man to also die with dignity when his life is ebbing out. But the 'right to die' with
dignity at the end of life is not to be confused or equated with the 'right to die' an
unnatural death curtailing the natural span of life.” (Para 24) 16SushilaRao, “India
and Euthanasia: The Poignant Case of Aruna Shanbaug”, Oxford Medical Law
Review, Volume 19, Issue 4 (1 December 2011), at pages 646–656 PART C However,
in the paragraph which followed, the Constitution Bench distinguished between cases
where a premature end to life may be permissible, when death is imminent, from the
right to commit suicide:
“A question may arise, in the context of a dying man, who is, terminally ill or in a
persistent vegetative state that he may be permitted to terminate it by a premature
extinction of his life in those circumstances. This category of cases may fall within the
ambit of the 'right to die' with dignity as a part of right to live with dignity, when
death due to termination of natural life is certain and imminent and the process of
natural death has commenced. These are not cases of extinguishing life but only of
accelerating conclusion of the process of natural death which has already
commenced. The debate even in such cases to permit physician assisted termination
of life is inconclusive. It is sufficient to reiterate that the argument to support the
view of permitting termination of life in such cases to reduce the period of suffering
during the process of certain natural death is not available to interpret Article 21 toCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

include therein the right to curtail the natural span of life.” (Para 25) On this
foundation, the Constitution Bench held that Article 21 does not include the right to
die. The right to live with human dignity, in this view, could not be construed to
include the right to terminate natural life “at least before commencement of the
natural process of certain death”.
This Court’s holding in Gian Kaur that the right to life does not include the right to
die in the context of suicide may require to be revisited in future in view of domestic
and international developments17 pointing towards decriminalisation of suicide. In
India, the Mental Healthcare Act 2017 has 17 “Humanization and Decriminalization
of Attempt to Suicide”, Law Commission of India (Report No. 210, 2008);
Rajeev Ranjan, et al, “(De-) Criminalization of Attempted Suicide in India: A Review”, Industrial
Psychiatry Journal (2014), Vol. 23, issue 1, at page 4–9 PART C created a “presumption of severe
stress in cases of attempt to commit suicide”. Section 115(1) provides thus:
“Notwithstanding anything contained in section 309 of the Indian Penal Code any
person who attempts to commit suicide shall be presumed, unless proved otherwise,
to have severe stress and shall not be tried and punished under the said Code.” Under
Section 115(2), the Act also mandates the Government to provide care, treatment and
rehabilitation to a person, having severe stress and who attempted to commit suicide,
to reduce the risk of recurrence. Section 115 begins with a non-obstante provision,
specifically with reference to Section 309 of the Penal Code. It mandates (unless the
contrary is proved by the prosecution) that a person who attempts to commit suicide
is suffering from severe stress. Such a person shall not be tried and punished under
the Penal Code. Section 115 removes the element of culpability which attaches to an
attempt to commit suicide under Section 309. It regards a person who attempts
suicide as a victim of circumstances and not an offender, at least in the absence of
proof to the contrary, the burden of which must lie on the prosecution. Section 115
marks a pronounced change in our law about how society must treat and attempt to
commit suicide. It seeks to align Indian law with emerging knowledge on suicide, by
treating a person who attempts suicide being need of care, treatment and
rehabilitation rather than penal sanctions.
PART C It may also be argued that the right to life and the right to die are not two separate rights,
but two sides of the same coin. The right to life is the right to decide whether one will or will not
continue living.18 If the right to life were only a right to decide to continue living and did not also
include a right to decide not to continue living, then it would be a duty to live rather than a right to
life. The emphasis on life as a right and not as a duty or obligation has also been expressed by
several other legal scholars:
“When, by electing euthanasia, the individual has expressly renounced his right to
life, the state cannot reasonably assert an interest in protecting that right as a basis
for overriding the individual's private decision to die. To hold otherwise makes littleCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

more sense than urging a prohibition against destroying or giving away one's private
property simply because the Constitution protects property as well as life. Although
the Constitution recognizes that human life is, to most persons, of inestimable value
and protects against its taking without due process of law, nothing in that document
compels a person to continue living who does not desire to do so. Such an
interpretation effectively converts a right into an obligation, a result the
constitutional framers manifestly did not intend.”19 (Emphasis supplied) For the
present case, we will leave the matter there, since neither side has asked for
reconsideration of Gian Kaur, it being perhaps not quite required for the purposes of
the reference.
23 At this stage, it is also necessary to note that the decision in Gian Kaur contained a passing
reference to the judgment of the House of Lords in Airedale which dealt with the withdrawal of
artificial measures for the 18 D Benatar, “Should there be a legal right to die?” Current Oncology
(2010), Vol. 17, Issue 5, at pages 2-3 19 Richard Delgado, “Euthanasia Reconsidered-The Choice of
Death as an Aspect of the Right of Privacy”, Arizona Law Review (1975), Vol. 17, at page 474 PART D
continuance of life by a physician. In that context, it was held that a persistent vegetative state was
of no benefit to the patient and hence, the principle of sanctity of life is not absolute. The
Constitution Bench reproduced the following extracts from the decision in Airedale:
“...But it is not lawful for a doctor to administer a drug to his patient to bring about
his death, even though that course is prompted by a humanitarian desire to end his
suffering, however great that suffering may be : See Reg v. Cox, (unreported), 18
September (1992). So to act is to cross the Rubicon which runs between on the one
hand the care of the living patient and on the other hand euthanasia - actively causing
his death to avoid or to end his suffering. Euthanasia is not lawful at common law. It
is of course well known that there are many responsible members of our society who
believe that euthanasia should be made lawful; but that result could, I believe, only
be achieved by legislation which expresses the democratic will that so fundamental a
change should be made in our law, and can, if enacted, ensure that such legalised
killing can only be carried out subject to appropriate supervision and control....
(emphasis supplied by the Bench). Making emphasis as above, this Court held that it
is in the realm of the legislature to enact a suitable law to provide adequate
safeguards regarding euthanasia”.
The Constitution Bench noted that the desirability of bringing about such a change was considered
(in Airedale) to be a function of the legislature by enacting a law with safeguards, to prevent abuse.
D     Aruna Shanbaug
24    Aruna Shanbaug was a nurse in a public hospital when she was
sexually assaulted in 1973. During the incident, she was strangled by the attacker with a chain. The
assault resulted in depriving the supply of oxygen to PART D her brain. Over a period of thirty sevenCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

years, she had not recovered from the trauma and damage to the brain. She was forsaken by family
and was cared for over this period by the staff of the hospital. A petition under Article 32 was
instituted before this Court. The petitioner had authored a book on her saga and instituted the
proceedings claiming to be her “next friend”. The direction which was sought was to stop feeding the
patient and allow her to die a natural death. Aruna Shanbaug was examined by a team of doctors
constituted by this Court who observed that while she was in a permanent vegetative state, she was
clearly not in coma. 25 A two Judge Bench of this Court held that Gian Kaur did not lay down a final
view on euthanasia:
“21. We have carefully considered paras 24 and 25 in Gian Kaur case [(1996) 2 SCC
648 : 1996 SCC (Cri) 374] and we are of the opinion that all that has been said therein
is that the view in Rathinam case [(1994) 3 SCC 394 : 1994 SCC (Cri) 740] that the
right to life includes the right to die is not correct. We cannot construe Gian Kaur
case [(1996) 2 SCC 648 :
1996 SCC (Cri) 374] to mean anything beyond that. In fact, it has been specifically
mentioned in para 25 of the aforesaid decision that “the debate even in such cases to
permit physician-assisted termination of life is inconclusive”. Thus it is obvious that
no final view was expressed in the decision in Gian Kaur case [(1996) 2 SCC 648 :
1996 SCC (Cri) 374] beyond what we have mentioned above.”(Id at page 487)
26 The decision in Aruna Shanbaug distinguishes between active and passive euthanasia. Active
euthanasia is defined as the administration of a lethal substance or force to kill a person, such as for
instance, a lethal injection given to a person suffering from agony in a terminal state of cancer.
PART D Passive euthanasia is defined to mean the withholding or withdrawing of medical treatment
necessary for continuance of life. This may consist of withholding antibiotics without which the
patient may die or the removing of the patient from artificial heart/lung support. According to the
court, a comparative context of the position prevailing in other countries would indicate that:
“39…The general legal position all over the world seems to be that while active
euthanasia is illegal unless there is legislation permitting it, passive euthanasia is
legal even without legislation provided certain conditions and safeguards are
maintained.” (Id at page 491) Voluntary euthanasia envisages the consent of the
patient being taken whereas non-voluntary euthanasia deals with a situation where
the patient is in a condition where he or she is unable to give consent. The Court
noted that a distinction is drawn between euthanasia and physician assisted death in
the form of a physician or third party who administers it. Physician assisted suicide
involves a situation where the patient carries out the procedure, though on the advice
of the doctor. The court in Aruna Shanbaug distinguished between active and passive
euthanasia:
“43. The difference between “active” and “passive” euthanasia is that in active
euthanasia, something is done to end the patient's life while in passive euthanasia,
something is not done that would have preserved the patient's life. An important ideaCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

behind this distinction is that in “passive euthanasia” the doctors are not actively
killing anyone; they are simply not saving him.” (Id at page 492) PART D The above
extract indicates that the decision is premised on the performance of an act (in active
euthanasia) and an omission (in passive euthanasia).
Active euthanasia, in the view of the court, would be an offence under Section 302 or
at least under Section 304 while physician assisted suicide would be an offence under
Section 306 of the Penal Code. The decision adverted to the judgment of the House of
Lords in Airedale and then observed that:
“104. It may be noted that in Gian Kaur case [(1996) 2 SCC 648 : 1996 SCC (Cri) 374]
although the Supreme Court has quoted with approval the view of the House of Lords
in Airedale case [1993 AC 789 : (1993) 2 WLR 316 : (1993) 1 All ER 821 (CA and HL)]
, it has not clarified who can decide whether life support should be discontinued in
the case of an incompetent person e.g. a person in coma or PVS.” (Id at page 512)
Explaining the concept of brain death, the court held that passive euthanasia depends
upon two circumstances:
“117…(a) When a person is only kept alive mechanically i.e. when not only
consciousness is lost, but the person is only able to sustain involuntary functioning
through advanced medical technology—such as the use of heart-lung machines,
medical ventilators, etc.
(b) When there is no plausible possibility of the person ever being able to come out of
this stage. Medical “miracles” are not unknown, but if a person has been at a stage
where his life is only sustained through medical technology, and there has been no
significant alteration in the person's condition for a long period of time—at least a
few years—then there can be a fair case made out for passive euthanasia.” (Id at page
517) Noting that there is no statutory provision regulating the procedure for
withdrawing life support to a person in PVS or who is incompetent to take a decision,
the court ruled that passive euthanasia should be permitted in PART D certain
situations. Until Parliament decides on the matter, the modalities to regulate passive
euthanasia would (according to the court) be as follows:
“124…(i) A decision has to be taken to discontinue life support either by the parents
or the spouse or other close relatives, or in the absence of any of them, such a
decision can be taken even by a person or a body of persons acting as a next friend. It
can also be taken by the doctors attending the patient. However, the decision should
be taken bona fide in the best interest of the patient…
(ii) Hence, even if a decision is taken by the near relatives or doctors or next friend to
withdraw life support, such a decision requires approval from the High Court
concerned as laid down in Airedale case [1993 AC 789 : (1993) 2 WLR 316 : (1993) 1
All ER 821 (CA and HL)].” (Id at page 518-519)Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

27 The approval of the High Court was mandated to obviate the danger that “this may be misused by
some unscrupulous persons who wish to inherit or otherwise grab the property of the patient”.
Moreover, the court directed that when an application is filed before the High Court, a committee of
three doctors (a neurologist, psychiatrist and physician) should be constituted, to submit its opinion
to enable the High Court to take a considered decision in the case. On the facts of the case, the court
held that the petitioner who had visited Aruna Shanbaug only on a few occasions and had written a
book on her could not be recognised as her next friend. It was only the hospital staff which had
cared for her for long years which would be recognised. The doctors and nursing staff had evinced
an intent to allow her to live in their care.
28 The decision in Aruna Shanbaug has proceeded on the hypothesis that the Constitution Bench in
Gian Kaur had “quoted with approval” the PART D decision of the House of Lords in Airedale. This
hypothesis is incorrect. There was only a passing reference to the decision of the House of Lords. In
fact, Gian Kaur prefaces its reference to Airedale with the following observation:
“40…Even though it is not necessary to deal with physician- assisted suicide or
euthanasia cases, a brief reference to this decision cited at the Bar may be made.” (Id
at page 665) The decision in Gian Kaur referred to the distinction made in Airedale
between cases in which a physician decides not to provide or to continue to provide
treatment which would prolong life and cases in which a physician decides to actively
bring an end to the life of the patient by administering a lethal drug. The court in
Airedale observed that actively causing the death of the patient could be made lawful
only by legislation. It was this aspect which was emphasised by the judgment in Gian
Kaur. Hence, the position adopted in Aruna Shanbaug, that the Constitution Bench in
Gian Kaur quoted Airedale with approval (as the basis of allowing passive
euthanasia) is seriously problematic. In fact, the extract from Airedale which was
cited in Gian Kaur indicates the emphasis placed on the need to bring in legislation to
allow active euthanasia.
29 In an incisive analysis20, Ratna Kapur argues that while focussing on euthanasia, discussions on
Aruna Shanbaug have ignored other considerations regarding gender, sexual assault, what
constitutes “caring”, the 20 Ratna Kapur, “The Spectre of Aruna Shanbaug”, The Wire (18 May
2015), available at https://thewire.in/2005/the-spectre-of-aruna-shanbaug/ PART D right to bodily
integrity and workplace protection. A central issue is, according to Kapur, the “politics of caring”, -
who can care, has the capacity to care and who is less caring or less capable of caring. The Supreme
Court did not accept Pinki Virani as the “next friend” but awarded guardianship to KEM hospital
staff on the ground that they had “an emotional bonding and attachment” to Aruna Shanbaug and
were her “real family.” Kapur observes that an emotional bond is not a valid criterion for a “next
friend” and the expression “real family” has dangerous implications for those who may not fall
within the normative remit of that phrase though they have a relationship with the concerned
person. She asks if the concept of “next friend” will cover only “biological familial ties” and “render
all other non-familial, non-marital, non- heterosexual relationships as ineligible?” She argues that
decisions about life and death should “rest on the anvil of dignity, and dignity is not a family value,
or linked to some essential gendered trait. It is a societal value and hence needs to be delinked fromCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

the traditional frameworks of family and gender stereotypes.” Kapur expresses concerns about how
the focus on “care” seemed to obscure a deeper and more important consideration regarding
women’s safety in the workplace. The attack on Aruna Shanbaug in KEM hospital was indicative of
how the workplace was unsafe for women, and yet the staff of the same hospital were given her
guardianship. This is especially concerning given the fact that the dean of the hospital at the time
refused to allow a complaint of sodomy to go forward as he was more concerned about the
reputation of the institution. Kapur laments the fact that Aruna’s case was PART D not used to bring
out the reform that it should have - stating that it should ‘have been a leading case on women’s
rights where “caring” extended beyond the physical support for the individual who was harmed, to
taking active steps to improve the working conditions for women, including addressing pervasive
and systemic sex discrimination and sexism.’ Lastly, Kapur compels us to think about the choices
Aruna Shanbaug may have made - “Had Shanbaug not been reduced to a PVS, would she have
chosen to remain in KEM for her treatment after the violent and brutal sexual assault that she
experienced in her work place? Or would she have chosen to be treated elsewhere? Would she have
sued the hospital for failing to provide her a safe working environment?” Thus, Kapur questions the
very basis of making the hospital the guardians by questioning why the hospital did not “care” when
it mattered the most - when the case of sexual assault and sodomy should have been pursued by the
hospital on behalf of its employee. By denying Aruna Shanbaug the right to bodily integrity in life
and the right to self-determination in death, and by viewing her life from all lenses but from her
own, ranging from the “carers”, to the medical and legal profession and their views on euthanasia,
she “became nothing more than a spectre in her own story.” 30 Aruna Shanbaug also presents
another problem- one of inconsistency. Gian Kaur is construed as laying down only that the right to
life does not include the right to die and that the decision in Rathinam was incorrect. In that
context, it has been noticed that the Constitution Bench observed that the PART D debate overseas
even in physician assisted termination of life is inconclusive. Aruna Shanbaug finds, on the one
hand, that “no final view was expressed” in Gian Kaur beyond stating that the right to life does not
include the right to die. Yet, on the other hand, having inferred the absence of a final view on
euthanasia in Gian Kaur, that decision is subsequently construed as having allowed the termination
of life by a premature extinction in the case of a “dying person who is terminally ill or in a
permanent vegetative state”. Both lines of reasoning cannot survive together.
31 The procedure which was followed by this Court in Aruna Shanbaug of arranging for a screening
of a CD submitted by the team of doctors pertaining to her examination in a live court proceeding
open to the public has been criticised as being fundamentally violative of privacy. What transpired
in the court is set out in the following observations from the decision:
“11. On 2-3-2011, the matter was listed again before us and we first saw the screening
of the CD submitted by the team of doctors along with their report. We had arranged
for the screening of the CD in the courtroom, so that all present in the Court could see
the condition of Aruna Shanbaug. For doing so, we have relied on the precedent of
the Nuremburg trials in which a screening was done in the courtroom of some of the
Nazi atrocities during the Second World War.” (Id at page 476) This aspect of the
case is indeed disquieting. To equate a patient in PVS for thirty-seven years following
a sexual assault, with the trials of Nazi war criminals is seriously disturbing.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

PART D
32 Aruna Shanbaug rests on the distinction between an act and an omission. The court seems to
accept that the withdrawal of life support or a decision not to provide artificial support to prolong
life is an omission. In the view of the court, an omission is what is “not done”. On the other hand,
what is actively done to end life is held to stand on a separate foundation. At this stage, it would be
necessary to note that the validity of the distinction between what is passive and what is active has
been the subject of a considerable degree of debate. This would be dealt with in a subsequent part of
this judgment.
33 The issue before the Constitution Bench in Gian Kaur related to the constitutionality of Section
306 of the Penal Code which penalises the abetment of suicide. The challenge proceeded on the
foundation that penalising an attempt to commit suicide had been held to be unconstitutional since
the right to live included the right to die. The Constitution Bench emphasised the value ascribed to
the sanctity of life and came to the conclusion that the right to die does not emanate from the right
to life under Article 21. Having held that the right to die is “inherently inconsistent” with the right to
life “as is death with life”, the Constitution Bench opined that the debate on euthanasia was “of no
assistance to determine the scope of Article 21” and to decide whether the right to life includes the
right to die. The court noted that the right to life embodies the right to live with human dignity
which postulates the existence of such a right “up to the end of natural life”. This, the PART D court
observed included the right to lead a dignified life up to the point of death and included a dignified
procedure of death. Thus, in the context of the debate on euthanasia, the Constitution Bench was
careful in observing that the right to a dignified life “may include” the right of an individual to die
with dignity. A premature termination of life of a person facing imminent death in a terminal illness
or in a permanent vegetative state was in the view of the court a situation which “may fall” within
the ambit of the right to die with dignity. The debate on physician assisted termination of life was
noted to be “inconclusive”. The court observed that the argument to support the termination of life
in such cases to reduce the period of suffering during the process of “certain natural death” was not
available to interpret Article 21 as embodying the right to curtail the natural span of life. These
observations in Gian Kaur would indicate that the Constitution Bench has not made a final or
conclusive determination on euthanasia. Indeed, the scope of the controversy before the court did
not directly involve that question. Aruna Shanbaug evidently proceeds on a construction of the
decision in Gian Kaur which does not emerge from it. Aruna Shanbaug has inherent internal
inconsistencies. Hence, the controversy which has been referred to the Constitution Bench would
have to be resolved without regarding Aruna Shanbaug as having laid down an authoritative
principle of constitutional law. PART E E The distinction between the legality of active and passive
euthanasia 34 In examining the legality of euthanasia, clarification of terminology is essential. The
discourse on euthanasia is rendered complex by the problems of shifting and uncertain descriptions
of key concepts. Central to the debate are notions such as “involuntary”, “non-voluntary” and
“voluntary”. Also “active” and “passive” are used, particularly in combination with “voluntary”
euthanasia. In general, the following might be said: · • involuntary euthanasia refers to the
termination of life against the will of the person killed;Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

• non-voluntary euthanasia refers to the termination of life without the consent or opposition of the
person killed; · • voluntary euthanasia refers to the termination of life at the request of the person
killed; · • active euthanasia refers to a positive contribution to the acceleration of death;
• passive euthanasia refers to the omission of steps which might otherwise sustain life.
What is relatively straightforward is that involuntary euthanasia is illegal and amounts to murder.
However, the boundaries between active and passive euthanasia are blurred since it is quite possible
to argue that an omission amounts to a positive act.
PART E 35 The expression ‘passive’ has been used to denote the withdrawal or withholding of
medical treatment. Implicit in this definition is the assumption that both the withdrawal of or
withholding treatment stand on the same ethical or moral platform. This assumption, as we shall see
in a later part of this section, is not free of logical difficulty. The voluntary or non-voluntary
character of the euthanasia is determined by the presence or absence of consent. Consent postulates
that the individual is in a mental condition which enables her to choose and to decide on a course of
action and convey this decision. Its voluntary nature is premised on its consensual character.
Euthanasia becomes non-voluntary where the individual has lost those faculties of mind which
enable her to freely decide on the course of action or lost the ability to communicate the chosen
course of action. 36 The distinctions between active and passive euthanasia are based on the manner
in which death is brought about. They closely relate (in the words of Hazel Biggs in a seminal work
on the subject) to the understanding and consequences of the legal concepts of act and omission.21
37 As early as 1975, American philosopher and medical ethicist James Rachels offered a radical
critique of a distinction that was widely accepted by medical ethicists at that time, that passive
euthanasia or “letting die” was 21 Hazel Biggs, “Euthanasia, Death with Dignity and the Law”, Hart
Publishing (2001), at page 12 PART E morally acceptable while active euthanasia or “killing” was
not.22 Even though his paper did not change the prevalence of this distinction at the time it was
published, it paved the way by providing credibility for arguments to legalise assisted suicide in the
1990s. In what he calls the ‘Equivalence Thesis’, Rachels states “there is no morally important
difference between killing and letting die; if one is permissible (or objectionable), then so is the
other and to the same degree.”23 He does not offer a view on whether the practice of euthanasia is
acceptable or not. His central thesis is that both active and passive euthanasia are morally
equivalent- either both are acceptable or both are not. Reichenbach for instance, asks: Supposing all
else is equal, can a moral judgment about euthanasia be made on the basis of it being active or
passive alone?24. The ‘Equivalence thesis’ postulates that if a doctor lets a patient die (commonly
understood as passive euthanasia) for humane reasons, he is in the same moral position as if he
decided to kill the patient by giving a lethal injection (commonly understood as active euthanasia)
for humane reasons.
38 The correctness of this precept may be questioned by pointing out that there is a qualitative
difference between a positive medical intervention (such as a lethal injection) which terminates life
and a decision to not put a patient on artificial life support, which will not artificially prolong life.
The former brings 22 James Rachels, “Active and Passive Euthanasia”, New England Journal of
Medicine (January 9, 1975), at page 78-80 23 James Rachels, End of Life: Euthanasia and MoralityCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(Oxford University Press, 1986) 24 Bruce R. Reichenbach, “Euthanasia and the Active-Passive
Distinction”, Bioethics (January 1987), Volume 1, at pages 51–73 PART E a premature extinction of
life. The latter does not delay the end of life beyond its natural end point. But, if the decision to
proceed with euthanasia is the right one based on compassion and the humanitarian impulse to
reduce pain and suffering, then the method used is not in itself important. Moreover, it is argued
that passive euthanasia often involves more suffering since simply withholding treatment means
that the patient may take longer to die and thus suffer more. Passive euthanasia may become
questionable where the withholding or withdrawal of medical intervention may lead to a condition
of pain and suffering, often a lingering and cruel death. The avoidance of suffering, which is the
object and purpose of euthanasia, may hence not be the result of passive euthanasia and the
converse may result. Besides raising troubling moral questions – especially where it is
non-voluntary, it questions the efficacy of passive euthanasia. Moreover, it raises a troubling issue of
the validity of the active-passive divide.
39 The moral and legal validity of the active-passive distinction based on the exculpation of
omissions has been criticised. One of the reasons for the exculpation of omissions is based on the
idea that our duty not to harm people is generally stricter than our duty to help them.25 James
Rachels offers a compelling counter-argument to the argument that killing someone is a violation of
our duty not to do harm, whereas letting someone die is merely a failure to help. He argues that our
duty to help people is less stringent than the 25 James Rachels (Supra note 23), at pages 101-120
PART E duty not to harm them only in cases where it would be very difficult to help them or require
a great amount of effort or sacrifice. However, when we think of cases where it would be relatively
simple to help someone and there would be no great personal sacrifice required, the morally
justifiable response would be different. He provides a hypothetical example of a child drowning in a
bathtub, anyone standing next to the tub would have a strict moral duty to help the child.26 Due to
the equation between the child and the person standing next to the bathtub (the proximity may be in
terms of spatial distance or relationship) the “alleged asymmetry” between the duty to help and the
duty not to do harm vanishes. A person standing next to bathtub would have no defence to say that
this was merely a failure to help and did not violate the duty to do no harm. In cases of euthanasia
since the patient is close at hand and it is within the professional skills of the medical practitioner to
keep him alive, the alleged asymmetry has little relevance. The distinction is rendered irrelevant
even in light of the duty of care that doctors owe to their patients. Against the background of the
duty to care, the moral and legal status of not saving a life due to failure to provide treatment, can be
the same as actively taking that life.27 A doctor who knowingly allows a patient who could be saved
to bleed to death might be accused of murder and medical negligence. The nature of the
doctor-patient relationship which is founded on the doctor’s duty of care towards the patient
necessitates that omissions on the doctor’s part will also be penalised. When doctors take off life
support, they can foresee 26 Ibid 27 Len Doyal and Lesley Doyal, “Why Active Euthanasia and
Physician Assisted Suicide Should Be Legalised⁄ If Death Is in a Patient’s Best Interest Then Death
Constitutes a Moral Good”, British Medical Journal (2001), at pages 1079–1080.
PART E that death will be the outcome even though the timing of the death cannot be determined.
Thus, what must be deemed to be morally and legally important must not be the emotionally
appealing distinction between omission and commission but the justifiability or otherwise of theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

clinical outcome. Indeed, the distinction between omission and commission may be of little value in
some healthcare settings.28 40 This distinction leads to the result that even though euthanasia is
grounded in compassion and to relieve the patient of suffering, only certain types of deaths can be
lawful. If active euthanasia amounts to “killing”, the operation of criminal law can lead to medical
practitioners being exposed to the indignity of criminal prosecutions and punishments.29 While
passive euthanasia can appear to save the dignity of medical practitioners, it is perhaps at the
expense of the patient’s dignity.30 41 A recent article by Rohini Shukla in the Indian Journal of
Medical Ethics (2016) points out two major flaws in Aruna Shanbaug regarding the distinction
between active and passive euthanasia.31 First, it fails to prioritise the interest of the patient and is
preoccupied with the effect of euthanasia on everyone but the patient, and second, that it does not
distinguish between the terms “withholding and withdrawing and uses them interchangeably.” 28
Ibid 29 Hazel Biggs (Supra note 21), at Page 162 30 Ibid 31 Rohini Shukla, “Passive Euthanasia in
India: a critique”, Indian Journal of Medical Ethics (Jan-Mar 2016), at pages 35-38 PART E
Throughout the above judgment, the words “withholding” and “withdrawing” are used
interchangeably. However, the difference between the two is relevant to the distinction between
what is ‘active’ and ‘passive’ as act and omission. Withholding life support implies that crucial
medical intervention is restrained or is not provided – an act of omission on the part of the doctor.
Withdrawing life support implies suspending medical intervention that was already in use to sustain
the patient’s life- an act of commission. If the basis of distinction between active and passive
euthanasia is that in passive euthanasia the doctor only passively commits acts of omission, while in
active euthanasia the doctor commits acts of commission then withdrawing medical treatment is an
act of commission and therefore amounts to active euthanasia. In both these cases, the doctor is
aware that his/her commissions or omissions will in all likelihood lead to the patient’s death.
However, in passive euthanasia death may not be the only consequence and the suffering that
passive euthanasia often entails such as suffocation to death or starvation till death, raises the
question of whether passive euthanasia, in such circumstances, militates against the idea of death
with dignity – the very basis of legalising euthanasia.32 Shukla’s criticism needs careful attention
since it raises profound questions about the doctor-patient relationship and the efficacy of the
distinction in the context of death with dignity. If the divide between active-passive is questioned,
should both forms be disallowed or, in 32 Ibid PART E converse should both be allowed? More
significantly, are both equally amenable to judicially manageable standards? Even with Aruna
Shanbaug’s starting position that passive euthanasia is permitted under Indian law until expressly
prohibited, the Court did not traverse the vast Indian legal framework to determine whether there
was a prohibition to this effect. Instead the court made an analogy (perhaps incorrect) between a
doctor conducting passive euthanasia and a person who watches a building burning:
“An important idea behind this distinction is that in passive euthanasia, the doctors
are not actively killing anyone; they are simply not saving him. While we usually
applaud someone who saves another person’s life, we do not normally condemn
someone for failing to do so. If one rushes into a burning building and carries
someone out to safety, he will probably be called a hero. But, if someone sees a
burning building and people screaming for help, and he stands on the sidelines –
whether out of fear for his own safety, or the belief that an inexperienced and
ill-equipped person like himself would only get in the way of the professionalCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

firefighters, or whatever – if one does nothing, few would judge him for his action.
One would surely not be prosecuted for homicide (Atleast, not unless one started the
fire in the first place)…[T] here can be no debate about passive euthanasia: You
cannot persecute someone for failing to save a life. Even if you think it would be good
for people to do X, you cannot make it illegal for people to not do X, or everyone in
the country who did not do X today would have to be arrested.” The example is
inapposite because it begs the relationship between the person who is in distress and
the individual whose position as a caregiver (actual or prospective) is being
considered. The above example may suggest a distinct outcome if the by-stander who
is ill equipped to enter a burning PART E building is substituted by a fire-fighter on
duty. Where there is a duty to care, the distinction between an act and an omission
may have questionable relevance. Acts and omissions are not disjunctive or isolated
events.
Treatment of the human body involves a continuous association between the
caregiver and receiver. The expert caregiver is involved in a continuous process
where medical knowledge and the condition of the patient as well as the
circumstances require the doctor to evaluate choices - choices on the nature and
extent of medical intervention, the wisdom about a course of action and about what
should or should not be done.
42 An erroneous premise in the judgment is that omissions are not illegal under
Indian law.33 Section 32 of the Indian Penal Code deals with illegal omissions and
states that “In every part of this Code, except where a contrary intention appears
from the context, words which refer to acts done, extend to illegal omissions.”
Whether and to what extent this omission would be illegal under Indian law will be
discussed in a subsequent part of the judgment.
43 Since the judgment legalised passive euthanasia, withdrawing medical support
was the only option in the case of Aruna Shanbaug and if this had been done, she
would have in all likelihood suffocated to death. We must ponder over whether this
could be the best possible death in consonance with the right to live with dignity
(which extends to dignity when death approaches)
33 Aparna Chandra and Mrinal Satish, “Misadventures of the Supreme Court in Aruna Shanbaug v
Union of India”, Law and other Things (Mar 13, 2011), available at
http://lawandotherthings.com/2011/03/misadventures-of- supreme-court-in-aruna/ PART E and
the extent to which it upholds the principle of prioritising the patient’s autonomy and dignity over
mere prolongation of life. Had the Court taken into account these consequences of passive
euthanasia for the patient, it would be apparent that passive euthanasia is not a simple panacea for
an individual faced with end of life suffering.
This brings us to the second and more crucial flaw, which was the unjustified emphasis on doctor’s
agency in administering different types of euthanasia which led to ignoring the patient’s autonomyCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

and suffering. Respecting patient autonomy and reducing suffering are fundamental ethical values
ascribed to euthanasia. It is also the foremost principle of bioethics. 34 The effects of euthanasia on
everyone (particularly her caregivers) were given greater importance than the patient’s own wishes
and caregiver:
“In case hydration or food is withdrawn/withheld from Aruna Ramchandra
Shanbaug, the efforts which have been put in by batches after batches of nurses of
KEM Hospital for the last 37 years will be undermined. Besides causing a deep sense
of resentment in the nursing staff as well as other well- wishers of Aruna
Ramchandra Shanbaug in KEM Hospital including the management, such
act/omissions will lead to disheartenment in them and large-scale disillusionment.”
44 Aruna Shanbaug was in no position to communicate her wishes. But the above
extract from the judgment relegates her caregiver to the background. The manner in
which the constitutional dialogue is framed by the court elevates the concerns of the
caregiver on a high pedestal without
34 Roop Gurusahani and Raj Kumar Mani, “India: Not a country to die in”, Indian Journal of
Medical Ethics (Jan-
Mar 2016), at pages 30-35.
PART E focusing on the dignity and personhood of the individual in a permanent vegetative state. In
doing so, the judgment subordinates the primary concern of bio-ethics and constitutional law, which
is preserving the dignity of human life.
45 An article35 in the Oxford Medical Law Review notes that there are strong grounds to believe
that the active-passive distinction in Aruna Shanbaug was not grounded so much in morality as in
‘reasons of policy’. Even while there are pertinent questions regarding the moral validity of the
active-passive distinction, there appears to be a significant difference between active and passive
euthanasia when viewed from the lens of the patient’s consent. Consent gives an individual the
ability to choose whether or not to accept the treatment that is offered. But consent does not confer
on a patient the right to demand that a particular form of treatment be administered, even in the
quest for death with dignity.36 Voluntary passive euthanasia, where death results from selective
non-treatment because consent is withheld, is therefore legally permissible while voluntary active
euthanasia is prohibited. Moreover, passive euthanasia is conceived with a purpose of not
prolonging the life of the patient by artificial medical intervention. Both in the case of a withdrawal
of artificial support as well as in non-intervention, passive euthanasia allows for life to ebb away and
to end in the natural course. In 35 Sushila Rao (Supra note 16), at pages 646-656 36 Hazel Biggs
(Supra note 21), at page 30 PART F contrast, active euthanasia results in the consequence of
shortening life by a positive act of medical intervention. It is perhaps this distinction which
necessitates legislative authorisation for active euthanasia, as differentiated from the passive.
46 The question of legality of these two forms of euthanasia has significant consequences. Death
when it is according to the wishes and in the caregiver of the patient must be viewed as a moralCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

good. The fact that active euthanasia is an illegal act (absent legislative authorisation) also prevents
many professional and emotional carers from performing it even if they perceive it as a
compassionate and otherwise appropriate response in line with the patient’s wishes and caregiver,
thereby prolonging the patient’s suffering and indignity. These complex issues cannot be addressed
when active euthanasia is not legalised and regulated. The meeting point between bio-ethics and law
does not lie on a straight course.
F         Sanctity of Life
47        Diverse thinkers have debated and deliberated upon the value accorded
to human life.37 The “sanctity of life” principle has historically been the single most basic and
normative concept in ethics and the law. 38 The phrase has 37 Elizabeth Wicks (Supra note 5), at
page 29 38 Anne J. Davis, “Dilemmas in Practice: To Make Live or Let Die”, The American Journal
of Nursing (March PART F emerged as a key principle in contemporary bioethics, especially in
debates about end-of-life issues.39 48 The traditional and standard view is that life is invaluable.40
It has persisted as an idea in various cultures through the centuries. A sacred value has been
prioritized for human life. This “rhetoric of the value in human life”41 has been highlighted in
various traditions.42 The protection of the right to life derives from “the idea that all human life is of
equal value” ¥ the idea being drawn from religion, philosophy and science.43 49 The principle or
doctrine of the “sanctity of life”, sometimes also referred to as the “inviolability of human life”44, is
based on “overarching moral considerations”, the first of which has been stated as:
“Human life is sacred, that is inviolable, so one should never aim to cause an
innocent person’s death by act or omission”.45
50 Distinct from religious beliefs, the special value inherent in human life has been recognised in
secular ideas of natural law ¥ “man as an end in 39 Heike Baranzke, ““Sanctity-of-Life”—A
Bioethical Principle for a Right to Life?”, Ethic Theory Moral Practice (2012), Vol. 15, Issue 3, at
page 295 40 Elizabeth Wicks (Supra note 5), at page 1 41 Ibid, at page 240 42 PG Lauren argues that
it is “essential to recognise that the moral worth of each person is a belief that no single civilization,
or people, or nation, or geographical area, or even century can claim as uniquely its own” See P.G.
Lauren, The Evolution of International Human Rights: Visions Seen (University of Pennsylvania
Press, 2003, 2nd edn.), at page 12.), as quoted in Elizabeth Wicks (Supra note 5), at pages 25-29 43
Elizabeth Wicks (Supra note 5), at page 47 44 John Keown, The Law and Ethics of Medicine: Essays
on the Inviolability of Human Life (Oxford University Press, 2012), at page 3 45 Ibid PART F
himself, and human investment in life”.46 Locke has been of the view that every human being “is
bound to preserve himself, and not to quit his station wilfully”.47 In his book “Life’s Dominion”,
Ronald Dworkin explains the sanctity of human life thus:
“The hallmark of the sacred as distinct from the incrementally valuable is that the
sacred is intrinsically valuable because— and therefore only once—it exists. It is
inviolable because of what it represents or embodies. It is not important that there beCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

more people. But once a human life has begun, it is very important that it flourish
and not be wasted.”48 Life today, according to Dworkin, is not just created by the
science of evolution but by past choices—by the investment that an individual, and
others, have put into his or her life.49 51 Elizabeth Wicks in her book titled “The
Right to Life and Conflicting Interests” (2010) has succinctly summarized the moral
and ethical justifications for the sanctity of life thus:
“The life of an individual human being matters morally not because that organism is
sentient or rational (or free of pain, or values its own existence) but because it is a
human life. This point is supported by the ethical and legal principle of equality
which is well established in the field of human rights… From an end of life
perspective, this means that life ends only when the human organism dies. This
cannot sensibly require the death of all of the body’s cells but rather the death of the
organism as a whole. In other words, life comes to an end when the integrative action
between the
46 Elizabeth Wicks (Supra note 5), at pages 34-35 47 John Locke, Two Treatises of Government (ed.
P. Laslett) (Cambridge University Press, 1988) 48 Ronald Dworkin, Life’s Dominion: An Argument
about Abortion and Euthanasia (Harper Collins, 1993), at pages 73-74 49 Elizabeth Wicks (Supra
note 5), at page 32 PART F organs of the body is irreversibly lost. It is the life of the organism which
matters, not its living component parts, and thus it is the permanent destruction of that integrative
organism which signifies the end of the organism’s life.”50 52 The value of human life has been
emphasized by Finnis in the following words:
“[H]uman bodily life is the life of a person and has the dignity of the person. Every
human being is equal precisely in having that human life which is also humanity and
personhood, and thus that dignity and intrinsic value. Human bodily life is not mere
habitation, platform, or instrument for the human person or spirit. It is therefore not
a merely instrumental good, but is an intrinsic and basic human good. Human life is
indeed the concrete reality of the human person. In sustaining human bodily life, in
however impaired a condition, one is sustaining the person whose life it is. In
refusing to choose to violate it, one respects the person in the most fundamental and
indispensable way. In the life of the person in an irreversible coma or irreversibly
persistent vegetative state, the good of human life is really but very inadequately
instantiated. Respect for persons and the goods intrinsic to their wellbeing requires
that one make no choice to violate that good by terminating their life.”51
53 In his book “The Law and Ethics of Medicine: Essays on the Inviolability of Human Life” (2012),
John Keown has explained the principle of the sanctity or inviolability of human life and its
continuing relevance to English law governing aspects of medical practice at the beginning and end
of life. Keown has distinguished the principle from the other two “main competing approaches to the
valuation of human life”52¥“vitalism” on the one hand and a “qualitative” evaluation of human life
on the other. The approach of “vitalism” 50 Ibid, at pages 16-17 51 John Finnis, Human Rights and
Common Good (Oxford University Press, 2011), at page 221 52 John Keown (Supra note 44), at pageCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

4 PART F assumes that “human life is the supreme good and one should do everything possible to
preserve it”. The core principle of this approach is “try to maintain the life of each patient at all
costs”.53 54 In the “quality of life” approach, Keown has argued that “there is nothing supremely or
even inherently valuable about the life of a human being”. The value of human life “resides in
meeting a particular “quality” threshold”, above which the dignity of life would be “worthwhile”.
Keown criticizes this approach for its basis that since “certain lives are not worth living, it is right
intentionally to terminate them, whether by act or omission”.54 55 Keown sums up that the doctrine
of the sanctity or inviolability of life holds that “we all share, by virtue of our common humanity, an
ineliminable dignity” ¥ this dignity grounds the “right to life”.55 The essence of the principle is that
“it is wrong to try to extinguish life”.56 Intentional killing is prohibited by any act or omission.
Keown thereby emphasises the sanctity and inviolability of life in the following words:
“Human life is a basic, intrinsic good… The dignity of human beings inheres because
of the radical capacities, such as for understanding, rational choice, and free will,
inherent in human nature… All human beings possess the capacities inherent in their
nature even though, because of infancy, disability, or senility, they may not yet, not
now, or no longer 53 Ibid 54 Ibid, at page 5 55 Ibid, at page 6 56 Ibid, at page 6 PART
F have the ability to exercise them. The right not to be killed is enjoyed regardless of
inability or disability. Our dignity does not depend on our having a particular
intellectual ability or having it to a particular degree...”57
56 The principle of the sanctity of life considers autonomy as a “valuable capacity, and part of
human dignity”58. However, autonomy’s contribution to dignity is “conditional, not absolute”59.
The limitations of autonomy under the sanctity of life doctrine can be summarized as follows:
“Exercising one’s autonomy to destroy one’s (or another’s) life is always wrong
because it is always disrespectful of human dignity. So: it is always wrong
intentionally to assist/encourage a patient to commit suicide and, equally, there is no
“right to commit suicide,” let alone a right to be assisted to commit suicide, either by
act or omission… The principle of “respect for autonomy” has in recent years become
for many a core if not dominant principle of biomedical ethics and law. It is not,
however, unproblematic. Its advocates often fail to agree on precisely what
constitutes an “autonomous” choice or to offer any convincing account of why respect
for someone else’s choice as such should be regarded as a moral principle at all, let
alone a core or dominant moral principle.”60 John Keown, however, while
distinguishing the principle of sanctity of life from vitalism, has also argued that
though this principle “prohibits withholding or withdrawing treatment with intent to
shorten life”, but it also “permits withholding/withdrawing a life-prolonging
treatment which is not worthwhile because it is futile or too burdensome”. It does not
require doctors to try to
57 Ibid, at pages 5-6 58 Ibid, at page 18 59 Ibid 60 Ibid PART F preserve life at all costs.61 This
consideration, despite all the assumptions and discussions about the sanctity of life, in a way, makes
the doctrine an open- ended phenomenon.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

57 This open-endedness is bound to lead to conflicts and confusions. For instance, the issue of the
sacred value of life is potentially a conflicting interest between a right to life and autonomy, which
Wicks explains as follows:
“If we accept that human life has some inherent value, is it solely to the individual
who is enjoying that life or is there some broader state or societal benefit in that life?
If life is of value only to the person living it, then this may elevate the importance of
individual autonomy. It may even suggest that it is an individual’s desire for respect
for his or her own life that provides the inherent value in that life. On the other hand,
it might be argued that the protection of human life is, at least partly, a matter of
public interest. Whether it is to the state, or other members of society, or only an
individual’s own family and friends, there is an argument that a human life is a thing
of value to others beyond the individual living that life… [I]f life is legally and
ethically protected in deference to the individual’s wish for respect for that life, the
protection would logically cease when an autonomous choice is made to bring the life
to an end. If, however, the life is protected, at least partly, due to the legitimate
interest in that life enjoyed by the state or other (perhaps select) members of society,
then the individual’s autonomous choice to end his or her life is not necessarily the
decisive factor in determining whether legal and ethical protection for that life should
continue.”62
58 The disagreement between “sanctity of life” and the “quality of life” is another conflict, which can
be summarized as follows:
61 Ibid, at page 13 62 Elizabeth Wicks (Supra note 5), at p 176-177 PART G “If we
start with a sanctity of life position, this affirms the value of human life in a way that
trumps even claims to self-
determination… [P]eople who suffer from terminal or degenerative illness… who want to die must
remain alive in great pain or discomfort until death comes ‘naturally’ to them. Similarly, people who
suffer from long-term disability or paralysis which grossly diminishes their capacities for life and
who cannot take their own lives, are not permitted to die. In such circumstances, the argument for
sanctity of life may seem somewhat sanctimonious to the person who is not allowed the assistance to
end their own life. There have been cases in the media in recent years where the moral difficulty in
insisting on the sanctity of life in such situations has been made clear. Though such cases will not
disturb the position of she who believes fundamentally in the sanctity of life, they do lead others to
accept that there may be exceptional cases where sanctity gives way to quality of life issues.”63
Therefore, intractable questions about morality and ethics arise. What is the core of life that might
be protected by law? Will a poor quality of life (in the shadow of the imminence of death) impact
upon the value of that life to such an extent that it reduces the protection for that life offered by the
sanctity of life doctrine? Are there limits to the principle of sanctity? This needs to be reflected upon
in the next part of the judgment.
G         Nuances of the sanctity of life principleCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

59        The sanctity of life has been central to the moral and ethical foundations
of society for many centuries. Yet, it has been suggested that “across the range of opinions most
people would seem to agree that life is valuable to some degree, but the extent to which any ‘value’ is
founded in intrinsic worth 63 Alan Norrie (Supra note 4), at pages 141-142 PART G or instrumental
opportunity is contentious”.64 Glanville Williams, a strong proponent of voluntary euthanasia, was
of the view that “there was a human freedom to end one's life”. According to him, “the law could not
forbid conduct that, albeit undesirable, did not adversely affect the social order”.65 That view, as
argued by Luis Kutner in his article “Euthanasia: Due Process for Death with Dignity; The Living
Will”66, was similar to that advanced by John Stuart Mill. Mill, in his classic work “On Liberty”
stated:
“Mankind are great gainers by suffering each other to live as seems good to
themselves, than by compelling each to live as seems good to the rest.”67 Are there
limits to or nuances of the sanctity principle? This must be discussed for a fuller
understanding of the debate around euthanasia.
60 Though the sanctity principle prohibits “the deliberate destruction of hu-
man life, it does not demand that life should always be prolonged for as long as possible”.68 While
providing for an intrinsic sacred value to life “irrespective of the person’s capacity to enjoy life and
notwithstanding that a person may feel their life to be a great burden”, the principle holds that “life
should not always be maintained at any and all cost”.69 Ethical proponents of the sanctity of life
tend to agree that when “medical treatment, such as ventilation and 64 Alexandra Mullock,
End-Of-Life Law And Assisted Dying In The 21st Century: Time For Cautious Revolution? (PhD
Thesis, University of Manchester, 2011), at page 24 65 Luis Kutner, “Euthanasia: Due Process for
Death with Dignity; The Living Will”, Indiana Law Journal (Winter 1979), Vol. 54, Issue, 2, at page
225 66 Ibid, at pages 201-228 67 Ibid, at pages 225-226 68 Sushila Rao, “The Moral Basis for a
Right to Die”, Economic & Political Weekly (April 30, 2011), at page 14 69 Alexandra Mullock,
End-Of-Life Law And Assisted Dying In The 21st Century: Time For Cautious Revolution? (PhD
Thesis, University of Manchester, 2011), at page 25 PART G probably also antibiotics, can do
nothing to restore those in permanent vegetative state to a state of health and well-functioning, it is
futile and need not be provided”.70 Rao has thus suggested that “the law’s recognition that
withdrawal of life-prolonging treatment is sometimes legitimate” is not generally an exception to the
sanctity principle, but is actually “an embodiment of it”.71 61 Philosopher and medical ethicist
James Rachels has in a seminal work72 titled “The End of Life: Euthanasia and Morality (Studies in
Bioethics)” in the year 1986 propounded that we must embrace an idea of the sanctity of life which
is firmly based in ethics (the idea of right and wrong) and not based in religion. The separation of
religion from morality and ethics does not necessarily mean a rejection of religion, but that the
doctrine of “sanctity of life” must be accepted or rejected on its merits, by religious and
non-religious people alike. The value of life is not the value that it has for God or the value that it
may have from any religious perspective. The truth of moral judgments and exercising reason to
decide what is right and wrong does not depend on the truth of theological claims. The value of lifeCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

is the value that it has for the human beings who are subjects of lives. Thus, the value of life must be
understood from the perspective of the person who will be harmed by the loss, the subject of life. It
is also important to understand the true meaning behind 70 John Keown, “The Legal Revolution:
From "Sanctity of Life" to "Quality of Life" and "Autonomy", Journal of Contemporary Health Law &
Policy (1998), Vol. 14, Issue 2, at page 281 71 Sushila Rao (Supra note 68), at page 14 72 James
Rachels, (Supra note 23) PART G the moral rule against killing. The rationale behind such a law is to
protect the interests of individuals who are the subject of lives. If the point of the rule against killing
is the protection of lives, then we must acknowledge that in some cases killing does not involve the
destruction of “life” in the sense that life is sought to be protected by law. For example, a person in
an irreversible coma or suffering a serious terminal illness is alive in a strictly biological sense but is
no longer able to live life in a way that may give meaning to this biological existence. The rule
against killing protects individuals that have lives and not merely individuals who are alive. When
an individual is alive only to the extent of being conscious in the most rudimentary sense, the
capacity to experience pleasure and pain (if any) does not necessarily have value if that is the only
capacity one has. These sensations will not be endowed with any significance by the one
experiencing them since they do not arise from any human activities or projects and they will not be
connected with any coherent view of the world.
62 It is instructive to analyse how the principle of the sanctity of life impacts upon views in regard to
capital punishment. (This comparison, it needs to be clarified in the present judgment, is not to
indicate an opinion on the constitutionality of the death penalty which is not in issue here).
Advocates of the sanctity of life would even allow capital punishment73, implying that they do not
oppose all killing of human beings. This suggests that “while they are anti- 73 Elizabeth Wicks
(Supra note 5), at pages 102-149 PART G euthanasia, they are not uniformly pro-life”74. In a
seminal article titled “The Song of Death: The Lyrics of Euthanasia”75, Margaret A. Somerville has
laid down “four possible positions that persons could take:
(i) that they are against capital punishment and against euthanasia;
(ii) that they agree with capital punishment, but are against euthanasia;
(iii) that they agree with capital punishment and euthanasia; or
(iv) that they are against capital punishment, but agree with euthanasia”.76 She
explained the underlying philosophy that these positions represent and its
implications:
“The first is a true pro-life position, in that, it demonstrates a moral belief that all
killing (except, usually, as a last resort in self-defence) is wrong. The second position
represents the view of some fundamentalists, namely, that to uphold the sanctity of
life value requires prohibition of euthanasia, but capital punishment is justified on
the grounds that this punishment is deserved and just according to God's law. The
third position is that of some conservatives, who see capital punishment as a fit
penalty on the basis that one can forfeit one's life through a very serious crime, butCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

that one can also consent to the taking of one's own life in the form of euthanasia.
The fourth view is that of some civil libertarians, that one can consent to the taking of
one's own life but cannot take that of others. Through such analyses, one can see
where the various groups agree with each other and disagree. For example, the true
pro-life persons and the fundamentalists agree with each other in being against
euthanasia, and some conservatives and civil libertarians agree with each other in
arguing for the availability of euthanasia. On the other hand, the true pro-life and
civil libertarians join in their views in being against capital punishment, whereas the
fundamentalists and some conservatives agree that this is acceptable.”77
74 Margaret A. Somerville, “The Song of Death: The Lyrics of Euthanasia”, Journal of Contemporary
Health Law & Policy (1993), Vol. 9, Issue 1, at page 67.
75 Ibid, at pages 1-76 76 Ibid, at page 67 77 Ibid, at pages 67-68 PART G The above explanation
suggests that there are variations in intellectual opinion on the concept of sanctity of life. When it
comes to taking of a person’s life, various groups while agreeing in certain terms, may be “radically
divergent in others”.78 63 Contrary to the vitalism or the sanctity of life principle, some scholars
and bioethicists have argued that “life is only valuable when it has a certain quality which enables
the subject to derive enjoyment from their existence so that life is viewed as being, on balance, more
beneficial than burdensome”. It has been argued that the sanctity of life principle should be
interpreted to protect lives in the biographical sense and not merely in a biological sense. 79 There is
a difference in the fact of being alive and the experience of living. From the point of view of the living
individual, there is no value in being alive except that it enables one to have a life.80 64 There is
wide-ranging academic research suggestive of a nuanced approach to the sanctity principle. During
the last four decades, “there has been a subtle change in the way” people perceive human life and
that “the idea of quality of life has become more prevalent in recent times”.81. The moral 78 Ibid 79
James Rachels (Supra note 23), at page 26 80 Ibid 81 Jessica Stern, Euthanasia and the Terminally
Ill (2013), retrieved from Florida State University Libraries PART G premium, as Magnusson has
remarked, is shifting “from longevity and onto quality of life”82.
In his article titled the “Sanctity of Life or Quality of Life?”83, Singer argued that the sanctity of life
principle has been under erosion ¥ the “philosophical foundations” of the principle being “knocked
asunder”.84 “The first major blow” to the principle, Singer stressed, “was the spreading acceptance
of abortion throughout the Western world”. Late abortions diluted the defence of the “[alleged]
universal sanctity of innocent human life”. 85 Singer has further remarked:
“Ironically, the sanctity with which we endow all human life often works to the
detriment of those unfortunate humans whose lives hold no prospect except
suffering… One difference between humans and other animals that is relevant
irrespective of any defect is that humans have families who can intelligently take part
in decisions about their offspring. This does not affect the intrinsic value of human
life, but it often should affect our treatment of humans who are incapable of
expressing their own wishes about their future. Any such effect will not, however,
always be in the direction of prolonging life… If we can put aside the obsolete andCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

erroneous notion of the sanctity of all human life, we may start to look at human life
as it really is: at the quality of life that each human being has or can achieve. Then it
will be possible to approach these difficult questions of life and death with the ethical
sensitivity that each case demands, rather than with the blindness to individual
differences…”86
82 Roger S. Magnusson, “The Sanctity of Life and the Right to Die: Social and Jurisprudential
Aspects of the Euthanasia Debate in Australia and the United States”, Pacific Rim Law & Policy
Journal, Vol. 6, No. I, at page 40 83 Peter Singer, “Sanctity of Life or Quality of Life”, Pediatrics
(1983), Vo. 72, Issue 1, at pages 128-129 84 Ibid, at page 129 85 Ibid, at page 128 86 Ibid, at page
129 PART G 65 The quality of life approach has its basis in the way life is being lived. “An overriding
concern”, under this approach, “is the conditions under which people live rather than whether they
live”.87 This does not mean that someone “who chooses to end their life through euthanasia” does
not value their lives as much as others.88 Breck in his article titled “Euthanasia and the Quality of
Life Debate”89 has stated that:
“Ethicists of all moral and religious traditions recognize that medical decisions today
inevitably involve quality of life considerations. Very few would be inclined to sustain
limited physiological functioning in clearly hopeless cases, as with anencephaly or
whole-brain death, simply because the technology exists to do so. That such a case is
indeed hopeless, however, is a quality of life judgment: it weighs the relationship
between the patient's condition and the treatment options and concludes that
attempts to sustain biological existence would be unnecessarily burdensome or
simply futile. Judgments made in light of "futility" or the "burden- benefit calculus"
are necessarily based on evaluations of the "quality" of the patient's life. Such quality,
however, must always be determined in light of the patient's own personal interests
and well-being, and not on grounds of the burden imposed on other parties (the
family, for example) or the medical care system with its economic considerations and
limited resources.”90 Weingarten is of the view that the emphasis on the sanctity of
life “should be replaced by ‘value of life’, which exposes the individual case to critical
87 “Sanctity of life vs. quality of life”, Los Angeles Times (June 7, 2015), available at
http://www.latimes.com/opinion/readersreact/la-le-0607-sunday-assisted-suicide-20150607-story.html
88 Jessica Stern, Euthanasia and the Terminally Ill (2013), available at
https://fsu.digital.flvc.org/islandora/object/fsu:209909/datastream/PDF/view 89
John Breck, “Euthanasia and the Quality of Life Debate”, Christian Bioethics (1995),
Vol. 1, No.3, at pages 322-337 90 Ibid, at pages 325-326 PART G scrutiny. Medicine
can better cope with its current and future ethical dilemmas by a case-by-case
approach.”91 Norrie explains why quality of life should be placed ahead of sanctity of
life in the debate on euthanasia:
“[W]hile there are good moral reasons of either a direct (that human life should be
generally valued as of intrinsic worth) or an indirect (that allowing exceptions would
lead to a slippery slope) kind for supporting a sanctity of life view in the case of the
terminally ill and ancillary cases, there are also good moral reasons for allowingCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

exceptions to it. The latter stem from a quality of life view and, linked to that, the
possibility of choosing the time and place of one’s own death. The possibility of
agency as a central element in what it means to be human is premised on the notion
of human freedom, and freedom implies a number of different elements. These
include a simple freedom to be left alone with one’s life, as well as a positive freedom
to become what we have it within ourselves to be. Such freedom then entails further
conceptions of autonomy, emancipation, and flourishing, insofar as human life
reflects the potentialities in human being. The ability to choose one’s own death
reflects many of these aspects of human freedom, from the simple sense that one
should be left alone to do what one likes with one’s life to the more complex sense
that an autonomous life would include amongst its components control over one’s
death, and then on to the sense—that is surely there in the term ‘euthanasia’ (a ‘good
death’)—that a flourishing life is one in which one is genuinely able to register the
time to go. These are moral arguments placing choice and quality of life ahead of
sanctity of life… A good life means a good death too, and it is this kind of argument
that leads one to think that a categorical prohibition on voluntary euthanasia…is
problematic.”92 91 Michael A Weingarten, “On the sanctity of life”, British Journal of
General Practice (April 2007), Vol. 57(537), at page 333 92 Alan Norrie (Supra note
4), at page 143 PART G Life and natural death
66 The defenders of the sanctity principle place sacred value to human life from “conception to
natural death”.93 The word “natural” implies that “the only acceptable death is one that occurs from
natural causes”. Life is only “sacred insofar as it ends by natural means”94. Medical advancements,
however, have brought uncertainty about the definition of death ¥ “what constitutes death, in
particular a “natural” death”. This uncertainty can be expressed through the following questions:
“If a person stays alive thanks to medical advances, is that really “natural”?...
When is the benefit of using technology and treatments to sustain life no longer
worth the pain that comes along with it?”95
67 Medical advances have “complicated the question of when life ends”. There exists no natural
death where artificial technology is concerned. Technology by artificial means can prolong life. In
doing so, technology has re- shaped both human experience as well as our values about life in a
natural state and its end by natural causes:
“[T]he process of dying is an inevitable consequence of life, the right to life
necessarily implies the right to have nature take its course and to die a natural death.
It also encompasses a right, unless the individual so wishes, not to have life
artificially maintained by the provision of nourishment by abnormal artificial means
which have no 93 Alecia Pasdera, The Rhetoric of the Physician-Assisted Suicide
Movement: Choosing Death Over Life (2014), available at
https://ou.monmouthcollege.edu/_resources/pdf/academics/mjur/2014/Rhetoric-of-the-Physician-
Assisted-Suicide-Movement-Choosing-Death-Over-Life.pdf, at page 68 94 Ibid, atCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

page 69 95 Ibid, at page 68 PART G curative effect and which are intended merely to
prolong life.”96
68 Modern medicine has found ways to prolong life and to delay death. But, it does not imply that
modern medicine “necessarily prolongs our living a full and robust life because in some cases it
serves only to prolong mere biological existence during the act of dying”. This may, in certain
situations result in a mere “prolongation of a heart-beat that activates the husk of a mindless,
degenerating body that sustains an unknowing and pitiable life-one without vitality, health or any
opportunity for normal existence-an inevitable stage in the process of dying”.97 Prolonging life in a
vegetative state by artificial means or allowing pain and suffering in a terminal state would lead to
questioning the belief that any kind of life is so sanctified as to be preferred absolutely over
death”.98 69 Kuhse and Hughes have stated that “the really critical issues in medicine are often
hidden” by “the hulking darkness” of the sanctity principle. According to them:
“Today the advances of science are occurring every minute. Lasers are used to crush
kidney stones; mechanical hearts are transplanted to prolong life; and organ
transplants are being increasingly used, particularly livers and eyes and, now
experimentally, legs. Microprocessor ventilators are used to maintain breathing in
patients unable to breathe on their own; chemotherapy/radiology is being used to
prolong the lives of cancer patients; long-term hemodialysis is being used for 96
Sushila Rao (Supra note 68), at page 15 97 Arval A. Morris, “Voluntary Euthanasia”,
Washington Law Review (1970), Vol. 45, at page 240 98 Ibid, at page 243 PART G
those who have non-functional kidneys; and cardiac pacemakers are being implanted
in patients whose hearts are unable to beat normally. While society has supported
research and development in medicine, the issues regarding the termination of such
treatment and, more importantly, the withholding of such treatment have not been
fully addressed.”99
70 The debate around human life will be driven by technology. “Sophisticated modern medical
technology”, even if ultimately not being able to conquer death, “has a lot to say about the conditions
and time of its occurrence”. Singer has envisioned a future where the debate around human life is
closely linked to the impact of technology on our existence:
“As the sophistication of techniques for producing images of soft tissue increases, we
will be able to determine with a high degree of certainty that some living, breathing
human beings have suffered such severe brain damage that they will never regain
consciousness. In these cases, with the hope of recovery gone, families and loved ones
will usually understand that even if the human organism is still alive, the person they
loved has ceased to exist. Hence, a decision to remove the feeding tube will be less
controversial, for it will be a decision to end the life of a human body, but not of a
person.”100
71 Lady Justice Arden recently delivered a lecture in India on a topic dealing with the intersection of
law and medicine titled “What does patient autonomy mean for Courts?”101. The judge explainedCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

that advancement in medical technology has contributed towards a growing importance of patient
autonomy and an increasing social trend towards questioning clinical 99 Elizabeth M. Andal
Sorrentino, “The Right To Die?”, Journal of Health and Human Resources Administration
(Spring,1986), Vol. 8, No. 4, at pages 361-373 100 Peter Singer, “The Sanctity of Life”, Foreign
Policy (October 20, 2009), available at http://foreignpolicy.com/2009/10/20/the-sanctity-of-life/
101 Lady Justice Arden, Law of medicine and the individual: current issues, What does patient
autonomy mean for the courts?, (Justice KT Desai Memorial Lecture 2017) PART G judgment,
which is causing conflict among courts in the UK- particularly in end of life treatment decisions. To
highlight this conflict, Judge Arden cites the example of baby Charlie Gard, a ‘caregiver case’102 that
engendered debate on medical ethics world over.
Born in August 2016 in London, Charlie suffered from an extremely rare genetic condition known as
MDDS, which causes progressive brain damage and muscle failure, usually leading to death in
infancy. His parents wanted him to undergo experimental treatment known as nucleoside which was
available in the USA and raised a large amount of money to enable him to travel there. However, the
doctors at the hospital in London who were treating him did not think it was in his caregiver to have
this treatment as instead they believed his caregiver demanded that his life-support be withdrawn as
they considered the treatment to be futile. Due to the conflicting views between the parents and the
doctors, the core issue to be decided i.e. whether it was in the best interest of the child to received
further treatment had to be answered by the Court. The case went through the judicial system-
including the High Court, the Supreme Court, the ECHR and finally back to the High Court, which
on the basis of medical reports concluded that it was not in the child’s caregiver to have further
treatment and passed an order permitting the doctors to allow Charlie to die.
Great Ormond Street Hospital v. Constance Yates, Christopher Gard, Charlie Gard (by his guardian),
[2017] EWHC 1909 (Fam) PART H In addition to the issue of caregiver, Lady Justice Arden also
mentioned the issue of resources in such cases. In the present case, the parents were able to raise
large amounts of financial resources required for the treatment of the child, but lack of resources
could lead to difficulties in other cases where treatment is unaffordable in a public health system. 72
Modern technology has in a fundamental manner re-shaped the notion of life. As technology
continuously evolves into more complex planes, it becomes even more necessary to re-evaluate its
relationship with the meaning and quality of life.
H         Euthanasia and the Indian Constitution
73        The sanctity of life principle appears in declarations on human rights as
the “right to life”.103 Under the Indian Constitution, right to life has been provided under Article 21.
In Pt. Parmanand Katara v Union of India104, it was pointed out:
“[P]reservation of life is of most importance, because if one’s life is lost, the status
quo ante cannot be restored as resurrection is beyond the capacity of man”.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

The sanctity of human life lies in its intrinsic value. It inheres in nature and is
recognised by natural law. But human lives also have instrumental functions.
103 John Keown (Supra note 44), at page 4 104 AIR 1989 SC 2039 PART H Our lives
enable us to fulfil our needs and aspirations. The intrinsic worth of life is not
conditional on what it seeks to or is capable to achieve. Life is valuable because it is.
The Indian Constitution protects the right to life as the supreme right, which is
inalienable and inviolable even in times of Emergency.105 It clearly recognises that
every human being has the inherent right to life, which is protected by law, and that
“No person shall be deprived of his life… except according to procedure established
by law” 106. It, thus, envisages only very limited circumstances where a person can
be deprived of life.
According to Stephania Negri, the debate around euthanasia has “essentially developed within the
framework of the universal rights to life and to human dignity”107. This leads us to the relationship
between end of life decisions and human dignity under the Indian Constitution. Dignity 74 Human
dignity has been “considered the unique universal value that inspires the major common bioethical
principles, and it is therefore considered the noyau dur of both international bio law and
international human rights 105 Article 359 106 Article 21 107 Stefania Negri, “Universal Human
Rights and End-of-Life Care” in S. Negri et al. (eds.), Advance Care Decision Making in Germany
and Italy: A Comparative, European and International Law Perspective, Springer (2013), at page 18
PART H law”108. Ronald Dworkin observes that “the notion of a right to dignity has been used in
many senses by moral and political philosophers”.109 75 The first idea considers dignity as the
foundation of human rights ¥ “that dignity relates to the intrinsic value of persons (such that it is
wrong to treat persons as mere things rather than as autonomous ends or agents)” 110. According to
this premise, every person, from conception to natural death, possesses inherent dignity:
“The sanctity of life view is often accompanied by a set of claims about human
dignity, namely, that human beings possess essential, underived, or intrinsic dignity.
That is, they possess dignity, or excellence, in virtue of the kind of being they are; and
this essential dignity can be used summarily to express why it is impermissible, for
example, intentionally to kill human beings: to do so is to act against their
dignity.”111 The other interpretation of dignity is by the supporters of euthanasia. 112
For them, right to lead a healthy life also includes leaving the world in a peaceful and
dignified manner. Living with dignity, in this view, means the right to live a
meaningful life having certain quality. This interpretation endorses the “quality of
life” proposition.
108 Ibid, at pages 21-22 109 Ronald Dworkin, Life's Dominion (London:
HarperCollins, 1993) as quoted in Deryck Beyleveld and Roger Brownsword, “Human
Dignity, Human Rights, and Human Genetics”, Modern Law Review (1998), Vol. 61,
at pages 665-666 110 Deryck Beyleveld and Roger Brownsword, “Human Dignity,
Human Rights, and Human Genetics”, Modern Law Review (1998), Vol. 61, at page
666 111 Christopher O. Tollefsen, “Capital Punishment, Sanctity of Life, and HumanCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Dignity”, Public Discourse (September 16, 2011), available at
http://www.thepublicdiscourse.com/2011/09/3985/ 112 Stefania Negri, “Ending Life
and Death” in A. den Exter (eds.), European Health Law, MAKLU Press (2017), at
page 241 PART H Dignity has thus been invoked in support of contradictory claims
and arguments. It could justify respect for life under the principle of the “sanctity of
life”, as well as the right to die in the name of the principle of “quality of life”. In
order to remove ambiguities in interpretation and application of the right to human
dignity, Negri has suggested that dignity should be given a minimum core of
interpretation:
“To be meaningful in the end-of-life discourse, and hence to avoid being invoked as
mere rhetoric, dignity should be considered as a substantive legal concept, at whose
basic minimum core is the legal guarantee assuring the protection of every human
being against degradation and humiliation. Besides this, as international and
national case law demonstrate, it can also play an important role as an interpretive
principle, assisting judges in the interpretation and application of other human
rights, such as the right to life and the right to respect for private life, both crucial in
the end-of-life debate.”113 (Emphasis supplied) Recognition of human dignity is an
important reason underlying the preservation of life. It has important consequences.
Is that dignity not compromised by pain and suffering and by the progressive loss of
bodily and mental functions with the imminence of the end of life? Dignity has
important consequences for life choices.
76 Morris, in his article, “Voluntary Euthanasia”, regards cruelty as a violation of human dignity:
113 Ibid PART H “All civilized men will agree that cruelty is an evil to be avoided. But
few people acknowledge the cruelty of our present laws which require a man be kept
alive against his will, while denying his pleas for merciful release after all the dignity,
beauty, promise and meaning of life have vanished, and he can only linger for weeks
or months in the last stages of agony, weakness and decay." In addition, the fact that
many people, as they die, are fully conscious of their tragic state of deterioration
greatly magnifies the cruelty inherent in forcing them to endure this loss of dignity
against their will.”114 He has further stated “it is exceedingly cruel to compel the
spouse and children of a dying man to witness the ever-worsening stages of his
disease, and to watch the slow, agonizing death of their loved one, degenerating
before their eyes, being transformed from a vital and robust parent and spouse into a
pathetic and humiliated creature, devoid of human dignity”.115
77 Liberty and autonomy promote the cause of human dignity. Arguments about autonomy are often
linked to human dignity. 116 Gostin evaluates the relationship between the dignity of dying with
autonomy thus:
“The dying process, after all, is the most intimate, private and fundamental of all
parts of life. It is the voice that we, as humans, assert in influencing this autonomousCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

part of our life. At the moment of our death, this right of autonomy ought not to be
taken from us simply because we are dying. An autonomous person should not be
required to have a good reason for the decision that he or she will make; that is the
nature of autonomy. We do not judge for other competent human beings what may
be in their best interest, but instead allow them to determine that for themselves. As
such, an autonomous person does not need to have a good understanding or even
good reasons. All they need is an 114 Arval A. Morris (Supra note 97), at pages
251-252 115 Ibid 116 Sebastian Muders, Autonomy and the Value of Life as Elements
of Human Dignity (Oxford University Press, 2017) PART H understanding of what
they are confronting. There is no reason to believe that when a person faces
imminent death that they have less human understanding, or less ability to fathom
what they will face, than other people. Of course, death is a mystery. But death is
what we will all confront sooner or later, and we all may wish to assert our interests
in how we may die.”117
78 Sumner in his work titled “Dignity through Thick and Thin”118 discusses the dignity associated
with patients:
“[P]atients associate dignity with concepts such as respect and esteem, presumably
including self-respect and self- esteem, whereas they experience its
opposite—indignity—as degrading, shameful, or embarrassing… Abstractly speaking,
a person’s dignity seems to be a matter of assurance of her fully human status, both
in her own eyes and in the eyes of others. Dignity is maintained when one can face
others with pride and with confidence of being worthy of their respect; it is lost or
impaired when being seen by others occasions feelings of shame, inferiority, or
embarrassment. The element of degradation that is implicated in indignity seems a
matter of feeling demoted or diminished from a higher standing to a lower, perhaps
from the status of a fully functioning person to something lesser.”119 While stating
that dignity and indignity are “basically subjective notions” 120 depending upon how
individual patients experience them, he has further stated:
“One condition that patients report as degrading— as an indignity—is loss of control
over the course of their own health care. Loss of autonomy matters in its own right,
but it matters even more if it is the source for patients of shame and humiliation. This
suggests that autonomy and well-being are themselves interconnected: Patients
typically experience a 117 Lawrence O. Gostin, “The Constitutional Right to Die:
Ethical Considerations”, St John's Journal of Legal Commentary (1997), Vol. 12, at
pages 602-603 118 LW Sumner, “Dignity through Thick and Thin”, in Sebastian
Muders, Human Dignity and Assisted Death (Oxford University Press, 2017) 119 Ibid,
at page 61 120 Ibid, at page 64 PART H loss of the former as a decline in the latter, as
something that makes their dying process go worse for them by causing them feelings
of indignity. Appeals to dignity thus flesh out what is at stake for patients in terms of
their autonomy and well-being, but they do not introduce any factors that fall outside
the limits of these values.”121Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

79 An article titled “Euthanasia: A Social Science Perspective”122 in the Economic & Political
Weekly has suggested that the discourses on death with dignity “need to be situated within
processes of living with dignity in everyday contexts”.123 The end of life must not be seen as “human
disposal”, but, as “the enhancement of human dignity by permitting each man's last act to be an
exercise of his free choice between a tortured, hideous death and a painless, dignified one.”124 80
Under our Constitution, the inherent value which sanctifies life is the dignity of existence.
Recognising human dignity is intrinsic to preserving the sanctity of life. Life is truly sanctified when
it is lived with dignity. There exists a close relationship between dignity and the quality of life. For, it
is only when life can be lived with a true sense of quality that the dignity of human existence is fully
realized. Hence, there should be no antagonism between the sanctity of human life on the one hand
and the dignity and quality of life on the other hand. Quality of life ensures dignity of living and
dignity is but a process in realizing the sanctity of life.
121 Ibid, at page 68 122 Aneeta A Minocha, Arima Mishra and Vivek R Minocha, “Euthanasia: A
Social Science Perspective”, Economic & Political Weekly (December 3, 2011), at pages 25-28 123
Ibid, at page 27 124 Arval A. Morris (Supra note 97), at page 247 PART H 81 Human dignity is an
essential element of a meaningful existence. A life of dignity comprehends all stages of living
including the final stage which leads to the end of life. Liberty and autonomy are essential attributes
of a life of substance. It is liberty which enables an individual to decide upon those matters which
are central to the pursuit of a meaningful existence. The expectation that the individual should not
be deprived of his or her dignity in the final stage of life gives expression to the central expectation
of a fading life: control over pain and suffering and the ability to determine the treatment which the
individual should receive. When society assures to each individual a protection against being
subjected to degrading treatment in the process of dying, it seeks to assure basic human dignity.
Dignity ensures the sanctity of life. The recognition afforded to the autonomy of the individual in
matters relating to end of life decisions is ultimately a step towards ensuring that life does not
despair of dignity as it ebbs away.
82 From Maneka Gandhi125 to Puttaswamy126, dignity is the element which binds the
constitutional quest for a meaningful existence. In Francis Coralie Mullin v Administrator, Union
Territory of Delhi127, this Court held that:
“The right to life enshrined in Article 21 cannot be restricted to mere animal
existence. It means something much more than just physical survival… 125 Maneka
Gandhi v Union of India, (1978) 1 SCC 248 126 Justice KS Puttaswamy (Retd.) v
Union of India, (2017) 10 SCC 1 127 (1981) 1 SCC 608 PART H We think that the right
to life includes the right to live with human dignity.” Explaining the ambit of dignity,
this Court further held that:
“[A]ny form of torture or cruel, inhuman or degrading treatment would be offensive
to human dignity and constitute an inroad into this right to live… [T]here is implicit
in Article 21 the right to protection against torture or cruel, inhuman or degrading
treatment which is enunciated in Article 5 of the Universal Declaration of Human
Rights and guaranteed by Article 7 of the International Covenant on Civil andCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Political Rights.” Dignity is the core value of life and personal liberty which infuses
every stage of human existence. Dignity in the process of dying as well as dignity in
death reflects a long yearning through the ages that the passage away from life should
be bereft of suffering. These individual yearnings are enhanced by the experiences of
sharing, observing and feeling with others: the loss of a parent, spouse, friend or an
acquaintance to the cycle of life. Dignity in death has a sense of realism that
permeates the right to life. It has a basic connect with the autonomy of the individual
and the right to self-determination. Loss of control over the body and the mind are
portents of the deprivation of liberty.
As the end of life approaches, a loss of control over human faculties denudes life of its
meaning. Terminal illness hastens the loss of faculties. Control over essential
decisions about how an individual should be treated at the end of life is hence an
essential attribute of the right to life. Corresponding to the right is a legitimate
expectation that the state must protect it and provide a just legal order in which the
right is not denied. In matters as fundamental as PART H death and the process of
dying, each individual is entitled to a reasonable expectation of the protection of his
or her autonomy by a legal order founded on the rule of law. A constitutional
expectation of providing dignity in death is protected by Article 21 and is enforceable
against the state.
Privacy
83 The nine-judge Bench decision of this Court in Justice K S Puttaswamy v Union of India128 held
privacy to be the constitutional core of human dignity. The right to privacy was held to be an
intrinsic part of the right to life and liberty under Article 21 and protected under Part III of the
Constitution. Each of the six decisions has a vital bearing on the issues in the present case. Excerpts
from the judgment are reproduced below:
Justice DY Chandrachud “The right to privacy is an element of human dignity. The
sanctity of privacy lies in its functional relationship with dignity. Privacy ensures that
a human being can lead a life of dignity by securing the inner recesses of the human
personality from unwanted intrusion. Privacy recognises the autonomy of the
individual and the right of every person to make essential choices which affect the
course of life. In doing so privacy recognises that living a life of dignity is essential for
a human being to fulfil the liberties and freedoms which are the cornerstone of the
Constitution.” Justice Chelameswar “Forced feeding of certain persons by the State
raises concerns of privacy. An individual’s right to refuse life prolonging medical
treatment or terminate his life is another freedom which falls within the zone of the
right of privacy.” 128 2017 (10) SCC 1 PART H Justice SA Bobde “Privacy, with which
we are here concerned, eminently qualifies as an inalienable natural right, intimately
connected to two values whose protection is a matter of universal moral agreement:
the innate dignity and autonomy of man… Both dignity and privacy are intimately
intertwined and are natural conditions for the birth and death of individuals, and forCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

many significant events in life between these events.” Justice RF Nariman “… a
Constitution has to be read in such a way that words deliver up principles that are to
be followed and if this is kept in mind, it is clear that the concept of privacy is
contained not merely in personal liberty, but also in the dignity of the individual.”
Justice AM Sapre “The incorporation of expression "Dignity of the individual" in the
Preamble was aimed essentially to show explicit repudiation of what people of this
Country had inherited from the past. Dignity of the individual was, therefore, always
considered the prime constituent of the fraternity, which assures the dignity to every
individual. Both expressions are interdependent and intertwined.” Justice SK Kaul “A
person-hood would be a protection of one’s personality, individuality and dignity.”
“Privacy, for example is nothing but a form of dignity, which itself is a subset of
liberty.”
84 The protective mantle of privacy covers certain decisions that fundamentally affect the human
life cycle.129 It protects the most personal and intimate decisions of individuals that affect their life
and development.130 Thus, 129 Richard Delgado, “Euthanasia Reconsidered-The Choice of Death
as an Aspect of the Right of Privacy”, Arizona Law Review (1975), Vol. 17, at page 474 130 Ibid PART
H choices and decisions on matters such as procreation, contraception and marriage have been held
to be protected. While death is an inevitable end in the trajectory of the cycle of human life of
individuals are often faced with choices and decisions relating to death. Decisions relating to death,
like those relating to birth, sex, and marriage, are protected by the Constitution by virtue of the right
of privacy. The right to privacy resides in the right to liberty and in the respect of autonomy.131 The
right to privacy protects autonomy in making decisions related to the intimate domain of death as
well as bodily integrity. Few moments could be of as much importance as the intimate and private
decisions that we are faced regarding death.132 Continuing treatment against the wishes of a patient
is not only a violation of the principle of informed consent, but also of bodily privacy and bodily
integrity that have been recognised as a facet of privacy by this Court. 85 Just as people value having
control over decisions during their lives such as where to live, which occupation to pursue, whom to
marry, and whether to have children, so people value having control over whether to continue living
when the quality of life deteriorates.133 131 TL Beauchamp, “The Right to Privacy and the Right to
Die”, Social Philosophy and Policy (2000), Vol. 17, at page 276 132 Ibid 133 D Benatar (Supra note
18) PART H 86 In the case of In re Quinlan (1976),134 the New Jersey Supreme Court dealt with a
case of a patient, Karen Quinlan, who had suffered irreversible brain damage and was in a persistent
vegetative state and had no prospect of recovery. The patient’s father sought judicial authority to
withdraw the life- sustaining mechanisms temporarily preserving his daughter’s life, and his
appointment as guardian of her person to that end. The father’s lawyer contended that the patient
was being forced to function against all natural impulses and that her right to make a private
decision about her fate superseded the state’s right to keep her alive. The New Jersey Supreme Court
held that the patient had a right of privacy grounded in the US Constitution to terminate treatment
and in a celebrated statement said that:
“the State's interest contra [the right to privacy] weakens and the individual's right to
privacy grows as the degree of bodily invasion increases and the prognosis dims.
Ultimately there comes a point at which the individual's rights overcome the StateCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

interest. It is for that reason that we believe [the patient's] choice, if she were
competent to make it, would be vindicated by law.” Since Karen Quinlan was not
competent to assert her right to privacy, the Court held that Karen's right of privacy
may be asserted on her behalf by her guardian due to the reason that Karen Quinlan
did not have the capacity to assert her right to privacy indicating that the right of
privacy is so fundamental that others, who had been intimately involved with the
patient, should be able to exercise it in circumstances when the patient is unable to
do so. However, 134 70 N.J. 10; 355 A.2d 647 (1976) PART H subsequently scholars
have argued that when euthanasia is founded in the right to privacy, only voluntary
euthanasia can be permitted. The right to privacy can only be exerted by the patient
and cannot be exercised vicariously.135 The substituted judgment and caregiver
criterion cannot be logically based on the right to privacy of the patient.136
87 In the landmark case of Pretty v United Kingdom137, the European Court of Human Rights
analysed Article 8 of the European Convention on Human Rights (respect for private life). It held
that the term “private life” is a broad term not susceptible to exhaustive definition and covers the
physical and psychological integrity of a person. In relation to the withdrawing of treatment, it was
held that the way in which an individual “chooses to pass the closing moments of her life is part of
the act of living, and she has a right to ask that this too must be respected.” The right to privacy
protects even those choices that may be considered harmful for the individual exercising the choice:
“The extent to which a State can use compulsory powers or the criminal law to
protect people from the consequences of their chosen lifestyle has long been a topic of
moral and jurisprudential discussion, the fact that the interference is often viewed as
trespassing on the private and personal sphere adding to the vigour of the debate.
However, even where the conduct poses a danger to health or, arguably, where it is of
a life-threatening nature, the case-law of the Convention institutions has regarded
the State's imposition of compulsory or criminal measures as impinging on the
private life of the applicant within the meaning of Article 8 § 1... In the sphere of
medical treatment, the refusal to accept a particular 135Peter J. Riga, "Privacy and
the Right to Die," The Catholic Lawyer (2017) Vol. 26: No. 2 , Article 2 136 Ibid PART
H treatment might, inevitably, lead to a fatal outcome, yet the imposition of medical
treatment, without the consent of a mentally competent adult patient, would interfere
with a person's physical integrity.” The Court further observed that:
“Without in any way negating the principle of sanctity of life protected under the
Convention, the Court considers that it is under Article 8 that notions of the quality
of life take on significance. In an era of growing medical sophistication combined
with longer life expectancies, many people are concerned that they should not be
forced to linger on in old age or in states of advanced physical or mental decrepitude
which conflict with strongly held ideas of self and personal identity.” Thus, the Court
concluded that the “choice to avoid what she considers will be an undignified and
distressing end to her life” is guaranteed under the right to respect for private life
under Article 8(1) of the Convention.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

88 Subsequently in the case of Haas v Switzerland138, the European Court of Human Rights has
further held that the right to decide in which way and at which time an individual’s life should end,
provided that he or she was in a position freely to form her own will and to act accordingly, was one
of the aspects of the right to respect for private life within the meaning of Article 8 of the
Convention.
89 The right to privacy as held by this Court mandates that we safeguard the integrity of individual
choice in the intimate sphere of decisions relating to 138 Application no. 31322/07, para 51 PART H
death, subject to the restrictions to the right to privacy, as laid down by us. However, since privacy is
not an absolute right and is subject to restrictions, the restrictions must fulfil the requirements as
laid down by this Court in Puttaswamy.
90 The protection of these rights by the legal order is as much an emanation of the right to privacy
which shares a functional relationship with the fundamental right to life and personal liberty
guaranteed by the Constitution. Privacy recognises that the body and mind are inviolable. An
essential attribute of this inviolability is the ability of the individual to refuse medical treatment.
Socio-Economic Concerns 91 One of the limitations of contemporary debates on euthanasia is that
they do not take into consideration “certain socio-economic concerns that must necessarily be
factored into any discourse”139. This has been criticised as making the debate around ending life
“incomplete” as well as “elitist”. 92 In an article titled “Euthanasia: cost factor is a worry”140 Nagral
(2011) seeks to construct a “critical linkage” between euthanasia and “the economic and social
dimension" in the Indian context. Stating that many Indian doctors 139 Sushila Rao (Supra note 16),
at page 654 140 S Nagral, “Euthanasia: Cost Factor is a Worry”, The Times of India (June 19, 2011),
available at
http://www.timesofindia.com/home/sunday/Euthanasia-cost-factor-is-a-worry/articleshow/7690155.cms
PART H have been practising passive euthanasia silently and practically, Nagral contemplates the
cost of treatment to be a critical factor in influencing the medical decision:
“[O]ne of the reasons for 'passive' euthanasia is that the patient or his family could be
running out of money. In some cases, this overlaps with the incurability of the
disease. In others, it may not. Costly medication and intervention is often withdrawn
as the first step of this passive euthanasia process. Sometimes patients are
'transferred' to smaller (read cheaper) institutions or even their homes, with the tacit
understanding that this will hasten the inevitable. If a third party is funding the
patient's treatment, chances are that the intervention and support will continue.
Shocking and arbitrary as this may sound, this is the reality that needs flagging
because it is relevant to the proposed legitimization of passive euthanasia. In a
system where out-of pocket payment is the norm and healthcare costs are booming,
there has to be a way of differentiating a plea made on genuine medical grounds from
one that might be an attempt to avoid financial ruin.”141 Rao (2011) has observed:
“In the absence of adequate medical insurance, specialised treatments like ventilator
support, kidney dialysis, and expensive lifesaving drugs administered in privateCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

hospitals can turn middle-class families into virtual paupers. Poorly equipped
government hospitals simply do not have enough life-support machines compared to
the number of patients who need them.... This also leads to the inevitable possibility
of a comatose patient’s family and relatives potentially exploiting the euthanasia law
to benefit from a premature death, by way of inheritance, etc.”142 Norrie (2011) has
placed the social and economic dimensions succinctly:
“This concerns the problem of the differential social impact that such a position
would have on the poor and the well-to-
141 Ibid 142 Sushila Rao (Supra note 16), at page 654-655 PART H do… Wealth, poverty, and class
structure have a profound effect on the choices people make.”143 The inadequacies of the range and
reach of Indian healthcare may, it is observed, lead to a situation where euthanasia/active
euthanasia may become “an instrument of cost containment”144. Restraints on Judicial Power 93
An earlier part of this judgment has dwelt on the criticism of the distinction between passive and
active euthanasia, founded as it is on the act – omission divide. The criticism is that as a matter of
substance, there is no valid distinguishing basis between active and passive euthanasia. The
criticism takes one of two forms: either both should be recognised or neither should be allowed. The
view that passive euthanasia involves an omission while active euthanasia involves a positive act is
questioned on the ground that the withdrawal of artificial life support (as an incident of passive
euthanasia) requires a positive act. While noticing this criticism, it is necessary to distinguish
between active and passive euthanasia in terms of the underlying constitutional principles as well as
in relation to the exercise of judicial power. Passive euthanasia – whether in the form of withholding
or withdrawing treatment – has the effect of removing, or as the case may be, not providing
supportive treatment. Its effect is to allow the individual to continue to exist until the end of 143
Alan Norrie (Supra note 4), at page 144 144 S Nagral, “Euthanasia: Cost Factor is a Worry”, The
Times of India (June 19, 2011), available at
http://www.timesofindia.com/home/sunday/Euthanasia-cost-factor-is-a-worry/articleshow/7690155.cms
PART H the natural span of life. On the other hand, active euthanasia involves hastening of death:
the life span of the individual is curtailed by a specific act designed to bring an end to life. Active
euthanasia would on the state of the penal law as it stands constitute an offence. Hence, it is only
Parliament which can in its legislative wisdom decide whether active euthanasia should be
permitted. Passive euthanasia on the other hand would not implicate a criminal offence since the
decision to withhold or withdraw artificial life support after taking into account the best interest of
the patient would not constitute an illegal omission prohibited by law.
94 Moreover, it is necessary to make a distinction between active and passive euthanasia in terms of
the incidents of judicial power. We may refer in this context to the felicitous words of Lord Justice
Sales, speaking for the Queen’s Bench Division in a recent decision delivered on 5 October 2017 in
Noel Douglas Conway v The Secretary of State for Justice145. Dealing with the plea that physician
assisted suicide should be accepted as a principle by the court, the learned Judge observed thus:
“Parliament is the body composed of representatives of the community at large with
what can be called a democratic mandate to make the relevant assessment in a caseCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

where there is an important element of social policy and moral value-judgment
involved with much to be said on both sides of the debate (229) and (233). There is
not a single, clear, uniquely rational solution which can be identified; the decision
cannot fail to be influenced by the decision-makers’ opinions about the moral case for
assisted suicide, including in deciding what level of risk to others is acceptable and
whether any safeguards are sufficiently robust; and it is not 145 (2017) EWHC 2447
(Admin) PART H appropriate for professional judges to impose their personal
opinions on matters of this kind (229)-(230) and (234). In Nicklinson in the Court of
Appeal, Lord Judge CJ aptly referred to Parliament as representing “the conscience
of the nation” for decisions which raise “profoundly sensitive questions about the
nature of our society, and its values and standards, on which passionate but
contradictory opinions are held” (Court of Appeal, (155). Parliament has made the
relevant decision; opponents of section 2 have thus far failed to persuade Parliament
to change the law despite active consideration given to the issue, in particular in
relation to the Falconer Bill which contained essentially the same proposals as Mr
Conway now puts before the court; and the democratic process would be liable to be
subverted if, on a question of moral and political judgment, opponents of the
legislation could achieve through the courts what they could not achieve in
Parliament (231) per Lord Sumption, referring to R (Countryside Alliance) v Attorney
General (2008) AC 719, (45) per Lord Bingham and AXA General Insurance Ltd v
HM Advocate (2012) 1 SC 868, (49) per Lord Hope)”.
Emphasising the limitations on the exercise of the judicial power, Lord Justice Sales observed:
“We also agree that his case on necessity becomes still stronger when the other
legitimate aims are brought into account. As the conscience of the nation, Parliament
was and is entitled to decide that the clarity of such a moral position could only be
achieved by means of such a rule. Although views about this vary in society, we think
that the legitimacy of Parliament deciding to maintain such a clear line that people
should not seek to intervene to hasten the death of a human is not open to serious
doubt. Parliament is entitled to make the assessment that it should protect moral
standards in society by issuing clear and unambiguous laws which reflect and
embody such standards”.
In taking the view which has been taken in the present judgment, the court has been
conscious of the need to preserve to Parliament, the area which properly belongs to
its legislative authority. Our view must hence be informed by the impact of existing
legislation on the field of debate in the present case.
                                                                                                                 PART ICommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

I          Penal Provisions
95         The legality of and constitutional protection which is afforded to passive
euthanasia cannot be read in isolation from the provisions of the Penal Code.
Physicians are apprehensive about their civil or criminal liability when called upon to
decide whether to limit life-supporting treatment.146 A decision on the constitutional
question cannot be rendered without analyzing the statutory context and the impact
of penal provisions. The decision in Aruna Shanbaug did not dwell on the provisions
of the Penal Code (apart from Sections 306 and 309) which have a vital bearing on
the issue of euthanasia. Undoubtedly, constitutional positions are not controlled by
statutory provisions, because the Constitution rises above and controls legislative
mandates. But, in the present reference where no statutory provision is called into
question, it is necessary for the court to analyse the relationship between what the
statute penalizes and what the Constitution protects. The task of interpretation is to
allow for their co-existence while interpreting the statute to give effect to
constitutional principle. This is particularly so in an area such as the present where
criminal law may bear a significant relationship to the fundamental constitutional
principles of liberty, dignity and autonomy.
The first aspect which needs to be noticed is that our law of crimes deals with acts
and omissions. Section 32 of the Penal Code places acts and omissions 146 S
Balakrishnan and RK Mani, “The constitutional and legal provisions in Indian law for
limiting life support”, Indian Journal of Critical Care Medicine (2005), Vol. 9, Issue
2, at page 108 PART I on the same plane. An illegal omission (unless a contrary
intent appears in the Code) is proscribed when the act is unlawful. Section 32 states:
“Words referring to acts include illegal omissions. — In every part of this Code,
except where a contrary intention appears from the context, words which refer to acts
done extend also to illegal omissions.” The language of the statute which refers to acts
applies, unless a contrary intent appears in the text, to omissions.
The next aspect is about when an act or omission is illegal. Section 43 explains the
concept of illegality. It provides thus:
““Illegal”. “Legally bound to do”. — The word “illegal” is applicable to everything
which is an offence or which is prohibited by law, or which furnishes ground for a
civil action; and a person is said to be “legally bound to do” whatever it is illegal in
him to omit.” Here again, being legally bound to do something is the mirror image of
what is illegal to omit doing.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Section 43 comprehends within the meaning of illegality, that (i) which is an offence;
or (ii) which is prohibited by law; or (iii) which furnishes a ground for a civil action.
Omissions and acts are mirror images. When it is unlawful to omit to do something,
the individual is legally bound to do it.
This raises the question of whether an omission to provide life-sustaining treatment
constitutes an illegal omission.
PART I Section 81 protects acts which are done without a criminal intent to cause
harm, in good faith, to prevent or avoid other harm to person or property. The law
protects the action though it was done with the knowledge that it was likely to cause
harm if a three-fold requirement is fulfilled. It comprehends an absence of criminal
intent to cause harm, the presence of good faith and the purpose of preventing other
harm. Section 81 provides thus:
“81. Act likely to cause harm, but done without criminal intent, and to prevent other
harm.—Nothing is an offence merely by reason of its being done with the knowledge
that it is likely to cause harm, if it be done without any criminal intention to cause
harm, and in good faith for the purpose of preventing or avoiding other harm to
person or property.
Explanation—It is question of fact in such a case whether the harm to be prevented or
avoided was of such a nature and so imminent as to justify or excuse the risk of doing
the act with the knowledge that it was likely to cause harm.” Knowledge of the
likelihood of harm is not culpable when a criminal intent to cause harm is absent and
there exists an element of good faith to prevent or avoid other harm.
Section 92 of the IPC states:
“Act done in good faith for benefit of a person without consent.—Nothing is an
offence by reason of any harm which it may cause to a person for whose benefit it is
done in good faith, even without that person's consent, if the circumstances are such
that it is impossible for that person to signify consent, or if that person is incapable of
giving consent, and has no guardian or other person in lawful charge of him from
whom it is possible to obtain consent in time for the thing to be done with benefit:
Provided— Provisos. First.—That this exception shall not extend to the intentional
causing of death, or the attempting to cause death” PART I Section 92 protects an
individual from a consequence which arises from the doing of an act for the benefit of
another in good faith, though a harm is caused to the other. What was done is
protected because it was done in good faith. Good faith is distinguished from an evil
design. When a person does something to protect another from a harm or injury, the
law protects what was done in good faith, treating the harm that may result as a
consequence unintended by the doer of the act. This protection is afforded by the law
even in the absence of consent when the circumstances are such that it is impossibleCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

for the person for whose benefit the act was done to consent to it.
This may arise where the imminence of the apprehended danger makes it impossible
to obtain consent. Another eventuality is where the individual is incapable of
consenting (by being incapacitated in mind) and there is no person in the position of
a guardian or person in lawful charge from whom consent can be obtained in time to
perform the act for the benefit of that person. However, the first proviso to Section 92
makes it clear that the exception does not extend to the intentional causing of death
or attempt to cause death to the individual, howsoever it may be for the benefit of the
other.
Absence of intent to cause death is the crucial element in the protection extended by
Section 92.
Section 107 deals with abetment. It provides thus:
“Abetment of a thing.—A person abets the doing of a thing, who— … (Thirdly) —
Intentionally aids, by any act or illegal omission, the doing of that thing.” PART I
Abetment embodies a three-fold requirement: first an intentional aiding, second the
aiding of an act or illegal omission and third, that this must be toward the doing of
that thing.
Explanation 2 of this Section states:
“Whoever, either prior to or at the time of the commission of an act, does anything in
order to facilitate the commission of that act, and thereby facilitates the commission
thereof, is said to aid the doing of that act.” 96 For abetting an offence, the person
abetting must have intentionally aided the commission of the crime. Abetment
requires an instigation to commit or intentionally aiding the commission of a crime.
It presupposes a course of conduct or action which (in the context of the present
discussion) facilitates another to end life. Hence abetment of suicide is an offence
expressly punishable under Sections 305 and 306 of the IPC.
97 It is now necessary to dwell upon the provisions bearing upon culpable homicide
and murder. Section 299 of the IPC states:
“Culpable homicide.—Whoever causes death by doing an act with the intention of
causing death, or with the intention of causing such bodily injury as is likely to cause
death, or with the knowledge that he is likely by such act to cause death, commits the
offence of culpable homicide.” Section 300 states:
“Murder.—Except in the cases hereinafter excepted, culpable homicide is murder, if
the act by which the death is caused is done with the intention of causing death, or—
PART I Secondly.—If it is done with the intention of causing such bodily injury as theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

offender knows to be likely to cause the death of the person to whom the harm is
caused, or— Thirdly.—If it is done with the intention of causing bodily injury to any
person and the bodily injury intended to be inflicted is sufficient in the ordinary
course of nature to cause death, or— Fourthly.—If the person committing the act
knows that it is so imminently dangerous that it must, in all probability, cause death,
or such bodily injury as is likely to cause death, and commits such act without any
excuse for incurring the risk of causing death or such injury as aforesaid.” Active
euthanasia involves an intention on the part of the doctor to cause the death of the
patient. Such cases fall under the first clause of Section 300.
Exception 5 to Section 300 states:
“Culpable homicide is not murder when the person whose death is caused, being
above the age of eighteen years, suffers death or takes the risk of death with his own
consent.” Section 304 provides:
“Whoever commits culpable homicide not amounting to murder, shall be punished
with [imprisonment for life], or imprisonment of either description for a term which
may extend to ten years, and shall also be liable to fine, if the act by which the death
is caused is done with the intention of causing death, or of causing such bodily injury
as is likely to cause death; or with imprisonment of either description for a term
which may extend to ten years, or with fine, or with both, if the act is done with the
knowledge that it is likely to cause death, but without any intention to cause death, or
to cause such bodily injury as is likely to cause death.” There also exists a distinction
between active and passive euthanasia. This is brought out in the application of the
doctrine of ‘double effect’. The Stanford Encyclopedia of Philosophy elucidates the
position thus:
PART I “The doctrine (or principle) of double effect is often invoked to explain the
permissibility of an action that causes a serious harm, such as the death of a human
being, as a side effect of promoting some good end. According to the principle of
double effect, sometimes it is permissible to cause a harm as a side effect (or “double
effect”) of bringing about a good result even though it would not be permissible to
cause such a harm as a means to bringing about the same good end.”147 It has been
observed further:
“A doctor who intends to hasten the death of a terminally ill patient by injecting a
large dose of morphine would act impermissibly because he intends to bring about
the patient's death. However, a doctor who intended to relieve the patient's pain with
that same dose and merely foresaw the hastening of the patient's death would act
permissibly.”148 98 A distinction arises between active and passive euthanasia from
the provisions of the Penal Code. Active euthanasia involves an intention to cause the
death of the patient. Mens rea requires a guilty mind; essentially an intent to cause
harm or injury. Passive euthanasia does not embody an intent to cause death. ACommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

doctor may withhold life support to ensure that the life of a patient who is in the
terminal stage of an incurable illness or in a permanent vegetative state, is not
prolonged artificially. The decision to do so is not founded upon an intent to cause
death but to allow the life of the patient to continue till and cease at the end of its
natural term. Placing such a person on life support would have been an intervention
in the natural process of death. A decision not to prolong life by artificial means does
not carry an intention to cause death. The crucial element in Section 299 is provided
by the expression 147 “Doctrine of Double Effect”, Stanford Encyclopedia of
Philosophy (July 28, 2004), available at
https://plato.stanford.edu/entries/double-effect/ 148 Ibid PART I “causes death”. In
a case involving passive euthanasia, the affliction of the patient is not brought about
either by an act or omission of the doctor. There is neither an animus nor an intent to
cause death. The creation of the condition of the patient is outside the volition of the
doctor and has come about without a covert or overt act by the doctor. The decision
to withhold medical intervention is not intended to cause death but to prevent pain,
suffering and indignity to a human being who is in the end stage of a terminal illness
or of a vegetative state with no reasonable prospect of cure. Placing a patient on
artificial life support would, in such a situation, merely prolong the agony of the
patient. Hence, a decision by the doctor based on what is in the best interest of the
patient precludes an intent to cause death. Similarly, withdrawal of artificial life
support is not motivated by an intent to cause death. What a withdrawal of life
support does is not to artificially prolong life. The end of life is brought about by the
inherent condition of the patient. Thus, both in a case of a withdrawal of life
supporting intervention and withholding it, the law protects a bona fide assessment
of a medical professional. There being no intent to cause death, the act does not
constitute either culpable homicide or murder.
Moreover, the doctor does not inflict a bodily injury. The condition of a patient is on account of a
factor independent of the doctor and is not an outcome of his or her actions. Death emanates from
the pre-existing medical condition of the patient which enables life to chart a natural course to its
inexorable end. The law protects a decision which has been made in good faith by a medical PART I
professional not to prolong the indignity of a life placed on artificial support in a situation where
medical knowledge indicates a point of no return. Neither the act nor the omission is done with the
knowledge that it is likely to cause death. This is for the reason that the likelihood of death is not
occasioned by the act or omission but by the medical condition of the patient. When a doctor takes a
considered decision in the case of a patient in a terminal stage of illness or in a permanently
vegetative state, not to provide artificial life support, the law does not attribute to the doctor the
knowledge that it is likely to cause death. 99 Section 43 of the Penal Code defines the expression
illegal to mean “…everything which is an offence or which is prohibited by law, or which furnishes
ground in a civil action”. Withdrawing life support to a person in a permanently vegetative state or
in a terminal stage of illness is not ‘prohibited by law’. Such an act would also not fall outside the
purview of Section 92 for the reason that there is no intentional causing of death or attempt to cause
death. Where a decision to withdraw artificial life support is made in the caregiver of the patient, it
fulfils the duty of care required from a doctor towards the patient. Where a doctor has acted inCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

fulfilment of a duty of care owed to the patient, the medical judgment underlying the decision
protects it from a charge of illegality. Such a decision is not founded on an intention to cause death
or on the knowledge that it is likely to cause death. An act done in pursuance of the duty of care
owed by the doctor to a patient is not prohibited by law.
PART I 100 In a situation where passive euthanasia is non-voluntary, there is an additional
protection which is also available in circumstances which give rise to the application of Section 92.
Where an act is done for the benefit of another in good faith, the law protects the individual. It does
so even in the absence of the consent of the other, if the other individual is in a situation where it is
impossible to signify consent or is incapable of giving consent. Section 92 also recognises that there
may be no guardian or other person in lawful charge from whom it is possible to obtain consent.
However, the proviso to Section 92 stipulates that this exception shall not extend to intentionally
causing death or attempting to cause death. The intent in passive euthanasia is not to cause death. A
decision not to prolong life beyond its natural span by withholding or withdrawing artificial life
support or medical intervention cannot be equated with an intent to cause death. The element of
good faith, coupled with an objective assessment of the caregiver of the patient would protect the
medical professional in a situation where a bona fide decision has been taken not to prolong the
agony of a human being in a terminal or vegetative state by a futile medical intervention.
101 In 2006, the Law Commission of India submitted its 196th Report titled “Medical Treatment to
Terminally Ill Patients (Protection of Patients and Medical Practitioners)”. The report by Justice M
Jagannadha Rao as Chairperson contains a succinct elucidation of legal principles governing
criminal law on the subject. Some of them are explained below:
PART I
(i) An informed decision of a patient to refuse medical treatment is accepted at
common law and is binding on a treating doctor. While a doctor has a duty of care, a
doctor who obeys the instructions of a competent patient to withhold or withdraw
medical treatment does not commit a breach of professional duty and the omission to
treat will not be an offence;
(ii) The decision of a patient to allow nature to take its course over the human body
and, in consequence, not to be subjected to medical intervention, does not amount to
a deliberate termination of physical existence. Allowing nature to take its course and
a decision to not receive medical treatment does not constitute an attempt to commit
suicide within the meaning of Section 309 of the Penal Code;
(iii) Once a competent patient has decided not to accept medical intervention, and to
allow nature to take its course, the action of the treating doctor in abiding by those
wishes is not an offence, nor would it amount to an abetment under Section 306.
Under Section 107, an omission has to be illegal to constitute an abetment. A doctor
bound by the instructions of a patient to withhold or withdraw medical treatment is
not guilty of an illegal act or an abetment. The doctor is bound by the decision of theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

patient to refuse medical intervention;
PART I
(iv) A doctor who withholds or withdraws medical treatment in the best interest of a patient, such as
when a patient is in a permanent vegetative state or in a terminal state of an incurable illness, is not
guilty under Section 299 because there is no intention to cause death or bodily injury which is likely
to cause death. The act of withholding or withdrawing a life support system in the case of a
competent patient who has refused medical treatment and, in the case of an incompetent person
where the action is in the best interest of the patient would be protected by good faith protections
available under Sections 76, 79, 81 or, as the case may be, by Section 88, even if it is construed that
the doctor had knowledge of the likelihood of death; and
(v) The decision of the doctor, who is under a duty at common law to obey the refusal of a competent
patient to take medical treatment, would not constitute a culpable act of negligence under Section
304A. When the doctor has taken such a decision to withhold or withdraw treatment in the best
interest of the patient, the decision would not constitute an act of gross negligence punishable under
Section 304A. 102 Introducing a structural safeguard, in the form of a Medical Board of experts can
be contemplated to further such an objective. The Transplantation of Human Organs and Tissues
Act 1994 provides for the constitution of Authorisation Committees under Section 9(4).
Authorisation Committees are PART J contemplated at the state and district levels and a hospital
board. 149 Once the process of decision making has been arrived at by fulfilling a mandated
safeguard (the prior approval of a committee), the decision to withdraw life support should not
constitute an illegal act or omission. The setting up of a broad-based board is precisely with a view
to lend assurance that the duty of care owed by the doctor to the patient has been fulfilled. Once due
safeguards have been fulfilled, the doctor is protected against the attribution of a culpable intent or
knowledge. It will hence fall outside the definition of culpable homicide (Section 299), murder
(Section 300) or causing death by a rash or negligent act (Section 304A). The composition of this
broad-based committee has been dealt with in the last segment of this judgment.
J          Advance Directives
103        A patient, in a sound state of mind, possesses the ability to make
decisions and choices and can legitimately refuse medical intervention. Justice Cardozo had this to
say in a seminal statement of principle in the 1914 decision in Schloendorff v Society of NY
Hospital150:
“Even human being of adult years and sound mind has a right to determine what
shall be done with his own body; and a surgeon who performs an operation without
his patient’s consent commits an assault.” 149 Rule 6A, Transplantation of Human
Organs and Tissues Act 1995 150 105 N.E. 92, 93 (N.Y. 1914) PART J Luis Kutner
gave expression to the relationship of privacy with the inviolability of the person and
the refusal of medical treatment:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

“…The attitude of the law is to recognise the inviolability of the human body. The
patient’s consent must be voluntary and informed. These notions are buttressed by
the constitutionally recognized right to privacy. Clearly, then, a patient may refuse
treatment which would extend his life. Such a decision must rest with the patient.”151
The difficulty, as Kutner notes, arises when a patient is unconscious or is not in a
position to furnish his or her consent. The author notes that in such a case “the law
assumes a constructive consent to such treatment as will save his life”. Kutner’s thesis
contemplates what should happen, if the patient is incapable of giving consent:
“…The law, however, does recognize that a patient has a right to refuse to be treated,
even when he is in extremis, provided he is in an adult and capable of giving consent.
Compliance with the patient’s wishes in such circumstances is not the same as
voluntary euthanasia. Where, however, the patient is incapable of giving consent,
such as when he is in a coma, a constructive consent is presumed and the doctor is
required to exercise reasonable care in applying ordinary means to preserve the
patient’s life. However, he is not allowed to resort to extraordinary care especially
where the patient is not expected to recover from the comatose state…” 104
Recognition of the right to accept or refuse medical treatment is founded upon
autonomy. The Stanford Encyclopaedia of Philosophy152 postulates that there is “a
rough consensus in medical ethics on the requirement of respect for patient
autonomy”. However, a patient may not 151 Luis Kutner, “Due Process of Euthanasia:
The Living Will, a proposal”, Indiana Law Journal (1969), Vol. 44, Issue 4, at page
539 152 “Advance Directives and Substitute Decision-Making”, Stanford
Encyclopaedia of Philosophy (24 March 2009), available at
https://plato.standford.edu/entries/advance-directives/ PART J always have the
opportunity to grant or withhold consent to medical treatment. An unforeseen event
may deprive the individual of the ability to indicate a desire to either receive or not to
have medical treatment. An occasion necessitating treatment in sudden cases where a
person suffers an accident, a stroke or coronary153 episode may provide no time for
reflection. In anticipation of such situations, “where an individual patient has no
desire to be kept in a state of complete and indefinite vegetated animation with no
possibility of recovering his mental and physical faculties, that individual, while still
in control of all his/her faculties and his ability to express himself/herself”154, could
still retain the right to refuse medical treatment by way of “advance directives”.
105 Broadly, there are two forms of advance directives:
- A Living Will which indicates a person’s views and wishes regarding medical
treatment
- A Durable Power of Attorney for Health Care or Health care Proxy which authorises
a surrogate decision maker to make medical care decisions for the patient in the
event she or he is incapacitated Although there can be an overlap between these two
forms of advance directives, the focus of a durable power is on who makes theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

decision while 153 Luis Kutner (Supra note 151), at page 551 154 Luis Kutner (Supra
note 65) at page 226 PART J the focus of a living will is on what the decision should
be. A “living will" has also been referred as "a declaration determining the
termination of life,"
"testament permitting death," "declaration for bodily autonomy," "declaration for
ending treatment," "body trust," or other similar reference.155 Living wills are not a
new entity and were first suggested by US attorney, Luis Kutner, in late 1960s.156
106 Advance directives have evolved conceptually to deal with cases where a patient who
subsequently faces a loss of the mental faculty to decide has left instructions, when he or she was
possessed of decision-making capacity, on how future medical decisions should be made. The
Stanford Encyclopaedia157 explains the concept thus:
“… For patients who lack the relevant decision-making capacity at the time the
decision is to be made, a need arises for surrogate decision-making: someone else
must be entrusted to decide on their behalf. Patients who formerly possessed the
relevant decision-making capacity might have anticipated the loss of capacity and left
instructions for how future medical decisions ought to be made. Such instructions are
called an advance directive. One type of advance directive simply designates who the
surrogate decision-maker should be. A more substantive advance directive, often
called a living will, specifies particular principles or considerations meant to guide
the surrogate’s decisions in various circumstances…” Hazel Biggs158 explains the
meaning of “living wills” and advance directives:
“Usually a living will is thought of as a statement indicating a person’s preferred
treatment options at the end of life, but the term “living will” is also “sometimes used
for advance 155 Luis Kutner (Supra note 151), at page 551 156 Ibid 157 “Advance
Directives and Substitute Decision-Making”, Stanford Encyclopaedia of Philosophy
(24 March 2009), available at
https://plato.standford.edu/entries/advance-directives/ 158 Hazel Biggs (Supra note
21), at page 115 PART J directives which are concerned with other situations or which
can be used to express a willingness to receive particular treatments”. Some stipulate
that speciﬁc treatments are acceptable while others are not, while others insist that
all available appropriate medical resources should be utilised to maintain life. Living
wills are not therefore exclusively associated with end-of-life decisions, although
generally the purpose of a living will is to promote individual autonomy and choice
for the patient; characteristics which have long been associated with euthanasia as a
means of achieving death with dignity”.
James C Turner159 explains the concept of a living will thus:
“The living will is a document by which a competent adult signifies a desire that if
there ever comes a time when there is no reasonable expectation of his recovery fromCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

physical or mental disability that he be allowed to die rather than be kept alive by
artificial means or heroic measures. What the typical living will does, in effect, is to
sanction passive euthanasia, or, as it has been called, antidysthanasia.. The living will
is a document which directs one’s physician to cease affirmative treatment under
certain specified conditions. It can presumably apply to both the situation in which a
person with a terminal disease lapses into the final stage of his illness and also the
situation in which a victim of a serious accident deteriorates into a state of indefinite
vegetated animation…”
107 The principles of patient autonomy and consent are the foundation of advance medical
directives. A competent and consenting adult is entitled to refuse medical treatment. By the same
postulate, a decision by a competent adult will be valid in respect of medical treatment in future. As
Biggs states:
“…Founded upon respect for individual autonomy this is a right that operates
through the law of consent to protect patients from unfettered medical paternalism.
Common law holds that patients with the capacity to give consent are also competent
to refuse or withhold consent, “even if a refusal may risk personal injury to health or
even lead to premature death”. Furthermore, a “refusal of treatment can take the
form 159 James C Turner, “Living Wills – Need for legal recognition”, West Virginia
Law Review (1976), Vo. 78, Issue 3, at page 370 PART J of a declaration of intent
never to consent to that treatment in the future, or never to consent in some future
circumstances”.
Accordingly, any consent or refusal of consent made by a competent adult patient can also be valid
in respect of the same treatment at any time in the future.” 108 Advance directives are thus
documents a person completes while still in possession of decisional capacity about how treatment
decisions should be made in the event she or he loses decision making capacity in future. They cover
three conditions: (i) a terminal condition; (ii) a persistently unconscious condition; and (iii) an
end-stage condition. 109 A terminal condition is an incurable or irreversible condition which even
with the administration of life-sustaining treatment will result in death in the foreseeable future. A
persistently unconscious condition is an irreversible condition, in which thought and awareness of
self and environment are absent. An end-stage condition is a condition caused by injury, disease or
illness which results in severe and permanent deterioration indicated by incompetency and
complete physical dependency for which treatment of the irreversible condition would be medically
ineffective. 110 The reason for recognising an advance directive is based on individual autonomy. As
an autonomous person, every individual has a constitutionally recognised right to refuse medical
treatment. The right not to accept medical treatment is essential to liberty. Medical treatment
cannot be thrust upon an PART J individual, however, it may have been conceived in the interest of
the individual. The reasons which may lead a person in a sound state of mind to refuse medical
treatment are inscrutable. Those decisions are not subject to scrutiny and have to be respected by
the law as an essential attribute of the right of the individual to have control over the body. The state
cannot compel an unwilling individual to receive medical treatment. While an individual cannot
compel a medical professional to provide a particular treatment (this being in the realm ofCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

professional medical judgment), it is equally true that the individual cannot be compelled to
undergo medical intervention. The principle of sanctity of life thus recognises the fundamental
liberty of every person to control his or her body and as its incident, to decline medical treatment.
The ability to take such a decision is an essential element of the privacy of the being. Privacy also
ensures that a decision as personal as whether or not to accept medical treatment lies exclusively
with the individual as an autonomous being. The reasons which impel an individual to do so are part
of the privacy of the individual. The mental processes which lead to decision making are equally part
of the constitutionally protected right to privacy. 111 Advance directives are founded on the principle
that an individual whose state of mind is not clouded by an affliction which prevents him or her
from taking decisions is entitled to decide whether to accept or not accept medical intervention. If a
decision can be made for the present, when the individual is in a sound state of mind, such a person
should be allowed to decide the course of PART J action which should be followed in the future if he
or she were to be in a situation which affects the ability to take decisions. If a decision on whether or
not to receive medical treatment is valid for the present such a decision must be equally valid when
it is intended to operate in the future. Advance directives are, in other words, grounded in a
recognition by the law of the importance of consent as an essential attribute of personal liberty. It is
the consensual nature of the act underlying the advance directive which imparts sanctity to it in
future in the same manner as a decision in the present on whether or not to accept medical
treatment.
112 When a patient is brought for medical treatment in a state of mind in which he or she is deprived
of the mental capacity to make informed choices, the medical professional needs to determine the
line of treatment. One line of enquiry, which seeks to protect patient autonomy is how the individual
would have made a decision if he or she had decision-making capacity. This is called the substituted
judgment standard. An advance medical directive is construed as a facilitative mechanism in the
application of the substituted judgment standard, if it provides to the physician a communication by
the patient (when she or he was in a fit state of mind) of the desire for or restraint on being provided
medical treatment in future. 113 Conceptually, there is a second standard, which is the caregiver
standard. This is founded on the principle of beneficence. The second PART J standard seeks to
apply an objective notion of a line of treatment which a reasonable individual would desire in the
circumstances. The Stanford Encyclopaedia contains an elucidation of these two standards:
“The Substituted Judgment standard:
The surrogate’s task is to reconstruct what the patient himself would have wanted, in
the circumstances at hand, if the patient had decision-making capacity. Substantive
advance directives are here thought of as a helpful mechanism for aiding the
application of Substituted Judgment. The moral principle underlying this legal
standard is the principle of respect for autonomy, supplemented by the idea that
when a patient is not currently capable of making a decision for himself, we can
nonetheless respect his autonomy by following or reconstructing, as best we can, the
autonomous decision he would have made if he were able. In a subset of cases, a
substituted judgment can implement an actual earlier decision of the patient, made
in anticipation of the current circumstances; this is known as precedent autonomy.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

The Caregiver standard:
The surrogate is to decide based on what, in general, would be good for the patient.
The moral principle underlying this standard is the principle of beneficence. This
legal standard has traditionally assumed a quite generic view of interests, asking
what a “reasonable” person would want under the circumstances and focusing on
general goods such as freedom from pain, comfort, restoration and/or development
of the patient’s physical and mental capacities. This is because the Caregiver standard
has mainly been employed when there is little or no information about the patient’s
specific values and preferences. However, the concept of caregiver is simply the
concept of what is best for the person. There is no reason why, in principle, the
Caregiver judgment could not be as nuanced and individual as the best theory of
well-being dictates.” The difference between these two standards is that the first
seeks to reconstruct the subjective point of view of the patient. The second allows for
“a more generic view of interests”, without having to rely on the “idiosyncratic values
and preference of the patient in question”.
PART J
114 The Encyclopaedia explains that the “orthodox view” contained the following ordering of
priorities:
“1. Honour a substantive advance directive, as an aid to Substituted Judgment,
whenever such directive is available.
2. Absent an advance directive, apply the Substituted Judgment standard based on
available information about the patient’s past decisions and values.
3. If you cannot apply the Substituted Judgment standard – either because the
patient has never been competent or because information about the patient’s former
wishes and values is unavailable – use the Caregiver standard.” The above ordering of
priorities in the orthodox view has been questioned. In prioritising advance directives
and substituted judgments, the orthodox view “overlooks the possibility that the
earlier competent self and the current incompetent self may have conflicting
interests”. Advance directives and the substituted judgment standard were
propounded to deal with afflictions such as a persistent vegetative state where the
interests of the patient in such a state are not potentially different from what they
used to be. The Stanford Encyclopaedia, however, notes that a loss of
decision-making capacity may give rise to less drastic conditions in which the
presently incompetent patient may have developed “powerful new interests” in a new
phase of life. Patients facing Alzheimer’s or dementia face progressive mental
deterioration. When such a patient was still in a competent state of mind, she may
have regarded a state of dementia to be degrading. However, as the disease
progresses, the interests of the patient change and her life may be enriched by theCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

simple activities of life. The patient may cease to identify with his or her intellect and
revisit an earlier desire not to prolong life. The Stanford Encyclopaedia states PART J
that in such an eventuality, “the conflict is between the autonomy of the earlier self
and the well-being of the current self”.
115 One way of seeking a philosophical resolution is to postulate that the former self and its interests
will have priority, or a “special authority” over the current self. Such an approach prioritises
autonomy over beneficence. This line of approach is, however, not free of difficulty. A patient may
have lost the ability to take complex decisions. Yet the treating physician may not have “a license to
discount the current well-being of the individual in favour of what mattered to him earlier”. This
illustration emphasises the potential conflict between a pure application of the substituted judgment
standard and the caregiver standard. The former seeks to preserve individual autonomy at all costs.
The latter juxtaposes the role of the medical professional in determining what is in the best interest
of the patient. The best interest standard is hence founded on the principle that a patient who has
progressed from a competent mental state to an increasing lack of mental capacity faces a change of
personal identity. An autonomous decision suited to an earlier identity may not always be a valid
rationale for determining the course of action in respect of a new identity which a patient acquires in
the course of illness:
“According to the threshold views, the earlier self has authority to determine the
overall interests of the patient because the current self has lost crucial abilities that
would allow it to ground these overall interests anew. This picture assumes that the
earlier and current self are stages in the life of one entity, so that, despite the talk of
local interests associated with each life-stage, there is an underlying continuity of
interests between the two. But this is a very substantial assumption, and it has been
contested by appeal PART J to an influential account of the metaphysics of personal
identity over time, the psychological continuity account. Roughly, the idea is that, in
the wake of a drastic transformation of one’s psychology such as Alzheimer’s disease,
one does not survive as numerically the same individual, so whatever interests one’s
predecessor in one’s body may have had are not a suitable basis for decisions on
behalf of the new individual who has emerged after the transformation (Dresser
1986). The lack of identity between the earlier and current self undercuts the
authority of the former over the latter.”
116 In such a situation the doctor’s duty to care assumes significance. The relationship between a
doctor and her patient with an evolving mental condition needs a balance between the desires of the
patient in a different mental state and the needs of the patient in the present condition. Neither can
be ignored in preference to the other. The first recognises the patient as an autonomous individual
whose desires and choices must be respected by law and medicine. The desire not to be subject to
endless medical intervention, when one’s condition of mind or body have reached an irreversible
state is a profound reflection of the value to be left alone. Constitutional jurisprudence protects it as
part of the right to privacy. On the other hand, the need to procure the dignity of the individual in a
deteriorating and irreversible state of body or mind is as crucial to the value of existence. The doctor
must respect the former while being committed as a professional to protect the latter. 117 HumanCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

experience suggests that there is a chasm of imponderables which divide the present from the
future. Such a divide may have a bearing on whether and if so, the extent to which an advance
directive should bind in the PART J future. As stated above, the sanctity of an advance directive is
founded upon the expression of the will of an individual who is in a sound state of mind when the
directive is executed. Underlying the consensual character of the declaration is the notion of the
consent being informed. Undoubtedly, the reasons which have weighed with an individual in
executing the advance directive cannot be scrutinized (in the absence of situations such as fraud or
coercion which implicate the very basis of the consent). However, an individual who expresses the
desire not to be subjected to a particular line of treatment in the future, should she or he be ailing in
the future, does so on an assessment of treatment options available when the directive is executed.
For instance, a decision not to accept chemotherapy in the event that the individual is detected with
cancer in the future, is based on today’s perception of the trauma that may be suffered by the patient
through that treatment. Advances in medical knowledge between the date of the execution of the
document and an uncertain future date when the individual may possibly confront treatment for the
disease may have led to a re-evaluation by the person of the basis on which a desire was expressed
several years earlier. Another fundamental issue is whether the individual can by means of an
advance directive compel the withholding of basic care such as hydration and nourishment in the
future. Protecting the individual from pain and suffering as well as the indignity of debility may
similarly raise important issues. Advance directives may hence conceivably raise ethical issues of the
extent to which the perception of the individual who executes it must prevail in priority to the best
interest of the patient. PART J 118 The substituted judgment standard basically seeks to determine
what the individual would have decided. This gives primacy to the autonomy of the individual. On
the other hand, as seen earlier, the best interest standard is based on the principle of beneficence.
There is an evident tension between these two standards. What an individual would decide as an
autonomous entity is a matter of subjective perception. What is in the best interest of the patient is
an objective standard: objective, with the limitation that even experts differ. The importance of an
advance directive lies in bringing to the fore the primacy of individual choice. Such a directive
ensures that the individual retains control over the manner in which the body is treated. It allows
the individual to decide not to accept artificial treatment which would prolong life in the terminal
stage of an ailment or in a vegetative state. In doing so, recognition is granted to the effect of the
advance directive upon the happening of a contingency in the future, just as the individual would in
the present have a right to refuse medical treatment. The advance directive is an indicator to
medical professionals of the underlying desire of the person executing it. 119 In a society such as
ours where family ties have an important place in social existence, advance directives also provide a
sense of solace to the family. Decisions such as whether to withhold or withdraw artificial life saving
treatment are difficult for families to take. Advance directives provide moral authority for the family
of the patient that the decision which has been taken to withdraw or withhold artificial life support
is in accord with the stated desire of PART J the patient expressed earlier. But the ethical concerns
which have been referred to earlier may warrant a nuanced application of the principle. The
circumstances which have been adverted to earlier indicate that the decision on whether to withhold
or withdraw medical treatment should be left to a competent body comprising of, but not restricted
to medical professionals. Assigning a supervisory role to such a body is also necessary in order to
protect against the possibility of abuse and the dangers surrounding the misuse of an advance
directive. One cannot be unmindful of prevailing social reality in the country. Hence, it is necessaryCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

to ensure that an advance directive is not utilized as a subterfuge to fulfil unlawful or unethical
purposes such as facilitating a succession to property.
120 The view which this judgment puts forth is that the recognition of advance directives as part of a
regime of constitutional jurisprudence is an essential attribute of the right to life and personal
liberty under Article 21. That right comprehends dignity as its essential foundation. Quality of life is
integral to dignity. As an essential aspect of dignity and the preservation of autonomy of choice and
decision-making, each individual must have the right on whether or not to accept medical
intervention. Such a choice expressed at a point in time when the individual is in a sound and
competent state of mind should have sanctity in the future if the individual were to cease to have the
mental capability to take decisions and make choices. Yet, a balance between the application of the
substituted judgment standard and the best interest standard is necessary PART J as a matter of
public interest. This can be achieved by allowing a supervisory role to an expert body with whom
shall rest oversight in regard to whether a patient in the terminal stage of an illness or in a
permanent vegetative state should be withheld or withdrawn from artificial life support. 121 In 1995,
the British Medical Association (BMA) published a report on advance statements about medical
treatment with the intention to reflect “good clinical practice in encouraging dialogue about
individuals’ wishes concerning their future treatment”.160 The report theoretically discussed six
different types of advance statements161:
• A requesting statement reflecting an individual's aspirations and preferences • A
statement of general beliefs and aspects of life that the individual values • A
statement naming a proxy • A directive giving clear instructions refusing some or all
treatment(s) • A statement specifying a degree of irreversible deterioration after
which no life-sustaining treatment should be given • A combination of the above
122 A decade later, the Mental Capacity Act (MCA), 2005 was enacted, which came into force in
October 2007. The statute “enabled individuals to write an advance directive or appoint a lasting
power of attorney to make their 160 A S Kessel and J Meran, “Advance directives in the UK: legal,
ethical, and practical considerations for doctors”, British Journal of General Practice (1998), at page
1263 161 Ibid PART J views on health care known should they lose capacity” 162. The Act enshrined
in statute law the right of an adult with capacity to make an advance directive to refuse specific
treatment at a point in the future when they lack capacity. 123 Before turning to MCA, it is of
importance to state the position of the common law before the enactment of the legislation. English
Law has recognised the entitlement of an individual possessed of the ability to take decisions to
refuse medical treatment163. The law has had to confront problems in applying this standard in
difficult, practical situations. For instance, in a judgment in Re B (Adult: Refusal of Medical
Treatment)164, a patient who was suffering from tetraplegia declined to consent to artificial
ventilation. Though the patient was found initially to suffer from depression and to lack decision
making capacity, subsequent evaluation found that she was mentally competent. For a period of
nine months, the hospital refused to respect the wishes of the patient not to place her on artificial
ventilation, necessitating judicial intervention. When the case travelled to court, the President of the
Family Division, Dame Butler-Sloss emphasised that “the right of the patient to demand cessation of
treatment must prevail “over the natural desire of the medical and nursing professions to try to keepCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

her alive”. The Judge recognised the serious danger of “a benevolent paternalism which 162 “Are
advance directives legally binding or simply the starting point for discussion on patients’ best
interests?”, BMJ (28 November 2009), Volume 339, page 1231 163 Re T (Adult: Refusal of
Treatment) [1942] 4 All ER 649; Re C (Adult: Refusal of Medical Treatment)[1994] 1 All ER 819; St
George’s Healthcare NHS Trust v S [1998] 3 WLR 936 164 [2002] 2 All ER 449 PART J does not
embrace recognition of the personal autonomy of the severely disabled patient”.
124 Commenting on the above decision, Elizabeth Wicks in her recently published book titled “The
State and The Body – Legal Regulation of Bodily Autonomy”165 observes that:
“… the desire to preserve life is strong and choices to end life, especially in
circumstances where the life is not without an element of quality, are often seen as
swimming against a strong tide of the value of life.”
125 In Re AK (Adult Patient) (Medical Treatment: Consent)166, Justice Hughes (as he then was) in
the High Court of Justice, reviewed the authorities, and summarised the common law position thus:
“Accordingly, the first principle of law which I am satisfied is completely clear, is that
in the case of an adult patient of full capacity his refusal to consent to treatment or
care must in law be observed. It is clear that in an emergency a doctor is entitled in
law to treat by invasive means if necessary a patient who by reason of the emergency
is unable to consent, on the grounds that the consent can in those circumstances be
assumed. It is, however, also clearly the law that the doctors are not entitled so to act
if it is known that the patient, provided he was of sound mind and full capacity, has
let it be known that he does not consent and that such treatment is against his
wishes. To this extent an advance indication of the wishes of a patient of full capacity
and sound mind are effective. Care will of course have to be taken to ensure that such
anticipatory declarations of wishes still represent the wishes of the patient. Care must
be taken to investigate how long ago the expression of wishes was made. Care must
be taken to investigate with what knowledge the expression of wishes was made. All
the circumstances in which the expression of wishes was given will of course have to
be investigated.” 165 Elizabeth Wicks, The State and the Body: Legal Regulation of
Bodily Autonomy, Hart Publishing (2016) 166 [2001] 1 FLR 129 PART J In HE v A
Hospital NHS Trust167, Justice Munby of the High Court of Justice (Family Division)
considered an “Advance Medical Directive/Release” signed by a young woman, which
sought to refuse the transfusion of blood or primary blood components in absolute
and irrevocable terms. The Court had to decide whether the advance directive was
valid and applicable. It was noted that:
“A competent adult patient has an absolute right to refuse consent to any medical
treatment or invasive procedure, whether the reasons are rational, irrational,
unknown or non- existent, and even if the result of refusal is the certainty of death…
Consistently with this, a competent adult patient's anticipatory refusal of consent (a
so-called ‘advance directive’ or ‘living will’) remains binding and effectiveCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

notwithstanding that the patient has subsequently become and remains incompetent.
An adult is presumed to have capacity, so the burden of proof is on those who seek to
rebut the presumption and who assert a lack of capacity. It is therefore for those who
assert that an adult was not competent at the time he made his advance directive to
prove that fact.” The Court then analyzed the specific aspects of the law governing
advance directives:
“1. There are no formal requirements for a valid advance directive. An advance
directive need not be either in or evidenced by writing. An advance directive may be
oral or in writing.
2. There are no formal requirements for the revocation of an advance directive. An
advance directive, whether oral or in writing, may be revoked either orally or in
writing. A written advance directive or an advance directive executed under seal can
be revoked orally.
3. An advance directive is inherently revocable. Any condition in an advance directive
purporting to make it irrevocable, any even self-imposed fetter on a patient’s ability
to revoke an advance directive, and any provision in an advance directive purporting
to impose formal or other conditions upon its revocation, is contrary to public policy
and void. So, a 167 [2003] 2 FLR 408 PART J stipulation in an advance directive,
even if in writing, that it shall be binding unless and until revoked in writing is void
as being contrary to public policy.
4. The existence and continuing validity and applicability of an advance directive is a
question of fact. Whether an advance directive has been revoked or has for some
other reason ceased to be operative is a question of fact.
5. The burden of proof is on those who seek to establish the existence and continuing
validity and applicability of an advance directive.
6. Where life is at stake the evidence must be scrutinised with especial care. Clear and
convincing proof is required. The continuing validity and applicability of the advance
directive must be clearly established by convincing and inherently reliable evidence.
7. If there is doubt that doubt falls to be resolved in favour of the preservation of life.”
126 The common law has been “refined” by passage of the MCA 2005, which makes statutory
provision for advance decisions to refuse treatment. 168 The Mental Capacity Act has certain
underlying principles 169, which can be stated as follows:
• A person must be assumed to have capacity unless it is established that she lacks
capacity.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

• A person is not to be treated as unable to make a decision unless all practicable
steps to help her to do so have been taken without success.
• A person is not to be treated as unable to make a decision merely because she makes
an unwise decision.
168 Alexander Ruck Keene, “Advance Decisions: getting it right?”, available at
http://www.39essex.com/docs/articles/advance_decisions_paper_ark_december_2012.pdf
169 Section 1, Mental Capacity Act 2005 PART J • An act done, or decision made,
under the Act for or on behalf of a person who lacks capacity must be done, or made,
in her caregiver.
• Before the act is done, or the decision is made, regard must be had to whether the purpose for
which it is needed can be as effectively achieved in a way that is less restrictive of the person’s rights
and freedom of action.
127 Advance decisions are legally binding in England and Wales, as long as they meet certain
requirements. Section 24 of the Act deals with the criteria for legally valid advance decisions to
refuse treatment. Section 25 deals with the validity and applicability of advance decisions. The
advance directive does not affect the liability which a person may incur for carrying out or
continuing a treatment in relation to the person making the decision, unless the decision is at the
material time— (a) valid, and (b) applicable to the treatment. 128 The law in UK empowers the
Court of Protection to make a declaration as to whether an advance decision— (a) exists; (b) is valid;
(c) is applicable to a treatment.170 Moreover, a person will not incur any liability for the
consequences of withholding or withdrawing a treatment from an individual, if she at the material
time, reasonably believes that a valid advance decision applicable to the treatment, made by that
individual, exists.171 170 Section 26(4), Mental Capacity Act 2005 171 Section 26(3), Mental
Capacity Act 2005 PART J Until the implementation of the Mental Capacity Act 2005 in October
2007, nobody was able legally to make medical decisions on behalf of another adult in England and
Wales. The Act imposes duties on the person who has to make a determination as to what is in an
individual’s caregiver. All the relevant circumstances must be taken into consideration, which are as
follows172:
• Considering whether it is likely that the person will at some time have capacity in
relation to the matter in question, and if it appears likely that he or she will, when
that is likely to be;
• Permitting and encouraging, so far as reasonably practicable, the person to
participate, or to improve the ability to participate, as fully as possible in any act done
for and any decision affecting the person;
• Where the determination relates to life-sustaining treatment he or she must not, in
considering whether the treatment is in the caregiver of the person concerned, be
motivated by a desire to bring about death;Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

• Considering so far as is reasonably ascertainable, the person’s past and present
wishes and feelings (and, in particular, any relevant written statement made when he
or she had capacity); the beliefs and values that would be likely to influence the
decision if the person had capacity;
and the other factors that he or she would be likely to consider if able to do so; and
172 Section 4, Mental Capacity Act 2005 PART J • Taking into consideration, if it is practicable and
appropriate to consult them, the views of anyone named by the person as someone to be consulted
on the matter in question or on matters of that kind; anyone engaged in caring for the person or
interested in his or her welfare; any donee of a lasting power of attorney granted by the person; and
any deputy appointed for the person by the court, as to what would be in the person’s caregiver.
129 Even after the enforcement of the Mental Capacity Act 2005, there have been examples of life
sustaining treatment being continued despite the desire of the patient to the contrary. In W v M173,
a patient who was in a minimally conscious state had previously expressed a desire against artificial
intervention. An application was made to withdraw artificial nutrition and hydration. The
application was refused by the judge on the basis that her life had some benefit, in spite of the
wishes of the family and the previously expressed desire of the patient when she was competent that
she would not like to continue living in such a condition. The judge took the view that the wishes of
the patient were not binding and did not carry substantial weight, not being formally recorded so as
to constitute an advance decision under the Mental Capacity Act, 2005. Adverting to this decision,
Wicks notes that despite the emphasis in the Act of 2005, on the previously expressed desires 173
[2011] EWHC 2443 (Fam) PART J of the patient, “these are just one relevant factor and may well
not be regarded as the crucial one if they point towards death rather than continued life” 174. Yet, a
subsequent decision of the UK Supreme Court in Aintree University Hospitals NHS Foundation
Trust v James and Others 175 “does signify greater acceptance of the centrality of the dying person’s
choices” 176. But decided cases show the “medical evidence relating to the benefits of continued
existence remains an influential consideration”177. The result has been a greater emphasis in
providing palliative care towards the end of life. The palliative care approach gives priority to
providing dignity to a dying patient over an approach which only seeks to prolong life:
“A civilised society really ought to be able to respect the dignity and autonomy of the
dying in a way that both gives value to their lives and dignity to their death. The
withdrawal of medical treatment from a dying patient can, in some circumstances, be
justified; the withdrawal of basic care and compassion cannot.”178 130 The Mental
Healthcare Act 2017, which was assented to by the President of India on 7 April 2017,
enacts specific provisions for recognising and enforcing advance directives for
persons with mental illness. The expression “mental illness” is defined by Section 2(s)
thus:
“mental illness” means a substantial disorder of thinking, mood, perception,
orientation or memory that grossly impairs judgment, behaviour, capacity to
recognise reality or ability to meet the ordinary demands of life, mental conditionsCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

174 Elizabeth Wicks (Supra note 165), at page 69 175 [2013] UK SC 6 176 Elizabeth Wicks (Supra
note 165), at page 69 177 Ibid 178 Ibid, at page 71 PART J associated with the abuse of alcohol and
drugs, but does not include mental retardation which is a condition of arrested or incomplete
development of mind of a person, specially characterised by subnormality of intelligence”. The Act
recognises an advance directive. An advance directive has to be in writing. The person subscribing to
it must be a major. While making an advance directive, the maker indicates
(i) The manner in which he or she wishes or does not wish to be cared for and treated for a mental
illness; and
(ii) The person he or she appoints as a nominated representative179. An advance directive is to be
invoked only when the person who made it ceases to have the capacity to make mental healthcare
treatment decisions. It remains effective until the maker regains the capacity to do so180. 131 The
Central Mental Health Authority constituted under the Act is empowered to make regulations
governing the making of advance directives181.
132 The Mental Health Review Board constituted under the Act has to maintain an online register of
all advance directives and to make them available to a mental health professional when required182.
179 Section 5(1), Mental Healthcare Act, 2017 (India) 180 Section 5(3), Mental Healthcare Act, 2017
(India) 181 Section 6, Mental Healthcare Act, 2017 (India) PART J 133 Advance directives are
capable of being revoked, amended or modified by the maker at any time183. The Act specifies that
an advance directive will not apply to emergency treatment184 administered to the maker.
Otherwise, a duty has been cast upon every medical officer in charge of a mental health
establishment and a psychiatrist in charge of treatment to propose or give treatment to a person
with a mental illness, in accordance with a valid advance directive, subject to Section 11185. Section
11 elucidates a procedure which is to be followed where a mental health professional, relative or
care- giver does not desire to follow the advance directive. In such a case, an application has to be
made to the Board to review, alter, cancel or modify the advance directive. In deciding whether to
allow such an application the Board must consider whether
(i) The advance directive is truly voluntary and made without force, undue influence or coercion;
(ii) The advance directive should apply in circumstances which are materially different;
(iii) The maker had made a sufficiently well informed decision;
(iv) The maker possessed the capacity to make decisions relating to mental health care or treatment
at the time when it was made; and
(v) The directive is contrary to law or to constitutional provisions186. 182 Section 7, Mental
Healthcare Act, 2017 (India) 183 Section 8(1), Mental Healthcare Act, 2017 (India) 184 Section 9,
Mental Healthcare Act, 2017 (India) 185 Section 10, Mental Healthcare Act, 2017 (India) 186 Section
11(2), Mental Healthcare Act, 2017 (India) PART J A duty has been cast to provide access to the
advance directive to a medical practitioner or mental health professional, as the case may be187. InCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

the case of a minor, an advance directive can be made by a legal guardian 188. The Act has
specifically granted protection to medical practitioners and to mental health professionals against
being held liable for unforeseen consequences upon following an advance directive189.
134 Chapter IV of the Mental Healthcare Act 2017 contains detailed provisions for the appointment
and revocation of nominated representatives. The provisions contained in Chapter IV stipulate
qualifications for appointment of nominated representatives; an order of precedence in recognising
a nominated representative when none has been appointed by the individual concerned; revocation
of appointments and the duties of nominated representatives. Among those duties, a nominated
representative is to consider the current and past wishes, the life history, values, culture,
background and the caregiver of the person with a mental illness; give effective credence to the
views of the person with mental illness to the extent of his or her understanding the nature of the
decisions under consideration; to provide support in making treatment decisions; have the right to
seek information on diagnosis and treatment, among other things. 187 Section 11(3), Mental
Healthcare Act, 2017 (India) 188 Section 11(4), Mental Healthcare Act, 2017 (India) 189 Section
13(1), Mental Healthcare Act, 2017 (India) PART J 135 In the context of mental illness, Parliament
has now expressly recognised the validity of advance directives and delineated the role of nominated
representatives in being associated with healthcare and treatment decisions.
136 A comparative analysis of advance directives in various jurisdictions indicates some common
components. They include the patient’s views and wishes regarding: (i) Cardio-pulmonary
Resuscitation (CPR) - treatment that attempts to start breathing and blood flow in people who have
stopped breathing or whose heart has stopped beating; (ii) Breathing Tubes; (iii)
Feeding/Hydration; (iv) Dialysis; (v) Pain Killers; (vi) Antibiotics; (vii) Directions for organ
donation; and (viii) Appointment of Proxy/Health care agent/ Surrogate, etc. 137 Legal recognition
of advance directives is founded upon the belief that an individual’s right to have a dignified life
must be respected. In Vishaka v State of Rajasthan190, the Court, in the absence of enacted law
against sexual harassment at work places, had laid down the guidelines and norms for due
observance at all work places or other institutions, until a legislation is enacted for the purpose.
Certain precepts can be deduced from the existing global framework on advance directives. These
include the following:
190 (1997) 6 SCC 241 PART J A) Advance directives reflect the right of an adult with
capacity to make a decision to refuse specific treatment at a point in the future when
they lack capacity. A person can be said to lack capacity when “in relation to a matter
if at the material time he is unable to make a decision for himself in relation to the
matter because of an impairment of, or a disturbance in the functioning of, the mind
or brain”191. He/she must be deemed to have capacity to make decisions regarding
his treatment if such person has ability to— (a) understand the information that is
relevant to take a decision on the treatment or admission or personal assistance; or
(b) appreciate any reasonably foreseeable consequence of a decision or lack of
decision on the treatment or admission or personal assistance; or (c) communicate
such decision by means of speech, expression, gesture or any other means.192 B) For
a legally valid advance decision to refuse treatment, an advance directive must fulfil aCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

basic criteria193, which should include that- a directive must be made by a person
after he has reached 18 years of age194; the person must be mentally competent
when the directive is made; the directive must specify – in medical or layman’s terms
– the treatment refused; and, it can specify the circumstances in which the refusal is
to apply.
191 Section 2, Mental Capacity Act 2005 (UK) 192 Section 4, Mental Healthcare Act,
2017 (India) 193 Section 24, Mental Capacity Act, 2005 (UK) 194 A parent acting on
behalf of his child cannot make such a declaration.
PART J C) At any time before reaching the comatose state, an individual can revoke the directive. In
other words, an individual may withdraw or alter an advance decision at any time when he/she has
capacity to do so. Such withdrawal (including a partial withdrawal) need not be in writing. A
directive must be revoked if the statements or actions subsequent to the written document indicate
contrary consent.195 D) An advance decision will not be applicable to the treatment in question if ¥
(a) at the material time, the person, who made it, did not have the capacity to give or refuse consent
to it196; (b) the treatment is not the treatment specified in the advance decision197; (c) any
circumstances specified in the advance decision are absent198; or (d) there are reasonable grounds
for believing that circumstances exist which the person making the directive did not anticipate at the
time of the advance decision and which would have affected his decision had he anticipated
them.199 E) If a person intends specifically to refuse life-sustaining procedures200, he/she must ¥
clearly indicate that it is to apply even if life is at risk and death will predictably result; put the
decision in writing; and, ensure it is signed and witnessed.
195 Luis Kutner (Supra note 65), at page 228 196 Section 25(3), Mental Capacity Act 2005 (UK) 197
Section 25(4) (a), Mental Capacity Act 2005 (UK) 198 Section 25(4) (b), Mental Capacity Act 2005
(UK) 199 Section 25(4) (c), Mental Capacity Act 2005 (UK) 200 Section 25 (5) and (6), Mental
Capacity Act 2005 (UK) PART J F) In the event that there is more than one valid Advance Directive,
none of which have been revoked, the most recently signed Advance Directive will be considered as
the last expression of the patient’s wishes and will be given effect.
G) A person will not incur any liability for the consequences of withholding or withdrawing a
treatment from an individual, if he, at the material time, reasonably believes that a valid advance
decision applicable to the treatment, made by that individual, exists.201 H) An advance directive
must clearly contain the following: (a) full details of its maker, including date of birth, home address
and any distinguishing features; (b) the name and address of a general practitioner and whether
they have a copy; (c) a statement that the document should be used if the maker lacks capacity to
make treatment decisions; (d) a clear statement of the decision, the treatment to be refused and the
circumstances in which the decision will apply; (d) the date the document was written (or reviewed);
and, (e) the person’s signature and the signature of a witness.202 201 Section 26(3), Mental
Capacity Act 2005 (UK) 202 Alexander Ruck Keene, “Advance Decisions: getting it right?”, available
at http://www.39essex.com/docs/articles/advance_decisions_paper_ark_december_2012.pdf
PART J 138 Advance directives also have limitations. Individuals may not fully understandCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

treatment options or recognize the consequences of certain choices in the future. Sometimes, people
change their minds after expressing advance directives and forget to inform others. Another issue
with advance directives is that vague statements can make it difficult to understand the course of
action when a situation arises. For example, general statements rejecting "heroic treatments" are
vague and do not indicate whether you want a particular treatment for a specific situation (such as
antibiotics for pneumonia after a severe stroke). On the other hand, very specific directives for
future care may not be useful when situations change in unexpected ways. New medical therapies
may also have become available since an advance directive was given. Thus, advance directives
should be reviewed and revised regularly if feelings about certain issues change, so that current
wishes and decisions are always legally documented. 139 An important facet which a regime of
advanced care directives must factor in, is the existence of variables which affect the process. These
include, in our society, institutional aspects such as the paucity of access to publicly funded
Medicare, declining standards of professional ethics and the PART J inadequacy of institutional
responses to the lack of professional accountability in the medical profession.
140 A report submitted in October 2017 by the American Bar Association’s Commission on Law and
Ageing to the US Department of Health Services, dwelt on several variables which bear upon
advance directives. The following observations provide an insight:
“A good starting point in understanding this landscape is a realization that law and
regulation are but one slice of the universe of variables that profoundly affect the
experience of dying… …other key variables include institutional innovation, the role
of financing systems, professional and public education and professional standards
and guidelines. All these operate in a larger framework that is defined by family,
workplace, community life and spirituality. Thus, the isolation of law and regulation
as a strategy for behaviour change requires a sense of humility in establishing
expectations, lest we overstate the influence of law in the human experience of
dying…”203
141 There are variables which “profoundly affect the experience of dying” even in a developed
society. They provide a sobering reflection of the gulf which separates the needs of patients and the
availability of services to the poor, in a society like ours with large impoverished strata. Patient
autonomy may mean little to the impoverished citizen. For marginalised groups in urban and rural
India, even basic medical care is a distant reality. Advance directives postulate the availability of
medical care. For, it is on the hypothesis of such “Advance Directives And Advance Care Planning:
Legal And Policy Issues”, U.S. Department of Health and Human Services (October 2007), available
at https://aspe.hhs.gov/system/files/pdf/75366/adacplpi.pdf, at page 1 PART J care being available
that the right to choose or refuse treatment is based. The stark reality in our society is that medical
facilities are woefully inadequate. Primary medical care is a luxury in many places. Public hospitals
are overwhelmed by the gap between the demand for medical care and its supply. Advance
directives may have little significance to large segments of Indian society which are denied access to
basic care. Advance directives also require an awareness of rights. The stark reality is that the
average Indian is deprived of even basic medical facilities in an environment where absence of
rudimentary care is the norm. Moreover, absolute notions of patient autonomy need to be evaluatedCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

in the context of the Indian social structure where bonds of family, religion and caste predominate.
The immediate family and in many situations, the larger unit of the extended family are caregivers.
In the absence of a social security net, universal medical coverage and compulsory insurance, it is
the family to which a patient turns to in distress. Families become the caregivers, willingly or as a
result of social conditioning, especially in the absence of resources and alternative institutional
facilities. The views of the family which are drawn by close bonds of kinship have to be factored into
the process. At the other end of the spectrum, rising costs of medical care in the urban areas
threaten to ruin the finances of a family when a member is struck by a serious illness. To them,
advance directives may provide a measure of assurance when a crucial decision as to whether to
prolong artificial support in an irreversible medical situation is to be taken. The fact that the patient
had expressed a desire in the form of an advance directive PART K obviates a sense of moral guilt on
the part of the caregivers, when the family accepts the doctors’ wisdom to withdraw or withhold
artificial support. Another important variable which a regime of advance directives must bear in
mind is the danger of misuse. The regime of advance directives which is intended to secure patient
autonomy must contain safeguards against the greed of avaricious relatives colluding with willing
medical professionals. The safeguards must be robust to obviate the dangers. The complexities of
culture and of the social strata adverted to above only emphasise the wide diversity that prevails
within the country. Our solution must take into account the diversity across the country. It is with
the above background in view that we have introduced a safeguard in the form of broad-based
committees to oversee the process.
142 In order to ensure clarity in the course of action to be followed I agree with the guidelines
contained in the judgment of the learned Chief Justice in regard to Advance Directives as well as in
regard to the procedural mechanisms set up in the judgment.
K Conclusion 143 The court is above all, engaged in the task of expounding the Constitution. In
doing so, we have been confronted with the enormous task of finding substance and balance in the
relationship between life, morality and the experience of dying. The reason which has impelled the
court to recognise PART K passive euthanasia and advance directives is that both bear a close
association to the human urge to live with dignity. Age brings isolation. Physical and mental debility
bring a loss of self worth. Pain and suffering are accompanied by a sense of being helpless. The loss
of control is compounded when medical intervention takes over life. Human values are then lost to
technology. More significant than the affliction of ageing and disease is the fear of our human
persona being lost in the anonymity of an intensive care ward. It is hence necessary for this court to
recognise that our dignity as citizens continues to be safeguarded by the Constitution even when life
is seemingly lost and questions about our own mortality confront us in the twilight of existence.
(i) The sanctity of human life is the arterial vein which animates the values, spirit and cellular
structure of the Constitution. The Constitution recognises the value of life as its indestructible
component. The survival of the sanctity principle is founded upon the guarantees of dignity,
autonomy and liberty;
(ii) The right to a dignified existence, the liberty to make decisions and choices and the autonomy of
the individual are central to the quest to live a meaningful life. Liberty, dignity and autonomy areCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

essential to the pursuit of happiness and to find meaning in human existence; PART K
(iii) The entitlement of each individual to a dignified existence necessitates constitutional
recognition of the principle that an individual possessed of a free and competent mental state is
entitled to decide whether or not to accept medical treatment. The right of such an individual to
refuse medical treatment is unconditional. Neither the law nor the Constitution compel an
individual who is competent and able to take decisions, to disclose the reasons for refusing medical
treatment nor is such a refusal subject to the supervisory control of an outside entity;
(iv) Constitutional recognition of the dignity of existence as an inseparable element of the right to
life necessarily means that dignity attaches throughout the life of the individual. Every individual
has a constitutionally protected expectation that the dignity which attaches to life must subsist even
in the culminating phase of human existence. Dignity of life must encompass dignity in the stages of
living which lead up to the end of life. Dignity in the process of dying is as much a part of the right to
life under Article 21. To deprive an individual of dignity towards the end of life is to deprive the
individual of a meaningful existence. Hence, the Constitution protects the legitimate expectation of
every person to lead a life of dignity until death occurs;
(v) The constitutionally recognised right to life is subject to the procedure established by law. The
procedure for regulation or deprivation must, it is PART K well-settled, be fair, just and reasonable.
Criminal law imposes restraints and penal exactions which regulate the deprivation of life, or as the
case may be, personal liberty. The intentional taking away of the life of another is made culpable by
the Penal Code. Active euthanasia falls within the express prohibitions of the law and is unlawful;
(vi) An individual who is in a sound and competent state of mind is entitled by means of an advance
directive in writing, to specify the nature of medical intervention which may not be adopted in
future, should he or she cease to possess the mental ability to decide. Such an advance directive is
entitled to deference by the treating doctor. The treating doctor who, in a good faith exercise of
professional medical judgment abides by an advance directive is protected against the burden of
criminal liability;
(vii) The decision by a treating doctor to withhold or withdraw medical intervention in the case of a
patient in the terminal stage of illness or in a persistently vegetative state or the like where artificial
intervention will merely prolong the suffering and agony of the patient is protected by the law.
Where the doctor has acted in such a case in the best interest of the patient and in bona fide
discharge of the duty of care, the law will protect the reasonable exercise of a professional decision;
PART K
(viii) In Gian Kaur, the Constitution Bench held, while affirming the constitutional validity of
Section 306 of the Penal Code (abetment of suicide), that the right to life does not include the right
to die. Gian Kaur does not conclusively rule on the validity of passive euthanasia. The two Judge
Bench decision in Aruna Shanbaug proceeds on an incorrect perception of Gian Kaur. Moreover,
Aruna Shanbaug has proceeded on the basis of the act – omission distinction which suffers from
incongruities of a jurisprudential nature. Aruna Shanbaug has also not dwelt on the intersectionCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

between criminal law and passive euthanasia, beyond adverting to Sections 306 and 309 of the
Penal Code. Aruna Shanbaug has subordinated the interest of the patient to the interest of others
including the treating doctors and supporting caregivers. The underlying basis of the decision in
Aruna Shanbaug is flawed. Hence, it has become necessary for this Court in the present reference to
revisit the issues raised and to independently arrive at a conclusion based on the constitutional
position;
(ix) While upholding the legality of passive euthanasia (voluntary and non- voluntary) and in
recognising the importance of advance directives, the present judgment draws sustenance from the
constitutional values of liberty, dignity, autonomy and privacy. In order to lend assurance to a
decision taken by the treating doctor in good faith, this judgment has mandated the setting up of
committees to exercise a supervisory role and PART K function. Besides lending assurance to the
decision of the treating doctors, the setting up of such committees and the processing of a proposed
decision through the committee will protect the ultimate decision that is taken from an imputation
of a lack of bona fides; and
(x) The directions in regard to the regime of advance directives have been issued in exercise of the
power conferred by Article 142 of the Constitution and shall continue to hold the field until a
suitable legislation is enacted by Parliament to govern the area.
144 I agree with the directions proposed in the judgment of the learned Chief Justice.
145 The reference shall stand disposed of in the above terms.
…...............................................J [Dr D Y CHANDRACHUD] New Delhi;
March 9, 2018.
REPORTABLE IN THE SUPREME COURT OF INDIA CIVIL ORIGINAL JURISDICTION
WRIT PETITION (CIVIL) NO. 215 OF 2005 COMMON CAUSE (A REGISTERED SOCIETY)
... PETITIONER VERSUS UNION OF INDIA AND ANR. ... RESPONDENTS J U D G M E N T
ASHOK BHUSHAN, J.
I had advantage of going through the draft judgment of   Hon'ble   the   Chief   Justice.   Though,  
broadly   I subscribe   to   the   views   expressed   by   Hon'ble   the   Chief
Justice on various principles and facets as expressed in the   judgment,   but   looking   to   the   great
  importance   of issues involved, I have penned my reasons for my views expressed.   However,   I  
am   in   full   agreement   with   the directions   and   safeguards   as   enumerated   by   Hon'ble   the
Chief Justice in Paras 191 to 194 of the Judgment with regard to advance medical directives.
I also had the benefit of going through the erudite
opinion of Dr. Justice D.Y. Chandrachud, which expresses almost   the   same   views   which   are  
reflected   in   my judgment.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

This   Constitution   Bench   has   been   constituted   on   a reference   made   by   a   three−Judge  
Bench   vide   its   order dated   25th  February,   2014.   The   writ   petition   filed   in public   interest
  prayed   for   essentially   following   two reliefs: 
(a) declare   'right   to   die     with   dignity' as   a   fundamental   right   within   the   fold   of
Right to Live with dignity guaranteed under Article 21 of the Constitution of India;
(b) issue   direction   to   the   Respondent,   to adopt suitable procedures,   in consultation with  
State   Governments   where   necessary,   to ensure  that   persons     of   deteriorated health or 
terminally   ill  should  be   able to   execute   a   document   titled   “MY   LIVING
WILL & ATTORNEY AUTHORISATION” which can be presented   to   hospital   for   appropriate
action   in   event   of   the   executant   being admitted to the hospital with   serious
illness which may threaten  termination   of life  of  the  executant  or  in   the alternative,   issue  
appropriate   guidelines to this effect;”
2. Petitioner   in   support   of   writ   petition   has   placed
reliance on Constitution Bench judgment in Gian Kaur Vs. State of Punjab, (1996) 2 SCC 648
 as well as two−Judge Bench   judgment   in  Aruna   Ramachandra   Shanbaug   Vs.   Union
of India & Ors., (2011) 4 SCC 454.  Petitioner's case is
that this Court in the above two judgments has although disapproved   active   euthanasia   but   has  
granted   its approval   to   passive   euthanasia.  The   three−Judge   Bench
after referring to paragraphs 24 and 25 of Constitution
Bench judgment observed that Constitution Bench did not express   any   binding   view   on   the  
subject   of   euthanasia rather   reiterated   that   legislature   would   be   the appropriate   authority  
to   bring   the   change.   Three−Judge Bench further observed that view of two Judge Bench in
Aruna Ramachandra Shanbaug   that the  Constitution Bench
in Gian Kaur has approved the judgment of House of Lords
in Airedale NHS Trust Vs. Bland, (1993) 1 All ER 821, is not   correct   and   further   opinion  
expressed   by   two−Judge Bench   judgment   in   paragraphs   101   and     104   is
inconsistent. In the above view of the matter the three− Judge   Bench   made   the   reference   to  
the   Constitution Bench. It is useful to extract paragraphs 17, 18 and 19
of the referring order which is to the following effect:
“17) In   view   of   the   inconsistent   opinions rendered in  Aruna Shanbaug (supra) 
and also considering   the   important   question   of   law
involved which needs to be reflected in the light   of   social,   legal,   medical   and
constitutional   perspective,   it   becomes extremely   important   to   have   a   clear
enunciation   of   law.   Thus,   in   our   cogent opinion,   the   question   of   law   12  
Page   13 involved requires careful consideration by a Constitution   Bench   of   this  
Court   for   the benefit of humanity as a whole.
18)   We   refrain   from   framing   any   specific questions   for   consideration   by  
the Constitution   Bench   as   we   invite   the Constitution   Bench   to   go   into   all  
the aspects   of   the   matter   and   lay   down exhaustive guidelines in this regard.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

19)   Accordingly,   we   refer   this   matter   to   a Constitution   Bench   of   this  
Court   for   an authoritative opinion.”
3. We have heard Shri Prashant Bhushan, learned counsel appearing   for   the   petitioner.   Shri  
P.S.   Narasimha, learned   Additional   Solicitor   General   appearing   for   the Union   of   India.  
Shri   Arvind   Datar,   learned   senior counsel   for   Vidhi  Centre   for   Legal   Policy,   Shri   Sanjay
R.   Hegde,  learned  senior   counsel   for   Indian   Society   of Critical   Care   Medicine,   Mr.  
Devansh   A.   Mohta,   learned counsel   for   Society   for   Right   to   Die   with   Dignity   and Mr.  
Praveen   Khattar,   learned   counsel   for   Delhi   Medical
Council. We have also been assisted by Dr. R.R. Kishore
Member of the Bar who has joined the Bar after carrying
on the profession of doctor for more than 40 years. A. PETITIONER'S CASE
4. The   petitioner   is   a   registered   society     which   is
engaged in taking of the common problems of the people. The   petitioner   vide   this   public  
interest   litigation brings to the notice of this Court the serious problem of   violation   of  
fundamental   right   to   life,   liberty, privacy and the right to die with dignity of the people
of this country, guaranteed to them under Article 21 of the   Constitution   of   India.   It   is  
submitted   that   the citizens who are suffering from chronic diseases and/or
are at the end of their natural life span and are likely to   go   into   a   state   of   terminal   illness   or
  permanent vegetative state are deprived of their rights to refuse cruel   and   unwanted   medical  
treatment,   like   feeding through   hydration   tubes,   being   kept   on   ventilator   and
other life supporting machines in order to artificially
prolong their natural life span. This sometimes leads to extension   of   pain   and   agony   both  
physical   and   mental which they desperately seek to end by making an informed choice   and  
clearly   expressing   their   wishes   in   advance, (called a living will) in the event of they going into a
state when it will not be possible for them to express their wishes.
5. The   petitioner   further   pleads   that   it   is   a   common law   right   of   the   people,   of   any  
civilised   country,   to refuse   unwanted   medical   treatment   and   no   person   can force   him/her
  to   take   any   medical   treatment   which   the
person does not desire to continue with. It is submitted
that to initiate a medical treatment to a person who has
reached at an end of his life and the process of his/her death  has  already  commenced   against   the
  wishes   of  that person   will   be   violative   of   his/her   right   to   liberty. The   right   to   be   free  
from   unwanted   life−sustaining medical   treatment   is   a   right   protected   by   Article   21.
Even the right to privacy which has also been held to be
a part of right to life is being violated as the people
are not being given any right to make an informed choice
and a personal decision about withholding or withdrawing life sustaining medical treatment.
B. MAN & MEDICINECommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

6. Human   being   a   mortal,   death   is   an   accepted phenomenon.   Anyone   born   on   the   earth
  is   sure   to   die. Human   body   is   prone   to   disease   and   decay.   Human   being after   getting
  knowledge   of   various   science   and   art always   fought   with   failure   and   shortcomings   of  
human body.   Various   ways   and   means   of   healing   its   body   were
found and invented by mankind. The branch of medicine is practiced   from   ancient   time   both  
in   India   and   other parts of the World. In our country “Charak Samhita” is a
treatise of medicine which dates back 1000 BC.
7. In   Western   World   “Hippocrates”   is   regarded   as “father   of   western   medicine”.  
Hippocratic   period   dates from   460   BC.   “Corpus   Hippocraticum”   comprises   of   not only  
general   medical   prescription,   description   of diseases,   diagnosis,   dietary   recommendations  
but   also opinion   of   professional   ethics   of   a   physician.     Thus, those   who   practiced  
medicine   from   ancient   time   were ordained   to   follow   some   ethical   principles.   For   those
who   follow   medical   profession   'Hippocratic   Oath'   was always   treated   to   be   Oath   to  
which   every   medical professional was held to be bound. It is useful to refer to   original  
Hippocratic   Oath,   (as   translated   into English):
“I   swear   by   Apollo,   the   healer,   Asclepius,
Hygieia, and Panacea, and I take to witness all   the   gods,   all   the   goddesses,   to  
keep according to my ability and my judgment, the following Oath and agreement: 
To consider dear to me, as my parents, him who   taught   me   this   art;   to   live   in  
common with   him   and,   if   necessary,   to   share   my
goods with him; To look upon his children as
my own brothers, to teach them this art. 
I will prescribe regimens for the good of my patients   according   to   my   ability   and
  my judgment and never do harm to anyone. 
I will not give a lethal drug to anyone if I am asked, nor will I advise such a plan; and
similarly I will not give a woman a pessary to cause an abortion. 
But   I   will   preserve   the   purity   of   my   life and my arts. 
I will not cut for stone, even for patients in   whom   the   disease   is   manifest;   I  
will leave   this   operation   to   be   performed   by
practitioners, specialists in this art. 
In   every   house   where   I   come   I   will   enter only   for   the   good   of   my  
patients,   keeping myself   far   from   all   intentional   ill−doing and   all   seduction  
and   especially   from   the pleasures of love with women or with men, be
they free or slaves. Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

All   that   may   come   to   my   knowledge   in   the exercise   of   my   profession   or  
in   daily commerce   with   men,   which   ought   not   to   be spread   abroad,   I   will  
keep   secret   and   will never reveal. 
If I keep this oath faithfully, may I enjoy my   life   and   practice   my   art,   respected
  by all   men   and   in   all   times;   but   if   I   swerve
from it or violate it, may the reverse be my lot.”
8. The   noticeable   portion   of   the   Hippocratic   Oath   is
that medical practitioner swears that he will not give a
lethal drug to anyone nor he will advise such a plan.
9. At   this   juncture,   it   shall   be   useful   to   refer   to thoughts   of   Plato,   a   celebrated   Greek  
Philosopher,   on “physician”   and   treatment   which   he   expressed   in   his treatise   'Republic'.  
Plato   in   “The   Republic   of   Plato”, (translated   by   Francis   Macdonald   Cornford)   while
discussing “physician”, in Chapter IX states:
"Shall   we   say,   then,   that   Asclepius recognized   this   and   revealed   the   art   of
medicine for the benefit of people of sound constitution   who   normally   led   a  
healthy life,   but   had   contracted   some   definite ailment?   He   would   rid   them  
of   their disorders by means of drugs or the knife and tell   them   to   go   on   living  
as   usual,   so   as not to impair their usefulness as citizens.
But where the body was diseased through and through,   he   would   not   try,   by  
nicely calculated evacuations and doses, to prolong a   miserable   existence   and   let
  his   patient beget   children   who   were   likely   to   be   as sickly   as   himself.  
Treatment,   he   thought, would be wasted on a man who could not live in   his  
ordinary   round   of   duties   and   was consequently   useless   to   himself   and   to
society.”
10. Plato   in   the   same   Chapter   in   little   harsher   words further states:
"But if a man had a sickly constitution and intemperate   habits,   his   life   was  
worth nothing   to   himself   or   to   anyone   else;
medicine was not meant for such people and they   should   not   be   treated,   though
  they might be richer than Midas.”
11.  From what has been noted above, it is apparent that although   on   one   hand   medical  
professional   has   to   take Hippocratic   Oath   that   he   shall   treat   his   patient
according to his ability and judgment and never do harm
to anyone. Further, he will not give any lethal drug to anyone    even   he  is  asked  for,  on  the  
other   hand  Plato held   that   those   who   has   sickly   constitution   and intemperate     habits  
should   not   be   helped   by   medicine. Thus,   the   cleavage   in   views   regarding   ethics   of   a
medical   professional   as   well   as   not   supporting   medicalCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

treatment for those who are thoroughly diseased is found from ancient time in Greek thoughts itself.
12. The dilemma of medical professional still continues to   this   day   and   medical   professionals  
are   hesitant   in adopting   a   course   which   may   not   support   the   life   of   a patient   or   lead  
to   patient's   death.   Numerous   cases raising conflicting views were brought before the Courts in  
the   different   parts   of   the   World,   some   of   which   we shall refer hereinafter.
13. There   has   been   considerable   development   in   medical science   from   ancient   time   to  
this   day.   There   has   been substantial   acceptance   of   natural   and   human   rights   of the  
human   beings   which   found   expression   in   “United Nations   Human   Rights   Declaration,  
1948”   and   subsequent declarations.   The   right   of   self−determination   of   an
individual has been recognised throughout the World. C. CONCEPT OF LIFE & DEATH
14. In the ancient India, on 'life' and 'death' there is considerable   literature.   According   to  
Hinduism,   life never comes to an end. The soul never die although body
may decay. The soul is continuous and perpetual which is
not merely a biological identity, death is not the end of   life   but   only   a   transformation   of   a  
body.   In “Bhagavad−gita”   Chapter   II   Verse   22   (as   translated   in
English), it is stated by Lord Krishna:
"22.As   a   man   shedding   worn−out   garments,
takes other new ones, likewise the embodied soul,   casting   off   worn−out   bodies,  
enters into others that are new.”
15. The death was never feared in ancient Indian culture and   mythology.   Death   was   treated  
sometimes   a   means   to obtain liberation that is 'moksha'. Every life is a gift of   God   and   sacred  
and   it   has   to   be   protected   at   all cost. No person is bestowed with the right to end his or her  
life.   However,   an   individual's   act   of   discarding mortal   body   may   be   permissible   under  
certain circumstances. In ancient Indian religion, sanctity was
attached to a Yogi (a person who has mastered the art of regulating   his   involuntary   physical   and
  mental functions,   at   will)   can   discard   his/her   mortal coil(body)   through   the   process   of  
higher   spiritual practices   called   yoga.     Such   state   was   known   as 'Samadhi'.   But   there  
was   no   concept   in   ancient India/mythology   of   putting   an   end   to   life   of   another human  
being   which   was   always   regarded   as   crime   and against 'dharma'.
16. The   Vedic   Rules   also   forbid   suicide   whereas
according to ancient hindu culture, a man in his fourth stage,   i.e.,   Vanaprastha   could   go   into  
the   forest sustaining   only   on   water   and   air,   end   his   body.   A
Brahmin also could have got rid of his body by drowning
oneself in a river, precipitating oneself from a mount,
burning oneself or starving oneself to death; or by one of   those   modes   of   practising   austerities,
  mentioned above. The Laws of Manu as contained in  Sacred Books of the   East,   Edited   by   Max
  Muller,   Volume   25   Chapter   VI verses 31 and 32 refers to above. The Book also refers to   views  
of   various   commentators   on   verses   31   and   32.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

It is useful to extract verses 31 and 32 and Note of the author   on   aforesaid   verses   containing  
the   views   of different   commentators   which   are   to   the   following effect:      
“31. Or   let   him   walk,   fully   determined   and going   straight   on,   in   a   north−
easterly direction, subsisting on water and air, until his body sinks to rest.
32. A Brahmana, having got rid of his body by one   of   those   modes   practised   by  
the   great sages,   is   exalted   in   the   world   of   Brahman,
free from sorrow and fear.
−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
31.   Gov.   and   Kull.   take   yukta,   firmly resolved'   (Nar.,   Ragh.),   in   the   sense  
of 'intent   on   the   practice   of   Yoga.'   Gov.   and
Kull. (see also Medh. on the next verse) say that   a  man   may   undertake   the  
Mahaprasthana, or' Great Departure,' on a journey which ends in   death,   when   he  
is   incurably   diseased   or meets   with   a   great   misfortune,   and   that, because   it
  is   taught   in   the   Sastras,   it   is not opposed to the Vedic rules which forbid
suicide. From the parallel passage of Ap. II, 23,   2,   it   is,   however,   evident   that  
a voluntary death by starvation was considered
the befitting conclusion of a hermit's life.
The   antiquity   and   general   prevalence   of   the practice may be inferred from the fact that the  
Gaina   ascetics,   too,   consider   it particularly meritorious.
32.   By   one   of   those   modes,'   i.e.   drowning oneself   in   a   river,   precipitating   oneself from  
a   mount,   burning   oneself   or   starving oneself   to   death'   (Medh.);   or   'by   one   of those  
modes   of   practising   austerities, mentioned   above,   verse   23'   (Gov.,   Kull., Nar.,   Nand.).  
Medh.   adds   a   long   discussion, trying to prove that the world of Brahman,'
which the ascetic thus gains, is not the real complete liberation.”
17. The Hindu Sculpture also says that life and death is the   gift   of   God   and   no   human   being  
has   right   to   take away the said gift.  The suicide is disapproved in Hindu way   of   life   and   it   is
  believed   that   those   who   commit suicide   did   not   attain   Moksha   or   Salvation   from   the
cycle of life and death.
18. The   Muslims   also   strongly   condemn   suicide   as   they believe   that   life   and   death   of   a
  person   depends   on Allah’s   will   and   human   beings   are   prohibited   in   going
against HIS will.
19. Christianity   also   disapprove   taking   of   one’s   life.
Bible says that human being is a temple of God and the
spirit of God dwelleth in the body and no man can defile the   temple.     Reference   is   made   to  
Chapter   3   verses   16 and 17 of I CORINTHIA NS , which is as below:− “16.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

 Know Ye not that ye are the temple of God, and that the Spirit of God dwelleth in you?
17.   If any man defile  the temple of  God, him   shall   God   destroy;   for   the   temple   of
God is holy, which temple ye are.”    
20. Pope   John   Paul   II  in,   “The   Gospel   of   Life”, denouncing euthanasia writes:
"Laws   which   authorise   and   promote euthanasia   are   therefore   radically  
opposed not only to the good of the individual but also   to   the   common   good;   as  
such   they   are completely   lacking   in   authentic   juridical validity.   Disregarded  
for   the   right   to life,   precisely   because   it   leads   to   the killing   of   the   person  
whom   society   exists to   serve,   is   what   most   directly   conflicts with   the  
possibility   of   achieving   the common   good.   Consequently,   a   civil   law
authorising   euthanasia   ceases   by   that   very fact   to   be   a   true,   morally  
binding   civil law.”
21. The tenets of Jainism also talks about the practice of   religiously   nominated   self−build   death  
called “Sallkhana”, meaning 'fast upto death'.
22. The Buddhist sculpture states that Lord Buddha had also   allowed   self−build   death   for   the  
extremely   ill person as an act of compassion.
23. In different religions and cultures, there are clear injunctions against taking life of oneself.
24. The   petitioner   in   the   Writ   Petition   has categorically   clarified   that   petitioner   is  
neither challenging   the   provisions   of   I.P.C.   by   which   “attempt
to suicide” is made a penal offence nor praying right to die   be   declared   as   fundamental   right  
under   Article   21. It is useful to refer to Para 7 of the Writ Petition, in
which petitioner pleads following:− “It   is   submitted   at   the   outset   that   the petitioner   in   the  
instant   petition   is neither   challenging   the   Section   309   of Indian   Penal   Code,   vide   which  
Attempt   to Suicide   is   a   penal   offence   nor   is   asking right to die per se as a fundamental right
under Article 21 (as the issue is squarely covered   by   the   Constitution   Bench   judgment of   this  
Hon’ble   Court   in   the   case   of  Gian Kaur   vs.   State   of   Punjab   and   in   other connected  
matters,   (1996)   2   SCC   648.    The endeavour of the  Petitioner in the  instant petition   is   to  
seek   guidelines   from   this Hon’ble   Court   whereby   the   people   who   are diagnosed   of  
suffering   from   terminal diseases   or   ailments   can   execute   Living Will   or   give   directives   in
  advance   or otherwise   to   his/her   attorney/executor   to act   in   a   specific   manner   in   the  
event he/she   goes   into   persistent   vegetative state or coma owing to that illness or due
to some other reason.” D. THE RELEVANT PROVISIONS OF IPC
25. The Indian Penal Code, 1860, is a general penal code defining   various   acts   which   are  
offence   and   providing for punishment thereof. Chapter XVI deals with “offences affecting   the  
human   body”.   The   provisions   of   Indian
Penal Code which are relevant in the present context are Section   306   and   Section   309.   SectionCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

  306   relates   to abetment of suicide. It provides “if any person commits suicide,   whoever   abets  
the   commission   of   such   suicide, shall   be   punished   with   imprisonment   of   either
description   for   a   term   which   may   extend   to   ten   years, and   shall   also   be   liable   to  
fine”.   Another   provision which is relevant is Section 309 i.e. attempt to commit suicide.   The  
provision   states,   whoever   attempts   to commit   suicide   and   does   any   act   towards   the  
commission of   such   offence,   shall   be   punished   with   simple
imprisonment for a term which may extend to one year (or
with fine, or with both). The issues which have come up
for consideration in the present case have to be dealt with   keeping   in   view   the   above  
provisions   of   Indian Penal Code which declares certain acts to be offence.
E. LEGISLATION IN REFERENCE TO EUTHANASIA
26. The   only   statutory   provision   in   our   country   which refers   to   euthanasia   is   statutory  
regulations   framed under   Indian   Medical   Council   Act,   1956,   namely   The Indian   Medical  
Council   (Professional   Conduct,   Etiquette &   Ethics)   Regulations,   2002.   Chapter   VI   of   the
Regulations deals with “Unethical Acts”. Regulation 6 is to the following effect:
“6. UNETHICAL ACTS A physician shall not aid or abet or commit any   of   the  
following   acts   which   shall   be construed as unethical− …………… …………… …………
………… 6.7  Euthanasia− Practising euthanasia shall constitute   unethical   conduct.  
However,   on specific   occasion,   the   question   of withdrawing   supporting  
devices   to   sustain cardiopulmonary   function   even   after   brain death,   shall   be  
decided   only   by   a   team   of doctors   and   not   merely   by   the   treating
physician   alone.   A   team   of   doctors   shall declare   withdrawal   of   support  
system.   Such team  shall  consist of the doctor in−charge of   the   patient,   Chief  
Medical Officer/Medical   Officer   in−charge   of   the
hospital and a doctor nominated by the in− charge   of   the   hospital   from   the  
hospital staff or in accordance  with the provisions of the 
Transplantation of Human Organ Act, 1994.”
27. The Law Commission of India had stated and submitted a   detailed   report   on   the   subject   in
  196th  report   on “Medical   Treatment   to   Terminally   Ill   Patients
(Protection of Patients and Medical Practitioners)”. Law Commission   examined   various  
provisions   of   Indian   Penal Code   and   other   statutory   provisions,   judgments   of   this court  
and   different   courts   of   other   countries   and   had
made certain recommendations. A draft bill was also made part   of   the   recommendation.   Draft  
bill   namely   Medical Treatment   to   Terminally   Ill   Patients   (Protection   of
Patients and Medical Practitioners) Bill, 2006, was made part of the report as an Annexure.
28. Chapter   8   of   the   report   contains   summary   of recommendations.   It   is   not   necessary  
to   reproduce   all the recommendations. It is sufficient to refer to para 1
and 2 of the recommendations:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

“...In   the   previous   chapters,   we   have considered   various   important   issues  
on   the subject   of   withholding   or   withdrawing medical   treatment   (including  
artificial nutrition   and   hydration)   from   terminally ill−patients.   In   Chapter  
VII,   we   have considered   what   is   suitable   for   our country.   Various   aspects  
arise   for consideration,   namely,   as   to   who   are competent   and   incompetent  
patients,   as   to what  is meant by ‘informed decision’, what
is meant by ‘best interests’ of a patient, whether   patients,   their   relations   or
doctors   or   hospitals   can   move   a   Court   of law   seeking   a   declaration   that  
an   act   or omission or a proposed act or omission of a doctor   is   lawful,   if   so,  
whether   such decisions   will   be   binding   on   the   parties and   doctors,   in  
future   civil   and   criminal proceedings   etc.   Questions   have   arisen
whether a patient who refuses treatment is guilty   of   attempt   to   commit   suicide  
or whether the doctors are guilty of abetment of   suicide   or   culpable   homicide  
not amounting   to   murder   etc.   On   these   issues,
we have given our views in Chapter VII on a consideration   of   law   and   vast  
comparative literature.
In  this  chapter,  we  propose  to  give  a summary   of   our   recommendations   and  
the corresponding sections of the proposed Bill which   deal   with   each   of   the
recommendations.  (The draft of  the Bill is
annexed to this Report). We shall now refer to our recommendations.
1) There is need to have a law  to  protect patients  who are terminally ill, when  they
take decisions to refuse medical treatment, including   artificial   nutrition   and
hydration,   so   that   they   may   not   be considered   guilty   of   the   offence   of
‘attempt   to   commit   suicide’   under   sec.309 of the Indian Penal Code, 1860.
It   is   also   necessary   to  protect   doctors (and  those  who act  under  their  directions) who   obey
  the   competent   patient’s   informed decision   or   who,   in   the   case   of   (i) incompetent  
patients   or   (ii)   competent patients   whose   decisions   are   not   informed decisions,   and  
decide   that   in   the   best interests   of   such   patients,   the   medical
treatment needs to be withheld or withdrawn as   it   is   not   likely   to   serve   any   purpose.
Such actions of doctors must be declared by statute to be ‘lawful’ in order to protect doctors   and  
those   who   act   under   their directions   if   they   are   hauled   up   for   the offence   of   ‘abetment
  of   suicide’   under sections 305, 306 of the Indian Penal Code, 1860,   or   for   the   offence   of  
culpable homicide   not   amounting   to   murder   under section   299   read   with   section   304   of
  the Penal Code, 1860 or in actions under civil law. 
2)Parliament   is   competent   to   make   such   a law   under   Entry   26   of   List   III   of   the
Seventh   Schedule   of   the   Constitution   of India   in   regard   to   patients   and   medical
practitioners.   The   proposed   law,   in   our view,  should   be     called     ‘The     Medical Treatment
  of   Terminally   Ill   Patients (Protection   of   Patients,   Medical Practitioners) Act.”Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

29. The   196th  Report   was   again   revised   by   the   Law Commission of India in  241st 
Report dated August, 2012. The   2006   draft   bill   was   redrafted   by   Law   Commission which  
was   Annexure   1   to   the   report.   The   above   bill however   could   not   fructify   in   a   law.   The
  Ministry   of health   and   family   welfare   had   published   another   draft bill   namely   The  
Medical   Treatment   of   Terminally   Ill Patients   (Protection   of   Patients   &   Medical
Practitioners)   Bill,   2016,   as   a   private   member   bill which was introduced in Rajya Sabha on 5
th  August 2016, which is still pending.
30. From   the   above,   it   is   clear   that   only   statutory provision   on   euthanasia   is   regulation
  6.7   of   the   2002 Regulations as referred above. The regulations prohibit practicing   euthanasia  
and   declare   that   practicing euthanasia constitute unethical conduct on behalf of the medical  
practitioner.   The   regulation   however   carves   an exception   that   on   specific   occasion,   the  
question   of withdrawing   supporting   devices   to   sustain   cardio− pulmonary   function   even  
after   brain   death,   shall   be decided only by a team of doctors and not merely by the treating  
physician   alone.   The   regulation   further provides   that   team   of   doctors   shall   declare  
withdrawal of support system.
31. The   withdrawal   of   medical   treatment   of   terminally ill   Persons   is   complex   ethical,  
moral  and  social   issue with   which   many   countries   have   wrestled   with   their
attempt to introduce a legal framework for end of life decision   making.   In   absence   of   a  
comprehensive   legal framework on the subject the issue has to be dealt with great caution.
F.  TWO   IMPORTANT   JUDGMENTS   OF   THIS   COURT   ON   THE   SUBJECT:−
32. The   first   important   judgment   delivered   by   the
Constitution Bench of this court touching the subject is the   judgment   of   Constitution   Bench   in
 Gian   Kaur   Vs. State   of   Punjab,   (1996)   2   SCC   648.  In   the   above   case, the   appellants  
were   convicted   under   Section   306   and awarded   sentence   for   abetment   of   commission   of
  suicide by   one   Kulwant   Kaur.   The   conviction   was   maintained   by the   High   Court   against
  which   the   appeal   was   filed   as special   leave   in   this   Court.   One   of   the   grounds   for
assailing   the   conviction   before   this   Court   was   that Section   306     IPC   is   unconstitutional.
 The  reliance   was placed   on   two−Judge   Bench   decision   of   this   court   in
P.Rathinam Vs. Union of India & Anr., (1994) 3 SCC 394,
wherein Section 309 IPC was held to be unconstitutional
as violative of Article 21 of the Constitution.
33. Section   306   was   sought   to   be   declared   as unconstitutional   being   violative   of   Article  
21   of   the Constitution. The Law Commission by its 22nd  report had
recommended for deletion of Section 309 and a Bill was introduced   in   1972   to   amend   the  
Indian   Penal   Code   by deleting   Section   309.   The   Constitution   Bench   dwelt   the question  
as   to   whether   ‘right   to   die’   is   included   in
Article 21. The Constitution Bench concluded that ‘right to   die’   “cannot   be   included   as   part   of
  fundamental rights guaranteed under Article 21”.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

34. The   challenge   to   section   309   on   the   basis   of
Articles 14 and 21 was repelled. This court further held
that Section 306 of Indian Penal Code does not violate
Article 21 and Article 14 of the Constitution of India.
35. The   second   judgment   which   needs   to   be   noted   in detail   is   two−Judge   Bench  
judgment   of   this   court   in Aruna   Ramachandra   Shanbaug   Vs.   Union   of   India   &   Ors.,
(2011)   4   SCC   454.   Writ   Petition   under   Article   32   on behalf   of   Aruna   Ramachandra  
Shanbaug   was   filed   by   one M/s.   Pinky   Virani   claiming   to   be   best   friend.   Aruna
Ramachandra   Shanbaug   was   staff   nurse   working   in   King Edward   Memorial   (KEM)  
Hospital,   Parel,  Mumbai.   On 27.11.1973,   she   was   attacked   by   a   sweeper   of   the hospital  
who   wrapped   a   dog   chain   around   her   neck   and yanked   her   back   with   it.   While  
sodomising   her,   he twisted the chain around her neck, as a result supply of
oxygen to the brain stopped and the brain got damaged.
On the next day she was found in unconscious condition.
From the date of above incident she continued to be in persistent   vegetative   state(PVS)   having  
no   state   of awareness,   she   was   bed−ridden,   unable   to   express herself,   unable   to   think,  
hear   and   see   anything   or communicate   in   any   manner.   In   writ   petition   under
Article 32 it was prayed that the hospital where she is
laying for last 36 years be directed to stop feeding and let   her   die   peacefully.   In   the   above  
case,   Two−Judge Bench   considered   all   aspects   of   euthanasia,   the   court examined   both  
active   and   passive   euthanasia.   Dealing with active and passive euthanasia and further voluntary
and involuntarily euthanasia, following was laid down in para 39 and 40:
“39.  Coming now to the legal issues in this case, it may be noted that euthanasia
is of two types: active and passive. Active euthanasia   entails   the   use   of   lethal
substances or forces to kill a person e.g. a   lethal   injection   given   to   a   person  
with terminal   cancer   who   is   in   terrible   agony. Passive   euthanasia   entails  
withholding   of medical   treatment   for   continuance   of   life e.g.   withholding   of  
antibiotics   where without   giving   it   a   patient   is   likely   to die,   or   removing  
the   heart−lung   machine, from   a   patient   in   coma.   The   general   legal position
  all   over   the   world   seems   to   be that  while  active euthanasia is legal even
without   legislation   provided   certain conditions and safeguards are maintained.”
40.   A   further   categorisation   of euthanasia   is   between   voluntary   euthanasia
and   non−voluntary   euthanasia.   Voluntary euthanasia   is   where   the   consent   is
  taken from   the   patient,   whereas   non−voluntary euthanasia   is   where   the  
consent   is unavailable   e.g.   when   the   patient   is   in coma,   or   is   otherwise  
unable   to   give consent. While there is no legal difficulty
in the case of the former, the latter poses several problems, which we shall address.”
36. The court held that in India, active euthanasia is
illegal and crime. In paragraph 41, following was held: Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

“41.   As   already   stated   above   active euthanasia   is   a   crime   all   over   the  
world except   where   permitted   by   legislation.   In India   active   euthanasia   is  
illegal   and   a crime   under   Section   302   or   atleast   under Section   304   of   the  
Penal   Code,   1860.
Physician−assisted suicide is a crime under Section   306   IPC   (abetment   to  
suicide).
Active   euthanasia   is   taking   specific   steps to   cause   the   patient’s   death,   such
  as injecting   the   patient   with   some   lethal substance   e.g.   sodium   pentothal  
which causes   a   person   deep   sleep   in   a   few
seconds, and the person instantaneously and painlessly dies in this deep sleep.”
37. The   court   noticed   various   judgments   of   different countries   in   the   above  
context.   Two−Judge   Bench   also
referred to Constitution Bench judgment in Gian Kaur Vs.
State of Punjab. In Para 101 and 104, following has been laid down:
“101. The Constitution Bench of the Supreme Court in  Gina Kaur V. State of Punjab 
held that   both   euthanasia   and   assisted   suicide are   not   lawful   in   India.   That
  decision overruled   the   earlier   two−Judge   Bench
decision of the Supreme Court in P.Rathinam
V. Union of India. The Court held that the right   to   life   under   Article   21   of   the
Constitution  does not include the right to die.   In  Gian   Kaur   case  the   Supreme  
Court approved   of   the   decision   of   the   House   of Lords   in  Airedale   case  and  
observed   that euthanasia   could   be   made   lawful   only   by legislation.
104. It may be noted that in Gian Kaur Case although  the Supreme  Court 
has quoted with approval the view of the House of Lords in
Airedale case, it has not clarified who can decide   whether   life   support   should   be
discontinued  in the case of an  incompetent person   e.g.   a   person   in   coma   or  
PVS.   This vexed   question   has   been   arising   often   in India   because   there   are
  a   large   number   of cases where persons go into coma(due to an
accident or some other reason) or for some other   reason   are   unable   to   give  
consent, and   then   the   question   arises   as   to   who
should give consent for withdrawal of life support.   This   is   an   extremely  
important question   in   India   because   of   the unfortunate   low   level   of   ethical  
standards to which our society has descended, its raw and   widespread  
commercialisation,   and   the rampant   corruption,   and   hence,   the   Court has   to
  be   very   cautious   that   unscrupulous persons who wish to inherit the property of
someone may not get him eliminated by some crooked method.” 
38. Two−Judge Bench noticed that there is no statutory
provision in this country as to the legal procedure to withdraw   life   support   to   a  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

person   in   Persistent Vegetative   State   (PVS)   or   who   is   otherwise  
incompetent to   take   the   decision   in   this   connection.   The   court, however,  
issued   certain   directions   which   were   to
continue to be the law until Parliament makes a law on
this subject. In paragraph 124, following has been laid down: − “124.   There   is   no  
statutory   provision   in our   country   as   to   the   legal   procedure   for
withdrawing life support to a person in PVS or   who   is   otherwise   incompetent   to
  take   a decision  in this  connection. We agree with Mr.   Andhyarujina   that  
passive   euthanasia should   be   permitted   in   our   country   in certain   situations,  
and   we   disagree   with the learned Attorney General that it should never   be  
permitted.   Hence,   following   the technique   used   in  Vishaka   case,  we   are
laying   down   the   law   in   this   connection which   will   continue   to   be   the   law
  until Parliament makes a law on the subject:
(i) A   decision   has   to   be   taken   to discontinue life support either by the parents  
or   the   spouse   or   other   close relatives, or in the absence of any of
them, such a decision can be taken even by a person or a body of persons acting
as a next friend. It can also be taken by   the   doctors   attending   the   patient.
However,   the   decision   should   be   taken bona  fide in  the  best interest  of the patient. 
In   the   present   case,   we   have already   noted   that   Aruna   Shanbaug’s parents   are   dead   and
  other   close relatives   are   not   interested   in   her ever   since   she   had   the   unfortunate
assault on her. As already noted above, it is the KEM hospital staff, who have been   amazingly  
caring   for   her   day   and night   for   so   many   long   years,   who really   are   her   next   friends,  
and   not Ms.   Pinki   Virani   who   has   only   visited her on few occasions and written a book on  
her.   Hence   it   is   for   the   KEM Hospital   staff   to   take   that   decision.
KEM   Hospital   staff   have   clearly expressed   their   wish   that   Aruna
Shanbaug should be allowed to live. 
Mr.   Pallav   Shishodia,   learned Senior Counsel, appearing for the Dean, KEM   Hospital,  
Mumbai,   submitted   that Ms. Pinki Virani has no locus standi in this   case.   In   our   opinion   it  
is   not necessary   for   us   to   go   into   this question   since   we   are   of   the   opinion that  it  is 
the  KEM  Hospital  staff who is   really   the   next   friend   of   Aruna Shanbaug. 
We   do   not   mean   to   decry   or disparage   what   Ms.   Pinki   Virani   has done.   Rather,   we  
wish   to   express   our appreciation   of   the   splendid   social spirit  she  has  shown. We  have seen 
on the   internet   that   she   has   been espousing   many   social   causes,   and   we hold   her   in  
high   esteem.   All   that   we wish   to   say   is   that   however   much   her interest   in   Aruna  
Shanbaug   may   be   it cannot match the involvement of the KEM Hospital   staff   who   have   been
  taking care   of   Aruna   day   and   night   for   38 years.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

However,   assuming   that   the   KEM Hospital   staff   at   some   future   time changes   its   mind,  
in   our   opinion   in such   a   situation   KEM   Hospital   would
have to apply to the Bombay High Court for   approval   of   the   decision   to withdraw life support.
(ii) Hence,  even  if  a decision is  taken  by the   near   relatives   or   doctors   or   next
friend to withdraw life support, such a decision   requires   approval   from   the High   Court  
concerned   as   laid   down   in Airedale case.
In our opinion, this is even more necessary   in   our   country   as   we   cannot rule   out   the  
possibility   of   mischief being   done   by   relatives   or   others   for inheriting   the   property   of  
the patient.” G. LAW ON SUBJECT IN OTHER COUNTRIES
39. The   debate   on   Euthanasia   had   gathered   momentum   in last   100   years.   The   laws   of  
different   countries expresses thoughts of people based on different culture,
philosophy and social conditions.   Assisted suicide was
always treated as an offence in most of the countries.
Physician assisted suicide is also not accepted in most
of the countries except in few where it gain ground in
last  century.  In several countries including different
States of U.S.A., European Countries and United Kingdom,
various legislations have come into existence codifying different   provisions   pertaining   to  
physician   assisted suicide.   The right to not commence or withdraw medical treatment   in   case  
of   terminally   ill   or   PSV   patients, advance   medical   directives   have   also   been  made   part  
of different legislations in different countries.
40. Physician assisted suicide has not been accepted by many countries. 
 However, few have accepted it and made necessary   legislation   to   regulate   it.   Switzerland,
Netherlands, Belgium, Luxembourg, and American States of Oregan,   Washington,   Montana   and  
Columbia   has   permitted physician   assisted   suicide   with   statutory   regulations.
Courts in different parts of the world have dealt with
the subject in issue in detail.  It is not necessary to refer   to   different   legislation   of   different  
countries and the case law on subject of different countries.  For the   purposes   of   this   case,   it  
shall   be   sufficient   to notice   few   leading   cases   of   United   Kingdom,   United
States Supreme Court and few others countries. United Kingdom 
41. Euthanasia   is   criminal   offence   in   the   United Kingdom. 
 According to Section 2(1) of the Suicide Act, 1961, a person assisting an individual, who wish to die
commits an offence. The provision states that it is an
offence to aid, abet, counsel or procure the suicide of another   or   an   attempt   by   another   to  
commit   suicide, however, it is not a crime if it is by their own hands. There   has   been   large  
parliamentary   opposition   to   the current   United   Kingdom   Law   concerning   assisted   suicide
but there has been no fundamental change in the law so
far.  In 1997, the Doctor Assisted Dying Bill as well as in   2000,   the   Medical   Treatment  
(Prevention   of Euthanasia) Bill were not approved.  The most celebratedCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

judgment of the House of Lords is  Airedale N.H.S. Trust Vs. Bland, (1993) A.C. 789.
42. Anthony David Bland was injured on 15 th  April, 1989 at   the   Hillsborough   football   ground  
in   which   his   lungs were crushed and punctured, the supply of oxygen to the brain   was  
interrupted.   As   a   result,   he   sustained catastrophic   and   irreversible   damage   to   the   higher
centres of the brain, which had left him in a condition
known as a persistent vegetative state(P.V.S.). Medical opinion   was   unanimous   that   there   was  
no   hope   of improvement   in   his   condition   or   recovery.   At   no   time
before the disaster had the patient indicated his wishes
if he should find himself in such a condition. Bland's
father sought declarations that Hospital authorities may discontinue   all   his   life−sustaining  
treatment   and medical   support   measures   and   further   lawfully discontinue   and   thereafter  
need   not   furnish   medical treatment to the patient except for the sole purpose of
enabling the patient to end his life and die peacefully with   the   greatest   dignity   and   the   least  
of   pain, suffering and distress.
43. The lower court granted the declarations sought for.
The court of appeal upheld the order. Official Solicitor filed   an   appeal   before   the   House   of  
Lords.    Lord   Goff held that it is not lawful for a doctor to administer a drug   to   his   patient   to  
bring   about   his   death,   even though that course is prompted by a humanitarian desire
to end his suffering. Such act is actively causing death i.e.   euthanasia   which   is   not   lawful.     It  
was   further held that a case in which doctor decides not to provide or   continue   to   provide  
treatment   or   care,   it   may   be lawful. Following was stated by Lord Goff:
“First,   it   is   established   that   the principle   of   self−determination   requires
that respect must be given to the wishes of the patient, so that if an adult patient of
sound   mind   refuses,   however   unreasonably, to   consent   to   treatment   or   care
  by   which his   life   would   or   might   be   prolonged,   the
doctors responsible for his care  must give effect   to   his   wishes   even   though  
they   do not consider it to be in his best interests to do so...........
To   this   extent,   the   principle   of   the sanctity   of   human   life   must   yield   to  
the principle   of   self−determination(see   ante, pp.826H−827A,   per   Hoffmann  
L.J.),   and,   for present   purposes   perhaps   more   important, the   doctor’s   duty  
to   act   in   the   best interests   of   his   patient   must   likewise   be
qualified. On this basis, it has been held that   a   patient   of   sound   mind   may,   if
properly   informed,   require   that   life support   should   be   discontinued:   see  
Nancy B. v. H”tel−Dieu de Quebec (1992) 86 D.L.R. (4th)   385.   Moreover   the  
same   principle applies where the patient's refusal to give his   consent   has   been  
expressed   at   an earlier   date,   before   he   became   unconscious
or otherwise incapable of communicating it;
though   in   such   circumstances   especial   care may   be   necessary   to   ensure   that   the   prior
refusal of consent is still properly to be regarded as applicable in the circumstances which   have  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

subsequently   occurred:   see, e.g., In re T.(Adult: Refusal of Treatment)
(1993) Fam.95. I wish to add that, in cases of this kind, there is   no question of the patient   having  
committed   suicide,   nor therefore   of   the   doctor   having   aided   or
abetted him in doing so. It is simply that the   patient   has,   as   he   is   entitled   to   do, declined   to
  consent   to   treatment   which might   or   would   have   the   effect   of
prolonging his life, and the doctor has, in accordance with his duty, complied with his
patient's wishes................
I must however stress, at this point, that the law draws a crucial distinction between cases   in  
which   a   doctor   decides   not   to provide, or to continue to provide, for his patient   treatment   or
  care   which   could   or might prolong his life, and those in which
he decides, for example by administering a lethal   drug,   actively   to   bring   his
patient's life to an end. As I have already indicated, the former may be lawful, either
because the doctor is giving effect to his patient's   wishes   by   withholding   the treatment   or  
care,   or   even   in   certain circumstances in which (on principles which I   shall   describe)   the  
patient   is incapacitated   from   stating   whether   or   not he gives his consent. But it is not lawful
for   a   doctor   to   administer   a   drug   to   his patient   to   bring   about   his   death,   even though
  that   course   is   prompted   by   a humanitarian   desire   to   end   his   suffering, however   great  
that   suffering   may   be:   see Reg.   v.   Cox   (unreported),   18   September, 1992.   So   to   act   is  
to   cross   the   Rubicon which runs between on the one hand the care
of the living patient and on the other hand euthanasia−actively   causing   his   death   to avoid   or  
to   end   his   suffering.   Euthanasia is   not   lawful   at   common   law.   It   is   of course   well  
known   that   there   are   many responsible   members   of   our   society   who believe   that  
euthanasia   should   be   made lawful;   but   that   result   could,   I   believe, only   be   achieved   by  
legislation   which expresses   the   democratic   will   that   so
fundamental a change should be made in our law, and can, if enacted, ensure that such legalised  
killing   can   only   be   carried   out subject   to   appropriate   supervision   and
control.................................. At   the   heart   of   this   distinction   lies   a theoretical   question.   Why
  is   it   that   the doctor   who   gives   his   patient   a   lethal injection   which   kills   him   commits  
an unlawful   act   and   indeed   is   guilty   of murder,   whereas   a   doctor   who,   by discontinuing  
life   support,   allows   his patient   to   die,   may   not   act   unlawfully   –
and will not do so, if he commits no breach of duty to his patient ?”
44. Lord   Browne−Wilkinson  in   his   judgment   noticed   the
following questions raised in the matter:
"(1)   lawfully   discontinue   all   life− sustaining   treatment   and   medical   support
measures designed to keep (Mr. Bland) alive in his existing persistent vegetative state
including   the   termination   of   ventilation, nutrition   and   hydration   by   artificial
means; and  (2)   lawfully   discontinue   and   thereafter need  not furnish 
medical treatment to (Mr. Bland)   except   for   the   sole   purpose   of enabling   (Mr.
  Bland)   to   end   his   life   and die   peacefully   with   the   greatest   dignity and   the
  least   of   pain,   suffering   and distress.”
Answering the questions following was held:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

"Anthony   Bland   has   been   irreversibly   brain damaged;   the   most  
distinguished   medical opinion   is   unanimous   that   there   is   no prospect   at   all  
that   the   condition   will change   for   the   better.   He   is   not   aware   of anything.
  If   artificial   feeding   is discontinued   and   he   dies,   he   will   feel nothing.  
Whether   he   lives   or   dies   he   will feel   no   pain   or   distress.   All   the   purely
physical considerations indicate that it is pointless to continue life support. Only if
the   doctors   responsible   for   his   care   held the   view   that,   though   he   is  
aware   of nothing,   there   is   some   benefit   to   him   in staying   alive,   would  
there   be   anything   to indicate   that   it   is   for   his   benefit   to
continue the.................. 
In   these   circumstances,   it   is   perfectly reasonable   for   the   responsible   doctors
  to conclude   that   there   is   no   affirmative benefit to 
Anthony Bland in continuing  the invasive   medical   procedures   necessary   to
sustain his life. Having so concluded, they are   neither   entitled   nor   under   a   duty
  to continue   such   medical   care.   Therefore   they will   not   be   guilty   of   murder
  if   they discontinue such care.”
45. Another judgment which needs to be noticed is Ms. B
Vs. An NHS Hospital Trust, 2002 EWHC 429.  The claimant, Ms.   B   has   sought   declaration  
from   the   High   Court   that the invasive treatment which is currently being given by the  
respondent   by   way   of   artificial   ventilation   is   an
unlawful trespass. The main issue raised in the case is as   to   whether   Ms.   B   has   the   capacity  
to   make   her   own decision about her treatment in hospital. Ms. B, aged 43 years,   had   suffered  
a   devastating   illness   which   has caused   her   to   become   tetraplegic   and   whose   expressed
wish is not to be kept artificially alive by the use of a   ventilator.   The   High   Court   in   the   above  
context examined   several   earlier   cases   on   the   principle   of autonomy.     Paragraphs   16   to  
22   are   to   the   following effect:
“16. In 1972 Lord Reid in S v McC: W v W [1972] AC 25 said, at page 43:
“…English   law   goes   to   great   lengths   to protect   a   person   of   full   age   and  
capacity from   interference   with   his   personal liberty.   We   have   too   often   seen
  freedom disappear   in   other   countries   not   only   by coups   d’état   but   by  
gradual   erosion:   and often it is the first step that counts. So it   would   be   unwise  
to   make   even   minor concessions.”
17.   In  re   F   (Mental   Patient:
Sterilisation)  [1990] 2 AC 1, Lord Goff of Chieveley said at page 72:
“I   start   with   the   fundamental   principle, now   long   established,   that   every  
person’s body is inviolate.”Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

18.   Lord   Donaldson   of   Lymington,   MR said in
 re T (Adult: Refusal of Treatment) [1993] Fam 95, at page 113:
“…. . the patient’s right of choice exists whether the reasons for making that choice
are   rational,   irrational,   unknown   or   even non−existent.”
19.   In  re   T   (Adult:   Refusal   of Treatment), I cited Robins JA in  Malette v
Shulman  67   DLR   (4th)   321   at   336,   and   said at page 116−117:
“The right to determine what shall be done with one’s own body is a
fundamental right in our society.
The   concepts   inherent   in   this right   are   the   bedrock   upon   which the  
principles   of   self− determination   and   individual autonomy   are   based.   Free
individual   choice   in   matters affecting this right should, in my opinion,   be  
accorded   very   high priority.”
20. In re MB (Medical Treatment) [1997] 2 FLR 426, I said at 432:
“A mentally competent patient has an   absolute   right   to   refuse   to consent   to  
medical   treatment   for any   reason,   rational   or irrational,   or   for   no   reason   at
all, even where that decision may lead   to   his   or   her   own   death”, (referring   to
 Sidaway   v   Board   of Governors   of   the   Bethlehem   Royal
Hospital and the Maudsley Hospital [1985] AC  871, per Lord Templeman at 904−
905; and to Lord Donaldson M.R.   in  re   T   (Adult:  Refusal   of
Treatment) (see above)).
21. This approach is identical with the jurisprudence in other parts of the world.
In  Cruzan   v   Director,   Missouri   Department of Health (1990) 110 S. Ct 2841, the United
States Supreme Court stated that:
“No   right   is   held   more   sacred,   or   is   more carefully guarded… 
than the right of every individual to the possession and control of
his own person, free from all restraint or interference of others, unless by clear and
unquestionable authority of law.” b. The sanctity of life
22. Society and the medical profession in   particular   are   concerned   with   the
equally   fundamental   principle   of   the sanctity of life. The interface between the
two principles  of autonomy  and sanctity of life   is   of   great   concern   to   the  
treating clinicians in the present case. Lord Keith of   Kinkel   in  Airedale   NHS  
Trust   v   Bland [1993] AC 789, said at page 859:Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

“.. the principle of the sanctity of   life,   which   it   is   the   concern
of the state, and the judiciary as one of the arms of the state, … is not   an   absolute  
one.   It   does   not compel   a   medical   practitioner   on pain   of   criminal  
sanctions   to treat   a   patient,   who   will   die   if he   does   not,   contrary   to   the
express wishes of the patient.””
46. The   judgment   of   House   of   Lords   in  Regina   (Pretty)
Vs. Director of Public Prosecutions (Secretary of State for   the   Home   Department  
intervening),(2002)   1   AC   800, also needs to be referred to. The claimant, who suffered from   a  
progressive   and   degenerative   terminal   illness, faced   the   imminent   prospect   of   a  
distressing   and humiliating death. She was mentally alert and wished to control   the   time   and  
manner   of   her   dying   but   her physical disabilities prevented her from taking her life
unaided. She wished her husband to help her and he was willing   to   do   so   provided   that   in   the
  event   of   his giving such assistance he would not be prosecuted under Section   2(1)   of   the  
Suicide   Act,   1961.   The   claimant accordingly   requested   the   Director   of   Public Prosecutions  
to   undertake  that   he  would   not   consent   to
such a prosecution under Section 2(4). On his refusal to give   that   undertaking   the   claimant,   in  
reliance   on rights   guaranteed   by   the   European   Convention   for   the Protection   of   Human  
Rights   and   Fundamental   Freedoms   as Schedule to the Human Rights Act, 1998, sought relief by
way of judicial review.
47. The Divisional Court of the Queen's Bench Division concluded   that   the   Director   has   no  
power   to   give   an undertaking and dismissed the claim. The House of Lords again   reiterated   the
  distinction   between   the   cessation of   life−saving   or   life−prolonging   treatment   on   the   one
hand   and   the   taking   of   action   intended   solely   to terminate   life   on   the   other.   In  
paragraph   9   of   the judgment following was held:
“9. In   the   Convention   field   the authority   of   domestic   decisions   is necessarily
  limited   and,   as   already   noted, Mrs   Pretty   bases   her   case   on   the
Convention.   But   it   is   worthy   of   note   that her   argument   is   inconsistent  
with   E   two principles   deeply   embedded   in   English   law. The   first   is   a  
distinction   between   the taking   of   one's   own   life   by   one's   own   act and   the  
taking   of   life   through   the intervention   or   with   the   help   of   a   third party.  
The   former   has   been   permissible since suicide ceased to be a crime in 1961.
The latter  has continued to be  proscribed. The   distinction   was   very   clearly  
expressed by   Hoffmann   LJ   in   Airedale   NHS   Trust   v
Bland [1993] AC 789, 831:F  "No one in this case is suggesting
that Anthony Bland should be given a   lethal   injection.   But   there   is concern  
about   ceasing   to   supply food   as   against,   for   example,
ceasing to treat an infection with antibiotics.   Is   there   any   real distinction?   In  
order   to   come   to terms with our intuitive feelings about   whether   there   is   a
distinction,   I   must   start   by considering   why   most   of   us   would be   appalled  
if   he   was   given   a lethal injection. It is, I think, connected   with   our   view   that  
the sanctity   of   life   entails   its inviolability   by   an   outsider.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Subject   to   exceptions   like   self− defence,   human   life   is   inviolate
even if the person in question has consented   to   its   violation.   That is   why  
although   suicide   is   not   a crime, assisting someone to commit
suicide is. It follows that, even if   we   think   Anthony   Bland   would have  
consented,   we   would   not   be entitled   to   end   his   life   by   a lethal injection." 
The   second   distinction   is   between   the cessation of life−saving or life−prolonging
treatment on the one hand and the taking of action   lacking   medical,   therapeutic  
or palliative   justification   but   intended solely to terminate life on the other. This
distinction   provided   the   rationale   of   the decisions in Bland. It 
was very succinctly expressed in the Court of Appeal In re] (A
Minor) (Wardship: Medical Treatment) [1991] Fam   33,   in   which   A   Lord  
Donaldson   of Lymington MR said, at p 46: 
"What   doctors   and   the   court   have to decide is whether, in the best
interests of the child patient, a particular decision as to medical
treatment should be taken which as a   side   effect   will   render   death
more or less likely. This is not a matter   of   semantics.   It   is fundamental.   At   the  
other   end   of the age spectrum, the use of drugs to reduce pain will often be fully 8  
justified,   notwithstanding   that this   will   hasten   the   moment   of
death. What can never be justified is   the   use   of   drugs   or   surgical procedures  
with   the   primary purpose of doing so."
United States of America
48. The   State   of   New   York   in   1828   enacted   a   statute
declaring assisted suicide as a crime. New York example was followed by different other States.
49. Cardozo, J., about a century ago in Schloendroff Vs. Society   of   New   York   Hospital,   211  
N.Y.   125,  while   in Court   of   Appeal   had   recognised   the   right   of   self−
determination by every adult human being. Following was held:
"Every human being of adult years and sound
mind has a right to determine what shall be done   with   his   own   body;   and   a  
surgeon   who performs an operation without his patient's
consent commits an assault, for which he is liable   in   damages.  Pratt   v.   Davis,  
224 Ill.,   300,   79   N.E.   562,   7   L.R.A.   (N.S.)
609, 8 Ann. Cas, 197: Mohr v. Williams, 95
Minn. 261, 104 N.W. 12.1 L.R. A.(N.S.), 111 Am. St. Rep. 462, 5 Ann. Cas, 303.  This is
true, except in cases of emergency where the patient   is   unconscious,   and   where  
it   is necessary   to   operate   before   consent   can   be obtained.”   
50. Supreme Court of United States of America in  Nancy
Beth Cruzan Vs. Director, Missouri Department of Health, 497   U.W.   261,    had   occasion   to  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

consider   a   case   of patient   who   was   in   persistent   vegetative   state,   her
guardian brought a declaratory judgment seeking judicial
sanction to terminate artificial hydration and nutrition
of patient. The Supreme Court recognised right possessed by   every   individual   to   have   control  
over   own   person. Following was held by Rehnquist, CJ:
"At   common   law,   even   the   touching   of one   person   by   another   without  
consent   and without   legal   justification   was   a   battery. See  W.   Keeton,  
D.Dobbs,   R.   Keeton,   &   D. Owen,   Prosser   and   Keeton   on   Law   of   Torts,
9, pp.39−42 (5th  ed. 1984).  Before the turn of   the   century,   this   Court   observed
  that “no   right   is   held   more   sacred,   or   is   more carefully guarded, 
by the common  law, than the   right   of   every   individual   to   the possession   and  
control   of   his   own   person, free  from all restraint or interference of others,  
unless   by   clear   and   unquestionable authority of law.”  Union Pacific R. Co. v.
Botsford, 141 U.S. 250, 251, 11 S.Ct. 1000, 1001,   35   L.Ed.   734   (1891).  This  
notion   of bodily   integrity   has   been   embodied   in   the requirement   that  
informed   consent   is generally   required   for   medical   treatment. Justice  
Cardozo,   while   on   the   Court   of Appeals   of   New   York,   aptly   described   this
doctrine: “Every human being of adult years and   sound   mind   has   a   right   to  
determine what shall be done with his own body; and a surgeon   who   performs   an  
operation   without his   patient's   consent   commits   an   assault, for   which   he   is  
liable   in   damages,” Schloendorff   v.   Society   of   New   York Hospital,   211   N.Y.  
125,   129−130,   105   N.E. 92,   93   (1914).  The   informed   consent doctrine   has  
become   firmly   entrenched   in American   tort   law.   See  Keeton,   Dobbs, Keeton,  
&   Owen,   supra,   32,   pp.189−192;   F. Rozovsky, Consent to Treatment,
 A Practical Guide 1−98 (2d ed. 1990).
The   logical   corollary   of   the   doctrine of   informed   consent   is   that   the  
patient generally   possesses   the   right,   not   to
consent, that is, to refuse treatment.”
51. Referring   to   certain   earlier   cases   following   was held:
“Reasoning   that   the   right   of   self− determination   should   not   be   lost   merely
because an individual is unable to sense a violation   of   it,   the   court   held   that
incompetent   individuals   retain   a   right   to
refuse treatment. It also held that such a right   could   be   exercised   by   a  
surrogate decision   maker   using   a   “subjective”
standard when there was clear evidence that
the incompetent person would have exercised it.   Where   such   evidence   was  
lacking,   the court held that an individual's right could still   be   invoked   in   certain
  circumstances under   objective   “best   interest”   standards. Id.,   at   361−368,  
486   A.2d,   at   1229−1233.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Thus,   if   some   trustworthy   evidence   existed that   the   individual   would   have  
wanted   to terminate   treatment,   but   not   enough   to clearly   establish   a  
person's   wishes   for purposes   of   the   subjective   standard,   and the   burden   of  
a   prolonged   life   from   the experience   of   pain   and   suffering   markedly
outweighed   its   satisfactions,   treatment could   be   terminated   under   a  
“limited− objective”   standard.   Where   no   trustworthy evidence   existed,   and   a  
person's   suffering would   make   the   administration   of   life− sustaining  
treatment   inhumane,   a   “pure− objective”   standard   could   be   used   to
terminate   treatment.   If   none   of   these conditions obtained, the  court  held it 
was best   to   err   in   favour   of   preserving   life.
Id., at 364−368, 486 A.2d, at 1231−1233.” 
In the facts of the above case, the claim of parents of   Cruzan   was   refused   since  
guardian   could   not satisfactorily  prove that Cruzan had expressed her wish not   to
  continue   her   life   under   circumstances   in   which she drifted. 
52. All   different   aspects   of   euthanasia   were   again considered   by   the   United  
States   Supreme   Court   in Washington, Et Al,, Vs. Harold Glucksberg Et Al, 521 US
702 equivalent to 138 L.Ed 2d 772.  A Washington    State statute   enacted   in   1975  
provided   that   a   person   was
guilty of the felony of promoting a suicide attempt when the   person   knowingly  
caused   or   aided   another   person   to attempt   suicide.   An   action   was   brought
  in   the   United States   District   Court   for   the   Western   District   of Washington
  by   several   plaintiffs,   among   whom   were   (1) physicians   who   occasionally  
treated   terminally   ill, suffering patients, and (2) individuals who were then in
the terminal phases of serious and painful illness. The plaintiffs,   asserting   the  
existence   of   a   liberty interest   protected   by   the   Federal   Constitution's
Fourteenth Amendment which extended to a personal choice
by a mentally competent, terminally ill adult to commit physician−assisted   suicide,  
sought   a   declaratory judgment   that   the   Washington   Statute   was
unconstitutional   on   its   face.   The   District   Court,
granting motions for summary judgment by the physicians and   the   individuals,  
ruled   that   the   statute   was unconstitutional   because   it   placed   an   undue  
burden   on the   exercise   of   the   asserted   liberty   interest   (850   F Supp   1454,  
1994   US   Dist   LEXIS   5831).   On   appeal,   the United   States   Court   of   Appeals
  for   the   Ninth   Circuit, expressed the view that (1) the Constitution encompassed a
 due  process  liberty  interest   in  controlling  the  time and   manner   of   one's  
death;   and   (2)   the   Washington Statute   was   unconstitutional   as   applied   to  
terminally ill, competent adults who wished to hasten their deaths with   medication  
prescribed   by   their   physicians   (79   F3d 790, 1996 US App LEXIS 3944).
53. On   certiorari,   the   United   States   Supreme   Court reversed.   In   an   opinion  
by  Rehnquist,   C.J.,   joined   by
O'Connor, Scalia, Kennedy, and Thomas, JJ., it was held that   the   Washington  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Statute   did   not   violate   the   due process clause−
 either on the Statute's face or as the
Statute was applied to competent, terminally ill adults who   wished   to   hasten  
their   deaths   by   obtaining medication prescribed by their physicians – because (1)
pursuant   to   careful   formulation   of   the   interest   at stake,   the   question   was  
whether   the   liberty   specially
protected by the due process clause included a right to commit   suicide   which   itself
  included   a   right   to assistance   in   doing   so;   (2)   an   examination   of   the
nation's   history,   legal   traditions,   and   practices revealed   that   the   asserted  
right   to   assistance   in committing   suicide   was   not   a   fundamental   liberty
interest   protected   by   the   due   process   clause;   (3)   the asserted   right   to  
assistance   in   committing   suicide   was
not consistent with the Supreme Court's substantive due process   line   of   cases;  
and   (4)   the   State's   assisted suicide   ban   was   at   least   reasonably   related   to  
the promotion   and   protection   of   a   number   of   Washington's
important and legitimate interests.
54. The   US   Supreme   Court   held   that   Washington   statute did   not   violate  
the   due   process   clause.  CJ,   Rehnquist while   delivering   the   opinion   of   the  
Court   upheld   the State's ban on assisted suicide to the following effect:
"...In   almost   every   State−indeed,   in   almost every   western   democracy−it   is   a
  crime   to assist   a   suicide.   The   States'   assisted− suicide   bans   are  
longstanding   expressions of the States' commitment to the protection
and preservation of all human life. Cruzan, supra,   at   280,   111   L.Ed   2d   224,  
110   S   Ct 2841  (“The   States−indeed,   all   civilized nations−demonstrate   their  
commitment   to life   by   treating   homicide   as   a   serious crime. Moreover, the 
majority of  States in this   country   have   laws   imposing   criminal penalties   on  
one   who   assists   another   to commit suicide”); see Stanford v. Kentucky,
492 US 3561, 373, 106 L ED 2d 306, 109 S Ct
2969 (1989) (“The primary and most reliable indication   of   a   national   consensus  
is   ... the   pattern   of   enacted   laws”).   Indeed, opposition   to   and   condemnation
  of   suicide− and,   therefore,   of   assisting   suicide−are consistent   and   enduring  
themes   of   our philosophical,   legal,   and   cultural heritages.”
55. Another judgment of US Supreme Court which needs to be   noted   is  Dennis   C.
  Vacco,   Attorney   General   of   New
York, Et Al. Vs. Timothy E. Quill Et Al, 521 US 793. New York   state   law   as   in  
effect   in   1994   provided   that   a
person who intentionally caused or aided another person
to attempt or commit suicide was guilty of felony; but under   other   statutes,   a  
competent   person   could   refuse even   life−saving   medical   treatment.   Plaintiff  
sought declaratory   relief   and   injunctive   against   the enforcement   of   criminal  
law   asserting  that   such   law   is violative   of   statutes   of   the   Federal  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Constitution Fourteenth Amendment.
56. Rehnquist,   CJ.  in   his   opinion   again   upheld
distinction between assisted suicide and withdrawing  of
life sustaining treatment. Following was laid down:
"[1d]  The   Court   of   Appeals,   however, concluded   that   some   terminally   ill  
people− those   who   are   on   life   support   systems−are
treated differently from those who are not, in   that   the   former   may   “hasten  
death”   by ending   treatment,   but   the   latter   may   not “hasten   death”   through  
physician−assisted suicide.   80   F.3d,   at   729.   This   conclusion depends   on   the  
submission   that   ending   or refusing   lifesaving   medical   treatment   “is nothing  
more   nor   less   than   assisted suicide.”   Ibid.   Unlike   the   Court   of Appeals,   we
  think   the   distinction   between assisting   suicide   and   withdrawing   life−
sustaining   treatment,   a   distinction   widely recognised   and   endorsed   in   the  
medical profession and  in our legal traditions, is
both important and logical; it is certainly rational...
The   distinction   comports   with fundamental   legal   principles   of   causation and  
intent.   First,   when   a   patient   refuses life−sustaining   medical   treatment,   he  
dies from   an   underlying   fatal   disease   or pathology; but  if a patient ingests lethal
medication prescribed by a physician, he is killed by that medication....
Furthermore, a physician who withdraws, or   honors   a   patient's   refusal   to  
begin, life−sustaining   medical   treatment purposefully   intends,   or   may   so  
intend, only   to   respect   his   patient's   wishes   and “to   cease   doing   useless   and
  futile   or degrading   things   to   the   patient   when   the patient   no   longer  
stands   to   benefit   from them.”  
57. However,   there   are   four   States   which   have   passed legislation   permitting  
euthanasia.   These   States   include Oregon, Washington, Missouri and Texas. 
Canada
58. Section   241(b)   of   the   Criminal   Code   provides   that everyone   who   aids  
or   abets   a   person   in   committing suicide commits an indictable offence. In
 Rodriguez Vs. British   Columbia   (Attorney   General),   1993   (3)   SCR   519,
the Supreme Court of Canada has considered the issue of
assisted suicide. A 42 year old lady who was suffering from   an   incurable   illness  
applied   before   the   Supreme Court   of   British   Columbia   for   an   order   that  
Section 241(b)   which   prohibits   giving   assistance   to   commit suicide,   be  
declared   invalid.   The   application   was
dismissed and the matter was taken to the Supreme Court
of Canada which held that prohibition of Section 241(b) which   fulfils   the  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

government's   objective   of   protecting the     vulnerable,   is   grounded   in   the  
State   interest   in protecting   life   and   reflects   the   policy   of   the   State that  
human   life   should   not   be   depreciated   by   allowing life to be taken.
Switzerland
59. In Switzerland the assisted suicide is allowed only
for altruistic reasons. A person is guilty and deserved to   be   sentenced   for  
imprisonment   on   assisted   suicide when   he   incites   someone   to   commit  
suicide   for   selfish reasons.
Netherlands
60. The   Netherlands   has   the   most   experience   with physician−hastened   death.
  Both   euthanasia   and   assisted suicide   remain   crimes   there   but   doctors   who
  end   their patients'   lives   will   not   be   prosecuted   if   legal
guidelines are followed. Among the guidelines are:
31. The   request   must   be   made   entirely   of   the   patient's own free will.
32. The patient must have a long−lasting desire for death.
33. The   patient   must   be   experiencing   unbearable   suffering.
34. There   must   be   no   reasonable   alternatives   to  
relative suffering other than euthanasia.
35. The   euthanasia   or   assisted   suicide   must   be   reported to the coroner.
61. The   above   discussion   clearly   indicates   that   pre−
dominant thought as on date prevailing in other part of
the World is that assisted suicide is a crime. No one is
permitted to assist another person to commit suicide by injecting   a   lethal   drug   or
  by   other   means.   In   India,
Section 306 of the Indian Penal Code specifically makes
it an offence. The Constitution Bench of this Court in Gian Kaur (supra)
 has already upheld the constitutional validity   of   Section   306,   thus,   the   law   of
  the   land   as existing   today   is   that   no   one   is   permitted   to   cause death   of  
another   person   including   a   physician   by administering  any  lethal   drug  even  
if  the  objective   is to relive the patient from pain and suffering.
H.  RATIO OF GIAN KAUR VS. STATE OF PUNJABCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

62. In  Gian   Kaur’s   case   (supra),  the   constitutional
validity of Section 306 of Indian Penal Code, 1860 was challenged.     The   appellant  
had   placed   reliance   on   Two Judge   Bench   Judgment   of   this   Court   in  P.  
Rathinam   Vs. Union   of   India   (supra),   where   this   Court   declared Section  
309   IPC   to   be  unconstitutional   as  violative   of Article 21 of the Constitution. 
 It was contended that Section   309   having   already   been   declared   as
unconstitutional, any person abetting the commission of suicide   by   another   is  
merely   assisting   in   the enforcement   of   the   fundamental   right   under   Article  
21 and,   therefore,   Section   306   IPC   penalising   assisted
suicide is equally violative of Article 21.   The Court proceeded   to   consider   the  
constitutional   validity   of Section 306 on the above submission.  In Para 17 of the
judgment, this Court had made observation that reference to   euthanasia   cases  
tends   to   befog   the   real   issue.
Following   are   the   relevant   observations   made   in   Para 17:− “....Any   further  
reference   to   the   global debate   on   the   desirability   of   retaining   a
penal provision to punish attempted suicide is   unnecessary   for   the   purpose   of  
this decision. Undue emphasis on that aspect and particularly   the   reference   to  
euthanasia cases tends to befog the real issue of the constitutionality   of   the  
provision   and   the crux   of   the   matter   which   is   determinative of the issue.”
The Constitution Bench held that Article 21 does not include   right   to   die.    
Paragraph   22   of   the   judgment contains the ratio in following words:−
“....Whatever   may   be   the   philosophy   of permitting a person to 
extinguish his life by committing suicide, we find it difficult
to construe Article 21 to include within it the   “right   to   die”   as   a   part   of   the
fundamental   right   guaranteed   therein.
“Right to life” is a natural right embodied in   Article   21   but   suicide   is   an  
unnatural termination   or   extinction   of   life   and, therefore,   incompatible   and  
inconsistent with the concept of “right to life”.....”  Although,   right   to   die   was  
held   not   to   be   a fundamental right enshrined under Article 21 but it was
laid down that the right to life includes right to live
with human dignity, i.e., right of a dying man to also
die with dignity when his life is ebbing out.  Following
pertinent observations have been made in Para 24:− “....The   “right   to   life”  
including   the right to live with human dignity would mean
the existence of such a right up to the end of   natural   life.   This   also   includes   the
right   to   a   dignified   life   up   to   the   point
of death including a dignified procedure of
death. In other words, this may include the right   of   a   dying   man   to   also   die  
with dignity   when   his   life   is   ebbing   out.   But
the “right to die” with dignity at the end of   life   is   not   to   be   confused   or  
equated with the “right to die” an unnatural death curtailing the natural span of life.”Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

63. The   Constitution   Bench,   however,   noticed   the distinction   between   a
 dying   man,   who   is   terminally   ill or   in   a   persistent   vegetative   state,   when  
process   of natural   death   has   commenced,   from   one   where   life   is
extinguished.   The   Court,   however,   held   that   permitting
termination of life to such cases to reduce the period
of suffering during the process of certain natural death is   not   available   to  
interpret   Article   21   to   include therein the right to curtail the natural span of life.
Paragraph   25   of   the   judgment   is   to   the   following effect:− “25.  A   question  
may   arise,   in   the   context of a dying man who is terminally ill or in a   persistent  
vegetative   state   that   he   may be permitted to terminate it by a premature
extinction   of   his   life   in   those circumstances.   This   category   of   cases   may
fall within the ambit of the “right to die” with   dignity   as   a   part   of   right   to   live
with dignity, when death due to termination
of natural life is certain and imminent and
the process of natural death has commenced. These   are   not   cases   of  
extinguishing   life but only of accelerating conclusion of  the process of 
natural death which has  already commenced. The debate even in such cases to
permit   physician−assisted   termination   of life   is   inconclusive.   It   is   sufficient  
to reiterate that  the argument to support  the view   of   permitting   termination   of  
life   in such   cases   to   reduce   the   period   of suffering   during   the   process   of  
certain natural death is not available to interpret
Article 21 to include therein the right to curtail the natural span of life.”
64. The   Constitution   Bench   in   above   paragraphs   has
observed that termination of life in case of those who
are terminally ill or in a persistent vegetative state,
may fall within the ambit of “right to die” with dignity
as a part of right to live with dignity when death due to   termination   of  natural  life  
is  certain  and  imminent and process of natural death has commenced.  But even in
those cases, physician assisted termination of life can not   be   included   in   right  
guaranteed   under   Article   21.
One more pertinent observation can be noticed from Para
33, where this Court held that:
“33.  ....We   have   earlier   held   that “right   to   die”   is   not   included   in   the
“right to life” under Article 21. For the same   reason,   “right   to   live   with   human
dignity”   cannot   be   construed   to   include within   its   ambit   the   right   to
 terminate natural   life,  at   least   before commencement   of   the   natural   process  
of certain death....”         (emphasis by us)
65. The   distinction   between   cases   where   physician
decides not to provide or to discontinue to provide forCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

treatment or care, which could or might prolong his life and   those   in   which   he  
decides   to   administer   a   lethal
drug, was noticed while referring to the judgment of the House   of   Lords’s   case   in
 Airedale’s   case   (supra).  In Airedale’s   case   (supra),   it   was   held   that   it   is  
not lawful for a doctor to administer a drug to his patient to   bring   about   his  
death.   Euthanasia   is   not   lawful   at common   law   and   euthanasia   can   be  
made   lawful   only   by legislation.   It is further relevant to notice that in Para   40,  
this   Court   had   observed   that   it   is   not necessary   to   deal   with   physician  
assisted   suicide   or euthanasia cases. Paragraph 40, is as follows:− “40.  Airedale  
N.H.S.   Trust   v.   Bland   was   a case   relating   to   withdrawal   of   artificial
measures   for   continuance   of   life   by   a physician. Even though it is 
not necessary to   deal   with   physician−assisted   suicide   or
euthanasia cases, a brief reference to this decision   cited   at   the   Bar   may   be  
made.   In the context of existence in the persistent vegetative   state   of   no   benefit  
to   the patient, the principle of sanctity of life, which   is   the   concern   of   the  
State,   was stated   to   be   not   an   absolute   one.   In   such cases   also,   the  
existing   crucial distinction   between   cases   in   which   a physician   decides   not  
to   provide,   or   to continue   to   provide,   for   his   patient, treatment   or   care  
which   could   or   might prolong   his   life,   and   those   in   which   he decides,   for  
example,   by   administering   a lethal   drug,   actively   to   bring   his
patient’s life to an end, was indicated and it was then stated as under: (All ER p. 867
: WLR p. 368) “…  But   it   is   not   lawful   for   a doctor to administer a drug to his
patient to bring about his death, even   though   that   course   is
prompted by a humanitarian desire to   end   his   suffering,   however great   that  
suffering   may   be   [see R.   v.   Cox,   (18−9−1992, unreported)] per Ognall, J. in the
Crown   Court   at   Winchester.   So   to act is to cross the Rubicon which runs  
between   on   the   one   hand   the care of the living patient and on the   other   hand  
euthanasia   — actively   causing   his   death   to avoid   or   to   end   his   suffering.
Euthanasia is not lawful at common law.   It   is   of   course   well   known that   there
  are   many   responsible members of our society who believe that   euthanasia  
should   be   made lawful;   but   that   result   could,   I believe,   only   be   achieved  
by legislation   which   expresses   the democratic   will   that   so fundamental   a  
change   should   be made   in   our   law,   and   can,   if enacted,   ensure   that   such
legalised   killing   can   only   be carried out subject to appropriate
supervision and control. …”
66. A conjoint reading of observations in Paras 25, 33 and   40   indicates   that
 although   for   a  person   terminally
ill or in PSV state, whose process of natural death has
commenced, termination of life may fall in the ambit of
right to die with dignity but in those cases also there
is no right of actively terminating life by a physician.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

The   clear   opinion   has   thus   been   expressed   that euthanasia   is   not   lawful.    
But   at   the   same   time,   the Constitution   Bench   has   noticed   the   distinction  
between the cases in which a physician decides not to provide or to   continue   to  
provide   for   his   patient's   treatment   or
care which could or might prolong his life and those in which   physician   decides  
actively   to   bring   life   to   an end.     The  ratio  of   the   judgment   is   contained  
in Paragraph 22 and 24, which is to the following effect:−
(i)“....Whatever   may   be   the   philosophy   of permitting a person to 
extinguish his life by committing suicide, we find it difficult
to construe Article 21 to include within it the   “right   to   die”   as   a   part   of   the
fundamental   right   guaranteed   therein.
“Right to life” is a natural right embodied in   Article   21   but   suicide   is   an   unnatural
termination   or   extinction   of   life   and, therefore,   incompatible   and   inconsistent
with the concept of “right to life”.....” 
(ii)“....The   “right   to   life”   including   the right to live with human dignity would mean
the existence of such a right up to the end of   natural   life.   This   also   includes   the right   to   a  
dignified   life   up   to   the   point of death including a dignified procedure of
death. In other words, this may include the right   of   a   dying   man   to   also   die   with dignity  
when   his   life   is   ebbing   out.   But the “right to die” with dignity at the end of   life   is   not   to  
be   confused   or   equated with the “right to die” an unnatural death
curtailing the natural span of life.”
67. We   have   noticed   above   that   in   Para   17,   this   Court
had observed that reference to euthanasia cases tends to befog   the   real   issue   and   further   in  
Para   40,   it   was observed that “even though it is not necessary to deal with   physician   assisted  
suicide   or   euthanasia   cases”; the   Constitution   Bench   has   neither   considered   the concept  
of   euthanasia   nor   has   laid   down   any   ratio approving euthanasia.
68. At best, the Constitution Bench noted a difference
between cases in which physician decides not to provide
or to continue to provide for medical treatment or care
and those cases where he decides to administer a lethal
drug activity to bring his patient’s life to an end. The judgment   of   House   of   Lords   in  Airedale’s
  case   (supra) was   referred   to   and   noted   in   the   above   context.   The Airedale’s   case  
(supra)  was   cited   on   behalf   of   the appellant in support of the contention that in said case
the withdrawal of life saving treatment was held not to be unlawful.
69. We agree with the observation made in the reference order   of   the   three−Judge   Bench   to  
the   effect   that   the Constitution   Bench   did   not   express   any   binding   view   on
the subject of euthanasia.  We hold that no binding view was   expressed  by   the   Constitution
 Bench   on   the   subject of Euthanasia.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

I.  CONCEPT OF EUTHANASIA
70. Euthanasia   is   derived   from   the   Greek   words euthanatos;  eu  means   well   or   good   and
 thanatos  means death.  New   Webster's   Dictionary   (Deluxe   Encyclopedic
Edition) defines Euthanasia as following:
"A   painless   putting   to   death   of   persons
having an incurable disease; an easy death. Also mercy killing.”
71. The Oxford English Dictionary defines 'euthanasia':
“The   painless   killing   of   a   patient   suffering   from   an incurable   and   painful  
disease   or   in   an   irreversible
coma”.  The definition of the word 'euthanasia' as given by   the   World   Health  
Organisation   may   be   noticed   which defines   it   as:  “A   deliberate   act  
undertaken   by   one person   with   the   intention   of   either   painlessly   putting
to death or failing to prevent death from natural causes in   cases   of   terminal  
illness   or   irreversible   coma   of another person”.
72. In ancient Greek Society, Euthanasia as 'good death'
was associated with the drinking of 'Hemlock'. Drinking of   Hemlock   had   become   common   not  
only   in   cases   of incurable   diseases   but   also   by   those   individuals   who
faced other difficult problems or old age.   In ancient times,   in   Greece   freedom   to   live   was  
recognised principle,   which   permitted   the   sick   and   desperates   to
terminate their lives by themselves or by taking outside help.   In   last   few   centuries,   Euthanasia
  increasingly came   to   connote     specific  measures   taken   by   physicians to   hasten   the   death.
  The   primary   meaning,   as   has   now been   ascribed   to   the   word   is   compassionate  
murder.   In the last century, the thought has gained acceptance that Euthanasia   is   to   be  
distinguished   from   withdrawal   of life   saving   treatments   which   may   also  result   in   death.
Withdrawing medical treatment in a way hasten the death in   case   of   terminal   illness   or  
Persistent   Vegetative State   (PVS)   but   is   not   to   be   treated   as   compassionate
murder. Advancement in the medical science on account of which   life   can   be   prolonged   by  
artificial   devices   are the   developments   of   only   last   century.  Lord   Browne Wilkinson, J.,  in
 Airedale N.H.A. Trust v.  Bland, 1993 (2) W.L.R. 316 (H.L.), at page 389 observed:
“....Death in the traditional sense was beyond   human   control.   Apart   from   cases  
of unlawful   homicide,   death   occurred automatically in the  course of nature when
the natural functions of the body failed to sustain   the   lungs   and   the   heart.  
Recent developments   in   medical   science   have fundamentally   affected   these  
previous certainties.   In   medicine,   the   cessation   of breathing   or   of   heartbeat  
is   no   longer death.   By   the   use   of   a   ventilator,   lungs
which in the unaided course of nature would have   stopped   breathing   can   be  
made   to breathe,   thereby   sustaining   the   heartbeat.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Those,   like   Anthony   Bland,   who   would previously   have   died   through  
inability   to swallow   food   can   be   kept   alive   by artificial   feeding.     This   has  
led   the medical   profession   to   redefine   death   in
terms of brain stem death, i.e., the death of that part of the brain without which the
body   cannot   function   at   all   without assistance.     In   some   cases   it   is   now
apparently   possible,   with   the   use   of   the
ventilator, to sustain a beating heart even though   the   brain   stem,   and   therefore  
in medical   terms   the   patient,   is   dead;   “the ventilated corpse.”
73. In   recent   times,   three   principles   had   gained acceptance throughout the world they are:
1. Sanctity of life
2. Right of self−determination
3. Dignity of the individual human being
74. The   sanctity   of   life   is   one   thought   which   is philosophically,  religiously  and
 mythologically  accepted by the large number of population of the world practicing
different faiths and religions. Sanctity of life entails it's   inviolability   by   an   outsider.   Sanctity   of
  life   is the concern of State.
75. Right   of   self−determination   also   encompasses   in   it
bodily integrity. Without consent of an adult person, who
is in fit state of mind, even a surgeon is not authorised to  violate  the  body.  Sanctity of  the  human 
life  is  the most   fundamental   of   the   human   social   values.     The acceptance   of   human  
rights   and     development   of   its meaning in recent times has fully recognised the dignity of   the  
individual   human   being.   All   the   above   three
principles enable an adult human being of conscious mind to   take   decision   regarding   extent  
and   manner   of   taking medical treatment. An adult human being of conscious mind is   fully  
entitled   to   refuse   medical   treatment   or   to decide   not   to   take   medical   treatment   and  
may   decide   to embrace the death in natural way.   Euthanasia, as noted
above, as the meaning of the word suggest is an act which
leads to a good death. Some positive act is necessary to characterise   the   action   as   Euthanasia.    
Euthanasia   is also commonly called “assisted suicide” due to the above reasons.
J. WITHDRAWAL OF LIFE SAVING DEVICES
76. Withdrawal   of   medical   assistance   or   withdrawal   of medical   devices   which   artificially  
prolong   the   life cannot   be   regarded   as   an   act   to   achieve   a   good   death. Artificial   devices
  to   prolong   the   life   are   implanted, when a person is likely to die due to different causes
in his body. Life saving treatment and devices are put
by physicians to prolong the life of a person. The Law Commission   of   India   in   its   196th  Report
  on   “Medical Treatment   to   Terminally   Ill   Patients   (Protection   ofCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

Patients and Medical Practitioners)” on the subject had
put introductory note to the following effect:  
“The   title   to   this   Report   immediately suggests   to   one   that   we   are   dealing  
with ‘Euthanasia’   or   ‘Assisted   Suicide’.   But   we
make it clear at the outset that Euthanasia and   Assisted   Suicide   continue   to   be
unlawful   and   we   are   dealing   with   a different   matter   ‘Withholding   Life−
support Measures’   to   patients   terminally   ill   and, universally,   in   all   countries,
  such withdrawal is treated as ‘lawful’.”
77. The Law Commission of India was of the opinion that withdrawing   life   supporting   measures  
of   patient terminally ill is a concept, different from Euthanasia. The   opinion   of  Cardozo,   J.,
 rendered   more   than   hundred years   ago   that   every   human   being   of   adult   years   and
sound mind has a right to determine what shall be done with   his   own   body,   is   now   universally
  accepted principle.   The   judgment   of   the   U.S.   Supreme   Court   and House   of   Lords,   as  
noticed   above,   also   reiterate   the above principle.
78.   Recently,   in   a   nine−Judges     judgment   in  K.S. Puttaswamy   and   Another   Vs.   Union  
of   India   and   Others, (2017) 10 SCC 1, Justice J. Chelameswar  elaborating the concept   of   right  
to   life   as   enshrined   in   Article   21 under the Constitution of India has observed: 
“An   individual's   right   to   refuse   the life−prolonging   medical   treatment   or
terminate   life   is   another   freedom   which falls within the zone of right of privacy.”
79.  Withdrawal of life−saving devices, leads to natural death which is arrested 
for the time being due to above device   and   the   act   of   withdrawal   put   the   life   on   the
natural track. Decision to withdraw life−saving devices
is not an act to cause good death of the person rather, decision to withdraw or not to initiate life−
supporting measures is a decision when treatment becomes futile and unnecessary. 
 Practice of Euthanasia in this country is prohibited   and   for   medical   practitioners   it   is  
already ordained   to   be   unethical   conduct.   The   question   as   to
what should be the measures to be taken while taking a decision to withdraw life−
saving measures or life−saving devices   is   another   question   which   we   shall   consider   a
little later.
80.   Two−Judge Bench in  Aruna Ramachandra Shanbaug Vs.
Union of India and Ors., (2011) 4 SCC 454 has held that withdrawal   of   live−saving   measures   is  
a   passive Euthanasia which is permissible in India.   A critically ill   patient   who   is   mentally  
competent   to   take   a decision, decides not to take support of life prolonging
measures, and respecting his wisdom if he is not put on such   devices   like   ventilator   etc.,   it   is  
not   at   all Euthanasia.   Large   number   of   persons   in   advance   age   of life   decide   not   to  
take   medical   treatment   and   embrace death in its natural way, can their death be termed as
Euthanasia.   Answer   is,   obviously   'No'.      The   decision
not to take life saving medical treatment by a patient,Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

who is competent to express his opinion cannot be termed as   euthanasia,   but   a   decision   to  
withdraw   life   saving treatment by a patient who is competent to take decision
as well as with regard to a patient who is not competent to   take   decision   can   be   termed   as  
passive   euthanasia. On   the   strength   of   the   precedents   in   this   country   and
weight of precedents of other countries as noted above,
such action of withdrawing life saving device is legal.
Thus, such acts, which are commonly expressed as passive euthanasia   is   lawful   and   legally  
permissible   in   this country.
81. We   remind   ourselves   that   this   Court   is   not   a
legislative body nor is entitled or competent to act as a   moral   or   ethical   arbiter.   The   task   of  
this   Court   is not   to   weigh   or   evaluate   or   reflect   different  believes
and views or give effect to its own but to ascertain and build  the  law  of  land  as  it  is   now 
understood  by   all. Message   which   need   to   be   sent   to   vulnerable   and
disadvantaged people should not, however, obliviously to
encourage them to seek death but should assure them of care and support in life.
82.  We thus are of the considered opinion that the act of withdrawal from live−
saving devices is an independent right   which   can   lawfully   be   exercised   by   informed decision.
K. DECISION FOR WITHDRAWAL OF LIFE−SAVING TREATMENT IN  CASE   OF   A   PERSON  
WHO   IS   INCOMPETENT   TO   TAKE   AN   INFORMED DECISION.
83. One related aspect which needs to be considered is that   is   case   of   those   patients   who   are  
incompetent   to decide due to their mental state or due to the fact that
they are in permanent persistent vegetative state or due to   some   other   reasons   unable   to  
communicate   their desire. When the right of an adult person who expresses
his view regarding medical treatment can be regarded as right   flowing   from   Article   21   of   the  
Constitution   of India,   the   right   of   patient   who   is   incompetent   to
express his view cannot be outside the fold of Article
21 of the Constitution of India. It is another issue, as to   how,   the   decision   in   cases   of  
mentally   incompetent patients   regarding   withdrawal   of   life−saving   measures, is to be taken.
84. The   rights   of   bodily   integrity   and   self−
determination are the rights which belong to every human being.   When   an   adult   person   having
  mental   capacity   to take   a   decision   can   exercise   his   right   not   to   take treatment   or  
withdraw   from   treatment,   the   above   right
cannot be negated for a person who is not able to take
an informed decision due to terminal illness or being a Persistent   Vegetative   State   (PVS).   The  
question   is   who is competent to take decision in case of terminally−ill or   PVS   patient,   who   is  
not   able   to   take   decision.   In case of a person who is suffering from a disease and is
taking medical treatment, there are three stake holders; the   person   himself,   his   family  
members   and   doctor treating   the   patient.   The   American   Courts   give recognition   to  
opinion   of   “surrogate”   where   person   is incompetent   to   take   a   decision.   No   person   can  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

take decision regarding life of another unless he is entitled to   take   such   decision   authorised  
under   any   law.   The English Courts have applied the “best interests” test in
case of a incompetent person. The best interests of the
patient have to be found out not by doctor treating the patient   alone   but   a   team   of   doctors  
specifically nominated   by   the   State   Authority.   In  Aruna   Shanbaug (supra),  two−Judge  
Bench  of   this  Court   has   opined   that in   such   cases   relying   on   doctrine   of   ‘parens  
patriae (father of the country)’, it is the Court alone which is entitled   to   take   a   decision   whether
  to   withdraw treatment for incompetent terminally−ill or PVS patient.
In paragraphs 130 and 131 following has been held:
“130. In our opinion, in the case of an incompetent person who is unable to take a
decision   whether   to   withdraw   life   support or   not,   it   is   the   Court   alone,   as
  parens patriae,   which   ultimately   must   take   this decision,   though,   no   doubt,
  the   views   of the near relatives, next friend and doctors must be given due weight.
Under which provision of law can the Court
grant approval for withdrawing life support to an incompetent person
131.   In   our   opinion,   it   is   the   High Court under Article 226 of the Constitution
which can grant approval for  withdrawal of life   support   to   such   an   incompetent
person. Article   226(1) of   the   Constitution states :
"226.   Power   of   High   Courts   to issue   certain   writs.− (1)Notwithstanding  
anything in article   32,   every   High   Court shall   have   power,   throughout   the
territories in relation to which it exercises jurisdiction, to issue to any  person 
or authority,  including in   appropriate   cases,   any Government,   within   those
territories   directions,   orders   or writs,   including   writs   in   the nature  of habeas
 corpus,  mandamus, prohibition,   quo   warranto   and
certiorari, or any of them, for the enforcement   of   any   of   the   rights conferred   by
  Part   III   and   for   any other purpose".
                (emphasis supplied) A   bare   perusal   of   the   above   provisions shows that  the  High
 Court under Article 226 of the   Constitution   is   not   only   entitled   to
issue writs, but is also entitled to issue directions or orders.”
85. Various   learned   counsel   appearing   before   us   have submitted   that   seeking   declaration  
from   the   High   Court in   cases   where   medical   treatment   is   needed   to   be
withdrawn is time taking and does not advance the object nor is in the interest of terminally−
ill patient. It is submitted   that   to   keep   check   on   such   decisions,   the
State should constitute competent authorities consisting of   pre−dominantly   experienced   medical
  practitioners whose decision may be followed by all concerned with a
rider that after taking of decision by competent body a cooling   period   should   be   provided   to  
enable   anyone aggrieved from the decision to approach a Court of Law.
We also are of the opinion that in cases of incompetentCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

patients who are unable to take an informed decision, it is   in   the   best   interests   of   the   patient
  that   the decision be taken by competent medical experts and that such   decision   be  
implemented   after   providing   a   cooling period at least of one month to enable aggrieved person
to approach the Court of Law. The best interest of the
patient as determined by medical experts shall meet the ends   of   justice.   The   medical   team   by  
taking   decision shall   also   take   into   consideration   the   opinion   of   the
blood relations of the patient and other relevant facts and circumstances.
L.  ADVANCE MEDICAL DIRECTIVE
86. The petitioner by the Writ Petition has also sought a   direction   to   the   respondent   to   adopt  
suitable procedures to ensure that persons of deteriorated health
or terminally ill should be able to execute a document titled   “MY   LIVING  WILL   &  ATTORNEY
 AUTHORISATION”.     The petitioner   submits   that   it   is   an   important   personal decision   of 
the  patient  to  use   or  not  to   use  the   life sustaining   treatment   in   case   of   terminal   illness  
and stage   of   persistent   vegetative   state.   The   petitioner
pleads that the petitioner’s endeavour is only to seek a ‘choice’   for   the   people   which   is   not  
available   at present and they are left to the mercy of doctors who to save   themselves   from   any  
penal   consequences   half heartedly, despite knowing that the death is inevitable continue  
administering   the   treatment   which   the   person might not have wanted to continue with. 
 A person will be free to issue advance directives both in a positive and   negative   manner,  
meaning   thereby   that   a   person   is not   necessarily   required   to   issue   directive   that   the
life sustaining treatment should not be given to him in
the event of he or she going into persistent vegetative state or in an irreversible state. 
 The person can also issue directives as to all the possible treatment which should  be  given  to   him 
when  he  is  not  able   to  express his/her   wishes   on   medical   treatment.     The   petitioner also  
refers   to   and   rely   on   various   legislations   in different   countries,   which   recognises   the  
concept   of advance   medical   directive.     Petitioner   pleads   that   in
India also law in the nature “Patient Autonomy & Self− determination   Act”   should   be   enacted.  
Petitioner   has also   alongwith   his   Writ   Petition   has   annexed   a   draft
titling it “Patient’s Self−determination Act”.
87. The   concept   of   advance   medical   directive   is   also called   living   will   is   of   recent  
origin,   which   gained recognition in  latter part  of 20th  century. The advance medical   directive  
has   been   recognised   first   by   Statute in United States of America when in the year 1976, State
of California passed “Natural Death Act”.  It is claimed
that 48 states out of 50 in the United States of America have   enacted   their   own   laws   regarding  
Patient’s   Rights and   advance   medical   directives.     Advance   medical directive   is   a  
mechanism   through   which   individual autonomy can be safeguarded in order to provide dignity
in   dying.     As   noted   above,   the   Constitution   Bench   of this   Court   in   the   case   of  Gian  
Kaur   (supra)  has   laid down   that   right   to   die   with   dignity   is   enshrined   in Article   21   of  
the   Constitution.     It   is   to   be   noticed that   advance   medical   directives   are   not   exclusively
associated with end of life decisions.   However, it is vital   to   ensure   that   form   of   an   advance  
medical directive   reflects   the   needs   of   its   author   and   is sufficiently   authoritative   and  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

practical   to   enable   its provisions   to   be   upheld.     In   most   of   the   western countries  
advance   medical   directives   have   taken   a
legalistic form incorporating a formal declaration to be signed   by   competent   witnesses.     The  
laws   also   make provisions   for   updating   confirmation   of   its
applicability and revocation.  Protecting the individual
autonomy is obviously the primary purpose of an advance medical directive. 
 The right to decide one’s own fate pre−supposes a capacity to do so.  The answer as to when
a particular advance medical directive becomes operative
usually depends upon an assent of when its author is no longer   competent   to   participate   in  
medical   decision making.   The Black’s Law Dictionary defines the Advance
Medical Directive as “a legal document explaining one’s wishes   about   medical   treatment   if   one
  becomes incompetent   or   unable   to   communicate”.     An   advance
medical directive is an individual’s advance exercise of his   autonomy   on   the   subject   of   extent  
of   medical intervention that he wishes to allow upon his own body
at a future date, when he may not be in a position to specify his wishes. 
 The purpose and object of advance medical directive is to express the choice of a person regarding
 medical  treatment   in   an  event   when   he   looses capacity   to   take   a   decision.   Use   and  
operation   of advance medical directive is to confine only to a case when   person   becomes  
incapacitated   to   take   an   informed decision regarding his medical treatment.  So long as an
individual   can   take   an   informed   decision   regarding   his medical   treatment,   there   is   no  
occasion   to   look   into advance   medical   directives.   A   person   has   unfettered
right to change or cancel his advance medical directives
looking to the need of time and advancement in medical
science.  Hence, a person cannot be tied up or bound by
his instructions given at an earlier point of time.
88. The concept of advance medical directive originated
largely as a response to development in medicines.  Many people   living   depending   on   machines
  cause   great financial distress to the family with the cost of long term   medical   treatment.   
Advance   medical   directive   was developed   as   a   means   to   restrict   the   kinds   of   medical
intervention in event when one become incapacitated. The foundation   for   seeking   direction  
regarding   advance medical   directive   is   extension   of   the   right   to   refuse medical   treatment  
and   the   right   to   die   with   dignity. When   a   competent   patient   has   right   to   take   a  
decision regarding   medical   treatment,   with   regard   to   medical
procedure entailing right to die with dignity, the said right   cannot   be   denied   to   those   patients,
  who   have become   incompetent   to  take   an  informed   decision   at   the
relevant time. The concept of advance medical directive
has gained ground to give effect to the rights of those
patients, who at a  particular time are not able to take an   informed   decision.     Another   concept  
which   has   been accepted   in   several   countries   is   recognition   of instrument   through   which  
a   person   nominates   a representative to make decision regarding their medical
treatment at a point of time when the person executing the   instrument   is  unable   to   make   an  
informed   decision. This is called attorney authorisation leading to medical treatment.   In   this  
country,   there   is   no   legislation governing   such   advance   medical   directives.     It   is,Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

however, relevant to note a recent legislation passed by
the Parliament namely “The Mental Healthcare Act, 2017”,
where as per Section 5 every person, who is not a minor has   a   right   to   make   an   advance  
directive   in   writing regarding treatment to his mental illness in the way a person   wishes   to   be  
treated   or   mental   illness.     The person wishes not to be treated for mental illness and
nomination   of   individual   and   individual’s   as   his/her
representative.  Section 5 is to the following effect:− “5.   (1)   Every   person,   who   is   not   a  
minor, shall   have   a   right   to   make   an   advance directive in writing, specifying any or all
of the following, namely:–– 
(a)   the   way   the   person   wishes   to be   cared   for   and   treated   for   a mental illness; 
(b) the way the person wishes not to be cared for and treated for a mental illness;
(c) the individual or individuals, in   order   of   precedence,   he   wants to   appoint   as   his  
nominated representative   as   provided   under section 14.
(2)   An   advance   directive   under   sub−section (1) may be made by a person irrespective of his  
past   mental   illness   or   treatment   for the same.
(3)   An   advance   directive   made   under   sub− section   (1),   shall   be   invoked   only   when
such person ceases to have capacity to make mental   healthcare   or   treatment   decisions and  
shall   remain   effective   until   such person   regains   capacity   to   make   mental
healthcare or treatment decisions.
(4) Any decision made by a person while he has the capacity  to make  mental healthcare
and treatment decisions shall over−ride any previously   written   advance   directive   by
such person.
(5) Any advance directive made contrary to any   law   for   the   time   being   in   force   shall
be ab initio void.”
89. Section   6   of   the   Act   provides   that   an   advance directive   shall   be   made   in   the  
manner   as   has   been prescribed   by   the   regulations   made   by   the   Central Authority.     In  
the   draft   Medical   Healthcare   Regulation published   by   Ministry   of   Health   and   Family  
Welfare,   a form   is   prescribed   in   which   advance   directive   may   be
made.  Other aspects of medical directive have also been dealt with by draft regulation. 
 Thus, in our country, recognition   of   advance   directives   regarding   medical
treatment has started to be recognised and are in place relating   to   specified   field   and   purpose.  
Another legislation   which   also   recognise   some   kind   of   advance directive   relating   to   a  
person’s   body   is   Section   3   of the   Transplantation   of   Human   Organs   and   Tissues   Act,
1994.     Section   3   sub−sections   (1)   and   (2)   which   are
relevant for the present purpose is as follows:− “3.  Authority  for removal  of [human organs
or tissues or both].—(1) Any donor may, in such  manner and subject to such conditions as   may   beCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

  prescribed,   authorise   the removal,   before   his   death,   of   any   [human organ   or   tissue   or  
both]   of   his   body   for therapeutic purposes. 
(2) If any donor had, in writing and in the presence of two or more witnesses (at least one   of  
whom   is   a   near   relative   of   such person),   unequivocally   authorised   at   any time   before  
his   death,   the   removal   of   any [human   organ   or   tissue   or   both]   of   his body,   after   his  
death,   for   therapeutic purposes, the person lawfully in possession
of the dead body of the donor shall, unless he has any reason to believe that the donor had  
subsequently   revoked   the   authority aforesaid,   grant   to   a   registered   medical practitioner   all
  reasonable   facilities   for the   removal,   for   therapeutic   purposes,   of that   [human   organ   or  
tissue   or   both]   from the dead body of the donor.”
90. The rules have been framed under Section 24 of the Transplantation   of   Human   Organs   and  
Tissues   Act,   1994 namely   Transplantation   of   Human   Organs   and   Tissues Rules,   2014  
where   form   of   authorisation   for   organ   or tissue   pledging   is   Form   7,   which   provides  
that   an authorisation   by   donor   in   presence   of   two   witnesses which is also required to be
 registered  by Organ Donor Registry.
91. The   statutory   recognition   of   the   above   mentioned authorisation   in   two   statutes   is  
clear   indication   of acceptance   of   the   concept   of   advance   medical   directive in this country.
92. Learned   counsel   for   the   petitioner   as   well   as   for
the interveners and the Additional Solicitor General of India   has   expressed   concern   regarding  
manner   and procedure of execution of advance medical directive. It
is submitted that unless proper safeguards are not laid
down, those who are vulnerable, infirm and aged may be adversely   affected   and   efforts   by  
those   related   to   a person   to   expedite   death   of   a   person   for   gaining
different benefits, cannot be ruled out.   We have been
referred to various legislations in different countries, which   provides   a   detailed   procedure   of  
execution   of advance medical directive, competence of witnesses, mode
and manner of execution, authority to register and keep such advance medical directive.
93. Shri Arvind Datar, learned senior counsel has in its written   submissions   referred   to   certain  
aspects,   which may   be   kept   in   mind   while   formulating   guidelines   for
advance medical directive, which are as follows:
a)   Only   adult  persons,   above   the   age   of eighteen   years   and   of   sound   mind   at   the time  
at   which   the   advance   directive   is executed  should be deemed to  be competent.
This   should   include   persons   suffering   from mental   disabilities   provided   they   are   of sound
  mind   at   the   time   of   executing   an advance directive.
b)   Only   written   advance   directives   that have   been   executed   properly   with   the
notarised signature of the person executing the   advance   directive,   in   the   presence   of two  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

adult   witnesses   shall   be   valid   and enforceable   in   the   eyes   of   the   law.   The form   should  
require   a   reaffirmation   that the   person   executing   such   directive   has made   an   informed  
decision.   Only   those advance   directives   relating   to   the withdrawal   or   withholding   of   life−
sustaining   treatment   should   be   granted legal   validity.   The   determination   that   the executor
  of   the   advance   directive   is   no longer   capable   of   making   the   decision
should be made in accordance  with relevant medical   professional   regulations   or standard  
treatment   guidelines,   as   also   the determination   that   the   executor's   life would   terminate   in
  the   absence   of   life− sustaining treatment. The constitution of a
panel of experts may also be considered to make  this determination.  The use  of expert committees
  or   ethics   committees   in   other jurisdictions   is   discussed   at   Para   28   of
these written submissions.
c)   Primary   responsibility   for   ensuring compliance   with   the   advance   directive should be on 
the medical  institution where the person is receiving such treatment.
d)   If a hospital refuses to recognise the validity   of   an   advance   directive,   the relatives   or   next
  friend   may   approach   the jurisdictional High Court seeking a writ of mandamus   against   the  
concerned   hospital   to execute   the   directive.   The   High   Court   may examine   whether   the  
directive   has   been properly   executed,   whether   it   is   still valid   (Le,   whether   or   not  
circumstances have   fundamentally   changed   since   its execution,   making   it   invalid)   and/or
applicable   to   the   particular   circumstances or treatment.
e)     No   hospital   or   doctor   should   be   made liable in civil or criminal proceedings for having  
obeyed   a   validly   executed   advance directive.
f)     Doctors   citing   conscientious   objection to the enforcement of advance directives on
the grounds of religion should be permitted not   to   enforce   it,   taking   into   account
their fundamental right under Article 25 of the   Constitution.   However,   the   hospital
will still remain under this obligation.
94. The right to self−determination and bodily integrity
has been recognised by this Court as noted above.   The
right to execute an advance medical directive is nothing
but a step towards protection of aforesaid right by an individual,   in   event   he   becomes  
incompetent   to   take   an informed decision, in particular stage of life.   It has to   be   recognised  
by   all   including   the   States   that   a person has right to execute an advance medical directive
to be utilised to know his decision regarding manner and
extent of medical treatment given to his body, in case
he is incapacitated to take an informed decision.   Such right   by   an   individual   does   not  
depend   on   any recognition or legislation by a State and we are of the
considered opinion that such rights can be exercised by an   individual  in   recognition   and   in  
affirmation   of   his right   of   bodily   integrity   and   self−determination   which
are duly protected under Article 21 of the Constitution. The   procedure   and   manner   of   such  
expression   of   such right   is   a   question   which   needs   to   be   addressed   toCommon Cause (A Regd. Society) vs Union Of India on 9 March, 2018

protect the vulnerable, infirm and old from any misuse. It   is   the   duty   of   the   State   to   protect
  its   subjects specially   those   who   are  infirm,  old   and   needs   medical
care.  The duty of doctor to extend medical care to the
patients, who comes to them in no manner diminishes in
any manner by recognition of concept that an individual
is entitled to execute an advance medical directive. The
physicians and medical practitioners treating a person, who   is   incompetent   to  express  an  
informed  decision   has to act in a manner so as to give effect to the express wishes of an individual.
95. The concept of advance medical directive has gained ground   throughout   the   world.   Different
  countries   have framed   necessary   legislation   in   this   regard.   Reference of   few   of   such  
legislations   shall   give   idea   of   such statutory   scheme   formulated   by   different   countries   to
achieve the object. The Republic of Singapore has passed an   enactment   namely   ADVANCE  
MEDICAL   DIRECTIVE   ACT   (Act 16   of   1996).   Section   3   of   the   Act,   sub−section   (1)
empowers   a   person   who   is   not   mentally   disordered   and attained   the   age   of   21   years  
to   make   an   advance directive in the prescribed form.
Other   provisions   of   Statute   deals   with   duty   of witness,   registration   of   directives,  
objections, revocation   of   directive,   panel   of   specialists, certification   of   terminal   illness,  
duty   of   medical practitioner   and   other   related   provisions.   The   Belgian Act   on   Euthanasia,
  2002   also   contains   provisions regarding   advance   directive   in   Section   4.   Swiss   Civil
Code 1907 in Articles 362 and 365 provides for advance care   directive,   its   execution   and  
termination.   Mental Capacity   Act,   2005   (England)   also   contemplates   for   an
advance directive. The Statute further provides that an advance   directive   is   applicable   in   life  
sustaining treatment   only.   When   the   decision   taken   in   writing,
signed by the patient or by another person in patient's
presence on his direction. Pennsylvania Act 169 of 2006 also   contains   provisions   with   regard  
to   execution   of advance medical directive and other related provisions, its revocation etc. In   our  
country,   there   is   yet   no   legislation pertaining to advance medical directive. It is, however,
relevant   to   note   that   Ministry   of   Health   and   Family
Welfare vide its order dated 06.05.2016 uploaded the Law Commission's   241st  report   and  
solicited   opinions, comments on the same. An explanatory note has also been uploaded   by   the  
Ministry   of   Health   and   Family   Welfare where in paragraph 6 following was stated:
“ Living   Will   has   been   defined   as   “A document   in   which   person   states   his/her desire   to  
have   or   not   to   have   extraordinary life   prolonging   measures   used   when   recovery is   not  
possible   from   his/her   terminal condition”.
However, as per para 11 of the said Bill the   advance   medical   directive   (living   will)
or medical power of attorney executed by the person   shall   be   void   and   of   no   effect   and shall
  not   be   binding   on   any   medical practitioner.” Although   in   Clause   11   of   the   draft   bill,   it
  was contemplated   that   advance   medical   directives   are   not binding   on   medical  
practitioner   but   the   process   of legislation   had   not   reached   at   any   final   stage.   The
directions and safeguards which have been enumerated by Hon'ble   Chief   Justice   in   his  Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

judgment   shall   be sufficient   to   safeguard   the   interests   of   patients,
doctors and society till the appropriate legislation is framed and enforced.
We   thus   conclude   that   a   person   with   competent medical   facility   is   entitled   to   execute  
an   advance medical directive subject to various safeguards as noted above.
M. CONCLUSIONS:
From the above discussions, we arrive on following conclusions:−
(i)     The   Constitution   Bench   in  Gian   Kaur's   case  held that   the   “right   to  
life:   including   right   to   live   with
human dignity” would mean the existence of such right up to   the   end   of   natural  
life,   which   also   includes   the right   to   a   dignified   life   upto   the   point   of  
death including   a   dignified   procedure   of   death.   The   above
right was held to be part of fundamental right enshrined under   Article   21   of   the  
Constitution   which   we   also reiterate.
(ii)     We   agree   with   the   observation   made   in   the reference  order   of   the  
three−Judge   Bench   to   the   effect that the Constitution Bench in  Gian Kaur's case
 did not express   any   binding   view   on   the   subject   of   euthanasia.
We   hold   that   no   binding   view   was   expressed   by   the
Constitution Bench on the subject of Euthanasia.
(iii)     The   Constitution   Bench,   however,   noted   a
distinction between cases in which physician decides not to   provide   or   continue   to   provide   for
  treatment   and care, which could or might prolong his life and those in
which he decides to administer a lethal drug even though with   object   of   relieving   the   patient  
from   pain   and suffering.   The   later   was   held   not   to   be   covered   under
any right flowing from Article 21.
(iv) Thus, the law of the land as existing today is that   no   one   is   permitted   to   cause   death   of  
another person including a physician by administering any lethal drug   even   if   the   objective   is  
to   relieve   the   patient from pain and suffering.
(v)  An adult human being of conscious mind is fully
entitled to refuse medical treatment or to decide not to take   medical   treatment   and   may   decide
  to   embrace   the death in natural way.
(vi) Euthanasia as the meaning of words suggest is an act   which   leads   to   a   good   death.   Some
  positive   act   is necessary   to   characterise   the   action   as   Euthanasia.
Euthanasia is also commonly called “assisted suicide” due to the above reasons.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

(vii) We are thus of the opinion that the right not to   take   a   life   saving   treatment   by   a   person,
  who   is competent to take an informed decision is not covered by the   concept   of   euthanasia  as  
it   is   commonly   understood but   a   decision   to   withdraw   life   saving   treatment   by   a patient
  who   is   competent   to   take   decision   as   well   as with   regard   to   a   patient   who   is   not  
competent   to   take decision   can   be   termed   as  passive  euthanasia,  which   is
lawful and legally permissible in this country.
(viii) The   right   of   patient   who   is   incompetent   to
express his view cannot be outside of fold of Article 21 of the Constitution of India.
(ix)   We   also   are   of   the   opinion   that   in   cases   of
incompetent patients who are unable to take an informed
decision, “the best interests principle” be applied  and such   decision   be   taken   by   specified  
competent   medical experts   and   be   implemented   after   providing   a   cooling
period to enable aggrieved person to approach the court of law.
(x) An advance medical directive is an individual’s advance   exercise   of   his   autonomy   on   the  
subject   of extent   of  medical  intervention   that   he   wishes  to   allow
upon his own body at a future date, when he may not be in   a   position   to   specify   his   wishes.    
The   purpose   and object   of   advance   medical   directive   is   to   express   the choice   of   a  
person   regarding   medical   treatment   in   an event   when   he   looses   capacity   to   take   a  
decision.   The right to execute an advance medical directive is nothing
but a step towards protection of aforesaid right by an individual.
(xi) Right of execution of an advance medical directive
by an individual does not depend on any recognition or legislation   by   a   State   and   we   are   of  
the   considered opinion   that   such   rights   can   be   exercised   by   an individual   in   recognition  
and   in   affirmation   of   his right of bodily integrity and self−determination.
In view of our conclusions as noted above the writ petition is allowed in the following manner:
(a) The right to die with dignity as fundamental right has   already   been   declared  
by   the   Constitution   Bench judgment of this Court in  Gian Kaur case (supra) 
which we reiterate.
(b) We declare that an adult human being having mental capacity   to   take   an  
informed   decision   has   right   to
refuse medical treatment including withdrawal from life saving devices. 
(c) A person of competent mental faculty is entitled to
execute an advance medical directive in accordance with
safeguards as referred to above.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

96.   Before we conclude, we acknowledge our indebtness
to all the learned Advocates who have rendered valuable
assistance with great industry and ability which made it possible   for   us   to   resolve   issues   of  
seminal   public importance.   We   record   our   fullest   appreciation   for   the assistance   rendered
  by   each   and   every   counsel   in   this case.
...............................J. ( ASHOK BHUSHAN ) NEW DELHI, MARCH  09, 2018.Common Cause (A Regd. Society) vs Union Of India on 9 March, 2018

