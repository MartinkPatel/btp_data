Bihar Minerals (Concession, Prevention of Illegal Mining,
Transportation & Storage) Rules, 2019
BIHAR
India
Bihar Minerals (Concession, Prevention of Illegal
Mining, Transportation & Storage) Rules, 2019
Rule
BIHAR-MINERALS-CONCESSION-PREVENTION-OF-ILLEGAL-MINING-TRANSPORTATION-STORAGE-RULES-2019
of 2019
Published on 17 September 2019• 
Commenced on 17 September 2019• 
[This is the version of this document from 17 September 2019.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules,
2019Published vide Notification No. 4/V.Mu-20-93/18-3174/M, dated 17th September 2019Last
Updated 14th January, 2020No.-4/V.Mu-20-93/18-3174/M, - In exercise of the powers conferred
under Section 15 read with Section 23C and Section 26 of Mines and Minerals (Development and
Regulation) Act, 1957 (Act 67 of 1957), the Governor of Bihar is pleased to make the following
Rules-Chapter-I Preliminary
1. Short Title, Extent and Commencement.
(1)These rules may be called the Bihar Minerals (Concession, Prevention of Illegal Mining,
Transportation &Storage) Rules, 2019(2)It shall extend to the whole State of Bihar.(3)It shall come
into force on the day of its publication in the Official Gazette.
2. Definitions.
(1)In these Rules, unless otherwise required in the context, -(i)"Act" means the Mines and Minerals
(Development and Regulation) Act, 1957 (Act 67 of 1957);(ii)"Collector" means the
Collector-cum-District Magistrate of a district or any person appointed by the Government to
exercise the powers and perform the functions of the Collector-cum- District
Magistrate;(iii)"Competent Officer" means.-(a)in the case of grant of quarrying permits in land
notified as reserved and protected forest under the Indian Forest Act, 1927 (Central Act XVI of
1927), where the actual mining operation involved is merely removal from the surface or from aBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

depth not exceeding five feet and to a limit of 10,000 cubic feet only, Divisional Forest Officer of the
reserved and protected areas concerned, and;(b)In all other cases in respect of all lands, and
sub-soil including any right in mines and minerals whether discovered and whether being worked or
not, the Mining Officer of the District;(iv)'Competent authority' means the authority for exercise of
such powers and carrying out of such functions as specified in these rules and shall include officer
authorised by the Central Government as per the Environment Impact Assessment Notification and
Environment Protection Act in case of granting Environmental Clearance;(v)'Carrier' means any
mode or conveyance of facility by which Ore/mineral is transported from one place to another and it
includes mechanized device, person, animal, Cart, Boats;(vi)"Department" means the Department
of Mines and Geology, Government of Bihar;(vii)"Divisional Commissioner" means the
Commissioner of a Division appointed as such by the State Government;(viii)"Director of Mines"
means the Director of Mines appointed as such by the State Government;(ix)"Export" means to take
out of the State of Bihar otherwise than across a customs frontier as defined by the Central
Government;(x)"Form" means a form set out in schedule I appended to these
rules;(xi)"Government" means the State Government of Bihar;(xii)"Import" means to bring into the
State of Bihar otherwise than across a customs frontier as defined by the Central
Government;(xiii)"Local Authority" means a Municipal Committee, District Board or other
authority legally entitled to, or entrusted, by the Government with the control or management of a
municipal or local fund;(xiv)"Mines Commissioner" means the Commissioner of Mines and
Geology, Bihar, or any other Officer authorized in this behalf by the State Government to perform
the duties of Commissioner under these rules;(xv)"Minor Minerals" means minor minerals as
defined in clause(e) of Section 3 of the Mines and Minerals (Development and Regulation) Act, 1957
and includes such minor minerals as notified by the Ministry of Mines in their Notification No. SO
423(E) dated 10.02.2015;(xvi)"Mineral Concession" means a mining lease or settlement in respect
of minor minerals and includes quarrying permits, permitting the mining of minor mineral(s) in
accordance with the provisions of these rules;(xvii)"Mineral Concession Holder/ Settlee/Lessee"
means a person(as defined in these rules) holding a valid Mineral Concession for quarrying/raising
stone, sand and other minor minerals from the settled/ lease hold area and would also include the
plural there of;(xviii)"Mining Plan" means a plan prepared by a Recognized Qualified Person (RQP)
on behalf of Department /mineral concession holder of minor minerals and includes progressive
and final mine closure plans;(xix)"Mining Officer" means the officer as mentioned under these
rules;(xx)"Person" means an individual, a firm, a company, an association or body of individuals, an
institution or department of the State Government or Central Government;(xxi)"Prescribed" means
prescribed by these rules or guidelines;(xxii)"Public Demand" means public demand as defined
under Bihar & Orissa Public Demands Recovery Act, 1914 (Act 4 of 1914);(xxiii)"Quarrying Permit"
means a permit granted under chapter VII of these rules to extract and remove any minor minerals
in specified quantities from the specified areas;(xxiv)"Recognized Qualified Person" means a person
who has been notified/empanelled as such by the Department;(xxv)"Sandghat" means a sand
bearing area from where sand may be extracted and transported by means of a
carrier;(xxvi)"Settlement" means a mining right given on behalf of the Government to quarry, win,
work and carry away sand and other minor mineral(s) specified therein through a competitive
bidding process as notified by the State Government;(xxvii)"Schedule" means a schedule appended
to these rules;(xxviii)"Transport" means to remove from one place to another within the State of
Bihar;(xxix)"Works Department" means departments of the Central or State Government includingBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

Company, Corporation, Undertakings, Autonomous body of the Government engaging works
contractors for any kind of construction on its behalf;(xxx)Works Contractor" means an individual,
a firm, a company, an association or body of individuals who under an agreement, with the Works
Department work for the said Department.(2)Words and expressions used but not defined in these
Rules shall have the same meaning which is assigned to them in the Act.Chapter-II Establishment
and Control
3. Appointment of Mines Commissioner.
- The State Government may, by notification, appoint a Mines Commissioner who shall be
responsible for Administration of these rules at the State level.
4. Appointment of Director Mines.
- The State Government may, by notification, appoint a Director Mines who shall be responsible for
Administration of these Rules in the field offices at the district level.
5. Role of the Collector.
(1)The Collector of the district shall be responsible for the complete implementation of the
provisions of the Act and these rules.(2)The Collector shall also be competent to exercise the powers
of the Mining Officer under these rules;(3)The Collector shall exercise direct control and
superintendence over all the Mining Officers of the district.(4)The State Government may, by
notification, confer the powers of the Collector to any Officer, not below the rank of Mineral
Development Officer of the Mines Department or any Officer, not below the rank of Deputy
Collector of the Revenue Department, with such designations, powers and duties as the State
Government may think fit.
6. Role of the Superintendent of Police.
- The Superintendent of Police shall.(a)Assist the Collector in ensuring implementation of the
provision of the Act and these rules;(b)work under direct control and superintendence of the
Collector;(c)enforce and implemen t such lawful directions of the Collector or the Director Mines or
the Mines Commissioner as issued under the Act and these rules;(d)Submit such reports and in such
manner as the Collector or the Director Mines or the Mines Commissioner may desire.
7. Powers and functions of the Mines Commissioner.
- The Mines Commissioner.-(a)Shall exercise over all control and superintendence over all Mining
Officers in the State;(b)may require any Mineral Concession holder by notice to produce or caused
to be produced before him such documents, accounts or other evidence which may be deemed
fit;(c)may suo motto call for and examine the record of any proceeding conducted by any authority,
officer or person subordinate to him under the Act and these rules and if he considers that any orderBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

passed therein is erroneous or is prejudicial to the interest of revenue, mining rules and
environmental conditions, pass such order as he deems fit after giving the Mineral Concession
holder or the person concerned an opportunity of being heard;(d)shall monitor the activities of the
Mineral Concession holder and if he is prima facie satisfied that any Mineral Concession holder has
violated all or any of the condition of the lease/ settlement or is not complying to any lawful
direction issued by any authority, he shall direct the Collector to take legal action against the
Mineral Concession Holder.
8. Power and function of Director Mines.
(1)He shall head the Directorate of Mines and shall exercise administrative control over all Mining
Officers of the Department.(2)He shall be responsible for the security of all mining operations in the
State. He shall also be responsible for ensuring that the interest of the State are protected and all the
Mineral Concession Holder, Corporation, other licensees operate as per the provisions of the Act
and these rules.(3)He shall be responsible for the collection of royalty and other revenues
payable.(4)There may be a Directorate of Security under him which shall employ adequate
personnel on either deputation or recruitment from Civil / Police Personnel or retired Defence/Para
Military/ Police Personnel.(5)The Directorate of Security shall function under the control and
supervision of Director and shall discharge such duties as may be assigned to it by the
Director.(6)The structure of the Directorate of Security shall be approved by the State Government.
9. Mining Officers at the District Level.
- All districts of the State shall have a Mining Office headed by an appropriate Mining Officer to be
appointed by the State Government.
10. Persons with Special Powers.
- The State Government may, by notification, and in order to implement the Act and these rules,
empower any Government functionary not being a Mining Officer, with powers to perform all or any
of the functions of any Mining Officer under these rules, and such person shall, in exercise of these
functions, be deemed to be a Mining Officer.Chapter - III General Restriction On Undertaking
Mining Operation
11. Prohibition of mining operation without permit or mining lease.
(1)No person shall undertake any mining operation in any area, except under and in accordance
with the terms and conditions of a quarrying permit or, as the case may be, a mining lease, granted
under these rules;Provided that nothing in this sub-rule shall affect any mining or quarrying
operations undertaken in any area in accordance with the terms and conditions of a mining lease or
quarrying permit granted before the commencement of these rules which is in force at the time of
such commencement.(2)No quarrying permit or mining lease shall be granted otherwise than in
accordance with the provisions of these rules.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

12. Restriction on the grant of quarrying permit or mining lease.
(1)No mineral concession shall be granted in respect of any land-(a)to a person who is not an Indian
national except with the previous approval of the Government;(b)in respect of land notified by
Government as reserved for the use of the Government, local authorities or for any other public or
for special purposes except with the previous approval of the Government;(c)in reserved and
protected forest area without consulting the Divisional Forest Officer concerned;(d)in respect of any
land within a distance of 50 meters from any village, bridge, national highway or reservoir except
with the prior approval of the State Government.(e)falling within 'forest' as identified by
Environment & Forest Department according to its dictionary meaning except after obtaining
clearance under the Forest Conservation Act, 1980;(f)falling within protected areas, such as national
parks, sanctuaries, community reserves, eco sensitive zone, notified wetlands and wild life
corridors;(g)falling within bio-diversity heritage sites as defined under the provisions of the
Biological Diversity Act, 2002 (Central Act No.18 of 2003); and(h)notified by the State Government
from time to time as no mining zone.(2)No mining lease and quarry permit shall be granted for any
such minor minerals as the State Government may notify in this behalf.Provided that such
notification may be for the whole State or any part thereof.
13. Boundaries below the surface.
- Boundaries of the area covered by a mineral concession shall run vertically downwards below the
surface towards the center of the earth.
14. Maximum and Minimum area for a Mining lease/ Settlement.
(a)No person shall acquire in the State in respect of any minor mineral one or more mineral
concessions covering a total area of more than 200 (Two hundred) hectares. Provided that in case of
settlement of sand this limit shall be applicable only for rivers mentioned in clause 5(i) of Bihar
Sand Mining Policy, 2019.(b)The minimum area for grant of a mineral concession shall be 5 (five)
hectares.
15. Mineral concession to be in a compact block.
- No mineral concession shall be granted in respect of any area which is not compact and
contiguous.
16. Duration of mineral concessions.
- The duration of the mineral concessions for minor minerals shall be 5 years.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

17. Mining Plan.
- Each Mineral Concession Holder/Government/ Corporation as the case may be shall have to
submit a Mining Plan, to the Department/Mining Officer before commencing the mining operation.
Such mining plan shall be prepared by any Recognized Qualified Person.(1)Essential Factors to be
considered for preparation of Mining Plan.-While preparing the Mining Plan the following issues
should be taken into consideration:-(i)Estimated level of production.(ii)Estimated level of
mechanization.(iii)Type of machinery to be used.(iv)Estimated quantity of diesel / fuel
consumption.(v)Estimated number of trees to be uprooted due to mining operation.(vi)Previous
level of the river-bed, quarry-bed to be ascertained by RQP and stated in the plan for calculation of
mineable minerals.(vii)Ascertaining water level at mine-site and stating same in mine plan to avoid
mining below ground water level as well as for study of ground water level.(viii)In case of mining of
River-bed material calculation of Annual Rate of Replenishment for Sustainability of Sand Mining
as per guidelines of MoEF & CC.(ix)Study to show the Annual Replenishment of sand in mining
lease area being sufficient to sustain mining operations at level prescribed in the mining
plan.(2)Important aspects of Mining Plan.-The said Mining Plan shall incorporate-(i)The plan of the
precise area showing the nature and extent of the minor mineral reserve;(ii)Spot/ spots where the
excavation is proposed and its extent;(iii)A detailed cross section and detailed plan of spots of
proposed excavation.(iv)Details of the geology of the precise area including minor mineral reserves
of the area.(v)The extent of manual mining/ mechanised mining in the precise area.(vi)Measures
under Mine Closure plan -Progressive and Final Mine Closure plan.(vii)Annual programme and
plan for excavation in the precise area from year to year for the entire mineral concession
period.(viii)Tree/Plants conservation and development plan.(ix)Any other matter which the State
Government may require to be provided in the mining plan.(3)The mining plan shall be prepared by
a person who shall possess the qualification and experience as specified below.-(i)a degree in mining
engineering or a post-graduate degree in geology granted by a University established or
incorporated by or under an Act of Parliament or State Legislature or any institution recognized by
the University Grants Commission established under section 4 of the University Grants Commission
Act, 1956 (Central Act No. 3 of 1956) or any qualification equivalent thereto; and(ii)Professional
experience of five years of working in a supervisory capacity in the field of mining after obtaining the
qualification as specified in clause (i):Provided that the person is empanelled with State
Government or other State Government or Central Government.(4)Approval and submission of
Mining Plan.-All Mineral Concession Holders or the Government/Corporation as the case may be
shall submit a mining plan duly prepared by an RQP and approved by the Director or any officer /
person/academic institution/Govt. agency authorized by the Department in this regard within a
period of three months from the date on which communication regarding grant of mineral
concession is received or such other period as may be decided/ allowed by the department for the
submission of the approved mining plan.Provided that in case mine plan is prepared by the
department through agencies, the cost shall be realized from the concerned Mineral Concession
holder/ settlee.(5)Period of validity of Mining Plan.-The mining plan, once approved shall be valid
for the entire mineral concession period unless revised/modified during the mineral concession
period.(6)Modification of Mining Plan.-(i)The Director or any person authorized in this behalf by
the Department may require the holder of a mineral concession to make such modifications in the
mining plan or impose such conditions as it considers necessary by an order in writing if suchBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

modifications or imposition of conditions are considered necessary.(a)In light of the experience of
operation of mines.(b)On account of change in the technological development.(c)In light of any
change in the legal provisions or the orders of any court.(ii)A Mineral Concession Holder, desirous
of seeking modifications in the approved mining plan, shall apply to the Department or any person
authorized in this behalf setting forth the intended modifications and explaining the reasons for the
same.(iii)The Director or any officer/ person / academic institution/ Govt. agency authorized in this
behalf by the Department may approve the modification or approve with such alterations as it may
consider expedient within a period of sixty days from the date of receipt of such application for
modification of mining plan.(iv)Where no decision is communicated within the aforesaid period of
sixty days, the mining plan or modified mining plan or scheme of mining, as the case may be, shall
be deemed to have been provisionally approved, till such time a final decision in the matter is
communicated.(v)In case of any increase in lease area or production capacity prior approval of
competent authority of MoEF & CC has to be obtained.(7)(i)Mine Closure Plan- Every mine shall
have Mine Closure Plan which shall be of two types -Progressive Mine Closure Plan; and Final Mine
Closure Plan.(ii)Submission of Progressive Mine Closure Plan.-(a)The owner, agent or manager of a
mineral concession shall submit a progressive Mine Closure Plan as a component of mining plan to
the officer authorized by the Department in this behalf as the case may be for approval within a
period of one year from the date of grant of such mineral concession.(b)The officer authorized by the
Department in this behalf shall convey his approval or refusal of the progressive mine closure plan
within ninety days of the date of its receipt.(c)If approval or refusal of the progressive mine closure
plan is not conveyed to the owner, agent or manager of the mineral concession the progressive mine
closure plan shall be deemed to have been provisionally approved, and such approval shall be
subject to final decision whenever communicated.(iii)Submission of Final Mine Closure
Plan.-(a)The owner, agent or manager of a mineral concession shall submit a final mine closure plan
to the officer authorized by the Department in this behalf for approval one year prior to the
proposed closure of the mine.(b)The officer authorized by the Department in this behalf shall
convey his approval or refusal of the final mine closure plan within ninety days of the date of its
receipt to the owner, agent or manager of the mineral concession.(c)If approval or refusal of the
final mine closure plan is not conveyed to the owner, agent or manager of the mineral concession,
the final mine closure plan shall be deemed to have been provisionally approved and such approval
shall be subject to final decision whenever communicated.(d)The essential factors for preparation of
mine plan, modified mine plan and submission of final mine closure plan shall be subject to
guideline issued from time to time by the State Govt./ Central Govt.
18. Protection of Environment.
(1)Every holder of a mineral concession shall take all possible precautions for the protection of
environment and control of pollution, while conducting mining operation, beneficiation, crushing or
any other allied activity.(2)Environmental Clearance- All Mineral Concession Holders or the
Government/Corporation as the case may be shall obtain prior environmental clearance as per the
prevailing Environmental Impact Assessment notification and latest instructions issued by the
Competent Authority of the Ministry of Environment and Forest, Government of India in this regard
and as per the provisions of the Environment Protection Act.Provided further that the Mineral
Concession Holder shall obey and comply with such other instructions, regarding environmentalBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

protection and Environmental Clearance issued from time to time by the Government of India, State
Government, Central Pollution Control Board, State Pollution Control Board and the Collector of the
District.(3)Mining operation to be in accordance with Environmental Clearance-All mining
operations shall be in accordance with the terms and conditions laid under the environmental
clearance.
19. Contribution to the District Mineral Foundation.
(1)The mineral concession holder shall deposit or make payment to the District Mineral Foundation
which is created as per the District Mineral Foundation Rules at the rate prescribed by the State
Government for the benefit of the persons and areas affected by mining and quarrying.(2)The
manner in which payment is required to be made and the mode of payment shall be prescribed by
the State Government in the relevant rules.
20. Mining in the Forest Areas.
(1)The minor minerals lying inside any forest area may be settled by the Collector with the condition
that the prospective Settlee brings the due permission from the Forest Department under the Forest
Conservation Act,1980.(2)The formal mining lease deed shall be executed only after the required
clearance from the Forest Department is received.
21. Other Conditions.
(1)The Department may require any Mineral Concession Holder to take up environmental friendly
activities and set up such modern facilities like weigh bridges, computers, offices at the mining sites
or his premises.(2)The Department may lay down such other conditions from time to time on the
Mineral Concession Holders as it may deem fit in order to enforce the provision of the Act and these
rules. These may, inter alia, include such conditions as are peculiar to a particular minor mineral or
a particular geographical area.Chapter - IV Procedure For Grant of A Mining Lease Except Sand
22.
Any mineral concession in the form of a mining lease shall be settled by means of public auction
cum tender only through e- bidding mode and as per the procedure laid in the latest notification
issued by the State Government in this regard or as decided by the State Government in this regard
from time to time.(1)For the purpose of grant of mineral concession by public auction cum tender
the Collector shall notify the following particulars of the area, namely:-(a)Toposheet No. extent of
the area and boundaries.(b)Name of village, Circle, Plot No. Khata No. etc.(c)The period of mineral
concession.(d)Date of auction shall be notified before one month from the date of auction.(2)Every
bidder of mineral concession shall file required documents before public auction cum tender as
notified by the State Government in this regard from time to time including.(a)Clearance Certificate
in respect of mining dues, such as royalty or dead rent and surface rent as obtained from competent
officer.(b)An affidavit stating that the applicant has-(i)Filed up-to-date income tax return.(ii)PaidBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

the income tax assessed on his total income.(c)Amount equivalent to 10[ten percent] of auction
amount as security which shall be adjusted with the last installment of auction amount if the mining
leaseholder is not otherwise defaulter in payment. In case of unsuccessful bidder the security
deposit shall be refunded by the Collector.(3)Payment of bid amount.-The bid amount shall be
deposited in yearly basis in equal installments and each installment shall be deposited sixty days
before the completion of one year from the date of execution of the lease during the first year
followed by the same procedure in the consecutive years.Provided that leases executed before the
commencement of this rule shall continue to deposit yearly instalments before 31st January of every
year.Provided further that notwithstanding repugnant in these Rules or otherwise the settlee shall
pay extra royalty for the quantity of mineral extracted and dispatched in excess of the quantity
equivalent to bid amount.(4)Default in payment.-If any installment shall not be deposited before
prescribed period, 24 percent simple interest shall be charged up to two months and after that
action for cancellation shall be taken.(5)Fixation of Minimum Reserve Value.-The fixation of
minimum reserve value shall be as decided by the Department from time to time.(6)Failure on the
part of the successful bidder.-In case the successful bidder fails to deposit the required security
deposit along with other payable taxes within the prescribed time limit as referred to in the
prevailing notification of the State Government in this regard, his security deposit shall be forfeited
and a fresh settlement process through public auction shall be initiated.
23.
All such minerals notified by the Central Government vide notification no. SO 423(E) dated
10.02.2015 and contained in Schedule-IIIA shall be settled through public auction-cum-tender
through e-bidding mode or as decided by the State Government in this regard from time to time.
24. Application for grant of mining leases.
- Notwithstanding anything contained in this rules any application for grant of mining lease shall be
disposed of in the following manner-(1)(a)A mining lease except of granite shall be granted by the
Collector,(b)Mining lease of granite shall be granted by the State Government.(2)Every application
for a mining lease in respect of any mineral shall be made in Form "A" to the competent officer or
any other officer authorised by the Collector.(3)Every application for a mining lease shall be
accompanied by a fee of Rs. 10,000/- and details of the land in respect of which the mining lease is
applied for, and where so required, certified copy or copies of the relevant extracts of the record of
rights.(4)Every application for mining lease shall be accompanied by a valid clearance certificate of
payment of mining dues such as royalty or dead rent, surface rent and cess upto the end of last
financial year in respect of all mineral concessions held in the State of Bihar.(5)Every application
shall be accompanied by an affidavit stating that the applicants has-(a)filed Income-Tax returns
up-to-date;(b)paid the Income- Tax assessed on him; and(c)paid the Income-Tax on the basis of self
assessment as provided in the Income-Tax Act, 1961.(6)Every application shall be accompanied by
an affidavit showing particulars of areas mineral wise in such State, which the applicant or any
person jointly with him -(a)already holds under a mining lease;(b)has applied for but has not been
granted; and(c)being applied for simultaneously.(7)Every application for grant of mining lease,
where the land is not owned by the applicant shall be accompanied by a statement in writing thatBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

the applicant has obtained surface right over the area or has obtained the consent of the owners for
starting miming operation Provided that no such statement shall be necessary where the land is
owned by the State Govt.Provided further that consent of the raiyats/owners of the land for starting
mining operations in the area or part thereof shall be furnished after execution of the lease deed but
before entry into said area;When an application for a mining lease is not accompanied by the papers
specified in sub rules (2) to (7), it shall be rejected by the Competent Officer within a period of 15
days from the date of its receipt.
25. Survey of the area.
- Survey and demarcation of the area under a mineral concession shall be done by the mineral
concession holder and verification of the same shall be done by the competent authority. No mining
or quarrying operation shall commence before verification of the boundaries of the applied area for
grant of mining lease or quarry permit.
26. Conditions.
(1)(a)Every mining lease shall be in Form 'B' or in a Form as near thereto as circumstances in each
case may require.(b)The conditions embodied in Form 'B' shall be deemed to be conditions imposed
under this Rule and shall be binding upon the lessee.(2)The mineral concession holder shall erect
boundary pillars at regular intervals (not exceeding twenty meters in any case) at the boundary of
the lease hold area. The said boundary pillars should be made of reinforced concrete pillars of
dimension of minimum one square feet and height of 1.5 meters, 1/3rd of which shall be erected
below the ground. The part of the pillar above the ground shall be painted in white and black colour
alternately (in zebra style) so as to render it distinctly visible.(3)The Collector may impose such
other conditions as he deems necessary in regard to the following namely-(a)The time limit, mode
and place of payment of rents and royalties;(b)The mineral concession holder shall pay to the
occupier of the surface of the land such compensation as may become payable under these
rules.(c)The mineral concession holder shall take such measures for planting in the same area or
any other area selected by the Central or state Government not less than twice the number of trees
destroyed by reasons of any mining operation or to the extent possible, the restoration of flora and
other vegetation destroyed by such operation.(d)The restriction of surface operations in any area
prohibited by any authority;(e)The notice by mineral concession holder for surface
occupation;(f)The provision of proper weighing machines;(g)The facilities to be given by the mineral
concession holder for working other minerals in the lease area or adjacent area;(h)The reporting of
accidents;(i)The securing of pits and shafts;(j)The indemnity to Government against claims of third
party;(k)The delivery of possession of lands and mines on the surrender, expiration or
determination of the lease;(l)The forfeiture of properly left after determination of the lease;(m)The
power to take possession of plant, machinery, premises and mines in the event of war or
emergency;(n)The lessee shall not pay a wage lesser than the minimum wage prescribed by the
Central or State Government from time to time under the Minimum Wages Act, 1948.(4)The
Collector, if he is of the opinion that in the interest of mineral development it is necessary so to do,
may, in any case with the previous approval of the Government, impose such further conditions as
he thinks fit.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

27. Application for the transfer of mineral concession.
(1)The transferor and transferee interested in the transfer shall produce valid clearance certificate of
payment of mining dues such as settlement amount, royalty, dead rent, surface rent etc.(2)(a)The
mineral concession holder shall not assign, sub-let, mortgage or in any other manner transfer the
quarrying lease or any right, title or interest vested therein unless prior order of Collector has been
obtained, to any other person.(b)Every Mineral Concession Holder seeking prior order under
sub-rule (1) shall make an application to the Mining Officer which shall be accompanied by a letter
of consent of the owner or occupant of the land to the effect that he has no objection for quarrying
minor minerals by the transferee.(c)Transfer of Mine ral Concession shall require transfer of EC by
competent authority of MoEF & CC from transferor to transferee.
28. Execution of lease.
(1)Where a mineral concession is granted under the rules the formal lease deed shall be executed by
the Collector in Form "B" within 180 days of the order sanctioning the lease and if the person to
whom such mineral concession has been granted fails to submit the required documents for
execution within the aforesaid period the order sanctioning the lease shall be deemed to have been
revoked, and in that event the application fee and the security deposit shall be forfeited.Provided
that no lease shall be executed unless the person to whom such lease has been granted submits the
mining plan and environment clearances as required under these rules.Provided further that where
the Collector is satisfied that the person to whom such lease has been granted is not responsible for
the delay in execution of the formal lease, he may permit the execution of the formal lease even after
the expiry of the aforesaid period of 180 days.(2)The date of the commencement of the period for
which a mineral concession is granted shall be the date on which the mining lease deed is executed
under sub-rule (1) and the lessee shall be liable to pay rent/royalty from the date of the execution of
the mining lease.(3)The lease dead has to be duly registered by paying proper stamp duty and
registration fees.(4)No claim for extension of lease period shall be entertained for any delay.Chapter
- V Settlement of Sand
29.
(A)Mode of Settlement. - (1) The settlement of sand as minor mineral shall be done by public
auction-cum-tender through e-bidding mode in favour of the highest bidder by the Collector/any
officer so authorised by the State Government.(a)The State Government shall issue a notification
regarding mode & detailed procedure for settlement of sandghats from time to time as and when
required.(b)The highest bidder shall deposit 10% of the auction amount immediately after the
auction, following which an in-principle sanction order shall be issued in his favour by the
Collector/ any officer so authorised by the State Government.(c)The highest bidder shall submit the
required documents within the prescribed time limit as referred to in the prevailing notification
issued by the State Government in this regard, following which the work order shall be issued in his
favour by the Collector/ any Officer so authorised by the State Government.(d)The successful bidder
or the Government/ Corporation as the case may be shall submit a mining plan prepared for the
respective sandghats and shall be approved by the Director or any person / officer authorised in thisBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

regard.(e)The successful bidder or the Government/ Corporation as the case may be shall obtain
environmental clearance from the competent authority as per the prevailing Environmental Impact
Assessment notification of the Ministry of Environment, Forest & Climate Change, Government of
India and as per the provisions of the Environment Protection Act.(2)Restricted areas for sand
quarrying, -(i)The quarrying of sand shall be prohibited within 300 (three hundred) meters on both
sides of any railway bridge or any bridge falling under any National Highway/ State Highway and
shall be prohibited within 100 (one hundred) meters of both sides of any other bridge. However the
prohibited zone in respect of any particular bridge may be extended by the State Government
through a notification in this regard, if so required for reasons of safety.(ii)No quarrying shall be
permitted within 50 (fifty) meters of any public place i.e. Cremation ghat or any religious place
etc.(iii)No quarrying shall be permitted within 5 (five) meters from both banks of the river.(iv)The
quarrying of sand shall be prohibited within 100 (one hundred) meters upstream and downstream
from any dam/ weir or any other structure erected for irrigation purpose.(v)Sandghats should
preferably be located on the river side of embankment. For low embankment less than 6 metres
height, quarrying should not be done within 25 metre from toe/heel of the embankment and depth
of mining should not be more than 1.00 metre. In case of higher embankments, the distance should
not be less than 50 metre and depth of mining should be maximum 1.50 metre and at a distance of
75 metre or more mining depth should be maximum 2.00 metre. In order to obviate the
development of flow parallel to embankment, crossbars of width eight times the depth of mining
pits spaced at 50 to 60 metres center to center should be left in the mining pits.(vi)The irrigation
outlet shall be maintained at the same level as that of the riverbed and in no case the river bed level
shall be permitted to be below the irrigation outlet level. No quarrying shall be permitted around the
infiltration well/ intake well up to a distance of 5 meters.(vii)The extraction of sand shall be
permitted only after obtaining a No Objection Certificate from the Water Resources Department in
the case of rivers where from irrigation channels are out flowing.(viii)No quarrying of sand shall be
permitted in any private land owned by any person unless the settlee obtains the consent of the
concerned land owner /raiyat.(ix)No quarrying of sand shall be permitted in any area which the
State Government notifies as a restricted area.(3)Maximum depth of Sand Mining. - The maximum
depth of mining in the river bed shall not exceed 3 (three) meters measured from the unlined bed
level at that point of time or the water level whichever is less. All such pits formed during the course
of excavation shall be filled on a regular basis.(4)Fixation of Minimum Reserve Value. -(i)The
minimum reserve value shall be fixed as decided by the Department.(ii)If no bidder turns up during
the auction process on the fixed minimum reserve value, even after three attempts, the minimum
reserve value shall be revised by the departmental technical committee on the basis of sand reserve
in the concerned area, other local/ technical conditions and recommendation received from district
level committee headed by Collector. A re-auction of the said reach/sand block/sand ghat shall be
conducted on the basis of revised minimum reserve value after taking approval of the State
Government.(5)Failure on the part of the successful bidder. - In case the successful bidder fails to
deposit the required security deposit along with other payable taxes within the prescribed time limit
as referred to in the prevailing notification of the State Government in this regard, his security
deposit shall be forfeited and a fresh settlement process for the concerned sandghats through public
auction shall be initiated.(B)Payment of Security Deposit. -(1)Every settlee of sand as minor mineral
shall deposit the amount equivalent to 10 (ten) percent of auctioned / tendered amount as security
for due observance of the terms and conditions of settlement which shall be refunded after theBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

expiry of the period of settlement / adjusted with the last installment of the settlement by the
Mining Officer (as defined in the rules).(2)Award of Concession and Signing of Deed. - The
successful bidder shall be awarded the concession to mine sand for a period of 5 years. The
successful bidder shall execute the settlement deed in form 'B' as prescribed in this rule or a form as
near thereto before starting work. In case the approval of mining plan and the environment
clearance have not been obtained, successful bidder shall obtain the same before the execution of
settlement deed.(3)Mode of Payment of Royalty / Settlement Amount. -(i)The settle shall make
payment of the settlement amount as laid down in the Tender Document.(ii)In case the royalty
computed on annual basis for the mineral extracted exceeds the annual settlement amount, the
settlee shall be liable for payment of excess royalty for the additional quantity as extracted in
addition to the settlement amount.(4)Default in Payment-In case of default in payment of any
installment within prescribed date, a simple interest at the rate of 24 percent per annum shall be
charged.(C)Observance of terms & conditions of mining plan/ environmental clearance. - The
settlee shall observe the terms and conditions of the mining plan as well as the terms and conditions
laid in the Environmental Clearance pertaining to the concerned settlement.(D)Deployment of
Machinery in sandghats. - The settlee shall follow stipulations enumerated in Sustainable Sand
Mining Management Guidelines, 2016/conditions specified in Environmental Clearance.(E)Online
Sand Portal. - The Settlee shall make sale of sand to all consumers (small, medium or large) either
through online or offline mode. All transactions/payments, excavation, production / transportation,
stocking details shall be captured through the departmental online real time monitoring system.
Sale of sand shall be controlled by electronic documentation linked to a central documentation
monitoring facility and all lessee shall upload a monthly progress report on the departmental portal
without fail.(F)Installation of Weighbridges. - Each sandghat may have an electronic weigh-bridge,
integrated with central server. However for adjacent sandghats, department may allow use of
common weighbridge. Any vehicle found carrying sand without proper weighment slip/ e-challan
shall be liable to be seized under the provisions of the Mines and Minerals (Development and
Regulation) Act, 1957 or the rules made there under.(G)Government's Right to undertake De-silting.
- The Government reserves the right to take up desiltation projects, in such allocated mining blocks,
to maintain the river flow, safeguard the embankments and habitations along the rivers on account
of geo-technical and hydrological considerations. The department shall issue guidelines for disposal
of sand excavated in the process of De-silting.(H)Removal of subsoil sand from raiyati land. - The
settlee may remove subsoil sand from raiyati land after taking consent and adequately
compensating the land owner. Such proposals shall be included in mine plan and due environmental
clearance from concerned competent authority of MoEF & CC has to be obtained before starting
mining operations.(I)No objection from Water Resources Department. - In case of lifting sand from
any sandghat if any natural water course / irrigation canal falls in between the link road and the
sandghat then the settlee may erect temporary structure for transportation of sand with prior
permission of water resources department. Such application for prior permission shall be submitted
by the settlee before the concerned Chief Engineer of Water Resources Department. If no decision is
communicated in this regard to the settlee within one month from the date of application then it will
be deemed that the concerned Department has no objection in the proposal.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

30. Penalty In case of breach of terms.
(1)In case of mining within restricted area or mining sand beyond a depth of 3 meters, a penalty of
Rs. One Lakh shall be imposed by the Col lector against the settlee for a first time violation.(2)For a
second time violation a penalty ranging from Rs. Five lakh to rupees ten lakhs may be imposed
against the settlee keeping in view the gravity of the violation.(3)Wherever a settlee is found
indulging in such offence for the third time or more the settlement of that particular sandghat may
be suspended by the Collector temporarily for a maximum period of one month until such breaches
are rectified. If the breaches are not rectified in the time given by the Collector in this regard, action
for cancellation of the settlement of the concerned sandghat shall be taken in extreme
condition.(4)Transportation of sand shall be carried out through covered carriers only and no wet
sand shall be loaded in carriers. The Competent Authority shall impose fine equivalent to market
price of sand loaded in the said carrier for any transportation of wet sand and sand transported
uncovered from the transporter.Chapter - VI Role of State Owned Mining Corporation
31. Activities by the Bihar State Mining Corporation.
(1)The State Government may entrust all or any of the mining activity or trade to Bihar State Mining
Corporation. The Corporation may undertake, in particular, mining activity, wholesale trading,
retail trading, storage, and transportation etc. of sand.(2)The Corporation may enter into an
arrangement with any Government or semi Government or private undertaking for the said
purpose.
32. Corporation to buy minerals at prescribed rates.
- The Department may direct all Mineral Concession Holder to sale some proportion of their
produce which should not exceed 50 % of their total produce to the corporation at pit head
cost.Chapter - VII Procedure For Grant of Quarrying Permit
33. Grant of quarrying permits.
(1)On an application made to him, the Mining Officer may grant a quarrying permit in Form "D" to
any person to extract and remove from any specified land within the limits of his jurisdiction any
mineral except sand & stone not exceeding Ten thousand cubic meters in quantity under anyone
permit, on pre-payment of royalty at the rates specified in Schedule III'A'. Before granting such
permit, the Competent Officer shall satisfy himself that the requirement of the permit is genuine and
that it does not obviate the necessity of obtaining a mining lease in the area in respect of which the
permit for extraction of the mineral has been applied for.(2)The Mining Officer may refuse the issue
of such permits for reasons to be recorded by him in writing.(3)The permits for extraction of
ordinary earth under this rule shall not be granted for excavation beyond a depth of three feet for
areas where "sand deposits" are available below the ordinary earth/clay/soil. No raiyat can claim for
any permit from any specific land already leased/ settled to anybody for mining.(4)The department
may issue instructions for ban of granting Quarrying Permit for any particular mineral or minerals.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

34. Application for quarrying permit.
(1)An application for quarrying permit shall be submitted to the Mining Officer in Form 'C'.(2)Every
application for quarrying permit shall be accompanied by a fee of [Rs.5,000/-]. (for Bangla Brick
kiln the fee for quarrying permit shall be Rs. 500/- only).(3)Every application for quarrying permit
shall be accompanied by a valid and up-to-date clearance certificate of payment of mining dues, if
any. Every application of a quarrying permit shall, if the lands from which the minor mineral is to be
extracted are raiyati lands, be accompanied by a written consent letter from the occupant of such
lands to the effect that he has no objection to the extraction of the mineral by the applicant.(4)The
application fee and royalty shall not be refunded if the raiyat subsequently refuses permission to the
permit holder to work in the raiyati area.(5)Every application for the extension of the period of the
permit shall be accompanied by a fee Rs. 1000.(6)The area applied for grant of quarrying permit
shall be in a compact block covering not more than 5 hectares.
35. Disposal of application for quarrying permit.
(1)An application for the grant of quarrying permit shall be disposed of by the Mining Officer within
30 days from the date of its receipt.(2)If any application is not disposed of within the period
specified in sub-rule (1), it shall be deemed to have been rejected.
36. Conditions on which the quarrying permit shall be granted.
(1)Every quarrying permit granted under rule 33(1), shall contain a condition that the depth of the
pit below the surface shall not exceed 3 meters.(2)Any quarrying permit granted under rule 33(1)
may contain such other conditions as deem necessary in regard to the following matters, namely:
-(a)Time limit, mode and place of payment of rents and royalties;(b)Compensation for damage to
the land covered by permit;(c)Felling of trees in consultation with Divisional Forest Officer in case
of forest areas and in consultation with the Additional Collector in other areas;(d)Restriction on
surface operation in any area prohibited by any authority;(e)Reporting of accidents;(f)Indemnity to
Government against claims of third parties;(g)Period within which the minor mineral shall be
extracted and removed and delivery of possession over lands on the expiry of such period or on the
removal of the quantity of the minor mineral for which the permit is valid;(h)Forfeiture of property
left after cancellation of the permit; and(i)Disposal of minerals in stock at site after expiry of the
permit.(3)In case of breach of any of the conditions subject to which the permit is granted, the
Mining Officer may cancel the permit issued by him. On cancellation of the permit, the quarried
material lying on the land from which they are extracted shall become the absolute property of the
Government and shall be sold by public auction by the Mining Officer.(4)The Mining Officer after
enquiry and verification shall assess amount of royalty and penalty for the excess quantity at the end
of the prescribed period.(5)Every permit holder shall obtain a prior environmental clearance as
specified in Rule 18 (2).(6)Every permit holder shall also abide by the following conditions -(i)The
activity associated with mining / excavation of brick earth and ordinary clay / earth for purpose of
brick manufacturing, construction of roads, embankments etc. shall not involve blasting.(ii)The
mining / excavation activity shall be restricted to a maximum depth of 3m below normal ground
level at the site.(iii)The mining / excavation activity shall be kept above the ground water table at theBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

site.(iv)The mining / excavation activity should not alter the natural drainage pattern of the
area.(v)The mined/ excavated pit shall be restored by the project proponent for useful
purpose(s).(vi)Appropriate fencing all around the mined / excavated pit shall be made to prevent
any mishap.(vii)Measures shall be taken to prevent dust emission by covering of mined /excavated
earth during transportation.(viii)Safeguard shall be adopted against health risks on account of
breeding of vectors in the water bodies created due to mining/ excavation of earth.(ix)Workers /
labourers shall be provided with facilities for drinking water and sanitation.(x)A berm shall be left
from the boundary of adjoining field having a width equal to at least half the depth of proposed
excavation.(xi)A minimum distance of 15 m from any civil structure shall be kept from the periphery
of any excavation area.(xii)No mining of earth / excavation of 'brick earth' or ordinary earth shall be
permitted in case the area of mining excavation is within 1km of boundary of national parks and
wild life sanctuaries:Provided that the permit holder shall abide by any other condition imposed or
any instruction issued by the Central Government / State Government in this regard."
37.
(1)Grant of Mineral Disposal Permit for mineral encountered in the process of construction of
Building /Structure/Development Projects. - Notwithstanding anything contained in these rules,
where any mineral is encountered in the process of construction of any building or a development
project and has to be extracted in the process of execution of such project the Collector on a report
from concerned mining officer may grant a permit for removal and use of any such minor mineral
from any specified land not already leased/settled to anybody for mining. The said permission may
be granted on payment of the applicable royalty and other charges to the Government in advance for
the specified quantity and period not exceeding three months.(2)Grant of Mineral Disposal Permits
for minerals excavated in the process of maintenance of Canal and Drainage System by the
Department of Irrigation. - Notwithstanding anything contained in these rules where any silt or
sand or ordinary earth or any other minor mineral is extracted in the process of maintenance and
upkeep of a canal or drainage system or clearance of drains, the Collector on a report from
concerned mining officer may grant a permit for removal and use of any such minor mineral. The
Executive Engineer concerned shall submit an application before the concerned mining office for
issue of permit for disposal of the said mineral. The said permission may be granted on payment of
the applicable royalty and other charges to the Government in advance for the specified quantity
and period not exceeding three months.(3)Permits for specific emergency situations. -
Notwithstanding anything contained in these rules the Collector may grant permit for extraction of
minor minerals from such area which has not been granted on mineral concession to such
government department or any other government agency or any individual requiring mineral for
execution of works relating to emergent flood protection works or any other natural calamity or
other pressing circumstances for safety of human and cattle life under emergency conditions. The
said permission may be granted on payment of the applicable royalty and other charges to the
Government in advance for the specified quantity.All application under Rule 37(1), (2) & (3) shall be
in Form"E" and the permits shall be granted in Form "F".Chapter- VIII Regulation and Revenue
Collection From Brick KilnBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

38.
(1)Consolidation of royalty on brick earth. - Notwithstanding anything contained in these rules, the
State Government shall determine a consolidated amount of royalty which may be revised once in
three years, to be paid by the Brick Kiln owner/brick earth remover per kiln per annum as
mentioned in Schedule III-B of the Rules to the State Government on a fixed number of bricks for
every classified area.Provided that the State Government may for the purposes of determining the
consolidated amount of royalty to be so paid classify the place into different categories taking such
facts into account which the State Government think proper.(2)Authorisation of Sub divisional
Officer and Circle Officer to take action. - The Sub Divisional Officer (SDO) and Circle Officer of the
area concerned shall be duly authorized to function in the manner provided under this
Rule.(3)Grant of Quarrying permit for Brick Earth. - On an application made to the Mining Officer
by an applicant and on submission of the required documents as prescribed in Rule 34 of these rules
along with the required Environmental Clearance from competent authority as notified by MoEF &
CC, a No Objection Certificate and Emission Consent order from the Bihar State Pollution Control
Board and the consolidated amount of royalty as per Schedule III 'B' of the rules, He/She shall grant
a quarrying permit in form 'D' for extraction and removal of brick earth in respect of any brick kiln
for a particular brick season from any specified land within the limits of his jurisdiction.(4)Mode of
Payment. - The brick kiln owner/brick earth remover shall pay the consolidated amount of royalty
per kiln per annum as per Schedule III 'B' of the rules to the State Government for different areas
within the date as prescribed for the particular brick season shown in the table below:-
Sl. no.Date of deposition of consolidated amount
ofroyaltyAmount to be paid
1. By 30th November95% of consolidated royalty in one
installment
2. By 31st December100% of consolidated royalty in one
instalment
3. By 31st January105% of consolidated royalty in one
instalment
4. By 28/29th February110% of consolidated royalty in one
instalment
5. By 31st March115% of consolidated royalty in one
instalment
6. By 30thJune150% of consolidated royalty in one
instalment
7. After 30th June200% of consolidated royalty in one
instalment
(5)Action for default in payment. - If the brick earth remover /brick kiln owner fails to make
payment of the consolidated amount of royalty in the manner so prescribed of that particular Brick
season, he/she shall not be allowed to carry on the business and the competent officer or any other
officer duly authorised in this behalf by the State Government shall be competent to stop suchBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

business.Explanation. - For the purpose of this rule-(a)Business means and includes laying, burning
or selling of brick by brick earth remover/ brick owner and such other activities as are associated
with manufacturing of bricks.(b)For the purpose of this rule brick earth remover means and
includes person or persons by whom or on whose behalf the brick earth is removed for
manufacturing bricks.(c)For the purpose of this rule brick kiln owner means a person who owns the
bricks kiln or on whose behalf bricks are manufactured in that kiln and includes manager, agent and
lessee of such person(6)Action for non-submission of required clearance from comp competent
authority as notified by MoEF & CCIf the brick earth remover / brick kiln owner fails to submit the
required Environmental Clearance from the competent authority as notified by MoEF & CC and / or
the required Emission Consent Order from the Bihar State Pollution Control Board (BSPCB), the
Competent Officer/ Sub Divisional Officer/ Circle Officer shall stop the business and report the
matter to competent authority as notified by MoEF & CC/ BSPCB for initiating penal provisions for
violation of rules.Chapter- IX Storage of Minor /major Minerals Beyond Lease Hold Area
39.
(1)Every person who carried business of minor/major mineral beyond any lease hold area shall
obtain a stockist license from the Mining Officer in Form-K which shall be displayed at a
conspicuous place of business and shall maintain proper accounts of purchase and sale of all such
minerals in a register in form-H which shall be produced before the Mines Commissioner, Director
of Mines, Additional Director of Mines or Deputy Director of Mines or Mining officer or any other
officers authorised by the Government, for inspection. Every application for obtaining license in
Form-K shall be accompanied with a fee of Rs. 10,000/- (Ten Thousand Rupees)(a)Every such licen
se shall be valid for one calendar year;(b)Every such license may be renewed on application which
shall be accompanied by a fee of Rs. 2000 (Two Thousand Rupees)(2)Every such person as
mentioned in (1) shall issue a transport challan in Form-'G' or in the prescribed format to every
carrier, while dispatching minerals from his stock.(3)If any person as mentioned in (1) fails to
maintain a register in form 'H' or obtain license in Form 'K' or issue a challan in Form 'G' or in the
prescribed format, shall be punishable with simple imprisonment which may extend up to one year
or value of the mineral along with a fine which may extend upto Rs 10,000/- or with both.(4)No
person shall be permitted to erect, install or operate a stone crusher outside a lease hold
area.Provided that the existing stockist license held for stone mineral used for crusher shall remain
operational till the validity of their license period, on the condition of the licensee abiding by all the
relevant rules/provision of law / conditions stated in their license/ conditions stated in CTE & CTO
issued by BSPCB failing which the license shall be cancelled.Provided further that the department
may allow installation of any crusher including mobile crusher within a periphery of 500 meters of
the lease hold boundary to the lease holder or person directly engaged in construction activity on
conditions as decided by the department.
Chapter X
E-RequirementsBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

40. Usage of Electronic Procedures.
- The Mines Commissioner may, by notification, require all Mineral Concession Holder or any other
Stake Holder to file their returns, statements and activities electronically and undertake all or any
operations through electronic mode. Government shall implement all the working system of the
Department through e-office system and ultimately convert to paperless working.
41. E-Challan.
- The movement of all minor minerals, whether by Mineral Concession Holder or by the
Corporation, shall be monitored through e-Challan in Form G or in the prescribed format.
42. Mining MIS.
(1)The Department may also require all the Mineral Concession Holder, the Corporation and other
persons engaged in the transport and trade of minor minerals to come under the purview of the
provision of these rules and under take their activities as per the Mining MIS system to be developed
by the Department.(2)The Department may lay down detailed guidelines for its MIS.Chapter -XI
Grant of Transit Pass/ Challan/ E-Challan For Movement of Minerals
43. Prohibition on Transportation.
- No person shall transport or carry or cause to transport or carry any Ore/ mineral by any means
from the place of raising, leasehold area or the area of stock of minerals to another place without
being in possession of a valid transit pass/ challan/ E-challan in Form-G or in the prescribed format
issued by the Competent Officer under the Rules;
44. Restrictions on Vehicles Carrying Minerals.
- The State Government may lay down reasonable restrictions on the vehicles transporting any
minerals and may require them to adhere to certain specifications.Provided further that the State
Government may direct the owners of transport vehicles to install GPS devices or such other
devices, as it may require and give such directions as it deems fit.
45. Power to Regulate Movement of Minerals.
- The Department may by notification regulate the export of mineral from State to other states. The
department may set up check-post, barriers, weighbridges etc. and such other facilities to regulate
the movement of minerals.If the Department considers it necessary to do so with a view to check the
transport and storage of minerals transported without lawful authority, it may direct the setting up
of check-post or erection of barrier or both at any place or places within the state by an order in
writing.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

46. Registers, returns and Signboard.
(1)Every Mineral Concession holder shall maintain Register in Form 'H' in which day to day
transaction shall be entered. He shall also have to display a signboard.(2)Every Mineral Concession
holder shall submit every month to the Competent Officer a true and correct return for minerals in
Form 'I' by the fifteenth day of the following month to which it relates.(3)Every Mineral Concession
Holder shall submit annual returns in Form "J" as appended to these rules before the 30th April of
each year in respect of the preceding financial year.(4)Every Mineral Concession holder shall give all
reasonable facilities to the Mining Officer or Director of Mines or Additional Director of Mines or
Deputy Director of Mines or any other Officer authorised by the Collector in this behalf to inspect,
verify and check the accounts of the minerals.(5)If the accounts, returns and other evidence
produced by the Mineral Concession holder or any other person who has removed minerals, are in
the opinion of any of the officers authorised incorrect, incomplete or unreliable either wholly, or
partly, the officer conc erned, shall report to the Mining Officer who shall proceed to assess to the
best of his judgment, the amount of royalty due from the assessee:Provided that if the mining officer
himself has formed the opinion he shall proceed forthwith to assess to the best of his judgment, the
amount of royalty due from the assessee.(6)The state government in addition to accounts/ returns
or other evidence may also direct to ascertain the actual quantity of mineral excavated during
relevant concession period by deploying modern technology such as aerial survey/ground survey or
any latest method.Chapter -XII Cancellation of Mineral Concession
47. Power to Suspend or Cancel Mineral Concession.
(1)The Collector shall be competent to cancel / suspend any Mineral Concession in his
district.(2)Subject to such restrictions as the State Government may prescribe, the Collector may
suspend or cancel and forfeit the Security Deposit/Earnest Money Deposit of any mineral
concession in the following circumstances after giving reasonable opportunity of being heard -(a)if
wrong documents have been furnished to obtain mineral concession; or(b)if the mineral concession
is transferred or sublet by the holder thereof; or(c)if any mining revenue payable by the holder
thereof is not duly paid; or(d)in the event of any breach by the holder of such mineral concession by
his servant or agent, or by any one acting on his behalf, with his express or implied permission, of
any of the terms and conditions of such mineral concession; or(e)if the holder of mineral concession
or his agent or employee is convicted of an offence punishable under the Act or these Rules or any
other law for the time being in force, relevant and connected with mining matters or matter relating
to mining revenue or of any cognizable and non-bailable offence under any other relevant law;
or(f)if the purpose for which the mineral concession was granted ceases to exist; or(g)if the mineral
concession has been obtained through misrepresentation or fraud; or(h)If the Mineral Concession
Holder has violated any of the conditions mentioned in these rules; or(i)If the Mineral Concession
Holder fails to obtain the environmental clearance or violates any of the condition mentioned
therein; or(j)If the Mineral Concession Holder fails to start mining operation within three months
from the date of executing deed(k)If, for any other reason, the Collector is prima facie satisfied, that
the mineral concession is fit to be cancelled.(3)For any action taken under sub-rule (1), the Mineral
Concession Holder shall not be eligible for any compensation or refund
whatsoever.(4)Notwithstanding anything mentioned above, in case of detection of any violation ofBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

the Act, these rules and any other condition of the mineral concession the State Government or the
Collector may, apart from cancelling the mineral concession, also impose suitable financial penalties
and/or start criminal prosecution.(5)Any such penalties levied shall be recoverable under the Public
Demand Recovery Act, 1914 (Act 4 of 1914).
48. Power of the Collector to take over the Management.
- If any Mineral Concession Holder contravenes any provision of the Act or any rules made there
under or defaults in complying with any condition imposed upon him or upon refusal to abide by
such reasonable directions as the Collector may issue under these rules, or upon expiry of the
mining lease period the Collector, may at any time, with or without cancellation of such mining
lease-(1)Take over the management of such mining operations at the risk and loss of the owner of
that establishment; or(2)Take over the management of such establishment at the risk and loss of the
owner of that establishment; or(3)Transfer the establishment, for the unexpired period of the
mining lease, at the risk and loss of the owner, to any other person or the Corporation.
49. Power of Collector to Requisition Minor Minerals.
- Notwithstanding anything mentioned above, in case of any natural disaster or acute shortage or
such other emergencies or in order to maintain a buffer stock, the Collector may require a Mineral
Concession Holder to produce or excavate a specified quantity of the minor mineral and deliver it to
such a place at such rate as he deems fit.
50. Exit Option for Mineral Concession Holder.
(1)Any Mineral Concession Holder, at any point of the Mineral Concession period, may opt to exit
the business upon giving Six months' notice to the Collector. However, this option is not available to
Mineral Concession Holder who have not paid their bidding amount or settlement amount or have
violated any condition of settlement.(2)The Collector may allow such Mineral Concession Holder to
exit the business and return any security money deposited by the Mineral Concession Holder after
deducting such dues as are recoverable.(3)The Collector, thereupon, shall initiate arrangement for a
fresh bidding.(4)In case of fraud or violation of mining or environmental conditions or any other
irregularities reported, no exit option will be available to the Mineral Concession Holder and their
security deposit shall be forfeited.Chapter- XIII Mining Revenue
51. Rent/royalty and assessment.
- 1. When a Mineral Concession is granted:-(a)Dead rent shall be charged at the rates specified in
Schedule II;(b)Royalty shall be charged at the rates specified in Schedule III(A); and(c)Surface rent
shall be charged at the rate specified by the Collector from time to time for the area occupied or used
by the lessee.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

2. On and from the date of commencement of these rules, the provisions of
sub-rule (1) shall also apply to the leases granted or renewed prior to the
date of such commencement and subsisting on such date.
3. If the Mineral Concession Holder permits the working of more than one
mineral in the same area, the Collector may charge separate dead rent in
respect of each mineral.
Provided that the lessee shall be liable to pay the dead rent or royalty in respect of each mineral,
whichever be higher in amount.
4. Notwithstanding anything contained in any instrument of lease the Mineral
Concession Holder shall pay rent/royalty in respect of any minor mineral
own, extracted and removed at the rate specified from time to time in
Schedule II and III(A).
5. The State Government may, by notification in the official Gazette, amend
the Schedule II, III(A) & III(B) so as to enhance or reduce the rate at which
rents/royalties shall be payable in respect of any minor mineral with effect
from the date of publication of the notification in the official Gazette.
6. The Mining Officer, after such enquiry and verification as he may deem
necessary of the monthly returns furnished by the lessee in Form "I"and
Annual Return in Form "J" shall assess the amount of rent/royalty payable by
the Mineral Concession Holder at the end of the prescribed period.
7. Notwithstanding anything contained in these Rules, the royalty in case of
auction of the minor minerals shall be the amount of auction. In cases where
the royalty on dispatched quantity exceeds the auction amount, the extra
royalty for the excess quantity of mineral extracted shall also be payable.
8. The Mineral Concession Holder shall also pay all assessments and
imposition whatsoever being in the natures of public demands which shall
from time to time be charged, assessed or imposed by the authority of the
State Govt.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

52. Single Bank Account.
(1)All Mineral Concession Holder shall necessarily operate only a single bank account for all their
operations connected with the said lease or the license.(2)The Mineral Concession Holder must
necessarily give the information of the said bank account to the Collector, the Mining Officer of the
district, Director Mines and the Mines Commissioner.(3)Any person who acts in violation of this
provision shall be liable for prosecution.
53. Power to Freeze Bank Account.
- Where the Collector, upon a report by Mining Officer has reason to believe that the bank account
of any Mineral Concession Holder has to be frozen in order to protect Government revenue, he shall
forthwith issue an order directing the concerned bank to freeze the bank accounts of such Settlee /
licensee, till further orders.
54. How the fees and deposit to be made.
- Any amount payable under these rules shall be paid into Treasury either through a paper challan
or an electronic fund transfer.
55.
The Government may, without prejudice to the provisions contained in the Act or any other rule in
these rules; charge simple interest at the rate 24 percent per annum on any rent, royalty or fee or
other sum due to the Government.Chapter-XIV Offences and Penalties
56. Penalty for unauthorized extraction and removal of minor minerals.
(1)Whoever is found to be extracting or removing minor minerals or on whose behalf such
extraction or removal is being made he be an agent, a manager, an employee or a contractor or a
sub-lessee, otherwise than in accordance with these Rules, shall be presumed to be party to the
illegal removal of the minor mineral and every such person shall be punishable with simple
imprisonment which may extend upto two years or with fine, which may extend upto rupees five
Lakhs or with both.(2)If any person in charge of any carrier while carrying mineral fails to furnish
the Challan in Form "G" or in the prescribed format or refuses inspection of such Challan by the
Director of Mines or Additional Director of Mines or Deputy Director of Mines or Mining Officer or
Mining Inspector or any officer authorised by the Collector, such officer shall recover from the
person in charge of the carrier the value of the mineral alongwith fine which may extend upto Rs.
Ten thousand.In case of transportation of mineral without valid challan in Form "G", total value of
mineral and fine which may extend upto Rs. Ten thousand shall be recovered from the person in
charge of the carrier and deposited in the Govt. Head.Provided that when the quantity of mineral
loaded in carrier differs from the quantity mentioned in the challan the authorised officer shall
recover value of the mineral for the difference quantity only along with fine which may extend uptoBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

Rs. Ten thousand. The quantity so assessed shall be based on actual measurement from weighbridge
and not on the basis of eye estimation only.For collection / deposition of penalties so imposed the
department may issue Money Receipts to the concerned Mining Inspector/ Mineral Development
Officer/Assistant Director who after realizing penalty through Money Receipts shall deposit it in
State Exchequer.(3)Whoever removes min or mineral without valid lease/ permit or on whose
behalf such removal is made otherwise than in accordance with these Rules he be an agent,
Manager, contractor or a sub-lessee, shall be presumed to be a party to the illegal removal of the
minor mineral and shall be liable to pay the price thereof and the Government may also recover
from such person rent, royalty or taxes as the case may be, for the period during which the land was
occupied by such person without any lawful authority without prejudice to other action being taken
against him under these Rules or any other law for the time being in Force.
57. Seigniorage Fee from Government Projects.
(1)All the Government Departments, particularly Works Departments using any minor mineral for
their schemes or projects, shall deduct a Seigniorage Fee from their suppliers or works contractors
of such minor minerals.(2)Such Seigniorage Fee shall be at a flat rate of 10(ten) percent of the
mineral value involved in the estimate and shall be deducted by the Works Department from their
supplier/works contractors and deposited with the Mining Officer of the district.Provided that the
State Government may increase or decrease the Seigniorage Fee from time to time.
58. Sale price of Minor Minerals.
- The sale price of minor minerals to the end user or the public shall be decided by the market
forces.Chapter- XV Detection, Investigation and Trial of Offences.
59. Power to enter, inspect, search and seize.
(1)For the purpose of ascertaining the position of the working, actual or prospective of any mine or
abandoned mine or for any other purpose connected with these rules, any of the following Officers
namely:(a)The Mines Commissioner, the Director Mines; or(b)The Collector or any other officer
authorised by the Collector(c)Additional Director, Deputy Director, Assistant Director, Mineral
Development Officer and Mining Inspectors; may,(i)enter and inspect any mine;(ii)survey and take
measurements in any such mine;(iii)weigh, measure or take measurements of the stocks of mineral
lying at any mine;(iv)examine any document, book, register or record in the possession or power of
any person having the control of, or connected with, any mine and place, marks of identification
thereon and take extracts from or make copies of such document, book, register or record;(v)order
the production of any such document, book register as is referred in clause (iv);(vi)examine any
person having the control of or connected with any mine;(vii)seize any document, sample,
equipment, conveyance, animal, commodity, minor mineral, material, raw material or any other
item of concern.(2)In case of such search and seizure, provisions of Section 100, of the Code of
Criminal Procedure 1973 shall apply.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

60. Power to stop and check any carrier, transport or vessel.
(1)Any of the Officers mentioned in Rule 59 may stop any carrier, vehicle or vessel carrying minor
minerals, to check for verification of the contents.(2)In case such Officer prima facie finds that the
load of the carrier, vehicle or vessel, is more than the permitted quantity and / or challan, he may
require the driver of the carrier, vehicle, vessel, to take such carrier, vehicle, vessel to the nearest
weighbridge and get the contents weighed at the expense of the driver or the owner of such
vehicle/carrier/ vessel.(3)If any person who refuses to obey the lawful command of such Mining
Officer shall be prosecuted under these Rules.
61. Offences cognizable upon written complaints.
- No court inferior to that of a Magistrate of the First Class shall try any offence punishable under
these rules and no court shall take cognizance of any offence under these rules, except upon a
written complaint made in writing by the Competent Officer or Dy. Director of Mines or Additional
Director of Mines or Director of Mines or any other officer empowered by the Government.
62. Compounding of Offence.
- The competent officer may, with the approval of the Collector, compound a case instituted against
any person, if instituted at his direction and complaint, on payment of such sum as may be
determined payable for offence, to the credit of government.Provided that where a case has been
instituted by the Dy. Director of Mines or Additional Director of Mines or Director of Mines or any
other officer empowered by the Government may, with approval of the Commissioner, compound a
case instituted against any person.
63. Reports of Searches and Seizures.
- Every Mining Officer upon making any arrest, search or seizure shall submit a report to the
Collector within twenty four hours.
64. Special Courts.
(1)In terms of power conferred under Section 30B of the Act, the State Government may, if consider
necessary in the public interest, for the purposes of trial of all or any of the offences under this rule,
either appoint or designate in every District of the State, Special Court(s) in consultation with the
Chief Justice of the High Court.(2)The Special Court shall be presided over by a Special Judge who is
or has been a Sessions Judge or an Additional Sessions Judge or an Assistant Sessions Judge under
the Code of Criminal Procedure 1973 (Act 2 of 1974).(3)The trial under this Act of any offence by the
Special Court shall have precedence over the trial of any other case against the accused in any other
Court (not being a Special Court) and shall be concluded in preference to the trial of such other case.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

65. Power to transfer cases to Regular Courts.
- Where, after taking cognizance of any offence in these rules, a Special Court is of the opinion that
the offence is not triable by it, it shall, notwithstanding that it has no jurisdiction to try such offence,
transfer the case for the trial of such offence to any Court having jurisdiction under the Code of
Criminal Procedure, 1973 (Act 2 of 1974) and the Court to which the case is transferred may proceed
with the trial of the offence as if it had taken cognizance of the offence.
66. Appeal.
- Any person aggrieved by any order of the Special Court may, within sixty days from the date of
order, prefer an appeal in the High Court.Chapter-XVI Appeals and Revision
67. Appeals.
(1)All final orders passed by Mining Officer shall be appealable to the Collector within sixty days
from the date of the order.(2)All final orders passed by the Collector shall be appealable to the
Mines Commissioner within sixty days from the date of the order.(3)All appeals shall be disposed of
within three months from the date of the filing. All appeals in the rule shall be in Form "L".
68. Revision.
(1)The Mines Commissioner, at any time for reason to be recorded in writing, may on his own
motion, and where any person aggrieved by any order passed by the Collector under these rules files
an application within 60 days from the date of communication of the order, and within 75 days from
the date on which an application is deemed to have been refused by the Collector, if no
communication is made of such refusal, shall start a proceeding for revision of the order:Provided
that an application for revision may be entertained even after the time specified as above if the
applicant satisfies the Mines Commissioner that he had sufficient cause for not making the
application within time.(2)On receipt of the application and copies thereof under sub rule (1), the
Commissioner shall send a copy of the application, and where proceeding is started by him on his
own motion, under sub-rule (1) he shall send notices of starting the proceeding and reasons thereof
to each of the parties impleaded specifying a date on or before which he may make representation, if
any, against the revision application.(3)After considering the records referred to in sub-rule (2) the
Mines Commissioner may confirm, modify or set aside the order or pass such other order in relation
thereto as the Mines Commissioner may deem just and proper and his order shall be
final.(4)Pending the final disposal of an application for revision, the Mines Commissioner may, for
sufficient cause, stay the execution of the order against which any revision application has been
made.Chapter - XVII EnforcementBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

69. State Level Mining Task Force.
(1)There shall be constituted a State Level Mining Task Force as under:-
(a) Chief Secretary -Chairman
(b) Development Commissioner -Member
(c) Principal Secretary Home -Member
(d) DG Police -Member
(e) Principal Secretary, Environment and Forest -Member
(f) Principal Secretary, Revenue and Land Reforms -Member
(g) Principal Secretary, Industries -Member
(h) Principal Secretary, Road Construction Department -Member
(i) Principal Secretary, Building ConstructionDepartment -Member
(j) Principal Secretary, Rural Works Department -Member
(k) Principal Secretary, PHED -Member
(l) Principal Secretary Commercial Taxes Department -Member
(m) Chairman State Pollution Control Board -Member
(n) Principal Secretary, Mines and Geology Department -Member
(o) Director Mines -Member Secretary
(2)The Chief Secretary may co-opt or invite any other officer or expert to attend and contribute in
the meeting of the State Level Mining Task Force. Half of the Members present shall constitute the
quorum.
70. Monitoring Committee.
- The State Level Mining Task Force shall constitute a Monitoring Committee headed by the
Principal Secretary of the Department of Mines and Geology with such members as it may deem fit.
The Monitoring Committee shall ensure the compliance of the directions of the State Level Mining
Task Force.
71. Function of State Level Mining Task Force.
- The State Level Mining Task Force shall insure implementation of these Rules and shall monitor
the excavation, trade and availability of minor minerals in the State. In addition to the above, it shall
also(1)Provide guidance to the Department for achieving the objective of the Act and these
Rules(2)Frame policies and guidelines essential to implement these Rules(3)Issue direction to any
other Department to undertake such action as essential to achieve the objective of the Act and these
Rules.(4)Shall ensure that the mining activity is undertaken as per the environmental safeguards
laid down by the Ministry of Environment Forest and Climate Change.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

72. Divisional Level Mining Task Force.
(1)There shall be constituted a Divisional Level Mining Task Force as under :-(a)Divisional
Commissioner - Chairman(b)Divisional Commissioners of the Bordering Divisions
-Co-Chairmen(c)DIG Police of the Division.(d)DIG Police of the Bordering Divisions(e)The
Conservator of Forest(f)All Collectors of the Division(g)All SPs of the Division(h)All DFOs of the
Division(i)All Mining Officers of the Division(j)Secretary to the Divisional Commissioner-Member
Secretary(2)Additionally, the Divisional Commissioner may co-opt such additional members as he
may deem fit. The Divisional Commissioner may also invite the Collectors and the SPs of the
districts who share boundaries with the Division.(3)Half of the Members present shall constitute the
quorum.(4)It shall meet once in a month.
73. Function of the Divisional Level Mining Task Force.
- The Divisional Level Mining Task Force shall insure implementation of these rules and shall
monitor the excavation, trade and availability of minor minerals in the Division. In addition to the
above, it shall also -(1)Ensure the inter-district coordination between the districts of the Division
and the bordering districts of Division.(2)Prepare and launch coordinated action plan to check
illegal mining and illegal transportation of minor minerals across districts and districts outside the
Division.
74. District Level Mining Task Force.
(1)There shall be a constituted a District Level Mining Task Force as under:(a)Collector-
Chairman(b)Superintendent of Police(c)All Sub Divisional Officers(d)All Sub Divisional Police
Officers(e)Divisional Forest Officer(f)Executive Engineer, RCD, BCD, PHED and Rural Works
Department(g)District Transport Officer(h)District Mining Officer - Member Secretary(2)The
Collector may co-opt or invite any other Officer or expert to attend and contribute in the meeting of
the District Level Mining Task Force.(3)Half of the Members present shall constitute the
quorum.(4)It shall necessarily meet once a month and at earlier frequencies as directed by the
Department.
75. Function of the District Level Mining Task Force.
- The District Level Mining Task Force shall insure implementation of these rules and shall monitor
the excavation, trade and availability of minor minerals in the district. In addition to the above, it
shall also(1)ensure that all the mining activity is carried on as per the condition of the mining
lease.(2)ensure that no illegal mining, illegal transportation, over loading, hoarding and black
marketing of minor mineral is carried on.(3)all the retail business of minor minerals are carried out
as per the provision in these rules.(4)issue direction to any other Department to undertake such
action as essential to achieve the objective of the Act and these Rules.(5)Shall ensure that the mining
activity is undertaken as per the environmental safeguard laid down by the Ministry of Environment
Forest and Climate Change.Chapter- XVIII ExemptionsBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

76. Power of State Government to exempt minor minerals from the provisions
of these Rules.
- The State Government may, by notification, either wholly or partially, and subject to such
conditions (if any) as it may think fit to prescribe, exempt any minor mineral from all or any of the
provisions of these rules, either throughout the State or any specified area of the State, for any
specified period or occasion or for any specified class of persons and for such purposes.
77. Power of Government to relax the operation of any provision of these
Rules.
(1)State Government may, relax the operation of one or more of the provisions of these Rules if, in
the opinion of the Government, such relaxation is necessary in public interest.(2)Notwithstanding
anything contained in these rules, the State Government, in such case as it deems proper in public
interest, may grant a mining lease/mining settlement and may also authorize the grant of a
quarrying permit or movement permit to any person on terms and conditions other than those
prescribed in these rules for reasons to be recorded in writing:Provided that the State Government
may grant a mining lease/settlement/in any area under its jurisdiction to any Government
Department or State owned Corporation on terms and conditions other than those prescribed in
these Rules.
78. Mining Lease etc to any Works Department.
(1)Notwithstanding anything contained in these rules, the State Government may grant
license/lease to any Works Department for any particular project in a specific number of districts for
specific period of time.(2)The said Works Department shall have to pay the due royalty and such
other fee as applicable under these rules.
Chapter XIX
Miscellaneous
79. Power to rectify apparent errors.
- Any clerical or arithmetical mistake in any order passed by the Government or any other authority
or Officer under these rules and any error arising therein from accidental slip or omissions, may
within two years from the date of the order, be corrected by the Government authority or the Officer,
as the case may be:Provided that no order prejudicial to any person shall be passed unless he has
been given a reasonable opportunity of being heard.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

80. Submission of copy of lease.
- Every person holding a mining lease or sub-lease from a private person or before the
commencement of these rules, shall submit to the Mining Officer in whose jurisdiction the area or
areas covered by such lease or sub-lease is or are situated a certified or true copy of the lease or
sub-lease.
81. Interpretation of mining lease.
- Every lease shall provide for submission by the lessee of any question of dispute regarding the
lease or any other matter or thing, construction of a term or condition in the lease or anything
connected with the mining of minor minerals specified in the lease, or the working or non- working
of the mine or the quarry, and the amount of royalty or dead rent or its mode of payment to the
Mining Officer, for the decision of the Collector, which shall be final and binding on the lessee.
82. Mode of realization of rents, royalties and penalty.
- The amounts of rent, royalty or penalty payable under these rules, shall be recoverable as a public
demand under the Bihar Public Demands Recovery Act, 1914.
83. Payment of compensation to owner of surface rights etc.
(1)The holder of a mineral concession shall be liable to pay to the occupier of the surface of the land
over which he holds the mineral concession, such annual compensation as may be determined by
the Collector.(2)In case of agricultural land the amount of annual compensation shall be worked out
on the basis of the average annual net income for the cultivation of similar land for the previous 3
years.(3)In case of non-agricultural land, the amount of annual compensation shall be worked out
on the basis of average annual letting value of similar land for the previous three years;(4)The
annual compensation referred to in sub-rule (1) shall be payable on or before such date as may be
specified by the Collector.
84. Power to issue directions.
(1)The Department may, in the interest of systematic development of mineral deposits, conservation
of minerals, scientific mining, sustainable development and protection of the environment, issue
direction to the owner, agent or manager of the mining lease/settlement.(2)Every direction issued
under sub-rule (1) shall be complied by the owner, agent or manager of the mining lease/ settlement
as the case may be, who in case of any difficulty in giving effect to any such direction, may apply for
modification or rescinding of such direction and the officer so authorized by the Department in this
regard, may either modify or rescind the direction or confirm the same.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

85. Officers to be Public Servants.
(1)All Officers and persons empowered to exercise any powers or to perform any functions under the
Act or these rules shall be deemed to be public servants within the meaning of Section 21 of the
Indian Penal Code, 1860 (Act 45 of 1860).(2)No suit shall lie in any Civil Court against the State
Government or any Mining Officer for damages for any act done in good faith or ordered to be done
in pursuance of the Act or these rules or of any other law for the time being in force relating to the
Mining Revenue.(3)No Civil Court shall try any suit against the State Government in respect of
anything done, or alleged to have been done, in pursuance of these rules, and except with the
previous sanction of the State Government, no Magistrate shall take cognizance of any charge made
against any Mining Officer under these rules or made against any other person under these rules.
86. Protection of action taken in good faith.
- No suit, Prosecution or other legal proceedings shall lie against any person for anything which is in
good faith done or intended to be done under this rules.
87. Orders to remain in Force.
- Every Order, Notification, Rule or Regulation which was made under the Bihar Minor Mineral
Concession Rules, 1972 (as amended from time to time), the Bihar Minerals (Prevention of Illegal
Mining, Transportation and Storage) Rules, 2003, Bihar Minor Mineral Rules, 2017 or by the Mines
Commissioner, the Collector, the Board of Revenue or any other Mining Officer appointed under
those Rules relating to the matter of Mining and which was in force immediately before the
expiration thereof shall, in so far as such order or notification or rule or regulation is not
inconsistent with the provisions of the Act and these rules, be deemed to continue in force and to
have been made under the Act and these rules.
88. Repeal and Savings.
(1)The Bihar Minor Mineral Concession Rules, 1972 (as amended from time to time), the Bihar
Minerals (Prevention of Illegal Mining, Transportation and Storage) Rules, 2003 and Bihar Minor
Mineral Rules, 2017 are hereby repealed.(2)Notwithstanding such repeal, anything done or any
action taken under the said rules shall be deemed to have been done or taken under the
corresponding provisions of the Act and these rules.(3)All references in any provisions of the rules
so repealed shall be construed as references to the corresponding provisions of these rules.(4)All
proceedings (including proceedings by way of investigations) pending before any Officer, Authority
or Court, immediately before the commencement of these rules shall, on such commencement, be
deemed to be proceedings pending before it as per these rules and shall continue to be dealt with
accordingly.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

89. Power to remove difficulty.
- If any difficulty arises in giving effect to the provisions of these rules, the State Government may,
by notification in the Official Gazette, make such provisions as it deems necessary or expedient for
removing the difficulty.
90. Laying of Rules.
- These rules, as soon as they are promulgated, shall be laid before each house of the State
Legislature. By the Order of Governor of Bihar.
I
[See Rule 2(x)]
1Application for Mining Lease Form A
2Mining Lease Deed Form B
3Application for Quarrying permit Form C
4Quarry Permit Form D
5Application for the grant of Mineral DisposalPermit Form E
6Form for grant of Mineral Disposal Permit Form F
7Format of E Challan Form G
8Register to be maintained by the Lessee/PermitHolders Form H
9Monthly Returns Form I
10Annual Returns Form J
11Stockist License Form K
12Form for Appeal Form L
II
[See Rule 51(1)(a) ]Dead Rent
Period Rate of Dead Rent (in Rs.)
1 2
Rate per year for entire period of lease 50,000.00 per acre per year
III A
[See Rule 51(1)(b)]
Sr. No. Royalty Name of Minerals Rate Per CubicBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

meter in Rupees
1 2 3
1(a) Boulder, Gravel, shingle or stone as defined byname whichever (b)
Stone settled by way of auction150.00In case of
auction the
amount of
auction
2(a) Ordinary sand used for construction purpose (b)Ordinary sand of
auctioned ghats75.00In case of
auction the
amount of
auction
3 Brick earth (equivalent to 400 standard bricks) 18.00
4Ordinary Earth/Clay which is used for filling orlevelling purposes in
construction of embankment, Roads,Railways. Building etc. and for
other commercial works.33.00
5Lime shell, Lime stone and kankar used in kilns formanufacturing of
lime used as a construction material and Limeshell used for manufacture
of buttons.165.00
6 Murram 83.00
7 Chalcedony Pebbles used for Ball Mill purpose only 95.00
8 Granduler Earth 83.00
9Quartzite used for the purpose of buildingconstruction or for making
road150.00
10 Reh Mitti 34.00
11 Saltpetre 38.00
12 Slate and Shell when used for making buildingmaterial 110.00
13 Fullers Earth 124.00
14 Stone used for making household utensils includinggrinding stone 95.00
15 Stone sets and Stone Bricks per hundred 95.00
16 Stone dust 30.00
17Granite (in case of use for decorating stone) perhundred (i) Block more
than 60 c.m. (ii) Block less than 60 c.m.709.00 355.00
18 Quartz;30 % of the sale
price on ad
valorem basis.
19 Sand (others);
20 Silica Sand;
21 Steatite or Talc or Soapstone.
22 Agate;
23 Ball Clay;Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

24 Barytes;
25 Calcareous Sand;
26 Calcite;
27 Chalk;
28 China Clay;
29 Clay (others);
30 Corundum;
31 Diaspore;
32 Dolomite;
33 Dunite or pyroxenite;
34 Felsite;
35 Felspar;
36 Fireclay;
37 Fushite Quartzite;
38 Gypsum;
39 Jasper;
40 Kaolin ;
41 Laterite;
42 Mica;
43 Ochre;
44 Pyrophyllite;
45 All other minerals
Note. - (I) Notwithstanding anything contained repugnant Bihar Minerals (Concession, Prevention
of Illegal Mining, Transportation & Storage) Rules, 2019 or otherwise, the settlee shall pay extra
Royalty for the excess quantity of extracted and dispatched stone more than the equivalent auction
amount.Note. - (II) The settlee shall pay extra Royalty for the excess quantity of extracted and
dispatched sand more than the equivalent auction amount.Note. - (III) No royalty for
non-commercial use of ordinary earth shall be levied.
III- B
[See Rule 38 (1)]In exercise of the powers conferred by Rule 38 (1) of the Bihar Minerals
(Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019 and having regard
to location, population, state of Civil Construction, state of Industrial Construction, state of
Urbanisation and place of industrial growth in different areas of the State, the Governor of Bihar is
pleased to reclassify such areas to determine the number of bricks per fixed kiln and Bangla Bhatta
and consolidated amount of royalty to be paid thereon by brick kiln owner/ brick earth remover per
kiln per annum to the State Government for different areas as shown in the table below :-
Sl. Categories Name of district and Capacity- fixed no. for the Royalty- amount of royaltyBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

no. of area area manufactured brickfor fixed
kiln and Bangla Bhatta
situated in areas shown
incolumn 3payable per kilnper annum
on number of brick fixed in
column 4 (in Rupees)
1 2 3 4 5
1. IUrban areas of Patna,
Muzaffarpur,
Bhagalpur,Gaya,
Darbhanga, districts45 Lakhs bricks Rs.2,02,500.00
2. II Other Urban areas 35 Lakhs Bricks Rs.1,57,500.00
3. III Rural Areas 25 Lakhs Bricks Rs.1,12,500.00
4. IV Bangla Bhatta 01(One Lakh) Bricks Rs. 4,500.00
Note:- (I) "Urban area" means the areas within the local limits of Municipality or Municipal
Corporation or Notified area Committee and also includes the area falling within 4 Kms. outside the
boundary limits of such Municipal Corporation or Municipality or Notified area Committee as the
case may be;Note :- (II) No royalty shall be payable on brick/brick earth manufactured in Bangla
Bhatta for non-commercial, Personal consumption.Form A.[See Rule 24 (2)]Form of application for
Mining Lease for Minor Minerals.Dated................day of...................20To,The
Collector,.......................Sir,I/We have the honour to apply for the grant of Mining Lease under the
Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019.
Received...............on..........(Dated)............................`(Initial) A sum of Rs.................being the fee in
respect of this application payable under rules 24 (3) of the said rules has been deposited in
..............(name of treasury or branch of the State Bank of India doing the treasury business) and the
relevant challan is attached herewith.The required particulars are given below:Particulars
1. Name of individuals, firm or company applying.
2. Nationality of individuals or place of registration of incoporation of firm or
company.
3. Profession of individuals or nature of business of firm or company and
place of business.
4. Address of the individuals, firm or company.
5. Mineral or minerals which the applicant intends to mine.
6. Period for which the mining lease is required-Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

7. Details of area in respect of which lease is required-
(i)District, (ii) Revenue thana, (iii) Village/Mouza, (iv) J.L. no., (v) Plot nos., (vi) Total area.
8. Particulars of map or plan on 16"= 1 Kilometre scale, covering the area
mentioned at 7 above, attached. It shall give sufficient information to enable
identification of the area in respect of which the lease is required.
9. Brief description of the area.
10. Area and minerals within the jurisdiction of the State Government for
which the applicant or any person joint in the interest
with him-: Mineral ..... Area: Taluk ..... District(a)already holds a lease (s);(b)has already applied for
but not been granted a lease; or(c)has applied simultaneously.
11. Nature of joint interest, if any under 10 above.
12. Approximate quantity of minerals expected to be raised during the first
year.
13. Means by which the minerals are to be raised, i.e. by hand labour or
mechanical or electrical power and the degree of mechanisation if any
contemplated.
14. The amount of money proposed to be invested.
15. Past experience of the applicant in the profession of mining.
16. Manner in which the mineral raised is to be utilised, expected consumers
and places of consumption of the mineral.
17. Any other particulars which the applicant wishes to furnish or which the
Collector may ask for.
18. Manner and details of payment of the application fee prescribed in these
rules.
(Note.-The fee to be paid to the credit of the State Government under the head................)I/We do
hereby declare that the particulars furnished above are correct and am/are ready to furnish anyBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

other details, including accurate plan and security deposit, etc. as required by you before the grant
of the lease.Yours faithfully.Signature and designation of the
ApplicantPlace...............Date.................Form B[See rule 26(1)]Model Form of Mining Lease For
Minor MineralThis Indenture Made This ..................... Day of ...................... 20...........Between the
Governorof BIHAR (hereinafter referred to as the "State Government" which expression shall where
the context so admits be deemed to include his successors in office and assigns)Of The One Part
andWhen the lessee is an individual ..................................... (Name of person) ;Son of
.......................... (Address and occupation) ( hereinafter referred to as "the lessee" which expression
shall where the context so admits be deemed to include his respective heirs, executors,
administrators, and representatives and permitted assigns.)When the lessees are more than one
individual ............................................. (Name of person with address and occupation) and
...................(Name of person with address and occupation) (hereinafter referred to as "the lessees"
which expression shall where the context so admits be deemed to include their respective heirs,
executors, administrators, representatives and permitted assigns).When the lessee is a registered
firm or syndicate ........................... (Name and address of partner), son of ........................
............................son of ................... all carrying on business in partnership, under the firm name
and style of................... (Name of the firm) registered under the Indian Partnership Act,1932 (9 of
1932) and having their registered office at ........................... in the town of ................(hereinafter
referred to as "the lessee" which expression where the context so admits be deemed to include all the
said partners, their respective heirs, executors, legal representatives and permitted assigns)When
the lessee is registered company ....................................... (Name of company) a company registered
under............................ (Act under which incorporated) and having its registered office at
....................... (Address) (hereinafter referred to as "the lessee" which expression shall where the
context so admits be deemed to include its successors and permitted assigns), of The Other
Part.Whereas The lessee/lessees has/have applied to Government of Bihar (hereinafter referred to
as the 'State Government') for a mining lease for ..................(Name of Mineral) in accordance with
the Bihar Minor Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage)
Rules, 2019 (hereinafter referred to as the said Rules) in respect of the lands described in Part I of
the Schedule hereunder written and has/have deposited with the State Government the sum of Rs.
.................. as security. NOW This Indenture Witnesseth that in consideration of the rents and
royalties, covenants and agreements by and in these presents and the said schedule hereunder
written reserved and contained and on the part of the lessee to be paid, observed and performed the
State Government both hereby grant and demise unto the lessee/ lessees. All those this mines
beds/veins seams of stone [here state the "Minerals"] (hereinafter and in the said schedule referred
to as the said "minerals") situated lying and being in or under the land mentioned and described in
part I of the said schedule, together with the, liberties, powers and privileges to be exercised on or
enjoyed in connection herewith which are mentioned in part II of the said schedule subject to the
restrictions and conditions as to the exercise and enjoyment of such liberties, powers, and privileges
which are mentioned in part III of the said schedule Except and reserving out of this demise unto
the State Government the liberties, powers and privilege mentioned in part IV of the said Schedule
To Hold the premises hereby granted and demised unto the lessee-from the day
............................................... 20... for the term of five years thence next ensuing Yielding and paying
therefor unto the State Government the several rents and royalties mentioned in part V of the said
schedule at the respective time therein specified subject to the provisions contained in part VI of theBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

said schedule and the lessee/lessees hereby covenant/covenants with the State Government as in
part VII of the said schedule is expressed and the State Government hereby covenants with the
lessee as in part VIII of the said schedule is expressed AND it is hereby mutually agreed between the
parties hereto as in part IX of the said schedule is expressed.In witness whereof these presents have
been executed in manner hereunder appearing the day and year first above written.In Witness
Whereof these presents have been executed in manner hereunder appearing the day and year first
above written.The Schedule above referred to.Part-I The Area of This LeaseLocation and area of the
lease:All that tract of lands situated at .................................................. (Description of area or areas)
in the Registration District of ....................................... Sub-Division.......................... and
Thana.......................bearing cadastral Survey Nos. ...................................containing an area of
........................... or there abouts delineated on the plan here to annexed and thereon marked with
lines/coloured ..................................... and bounded as follows: -On the North by
...........................................................................On the South by
...........................................................................On the East by
...........................................................................And On the West by
...........................................................................hereinafter referred to as " the said lands".Part-II
Liberties, Powers and Privileges To Be Exercised and Enjoyed By The Lessee/lessees Subject To The
Restrictions and Conditions In Part Iii.
1. To enter upon land & search for, win, work etc. - Liberty and power at all
times during the term hereby demised to enter upon the said lands and to
search for, mine, bore, dig, drill for, win, work, dress, process, convert, carry
away and dispose of the said mineral/minerals.
2. To sink, drive and make pits, shafts, and inclines etc. - Liberty and power
for or in connection with any of the purposes mentioned in this part to sink,
drive, make, maintain and use in the said lands any pits, shafts, inclines
drifts, levels, waterways, airways and other works (and to use, maintain,
deepen or extend any existing works of the like nature in the said lands).
3. To bring and use machinery, equipments etc. - Liberty and power for or in
connection with any of the purpose mentioned in this part to erect, construct,
maintain and use on or under the said lands any engines, machinery, plant,
dressing floors, furnaces, coke ovens, brick-kilns, workshops, store houses,
bungalows, godowns, sheds and other buildings and other works and
conveniences of the like nature on or under the said lands.
4. To make roads and ways etc. and use existing roads and ways. - Liberty
and power for or in connection with any of the purposes mentioned in this
part to make any tramways, railways, aircraft landing grounds and otherBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

ways in or over the said lands and to use, maintain and go, and repass with
or without horses, cattle, wagons, aircrafts, locomotives or other vehicles
over the same (or any existing tramways, railways, roads and other ways in
or over the said lands) on such conditionsas may be agreed to.
5. To use water from streams etc. - Liberty and power for or in connection
with any of the purposes mentioned in this part but subject to the right of any
existing or future lessees and with the written permission of the Collector to
appropriate and use water from any streams, water-courses, springs or other
sources in or upon the said lands, to step up or dam any such stream or
water course and collect or impound any such water and to make, construct
and maintain any water course culverts, drains or reservoirs but not as so to
deprive any cultivated lands, villages, buildings or watering places for
livestock of a reasonable supply of water as before accustomed or in any
way to foul or pollute any stream or springs. Provided that the lessee/lessees
shall not interfere with the navigation in any navigable stream nor shall divert
such stream without the previous written permission of the State
Government.
6. To use land for stacking, heaping or depositing purpose. - Liberty and
power to enter upon and use a sufficient part of the surface of the said lands
for the purpose of stacking, heaping, storing or depositing therein any
produce of the mines or works carried on and any tools, equipment, earth
and materials and substances dug or raised under the liberties and powers
mentioned in this part.
7. Beneficiation and conveying away of production. - Liberty and power to
enter upon and use a sufficient part of the said lands to beneficiate any
mineral produced from the said lands and to carry away such beneficiated
mineral.
8. To clear brushwood and to fell and utilize trees, etc. - Liberty and power for
or in connection with any of the purposes mentioned in this part and subject
to the existing rights of others and save as provided that Collector may ask
the lessee/lessees to pay for any tree or timber felled and utilized by
him/them at the rates specified by the Collector.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

Part-III Restrictions and Conditions As To The Exercise of The Liberties, Powers and Privileges In
Part-II.
1. No building etc. upon certain places. - No building etc. shall be erected, set
up or placed and no surface operations shall be carried on in or upon any
public pleasure ground, burning or burial ground, or place held sacred by
any class of persons or any house or village site, public road, or other place
which the State Government may determine as public ground or in such a
manner as to injure or prejudicially affect any buildings, works, property or
rights of other persons and no land shall be used for surface operations
which is already occupied by persons other than the State Government for
works or purpose not included in this lease. The lessee/lessees shall not also
interfere with any right of way, well or tank.
2. Permission for surface operations in a land not already in use. - Before
using for surface operations any land which has not already been used for
such operations, the lessee/lessees shall give to the Collector of the District
two calendar months previous notice in writing specifying the name or other
description of the situation and the extent of the land proposed to be so used
and the purpose for which the same is required and the said land shall not be
so used if objection is issued by the Collector within two months after the
receipt by him of such notice unless the objections so stated shall on
reference to the State Government be annulled or waived.
3. To cut trees in unreserved lands. - The lessee/lessees shall not, without
the express sanction of the Collector, cut down or injure any timber or trees
on the said lands but may without such sanction clear away any brushwood
or under growth which interferes with any operations authorised by these
presents. The Collector may require the lessee/lessees to pay for any tree or
timber felled and utilized by him/them at the rates specified by the State
Government in Forest and Environment Department.
4. Not to enter upon reserved forests. - Notwithstanding anything contained
in this Schedule the lessee/lessees shall not enter upon any reserved forest
included in the said lands or fell, cut and use any timber or trees.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

5. No mining operations within 50 meters of public works etc. - The
lessee/lessees shall not work or carry on or allow to be worked or carried on
any mining operations at or to any point within a distance of 50 meters from
any railway line except with the previous written permission of the Railway
Administration concerned or under or beneath any rope way or any ropeway
trestle or station, except under and in accordance with the written
permission of the authority owning the ropeway or from any reservoir, canal
or other public works such as public roads and buildings or inhabited site
except with the previous written permission of the Collector or any other
officer authorised by the State Government in this behalf and otherwise than
in accordance with such instructions, restrictions and conditions, either
general or special, which may be attached to such permission. The said
distance of 50 meters shall be measured in the case of railway, reservoir or
canal horizontally from the outer toe of the bank or the outer edge of the
cutting as the case may be and in case of a building horizontally from the
plinth thereof. In the case of village roads no working shall be carried on
within a distance of 10 meters of the outer edge of the cutting except with the
previous permission of the Collector or any other officer duly authorised by
the State Government in this behalf and otherwise than in accordance with
such directions, restrictions and additions, either general or special, which
may be attached to such permission.
Explanation. - For the purpose of the clause the expression Railway Administration shall have the
same meaning as it is defined to have in the Indian Railway Act, 1890 by clause (6) of section 3 of
that Act. 'Public Road' shall mean a road which has been constructed by artificially surfaced as
distinct from a track resulting from repeated use. Village road will include any track shown in the
Revenue record as village road.
6. Facilities for adjoining Government licenses and leases. - The
lessee/lessees shall allow existing and future holders of Government
licenses or leases over any land which is comprised in or adjoins or reached
or is reached by the land held by the lessee/lessees reasonable facilities of
access thereto:
Provided That no substantial hindrance or interference shall be caused by such holders of licenses or
leases to the operations of the lessee/lessees under these presents and fair compensation (as may be
mutually agreed upon or in the event of disagreement, as may be decided by the State Government)
shall be made to the lessee/lessees for loss or damage sustained by the lessee/lessees by reason of
the exercise of this liberty.Part-IV Liberties, Power and Privileges Reserved To The StateBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

Government.
1. To work other minerals. - Liberty and power for the State Government, or
to any lessee or persons authorised by it in that behalf to enter into and upon
the said lands and to search for, win, work, dig, get, raise, dress, process,
convert and carry away minerals other than the said minerals and any other
substances and for those purposes to sink, drive, make erect, construct,
maintain and use such pits, shafts, inclines, drifts, levels and other lines,
waterways, airways, water courses, drains, reservoirs, engines, machinery,
plant, buildings, canals, tramways, railways, roadways and other works and
conveniences as may be deemed necessary or convenient.
Provided That in the exercise of such liberty and power no substantial hindrance or interference
shall be caused to or with the liberties powers and privileges of the lessee/lessees under these
presents and that fair compensation (as may be mutually agreed upon or in the event of
disagreement as may be decided by the State Government) shall be made to the lessee/lessees for all
loss or dama ge sustained by the lessee/lessees by reasons or in consequence of the exercise of such
liberty and power.
2. To make railway lines and roads, etc. - Liberty and power for the State
Government or any lessee or person authorized by it on that behalf to enter
into and upon the said lands and to make upon over or through the same any
railways, tramways, roadways , electric lines, telephone lines or pipelines for
any purpose other than other than those mentioned in part II of these
presents and to get from the said land stoned, gravel, earth and other
materials for making, maintaining and repairing such railways, tramway and
roads or and existing railways, tramways, and roads and to go and repass at
all times with or without horses, cattle or other animals, carts, wagons,
carriages, truck, cars, locomotives or the vehicles over or along any such
railways, roads, line and other ways for all purposes and occasions may
require provided that in the exercise of such liberty and power by such other
lessee or person no substantial hindrance or interference shall be caused to
or with the liberties, powers and privileges of the lessee for all loss or
damage sustained by the lessee by reason or in consequence of the exercise
by such lessee or person of such liberty and power, subject to the provision
that no compensation shall be deemed to be payable where only electric
lines or telephone or similar lines are carried in or over the lands under
lease.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

3. Lease by mistake. - The lessee shall have no claim against the State
Government for compensation or damage in respect of land having been
included in this lease which already been included in some previous lease
but that the lessee shall be entitled to proportionate reduction of the
assessment in respect of any land covered by the lease which may
subsequently be discovered not to have been available for lease.
4. Action in case of occurrence of valuable Mineral. - In case there are
reasons to believe at any time that valuable mineral or minerals exist along
with the mineral for which this lease is being granted the Collector may issue
such order for the compliance of the lessee as the Collector may thing
proper for dumping of the tailings or screened rejects of the mineral to
treated or treatment of the mineral to which this lease is being granted. The
granting of this lease to the lessee will always be without prejudice to the
right of the Collector to terminate the lease if the mineral leased is found any
time to contain any valuable mineral separation of which is not, in the
opinion of the Collector, easily possible or within the means of the lessee.
Part-V Rents and Royalties Reserved By This Lease
1. To pay dead rent or royalty whichever is higher. - The lessee shall pay for
every year except the first year of the lease, dead rent specified in clause 2 of
this Part. Provided that the lessee shall be liable to pay the dead rent or
royalty in respect of each mineral whichever is higher in amount but not
both.
2. Rate and mode of payment of dead rent. - Subject to the provisions of
clause 1 of this Part, as from the day [XXXX].........20.........during the
subsistence of the lease, the lessee/lessees shall pay to the Collector(in four
equal quarterly installments on the ............day of the months of ............or in
four equal half yearly installments on the ............day of and the day
of.............(in each year) certain annual dead rent at the following rate per acre
of land s, described in Part I of this Schedule subject to revision at any time
by state Government by notification of schedule-II of this Rule(here insert the
amount payable).Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

3. Rate and mode of payment of royalty/Settlement Amount. - Subject to the
provision of clause 1 of this part, the lessee/lessees shall during the
subsistence of this lease pay to the State Government at such times and in
such manner as the State Government may prescribe, installment of
settlement amount/royalty in respect of any mineral/minerals removed by
him/them from the leased area at the rate for the time being specified in the
Schedule IIIA of the said Rules.
4. Payment of surface rent, and water rate. - The lessee/lessees shall pay rent
and water rate to the State Government in respect of all parts of the surface
of the said lands which shall from time to time be occupied or used by the
lessee/lessees under the authority of these presents at the rate of
Rs...................... and Rs. .................................... respectively per annum per
acre of the area so occupied or used and so in proportion for any area less
than a acre during the period from the commencement of such occupation or
used until the area shall cease to be so occupied or used and shall as far as
possible restore the surface land so used to its original condition. Surface
rent and water rate shall be paid as herein before detailed in clause 2:
Provided That No Such Rent/water Rate shall be payable in respect of the occupation and use of the
area comprised in any roads or ways to which the public have full right of access.Part-VI Provisions
Relating To The Rents and Royalties
1. Rent and royalties to be from deduction etc. - The rent, water rate and
royalties mentioned in Part V of this Schedule shall be paid free from any
deductions to the State Government at .............................. and such manner
as the State Government may prescribe.
2. Mode of computation of royalty. - For the purposes of computing the said
royalties the lessee/lessees shall keep a correct account of the
mineral/minerals produced and dispatched. An Account as well as the weight
of the mineral/minerals in stock or the process of export may be checked by
an officer authorised by the State Government.
3. Monthly account to be sent to State Government. - The accounts for each
month in respect of raising, sale, dispatch, local consumption, royalty, and
rent dues and paid shall be [submitted] within 15 days of the month following
and a true copy signed by the lessees or his/her/its authorised agent shall beBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

sent in triplicate to the Competent Officer thereafter in a form that may be
prescribed from time to time by the State Government .
4. Interest on arrear payments. - The lessee/lessees shall be liable to pay
interest at the rate of [24] percent per annum on any amount remaining
payable to the State Government
5. Course of action if rents and royalties are not paid in time. - Should any
rent, royalty or other sums due to the State Government under the terms and
conditions of these presents be not paid by the lessee/lessees within the
prescribed time the same, together with simple interest due thereon at the
rate of twenty four percent per annum may be recovered on a certificate of
such officer as may be specified by the State Government by general or
special order, in the same manner as an arrear of land revenue.
Part- VII The Covenants of The Lessee/lessees
1. Lessee to pay rents and royalties taxes, etc. - The lessee/lessees shall pay
the rent, water rate and royalties reserved by this lease at such times and in
the manner provided in PARTS V and VI of these presents and shall also pay
and discharge all taxes, rates, assessments and impositions whatsoever
being in the nature of public demands which shall, from time to time, be
charged, assessed or imposed by the authority of the Central and State
Governments upon or in respect of the premises and works of the
lessee/lessees in common with other premises and works of a like nature
except demands for land revenues.
2. To maintain and keep boundary marks in good order. - The lessee/lessees
shall at his/their own expense, erect and at all times maintain and keep in
repair, boundary marks and pillars according to the demarcation to be shown
in the plan annexed to this lease. Such marks and pillars shall be sufficiently
clear of the shrubs and other obstructions as to allow easy identification.
3. To commence operations within three months and work in a workmanlike
manner.-The lessee/lessees shall commence operation within three months
from the date of execution of the lease and shall thereafter at all times during
the continuance of his lease search for, win, work and develop the said
minerals without voluntary intermission in a skillful and workman-likeBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

manner and as prescribed under clause 12 hereinafter without doing or
permitting to be done any unnecessary or avoidable damage to the surface
of the said lands or the crops, buildings, structures or other property
thereon. For the purposes of this clause, operations shall include the
erection of machinery, laying of a tramway or construction of a road in
connection with the mine.
4. To indemnify Government against all claims. - The lessee/lessees shall
make and pay such reasonable satisfaction and compensation as may be
assessed by lawful authority in accordance with the law in force on the
subject for all damage, injury or disturbance which may be done by him/them
in exercise of the powers granted by this lease and shall indemnify and keep
indemnified fully and completely the State Government against all claims
which may be made by any person or persons in respect of any such
damage, injury or disturbance and all costs and expenses in connection
therewith.
5. To secure and keep in good condition pits, shafts, etc. - The lessee/lessees
shall, during the subsistence of this lease, well and sufficiently secure and
keep open with timber or other durable means all pits, shafts and workings
that maybe made or used in the said lands and make and maintain sufficient
fences to the satisfaction of the concerned authority of the Central or State
Government round every such pit, shaft or working whether the same is
abandoned or not and shall during the same period keep all workings in the
said lands, except such as may be abandoned, accessible, free from water
and foul air as far as possible.
6. To strengthen and support the mine to necessary extent. - The
lessee/lessees shall strengthen and support to the satisfaction of the Railway
Administration concerned or the State Government, as the case may be, any
part of the mine which in its opinion requires such strengthening or support
for the safety of any railway, reservoir, canal, road and any other public
works or structures.
7. To allow inspection of workings. - The lessee /lessees shall allow any
officer authorised by the Central Government or the State Government in that
behalf to enter upon the premises including any building, excavation or landBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

comprised in the lease for the purpose of inspecting, examining, surveying,
prospecting and making plans thereof, sampling and collecting any data and
the lessee/lessees shall with proper person employed by the lessee/lessees
and acquainted with the mines and works effectually assist such officer,
agents, servants and workmen in conducting every such inspection and shall
afford them all facilities, information connected with the working of the mines
which they may reasonably require and also shall and will conform to and
observe all orders and regulations which the Central and State Governments
as the result of such inspection or otherwise may, from time to time, see fit to
impose.
8. To report accident. - The lessee/lessees shall without delay, send to the
Collector/ competent officer, as the case may be, a report of any accident
causing death or serious bodily injury or serious injury to property or
seriously affecting or endangering life or property which may occur in the
course of the operations under this lease.
9. To report discovery of other minerals. - The lessee/lessees shall report to
the Collector/competent officer, as the case may be, the discovery in the
leased area of any mineral not specified in the lease within sixty days of such
discovery along with full particulars of the nature and position of each such
find. If any mineral not specified in the lease is discovered in the leased area,
the lessee/lessees shall not win and dispose of such mineral unless such
mineral is included in the lease or a separate lease is obtained thereof.
10. To keep records and accounts regarding production and employees etc. -
The lessee/lessees shall at all time during the said term, keep or cause to be
kept at an office to be situated upon or near the said lands, correct and
intelligible books of accounts which shall contain accurate entries showing
from time to time.-
(1)Quantity and quality of the said mineral/minerals realised from the said lands.(2)Quantity of the
various qualities of ores beneficiated or converted.(3)Quantities of the various qualities of the said
mineral/minerals sold and exported separately.(4)Quantities of the various qualities of the said
mineral/minerals otherwise disposed of and the manner and purpose of such disposal.(5)The prices
and all other particulars of all sales of said mineral/minerals.(6)The number of persons employed in
the mines or works upon the said lands specifying nationality, qualifications and pay of the technical
personnel.(7)Such other facts, particulars and circumstances as the State Governments may from
time to time require and shall also furnish free of charge to such officers and at such times as theBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

State Governments may appoint, true and correct abstract of all or any such books of accounts and
such information and returns to all or any of the matters aforesaid as the State Government may
prescribe and shall at all reasonable times allow such officers as the State Government shall in that
behalf appoint to enter into and have free access to the said officers for the purpose of examining
and inspecting the said books of accounts, plans and records and to make copies thereof and make
extracts therefrom.
11. To maintain plans, etc. - The lessee/lessees shall at all times during the
said term, maintain at the mine office correct, intelligible, up-to-date and
complete plans and sections of the mines in the said lands. They shall show
all the operations and workings and all the trenches, pits and drillings made
by him/them in the course of operations carried on by him/them under the
lease, faults and other disturbances encountered and geological data and all
such plans and sections shall be amended and filled up by and from actual
surveys to be made for that purpose at the end of twelve months or any
period specified from time to time and the lessee/lessees shall furnish free of
charge to the State Government, true and correct copies of such plans and
sections whenever required. Accurate records of all trenches, pits and
drillings shall show: -
(a)The subsoil and strata through which they pass.(b)Any mineral encountered.(c)Any other matter
of interest and all data required by the State Government, from time to time.The lessee/lessees shall
allow any officer of the State Government to inspect the same at all reasonable times. He/they shall
also supply when asked for by the State Government, Director General, Geological Survey of India,
the Controller General, Indian Bureau of Mines, a composite plan of the area showing thickness,
dip, inclination, etc. of all the seams as also the quantity of reserves quality-wise.
11A. The lessee shall pay a wage not less than the minimum wage prescribed
by the Central or State Government from time to time.
11B. The lessee shall comply with provisions of the Mines Act, 1952, as and
when applicable and the rules made thereunder.
11C. The lessee shall take measures for the protection of environment like
planting of trees, reclamation of land, use of pollution control devices; and
such other measures as may be prescribed by the Central or State
Government, from time to time, at his own expense.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

11D. The lessee shall pay compensation to the occupier of the land on the
date and in the manner as prescribed by the State Government.
11E. The lessee shall, in the matter of employment, give preference to the
tribal and to the persons who become displaced because of the taking up of
mining operations.
12. Act 67 of 1957. - The lessee/lessees shall be bound by such rules as may
be issued from time to time by the Government of India under section 15 of
the Mines and Minerals (Development and Regulation) Act, 1957 (Act 67 of
1957) and shall not carry on mining or other operations under the said lease
in any way other than as prescribed under these rules.
13. To provide weighing machine. - Unless specifically exempted by the State
Government, the lessee/lessees shall provide and at all times keep at or near
the pit head or each of the pit heads at which the said minerals shall be
brought to bank, a properly constructed and efficient weighing machine and
shall weigh or cause to be weighed thereon all the said minerals, from time to
time, brought to bank, sold, exported and converted and also the converted
products and shall at the close of each day cause the total weights,
ascertained by such means of the said minerals, ores products raised, sold,
exported and converted during the previous twenty- four hours to be entered
in the aforesaid books of accounts. The lessee/lessees shall permit the State
Government at all times during the said term to employ any person or
persons to be present at the weighing of the said minerals as aforesaid and
to keep accounts thereof and to check the accounts kept by the
lessee/lessees.
14. To allow test of weighing machine. - The lessee/lessees shall allow any
person or persons appointed in that behalf by the State Government at any
time or times during the said term, to examine and test every weighing
machine to be provided and kept as aforesaid and the weights used
therewith in order to ascertain whether the same respectively are correct and
in good repair and order and if upon any such examination or testing any
such weighing machine or weights shall be found incorrect or out of repair or
order, the State Government may require that the same be adjusted, repaired
and put in order by and at the expense of the lessee/lessees and if suchBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

requisition be not complied with within fourteen days after the same shall
have been made, the State Government may cause such weighing machine
or weights to be adjusted, repaired, and put in order and the expense of so
doing shall be paid by the lessee/lessees to the State Government on
demand and if upon any such examination or testing as aforesaid any error
shall be discovered in any weighing machine or weights to the prejudice of
the State Government such error shall be regarded as having existed for
three calendar months, previous to the discovery thereof or from the last
occasion of so examining and testing the same weighing machine and
weights in case such occasion be within such period of three months and the
said rent and royalty shall be paid and accounted for accordingly.
15. To pay compensation for injury of third parties. - The lessee/lessees shall
make and pay reasonable satisfaction and compensation for all damage,
injury or disturbance of person or property which may be done by or on the
part of lessee/lessees in exercise of the liberties and power granted by these
presents and shall at all times save harmless and keep indemnified the State
Government from and against all suits, claims and demands which may be
brought or made by any person or persons in respect of any such damage,
injury or disturbance.
16. Not to obstruct working of other minerals. - The lessee/lessees will
exercise the liberties and powers hereby granted in such a manner as to offer
no unnecessary or reasonably avoidable obstruction or interruption to the
development and working within the said lands of any minerals not included
in this lease and shall at all times afford to the State Government and to the
holders of mining leases in respect of any such minerals or any minerals
within any land adjacent to the said lands, as the case may be, reasonable
means of access and safe and convenient passage upon and across the said
lands to such minerals for the purpose of getting, working, developing and
carrying away the same provided that the lessee/lessees shall receive
reasonable compensation for any damage or injury which he/they may
sustain by reason or in consequence of the use of such passage by such
lessees.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

17. Transfer of lease. - (1) The lessee/lessees shall not, without the previous
approval of the Collector,:-
(a)assign, sublet, mortgage, or in any other manner, transfer the mining lease, or any right, title or
interest therein, or;(b)enter into or make any arrangement, contract or understanding whereby the
lessee/lessees will or may be directly or indirectly financed to a substantial extent by, or under
which the lessee's operations or undertakings will or may be substantially controlled by, any person
or body of persons other than the lessee/lessees:Provided That The Collector shall not give its
approval unless, -(a)the lessee has furnished an affidavit along with his application for transfer of
the mining lease specifying therein the amount that he has already taken or proposes to take as
consideration from the transferee;(b)the transfer of the mining lease is to be made to a person or
body directly undertaking mining operations.(2)The lessee/lessees shall make available to the
transferee the original or certified copies of all plans of abandoned workings in the area and in a belt
65 metres wide surrounding it.(3)The Collector may by order in writing, determine the lease at any
time if the lessee/lessees has/have committed a breach of any of the above provisions.Provided That
no such order shall be made without giving the lessee/lessees a reasonable opportunity of stating
his/their case.
18. Not to be financed or controlled by a Trust, Corporation, Firm or person. -
The lease shall not be controlled and the lessee/lessees shall not allow
themselves to be controlled by any Trust, Syndicate, Corporation, Firm or
person except with the written consent of the State Government. The
lessee/lessees shall not enter into or make any arrangement, compact or
understanding, whereby the lessee/lessees will or may be directly or
indirectly financed by or under which the lessee's/lessees' operations or
undertakings will or may be carried on directly or indirectly by or for the
benefit of or subject to the control of any Trust, Syndicate, Corporation, Firm
or person unless with the written sanction given prior to such arrangement,
compact or understanding, being entered into or made, of the State
Government and any or every such arrangement, compact or understanding,
as aforesaid (entered into or made with such sanction as aforesaid) shall
only be entered into or made and shall always be subject to an express
condition binding upon the other party or parties thereto that it shall be
terminable if so required in writing by the State Government and shall in the
event of any such requisition being made be forthwith thereafter determined
by the lessee/lessees accordingly.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

19. Lessee shall deposit any additional amount necessary. - Whenever the
security deposit Rs. .............. or any part thereof or any further sum hereafter
deposited with the Collector in replenishment thereof shall be forfeited or
applied by the State Government pursuant to the power hereinafter declared
in that behalf the lessee/lessees shall deposit with the Collector such further
sum as may be sufficient with the unappropriated part thereof to bring the
amount in deposit with the State Government up to the sum equal to the full
security deposit amount.
20. Delivery of workings in good order to State Governments after
determination of lease. - The lessee/lessees shall at the expiration or sooner
determination of the said term deliver up to the State Government all mines,
pits, shafts, inclines, drifts, levels, water ways, airways and other works now
existing or hereafter to be sunk or made on or under the said lands except
such as have been abandoned with the sanction of the State Government
and in any ordinary and fair course of working all engines, machinery, plant,
buildings, structures, other works and conveniences which at the
commencement of the said term were upon or under the said lands and all
such machinery set up by the lessee/lessees below ground which cannot be
removed without causing injury to the mines or works under the said lands
(except such of the same as may with the sanction of the State Government
have become disused) and all buildings and structures of bricks or stone
erected by the lessee/lessees above ground level in good repair order and
condition and fit in all respects for further working of the said mines and the
said minerals.
21. (a) Right of preemption. - The State Government shall from time to time
and all times during the said term have the right (to be exercised by notice in
writing to the lessee/lessees) of pre-emption of the said minerals (and all
products thereof) lying in or upon the said lands hereby demised or
elsewhere under the control of the lessee/lessees and the lessee/lessees
shall with all possible expedition deliver all minerals or products or minerals
purchased by the State Government under the power conferred by this
provision in the quantities at the times in manner and at the place specified
in the notice exercising the said right.
(b)Should the right of pre-emption conferred by this present provision be exercised and a vessel
chartered to carry the minerals or products thereof procured on behalf of the State Government orBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

the Central Government be detained on demurrage at the port of loading, the lessee/lessees shall
pay the amount due for demurrage according to the terms of the charter party of such vessel unless
the State Government shall be satisfied that the delay, is due to causes beyond the control of the
lessee/lessees.(c)The price to be paid for all minerals or products of minerals taken in pre-emption
by the State Government in exercise of the right hereby conferred shall be the fair market price
prevailing at the time of pre-emption provided that in order to assist in arriving at the said fair
market price the lessee/lessees shall if so required furnish to the State Government for the
confidential information of the Government, particularly of the quantities, descriptions and prices of
the said minerals or products thereof sold to other customers and of charters entered into for
freight, for carriage of the same and shall produce to such officer or officers as may be directed by
the State Government original or authenticated copies of contracts and charter parties entered into
for the sale or freightage of such minerals or products.(d)In the event of the existence of a state of
war or emergency (of which existence and President of India shall be the sole judge and a
notification to this effect in the Gazette of India shall be conclusive proof), the State Government
with the consent of the Central Government shall from time to time and all times during the said
term have the right (to be exercised by a notice in writing to the lessee/lessees forthwith take
possession and control of the works plant machinery and premises of the lessee/lessees on or in
connection with the said lands or operations under this lease and during such possession or control
the lessee/lessees shall conform to and obey all directions given by or on behalf of the Central
Government or State Government regarding the use or employment of such works, plants, premises
and minerals provided that fair compensation which shall be determined in default of agreement by
the State Government shall be paid to the lessee/lessees for all loss or damage sustained by
him/them by reason or in consequence of the exercise of the powers conferred by this clause and
PROVIDED ALSO that the exercise of such powers shall not determine the said term hereby granted
or affect the terms and provisions of these presents further than may be necessary to give effect to
the provisions of this clause.
22. Employment of foreign national. - The lessee/lessees shall not employ, in
connection with the mining operations any person who is not an Indian
national except with the previous approval of the State Government.
23. Recovery of expenses incurred by the State Government. - If any of the
works or matters which in accordance with the covenants in that behalf
hereinbefore contained are to be carried or performed by the lessee/lessees
be not so carried out or performed within the time specified in that behalf, the
State Government may cause the same to be carried out or performed and
the lessee/lessees shall pay the State Government on demand all expenses
which shall be incurred in such carrying out or performance of the same and
the decision of the State Government as to such expenses shall be final.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

24. Furnishing of geophysical data. - The lessee/lessees shall furnish, -
(a)all geophysical data relating to mining fields, or engineering and ground water surveys, such as
anomaly maps, sections, plans, structures, contour maps, logging, collected by him/them during the
course of mining operations to the State Government and Director- General, Geological Survey of
India.(b)all information pertaining to investigations of radioactive minerals collected by him/them
during course of mining operations to the Secretary, Department of Atomic Energy, New Delhi and
to the State Government. Data or information referred to above shall be furnished every year
reckoned from the date of commencement of the period of the mining lease.
25. Storage and use of explosive. - The storage and use of any explosive
shall only be in accordance with the provision of Indian Explosive Act, the
Metalliferous Mines Regulation for the time being in force and lawful
directions of the Inspector of Mines. The lessee shall be responsible for and
ensure that no explosive intended for the mine is pilfered or misused or used
for purposes, within or outside the lease area, other than mining within the
lease area.
26. Boundary dispute. - If any boundary dispute or disputes regarding the
right or way or any other dispute, whatsoever regarding the construction of
any term or condition in the lease arises between the lessee and the lessee
of any adjoining block already leased under similar terms or which may
subsequently be leased, the lessee shall be bound to submit such dispute to
the decision of the Collector or to an officer appointed by State Government
for the purpose. An appeal shall lie to the Commissioner of the Division from
the decision of the said officer and the order of the Commissioner of the
Division thereon shall be final and binding on the lessee.
27. To abide by rules and regulations. - The lessee shall abide by all existing
laws and rules and regulations as may be enforced by the Government of
India or the State Government and all such other laws, rules and regulations
as may be enforced from time to time in respect of working of mines and
minerals and other matter affecting the safety, health and convince of the
employees of the lessee or of the public. On receipt of a notice from the State
Government or from an officer authorised by the State Government in this
behalf regarding any unlawful or irregular work in connection with the
working of the mine the lessee shall also be bound to pay compensation to
the State Government for all losses due to any illegal or unlawful work done
by the lessee or this employees.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

28. The lease shall be liable to cancellation if the lessee ceases to work the
mine or the quarry, for a continuous period of one year without obtaining the
previous permission of the competent office or collector.
Provided that the lease shall not be cancelled if the lessee is prevented from working the mine or
quarry owing to circumstances beyond his control.
29. If the lessee does not work in any part of the area leased out to him
continuously for period of six months, of which the Collector shall be the
sole judge, the Collector shall have the power to determine the lease and
reenter the area, provided that the lessee shall be given a reasonable
opportunity to show cause against the same.
30. If the lessee does not work on more than 10% of the area leased out to
him continuously for more than 6 months of which the Collector shall be the
sole judge, the Collector shall have the power to re-enter on 75% of the area
comprised in the lease, provided that the lessee shall be given a reasonable
opportunity to show cause against the same and the area left with the lessee
shall be a compact block including the portion of the area worked by him and
the terms of the original lease shall be considered as modified from the date
of re-entry by the Collector after his final order.
31. It will be the responsibility of the lessee to ensure that the
individual/public/ community properties, cultivable land/structures like
Road/Temple/ Mosque/ Gurudwara/ Church or any other property is not
damaged during the course of mining. Otherwise the lessee will have to pay
the compensation to the concerned and his settlement can also be cancelled
on these basis and all the deposited amount can be forfeited.
32. The Collector may cancel the leased area if the said area is notified as
archaeological site or reserve/protected forest area in future.
33. All mining operations shall be in accordance with the terms and
conditions laid under the Environmental Clearance submitted by the lessee.
34. Any mining operation under settlement shall be undertaken by the lessee
in accordance with the terms & conditions of approved mining plan prepared
for the entire settlement period.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

35. Lessee shall have to pay to the District Mineral Foundation at prescribed
rates every calendar year during the entire lease period.
36. Lessee shall have to pay 2.06% of every calendar year settlement amount
as Income Tax and surcharge.
37. The lessee shall have no claim against the State Government for
compensation or damages due to non-availability of minerals or boundary
disputes or any hindrance caused in transportation.
38. The lessee shall allow other lessee to transport the mineral through his
auction area.
39. Lessee shall have to display a signboard at mining sight exhibiting name
and address of the Lessee, Settlement period, name and address of local
manager.
40. Lessee shall have to arrange shed/shelter, drinking water, 'Palna Ghar',
First Aid kit etc. at mine site under the provisions of labour act/ rules.
41. Lessee shall abide by any other conditions imposed by the Collector as
he deems necessary in regard to public interest. The Collector may
determine the settlement by passing reasoned order if the lessee commits
any breach of terms and conditions mentioned above after the applicant is
given reasonable opportunity of being heard.
42. If the lessee makes default in payments of any Installments, GST, Income
Tax, Stamp Duty and Registration fees on time, the Collector shall give a
thirty days notice to the lessee requiring him to pay within prescribed time
limit and if not paid within such period the Collector may without prejudice to
any proceeding that may be taken against lessee, determine the settlement
and forfeit the whole or part of the security deposit.
43. The lessee shall have to take permission from DGMS under Rule 106 (2)
(b) of Metalliferrous Mines Regulation 1961 for any deep hole blasting and
before deploying any HEMM in mining area.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

44. The lessee shall have to dispatch mineral loaded vehicles by main roads
only and not by the PMGSY roads.
45. Lessee shall submit a mine closure plan within prescribed time period in
the rule.
46. The lessee shall have to submit a yearly report before 31st December of
every year setting forth the extent of protective and rehabilitative works
carried out as envisaged in the approved mine closure plan.
47. The lessee shall maintain the boundary pillars on his own cost in the
whole lease period according to provisions prescribed in the rule.
48. The lessee shall use and store any explosive only after getting
permission from District Magistrate. The lessee shall use any explosive in
accordance with provisions of Indian explosives act and rules. Explosives
shall be supplied by the firms recommended by the Collector.
49. The lessee shall have no claim on any type of property lying within
settled area before the execution of the lease deed.
50. The period of the lease will be valid for five years from the date of
execution of the lease deed. No claim for delay in handing over the area shall
be accepted in future.
51. The lease deed shall be registered by depositing required fees. The lease
may be cancelled in case of non registration of lease deed.
Part-VIII The Covenants of the State Government
1. Lessee/lessees may hold and enjoy rights quietly. - The lessee/lessees
paying the rents, water rate and royalties hereby reserved and observing and
performing all the covenants and agreements herein contained and on the
part of the lessee/lessees to be observed and performed shall and may
quietly hold and enjoy the rights and premises hereby demised for and
during the term hereby granted without any unlawful interruption from or by
the State Government, or any person rightfully claiming under it.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

2. Acquisition of land of third parties and compensation thereof. - If in
accordance with the provision of clause 4 of Part VII of this Schedule the
lessee/lessees shall offer to pay to an occupier of the surface of any part of
the said lands compensation for any damage or injury which may arise from
the proposed operations of the lessee/lessees and the said occupier shall
refuse his consent to the exercise of the right and powers reserved to the
State Government and demised to the lessee/lessees by these presents and
the lessee/lessees shall report the matter to the State Government and shall
deposit with it the amount offered as compensation and if the State
Government is satisfied that the amount of compensation offered is fair and
reasonable or if it is not so satisfied and the lessee/lessees shall have
deposited with it such further amount as the State Government shall
consider fair and reasonable, the State Government shall order the occupier
to allow the lessee/lessees to enter the land and to carry out such operations
as may be necessary for the purpose of this lease. In assessing the amount
of such compensation, the State Government shall be guided by the
principles of the Land Acquisition Act.
3.
(1)Liberty to surrender the lease. - The lessee/lessees may at any time surrender this lease by giving
not less than Six months notice in writing to the Collector, and upon the expiration of such notice
provided that the lessee/lessees shall upon such expiration render and pay all rents, water rates,
royalties, compensation for damages and other moneys which may then be due and payable under
these presents to the lessor or any other person or persons and shall deliver these presents to the
State Government then this lease and the said term and the liberties, powers and privileges hereby
granted shall absolutely cease and determine but without prejudice to any right or remedy of the
lessor in respect of any breach of any of the covenants or agreements contained in these presents.
4. Collector may on an application made by the lessee, permit him to
surrender one or more minerals from his lease which is for a group of
minerals on the ground that deposits of that mineral have since exhausted or
depleted to such an extent that it is no longer possible to work the mineral
economically, subject to the condition that the lessee-
(a)Makes an application for such surrender of mineral at least Six months before the intended date
of surrender; and(b)Gives an undertaking that he will not cause any hindrance in the working of the
mineral surrendered by any other person who is subsequently granted a mining lease for that
mineral.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

5. Refund of security deposits. - On such date as the State Government may
elect within 12 calendar months after the determination of this lease the
amount of the security deposit paid in respect of this lease and then
remaining in deposit with the State Government and not required to be
applied to any of the purposes mentioned in this lease shall be refunded to
the lessee/lessees. No interest shall run on the security deposit.
Part IX – General Provisions
1. Breach of any condition. - In case of breach of any of the condition of the
lease other than mentioned in clauses 2 and 3 of this part the Collector may
require the lessee or his transferees or assignees to pay penalty not
exceeding an amount of annual deed rent specified under clause 2, part V
2. Obstruction to inspection. - In case the lessee or his transferees or
assignees obstructs/obstruct or does/do not allow entry or inspection any of
the conditions of the lease mentioned in clause 1 part III and clauses 13, 14
and 2 of part VII, the Collector may cancel the lease and forfeit the whole or
part of the security deposit.
3. Breach of any other condition. - In case of lessee or his transferee or
assignee commit any breach of any of the conditions specified in (clause 3 of
part III) and clauses 2, 3, 6, 10, 23 of part VII then and in any such case the
Collector shall give notice in writing to the lessee or his transferees or
assignees as the case may be asking him/them to remedy the breach within
30 days from the date of the notice and if the breach is not remedied within
such period the Collector may determine the lease; provided that nothing
therein contained shall debar the Collector from enforcing any other right or
remedy that the Collector may have against the lessee or his transferees or
assignees under any other provisions herein contained.
4. In case of breaches of the covenants and agreements by the lessee on
which the aforesaid notice has been given, the Collector in lieu of giving
notice may impose such penalty not exceeding four times the amount of
annual deed rent specified in clause 2 of part V.Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

5. Failure to fulfill the terms of lease due to "force majeure". - Failure on the
part of the lessee to fulfill any of the terms and conditions of this lease shall
not give the Collector any claim against the lessee or be deemed a breach of
this lease, in so far as such failure is considered by the said Collector to
arise from force majeure, and if through force majeure the fulfillment by the
lessee of any of the terms and condition of this lease be delayed the period
such delay shall be added to the period fixed by this lease. In this clause the
expression "force majeure" means act of god, war, insurrection, riot, civil
commotion, a strike, earthquake, tide, storm, tidal wave flood, lightening,
explosion, fire, earthquake and other happenings which the lessee could not
reasonable prevent or control.
6. Lessee to remove his properties on the expiry of lease. - The lessee having
first paid and discharged the rents and royalties payable by virtue of these
presents may at the expiration or sooner determination of the said term or
within six calendar months thereafter take down and remove for his own
benefit all or any machinery, plant, building, and other works, erections and
conveniences which may have been erected, set up on placed by the lessee
in or upon the said lands and which the lessee is/are not bound to deliver to
the Collector under clause 18 part VII of this schedule and which the
Collector shall not desire to purchase.
7. Forfeiture of property left more than six months after determination of
lease. - If at the end of three calendar months after the expiration or sooner
determination of the said term or after the expiration or sooner determination
of the said term or after the date from which any, surrender by the lessee of
the said lands under the provision contained in clause 4 of part VIII of this
schedule become effective there shall remain in or upon the said land, any
machinery, plant, buildings, structures and other work, erections and
conveniences or other property, the same may be sold or disposed of in
such manner as the Collector shall deem fit without liability to pay any
compensation or account to the lessee in respect thereof.
8. Recovery under the public demand act. - Without prejudice to any other
mode of recovery authorised by any provision of this lease or by any law all
amount falling due hereunder against the lessee may be recovered as a
public demand under the Bihar & Orissa Public Demands Recovery Act orBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

any Statutory Act or Rules Thereof for the time being in force.
9. Anticipated royalty for the purpose of stamp duty. - For the purpose of
stamp duty, the anticipated royalty is Rs ...................
10. Responsibility of managing agents. - The managing agent of the lessee
shall be equally responsible as the lessee.
11. Service of notice. - Every notice by these presents required to be given to
the lessee shall be given in writing to such person resident on the said lands
as the lessee may appoint for the purpose of receiving such notices and if
these shall be sent the lessee by registered post addressed to the lessee at
the address recorded in this lease or at such other address in India as the
lessee may from time to time in writing to the Collector or the competent
officer authorised by the Collector in this behalf designate for the receipt of
notices and every such service shall be deemed to the proper and valid
service upon the lessee and shall not be questioned or challenged by him, In
witness where of these presents have been executed in the manner
hereunder appearing the day, month and year first above written.
12. For the purpose of stamp duty the anticipated royalty from the demised
land is Rs......................................................per year.
In Witness Whereof these presents have been executed in the manner hereunder appearing the day
and year first above written.Signed by............For and on behalf of the Governor of Bihar in the
presence of:
1.
2.
Signed by.....for and behalf of.................................................................. in presence of:
1.
2.
Form C[See Rules 34(1)]Form of application for Quarrying PermitNo. - .......Date
......................To,The Competent Officer,.....................................Sir,I/We request that a quarrying
permit under the Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation &Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

Storage) Rules, 2019 be granted to me/us.A sum of Rs. 5000/- being the fee in respect of application
is deposited (copy of challan is enclosed)The following particulars are enclosed:-(i)Clearance
certificate for payment of mining dues to be attached(ii)Written consent of the Raiyatas from which
mineral is to be extracted if the land from which minor mineral is to be extracted are raiyati
lands.(iii)Mineral which the applicant intends to quarry.(iv)The details of the land from which
mineral will be quarried.I/We do hereby declare that the particulars furnished above are correct and
am/are ready to furnish any other details as may be required by you. I/We do hereby declare that
I/We shall adhere to the terms and conditions as indicated in these rules and any other conditions
imposed by competent authority.Yours Faithfully,Signature and Designation of the
applicantPlace-Date-Form D[See Rules 33(1)]Form of Permit For Minor Minerals To be Issued
Under The Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage)
Rules, 2019.Permit No.-___________________of 20_________Name and address of the
permit holder:-
Name of locality
village, plot,
number etc.Date of
expiry of
permitName and
description of
minor mineralsPurpose for
which it will
be usedNumber of
quantity of
materialsRate of
royaltyTotal
amount
paid
1 2 3 4 5 6 7
       
SealCompetent OfficerThe permit is issued subject to the terms and conditions noted
below:-Conditions.(1)Materials shall have to be removed within the prescribed time-
limit.(2)Quarrying is not allowed beyond a depth of 3m from the surface.(3)Compensation, if any,
shall have to be paid for damage to the land covered by permit.(4)Felling of trees is not allowed
without prior permission of competent authorities within whose jurisdiction the area lies.(5)Surface
operation shall not be done on any public prohibited and restricted place.(6)Every type of accident
shall be reported to the Competent Officer immediately.(7)The party shall be liable to indemnify the
claims of third parties. State Government shall not be responsible for such claims in any way.(8)The
materials left after the cancellation of the permit shall be forfeited to Government and the same
shall be deemed to be Government property.(9)No excess quantity of materials beyond this permit
this permit shall be removed without obtaining prior permit, otherwise the permit holder shall be
liable for action Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation &
Storage) Rules, 2019.(10)Proper accounts for the extraction and removal shall be maintained in the
prescribed form and a monthly return shall be submitted within the month following the month to
which extraction relates.(11)e-chalans in the prescribed form shall have to be issued for the
materials to be dispatched or sold from the area.N.B. - Breach of any of the conditions noted above
is liable for the cancellation of permit, forfeiture of materials extracted and such other action as may
be deemed necessary.Form- E{See Rule 37(1), (2) & (3)}Application for the grant of Mineral
Disposal Permit for disposal of mineral extracted during the process of maintenance / drainage of
drain / canal / river or generated during the process of construction or repair or demolition of
building /structure / or accumulated due to floods / dispersed through production activity.ToThe
District Mining Officer,Mines and Geology Department,..........................................................Dear
Sir,Undersigned has to remove and transport minor minerals during the process of maintenance /
drainage of drain / canal / river or generated during the process of construction or repair or
demolition of building /structure / or accumulated due to floods / dispersed through productionBihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

activity at ....................................... (Location of site). The approved copy of the site plan is attached.
In the process of digging /repair/ demolish mineral(s) namely.................... shall also be excavated
incidental to the above developmental activity .The same requires to be consumed at the site or
disposed off, for which permission is solicited.
2. The details of the area for which permission is being sought, is given as
under:-
(a)Location of the area(b)Purpose(c)Total area/ built up area(d)Extent of the area required for
digging giving length, breadth & depth(e)Quantity and particulars of the mineral(s) to be
removed(f)Advance royalty payable
3. The applicant further state that:-
(i)the royalty at the rates prescribed under the rules shall be paid in advance on the mineral(s)
excavated incidental to digging of foundation/ basement / demolish of structure / maintenance of
drain /canal / river / accumulated due to floods.(ii)the intention of digging is not to excavate
mineral(s) from the said site for commercial mining but for lying of foundation or basement /
demolish of structure or developmental activity duly approved by the competent authority.(iii)The
incidental mineral(s) excavated will be disposed of only on issuance of a valid E-challan / Transit
Pass as supplied by the Competent Officer / District Mining Officer.Dated :Enclose: As above.(Name
and address of the applicant)(i)Proof of ownership of land.(ii)Site plan along with a copy of
permission/ sanction of competent authority to undertake development activities or construction /
demolition of building etc.Form -F[See Rule 37(1), (2)&(3) ]Form For Grant of Mineral Disposal
PermitMineral Disposal Permit No.....................Place ................ Date.......................... Whereas, Shri
........................................................ (Name and Designation) applied for grant of Mineral Disposal
permit for disposal of ............................ cubic meters / tones / cubic feet of
........................................... (Name of Minor Minerals) from Khesra No.............................................of
Village ............................... Circle ..................... District ............................. under Rule 37 of the Bihar
Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019 and has
paid an application fee of Rs. ..................... and advance royalty amounting to Rs.. ...............
2. Permission is hereby granted to quarry, collect, remove and transport
.....................................(mineral) from the area indicated on the plan annexed
hereto during the process of maintenance / drainage of drain / canal / river or
generated during the process of construction or repair or demolition of
building / structure / or accumulated due to floods / dispersed through
production activity at ................................................... (village)
............................................................ (Circle)................................. (District).Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

3. The mineral disposal permit shall be valid for........................ (Period) from
................................... to ..............................
4. The Mineral disposal permit shall be governed by the following conditions
namely-
(a)The holder of permit shall maintain complete and correct account of the mineral removed and
transported from the area;(b)The holder of permit shall allow Deputy Director/Mining
Officer/Mining Inspector or any officer authorized by the Collector to inspect the site and verify the
accounts.(c)No sooner the permitted quantity is transported within the time period of 30 days or
earlier, complete statement of the quantities deposited duly certified by the Officer of the concerned
department shall be furnished to the Sanctioning Authority.(d)The holder of permit shall obtain all
permissions/ consents from the competent authority under any Act and Rules applicable for
excavation or removal of the minerals from the area.(e)The holder of permit shall submit by the 15th
of every month, to the District Mining Officer / Collector a return in prescribed format.(f)Any other
condition, the sanctioning authority may deem fit.Enclosure. - Plan showing area granted under
permit.Signature of the Competent Authority With seal of officeForm-G[See Rule 41 ]Mineral
Transit pass/ e-challan Deptt. of Mines & Geology Government of BiharChallan/Pass No. :
1. Year :
2. Name of the Sand ghat/quarry :
3. GPS co-ordinates of sand ghat/quarry :
4. Name of sand ghat Owner/Settlee :
5. Mobile No. of Settlee :
6. Full Adress of Settlee :
7. Date of expiry of lease :
8. Date and time of issuance of this Challan :
9. Challan Valid Upto :
10. . Name of the customer :Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

11. Mobile No. of the customer :
12. Name of Mineral :
13. Weight of the mineral(in MT) :
14. Volume of the mineral (in Cft ) :
15. Amount Collected at Pit Head :
16. Vehicle No. :
17. Type of Vehicle :
18. Driver Name :
19. Driver Mobile No :
20. Destination :
Note:- Additional entries may be made in the prescribed format in electronic system as per
need.Form- H[See Rule 46 (1)]Register to be Maintained by the Lessee / Permit Holder
1. Name and address of lessee / permit holder
2. Details of quarry lease / permit.
3. Area ...............................................
4. Mineral ...........................................
5. Location of quarry site .........................
SL.
No.DateOpening
Balance.Quantity
extractedTotalName of
Persons to
whom sold/
dispatchedNumber
of
challan
issuedTotal
quantity
sold or
dispatchedQuantity
in stock
at the
close of
the dayAmount
of
royaltyRemarks
1 2 3 4 5 6 7 8 9 10 11
           Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

Form- IMonthly Return[see rule 46 (2)](To be submitted before the 15th day of every month in
respect of preceeding month)
1. Return for the month: ____________(name of month and year)
2. Name of the lessee with address:_________________________________
3. Details of the mining lease:
(a)Grant order No.& Date ______________________________________(b)Date of
execution of the lease________________________________(c)Location of the mining lease
_________________________________(d)Area of the mining lease
___________________________________(e)Period of the mining lease
___________________________________
4. Name of the Minor Mineral: ________________________________________
5. Opening stock on the first day of the month_________________________
6. Quantity
produced:________________________________________________
7. Quantity
consumed:_______________________________________________
(b)Quantity dispatched:____________________________________________
8. Closing stock at the end of the month:______________________________
9. Pits mouth value
__________________________________________________
10. Number of days the mine worked:__________________________________
11. The number of days of works stoppage._____________________________
In the mine. Indicate reason for such stoppage._____________________Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

12. No. of man days worked:
___________________________________________
13. Average daily
employment:_________________________________________
14. Details of machinery and equipment deployed_______________________
15. Details of explosives consumed with Quantity_______________________
Remarks: _________________________________Date:Place:Signature of the lessee.Or his
Authorized Agent or Manager with Seal.Form - JAnnual Return[see rule 46 (3)](To be submitted by
30th April of each year in respect of the preceding financial year)
1.Annual Return for
the year1st April 20__to 31st March 20__
2.Name of lessee
with address:_________________________________
  _________________________________
  _________________________________
  _________________________________
3.Details of the
mining lease:_________________________________
 a. Grant order
No.& Date_________________________________
 b. Date of
execution of the
lease_________________________________
 c. Location of the
mining lease_________________________________
 d. Area of the
mining lease_________________________________
 e. Period of the
mining lease_________________________________
4.Name of the Minor
Mineral:_________________________________
5.Opening stock on
the first day of the
month_________________________________
6.Quantity produced _________________________________Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

during the year:
7.a) Quantity
consumed during
the year:______________________________
 (b) Quantity
dispatched during
the year:_____________________________
8.Closing stock at
the end of the year:_________________________________
9.Average Pits
mouth value (Rs):_________________________________
10.Royalty (Rs) paid /
Installment
amount: 
 (a) for the current
year:_________________________________
 (b) towards past
arrears:_________________________________
11.Dead Rent (Rs)
paid: 
 (a) for the current
year:_________________________________
 (b) towards past
arrears:_________________________________
12.Number of days
the mine worked
during the year:______________________
13.The number of
days of work
stoppage during
theyear. Indicate
reason(s) for such
stoppage(s)._________________________________________
14.No. of mandays
worked:______________________________________________
15.Average daily
employment:____________________________________________
16.Accidents (if any): ____________________________________________________
17.Details of
machinery &
equipment___________________________Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

deployed
18.Details of
explosives used
with quantity:_________________________________
Remarks:Date:Place:Signature of the lessee or his Authorized Agent or Manager with SealLicense in
Form 'K'[See Rule 39 (1)]Shri/s. Sri.....................is Approved To Be A Person To Stock Minor/major
Minerals At ..................(Name of Place)..............P.S............................ District ............................... and
He Will Abide By The Provisions of Bihar Minerals (Prevention of Illegal Mining, Transportation,
Storage & Concession) Rules, 2019Seal and Signature of Competent officer'Form - LForm For
Appeal[See rule 67 (3)
1.Name and address of individual (s) /firm or _________________________
 Company _________________________
2.Number & date of order against which appeal ismade.
(certified copy to be enclosed)_________________________
3.Designation of the authority that passed the order. _____________________
4.(i) Whether the appeal has been filed within60(Sixty)
days from the date of communication of the order
interms of sub rule 1/2 of Rule 67.__________________________
(ii)If not, the reasons thereof __________________________
5.Name(s) of mineral or minerals for which appeal ismade _________________________
6.Details of the area in respect of which appeal ismade (A
Plan of the area to be attached) 
 (a) Village/Locality: __________________________
 (b) P.O/Thana: __________________________
 (c) Pin code: __________________________
 (d) Block/Sub-Division/District: __________________________
7.Grounds for appeal. a.________________________
  b._______________________
  c.________________________
8.Name and address of the party/parties
impleaded.Reasons for impleading him/them to be
mentioned.__________________________
  __________________________
  __________________________
9.Proof of fee paid (to be attached)  
Yours faithfully,Signature of the applicant.Place ......................Dated ......................Bihar Minerals (Concession, Prevention of Illegal Mining, Transportation & Storage) Rules, 2019

