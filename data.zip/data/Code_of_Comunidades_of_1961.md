Code of Comunidades of 1961
GOA
India
Code of Comunidades of 1961
Rule CODE-OF-COMUNIDADES-OF-1961 of 1961
Published on 15 April 1961• 
Commenced on 15 April 1961• 
[This is the version of this document from 15 April 1961.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Code of Comunidades of 1961The Code of Comunidades has been amended from time to time and in
the earlier translation published by the Government text of different amendments have been
appended to the said volume from pages 217 to 249. They are incorporated in the present set
translation for the purpose of convenience.Title I
Chapter I
General Provisions
Article 1.The [comunidades] [[The Code uses the expression 'comunidades'.Dalgado in his LUSO
Asiatic Glossary, Vol. I, p. 301, publication of Asian Educational Services:explains that
'comunidades' is a Portuguese name, also adopted in Konkani which conveys an agricultural
association of each village of Goa , that possesses from immemorial times, properties in common,
income of which accrues in favour of its members. Englishmen adopted portuguese denominations
within the shape of 'village community'. The comunidades were in the organ, a sort of 'comune'
village all particularly necessary for social life]] or ['gauncarias'] ['gauncarias' means an association
of gauncares.]- (association of gaucares) existing in the District of Goa shall be governed by the
provisions of the present [Code] [In the same article the general law is the Civil Code.], and in
particular, by the specific statutes governing each of them and in matters where the code is silent,
the general law shall apply.§ 1. A group of two or more comunidades under one single administrator
or the group of several villages forming one single Comunidades, is called [Torofo] [The word
'Torofo' similar to 'sazas' under the Land Revenue Code, conveys the meaning of a group.] - (group
of comunidades)- and the provisions by which the comunidades are governed shall be applicable to
them.§ 2. By statute it implies any written instrument or regulation by which a Comunidades had
been governed, and in absence of these, by the practice invariably observed at least for 50 years
prior to 1904.§ 3. The statute of the comunidades of Goa, Salsete, Bardez, Mormugao are, as
mentioned in map 8 which forms an integral part of this code and that of to the other comunidades,
shall be formulated within a period of six months from the date of publication of this code by the
respective administrative boards and submitted for the approval of the Government which also,Code of Comunidades of 1961

after the approval, shall form integral part of the same Map.Article 2.The comunidade and the group
of comunidades - [Torofo] [The word 'Torofo' similar to 'sazas' under the Land Revenue Code,
conveys the meaning of a group.], existing at present, are indicated in map No. 1.Article 3.Each
Comunidades comprises of: a) members by birth - [joneiros] [['joneiro' and 'zonn', meaning as per
Dalgado in Portuguese means 'JONO' from which comes'jonoeiro'. 'Zonns' are proceeds which are
normally received by a 'gauncar'.]] zonnkars ;b) shareholders; c) members by birth and shareholders
and d) participants.§ 1. The shares of the annual income belonging to Comunidades members by
birth - (zonnkars) is called the zonn (profit), and that of the shareholders is called the dividend.§ 2.
In case of dissolution - of the comunidades by means of distribution of its properties or of its values
among members by birth (zonnkars) or shareholders, the holders of these properties substitute in
all respect such members by birth (zonnkars) or shareholders subject to all the burden lying over the
respective comunidades.Article 4.Only the Comunidades members by birth - (zonnkars) and
shareholders are entitled to the profits or losses of the comunidades and only they have the rights
and duties that are guaranteed and imposed by this Code to the members of the Comunidades.Sole §
For the purpose of this article, the orphan sons of the members by birth (zonnkars) and their
widows and unmarried daughters, who are entitled to receive the proceeds of zonn, annuity for
service or life-long pension as per the statues of the Comunidades, shall be considered as members
by birth (zonnkars).Article 5.The comunidades shall be under the administrative tutelage of the
State, in terms established in this Code, and its immovable properties may be granted on
emphyteusis and alienated in the manner provided in this Code.Sole § With effect from the year
1962 the comunidades shall cease to pay the (foro) to the National Treasury.Article 6.The canons
(foros) payable on emphyteusis, by the comunidades and any other instalments or periodical
pensions that they may receive from the emphyteutas, owners, servants or individuals are
redeemable, in terms of the general law that regulates the redemption of pension (foro), in all the
respects not provided in this Code.Sole § The amount received from the redemption shall be utilized
for the purposes prescribed in articles 8, 14 and 64 , No. 4 and for the agricultural
development.Article 7.The Comunidades do not enjoy, in regards to the immovable properties,
granted on emphyteusis, the right conferred to the grantors, under article 1662 of the Civil Code and
its paragraphs, and the said immovable properties may be alienated and divided, however the
comunidades shall have the right to increase the pension (foro) at the time of its division, in terms
prescribed in this Code.Article 8.The comunidades may request, in terms of law, acquisition of land
for public purpose that may be required for irrigation and protection purposes.Article 9.The
comunidades are not entitled to file any civil suits without permission of the Administrative
Tribunal, save in cases where civil suit is merely of preventive relief or of executive nature or the
delay in its filing may result in extinction of the right or any guarantee, in which case the sanction of
the administrator be enough.Article 10.The comunidades will be represented in Civil Courts or any
other tribunal, Government office, by its regular attorney on duty, or substitute with full powers or
by special attorney.§ 1. The minutes of the meeting of the election or the order of appointment of the
regular attorney, effective or substitute, shall have the effect as that of a power of attorney, but in the
event of choice of the special attorney, the power of attorney shall be recorded in the minutes of
meeting, in the respective book, specifying the respective power.§ 2. The lawyer shall be chosen by
the regular or special attorney.§ 3. For the purposes of supervision, the attorney shall communicate
to the administrator the choice made. However the administrator may change it by a speaking order
and in consultation with the managing committee, when it is found to be against the interests of theCode of Comunidades of 1961

respective Comunidades, save in case of an appeal or claim against the decision of the Comunidades
or of the managing committee or of the administrator.Article 11.The comunidades shall be served
with summon in the person of the respective administrator or one who substitutes him.Article
12.For the debts of the comunidades, the attachment may be made on its credits, on the net income,
as mentioned in the balance sheet of income or expenditure and on any other profits, but never on
immovable properties.§ 1. The attachment shall always be carried out through the treasurer of the
Comunidades, in presence of the respective clerk, who is liable to inform, within 24 hours, the
administrator for necessary action; the clerk-in-charge, dealing with the case, shall mention in the
declaration of the attachment, the amount under execution proceedings and the accessories.§ 2. As
long as the attachment subsists, no extraordinary expenditure shall be voted or approved, except in
cases provided in the article 64, No. 3, or when the debt under execution proceedings is guaranteed
by the balance in the safe.Article 13.The proceeds of income (zonn), of the members of the
comunidades and the rights to the future profits can be seized or attached for the debts of the same
member to the respective comunidades or to their subrogatories.§ 1. Barring this case, only the
portion of the amount that has matured, from the same proceeds to which the member may be
entitled to, at the time of attachment, may be seized.§ 2. The clerk of the Comunidades, in view of
the authentic copy of the declaration of attachment, which shall be given to him by the clerk who
carries out the seizure or attachment, shall inform the administrator and shall make the necessary
annotations and entries in the competent books and shall not effect payment of proceeds from the
properties seized or attached.Article 14.As soon as there is sufficient fund in the safe, the
comunidades can redeem the charges in favour of individual or collective persons, by paying the
amount of twenty annual instalments, save the religious charges, which cannot be redeemed.Article
15.The comunidades that have liabilities to clear or charges which may desire to redeem, in terms of
preceding article, shall be bound to set apart amount not less than one tenth of its net incomes, in
their annual income and expenditure sheet for payment of loans or remission charges. It shall be
duty of the administrator to carefully verify the compliance of this disposition, failing which he shall
be liable to civil and disciplinary proceedings.§ 1. Amount less than required for the purpose
mentioned in this article can be kept separately, when the obligations does not exceed one-tenth of
the net income.§ 2. For the purpose of this article it is necessary that the debts are supported by a
legal and valid document.Article 16.All the services that are rendered hereditarily by certain families
and paid by usufruct of some specific properties, stand abolished.Article 17.The properties, at
present enjoyed by way of usufruct, referred to in preceding article, shall continue to belong to its
possessors and the services rendered by them shall be valued and the same shall be converted, as
per the assessment, in a pension (foro) in favour of the Comunidades, which pension shall be
remain as a charge on the said land.Sole § The valuation shall be done in accordance with the
respective terms of the Code of Civil Procedure (Codigo de Processo Civil) in presence of the
administrator. The latter's decision is subject to appeal to the Administrative Tribunal.Article 18.The
comunidades can create medical posts, in consultation with the Directorate of Health Services, and
the selection procedure to fill up those posts shall be conducted in the Directorate of Civil
Administration, in terms of general law in force.§ 1. The medical posts, referred to in the present
article, shall be filled on contract basis, in accordance with the articles 45 to 47 of the Overseas Civil
Services Statutes - (Estatuto do Funcionalismo Ultramarino). However the same shall depend on the
favorable vote of the concerned comunidades, in respect of the concession of privileges that imply
financial burden to them.§ 2. The provision in the preceding paragraph shall be applicable to theCode of Comunidades of 1961

medical posts existing as on the date of publication of this Code.Article 19.All the fines laid down in
this Code and those that may be fixed in the clauses of contracts or of the auction, shall be recovered
in terms of title V, when they are not paid voluntarily, and the same shall be reverted in favour of the
Pensioners' Bank - (Caixa de Aposentações).Sole § No fine shall be imposed nor any necessary
charge made, without the prior hearing of the interested party, who shall be notified, about the
same, within the period of five days of the respective decision. The defaulter being free to pay the
same voluntarily within same period, from the date of the notification or he may file an appeal to the
higher instance, within the time limit prescribed by law.
Chapter II
Comunidades
Section IMembers of the ComunidadesArticle 20.Following are the members of the comunidades in
terms of article 3.
1. Those who are entitled to receive zonn, either per head or per lineage - (per
capita or per stirpes) - and their male descendants by male lineage,
legitimate, legitimized, acknowledged as legitimate and adopted, whatever
may be their number;
2. Those who possess Comunidades shares certificates annotated and
registered in their own name;
3. Those who have a share in the net income of the Comunidades, whichever
may be the nature and denomination of such participations, provided they
obtain their registration in their favour in the respective books of the
Comunidades, by way of an application addressed to the administrator,
supported by the document of transmission.
Article 21.The right to zonn, of the members to which the clause No. 1 of the preceding article refers,
is personal, inalienable and imprescriptible and it shall only commence from the date of the primary
enrolment, save in case when the registration is effected through an appeal, in which case, the right
shall be effective from the retrospective date of refusal by the clerk of Comunidades.§ 1. For
receiving the proceeds of zonn, it is necessary, besides the primary enrolment, the annual enrolment
of members by birth - zonnkars.§ 2. The right to the proceeds of zonn, stands suspended or lost in
the case mentioned in clause (b) of article 379 and stands extinguished on the death of the zonnkar
but only after the expiry of the year for which he has been registered.§ 3. The proceeds of zonns, the
allowances or periodical pensions, prior to the last ten years, stand prescribed in favour of the
Comunidades, from the 1st March immediately following the period fixed for its payment.Article
22.The rights laid down in the clause No. 2 of article 20 shall commence from the date of the
primary enrolment of the respective shares, and those laid down in No. 3 of the same article fromCode of Comunidades of 1961

the primary enrolment of the respective participants.§ 1. For receiving the dividends of the shares
and in order to exercise the rights of the member, it is necessary that registration must be in the
administration office and the primary enrolment in the respective Comunidades.§ 2. The provisional
registration of shares certificates does not confer upon the shareholder the membership right, but
only the right of alienation of shares certificates, in the status in which he possesses them; however,
the provisional primary enrolment, confers the rights referred to in the preceding paragraph, and
these rights are liable for extinction.§ 3. The provision of the first part of paragraph 2 and in the
paragraph 3 of the preceding article shall be applicable to the dividends from the shares and to the
shares of the participants.§ 4. When there is impossibility or difficulty for the appearance of the
absentee members to collect the proceeds of zonns, dividends of shares certificates, share of
participants, allowances and pensions, the Governor-General may authorize the payment to be
effected in favour of the one who produces a declaration issued by the concerned party, with the
signature duly recognized by the clerk of the Comunidades, and with the undertaking to refund, in
case of any complaint being received.§ 5. In cases of constitution of [fideicomissum] [See 1866 of the
Civil Code.] or reservation of [usufruct] [See 2197 of the Civil Code.], the registration (averbamento)
shall be made in the name fideicomissionare or of the owner and the registration in the name of
fiduciary or of usufructuary.Article 23.It is not lawful to make transfer of proceeds of zonn to be
accrued in future.Article 24.The shares certificates of the comunidades are transmissible and
alienable in terms prescribed in this Code.[Article 25.] [Article 25 has been amended by Goa Act No.
3 of 1998 dated 17/01/1998. (See Appendix).]The proceeds of zonns, and interests of any nature of a
deceased member and the dividends of the shares registered and inscribed in the name of the
deceased member of an inheritance can be received by the head of family, upon production of an
order issued by the administrator, based on the certified copy of a pending inventory.§ 1. When the
proceeds of zonn, amount of interests, or dividends do not exceed [Rupees 500/-] [Substituted for
the words '3,000 escudos' by Goa Act 3 of 1998, dated 17-1-1998.], the interested parties in the
inheritance can receive the same, by producing a certificate, issued by the clerk of the Comunidades,
to the effect that he had issued notices of claim, within a time limit of 30 days, at the door of a
temple of any religion existing in the village, at the door of meeting hall of the comunidades and at
that of the respective office of the administrator and published in the Official Gazette, being one of
the copy presented to the managing committee, when in meeting, and passed without objection
from any of the members, in the respective meeting.Where the amount to be received does not
exceed [Rupees 50/-] [Substituted for the words '3,00 escudos' by Goa Act 3 of 1998, dated
17-1-1998.], the publication in the Official Gazette is dispensed with.[Explanation. - In the Code of
Comunidades, wherever any amount is indicated in escudos, the same shall be calculated at the rate
of six escudos per rupee.] [Inserted by Goa Act 3 of 1998, dated 17-1-1998.]§ 2. The authorization
granted by the administrator, for the purposes of provision in this article, shall be valid for the
subsequent years and shall subsist until the inheritance, in the inventory proceedings, has been
finally partitioned.§ 3. If the objections are disputed or when there is litigation pending about the
legitimacy of heirs, the proceeds, the interests and the dividends shall be retained on deposit in the
safe of the Comunidades and the objection shall be attached to the file of proceedings. In this case,
the prescription provided in paragraph 3 of articles 21and 22 of this Code shall not be applicable.§ 4.
The provision of this article and its paragraphs shall be applicable to the pensions dealt with in the
article 202.Article 26.The following are the powers of the members of the Comunidades:Code of Comunidades of 1961

1. To intervene, discuss and vote in the meetings of the Comunidades, and
record any protests in the minutes of the meeting;
2. To be elected or appointed for the posts of the Comunidades;
3. To make up for the deficit;
4. To request the president of the managing committee to convene a meeting
of the Comunidades by a petition duly supported, mentioning clearly the
reasons for it and signed by more than five components, or by three in the
comunidades where the number of members is less than fifty. The petition
may be made on ordinary paper;
5. To call for, by a letter addressed to the president, an extraordinary meeting
the managing committee, by indicating the matter to be discussed. In case
the president does not convene the meeting, they can appeal also by a letter
addressed to the administrator, who shall decide as deems proper;
6. To consult, orally or in writing, the managing committee, in session, about
any matters that they feel to be of the interest of the comunidades, and to
submit proposals, which shall be recorded in the minutes of the meeting;
7. To examine the income and expenditure sheets, the calculations for the
auctions and its conditions, the final accounts, the record books and the
account books of the Comunidades and the extraordinary budget heads, at
periods and the forms stipulated in this Code;
8. To appeal against the resolutions of the Comunidades and of the
managing committee and the orders or decisions of the administrator and of
the authorities and higher courts and, in general, to submit complaints on the
matters which are of the interest of the Comunidades;
9. To report the defalcation of funds of the 'comunidade', the encroachment
of its lands and other unlawful acts, as well as any misconduct or error of the
employees and agents of the comunidades.
Article 27. [***] [Article 27 omitted by Goa Act No.3 of 1998 dated 17/01/1998. (See Appendix)]Code of Comunidades of 1961

Article 27.The powers referred to in clauses 1 and 4 to 9 of the preceding article may be exercised
through the attorney, legally constituted. However, for the purpose of paragraph 1 of article 48
specific powers are required to be given.§ 1. It is also permissible for each specific case to use, by
way of declaration in writing, in a paper of any quality and format, with the signature attested by
the notary or by the clerk of the respectiveComunidades, for the acts referred to in the body of this
article.§ 2. When a member does not know to sign, his declaration shall be made by the notary,
drawn in the presence of two witnesses.
[Article 28.] [Article 28 has been amended by Goa Act No.3 of 1998 dated 17/01/1998. (See
Appendix)]The following persons are not permitted to participate in the deliberations of the
Comunidades:
1. The non-emancipated minors and the interdicts, however may be allowed
through their legal guardians;
2. The debtors to the Comunidades or the [subrogatories] [See Section 778 of
the Civil Court.] of the latter, held as such, on whom notice for payment of
debt on current account has been served;
3. Those who may have filed suits or have disputes with the Comunidades, in
the matter relating or connected with the same suits or disputes;
4. Those who have been barred from voting by a judgement that has become
definite in cases provided for in this Code;
5. Those who are directly interested in the subject matter of the deliberation,
or when any of their ascendant or descendant, spouse or relative, in the
transversal line up to the 2nd grade, is interested in it.
6. The foreigners.
§ 1. For the purposes of No. 1, the clerk of the Comunidades shall make a note on the margin of the
respective registration or inscription, mentioning the name of the legal representative or the minor
or incapable person. This note may be made on verbal request of the interested party on
presentation of a document proving the said representation, which may be cancelled based on the
respective document submitted. And in either cases, the documents which have been presented shall
be filed.§ 2. The provision of the No. 6 is not applicable in case of the descendents of the Portuguese
subjects.Article 29.The following cannot be either voted for or appointed for the posts in the
Comunidades:Code of Comunidades of 1961

1. The shareholders, whose income in the Comunidades, when the same is
composed also of members by birth (zonnkars), is not, at least, equivalent to
the minimum quota belonging to any of the zonnkars and, in the
comunidades, exclusively comprised of shareholders, when the number of
shares is greater than 500, those who do not possess, at least, five shares;
2. The non-emancipated minors and the interdicted;
3. Those who are indicted on the final judgement that has become definitive
and those who have been sentenced for the crimes referred to in paragraph 4
of article 12, of Overseas Civil Services Statute (Estatuto do Funcionalismo
Ultramarino);
4. The debtors to the Comunidades or to subrogees, of the later, held as
such, against whom a suit or execution is pending or even against whom a
note of payment of debt in current account has been served;
5. The employees of the cadre of the civil administration, the members and
employees of the Administrative Tribunal and the subordinate officials to the
administrator;
6. The relatives of the administrator up to the 3rd degree;
7. The members of Comunidades of either sex who may not know to read or
write and count in Portuguese;
8. The foreigners.
§ 1. The condition referred to in No.7 may be waived in the talukas of Ponda, Bicholim, Quepem,
Pernem, Sanguem and Canacona, where voting or appointment shall be made of persons who have
knowledge of Marathi, excepting, in regard to the post of president of managing committee, whose
incumbent should have at least passed 4th standard of primary education in Portuguese language.§
2. The relaxation referred to in paragraph 2 of preceding article is applicable to the clause 8of this
article.Section IIPowers of the comunidadesArticle 30.The Comunidades shall:
1. Elect every three years the ordinary attorneys and its substitute, in the
form provided in this Code;Code of Comunidades of 1961

2. Appoint a special attorneys, when necessary, or have their services
dispensed with according to circumstances and the interests of the
Comunidades;
3. Opine on the statement of income and expenditure, the estimates for the
ordinary and extraordinary auctions and their conditions, and on the
finalisation of the accounts and the extraordinary budgets;
4. To deliberate on:
(a)The works and the extraordinary expenses to be incurred;(b)The loans to be
borrowed;(c)Creation or abolition of medical posts, extension of the period of its duration and
maintenance of the same, as well as the creation or abolition of any services or charges of permanent
nature;(d)Introduction of the non-saline and saline water in the khasanas - ['casanas'] [casanas -
Low lying paddy fields at the side of the river or water course, with a bund to prevent
inundation.];(e)Acquisition of lands;(f)Emphyteusis, sale or exchange of land;(g)Institution,
admissions, withdrawal and compromise of civil suit;(h)Extension of time granted for utilization of
land granted on emphyteusis;(i)About the grant of rebate (quita) to the leaseholders;(j)And in
general, about all the extraordinary acts not provided for in the statement of income and
expenditure or in the provisions of this code, as well as relating to any matters about which the
opinion is called for.
5. To appoint and dismiss peons or criers, determining their rights and
obligations.
Article 31.The deliberations referred to in Nos. 1 and 2 of the preceding article are executable
immediately;Sole § The deliberations referred to in clauses (a) to (f) and (h) to (j) of No. 4 of
preceding article shall be devoid of any enforce ability without the approval of the Governor
General, without prejudice to the consultation with the Directorate of Health Services regarding
creation of medical posts.Article 32.The creation of expenditure of permanent nature or of any
extraordinary expenditure for the purposes, other than relating to the Comunidades, may only be
voted by two-thirds of the share capital.§ 1. When the Comunidades, duly convened, for two
successive times, does not meet so as to meet the requirement of two-thirds of its share capital, the
expenditure can be voted for the third time, as per ordinary procedure prescribed in this Code, and
with consent of the twenty majors shareholders of the Comunidades, when such members exist.§ 2.
The members of the comunidades, who contribute for the construction, reconstruction or repair of
the cemeteries shall pay, not more than two-thirds of the ordinary burial charges.Section
IIIMeetings of the comunidadesArticle 33.The Comunidades shall have four ordinary meetings per
year, and extraordinary meetings, as and when necessary.§ 1. The ordinary meetings shall be held in
the first fortnights of March, April, May and December, each of them shall be preceded by an
announcement by beat of drums, through different wards of the village, and by notices affixed on the
doors of the meetings hall and of the temples of any religion existing in the village.§ 2. TheCode of Comunidades of 1961

extraordinary meetings shall be convened by order of the president of the managing committee,
with beat of drums and announcements in the same form as per the preceding paragraph, by
making known in these notices, express and clearly the matter or matters to be dealt with.§ 3.
Whenever the subject referred to is the one of clauses of No. 4 of article 30 and article 77, the notice
of meeting shall be published in the Official Gazette and, at least, in one newspaper, if any, existing
in the respective taluka, no less than fifteen days in advance , in addition to the announcement by
way of beating of drums and public notices, as prescribed in the preceding paragraph, though the
subject ought to have been to be discussed and voted in an ordinary meeting.§ 4. All the meetings of
the Comunidades shall be held in the respective villages, in the building designated for this purpose,
the same however may be held in the headquarters of the administration office or in any other place,
when the Governor-General, for special reasons, so determine.§ 5. In the extraordinary meetings,
only the subject or matters that may have been expressly announced, may be dealt with.§ 6. The
deliberations taken in contravention of the preceding paragraphs are null and void.[Article 34.]
[Article 34 has been amended by Goa Act No.3 of 1998 dated 17/01/1998. (See Appendix)]- The
Comunidades may deliberate when 25 of its members, with the right to vote, are present personally
or by their proxy in the comunidades having more than 100 members; 15, in which there are more
than 50 and less than 100; 9, those having more than 25 and less than 50; and 5 having less than
25.§ 1. However, the Comunidades may be considered as constituted and may deliberate with the
number of members less than indicated in this article, when the members present are more than
one-third of its share capital.§ 2. Save in the cases referred to in paragraph 1 of article 32, the
president of the managing committee shall not consider the Comunidades as duly constituted, if
there may not be represented in it, at least two-thirds of its share capital, in cases provided in this
Code. In this case of irregular meeting, those present shall be responsible for the loss and damage
that the Comunidades may suffer and the deliberation or deliberations taken shall be null and
void.[Article 35.] [Article 35 has been amended by Goa Act No.3 of 1998 dated 17/01/1998. (See
Appendix)]- The deliberations of the Comunidades are to be taken by absolute majority of the votes
by the members present, personally or by their proxy, or even, by the declaration of vote.Sole § In
cases where the voting is done by representation of the share capital, the deliberations shall be taken
by absolute majority of such representation.Article 36.In cases foreseen in clauses (a), (b), (c), (g),
(i) and in the first part of clause (j) of clause 4 of article 30 and, in general in all the matters that
may relate to extraordinary incomes and expenditures and to the sale or exchange of the land of the
Comunidades, the voting on the respective deliberations shall be done by the system of the
representation of share capital.Article 37.The sessions of the Comunidades are public and are
chaired by the president of the managing committee or his substitute and, in the impediment of
both, by the eldest member, the minutes being drawn by the respective clerk.§ 1. When more than
one Comunidades or of its respective managing committee meet, in a joint session, to deal with the
matters of common interests, the president of managing committee, designated by the
administrator, shall preside, and in this case, the clerk of the same Comunidades shall act as the
clerk who shall write the minutes in the book in his charge and immediately forward one copy of it
to the clerks of other comunidades taking part in the meeting, to be written in the respective
minutes book.§ 2. In order to have a combined meeting held or to take deliberation, it is necessary
that there must be present, as many members as would have been required for each of the individual
Comunidades to hold separately a meeting.And in this case, the disposition of previous articles,
relating to the convocation of the meeting and voting, is to be made applicable.Article 38.When theCode of Comunidades of 1961

Comunidades duly convened does not meet, or when no majority could be achieved on any subject
submitted to its deliberation, the respective powers for its approval, shall be passed to the managing
committee, with the exception to the event referred to in the article 32, in which there is no room for
any relaxations.Section IVManaging Committee[Article 39.] [Article 39 has been amended by Goa
Act No. 3 of 1998 dated 17/01/1998. (See Appendix)]- The affairs of each Comunidades shall be
managed by an managing committee chosen every three years in the manner prescribed in this
Code.Article 40.The managing committee is comprised of three members: president and two
members, one of whom shall be the attorney and the other the treasurer.[Article 41. [Article 41
inserted by Goa Act No. 3 of 1998 dated 17/01/1998.]The board shall be elected by the Comunidade
from amongst the able components, including share holders, preferably those residing in the
village.When the Comunidade is not constituted for election of any of the members of the board, the
same shall be appointed by the Government from amongst the able components, including share
holders, preferably those residing in the village.]
Article 41.The president of the committee and his substitute shall be appointed by the
Governor-General, from amongst the qualified members, preferably resident in the village, but in
duly justified circumstances, persons unrelated to thecomunidadesmay be appointed.The attorney
and his substitute shall be elected by theComunidades, from amongst the qualified members. The
second member and his substitute shall be elected by the twenty major shareholders who are
qualified members.§ 1. When there are not twenty major shareholders in theComunidadesor when
theComunidadescomprises exclusively of members by birth - (zonnkars), the second member may
be appointed by the Governor-General, from amongst the qualified members.§ 2. When
theComunidadesis not duly constituted for the election of the two members of the committee, they
may be appointed by the Governor-General, from among the qualified members, preferably
resident in the village; but in duly justified cases, unrelated persons other than belonging to
theComunidades, may be appointed under the proposal of the administrator.
[Article 42.] [Article 42 has been amended by Goa Act No. 3 of 1998 dated 17/01/1998. (See
Appendix)]- For the purpose of constituting the managing committee, two lists shall be prepared
every three years, by 31st August, by the clerk and the attorney of the Comunidades, based on the
accounts of the last three years and of the registers of members by birth - (zonnkars) and
shareholders, in accordance with the terms of this Code. One of the two lists shall be of all the
qualified members and the other of twenty major shareholders who are qualified members.§ 1. [The
list] [Substituted for the words 'Each of the lists' by Goa Act 3 of 1998, dated 17-1-1998.] shall
contain:a. The serial number;b. Name of the member;c. His status as shareholder or members by
birth - (zonnkar);d. Residence;e. Age, when available;f. Family relationship, if any, up to the 3rd
degree which exists among different members;g. Number of shares held, in case of shareholder or
the social interest that each member by birth - zonnkar has in relation to the share;h. Educational
qualifications of the member.§ 2. When, for the preparation of the list of twenty major shareholders,
there are two or more members with the same social interest and all of them cannot be included in
the same list, then the member who is senior in age shall be included, till the number make up the
total of twenty.§ 3. The documents submitted by the parties for the purposes of clause (h) shall be
returned to them, once the list referred to in the preceding paragraph has been approved.Article
43.After the lists have been publicly displayed for a period of eight days, from the 2nd September
and the copies of the same affixed on the door of the committee meeting's hall and any of theCode of Comunidades of 1961

temples of any religion, existing in the village, an appeal may be filed to the administrator, on a
plain paper, within the same period.Article 44.The administrator shall give his decision, within the
fixed period of five days, without fail, and the said decision shall be made public in the entry book of
the administration office, against which an appeal may be filed, also on plain paper, to the
Administrative Tribunal, within the period of eight days. This appeal shall also be decided within
eight days.§ 1. The appeal is exempted from the payment of cost and stamp fees.§ 2. Once the
decision is given, the secretary of the Administrative Tribunal shall immediately send a copy of the
judgement to the respective administrator of Comunidades, for compliance.Article 45.The clerk of
the Comunidades, after making the rectification, as required by the higher authorities, shall affix
again, in the presence of two witnesses, the rectified lists, by the 15th November, after being
countersigned by the president of the committee, who shall verify, under his responsibility, if the
said decision has been duly complied with.Sole § Two copies of the finalized list of members shall be
forwarded by the clerk to the administration office by the 20th November.Article 46.The clerk who
fails to affix the lists or to forward them to the administrative office, within the prescribed time
limit, shall be penalized by the administrator with the fine of 120 $ to 300 $.[Article 47.] [Article 47
has been amended by Goa Act No. 3 of 1998 dated 17/01/1998. (See Appendix)]The elections of the
members of the managing committee shall be held [on any Sunday in the month of December or
January prior to the three yearly period in which they should start functioning] [Substituted by Goa
Act No. 3 of 1998 dated 17/01/1998.].§ 1. For the purposes of the provisions of this article, the
Comunidades [* * *] [Words Omitted by Goa Act No. 3 of 1998 dated 17/01/1998.] shall be
convened by the administrator, by notices published in the Official Gazette and public notices
affixed on the door of the hall of the committee meeting and of the temples of any religion existing
in the village, in not less than twenty days in advance.§ 2. The fixation of the days of elections,
referred to in the present article and the preceding paragraph shall be set by a single notice for all
the comunidades of the taluka.§ 3. The possibility of holding elections on the same day for two
neighbouring comunidades should be avoided.[Article 48.] [Article 48 has been amended by Goa
Act No. 3 of 1998 dated 17/01/1998. (See Appendix)]The election committee for the attorney and his
substitute and of the treasurer and his substitute, shall be composed of the president of the
committee, the attorney and the clerk and the former shall be the president of the said committee.§
1. All the elections shall be held by open ballot and each list should have one name for the effective
member and another one for his substitute. The voting shall be conducted by the listing of the
electors present personally or by proxy and of the absent electors by declaration of vote.§ 2. The
minutes of the elections shall be recorded by the clerk in the minutes book of the comunidades,
mentioning therein all facts occurred including any protests and declaring at the end, the names of
the members elected. This shall be announced by the president in the light of the votes counted by
the said committee.[Article 49.] [[Article 49 has been amended by Goa Act No. 3 of 1998 dated
17/01/1998. (See Appendix)Article 49 has been amended by Goa Act No. 49 of 2001 dated
04/04/2001. (See Appendix)]]- In the case of any irregularity in the election, any member of the
Comunidades, with voting right, may appeal to the Administrative Tribunal, within five days and the
proceedings of the appeal shall be drawn up on plain paper.Sole § The Administrative Tribunal shall
decide the appeal, within eight days and, if the election is annulled, the Comunidades or the twenty
major shareholders members, shall be convened again, following the formalities prescribed in the
article 47, in order to hold a fresh election in accordance with the decision of the Tribunal.[Article
50.] [Article 50 has been amended by Goa Act No. 3 of 1998 dated 17/01/1998. (See Appendix)]-Code of Comunidades of 1961

Persons who have served as members of the managing committee shall not be appointed or elected
as such, before the expiry of a period of three years, save in exceptional and duly justified
cases.Article 51.In the comunidades where it is not possible to select three qualified members, the
managing committee shall be appointed by the Governor-General, based on the proposal of the
administrator and in the manner he considers most convenient.Article 52.The managing committee
shall assume office within the first three days of the month of March of the first year of their
management and the president shall inform the administrator about the installation and in case,
when there had been any misappropriation of funds in the accounts, whether the same has been
repaid.Sole § The members of the managing committee, appointed or elected, shall continue until
they are legally substituted.Article 53.The managing committee may deliberate, when in addition to
the president or his substitute, one of its members, with right to vote, is present. In event of a tie the
president shall have the casting vote.§ 1. In case of a simultaneous impediment of the president and
his substitute, the oldest effective member shall preside.§ 2. The relatives up to the 3rd degree under
civil law, are barred from acting as committee members.Article 54.The clerk of Comunidades is an
ex-officio member of the managing committee, but he can give only advisory opinion which can be
recorded in the minutes of the proceedings.Article 55.The managing committee shall hold twelve
ordinary meetings in a year, - the first shall be in the first three days of March and the others on the
first Sundays of the months of April to February.§ 1. The first meeting of the year is meant for
dealing expeditiously with the affairs of the month and for the scrutiny of the accounts of the
management of the previous year, giving its opinion on the same, checking the balance in the safe
and handing it over to the new committee.§ 2. When so requested by the respective committee, in
special cases, or when the clerk of the Comunidades is common to more than one Comunidades, the
administrator may designate any other day for the ordinary meetings. In this case the clerk of the
comunidades shall publish this change in the Official Gazette or in any other periodical of the taluka,
if any, and by way of notices affixed, at least ten days in advance, in places indicated in article 43.§ 3.
The meetings shall be open to public, and held in the building meant for that purpose, unless the
committee may have to conduct any inspection in the properties of the comunidades and shall start
at 9.30 hours, except when other time may have been fixed by the administrator, for reasons
mentioned in the preceding paragraph. In that case the comunidades clerk shall make public the
time fixed, by means of notices published in any newspaper of the taluka and affixed in places
indicated in article 43, with an anticipation of ten days.Article 56.The president of the committee
corresponds officially with authorities and government departments of the taluka.[Article 57.]
[Article 57 has been amended by Goa Act No. 3 of 1998 dated 17/01/1998. (See Appendix)]In the
comunidades, where the revenue obtained from the average of last three trienniums is less than
30.000 $, the allowance paid for each meeting shall be of 18$ for the president and 9$ to each of the
other members of the committee, with the exception to the clerk of Comunidades. When the
revenues are greater than this amount, the allowance shall be 30$ and 15$, respectively, there being
not more than thirty paid meetings per year, unless in cases of triennial auctions, when the
allowances may be increased to the total of forty-two meetings.§ 1. The president of the committee
or whoever substitutes him, and the attorney and his substitute shall also be entitled to the
allowance due to them when they take part in the meetings of the Comunidades. There shall be not
more than ten paid meetings a year. They shall not be entitled to this allowance when the meetings
of the Comunidades and of the committee are held on the same day.§ 2. When the number of
Comunidades meetings or of the managing committee, exceeds the fixed number, the value of theCode of Comunidades of 1961

allowance corresponding to this total number shall be divided by the number of meetings held.§ 3.
The allowance shall not be paid, just because the non-holding of meetings of the comunidades and
of the committee have been recorded in the respective reports of the meetings of the Comunidades.§
4. In the cases, due to the fault of the clerk of comunidades, the minutes of the meeting has not been
written, the committee members shall be entitled to the remuneration which shall be paid by the
clerk, by order of the administrator.Article 58.The president and the members of the committee
shall be entitled to the travel allowance, regulated in accordance with the provisions laid down in the
annexed table, this right being restricted to the number of meetings fixed in the body of the
preceding article.§ 1. The travel allowance for the president and the attorney shall not be paid in
double when the meetings of the committee and of the comunidades take place on the same day and
in the same village.§ 2. The travel allowance shall be paid from the usual residence of the managing
committee.Article 59.When the meetings are held on the application of the parties, the allowances
and transportation of the members of the committee shall be borne by them.Sole § The requesting
party shall deposit, in advance, the required sum in the hands of the clerk of the Comunidades who
shall issue a receipt to the interested party.Article 60.No remuneration or travel allowance shall be
paid by the Comunidades without order from the administrator.Article 61.In Comunidades where
there is a deficit, neither remuneration nor travel allowance shall be paid.Article 62.The member of
the committee who, for a just cause, is unable to attend a meeting, should intimate the clerk of this
fact so that his substitute could be summoned by giving him directly the required notice.Article
63.The members of the committee who are unable to attend, on valid reason, the meeting or for any
act where their presence is mandatory, should intimate the clerk so that their substitute should be
summoned or given the required notice, shall pay each time, the fine of 60$, which shall be imposed
by the administrator, after the hearing of the absentee, to whom the clerk shall mandatory furnish
information of such absences, failing which the clerk shall be liable to the same penalty.[Article 64.]
[Article 64 has been amended by Goa Act No. 13 of 1998 dated 25/05/1998. (See Appendix)]- The
managing committee shall have the powers to:
1. Lease out property and hold any auction of the properties of the
Comunidades;
2. Certify the fitness from the bidders of the lands, services and works, as
well as all other sureties of others, its committee members being answerable
severally in case of insolvency;
3. Take steps in cases of breach of the bunds of [casanas] [For definition
refer to foot note of 30], flooding of fields, loss of stored water due to the
breach of bunds and of the dike of ponds, risk of collapse of the
comunidades building and other similar cases, arrange immediately for
urgent repairs and those which are, at that particular time, indispensable,
conducting an inspection and assessment of losses suffered, with the help
of an expert, if possible. Carry out auction, immediately thereafter, preceded
by cries in the village, by giving in writing to the crier the requiredCode of Comunidades of 1961

information and keeping immediately the administrator informed of the facts
and measures taken by the managing committee.
In the absence of bidders, the managing committee shall execute the work by direct administration
(on daily wages basis or job contract) provided that in no case the expenditure exceeds the amount
of the estimate, in which case it will be the responsibility of the administration of the comunidades
to proceed with inspection within the period of five days of completion of work for the purposes of
their taking over.
4. Invest, with the sanction of the administrator, the capital of the
Comunidades, not reserved for dividends.
a. In the purchase of shares of the very same Comunidades, however the same purchase is
prohibited in comunidades which do not have members by birth - zonnkars.b. In the loan bearing
interest not less than 4% on pawning shares of the comunidades, however when the borrower is the
member of the Comunidades the interest shall be 3%;[c. In deposits in such manner as the
Government may prescribe.] [Substituted by Act No. 13 of 1988.]
5. Lend at the rate of 4 per cent interest, when there is money available in the
safe, against pledge of gold and silver or shares of the comunidades, to the
tenants of the paddy fields of the Comunidades, an amount not exceeding
the rent and other contributions of the tenanted field and never for the period
beyond six months;
6. Lend in the same way an amount not exceeding 6000$ when there is
money available, to any other Comunidades of the respective taluka , duly
sanctioned by the respective administrator, at the same rate of interest and
for a period not more than one year. Higher amount and for the period more
than one year, can also be lent, but with the approval of the
Governor-General.
The loans shall be given by recording the same in the book of sundry declarations and reports and
the acquiring comunidades shall be represented by competent attorney with special powers, to that
effect conferred by the board with the observance of all legal formalities;
7. Take over the works of the embankments, its paving, closure of breaches
and other similar works which form part of the ordinary plan of the
comunidades, informing the administrator of the results, within forty-eight
hours and affixing copies of the same on the door of the meeting place.Code of Comunidades of 1961

The bidders, however can request the intervention of an expert of their choice, but in this case there
will be three experts, being the other two appointed, one by the attorney of the comunidade and the
other by the administrator. The expenditure shall be borne by the respective bidder;
8. Take over all the urgent and extraordinary works value of which does not
exceed 1500$, in the manner indicated in the preceding number, except for
the provisions in the second part of clause No. 3;
9. Deliberate on :
(a)Formation of the core group of agricultural labourers, by granting lands and other advantages,
and on financial aid to the of People's House (Casas do Povo);(b)Setting up reserve funds and using
these and other capital in the works to improve and encourage agriculture, acquisition of improved
machines and latest tools, institution and improvement of agriculture related industries connected
with agriculture, in the creation of agricultural and livestock insurance schemes, establishment of
welfare institutions and social help to its Comunidades members and to the agricultural population
of the respective village.The deliberations of the managing committee, in the matters referred to in
the items of this clause, shall be implemented only after they are approved by members representing
at least, one-third of the share capital, and sanctioned by the Governor-General, after consulting the
Government Council;
10. Authorize the payment to the contractors of the ordinary services after
taking delivery referred to in the preceding clause, and the payment shall not
be made before fifteen days from the date of taking over.
In case of complaint against the execution of these services, the administrator shall immediately
order the suspension of the payment and shall directly and obligatorily inspect the work. The
expenses of this inspection shall be borne by the complainant, when it is proved that the complaint
was baseless, to which the respective administration office shall obtain an adequate declaration of
responsibility from the complainant;
11. Perform all the necessary steps required for the administrative and
financial management of the comunidade.
[Article 65.] [Article 65 has been amended by Goa Act No. 3 of 1998 dated 17/01/1998. (See
Appendix)]The expenses incurred or already paid, to meet the cases foreseen in clause 3 of
preceding article, require the approval of the Governor-General, with prior hearing of the twenty
major shareholders of the Comunidades, when such an expenditure exceeds the amount of 3000$
for each work and the sanction of the administrator, when it is of lesser amount.§ 1. For this
purpose, the clerk shall send the statement of expenditure incurred, duly countersigned by the
president of the committee, with the opinion of the twenty major shareholders of the Comunidades,
if necessary, to the administrator, who shall send the same, with his own remarks to the DirectorateCode of Comunidades of 1961

of Civil Administration, or else shall approve himself the same, if it is within his competence, in
terms of the body of the article.§ 2. When the amount of the expenses exceed 3000$, or when the
administrator thinks it necessary, he shall proceed to inspect the works, along with the technical
expert of the Comunidades, before the report is prepared or sanction is accorded or whilst the works
are in progress.§ 3. The Governor-General shall make the committee responsible, after giving prior
hearing to it, for any excess committed in the exercise of its powers provided for it in clause 3 of the
preceding article.Article 66.The committee shall express its opinion in all the deliberations that the
Comunidades adopts on the matters of its competence.Article 67.The members of the committee
and its substitutes are expressly prohibited to bid or to stand surety in auctions, directly or through
dummy party.Sole § By dummy party means: the spouse of the interdict person, the individual who
may be presumed hair, the nearest relative with whom he may live in common domestic economy
and any third person who, in collusion with the interdict member, bids or subsequently transfer to
him the thing auctioned.Article 68.The members of the committee who violate the provisions of the
preceding article shall be liable to pay a fine from 300 $ to 3000 $, which shall be imposed by the
administrator, following an enquiry and cannot be reappointed to the post or be re-elected during
the period of three to nine years, as set also by the administrator, depending on the seriousness of
the case.Article 69.The members of the managing committee, appointed or elected, cannot decline
the post, except if they have obtained the exemption from the Governor-General and are liable for
payment of a fine of 300$, imposed by the administrator, in case they fail to obtain the said
exemption and cannot be appointed or re-elected during the period of nine years.§ 1. When any of
the elected members do not take charge of the office, with or without obtaining the respective
exemption, the Governor-General shall appoint one who will substitute him till the end of the
triennium.§ 2. The following shall be grounds for the grant of exemption:-
1. Age more than 67 years;
2. Suffering from diseases that prevents him from discharging the respective
functions;
3. Residing beyond 5 kms. from the head office of the comunidades;
4. Holding a public office;
5. Any other ground that the Governor-General deems fit;
Article 70.When the committee fails to meet for two consecutive times, on the days fixed for the
meetings, it is the duty of the administrator by his order, to adopt the resolution that would have
been taken and may propose the dissolution of the elected part of the same committee, in case he
deems fit.§ 1. The elected part of the committee may only be dissolved by the Governor-General after
conducting an inquiry in which it is proved that its performance was against the interests of the
comunidades. In this inquiry the defendants must be given a hearing.§ 2. In the cases of dissolution,
referred to in this article and preceding paragraph the Governor-General shall appoint, till the end
of the triennium, persons who shall substitute the members affected by the dissolution.§ 3. TheCode of Comunidades of 1961

members of the managing committee affected by the dissolution shall not be reelected before
completing nine years from the dissolution and shall pay the fine of 300$.Article 71.The president
has the right to appeal to the administrator against the deliberations of the managing committee
which are enforceable without sanction of the higher authority and the administrator may order the
immediate suspension of execution of the deliberations and take steps that think fit, to avoid any
loss to the Comunidades, by deciding the matter of the appeal within forty-eight hours.Article
72.The president is specially empowered to:
1. Conduct the works of the meetings of the managing committee and of the
Comunidades;
2. Maintain order in the meetings hall, ordering the expulsion of any persons
who disturb the same;
3. Bring to the notice of the administrator of any irregularities which he
notices in the comunidades services;
4. Order the seizure of produce taken away by the leaseholders of the fields
without prior payment of the rent;
5. Request the assistance of the authorities and the public force whenever
necessary for protection of the rights of the Comunidades and maintenance
of order in the comunidades and committee meetings;
6. Exercise other rights and fulfill all the obligations imposed on him by this
Code;
7. Submit to the administrator, every year, till 31st January, a report of all
important facts occurred during the preceding year;
8. Inspect the services of the office of the clerk of the Comunidades and the
compliance by the said clerk of his duties and obligations informing
immediately the administrator of any irregularities observed;
§ 1. For failure to comply with the provisions prescribed in clauses 7 and 8, the president shall be
liable to pay a fine of 300$ to 600$, imposed by the respective administrator.§ 2. Against the acts
exercised by the president of the managing committee an appeal lies to the administrator and
against decision of the latter appeals, as provided in this Code, may be filed depending on the nature
of the matter.Section VAttorneysArticle 73.In each Comunidades there shall be one attorney
effective and one substitute attorney, elected for a three years term, in accordance with article 41, or
appointed by the Governor-General, as laid down in paragraph 2 of the same article.Article 74.TheCode of Comunidades of 1961

attorney, who has been found to be harmful to the interests of the Comunidades, shall be suspended
by the administrator and dismissed by the Governor-General, upon the report or proposal of the
administrator and hearing of the interested party.Article 75.The attorney of the Comunidades shall
be its representative and its controller who shall have the following powers:-
2. Represent the Comunidades before any courts and offices or public
authorities;
3. Bring to the notice of the authorities or the Comunidades the irregularities
on the part of employees and agents and the encroachment of land. He may
even challenge the encroachment in terms of articles 486 and 2354 of the
Civil Code;
4. Attend the comunidades meetings and take part in its deliberations and in
the works of enrolment and registration of the zonnkars, in the closing of the
enrolment of shareholders, in the auctions and charges, in the preparation of
the statement of income and expenditure and the list of qualified members
and of the estimate, in final accounts of comunidades and in all inspections
made by the managing committee or by the administrator of the fields,
services and extraordinary works;
5. Supervise the ordinary and extraordinary services and extraordinary
works;
6. Submit, within fifteen days, at the administration office or in the registrars
offices -"Conservatorias" the conditions of auctions, security and other
required documents to effect the registration of the pledge of shares or to
register the mortgage, under penalty of being responsible on subsidiary
basis, if he fails to do the same;
7. Appeal against all the deliberations and orders which are against the
interests of the Comunidades and in those cases where the appeal is
compulsory;
8. Take all the steps required for a good administrative and financial
management of the Comunidades.
Article 76.The clerk shall issue to the attorney, as many copies of the minutes of his election, as
asked by him, authenticated with his signature and the embossed seal of the Comunidades.Sole §Code of Comunidades of 1961

The clerk who refuses to issue to the attorney, within three days, the copies referred to in this article,
when its number does not exceed nine, shall be disciplinary punished.Article 77.The Comunidades
may, at any time, by holding a meeting following the formalities prescribed in this Code, dismiss the
elected attorney effective or substitute, when his action is proved to prejudice the interests of the
Comunidades and elect another one in his place.Article 78.The attorney is bound to comply with the
provisions of article 379, within fifteen days, from the date of notice, which shall be accompanied by
the handing over of the papers or documents which shall serve as basis for the suit and such notice
and handing over, should be made by the secretary of the administration office.§ 1. Within ten days
from the filing of the suit, the attorney shall place before the administrator the certificate of having
filed the same, failing which he is liable to pay a fine of 180$, imposed by the same administrator.§
2. The administrator who fails to impose the penalty referred to in the last part of preceding
paragraph shall incur the penalty of suspension for fifteen days.Article 79.The special attorney
authorized to take part in a suit representing the Comunidades, shall follow the same till the end,
even after expiry of the term for which he was appointed, unless the Comunidades expressly
withdraws the powers conferred.Sole § If the suit is filed by the regular attorney, the lawyer
appointed by him shall follow the suit, even if the attorney ceases to exercise his functions and until
such advocate is legally substituted.Article 80.If, after filing the suit, the attorney allows it to remain
pending for more than three months, the administrator of the comunidades, after first hearing the
said attorney and granting a period of three days for his defence, shall, by an order, impose the fine
of 150 $ to 900 $, besides barring him from holding any post in the Comunidades for a period of
three to nine years with all civil consequences.Article 81.The attorney is bound to appeal against all
the final judgements and orders which put an end to the suit, when they are not favourable to the
Comunidades.Article 82.The attorney who recovers the active debts of the Comunidades, through
administrative or judicial means, after effecting the attachment, shall be entitled to 3 percent of the
capital collected, paid by the debtors, and when the collection is done prior to the attachment, but
after ten days have passed since the summons for execution were served, he will have right to 1 per
cent, also paid by the debtors.Article 83.The attorney can officially enter in correspondence with the
administrator, president of the managing committee and the clerk of the comunidades in all matters
of the interest of the Comunidades.Section VIClerks of the comunidadesArticle 84.Each
Comunidades or group of comunidades shall have one clerk -escrivão - of 1st, 2nd and 3rd class, as
per the Map - 2-II annexed.§ 1. The offices of the 1st class clerks of the comunidades of Carambolim,
Chorão-Caraim-Passo de Ambarim, Calapur-Cujira, Jua, Serula, Margão and Curtorim shall have
one assistant clerk with the category of 3rd class clerk.§ 2. The Governor-General shall create posts
of assistant clerks in the clerks office of the Comunidades where the need of services so
justify.Article 85.The clerk (escrivão) shall furnish a security, before the administrator of 12.000$,
6.000$ and 3.000$, according to whether they are of 1st , 2nd or 3rd class comunidades,
respectively, of immovable properties situated in this State, shares of the comunidades, pledge or
cash, and based only on this document proving the said pledge, the Directorate of Civil
Administration Services shall issue the necessary orders for taking charge of the office.Sole § In the
case of transfer of the former from one Comunidades to another, the security furnished in the
former Comunidades shall be considered as valid and subsist for the second, on a declaration to that
effect, without prejudice to the liabilities which the clerk might have incurred at the same,
reinforcement of the security being required, if necessary.Article 86.The clerks, who fail to recover
the accounts of the debtors of the comunidades and the final accounts of the year, within the timeCode of Comunidades of 1961

limits prescribed in this Code, shall be liable to pay a fine equivalent to one-third of their annual
pay, which shall be imposed by the administrator, besides being jointly responsible with the debtors
for the amounts outstanding, without prejudice to the disciplinary action.Article 87.The clerks are
subject to the general disciplinary rules for the [public servants] [See Statute of Overseas Civil
Service.], enjoying rights and duties of the same, without prejudice to the provisions of this
Code.Sole § The clerks are forbidden to intervene, as expert witnesses, in comunidades proceedings,
save in cases in which such intervention is required by this Code or derived from the nature of duties
they perform.[Article 88.] [Article 88 has been amended by Goa Act No. 3 of 1998 dated
17/01/1998. (See Appendix).]- The clerks of comunidades - shall, in particular, be bound to:-(a)Keep
the book and accounts;(b)Keep custody and maintain the archives, which they can do at their own
residence, with permission of the administrator when the Comunidades does not have its own
building, for that purpose;(c)Effect the service of summons and notices in the area of the respective
Comunidades;(d)Provide information which the administrator may require, within the period of five
days and the necessary clarifications that may have been requested by any member;(e)Submit
accounts, presenting himself for this purpose in the administration office, in terms provided in this
Code, being civilly responsible for the same;(f)Effect the service to the attorney to initiate the filing
of suits and execution proceedings, by handing over, at the time of service of notice, the necessary
documents;(g)Effect the service, within three days, to the attorney of the Comunidades, of the
notifications, orders and instructions that may have been received from the higher authorities,
issuing copies thereof, when demanded;(h)Perform all other duties that is bound to fulfill as per the
provisions of this Code or others which may be imposed.§ 1. The duties referred to in clause (a) may
be carried out by the assistants, selected by the clerk and under his own sole responsibility;§ 2. The
clerk's assistant shall assist him in the work of maintaining the records, accounts and maintenance
of archives, as well as in serving notices, when entrusted by the same clerk.Article 89.The clerk of
the comunidades and their substitutes shall have their residence obligatory at the seat of the
Comunidades they serve and shall follow the working hours of the government offices, in which they
shall be supervised by the presidents of the managing committee and administrators of the
comunidades.§ 1. In the comunidades, which are grouped together, the clerk shall follow the
working hours in all the comunidades which form the group, on the day or days that may be
established by the Director of Civil Administration Services, on the basis of recommendation from
the administrator and published in the Official Gazette.§ 2. The weekly rest day for the clerk of the
comunidades and their substitutes shall be determined, in accordance with the needs of service, by
order of the Governor-General.Article 90.The clerks shall correspond officially with the members of
the committee and with the administrator.Article 91.The clerks shall have full faith and credit in the
acts performed within their powers, but the certificates issued by them shall be deemed
authenticated when they carry the embossed seal of the Comunidades.Article 92.In the
comunidades, without clerk's assistants, the clerks shall be substituted, during their absence or
impediment, by a reliable person of their responsibility, proposed by them and appointed by the
administrator.Sole § A substitute appointed, in this manner, shall jointly be responsible with the
clerk and, in cases of substitution due to sick leave, bereavement leave or sickness proven by a
medical certificate, in accordance with the law, the substitute shall be entitled to a remuneration
corresponding to two-third or half of the salary of the clerk substituted, paid by the Comunidades,
depending on whether the substitute is an unrelated person or a clerk of any other
Comunidades.Article 93.In comunidades where there are clerk's assistants, these assistants shallCode of Comunidades of 1961

substitute the clerk during his absence and impediment. The assistant will be entitled to a
remuneration corresponding to one third of the salary of the substituted clerk, which shall be the
latter's liability, in the cases not provided for in the sole paragraph of the preceding article.Sole §
The provisions of the preceding article and its sole paragraph shall be applicable to the absence and
impediment of clerk's assistants.Article 94.The clerks of Comunidades belong to a general cadre and
shall be appointed, promoted and transferred by the Governor-General, under the terms prescribed
in the present Code.Sole § The appointment of the clerks of comunidades in the talukas of Quepem
andPernem and their respective salary shall continue to be regulated by their private
legislation.Article 95.The filling up of vacant posts of 3rd class clerks shall be done by a competitive
practical examinations, held every two years, or earlier, if justified by the needs of the service, at the
Directorate of Civil Administration Services, and the minimum qualification required should be the
"20 Ciclo" of Lyceum.§ 1. The examinations which will have the duration of three consecutive hours
will cover the following program:(a)Drafting of a note, report or resolution on a given
subject;(b)Knowledge of the Code of Comunidades and about the duties and rights, discipline and
workings of services, the Overseas Civil Service Statute;(c)Arithmetic and book keeping of the
comunidades;(d)Typing.§ 2. The board of examiners shall comprise of two members appointed by
the Governor-General, from amongst the heads of offices of the Directorate of Civil Administration
Services and the administrators of the comunidades of Goa, Bardez and Salsete, chaired by the
Director of Services and one of the heads of section of the 2nd Division being designated as
secretary.Article 96.The posts of clerks of 2nd and 1st class shall be filled by competitive promotion
procedure and practical test among the clerks of 3rd and 2nd class and auxiliaries of 3rd and 2nd
class, respectively, having the minimum of three years' service in their class with good reports.§ 1.
The competitive procedure referred to in this article shall be held every two years, or earlier, if the
exigencies of service so require, at the Directorate of Civil Administration Services and that consist
of:Written test of the duration of 3 hours:(a)Drafting of a note, official letter, report or resolution on
a given matter subject;(b)Knowledge of the Code of comunidades, and with reference to duties and
rights, discipline and functioning of services, of the Overseas Civil Services Statutes;(c)Arithmetic
and book keeping of the comunidades;Oral test of the duration of 15 minutes:Oral examination on
the matters of the clauses (b) and (c).§ 2. The provisions of paragraph 2 of previous article shall be
applicable to these examinations.Article 97.The clerks of the comunidades can be transferred to the
offices of other comunidades of the same category, when they so apply, within the period fixed for
this purpose in the notice published in the Official Gazette by the Directorate of Civil Administration
Services and the following shall be the preferential factors for the graduation:
1. Greater length of service in the place they occupy, without penalty
recorded in the respective personal file;
2. Greater length of service in the comunidades.
Sole § Clerks, with more than six years in the same position, shall obligatorily be transferred and
shall not return to the same position until a further equal period had passed.Article 98.When any
post of clerk (escrivão) is vacant and until the Government makes arrangements to fill the same, the
administrator shall make temporary arrangement for the performance of the respective functions in
terms of general law. If however the clerk of another Comunidades performs the duties, in additionCode of Comunidades of 1961

to his own duties, he shall be paid 50 percent of the pay of the post accumulated, besides his own
pay.Section VIITreasurerArticle 99.In each Comunidades, the member of the managing committee,
who is not the attorney, shall serve as treasurer.Article 100.The treasurer shall have the followings
powers to:-
1. Collect and deposit- in the safe, in accordance with article 105 all the
income of the Comunidades as well as the sum of all charges levied as per
the provisions of this Code and in terms of the estimates prepared by of the
comunidades or the orders of a higher authority;
2. Pay to the administration of comunidades, every month and in the first
three days of the month, the respective shares in the ordinary and
extraordinary [derrama] [Derrama - Compulsory financial contribution from
the net revenue to make up the deficit in the budget of the administration
office of comunidades.], to the National Treasury, at the appropriate time,
property tax and other taxes due; and to zonnkars, shareholders, consignees
and other creditors of the Comunidades, each year or at the proper seasons
of the year, as per the provisions of this code or in the respective contracts,
or on the orders of a higher authority, the profits, dividends, interest, salaries
or other payments;
3. Pay, by postal order, whenever possible, and in the proper season of the
year, the proceeds, dividends, pensions, consignments or any credits due to
religious and charitable institutions, deducting the cost of the postal order
from the respective amount;
4. Present to the administrator, to be countersigned by him and to the
respective clerk, in order to be recorded in the comunidades book, the bills
of the payments made to the National Treasury, within three days of the due
dates, mentioned in the preceding number failing which he shall be
punished, for the first offence, with a fine ranging from 300$ to 600$, and for
the second time with suspension from duties. Such penalties shall be
imposed by the administrator, after giving due hearing to the person
concerned.
Article 101.The treasurer, who withdraws cash from the safe of the comunidades and does not put it
to the intended use, within the legal time, shall be subject to imprisonment and shall be punished
for the crime foreseen in article 313 of the Penal Code.Section VIIISafe and the key-holdersArticle
102.In each Comunidades there shall be an iron safe with three keys, wherein all the revenueCode of Comunidades of 1961

amount, valuables and titles belonging to the comunidades shall be kept.Sole § The safe shall be
kept in the comunidades building or in any other place, offering the necessary conditions of security;
in special cases and with express authorization of the Governor-General, it may be kept in the
building of the administration office or other building situated in the seat of the taluka.Article
103.The key-holders of the safe are the president of the committee, the treasurer and the clerk of
Comunidades, who are all jointly responsible for any misappropriation.Article 104.Each of the
key-holders has one key of the safe which shall not be opened without the presence of all.Article
105.It is the duty of the key-holders to place in the safe all the income of the comunidades and make
payments authorized by law or by order of the higher authorities, and when any of these acts are not
performed due to the fault of any of them, on the days designated for this purpose, the person
responsible will be liable to pay a fine of 60 $ for each occasion, by order of administrator who can
increase it up to five times the said amount, according to the seriousness and consequences of the
omission.§ 1. The key-holders, who make payments, not authorized by law or by order of higher
authorities, shall be jointly and severally responsible before the Comunidades for the amount of
such payments.§ 2. When any of the key-holder has any doubt about the legality of any payment to
be made, he shall suspend the payment and inform the administrator about the doubt, who shall
clarify the matter within three days.Article 106.For the purpose of collection of income and payment
of expenses, in addition to the days mentioned in article 489, the key-holders shall be present on all
the last Sundays of each of the months and on all the Sundays of the months of March to May and
September to December, or on all the Sundays, covered by the period designated for the collection of
the respective assessment, from 9.30 to 12.30 hrs., in the Comunidades hall when the safes are in
the respective village, and from 9.30 to 12.30 hours of the following day in the places where the safes
are installed in the building of the administration office or other building situated in the seat of the
taluka.Article 107.In the event of an extraordinary opening of the safe, the president and the
treasurer shall be entitled to the allowances, designated in the table No. 3, when such openings are
made at the request of the party.Article 108.Besides the allowance that the president and the
treasurer, receive for attending the meetings of the committee, they are entitled to an annual
allowance, authorized by the administrator, corresponding to 2% of the income collected in order to
deposit in the safe, out of which one-third shall be to the president and two-thirds for the treasurer,
total of which shall not exceed 3000$.Sole § In the Comunidades with deficit, no payment of
percentages referred in this article shall be effected.Article 109.In the safes of the Comunidades
having 3rd , 2nd and 1st class clerks, amounts exceeding 3.000$, 4.000$ and 6.000$ respectively,
should not be kept.Article 110.Sums, exceeding the limit fixed in the preceding article, shall be
deposited by the treasurer in the Bank, known as [Cooperative Bank or where such Bank is not in
operation, in the Post Office Savings Bank as the case may be] [Substituted for the words 'Caixa
Economica de Goa' by Goa Act 3 of 1998, dated 17-1-1998.], in the name of the respective
Comunidades, in keeping with the following rules:
1. The sum to be deposited shall be handed over to the treasurer, based on
items entered in the Cash Book;Code of Comunidades of 1961

2. Cash shall not be given to the treasurer for the second deposit, unless the
provisional receipt of the first deposit is presented and entered in the safe;
3. The treasurer must hand over the provisional receipt in office of the clerk
of the Comunidades, within three days from taking the cash and if he fails to
do so, the current account shall immediately be sent by the respective clerk
to the administrator for the legal purposes;
4. The withdrawal of deposits shall be effected by a repayment voucher
signed by all the key-holders and countersigned by the administrator.
Article 111.The administration office of the Comunidades shall notify to the management of the said
bank - [Cooperative Bank or where such Bank is not in operation, in the Post Office Savings Bank as
the case may be] [Substituted for the words 'Caixa Economica de Goa' by Goa Act 3 of 1998, dated
17-1-1998.], of the names of the key-holders of the safe of each of the Comunidades, with their
specimen signatures, duly authenticated by the secretaries of the administration offices, in order to
be compared at the time of reimbursements. Such intimation should be renewed as and when there
are changes of the key-holders.Article 112.Every three months and, possibly during the months of
January, April, July, and October, the Comunidades shall send their Pass Books to the head office of
the said Bank Caixa Economica de Goa to be checked.Article 113.The orders for reimbursements,
even in the case of endorsements, shall be sent free of charge and exempted of stamp duty.Article
114.During the ordinary period set for the payment of prevents of zonn and dividends, the
key-holders shall calculate the amount necessary to effect these payments, based on the average
paid in the same period over last three years, and make that amount available in the safe by
withdrawing in advance from the Bank [Cooperative Bank or where such Bank is not in operation, in
the Post Office Savings Bank as the case may be] [Substituted for the words 'Caixa Economica de
Goa' by Goa Act 3 of 1998, dated 17-1-1998.], but never in anticipation of more than eight
days.Article 115.In the balance sheets referred to in the article 466, the balances in cash and deposit
in the said Bank [Cooperative Bank or where such Bank is not in operation, in the Post Office
Savings Bank as the case may be] [Substituted for the words 'Caixa Economica de Goa' by Goa Act 3
of 1998, dated 17-1-1998.] shall be distinguished, in separate items.Sole § One copy of the balance
sheets of the movement of the receipt and expenditure of each Comunidades shall obligatorily, be
affixed by the clerk on the door of the meeting hall.
Chapter III
Administration of the comunidades
Section IGeneral provisionsArticle 116.In each of the talukas of Goa, Salsete and Bardez, there shall
be one independent office of administration of Comunidades and in other talukas, excepting for that
of Satari, the interests of the Comunidades shall be entrusted to the respective taluka
administration.Sole § For the purposes of the provisions of this article, the Comunidades of Satari
taluka are included under the administration of the taluka of Bicholim.Article 117.TheCode of Comunidades of 1961

administration offices of the Comunidades are considered for all purposes as public offices[[] [See
Overseas Civil Services Statutes (EFU).].Section IIAdministrators
118. [] [Article 118 has been amended by Goa Act No. 3 of 1998 dated
17/01/1998. (See Appendix).]
In each of the administration offices of the Comunidades of Goa, Salsete and Bardez, the respective
administrator shall be appointed by the Governor General, on service commission, from amongst
persons of recognized competence, conversant in the study of public affairs, mainly Comunidades
affairs and possessing the minimum qualification of the 3rd cycle of Lyceum.Sole § The
administrators of Comunidades may be transferred for convenience of service.Article 119.The
independent administrators of the Comunidades are administrative magistrates and shall take an
oath of office before the Governor General.Article 120.The independent administrators of
Comunidades shall obligatorily be resident in the seat of the respective taluka, and cannot absent
themselves from there without being authorized by the Governor General.Article 121.The
independent administrators of the Comunidades shall be substituted, in their absence and
impediments, by the secretary of the respective administration and in the event of his absence and
impediment by the taluka administrator.Article 122.The provisions of article 67 and its sole
paragraph are applicable to the administrators of Comunidades and their legal substitutes, in
service.Article 123.The administrator shall correspond officially with the functionaries, authorities
and public offices and shall issue orders to his subordinates.Article 124.Application for recusal may
be moved before the administrator on ground of bias in manner provided in the civil procedural
law.Article 125.The administrator of Comunidades has powers to:-
1. Enforce and get the enforcement done of the provisions of this Code, the
contracts entered with the Comunidades and all the resolutions and
decisions of the higher authorities;
2. Maintain order and discipline in service of the offices of the Comunidades
under his supervision;
3. Order the preparation, in October of each year, of the budget of income
and expenditure of the administration, dividing the contributions between the
Comunidades, proportionally to the amount of its revenue in such year and
submit it for the approval of the Government;
In the taluka of Bicholim, the amount from the derrama of [dessaidos] ['Dessaidos' Under the
Provincial Decree No.144 dated 22-10-1896 special concession was given to certain families of Sar
Dessai.] shall be included in the budget;Code of Comunidades of 1961

4. Enforce the collection of supplementary derrama when there are
extraordinary expenses, duly authorized;
5. Inform the Comunidades and the parties concerned, by 15th December, of
the share of derrama which they are required to pay, and at appropriate time,
the share in an extraordinary derrama. The recovery of the respective
instalments, either by voluntarily payment or by coercive matter, shall be
done by the provisions in this Code;
6. Write the opening and closing declarations and initial the books referred to
in articles 440 and 445 or in respect of the Comunidades books or to
authorize the secretary or the administrative assistants of the administration
office, to do this work;
7. Preside over the visits, inspections and auctions as well as handing over
and giving possession of land;
8. Inspect the books and accounts of the Comunidades, check whether the
Comunidades clerks are following their duties and obligations mainly those
relating to working hours and residence at the seat, and take action, in
accordance with this Code, against those violating those obligations;
9. Approve the annual income and expenditure sheets of the Comunidades
and the calculations and terms of ordinary auctions;
10. To inspect the archives and check the balance of the safe, when he finds
it convenient or when requested, denouncing the deviation of books or cash
from the safe;
11. Exercise the powers of the managing committee in the cases and under
such terms set out in article 70;
12. Attend, whenever he finds it convenient, the meetings of the
Comunidades and those of the managing committees;
13. Propose the appointment and dismissal of the president of the managing
committee, the dissolution of the elected part of the same, in terms set forth
in this Code, and the appointment of persons who should function asCode of Comunidades of 1961

members of the committee, in cases provided for in the § 2 of articles 41 and
51 and § 1 of article 69;
14. Take oath of office of the staff members under him, as well as of
members of the managing committee and other agents of the Comunidades.
He may however delegate these functions to the president of the committee,
who had already taken the oath of office;
15. Authorize the payment of percentages referred to in article 108 of this
Code;
16. Propose to the Government the meetings of the Comunidades to be held
at seat of the taluka or in the building of the administration office and order
the meetings of the board in these places;
17. Authorize the extraordinary meetings of the Comunidades and of the
committee, when they are not convened by their president;
18. Exercise disciplinary power in terms of law and impose the penalties
established in No. 1 to 3 of article 354 of the Overseas Civil Services Statutes
(E.F.U.);
19. Decide the applications for registration or listing;
20. Take steps to fill temporarily the post of clerk;
21. Take notice and decide all the applications, complaints and appeals
instituted against the acts that are not within the competence of higher
authorities and offer his say on all the cases which have to be sent for a
decision of the Governor General or the Administrative Tribunal;
22. Proceed in accordance with article 371 and the following, regarding
encroachment on the lands of the Comunidades;
23. Authorize the Comunidades to file suits under the terms of the article 9 as
well as authorize the necessary expenses;Code of Comunidades of 1961

24. Authorize every year, occasional or unforeseen expenses, which are not
for any other purpose unconnected to the Comunidades, up to 1.500 $ and
the advance of amounts essential for covering the ordinary and extraordinary
expenses, duly authorized, when they are not foreseen in the respective
assignment or contract as well as the expenses necessary to defend the
suits filed against the Comunidades;
25. Withhold or order the retention of proceeds of zonns dividends or any
other credits that the debtors may have in the Comunidades until the latter
have paid their dues and accessory amounts, when these dues have not
been guaranteed for;
26. Arrange for the coercive collection, in accordance with the terms of Title
V, of the Comunidades dues, acting as judge in the respective proceedings;
27. Distribute the cases for recovery of debts, referred to in the preceding
number, among the enforcement clerks, equally and by lots, in three classes,
according to the value referred to in § 1 of article 627;
28. Decide by 31st of October of the following year, the yearly accounts of
the persons responsible to the Comunidades, forwarding by the 15th
November, the respective statement to the Administrative Tribunal. Failure to
comply with would incur payment of fine corresponding to 5% of the ordinary
fees collected;
29. Forward to the treasury department of the taluka, every month, a note of
the remissions made in the preceding month and a form for the payment of
stamp duty on transfer of shares and for the respective tax corresponding to
the normal emoluments recovered in the preceding month;
30. Take delivery of the extraordinary services and works valued in excess of
3000 $ and of the ordinary works in case of appeal or complaint against the
taking of the delivery by the managing committee;
31. Present to the Governor General, by the 31st of March of every year, a
report of the management of the Comunidades for the preceding year,
mentioning therein the important facts of his administration and indicating
the means, he thinks fit, to adopt in order to increase and improve crops.Code of Comunidades of 1961

This report shall be accompanied by a statistical map of the office's work, a
map showing the movement of the shares of Comunidades, organized
according to model No. 5, a map showing the dividends and zonns
distributed by each Comunidades, in each of the last nine years, a statement
indicating the grants as emphyteusis (aforamentos) granted and a map
showing the extraordinary expenses incurred by each Comunidades in the
preceding year and other information as he sees fit deemed useful. Failure to
comply with would incur in payment of a fine corresponding to the salary for
the number of days delay.
Article 126.The decisions of the administrator are subject to appeals provided by law.Section
IIIOffice of secretary and personnelArticle 127.Each of the private administrations of the
Comunidades shall have a secretarial office controlled by the respective secretary and a works
foreman in charge of a technical person for works.The offices of the talukas administrators shall
have a Comunidades section under the control of the secretary of those administrations.The
strength of the staff shall be as shown in attached map No. 2-I forming a single cadre.Sole § The
provisions contained in the article 67 and its sole paragraph and sole paragraph of article 87 and 97,
the later to some extent, shall be applicable to the personnel of the administrations.Article 128.The
secretary is empowered to:-
1. Maintain order in secretariat office, distribute and regularise the service
among the employees, when not defined by the administrator or by this
Code.
2. Perform the office work of administration, keep books and maintain the
registers, check the income and expenses statements, calculations, auctions
and accounts and carry out all other duties assigned by this Code and by
order of higher authorities.
3. Draft the correspondence in accordance with the decision of the
administrator.
4. Mark in all the outwards correspondence with the respective sequential
number after being signed by the administrator. Provide clarifications for the
purposes of the pledge and attachment of.
5. Offer classifications for the purpose of attachment and seizure of shares.Code of Comunidades of 1961

6. Have under his control the office archive and keep it in order.
7. Issue summons and notifications in the suit itself when ordered by
dispatch.
Article 129.The auxiliaries shall:-
1. Assist the secretary in the exercise of his duties performing all acts as
ordered by the administrator or the secretary;
2. Write and type notes, official letters and other documents as per the drafts
given to them;
Sole § In the private administrative offices of the Comunidades, the senior most 1st class assistant
shall substitute the secretary in his absence or impediment.Article 130.The bailiff shall serve
summons and notices and deliver the correspondence.Article 131.The peons are responsible for the
cleanliness of the office and for any other service determined by higher authorities.Article 132.The
administration of Comunidades shall have an iron safe, with three keys, where the income from
derramas and of the in default Comunidades in their charge, as well as the income of Pension Bank,
should be deposited in accordance with this Code.§ 1. The key-holders of this safe are the
administrator, the secretary and the more qualified and senior most auxiliary. They are jointly and
severally responsible for any embezzlement if taken place.§ 2. In the same safe there shall also be
deposited, but kept separately, the amount of advance fees paid by the parties in connection with the
cases pertaining to the administration.The entry of such amounts should be recorded in a special
cash book maintained on the same lines as that of the safe of the administration.Article 133.The
general archive of the past books of the Comunidades will be in charge of the administration.Sole §
Every year, all the Comunidades books, closed files and useful papers which are ten years old, shall
be sent to the general archive.Article 134.The books shall be preserved in closed shelves, properly
separated, Comunidades wise or least in separate shells for each Comunidades. Each book or bundle
of papers shall have a label indicating the nature of the books and papers and the year to which they
concern.Article 135.The secretary of the administration is the conservator of the general archive and
as such, it shall be his responsibility to receive all the books and papers referred to in article 454,
paragraph 2, by issuing the necessary receipt to the clerks of Comunidades on one of the duplicates
of the inventory referred to in article 137, paragraph 2, and he shall be responsible for their
preservation, by fulfilling all the duties imposed by this Code to the clerks of Comunidades as
regards the archive of each Comunidades.Article 136.The administrator shall order the binding of
the books and have copied the texts that are party effaced, ordering the checking of the copies by
two experts and they shall certify at the end of the copies, that they are true copies of the originals,
authenticating them and preserving the originals along with the copies in the general archive.Article
137.The general expenses of the archive shall be borne out of the general administrative funds but,
each Comunidades shall pay for the binding expenses as well as of copies of books, honorariums of
the experts and the wages of the clerks recruited by the administrator for the purpose of making
copies.§ 1. As and when the books, files and papers, referred to in the sole paragraph of article 133Code of Comunidades of 1961

are sent to the general archive, a record should be made in the inventory of each Comunidades
mentioning the note by which they were sent.§ 2. In the first fortnight of April, in each year the
president of the managing committee, the attorney and the clerk of the Comunidades, forming a
commission, should sort out the books, closed files and papers which, under the terms in sole
paragraph of article 133, should be sent to the general archives and the clerk shall send them to the
administrative office before the 30th of the same month, accompanied by an inventory, in duplicate,
signed by all the members of the committee.§ 3. The failure to comply with what is contained in
preceding paragraph, the president of the committee, the clerk and the attorney of the Comunidades
shall be liable to pay each one a fine of 300 $, by order of the administrator.§ 4. The administrator
of Comunidades who proves to be negligent in awarding penalties referred to in preceding
paragraph shall be punished with a fine of 600 $.Article 138.In addition to the duplicate of the
partial inventories of each comunidade, the general archives shall have its own general inventory,
organized by the conservator and approved by the administrator, after checking its accuracy.Article
139.All the provisions of this Code regarding the archives of the administration office and those of
Comunidades shall be applicable to the general archives.Article 140.The certified copies of general
archives shall be issued by the secretary of administration office, without requiring any order and
the emoluments shall be normal ones.Article 141.The staff in charge of the works have competence
to:-(a)Study and draw up maps and estimates for ordinary, extraordinary and urgent works and
services;(b)Assist in the inspections for taking provisional or definite charge of works, in cases
where it is within the powers of the administrator to do it, in accordance with this Code;(c)Oversee
and check the execution of all the services and works, whether ordinary, extraordinary or urgent, by
his own initiative or when ordered by the administrator;(d)Assist the administrator in matters
within his area of expertise.Article 142.The assistant engineer (apontadores) shall assist the
engineers in all the services for which they are responsible and shall execute the routine work of the
technical sections as ordered.Article 143.In the talukas of Ponda, Mormugao, Bicholim, Sanguem,
Canacona, Quepem & Pernem, the functions of technical person of the works shall be performed by
the head of office or head of technical section of the respective municipality being entitled to draw
the gratuity mentioned in the attached map No. 2-I.Sole § In the absence of the head of office or
head of the technical section of the Taluka, any technical person may be entrusted with the study or
elaboration of the projects.Article 144.The works of the Comunidades may also be studied by the
heads of the agricultural divisions and by the technical person of special brigades appointed by the
Government.Article 145.The filling up of the post of secretary of administrations of Comunidades
shall be made through a competitive practical examination among the first class auxiliaries and first
class clerks of Comunidades with a minimum of two years service in the respective class and a good
service report. The admission to the examination shall be based on production of the document in
proof of the referred service.Sole § The examination will cover the following:-Written examination
of the duration of 3 hours:(a)Drafting of a report or proposal over a given subject;(b)Knowledge of
matters dealt with in the Code of Comunidades, the Overseas Organizational Law, the Statute of
State of India and the Overseas Civil Services Statute;(c)Elementary mathematics and accounting of
Comunidades.Oral test: with the duration of 15 minutes.Questions over the matter referred to in
item (b) of the written test.Article 146.The posts of auxiliaries of 1st class shall be filled up by a
competitive examination among the 2nd class auxiliaries and 2nd class clerks of Comunidades, with
a minimum of three years service with good service report in the respective class and the admission
to the examination shall depend on production of a document in proof of the referred service.Sole §Code of Comunidades of 1961

The examination shall be based on the same program indicated for the examination of 1st class
clerks of Comunidades.Article 147.The filling up of posts of 2nd class auxiliaries shall be made
through a competitive examination among the 3rd class clerks and 'Comunidades' clerk of the 3rd
class, with a minimum of three years service with good information report in the respective
class.Sole § The examination shall cover the same matter established for the 2nd class Comunidades
clerks and a typing test.Article 148.The posts of 3rd class auxiliaries shall be filled up through a
competitive practical examination, under the terms prescribed in article 95 for the 3rd class clerks of
Comunidades.Article 149.The competitive examinations referred to in the preceding articles shall be
announced by and conducted at the Directorate of Civil Administration, in accordance with article
95, and those that follow this Code.Article 150.The posts of bailiffs shall be filled up through a
competitive procedure conducted in the respective administration office and it shall be based on
documents produced, the minimum qualification shall be the 4th standard of primary education in
Portuguese.Article 151.The posts of foreman shall be filled up on contract basis under the terms
applicable to the services contracts in the State, through a competition based on documents
produced. It will be conducted by the Directorate of Civil Administration.§ 1. The minimum
qualification for admission to this competition is the completion of a course of the civil engineering
technician or equivalent qualification.§ 2. The selection panel for the competition shall comprise of
two members appointed by the Governor General, and the Director of Civil Administration shall be
its chairman.Article 152.The posts of assistant engineer (apontadores) shall be filled up on contract
basis, through a competitive examination as per the terms established for the filling up of similar
posts in the Municipalities.Sole § The selection panel shall comprise of the technical officer for
works and the head of the technical division of the municipality under the chairmanship of the
administrator.
Chapter IV
Governor-General
[Article 153.] [Article 153 has been amended by Goa Act No. 9 of 1985 dated 27/04/1985 by adding
clause 19 (See Appendix).]Governor General is empowered to:
1. Appoint, contract, promote, transfer, retire and dismiss administrators and
employees of the administration office and of the comunidade, in accordance
with the law;
2. Exercise disciplinary action on the administrators and the personnel
referred in the previous number, as per law, and grant them leave;
3. Appoint and dismiss the effective and substitute presidents of the
managing committees, dissolve the elected part of them, and appoint
suitable persons to replace them, in terms foreseen in this Code;Code of Comunidades of 1961

4. Approve urgent expenses in terms of article 65;
5. Authorise the meetings of the Comunidades in the seat of the
administration office and direct the administrator to attend the meetings,
where they are normally held;
6. Authorize eventual or unforeseen expenses in excess of 1500$ and the
extraordinary expenses approved by the respective comunidade;
7. Compel the Comunidades to use the technical means necessary for the
maintenance of the paddy fields of one or two crops and to cultivate the
uncultivated lands suitable for cultivation;
8. After hearing the Comunidades, to order the acquisition of machinery and
tools that facilitate and improve agriculture, the rational use of fertilizers and
experiment new crops and the creation of new artificial pastures for the
feeding cattle;
9. [Grant emphyteusis] [For the meaning of emphyteusis see 324.], authorize
the exchange of the land of Comunidades and order its reversion;
10. Grant long time [leases] [For the meaning of long time lease see 317.];
11. Grant extension of period for the utilization of the lands granted on
emphyteusis;
12. Grant rebate - (quita) to the lease holders of the paddy fields;
13. Authorize the payment, in instalments, of the dues to the Comunidades;
14. Decide the complaints and appeals against the decisions of the
administrator in non-contentious matters;
15. Wind up the insolvent Comunidades which are in the conditions
mentioned in the article 178;Code of Comunidades of 1961

16. Exercise all the powers conferred in this Code;
17. After hearing the Government Council, to approve the budgets of income
and expenditure of the administration office of Comunidades and of the
Pension Bank (Caixa de Aposentações).
18. And, in general, to take cognizance of all the acts of the administrator of
the Comunidades, in matters which are not within the cognizance of the
Administrative Tribunal or by common courts.
19. [ To make rules for carrying into effect the provisions of the Code.]
[Inserted by Act No. 9 of 1985.]
Chapter V
Administrative Tribunal
Article 154.The Administrative Tribunal is empowered to:-
1. Decide on appeals filed against the decisions of the administrator of the
Comunidades in non-contentious matter, as well as on those which pertain to
the balance sheet of the annual income and expenditure of the
Comunidades;
2. Decide on the irregularities of the auctions of the Comunidades, either
noticed or informed by the administrator or alleged in complaints filed by
private parties, in terms of this Code;
3. Grant permission to the Comunidades to file suits in accordance with
article 9, save in what is provided in the article 353, paragraph 3 of article 380
and article 388 and article 305 of the Portuguese Civil Procedure Code to
withdraw, admit and compromise, as well as authorize the respective
expenditure;
4. Decide complaints against the acts of the Comunidades on the matters
regarding derramas, easements, distribution of waters, usufruct of fallow
lands or groves and of common pasture, save when it is related to the cases
of verification and assessment of compensation;Code of Comunidades of 1961

5. Confirm the judgement of uncollected debts and annulment of dues to the
Comunidades and pronounce judgement on the questions of prescription;
6. To examine the annual accounts of the Pensioners' Bank (Caixa de
Aposentações).
Chapter VI
Pensioners' Bank
Article 155.The employees and agents of the Comunidades and of the administrative office are
entitled to a retirement pension paid through the Pensioners' Bank, on the same terms as admissible
to the public servants.Article 156.The Pensioners' Bank (Caixa de Aposentações) shall have its head
office in Panjim City of Goa and branches in the administrations offices of the Comunidades of
Salsete and Bardez and in the talukas where there exist Comunidades.Sole § When the Pensioners'
Bank does not have sufficient funds for the payment of pensions, the difference shall be made good
by all the Comunidades by way of advances in proportion to their income.These advances constitute
a debt against the Pensioners' Bank which shall pay to the respective Comunidades soon after it is in
condition to repay.Article 157.All the employees mentioned in article 155, shall have to enrol
themselves as members of the Pensioners' Bank and pay the pension contribution as fixed in the
article 439 and its paragraphs of Overseas Civil Service Statute (Estatuto do Funcionalismo
Ultramarino).Article 158.The enrolment of the members mentioned in the preceding article shall be
made within thirty days from the date of appointment, by the secretary of the administration office
of the Comunidades of Goa, in a special book. This shall be made independent of any
authorization.Article 159.The funds of the Pensioner's Bank shall be deposited in the safe of the
respective administrative office, but shall be kept separately.Article 160.The incomes of the
Pensioners' Bank comprise of:-
1. The monthly contribution of the members;
2. The proceeds of the fees collected by the administrative offices;
3. Any legacies (legados) in favour of the said Pensioners' Bank;
4. Any amount which prescribes in favor of the said Pensioners' Bank;
5. Interests on loans given;
6. 25 per cent of the proceeds of zonns and the dividends of the shares
prescribed. The Governor General, however, soon after he satisfies that the
fund of Pensioners' Bank had reached a level of 4.800.000$, he shall direct
reversion to the respective Comunidades, of the amount of 50 per cent of theCode of Comunidades of 1961

said percentage stated above;
7. Any other eventual revenue.
§ 1. Whenever the Pensioners' Bank has funds available, it may grant loans to the private persons
and to the Comunidades, in the former case with guarantee by way of shares of the Comunidades
and of the gold and silver or mortgage of rustic and urban properties, without prejudice to the
amount necessary for the payment of pensions.§ 2. The loans to the Comunidades shall bear the
interest of 2 per cent interest, when they are meant for works of agricultural development and
improving of its properties or acquisition of machinery and agricultural tools. In other cases, as well
as for private persons, the interest shall not be less than 3 per cent, for loans less than 8.000$ and
2.5 per cent for the loans of higher amount.§ 3. The loans of a sum not higher than 8000$,
repayable within the period of one year, can be made by a private declaration and renewed for equal
periods, if the borrower pays the interest due, punctually.§ 4. The loans of amount higher than
8000$ shall be made by public deed, with prior authorization of the Governor-General.§ 5. The
Government shall regulate what is contained in the preceding paragraph.Article 161.The expense of
the Pensioners' Bank comprises of:-
1. The pensions of the retired employees;
2. Other expenses inherent to the functioning of the Bank.
Article 162.The writing of books and accounts of the Pensioners' Bank and its branches shall be
under the charge of the secretary of the respective administrative office.Article 163.There shall be
five books for maintenance of accounts of the Pensioners' Bank: the <Catalogue Book>, for the
enrolment of the members, one of <Income and Expenditure Book> for entering the annual
budgets, one <Cash Book> for the cash movement in the safe, one of <Current Accounts Book>, for
the current accounts of all the employees and agents, in active service and retired, and one of
<Sundry Declarations and Reports Book> for maintaining the record of the seizure or remission and
any others.§ 1. The branch of the Pensioners' Bank shall have a Cash Book, to register the movement
in the safe in their charge and one the Current Accounts Book of the retired employees who may
have to be paid by the branch.§ 2. All the books referred to in this article and the preceding
paragraph shall be signed by the administrator of Comunidades of Goa and the respective terms of
opening and closing should also be signed by him.Article 164.The ordinary budget shall be prepared
annually, during the month of October, by the secretary of the administrative office, where the
Pensioners' Bank is located and shall be approved, on the recommendation of the administrator, by
the Governor-General, after consulting the Government Council.Article 165.The Current Accounts
Book, which is yearly, shall be prepared by 15th October of every year and in it shall be entered the
credits and debits of all the creditors and debtors of the Pensioners' Bank as per the model No. 29
attached to this Code.Article 166.All the movement in the safe shall be entered in the Cash Book, the
deposits of the money on the left hand page and the payments in the right hand page, the latter
being signed by the individuals receiving the money and the opening and closing notes of the safe
signed by key holders as per model No. 26 attached to this Code.Article 167.The Pensioners' BankCode of Comunidades of 1961

shall send to its branches a list of the retired employees to be paid by the respective branches.Article
168.In the case when there is a deficit in the ordinary budget, such a shortfall shall be shared by all
the Comunidades, in order to enable the Pensioners' Bank to fulfil its responsibilities and the
secretary of the administrative office shall forward to its branches, with the administrator's
signature, the notes indicating the contributions that the respective Comunidades are required to
advance and the branches in their turn, after collecting these contributions from the Comunidades
of the respective taluka, shall forward them to the Pensioners' Bank after deducting the charges due
on the same.Article 169.If, after sharing the shortfall referred to in the preceding article, there are
new charges resulting from retirement of new staff members or any new expenses, there shall be a
new adjustment in the distribution or a supplementary financial contribution [derrama] [Derrama -
For definition refer to foot note of 100.] shall be asked and which shall be paid immediately by the
same Comunidades.Article 170.The branches shall send to the Pensioners' Bank by the 5th of each
month, by postal order, the amount collected by them in the preceding month, that is to say, the
excess of the income over the expenditure.Sole § The same branches shall send on the same date, a
statement of monthly movement of the respective income and expenditure, in order to enable the
head office of the Pensioners' Bank to organize its current accounts.Article 171.For the purposes of
No. 6 of Article 154, the accounts of the Pensioners' Bank shall be processed and sent by the
respective secretary, to the Administrative Tribunal along with those of the general safe.Article
172.All the monies which exceed the total of the payments to be made at the Pensioners' Bank and
its branches shall be deposited in said Bank known as [Cooperative Bank or where such Bank is not
in operation, in the Post Office Savings Bank as the case may be] [Substituted for the words 'Caixa
Economica de Goa' by Goa Act 3 of 1998, dated 17-1-1998.].
Chapter VII
Comunidades in default
Article 173.Comunidades in default is the one whose members have deserted its administration or is
unable to pay the dues.Article 174.Whenever it is found that there are comunidades in the
conditions described in the preceding article, the administrator shall convene the respective
members, for a meeting in the administration office, if there are five or more in number, in order to
deliberate whether it is convenient for them to take up the management of the same
comunidades.Article 175.The meetings shall be called by notices published in the Official Gazette
and one newspaper published in the seat of the taluka or, if not possible, in the capital, and affixed
to the door of the administration office and of the temples of any religion or at other public place of
the area of the Comunidades.Sole § If the number of the members is less than twenty and all of them
are residents of the taluka, the meeting shall be called by notice and the public notices will not be
required.Article 176.When half plus one of its total number of members are present, they shall
deliberate, by majority, whether or not it is convenient for them to take on the management of the
Comunidades.Article 177.If they deliberate to assume the management, the administrator shall
inform the Governor-General about it.Sole § Once the deliberation has been confirmed by the
Governor-General and consequently the managing committee has been constituted, its management
shall be handed over to the said committee, continuing henceforth the comunidades to be
administered in the same way as the others, observing the rules established in this Code.ArticleCode of Comunidades of 1961

178.If the members fail to meet or after meeting, they declare they do not want to take on the
management, the administrator will take charge of its management.§ 1. To such management, the
rules prescribed in this Code are applicable and the administrator shall perform the functions of
Comunidades and of the managing committee.§ 2. The collection of revenues and the credits of the
Comunidades shall be adjudicated annually, by public auction.§ 3. The administrator shall appoint
an attorney who shall represent the in default Comunidades and such appointment should be made
from among the five major interest members, if available.§ 4. In the event foreseen in the body of
this article, if the incomes of the Comunidades are not sufficient to meet the expenses and the
respective members do not guarantee the payment of the annual shortfall, the Governor-General
shall order the extinction of the said Comunidades.§ 5. If the members guarantee payment of the
annual shortfall and the same is not paid at the end of each year, a current account will be issued
against the responsible for the same and if the non-payment is continued for two consecutive years,
the Governor-General shall order the extinction of the Comunidades without hearing the
sameArticle 179.In the Comunidades whose extinction had been ordered, in terms of preceding
article, an inventory shall made of its properties, following the provisions of Article 209 and the
following ones. However the inventory shall be dispensed with when the income of the
Comunidades is below 3000$.At the same time the clerk of the Comunidades shall prepare a list of
the income not derived from the properties, whatever may be its origin, declaring the source of each
item.In the same manner another list shall be prepared of the charges on the Comunidades which
constitute an obligatory item of its annual expenditure, comprising all its debts.These two lists shall
be presented to the administrator alongwith the books, on which they were based for their
preparation and the administrator shall have them checked and, if he finds them in order, he shall
approve them, otherwise he shall order their correction.Article 180.On completion of the work,
referred to in the preceding article, the sale of the properties and other revenues shall be announced,
observing in the auction the provisions of the Code of Civil Procedure, - (Codigo de Processo Civil)
in whatever is applicable.§ 1. The bidding price, by which the properties shall be auctioned, is the
one indicated in the Register I - (Tombo 1), to which twenty annuities of the charges variable and
invariable, indicated in the same register, shall be added, and the price of other revenues shall be the
sum of twenty annuities or instalments.§ 2. The sale shall start with these revenues.§ 3. The
properties shall be auctioned free of charge or encumbrances.§ 4. Only the revenues and properties
shall be sold in auction, the price of which, determined by way of auction, is sufficient to redeem the
expenses as per the list referred to in the third period of Article 179.Article 181.With the proceeds of
the sale, the remission mentioned in the paragraph 4 of previous article, shall be effected and the
remaining properties or revenues shall be given to the members for them to divide in the proportion
to their rights.§ 1. If the majority of the members prefer the sale of all the properties, this shall be
done, and the funds that remained, after paying off all the debts, shall be distributed among them,
according to each ones right.§ 2. If the Comunidades does not have members, all the assets shall be
sold and the proceeds that remain, after paying the debts, shall be deposited in the said Bank
[Cooperative Bank or where such Bank is not in operation, in the Post Office Savings Bank as the
case may be] [Substituted for the words 'Caixa Economica de Goa' by Goa Act 3 of 1998, dated
17-1-1998.] in favour of the Pensioners' Bank.Title IIOperations of the Comunidades and their
procedureCode of Comunidades of 1961

Chapter I
Qualification of the members
Section IOf primary enrolment of the zonnkarsArticle 182.The primary enrolment provided in
Article 21 will be open from 1st to 31st May each year.Sole § Any interested party, however apply for
his primary enrolment after this period, at any time of the year, on payment of fees of 6 $ for each
primary enrolment, which fee shall be reverted totally in favour of the Pensioners' Bank.Article
183.Whoever desires to have his name in the book of primary enrolment shall present to the clerk of
the respective Comunidades the documents in proof of the following:-
1. That has the capacity to be a zonnkar as per number 1 of article 20;
2. He had completed within the period indicated in the preceding article, the
age required by the statutes of the respective Comunidades to be entitled for
any kind of zonn or the age of 21 years, if not fixed in the statutes.
The proof of age shall be made by producing a certificate from the Civil Registrar or any other legal
document substituting the same.Article 184.In the Comunidades in which, as per its statutes, the
orphans of the zonnkars are eligible to get the zonn on the death of their father, before attaining the
age set for being entitled for the same, in their own right, such orphans themselves, when aged 14
years or more, or by their representatives, when they are of lesser age, shall apply for the inscription,
by producing before the clerk of the comunidade, at the appropriate time, a certificate identifying
their parents and the certificate of the death of their father.Article 185.The widows of zonnkars
without male heirs succession and the unmarried daughters of the same, orphans of parents, who
may not have full brothers in the Comunidades in which, as per the statutes, are legible for some
part of zonn or a life pension, during the widowhood or during the period when they remain
unmarried, they should apply for their inscription by producing to the clerk of the respective
'comunidade', the following documents:
1. The widows: death certificate of her husband and document of the
respective parish priest or the managing committee of the village or of the
functionary in-charge of the parish (regedor) proving that she has no male
heir;
2. The unmarried daughters: birth certificate or any other document
substituting the same and of the death of her father, and certificate that he
did not have any son, true brother of the applicant for inscription.
Article 186.The clerk and the attorney of the comunidade, after verifying the authenticity of the
documents, shall examine if the name of applicant's ascendant figures in the catalogue, and after
finding it, they shall immediately do the inscription in the respective class. This provision shall beCode of Comunidades of 1961

applicable to the widows and unmarried daughters mentioned in the preceding article.§ 1. If the
clerk of the Comunidades and the attorney are not able to make the inscription on the day that the
applicant presents the documents, the said clerk, keeping the same in his possession, shall issue a
receipt to the applicant, mentioning the number and the nature of the documents, and shall advise
him to come on any first eight days of June of the respective year to collect the copy of the
declaration of inscription or the documents with declaration of refusal, on returning the respective
receipt to the said clerk.§ 2. If the applicant does not satisfy the requirement to be inscribed, as per
this article, the inscription shall be refused, handing over to him on the same act or on the day that
may be fixed, in terms of preceding paragraph, a note giving grounds for refusal, written and dated
by the clerk of the Comunidades and signed by him and by the attorney. Based on this note the
affected person may file an appeal to the administrator within the next ten days.§ 3. If the attorney
and the clerk do not agree with the inscription, as applied the matter will be resolved by the
managing committee and, in this case, instead of the note of refusal, the applicant shall be given a
copy of the respective minutes, mentioning the date of handing over issued by the clerk of the
Comunidades with which he may file an appeal to the administrator within the next ten days.§ 4.
The inscription made shall be displayed in the meetings hall during the first fifteen days of the
month of June for the examination by the members.§ 5. Any member may appeal to the
administrator, within the period of ten days, against the inscription unduly done, requesting the
exclusion of the inscribed person, and the administrator, after hearing the person concerned, the
clerk of Comunidades and the attorney and after attaching to the file the copy of the declaration of
inscription and the document on which it was based, shall decide the matter according with the
law.§ 6. The power given to the clerk of the Comunidades and to the attorney to do the inscription is
restricted only to the cases when in the catalogue the name of father or grand-father of the applicant
figures.Article 187.In cases not specified in paragraph 6 of the preceding article, application for
inscription can be made at any time of the year to the administrator, who shall prepare the case file
as per the procedure laid down in article 390 and following ones, with the intervention of the
comunidade. Documentary evidence and, in its absence, judicial qualification may be
accepted.Article 188.In case there is any objection against the inscription of any member, he may
enjoy his rights and obligations as from the date when the decision becomes res judicata.Article
189.If the objection, in connection with the inscription, is upheld the interested party lead further
evidence in the same file or renew his application.Article 190.It is within the jurisdiction of the
administrative tribunals to decide the questions relating to qualification or local stand of applicants
seeking inscription but it is for ordinary court of law to decide all the questions involving third party
or the Comunidades either against the applicant or against member itselfArticle 191.The provisions
of paragraph 1 of article 22 are applicable to the widows, orphaned sons and unmarried daughters of
zonnkars, who under the terms of Articles 184 and 185, may have right to any part of zonn, annuity
or pension.Article 192.After the inscription is done as per the model No. 6, a copy of the inscription
document of the same, shall be given to the interested party, when applied by him.§ 1. The
inscription document shall contain the corresponding serial number, name, affiliation, age, place of
birth, address and quality of the registered person and finally, the designation of the number of the
bundle in which the documents are kept filed in the 'comunidade' or the reference to the book or
public notary from where they were obtained.§ 2. The inscription document shall be dated and
signed by the clerk of the Comunidades and the attorney, as well as by the member who had applied
or by two witnesses when the applicant do not know to write.Section IIAnnual enrolment ofCode of Comunidades of 1961

zonnkarArticle 193.Every year, during the period prescribed in the article 182, there shall be annual
enrolment of zonnkar, as well as widows, sons and daughters who may have interest in the
comunidade, as provided in Articles 184 and 185, upon production of their existence till the 30th
day, inclusive, of the previous month of April.§1. The following are competent to issue life
certificates.The administrative board of village, (Junta de freguesia), functionary in charge of parish,
(regedor), parish priest, consular agent, missionary and administrators of taluka and of
comunidade.§ 2. Instead of producing the certificate mentioned in the preceding paragraph the
applicant himself may sign, within the period prescribed above and his signature may be certified by
the Notary or by the clerk of the respective Comunidades as well as by a declaration of the parents,
spouse or son of the interested person or, in the absence of the same, by any member of respective
comunidade, which declaration shall be drawn up before the clerk of comunidade, in the presence of
two witnesses, who shall also be members of the comunidade.§ 3. However, the necessity on
production of the documents, referred to in the preceding paragraph, is dispensed with when the
member appears personally which per se is sufficient for the registration, if he is known to the clerk
or to the attorney of the respective 'comunidade' or to two members who guarantee, on their own
responsibility, based on the declaration signed by them, along with the interested person and which
shall be filed.§ 4. The annual enrolment shall be done in accordance with the model No. 7.§ 5. The
provisions of paragraphs 2 to 5 of article 186 shall apply to the annual enrolment.§ 6. From the
refusal to the annual enrolment, or its irregularity or omission or to the annual enrolment wrongly
done, complaints and appeals, as established for the admission can be filed.Article 194.The zonnkar
once primarily enrolled, who fails to take steps to get annually enrolled get registered for a
particular year, cannot receive the income of his zonn in respect of that particular year, he can
however receive that income in any other year in which he has been annually enrolled, provided the
claim in enforceable.Sole § In the case foreseen in this article and also in the Article 187, the clerk of
the Comunidades shall set apart in the statement of the income and expenditure of the year of
registration, the amount of the incomes accrued in order to be paid to the creditor zonnkar.Article
195.In the case of death of a zonnkar without having been registered, his duly qualified heirs, within
the period of one year from the date of death, may receive the income accrued in the previous years,
without prejudice to the provisions of paragraph 3 of Article 21.Sole § In this case the Comunidades
clerk shall, also proceed in terms indicated in the sole paragraph of preceding article.Article 196.The
orphaned sons, unmarried daughters of the zonnkar and their widows shall not be able to make
periodical enrolment in the year of the death of their parents or husbands if the latter died after
receiving the income of zonn in respect of that year.Article 197.In the Comunidades where there is a
deficit, the registration of the member shall be made by the clerk of the comunidade, on his own
initiative, and he shall inform, in writing, of the same to the interested persons, after observing the
rules of this section.Article 198.By the 30th June each year, the clerk of the Comunidades shall send
to the administration office the primary enrolment and annual enrolment books for
approval.Section IIIInscription of share-holdersArticle 199.The inscription of share-holders, as
prescribed in paragraph 1 of article 22, shall be done in the respective comunidade, by fulfilling the
following:Code of Comunidades of 1961

1. The person asking for inscription shall submit to the clerk of the
Comunidades a certificate, issued by the secretary of the administration
office, countersigned by the administrator, that one or more shares of the
same Comunidades are endorsed in his favour as his property, or else
submit the actual share certificate itself with a note signed by the
administrator.
2. The clerk of the Comunidades shall examine if the shares transferred are
included in the inscription book in the name of the transferor's name, and
only then, after cancelling this inscription in the transferor, in all or some of
the shares, as the transfer was made in full or in party shall inscribe the
name of the applicant as possessor of the shares according to the certificate
or title presented.
3. If in the book of inscription of the shares, the name of the transferor is not
found recorded, the request for registration shall be refused, and a note of
refusal shall be given to the applicant, and based on it, he can file an appeal
to the administrator.
Article 200.The inscription of the share-holders may be done at any time of the year, but on the last
day of the month of May of each year, the clerk of the Comunidades and his attorney shall close the
inscription book, adding up the shares which upto that date were registered and after checking the
sum, with the total number of the shares of the comunidade, as indicated in the map No. 8, he shall
satisfy if the register is in order and thereafter, sign the closing declaration in the register.Article
201.By 30th day of June of each year, the clerk of the Comunidades shall send to the administration
office the book of inscription of the share-holders, for approval.Section IVInscription of pensioners
and participantsArticle 202.The annual fixed pensions, known as [acas, formás, votonas, tainatas]
[[Acas-(Acca or hacca) - Is a portion of rent or production payable to hereditary functionary of the
District or village in India or pension paid hereditary.Glossario Luso Asiatico by Sebastiao Rodolfo
Dalgado, Pg. 6 Vol I.-Formas A fixed pension that the Comunidades had to pay Ibid Pg. 403 Vol
I.-Votonas A pension payable to the Watandar who is hereditary interested in a WatanIbid Pg. 557
by H.H. Wilson.Pg 116 Terminology in Indian Land Reform by P. T. George.-Tainata Pension
payable on account of military service Ibid Pg. 338 Vol II.]] and others that the Comunidades pay to
the individuals, as well as to the participants, referred to in the No. 3 of Article 2 shall be inscribed,
applying to the administrator by attaching to the petition the documents confirming the
transfer.Article 203.The pensions and holdings that are inscribed in a name different from that of
the transferor or of the one representing him, shall not be inscribed in the name of the applicant
unless, by a judicial decision, that has become res judicata, it is proved that the applicant's right to
them has been confirmed, in which case the inscription shall be made.Article 204.The inscription
cannot be effected when the person, in whose name the pensions or holdings are inscribed, have
transferred them, with reservation of the usufruct, and if the propriety is transferred to one personCode of Comunidades of 1961

and the usufruct to another, firstly the enrolment will be made of the usufructuary, declaring this
capacity. The inscription, in the name of the owner should be made only when the ownership and
usufruct right vest are merged in.Article 205.The provisional inscription in the name of the head of
the family, is permitted by proving this status with a certified copy of the inventory that is in
progress, and in the name of a head of a joint hindu family by producing authentic document of the
joint family it being legally formed.Article 206.After the application is accepted, the claim for the
registration shall be announced in two successive numbers of the Official Gazette, calling for
objections against the same, within sixty days from the second publication.§ 1. After the period of
sixty days, any representation or the negative certificate, as the case may be, shall be attached to the
application, and the clerk of the Comunidades and the managing committee shall be heard.§ 2. As
per the material on record, the administrator shall decide the claim.§ 3. These inscriptions shall be
done in special books which the clerk of the Comunidades shall send to the administration office by
the 30th day of June of each year for approval.Article 207.The provisions contained in sole
paragraph of article 418 shall be applicable to the registrations referred to in this section.
Chapter II
Registers (Tombos)
Section IRegister 1 (Tombo 1)Article 208.The register. 1- (Tomb I) is the cadastre of all the
properties of the Comunidades mentioned in map No. 1, and the description of the sources of other
revenues, not connected to private land.Article 209.It is obligatory in all the Comunidades,
whenever necessary, to organize and reorganize, the Register 1 of the properties, known as 'Tombo'
1, which shall be carried out in the shortest possible time, according to the following numbers:The
paddy fields, with the exception of those mentioned in article 325, shall be divided in lots, whose
area generally shall be of 0.5 ha. to 1 ha., save where special circumstances advise that some larger
or smaller lots are advisable. The hilly properties need not be divided into lots or may be divided
into lots of area higher than 1 ha. whenever the nature of the land and the system of cultivation
justify;Maps shall be prepared of all the rustic land of the Comunidades, showing independent
property units and the lots into which each property is divided. All the lots and the building
properties shall be duly enumerated, named, demarcated, bounded, measured and valued, with all
the necessary and indispensable indications to establish its identity and indications, which will be
reflected from the map and in the register of the surveyor (model No. 9), which shall accompany the
maps where all the lots shall be numbered in each maps records with the number which shall
correspond to the one in the general numbering of the properties of the comunidade;The
denomination of the lots, shall not, generally differ from the actual names used, which shall only be
changed or added to, when necessary for the better identification of each individual property;The
demarcation of the properties shall be done by the comunidade, for which the Comunidades shall
solicit the supply of boundary stones by way of auction, preceded by the estimate duly approved by
the administrator.The boundary stones shall be of solid stone and of two types: the first type meant
for demarcation of the perimeter of each independent property, shall constitute of rectangular
parallelepipeds having 0.80 metres of height and 0.22 metres of width on each side; others, meant
for interior demarcation of lots, shall be of the same kind, having however, 0.50 metres of height by
0.22 metres of width, whenever possible. In the firm land as of the hilly places, the dimensions inCode of Comunidades of 1961

height can be reduced, which shall be indicated in the clauses of the auction; in loose soils, such as
sandy land, the heights may be increased;The survey of each property shall be done numerically, so
that one or more boundary stones of its perimeter can be easily indicate on the ground, by
references to fixed and permanent points. Whenever possible, this reference shall be in relation to
trigonometric points or points that shall delimitate each village, and whenever, at the time of the
survey, if the perimeter map of the village map is available, the position of the map drawn should be
shown in that map. The result of the measurements shall be expressed in units of the decimal metric
system. In the area of each lot, fractions of the square meter shall be rejected, and in dividing lots,
use should be made, as much as possible, of straight alignments.The valuation of lots of regular
productivity shall be done in such a way that the net annual income of each of them, previously
calculated, corresponds to 4 per cent of the respective value, and the net revenues shall be computed
in the following manner: after calculating the output of the portion of land correspondent to the
quantity of the seed that the land will take, as per the nature of the soil. This is to be converted in
cash, on the basis of the respective average price for the cereal cultivated during the last five years.
Thereafter, the production expense is then set at 35, 40 or 50 per cent, according to the nature of the
soil. While preparing the Register 1 - (Tombo 1), various charges and expenses referred to in the
article 216 and its paragraphs shall be deducted from these net revenues;The valuation of the lands
meant for the cultivation of pulses shall be done considering the number of years left fallow, and
regarding those which are deteriorated and uncultivated, they shall be valued on the basis of the
area and productive capacity of the soil;The production of the coconut groves shall be calculated as
per the number, nature and quality of fruit bearing trees existing in them. The expense of
production shall be fixed at 40 or 50 percent;The valuation of the building properties shall be done
so that the annual net income of each of them, calculated by the average of the incomes accrued over
the last nine years, corresponds to eight per cent of the respective value;If in any one or more years,
referred to in the preceding number, there has not been any income, the income of - those years will
be considered equal to those of the immediately preceding years;If there has not been any income in
all those nine years, then a fair and proper value should be determined to the property taking into
consideration the probable expenses of the respective construction, annual repairs and condition of
maintenance;Any income not specified shall be taken into account while fixing the value of the
properties; After all the necessary calculations are done, whilst fixing the value of the properties, the
fractions of 6$ should be ignored, adding however 6$ to the whole part of this value, when the
fraction part is above 3$.Article 210.In order to carry out the preparation of the Tombo (register of
the properties) of each comunidade, a brigade shall be constituted as follows:- one surveyor
requisitioned by the administrator from the Directorate of Economic Services, one informer, one
measurer chosen by the surveyor and two labourers to carry the instruments and to help in the
measurements.§1. The work to carry the inventory of properties of each Comunidades shall not be
executed by more than one brigade simultaneously.§2. The appointment of informers shall be made
by the administrator, on the basis of a proposal from the managing committee that will suggest a list
that contains names, not less than twice the number deemed sufficient, however the individuals
suggested should satisfy the requirements indicated in the following paragraph.§3. The informers of
each brigade shall be replaced in such a way that to each property or fraction of it corresponds to an
informer that have full knowledge of the same, and each of them shall be notified by the clerk of the
comunidade, to when their information may be required.§4. The surveyor is bound to bring to the
notice of the administrator, in writing, about the incompetence, unsuitability or lack of zeal that heCode of Comunidades of 1961

may notice in any of the informers, who attend to the work of preparation of the cadastre (Tombo).
Copies of these communications shall be sent to the Directorate of Economic Services.§5. All the
works of preparation of cadastre shall be supervised by the director of Economic Services and by the
administrator. The technical supervision over these works shall be of the exclusive responsibility of
the former or of the heads of the competent departments of the same Directorate.Article 211.The
personnel indicated in the preceding article shall be assisted in the work of preparation of Register
-'Tombo' by the attorney and by the clerk of the respective comunidade, who shall be required to be
present on the site each day whenever his presence is necessary.As and when convenient, the
managing committee may appoint, in substitution of the attorney, a special commissioner to
monitor and supervise the work of preparation of the said inventory. This appointment shall be
approved by the administrator.§1. It is the duty of the attorney or of the specially appointed
commissioner to:Represent the Comunidades during the preparation of the inventory of the
properties, safeguarding the interests of the comunidade, avoiding by means at his disposal that
such interests are harmed, supervising on behalf of the comunidade, the same work;Be present
during the placing of boundary stones in the places fixed by the surveyor and to do in such a way
that this inventory may be prepared in shortest possible time.§2. It is of the duty of the clerk
(escrivão) to:-Take notes of the complaints, agreements, encroachments, as and when necessary, as
per provisions of this Code;Notify or ask for notification, of the owners of the adjoining properties of
the comunidade, to be present at the time of placing the boundary stones of delimitation and to the
measurement of the encroachment, if any, and to sign the respective records, failing which it will
done in their absence;Have ready, sufficiently in advance, in order to give to the surveyor at the time
of starting the inventory work, or as and when requested, the following information:A nominal list
of all the properties belonging to the Comunidades, showing its divisions and sub-divisions;A list of
the auctions notes, with the respective calculations and rent collected during the last three
trienniums;Copy of the mutual rights of the cultivators in relation to irrigation;Certificate of various
charges or encumbrances.To make, under the direction of the surveyor, all the entries in the
inventory register of the properties -Tombo and extract copy of the surveyor's record.Article
212.Prior to taking up the inventory of the properties, the same shall be announced in the Official
Gazette and in the newspapers of the locality, if any, in order that the owners of the lands, adjoining
to that of the comunidade, and as well as those interested in the comunidade, shall be able to follow
the process and present any claims that they may have, which shall be duly recorded by the clerk of
the Comunidades in a special book and decided administratively, when possible.§ 1. This book shall
have the number of pages that are necessary and shall be previously initialled by the administrator
or his commissioner, and each one of them shall have, besides the space reserved to record the text
of the claim, two columns: one on the left, which shall used to record the sequential number of each
claim, the other, on the right, to record the decision.§ 2. All the claims shall be recorded, as briefly
and concisely, as possible and which shall be signed by the respective claimants, by the clerk of the
Comunidades and by the surveyor (model No. 10).§ 3. No claim shall be attended for the purpose of
administrative decision, unless the respective claimant undertakes to present and does present it in
the administration office of the Comunidades, within thirty days, from the date when the objection
is filed , all the documents that can substantiate his claims.§ 4. As soon as these documents are
presented in due time, the administrator shall examine the evidence in favour or against the
respective claim and shall direct the rectification of any mistake that he finds as having been made
by the respective persons involved in this work or else by directing that the claimant may use theCode of Comunidades of 1961

ordinary means, holding that there is no sufficient evidence.§ 5. When the administrator recognizes
that, in view of the documents presented, or any others, that there has been encroachment of the
land, he shall order that this property, or part of the property in question, be listed in the register of
encroachment, in order to proceed in respect of this property or part of it, in the manner indicated
in Articles 382 or 385 and following ones.§ 6. The administrator's decision is subject to appeal to the
Administrative Tribunal.Article 213.The work of cadastral survey, shall consist of field and office
works, the former being conducted in seven months, from 1st November to 31st May, and the second
in the remaining five months.§ 1. The supervision of the work of the survey is the responsibility of
the surveyor who shall be the main responsible for its execution.§ 2. During the time of the field
work, the surveyor shall have to carry out the following works:
1. In consultation with the attorney or commissioner and informer and with
the assistance of the clerk of the comunidade, he shall indicate, by means of
temporary pegs, the locations for placement of outer border stones and also
those dividing the lots. This fixing shall be preceded by any topographical
surveying for the plans or measurement;
2. To draw the perimetric plans, as per clause 2 of article 209, representing
within the lots into which each property is divided;
3. To collect from the field the necessary particulars and clarifications in
order to fill up the surveyor register;
4. To make the graphic drawings of the plans and to the value of the area of
the lots and of the encroachments;
5. To send every fortnight to the Director of the Economic Services and to the
administrator a report showing the area measured, with indication of the
boarder maps drawn up, the number of lots, encroachments and the value of
the latter, giving at the same time general progress of the work and the
manner in which it was carried out by the personnel of the cadastral survey.
§ 3. The period of the field work shall be carried out for six hours a day and shall be executed on all
working days.§ 4. The surveyor shall have his residence close to the place of work. The administrator
shall grant him every month the required amount to provide with a lodging in good hygienic
conditions and also provide him with the furniture essential for his office work.§5. The Director of
Economic Services and the administrator shall be present when the field work is in progress and
whenever they think necessary for the regular checking of the works.Article 214.On the initial days
of the field work, it is the duty of the surveyor, alongwith the president of the managing committee
and the attorney of the comunidade, to classify the lands coming under article 325 which as such,
shall be excluded from the sale or lease, sending the result of this classification to the administrator,Code of Comunidades of 1961

who shall give full publicity, so that the residents can make the complaints, if any, against such
classification.§ 1. On the complaints received, the Directorate of Economic Services, shall prepare a
report for technical purposes, and the administrator shall decide the case after inspecting the land.
Against his decision an appeal lies to the Administrative Tribunal.§ 2. The claims presented thirty
days after the date of publication of the classification, shall not be entertained.Article 215.In each
period of the field work, soon after the works of demarcation and division of lots are over, with the
register of the surveyor being completed in relation to each lot, fresh notice shall be issued, inviting
the owners of the adjoining lands and the party that have interest in the Comunidades, who may
have or not attended the field work, to present within fifteen days, from the second publication of
the same notice, any claims that may have to do in relation to the manner in which the survey
register have been maintained and organized, the division into lots and the drawings and
representation of maps in the field. After that period no complaints shall be attended to and for this
purpose the duplicate of the register shall be made available to the public in the Comunidades
meeting house and the respective original and the maps shall be displayed in the administration
office, during the said period.§ 1. As regards this complaint, the procedure to be followed shall be
also that indicated in the article 212 and its paragraphs and the expenses of the inspections referred
to in paragraph 1 of article 214, shall be at the cost of the comunidade, if the objections are in the
general interest.§ 2. During the period fixed in this article, the surveyor shall remain in the
administration office, in order to furnish information about any claim or to make necessary
modifications in the maps and in the registers, when these claims are upheld.§ 3. It is the duty of the
administrator to issue the notices mentioned in articles 213 and 215.Article 216.Soon after the
classification of the excluded lands become final and there are no pending complaints to decide,
steps shall be taken to organise and write the book of Register 1, (Tombo 1) which shall contain the
name and number of the maps, of the lots or properties, the serial order and perimeter
measurement of each one, the boundaries, the type of land, the type of cultivations and special crops
and harvest in each lot, the natural or artificial irrigation to be found, the value, the rental, the other
charges that they are subject to and all the details that could be obtained, including the
improvements that could be made to various lots, separately or in groups, indicating in this last case
the lots that may require the grouping for this purpose (model No. 11).§ 1. The burdens that each lot
is subject to, proportionally to the value of each one, shall be mentioned in the Register I (Tombo 1)
in two separate heads, comprising: the 1st, the permanent and variable burdens, like the
contributions for the assessment and various others duly authorized; the 2nd, the average of the
variable or eventual expenses, such as renovation of sluice gates, bunds and others. The sum of
these two items shall be deducted from the amount arrived at, as per clause 7 of article 209, and the
remaining shall constitute the net income.§ 2. The variable or eventual expenses shall be charged,
solely, on the lots which take advantage from them, and not on the whole of the field and its average
shall be calculated considering similar expenses done in the last nine years.§ 3. As far as building
properties are concerned, the same burdens that presently may have, shall be maintained without
any addition.Article 217.The lot or lots that form part of the lands leased for long period shall be
recorded in the Register I - (Tombo 1) in the same way as others. However, in respect of each one of
them, the period when the lease terminates should be mentioned.Article 218.The work of organizing
the Register I - (Tombo 1) referred to in the articles 216 and 217, shall be done during the period of
office work by the surveyor who had carried out the corresponding field work.§ 1. This work shall be
executed under the supervision of the administrator of the Comunidades, in the respectiveCode of Comunidades of 1961

administration office, with the assistance of the attorney or the commissioner of the Comunidades
who have accompanied the work of preparing the register of properties.§ 2. When a period of field
work is not sufficient to complete the work of survey of all the properties of the comunidade, the
surveyor shall take up in the period following the one designated for office work, the organization of
the said Register I (Tombo 1)which shall be compatible with the non-completion of the field work
following the formalities designated in Article 215. In this case, soon after the completion of the
work that in this period may be executed, the surveyor shall be directed, by the administrator to
present it to the Director of Economic Services.§ 3. When the field work connected with the
cadastral survey of a Comunidades has been completed, the surveyor shall complete the
organization of the Tombo, as per this article, even if he requires more time besides the five months
of office work.§ 4. The maps drawn up, accompanied of the field registers, after being placed for
objection to the public, as per Article 215, the same shall be sent to the Directorate of Economic
Services to be finally drawn. Copies on paper tela, of the plans drawn shall be sent to the
administration office by the Directorate of Economic Services. The Comunidades shall pay 6 $ for
the final drawing of each plan, by way of compensation for the paper and other articles of drawing.
These amounts shall constitute income of the State and shall be paid, on the order of the
administrator of Comunidades, in the respective treasury offices, in view of the sheets sent by the
Directorate of Economic Services, through the Directorate of Accounts and Revenue.Article 219.The
surveyors, attorneys or commissioners, clerks, informers and measurers shall be paid as per the
attached Table.§ 1. The Comunidades shall pay the expense allowances, equal to those paid to them
by the State for similar work, besides their respective transport allowance, to the Director of the
Economic Services or to the heads of the sections of the respective Directorate, for the days in which
they have spent on inspection of the field work connected with the preparation of the said Register.§
2. The surveyors shall be entitled to transport allowance, paid by the Comunidades, in terms of the
regulations of the Directorate of Economic Services.§ 3. The informers shall be entitled to the
allowance for the days in which they were present in the field.Article 220.The surveyors entrusted
with the cadastral survey work shall be ordered by the Director of Economic Services to present
themselves to the administrators, who had requested their services, to remain under them to carry
out the same work, but will not be under them in matters connected with discipline. The
administrators shall inform the Director of any faults, if committed by them and report on the zeal
shown in executing the works entrusted.§ 1. The Director of Economic Services shall issue, whenever
he thinks necessary, office orders giving precise instructions for the full and efficient functioning of
the technical part of the work of cadastral survey work.§ 2. Once the work connected with cadastral
survey work of a particular Comunidades is over, the surveyor in-charge of the same shall prepare a
report in which, briefly, he should mention the time spent on this work, the manner of its execution,
the number of maps drawn up, the number of lots into which the Comunidades land have been
divided, the total area of such lands, the number, total area and value of the encroachments and
other details of the work and general description of the land surveyed, classified according to their
nature, its situation and the kind of crops cultivated, so that a precise idea can be made of the
territorial domain of each comunidade.§ 3. Copies of each such report shall be sent one to the
administrator and the other to the Directorate of Economic Services.Article 221.At the end, a
description shall be made in the Register I (Tombo I) indicating the sources of income of the
Comunidades not derived from its properties nor related to properties possessed by others.Section
IIRegister 2 (Tombo 2)Article 222.The Register 2 (Tombo 2) is the detailed list of the properties inCode of Comunidades of 1961

Comunidades domain which are in possession and inscribed in the name of the private persons
(Model No. 12).Article 223.The Tombo 2 referred to in the preceding article, include properties that
have been granted by way of aforamentos or are subject for payment of fixed contributions.Article
224.When the organization of Tombo 2 is not prepared, the Register shall be made as per books and
other information available in the Comunidades and then the interested parties shall be invited, by
way of publication, to make within thirty days, any claim as they deem fit.§ 1. The claims shall be
processed and decided in terms of article 390 and following.§ 2. The list shall be prepared as per the
model No. 12, and without prejudice to the ownership rights of the propriety, which shall be
adjudicated in the judicial courts.Article 225.The detailed record relating to Register 2 (Tombo 2)
shall be prepared as per the location wise order of the properties, by a committee comprising of the
president of the managing committee, of the attorney, of the clerk and of two members, appointed
by the administrator, from among the members of the comunidade.Sole § The members of the
committee, referred to in this article, shall be awarded a special remuneration by the administrator,
after consulting the comunidade, depending upon the volume and the importance of the work
executed. The grant of this remuneration shall be subject to the sanction of the
Governor-General.Article 226.Requests for subsequent mutation of the properties in the Tombo 2
shall be made to the administrator, by application supported by the following documents:Title
proving transmission of domain;The payment of the [siza] [siza - transference tax due to the
Revenue Department.] whenever payable.§ 1. The properties registered in Tombo 2 in a name
different from the one of the transferor, or of the one who represents him, shall not be mutated.In
the same way those properties, the foro in respect of which and other contribution relating to the
last five years are in arrears, shall also not registered save when the defaulter pays the due at the
time of mutation.§ 2. If the property is transferred with reservation of usufruct, the mutation shall
not be done; however if the ownership and usufruct are transferred to different persons, the
mutation shall be done first making clear reference to his statue as usufructuary and mutation in the
name of the owner shall be done only when the ownership is merge with the usufruct.§ 3. However
the property, fulfilling the requirements of the paragraph 1, may be mutated when by a judgement of
Civil Court, that has become res judicata, either the ownership of the property was acknowledged to
the applicant or given mere possession.Article 227.When the total value of the properties involved in
favour of a solitary person, either as mandatory heir or legal heir, does not exceed 3000$, and there
are no other assets in the state, the mutation shall be carried out if the interested party establishes
their local standard, after following the formalities prescribed in the paragraphs 1 and 2 of the
article 25. In addition it shall prove the value of the property based on the certificate of the revenue
records that the tax was paid and in the event that no name is found in the revenue records, opinion
of the president of the managing committee and of the clerk of the Comunidades could be a
substitute.Sole § However the public notice, shall be issued making reference to the caption to the
detailed record of properties which shall contain, besides the name and address of the transferor,
the name of property, its location and properties and its boundaries, name and address of
transferring person and the capacity in which transferor so qualifies.Article 228.The mutation of
one property in the name of more than one possessor is not allowed, as the mutation of many
properties with the foro of all the properties together, is prohibited in the name of one
possessor.Article 229.The provisional mutation in the name of head of family is allowed upon
proving by a certified copy obtained from a pending inventory, and also in the name of the head of a
family society, on production of an authentic document proving that such society has been legallyCode of Comunidades of 1961

constituted.Section IIIDivision of property and proportionate division of foroArticle 230.The
division of properties and proportionate division of foro of the properties mutated or to be mutated
in the Register 2 - (Tombo2) is mandatory in the following cases:-When the property is mutated in
the name of many persons and there is no indication as to the foro for each person;When several
properties are mutated in the name of single individual and there is no indication of the foro for
each property;When one part of the property mutated is transferred or the entire property is
transferred in parts.Article 231.The division of foro and proportionate division of the properties, in
the case of clauses 1 and 3 of the preceding article, shall be made in the following manner:-
1. If the authentic document does not indicate which part belongs to each
person, the division shall be made in equal parts, as if all are possessors of
the equal part of the property;
2. If the part belonging to each person is a certain share of the whole
property, the division of the foro shall be made in the proportion of the
shares of all of them;
3. If the share of each person is known and not being a fixed part of the entire
property, the interested parties shall agree between themselves on the
division of the foro.
§ 1 Only in the case of the clause 3 the managing committee shall be heard and, when it agrees with
the division made, the foro for each part shall be that fixed by the interested parties.§ 2 If the
interested parties fail to reach an agreement between themselves on the division of the foro, or the
managing committee does not agree in the effort made by the interested parties, the said committee
shall propose the share to be borne by each party and the administrator shall determine the share of
foro to be assigned to each part of the property, when he is able to get the information regarding the
value of each fraction.Article 232.The division of foro and proportionate division of the properties in
the case referred to in clause 2 of article 230 shall be made in the proportion to the value of each
property, by applying to each of these the share that is due, according to his value.Sole § The value of
each property shall be fixed in accordance with Article 227.Article 233.The documents required to
effect the division of property and proportionate division of the foro shall be produced by the
interested parties and, when they fail to do so and foro is needed to be separated to regularise the
Tombo 2, those documents shall be officially obtained by the clerk of the Comunidades and its cost
charged on the same interested parties in its current accounts to be collected in execution
proceedings, as per Title V, in case they do not pay voluntarily.Article 234.After the division of foro
is done in the manner indicated in the preceding articles, the share due to each part in the property
or in each property, shall be increased by 5 per cent, and rounded up or down to the nearest centavo
resulting from the operation, and once increased it shall remain as a charge in future on the party or
properties whose foro has been separated.§ 1 The increase of five per cent affects not only the part or
the properties transferred by a possessor, but also the other part or the other properties that
continue registered in the name of the transferor, as it is in the case provided for in clause 2 ofCode of Comunidades of 1961

article 230.§ 2 When, after the division of foro and proportionate division of the properties is done,
as per this article, it is verified that the foro resulting of any property or its share is below 12$, those
liable to pay the said foro shall obligatorily redeem the same, by paying the instalments or annuities
and plus the annuity relating to the year of remission, independently of the order of the
administrator, proceeding further as laid down in the paragraphs of article 238.Article 235.The
division of foro and proportionate division of the properties in manner prescribed in this section is
mandatory not only for the first divisions of the property but also in the successive
sub-divisions.Article 236.Every time when the division and separation of foro is carried out, the
clerk of the comunidade, within eight days, shall send to the administration office a statement
indicating the name of the property and its possessor, the foro that is payable, the pinto which it was
divided, the share corresponding to each part with addition of the 5 per cent, and the name of the
person in whose favour it stands registered, in order to be taken into account at the time of approval
of balance sheet of income and expenditure.Sole § The clerk, who fails to comply with what is
prescribed in this article, shall incur a fine of 18$, imposed by the administrator, for each default
committed.Article 237.After the separation is done, the clerk of the 'comunidade' shall cancel the
previous mutation of the property in the Tombo 2, by opening a new one and indicating in this, the
foro that shall be payable subsequently.Section IVRedemption of foroArticle 238.The redemption of
the foro of the emphyteusis of the Comunidades or of any periodical payments that the
Comunidades receive from the proprietors, servants or other individuals under the article 6, shall be
applied to the clerk of the comunidade, requesting that the amount may be calculated and received,
mentioning in the petition the nature and the burden thereof of which redemption is asked for.§ 1
The clerk, within the period of eight days and under his responsibility, shall calculate the amount of
redemption. This shall be recorded on the reverse of the application, adding to the sum, the
outstanding annuities due to the comunidade.§ 2 The amount payable for the redemption is the sum
of twenty annuities of the foro or burden whose redemption is intended, plus the annuity relating to
the year of redemption, when it is not done, with effective payment, by 31st March.§ 3 The
application shall then be returned to the party, who has to effect the payment into the safe of the
amount calculated.§ 4 At the time of payment, the clerk of the 'comunidade' shall mention below the
calculation set out in the application the following note: "The above amount was paid on this date,
by item no........., mentioned at pg........ of the Cash Book No.... and noted the transference in the
corresponding entry in the Register 2, No......"§ 5 The application containing the calculation and
note referred to above, shall remain in possession of the interested party, who shall return it to the
clerk no sooner he obtains the certified copy of the redemption's effected, with the designations
contained in the respective lists, wherein reference is made to the payment effected.Article 239.The
redemption of foro below 12$, is mandatory and this should be done within 12 months, from the
publication of this Code relating to emphyteusis granted earlier, and from the date of the final
possession given in respect of the future grants.Sole § The redemption referred to in the body of this
article may be applied for by any person, without thereby acquiring any title by this fact.Article
240.The certified copy that referred to in the paragraph 5 of article 238, after countersigned by the
administrator, is a sufficient document for the registrations and annotations in the competent land
registration office.§ 1 The certified copy shall be issued independent of the administrator's order, but
those wishing to obtain the certified copy urgently, shall give to the clerk, at the time of payment, the
required stamp paper and the clerk of the Comunidades is bound to declare, in this case, under the
note written in the reverse of the application, the number of pages and half pages given to him andCode of Comunidades of 1961

issue the certified copy within five days immediately after the payment.§ 2 At the time of auditing
the accounts, the clerk shall be held responsible to the Comunidades or to the parties, to whom they
shall compensate for the amounts that may have received less or in excess. To facilitate this
verification they shall present in such act the applications that may have been returned by the
parties.§ 3 In the ordinary meetings of the managing committee there shall be, in each comunidade,
whenever necessary, an ordinary opening of the safe, meant for the collection of the amounts
corresponding to the liquidations done in the preceding month.§ 4 Any applicant may request the
extraordinary opening of the safe to receive the capital of the redemption. In this case opening fees
shall be deposited with the clerk of the comunidade.§ 5 The clerk shall send to the respective
administration office, within forty hours of each opening of the safe, a report of redemption effected
on such occasion, with all the necessary details in order to verify if calculations and payments
conform to the corresponding certified copy.§ 6 The price of redemption may be paid, in full or in
pin shares of the same comunidade, at the market price, fixed by the administrator, after hearing the
managing committee.§ 7 The shares shall be endorsed by the respective proprietors in favour of the
comunidade, mentioning expressly in the endorsement of redemption or redemptions to which they
apply.The presenters shall take with them the necessary amount to pay the stamp duty and
registration fees for endorsement and annotation, without which they shall not be accepted.§ 8 Two
or more individuals may present, in common, one or more shares for the payment of the price of
redemption of the charges related to two or more properties, provided that such use of shares does
not result in a positive balance in favour of the respective proprietors.§ 9 In the register of share
holders, the clerks shall make the mutation of shares in favour of Comunidades and cancel from the
mutation the name of the transferor, obtaining previously from the administration office the
annotation of shares, for which they shall present or send to the administration office the shares
along with the amount received as deposit for the stamp duty and fees. After the inscription is made
the shares shall be kept in the respective safe.Article 241.After the redemption, when this is of the
entire foro or of the other charges regarding the property, the clerk of the Comunidades shall cancel
the mutation of the same property made in the Register -2 (Tombo 2), and when only of a part of the
foro or charge, have been redeemed, necessary note of the same is made in the registration of the
property, reducing its foro or charge to the part that has not been redeemed.Article 242.The claims
for payments in instalments shall not be attended to, but redemptions of part of foro or any other
charges shall be permitted. However the properties on whom partial redemptions have been made
shall remain burden in the same way by the remaining charge or part of the charge.
Chapter III
Ordinary auctions
Section IEstimate or evaluation of items of revenue and items of expenditure in generalArticle
243.All ordinary auction of the properties, works, services and agreements of the Comunidades shall
be preceded by an estimate or evaluation, organized as per the instructions of the respective
managing committee, observing the following provisions.Article 244.The managing committee shall
call the [camotins] [Camotins- were inspectors of paddy fields.] and [painis] [Painis- were
supervisors of the paddy fields.] for ordinary meeting of the month of April and, after hearing their
views , shall give instructions to the clerk of the Comunidades to prepare the estimate and theCode of Comunidades of 1961

clauses of the auction, recording the same in the respective minutes.Article 245.The assessment
shall be done on the basis of the following clauses:-
1. For the rent of the palm groves and any other sources of income, the
average of the rent obtained in the last three trienniums;
2. For the amount payable for the services and works, the estimate prepared
by the managing committee, or with the assistance of technical staff,
whenever justified, in view of importance of service and work;
3. For the expenses of other items of expenditure, the average of the cost of
last three years;
4. For the ordinary income and expenditure which may not have been
auctioned in the previous years, what the managing committee may fix, after
getting the views of the officials mentioned in the previous article and, if
necessary, one or two experts, familiar with the specialities and chosen by
the managing committee.
§ 1 The opinion of these technical staff, officials and experts shall be recorded in the minutes that
refers to in the previous article, forming part of the instructions that the committee shall give to the
clerk of the comunidade.§ 2 Any clauses established in the assessment which are contrary to the
provisions of this Code, are null and void, and the managing committee and the administrator shall
be jointly and severally responsible for the damages that may result to the Comunidades or to the
private parties.Article 246.Based on the instructions given by the managing committee, the clerk of
the Comunidades shall prepare, with the intervention of the attorney, the estimate, in a form of a
chat, mentioning therein the coconut garden, cashew garden, land for cultivation of vegetable, lands
for the cultivation of pulses, saltpans, building properties, lagoons and rivulets for fishing and any
other sources of income.§ 1 In the same chat, after entering the items of the income, it shall follow
the items of expenditure, such as construction works, repairs of roads leading to paddy fields,
services and others.§ 2 All the items shall have a number in sequence, with reference to the
numbering of previous assessment, its special denomination and the rent, premium or price for
which they are to be auctioned.§ 3 Following the above listing, the clauses of bid in relation to each
type shall be written, those necessary for the purpose of preparatory work and for preparation,
ploughing and maintenance of bunds and dykes, conservation of planks, contrivances, outlets,
reservoir, distribution of water, fishing and other services.Article 247.The estimate shall be
completed by 21st April, signed by the attorney and clerk, and shall be kept for the examination of
the interested parties in the archive office till the first Sunday of the month of May, on all working
days and during the office hours. The interested persons may propose, in writing and on a plain
paper, any alterations, which shall be handed over to the clerk of the Comunidades or in the
administration office of the Comunidades, which in the latter case shall forward them, within twenty
four hours, to the clerk of the comunidade. The estimates and alterations shall be examine in theCode of Comunidades of 1961

following manner:-(a)The managing committee shall meet in session on the first Sunday of May and
the clerk of the Comunidades shall present for its examination the estimate and all the proposals for
revision that may have been received and that the committee shall accept or reject, correcting in the
first case the estimate and the clauses, as per the proposals adopted and the rules as deem fit to
apply, by recording all in the minutes, as well the reasons that justify these changes;(b)On the first
Sunday after the meeting of the managing committee, the Comunidades shall meet, in continuous
and uninterrupted session, convened by way of notice affixed, three days in advance, on the door of
the meetings hall and of the temples of any religion existing in the village and by way of cry made in
the places that may have been indicated and, after examining the estimate and the clauses, after
introduction of the changes made by the committee, shall approve or modify the same as it thinks
fit, by recording every thing in the minutes.Article 248.The clerks of the Comunidades shall present
the estimate in the administration office by 25th May, with the modifications done in terms of
sub-paragraphs of the preceding article, and the administrator shall confirm or alter the same,
solving all the disputes that may have been raised, by 15th June, applying the penalties established
in the Code to the clerks of Comunidades and agents for the breaches of the rules that may have
incurred and handing over the estimate by end of the period fixed to the respective clerks of the
comunidade.§ 1 In the case of works or services, the administrator shall consult the technical person
before giving his final decision.Article 249.Soon after receiving the estimate, the clerk of the
Comunidades shall make a note in the margin indicating the alterations made by the administrator
and within a period of five days, that cannot be extended, present it again to the administrator, who
after verifying if it is in order, shall approve, handing it over to the clerk by the 25th of the same
month of June.Sole § The administrator who does not observe the period fixed on the body of the
article shall incur the penalty of 600$ for each default.Article 250.The clerk of the Comunidades
who does not fulfil the rules and the time limit prescribed for the operations of the estimate, shall
incur the penalty of 300 $ for the first default and twice of this penalty for each subsequent
violation.Article 251.The estimate, once approved by the administrator, comes into force
immediately, but against the decision of the administrator lies an appeal, which does not stay the
execution, to the Administrative Tribunal.Article 252.The estimate and the maps of the fields to be
auctioned shall be displayed in the meetings hall during office hours on the two days prior to the day
of auction, to be examined by the interested parties, to whom the managing committee or the clerk
of the Comunidades shall provide all information and clarifications.Article 253.All the fields
belonging to the private owners, who make use of the irrigation works executed by the comunidade,
shall pay in the month of November of each year, to the same Comunidades a charge fixed by the
managing committee and approved by the administrator, which shall not be higher than the one
that the State receives on account of waters of the 'Channel of Paroda' nor below 50 per cent of that
charge, same charge being applicable for the contracts previous to the publication of this Code.§ 1
After the charges have been calculated, the private owners shall sign before the managing committee
a declaration that they wish to utilize the water and undertake to pay the said charge, and this
declaration shall have effects till it is not modified or revoked by another.§ 2 The operator of water
supply of the irrigation work does not have right to any payment in money or kind, besides the
auction premium.Article 254.The extraction of earth from the fields of the Comunidades is expressly
forbidden , without prior authorization of the managing committee granted in a meeting, on verbal
request of the interested party, and approved by the administrator, to whom the copy of the minutes
shall be submitted by the clerk of the comunidade, within the period of five days.Sole § ThisCode of Comunidades of 1961

prohibition does not include the earth that may be extracted for the repairs of the bunds existing in
the paddy fields or for the repair of the borders of properties bordering upon the paddy fields, in
which cases the interested person shall inform the fact in advance to the clerk of the comunidade,
who shall bring the same to the notice of the attorney for him to supervise.Article 255.The managing
committee shall authorize the extraction of the mud from the subsoil, only in the paddy fields of the
Comunidades that have a level higher than that of the adjacent field, for the following purposes:
construction of houses, manufacture of artefacts of clay and repair of borders and improvement of
the bordering private properties, when there is no encroachment of adjoining land belonging to the
Comunidades.Sole § The rental for the extraction of clay earth for the making of clay artefacts shall
be entered in the estimate of the income and put out for public auction.Article 256.The respective
lease holder is bound to complain against any extraction of ewhich has not been authorized by the
managing committee, in terms of preceding articles, under penalty of being responsible for the
transgression, along with the offender, and the managing committee, on verifying this fact, shall
authorize the attorney of the Comunidades to bring to the notice of the "Ministerio Público", for the
purposes of criminal proceedings, failing which its members shall incur a fine of 300$.Section
IILicitationArticle 257.All the bids and contracts, either of income or expenditure, shall be auctioned
by the managing committee and granted to the suitable bidders, who shall deposit earnest money in
terms of Section III of this Chapter.Article 258.The auction or [licitation] [The word -'Licitation' is
defined in the Blacks Law Dictionary.], annual or triennial, in each Comunidades shall be carried
out between 1st to 31st July and shall end by 31st October.Sole § The administrator of Comunidades,
may authorize the extension of the period for the finalization of the auctions, on proposal of the
managing committee, whenever he finds that the reasons submitted are acceptable.Article 259.The
lease period of the source of income of the Comunidades shall be, as a rule, of three years and in
special cases however, the same period can be extended for nine years, whenever the Comunidades
acknowledge the necessity of useful improvement to be made before the preparation of the estimate,
and in such cases, a special clause shall be inserted dealing with such improvements in the
properties.§ 1. When the Comunidades has coconut gardens, the auction of these shall be for a
period of nine years, subject to special conditions in the estimates.§ 2. The auction of items of
expenditure will be yearly.Article 260.During the auction the items of income shall have precedent
over the items of expenditures and shall be carried out during five hours every day on the days fixed
and duly announced, starting at 10 hours, when they are held in the respective village, and at 11
hours when held at the administration office of the Comunidades.Article 261.The extraordinary
auctions of the perished trees and of the old wood of the gates shall be done by way of notices issued
eight days in advance and cries in the village on the previous day. The same shall be preceded by
estimate drawn by the clerk and the attorney of the Comunidades and approved by the managing
committee.Article 262.The ordinary annual or triennial auctions shall be made public by way of
notices affixed ten days in advance -one on the door of the meetings hall of the Comunidades and
the other to the door of the temples of any religion existing in the village.§ 1. A notice shall also be
published in the Official Gazette or in any newspaper of the taluka, if any.§ 2. The notice shall
specify the item to be auctioned , the place, the time and day of the auction.Article 263.The meetings
of the managing committee, for auction or licitation shall be continuous and without interruption,
without exception of holidays, inclusive religious ones, until all the items are auctioned.§ 1. The
auction shall be conducted in the order by which the various lots and items have been listed in the
estimate. All those whose licitation prices are the highest shall be awarded to the highest bidder.Code of Comunidades of 1961

Only those on which there is no competition or request for auction, shall be reserved for new
auction.§ 2. Each lot or bid shall be called in a loud and in an audible voice and concluded, with the
highest bid, with a previous declaration repeated three times, that the same shall be closed as per
express order of the president of the managing committee, after which no further bid or any price
shall be accepted.§ 3. Once started, the auction can be suspended only by determination of the
Governor General and in any case, when re-starts, it shall be announced five days in advance.§ 4.
The award of each lot or item shall be certified by a declaration signed immediately, following the
award in the open auction, in terms of the paragraph 1 of article 533 and model No. 13, mentioning
at the end of the declaration, the items not awarded, with the indication of the respective numbers.§
5. Only one declaration can be drawn up of the items not auctioned, when they are listed one after
the other.Article 264.The following is expressly prohibited:-
1. Joint award of one item to more than one person;
2. To finalize, in group, more than one item in favour of only one individual,
though he may offer greater advantage;
3. To accept a bidder who offers to provide some service by paying some
sum to the Comunidades ('savanzonvom');
Sole § The following persons are disqualified to bid in the auctions, directly or through a third party.
1. The debtors to the Comunidades or its subrogates, adjudged as such, or
against whom action or execution proceedings are pending or even against
whom a current account has been issued;
2. In the case of works and services, those who, by decision of the
administrator, or the director of the Public Works and Transport or of any
other entity, designated by the Governor General, may have been disqualified
to compete for execution of the works having given proofs of incompetence
or to have used fraudulent means in the execution of contract works that
may have been awarded or entrusted, or who may have been found to be
defaulters for more than one time, due to deficiency in the works executed by
them.
Article 265.Auction or self cultivation of Comunidades land is forbidden in case of following land :-
1. The lands reserved for easement of the neighbours;Code of Comunidades of 1961

2. The lands necessary for cattle grazing ;
3. The lands here marked for threshing and other necessary work for
cultivation or protection of the fields.
Article 266.The items that remain to be auctioned during the first auction, referred to in the article
257, shall be announced again for auction, in terms of paragraph 3 of article 263, with the price
being changed upward or downward, as the items are for the expense or revenue, as determined by
the administrator, within the period of five days, based on the opinion of the managing committee
given on the last day of auction. The administrator may decide about any other form which he thinks
convenient for the interests of the Comunidades and the clerk is bound to give publicity to the
decisions taken by higher authorities.Sole § In cases of auction of works or services of maintenance
of embankment and other expenditure work of the fields, only the increases indicated by the
technical personnel, duly justified, can be considered, and if, even with these increases, there are no
bidders, the services or works shall be executed by direct administration.Article 267.After the
auctions are over and after the totals of the income and expenses awarded have been added up,
indicating its source, the clerk of the comunidade, along with its attorney, shall write the closing
declaration, mentioning, in words, the respective total, and shall present the books to the
administration office, within eight days, under penalty of a fine of 120$, to enable the administrator
to give his approval.§ 1. The administrator shall give his approval, within the period of thirty days,
from the date of submission of the books, and this approval shall be recorded in the entry book of
the administration.§ 2. There shall be no appeal against the order approving the auctions.Article
268.The administrator shall decline suo moto to approve the auction when he detects irregularities
which involve nullity of the contract, approving the portion not affected by the defect.Article
269.The order refusing the approval depends upon the confirmation by the Administrative
Tribunal.§ 1. The administrator, on his own initiative within eight days, shall inform of the refusal of
the approval to the Administrative Tribunal, sending to the said Tribunal copy of his order and all
the documents and elements justifying the refusal.§ 2. In case of a complaint against an irregularity
in the auction within the period stipulated for the approval, the administrator shall refer it to the
Administrative Tribunal within the time limit and in the manner indicated in the relevant portion of
the previous paragraph, and shall not approve the amount or amounts covered by the complaint.§ 3.
Once the file is received by the Administrative Tribunal, the same shall be allotted, in the first
session after its receipt, and shall be finalized and sent, within twenty four hours, to the reporting
member, who shall present it in the first session after sending for trial, independent of circulation
for the approvals and the judgement shall be pronounced soon thereafter.§ 4. The secretary of the
said Tribunal, within forty eight hours from the decision, shall send the copy of the judgement to the
administration office of the Comunidades.§ 5. The administrator who, in the prescribed period, fails
to refer to the Administrative Tribunal the papers relating to the refusal of approval, shall be
punished with the fine of 300$, imposed by the same Tribunal in the respective judgement.Article
270.If the Administrative Tribunal confirms the refusal of approval, the administrator, within
twenty four hours after the receipt of the copy of judgement, shall fix the date for the new auction of
the lot or lots, the adjudication of which have been annulled.Sole § The administrator who fails to
comply with what is prescribed in this article shall be punished with a fine of 300$ and shall be
liable for the damages and loss that may have been caused.Article 271.The auction after it is closedCode of Comunidades of 1961

with the approval, shall not be rescinded nor amended on any ground.Article 272.After the triennial
auction is approved, the clerk of the Comunidades shall send to the administration office, within the
period of fifteen days, a list of all items, with the amount of rent of each one, which shall be sent to
the respective revenue office in order to settle there the matter of the stamp duty on rent.Section
III[Security] [[Section 436 of the Portuguese Civil Procedure Code.Section 818 of the Portuguese
Civil Procedure Code.]]Article 273.No bid of item of revenue or expense contract shall be awarded in
the auctions without execution of a proper bond and unless its fitness is satisfied and accepted by
the managing committee before finalizing the contract.Sole § The decision of the committee
rejecting the guarantee furnished shall be duly substantiated and recorded, in the minutes of the
auction.Article 274.Against the decision of the committee rejecting the guaranty offered, irrespective
of its nature or quality, an appeal shall lie to the administrator of Comunidades, who shall decide
within the shortest possible period, as per the following procedure:(a)The appeal shall be filed in a
simple application, supported by all the documents of proof, addressed to the administrator of
Comunidades and presented, within three days from the auction, to the clerk of the comunidade,
who shall issue the acknowledgement receipt, or in the administration office, from where it shall be
forwarded to the clerk of the comunidade;(b)The clerk, after recording the date and time when the
appeal was received, shall forward the same to the administrator, within forty eight hours and
without expense to the party, with the copy of the minutes of the auction, concerning the portion
referred to in the auctioning of the lot and to the bond furnished by the appellant;(c)The
administrator, shall conduct the enquiry that he may find necessary and, decide the appeal setting
out clearly his reasons, within forty eight hours after the receipt of the information requested, or ten
days after the receipt of the appeal;(d)The administrator on the same day of the decision of the
appeal or on the next day, shall inform the clerk of the Comunidades about his decision, for him to
notify the managing committee, that shall comply with it immediately, and to the respective
appellant.Article 275.An appeal, which will have no effect on the execution, shall lie to the
administrator of Comunidades against the decision of the committee accepting the surety, brought
up by any interested party or representative of the comunidade. This appeal shall be filed within
three days from the acceptance.Article 276.The decisions of the administrator in the matter of
guaranty are subject to appeal, which will have no effect on its execution, shall lie to the
Administrative Tribunal.Article 277.The appeal to the administrator against the refusal of surety by
the committee may be presented, on plain paper, and shall not be subject for payment of cost, but
the appeal to the administrator against the acceptance of the guarantee by the committee, as well as
the appeal against the decisions of the administrator, to the Administrative Tribunal shall be subject
for payment of cost at the end by the loser.Article 278.The administrator, who does not obey, with
the time limits established in the preceding provisions, and the members of the managing
committee and the clerk of the comunidade, who fail to give prompt execution to the decision of the
appeal, shall each one, incur a fine of 3000$. Besides this the agents, who are employees, shall be
subject to disciplinary action.Article 279.The guaranty can be provided by surety, mortgage, cash,
deposit or pledge of objects of gold, silver and shares of comunidade.Sole § No surety by pledge shall
be accepted from bidders of works, services or supplies whose price exceed 1800$.Article 280.The
guarantors are always the principal payers and, in the case of their insolvency, the members of the
managing committee shall be jointly and severally responsible for the obligation guaranteed to them
or for the part which remains due, after execution of the properties of the bidders and their
guarantors.Article 281.When the guaranty consists in pledge of objects of gold or silver, these shallCode of Comunidades of 1961

be, at the time of auction, weighed and estimated by the goldsmith, designated by the president of
the managing committee and paid by the bidder, and kept in the safe of the comunidade, after being
conveniently packed in a box or in a bundle closed and sealed with wax seal, with signature or seal of
the clerk of the Comunidades and of the bidder or of the person indicated by him, everything being
recorded in the minutes of adjudication, which shall be signed by the goldsmith and by person
chosen by the bidder.Article 282.When the guarantee provided is by way of shares of the
Comunidades which are registered in the name of the bidder or any other, its value shall be the one
indicated by the quotation at the time of the offer, minus one third, and in the minutes of bidding,
those shares shall be conveniently identified and kept in the safe of the comunidade.Article
283.When the guarantee, for rental of properties, is provided by deposit of money, pledge of objects
of gold or silver or of the shares, which shall be preserved in the safe till the end of the period of
contract, the amount equivalent to the pension and contributions for one year plus one fifth, shall be
sufficient.Article 284.In the lease of rustic properties, besides the guarantee, also the fruits and the
products of respective items shall be acceptable as guarantee for the pension.Article 285.In the
items of the expenditure of the Comunidades and of the services and supplies, the value of the surety
shall be set in the evaluation or in the respective proceedings.Article 286.The lot auctioned and not
awarded because the guarantee offered was not accepted, shall be awarded to the other bidder, if
any, recording soon thereafter, the declaration of provisional auction, mentioning therein all the
facts that took place and the names of the bidder and his guarantor, whose guarantee was rejected
and the price offered.§ 1. If no appeal was filed or if filed, it was rejected, the provisional declaration
of auction shall be converted in definitive, and the clerk of the Comunidades shall note such
conversion at the margin of the respective declaration in red ink, and this note shall be
authenticated by the managing committee.§ 2. If the appeal is accepted, the clerk of the
Comunidades shall make in the margin of the minutes, the competent marginal note in respective
declaration, and consequently the lot shall be let out to the appellant for the price offered,
transcribing the same in the respective column, in red ink, and cancelling the one of the provisional
lease, also in red ink. This marginal note shall be authenticated by the respective managing
committee.§ 3. When the managing committee does not admit the guarantee for being unsuitable
and the bidder being only one, the declaration of provisional auction shall be written, indicating all
the circumstances and this shall be converted into definitive, in case the appeal is accepted.
Otherwise it shall be cancelled when the appeal is rejected or when the party fails to appeal and in
this last circumstance, the clerk of the comunidade, soon after the expiry of the period, shall
announce a new auction, observing the legal formalities.§ 4. The note, either of the conversion of the
provisional adjudication into definitive, or of its cancellation, shall be recorded, in red ink, and
countersigned by the managing committee in the margin.Article 287.In case of surety consisting of
mortgage of immovable properties the bidders shall waive the venue of the location of these
properties, when situated out of the respective judicial division.Section IVTransfer of contractArticle
288.Any individual to whom any item of income or expenditure has been awarded by auction he
may transmit it to the third party or to the very surety.§ 1. The transfer shall be recorded by the clerk
of the Comunidades in the competent book, with the consent of the managing committee and with
new guarantors, when the ones from the auction do not want to guarantee the transfer or these
transfers are made to guarantors themselves.§ 2. Those who are empowered to bid for auction have
also right to be transferees, although, the transferors shall be liable, on a subsidiary basis, to the
Comunidades for the obligations under the respective contract.§ 3. No transfer shall be made byCode of Comunidades of 1961

dividing the item during the course of the auction or in the actual declaration of award.Section
VEviction of tenantArticle 289.Without prejudice to any other penalties that may be imposed under
the clauses of the respective contract, the lessee of the properties and the bidders of the services,
works and other items, may be evicted by the administrator, on the proposal of the managing
committee, after they have been heard on the point of breach of their contract and shall be liable to
pay to the Comunidades any difference that may be for less in the rent or for more in the price,
according to the result of the new auction of the respective item, which shall proceed as per the
formalities prescribed for the auctions in general.Section VIDamages and chargesArticle 290.The
following are called charges :-
1. The liability imposed on the guards, in conformity with the clauses
previously agreed upon on account of the value of the produce that is
diverted from the properties, of the rent and of the damages caused to the
same;
2. The liability imposed to members of the Comunidades and to the holder of
aforamentos of the Comunidades on account of breach committed against
the provisions of this Code or the clauses stipulated by the comunidade;
3. The liability imposed by higher authorities against all those who have
current accounts in the comunidade.
Sole § The absence of the charges against the guards on the part of the treasurer of the managing
committee does not exonerate the leases of the Comunidades of the obligation to pay the rent and
the contributions due.Section VIILease of paddy fieldsArticle 291.The paddy fields of the
Comunidades shall be leased by means of public auction, for the period of six years.Sole § This
system shall come into force from the year 1962.Article 292.The auction for the lease of paddy fields
shall take place from 1st July to 30th September of the year immediately preceding the period to
which it is intended for and shall be held in the meetings place of the comunidade.§ 1. The basis for
licitation shall be calculated in kind (rice), in the quantity of rent indicated in the respective
estimates in force and expressed in cash, as per official price fixed by the Governor General, on
hearing the Directorate of Economic Services, of the Board of External Trade and of the
administrator of Comunidades.§ 2. The estimates of the paddy fields may be reviewed periodically in
the manner directed by the Governor General by an executive order, but the revision made in this
manner shall only be applicable in the auction for the next period.§ 3. The clauses which govern the
lease shall be prescribed by the managing committees, on the approval of the administrator, after
hearing the head of the agricultural division or agricultural zone.§ 4. It is the duty of the managing
committee and specially of the attorney and the clerk of the Comunidades to supervise the
compliance of the clauses of lease, less they shall be responsible for the losses and damages. Similar
powers are vested on the personnel of agricultural divisions or agricultural zones, but only in respect
to cultivation and its preparatory works.§ 5. In the harvest season, under the proposal of the
managing committee, approved by the administrator, necessary guards shall be admitted to workCode of Comunidades of 1961

under the orders of the attorney, receiving the salary that, for each season, is fixed by the
administrator, up to the limit of 18$ per day.§ 6. The conditions of the supervisory duties of the
attorney and of the guards shall be stipulated in the respective estimate.Article 293.The rent payable
by the lease holders shall be paid in cash, comprising the amount offered in the auction bid,
increased by amounts foreseen in the estimate, in relation to the subsidiary crops.Article 294.The
auction, to be announced in advance, shall be held in one or more rounds.§ 1. At the first bidding,
only the cultivators who have actual residence in the village, for more than two years, may
compete.§ 2. If at the first bidding there remain lots without being taken in auction, the same shall
be auctioned at the second bidding, to which the cultivators of the village of any taluka may
compete.§ 3. If still there are vacant lots, the same shall be auctioned in the third and subsequent
sessions, with a reduced base price, as per article 266, to which all or any cultivator may compete,
independently of the limit foreseen in article 296, after the third bidding.§ 4. In the auction, each
bid shall not be lesser than 6$.§ 5. In the absence of bidders in the case envisaged in the paragraph
3, the lot shall be given through private negotiations for any price and for one year, being again put
up to public auction in the subsequent year.§ 6. The lease holder who has cultivated the lot in the
previous year, even if he has no actual residence, in the last two years, in the village of the
comunidade, shall have right to option in the first and second bidding, at the time of auction, soon
after the price of bid is finalized unless he has been punished under article 300.Article 295.Only the
cultivators can take on lease the paddy fields of the comunidade, but in no case, they shall sub-let
the same, enter into on partnership or enter into any contract or service, on the pain of the contract
being rescinded and to a fine equivalent to double the rent and equal fine being imposed on the sub
lessee.Sole § For the purposes of the provisions of this article, cultivator means the one who
cultivates the field personally, or with his family members, relatives, or with workers paid by
him.Article 296.Each cultivator can only take on lease one or more lots whose total gross production
does not exceed 20 [candils] [Candil - A measurement of capacity of 20 curos and one curo is
equivalent to 8 litres.] of 160 litres each, when the number of his family members is not more than
five, to 25 candils when that number does not exceed eight and to 30 candils when the family
members exceed more than eight, on the pain of the contract being nullified.§ 1. A tolerance up to
one candil may be permitted safeguarding also the case in which a single lot has production beyond
the limit fixed.§ 2. On the recommendation from the administrator, at least ninety days prior to the
auction, the Governor General can reduce the limit fixed in the body of this article, in the
Comunidades when there is a justified need of better distribution of the fields.§ 3. For the purposes
of restriction foreseen in this article, it shall be taken into account the production of the paddy fields
of the cultivator itself and his family or even of the paddy fields of other individuals singular or
collective, taken on rent by them.Article 297.The allotment shall be done, without need of any kind
of bond or special guarantee, as the produce itself shall be the guarantee for the payment of rent,
unless if the lot or lots may have been auctioned with an increase higher than 30 per cent of the
starting price, in which case, guarantee shall be demanded, in terms of section III.Sole § When two
or more lots, have been allotted to a cultivator, the fruits of each of the lots and of all together, shall
guarantee for all the rent due.Article 298.On account of the non the payment of rent, within the
period of the contract, the lessee shall be subject to the following penalties:(a)During the first ten
days, a daily fine of 6$, up to the limit of 25 per cent of the rent, which shall be collected along with
the rent;(b)If the payment is effected with delay up to 30 days, with fine of 12$ per day, to the limit
of 50 per cent of the rent, which shall be collected in terms indicated in preceding clause;(c)After 30Code of Comunidades of 1961

days without the rent, being paid the managing committee shall immediately proceed to the seizure
of the produce and sell it in public auction, entering the price in the safe, till the corresponding
amount of the rent, fine and increases is met, depositing the remainder in favour of the leaseholder ,
unless a bond has been provided in terms of the final part of article 297, in which case the same
bond shall be broken and by its value paid the rent, fine and further increases, and the contract shall
be terminated.(d)Whenever the produce is withdrawn and the bond has not been furnished, a fine
equivalent to the value of the rent, convertible into prison at 20$ per day till the limit of two years,
in case of not being paid voluntarily within ten days, and termination of the respective
contract;(e)The guard of the respective paddy field who allows the produce to be lifted without
taking measures to obstruct the lifting, incurs in the fine foreseen in the previous clause.Article
299.If the lessee does not cultivate the lot or lots, he shall incur a fine equivalent to the double the
rent , convertible in prison, in case of non-payment within ten days, at the rate of 20$ per day, in
addition to the rescission of the contract.Article 300.If the lessee does not execute the preparatory
and other works, in the periods and in the form that may have been fixed in the clauses of the lease,
or does not cultivate the lot or lots, in terms prescribed in the conditions of the lease, he shall be
subject to pay a fine equivalent to half of the rent, without prejudice to the payment of the
rental.Sole § The time limits referred in this article can be extended by the administrator, after
hearing the respective agricultural authorities or zone.Article 301.The lease of the paddy field of the
Comunidades in not determined on the death of the lessee, if survived by the spouse not separated
of persons and properties judicially or de facto, or descendants or ascendants who had lived with
him at least for one year.§ 1. The transfer of the right of lease established in the body of this article is
done in the following order:(a)To the survived spouse;(b)To the descendants, the near ones having
preference;(c)The ascendants, the near ones have the preference in the same manner.§ 2. The
succession in favour of descendants or ascendants of the original lessee shall also take place on the
death of spouse of the latter, when in terms of this article such right has been transferred to such
spouse. This second transmission can only be made in favour of the persons who had lived with the
spouse of the lessee at least for a year.§ 3. The renewal of the contract of lease shall be granted by
the administrator of Comunidades, on the application of the interested party, made within the
period of 30 days from the date of death of the lessee. The decision of the administrator shall be
subject to the approval of the Governor General.Article 302.Without prejudice to the provisions laid
down in the previous article, the lots which became vacant by the death of the lessee or for any other
reason, shall be awarded by public auction for remaining period of six years. But if there is justified
urgency it shall be awarded by private negotiations, announced by cries given, with the antecedence
of three days, however in the following year the procedure prescribed in the first part of the article
shall apply.Sole § The provision of this article shall be applied equally to the situation foreseen in the
article 299.Article 303.For the purposes of article 296 and its paragraph 3, the interested party shall
submit to the managing committee, prior to the auction, a note indicating the number of family
members and whether the former or the latter possesses paddy fields or cultivate those of other
persons, sole or collective entities, with the respective production as per the estimate, when the
paddy fields are of the Comunidades or if not as per the records of matriz. Any false declaration
given shall attract penalty provided in the article 242 of the Penal Code (Código Penal).Article 304.It
is permissible to give each lot on lease or through a private negotiation to more than one person, up
to number four, when there is agreement to cultivate it by dividing in parts of equal production, case
in which the managing committee, within thirty days, from the date of auction, shall divide the plotCode of Comunidades of 1961

and hand over to each person his part of the lot, with the necessary elements of identification. All
this shall be mentioned in the supplementary contract.Article 305.The administrator has power to
impose penalties provided in articles 295, 296, 298, 299 and 300, but his decision, however shall be
subject to confirmation of the Director of Civil Administration Services, with appeal to the
Administrative Tribunal.Article 306.What is prescribed in this Code in relation to the ordinary
auctions, is applicable to the auction of paddy fields, save what is provided in the present
section.Article 307.From the increase in revenue resulting from the public auction on the average of
the normal income of the last nine years, fifty per cent shall be allocated for the purpose provided in
the clause (b) of article 316 and the remaining part shall constitute income of the Comunidades to be
distributed to its members, by observing the legal formalities.
Chapter IV
Development of agriculture and extraordinary expenses
Article 308.For the purposes of agriculture development, the technical officer of works and the
farming officer shall hold a meeting in the administration office of Comunidades by 25th January of
each year, under the chairmanship of the respective administrator and with the necessary
information obtained in advance from the respective managing committee or any other sources shall
prepare a scheme of works of a permanent character that can be executed in one or more years,
preferably works of irrigation and of the consolidation of bunds and sluice gates, so as to avoid, as
much as possible, urgent works.Whenever there is need to carry out or to implement any work, not
foreseen in the scheme referred earlier, it is the responsibility of the managing committee or the
administrator, on their own, to ask for the preparation of the respective schemes and required
budgets.Article 309.The scheme referred to in the previous article, shall be submitted for the
approval of the Governor General, through the Directorate of Economic Services, by the 20th
February next, and after its approval the managing committee shall order the preparation of the
respective projects.Sole § One copy of the scheme, after it is approved, shall be sent to the
Directorate of CivilAdministration Services by the respective administration of Comunidades
office.Article 310.On receipt of the projects with the budgets, the clerk of the Comunidades shall
convene the comunidade, returning the file to the administration office, with the copies of the
deliberation of the same and of the managing committee, which shall indicate how to meet the
expenditure and the financial position of the comunidade.§ 1. The administration office shall attach
the conditions for auction and the contract specification, if not attached earlier, and announce the
auction, except when any work in question is not of the interest of the Comunidades or the
Comunidades does not approve the necessary expense, circumstance in which the file shall be
submitted to the Directorate of Civil Administration Services for the decision by the Governor
General.§ 2. With the provisional contract drawn up or deliberation taken, and with his remarks on
the matter, the administrator shall submit the file to the Directorate of Civil Administration Services
for the decision of the Governor General.§ 3. The Directorate of Public Works and Transport shall be
consulted on all the budgets or estimates that exceed 50.000$.Article 311.The works shall be
executed, as a rule, on contract basis, by observing the regulations and clauses in force. However
works may be carried out by direct administration, when in the second auction, which shall be
announced along with the first one, there is no bidder.Article 312.The contract works shall beCode of Comunidades of 1961

preceded by public auction, announced, not less than ten days in advance, in the Official Gazette, in
one newspaper of the capital or of the taluka and posted at the usual places, and the said contract
drawn up in the administration office, with the intervention of the managing committee and two
witnesses.Article 313.The works shall be inspected and supervised by:-
1. The works officer, who shall give his opinion in the file;
2. The managing committee, and, specially, the attorney, who shall inform the
administrator of the irregularities that he may notice;
3. The administrator, who shall conduct at least one inspection, in the course
of the works accompanied by the technical officer, of which a competent
inspection report shall be prepared.
§ 1. In case of works of the value exceeding 3000$, and if the required funds have been provided, the
administrator may, with the sanction of the Governor General, ask for the report referred to in the
paragraph 2 of article 310, and engage one overseer or temporary supervisor, with salary not
exceeding to 18$ per day.§ 2. The overseer or supervisor, to which reference is made in the
preceding paragraph, shall work under orders of the attorney of the comunidade, carrying the
instructions received from the technical person.§ 3. For the execution under direct administration,
only in special cases duly recognized by the Government, technical persons or overseers and
supervisors shall be admitted.Article 314.The provisional and definitive acceptance, of the works
shall be preceded by inspection, in the following manner:(a)In case of works of the value up to
3000$, by the managing committee, with intervention of the technical personnel of works;(b)When
the value is above 3000$, by the administrator, with the intervention of the technical person of
works and assisted by the managing committee.§ 1. Whenever it is found convenient any technical
personnel of the Directorate of Public Works and Transport can be requisitioned to intervene in the
acceptance proceedings, and his intervention shall be mandatory, in final delivery, when the value of
the works exceeds 50000$.§ 2. The final delivery shall be considered valid only after being
confirmed by the Governor General.Article 315.The administrator shall fix, in each case, a time limit
to the clerk of the Comunidades to complete the work which he is supposed to do in relation to the
works, when not defined in this Code.Article 316.To bear the expenses with works, provided for in
this chapter a reserve fund shall be constituted, with the following incomes:(a)50 per cent of the
proceeds of zonns and dividends of the shares prescribed;(b)50 of the increase of the income
referred to in the article 307;(c)50 per cent of the capital derived from the redemption;(d)The
amount ordered to be separated by the administrator in terms of article 476.Sole § When the
availabilities of the reserve fund are insufficient, the expenses may be paid from advances of the
Comunidades or by a loan obtained with the authorization of the Governor General.
Chapter V
Long term leasesCode of Comunidades of 1961

Article 317.The Comunidades may give on long term lease its uncultivated lands or paddy fields and
land with fruit bearing trees which are in remarkably deteriorated condition and the Comunidades
is not in a position to carry out the expenses necessary for its improvement.§ 1. The period of lease
shall be of nine to eighteen years, and the area of each concession shall not exceed 20 ha.§ 2. The
leases may be made with more than one person jointly, who shall be jointly and severally
responsible to fulfil the obligations resulting from the same and shall be subjected to the respective
penalties.Article 318.The applications for long term lease shall be addressed to the Governor
General and processed in the administration office, containing:-(a)The name of the land, nature of
the crop for which it is intended and the number of item under which it is listed in the estimate in
the last ordinary auction;(b)In case of the paddy field, the quantity of seed and the estimated
production indicated in the estimate;(c)The situation and the boundaries;(d)The area, when
available, or the probable area;(e)The number of years for which it is intended to lease and the rent
offered.Sole § The procedures relating to grant of the emphyteusis is applicable to the application for
long lease.Article 319.The application shall be accompanied by a estimate of the beneficiary scheme
which the applicant offers to carry out, with the indication of services or works to be executed in
each year and their probable cost. The period for the completion of all the improvements shall not
exceed five years.Article 320.Subsequently, the inspection with three experts shall be held, with one
appointed by the applicant, the other by the attorney and the third by the administrator, among the
agricultural experts.Article 321.The experts shall verify in the inspection:(a)Whether the lands are or
not fit for the cultivation that the applicant proposes to do;(b)Whether the plan of improvements
and works to be executed, indicating the alterations that have to be done in the same scheme, can be
approved and also whether the rent which shall be received by virtue of this lease, will be favorable
to the interests of the comunidade.Article 322.If the Comunidades in conformity with the findings of
the experts approves the lease, the land shall be put to auction.§ 1. The base of auction shall be
indicated by the experts, which however, in no case, shall be inferior to the maximum rent obtained
in the previous nine years plus 15 per cent.§ 2. The lessee who fails to comply with the clauses of the
contract, shall be subject to pay a fine equivalent to the double of the expense that would have to be
done with the works or services which he left to be executed in due time, and in case of recurrence,
he may be removed, without prejudice to the imposition of fine.§ 3. To the lessee who does not
implement the beneficiary scheme, within the period in which he ought to do or shall abandon the
land later on, leaving it to deteriorate, the contract of lease shall be terminated reverting soon
thereafter the land to the comunidade, with all the improvements, and the lessee shall not be
entitled to the same. He shall also have no right for any compensation.§ 4. The rescission referred to
in the preceding paragraph shall be directed upon the inspection by the administrator, with the
intervention of an expert, who shall be the head of the office of agriculture and veterinary or his
delegate, and subject to the confirmation of the Governor General, without which it shall not be
enforceable.§ 5. The decision which direct the rescission, shall be published in the Official Gazette
and, as from its publication, the Comunidades shall re-enter in possession of the land, without
prejudice of any administrative claim or judicial action on the part of the lease holder or of the third
party.Article 323.The land that the Government requisition to the Comunidades, in terms of
Diplomas nos. 84 of 28th April, 1924, and 483, of 15th May, 1931, may be utilized for the purpose of
demonstrations, not only with the cultivation of rice, but also, of tobacco, sugarcane, horticulture
and others of vegetative cycle, the same lands being leased till the maximum limit of 5 ha. and for
the period of six years, renewable for equal periods.Code of Comunidades of 1961

Chapter VI
Aforamentos or emphyteusis
Section IGrantArticle 324.The Comunidades may grant aforamento - emphyteusis in respect its
uncultivated and undeveloped lands and even the ones cultivated of vegetables, when required for
the cultivation of rice, fruit-bearing trees or for the construction of houses.Sole § Whenever the
lands to be granted are bordering national forest lands or lands enclosed on it, it is not lawful to
enter into respective agreements without prior hearing the Department of Agriculture and
Veterinary of the Directorate of Economic Services.Article 325.Grant of lands shown below, by way
of aforamento is forbidden:-
1. The lands earmarked for the use of the community;
2. Land necessary for cattle grazing;
3. Land reserved for easement of neighbours;
4. Lands earmarked for threshing and other ordinary works related to;
cultivation and protection of the paddy fields;
5. Lands reserved for reservoirs of waters for irrigation of fields and breeding
fish;
6. The open yards in front of temples of any religion and cemeteries and
plots adjacent to markets places up to 10 m. on each side;
7. The lands which are locked within paddy fields of the Comunidades and
the rivulets of casana land.
§ 1. The lands mentioned in this article, and those abutting public ways and paddy fields, within a
radius of 50 meters earmarked exclusively for grant in emphyteusis, for building houses and those
that can be used for cultivation by the comunidade, shall be identified, described and demarcated if
they have not been demarcated before in cadastral survey of the comunidade. A respective record
shall be drawn and enter in the 'Tombo 1' of the comunidade.§ 2. This identification shall be done by
the managing committee with the help of a surveyor. In cases of the lands that can be brought under
cultivation, an expert in agriculture shall also be heard.§ 3. Whenever necessary, the administrator
shall inspect the works, by solving in loco any doubts that may arise.§ 4. Once the demarcation is
done, the provisions of article 212, to the extent applicable, shall be observed.§ 5. Until the
identification of lands, referred in paragraph 1, is not done, no aforamento shall be granted nor
confirmed.§ 6. After the lands that can be used for cultivation are separated, the managingCode of Comunidades of 1961

committee, with the help of the agricultural expert, shall prepare the map of cultivation with
necessary estimates for the execution of works in one or more lots, so that cultivation can be done
with financial capacity of the comunidade.§ 7. The emphyteusis granted, in contravention of
previous paragraphs, shall be null and with no effect and the persons that contributed to such grants
shall be liable for damages.Article 326.Plots with and area more than 3 hectares shall not be granted
on emphyteusis for cultivation and those with more than 1000 m2 for the construction of house;
however bigger area can be granted, for construction of house when the applicant so desires and
produces a plan of the proposed building.§ 1. Lands with an area of 3 to 10 hectares may be granted
on emphyteusis for cultivation if on account of rocky nature of soil the development of the said land
demand heavy expenses or if the land is of single crop and it is intended to convert into two crops
land.§ 2. In each comunidade, more than one emphyteusis for construction cannot be granted to the
same person.Article 327.The plots adjoining each other and located near residential buildings and
those abutting roads, public ways or village ways and paddy fields shall not be granted in
emphyteusis for cultivation within a radius of 50 meters, except strips of land of not more than 5
meters wide which may be granted, without auction, and on payment of approximate foro previously
fixed, increased by 50 per cent.Article 328.It is expressly forbidden to apply in the same application
for more than one plot, or land for cultivation and for house at the same time, or of more than one
applicant for the same or different plots.Article 329.The applications for emphyteusis shall be
addressed to the Governor General and shall be filed in the office of the respective administration of
the Comunidades, mentioning:(a)The name of the plot;(b)Its situation;(c)Its boundaries;(d)Its
probable area;(e)The proposed use;(f)The statement whether the plot is uncultivated or cultivated.§
1. The officer entrusted with the work shall give to the interested party the acknowledgement receipt
of the entry of the application indicating the respective number given to it.§ 2. No application shall
be processed, without the deposit of the probable cost of not above 240 $ at the hands of the
secretary of the administration office, who shall issue to the interested pa receipt indicating the day
and hour at which the deposit was effected and the entry in the respective book.§ 3. The applications
for the emphyteusis which are not as per conditions prescribed in this Code shall not be
processed.Article 330.After the application has been processed, the secretary of the administration
office shall announce the request applied for, in two successive numbers of the Official Gazette,
describing the land with all the conditions indicated in the preceding article, so that objections
against it could be filed within the period of thirty days, from the date of the second publication of
the advertisement. At the end of that period, enclosing the objections received or certifying that
there have been none, the file shall soon be sent to the clerk of the Comunidades for his reply and
that of the managing committee, and within a period of thirty days, which is not to be extended,
shall express their advisory opinion on the application.§ 1. Extraordinary sessions of the
Comunidades and of the managing committee may be held for the purposes of this article.§ 2. The
pages of the Official Gazette, in which the advertisements are published, shall be attached to the
file.Article 331.On the expiry of the period for the reply, the clerk shall return the file to the
administration office, with or without the reply of the Comunidades or of the committee.§ 1. The
administrator shall order to notify the applicant and the attorney of the Comunidades office for
appointment of experts for the inspection, indicating the day and the hour for this purpose.§ 2. The
appointment of the experts shall be done in the manner prescribed in the Code of Civil Procedure.
The third expert shall always be appointed by the administrator.§ 3. In the order of appointment of
the experts, the date and the hour for the inspection, shall be indicated and this inspection shall beCode of Comunidades of 1961

held within the period of twenty days.Article 332.The inspection shall be presided by the
administrator along with his secretary, and besides the experts, the applicant, the attorney and the
clerk of the Comunidades shall be notified to attend.§ 1. After taking the oath, the experts shall give
their report declaring whether the land is suitable to be granted as emphyteusis and whether from
the grant it will result or not loss to the Comunidades and in this regard the opinion, if any, from the
same Comunidades and from the committee, shall also be considered. The experts shall also state
which is the amount of foro to be fixed and all the circumstances that may contribute for the final
decision.§ 2. If on inspection it is found that the land is suitable to be granted, it shall be measured
and demarcated, placing temporary boundary stones in all its angles.§ 3. If on inspection the land
has been found not suitable to be granted on emphyteusis, the applicant may request the
administrator, within the period of eight days, a new inspection, and it shall be granted with five
experts, being two appointed by the applicant, two by the attorney of the Comunidades and the fifth
by the administrator.§ 4. The same shall apply when the attorney of the comunidade, does not agree
with the opinion given regarding the suitability of that plot, and thus requests for the inspection.§ 5.
In the talukas of 1st class the foro cannot be less than 6$ for each 100m2 and in the remaining
talukas not less than 3$. However, if the land applied on emphyteusis is cultivated, the foro shall
never be less than the maximum rent accrued in the last nine years and plus ten per cent.§ 6. After
the inspection, the minutes shall be written and signed by all present and then recorded in the book
of the comunidade, within the period of eight days.Article 333.If the applicant desists from the
claim, the administrator shall order that the proceedings be filed and shall return to the applicant
the pre-payment costs made, after deducting the amount of cost.[Article 334.] [[Article 334A was
introduced on 05/01/1985.Article 334A has been amended by Goa Act No. 10 of 1993 dated
04/05/1993.Article 334A has been further amended by Goa Act No. 3 of 1996 dated
23.
/01/1996. (See Appendix)Article 334A has been amended by Goa Act No. 3 of 1997 dated
12/03/1997. (See Appendix)The same Article has been amended by Goa Act No. 3 of 1998 dated
17/01/1998. (See Appendix)The same Article 334A was further amended by Goa Act No. 24 of 2001
dated
04.
/04/2001. (See Appendix)]]All the lands applied for emphyteusis shall be put up for public auction,
without prejudice to the provisions of article 327.§ 1. The auction shall be published in the Official
Gazette, at least fifteen days in advance.§ 2. On the day fixed for the auction, the administrator shall
order the bailiff to announce the initiation of bids and, at the end of the bidding, the land shall be
granted in terms of the following paragraphs, drawing the required record.§ 3. In the case when the
land is granted to a person other than the applicant, the latter shall be indemnified by the former
with double the procedural cost.§ 4. The bidder who offers the highest bid foro shall deposit the
amount corresponding to foro of one year and plus the double of the deposit, and only then the bid
shall be considered finalized.§ 5. After the order of the grant of the emphyteusis, the amount of
double of the costs shall be handed over to the first applicant and the one corresponding to the foro
paid into the safe of the comunidade, being credited separately in the first year of the contract.§ 6. InCode of Comunidades of 1961

the absence of bidders the land shall be adjudicated to the applicant for the foro fixed at the
inspection.[Article 334A. [Inserted by Act No. 1 of 1958.]- Notwithstanding anything contained in
article 334, but subject to article 327, a Comunidade may subject to such guidelines as the
Government, may, from time to time, issue, grant on lease [not more than 10,000 sq. metres of land
to educational societies for construction of playgrounds and] [not more than 400 sq. metres of]
[Inserted by Goa Act No. 10 of 1993, dated 4-5-1993.] land for construction of houses or buildings,
without auction, to any of the following categories or for purposes:-i) Public, Charitable or Religious
Institutions;ii) For any scheme of providing housing to the economically weaker sections;iii) Small
scale Industrial purposes;iv) Government Departments or local bodies;v) Co-operative Housing
Societies of landless persons;vi) Government servants or employees of the Comunidades [who are
landless] [Inserted by Goa Act No. 10 of 1993, dated 4-5-1993.];vii) Landless Jonoeiros;viii)
[Landless] [Inserted by Goa Act No. 10 of 1993, dated 4-5-1993.] Freedom Fighters;ix) Such other
categories or purposes as may be notified by the Government, from time to time.Provided that every
notifications issued under this clause shall be laid as soon as may be, after it is issued, before the
Legislative Assembly:[Provided further that institutions of public utility and associations of
professional bodies duly recognised by the Government may also be granted not more than 10,000
sq. metres of Comunidade land on lease for construction of houses or buildings, without
auction.Provided further that the educational societies, institutions of public utility, social
organisation and associations professional bodies duly recognised by the Government and have
been granted Comunidade land under any other provisions of law or are in actual possessions of the
land, shall be deemed to have granted the same under the provisions of this Legislative Diploma, on
payment of annual lease rent.] [Inserted by Goa Act No. 3 of 1997, dated 12.3.1997.]Provided further
that the members of Cooperative Housing Societies and the persons belonging to the categories (vi),
(vii) and (viii) above are residing in Goa for preceeding [15] [Substituted for the figures '25' by Act
No. 9 of 1985.] years:Provided also that no person whose annual income exceeds [Rs. 1,25,000/-]
[Substituted by Goa Act No. 3 of 1996, dated 23-1-1996.] or such amount as may be prescribed by
the Government shall be eligible for grant of land on lease without auction.][Explanation 1. - For the
purpose of the Article, the word "landless" means that neither the person nor his or her spouse or
minor child owns a plot of land or house in the State of Goa. The word "house" shall also include a
flat or apartment.Explanation 2. - For the purpose of this Article, the annual income of the person
shall be construed to mean the annual income of the person and of his or her spouse or minor child.]
[Inserted by Goa Act No. 10 of 1993, dated 4-5-1993.]Article 335.After the auction, the secretary of
the administration shall forward the file to the administrator, who, with his remarks, shall send it to
the Directorate of Civil Administration Services.§ 1. The Governor-General, on going through the
file, shall consider the request.§ 2. Soon after the file is returned to the administration office, the
same shall be forwarded to the clerk of the respective comunidade, who shall register, within the
period of three days of receipt, the order of the Governor General in the competent book.§ 3. If the
order is for grant of the emphyteusis, the clerk of the Comunidades, soon after the registration, shall
issue a chalan to be paid, within eight days, by the emphyteuta the [siza] [For definition refer to foot
note of 226.] which may be due by the law in force and, after attaching to the file the receipt of the
payment, with the assistance of the attorney of the comunidade, shall make provisional delivery of
the land to the emphyteuta, verifying the correctness of the measurement and that there has not
been any change in the provisional boundary marks, drawing thereafter the competent record,
which shall also recorded in the book.§ 4. Soon after, the clerk shall make provisional registration ofCode of Comunidades of 1961

land granted which shall be converted in definitive after being granted the final possession to the
emphyteuta.§ 5. If the provisional delivery is not taken, without justified reasons, within the period
of four months from the order of the grant, the administrator shall inform this fact to the
Governor-General, proposing the cancellation of the order of the grant of emphyteusis and reverting
the land to the comunidade.Article 336.In case of the applicants or successful bidders show no
interest in taking necessary further steps, within the time fixed by the administrator, the
Governor-General may order the application to be filled.Article 337.The emphyteuta, within three
days after the end of the period set in article 341, or extended as per article 342, is bound to apply to
the administrator for the definitive possession of the land granted on emphyteusis.Sole § After
applying for the possession, the administrator shall grant the same on the day and hour that shall be
fixed , and in the presence of the emphyteuta, the attorney, the clerk of the Comunidades and the
secretary of the administration, the latter shall write the respective minutes, which later on shall be
recorded by the clerk in the competent register.Article 338.The provisional delivery of the land
granted, as emphyteusis, cannot be considered in legal relations between the Comunidades and the
lease holder, as this is an optional act of mere tolerance, and only the definitive possession confers
to the emphyteuta the rights that the civil law recognize and assure him. He, meanwhile, can make
use of the possessory actions and of the other conservatory means against the third parties.Article
339.Following persons have premption in the emphyteusis for cultivation:-
1. The member of the Comunidades with actual residence in the village;
2. Any other inhabitant of the village, and preferably, direct cultivator;
3. Those who have adjoining land to the one to be granted, preferably
between them, the proprietor of smaller area;
4. Those who earlier have applied for grant of emphyteusis for the same plot
and the application has been processed.
Sole § The preemptors shall make their claim at the auction, at the end of bidding, and before the
award, for which it shall be announced that the auction has been knocked down and the provisions
of the paragraph 4 of article 334 shall apply to the preemptors with the exception of the those
covered by the clause 4 of this article, who shall not be bound to pay double of the costs.Section
IIObjections against applications for the grantsArticle 340.Any objection against the request for
emphyteusis can only be brought up, within the period of thirty days referred to in the article 330.§
1. After the objection is received and the Comunidades is heard, the administrator shall stay further
proceedings in respect of the contested portion of land and continue the proceedings in respect of
part on which there is no objection, provided the applicant so desire.§ 2. The objection shall be put
in writing and signed by the objector with the signature attested by the Notary, and on the same the
administrator shall pass his order deciding the objection or directing the parties to approach the
court through the ordinary means if the dispute is concerning possession and title of the property.§
3. If the objection cannot be decided without inspection of the property, necessary data shall be
collected on the inspection referred to in the article 332, and the claimant, upon notice, mayCode of Comunidades of 1961

formulate any queries and produce any document.§ 4. If the applicant, inspite of knowledge, that
the parties have been directed to approach the court, insists on the grant of lease, the proceedings
shall be taken and the grant shall be granted with all the legal formalities, but on the clause that the
Comunidades shall not be answerable for the eviction of the grant, nor bring objection to any
delivery of the plot, and further, with the clause that the grantee will subrogate of all the rights of the
comunidade.§ 5. In case of the declaration referred to in the previous paragraph, of which record
shall be made, the provisions of the paragraphs 8 and 9 of this article shall not be complied with and
the objector may enforce his rights against the emphyteuta at any time, observing the provisions of
general law.§ 6. In the case provided in paragraph 4, the grantee is bound to pay to the
Comunidades the respective foros, until the date of the final court decision, directing the reversion
of the land to the objector, become res judicata or to the one who legally represents him.§ 7. In the
defence of the suit filed by the objector, in the case of paragraph 4, the grantee, for all purposes,
shall be considered the legal representative of the comunidade.§ 8. The objectors whose objection
are to be decided in the judicial courts, shall produce, within thirty days from the date of notice of
the order which is referred to in the paragraph 2 of this article, a certified copy that the competent
plaint has been presented in the court, on the pain of the objections being considered of no effect
and the proceedings to take normal course for the grant of emphyteusis.§ 9. The objectors are
equally obliged to present in the administration office every three months, a certified copy
indicating that the case proceeds it normal course, failing which the sanction imposed in the
previous paragraph shall follow.§ 10. If the suit is decided finally in favor of the comunidade, the
application for grant of emphyteusis shall follow its course.Section IIIReversion of lands granted on
emphyteusisArticle 341.The plot granted by way of emphyteusis shall revert back to the
Comunidades if it is not utilised, within four years from the date of provisional possession.§ 1. The
following plots shall deemed as utilised :-
1. The plots granted for cultivation of rice, when their major part is used for
such cultivation, within the prescribed period;
2. The plots granted for plantation of trees or of the other species, when they
are totally or in major part utilized for such plantation during the prescribed
period;
3. The plots granted for building houses which were completed within the
said four years, with at least one fifth of the area fully utilized upon;
4. The plots granted for the construction of houses and also for the
cultivation when they may have been utilized for both the ends;
5. The plots granted in the area above 3 ha. for establishments of public
utility, if the same establishment is completed within six years including the
compound, play grounds, garden and other easements, covering at least one
tenth of the granted area.Code of Comunidades of 1961

§ 2. If it is found that the plots granted for construction of houses have been utilized, but the area
used is less than that foreseen in clause 3 of paragraph 1, the Governor General may direct the final
possession of the area corresponding to 5 times of the occupied area, without changing the quantum
of foro, ordering the reversion of the remaining area.§ 3. The provision of the preceding paragraph
shall not apply to the leases granted in urban zones or subject to urban planning, without the
municipality being heard.Article 342.The emphyteuta who, for any reason, cannot avail of plots
granted as emphyteusis, within the period of four years, can, before expiry of the same, apply for its
extension, mentioning the causes for delay in the fulfilment within the stipulated period, and the
Governor General, after hearing the managing committee of the Comunidades and the respective
administrator, decide the request as he thinks fit, granting the extension for one year.Article 343.A
committee comprised of president of the managing committee, the attorney and the clerk of the
comunidade, shall inspect every year, during the month of December, the areas granted by way of
emphyteusis checking whether the plots granted have been utilized in terms of previous articles and
drawing the competent report, where it shall be mentioned therein the actual statues.§ 1. For this
purpose the clerk shall provide the committee, the necessary clarifications, as per the registers, and
when not available, obtaining the same from the administration office of Comunidades.§ 2. One
copy of the report of the inspection shall be forwarded to the administration office of Comunidades,
by 15th January of each year.§ 3. The members of the committee who do not comply with the
provisions of this article, shall incur, each one, a fine of 150$ to 300$, which shall be imposed by the
administrator, without prejudice to the disciplinary action against the said clerk.§ 4. The
administrator who does not comply with the provisions of preceding paragraph incurs a fine of
300$ to 600$, without prejudice to disciplinary action.Article 344.When it is found from the
inspection, referred to in the article 343 that the emphyteuta did not utilise the land for the purpose
for which it was granted in terms of article 341, the penalty corresponding to twenty times the
amount of foro, and the same not being below 300$, shall be imposed on him.Article 345.After the
receipt of the copy referred to in the paragraph 2 of the article 343, the administrator shall order to
notify the emphyteuta, on pain of the case being set ex-part to state in his petition to be submitted,
within the period of eight days, the reason for failing to avail of the land.§ 1. If the emphyteuta admit
his fault noted during the inspection or if the case is decided ex-part the administrator shall bring
this to the knowledge of the Governor-General, proposing that the order of grant be revoked and the
land reverted to the comunidade.§ 2. If the emphyteuta dispute the correctness of the examination,
the administrator shall order the re-examination, which shall take place in terms of article 332, by
way of experts. The grantee shall make the pre payment of the cost and if the examination establish
that the contention made by the grantee is without merit then he shall forward the file and direct
action for early reversion of land to the comunidade.Article 346.The order of reversion shall be
published in the Official Gazette, duly recorded in the respective book.§ 1. The copy of this order
shall be sufficient document to cancel the registration of the emphyteusis in his name in the land
Registration Office. Such cancellation shall be sought by the attorney of the Comunidades in ten
days time, failing which the attorney shall be fined ten times the amount of foro.§ 2. As from the
date of publication of the order in the Official Gazette the plot stands reverted to the comunidade,
and no suit or no administrative proceedings shall lie against such cancellation done under the Code
under this article from the part of emphyteuta.Code of Comunidades of 1961

Chapter VII
Sale of pledges and of produce of properties
Article 347.The pledges created in terms of article 279 shall be sold in the following manner, when at
the proper time the amount secured by the pledge, has not been paid.§ 1. The clerk of the
Comunidades shall announce the public sale, inviting the prospective buyers to be present in the
administration office of comunidade, on the date and hour indicated by the administrator.§ 2. The
advertisement shall indicate the type of the securities, its metal and value and the corresponding
number of certificates of the shares and the issuing comunidade.§ 3. On the day fixed for the sale, in
the presence of the administrator, the president of the managing committee, the attorney and the
clerk of the comunidade, the items shall be awarded, each one of the objects separately, or all
together, to whoever offers higher bid. The clerk of the Comunidades shall write a report in the book
of records, signed by all of them, by the bidder and by two witnesses.§ 4. The pledge put for auction
shall not be delivered to successful bidders without prior payment of the respective price, and in
case it not paid within three days, a new auction shall be held, and the original bidder shall be
subject to penalties provided in the article 904 of the Code of Civil Procedure.§ 5. From the amount
of the bid, the interest and the emoluments due from the proceeds of the auction shall be deducted
and the surplus shall be returned to the debtor.Article 348.For the sale of fruits and products of the
properties mentioned in article 284, the formalities prescribed in the present chapter, as far as
applicable, shall be observed.
Chapter VIII
Permission for filing of suit
Article 349.When the Comunidades decides to file any suit, in terms of article 9, the attorney shall
explain, with indication of the probable expenditure to be incurred with the suit, with para wise
pleadings in fact and law supported by documents and addressed to the Administrative Tribunal,
through the respective administrator, who shall put his remarks on it.The Administrative Tribunal
shall decide, independently of the approval without circulation to other members, with exception
that of the Ministerio Público, and if the permission is grated to file the suit, it shall sanction the
expenditure to be incurred for the purpose.Article 350.Same procedure as per the preceding article
shall be adopted when the Comunidades requests permission to withdraw, admit and compromise
the suit.Article 351.Permission for conservatory actions shall be obtained by application addressed
by the attorney of the Comunidades to the administrator.Article 352.The permission referred to in
the articles 9 and 154, No. 3, shall be accompanied by the copy of the initial plaint and the one
referred to in the preceding article shall be presented in court in terms of article 25 of the Code of
Civil Procedure (Codigo de Processo Civil).Article 353.The suits filed in regards to the current
accounts issued in terms of this Code, as well as the suits against the debtors of the annual income of
the Comunidades and against the defaulting borrowers are not subject to the formalities prescribed
in this chapter.Code of Comunidades of 1961

Chapter IX
Redemption of charges and contributions due to the
Comunidades
Article 354.The remission of fees of the offices of clerks of the Comunidades and any other charges
shall be applied to the Governor-General through the administrator, attaching to the application the
copy of the minutes of the Comunidades in which it was deliberated to effect the remission and a
certificate stating that the safe of the Comunidades is in position to pay the same.Sole § The
administrator shall hear the interested pin whose favor the charge is constituted and, if it is a
collective person, shall forward the application to its representative, for him to hear the same, and,
enclosing the replies that may be obtained, he shall send the file to the Directorate of Civil
Administration Services with remarks of the same to be submitted for order of the
Governor-General.Article 355.The document proving the payment of the capital of redemption or of
the delivery of title of equivalent shares is sufficient to proof the cancellation of the burden and, in
view of the same to make the cancellation in the registry.
Chapter X
Rebate on the rent of the fields
Article 356.The lessee of the Comunidades has the right, irrespective of previous stipulation, to seek
rebate in the payment of rent proportionate to the object of the lease arising from fortuitous events
or of force major, for which by no manner he has contributed, without prejudice to what is provided
in the sole paragraph of the following article.Article 357.For the purposes laid down in the preceding
article, the unforeseen happenings or cases beyond ones control are only those of inundations of
saline water or fresh water due to the breach of bunds or to the mal-functioning of the sluice gates,
drought, fire, extraordinary invasion of insects and the lack of water in the reservoirs of irrigation of
fields for the cultivation of vaingana.Sole § In cases of inundation and of drought, the lessee can ask
for reduction of rent only if the leased lot has produced less than half of the production attributed in
the estimate. If it is verified that this production is above 75 percent of the one foreseen in the
estimate, the lessee shall incur in a fine, applied by the Governor-General, corresponding to 50 per
cent of the respective rent.Article 358.The lessees, when any of the events mentioned in the
preceding article take place, shall bring to the notice, in writing, on ordinary paper to the
administrator of Comunidades and to the clerk of the comunidade, who shall bring to the notice of
the higher authorities and to the agents of the comunidade.Sole § When the lessee realizes there is
no water in the reservoir for irrigation of the field that it serves, he shall bring this fact to the notice,
in the manner indicated in this article, till the end of the month of November, for its verification and
reduction of the area of the field that may be irrigated.Article 359.The administrator of the
Comunidades, the attorney and the bidder of the embankment and of the sluice gate, if any, shall
take immediate steps to repair the damage or to lessen the same.Article 360.The administrator, after
receiving the communication, shall immediately order its inspection of the field or of the reservoir
by technical expert or, in his absence, by a fit person, in the presence of the attorney, and record in a
report, which shall be written by the clerk of the comunidade, all that has been collected for a justCode of Comunidades of 1961

evaluation of the damage, its causes, responsibility and identification of the lots affected.Article
361.The rebate of rent known as quita shall not be granted if the lessee fails to bring to the notice of
any case arising from fortuitous events or of force major in precise terms of article 358 and its sole
paragraph.§ 1. The communication made, within three days, after the occurrence is considered as
deemed made in due time.§ 2. The benefit of the inspection made shall be of advantage to all the
tenants.Article 362.The administrator who fails to order to carry out, within the period of forty eight
hours, the inspection referred to in the article 360, and on account of such behaviour it not possible
to verify the reason for the occurrence and to identify the person, he will be answerable to the
Comunidades for the damages caused which shall be recovered by ordinary means.Article 363.The
administrator, members of the managing committee, the lessee who fail to take appropriate
measures or have not execute them to prevent the worsening of the damage, shall be held
responsible to the Comunidades that it may suffer and which shall be recovered by using ordinary
means.Sole § Any member of the Comunidades shall be considered as proper party to file suit to
recover damages in favour of the comunidade.Article 364.The applications for the relief of rent
(quita), addressed to the Governor-General, shall be given entry in the respective administration
office, indicating in it the name or names of the plots, their location and probable quantity of the
loss of income, its causes, the impossibility to sow the plots and all the grounds in support of the
request and the proof that the lease holder has fulfilled the technical conditions of the cultivation.§
1. The rebate (quita) of each plot shall be applied by the respective lessee. When the plots are
continuous or that the distance from each other in not more than 500m, or, when the reason for the
quita of the rent of [vaingana] [[Vaigana - Crops planted during the rainy season and ready for
harvest in autumn are termed as 'Vaigana'. In India the kharif season varies by crop and state, with
kharif starting at the earliest in May.Rabi - Spring grain harvest in India.]], when the plots are
irrigated with the waters of only one reservoir, the quita can be applied in one application by the
affected lessee.§ 2. When application is processed the administrator shall order to notify the
interested party and the attorney of the Comunidades to appear in the administration office, in
order to appoint of one or three experts.§ 3. The appointment of experts be made in terms of general
law, being the third expert appointed by the administrator. If the parties agree that there shall be
only one expert, such appointment will be done by the administrator.§ 4. At the time of the
appointment of the experts, the administrator shall fix the date of the inspection, direct to notify the
experts, the parties and the attorney of the Comunidades to appear at the place of the respective
plots on the designated day and hour.§ 5. In the inspection the loss of income shall be assessed, its
causes and quantity, the impossibility of sowing and all that may concur for the clarification of the
matter, drawing a detailed report.§ 6. The interested parties may formulate queries and the
administrator may direct any steps that may think essential to clarify the matter.§ 7. If any lessee,
the attorney of the Comunidades or its managing committee, do not agree with the result of the
inspection, it shall proceed for the direct measurement of the produce, it being the duty of the
administrator to promote all the necessary diligences for correct execution of this measurement.
When by the measurement it is found that the experts have acted in bad faith in the inspection, the
administrator shall report this fact to the Judicial Court, within the period of forty eight hours, and,
if it is in the case of public servants, shall report also to the Director or head of the respective
department.§ 8. On the conclusion of the investigation , the administrator shall order to hear the
Comunidades and the managing committee and forward the process with his remarks, to the
Directorate of Civil Administration Services for the decision of the Governor-General.§ 9. TheCode of Comunidades of 1961

Governor-General, in view of what has been recorded in the process, shall resolve if the applicants
deserve or not the rebate (quita) and, in the former case, shall determine the reduction that should
be made in the rent of each plot.Article 365.When the quita is applied for the motive of shortage of
water necessary for the sowing and irrigation of vaingana in the reservoirs of the comunidade, the
fact and its cause shall be verified during the inspection, as well as, if the plots referred to in the
request can be or not cultivated and watered, till the ripening of the standing crop, with the existing
waters.
1st. If it is found that the plots of the applicant can be cultivated, the rebate
(quita) shall not be granted; and, in the other case, after the diligences dealt
with in the paragraph 6 of preceding article, the file shall be forwarded, with
the remarks of the administrator, for the final decision.
2nd. On verifying that the cause of shortage of waters was not casual, but
due to action of a person other than the applicant, he may use against the
former all the remedies available within the power of the comunidade.
Article 366.For the purposes of the grant of the quita of rent of the fields in which there may have
been total damage of the crop, the verification of the alleged fact shall be done by the managing
committee, with the assistance of the agricultural technician, having the interested lessee to deposit
previously the probable amount of travel expenses of the said technician, in the respective
administration, observing in the subsequent terms the provisions of the article 364, wherever
applicable.Article 367.The request for the grant of the rebate (quita) shall be presented till February
15 in relation to [vaingana/Rabby] [For definition of Vaigana refer to foot note of 364.], till August
15, in relation to kharif crop, till September 15 in case of drought and within five days from the
occurrence in case of fire and extraordinary invasion of insects.The commission for the verification
of grounds of the request shall be done before the harvest.
Chapter XI
Introduction of waters in the fields
Article 368.No saline waters or sweet waters can be introduced in the paddy fields of the
Comunidades, without permission of the Governor-General.§ 1. This shall be applied by the attorney
of the comunidade, through the respective administration office, by attaching to the application the
following documents:-(a)Resolution of the Comunidades or of the managing committee when the
requirements of article 38 are satisfied , deliberating on the intended introduction of waters and
indicating the time up to which it last;(b)Opinion of two physicians , one of which shall be the health
officer or his deputy of the area, declaring that the introduction of waters shall not cause prejudice
to the health of the neighbouring population nor the waters of the wells situated in the neighbouring
properties, in the case of saline waters;(c)Declaration of the proprietors of the adjoining properties
that they agree to the request;§ 2. The application, with the remarks of the administrator, shall be
submitted by the Directorate of Civil Administration Services to the resolution of theCode of Comunidades of 1961

Governor-General, after hearing the Directorate of Economic Services (Office of the Agriculture and
Veterinary Services) and the Directorate of Marine Services.Article 369.The permission, if granted,
shall be subject to the following conditions:-
1st. The waters to be introduced in any paddy fields shall not rise to more
than 0.m75 in the middle part of its surface;
2nd. Cannot be retained more than twenty four hours, for an height above
0.50m in the middle part of the inundated surface, however the introduction
can be repeated, when necessary, with the minimum interval/break of twenty
four hours.
Article 370.The violation of the provisions of the preceding articles shall be punished with simple
punishment of 6 months to two years and corresponding fine, and the functionary in charge of
parish (Regedor) of the village soon after comes to his knowledge of the same immediately shall
have the inundated field drained, making record and conducting a summary enquiry, and he shall
send the file to the competent tribunal, informing also the fact to the administration office of the
Comunidades and of the taluka.Sole §. The expenses incurred with the drainage shall be considered
for the purposes of damages to be fixed in the criminal case in case of conviction and the
expenditure incurred, which initially shall be borne by the comunidade.
Chapter XII
Encroachment of lands and remedies for their recovery
Section IEncroachment discovered with or without complaint[Article 371. Summary eviction of a
person unauthorisedly occupying land vesting in Comunidades. [Article 371 has been amended by
Act No. 8 of 1986 dated 14/10/1986. (See Appendix).](1)If in the opinion of the Director of Civil
Administration, any person is unauthorisedly occupying or wrongfully in possession of any
land.(a)vesting in the Comunidade ; or(b)to the use or occupation of which he is not entitled or has
ceased to be entitled by reason of -(i)any of the provisions of this Code, or,(ii)the expiry of the period
of lease or termination of lease for breach of any of the conditions annexed to the tenure,it shall be
lawful for the Director of Civil Administration to summarily evict such person in the manner
provided in clause (2).(2)The Director of Civil Administration shall serve a notice on such person
requiring him within such time as may appear reasonable after receipt of the said notice to vacate
the land and if such notice is not obeyed, the Director of Civil Administration may remove him from
such land.(3)A person unauthorisedly occupying or wrongfully in possession of land after he has
ceased to be entitled to continue the use, occupation or possession by virtue of any of the reasons
specified in clause (1), shall also be liable at the discretion of the Director of Civil Administration to
pay a penalty not exceeding two time the assessment or rent for the land for the period of such
unauthorized use or occupation.(4)The proceeds on account of the penalty imposed on the
encroacher envisaged in clause (3) shall be credited to the coffer of the Comunidades.]Code of Comunidades of 1961

Article 371.The suits that theComunidadesmay have to file in the courts against those who encroach
lands shall be preceded by an administrative inquiry, as per the following article which shall serve
as the basis for authorizing the respective civil suit on title.Sole § The possessory suits are exempted
from the provisions of this article.
[Article 372. Forfeiture and removal of property left out after summary eviction. [Article 372 has
been amended by Act No. 8 of 1986 dated 14/10/1986. (See Appendix).](1)After summary eviction
of any person under Article 371 any building or other construction erected on the land or any crop
raised on the land shall if not removed by such person after such written notice as the Director of
Civil Administration may deem reasonable, be liable to forfeiture or to summary
removal.(2)Forfeiture under this Article shall be adjudged by the Director of Civil Administration
and any property so forfeited shall be disposed off as the Director of Civil Administration may
direct, and the cost of the removal of any property under this Article shall be recoverable as an
arrear of land revenue.(3)For the purpose of this Article and Article 371, the Director of Civil
Administration means the Collector of Goa, as defined in the Goa, Daman and Diu Land Revenue
Code, 1968 (9 of 1969).(4)The Director of Civil Administration may by order, delegate any of the
powers and duties conferred on him under Articles 371 and 372 of the Code to any Administrator of
Comunidades or officer subordinate to him, subject to such condition, if any, as may be specified in
the order.]
Article 372.All the members of theComunidadesand even the non members are competent to
denounce the encroachment of land. They shall be, however, liable to the penalty prescribed in the
paragraph 2 of the following article, if the complaints proved to be made in bad faith and the
denouncement is held as untenable.
Article 373.The following persons are obliged to denounce the encroachment of land:-
1. The attorney of the comunidade;
2. The lessee of the fields, both in relation to land leased as well as of
embankment, drains and lands enclosed by or confining it, which are not
found leased to another individual.
§1. The attorney who does not denounce the encroachment of land, as soon as it comes to his
knowledge, shall be dismissed from the office, and shall forfeit in favour of the Comunidades the
allowance to which he is entitled for the service rendered up to the date of the discovery of the
encroachment of land.§2. The lessee who fail to denounce the encroachment of land soon after they
come to know about it, shall be liable to pay a fine equal to half of the value of land
encroached.Article 374.The denouncement shall be addressed to the administrator and it shall
contain:-(a)The name, status and the residence of the denouncer and of the encroacher;(b)The
denomination of the land encroached upon, its boundaries, the approximate area, time of
encroachment of land and its value;(c)The plot of land to which it belongs and the name of the
lessee;(d)Other clarifications that may help to discover and delimitate the encroachment of
land.Article 375.The denouncements can also be made to the managing committee, by sending the
respective petition to the respective clerk of the comunidade, who shall convene, within twenty four
hours, a meeting of managing committee, independently of the permission of the administrator, andCode of Comunidades of 1961

accompanied by a report of the committee with clear details, admitting or not the existence of the
denounced encroachment and shall forward the denouncement to the administration office.Sole §
The members of the managing committee, who fail to attend their meeting without proper
justification, shall incur a fine three times the one foreseen in article 63.Article 376.After processing
the complaint, the administrator shall call for views of the managing committee on the same, as per
of the provisions of the preceding article, in case the said denouncement was not earlier directed to
the committee, and shall notify the encroacher, within ten days to make a formal statement on the
file, whether he acknowledges or not the encroachment of land and in the latter case to present his
defence.§ 1. The encroacher shall be given, if he applies for it, a time of twenty days, to submit his
defence, if desired.§ 2. When the encroacher does not admit the encroachment of land, the
procedure established in the following articles shall be followed.Article 377.On the expiry of the
period of ten days, the administrator shall fix the date and will direct to notify the complainant and
the encroacher for the appointment of experts, in order to inspect the land and carry out the local
investigation of the land which is the object of encroachment.One of the experts shall be nominated
by the complainant, the other by the encroacher and the third by the administrator.§ 1. Members of
the respective Comunidades shall not be appointed as the experts.§ 2. At the time of appointment of
experts, the administrator shall fix the day for inspection, by directing that, besides the experts, the
members of the managing committee and the lessee of the land encroached to attend the same.§ 3.
The presence in the inspection of the denouncer and the encroacher is not required, although either
of them may have appeared at the time on appointment of experts.§ 4. The complainant, the
encroacher and the attorney may formulate queries they feel deemed necessary and present any
documents and the administrator may direct the enquire to follow any procedure that he may think
necessary to get the matter clarified.§ 5. The result of the local investigation shall be drawn on the
site and shall be prepared by the secretary of the administration office. The encroachment of land
shall be evaluated, measured and demarcated.§ 6. The members of the managing committee and the
lease holder of the land encroached shall be heard in the act of proceedings and they shall give their
views, to be recorded in the inspection report.Article 378.At the end of the local investigation, the
parties may lead any type of oral or legal evidence.Article 379.If from the evidence produced, as per
preceding articles, the existence of the encroachment of land stands proved, the administrator shall
order the issue of a copy of the respective report and other extracts of the file of proceedings, which
shall be handed over to the attorney of the Comunidades in order to request permission of the
Administrative Tribunal for filing of the competent suit in the Court, and shall impose, by order on
the file of proceedings, on the encroacher, the following penalties:(a)Banning for a period of five
years, from holding any post of the Comunidades of the respective taluka and from bidding and
standing as a guarantee in the ordinary and extraordinary auctions in the same Comunidades, either
directly or through an intermediary;(b)Forfeit in favour of the comunidade, for an equal period of
time, the proceeds of zonns, dividends on shares, annuities, [votonas] [votonas - Refer definition at
foot note of article 202.] or any other pension to which he be entitled in the respective
comunidade;(c)Fine to the tune of 600$ to 3.000$ when the person denounced is not member of
the comunidade. The fine shall not be greater than the double of the value of the land encroached.§
1. The penalties laid down in this article shall be enforced only after the suit is decided in favour of
the Comunidades by a judicial decision which has become res judicata.§ 2. If it is verified that the
denouncement was found to be without any ground, the administrator shall order the proceedings
filed.Article 380.The encroacher may, at any stage of the administrative inquiry, sign a declarationCode of Comunidades of 1961

undertaking to surrender the land or to pay its value, when it does not exceed 1800$. However he
shall not be allowed to do so in any circumstance, when the encroached land is subsequent to the
cadastral survey done for the purpose of preparing the register in respect of that land or when he
might have earlier been involved in another case of encroachment of land.§ 1. If the encroacher
admits the encroachment of land, by undertaking to surrender the land, the administrator shall
order that the attorney of the comunidade, along with the clerk of the same, take possession of the
said land, writing the competent report, which shall be incorporated in the file.§ 2. The record in
which the encroacher undertakes to pay the value of the land, shall not have any legal effect, without
the approval of the Administrative Tribunal, on the basis of prior report of the administrator, after
hearing the managing committee and the Comunidades which shall state whether it is convenient to
restore the land to the Comunidades or accept its value.§ 3. If the Administrative Tribunal does not
approve the record mentioned in the preceding paragraph, judicial proceedings shall be initiated
against the encroacher, irrespective of the authorization referred to in the article 349 and following
ones.§ 4. In the case of return of the land or of payment of its price, the encroacher shall not be
subject to the penalties provided for in article 379, but shall pay only the costs and stamp duty.§ 5.
When the encroachment of land had taken place prior to taking of the cadastral survey and its value
does not exceed 900$, the Administrative Tribunal may authorize or determine the respective
Comunidades to grant the land to the denounced person for the price determined during the
investigation.Article 381.Within 30 days after the sentence of the Court in favour of the
Comunidades become final, the attorney of the Comunidades shall produce in the administration
office, or otherwise be subject to a fine of 60$00, a certified copy of the judicial decision so that the
administrator may apply, after hearing the parties, the penalties established not only in article 379
but also in the article 373, paragraphs No. 1 and 2, with the exception of the penalty of dismissal of
the attorney which will be applied as soon as, by inspection referred to in article 377, the existence of
an encroachment is proved.Article 382.The administrator, as soon as he gets knowledge of any
encroachment of land, shall proceed on his own initiative and in accordance with provisions of the
preceding articles. In this case the respective Comunidades shall be considered as the
complainant.Article 383.The complaints proceedings, which may be initiated by any individuals
mentioned in articles 372 and 373, or when brought on the initiative of the comunidade, shall be on
plain paper, but of legal size, and the costs and stamp duty shall be assessed at the end and paid by
the complainant or the accused as the case may be.§ 1. The complainant cannot be ordered to pay
the costs and stamps duties when the existence of the encroachment of land is recognized by the
managing committee, on the information referred to in the articles 375 and 376, and in such a case
the respective Comunidades shall be considered as complainant, unless if the complaint is found to
be baseless and in that case the costs shall be paid jointly by the complainant and by the members of
the committee that have admitted it.§ 2. The transport allowances of the administrator, of the
secretary of the administration office and of the expert, appointed by the administrator, shall
however be advanced by the comunidade.§ 3. The stamp duties and costs on the proceedings
referred to in this article relating to the denounced person shall be demanded in terms of paragraph
1 of article 379.Article 384.Half of the allowances and of the fine referred to in the paragraphs 1 and
2 of article 373 shall be paid to the complainant who had followed the proceedings up to the end and
the other half shall be credited to the Pensioner's Bank where shall also be credited the amounts
derived from the penalties established in article 379.Section IIEncroachment discovered while
making the surveyArticle 385.The personnel entrusted with the work of organizing the cadastralCode of Comunidades of 1961

survey, referred to in the articles 210 and 211, shall measure, demarcate and evaluate, along with the
lands in possession of the Comunidades, any lands that they think must have been encroached, in
view of the measurement of its field, if any, and grant made by our government, emphyteusis
granted by the Comunidades and adjoining private properties.§ 1. The certificates of those
measurements, previously obtained from the competent offices by the managing committees, shall
be kept at the disposal of the personnel entrusted with the work of cadastral survey, at the beginning
of the respective works, attaching to them any other documents that may clarify the matter, whether
or not requested by the same personnel.§ 2. Before starting the work of measurement, the alleged
encroachers shall be notified to appear at the respective place, on the day and hours fixed in order to
assist during the measurement and evaluation of the respective lands, failing which the works will
be carried out in their absence.§ 3. It is the duty of the managing committee to order those
notifications to be issued by the clerk of the Comunidades or functionary in charge of the parish
(Regedor) where those individuals reside, in terms of the Code of Civil Procedure (Código de
Processo Civil).§ 4. When the encroacher does not agree with the value assigned to the land or to the
area calculated, he can apply to the administrator to verify the same area and value it again at his
own cost, through the experts, one of whom shall be appointed by the applicant, other by the
Comunidades and the third by the administrator.§ 5. The grant referred to in the preceding
paragraph shall not be effected unless the applicant signs before the managing committee a
declaration that he agrees to redeem the encroachment of land, in any of the forms established in
article 387, by applying for rectification.Article 386.There shall be one special book in each
comunidade, to record the encroachment of land which have not been legalized, which shall be
written according to model No. 14 and shall contain the measurement, the boundaries and the
evaluation of the lands encroached, the name of the encroacher and all the details that may be
needed, not only for the recognition and identification of these lands, but also for their restoration
or redemption.§ 1. The valuation shall be done based on the value of the land at the time of
encroachment of land, and it will be paid in terms of article 387 and respective paragraphs.§ 2.
When a competent suit has been filed against the encroacher, this circumstance shall be mentioned
and the name of the attorney in charge of the law-suit and the date of its filing shall be
indicated.Article 387.As soon as the register of encroachments of land is concluded, which shall be
done in preference to the writing of the general inventory (Tombo), the managing committee shall
order to notify in the form indicated in paragraph 3 of article 385, all the encroachers who have not
signed the declaration of recognition, during the registration of properties, in presence of the
surveyor, to come to declare before the committee, within the period of thirty days from the date of
notification, and by means of formal declaration, that they agree to pay, in lump sum or in yearly
instalments not exceeding to nine, the price of the land encroached by them, failing which legal
proceedings will be initiated.§ 1. The price payable shall be the value of land, fixed as per paragraph
1 of article 386, plus 25% of this value.§ 2. To the instalments, the interest of 4% shall always be
added.§ 3. The time limit that the managing committee may grant for the payment in lump sum
price or the first instalment shall not exceed thirty days.§ 4. The time for the payment in instalments
can be extended, in exceptional cases, after hearing the comunidade.Article 388.If the encroacher
does not sign the respective declaration within the time fixed in preceding article, the committee
shall order the issue of a certificate of encroachment not redeemed by him and send it to the
administrator, accompanied by all documents on which the finding was based and any others that
may serve as ground for claiming the land, in order to authorize the necessary expenses for the filingCode of Comunidades of 1961

of suit against the encroacher.Article 389.When any owner voluntarily admits the encroachment of
land that he has made and this he is unable to prove by any document, only two thirds of the value
of encroachment shall be approved if this admission is made during the survey work or within
fifteen days following to its completion, unless the competent suit had already been filed against the
encroacher.
Chapter XIII
Procedure in general
Article 390.Save in cases this Code prescribes a special procedure, all the petitions that are to be
dealt by the administrator of the Comunidades and decided by him shall be processed in the
following manner:-§ 1. The initial application, with the order of the administrator thereon, shall be
processed by the secretary of the administrative office, attaching the documents which accompanied
it, indicating on front cover the number corresponding to the year, the name of the parties and of
the Comunidades and the nature of the claim.§ 2. The administrator shall order the issue of the
notice to the opposite party, if any, to put up his defence, within ten days, allowing him to inspect
the file and when there is attached a power of attorney to an advocate residing in the seat of the
Taluka, judicial division and junior division.§ 3. The notice shall be served as per the Civil judicial
law.§ 4. When the managing committee or the Comunidades had to be heard , the secretary of the
administration office shall issue an order in the file forwarding the same to the clerk of the
comunidade, handing over personally, if he is present in the administration office, or else send it by
registered post and the postage shall be paid by respective party.§ 5. The clerk of the comunidade,
shall record a note acknowledging the receipt of the file and after submitting to the managing
committee, shall hand it over to the president, against a receipt.§ 6. The president, after examining
the papers as submitted to him, if he finds that the information of the clerk of Comunidades is
required, he shall ask for it, by order, to give the same in the file within ten days, transcribing there
after any deliberations of the Comunidades and the managing committee and other documents not
recorded in there or documents recorded in the books in his custody, pertaining to the case in
dispute or those that are relevant to the subject to be mentioned.§ 7. After the return of the file, with
the information of the clerk of the Comunidades or without the same, if not necessary, the president
shall soon fix the date for the meeting of the managing committee or of the comunidade, and order
to issue the necessary notices or advertisements.§ 8. During the meeting of the Comunidades or of
the managing committee, the president, explaining the matter and hearing on the same the attorney
and there after counting the votes of the committee members or of other members present, shall
direct the clerk of the Comunidades to record the result of voting and prepare the reply which
should be recorded in the respective book and copy of which shall be attached to the file.§ 9. In all
the cases in which the Comunidades is a party, its attorney shall be notified to constitute a lawyer or
defend the case himself when there is no need of an advocate.§ 10. With the reply of the
Comunidades or of the committee , the clerk after recording the forwarding note, shall send the file
to the administration office, and its secretary, and after recording the note of having received it,
shall soon forward the file to the administrator, who shall record, within ten days, his decision on it
by signing in full and publishing it in the Entry Book.§ 11. When application have been made to
produce evidence or it is held necessary that witnesses be examined, the administrator shall directCode of Comunidades of 1961

to that effect and after hearing in writing over the result, within ten days shall pass the order.§ 12.
The parties are not entitled to go though the proceedings when they fail to attach the document of
the power of attorney to an advocate residing in the seat of the taluka, judicial division or junior
division.Article 391.In cases when the decision lies with the Governor-General, the same procedural
form shall be observed, but the administrator shall give his report in the file and forward the same to
the Directorate of Civil Administration Services, and the parties shall be notified of it, if the power of
attorney to an advocate is attached.Article 392.When the requests made do not require the hearing
of the Comunidades or of the managing committee or of any other entity or person, as parties to the
case, there shall be no need to open a file and the decision or report shall be recorded in the
application at the margin or below the request.Article 393.All the proceedings concluded shall be
filed at the administration office, by the respective secretary, who can issue, without any order from
the administrator, certified copies of their content or a narrative description.Article 394.All the
process shall be on plain paper, in terms of general law, and the losing party shall be ordered, at the
end, to pay the costs and stamp duties, which shall be assessed by the secretary of the
administration and recovered in terms of this Code.§ 1. All the stages of the proceedings, including
petitions, till they are submitted to the Governor General, shall be conducted without collecting fees
in advance, when one of the parties is the comunidade, however the amount of the stamps duties
and costs shall be assessed and paid at last by the losing party, when it is not the comunidade, that
shall not required to pay for any thing excepting stamp duty and costs of the records processed at
level of the tutelage authority.§ 2. At the request of the attorney of the Comunidades or ex-officio,
the administrator may require that the opposite party, when it is not guaranteed, sign a bond for the
guarantee of payment of stamps duties and costs, which amount shall be fixed by the administrator,
after consulting the secretary and this bond can be given by personal guarantee under the terms of
the Code of Civil Procedure (Código de Processo Civil).Article 395.The administrator and the
Governor General can order that files inter-connected may be joined and suspend any other until a
decision is reached on another or others on which they may be dependent.§ 1. However, all pending
case files that may be of same nature and between the same parties, where one of them is the
comunidade, shall be joined, in order to be disposed and decide jointly.§ 2. The tutelage authorities
may request necessary clarifications for the good appreciation of the matters submitted for their
resolution.Article 396.Unless in urgent cases or as otherwise provided in any legal provision, the
following norms shall be observed in the conduct of the proceedings, failing which the offenders
shall incur a fine of 60$ to 300$:
1. The administrators should give decisions, which are not of routine
administrative nature, or give information on proceedings which may require
to be submitted for the appreciation of tutelage authorities, within a period of
ten days.
Sole § The decisions of routine matters shall be given immediately.Code of Comunidades of 1961

2. The secretaries of the administration offices and the clerks of the
Comunidades are required to conclude the proceedings and to do other
procedural work within 48 hours.
3. The technical experts shall conclude studies that are entrusted to them
within the time period fixed by the administrator, after assessing their
volume of service and the value of the project they are supposed to study.
4. The staff of the administrations office and the clerks of the Comunidades
shall render information or clarifications asked by their superiors within the
period of five days.
5. The Comunidades and the managing committees shall deliberate or report
on proceedings or application that may be presented to them, within the
period fixed by the administrator, and the clerk shall return the proceedings,
with the copy of the resolution adopted, within three days of the meeting.
Chapter XIV
Appeals or complaints in general
Article 397.The appeals and complaints against the resolutions of the Comunidades or their
managing committee, which are within the powers of the administrator to decide and for which no
special procedure has been laid down in the Code, shall be filed within ten days from the date on
which they become known, if the appellant or complainant has taken part in the resolution or if he
has been communicated and in other cases within fifteen days of the resolution.§ 1. The appeal shall
be filed by an application setting the due grounds and submitted, in person or through a legal
counsel to the clerk of the Comunidades or the secretary of the administration office who shall give a
receipt for it, indicating the date of receipt and recording the said date in the margin of the
application.§ 2. The provisions of the preceding paragraph shall apply to the complaints.§ 3. If the
appeal or the complaint is submitted to the clerk of the Comunidades, he shall attach to the same, a
copy of the impugned resolution contested and the respective documents, specially those mentioned
in the appeal, obtaining authenticate copy of the same, if it is not possible to obtain the originals
from archives and within three days shall forward it to the president, who shall convene the meeting
of the Comunidades within three days, following the formalities prescribed in the article 33 and its
paragraphs or a meeting of the managing committee depending on whether the appeal or complaint
has been filed against the resolution of former or latter, so that they may submit their reply.§ 4. If
the appeal or the complaint is submitted to the secretary of the administration office, he shall annex
to the same a copy of the resolution, if it was submitted earlier to the administration office, and
other relevant documents in his possession and with the order of the administrator he shall forward
it within three days to the clerk of the Comunidades for him to follow the procedure prescribed in
the preceding paragraph.§ 5. All the appeals or complaints shall be duly processed.§ 6. After theCode of Comunidades of 1961

appeals or complaint has been forwarded to the administration office, with the reply referred to in
the final part of paragraph 3, the evidence shall be led if so applied by the parties, or if the
administrator so directs.§ 7. The files shall be made available to the advocate of the parties, for a
period of ten days, for examination only for the purpose of filing arguments, in case a wakalatnama
is attached to the file.§ 8. The attorney of the Comunidades shall issue wakalatnama to a lawyer as
soon as he comes to know of an appeal against the Comunidades and if he has not done so until the
file is sent to the administration office, he shall be notified for this purpose, save when there is no
need of a lawyer, but in such case the decision shall be communicated personally to the attorney.§ 9.
What is prescribed in the preceding chapter shall be followed in all other matters.Article 398.When
the appeal or complaint is made to the Governor-General or to the Administrative Tribunal what is
prescribed in the Overseas Civil Service Statute and in the Overseas Administrative Reform,
respectively shall be followed.Article 399.The costs shall be calculated by the secretary of the
administration office.Sole § - In case of paragraph 1 of article 394, the costs of the proceedings shall
be calculated before forwarding to the higher tutelage authorities and the appellant or the
complainant, when is not the comunidade, shall deposit the costs and the stamp duties, failing
which the appeal or the complaint shall be dismissed.Title IIIShares of Comunidades
Chapter I
Issue of share certificates
Article 400.The number of shares of the Comunidades and the method of dividing the income of the
Comunidades and determination of the annual dividend on the same shares is indicated in map No.
8.§ 1. This map constitutes an extract from the catalogues existing in the various administration
offices, where shares certificates and the name of the respective share-holders are registered,
besides showing the operations of the same.§ 2. Each one of these catalogues shall have two
alphabetical indexes, the first one pertaining to the names of the share-holders to whom the shares
certificates were issued or transferred, and the other pertaining to the names of those in whose
favour any pending charges have been recorded.§ 3. The Catalogues, which in future may be needed
in the replacement, shall be organised as per model No. 15.Article 401.The face value of each share is
of 120$, and its real value is the sum of the last twenty annual dividends.Sole § The share certificate
is a printed form, as per model No. 16, and contains handwritten serial number of the title
document, its value, the name of the shareholder and that of the comunidade, the number of shares
it represents and the date of issue. It shall be signed by the administrator, the president of the
managing committee and by the clerk of the comunidade.Article 402.Each certificate may represent
one or more shares but not more than ten.Article 403.The total number of shares issued by each
Comunidades shall always be divisible by 100.Article 404.The certificates of more than one share
may be divided, at the request and at the cost of the parties concerned. The new share issued, in lieu
thereof, should indicate the same number as those of dividend certificate, followed by alphabetical
letters to indicate the new numbering and the order among the shares, at the reverse of each such
share, mention shall be made of the charges attached to the original share which, thereafter should
be destroyed.Article 405.The shares into which the original certificate was divided may again be
grouped into a single certificate, at the request and at the cost of the party concerned. To this new
certificate the old original number shall be assigned, and the provisions of the preceding article, asCode of Comunidades of 1961

regards charges and its destruction, shall be applicable.Article 406.The shares certificates of less
than ten shares may also be grouped until that number is made up, but in this case the renewal shall
be at the cost of the party concerned and the new certificate shall bear the number of the old original
certificate.Article 407.No stamp duty is payable for the division or grouping of shares
certificates.Article 408.The issue of new shares, by division of the old certificates, shall be
mentioned in the catalogue against the divided share and the new shares shall bear the original
number.Article 409.The conversion of any alienable interest, when it is not yet done, shall be made
in accordance with article 451 and the following ones of the regulations approved by Provincial
Notification No. 591, dated 30th October 1886, it being understood that the twenty and twenty five
installments provided for in the clauses 2 and 3 of the said article 451 are of the twenty and twenty
five years preceding the publication of this Code, and that the divider 10 indicated in the clause 5 of
the same article should be considered as 20.
Chapter II
Transfer of shares
Article 410.The ownership of the shares is transmissible and in order to carry out the operation of
the transmission, it is sufficient to indicate on the reverse of the respective share certificate, the
name of the transferee with the remarks "belongs to" [pertence] [ As per Dictionary Jayme de
Seguier, the word 'pertence' means: declaration which is made in some little documents indicating
the person to whom the ownership of the same is transfered.].Article 411.It is not lawful to make the
transmission of one share certificate in favour of more than one person, except when they are
husband and wife.Article 412.In the [transmission] [[To use the word 'transmission' instead of
transfer and word 'transmitter' (instead of transferor).Because as per Indian law there is difference
between 'transfer' and 'transmission'. First is intervivos and other is causa mortis. Such
differentiation is not there under the Portuguese law.]] intervivos, the remark "belongs to" when
made in the office of the administration shall be signed before the administrator for the transmitter
whose name is found in the original record, or by the transmission by way of "belongs to"
subsequently entered and followed by noting of registration of such transmission; when it is not
effected before the office of the administration, the signature of the transmitter shall be
authenticated by the notary.§ 1. The regulation of the transmission shall be made according to
model No. 18.§ 2. When the transmitter does not know or cannot sign, the transmitter shall be
recorded in the presence of the administrator or public notary when another person signs, at the
request of the transmitter, with two witnesses present thereto, but in the second case the public
notary shall certify, while attesting the signatures, the presence of the transmitter, in person.§ 3. The
transmission may be signed also by an attorney, with power of attorney given for disposal of
movable property, which shall be filed in the administration office, except when it is registered in
the respective book of the notary.§ 4. In the registration of the transmission drawn out in the way
provided in this article, the administrator shall declare the manner how the signature was affixed by
the transmitter and authenticated, the name of the notary and the mention of usufruct rights having
been reserved, when the transmitter has made such reservations.Article 413.In the transmission
inter vivos by use of expression "belong to" on the certificate, the kind of contract or ground of
transmission may be declared, and in the absence of such a declaration, the transmission shall beCode of Comunidades of 1961

deemed to have been done by way of sale.Article 414.If the transmission is to operate causa mortis
or by act inter vivos, by way of document authentic or authenticated, or by sale effected in inventory
proceedings or execution proceedings before the court or administrative proceedings or the
establishments of pledge duly authorized or in view of judgement of the court, the expression
"belong to" shall be recorded by the administrator and signed by him, with reference to noting of
transmission previously made (model No. 18).Article 415.The registration [averbamentos] ['averbar'
as per the said Portuguese Dictionary of Jayme de Seguier means: 'to write in the form of a note on
the margin of the deed', 'register.'] of the transmission inter vivos according to the share certificate
authenticated in the manner provided in article 412 and its paragraphs shall be made by drawing in
the presence of the transmitter and declaration signed by the transferor, or by another person, at the
latter's request, authenticated by the public notary, as per paragraph 2 of the said article, indicating
the number of the shares and of instrument of transmission, the name of the Comunidades that has
issued and the name and residence of the person in whose name the transmission is done.§ 1. Such
declaration is dispensed with when the transmitter signs the note of the presentation recorded in the
entry book, personally or through other person at the request of the former, in presence of two
witnesses when the former does not know to sign.§ 2. If the person who signed the instrument of
transmission dies, the declaration referred to in this article shall be done by the person in whose
favour the shares have been transferred, who shall declare the names and the addresses of the heirs
and its representatives, who shall be given notice to raise any objection within eight days and in
event of any objection is filed the party shall be advised to follow the ordinary means in case of a
claim.Article 416.The registration of transmission, operated by way of a contract contained in an
authentic or authenticated document, shall be based on the copy of the deed or of the authenticated
document itself, which shall be filed at the administration office.Article 417.If the transmission has
operated by virtue of judgement of a court of law that has become res judicata or by way of sale, by
auction, by award or by remission, in the inventory proceedings, in execution proceedings or
establishment of pledge, the registration shall be done on the strength of certificate of auction or
certified copy of document recording the transmission, the number of the share certificates or the
instrument of transmission, the name of the issuing Comunidades or of the share holder to whom
the share certificate belongs and that it is free from previous charges.Sole § When the judge in the
execution proceedings is the administrator himself, the registration shall be done on the strength of
the report of auction and the order which declare the shares is free of charge to the purchaser.Article
418.If the transmission has operated causa mortis the annotation shall be done on the strength of
the document to prove that the ownership of the share has passed to person who is seeking that the
transfer be made in his favour.Sole § When the value of shares transferred in favour of forced heirs
or legal heirs does not exceed 1.500 $, the transferees may obtain final entry of transmission in their
favour by proving their rights as per paragraphs 1 and 2 of article 25.Article 419.The registration of
the transmissions shall be made as per model No. 19.Article 420.The transmission of shares inter
vivos is not liable of payment of tax levied on the successions and gifts, but on the transfer recorded
on the reverse of the share certificate inter vivos or causa mortis are liable to pay the stamp duty
payable as per the law in force on transmission by way of expression "belongs to".Code of Comunidades of 1961

Chapter III
Creation of charges
Article 421.The shares certificates of the Comunidades may be offered as security for payment or
liabilities by way of a [pledge] [Art. 853 of Civil Code.] or an [usufruct] [Art. 2197 of Civil Code] and
consignment of [income] [Art. 873 of Civil Code] only by a shareholder, but who has full ownership
of the shares, duly registered.§ 1. It is not lawful to create charges referred to in this article, by way
of notice recording by an act of agreement in the share certificate itself, except for the purpose of
creation of usufruct, but it shall be done by a special document or contract following the formalities
prescribed in the general law for such cases.§ 2. It is lawful to make registration of the Civil Suit for
recovery of the share certificate of Comunidades in order that the judgement become executable
against the transferee subsequent to the registration.Article 422.Upon the presentation in the
administration office the contract or the document wherein the pledge, usufruct or consignment of
income is stipulated and the respective share certificates, their presentation shall be noted in
accordance with article 433, after the charge is registered, according to model No. 19 and the
corresponding record is made on the shares certificates according to model No. 20.Article 423.It is
lawful to any shareholders to seek provisional registration of charges in his share certificates
registered in his favour.§ 1. Such registration may be done on the strength of the application of the
shareholder, with his signature attested in accordance with article 412 and its paragraph 2, and from
there it will be reflected the type of charges to be registered, its terms, the name and residence of the
person in whose favour the charge is created.§ 2. When the shareholder is present or his attorney
produces the application and the respective shares, a note will be taken of their presentation in
accordance with the article 433, and the respective registration shall lapse, if within 30 days is not
converted into final by the person in whose favour the charge is created.§ 3. The effect of conversion
of provisional registration into permanent shall have retroactive effect from the date of presentation
of application for provisional registration for the purpose of preference or other legal effects.§ 4. A
shareholder who secure provisional registration may submit an application, in accordance with
paragraph 2, requesting for its cancellation, proving by declaration, signed by the person in whose
favour the charges was created, with the signature authenticated by the public notary, that the act or
contract for whose security the provisional registration was made, was not executed.Article 424.The
seizure or attachment of shares shall be effected in the administration office, after satisfying that as
per the catalogue and the book of annotation, that the respective share certificates are annotated in
favour of the person appointed or one authorized by him and which are there charges which burden
on them writing the result in the respective record which shall also be signed by the secretary of the
administration or his substitute.§ 1. In order to effect the attachment in the execution in cases which
are pending in the office itself, there is no need of separate warrant.§ 2. The shares that are issued or
carried in the names of other than those indicated as per the writ or warrant shall not be seized or
attached.§ 3. The clerk who effect the attachment or seizure shall remit to the administration office a
copy of the respective record, making a necessary note of presentation so that on the base of the
same a competent annotation is made.§ 4. When the seizure is made in pursuance of suits filed in
the administration itself, the registration shall be made based on the original report.§ 5. The clerk of
the Comunidades or the respective official attaching or seizing the shares shall notify the holder of
the certificates of the shares attached or seized, to surrender them in the administration office,Code of Comunidades of 1961

within eight days, failing which he shall be liable to be prosecuted for disobedience and thereafter
the necessary note shall be made and kept in deposit at the administration office.§ 6. When, the
shareholder, after the notification referred to in the preceding paragraph, declares that the
respective shares are pledged in safe treasury or are in private hands, the administrator shall, in the
first case, request the competent entities to forward the respective certificates within eight days and
in the latter case, he shall order the issue of the notification to the creditor to surrender the same
shares within the same period, to enable to make the necessary note of attachment or seizure of
those certificates. The shares thereafter shall remain in deposit in the administration office.§ 7. If,
after seized or attached, those shares are presented in the administration office for any registration,
they shall be retained and the necessary note of attachment or seizure shall immediately be made on
them (model No. 20).§ 8. After the annotation of seizure or attachment is made the administrator
shall order the clerk of the respective Comunidades to retain its dividends in the safe at the disposal
of the person who determined the attachment, when this is the case.§ 9. Once the seizure or
attachment is cancelled as result of a judgement or administrative order or on account of the
satisfaction of the executive proceedings in the administration office itself, the dividends accrued
and accumulated in the safe shall be free to the holder of the seized or attached shares, if nothing is
mentioned as regards them in the order or final judgement.§ 10. If the holder of certificate of shares
fails to surrender the same in pursuance to the notification prescribed in paragraphs 5 and 6, and
fails to justify its loss or existence in the hands of another person, the administrator shall prepare a
report and forward it to the Public Prosecutor in order to impose the penalty to such a possessor for
disobedience. He shall consider such certificates cancelled and issue a new ones in the form
provided for in No. 2 of article 436.Article 425.Action shall be initiated as provided for in
paragraphs 5, 6 and 10 of the preceding article in the event when by order or final judgement of the
court it is directed that the shares be delivered, on any grounds, to a person other than the possessor
and the latter refuses to surrender them even after being notified to this effect.Article 426.In the
execution and other proceedings in which the sale of shares is ordered, the persons in whose favour
any charge is registered shall be summoned for the proceedings of the recovery suit or sale and
claim their preferential rights in accordance with the general law.§ 1. The cancellation of seizure and
attachment or any other charges on the shares sold shall be made in view of the judgement that
declares them free from encumbrances, and as regards the dividends accrued and accumulated in
the safe, the final part of paragraph 9 of article 424 shall be observed.§ 2. In the execution
proceedings filed in the administration office itself, the cancellation shall be effected on the strength
of the respective proceedings.Article 427.The reversion of shares to the original state prior to the
creation of any note of charges, shall be made by means of the cancellation of the respective
registration of charge (model Nos. 19 and 20).Sole § In the presentation of documents for
cancellation and subsequent proceedings, the same rules shall be followed as prescribed for the
registration.Article 428.The registration or the cancellation of the charge on the shares shall be
recorded in the share register book of each comunidade, in the form prescribed in sole paragraph of
article 546.
Chapter IV
Common provisions dealing with transfer of shares and creation
of chargesCode of Comunidades of 1961

Article 429.The transmission of shares indicating the name of transferee (pertence - belongs to) or
any charges created on them shall have no effect at all as far as third parties or Comunidades are
concerned, before its registration in the administration office.§ 1. In the transmission of shares, with
consignation of usufruct of its dividend, the right to the same starts on the day of the respective
registration in the comunidade, except when it is expressly otherwise provided for.§ 2. Any
agreement entered on the same subject shall not be recorded as transferee (pertence) and the
document drawn for this purpose shall be produced in the administration office along with the
shareholder certificate whereon pertence (belongs to) is considered for the purpose of
registration.Article 430.The registration of whatever type they may be, will be noted in the catalogue
of shares, referred to in No. 9 of article 440, writing thereafter in the index the number of the share
certificate registered or in whose favour the charges, are created.Article 431.For the purpose of
registration of transmissions and of the charges recorded on the shares, there shall be, in the
administration office, two books of registration - one meant for registration of transmissions and the
other for registration and cancellation of charges.Article 432.In order to carry any registration, the
following documents shall be produced in the office of administration:- share certificates, along with
documents creating security, pledge, usufruct or consignment of the income, and those by which the
transmission may be proved.Sole § When the documents are presented by a person, other than the
interested party, one more declaration signed by the latter and attested by the public notary, shall be
required.Article 433.With the presentation of the shares certificates and correlative documents, a
note shall be made in the entry book of such presentation, signed by the person who presents them
and of the transferor in case of paragraph 1 of article 415, or any other person on his request and two
witnesses when the former do not know to sign.§ 1. The registrations shall be made and preferences
regulated, in the order of these entries, if the registration were not refused.§ 2. A single registration
may be made when the presentation refers to the shares of different Comunidades.§ 3. When, on
account of insufficiency of documents or defect of the "pertence"(transmission), the registration is
refused, the administrator shall issue to the applicant the note of refusal, in order that the latter may
file an appeal to the Administrative Tribunal.§ 4. In case the appeal is allowed, the registration made
as a result thereto shall be deemed to have been made on the original date of presentation.§ 5. Once
the registration is refused, due to insufficiency of documents or for irregularity in the annotation of
transfer, the annotation cannot later on be allowed based on the same documents or captions
"belongs to", except when the applicant clarifies the doubts or obtain favourable decision on
appeal.Article 434.When the registration of transfer or charges has been made, the administrator
shall order to put in the respective shares certificates the necessary captions "belongs to", and sign
them with his full name, as per model No. 17 and 19.Article 435.The declaration of transferor and
the documents based on which the registration was made, shall be filed in the administration office,
when the documents are not certified copies from the books of public office.
Chapter V
Reconstruction of share certificates
Article 436.Share certificates may be reconstructed only on following cases:-(1)In case of
destruction, loss or disappearance of the share certificates proved before the administrator, with
prior advertisement in the Official Gazette and in a local newspaper inviting, within sixty days, anyCode of Comunidades of 1961

one who may have interest to take notice of the reconstruction, except when the remains of the
destroyed shares certificates are shown to the administrator and thus their identity can be satisfied,
in which case no further proof is required;(2)In the cases referred to in paragraph 10 of article
424;(3)When at the back of the certificate there is no sufficient space to make further noting of
"belongs to" of transfer and annotation;§ 1. In any of those cases, the new share certificate shall have
the same original number, with the addition of a letter from the alphabet, in due order, and a
mention that the certificate has been reconstructed and the charges still in force shall be copied on
the back. The original certificate shall be destroyed by the administrator.§ 2. Whenever a new
certificate is issued without the previous one being destroyed, due to refusal to surrender the same
or as its disappearance or loss has been proved, the administrator shall announce this fact in the
Official Gazette indicating the number of the certificate and that of the share and in whose name it
was issued or the last registration of transfer was made.§ 3. The stamp duty is not payable in case of
reconstruction and division of shares.Article 437.The share certificate may be reconstructed and
divided by those who are interested in the same by applying and paying its expenses.
Chapter VI
Prescription of shares in favour of Comunidades
Article 438.The Comunidades acquires shares of the Comunidades by prescription if the dividends
are not claimed for thirty consecutive years.Sole § On expiry of this period, the administrator,
having complied with the formalities prescribed in paragraph 1 of article 25, shall order their
registration in favour of the comunidade, when there is no complaint, or when the claimer, having
been advised to take up ordinary means, fails to initiate competent action within thirty days, with
service of summons on the comunidade, in order to establish ownership.Article 439.The suit for
cancellation of the annotation of transfer of shares of Comunidades is barred after the lapse of
fifteen years from the date of annotation, if the person registered had collected the dividends and is
in good faith, or after thirty years irrespective of good or bad faith.Title IVBook-keeping and
accounts
Chapter I
Book-keeping and accounting of the administration of
Comunidades
Article 440.At each administration of Comunidades the following books, for general office work,
shall be supplied from the general fund:-(1)Book of recording of handing over of the
charges(2)Muster-roll.(3)Entry Book.(4)Book of registration of directives from higher authorities
for permanent execution.(5)Book for the registration of correspondence with the Directorate of Civil
Administration and of the reports on the applications and files submitted for decision of the
Governor General and Administrative Tribunal.(6)Book for the registration of correspondence with
the various authorities.(7)Book for the registration of correspondence and instructions addressed to
Comunidades.(8)Book for the registration of securities.(9)Catalogue- book of shares, one per each
comunidade.(10)Book for the registration of transfer of shares.(11)Book for registration andCode of Comunidades of 1961

cancellation of charges on the shares.(12)Book for distribution and registration of execution
proceeding.(13)Book for the returns, expenses and derramas of the general safe of the
Comunidades.(14)Book of revenue from common fees.(15)Cash-book.(16)Current-accounts book
with the Comunidades.(17)Inventory book.(18)Book for the registration and accounts of the advance
fees made.(19)Book for the registration of files of emphyteusis and others.(20)Book for the
registration of emoluments and salaries paid in the proceedings.(21)Book for confidential
correspondence.§ 1. All the books shall be of a thick paper, known as almaço and shall have opening
and closing declarations, sign by the administrator, who shall also initial all the pages, asking any
employee of the Comunidades to number them.In the closing declaration at the book mentioned
shall be made of the total number of pages of each book.§ 2. The books Nos. 1, 3, 9, 10, 11 and 12
shall be maintained as per the model Nos. 21, 22, 15, 18, 19 and 23 respectively, and the books Nos.
18 to 20 according to the models indicated by the Directorate of Civil Administration.§ 3. The
keeping of books Nos. 14 and 16 and the accounts of the general safe shall be regulated by the
provisions set down for the book-keeping and accountings in the Comunidades.Article 441.The
Entry-book shall be divided into two parts: The first for record of applications and official papers
received and the second for noting the presentation of certificates of shares and documents for
annotations.Article 442.On each page of books -Nos. 4, 5, 6 and 7 a necessary margin shall be kept
on both the sides, sufficient to mention, on the right margin the extract of the letter, note or
documents registered and on the left any previous or subsequent references to the subject.Article
443.The annual budget, referred to in No. 3 of article 125, shall be organised by the secretary of the
administration office as a file and the administrator shall give his final say.§ 1. A copy of the
preceding year's budget and his approval's order shall be attached to the new budget.§ 2. A summary
of the income and expenditure, indicating the surplus or deficit, that there may be, shall be shown
on the front page of the file, below the title.Article 444.Certified copies of contents, or of summary of
what is recorded in the books of the office and of the papers and proceedings that are pending or
filed, shall be issued by the secretary of the administration, independently of the order of the
administrator, on payment of normal fees.§ 1. The certified copies of the recovery proceedings of
dues which are in progress and the one delivered to the debtor, after the final judgement, to be used
for the purpose of payment, shall also be issued without order of the administrator, but by the clerk
in charge of the execution.§ 2. The certified copies relating to proceedings filed in the administration
office shall also be issued according to this article.§ 3. The duplicates of all the certified copies of the
extract of the abstract, issued shall be retained and filed chronologically in the administrative office,
by the dealing clerk.
Chapter II
Book-keeping and accounting of the Comunidades
Section IGeneral provisionsArticle 445.The Comunidades shall have the following books for their
records and accounts:-(1)Entry book.(2)Minutes-book.(3)Cash-book.(4)Book of income and
expenditure.(5)Current-accounts book.(6)Book of transfer of current
accounts.(7)Charges-book.(8)Contracts-book.(9)Sundry declarations and reports book.(10)Book of
orders from higher authorities.(11)Book records of the encroachments.(12)Books for the registration
of claims.(13)Books for the primary enrolment of the Zonnkars (1st entry)(14)Book of primaryCode of Comunidades of 1961

enrolment of the sharers holders.(15)Book of pensioners and stakeholders.(16)Register 1 (Tombo
1).(17)Register 2 (Tombo 2).(18)Inventory book.(19)Outward correspondence book.Sole § All the
books shall have continuity in their writing except the current accounts book which shall be written
yearly.Article 446.The book shall be made of a thick paper known as almaço of the model approved
by higher authorities, and shall have an opening and closure declaration, both signed by the
administrator who will also initial all their pages, directing the clerk of the Comunidades to number
them.In the closing declaration mentioned shall be made of the number of pages of each book.Sole §
The writing should be simple and clear, without insertions between the lines or erasures unless they
are indicated to at the end of the report, act, declaration or registration in which they are
made.Article 447.All entries shall be made with cross reference with the page, book or documents to
which they relate are related.Article 448.All the acts, records, items and minutes shall be written in
the respective books with clearly so as the reading become readable.Article 449.The amounts shall
be written out in words and in figures in the proper places.Article 450.From one item to another or
from act written to other, only the indispensable space shall be left open.Article 451.No entry or act
written in the book shall be signed without first being read to those who have to sign it and without
correcting the errors which may have been occurred.Article 452.All books shall be ready and duly
initialled no less than one month before finishing those that are in use.Article 453.The finished
books which are not necessary for the ordinary annual writing, shall be duly filed, each bearing the
appropriate label, indicating the nature of the book and the year to which they relates and such filing
shall be recorded in the inventory.Article 454.All the budgets, proceedings and other papers of the
Comunidades shall also be filed in the same manner, collected in bundles, divide year wise and
subject wise, each bundle bearing a list indicating the papers its contains.§ 1. The documents whose
originals are required to be sent to the authorities on their instructions, shall be replaced in the
respective bundles, by copies officiously drawn and authenticated by the clerk of the comunidade,
who have taken them.§ 2. The finished books and the papers more than years old, shall be collected
in the archives of the administration office, under the terms of the sole paragraph of article
133.Article 455.Certified copies of text or abstract of content or of summary certificates of both
current books and papers, and also those from the archives of the comunidade, shall be issued by
the clerk of the Comunidades independently of any order, except as established in paragraph 1 of
article 493 of the Overseas Services Statute (E.F.U.).§ 1. The certificates of full text (Known as of
teor) shall be issued by copying literally the documents from which they are taken.§ 2. When the
registered act contains various subject not inter related and a copy is requested of one or more
subjects, the certified copies shall contain the word for word copy of the preamble of the act, of the
subject asked for, of the closing and of the signature, indicating in dotted lines the unconnected
matter which has not been copied down.§ 3. The summary certified copied of the extract, when
referring from to the inventory Tombo 2 shall contain, besides the inscription, all reference to the
charges of encumbrances registered on the property in question.Article 456.All the certificates shall
be issued by the clerk of the Comunidades within 5 days, failing which he is liable to pay a fine of 30
$.Sole § If the time-limit of 5 days is insufficient to issue the certificates asked, the administrator
may extend it at the well justified request of the clerk of comunidade.Article 457.Each archive shall
have an inventory of all the books, documents and other papers, indicating the state in which they
are found.§ 1. Based on this inventory, the administrator shall check, whenever he finds convenient,
the archives of the Comunidades, and certify the existence, the state of preservation and order of the
books, documents and other papers, contained in the same and shall mention its findings in theCode of Comunidades of 1961

book of sundry declarations.§ 2. The administrator and the secretary of the administration office
shall not be entitled to any emoluments for the work of inspection, but only the conveyance
allowance.Article 458.No book or papers shall leave the archive of the comunidade, except when
taken to the administration office and by the order of the administrator or in the cases provided for
in this Code.Sole § In the criminal proceedings or any other, the books of the Comunidades may be
examined in the respective archive, with the prior notification to the administrator indicating the
date and hour, or in the administration of the Comunidades office where all the necessary books
shall be requisitioned.Article 459.The special way of keeping each book is defined in the rules and
models prescribed in the following sections.Article 460.No resolution may be taken or no act of the
interest of the Comunidades can be enforced, unless it is found recorded in the competent book.§ 1.
The clerks of the Comunidades who record such acts on loose papers or in an improper book shall be
punished with the suspension from duties without pay for thirty days.§ 2. When, for any reason, it is
not possible to record an act in the proper book and there is urgency for such an act, the
administrator, after being satisfied about the circumstance, may authorise that the recording may be
done in other book indicated by him, and from which it shall be transcribed in the proper book as
soon as possible.Article 461.The books of the Comunidades have full faith and credit and its achieves
shall be deemed public for the purpose of paragraph 2 of article 2423 of the Civil Code.Section
IIMinute-bookArticle 462.The minute-book shall contain the minutes of the managing committee
and of the comunidade.§ 1. This book shall have in each page two columns, one on the right margin
and the other on the left. The former shall be used to record the note of previous or subsequent
minutes which are related and the latter shall be used to record the abstract.§ 2. The minute shall
record the views of the majority and the votes and protests of the minority.§ 3. The wording of the
minutes is within the power of the presiding officer of the meeting; the single vote of any of the
members and the consultative vote of the clerk of Comunidades shall be drafted by
themselves.Section IIICash-BookArticle 463.All the revenue and expenses of the Comunidades shall
be collected in and paid at the office of comunidade, and all the entries and monies entering and
leaving the safe shall be recorded in the cash-book.Article 464.The cash-book shall be written
according to model No. 24, by recording the amounts entered on the left page and on the right the
amounts paid, the latter being signed by those who receive the money. The closure and opening of
the safe shall be signed by all the key holders.Sole§ In the closure declaration referred to in this
article, mention should be made of the total amount received and paid.Article 465.On each page,
two columns shall be opened on the right and one on the left, the latter one for the current accounts
to which a credit or debit shall be carried forward and the sum of the entries and issues, and the first
of the former to be used for entering in figures the amounts received and paid during the present
management and the second one for those of the previous management.[Article 466.] [Article 466
has been amended by Goa Act No. 3 of 1998 dated 17/01/1998. (See Appendix)]At the end of each
quarter, the clerk of the Comunidades after calculating the sum of the incomings and outgoings
amount, shall prepare the balance on a separate sheet of paper, determining the cash balance and,
together with the other key holders, after checking that this balance exists in the safe, shall certify
the balance in the safe, signed by the same key holders, forwarding the same to the administration
office during the first eight days of the next month. Failing to do this the clerk shall be liable to pay a
fine of 60 $.§ 1. Similar fine shall be imposed by the administrator on the key-holder who causes
delay in sending it, fail to justify to be present at the verification of balance in the safe, without
giving a proper justification for his absence, within five days.§ 2. The sums which have beenCode of Comunidades of 1961

forwarded to constitute this balance, shall refer to the page of the cash-book, from where they were
taken and shall also indicate the serial order of the amount entered and issued.§ 3. In addition to the
quarterly balance sheet foreseen in the main body of this article, a monthly balance-sheets may be
asked to prepare by the higher authorities and in accordance with the instructions issued for this
purpose by the Directorate of Civil Administration.Article 467.At the end of the management term, a
final balance sheet shall be prepared in the same manner in the cash book and compare it with the
actual balance that has been calculated and confirmed, to which shall add any arrears, advance
payment and a list of creditors to who the respective amount belongs. All this shall be made as per
model 24 and this balance and list shall be signed by the key holders and attorney on the out going
members.Article 468.After the list is prepared and, during the first days of March, a statement shall
be made to hand over, with the intervention of the managing committee, to the new key holders, the
money found in the safe, and then the new accounting shall start by transferring thereto under item
No-1 the money found in the prescribed form.Article 469.When from the result of the balance
foreseen in this section or from the extraordinary balance sheet prepared, the administrator is
satisfied that the balance, indicated in the cash book, does not exist in the safe, a certified copy of
the current account shall be issued and sent to the administration office, according to the provisions
of paragraph 1 of article 562, without prejudice to criminal and disciplinary proceedings.Section
IVIncome and expenditure bookArticle 470.The income and expenditure book shall be used to
prepare the yearly income and expenditure statement, determining the net income or deficit of the
comunidade.Sole§ This book shall be maintained according to model No. 25.Article 471.The income
comprises:
1. The indivisible balance from previous year, carried over to the new
committee;
2. Any amounts that were set apart on previous pages and in fact were not
spent;
3. Any sums that entered the safe under the management of the previous
year but belonging to the income of the year;
Under the title - Invariable:
4. The foro from emphyteusis of Comunidades;
5. Any certain and inalterable contributions that the interested parties have to
pay to the Comunidades;
Under the title - variable.Code of Comunidades of 1961

6. The rent of the rural properties of the Comunidades;
7. The rent of its urban properties;
8. The income from fish, straw, honey, wax and from any other contract of
the Comunidades;
9. The income from variable contributions due from the parties;
10. The interest on loan;
11. The interest for late payment on the arrears, paid by the debtors;
12. And finally, any other income received occasionally.
Article 472.The expenses shall comprises:-Under the title-invariable.
1. The tribute foros that the Comunidades pays to the National Treasury until
the cessation of such payment in terms of sole paragraph of article 5;
2. The foro that the Comunidades pays to private individuals;
3. Any duly authorised fixed charges that the Comunidades must pay;
4. The pay of the clerk of the comunidade;
5. The wages of the porter or crier and other employees;
Under the title-variable.
6. The subscription the Official Gazette of for subsequent year;
7. The contribution to the general safe;
8. The property tax and other taxes payable to the National Treasury;
9. The price of ordinary work of dams and others;Code of Comunidades of 1961

10. The probable cost of books, stationery and advertisements;
11. The interest on the Comunidades borrowing;
12. The extraordinary expenses legally authorised;
13. Any other expenses duly authorised.
Article 473.All the items of income shall refer to the respective sources and shall indicate the page
and the number of the books, where the sum received is accounted for; and those of the expenses
shall indicate their source or the authorization from higher authorities failing which they shall be
immediately cancelled by the administrator.Article 474.The figures of the income and expenditure
shall be considered together find the balance or deficit of Comunidades.The respective statement,
after being signed by the attorney, cashier and clerk of the comunidade, shall be submitted to the
managing committee which shall discuss the same in their ordinary meeting of the month of April
and give its opinion.Article 475.After submitting to vote of the Comunidades and other interested
parties, the clerk of the Comunidades shall forward the statement to the administration office by
16th April, along with a copy of the minutes of the meetings of the committee and of the
comunidade, complains and subsidiary books and documents demonstrating the legality of the
items of income and expenses.Sole§ The statement shall also be accompanied by the files relating to
pending works or those authorized.Article 476.On receiving the statements, the administrator, shall
order the staff of the administration to examine the same, under his responsibility, and shall
approve or have them corrected. He shall indicate in his order, the amount that should be separated
and go to reserve fund, up to the maximum limit of ten per cent of the income, and for payment of
the debts and occasional expenses, setting the rules to be followed in the fixation of the dividends
and return the statements before the 15th June.Article 477.On receipt of the books, the clerk of the
Comunidades shall convene the attorney and the treasurer and, in implementation of the order
issued shall establish the amount to be distributed as zonn and shares, or the deficit to be recovered
from members, all in accordance with model No. 25.Article 478.After following what is prescribed in
the provisions of the last part of the preceding article, distribution shall effect, according to the
statute of the respective comunidade, amongst the zonnkars and the shareholders, declaring the
amount due to each zonnkar and to each share holder. Such declaration should be signed by the
clerk of the comunidade, attorney and the treasurer.§ 1. For the purposes of this article, only
zonnkars registered before the closure referred to in article 200, shall be included for the purpose of
distribution.§ 2. In the Comunidades whose assets have been disentailed, the net income or deficit
shall be distributed, according to the conditions of the comunidade, between different properties in
proportions established in the inventory Tombo No.1, for payment to the respective proprietor or
recovered from him the share fallen due.Article 479.After the distribution is done, the Comunidades
clerk shall send to the administration office, by 10th August, together with the list and the book
referred to in sole paragraph of article 484, a chat mentioning out the revenue, expenses, net income
or deficit and debt payable, everything compared with the respective figures for the preceding year,
in accordance with to model No. 26, issuing at the end a certificate stating the amounts separated
for the purpose of works and payment of debts and the amount referred to in article 476, theCode of Comunidades of 1961

amount due to each zonnkar and to each share and the active debts.Sole§ This chat shall be
accompanied by the current accounts of the National Treasury, when the latter possesses shares in
the comunidade.Section VBooks of current accountArticle 480.The current account book shall be
divided into two parts: the first for annual enrolment of zonnkars and those who are obliged to
contribute to the deficit, and the second of the current accounts of all members, servants and
defaulters.Article 481.The current accounts shall be numbered following the order of the enrolment
of the members and the registration of the shares and after the conclusion, the current account shall
be opened of those who have credit or debit with the Comunidades, including the Pensioners' Bank.§
1. The contractors of the extraordinary works and the clerks of the Comunidades shall have in such
capacity, accounts different from those they may have as members or as contractors for any service
with the comunidade.§ 2. The Comunidades shall also have some space to record in this book the
dividends of its own shares and the amounts of indivisible balance, the amounts that are set aside
for ordinary expenses not put up to tender, for the extraordinary expenses and for payments of any
amount of advance given for work, services or extraordinary supply and for reserve fund, and also
any amounts indicated in the statement on account of advance payments made in the previous
years.Article 482.In the right hand margin of the left hand page of the current accounts book, that is
used for recording the entry of the credit of the member or servants, three columns shall be opened;
the first for recording in figures all the credit sums, the second for carrying over the sum of the same
credit and the third for observations and notes.Sole § Each credit entry shall indicate the number of
the entry of the book from which it has been taken.Article 483.In the right hand margin of the right
hand page, used for recording the entry of the debit of the member or servants, there columns shall
be set up in the same way; the first for recording, in figures, all the debit sums, the second for
carrying over the sum of the same debit and the third for observations and notes.Sole § Each debit
entry shall indicate the number of the entry of the book from which it has been taken.Article
484.The current accounts book shall be kept as per model No. 27.Sole § The clerks of the
Comunidades shall finish the writing of current account entries by 31st July, by crediting and
debiting the amounts to which the members, servants and others are entitled to or which they owe
to the Comunidades up to such date, and shall then prepare a list of the debits of the same, from
lease rent of the properties or contributions to invariable or variable charges, in the case of the
Comunidades assets being disentailed, sending the same to the administration office by 10th
August, together with the book of current accounts.Article 485.The treasurer shall collect these lists
from the administration office, duly approved by administrator by 20th August, and shall then
undertake the recovery by using the means provided for in this Code.Article 486.The current
accounts of the members, servants and other debtors shall be closed from the 11th November till the
end of the same month, and as per its result, the clerk of the Comunidades shall issued before the
8th December, a final confirmed list of the debts of the same.Article 487.The list referred to in the
preceding article shall be presented in the administration office by 10th December, together with the
current accounts book and with the administrator's approval, received by the treasurer on the 11th
and 12th of the same month.Sole § The time limits established in this article and in the preceding
one may be extended by the administrator, in view of the special circumstances of the comunidade,
but never beyond 31st January.Article 488.Once the accounts have been closed and the list is
submitted to the administration office, the clerk of the Comunidades shall send out current accounts
to the debtors, in accordance with article 559.Article 489.The administrators by official notice,
published in the Official Gazette and pasted on the door of the meeting house in each ComunidadesCode of Comunidades of 1961

shall fix , three to ten days for the payment of proceeds of zonn, dividends and credits which were
not paid on the days set in article 106, preferably between 15th January and the end of February.§ 1.
In the public notice it shall declare the proceeds of zonn or the dividend to which to each zonnkar
and each share holder is entitled.§ 2. Alongwith the notice, a comparative chat of the income and
expenditure of the respective Comunidades (model No. - 26) shall be affixed at the gate of the
meeting house.§ 3. The amounts, not collected on the designated days, may be paid, irrespective of
order, at any opening of the safe and the key holders shall be entitled to emoluments only when the
payment is made during extraordinary opening of the safe.Article 490.The payments for deposit
made directly in the safe by the debtors, mentioned in the confirmed list, shall be accepted after the
necessary entries is recorded in the debtor's current accountants book in the column reserved for
the remarks and against the balance in debt.Sole § The clerk of Comunidades shall always issue a
receipt to the interested party for this and any other payments made.Article 491.The payments made
to the zonnkar, shareholders and other creditors shall be taken from the safe of the Comunidades
and shall be recorded, in the same manner, in the current accounts of the creditor, opposite to the
balance in credit.Article 492.After the current accounts have been closed, the clerk of the
Comunidades shall indicate the balance of credit and the debit in the same accounts, as per model
No. 27.Article 493.The credit balance consists in comparing the amounts which are in fact credited
in the current accounts with those that should have been credited.Article 494.The amounts which
should have been credited are:-
1. The amount established in the statement of income and expenditure
referred to in the last part of article 477;
2. The sum of the expenses of the same statement;
3. The amount set aside for the extraordinary works;
4. The remain which is indivisible reserved for the following year;
5. The amount relating to charges;
6. The amount paid by the interested parties or servants in the safe until the
closure of current accounts, in relation to the management of the last year;
7. Any amounts which may have been added to current accounts from
overdue credits or advance payments from the previous year.
Sole § The sum of these amounts, is the first entry in the balance sheet.Article 495.The credited
amount shall consist of the sum of the second column of the left-hand page of the current accounts
and shall constitute the second entry in the balance sheet.Article 496.When the sum of the amounts
mentioned in the preceding article is greater than that of the amounts designated in article 494, the
clerk of the Comunidades shall be held responsible to the Comunidades for the difference, which heCode of Comunidades of 1961

may recovered from the person to whom it was given in excess; in the case of the amounts referred
to in the preceding article being less, the difference shall be found in the safe, from which shall be
paid those who have been paid less.Article 497.The debit balance in the current account consists in
comparing the amounts which are, in fact, debited in the current accounts with those that should
have been debited.Article 498.The amounts which should have been debited are:-
1. The total income of the Comunidades as recorded in the income
statement, less the balance and other amounts received on account of
previous years' credit;
2. The amounts relating to charges;
3. The amount withdrawn from the safe by last year's management
committee, until the closure of accounts;
4. Any amounts belonging to advances in arrears that were included in
current accounts.
Article 499.Those that are debited are the following ones:-
1. The sum of the second column of the right page of the current accounts;
2. The sum of the definitive list;
3. The amounts withdrawn from the safe by the treasurer, whose payment to
the parties concerned has not been effected and is not, therefore, included in
the current accounts.
Article 500.When the total sum of the amounts referred to in the preceding article is less than the
one referred to in article 498, the clerk of the Comunidades shall be held responsible to the
Comunidades for the difference which he may recover from the person whom he paid less; in case
when the amounts referred to in the preceding article being greater, the differences shall be found in
the safe, from which shall be paid those who have been over debited.Article 501.These balance of
credit and that of debit shall be examined and checked by the attorney, within the period fixed for
the closing of accounts, and sign them after making the necessary observations.Article 502.The
current accounts shall be available for examination to the members and other interested parties
from the 13th to the 20th December, and the clerk of the Comunidades is required to issue copies of
current accounts of the same, whenever asked for, duly signed on stamped paper supplied by the
party concerned or on unstamped paper.Article 503.The current accounts of the treasurer shall be
opened at the end of current account book, wherein shall enter, as a charge, chronologically and on
the respective dates, all the amount that he received from the safe, the amounts in debts that he has
to collect, as indicated in the confirmed list and the amounts that he has been entrusted to recover.Code of Comunidades of 1961

It shall be also crediting to such account, in due chronological order, the payments which he makes,
after registering the respective receipts, the amounts that he kept in the safe and those that have
been paid by the debtors, mentioned in the definitive list after the closure of the current
accounts.Sole § Deposits shall be made in the bank known as [Cooperative Bank or where such Bank
is not in operation, in the Post Office Savings Bank as the case may be] [Substituted for the words
'Caixa Economica de Goa' by Goa Act 3 of 1998, dated 17-1-1998.] by the treasurer, within three days
and the sum in question being handed over to him after the respective entry is made in the cash
book. This sum, on each occasion, shall never be greater than the amount decided by the
administration of the Comunidades.Article 504.This account shall be closed by 25th February and
verified and confirmed on this date by the attorney, who shall sign it, recording the observations he
sees fit, and the balance resulting from the same against the treasurer shall be paid by the end of the
same month. If not paid in time, the interest payable shall be at a rate of 6 per cent per annum, from
the following 1st March.Article 505.In the cases referred in the preceding article and in No. 4 of
article 100, the clerk of the Comunidades shall issue the certified copy of current account against the
treasurer, under the terms of article 562 and followings, and send it to the administration office in
the form required by article 564.Article 506.Each certified copy of current accounts issued against
the treasurer or and against the other debtors of the 'comunidade' shall be recorded in the respective
book, opposite to the balance outstanding, in the column for observations.Article 507.On the closing
of the treasurer's account, all the accounts shall be presented to the managing committee and to the
Comunidades at their ordinary meeting in March, to give their opinion on that matter, either
approving them as they are or indicating as to how they should be modified.Sole § During the period
from the 26th February to 15th March the same accounts shall be made available in the house of
meetings, for examination by the parties concerned.Article 508.After the replies referred to in the
preceding article are obtained, the clerk of the Comunidades shall participate to the administrator
before the 20th March certifying that all the requirements of the Code pertaining to the yearly
accounts system have been complied with.Article 509.The administrator, as soon as he receives
these information from the clerk, shall fix the days, by means of a notice published in the Official
Gazette, for auditing of the accounts of the clerks, key-holders and treasurers of the
Comunidades.Article 510.In accordance with this notice, the clerk of the Comunidades shall notify
the key-holders to be present in the administration office on the designated date and shall send to
such office, eight days in advance, the documents of notifications and the books and papers needed
for the auditing of the accounts.§ 1. These books are those indicated under Nos. - 3, 4, 5, 6, 7 and 10
of article 445, and the book of current accounts for the previous years, and the papers are the
receipts in connection with the payment made during the current year to National Treasury, to the
general safe and to other entities, and the copies of the minutes approving these accounts.§ 2. The
administrator may order that these books and papers be send much earlier, for them to examine and
keep the work ready for auditing of the accounts.Article 511.The clerk of Comunidades who fails to
be present, without proper justification, on the day indicated in the notice, shall be fined with 120 $,
and the accounts shall be audited, even in the absence of others who were not present.Article
512.The accounts of the clerk of Comunidades shall be audited as per the balances determined in
article 482 and the following ones; those accounts of the president as per the balance of the
cash-book; and those the treasurer as per his current accounts serving as supporting documents, all
the accounts books, records and papers, referred to in paragraph 1 of article 510.§ 1. In addition to
the responsibility resulting from the balances of credit and debit, the clerk of the Comunidades shallCode of Comunidades of 1961

also be held responsible for whatever excess or undue payment he made to the zonkars,
share-holders and other creditors, without prejudice of the joint and several liability of other
key-holders referred to in paragraph 1 of article 105. This shall be verified at the time of the auditing
of the accounts, showing the balance in the following way:(a)The balance of overdue credit shall
have as its first item the sum of the such credit, determined in the second part of the general balance
sheet of the preceding year, and the second item shall consist of the amounts of this credit included
in the statement, the payments made during the period of management and whatever remains
shown in the general balance sheet; if the sum of the second item is greater than that of the first, the
excess shall indicated the liability of the clerk; if, however it is less, it will show that certain creditor
has not been listed, or that his credit was understated and this fact shall be corrected in the credit
list.(b)The balance of current credit shall have as its first item the sum of the credit recorded in the
current accounts, and second item shall consist of the part compensated in the same accounts, from
what was paid to the parties concerned after the closures of accounts and of what was carried over to
the next management.If the sum of the second item is greater than that of the first, the excess shall
indicate the clerk liability; if however, it is less, it shall indicate that certain creditor was not listed or
that his credit was understated, which shall be corrected in the credit list.§ 2. If, these two balances
sheets result in any liability on the part the clerk, the same balance shall be referred to on the
auditing of accounts, and the certified copy of current account to be issued against the said clerk
shall be, in this case, a copy of the same.Article 513.The outcome of the audit of accounts shall be
recorded in the current accounts book by order of the administrator after entering before that in the
same book the necessary reports of assessments.Sole § In case of appeal against the decision, the
copies of the balances sheets, and of the treasurer's accounts, together with those reports of
assessment made and of the decision shall form the respective case file.Article 514.The clerk of the
Comunidades who fails to keep ready the accounts according to the rules and within the time limit,
shall forfeit one third of his pay and may be dismissed by the Governor General after being heard, if
the irregularity committed result any loss to the Comunidades as a result of the irregularity
committed, this loss may be recovered by means of charges to his accounts and to his guarantor.Sole
§ The administrator shall appoint a person to finalise the accounts and fix up a remuneration
according to the volume of work. This remuneration shall be paid by the comunidade.Article 515.If
punishable irregularities in the accounts are found after conducting the examination, the
administrator shall immediately notify the fact to the Governor General, in order to determine the
criminal and disciplinary responsibility of the clerk.Section VIBook of transfer of creditsArticle
516.It is known as 'outorga' the transfer of credit available from one current accounts to
another.Article 517.The creditor who wishes to transfer his available credit to another current
account shall sign directly or through his attorney, a declaration that he wishes to transfer all his net
credit or a certain part of it in the name of a person who has current accounts in the
comunidade.Article 518.The transfer shall be drawn up as per model No. 28.Article 519.When the
declaration has been signed, the clerk of Comunidades shall write, in figures at the right margin, the
amount transferred, and crediting and debiting in the respective current accounts, shall write at the
left margin of the terms, the numbers of the same current accounts. This shall be the indication that
the transfer requested has been made.Article 520.The credit may also be made by authorization
signed by the creditor of the Comunidades in stamped paper, with the signature notarised, when the
such a signature is not known to the clerk of comunidade, who shall enter in that book an item in the
form as shown in model No. 29.Sole § Once this entry has been signed by the clerk of theCode of Comunidades of 1961

comunidade, he shall indicate the amount in the margin and shall make transfers as provided for in
preceding article.Article 521.The declarations and entries of the credits shall be numbered annually
and in order and such numbering shall have reference to the credits and debits of the respective
current accounts.Article 522.The authorizations for items of credit shall bear special
numbering.Article 523.The credits may be made from the 1st August to the 10th November and shall
not be accepted before or after this period.Article 524.The clerks and the guards of the comunidade,
shall not grant the credits that they may have in the capacity as members of the comunidade,
without the consent of the same, as the treasurer shall not allow to grant or receive the credit on his
private account without first settling his management accounts.Article 525.On the 11th November
the clerk and attorney shall close this book, mentioning in the closing declaration, in words and in
figures at the margin the sum of amounts granted.Section VIIBook of chargesArticle 526.All the
charges shall be made in the book of charges and signed by one who creates them.Article 527.Once
the loading is legally created and valued when this is necessary, the clerk of the Comunidades shall
note down in the margin of the respective terms the quantity of the load or the amount determined
and, debiting or crediting to the respective debtor or creditor, shall record in the left hand margin,
the numbers of the current accounts, which shall indicate that the transfer has been effected.Article
528.The charges of the produce or rents of Vaingana/Rabbi shall only be made before the 30th April
and those on the product of Sorodio/Kharif by 10th November.Sole § What is contained in the sole
paragraph of article 487 shall be applicable to the recording of loading of Sorodio/Kharif.Article
529.The creation of charges shall have a numerical order to which the credit and debit in the current
accounts shall refer.Article 530.On the 11th November, the clerk and attorney of the Comunidades
shall close the book of charges, mentioning in words, in the closing declaration and in figure at the
margin, the sum of the amounts charged and signing the said closing declaration.Article 531.The
charges made upto the 10th November shall be transferred to the current accounts of the creditors
and debtors, and those made afterwards shall likewise be carried over to the current accounts of the
following year, along with those made up to the 10th November of the current year.Section
VIIIContract bookArticle 532.The contracts book shall be used to record the lease contracts and sale
of properties, the work contracts, services contract and agreements and any other contracts that the
managing committee may enter into.Article 533.The terms of contracts shall be recorded indicating
the date, month and year, the subject of the contract, the price or the rent, the name and the address
of the bidder and of the surety and the conditions of the contract, when these were not previously set
out and mentioned in the respective budget or estimate, and they shall be signed by the bidder and
his surety and by the members of the managing committee present.§ 1. In the ordinary auctions,
however, the clerk of the Comunidades shall draw each day the deed of a bid, incorporating therein
the terms of the biddings that were awarded, with the signature of the respective bidder and his
guarantor. At the end of the day, the same shall be sign by the members of the managing committee
as per model No. 13.§ 2. When the bidders and their sureties do not know or are unable to sign,
other persons shall sign on their behalf, at their request, in which case two witnesses shall also
intervene and sign.§ 3. For each draw, the Comunidades shall pay to the National Treasury, in the
form that is already established, the stamp duty due, in accordance with the law in force at the time
of the lease; when, however, the administrator presides at the auction, the Comunidades shall pay
also, in addition, the stamp duty on the tendering report.§ 4. The stamp duty on lease and the share
in the stamp duty on auction reports shall be charged to the respective lease holder, together with
the rent.Article 534.The book of contracts shall be divided into two parts, the first part for the termsCode of Comunidades of 1961

of auctions revenue and the second part for declarations of items of expense contract.Article
535.The pages of the book of contracts shall have a column in the left side margin in order to write
therein the number of the current account where the result of bidding amount be noted and on the
right side margin to record there in the number, the bidding amount of auction.Article 536.The
recording of auction of income and expenditure shall be numbered by a special numbering system,
as per its nature.Article 537.The book of contracts shall also be used to record any contracts with the
Comunidades and the managing committee drawn by public instrument or special records.Section
IXSundry declarations and reports bookArticle 538.The book of sundry declarations and reports
shall be used to write any record and deeds not included in the preceding book, such as those of
reinforcement of sureties, transmission and others and the reports of inspections carried out by the
managing committee and other agents of the Comunidades, to remedy the breach of bunds and
similar occurrences.Article 539.In all the reports and records mentioned will be made of the date,
month, year when they are made and residence of the intermediary party, the subject dealt with and
all the particulars collected and at the end the clerk of the Comunidades and other intermediary
party shall sign.Article 540.The records shall be numbered annually, and the caption of the subject
shall be written.Section XBook of record of orders from higher authoritiesArticle 541.This book shall
be divided into two parts, the first shall be used for the registration of all the orders for permanent
execution from higher authorities, received by the clerk of the comunidade.Sole § The first part shall
also be used to record the receipts of payments made to the National Treasury, to the general safe
and others, together with any miscellaneous acknowledgements or separate receipts.Article 542.The
second part of the same book shall be used to record the reports of experts in respect of land applied
for as emphyteusis and such registration shall be done only at the left side page and the page of right
side is meant for recording the delivery of possession of the same emphyteusis grants, which shall be
written precisely on the page at right portion of the report of examination by experts.Section XIBook
of record of encroachmentsArticle 543.This book shall be used for the registration of non-legalized
encroachments and shall be maintained as per model No. 14. It shall contain the measurements,
information regarding neighbouring land, valuation of the usurped lands, name and address of the
encroacher and all necessary clarifications, that may be required not only to identify the lands, but
also to do the recovery and redemption.Section XIIBook of the registration of claims in the matter of
surveyArticle 544.This book shall be used to record complaints against survey work of the
Comunidades fields connected with the preparation of Register (Tombo).Sole § On each of the pages
of this book, in addition to the space reserved for the text of the claim, there shall be two columns:
one, on the right, to register the administrator's decision, which shall contain his final decision on
this matter, and the other, on the left, for the serial number assigned to each claim (model No.
10).Section XIIIBook of primary enrolment of zonnkarsArticle 545.The book for the primary
enrolment of zonnkars shall be kept as per the model No. 6.Section XIVBook of primary enrolment
of the shareholdersArticle 546.The book for the primary enrolment of the shareholders shall be kept
as per model No. 30.In this book it shall also be noted down the inscriptions and cancellations of
any charges on the shares when, for this purpose the interested party produce before the respective
clerk of the Comunidades, the certified copy of the annotations made at the administration office, or
the certificates with the required annotations.Article 547.The book referred to in the preceding
article shall be closed on 31st May each year, under the terms of article 200.Section XVBook of
primary enrolment of the pensioners and sharersArticle 548.The book for the primary enrolment of
the pensioners and participants shall be maintained according to the model recommended by theCode of Comunidades of 1961

Directorate of Civil Administration.Section XVIRegister 1 (Tombo 1)Article 549.The Register 1
(Tombo 1) shall be used to record the rural, buildings and barren lands of the comunidade, their
measurements and land-marks, for the description of the sources of Comunidades income, not
deriving from private lands, and for the registration of the reports identifying, describing and
demarcating the lands marginal to the roads and the paddy fields, exclusively reserved for the
constructions, and of the lands that can be brought under cultivation at the Comunidades cost. It
shall be kept as per model No. 11.Sole § The maps of other lands shall be attached to this book when
the topographical survey is made.Article 550.The encroached lands which are reverted to the
Comunidades shall soon be recorded in this book.Section XVIIRegister 2 (Tombo 2)Article 551.The
Register 2 (Tombo 2) shall be used registration of the lands of the Comunidades granted in
emphyteusis or to any fixed contributions. The designation of the respective possessors shall be
mentioned in the book which should be kept as per model No. 12.Article 552.Any further change in
the description contained in Tombo 2 shall be recorded based on the orders of the administrator, in
the form prescribed in article 222 and the following ones.Section XVIIIBook for the general
inventoryArticle 553.The inventory book shall be kept in accordance with the article 446 and the
following ones.Section XIXBook of outgoing correspondenceArticle 554.The outgoing
correspondence register shall be used to copy all the correspondence issued by the Comunidades
and it shall not be subject to any special model.Title VCoercive recovery of the debts
Chapter I
General provisions
[Article 555.] [The above mechanism is similar to that of the articles 45, 46 and 52 of the Portuguese
Civil Procedure Code. See also Chapter X of the Land Revenue Code Section 122(2) relating to the
recovery of arrears of the Land Revenue.]The procedure established in the Code of Fiscal Executions
(Codigo das Execuções Fiscais), shall apply for coercive recovery of the debts payable to the
Comunidades, save otherwise provided in the title with exception of the provisions of this
title.Article 556.Only certified copy of current account issued in accordance with the provisions of
the following chapter shall be deemed to be enforceable title.Article 557.In the event of the death of
the principal debtor, during the course of execution, his heirs shall be summoned and subsequent
steps of the proceedings shall follow without there being need to formally bring on record.
Chapter II
Current accounts
Section IDebtors subject to coercive recoveryArticle 558.The following are subject to the provisions
of the preceding chapter:
1. The debtors of the Comunidades, whichever may be the source;Code of Comunidades of 1961

2. The [sureties] [See article 818 onwards of the Civil Code.] and persons
liable jointly or severally for debtors mentioned in the preceding clause;
3. The debtors liable to pay fines imposed in terms of this Code and for
recovery of stamp duties and costs due in any proceedings become res
judicata.
§ 1. The following are excluded:
1. Debtors of sum loaned by the Comunidades against [mortgages] [See
article 888 onwards of the Civil Code.], although the interest may be
demanded in accordance with the preceding chapter, when the mortgage
guarantee is not proposed to be enforced;
2. Liabilities guaranteed by mortgage, when it is proposed to use such
guarantee;
3. The debtors of the Comunidades declared by judicial decision.
§ 2. The cases for recovery of debts, except under the preceding paragraph, shall be instituted in
accordance with the general law.§ 3. In the case provided for in No. 2 of paragraph 1, the recovery
suits shall be based, besides the registration of the mortgage, also on the decision fixing the
responsibility or the respective account for the guaranteed debt, issued under the terms of this Code,
and in this latter case, the judgement debtor shall only be granted stay of execution, on the grounds,
beside those provided for in article 813 of the Code of Civil Procedure, on lack of standing to be sued
on the part of the judgement debtors, on the illegitimacy of the parties, on the illegality of the items
included in the current account and on forgery of such account.Section IIIssuance of certified copies
of current accountsArticle 559.Certified copies of current accounts shall be issued by its clerk, on
this own initiative, against the debtors to the comunidade:
1. As he is the key holder of the safe, immediately after the discovery that the
money is misappropriated and following on from the balance sheet, when the
missing money and its interest are not replaced forthwith in terms of the
article 469;
2. In the case of the treasurer, by 15th March of the year following that in
which he held office;Code of Comunidades of 1961

3. In the case of debtors of interest or the principal of loans obtained against
pledges, within fifteen days from the due date;
4. In the case of debtors of foros, rentals, land rents, charges and other
amounts mentioned in the current accounts, referred to in the article 488, by
30th December of the respective year, except when the time limit for issuing
of the definitive list of debtors has been extended by the administrator. In
this case, the current accounts shall be issued within ten days following the
expiry of such time limit;
5. In the case of debtors declared as such by a competent decision in an
administrative proceedings, within ten days of such decision becoming
definitive;
6. In the case of the rest of debtors, at the date fixed by the administrator by
his order or dispatch.
§ 1. Clerks of the Comunidades who fail to satisfy their responsibility, as assessed in the decision on
the auditing of accounts, within ten days from the date when the said decision becomes definitive,
shall be suspended from duty and paid by the administrator, who shall immediately replace them
and order their substitute to issue the current account within three days.§ 2. The same method shall
be adopted regarding the debts of the clerk when they derive from the fine imposed in accordance
with the rules laid down in this Code.§ 3. The suspension shall be lifted as soon as the debt and the
interest, stamp duty, costs and percentages, are settled but the clerk shall be subject to the penalty of
dismissal when the suspension exceeds two years.§ 4. If the key-keepers of the safe pay the missing
cash at the time of taking the balance, but without the corresponding interest due, in terms of
paragraph 1 of article 562, a current accounts shall be issued for the interest, within the time limit
stipulated in No. 3 of this article.§ 5. The same method shall be adopted against treasurers if they
pay the amounts missing without the interest due, under the terms of article 504.Article 560.The
Comunidades shall not forfeit their right to carry out the procedures provided for in this Title
against debtors when the respective clerk fails to issue the current accounts in terms of the
preceding articles. In such case, the administrator shall order its issue, at his own responsibility, as
soon as the clerk's failure to do so comes to his notice, and shall enforce the penalties to which the
clerk is subject.Article 561.A clerk of the Comunidades who fails to issue the current accounts in
terms of the article 559 shall be solitarily responsible for the debts resulting from the same accounts
and against him recovery suit shall be instituted, separately or jointly, with the respective
debtors.Article 562.The current accounts, save in special cases specified in this Code, shall
contain:(a)A copy of the current account of the debtor, as recorded in the book with reference to the
year to which it relates.(b)The name and address of the debtor and guarantors, with reference to the
share of responsibility of each.(c)The amount of missing funds or debt and the indication of the
percentage and date when the interest is due, as stipulated.(d)The declaration whether the
responsibility of the debtor was judged or not by way of administrative proceedings in terms of thisCode of Comunidades of 1961

Code.(e)The name of the attorney of the creditor comunidade.(f)A declaration of the amount which,
after the closure of accounts, has been entered in the safe in payment of the missing calculated
funds.§ 1. If the current accounts are issued against the key holders of the safe, it shall consist of a
copy of the balance sheet indicating as to what was the amount that should have existed in the safe,
with a certificate showing how much it was actually found, with reference to the date of the previous
balance. The negative difference between what should exist and what was found, is the amount of
missing funds, which carry interest at the rate of 6% as from the date of previous balance sheet.§ 2.
If the current account was issued against clerks of the Comunidades and the debt was the result
from over - crediting or under debiting current accounts, it shall consist of a copy of the credit or
debit balances referred to in article 493 and 497, followed by a certificate of the respective part of
the accounts audit decision.§ 3. If the responsibility of the clerks was the result from payment made
to the creditors in excess, considering the balance in credit, the current account shall consist of the
copy of part of the accounts audit decision containing the respective balance sheets, in terms of the
paragraphs of article 512.§ 4. If the responsibility of the clerks derives from missing amounts from
the safe due to accounting mistake, the current account shall consist of the certificates of respective
credit and debit, of the amount resulting from the same, and the respective part of the accounts
audit decision.§ 5. If the debt derives from fine, costs and stamp duty, the procedure to be followed
before the administrator shall be as provided in the article 92 of the Code of Civil Procedure.Article
563.The current accounts shall be written in two columns on the same half page, one for credit and
the other the debit, the balance being declared in words.§ 1. If the debtor or any of the guarantors or
any person holding joint responsibility expires, the clerk shall declare this fact in the current
accounts.§ 2. The current accounts which are based on securities not registered in the books of the
comunidade, shall always be accompanied by the same documents, in original or authenticated
copies.§ 3. When the Comunidades is the creditor, the current accounts shall be initialled by the
attorney so that he may know that the current account has been issued and defend the rights of the
respective Comunidades in the relevant proceedings.§ 4. If the attorney refuses to initial the current
account, the clerk shall notify and certify this fact in the current account.§ 5. Such notice may be
effected in the book of current accounts, following the registration of the definitive list, or in a list of
current accounts issued, which shall be filed with the comunidade, and the certificate of notice
issued, in the current account shall be referred to this book or to the list filed.Article 564.After the
issue of the certified copy of current accounts against the debtors of the Comunidades and after the
attorney has been notified, in accordance with the preceding provisions, the clerk of the
Comunidades who issues them shall forward them to the administration office within three days,
from the last date sent for issue. The secretary of the administration shall issue him a receipt for the
same.Sole § For the infringement of the provisions of this article the clerk shall be subject to the
provisions of article 561.Article 565.After receiving the certified copy of the current accounts, the
secretary of the administration office shall order the same to be recorded in the gate book, within
three days, and then present them to the administrator, who shall distribute the same and have the
distribution recorded in the book referred to in No. 12 of article 440, when the current account
debtor is not the National Treasury, an administrative body or a public administrative utility.Sole §
The recovery clerk to whom the current accounts are handed over shall issue the required
receipt.Article 566.If the debtor of the current accounts is one of the entities referred to in the last
part of the preceding article, the following procedure shall be observed:-§ 1. The current accounts
against the National Treasury shall be forwarded with remarks of the administrator to the DirectorCode of Comunidades of 1961

of the Treasury (Fazenda) who shall make arrangements for payment of the balance amount in
debt.§ 2. The current accounts against any administrative body or corporate body shall be forwarded
to the respective representative, with a request for the payment of the respective balance in debt.§ 3.
The entity receiving the requisition shall, within ten days, give orders for payment of debt in the
following ten days, when the same dept is not contested.§ 4. When contested, he shall return the
current accounts to the concerned administrator, attaching a copy of the resolution, of the
documents on which it is based and his information when he deems it necessary.§ 5. After receiving
the current account, along with the documents referred to in the preceding paragraph, the
administrator shall submit the case, with his remarks, for a decision of the Governor-General.§ 6.
When the debtor body has been communicated, through its representative, of the decision of the
Governor-General ordering any payment to be made, and if such payment is not effected within ten
days, the Governor-General shall be duly informed about this fact, to enable him to take further
measures as he finds convenient.Article 567.The recovery clerks to whom the current accounts have
been distributed shall process the same following legal formalities and forward them to the
administrator, to enable him to issue a dispatch ordering the summons of the debtors, guarantors
and joint responsible requiring them to pay the debt, within ten days or to indicate the assets for
seizure, failing which the proceedings shall follow its course.§ 2. For the purpose of service
summons, a warrant shall be issued, when necessary, and the current account shall be copied
therein.Section IIIThe effect of issuance of certified copies of current accountsArticle 568.The
current accounts give the respective Comunidades the following rights:-§ 1. To calculate the interest
in its favour at the rate of 6 per cent per annum, with effect from the date of service of summons, in
case no interest was payable on the debt, or else in case of interest was payable, but it was lower or
higher than 6 per cent.§ 2. To calculate against the debtor, in accordance of article 628, 3 per cent of
the debt in favour of the respective recovery court.§ 3. To permit the arrest of the debtor in the case
provided by the article 418 of the Code of Civil Procedure (Codigo de Processo Civil).Section
IV[Opposition of the judgement debtor] [See article 812 w.r.t. 813 of Portuguese Civil Procedure
Code.]Article 569.The judgement debtor may oppose the current accounts within 10 days from the
date of service of summons.§ 1. When the opposition is filed, the clerk shall receive the same and
attach it to the case file and issue a receipt to the person submitting it declaring that it has been
attached to the proceedings which shall be submitted for orders .§ 2. If the clerk refuses to accept
the opposition defence or to issue the receipt in accordance with the preceding paragraph, the
opponent shall file a complaint to the administrator who, after hearing the respective clerk, shall
decide as he deems fit, and if the complaint is upheld, the clerk may be suspended up to fifteen
days.Article 570.Opposition may be raised on following grounds:-
1. Error in the accounts.
2. Discrepancy in the accounts in the book and the certified copy issued.
3. The payment has been effected.Code of Comunidades of 1961

4. The claim for compensation.
Article 571.The defence shall be rejected in limine :-
1. When it is not presented within ten days, as from the date of service of
summons and the grounds raised are outside those mentioned in the article
570;
2. When it is not signed by the respondent and his lawyer or only by the
lawyer when he is holding a power of attorney;
3. When the denial is not specific and raised para wise, indicating in what
manner the accounts ought to be varied and what is the balance;
4. When, there is debit balance against the contesting party and no proof has
been adduced of having effected a deposit corresponding to this balance and
interest, when due, in records of the administration office or in the safe of the
respective comunidade;
5. When it is not accompanied by the documents mentioned in the
contestation, unless those documents are found in the archives of the
administration office or of the respective Comunidades and such statements
is made in opposition;
6. When the ground is the errors in the accounts and the same accounts has
been decided in a special procedure or in accordance with articles 512 and
513, unless there is a discrepancy between the respective decision and the
summons of the current accounts.
§ 1. If, in the course of proceedings of opposition raised by the latter establishment in the
proceedings under article 512 and 513 a certified copy of the decision shall be attached to the case
file and such decision shall substitute the proceedings of the opposition against the current account
in order to put an end to the respective case filed or to proceed in execution for recovery of the dept
established in the same judgement.§ 2. When the opposition is not in the conditions of being
received and processed, it shall remain attached to the file, so that it could be considered by the
higher authorities in the event of an appeal against the said decision which declared it.Article
572.The opposition suspends the proceedings of the executors subsequent to the attachment.Sole §
The attachment, however, shall not be done in the following cases:-Code of Comunidades of 1961

1. When the debt arises from an obligation secured by the pledge of shares
of the Comunidades or of gold or of silver objects or by mortgage.
2. When the opponent tenders security as provided in the Civil Procedure
Code, within ten days from the date of issue of notice by order of the
administrator including the probable amounts of the court-fees, costs and
interest, as stipulated.
Article 573.After the receipt of the opposition, the attorney of the Comunidades may reply within ten
days, commencing from the expiry of ten days time granted for the opposite party to submit his
defence, when there is sole defaulter, but when there are more than one defaulters the time shall
count from the date of service of notice the summons to the last defaulter.§ 1. The answer shall be
given and signed by the attorney of the Comunidades and the lawyer, or by the lawyer only when he
has the wakalatnama.§ 2. The clerk of the Comunidades who issued the current accounts may give
his say on the matter raised in the opposition.Section VProduction of evidence and
argumentsArticle 574.The evidence shall be led within ten days from the expiry of the time-limit
granted for the reply of the attorney of the comunidade.Article 575.Only documentary evidence is
admissible.§ 1. The payment is to be proved by a certified copy or receipt referring to the Cash book,
issued by the clerk, where from it is established the entry in the safe of the respective Comunidades
of the amount paid which is required to be proved.§ 2. The attorney or the clerk of the Comunidades
may challenge that the document produced is forged, in which case the respective file has to be
forwarded to the court for the decision on this incident.§ 3. The liabilities of the treasurer is not to
be adjusted with any amount which the latter may be entitled to from the comunidade.Article
576.Within the time fixed for leading evidence, the administrator may direct, at the instant of the
parties or as officio, if it is felt the necessary, the counter checking of the certified copy of the current
account with the examination of the books and documents which prove the source of credit and
debit of account and upto the examination shall record the result in a form of report.§ 1. The
examination can be done in the presence of the debtor, the creditor and the clerk who issued the
certified copy of the current account, with all the books and required documents.§ 2. The
examination and counter checking shall be done by the administrator or by the official of the
administration office designated by the administrator, except when the parties may ask that the
examination may be done by appointment of commissioner.§ 3. Whoever applies for examination by
commissioner shall with twenty four hours make the required advance payment failing which the
examination will be done without the commissioner.Article 577.The parties may give their
submission, in writing within five days from the date the production of evidence is approved, except
when the examination can not be concluded within the said time, in which case the time will start
after leading all the evidence.Sole § The pis entitled to inspect the file at the office of administration
but they are not entitled to have independent examination of the file.Section VIThe judgement and
appealArticle 578.The administrator shall deliver his judgement giving reasons, within ten days of
the end of the time limit for the submission, rejecting or upholding the defence, in whole or in party
and if the defence is upheld, he shall cancel the account or direct it review.Sole § The parties shall be
notified of the decision, unless they acted ex-part.Article 579.The cost arising from the deposition
and all steps taken till final decision shall be paid by the defeated pin the proportion to the quantumCode of Comunidades of 1961

decided.Sole § The costs and stamp duty incurred by the creditor Comunidades as per the
judgement shall be born by the clerk who had issue the certified copy of the current accounts and if
the change of the accounts was occasioned due to his fault or negligence, then he shall also have to
pay a fine in favour of the opposition, equivalent to double the costs and stamp duty.Article 580.If
the decision directs the review of accounts the same shall be done in the same proceedings, by way
of a record which shall be registered in the book of the respective comunidade, after the decision on
the objection has become res judicata.Article 581.A judgement against the Comunidades upholding
the objection shall not be final till it is confirmed by the Administrative Tribunal, whereto the
proceedings shall mandatorily be remitted and such remission should be notify the party that is not
ex part.Article 582.All the orders and final decisions of the administrator connected with the
objection against the current account are subject to appeals to the Administrative Tribunal.Sole §
The appeals against the interlocutory orders shall be forwarded along with the appeal against the
final decision.Article 583.The appeal against the final decision on the objection, if the objection is
not upheld, shall have the effect of a stay and shall be reported to the higher authorities along with
the main file.Section VII[Adjudication by way of embargo] [See article 812 w.r.t. 816 of Portuguese
Civil Procedure Code.]Article 584.Besides the objection to the current accounts before the
administrator, the judgement debtor may also raise objection by way of embargo.Article 585.When
the objection is raised on the grounds provided in clauses Nos. 3 and 4 of article 570, before the
administrator is not open to the judgement debtor to file the embargo on the same ground.Article
586.The embargo sustains the execution only after the attachment.Sole § The attachment shall not,
however, be done in the cases provided for in clauses Nos. 1 and 2 of the sole paragraph of article
572.Article 587.The embargo or petition shall be presented before the clerk who shall issue receipt
thereof to the presenter and process them separately appending the same to the file of the execution
proceedings or to the certified copies obtained by the objector when at the same time he had filed
objection (as per article 569) and after having given the security, the file shall be sent to the
administrator who shall send them to the court within three days under prior notice to the
petitioner.Article 588.If the clerk declines to accept the embargo or to issue a receipt with a
declaration that the papers are processed, the petition to the embargo will proceed in accordance to
paragraph 2 of article 569.Article 589.The further steps of the petition of the embargo shall be
proceeded in accordance with the provisions of the Code of Civil Procedure and the articles 575 and
576 shall be followed to the extent that it is not contrary to the general rule.§ 1. When the debt arises
from the payment of foros, the applications the embargo challenging the legality shall not be
maintainable when objection is raised by the person whose name is registered in the of the
registration of Comunidades claiming to be the owner in usufructuary or head of family of the
property from where the foro arises.§ 2. If the debt arises from the rents of property of Comunidades
and other contributions connected, then the embargo on the alleged illegality shall not be held
tenable when objection is raise by the lessee of the property or by a person who has stood as security
for payment of rent from the dept arised and when the respective auction has been countersigned by
the administrator.
Chapter III
AttachmentsCode of Comunidades of 1961

Article 590.At the end of the period of ten days without the payment of debt being made, the clerk of
the Comunidades shall proceed with the attachment.Article 591.The attachment shall start with the
estate that was especially given as guarantee for the obligation from where the debt arises and then
proceed with the share of Comunidades, by the sums to which the judgement debtor has right in
judicial, administrative and fiscal proceedings, moveable or semi-moveable, the credit receivable by
the judgement debtors, by rentals, foros, interest, pension and any other instalments, the fruits of
immovable property as well the property itself, and this attachment shall be made on the property
which may be found sufficient to pay the debt interest, stamp duty, costs and percentage.Sole §
When the debt arises from the foros, in the first place, the rent or the fruit of the property from
which the foro arises shall be attached.Article 592.The attachment of the shares of Comunidades
shall be effected in accordance with article 424 and its paragraphs.Article 593.The provisions
contained in article 854 of the Civil Procedure Code shall also be applicable to the depository found
to be in fault in the presentation of the respective accounts.Article 594.If the attachment is in
respect of immovable property and the debtor is married, the other spouse shall soon be
summoned.Article 595.If the attachment is in respect of immovable property, the attorney of the
respective Comunidades shall apply for its registration, to the conservator of the Land Registry
(Conservador do Registo Predial).In the same application, a certificate of the encumbrance on the
attached property shall also be requested.§ 1. In the talukas where there is no Land Registry office,
the application for the registration of the attachment and of the certificate of charges shall be made
through the respective administrator.§ 2. The registration note, the certificate referred to in this
article and the one of having issued the summons to the spouse of the debtor and of the taxable
income of the confiscated properties, shall be attached to the case file, and the same be forwarded to
the administrator, who shall order that it shall be sent to the competent court in the concerned
taluka.Article 596.When on the same lands, there is more than one attachment, the deposit shall be
made in the possession of the first depository, and, in case it is made in possession of any other
person, the depository can request for the change of deposit.Article 597.The depository shall submit
accounts in the recovery court, in accordance with the applicable provisions in the Civil Procedure
Code, except when the attachment falls in the immovable property, in which case the accounts shall
be submitted to the civil court.
Chapter IV
[Third party objections] [See article 1036 of Portuguese Civil
Procedure Code.]
Article 598.In the objections by the third party the following provisions shall be strictly
followed:(a)The objection raised by third party shall be rejected in limine by respective judge in
cases, dealing with the shares of Comunidades, which are not accompanied by a document which
prove that the attached shares are registered in the name of the objector or his representative and
also the objections raised shall not be accepted in case the recovery case is filed for the debt of a
deceased person in whose name the shares are registered.(b)The third party objections shall be
rejected when the debt is caused from the foros and other contributions due to the Comunidades
relating to the attached properties.Code of Comunidades of 1961

Chapter V
Auctions and awards
Article 599.After the attachment is done, or in the case of a debt secured by a pledge, the
administrator shall fix the day for auction.Article 600.When the execution of dept is of the amount
below 600 $ it is not mandatory to make public notice.Article 601.The starting bid in the auction of
movable items shall be the value referred to in the attachment report.Article 602.The bid price,
whether for movable or immovable property, shall be deposited, when required, at the order of the
respective court, in the safe of the respective comunidade, observing the applicable provisions of
articles 614 and 615 and it shall be withdrawn or paid into the safe as per the competent letter of the
court.Article 603.When the produce of the properties has to be auctioned, the respective sale shall
be limited to the produce of one year only, and when the value obtained is found not to be sufficient
to pay debt in full, interest, stamp duties, cost and percentages, or no bidder had come forward, the
administrator can order the transfer of attachment to any other assets of the debtors, or may attach
the soil, other provisions contained in article 595 shall be observed.Article 604.The bidder, who is
not known, shall be excluded from bidding, save when he is ready to pay, in ready cash, at the time
of auction, its price, the auction expenses, stamp duties, transfer tax or when a reliable person
stands surety for him subjecting himself to the imprisonment also.Article 605.The decree holder
may request the award of the properties, in accordance with article 874 and 875 of the Civil
Procedure Code.
Chapter VI
[Creditor's claim] [See article 564 of Portuguese Civil Procedure
Code.]
Article 606.After the auction is over the following shall be notified:-
1. The creditors of the debtor indicated in the certificate of charges.
2. Any other uncertain or unknown creditors.
The notice mentioned in No. 1 shall be issued personally to the creditors when they reside in this
State and regarding those mentioned in No. 2 by public notices of 20 days.Article 607.The creditors
notified in accordance with the preceding article may claim their credits according to the article 865
of the Code of Civil Procedure and, if they do so, the case papers shall be forwarded immediately to
the Courts of the competent judicial district for further legal action, till final decision regarding
creditor's claims.§ 1. The provisions of the main body of this article shall not apply to credits claimed
only from the income realized from the auction of shares of Comunidades, on the grounds of
registration of encumbrance, and when no preferential rights are claimed in addition over the
produce of other properties.§ 2. In the case provided for in the preceding paragraph, the claims of
creditors shall be conducted and determined before the administrator, as per the provisions of the
Code of Civil Procedure prescribes for such claims of recovery, whenever applicable, save theCode of Comunidades of 1961

modifications made in this Chapter.§ 3. The credits claimed before the administrator need not be
accompanied by a certificate of registration of encumbrance.Article 608.If anybody contests the
credits claimed under the terms permitted by the article 866 of the Code of Civil Procedure, the
method as prescribed in the present Code should be followed in the case of embargo of execution,
excepting regarding the surety that shall not be necessary.Article 609.When the debt secured by
recording on the shares is not valued or matured, the respective creditor shall claim his credit and,
once it is placed in the right position in the order of priority, the amount due to him shall be ordered
to be kept in the Comunidades safe, until such time as it matures and is valued, or until any
interested party does not cancel the encumbrance, because the debts to which the claim relates has
been extinguished.Article 610.The order of priority of creditors, with respect to income realized with
the sale of shares of the Comunidades shall be done in accordance with the priority of the respective
annotations made.Article 611.The final decision on the claims of creditors, in accordance with
paragraph 2 of article 607, shall declare the shares exonerated of all charges which are noted as
guarantee of debts, and shall order the respective annotations cancelled.
Chapter VII
Payment
Article 612.At any stage of the proceedings the debtor or any other person may pay the debt, along
with the interest, stamp duty, cost and percentage.§ 1. The third party who pays the debt shall be
subrogated in the rights of creditor to recover from the debtor, his guarantors or other responsible
in accordance with this Code, whatever they have paid for them, being able then to pursue further
the same case.§ 2. The co-responsible, who are established as such by contract or by law, and the
guarantors have right against the principal debtor, for any payment they make and in accordance
with the preceding paragraph, and each one against the others, in the respective proportion, under
the terms of general law.Article 613.Soon after the payment is offered, the clerk of the Comunidades
shall obtain from the accounts clerk, the immediate calculation of stamp duty, percentage and costs,
issuing thereafter the respective payment chalan, countersigned by the administrator, to enable to
effect the payment of the stamp duty owed to the National Treasury, to the person who has offered
payment, the said chalan shall be delivered along with an unstamped duplicate for filing at the
Treasury Office.Sole § The chalan issued shall be presented at the respective Treasury Office and the
corresponding amount shall be paid there, and, after obtaining the receipt on the chalan of having
effected the payment, the same shall be handed over within twenty four hours to the respective clerk
of the Comunidades that issued it.Article 614.After attaching the chalan, with the receipt recorded in
it, to the case file, the clerk shall issue another chalan signed by the administrator, for payment of
the debt and interest and shall deliver the same to the person offering payment, with an unstamped
duplicate chalan for filling in the records of the comunidade.§ 1 In this chalan issued reference shall
be made to the number of the case file and indicate specifically the origin and the value of the debt
and interest of each current account processed, mentioning the date till when such interests have
been calculated and any other sum to be paid to the Comunidades safe, declaring in the end that in
addition to these amounts, there is additional interest to be calculated in accordance with the
provisions of No. 1 of article 568, at the time of payment.§ 2. The provisions of the Civil Code shall
be applicable to the contractual interest.§ 3. In case the challan is not attached to the file till the timeCode of Comunidades of 1961

designated for the auction, the same shall not be suspended.§ 4. The percentages and the cost,
already assessed, shall be paid to the clerk, who shall certify the said payment at the end of the
accounts, and shall distribute them to whomsoever it belongs.Article 615.The challan referred to in
the preceding paragraph shall be presented to the clerk who has issued certified copy of the current
account, within three days and the said clerk after receiving the amount and the interest, which he
assessed, shall record the same in the cash-book, and, with reference to it record a receipt on the
slip, and hand it over to the presenter.§ 1. The clerk of the Comunidades who receives the amount,
mentioned in the challan, shall convene the key-holders of the safe, within twenty four hours, if the
total amount received is 300 $, or more, and after collecting this amount in the safe, he shall
authenticate the items entered in the cash-book with the signatures of the other two key keepers.§ 2.
If the amount is less than 300 $, it may be placed in the safe, after following the formalities
established in the preceding paragraph, at the next opening.§ 3. In the case referred to in the
preceding paragraphs, the clerk who received the money shall immediately participate to the
administrator the fact that the amount entered in the cash-book has been authenticated with the
signatures of the key-holders and that the said amount has been placed in the safe.§ 4. The challan
received by the person who made the payment, shall be returned to the clerk who had issued it,
within five days as from the date of the said challan.Article 616.The debtor is allowed to pay the debt
and the interest in the safe of the comunidade, without any slip, at any stage of the proceedings.Sole
§ The clerk of the Comunidades who had collected the money which was deposited in the safe, shall
issue the receipt referring to the cash-book, which shall be presented to the dealing clerk in charge
of the case, who shall attach it to the respective file and proceed further in terms of article
613.Article 617.After the clerk has received the chalan, referred to in paragraph 4 of article 615, or
sole paragraph of article 613, in case the integral amount of the debt and interest have been paid in
the safe of the comunidade, he shall attach it to the case file, and after effecting the payment of the
costs and percentages, if due, he shall forward it to the administrator for him to close the case and
order the same to be closed.§ 1. On the final decision of declaring the execution satisfied, there shall
be no notice.§ 2. The certified copy of payment made in the execution proceedings, which is issued
by the respective dealing clerk in charge of the file and signed by the administrator, constitutes the
document for the cancellation of the attachment.Article 618.When, within the prescribed period, the
slips referred to in article 613 and 614 have not been returned to the clerk, along with their receipt of
payment, the recovery proceedings shall continue.Article 619.When as a result of attachment and
auction, some amounts are collected which are not sufficient for the payment of the debt, interest,
cost and percentages, in that case, the revenues and cost shall be paid first and the rest shall be
deposited in the safe of the crediting Comunidades on account of the debt and the recovery case
shall proceed further, as regards the outstanding debt.Article 620.If the debtor presents money at
the auction for the payment of the debt, interest, revenues, costs and percentages, the auction shall
be suspended for the period of time which the administrator feels is absolutely sufficient for
effecting all the payments in the administrative office, and if that period expires without, the
payment being effected, the auction shall proceed further.§ 1. The amount to be received shall be
processed as provided in article 613 and 614.§ 2. In this and other cases where the integral payment
of the debt, stamp duties, cost and percentage is to be collected in the administration office, the
challan for payment of the stamp duties shall be hand over to the official concerned with the
required amount to effect the payment in the Office of Accounts (Fazenda) and the amount
necessary for payment of debt and its interest to be made to the clerk who had issued the certifiedCode of Comunidades of 1961

copy of the current accounts, for which purpose he being called in the administration office with
cash-book so that the entry could be made under the respective items.Article 621.The payment of
any part of the debt, which the debtor wishes to make, shall not be refused and, in this case, a
receipt for the amount received shall be passed to him and the proceedings shall continue in respect
of the remaining part of the debt.Article 622.If, after the issue of current accounts and its delivery to
the secretary of the administration, but prior to being summoned, the debtor pays the debt or a part
thereof, the clerk of the Comunidades shall issue him a receipt, referring to the cash-book. The
debtor shall present this receipt in the administration office in order that the current account
proceedings shall not continue further, although, he shall be held responsible for the payment of
stamp duty and costs incurred before the same receipt being received by the administration
office.Article 623.The Comunidades need not offer any security for the withdrawal of money from
public deposits relating to their credits, even if there is pending appeal in the recovery suits.Article
624.If, in view of the payment, remission or consignation in deposit made within the ordinary
period, any amount is necessary to be deposited, such deposit shall be made in the safe of the
respective comunidade.
Chapter VIII
Forgery of documents
Article 625.When forgery is invoked, the administrator shall order that they should be sent to the
competent court after being attached to the recovery case.Article 626.When the forgery is pertaining
to service of summons or any other act related to administrative procedure the administrator should
order that the proceeding alleged to be false be repeated along with others that are depending on the
same and direct that the recovery case should proceed further in the administration office itself.Sole
§ In case any proceedings alleged to be false are by order repeated, the petition that invokes the
forgery shall be detached from the case file and sent to the court in order that any crime therein
committed be punished.
Chapter IX
Costs
Article 627.The emoluments and the wages shall be calculated as per the table attached to the
Code.§ 1. In the recovery cases of the amount which is less than 150 $, the emoluments and the
wages shall be reduced to one fourth, and the value being inferior to 300 $ to half.§ 2. The rules in
force pertaining to the counting of non stamped paper, are applicable to the recovery cases.Article
628.In the recovery cases when the payment is effected, in any form, after the expiry period of ten
days following the summons, an additional percentage of 3% of the principal debt shall preferably
count against the debtor, out of which two-thirds shall belong to the administrator and one-third to
the recovery clerk in charge of the case.§ 1. The distribution of the percentage shall be done in the
case file itself.§ 2. In case the amount rise is insufficient, the cost shall be preferred over the
percentage.Article 629.All the acts and proceedings shall be carried out free of charge, in case in
respect to the same, no fees are fixed in the annexed table, for wages and conveyance.Sole § No costsCode of Comunidades of 1961

nor revenues shall be received when the debt not recoverable.Article 630.The accounts clerk shall
close the accounts with an indication of the total amount, written in words, and shall not count more
than one charge, for all the tasks that were carried out on the same day and in the same case in
favour of each of the employees carrying them out. In this case, when the proceedings of the same
nature are exercised by more than one employee, only one charge shall be counted which shall be
divided equally among them. This part of the rule shall not, however be applicable to the
proceedings where more than one employee is required by law.§ 1. The value of the costs shall not
exceed three-fourths of the amount of the recovery case, unless when the case is contested and there
is a request for stay of execution.§ 2. When the value of the costs calculated is in excess of
three-fourths of the amount to be recovered, proportional reduction shall be effected to amount
which the employees have right to it.§ 3. In no circumstances shall negative certificates be counted
in the proceedings, and the charges for attachment shall only be counted in the cases in which they
are counted in summons.Article 631.If any employee, who is entitled to the costs, does not resides in
the taluka, the payment made can be proved through the receipt noted on the reverse of the
payment slip, which the clerk of Comunidades shall send to the secretary of the administration
office of the Comunidades of the other taluka, mentioning specifically the name of the employee the
amount of the costs to which he is entitled.
Chapter X
Unrecoverable debts
Article 632.The debts which are known to be unrecoverable as the debtor, his guarantors and
co-responsible are not holding absolutely any land, those debts should be treated as non recoverable
in the respective file.Article 633.For the purpose of judging the debt, as non recoverable, the
administrator shall consult, in writing, the parish-priest, the functionary in charge of parish, the
clerk of the Comunidades and its managing committee and shall collect any other information that
he sees fit.Article 634.If the information gathered, confirms the insolvency of the debtors,
guarantors and co-responsible persons, the final order shall be pronounced judging the debt as non
recoverable.Article 635.The judgement declared non recoverable any debt, the rights of the creditor
shall be safeguarded for a period of thirty years, allowing the recovery of the debt, out of the estate
that may be acquired by the debtors, their guarantors or co-responsible persons.Article 636.The
judgement of the debt as failed, shall also be rendered when the debt indicated in the current
accounts origins from the foros, rentals, interests, land rents or any other periodical payments, and
when five years have elapsed after such debt matures, without the person responsible being
summoned to pay the same or without the limitation period being interrupted by any legal
means.Article 637.The non recoverable debts may be judged as failed, in view of a list organized by
the recovery clerks, separately for each comunidade, wherein there is mention of the names of the
debtors, guarantors and other co-responsible persons, the nature of the debt, the year to which they
relate, their value and the numbers of the respective case files.§ 1. The information referred to in
article 633 shall be attached to the list.§ 2. When the information thus gathered confirm the
insolvency of the debtors, their guarantors and other co-responsible persons, the respective debts
shall be judged as failed by a final order recorded in the respective list, attaching to each file the
certificate of the said order.Article 638.The judgement given on the failed debts shall only be validCode of Comunidades of 1961

after being confirmed by the Administrative Tribunal to which the case files shall be forwarded.Sole
§ When the judgement of failed debts have been written in the list itself, referred to in article 637,
this list shall be forwarded for confirmation along with the respective file.Article 639.Once the
judgement and the annulment of the failed debt have been confirmed, the administrator shall order
that the certificate of the judgement, with mention of all the required circumstances, shall be sent to
the clerk of the comunidade, to enable him to make the competent entries in the books, so that the
annulled credits will no longer figures in the yearly balance, save in the case of article 640.Article
640.The judgement failed debt shall be annulled when, within thirty years from the last proceedings
in the recovery case wherein the debtor was summoned, or from the due date of maturity of the
debt, if no summons were served, properties of the debtor, capable of being confiscated, are
discovered.§ 1. In this case, the judgement being annulled by order of the administrator, the assets
shall be attached and other proceedings shall follow as if no judgement had taken place.§ 2. The
clerk dealing with the file and the clerk of the Comunidades shall inform the administrator and
arrange for the annulment of the judgement of the failed debt as soon as it comes to their notice the
existence of assets that the debtors, guarantors and other co-responsible persons possess from
which the debt can be recovered.§ 3. The annulment of the failed debt cannot be effected in case
provided in the article 636.Title VIGeneral and transitory provisionsArticle 641.Only the
remunerations provided in this Code and in the maps annexed shall be quantified and paid to the
employees and agents of the Comunidades and to the administrators, without the prejudice of what
is contained in article 644.§ 1. The inclusion of these employees in the categories of map I, annexed
to Decree No. 40.709, dated 31st July, 1956, shall entitle them to the pay presently earned by the
government servants, of equal category, including the family allowance, daily allowance, travelling
allowance, travel and transport allowance on the same terms as are established to such government
servants.§ 2. The physicians of medical posts and junior staff of the Comunidades shall have the pay
and salaries fixed up by the Governor-General, after consulting the respective Comunidades.Article
642.The expenses with the pay of the clerks of the Comunidades shall be included in the private
budget of the administrations offices and the sections of the Comunidades and shall be paid from
the proportionate contributions derived from the division of the same expenses between the
Comunidades existing in each Taluka.Sole § The provisions of the second part of this article shall
apply to the clerks of the Comunidades of Quepem and Pernem.Article 643.The exercise of the right
of the clerks of the comunidade, which involve increase of expenses, excepting what is contained in
the preceding article, shall be subject to the financial possibilities of each Comunidades or their
group and its implementation shall be allowed subject to the favourable sanction of the same.Article
644.The remunerations of the administrators, clerks and auxiliaries which amount to an increase of
expenditure in relation to those earned at the date of publication of this Code shall also be subject to
the financial possibilities of the Comunidades of each taluka and depend on their favourable vote,
sanctioned by the Governor-General.Article 645.The personnel of the private administrative offices
of the Comunidades and those of the taluka administrations (sections of Comunidades) shall be
subject to the general discipline applicable to the government servants, enjoying the same rights and
duties, without the prejudice to the provisions of this code.Article 646.The Comunidades may
recommend and the Government may determine in the Comunidades where there is a need it is
deemed necessary the constitution of bouços (association of tenants).Sole § A special law shall
regulate the constitution, functioning and the objectives of the bouços.Article 647.It is not lawful to
pass deliberation for dissolution of their properties.Article 648.The Government may reconstituteCode of Comunidades of 1961

wherever possible and convenient, the Comunidades which have ceased to exist, or promote the
creation of new Comunidades, in accordance with sub-paragraph (c) of article 6 of Decree No.
35.230 dated 8th December, 1945.Article 649.Fishing is prohibited in the sluice gates of the
Comunidades, but it shall be the permitted in the streams, preceded by prior assessment and
auction and by placing nets at a distance not less than 10 meters from the portal.Article 650.For the
fiscal purposes, the percentages referred to in Article 307, with reference to sub-paragraph (b) of
article 316, shall be considered as expenses.Article 651.The sum corresponding to 5 percent of the
net income of every comunidade, shall be credited in favour of the fund of the village body (junta de
freguesia) or other body that may substitute the same, and such fund shall be spent exclusively for
local improvements.Article 652.Every five years, in city of Panjim, on 2nd Sunday of January, a
meeting shall be held of the delegates of all the Comunidades to deal with matters of general interest
to them to foster its progress and propose to the Governor-General, some measures in this
connection.§ 1. In the first fortnight of November, the Governor-General shall appoint a commission
comprising of five members chosen from among the members of the managing committee of the
Comunidades, in order to make arrangements for the meeting referred to in this article.§ 2. In the
first fortnight of December, the Comunidades, or in their absent, the respective managing
committee, shall chose the delegates to represent them at that meeting and shall approved the
necessary expenses for such representation within the funds available in the respective budgets.§ 3.
The first meeting shall be held in 1962.Article 653.The grants of land, made under the Regulations,
dated 30th October, 1886, Order dated 22nd December, 1898 and the Legislative Diploma No. 651,
dated 30th March, 1933 are subject to the provisions of Article 341 and the following, when the land
is in possession by the grantees or their heirs.Article 654.To emphyteusis grants of lands, for
cultivation purposes, in the talukas of Ponda, Bicholim, Quepem, Sanguem and Canacona, the
provisions of the Legislative Diploma No. 814, dated 6th September, 1935, and 967 dated 3rd
September, 1937 are applicable, as long as new methods are determined by the
Governor-General.Article 655.(transitory): The present clerical porters of the administrations of the
Comunidades appointed on permanent basis, and when are none such employees, the present
temporary assistants, appointed through competitive examination, having two years of good and
effective service, shall be absorbed as assistants of 3rd class, without any formalities other than the
publication of such appointments in the Official Gazette.Article 656.(transitory): The present 2nd
class assistants and special assistants, temporary or substitute, and the interim bailiffs may be
appointed to the respective posts, independently of any competitive examination, age and
qualifications, provided they have at least two years of good and effective service.Article
657.(transitory): In the cases where the foro in respect of emphyteusis granted at the time of
publication of this Legislative Enactment had been fixed up by a deliberation of the 'comunidade' at
a value different from the one resulting from the public auction, the aggrieved party may lodge a
claim to the Governor-General, against it, within ninety days from the date of publication of the
present Code.Article 658.The provisions of this Code shall apply to the pending cases, without
prejudice to the procedure carried out before the enforcement of this Code.Article 659.Any
modification that may be made, in future, on the matter contained in this Code, shall be considered
as being a part of the same, and inserted in proper place, either by replacing the amended articles,
or by eliminating of the revoked one or by addition of new articles as necessary.Article 660.From the
date of this enforcement of this Code was made effective all the prior legislation relating to the
Comunidades is revoked and specially the Legislative Enactments Nos. 651, 966, 1035, 1051, 1294,Code of Comunidades of 1961

1301, 1306, 1308, 1317, 1381, 1471, 1578, 1628, 1629, 1651, 1741 and 1869, of 30th March, 1933, of 1st
September, 1937, of 23rd December, 1938, of 27th April, 1939, of 30th July, 1949, of 18th August,
1949, of 22nd September, 1949, of 13th October, 1949, of 2nd December, 1949, of 21st June, 1951, of
30th April, 1953, of 24th February, 1955, of 15th March, 1956, of 15th March, 1956, of 20th
September, 1956, of 3rd October, 1957 and of 18th December, 1958, respectively, and Orders Nos.
5028, 5110 and 7664, of 19th January, 1950, of 28th September, 1950 and of 12th November, 1959,
respectively.Maps, Models and Tables Referred to in The Code of ComunidadesMap No. I(Article
2)On The Comunidades Existing in Goa
Tiswadi Taluka
Azossim Curca Morombi-o-grande
Bambolim Elá Morombi-o-pequeno
Batim Gancim Murdá
Calapur Gandaulim (insolvent) Naroá
Caraim Goa Velha Navelim
Carambolim Gaolim-Moulá Neurá-o-grande
Chimbel Goltim Neurá-o-pequeno
Chorão Jua Passo de Ambarim
Corlim Malar Renovadim
Cujirá Mandur Talaulim de Santana
Curca Mercurim Taleigão
Salsete Taluka
Aquem Curtorim Margao
Benaulim Davorlim Nagoa
Betalbatim Deussua Orlim
Calata Dicarpale Raia
Camorlim Donculim Sarzora
Cana Dramapur Seraulim
Carmona Gandaulim Sernabatim
Cavelossim Gonsua Sirlim
Cavorim Guirdolim Telaulim
Chandor Loutulim Utorda
Chinchinim Macasana Vanelim
Colva Majorda Varca
  Verna
Bardez Taluka
Aldona Guirim Pilerne
Anjuna Mapusa Pirna
Arpora Marna PomburpaCode of Comunidades of 1961

Assagao Marra Punola
Assonora Moira Revora
Bastora Nachinola Saligao
Calangute Nadora Sangolda
Camorlim Nagoa Siolim
Canca Nerul Sircaim
Candolim Olaulim Serula
Colvale Oxel Tivim
Corlim Paliem Ucassaim
Cunchelim Parra Verla
Mormugao Taluka
Arossim Cortalim Mormugao Vadem
Cansaulim Cuelim Pale Velção
Chicalim Dabolim Quelossim  
Chicolna Issorcim Sancoale  
Ponda Taluka
Adcolna Candola Nirancal Talaulim
Bandora Codar Orgao Tiurem
Betora Conxem Panchavadi Vadi
Betqui Concolim Priol Vagurbem
Boma Cundaim Querim Velinga
Borim Curti Queula Verem
Candeapar Marcaim Siroda Volvoi
Bicholim Taluka
Advolpale Cotombi Navelim Sirigao
Amona Cudnem Pale Surla
Arvalem Dumaxem Piligao Usgao
Bordem Gangem Pissurlem Vainguinim
Bicholim Naroa Sarvona Velguem
Latabarcem Mencurem Mulgao  
Pernem Taluka
Agarvado Dargalim Morgim Tuem
Alorna Ibrampur Paliem Uguem
Arambol Mandrem Pernem Virnora
Quepem Taluka
Molcornem Quepem Avedem Bali
Ambaulim Xelvona Chaifi AdnemCode of Comunidades of 1961

Assolda Sirvoi Chic-Xelvona Fatorpa
Cotombi Vodar Provincia de Bali Quedem
Curchorem Xeldem Quitol Canvorrem
Cusmane Cacora Naqueri Pirla
Sanguem Taluka
Astagrar Curdi Nunem  
Colomba Netrauli Rivona  
Zaqui    
Canacona Taluka
Canacona Gaundongrem Poinguinim  
Cola Nagorcem-Palolem Polem  
Loliem    
SummaryTiswadi Taluka ....................................................................................... 32Salcete Taluka
....................................................................................... 37Bardez Taluka
........................................................................................ 39Mormugao Taluka
.................................................................................. 14Ponda Taluka
......................................................................................... 28Bicholim Taluka
...................................................................................... 23Pernem Taluka
....................................................................................... 12Quepem Taluka
...................................................................................... 24Sanguem Taluka
...................................................................................... 7Canacona Taluka
..................................................................................... 7Map No. 2Cadre of the staff of the
comunidades Administrative offices, Sections of comunidades affairs and offices of the clerks of
comunidades.I(Article 127)
Talukas AdministratorsWorks
TechniciansSecretaries Assistants Draftsmen-cum-Overseers Bailiffs Peons
Class I Class II Class III
J L N Q R S U XZ'
and
Z"
Tiswadi 1 1 1 3 4 1 1 2 2
Salcete 1 1 1 3 4 1 1 2 2
Bardez 1 1 1 3 4 1 1 2 2
Mormugao -- -- -- 1 1 -- -- -- 1
Ponda -- -- -- 1 1 1 -- -- 1
Bicholim -- -- -- -- 1 1 -- -- 2(b)
Pernem -- -- -- -- -- 1(a) -- -- 1
Quepem -- -- -- -- 1 -- -- -- 1
Sanguem -- -- -- -- 1 -- -- -- 1
Canacona -- -- -- -- 1 -- -- -- 1(c)Code of Comunidades of 1961

 3 3 3 11 18 6 3 6 14
(a)Shall be filled in case the comunidades pass to system of "Comunidades Commissas".(b)The
expenses with the salary of one of the posts shall be borne by 9 and Mahajan associations, in the
proportion 7:8.(c)The respective expenditure shall be divided pro-rata among the comunidades and
Mahajan associations, in the proportion of 2/5 and 3/5 respectively.Special Monthly AllowancesTo
the Taluka administrators, on account of the service of the comunidades: Ponda, Mormugao and
Bicholim, 600$00, 450$00 and 450$00 respectively; Sanguem, Canacona and Quepem 180$00:
Pernem, 90$00.To the Secretaries of the Taluka Administrative Offices, on account of the service of
the comunidades: Ponda, Mormugao and Bicholim, 120$00: Sanguem, Canacona and Quepem
Escudos 90$00: Pernem, 60$00.To the clerk of Section Office of Mahajan Associations at Pernem,
on account of the service of the comunidades, so long as the post of Assistant for the same work is
not filled, 120$00.To the Municipal Works Technicians, on account of the service of the
comunidades: Ponda, 450$00; Mormugao, 300$00 and Bicholim 250$00; in the remaining
Talukas with the exception of Tiswadi, Bardez and Salcete, the technical staff of the respective
Municipalities or any other technician will be employed for study and working up of projects, and
they will be entitled to 3 per cent. on the value of the works.To the staff of the comunidades
Administrative Offices, on account of the service of the Pensioner's Bank:Tiswadi Administrator,
500$00; Secretary, 200$00; Assistant, Class I, 100$00; Bardez and Salcete administrator, 350$00;
Secretary, 150$00; Assistant, Class I, 100$00.I(Article 84)
Designation Category Total Talukas Total
Tiswadi Bardez Salcete Ponda Mormugao Bicholim Sanguem Canacona
Clerks Q 6 8 6 -- -- -- ----20
Clerks R 11 12 15 2 -- -- ----40
Clerks S 5(a) 6(a) 9(a) 9 9 8 2250
(a)Includes Assistant clerks of the comunidades of Carambolim, Chorao, Calapur and Jua in
Tiswadi; Serula in Bardez; Margao and Curtorim in Salcete.Classification of The Offices of The Clerk
of The Comunidades and Groups of ComunidadesOffices of the clerk of the comunidades, Class I
(20)Tiswadi - Batim*-Talaulim de Santana-Goalim-Moula (group): Calapur*-Cujira (group);
Carambolim: Chorao*-Caraim-Passo de Ambarim (group); Jua and Neura-o-grande. Total 6.Bardez
- Anjuna: Calangute; Corlim-Mapuca*-Cunchelim (group) Fraternal of Aldona; Guirim- Sangolda*
(group); Parra*-Canca-Verla (group); Serula; and Siolim*-Marna-Oxel (group). Total 8.Salcete -
Benaulim; Curtorim; Loutulim; Margao: Raia and Verna. Total 6.Offices of the clerks of the
comunidades, Class II (40)Tiswadi - Azossim-Mandur (group): Morombim-o-grande*-Chimbel
(group): Corlim*-Ela (group) Gancim-Neura-o-pequeno* (group): Goa Velha*-Mercurim (group):
Goltim: Malar*-Naroa (group): Morombim-o-pequeno*-Renovadim (group); Murda; Navelim and
Taleigao. Total 11.Bardez - Assagao; Assonora*-Sircaim (group); Boa Esperanca of Aldona;
Bastora-Ucassim* (group); Camorlim-Colvale* (group) Moira; Nachinola: Nerul: Marra-Pilerne*
(group); Olaulim-Pomburpa* (group) Saligao and Tivim. Total 12.Salcete - Aquem-Talaulim*
(group): Betalbatim; Carmona; Chinchinim; Chandor*-Cavorim (group); Davorlim*-Dicarpale
(group) Dramapur*-Sirlim-Deusua (group); Donculim-Seraulim* (group); Macasana; Majorda;
Nagoa; Sarzora; Varca; Velim and Ambelim-Assolna*(group). Total 15.Ponda - Marcaim and
Cundaim. Total 2. Offices of the clerks of comunidades, Class III (43)Tiswadi - Bambolim-Curca*
(group). Total 1.Bardez - Arpora*-Nagoa (group); Candolim; Paliem*-Punola (group);Code of Comunidades of 1961

Nadora*-Pirna (group) and Revora. Total 5.Salcete - Camorlim; Guirdolim; Utorda; Calata*-Gonsua
(group) Cana-Vanelim* Gandaulim (group) Cavelossim*-Orlim (group); and Colva*-Sernabatim
(group). Total 7.Ponda - Siroda: Adcolna-Boma* (group); Orgao*-Tiurem (group), Bandora*-Queula
(group); Betqui-Candola*-Volvoi (group); Borim*- Talaulim-Vadi (group)
Velinga*-Priol-Cuncoliem-Querim (group); Verem-Vagurbem-Candeapar*-Curti (group) and
Betora-Codar-Conxem-Nirancal-Panchavadi* (group). Total 9.Mormugao - Arossim; Cortalim;
Cuelim; Mormugao; Quelossim; Sancoale; Cansaulim*-Velção (group);
Chicalim*-Chicolna-Dabolim-Vadem (group); and Pale*-Issorcim (group). Total 9.Bicholim -
Advalpale*-Latambarcem-Mencurem-Dumacem (group); Amona; Arvalem-Navelim* (group);
Bicholim*-Bordem-Sarvona (group); Cudnem*-Pissurlem-Cotombi-Surla (group); Naroa-
Vainguinim-Piligao* (group) and Mulgao*-Sirigao (group); Pale-Velguem-Gangem-Usgao* (group).
Total 8.Sanguem - Astragar-Curdi-Rivona* (group); and Netorlim*- Colemba-Jaqui-Nundem
(group). Total 2.Canacona - Canacona-Cola*-Nagorcem-Palolem (group): and
Gaundongrem-Loliem-Polem*- Poinguinim (group). Total 2.*Headquarters for the purpose of
compulsory residence of the clerk.Note: The offices of the clerks of the groups of comunidades of
Batim Telaulim, Santana-Goalim-Moula and Siolim-Marna-Oxel shall be filled gradually as the
vacancies for the posting of the clerks of the same comunidades take place.Table No. 3Emoluments
and SalariesTitle IAdministration office of the comunidades
Chapter I
Administration of comunidades
Article 1. The administrator of the comunidades is entitled to the following fees:
For each record of inspection, survey, possession, handingover, supervision and acceptance
of works, verification anddrawing up of balance sheet18$00
The travelling allowance shall be as per the following rates:Upto 2 Kms. from the building of
the Administration Office11$30
For subsequent 8 Kms. for each kilometer 5$70
Further from upto 15 Kms., for each kilometer or fraction 3$80
Article 2. In case when during one and same day, more than one work is performed in respect of
different files or at the request of different persons, on different subjects the charge of the travelling
allowance shall be divided proportionally among all the works which might have been performed
and it is classified that when all these works are concerning only one file, the travelling allowance
shall be one only.Article 3. In the works requested by the comunidades or ordered officially, no fees
shall be collected.Article 4. When the chairmanship of the inspection work is entrusted to the
President of the Managing Committee of the comunidade, in the cases when this is permitted by
rules, he shall be entitled to one half of the fee prescribed in article I and, when he is resident of a
different village, he shall be entitled to the travelling allowance corresponding to half the distance
from his residence.Code of Comunidades of 1961

Chapter II
Secretary, Assistants and Bailiffs of the Administrative Office
Article 5. The Secretaries and the Assistants of the Administration Office are entitled to the
following fees:
1. For inspection and other services dealt with in Article 1stincluding sealing of the safe of
thecomunidades, half ofthe fees fixed to the administrator.
2. For each intimation or notification 1$50
3. In all the works mentioned in this article performed out ofthe building of the
Administration Office, they shall be entitledto half of the fees fixed to the Administrator.
Sole § - To the case as foreseen in this number the provision of the paragraph of No. 16, Article 11 of
this table shall be applicable.BailiffsArticle 6. The Bailiffs are entitled to the following fees:
1. For each intimation or notification, half of that which isfixed for the Secretary of the
Administrative Office, and thetravelling allowance, when it is due, shall be the kilometer at1$00
2. To the crier in the auctions of the interest of the privateparties, for each bidding 1$00
Chapter III
General fees of the Administration Office
Article 7. Following fees belong to the Administrative Offices:
1. On account of the distribution of the recovery files, eachone $40
2. On account of authentication record of the main file and ofthe appended files, when there
may be, for each one1$00
3. On account of each order 1$20
4. On account of each usual record in the file $20
5. On account of each record of deposits of quit-rents, rents,arrears and other of this kind $40
6. On account of each record of security by the clerks andothers, appointment of arbiters,
experts, appeals, desistenceacquittance, ratification, bond and others of this kind3$40
7. On account of each record of enquiry, inspection, survey,interrogation, examination,
settlement of accounts, auction ofproperties, of properties granted under emphytheusis
system and ofproduce from properties and others of this kind, besides writingcharges6$00
Sole § - Only one record shall be made concerning all the produce sold under one file of proceedings:
8.For issuing notice 1$20
9.For accounting the cost of one file of proceedings 2$30
10.For each descriptive certificate or of teor, besides writingcharges 2$30
11.For each certificate of theteorand copy of the currentaccounts, besides writing charges 1$70
12.For each living certificates and for each person $60
13. 1$20Code of Comunidades of 1961

Search of the book of notings and of the catalogue of shares,when it is not the current
one
14.Search of other non-current books and files of closedproceedings:  
 a) Of the last ten years 2$30
 b) More than 10 upto 20 years further 2$30
 c) More than 20 years further 4$50
 d) When the searched thing is not found 1$20
 e) When the year is indicated search fee is not due.  
15.For eachguiaintended to the payment of the transfertax and its duplicate $20
16.Registration of the Diploma of the Public Office 2$80
17.For each record of annotation or cancellation of the burdens onshares, besides writing
charges1$20
18.For the record of references made in more than one catalogueeach title 1$20
19.For each noting in the title $30
20.For renewal of titles, besides their price, each title 1$20
21.For division or grouping of titles, besides their price, eachtitle 1$20
22.Writing charges shall be $10 for each line of 30 letters  
23.For each registration ofzonncar:  
 When the gain is up to 60$00 2$30
 More than 60$00 up to 150$00 3$00
 Upto 300$00 4$50
 More than 300$ to 600$00 6$00
 More than 600$00 to 900$00 9$00
 More than 900$00 to 1,200$00 12$00
 More than 1200$00 15$00
24.For registration of each share $40
The fee of these last two items will be deducted in the current account of the respective party in the
first year of the registration.
Chapter IV
(Article 627)
In the Coercive RecoveriesArticle 8. Administrator:
1.For initials in letters of any kind, orders examination ofnotices,guias, documents, records
and writings in theproceedings where he is the chairman, in the folios where there isno
signature....$40
2.For signature in the letters of any kind, edicts, deprecativeletters, certificates and $50Code of Comunidades of 1961

acquittances....
3.For Chairmanship in the work of checking of the currentaccounts and in the examination
of the books and records existingin the record room of the administration office or in
anyComunidade, for not more than 4 hours....7$50
 For each exceeding hour, besides the said four hours.... 1$90
4.For Chairmanship in the auction of shares, crops, produces orany other property and for
each record of auction where the priceof bidding does not exceed 750$00.....6$00
 When more than 750$00 and less than 1.500$00.... 12$00
 When more than 1500$00.... 12$80
 For each record of the auction comprising all the property notauctioned during each day
because of the want of bidders....3$80
Sole § - In the case of lease, the fees will be calculated taking as its basis the value of the total rent
corresponding to the whole period of the lease.
5.For the record of the adjournment of auction, at the request ofthe interested party.... 3$80
6.For the decision of the contestation against the currentaccount.... 15$00
7.For the decision on the coercive recovery.... 4$50
8.Travelling allowance, the same as laid down in No. 1 of article1  
9.For each record of personal deposition.... 4$50
Article 9. Accountants:
1.For each item fees, salaries and costs accounted by them.... $40
§ 1. It is item of fees or salaries, or each one of the rates indicated in this table, in respect of the acts
and records in the proceedings: and item of costs, is part of account or each account already paid by
the parties or paid in advance by any of the officials of the Recovery Section.§ 2. However, for the
said purpose, it is considered as one item:(a)All the travelling allowances of each official;(b)All the
signatures of the same official;(c)All the initials of the same official;(d)All the stamp duty, including
stamp duty on the copies of summon and on copies which, under this Code or as per this table, have
been issued on ordinary paper;(e)All the stamp duties paid under cash payment;(f)Cost of the stamp
duty of the ordinary paper supplied by each official:Folio (stamped or ordinary) means folio of the
file of proceedings.
2.For accounting certificates, transcripts, copies, decision ofany kind whatever, request
letters, deprecative letters and anyother sundry writings or documents, each page....$20
3.For calculation of interest, upto one year.... $50
 For each further year or fraction.... $20
Article 10. The accountants will have to do under separate addition the calculation of what belongs
to them as their own salary and when its total exceeds 6$00 they will clearly indicate the number
and article of this table where the fees corresponding to different additions are found fixed and on
account of this procedure, they will not be entitled to any additional salary.Article 11. Clerks of
comunidade:
1.For each intimation.... 3$80
2.For each notification.... 2$30Code of Comunidades of 1961

(a)In case when the intimation or notification could not take place, on account of any of the reasons
as mentioned in the Civil Procedure Code, the clerk will be entitled to the same salary for his issuing
the certificate of his attempt;(b)For the purpose of calculation of fees, it will be considered as only
one intimation or notification those which were made on the same occasion and for the same object
to the wife and husband or to the co-heirs of the original debtor, when the former and latter are
residents of the same house;(c)The intimation whereof the certificates are not in keeping with the
directives of the CivilProcedure Code or which do not clearly state the place, date and the
approximate time of the intimation do not create right to any salary whatever.
3. On account of the copies of the summons and copies which might be
given to the persons subjected to the intimations or notifications or to the
depositories on the occasion of attachment and which are to be written on
ordinary paper (legal type) the clerk, besides the costs as mentioned in No.
14, will have the right to writing charges.
4.For each writ, deprecate letter or challan of payment ordeposit, up to 25 lines... 1$00
 For each further line, they will be entitled to the writingcharges.  
5.On account of the copy of the attachment record forregistration in the Land Registration
Office, the clerk who hasissued it shall receive the writing charges. 
6.Of initials on any documents or writing, under rules... $20
7.For each record of security or deposit of money... 1$90
8.For manuscripts of the edicts and announcements, each... $60
9.For each record of attachment effected in the premises of theoffice, besides writing
charges...3$80
10.For each record of the attachment of the crops, produce and anyother immovable,
movable property or cattle, besides writingcharges...7$50
11.For recording any work presided by the administrator, half ofthe fees due to this last
officer and the writing charges andbesides this he is also entitled to the travelling
allowance whenthe work is performed outside the office premises. 
12.For each charter of auction, upto 25 lines... 3$80
 For each further line, they shall have right to the writingcharges.  
13.On account of the cost of the ordinary paper supplied by them,each folio... $10
Sole § The cost of the paper supplied for the copies of summons and copies shall be accounted on
the basis of the declaration made in the respective certificate or records, with reference to the
number of the papers which were supplied.
14.For each descriptive certificate or teor certificate based onany file of proceedings in his
possession and the respectivetranscript, besides the writing charges....1$00
15.Writing charges for each line of 30 letters, and the figuresare to be counted as letters.... $10
 When typed, each line.... $10
16. 1$50Code of Comunidades of 1961

On account of the travelling allowance, in the intimationsnotifications, attachments and
any other action performed outsidethe office premises, upto 2 kms. for each kilometer
orfraction....
Sole § There can be no more than one travelling allowance on the same day and also in respect of the
intimation and notification when they have been ordered under the same and one order though they
might have been effected on different dates.Article 12. Bailiffs in the Recovery Section:
1. On account of the intimation and notification, half of the salary and of the
travelling allowance as prescribed to the clerk of the proceedings in Nos. 1, 2
and 16 of the Article 11, and the provisions of the sub-paragraphs (a), (b) and
(c) of No. 2 of the said article are applicable to them and also the provision of
No. 14 of the same article, in respect of the copies of the summons and
copies given to the persons subjected to the intimations or notifications.
2.For sticking edicts, comprising the certificates of stickingwritten in the respective copies:
 For the first edict.... 2$80
 For each further edict stuck on the same subject.... 1$40
3.For being present at the attachment.... 3$80
4.For working as crier during any auction, each bid.... 1$50
5.For arrests made on writ by the administrator, each person.... 15$00
6. For the auctions which have not been specified in the preceeding numbers
and where the bailiffs may be present in the company of administrator and
the clerk, or in the company of the clerk alone, they will receive half of that
which may belong to the clerks.
Title IIComunidades
Chapter I
Clerk of comunidades
Article 13. The clerk of the comunidades has right to the following fees:
1.For registration of any landed property in any Tombo.... 2$30
2.For division and individualization of the foro each part of theproperty.... $80
3.For calculation and certificate of redeeming the derrama.... 1$50
4.For noting the burden of usufruct, attachment and the burdenson the shares or their
profits and cancellation of the sameburdens in the respective registers or in the current
accountsbooks....$60
5. 4$50Code of Comunidades of 1961

For attending inspections, surveys, collections of crops andassessment of damage and
other similar works....
6.For investing provisional possession as the grantees of theemphteusis (aforamentos),
besides writing the record on account ofwhich he will get writing charges....4$50
7.For the record of carrying or depositing the produce of theproperties and of thrashing the
fields, besides the writingcharges....2$30
8.For the records of transfer, surety, damage and charge of thevalue not more than
150$00....1$50
 When exceeds to 150$00.... 3$00
9.For record or cession of the right (outorga) of the value notexceeding 150$00.... 1$50
 When it exceeds, for each 150$00 or its fraction, further.... 1$50
 This fee will be deducted from the amount which was transferredand from the title of the
person who ceded his right. 
10.For the ordinary records of reception, forwarding andsubmission, each one.... $20
11.For the opening of the coffer out of the usual days, in thevillage.... 3$00
Sole § When it is out of the village or in theAdministration Office, besides transport, under
article 16 of thistable6$00
12. For intimation or notification, same as fixed to the Bailiff.
13. Search of books when they are not current books, same as in No. 13 of
Article 7.
14. When it refers to the books earlier than the last 10 years, same as in the
sub-paragraphs of No. 14 of Article 7
15.Writing charges, each line of 30 letters.... $10
16.For descriptive certificate, besides writing charges.... 1$50
17.For certificate ofteor, besides writing charges.... $80
RecoveriesArticle 14. The clerk of the comunidade will receive:
1.For each current account, comprising the certificate writtentherein, besides the writing
charges....1$20
2.For attending the examination of the books and documentsexisting in the record-room of
the comunidade, each day....4$50
3.For each record of attachment, besides writing charges.... 6$0
4. For intimation, notification, copy of the records, certificate opening of the
coffers in the case of paragraph 1 of Article 615, besides the travelling
allowances and writing charges when they are due, he will receive the same
as fixed to him in the preceding article.Code of Comunidades of 1961

5. For acts in which he may intervene as clerk of the proceeding or as bailiff,
he shall receive the fee corresponding to the functions and acts which he
might have performed.
Chapter II
Experts and arbiters
Article 15. The experts and the arbiters shall receive:
1.For each survey in order to acknowledge the need of works,their supervision and
calculation of expenditure, besides thetravelling allowance as per the provision of article
4....13$50
2.For the examination of books, signatures, papers and otherinspections, besides the
travelling allowance counted from hisresidence and as per the provision of article 4....13$50
Sole § In case of qualified person, he shall receive the same as the administrator, except when he is
the Director of P.W.D. or his deputy or other qualified officer who shall receive the daily allowance
fixed in the official table, when their attendance is expressly prescribed in this Code, besides the
travelling allowance under article I of this Table. When it is about inspection or handing over of
works, the sum of fee and travelling allowance cannot be higher than two per cent of the value.
Chapter III
Members of the Managing Committee
Article 16. It will be allowed to each member of the Managing Committee, besides the allowance
fixed in the article 57 of this Code, the transport at 6$00 per each meeting and for each 5 kms. or
their fraction, besides the first 5 kms., the total allowance being not to be more than 30$00.Sole §
To the clerk, transport is not allowed when the meetings are held in the village not withstanding his
residence is outside the same village.
Chapter IV
Attorney and key-holders
Article 17. Following fees belong to the Attorney:
For each inspection, survey, handing over and other acts ofthis kind, one day.... 9$00
Continuing, for each further day.... 4$00
Article 18. Each key-holder is entitled, on account of the opening of the coffers at the request of
parties, same fee as fixed for the meetings of the managing committee.Code of Comunidades of 1961

Chapter V
Staff of the cadastral survey
Article 19. The staff employed for cadastral survey shall have right to following remuneration:
1.To the surveyors for the field work, besides the transport boththe ways, for the distance
exceeding 5 kms., per day....20$00
2.To the same, for indoors work, per day.... 14$00
3.To the apprentice-surveyors, for the field work, per day.... 13$00
4.To the same, for indoors work, per day.... 9$00
5.To the draughtsmen, per day.... 9$00
6.To the apprentice draughtsmen, per day.... 8$00
7.To the measurers including the days of journey, per day, eachone.... 15$00
8.To informers, each one, per day.... 9$00
9.To the Attorney of thecomunidadeor his representative,per day.... 9$00
10.To the clerk of thecomunidade, per day.... 7$00
Chapter VI
Article 20. The request of comunidades or their Attorneys for performing any work or to obtain any
document shall be acceded to by the employees of the Administration or of the comunidades
without payment of the fees on the spot and, at the end the looser party, when there is one, shall be
adjudged responsible to their payment.Article 21. For calculating the travelling allowances, only the
going journey shall be taken into account in all cases and, in no case, the travelling allowance shall
be sanctioned from a distance superior to 15 kms.Sole § In all cases when there is a right to the
travelling allowance, the number of the kilometers travelled up to the site of the work is to be
indicated.Article 22. In the recovery proceedings, when the dues to be recovered are 150$00 to
300$00, half of the prescribed fees shall be allowed and, when the dues are less than that, one
fourth of fees shall be allowed.Article 23. The accounting and collection of the ordinary fees is of the
competence of the secretary to the Administration and they are to be recorded in the Register as
referred to in the article 440.Article 24. In the certificates, certified copies and other sundry papers
and also in the payment records written in the files of proceedings or in the books, the respective
official shall mention the serial number of the entry of the receipt in the Register of ordinary fees,
under the penalty of 30$00 of fine for every infringement of this rule.Article 25. At the end of each
trimester it will be credited to the Pensioner's Fund the fees which were collected and in the entry
recorded in the respective Cash-Book, mention will be made of the serial number of the entries in
the Register of ordinary fees, corresponding to the amounts which are credited.Article 26. On the
first opening of the safe which may follow the closing of the current accounts, the Comunidades
clerk shall take from the safe the amount of the ordinary fees referred to in Nos. 20 and 21, article 7
of the Table, and of the zonns, dividends and other receipts payment of which is lapsed and, within
the period of 8 days, he shall remit it to the Pensioner's Fund or its delegation in the Taluka,
alongwith a detailed list of the receipts, in duplicate. The duplicate is to be returned to him after it isCode of Comunidades of 1961

countersigned by the administrator and the Secretary. This duplicate shall be exhibited during the
examination of the accounts in order to check its accuracy with the books.Article 27. It is forbidden
to include in the ordinary estimates and in the estimates of urgent and extraordinary works
conditions that it will be borne by the contractors the responses arising from the inspections to be
made for supervising and handing over of the same works.Article 28. The fees of translation shall be
regulated by the official rates.Article 29. The experts of the comunidades works who may intervene
in any inspections or who may undertake journeys while in service shall be entitled only to be paid
of the expenses with the transport as per the rules laid down in respect of the Government servants
and the use of special transports is dependent of the authorisation by the Director of the Civil
Administration except in the case of urgency and, in this case, the administrator is empowered to
grant such an authorisation and he has to communicate this fact immediately to that Officer.Article
30. When the vehicles supplied by the comunidades are available to the Administration Offices, they
shall not be entitled to travelling allowances.Article 31. The fees which are not received by the
administrators and the officials of the Administration Offices, including the recovery clerks and
comunidades clerks in view of the provision of the subparagraph (b) and (c), paragraph 1, article 153
of the Overseas Civil Services Statute, are to be reverted in favour of the General Treasury and this
income is to be shown in the annual budgets.Sole § It is the duty of the administrators to see that the
provision of this article is complied with in toto, in respect of the staff of the Administration Offices
as well as in respect of the clerks.Model No. 4(Article No. 125, No. 3)Ordinary budget of receipt and
expenditure of the Administration of comunidades of taluka of .......... for the year 19.......*
Sr.
No.Receipts Amount Sr. No. Expenditure Amount
 Balance of the management of the
previous years(for each year)  Of the accounts
concerning previous
years (foreach item*) 
1  .....$..... 1  .....$.....
2  .....$.....  Current .....$.....
3 Current .....$..... 2  .....$.....
4  .....$..... 3  .....$.....
5  .....$..... 4  .....$.....
6  .....$..... 5  .....$.....
7  .....$..... 6  .....$.....
8 Occasional .....$..... 7  .....$.....
9  .....$..... 8  .....$.....
 Contribution of thecomunidade .....$..... 9  .....$.....
 Total .....$..... 10  .....$.....
 Quota of eachcomunidadewhich
comprises,in terms of Article 125, No. 3
of this Code, is as follows: 11  .....$.....
 12  .....$.....Code of Comunidades of 1961

  Occasional  
 Communidadeof Adsulim .....$..... 13  .....$.....
 Comunidadeof Aquem .....$..... 14  .....$.....
 Comunidadeof Arossim .....$..... 15  .....$.....
 Comunidadeof Benaulim .....$.....   .....$.....
 Total .....$.....  Total .....$.....
Sd/- The Secretary to the Administration of the comunidades.Model No. 5Table of the movement of
the shares of the comunidades of ............... Taluka effected from the date of their issue upto 31st
December, 19..........
CommuninadesMovement
which took
place for the
issue upto
31stDecember
19....Movement
of the year
19....Total
Notes of TransferNote of
BurdenNotes of
TransferNote of
BurdenNotes of
TransferNote of
Burden
Number of NotesNo. of
respective
titlesNumber
of NotesNo. of
respective
titlesNumber
of NotesNo. of
respective
titlesNumber
of NotesNo. of
respective
titlesTotal
number
of NotesTotal No.
of
respective
titlesTotal
number
of NotesTotal No.
of
respective
titles
..............................Total..             
Administration of the comunidades of .............. at ........... 19......Sd/- The administrator of
comunidades of .............Model No. 6(Article 545)Record of primary enrolment of zonnkarNo. 1On
this .... of May, 19 ... in this village of ..... and in the premises of the respective Comunidade, before
me and (name) ......... clerk and attorney of the said comunidade, there appeared (name) .........
resident of ....... (personally or through his representative: father, mother, guardian, attorney) and
he exhibited the certificate of the Parish Register (or Civil Register, order of the administrator on the
appeal against the refusal of the Administrative Tribunal, copy of the judical decision), issued on
............. of the current year and I ascertained its authenticity and it shows that the said (name)
............. is legitimate (legitimized, adopted) son of the "gaonkar" (or what he is) name .......... of ........
"vangor" in the order of precedence and that his age is ...... completed years (and he is unmarried or
married), as required by the respective "institute": and, consequently, we enrol him as zonnkar of
this comunidade in the class of "Gaonkar" (culacharim, vantelo zonnkar or what he is) in order to
enjoy all the rights and to be subject to all the duties which, in that capacity, belong to him. The
document (or the documents) which had been exhibited is filed in bundle No. ...... In faith whereof,
this is made and it is signed by the said (name) (or by his representative), by the attorney of the
comunidade and by me, clerk, who wrote it ...........(Signature of the party)......... Attorney of the
comunidade.......... Clerk of the comunidadeN.B.: If the enrolment was effected because the claimant
comes under the provision of article 184 or article 185, it will be stated whether the person is a son,
widow or daughter of the deceased zonnkar and also the provision of the Code and the documents
on which ground the same person was enrolled.Model No. 7(Article 103, paragraph 4)Enrolment ofCode of Comunidades of 1961

the zonnkars of the comunidade of .................. in the year 19....
Roll
No.Date
1960Name of
the
zonnkarResidenceAge in
completed
yearsClass and
"Vangor" to
which he
belongsNo. of the
entry and
folio of
the book
where itis
recordedIn view of
which
document he
was enrolledRemarks
1 01/05/01Joao
Jose
BorgesArpora 27"Gauncar" of
3rd "Vangor"59, f. 18Certificate of
the parish
priest 
2 01/05/07Victor
Manuel
de SaChorao 18 "Culacharim" 63, f. 24Appeared in
person 
3 01/05/22Pedro de
AtaideRaia 59"Gauncar" of
7th "Vangor"12, fl. 3Certificate of
administrator
of
communidade 
4 01/05/31Miguel
de SouzaAzossim 22 "zonnkar" 27, f. 9Certificate of
the Taluka
administrator
orRegedor, etc. 
This roll is closed, after the enrolment of four zonnkars who proved their existence within the period
prescribed by the Code of Comunidades.
1st. May, 19...../............... Attorney of the Comunidade.
Sd/- Clerk of the comunidadeRemarksWhen the zonnkar is entitled only to a part of the profits, this
being the year of his enrolment, this circumstance would be stated in the column of the remarks,
opposite the respective name. When the zonnkar is registered for receiving the profits of the
respective year and of any of the last ten years, this should be mentioned in the said column of
remarks with the specification of the said year. When the registration of the widow or of the
unmarried daughter is made consequent upon the provision of article 185 of the present Code, this
should be mentioned in that column, stating the tença or the jono she has to service.Table No.
8(Article 1, para. 3)Of the transferable shares of the comunidades of Tiswadi, Salcetc, Bardez,
Mormugao and Ponda with the indication of the modality about apportioning the respective income
of the association and of fixing the annual dividend.TiswadiAzossim. - Multiply the number of zonns
(personal and of the Saints) by 56(*) (2 of "culacharins" and 4 of widows of "gaonkars" should be
taken as 1); to the product the number of the shares (300) is to be added and by this sum the net
income will be divided. The quotient will indicate what pertains to each share and, the
multiplication of this quotient by 56 will indicate what pertains to the zonns of the Saints. One half
of the amount of this zonn (of the Saints) will be the dividend of the zonn of culacharins or their
orphans and one fourth will be the dividend of the zonn of the widows of the "gaonkars". The
income of the "namoxins" will be divided by the "gaonkars" zonnkars and this quotient added to theCode of Comunidades of 1961

zonn of the saints (which is the product of the multiplication of 56 by that which pertains to each
share) will be the dividend of one zonn of "gaonkar" or of their orphans - 300.Bambolim. - The net
income will be divided by 1000 shares and the quotient will show what pertains to each share. The
product of 697 shares is to be distributed among the number of the "gaunkars" zonnkars and their
widows; the product of 249 shares is to be distributed among the number of "culacharins" and their
widows and the product of the remaining 54 shares (transferable) will be alloted to the shareholders
according to the number of shares possessed by them - 1000.Batim. - After the net income is
calculated, with the exclusion of the income of "namoxins" and of the fields of "honra" e "coita" one
forty eighth will show what pertains to each share of "tangas". The number of the personal zonns of
"gaonkar" as well as "culacharins" will be multiplied by 53 (*) (taking the zonns of 2 male orphans or
of 4 female orphans or widows as one) and to the product, the number of the shares of zonn (273)
will be added and also will be added 73 shares proceeding from the fractions of the number of the
zonnkars of 1881 pertaining to their group, by this sum, of the net income will be divided. The
quotient will show what pertains to the share of "jono" and multiplying the same quotient by 53 and
adding to its product the quota of the said 73 shares of the group of the zonnkars (obtained by the
division of their profits by the number of the zonnkars in the same proportion as that under which
they might have received their zonns) the resulting sum will indicate what pertains to the zonn of
"culacharins". The sum resulting from the addition of the zonn of "culacharins" to the quota of the
income of "nomoxim" and of the fields of "honra e coita" will indicate what pertains to the zonn of
"gaonkar". The dividend corresponding to 91 shares taken for rounding the number will be added to
17/48 ths of the net income of the next year - 400.Calapur. - The number of the personal zonns
(taking those of 3 widows as one) will be multiplied by 9 (*); to the product, the number of shares
(200) will be added and also will be added 355 shares proceeding from the fractions of the number
of the zonnkars of 1881 belonging to the group of zonnkars and the net income will be divided by
that sum. The quotient will indicate what pertains to each share and the sum of the product of the
multiplication of the same quotient by 9 with the quota of the said 355 shares of the group of
"zonnkars" (obtained by dividing the income of the same shares by the number of zonns) will
indicate what pertains to the zonn, and further adding to this last amount the quotient of the
division of the income of "covados", in accordance with the respective "vangor" or group, this will be
the dividend of the zonn of different "vangor" - 200.Carambolim. - Multiply the number of personal
zonns by 131 (*) (taking 2 of the "gaonkars" of half zonn, 4 of unmarried daughters or widows as
one), add to the product the number of the shares (100) and also 247 shares proceeding from the
fractions of the number of zonnkars of 1881, belonging to this group; and for this sum shall be
divided the net income. The quotient will indicate what pertains to the share and multiplying the
same quotient by 131 and adding to its product the quota of 246 shares of the group of zonnkars
(obtained by dividing the income of the same shares by the number of zonnkars in the same
proportion as under which they receive their zonns) the resulting sum will indicate what pertains to
the zonn of "gaonkar" or to the zonn of his orphan - 100.Chorao. - Calculate the net income by
separating in the account sheet 506$20, 4 for the "tenças" (annuities) of "gaonkars" and of
shareholders 163$30 for 35 shares of rounding, and 4.881, 2 for shares of "tangas brancas", as 90
were expropriated by the payment of the indivisible remainder (20$20) to the Government
Treasury, distribute the net income to the zonnkars in the same proportion as their profits. The
income of nomoxins, after deduction of the proper expenses, added to 271$00 of the "tença" of the
"gaonkars" will be distributed only to the "gaonkars" who will be paid this amount on account of theCode of Comunidades of 1961

"tença".The remaining amount of "tencas" (235$30) as 37$90 were expropriated by the payment of
(947$40) arising from the indivisible remainder the remaining amount of the "tenças" (235$30)
added to 163$30 and 4.881$70 (Total 5.280$10) is to be divided by the number of the shares
(1.100). The quotient will indicate what pertains to each share. The product of 34 shares taken for
rounding will be carried as income in the accounts of the next year - 1.100.Corlim. - Multiply the
number of personal zonn by 27 (*) (taking 4 zonns of widows or orphan daughters as 1) and add to
its product the number of shares (100) and more 27 proceeding from the fractions of the number of
the zonnkars of 1881, belonging to their group; Divide by this sum the net income and the quotient
will indicate what pertains to each share; and multiplying the same quotient by 27 and by adding to
that product the quota of the said 27 shares of the group of zonnkars (obtained by dividing the
profits of the same by the number of zonnkars) the result will indicate what belongs to the zonn of
"gaonkar" or to his orphan children - 100.Gancim. - Multiply the number of the personal zonns by
357(*) (taking the zonns of 4 widows as one); add to the product the number of the shares (2800)
and divide by this sum the net income. The quotient will indicate what pertains to each share; and
by multiplying the same quotient by 357 the product will indicate what pertains to the personal zonn
- 2.800.Goa Velha. - The net income is to be divided by the number of the shares (4300); and the
quotient will indicate what pertains to each share - 300.Goalim-Moula : - The net income shall be
divided by the number of shares (300), and the quotient shall indicate what pertains to each share -
300.Goltim. - Calculate the net income by separating 1.442$70 in the accounts sheet; divide this
amount by the number of the shares (300) alloting in favour of the Government Treasury that which
corresponds to 270 shares; and the dividend of 30 shares will be carried forward to the income of
the next year. Distribute the net income among the number of the zonnkars - 300.Jua. - Multiply the
number of the personal zonns by 8(*) (considering 4 zonns of the widows or of the orphan
daughters as one) and add to its product the number of the shares (100) and also 119 shares
proceeding from the fractions of the number of the zonnkars of 1881 belonging to their group; by
this sum divide the net income. The quotient will indicate what pertains to each share; and by
multiplying the same quotient by 8 and adding to the product the quota of the said 119 shares of the
group of the zonnkars (obtained after dividing their income by the number of zonnkars in the same
proportion as under which they receive their zonns), it will indicate what pertains to each personal
"zonn" -100.Mandur. - Multiply the number of personal zonns by 30(*); add to the product the
number of the shares (100) and divide by this sum the net income. The quotient will indicate what
belongs to the share and the multiplication of the same quotient by 30 will indicate what pertains to
the personal zonn.Malar. - Calculate the net income and take aside in the account sheet 1.446$00;
Divide this sum among the number of the shares (300) alloting to the Government Treasury that
which corresponds to 229 shares; and the dividend of 71 shares will be carried forward as income in
the next year. The net income will be distributed by the number of the zonnkars in the usual fashion
- 300.Mercurim. - The number of the personal zonns will be multiplied by 4(*) (taking the zonns of
4 widows as one) and add to the product the number of the shares (100) and also 54 shares
proceeding from the fractions of the number of the zonnkars of 1881 belonging to their group. By
this sum divide the net income. The quotient will show what belongs to each share; and the product
of the multiplication of the same quotient by 4, added to the quota of the said 54 shares of the group
of the zonnkars (obtained by dividing the profits of the same by the number of the zonnkars) in the
same proportion as under which they receive their zonns will indicate what pertains to each
personal zonn - 100.Murda. - The net income will be divided by the number of the shares (3.700)Code of Comunidades of 1961

and the quotient will indicate what pertains to each share - 3.700.Naroa. - Calculate the net income
and take aside in the account sheet the sum of 183$40. Allot this sum to the Government Treasury
on account of the 38 non-transferable shares of invariable income. Next, multiply the number of the
personal zonns by 19(*) taking as one share 4 of the widows or of the unmarried daughters; and add
to the product the number of the transferable shares (62) and also 5 shares proceeding from the
fractions of the number of the zonnkars of 1881 belonging to their group. By this sum divide the net
income. The quotient will indicate what pertains to each share. And multiplying the same quotient
by 19 and adding to the product the quota of the said 5 shares of the group of the zonnkars (obtained
by dividing the profits of the same shares by the number of the zonnkars in the same proportion as
under which they receive their zonn) the resulting sum will indicate what pertains to each personal
zonn - 100.Navelim. - Calculate the net income taking aside in the account sheet the sum of
2.106$30. Allot this sum to the Government Treasury on account of the 439 non-transferable shares
of invariable income. Next, multiply the number of the personal zonns by 16(*) (taking 2 of
"culacharins" as one share) add to the product the number of the transferable shares (61) and also 8
shares proceeding from the fractions of the number of the zonnkars of 1881 belonging to their
group. By this sum the net income will be divided. The quotient will indicate what belongs to each
share; and multiplying the same quotient by 16 and adding to the product the quota of the dividends
of the said 8 shares of the group of the zonnkars and the net income of the "namoxins" (obtained by
dividing their income by the number of the zonnkars in the same proportions as under which they
receive their zonn) the result will indicate what pertains to each zonn of "gaonkar" or to each zonn of
their orphans. Half of that which belongs to the zonn of "gaoncar" (excluding the quota of the
"namoxins") will be the dividend of the zonn of the "culacharins" or his orphans
-500.Neura-o-Grande. - The net income of the fields of the comunidade excluding the properties
known as "namoxins de Tomas Coelho Peres" and also those of the four enclosed associations will be
divided by 19121 shares and the quotient will indicate what pertains to each share. The produce of
the 4375 shares of the group of the "gaonkars" zonnkars added to the income of "namoxins" and to
the produce of two thirds of the clerks' office will be distributed equally among the number of the
zonnkars and of the orphans existing at the time of the death of the "gaonkar". The produce of the
shares taken for rounding will be carried forward to the income of the next year - 19300.Enclosed
associations of "adverica", "vanvans" of Gopala Sinai, Sinani and clerk's officeAs for the adverica,
deducting only what is necessary for the payment of half per cent. of the rent of the field (Adverica)
belonging exclusively to the group of the shareholders of the same, the remainder will indicate what
belongs to each share of the adverica. As for the vanvans, the rent of their fields, after deducting only
half per cent. is to be divided into three parts, one to be applied to the group of the shareholders of
Gopala Sinai in the proportion of their shares, the second in the same manner to those of Sinani,
and the third will be divided again into three parts, applying one of them to the shareholders of the
clerk's office, and the other two to the group of the zonnkars of the main comunidade.Renovadim. -
The net income is to be divided by the number of the shares (1.000) and the quotient will indicate
what pertains to each share; its dividend will be allotted to the shareholders according to their
number of shares without any more right to receive the paddy as it is done now, because its price
was included in the value of the share - 1.000.Siridao. - The deficit or the surplus of this comunidade
will be divided by the number of the shares (200) and the quotient will indicate what pertains to
each share - 200.Telaulim de Santana. - As there are in this comunidade two different fields, one
belonging exclusively to the zonnkars and other to the shareholders, the net income of each groupCode of Comunidades of 1961

will be calculated separately. After one third is separated from the income of the group of zonnkars,
the remaining two thirds are to be divided by the number of the zonnkars and the quotient will
indicate what pertains to each zonn. One third of the net income of the group of zonnkars added to
the rent of the field of the shareholders and to the sum of the limited quit-rents (foros limitados)
belonging to this group constitutes the income of the group of the shareholders. From this, after
deduction of the proportional allowance (derrama) to the Agrarian Chamber, the allowance of the
receiver (sacadoria), the derrama of "melaga" and the salary of the servant (only expenses to which
the shareholders are liable), the net rent will be divided by the number of the shares (1600) and the
quotient will indicate what pertains to each share - 1600.Taleigao. - After the net income is
calculated, it will be divided by the personal zonns of the "gaonkars" and their widows (considering
zonns of 2 widows as one) and by 5 zonns (of honour and precedence); the proceeds of these 5 zonns
will be separated from the said income and the remainder will be divided by 4. One fourth, added to
the one fourth of the expenditure effected in respect of the burials, will be deducted from the
amount to be divided and the remainder, added to the said proceeds of 5 zonns will be the amount
to be divided for the zonns of the "gaonkars", their widows and for 5 zonns and therefore, the same
amount will be distributed among them in the same proportion as under which they receive their
zonns. To the first zonn of honour, 28$30 will be added and it will be allotted in the usual form and
the produce of the other 4 (transferable) will be divided among the 100 shares of zonns. The
dividend corresponding to 24 shares taken for its rounding will be added, in the next year, to the
proceeds of the said 4 zonns before the distribution is effected.Next, the number of the personal
zonns of "culacharins" will be multiplied by 6(*) and the number of the shares of "tangas" (600) will
be added to the product, by this sum, the said fourth part of the net income brought together with
the forth part of the burials, will be divided and the quotient will indicate what belongs to each share
and the product of the multiplication of the same quotient by 6 will indicate what pertains to the
zonn of "culacharin" - 700.Association of Passo de Ambarim. - Calculate the net income by
separating in the accounts sheet 566$72; divide this amount by the number of the shares and the
dividend of the 90 shares will be carried forward to the next year. The net income will be divided
among the zonnkars - 100. (*)this number is of the shares corresponding to the
zonns.SalseteAdsulim. - It has got 100 shares. The dividend of each share will be calculated by
dividing the sum to be distributed or the dividend as fixed in the annual statement by the said
number of shares.Ambelim. - It has got 16.750 shares.Aquem. - It has got 2400 shares. The dividend
of each share will be calculated by dividing the dividend fixed in the annual statement by the said
number of shares.Assolna. - It has got 20.000 shares (a).Benaulim. - It has got 11.700 shares. It has
got also members with right to personal zonn of three different classes, namely: "gaoncars", natives
and "zonnkars".To all these three classes are belonging 2899 shares registered as of the group of
zonnkars. To the class of "gaonkars", besides this, belongs the "Vangorbarnim", amounting into 17$.
The personal zonn of the 3rd class zonnkars is equivalent to 4 shares plus the quota of 246 shares,
both taken from the said 2899 so that they may form their separate group. The zonn of 1st and 2nd
class ("gaonkars" and natives) is equivalent to the quota of the remaining shares after deducting
from the said 2899 shares those which were allotted to the zonnkars of the 3rd class. But, during the
division between them, the "gaonkar" will be separated as one unit and the natives as half unit.
Further, it belongs to the "gaonkars" the quota of the said "Vangorbarnim", by dividing it among the
"vangors" and by dividing per capita the quota pertaining to each "vangors" among the respective
"gaonkars".In view of this, division will be effected among all the members shareholders,Code of Comunidades of 1961

"gaonkars", and natives, in the following manner:From the sum to be distributed or from the
dividend fixed in the annual account sheet, before any other thing is done, 17$ of "Vangorbarnim"
will be kept aside and the remainder will be divided by 11.700. The quotient will indicate the
dividend corresponding to each share.When the dividend to be allotted to each share is thus
calculated, the gains will be calculated of the zonns of the classes, zonnkars, natives and
"gaonkars".Multiply by 4 the number of the zonnkars of the 3rd class enrolled during the year. Add
to the product, 246 shares belonging only to this group and the sum will show the number of the
shares, the dividend of which is to be divided among the enrolled members of this class. The
quotient of this dividend, divided per capita among the enrolled zonnkars, will indicate the gains of
the zonn of the class of the zonnkars.The number of the "gaonkars" enrolled during the year will be
multiplied by 2, and by adding to the product the number of the natives enrolled in the same year,
the divisor which will divide the dividend of the shares will be found. These shares are those which
remain out of the group of the said 2899 after deducting from them those which were allotted in the
preceding calculation in favour of the zonnkars of the 3rd class.The gains of the zonn of the
"gaonkars" will be twice than those of the natives, besides the quota of 17$ of "Vangorbarnim" after
its division among the 9 "vangors" which from the comunidade. This quota of each "vangor" will be
sub-divided per capita among the enrolled "gaonkars" of the respective "vangor".Betalbatim. - It has
got 5.400 shares. The dividend of each share will be calculated by dividing the dividend fixed in the
annual accounts sheet for the said number of shares.Calata. - It has got 1,300 shares. The dividend
of each share will be calculated by dividing the sum to be distributed or the dividend fixed in the
annual accounts sheet by the said number of shares.Camorlim. - It has got 700 shares and also
members known as "gaonkars" with right to the personal zonn. The zonn of the "gaonkars" is
equivalent to 9 shares, plus the quota of 152 shares belonging to the group of the zonnkars.Taking
this into consideration, the first thing that will be done is to calculate the divisor in the following
manner:The number of the "gaonkars" enrolled during the year, will be multiplied by 9 and 700
shares will be added to the product; this sum will indicate the divisor of the respective year. After
this is done, the sum marked for distribution or the dividend fixed in the annual accounts sheet will
be divided by this division. The resulting quotient will be the dividend which pertains to each share
in the respective year; and the gains of the personal zonn of the "gaonkars" will be the product of the
same quotient multiplied by 9, added to the quota corresponding to the dividend of 152 shares of the
group of the zonnkars. This quota will be found by dividing the same dividend of 152 shares by the
number of the enrolled "gaonkars", in the respective year.Cana. - It has got 100 shares. The dividend
of each share will be calculated by dividing the amount earmarked for distribution or the annual
dividend fixed in the accounts sheet by the said number of shares.Carmona. - It has got 6300 shares.
The dividend of each share will be calculated by dividing the dividend fixed in the accounts sheet by
the said number of shares.Cavelossim. - It has got 900 shares and also members known as
"gaonkars", with right to personal zonn or the share of "vangor". The share of "vangor" is composed
of 11 shares assigned to the group of the zonnkars.In view of this, division will be effected of the
dividend fixed in the annual accounts sheet by 900 which is the number of the shares and the
dividend will indicate what pertains to each share in the respective year.The dividend of the 11
shares of the share of "vangor" will be divided among the 10 "vangors" composing the comunidade
and the quota which pertains to each "vangor" will be sub-divided per capita among the enrolled
"gaonkars" of the respective "vangor". The result will be that which pertains to the "zonn" of each
member of this class.Cavorim. - It has got 3500 shares. The dividend of each share is calculated byCode of Comunidades of 1961

dividing by the number of the shares the general dividend fixed in the annual accounts sheet, after
deduction of the net income of the following fields:
1. Quepo of the zonns of the "gaonkars";
2. Coli;
3. Canteiro de Coli;
4. Setmeamoroda;
5. Cumbleantanco of zonns;
6. Camorantanco of zonns;
7. Cumbleamoroda of zonn" do 1st "lanco";
8. Cumbleamoroda of zonns do 2nd "lanco";
9. Cotomoroda of zonns.
This comunidade has got also members known as "gaonkars" with right to the personal zonn and it
belongs to them the exclusive income of the preceding fields, less 62$50.Payable to the master
(mordomo) of the feast of Our Lady of Belem and St. Anthony is to be considered as a zonnkar.The
profit of each zonns will be calculated by dividing the said net income by the number of the
"gaonkars" enrolled in the same year, increased by one (Santo Antonio), after deducting from the
said net income the said 62$50.Chandor. - If has got 2400 shares. The dividend of each share will be
calculated by dividing the general dividend fixed in the annual accounts sheet by the said number of
the shares.Chinchinim. - It has got 6.500 shares. The dividend of each share will be calculated by
dividing the general dividend fixed in the annual accounts sheet by the said number of the
shares.Colva. - It has got 2600 shares. The dividend of each share will be calculated by dividing the
general dividend fixed in the annual accounts sheet by the said number of the shares.Curtorim. - It
has got 22,000 shares and it has got also members known as "gaonkars", zonnkars, "vadicares" and
"zonnkars-escrivães", with right to the personal zonn.The zonn of the "gaonkars", zonnkars and
"vadicares" is equivalent to all shares plus the quota of 52 shares of the general group of the
zonnkars.The zonn of the "zonnkars-escrivães" is equal to that of the others. However, from it, it is
deducted the quota corresponding to one zonn which is not paid to the zonnkars of this class.In view
of this, the first thing to do is to calculate the annual divisor in the following manner:Multiply the
number of the "gaonkars", zonnkars, "vadicares" and "zonnkars-escrivães" enrolled during the year
by 11; from the product, deduct 11 and also the quotient of the division of 52 by the number of the
said enrolled members and add to the remainder 22.900 shares. The sum will indicate the divisor of
the respective year.When this is done, the general dividend fixed in the annual accounts sheet willCode of Comunidades of 1961

be divided by the said divisor.The resulting quotient will be the dividend which pertains to each
share in the respective year.The gains of the zonns of the "gaonkars", zonnkars and "vadicares" will
be the product of the multiplication of the same quotient by 11, added by the quota corresponding to
the dividend of the 52 shares of the group of zonnkars. This quota will be calculated by dividing the
dividend of the 52 shares by the number of the enrolled "gaonkars", zonnkars, "vadicares" and
"zonnkars-escrivães".For calculating the gains pertaining to the zonns of the "zonnkars-escrivães",
gains of all the zonns; calculated in the above form, belonging to the enrolled "zonnkars-escrivães",
less one, will be summed up and this sum will be divided among all the enrolled
"zonnkars-escrivães", and the quotient will be the gains of the zonn pertaining to the
"zonnkars-escrivães".Davorlim. - It has got 2,900 shares. The dividend of each share will be
calculated by dividing the general dividend as calculated in the annual accounts sheet by the said
number of the shares.Deussua. - It has got 600 shares. The dividend of each share will be calculated
by dividing the general dividend as calculated in the annual accounts sheet by the said number of
the shares.Dicarpale. - It has got 1,800 shares. The dividend of each share will be calculated by
dividing the general dividend as fixed in the annual accounts sheet by the said number of the
shares.Duncolim. - It has got 2,300 shares. The dividend of each share will be calculated by dividing
the general dividend as fixed in the annual accounts sheet by the said number of the
shares.Dramapur. - It has got 3,400 shares. The dividend of each share will be calculated by dividing
the general dividend as fixed in the annual accounts sheet by the said number of the
shares.Gandaulim. - It has got 600 shares. The dividend of each share will be calculated by dividing
the general dividend as fixed in the annual accounts sheet by the said number of the shares.Gonsua.
- It has got 300 shares. The dividend of each share will be calculated by dividing the general
dividend as fixed in the annual accounts sheet by the said number of the shares.Guirdolim. - It has
got 7.700 shares. The dividend of each share will be calculated by dividing the general dividend as
fixed in the annual accounts sheet by the said number of the shares.Loutulim. -It has got 4.300
shares and also members known as "gaonkars" and zonnkars, with right to the personal zonn and
also "vantelos" with right to 4 zonns only.The zonn of the "gaonkars" and zonnkars is equivalent to
10 shares plus the quota of 238 shares of the general group of the zonnkars, except in the first year
when it falls due and then it is equal to one half.The 4 zonns of the "vantelos" are equal to those of
the "gaonkars" and zonnkars, but is paid fully even in the first year.In view of this, the first thing to
do is to calculate the annual division in the following manner:The number of the enrolled
"gaonkars" and zonnkars is to be multiplied by 10, considering in this calculation as half unit those
who have been enrolled to receive first time their gains; 40 shares to be applied to the 4
"zonnkars-escrivães", of "vantelos" plus 4300 shares will be added to the said product and the sum
will indicate the divisor of the respective year.When this is done, the general dividend fixed in the
annual accounts sheet will be divided by the said divisor.The quotient of this divisor will be the
dividend pertaining to each share in the respective year. The gains of the zonn of the "gaonkars",
zonnkars and of each of the 4 zonns of "vantelos" will be equal to the product of the same quotient
multiplied by 10, added by the quota corresponding to the dividend of 238 shares of the group of the
zonnkars. This quota will be calculated by dividing the total of the same dividend concerning 238
shares by the number of the "gaonkars" and zonnkars, enrolled during the year, to which the 4
"vantelos" who might have been enrolled will be added.The gains to be paid to the enrolled
"gaonkars" and zonnkars, when first time they fall due, will be equal to one half of those which
belong to others. This is to say that they will be equal to the product of the said quotient multipliedCode of Comunidades of 1961

by 5 plus the quota corresponding to the dividend of 238 shares of the group of zonnkars, which,
while it is being apportioned, will be taken as half unit.Macasana. - It has got 7700 shares. The
dividend of each share will be calculated by dividing the general dividend fixed in the annual
accounts sheet by the said number of shares.Majorda. - It has got 6200 shares. The dividend of each
share will be calculated by dividing the general dividend fixed in the annual accounts sheet by the
said number of shares.Margao. - It has got 29.300 shares. The dividend of each share will be
calculated by dividing the general dividend fixed in the annual accounts sheet by the said number of
shares.Nagoa. - It has got 5.600 shares and also members known as "gaonkars" and zonnkars with
right to the personal zonn.The zonn of the "gaonkars" and zonnkars is equivalent to 10 shares plus
the quota of 3 shares of the general group of the zonnkars.The "gaonkars", besides the said zonn,
receive mainly the net income of the properties listed below.In view of this, in the first place, the
annual divisor shall be calculated in the following manner:The number of the enrolled "gaonkars" is
to be multiplied by 10, plus 5600 shares shall be added to the said product and the sum will indicate
the divisor of the respective year.When this is done, the profits shall be divided by separating in the
first place, the net income of the aforesaid properties from the amount to be distributed or that of
the general dividend fixed in the annual accounts sheet, and the remaining shall be divided by the
said divisor in the manner laid down above.The quotient of this division will be the dividend
pertaining to each share in the respective year.The gains of the zonn of the "gaonkars" will be the
product of the said quotient and multiplied by 10, added by the quota corresponding to the dividend
of 3 shares of the general group of zonnkars. This quota will be calculated by dividing the total of the
same dividend of 3 shares by the number of "gaonkars" and zonnkars enrolled in the respective
year.The quota of net income of the aforesaid properties shall be added to the gains of the zonn of
"gaonkars". This quota shall be fixed by dividing that income, per head, among the enrolled
"gaonkars".Properties, the net income whereof is exclusively received by the gaonkars are:-
1st. Azolto
2nd. Gorbata of the carpenters
3rd. Tolloy and coconut grove of the shoemakers
4th. Onarbata
5th. Capoty and coconut grove of the blacksmith.
Orlim. - It has got 3100 shares. The dividend of each share shall be calculated by dividing the
general dividend fixed in the annual accounts sheet by the said number of shares.Raia. - It has got
5400 shares and also members known as "gaonkars", "gentios" grade 1, "gentios" grade 2 and
"vantelos" with right to personal zonn.The zonn of the "gaonkars" and of the zonnkars of the
remaining three chasses is equivalent to 28 shares plus the quota of 136 shares of the general group
of zonnkars.The "gaonkars" are subject to annual tax, named "navim", which consists of $10 per
head and the zonnkars of the other three classes to $05 per head. This tax shall constitute the
income of the comunidade and it shall be divided by the general number.In view of this, in the firstCode of Comunidades of 1961

place, the annual divisor shall be calculated in the following manner:-The number of the "gaonkars"
and zonnkars of the other three classes enrolled in the said year, is to be multiplied by 28, plus 5400
shares shall be added to the said product and the sum will indicate the divisor of the respective
year.When this is done, the amount to be distributed or the general dividend fixed in the annual
accounts sheet, shall be divided by the said divisor.The quotient of this divisor will be the dividend
pertaining to each share in the respective year and the gains of the personal zonn of the aforesaid
four classes will be the product of the said quotient multiplied by 28, added by the quota
corresponding to the dividend of 136 shares of the general group of zonnkars. This quota will be
calculated by dividing the same dividend of 136 shares by the number of "gaonkars" and zonnkars of
the other three classes enrolled in the respective year.After paying the gains, calculated in the
aforesaid manner, to "gaonkars" and other zonnkars the tax "navim" described above, shall be
computed.Sarzora. - It has got 3600 shares. The dividend of each share will be calculated by
dividing the general dividend fixed in the annual accounts sheet by the said number of
shares.Seraulim. - It has got 4400 shares. The dividend of each share will be calculated by dividing
the general dividend fixed in the annual accounts sheet by the said number of shares.Sernabatim. -
It has got 600 shares. The dividend of each share will be calculated by dividing the general dividend
fixed in the annual accounts sheet by the said number of shares.Sirlim. - It has got 1800 shares. The
dividend of each share will be calculated by dividing the general dividend fixed in the annual
accounts sheet by the said number of shares.Telaulim. - It has got 3400 shares. The dividend of each
share will be calculated by dividing the general dividend fixed in the annual accounts sheet by the
said number of shares.Utorda. - It has got 3700 shares. The dividend of each share will be calculated
by dividing the general dividend fixed in the annual accounts sheet by the said number of
shares.Vanelim: - It has got 400 shares. The dividend of each share will be calculated by dividing the
amount to be distributed i.e. the general dividend fixed in the annual accounts sheet by the said
number of shares.Varca. -It has got 8000 shares. The dividend of each share will be calculated by
dividing the general dividend fixed in the annual accounts sheet by the said number of shares.Velim.
- It has got 41,650 shares.Verna. - It has got 9200 shares and also members known as "gaonkares",
with right to personal zonn or "vangor parte".The "vangor parte" consists in invariable amount of
135$90. Besides the member, "gaonkars" receive on account of title of gain of "servidores", the net
income of the properties listed below and the dividends of 5 shares of the "servidores"
carpenters.So, the aforesaid amount of 135$90, of "vangor", and the net income of the properties
mentioned below shall be separated from the amount to be distributed or from the general dividend
that may be fixed in the annual accounts sheet and the remaining shall be divided by 9200 shares,
the quotient will be the dividend of each share.The amount of "vangor parte" and the income of the
aforesaid properties shall be added to the dividend of the said 5 shares of "servidores carpinteiros"
and the sum will be divided by 25 "vangores" of which at present, the comunidade is composed, the
quota of each "vangor" shall be sub-divided "per stirpes" by "gaonkars" enrolled in the respective
year, and the quotient will indicate the gains that as title of "vangor parte" and gain of the
"servidores" belong to the gaonkars. The following are the properties, the net income whereof, is
exclusively distributed among "gaonkars":-Code of Comunidades of 1961

1st. Coconut grove Chamarbata;
2nd. Field Chamarpato;
3rd. Field Namoxim of Carpinteiros of 2 varieties;
4th. Field Namoxim of Carpinteiros of one variety situated in the lagoon.
BardezAldona. - As regards to comunidade "Boa Esperança" it is regulated by the statutes approved
by Provincial Portaria No. 456 dated 5th May, 1925 and relating to the "Fraternal" comunidade by
the statutes approved by Provincial Portaria No. 559 dated 9th June, 1925.Anjuna. - The net income
shall belong to the zonnkars and share holders (Accionistas). The first ones, in case they are
brahmins, shall receive zonn after completing 12 years, and being of other classes, after 15 years. In
future the distribution shall be made in the following manner:-The figure 387, which is of old
"annas", shall be added to the number of zonnkars and the total will represent the divisor of the
excess amount and its quotient will be the gain of each zonn. Then, after deducting the amount of all
the gains from the excess amount, the remaining will be divided by new shares, the number whereof
is 2300.Arpora. - The net income will be divided by 400 shares.Assagao. - Divide one half of the
excess or surplus amount (Sobras) plus 568$00 of the other half by whole zonns and half zonns. The
zonnkars will receive the gains after they are 12 years old. Each one of the orphans will be given half
zonn, except in case where there is more than one brother, in which case the youngest one will be
entitled to the whole zonn.Assonora. - The distribution of the net income will be done by whole
zonns and half zonns, whole zonn to each member after 11 years; and half zonn to each orphan,
except in case where there is more than one brother because in this case the youngest brother will
receive whole zonn.Bastora. - The excess amount is divided by whole zonn and half zonns, whole
zonn to each member after 15 years; and half zonn to each orphan save in case where there are two
or more brothers, because in this case the youngest brother will be given the whole zonn.Calangute.
- The net income is distributed by 2600 shares.Camorlim. - The excess amount is divided by 1000
shares, save, however, the right of "gaonkars", having 12 years to distribute by zonns. The incomes
of the properties Lailasod Cason and Matos, after deducting the amount of 106$30 in favour of the
group of shareholder and that of expenditure of respective bunds and sluice-gates etc.Canca. - The
distribution of the net income will be made between the zonnkars and shareholders, taking by rule
that the zonn is equivalent to 20 shares. The number of shares is 100. The age for receiving the zonn
is of 14 years.Candolim. - Divide the excess amount or surplus by 2700 shares.Colvale. - The net
income is distributed by whole zonns and half zonns. The whole zonn is due to each "gaonkar"
having 15 years and to each "culacharin" having 18 years. Where the orphan is the only son or the
youngest among the brothers, he is entitled to whole zonn. Half zonn is given to each one of other
orphans.Corlim. - One of the nine properties (cuntos) situated in the village belong to the
comunidade and the other to various landlords, but they are subject to sharing the deficit of the
same association.The net income of the communal "cunto" is to be divided into 9 equal quotas, out
of which one is to be distributed by zonns to "gaonkars" having more than 35 years and the
remaining eight by 200 shares.Cunchelim. - Distribute the excess amount by 300 shares.Guirim. -
The net income is to be divided by whole zonns and half zonns; whole zonn to each member after 12Code of Comunidades of 1961

years and half zonn to each one of their orphans except when there are two or more brothers in
which case the youngest will recieve whole zonn.Mapusa. - Distribute the excess amount by whole
and half zonn; whole zonn to each "gaonkar" after 14 years and to "culacharins" after 17 years; and
half zonn to each one of their orphans, and where there is more than one brother, the youngest is
given whole zonn.Marna. - The net rent is divided by zonns to each member after having 14 years.
Before this age, zonn is also given exceptionally to the youngest of their orphan brothers.Marra. -
Distribute the excess amount by 100 shares.Moira. - The net income is divided by whole zonns and
its fractions. Each member will receive it after 17 years. Whole zonn will be given to "gaonkars",
three fourths to "calvacares" and half zonns to "culacharins". Before this age, the orphan is also
given whole zonn where he as the only son of the "gaonkar" or where he is the eldest among the
brothers.Each one of the orphans of any of the three groups receive half zonn.Nachinola. - The
excess amounts are distributed by whole zonns and half zonns; half zonn to each member "sudra",
whole zonn to each one of other classes after attaining 15 years. The orphans also receive zonns. The
eldest among the brothers will receive the amount that would be received by his father, and others
will receive half according to the quota of the respective group.Nadora. - The net rent is divided by
whole zonns and half zonns. The members receive half zonn after 12 years and whole zonn after 15
years. Before this, each one of the orphans receive half zonn, except where there is more than one
brother in which case the youngest is entitled to whole zonn.Nagoa:- The net income is to be divided
by 1200 shares.Nerul. - Distribute the excess amount by 4000 shares.Qlaulim. - The net rent is
divided by whole zonns and half zonns.The members will receive whole zonns after 11 years. Where
there are orphan brothers, each one will receive half zonn; but if he is alone, he is entitled to whole
zonn.Oxel. - The work will be distributed by the zonns and its eighths. Each member is entitled to
whole zonn after completing 12 years. In case any member dies leaving behind minor sons of that
age, then the youngest will also receive whole zonn. Otherwise his widow will receive one/eight of a
zonn.Paliem. - Divide the net income by 1600 shares.Parra. - The excess amounts are distributed by
zonns, half zonns and one eighth of zonn. Each member will receive half zonn after 12 years and
whole zonn after 18 years. Each orphan receives half zonn, except where there are two or more
brothers, on which hypothesis the youngest is entitled to whole zonn. Each widow having no son will
be given one eight of the zonn.Pilerne. - Divide the net income by whole zonns, half zonns, and
deducted zonns. After completing the age of 14 years, each "gaonkar" will receive whole zonn, and
each "culacharim" will recieve whole zonn, after deducting 1'30 in favour of the group of "gaonkars".
Each orphan will be given half zonn, except where there are two or more brothers, because in this
case the youngest will receive whole zonns.Pirna. - The excess amounts are distributed by zonns.
Each one of the members will receive it after 12 years, when any of the member dies leaving behind
minor sons of that age, the youngest one will be entitled to a zonn.Pomburpa. - The net income is
divided by 5300 shares.Punola. - The excess amounts are divided by whole zonns, and half zonns.
Each member is entitled to whole zonn, after completing 15 years. When any one of them dies
leaving behind minor sons of that age, the eldest one will receive whole zonn, and each one of the
others half zonn.Revora. - The net income is distributed by whole zonns, and half zonns. Each
member receives half zonn, after 15 years and whole zonn, after 18 years. Each one of the orphans
before attaining that age will receive half zonn; but where there are more than one brothers, the
youngest is entitled to whole zonn.Saligao. - The excess amount is distributed by whole zonns, and
others with deduction. "Gaonkars" will receive zonn after 12 years and "culacharins" after 15. The
latter ones will receive less $40 than the former one in the respective gains.Sangolda. - DistributeCode of Comunidades of 1961

the net rent by personal zonns, and shares of new kind, in the manner as follows. Annex the figure
3½ which is one of the old zonns, "fateusins", to the number of zonnkars the total of both is the
divisor and its quotient indicates the gains allotted to each personal zonns, after this deduct the
amount of gains all the personal zonns, from the said rent and the remaining divide by 100 new
shares.Serula. - There are shares, whole zonns, and half zonns, as also common properties and
exclusive properties of shareholders and of zonnkars. In future the distribution of the interest shall
be made as follows:-The whole net income of the field "areal" and one half of the net income of
"cantors" "portais" (sluice gates), kitchen gardens and hills will be divided by total number of new
shares, which are 5300. Similarly the excess amounts in-whole of the field "casana" and the other of
the excess amount of the aforesaid "cantors", sluice gates, kitchen gardens and hills will be
distributed by zonnkars and half zonnkars. The members who are brahmins having 11½ years will
receive whole zonn, and the members of other classes having 15½ years will receive whole zonns.
The half zonnkars will receive the respective gains after attaining 12½ years.Sircaim. - The net
income is divided by zonns, and each member will receive his zonn, after 12 years. When any one of
them dies leaving behind minor sons of that age, only the youngest will receive zonn.Siolim. -
Distribute the excess amount by 3000 shares.Tivim. - The net income is divided by whole zonns,
and half zonns. Whole zonn, is given to each member after attaining 12 years and half zonn, to each
orphan before that age, except where are more brothers in which case the youngest will receive
whole zonn.Ucassaim. - The excess amounts are distributed by whole zonn, and half zonn. Each
member will recieve whole zonn, after completing 15 years. The eldest of the orphan brothers will
receive whole zonn, and each one of the other half zonn, till they attain that age.Verla. - The net
income is to be divided by shares, whole zonns, and half zonns, according to the rule as follows:-
Annex the figure 5½, which is one of the old; zonns, "fateusins" to the number of personal zonns;
the total of both the numbers is the divisor of the said income, and its quotient indicates the gain of
each zonns. Then after deducting from the said income, the total amount of gains of the zonnkars
and half zonnkars, the remaining is distributed by shares of new kind, the number of which is 100.
Age to receive the zonn, is of 14 years. Each one of the orphans are entitled to half zonn, except the
youngest amongst the brother who will receive whole zonn.MormugaoArossim. - It has got 4400
shares. The dividend of each share will be found by dividing the dividend fixed in the annual
accounts sheet by that number of shares.Cansaulim. - It has got 1800 shares and also members
named "gaonkares"entitled to personal zonn.The zonn, of the "gaonkares" is equivalent to 12 shares
and plus the quota of 38 shares belonging to the group of zonnkars.In view of this, in the first place,
calculate the annual divisor in the manner as follows-Multiply the number of "gaonkares" enrolled
in the year by 12 add 1800 shares to the product and the total will indicate the divisor of the
respective year.When this is done, the amount to be distributed or the dividend fixed in the annual
accounts sheet will be divided by that divisor.The quotient of this divisor will be the dividend
pertaining to each share in the respective year, and the gains of the personal zonn, of "gaonkares"
will be the product of the said quotient multiplied by 12, added by the quota corresponding to the
dividend of 38 shares of the group of zonnkars. This quota will be calculated by dividing the same
dividend of 38 shares by the number of "gaonkars" enrolled in the respective year.Chicalim. - It has
got 200 shares and also members known as "gaonkar", with right to personal zonn.The zonn, is
equivalent to the quota of 15 shares of the group of zonnkars.In view of this, divide the general
dividend fixed in the annual accounts sheet by that number of shares and the quotient will indicate
the dividend pertaining to each share in the respective year.The dividend of the 15 shares of theCode of Comunidades of 1961

group of zonnkars, will be sub-divided per head among the "gaonkares" enrolled in the year and the
quotient will indicate the gain of the zonn, of the respective year.Chicolna. - It has got 200 shares
and also members known as "gaonkares" with right to personal zonn.The zonn of the "gaonkares" is
equivalent to the quota of 3 shares of the group zonnkars.In view of this, divide the general dividend
fixed in the annual accounts sheet by the said number of 200 shares and the quotient will indicate
the dividend pertaining to each share in the respective year.The dividend of shares of the group of
zonnkars will be sub-divided, per head, among the "gaonkares" enrolled in the respective
year.Cuelim. - It has got 4900 shares. The dividend of each share is calculated by dividing the
general dividend fixed in the annual accounts sheet by that number of shares.Cortalim. - It has got
3000 shares and also members known as "gaonkares" with right to personal zonn.The zonn of
"gaonkares" is equivalent to the quota of 543 shares.In this group 8 zonns belong to the
comunidade.In view of this, divide the general dividend, fixed in the annual accounts sheet, by the
number of the said 3000 shares and the quotient will indicate the dividend pertaining to each share
in the respective year.The dividend of the 543 shares of the group of zonnkars will be sub-divided
per head among the "gaonkares" enrolled in the year and by the 8 zonns of the comunidade, and the
quotient of this operation will indicate the gains of the zonn of the respective year.The gains of the 8
zonns of the comunidade shall constitute the income of the following year, for the general
number.Dabolim. - It has got 100 shares which represent the quota of its gross income.The dividend
or the loss of each share will be calculated by dividing the amount to be distributed or the general
dividend or deficit fixed in the annual accounts sheet, by that number of shares.Issorcim. - It has got
500 shares, which represent the quota of its gross income. The dividend or loss of each share will be
calculated by dividing the general dividend or deficit fixed in the annual accounts sheet, by that
number of shares.Mormugao. - It has got 1100 shares and also members known as "gaonkares" and
zonnkars with right to personal zonn.The zonn of the "gaonkares" and zonnkars is equivalent to one
share plus the quota of 8 shares belonging to the general group of zonnkars.In view of this, in the
first place calculate the annual divisor, as follows:-Add the number of "gaonkares" and "zonnkars"
enrolled in the year, add 1100 shares to the sum and the total will indicate the divisor of the
respective year.When this is done, divide the general dividend fixed in the annual accounts sheet by
that divisor.The quotient of this operation will be the dividend that, in the respective year pertains
to each share, and the gains of the personal "zonn" of "gaonkares" and "zonnkars" will be the said
quotient added by the corresponding quota of the dividend of 8 shares of the general group of
"zonnkar". This quota will be found by dividing the said dividend of 8 shares by the number of
"gaonkares" and "zonnkars" enrolled in the respective year.Pale. - It has got 1400 shares. The
dividend of each share is calculated by dividing the general dividend fixed in the annual accounts
sheet by that number of shares.Quelossim. - It has got 1200 shares, four fifths of the net income is
distributed by these shares.It also has members known as "gaonkares" with right to personal zonn,
among whom is distributed the remaining one fifth.Besides this the same "gaonkares" receive
exclusively the amount of 3$40 of the derrama annexed to the property named as "terreno
alegadico" (marshy land) plus the exclusive income of the field Bandcazana or Bandacamota, on
which besides the derrama of 28#40 in favour of the comunidade, weighs the onus in the amount of
3#40 towards the security of the field, construction and preservation of bunds, placing of doors to
the sluice gates, construction of dams of water reservoir and cleaning of the rivulet, and also the net
income of the aforesaid property "Bandcazana" is to be separated from the general dividend and the
remaining is to be divided into 5 parts; and the total of 4 parts is sub-divided by 1200 shares, theCode of Comunidades of 1961

quotient will indicate the dividend pertaining to each share in the respective year.Add the remaining
one fifth to the said 3$40 and plus the net income of the said property "Bandcazana" and the total is
divided by number of "gaonkares" enrolled in the year, the quotient will indicate the gain of each
zonn.Sancoale. - It has got 2100 shares. The dividend of each share is calculated by dividing the
general dividend fixed in the annual accounts sheet by that number of shares.Vaddem. - It has got
200 shares which represent a quota of its gross income.It also has members known as "gaonkars"
and zonnkars with right to personal zonn.The "zonn" of "gaonkares" and "zonnkars" is equivalent to
the quota of one share of the group of "zonnkars", as also the quota of one more share or title
"navim" of "gaonkares", when the latter ones or the "zonnkars" are at the same time shareholders.In
view of this, divide the amount to be distributed or that of the general dividend or deficit calculated
in the annual accounts sheet by the total number of 200 shares and the quotient will indicate the
dividend or deficit of each share.The dividend or deficit of each share of the group of zonnkars will
be sub-divided by number of "gaonkares" and "zonnkars" enrolled in the said year and that of one
share of the title "navim" of the "gaonkares" will be sub-divided by the number of "gaonkares" and
zonnkars enrolled and who are also the shareholders; the quotient of these operations will indicate
the gain or the loss corresponding to the zonn of each one in the respective year.Velcao. - It has got
200 shares. The dividend of each share will be calculated by dividing the general dividend fixed in
the annual accounts sheet by that number of shares.PondaMarcaim*. - It has got 15100 shares. It
shall be calculated by dividing the net income by the number of shares.Cundaim. - It has got 12200
shares. It shall be calculated by dividing the net income by the number of shares.Talaulim*. - It has
got 1400 shares. It shall be calculated by dividing the net income by the number of shares.Orgao*. -
It has got 600 shares. It shall be calculated by dividing the net income by number of shares.Tivrem*.
- It has got 1200 shares. It shall be calculated by dividing the net income by the number of shares.(*)
There are no zonnkars in these comunidades.(a)It is regulated by the Legislative Enactment No. 467
dated 23-3-1931.Model No. 9(Article 209, para 2)Register of Land
SurveyorPage......................Comunidade of ............................
No. and
name of
the plan
to which
the lot
belongsNo. of
the lot
and its
nameSituated
in the
wardSituated
in the
kajan of
field or
hillArea in
sq.
metresPerimeter
(m)Serial
number of
landmarksDistance
in
metresQuality
of the
platNature of
cultivation
          
Quality
and
quantity
of the
seedProductionLitre
(a)Gross
RentCultivationNet
IncomeImprovement
of which it is
susceptibleNatural
or
artificial
irrigationBoundaries Remarks
Escudos Escudos
Income
inherent
to the lotCode of Comunidades of 1961

          
Model No. 10(Article 212, para 2)(Register to record the objections on the Tombação (registration in
the village "cadastro") of the field of the comunidade of ....................
Sr. No. of the registrationsText of the
objectionsOrder
On............... of 19..... there being present land surveyor................ with me .........
clerk of the comunidade andwhilst carrying out the "tombação"(registration in
the village cadestre) of the lot No. ..........situated at ....... known as ........and
bounded on the north by......... on the south by ...... on the east by ....... on
thewest ......... there appeared ........... residing at.................. and he stated that he
is the owner of aprivate property named ....................... which bounds uponon
the west with the aforesaid lot, and declared that he opposesto the "tombacao" of
the latter one, in the manner asit has been done by alleging that it has included
in itsboundaries one portion of his said property having the length of.........
metres and width of ........ metre. He undertakes topresent in the office of the
administrator of the comunidades ofthis Taluka, within a period of 30 days from
this date, documentswherefore his objection can be decided administratively.
And thisstatement after being read to the above agreed persons, theyfound it in
accordance and they sign it.
................. (complainant)............ (land surveyor)......................... (clerk)Model No. 11(Article
548)The "Tombo 1" of the comunidade of ..........
Name and
No. of the
plan toNo. of
the lotDesignation
of the
property
and itsBoundaries
and
perimeterMeasurementDesignation
of the
commonKind
of
plotNature of
cultivationIncome
inherent
to the lotImprovements
of which the
lot isWhether
there isGross
IncomeExpenditure
with
production
andEscudos
Sl. No. of
the
landmarksDistance
in
metersNature Artificial   
                 
(Overleaf Model No. 11)
No. of the lot Onus Total  
Permanent
and
invariable
chargesAccidental
variable
charges
(foros) Due
to
Government
TreasurySalary of the
clerk of
ComunidadeCult   Percentage
to the
cashierRepairs of
sluice-gates
and bunds    Extraordinary
charges of
cultPermanent
ChargesAccidental
and
variable
chargesTotalNet
incomeValue of
the
propertyCost of
boundary
marksRemarks
as regards
to
properties
or lots
                    
Model No. 12(Section 551)Register 2 (Tombo 2)Enumeration of private properties that pay foro toCode of Comunidades of 1961

the comunidade and of invariable taxes due to it and of movement carried out therein
Sl.
No.Name of
the
property
and its
locationName and
residence
of the
possessorAmount of
foro and
taxes
inhererent
to itBoundariesReference
to the
number of
transfererDocuments
that have
been
presented
and
signatureof
the one
who
presents
themDate
of
issueReference to
subsequent
modificationForos and
remaining
taxes
          
Model No. 13(Article 263 and para. 1 of Article 533)In the year 19 ...... on ......, in the village of .......
and in the house of meetings of the Comunidade of the said village, there met the respective
Administrative Board, comprised of ......... president of ......... and ........ members ......... attorney and
of me ........, clerk of comunidade in order to proceed with the auction six yearly (or yearly) of the
fields and other items of the said Comunidade, for, today, is the date designated for such purpose by
the Administrator and advertised in ........ No. ........ of ......... and soon the aforesaid fields and items
were put up for auction as per order of its calculation and under the clauses mentioned therein, as
follows:-No. 1 - The field ........ bearing No. 1 of the calculation was awarded to ....... for the annual
rent of ....... who offered as his surety ............. of ........... and both sign this.Sd/- (Lease holder)Sd/-
(Surety)No. 2 - The field .......... bearing No. 2 of the calculation was awarded to ............. of ...........
for annual rent of .......... who guaranteed the bid with deposit of ........ equivalent to installment of
one year and signs this, and the aforesaid amount was credited to the coffer of which I give public
notice and I also sign this.Sd/- (Lease holder)Sd/- (Clerk )No. 3 - The fish item bearing No. 3 of
calculation was put up for auction and as there was no bidders it was reserved for fresh auction.No.
4 - The item of ........ bearing No. ......... of calculation was awarded to ........ of............ for the annual
price of ......... who offered as his surety ........ (one) of ....... as both do not know to sign, signs ...........
(name) of ........... at the request of the lease holder, and ...................... (name) at the request of the
surety, with the witnesses present ........... (name) and .......... (name) of ......Sd/- .............. on behalf of
the lease holderSd/- .............. on behalf of the suretySd/- .............. witnessSd/- .............. witnessAnd
as it was time for the closing and as the total auction has not been finished it was announced that
the auction would be continued tomorrow at .............. In evidence whereof this report has been
drawn up which after being read is going to be signed by the president and members of the board
agreed above, with me said clerk, who wrote it ......Sd/- .............. (president)Sd/- ..............
(member)Sd/- .............. (member)Sd/- ..............(attorney)Sd/- .............. (clerk)Model No. 14(Article
543)Registration of encroachment of the comunidade of ................
Sl.
No.Designation &
location of
the plot with
nameof the
occupantsBoundaries
marksForm of
the
boundary
marksMeasurement Fixed date
or probable
date of
usurpationKind of
plots and its
cultivationsEvaluation Amount of
taxes that
figure in
the names
of
theoccupants
byRemarksCode of Comunidades of 1961

gratuitous
title
Value
of
plotValue of
improvementRent
enjoyed
            
Prepared by us, Land Surveyor Grade II and clerk of the comunidade ..............DateSd/- ..............
(Land Surveyor)Sd/- .............. (Clerk)Model No. 15(Article 40 Para 3)Catalogue of shares of the
comunidade of ............ of ......... Taluka
Enumeration
of Titles of
the sharesShares
comprised
in each
titleEnumeration
of shares in
each titleName and
residence
of the
person in
whose
favourthe
shares
have been
issuedValue of
titles in
escudosReference
to the
auction of
transferReference
to the
annotation
of onusReference to
the
annotation
of
cancellationRemarks
1 10 One to ten ...Joao Vaz
of Aquem
of1200$00 Book fl. 4Book 2 fl.
14Book 4 fl. 51  
2 100Eleven to
one hundren
& ten.Pedro Dias
of Pale12000$00
3 60One hundred
and eleven to
one hundred
&seventyCaetano
Fernandes
of Orli7200$00
4 30One hundred
and seventy
one to two
hundredJoao Vaz
of Aquem1200$00
10 200 24000$00
This communidade has ...... (in words) shares comprised in ............. (in words titles of the total value
of .......... Office of the Administrator of the comunidades of ......... at Margao ....................... 19....The
administrator of the comunidades of ...............Model No. 16(Article 401)Salsete TalukaNo. 67Value
1,200.00Comunidade of CurtorimThis title of the value of 1.200$00, belongs to Manuel da Costa
............... of Verna and it comprises, of 10 shares bearing Nos. 238 to 247, of the value of 120$ each
one, of the comunidade of Curtorim, to which belong the dividend that may be distributed in each
year. This title is transferable by endorsement with annotation in accordance with articles .............
and............Margao, ..................... 19....The administrator of the comunidadesSd/-The President of
the BoardThe clerk of the comunidadeSd/-Model No. 17(Article No. 434)The above transfer has
been registered on this date, at fl ............... of the respective book No. .................Margao, ................Code of Comunidades of 1961

19....Administrator of the comunidadeSd/-The transfer registered on this date at fl... of the
respective book No. ........... belongs to ........... Margao, .............. 19....(Administrator of the
comunidade)Model No. 18(Articles 412 to 418)(In the hypothesis of article 412 and 413)On ... of ... of
19 ..., F... from ...presented to be annotated in his favour the title No. ... valued at ... $... having ...
shares of the comunidade of ... , who transferred F ... of ... , to whom I verified to belong. In view of
the appurtenant signed by the transferor in my presence and of the note of presentation,
competently signed, I made this annotation of transfer, put the annotation in the said title on this
date with reference to this page and returned it to the presenter. Stamp of ....$... has been
collected.Sd/-... (administrator)N.B. - On the first part it will be added, as per the case:On... of ... of
19 ... F ... by his through his attorney F ... of ... constituted by power of attorney drawn (or attested)
by the notary of this judicial division (or judicial division of ...) and filed by me under No. ...of
bundle No. ...On ... F .... of ... minor, through his father administrator, mother or tutor F ... of ...On
... on behalf of F ... of ... and with competent declaration of the latter, presented F ... of ... to be
registered in favour of the said F ...And on the second part changes shall be effected as per the
case:In front of ... the concerned who signed in my presence by F ... of ... at the request of the
transmittent, who do not (or cannot) sign, in presence of witnesses F ... and F ... and of the note of
presentation competently signed ...In the presence of ... the concerned who signed in my presence
by F ... attorney constituted by the transmittent by power of attorney ... and of the note of
presentation duly signed.In the presence of ... the concerned who signed by the transmittent in
presence of the notary of the judicial division of ... F... by whom the same has been attested and of
the note of presentation duly signedIn the presence of the concerned and of the declaration of the
transmittent with signatures attested by the notary.In front of the concerned signed by F ..., of ..., at
the request of the transmittent as the same do not know (or cannot) sign and by the witnesses
present F ... and F ... in the presence of the notary of the judicial division of F ... by whom has been
attested the same signatures, and of the declaration competently signed ...(It shall be declared
having been filed the powers of attorney, the declarations of transmittents and those of the
interested and the serial number in the respective bundle)(In the hypothesis of the article 414)On ...
of ... of 19 ... F. ... of ...presented to be annotated in his favour, the titles Nos. ..., each one of the value
of ...$ ... containing ... shares of the comunidade of ... ; the titles nos. ... of the value of ...$ ... each ,
containing ... shares of the said of ... ; the titles nos. ..., this of the value of 120$ and that of 1.200$,
containing ... shares of the said of ...; all of whom belonging to F ... of ... summing ...$ ... and, as
seem from (it shall be designated the document or documents produced, the origin of these, the
name of the employee who issued them) have been purchased by the said F.... in auction of ...having
been adjudged free and disengaged of earlier onus prior to auction by judgment of ... already made
final (or have been ordered to register in the name of the said F ... cancelling the onus earlier to the
auction). In view of the said document, having been cancelled firstly, on this date, at pg., ...of the
respective book (the one of annotations of onus) the onus that were burdening on the referred titles,
I made the present annotation of transmission, wrote down on it the concerning in favor of the said
F ... and the annotation, on this date, with reference to this page , and returned them, filing the
documents submitted under No. ... of bundle No. ........ (on the stamp and emoluments idem)Sd/-....
(Administrator)(In the hypothesis of the article 414)On ... of ... of 19 ... F. ... of ...presented to be
annotated in his favour, the titles nos. ..., each one of the value of ...$ ... containing all ... shares of
the comunidade of ... ; which as seen from ...(shall be designed which is the document produced, its
origin, name of the signatory, notary office, and more particulars that may concurs for betterCode of Comunidades of 1961

clarification), returned to the said F ... as the heir of his father F ... who was from ... and to whom
they belong as I verified. In view of the said document, I made this annotation of transmission,
wrote down on the above mentioned titles the concerning in favor of the presenter and the
annotation on this date, with reference to this, and returned the titles (the documents the originals
of which may exist in the notary offices or public offices, being filed the ones which may be in those
conditions. (on the stamp and emoluments idem)Sd/-.... (Administrator)(In the hypothesis of the
only § of article 418)On ... of ... of 19 ... F. ... of ...presented to be annotated in his favour, the titles
nos. ..., each one of the value of ...$ ... containing ... shares of the comunidade of ... ;issued (or
annotated) in the name of F ... his uncle (or whoever may be), who is from ..., and proving by ... (the
respective documents shall be cited) being he the sole heir of said F ..., not to exceed 1500$, the
value of shares, the being no complaint against his claim, announced in terms of law, and having
been paid the duty on the successions and donations by acknowledgement of "Fazenda" of ... no.... of
... (when due), applied that they may be annotated in his favour the said titles. And in the presence
of the said documents I made this annotation of transmission, wrote down on the said titles the
concerned in favour of the said F ... and the annotation on this date, with reference to this page and
returned them, filing, etc.Sd/-.... (Administrator)(In the hypothesis of sub-division of the titles and
its application between the heirs by deed, etc.)On ... of ... of 19 ..., F ..., of ........... presented the title
no. ... of the value of ...$ .............. containing ......... shares of the comunidade of .................., and
applied that two shares of that tile may be annotated in his name, issued issued (or annotated) in the
name of F ..., who was from ... applied to the presenter as one of his representatives, by public will
dated ... drawn by the notary public of the judicial division of ... F ...at pg. .. of book of notes no. ...
(conciliation, private paper) and for which duty has been paid by him on the successions and
donations, as has proved by the acknowledgement of the "Fazenda" of ... no. ... of ... now produced
along with the said deed. And in the presence of the said documents I made this annotation of
transmission and, dividing the said title, expedited two new, valued at 120$ each, corresponding to
first two tenths and constituted, respectively, by the shares nos. ... and ... , wrote down on them the
concerned in favour of the presenter and the annotation, on this date, with reference to this page
and gave them. Cancelled the primitive title (on the documents to be filed or to return, stamp,
emoluments, idem).Sd/-.... (Administrator)Model No. 19(Article 419 and 434)On (date) F ... of ...
presented the titles nos. ... each one of the value of ...$... containing ... shares of the comunidade of
... and nos. ... of the value of ... each containing shares of the comunidade of ... which all by virtue of
the deed , etc., (conciliation, paper, copies to the termos of pledge or of auction, etc.,), serve as
surety (or guarantee as pledge) the amount of ...$... which the presenter owes F ... of ...) at the
interest of ... And having verified to belong to the debtor (or to his surety)on the clauses stipulated
(shares belonging to the surety should declare "on the surety of F ... of ..."). And having verified to
belong to the debtor (or to his surety) the propriety of the same titles, fix on them the annotation of
guarantee (or pledge) in favour of the creditor, on this date with reference to this page and returned
them. (To file or return the documents as it should be)Sd/- (Administrator)N.B. In case of deposit of
dividends, its mention shall be made on the annotation, as well as of any earlier onus:On ... (date) F
...of ...presenting the titles nos. ... of the value of ...$... all containing ... shares of the comunidade of
... has applied to register in favour of ... of ... the onus of ... that the presenter is going to constitute
for the security of said obligation or of such capital at the interest rate of ... for the period of ... on
those conditions. On verifying to belong to the presenter, the propriety of these titles, I made on
them the annotation of guarantee in favour of the said F ...provisionally on this date with referenceCode of Comunidades of 1961

too this page and returned the same to them filing the petition under no. ... bundle no.Sd/-
(signature of the Administrator)On (date) here appeared F. ... clerk of the court of this judicial
division or any other competent fiscal or administrative employee) along with the respective bailiff,
F ... and presenting to me the competent order dated ... proceeded with my intervention for the
apprehension or pledge of such shares of the titles nos. of the value of ... $... of the comunidade ...
issued in the name of ...of ... of whom (or of his heir F. ...) of whom the executor F ...of ... wants to
receive the amount of ...$... burdening on such shares the onus of ... annotated in favour of at pg. ...
of book no.. ...(or to declare if they are free). In view of the document copy of which I received and
filed under no. ... of bundle no. ...made this annotation and have not annotated in the titles for the
same not having been given (or declare other thing, as per the case).N. B. - Having been made the
pledge by clerk or assistant of the same administration of comunidades, there is no intervention of
the administrator nor the need of the copy of the document or of the order.Sd/- (signature of the
Administrator)On (date) F.... of ... applied for the cancellation of the onus of ... annotated in the
titles nos. .. of the comunidade of ...titles nos. ... of the of ....showing by deed, etc. (or conciliation,
paper, copy of document or certificate of the proceeding, etc.) of being solved such obligation or
amount, as such I cancelled the respective annotation of ... of book ...no. ... and made the competent
annotation at the margin of the same marginal note, on this date, referred to this page.Sd/-
(signature of the Administrator)Model No. 20(Article 422)(In the hypothesis of section 422)This
and other ........... titles guarantee the principal amount of .......... at the rate of interest of ........ per
cent. per annum, in favour of ....... of ......... with consignment of its dividends to pay the aforesaid
interest, in terms of the annotation of fl. .......... of the respective book No. ............... Margao,
.............. 19.....Sd/- (Administrator of the comunidades)(In the hypothesis of para 7 of Article
424)Mortgaged by judicial mandate, "ut" annotation at fl........... of the respective book No. ............
Margao, .............. 19.......Sd/- (Administrator of the comunidades)(In the hypothesis of Article
427)The onus mentioned in the preceding annotation on this date at fl. ............. of the respective
book No. ......... is hereby cancelled.Margao, ............ 19.....Sd/- (Administrator of the
comunidades)Model No. 21(Article 440, No. 1 and para 2)Register of appointmentsJob
_________________________Name _______________________
Sl.
No.StatusPosts held with dates of
respective
appointmentsand
remunerationsPeriod during
which he has
been away from
serviceAwards and
punishmentsExtraordinary
CommissionsRemarks
       
Model No. 22(Article 440, No. 3 and para 2)Entry Book of the Office of Administrator of the
Comunidades
Part I – Register of entries of applications and official
documents
Number of
the EntryDateOriginal of the
application letter of
fileSubjectInterlocation order or
destination given to itFinal
decisionRemarksCode of Comunidades of 1961

of entry in
the officeof the
document
       
Part II – Letter of presentation of documents and titles of shares
for annotations
Sr.
No.Month Dates PresenterTitle of shares that
have been presented
andComunidades
that have issued themDocuments
PresentedKind of
annotationInitials of the
presenter and
of Transferor
11931
Jan3Jose
Ribeiro ofCarmona 6 shares,
titles 2-7Deed of
PartitionTransfer Initials
2  16Belarmino
Dias of
CanaPale 2 shares titles
120 & 121Public Deed
dated
18-12-1901Onus with
consignmentInitials
3  20Joao Vaz of
PaleAquem 1 shares titles
413 Transfer Initials
Model No. 23(Article 440, No. 12 and para 2)(Book for distribution and registration of execution
proceedings)
Part I – Class I
General
number of
this fileSerial
No. in
the
ClassDate of
distributionName of the
clerk dealing
with the fileName and
residence of
the debtorAmount
of debtName of
CreditorConditions
of the file
        
Note: For the remaining parts meant for the files of the 2nd and 3rd Class, the same Model shall
follow.Model No. 24(Article 464)Cash-Book of the comunidade of .................
Reference
to the
C/CEntryRespective
movement to
the
managementReference
to the
C/CIssuesRespective
movement to the
management
Annual Arrears Annual Arrears
1 2 3 4 5 6 7 8
 No. 1    No. 1   
 Balance existing in
the cash book on
1st March 19 ...
Asmentioned in the... 72$ 11 To the cashier ... to
pay the local tax to
the Office of
theAdministrator of  Code of Comunidades of 1961

balance sheet at fl...
and statement of
handingover at fl...
of this book,
seventy-two
escudos ...the Comunidades,
one hundred and
one 'escudos'and
thirty Centavos.
 On 25th March, 19
... after opening the
coffer received.   Sd/- Cashier 101$30  
2 No. 2    No. 2   
 From Francisco
Coutinho towards
the rent of the field
Beloremtaken on
lease by him one
thousand tow
hundred and
sixty-sixescudos.1,266$ 11 8To the clerk for
advance towards the
subscription
ofGovernment
Gazette of the
current year, one
hundred and
twentyescudos .....
Sd/- Clerk120$  
 And the sole
payment was
received after
closing thesafe.Sd/-
PresidentSd/-
CashierSd/- Clerk   And it was closed
after paying off the
amount of two
hundredand
twenty-one
"escudos" and thirty
"centavos"derived
from the above two
items.Sd/-
PresidentSd/-CashierSd/-
Clerk  
 On 28th of the said
month and year
after opening the
safereceived:   On 2nd July, 19 ....
after opening the
coffer paid:  
 No. 3    No. 3   
 From the attorney
towards the deficit
collected from
thecashier of ... five
hundred and
twenty-eight
"escudos"528$  8To the clerk towards
his salary thirty
"escudos"Sd/- Clerk30$  
      Code of Comunidades of 1961

And the safe was
closed after
receiving the
amount of
fivehundred and
twenty-eight
"escudos" derived
from theabove
items.Sd/-
PresidentSd/-
CashierSd/- ClerkAnd safe was closed
after paying the
amount of
thirty"escudos"
derived from the
above
item.Sd/-PresidentSd/-
CashierSd/- Clerk
 On 15th December,
19 ... after opening
the safe received:   On 4th September,
19 .... after opening
the safe paid:  
 No. 4    No. 4   
 From cashier ... on
account of his debt,
two hundred and
ten"escudos"210$   To Paulo Costa
towards the balance
in credit of the
accountsof ... two
hundred and forty
"escudos"240$00  
 And the safe was
closed after
receiving the
amount of
twohundred and
ten "escudos"
derived from the
aboveitem.Sd/-
PresidentSd/-
CashierSd/- Clerk   Paulo Costa   
     No 5   
    12To the cashier to pay
the local tax of sixty
escudos60$  
     And the safe was
closed after paying
the amount ofthree
hundred escudos
derived from the
above two
items.Sd/-PresidentSd/-
CashierSd/- Clerk  Code of Comunidades of 1961

     On 15th January 19
...., after opening the
safe,it was paid:  
     No. 6   
    6To Joao Lourenco
towards the balance
in credit of the
presentmanagement
four hundred and
eighty escudos480$  
     Joao Lourenco   
    9To the servant ...
towards the salary
of the year...
eighteen "escudos".18$00  
     Sd/- Servant   
     No. 8   
    7To the local board
towards the balance
in the credit of
thepresent
management, one
hundred and fifty
"escudos"150$00  
     Sd/- Secretary of the
Board.  
     And the safe was
closed after paying
the amount of
sixhundred and
forty eight "escudos"
derived from
theabove three
items.Sd/
PresidentSd/-
CashierSd/-Clerk  
     On 16th January, 19
...... after opening
the safe it waspaid:  
     No. 9   
    5 To Francisco Pereira
towards the balance  Code of Comunidades of 1961

in credit of
thepresent
management, thirty
"escudos"
     Francisco Pereira.   
     And the safe was
closed after making
this only
paymentamounting
to thirty
"escudos".Sd/
PresidentSd/-CashierSd/-
Clerk  
  1476$ 600$   989$30 240$
"Yearly Balance Sheet"
Total amount entered in the safe by the Management of thecurrent year
.......................................... 1476$00
Total amount entered by the management of the preceding years  600$002076$00
Total amount of issues from the safe by the management of thecurrent
year........................................................ 898$00
Total amount of issues by the management of the precedingyears
.......................................................... 240$00
Balance in thesafe...................................................  846$002076$00
Balance in the abovesafe..........................................  846$70
Deficit of the cashier in the year 19.... mentioned at the ofthe current
accounts............................................. 65$40750$00
Debits of the title holders of the current year. .........  1662$10
This amount belongs to the creditors mentioned in the following list:-
Creditors of the year 19...........     
1. No. ..................... Pedro Fernandes.......................  120$00   
2. No. ..................... Joao da Silva............................  30$00   
3. No. ..................... Door Keeper...........................  30$00   
4. No. ..................... Clerk.......................................   60$00 240$00
     
Creditors of the year 19...........     
1. No. 1 Pedro Fernandes........................................  1632$00   
2. No. 4 Joao Fernandes..........................................  255$00   
3. No. 9 Clerk.........................................................  90$00   
4. No. 12 Government Treasury.........................................  183$80   
5. No. 13 Office of the Administrator .......................  18$00   Code of Comunidades of 1961

6. No. 14 Comunidade............................................   450$00 2628$00
   2868$80
This account has been closed, whereof derives the balance in the safe of the amount of eight
hundred and forty six "escudos" and seventy "centavos".House of meetings of the Comunidade.
(date)
 Sd/- President Sd/- Cashier
 Sd/- Attorney Sd/- Clerk
Statement of handing overOn first March 19......, there being present the president and the other
members of the administrative ........, ........, ........., ........, and the key-keeper of the safe .... and ....,
with me ........., clerk, the safe was opened and after counting the cash existing therein it was verified
that the total amount of the balance amount to 846$70. This amount along with the keys was
handed over to the new key-keepers ...... And ...... who were present and to me said clerk. We
collected the amount received in the same safe and took possession of the keys. In evidence whereof
this statement is drawn up and signed by all the persons agreed above.Coffer of the comunidade on
....... (date)Sd/- President Sd/- Members Sd/- MembersSd/- Members-cum-CashierSd/-
Member-cum-Attorney Sd/- President of 19 .......Sd/- Member-cum-Cashier of 19 ...... Sd/- Clerk of
19 .......Model No. 25(Article - 470)Book of Income & Expenditure of the comunidade
of.......................Statement of Income & Expenditure of the comunidade of the year 19.......
Sr.Expenses Amount Sr.Expenses Amount
12 3 12 3
    “Invariable”  
1Indivisible balance of the year 19 ...
which has beentransferred to the
current year as mentioned at fl ..... of
thereturns and expenses book No. ....
ninety-three escudos.93$00 1Contribution for the cleaning of
church of this village,authorized
by order of the Governor
General, registered at fl..... of
the register No. ... one hundred
and fifty "escudos"150$00
2Amount set apart for works
mentioned at fl. .... of the saidbook,
six thousand seven hundred and
eighty nine "escudos"6789$00 2Salary of the clerk of the
Comunidade mentioned in the
table2-II of the said code, seven
hundred and twenty "escudos".720$00
3Remaining amount spent under item
No. ........ for books,twenty-seven
"escudos" "Invariable"27$00 3Salary of the servant of the
Comunidade authorized by
orderof the Governor General,
registered at fl. ... of the
registerNo. ..... Forty-eight
"escudos".48$00
 “Invariable”   “Variable”  
4Foro of the emphiteuses of the
Comunidade recorded in
therespective village enumeration at
fl ... of the book "tombo"2-one180$00 4Subscription of the Government
Gazette of the followingyear 19
.... one hundred and twenty
"escudos".120$00Code of Comunidades of 1961

hundred and eight "escudos".
 “Variable”     
5Income of the field of the
Comunidade leased in terms of fl....
of the book of agreement No. ... four
thousand eight hundred"escudos".480$00 5Contribution of local tax,
mentioned in the
circularregistered at fl. ....... of
the said register ......60$00
6Ditto of urban properties leased in
terms of fl. ... to fl.... of the said book,
three hundred "escudos".300$00 6Percentage of the cashier and
president authorized by
orderdated ..... ninety
"escudos".90$00
7Ditto of fish and other settlements
auctioned in terms of fl.... to fl. ... of
the said book seventy five "escudos".75$00 7Land tax and additional
municipal tax to be paidto the
Government Treasury (item No.
9 of the income) fivehundred
and ten "escudos"510$00
8Interest on the principal amount of
six thousand "escudos"given on loan
to .... through deed of ... dated ...
threehundred "escudos".300$00 8Cost of construction and
repairs, auctioned in terms No.
....of fl .... of the book of
agreement No. ... Sixty
"escudos".60$00
9Land tax and additional municipal
tax to be collected fromthe lease
holders of the field of Comunidade,
five hundred andten "escudos" ....510$00 9Net income 11315$00
  13074$00   13074$00
House of Meetings of the comunidade at .............., .............. 19......Sd/- Attorney. Sd/- Treasurer.
Sd/- Clerk.(Place for order of the administrator)SummaryNet income verified at folio approved by
the above order (or fixed, by the said order) .... 11.316$00Amount set apart by the said order for
extraordinary works of the comunidade ....... 4,200$00Dividend to be distributed among the
"zonnkars" and shareholders of the comunidade 7.159$00Indivisible balance that is carried over to
the following year of 19................................. 57$00 11.316$00As per the institution of the
comunidade, one fourth of the net income belongs to the "zonnkars" and the remaining three
fourths to the shares. In the current year there are 4 "zonnkars" enrolled at folio ....... of the book of
c/c No. ....... and the number of shares is 880, as it is soon from fl. ..... of the respective book No. ....,
so there falls to each "zonn" 444$80 and to each share 6$00, there remaining an indivisible balance
of 57$00, which is carried over to the following year.Date:Sd/- (Attorney) Sd/- (Cashier) Sd/-
(Clerk)Model No. 26(Article 479)Comparative map of the returns and expenses, net income or
"deficit" and debts of the comunidades of .................... Taluka for the year 19......... to 19.............
Sr. No. Comunidade Returns Expenses Net income Deficit Debts Remarks
19.... 19.... 19.... 19.... 19.... 19.... 19.... 19.... 19.... 19....
1. Aquem...... 5400$ 5358$ 4502$ 4800$ 798$ - - - ---
 Difference.. for less 198$ for more 198$ - - - - ---Code of Comunidades of 1961

2. Cavorim...... 40104$ 40200$ 14994$ 28050$ - - - - ---
 Difference.. for more 96$ 2940$ for less 240$ - - - ---
3. Verma...... 15960$ 16080$ 17520$ 17940$ - 35206$ 1560$ 1860$ ---
 Difference.. for more 120$ for more 420$ - 2844$ for more 300$ ---
N.B. :- The names of the villages shall be declared in alphabetical order.
(Date) (Signature)
Model No. 27(Article 484)Current accounts of the comunidade of ........... of the year 19 ......................
Sr. No. Designation To recoverTotal
guaranteed
incomeRemarks
and
annotationDesignationTo
oweIncome
paid in
the
debitRemarks
and
annotation
1 2 3 4 5 6 7 8 9
Title of the
"Zonnkar"
PedroFernandes
1.Gains of
personal zonn300$   Rent of the
field Artoem
No. ......320$   
 Dividends of
25 shares at
the rate of
60$ .....1500$   Rent of
urban
property No.
................600$   
     Granted to
Pauloda,
Costa No. 3
under bond
No. .....210$   
      1130$ 1130$  
     Balance in
favour .......670$   
  1800$ 1800$   1800$   
Title of the
"Zonnkar"
FranciscoCoutinho
2.Gains of
personal zonn300$ 2766$  Income of
the field
Betorim No.
.....2100$   
 Dividends of
20 shares at
the rate of1200$   Ditto of the
urban
property No.576$   Code of Comunidades of 1961

60$ ..... ...
 Paid under
statement No.
2 ......1266$   Foro of
emph. lease90$   
  2766$    2766$ 2766$  
Title of the
"Zonnkar" Paulo
daCosta
3.Gains of
personal zonn300$300$   Income of
the field
Betorim No.
.....990$   
 Dividends of
5 shares at
the rate of
60$210$   Foro of
emph. lease96$   
 Granted to
Pedro
Fernandes
under record
No...........810$       
 Balance
.............240$ 810$    810$  
  1086$    1086$   
Title of the
"Zonnkar"
JoaoFernandes
4.Gains of
personal zonn300$   Rent of fish
......75$  Pd. vide
record No.
9
 Dividends of
5 shares at
the rate of
60$60$    75$ 75$
 Premium of
auction of
construction
of dam of
lakes No. ......90$   Balance in
favour of ….315$  
  390$ 390$   390$  
Title of theCode of Comunidades of 1961

Shareholder
Francisco Pereira
5.Dividends of
5 shares at
the rate of
60$300$   Foro of
emph. lease305  Pd. Vide
record No.
10
     No. 6 under
record No.
......240$  
      270$ 270$
      30$  
  300$ 300$   300$   
Title of the
Shareholder Joao
Lourenco
6.Dividends of
4 shares at
the rate of
60$ ....240$       
 Granted to
Francisco
Pereira No. 5
under
recordedNo.
.......240$   Balance in
favour of480$   
  480$ 480$      
Title of the Fabrica
of the Church of
.......
7.Contribution
for the
clearing of the
Church No. 3
of
theexpenses
sheet .....150$ 150$  Balance in
favour of150$  Pd. vide
record No.
7
Title of the clerk of
the Comunidade
8. Salary of the
year 19... No.
4 of the
expenses120$   Received on
account of
his salary
under record30$   Code of Comunidades of 1961

sheet No. 3
 Subscription
of the
Government
Gazette of
thecurrent
year No. 6 of
the expenses
Sheet120$   Paid for
subscription
of the
Government
Gazette by
receivingfrom
the safe
under record
No. 2120$   
      150$ 150$  
     Balance in
favour of90$   
  240$ 240$   240$   
Title of the Servant
of Comunidade
9.Salary of the
year 19 ....,
No. 5 of the
Expense
Sheet485   Balance in
favour
...............48$  Pd vide
record No.
8
Title of the Office of
the Administrator
10.Taxes of the
year 19 .... No.
7 of the
expense sheet90$ 90$  Paid under
statement
register at fl
......... of the
registerNo.
.....72$ 72$  
18$
      90$   
Title of the
Comunidade
11.Remaining
indivisible
amount of the
current year
.....30$   Balance in
favour
..................450$   
 Amount set
apart for
constructions420$       Code of Comunidades of 1961

  450$ 450$      
 Grand Total  7524$    7524$  
Houses of meetings of the Comunidade of ..........................19 Sd/- ClerkBalance of Credit Amount of
The Current Accounts
Gains and dividends paid to the "Zonnkars" and
shareholders in their current accounts 4800$  Total of
the 2nd
column of
the left
hand
page of
this book 11,691$  
Total of the items of expenses fl ... of the book of
incomeand expenses No. ... which have been credited
to the currentaccounts 1335$      
Amount set apart in the said sheet for extraordinary
works 420$      
Remaining indivisible amount that is carried to the
followingyear 30$      
Amount of grants made in the current year, mentioned
at fl...of the book No. 450$      
Ditto of charges fl. .... of the book No. .......  2196$      
Payment made to the title holders in the coffer on
account oftheir debit under statements No. 2 and 4 of
the cashbook. 2460$      
  11,691$    11,691$  
House of meetings of the Comunidade of ............................ 19 .............
Sd/- Attorney Sd/- Clerk
Balance of Debit Amount of the Current Accounts
Total income of the Comunidade mentioned at fl.
..... of thebook No. ...... with deduction of the
balance credited of thepreceding year6531$  Total of the
2nd column of
the right hand
page of this
book8354$  
Amount of grants made by "Zonnkars" and
shareholdersmentioned at fl. ....... of the book No.
.......450$  Amount that
the title
holders owe
towards the
balance of
theircurrent
accounts.1086$  
Ditto of charges fl. .... of the book No. ..... 2136$  Ditto, in
possession of101$  Code of Comunidades of 1961

the cashier
withdrawn
from the
cofferunder
statement No.
4 of the
cashbook No.
.....
Cash withdrawn from the coffer of the Comunidade
for advancesof various payments in the year of the
management understatements Nos. 1 to 6 of the
cash book No. ....424$     
 9541$   9541$  
House of Meetings of the comunidade of ..................., .................... 19......
Sd/- Attorney Sd/- Clerk
Model No. 28(Article 518)Statement of creditOn ............ there appeared ........ member of this
Comunidade residing in ......... (by himself or through his attorney ........... constituted by power of
attorney that has been filed in the bundle No. .......) and stated that he authorised the transfer to the
title No. ............ of ............. of the credit amount of .............. that he has in the Comunidade, by
deducting it from his title No. ......In evidence whereof he signs this with me the clerk.Sd/-
(Clerk)Model No. 29(Section 520)Item of creditCredited by ............... of .............. No. ............ the
amount of .........$..... to the title No. ...... of........ by authorization filed in the bundle No. .......
Date: Sd/- Clerk
Sr. No.Name and
residence of the
shareholderShares
possessed on
19 ....AnnotationMovement
carried out on
19 ….
ModificationSerial No. of the
new inscriptionShares
possessed on
19 .....Annotations
1Pedro
Fernandes of
Nagoa25    20 
2Francisco
Coutinho of
Pale20For onus of ...
favour of .......Sold 5 7 20The
preceding
onus
continues
3Paulo de Costa
of Orlim5The dividend has
been consigned
in favour of .....  5Same as
above
4Joao Vaz of
Calangute1  Sold 8   
5 4  Transferred   Code of Comunidades of 1961

Jose Lourenco
of Cana9 &
10
6Francisco
Pereira of Verna5  Same as above 10   
 Total 60      
 Date: Sd/- Clerk       
Year:19 ........
7Jose Pereira of
Anjuna    5 
8Catao
Fernandes of
Cuelim    1 
9Cosme
Lourenco of
Varca    2 
10Miguel
Lourenco of
Varca    7 
      60 
 Date: Sd/- Clerk       
Form No. 31(Article 180)Record of auctionIn the year nineteen hundred and ..... on ......... at about
9.00 a.m. in this city (or town) of .......... and in the office of the Administrator of the Comunidades
of .... Taluka, there met the respective Administrator .............. (name), the members of the
administrative board of the Comunidade of ....., signed below, with me ..... (name) ....... Secretary of
the office of Administrator to, as per the edicts and notices published in terms of article 180 of the
Code of Comunidades, proceed with the auction of immovable properties of the said Comunidade of
......... the said Administrator, appointed ..... (name) as crier ordered to put up for sale by auction.
The lots or properties recorded in the book "Tombo I" first part, of the aforesaid Comunidade, by
order of the said Administrator and under clauses and encumbrances mentioned in the respective
records, what he, in fact, did, as follows:-No.1 - Lot No. ....... (shall mention the number of its
inscription in the "Tombo") situated at ......... named ............. bounded .......... it has an area of ........
and it measures ................... and the leaseholder of which is subject to the following encumbrances
......... it has been awarded in sale to ....... (name) residing in ......., for the price of ......... & ..........
which he undertook to pay in annual instalments of ..... &......each, by subjecting himself to
punishments imposed to him by the Code of Comunidades in force; he offered as his surety .......,
residing in ........, married, who being present to this act accepted the burden and presented the
document to show that he has consent from his wife for this purpose, and he guaranteed the bid of
the one to whom he stood as surety with .......... shares of the said Comunidade, annotated in the
name of ........... (name), with consent of the latter one, which he also proved with the document
presented by the said surety. And in evidence whereof this statement is drawn up which after being
read is going to be signed by the leaseholder and his surety.Sd/- .................... leaseholder Sd/-
................... suretyNo. 2 - Lot No .......... situated at .........., etc........., was put for sale by auction andCode of Comunidades of 1961

its auction was suspended, as in the same act ......... (name) resident of ........ presented a certificate
issued by the clerk .......... of the district court of this judicial division, where it has been declared
that the suit referred to in article 806 of the said code has been filed by the presenter.No. 3 - Lot No.
...... situated at .......... named ........ etc., was awarded, (etc).No. 4 - Lot No. ........., .......... and ........
were put up for sale by auction, and there were no bidders.And as it was time up for the closing, the
auction was concluded and it was announced that it would continue tomorrow at 9 a. m. And this
report was concluded, which after being read, is going to be signed by the Administrator, by the
members of the administrative board and by me. .................. (name) Secretary of the office of
Administrator, who wrote it.Sd/- ......... AdministratorSd/- ......... President of the boardSd/- .........
Member-cum-cashierSd/- ......... MemberSd/- .......... Member-cum-attorneySd/- ......... MemberSd/-
.... clerk of the ComunidadeSd/- Secretary of the office of AdministratorNote: By similar way on this
act, it shall be written to all others, whichever and particularly hypothesis that may be, given that all
the special circumstancesModel No. 32Comunidade of.................Shares issued 4300. Value of each
share inscribed in the "tombo" 180$00
Name of the
shareholderInterest on
each
shareholderGrant of
shares made
by the
shareholders
for
thepurchase
of various
lots or
propertiesCredits
No. &
quantity of
titlesTotal no. of
sharesValue in
EscudosNo. &
quantity
of titlesTotal
no. of
sharesValue
Jose Dias8 titles of
100
shares10
titles of 20
shares3
titlesof 1
share1003 180540$To lot
No.
2,200
sharesTo lot
No. 3,
100
sharesTo lot
No. 4,
37
sharesTo lot
No.
7,63
sharesTo lot
No.
75,80
shares     5 titles
of 100
shares3
titles of
1 share503 90540$
Pedro
Antonio
Jorge15 titles of
100
shares28
titles of 30
shares2340 421200$To lot
No.
5,739
sharesTo lot
No.
23,64
sharesTo lot
No.
68,600
sharesTo lot
No.
73,17
shares-      9 titles
of 100
shares1
title of
23 share
(a)923 166140$
Manuel
Vicente da
Costa7 titles of
100 shares1
title of 40
shares8900 162000$ - - - - -      7 titles
of 100
shares1
title of900 162000$Code of Comunidades of 1961

titles of20
shares40
shares8
titles
of20
shares
Rosario
Manuel
Correia5 titles of 10
shares7
titles of 1
share57 10260$To lot
No. 27,
57
shares- - -       None - -
(a)One of the titles of 30 shares would have to be reduced by 23 by means of an annotation.
17.
/25/85-RD. - In exercise of the powers conferred by clause 19 of Article 153 of the Legislative
Diploma No. 2070 dated 15-4-1961, the Administrator of Goa, Daman and Diu hereby makes the
following rules, namely:-
1. Short title and commencement. - (1) These rules may be called the Goa,
Daman and Diu Legislative Diploma No. 2070 dated 15-4-1961 Rules, 1985.
(2)It shall come into force at once.
1. Publication of Notes. - Notices of auction in respect of plots to be allotted
by means of auction shall be published in the Government Gazette and also
one in local daily newspaper in the local language and one daily newspaper
in English.
2. Maximum area to be allotted. - In respect of any application made after the
commencement of these rules, the maximum area that can be alloted to a
person shall be restricted to 400 sq. mts.
3. Eligibility. - (1) The applicant to be eligible for allotment of a land should
not own any residential accommodation or a build site within a radius of 8
kms. from the Comunidade from which he intends to take land on lease.
(2)An applicant to be eligible for grant of land on lease without auction shall not be a person whose
annual income from all sources exceeds Rs. 60,000/-.Code of Comunidades of 1961

4. Affidavit to be sworn by certain bidders. - An affidavit shall be furnished by
those bidders in auction who are not original applicants affirming that they
do not own any land/house within a radius of 8 kms. from the particular
Comunidade.
5. Records of Comunidades to be maintained in English. - All the records of
the Comunidades shall be maintained in English to the extent possible.
6. Periodical inspection to be carried by Administrator of Comunidades. -
Administrator of Comunidades shall carry out quarterly inspections for
detecting as well as preventing encroachment of Comunidade lands and they
shall furnish a report thereof to the Collector of the district for further
necessary action.
7. Administrator of Comunidades to complete formalities within six months. -
Administrator of Comunidades shall complete all the formalities in respect of
grant or allotment of Comunidades land either by auction or without auction
within a maximum period of six months from the date of receipt of the
application.
8. Allottee to take permission for conversion of land use. - The allotee shall
take permission for conservation of land use under the provision of the Goa,
Daman and Diu Land Revenue Code, 1968 whenever change of land use is
intended after allotment. Unauthorised change of land use will make the land
liable for reversion.
9. Allottee to construct building within four years. - The allottee shall utilise
the land granted by constructing the necessary building within a maximum
period of four years failing which the land shall be liable for reversion.
10. Allotted land not to be transferred. - No transfer of allotted land or
building erected thereon shall be made before the expiry of ten years. After
the period of 10 years, if the said land or such buildings are to be transferred
it shall be done only with the prior approval of the Administrator of
Comunidades. In the event of transfer, 10% of the appreciated value of the
land shall be deposited to the Comunidade.Code of Comunidades of 1961

11. Administrator of Comunidades to prepare layout, etc. - It shall be the
responsibility of the Administrator of Comunidades to prepare suitable
layout plans with adequate place for public amenities like -roads, parks,
water supply mains etc. in consultation and with the approval of competent
authorities before proceeding to allotment of plots.
12. List of vacant plots to be displayed every year. - Every year in the month
of January, list of vacant plots of each Comunidade indicating Survey
number and the location and all other relevant details shall be displayed on
the Notice Board of the Office of the Administrator of Comunidades as also
in the Official Gazette.
13. Administrator of Comunidades to obtain conversion and subdivision of
plots. - Administrators of Comunidades concerned shall obtain conversion
under the provisions of the Goa, Daman and Diu Land Revenue Code, 1968
from the concerned authorities and shall get the plot sub-divided in
accordance with the Law before recommending the case to the Government.
Concluding NoteTranslation of the Code of Comunidades of 1961I have been requested by the
Government of Goa to re-examine the translated text of the Code of Comunidades of 1961, in force
in Goa, submitted by Mr. Egipcio Noronha Rodrigues.Looking backwards, there were merely
Regulations called "Regulamentos". Significantly after the Code of Comunidade of 1904, there was
the Code of Comunidade of 1933 followed by the present Code. Therefore, the difference between
"Regulamento" and "Code" is required to be noticed.In the Indian system by and large any statutory
enactment is called as an "Act", while the subordinate legislation named as Regulations, by-laws,
etc.,. But it is not a case, the Indian legislation does not recognize a Code at all. There is Goa Land
Revenue Code of 1968 and in the same pattern there was the Bombay Land Revenue Code of 1879,
which is now replaced by the Maharashtra Land Revenue Code of 1966. Question is whether they
satisfy the requirements of the Code.Sufficient at this stage to keep in mind that Article 44 of the
Constitution of India speaks of a Code and not an Act.IImpact of Sole para of Article 5 of the Code of
Comunidades 1961Keeping aside for a moment the differences between a Code and an Act, the Code
of Comunidade of 1961, has a marked difference as compared to the 1904 and 1933 Codes, as has
been expressly mentioned by the legislature in the sole paragraph of Article 5, and explained in the
Preamble in part III of the Code of Comunidades of 1961, in the following words. They are extracted
below:Article 5"......With effect from the year 1962 the Comunidades shall cease to pay "foro" to the
"National Treasury"."Preamble............................................................................"Part III: Without
reference to formal alterations that have been numerous and have touched almost every article of
the old Code, we shall give a brief account of the modification with major impact introduced in the
new Code. The canon (Foros) which the Comunidades were paying the National Treasury have been
abolished. By doing so, the historical truth was restored, which was stressed by Cunha Rivara by
recognizing that the properties of the Comunidades belong to them, as a of their full ownership andCode of Comunidades of 1961

that the "foros" do not correspond to its bifurcation, one being dominium utile and the other
dominium directum, the latter of the state and former of the Comunidade."From the sole paragraph
and the preamble extracted above, one thing is clear that all time in the past it was considered by the
rulers that the comunidades were paying "foro" to the government in acknowledgement of their
sovereign rights; but in the Code of Comunidades of 1961, it was acknowledged that the
comunidades were full-fledged owners of both the interests and that there was no bifurcation of
property like, dominium directum and dominium utile.IIWhether to maintain the word
"Comunidades" in the translated text?At the forefront, I must record that I was confronted with the
translation of the very word "Comunidades". What does "Comunidades" mean? Is it a "community"
of the village at large? Late Advocate Rui Gomes Pereira, in his work "Gaunkari, The old village
association" called it "community", while Dr. Olivinho J. F. Gomes, in his research book prepared
under the aegis of Vassantrao Dempo Education and Research Foundation named "The Goan
Village Communes" called it "communes". But late Advocate Gomes Pereira, in his title of the book
was very cautious to put it as "The old village associations" as "Gaonkari". Even Chapter II of his
book has been titled as gaonkari or communities. If it was said "Village Community" it would
comprise not only "Gauncars" of village but of all other villagers, non-gauncars also. But if it is said
"gauncari", it would signify the association of gauncars only and not of all the villagers.Sebastião
Rodolfo Dalgado in his Luso-Asiatico Glossary publication by Asian Educational Services, Volume I,
p. 301 explains that "comunidade" is a Portuguese name, also adopted in konkani, which conveys an
"agricultural association" of each village of Goa, that possesses from olden times, properties in
common, income of which accrues in favour of its members. English people adopted the Portuguese
denomination with the word "village community". The Indian "comunidades" were in its origin a
type of communes, with all the ingredients necessary for its social life". It is therefore clear that it is
not a commune but a sort of commune.The same Article 1 of the Code, also uses the word
"gauncarias" as synonym of "comunidades". In this context, Dalgado at page 417 of the same volume
explains that "gauncaria" is association or meeting of "gauncars" of a village. From conc. "gaunkari",
sansc. "gramakarya" - administration of village community. The comunidades being equated with
"Gaunkaria", i.e. association."Gaunkars" are founders of the village. The definition of the same given
by Dalgado at Volume I page 416 is that "gaunkar" is the member of the village agricultural
association in Goa. From Konkani "gaunkar" from Sanskrit "grama" village and "kar" is owner.In
Black's Law Dictionary , 6th edition inter alia "commune" is defined as "a self governing town or
village, smallest administrative district of many European countries.", they are public bodies.
Therefore, they cannot be equated to an association of gaunkaris (comunidades) which are private
associations."Comunidade" differs from the Panchayat. In the case association of gauncars income
from the properties accrue to the "gaunkars" in proportion of their shareholding. But in the
Panchayat no ownership vests in the residents.The purpose of the long title of any Code while
indicating the object of the legislation in brief, plays a pivotal role. Here "gaunkar" and the
associations of "gaunkaris" play major role. I have therefore maintained the word of origin i.e.
comunidades.If in english terminology "village community" was adopted, it would have distorted
the main concept of Comunidade itself giving appearance of a public body, i.e. community at large,
though of village and not the ownership of gaunkars alone with the exclusion of any person besides
gaunkars.IIIWhat is the meaning of the term "Code"?John H. Tucker, Jr. in his foreword to the
Louisiana Civil Code says:"What is meant by the term "code" as we use it here is to designate an
analytical and logical statement of general principles of law to be applied by deduction to specificCode of Comunidades of 1961

cases and extended by analogy to cases where the aphorism "au-delà du code civil mais par le code
civil" (beyond the civil code but through the civil code) can be applied"Since in the meaning above
there is mention to analogy, Article 16 of the Portuguese Civil Code be also be noted. It reads:Article
16(Interpretation and integration of the law)"Where the questions relating to rights and obligations
cannot be resolved, either by the text law or by its spirit, nor even by analogous cases, envisaged in
any other laws, they shall be decided by following principles of natural law as per circumstances of
the case."The purpose behind the above article is that litigant should be afforded relief applying
even the principles of analogy if not by natural law. The common law or the Indian Law do not
accept the principle of analogy. Instances are there because the law does not provide, no relief is
granted to the litigants. This is the trend which was there as it is evident from the judgement of the
Supreme Court in the case of Vidya Vati v. State of Punjab (AIR 1968 SC 519 at 522), held as
follows:Relevant passage is quoted below:"A lacuna undoubtedly exists in the Act, but it is for the
legislature to rectify it and not for the courts to give a strained meaning to the words used by the
legislature which they do not bear"Later a principle was evolved of "ironing out the creases" to use
terminology of Lord Dening.In true sense the Code is your friend as explained by John H. Tucker,
Jr. in his said forward to the Louisiana Civil Court in following words:"Here in the latest edition of
the most important book in your library, the 'Civil Code of Louisiana'. It is your most important
book because it ushers you into society as a member of your parent's family and regulates your life
until you reach maturity. It then prescribes the rules for the establishment of your own family by
marriage and having children, and for the disposition of your estate when you die, either by law or
by testament subject to law.It tells how you can acquire, own, use and dispose of the property
generously or gratuitously.It provides the rules for most of the special contracts necessary for the
conduct of the nearly all of your relations with your fellowman: sales, loans (with or without
security), leases, usufructs and servitudes; and finally, all of the rights and obligations governing
your relations with your neighbor and fellowmen generally"Applying the above test, the present
Code of Communidade of 1961 qualifies to be said "Code"In the Article 1 of the Code of
Comunidades of 1961, the term "comunidades" is defined as "Gauncarias" existing in the district of
Goa and they are also governed by the private constitution of each of them. It is further laid down
that wherever the Code is silent general law shall apply.In Article 3 of the Code of Comunidades,
1961, the composition or the membership of the comunidades is explained. Article 5 of the Code of
Comunidades, 1961, speaks about the administrative tutelage.Article 6 of the Code of Comunidades,
1961, speaks of redemption of foro. Article 9 of the Code of Comunidades, 1961, prohibits the filing
of the civil suit without the previous sanction of the Administrative Tribunal or the Administrator as
the case may be. Article 10 of the Code of Comunidades, 1961, how the representation of the
comunidades is done. The powers of the members are set in Article 26 of the Code of Comunidades,
1961, whereas disability to contest or vote are laid down in Article 29 of the Code of Comunidades,
1961.Article 30 v, deals with the powers of the comunidades and Article 31 of the Code of
Comunidades, 1961, speaks about the tutelage over the action of the comunidades. Article 33 of the
Code of Comunidades, 1961, deals with the meetings of the comunidades. Article 39 of the Code of
Comunidades, 1961 deals with the meetings of the Managing Committee and powers of the
Managing Committee is set out in Article 64 of the Code of Comunidades, 1961. Therefore the
powers of the president, attorney and clerk are set out in Article 64 of the Code of Comunidades,
1961. In Article 87 of the Code of Comunidades, 1961, the status of the clerk is given stating that they
are subject to same discipline of the Public Offices. Article 91 of the Code of Comunidades, 1961Code of Comunidades of 1961

states that the certified copy issued have public faith. Article 99 of the Code of Comunidades, 1961
deals with Treasurers and 102 of the Code of Comunidades, 1961 deals with members of the safe.The
office of Administration stated in Article 116, 117 and 118 of the Code of Comunidades, 1961 and
their powers are mentioned in Article 125.The powers of the Governor are stated in Article 153
whereas powers of the Administrative Tribunal are stated in Article 154 of the Code of
Comunidades, 1961.There is no need to along the list. Exhaustive provisions have been made
including the preparation of budget and its approval, what books have to be maintained in the office
of Administration and as well as the Comunidades. Provisions for cadastral survey and
encroachment have been made in detail. Procedure to let out the properties of Comunidades have
been mentioned in detail. Grant of land by way of aforamento is permitted and recovery of debts by
way of execution proceedings is contemplated.In short, minutely, all the provisions to govern the
institution have been made out and therefore any institution which intends to have a knowledge to
operate an institution may very well adopt the same.IVWhat is the meaning of general law in Article
1 of the Code of Comunidade of 1961?Article 1 of the Code of Comunidades, lays down that in case
the code is silent, the provisions of the general law shall apply.Which is the general law? It depends
upon the subject to be dealt with. If it pertains to civil matter, it is the Civil Code. If it pertains to
procedural aspect, the Portuguese Civil Procedure Code would apply. It is a case of association or
society more particularly matter of issuance of shares, it is either the Civil Code or the Portuguese
Commercial Code of 1888. If it is an administrative matter, then it is Reforma Administrativa
Ultramarina (RAU) (Overseas Administrative Reform) and lastly if it is a service matter then it is
"Estatuto do Funcionalismo Ultramarineno (EFU), Overseas Civil Service Statute".VMethodology
adopted in doing the translationa) in formIt is required to explain the methodology adopted in the
matter of translation, First of all the Portuguese Legislature uses the expression "Of the Constitution
of Comunidades".The 1961 Code prefixes the word "of the" before each heading on caption of the
chapter of or its divisions. The same pattern is followed in the French Civil Code, Portuguese Civil
Code, Mexican Civil Code, Brazil Civil Code and for that matter Louisiana Civil Code which is one of
the 9 states of U.S.A. where the "civil law" is followed in contradistinction with the remaining states
of United States are known as the common law system.I have come across a translation of the
Mexican Civil and Commercial Code, done in English from Spanish language, that was undertaken
by lawyers named Abraham Eckstein and Enrique Zepada.The said Mexican lawyers, while
translating the Mexican Civil Code in Spanish language eliminated the word "of the" before the
heading of the Chapter.To familiarize the lawyers who are following the Common Law, for
convenience purpose adopted same matter and eliminated "of the" writing simply "Constitution of
the Comunidade".b) In substanceIn the matter of translation much care has to be taken. It is said
that the language is a very weak conveyor of thought. It is more acute in the case of translation.
There is a saying that the translator may be a "traitor" if proper meaning is not conveyed. In Italian
language translator means "tradutore" but he may become "traditore" meaning hereby traitor.In the
light of this I remember what the said two translators have said in the preface to the said translated
Code:"The English version constantly departs from the tempting path of transliteration in order to
adapt itself to the cognizable judicial language familiar to Anglo American jurists and parishioners,
without sacrificing fidelity and preciseness in meaning of the text drafted in its original form.
Though written in a different language, it carefully transposes into cultural and philosophical
symbols used by American practitioner."We came across few words which created difficulties in the
matter of translation:a) Servidão:The word "servidão" is used in Article 325(3) of the Code ofCode of Comunidades of 1961

Comunidades of 1961. There are two interests involving easement: dominant and servient. The
reason is that as per the Anglo Indian rules expression used is with reference to
dominant/beneficiary, (active interest), whereas in Latin origin the concept used is with reference to
(passive interest).Definition of "servitude" may be seen in the Black's law Dictionary, 6th edition as:
"servitude: The state of the person who is subjected, voluntarily or otherwise, to another person as
his servant. A charge or burden resting upon one estate for the benefit or advantage of another; a
species of incorporeal right derived from the civil law (see Servitus) and closely corresponding to the
"easement" of the common law, except that "servitude" rather has relation to the burden or the
estate burdened, while "easement" refers to the benefit or advantage or the estate to which it
accrues."I therefore used the word "easement" instead of servitude.b) Hypothecation:There was also
a difficulty in translation of the word 'hypothecation' which is found in Article 279 of the Code of
Communidade.The word 'hypothecation' is found in the Portuguese Civil Code in Article 888 i.e.
creation of security in moveable or immoveable. However, there is no corresponding equivalent
either in the Indian Contract Act, 1872, nor in the Transfer of Property Act, 1882. There is a
reference to the guarantee by of 'Charge' in Section 100 of the Transfer of Property Act, 1882, but
that speaks of immovable property and not moveable property. Hypothecation under Indian Law
however, is only of moveable property but without statutory recognition.In this context, reference
may be made to the Judgement of the High Court of Andhra Pradesh in the case of State Bank of
India v. S. B. Shah Ali (died) & Ors., reported in AIR 1995 AP 134, wherein it is said at para 18 and
19 that 'hypothecation' is not a statutory creation but is a usage in mercantile field times
immemorial, and according to that the possession is never with the creditor but with the debtor.As
per Article 888 of the Civil Code guarantee could be created in favour of the creditor as regards the
property, moveable or immoveable, without parting with the possession. In the absence of such a
provision, since the purpose was of offering security, the same was translated as 'mortgage' with the
clear understanding that 'hypothecation' is not recognized in the Indian Law.It may be noted that
reference to the word 'hypothecation' in the Indian Law is found only in the Securitisation and
Reconstruction of Financial Assets and Enforcement of Security Interest Act, 2002, under Section
2(n). However, the term 'hypothecation' therein is qualified by the words - "as a security for
financial assistance and includes floating charge and crystallization of such charge into fixed charge
on moveable property". The legislation would, therefore, come into play only when there is a case of
financial assistance.Wharton's Law Lexicon, 15th Edition, speaks of 'hypothecation' as a 'pledge'
wherein the possession is retained. However, in case of a pledge it is implicit that the possession is
with the creditor.Therefore, hypothecation under Portuguese law has been translated as
"mortgage".c) UsufructThe word 'usufruct' is foreseen in the Civil Code under Article 2197 onwards.
However, there is no reference in the Indian Law to usufruct as a guarantee. Therefore, there is no
equivalent to usufruct as a guarantee as it appears in the Civil Code.Reference to usufruct is found in
the chapter of mortgage while dealing with usufructuary mortgage.d) ArrendamentoUnder
Portuguese Civil Code sale, gift, hypothecation, arrendamento, renting (locatio) were contracts.
Therefore renting was known as "arrendar". Under Indian law though basic foundation of Transfer
of Property is a contract, yet the reason best known to the framer of the law, leases, mortgagees have
been brought under the umbrella of the Transfer of Property Act, 1882 without any valid reason.One
could understand that in a case of gift or sale there is a conveyance, but it would not be correct to say
that in the case of mortgage or lease there is a conveyance. If the translation of chapter V starting
from 317 of the Code of Comunidade, 1961, as renting it would have been difficult to explain theCode of Comunidades of 1961

position. Therefore for convenience it has been translated as "lease".Reference to the concept of
arrendamento is made in the Portuguese Civil Code in Article 1595 which reads thus:Article
1595"There is a contract of locatio (renting), when anyone hands over to another, for a certain
period and against specific rent, the use and enjoyment of certain things."Reference may also be
made to Article 1596 of Portuguese Civil Code which reads thus:Article 1596"The locatio is said to be
arrendamento (renting), where it pertains to immovable property, if it is related to movable, it is
called hire."The "contract of locatio" is nothing but arrendamento of immovable property.Definition
of "locatio" may be seen in Wharton's Law Lexicon, 15th edition which reads thus:"Locatio: hire, a
letting out"Following this techniques we had to make many adjustments for e.g. there is a chapter
dealing with "renting the paddy fields and giving on rent for a long period (Article 317 of the Code of
Comunidade) and normal renting see for lease period in Article 291 of the Code of Comunidade,
1961, onwards for a period of three years.For convenience purpose, I adopted the word "lease"
whereas lease being part of the Transfer of Property Act, creates interest in the property whereas
under Portuguese Code it was a matter of contract and does not create any interest in the land.The
translator of earlier compilation had translated the heading of chapter V starting from Article 317 of
the Code of Comunidade as of "long term leases", whereas for chapter VI starting from article 324 of
the Code of Comunidade (aforamento) translated as permanent leases.e) AforamentoThere is
chapter with heading "Dos aforamento ou enfiteuses" , whereas there is prior Chapter VI starting
from Article 324 of the Code of Comunidade where as there is another chapter V called "Dos
arrendamentos a longo prazo" starting from article 317 of the Code of Comunidade. If I translate
article 324 of the Code of Comunidade, I would have said "aforamento" "In Portuguese term, but
using English terminology it would be "emphytheusis". Earlier chapter V starting from Article 317 of
the Code of Comunidade as contract of "arrendamento" (renting for a long period). But the long
period is restricted to 18 years as per paragraph 1 of article 317 of the Code of Comunidades,
1961.The concept of emphyteusis is explained in Wharton's Law Lexicon, 15th edition which reads
thus:"Emphyteusis, the jus emphyteuticarium, or as it is more generally called, emphyteusis, was
right of enjoying all fruits, and disposing at pleasure of the property of another, subject to the
payment of a yearly rent (pension or canon) to the owner."It was perpetual and even non payment of
foro could not entail eviction as said in article 1671 of the Code. Much to the contrary the right of
grantor would be only to recover the foro not more than five years in default. But in case of rental
non payment of rent would entail eviction. These are therefore two completely diametrical opposite
concepts which the translator of earlier time compilation brought it under one regime and it was a
difficult task to convince the judge on the face of the government translation.Grant of "aforamento"
was the power of the government as stated in article 153 clause 9 of the Code of Comunidade which
has been translated as follows:Article 153 (9)"To grant letting by leases (aforamento), to authorize
the exchange of lands of comunidades and determine its reversion."The translator deserves
compliments because he used "aforamento" which would save the case of the party.Reference may
be made to Article 1653 of Portuguese Civil Code which deals with Aforamento which reads as
follows:Article 1653"There is contract of "emprazamento", "aforamento" and "enfiteusis", when the
owner of any property transfers its dominium utile to another person, the latter undertaking to pay
him certain specific pension which is called "foro" or "canon".Dr. Luis da Cunha Gonçalves, in his
Treatise on the Civil Code Vol. IX page. 211, commenting on "emphyteusis", writes:"1301. Origin and
historic evolution of the contract of "emprazamento" or "enfitêuse" - The contract of
"emprazamento", "aforamento" or "enfitêuse" is one of the oldest form of contract which theCode of Comunidades of 1961

European law created; and so widely spread and entered into to give effect to, that the majority of
modern legislations adopted it and there are quite a few jurists who have not dealt with the same.
Three different names were given to such contract by the old jurists and the legislature adopted
them in Article 1653; but only the word "emphyteusis" is the classical term of the universal use;
whereas the word "emprazamento" is less justified, even though in Portugal it has been used for
quite a long time since the Ordinances, book iv, title 37, designate as "prazos" the emphyteutic
property. Originally, "emprazamento" was meaning any contract or reciprocal "prazo", however,
from the 14th century, the same word started having the meaning of "emphyteusis" .The word
"emphyteusis" is of Greek origin and means "plantation" or simply "cultivation". It shows that this
contract came to us from old Greece. From the time of Republics and Kingdom of Esparta and
Lacedemonia, this name was given to concessions (grants), which the public domain was making to
the private persons of the uncultivated lands, which the State could not cultivate directly and the
citizens could not acquire by purchase. Therefore, because the contract of renting was not
sufficiently encouraging, and would not give any security nor compensate for the works put in by
agriculturists, who were subject to eviction exactly when that land was started to give produce, the
State was demanding a small annual installment, and such concessions (grants) were perpetual or
for long period and had for one of the condition of exploring the land and bringing it under
cultivation. The installment which the concessionaire was paying was in cash or kind and was called
"canon" - denomination even subsisting; this installment was not clearly equivalent to the value of
the land, but was affirmation of the domain of the grantor, even though the grantee has full
enjoyment of the land and could transmit the same to his heirs with same juridical obligations. This
institution was born principally on account of lack of cultivators and lack of incentive to the few who
were knowing the art of cultivation.In the old Rome, similar economic and social necessities had
raised an identical juridical institution, but in classical Roman law this institution was not
designated in the same name; the old jurists were mentioning it as "locação perpetual (si qua res in
perpetuum locata sit, quod evenit in praediis municipum) and they were granted as agri vectigales
or municipal land, or also the land of the Emperor or latifundists (large estate holders)."To
understand the mechanism in English law it is profitable to extract a passage from Black's Law
Dictionary, 6th edition:"Feudal law. The mode or system of holding lands or tenement in
subordination to some superior which in feudal ages, was the leading characteristics of real
property. Tenure is a direct result of feudalism, which is separated the dominium directum (the
dominion of soil) which is placed, mediately or immediately in the crown, from the dominium utile
(the possessory title) the right to use and profit in the soil designated by term "Seisin" which is the
highest interest of a subject an acquired."VIDistinction between "arrendamento" and "aforamento"
at glancea. "Arrendamento" is a transaction between the landlord and the tenant while "aforamento"
is a transaction between the owner and a stranger.b. "Arrendamento" is for a certain period (Article
1595 of the Portuguese Civil Code and Section 105 of the Transfer of Property Act, 1882) whereas
"aforamento" is perpetual.c. In case of "Arrendamento" rent which is payable by the tenant to the
landlord is as per the agreement between the parties whereas, in "aforamento", foro is a sum of
amount fixed by grantor which is payable by the grantee to the grantor in recognition of the superior
rights of the grantor.d. In case of "aforamento", after passage of 20 years the foro is may be
redeemed by payment of 20 years of installments and one more additional installment if levable and
with such payment both the interest, dominium directum merge into dominium utile and the
contract of emphyteusis comes to an end and the grantee becomes fullfledged owner.e.Code of Comunidades of 1961

"Arrendamento" can be terminated; "aforamento" cannot be terminated even on account of non
payment of foro. The right of the grantor is only to recover the foro of last 5 years.f. In case of
"aforamento" the grantee is entitled to gift, mortgage the property, the transferee being subject to
payment of foro.Before concluding, I must record that I could complete my task due to tireless
efforts and valuable assistance given by co-translator, Mr. Egipcio Noronha Rodrigues.Notifications
13.
-1-94-RD. - In pursuance of clause (ix) of Article 334-A of the Legislative Diploma No. 2070 dated
15-4-1961, read with section 21 of the General Clauses Act, 1897 (Central Act 10 of 1897), the
Government of Goa hereby amends the Notification No. 13/1/94-RD dated 9-6-1995, published in
the Official Gazette, Series I, No. 14 dated 6-7-1995 (hereinafter called the 'said Notification'), as
follows:-In para 1 of the said Notification after the expression "sportsmen of Goan origin of the State
of Goa", the words "who are landless and" shall be inserted.
17.
/99/96-RD. - In pursuance of clause (ix) Article 334-A of the Legislative Diploma No. 2070 dated
15-4-1961, the Government of Goa hereby notifies the following category for the purposes of said
Article 334-A of the said Legislative Diploma No. 2070 dated 15-4-1961:-"The landless employees of
the High Court of Judicature at Bombay, Goa Bench, Panaji, who were employees of the erstwhile
Court of the Judicial Commissioner, Panaji".Code of Comunidades of 1961

