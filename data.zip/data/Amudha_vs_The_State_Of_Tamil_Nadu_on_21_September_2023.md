Amudha vs The State Of Tamil Nadu on 21 September, 2023
Author: M.Sundar
Bench: M.Sundar
    2023:MHC:4402
                                                                                      H.C.P.No.1526 of 2023
                                     IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                                       DATED : 21.09.2023
                                                                CORAM
                                       THE HONOURABLE MR.JUSTICE M.SUNDAR
                                                      and
                                      THE HONOURABLE MR.JUSTICE R.SAKTHIVEL
                                                     H.C.P.No.1526 of 2023
                     Amudha                                              .. Petitioner /
                                                                            mother of the detenu
                                                                 Vs
                     1.           The State of Tamil Nadu
                                  Rep. by its Additional Chief Secretary to Government,
                                  Home, Prohibition and Excise Department
                                  Chennai-600 009.
                     2.           The Commissioner of Police
                                  Avadi City
                                  Office of the Commissioner of Police
                                  Avadi, Chennai – 600 054
                     3.           The Superintendent of Police
                                  Central Prison
                                  Puzhal, Chennai – 600 066
                     4.           The Inspector of Police
                                  T3, Korattur Police Station
                                  Chennai – 600 050                             .. Respondents
                                  Petition filed under Article 226 of the Constitution of India praying
                     Page Nos.1/10Amudha vs The State Of Tamil Nadu on 21 September, 2023

https://www.mhc.tn.gov.in/judis
                                                                                      H.C.P.No.1526 of 2023
                     for issuance of a writ of habeas corpus calling upon the production of the
                     records relating to the detention order dated 29.12.2022 made in detention
                     order Memo No.196/BCDFGISSSV/2022 passed by the 2nd respondent
                     herein and quash the same and direct the respondents to produce the body or
                     person of detenu Dinesh, son of Ramesh, male, Hindu, aged 23 years,
                     branded as Goonda and now confined in Central Prison, Puzhal, Chenani
                     before this Court and set him at liberty forthwtih.
                                  For Petitioner            :     Mr.K.S.Harish
                                                                  for Mr.M.Dhivakar
                                  For Respondents           :     Mr.E.Raj Thilak
                                                                  Additional Public Prosecutor
                                                             ORDER
[Order of the Court was made by M.SUNDAR, J.,] When the captioned 'Habeas Corpus Petition'
(hereinafter 'HCP' for the sake of convenience and clarity) was listed in the Admission Board on
10.08.2023, the following order was made:
M.SUNDAR, J.
and R.SAKTHIVEL, J.
(Order of the Court was made by M.SUNDAR, J.,) Captioned Habeas Corpus Petition
has been filed in this Court on 31.07.2023 inter alia assailing a 'detention order dated
29.12.2022 bearing reference No.196/BCDFGISSSV/2022' [hereinafter 'impugned
preventive https://www.mhc.tn.gov.in/judis detention order' for the sake of
convenience, clarity and brevity] made by 'second respondent' [hereinafter 'Detaining
Authority' for the sake of convenience]. To be noted, fourth respondent is the
Sponsoring Authority.
2. To be noted, mother of the detenu is the petitioner.
3. Mr.K.S.Harish, learned counsel representing the counsel on record for petitioner
submits that ground case qua the detenu is for alleged offences under Sections 341,
294(b), 323, 336, 427, 397, 506(ii) of 'the Indian Penal Code, 1860 (Act 45 of 1860)'
[hereinafter 'IPC' for the sake of brevity] in Crime No.626 of 2022 on the file of T-3
Korattur Police Station.
4. The aforementioned impugned preventive detention order has been made on the
premise that the detenu is a 'Goonda' under Section 2(f) of 'The Tamil Nadu
Prevention of Dangerous Activities of Bootleggers, Cyber law offenders,
Drug-offenders, Forest-offenders, Goondas, Immoral traffic offenders,Amudha vs The State Of Tamil Nadu on 21 September, 2023

Sand-offenders, Sexual-offenders, Slum-grabbers and Video Pirates Act, 1982 (Tamil
Nadu Act No.14 of 1982)' [hereinafter 'Act 14 of 1982' for the sake of convenience and
clarity].
5. The impugned preventive detention order has been assailed inter alia on the
ground that family members were not informed about the detention of the detenu.
6. Prima facie case made out for admission. Admit. Issue
https://www.mhc.tn.gov.in/judis Rule nisi returnable by four weeks.
7. Mr.A.Gokulakrishnan, learned Additional Public Prosecutor, State of Tamil Nadu
accepts notice for all respondents. List the captioned Habeas Corpus Petition
accordingly.'
2. The aforementioned Admission Board order captures all essentials that are
imperative for appreciating this order and therefore, we are not setting out the same
again. However, short forms, short references and abbreviations used in the
Admission Board order will continue to be used in the instant order also for the sake
of brevity, convenience and clarity.
3. Mr.K.S.Harish, learned counsel on record for petitioner and Mr.E.Raj Thilak,
learned Additional Public Prosecutor for all the respondents are before us.
4. As would be evident from paragraph 5 of aforementioned Admission Board order,
in the captioned HCP, at the time of admission, learned counsel for petitioner posited
his challenge to the impugned preventive detention order on the ground that family
members were not https://www.mhc.tn.gov.in/judis informed about the detention of
the detenu but in the final hearing Board, learned counsel changed his line of attack
qua his campaign against the impugned preventive detention order and submitted
that subjective satisfaction arrived at by the Detaining Authority as regards imminent
possibility of detenu being enlarged on bail is clearly impaired. Elaborating on this
submission, learned counsel drew our attention to a portion of paragraph 4 of the
grounds of impugned preventive detention order, which reads as follows:
'4........ In a similar case registered at under section 294(b), 341, 323, 397, 336, 427
and 506(ii) of IPC, in J-4 Kotturpuram Police Station Crime No.43/2018, the bail was
granted by the Court of Principal Sessions Judge at Chennai in
Crl.M.P.No.1759/2018. Hence, I infer there is a real possibility of his coming out on
bail in T-3 Korattur Police Station Cr.ime No.626/2022 case by filing bail application
before the appropriate court, since in a similar case, the bail was granted by the court
after a lapse of time.....'
5.Thereafter, learned counsel placed before us the grounds booklet as served on the
detenu and drew our attention to page Nos.283 to 289 thereatAmudha vs The State Of Tamil Nadu on 21 September, 2023

https://www.mhc.tn.gov.in/judis which contain Aravind case bail order (similar
case) made in English by the learned Sessions Judge and what according to the
Detaining Authority is Tamil translation version of the same i.e., Aravind case bail
order. A perusal of the bail order in English and the Tamil translated version brings
to light that the bail order in English refers to pending cases against the petitioner
with specificity as regards calendar years in paragraph (6) but in the Tamil
translation, the same is missing.
6.Learned Prosecutor in response to the above argument submitted that only
mentioning of the calender years of pending cases with specificity is missing, the
same is clerical error but otherwise the translation is largely correct.
7.We carefully considered the rival submissions. We are of the view that it is not
merely a case of improper translation but it is also a case of giving orders with
different contents in English and Tamil version. This means that detenu's right to
make an effective representation against the impugned preventive detention order
gets impaired.
https://www.mhc.tn.gov.in/judis
8. We also remind ourselves of Powanammal case i.e., Powanammal Vs. State of Tamil Nadu,
wherein Hon'ble Supreme Court addressed to itself this translation point in a similar fact situation.
The question which the Hon'ble Supreme Court addressed to itself is captured in paragraph 6 and
the manner in which a Hon'ble Bench of the Supreme Court answered this question is captured in
paragraph 16. To be noted, Powanammal case is reported in (1999) 2 SCC 413 and paragraphs 6 and
16 {as in SCC journal} read as follows:
'6.The short question that falls for our consideration is whether failure to supply the
Tamil version of the order of remand passed in English, a language not known to the
detenue, would vitiate her further detention.
16. For the above reasons, in our view, the non-
supply of the Tamil version of the English document, on the facts and in the circumstances, renders
her continued detention illegal. We, therefore, direct that the detenue be set free forthwith unless
she is required to be detained in any other case. The appeal is accordingly allowed. '
https://www.mhc.tn.gov.in/judis
9. Therefore, this is a case of improper translation as well as providing documents with different
contents in two different languages impairing the detenu's right to make an effective representation.
The net sequitur is, the impugned preventive detention order is vitiated and the same deserves to be
dislodged.Amudha vs The State Of Tamil Nadu on 21 September, 2023

10. Before concluding, we also remind ourselves that preventive detention is not a punishment and
HCP is a high prerogative writ.
11. Ergo, the sequitur is, captioned HCP is allowed. Impugned preventive detention order dated
29.12.2022 bearing reference No.196/BCDFGISSSV/2022 made by the second respondent is set
aside and the detenu Thiru.Dinesh, male, aged 23 years, son of Thiru.Ramesh, is directed to be set at
liberty forthwith, if not required in connection with any other case / cases. There shall be no order
as to costs.
                                                                     (M.S.,J.)         (R.S.V.,J.)
                                                                            21.09.2023
                     Index : Yes
                     Speaking order
                     Neutral Citation : Yes
                     gpa
P.S: Registry to forthwith communicate this order to Jail authorities in Central Prison, Puzhal,
Chennai.
https://www.mhc.tn.gov.in/judis To
1. The Additional Chief Secretary to Government, Home, Prohibition and Excise Department
Chennai-600 009.
2. The Commissioner of Police Avadi City Office of the Commissioner of Police Avadi, Chennai –
600 054
3. The Superintendent of Police Central Prison Puzhal, Chennai – 600 066
4. The Inspector of Police T3, Korattur Police Station Chennai – 600 050
5. The Public Prosecutor, High Court, Madras.
https://www.mhc.tn.gov.in/judis M.SUNDAR, J., and R.SAKTHIVEL, J., gpa 21.09.2023
https://www.mhc.tn.gov.in/judisAmudha vs The State Of Tamil Nadu on 21 September, 2023

