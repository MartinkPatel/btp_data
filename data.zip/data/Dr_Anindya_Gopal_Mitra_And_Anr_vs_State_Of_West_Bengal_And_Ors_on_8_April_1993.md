Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And
Ors. on 8 April, 1993
Equivalent citations: 1993CRILJ2096
ORDER
Shyamal Kumar Sen, J.
1. In this writ petition the petitioners have challenged the order dated 31st March, 1993, issued by
the Commissioner of Police, Calcutta, "whereby the Commissioner regretted that permission cannot
be accorded to the petitioners for holding a public meeting at Brigade Parade Ground on 11th April,
1993 by relaxing the prohibitory orders under Section 144 Cr. P.C. now in force in Calcutta.
2. It is the contention of the writ petitioner that the members of the petitioner No. 2 Bharatiya
Janata Party are all citizens of India. The Constitution of the petitioner No. 2 admits all Indian
Citizens in its fold irrespective of their caste, religion and any bias if they subscribe to the common
ideals of the party.
3. The said Bharatiya Janata Party is a political party recognised by the Election Commission of
India in terms of its orders under the Representation of the People Act, 1951 and have been given
reserved symbols for its candidates contesting assembly and parliament elections throughout the
country.
4. It has also been contended that the petitioner No. 2 as the political party and organisation
contested successive State and Parliament Elections and its 150 candidates were elected to the
House of the People of the Parliament in the General Elections in 1991 and it has been recognised as
the largest opposition Political Party in the Lok Sabha and the leader of the members elected to the
Lok Sabha has been recognised and granted constitutional recognition as the leader of the
opposition in the Parliament with status equivalent to that of Central Minister of the Government of
India.
5. It is also the contention of the petitioners that the petitioner No. 2-Bharatiya Janata Party has a
large number of followers in the State of West Bengal and the total percentage of votes polled by it in
the last Parliamentary General Election was about 12 per cent.
6. It has been contended that in City of Calcutta public meetings as well various other meetings
convened by different political parties were and still are permitted to be held in the Brigade Parade
Ground which is centrally located and also can accommodate a large number of person. The policeDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

authorities in the past also have permitted and allowed various political parties for holding such
public meetings in the said Brigrade Parade Ground.
7. The petitioner No. 2 have decided to hold its National Executive Council Meeting at the City of
Calcutta in between 10th April to 12th April, 1993 and entrusted the West Bengal State Committee
with the responsibility of organising the said meetings. It has also been decided by the petitioner No.
2 organisation that Bharatiya Janata Party would hold on this occasion, a public meeting at Brigade
Parade Ground Calcutta on April, 11, 1993. The petitioner No. 1 being the Secretary on behalf of the
petitioner No. 2 being the said party applied accordingly to the Commissioner of Police Calcutta on
March 1, 1993 for usual permissions under the Police Act and Calcutta Police Act, 1898 and all other
Act in force. The representations of the petitioner No. 2 also met the Calcutta Police authorities, the
Home Secretary and the Chief Secretary to the Government of West Bengal on different dates, after
filing of the said application, with the purpose of expediting the said permission for making
necessary arrangements in advance for the said meeting. Neither any permission to hold the said
meeting nor the permission prayed for was rejected.
8. It has been alleged in the writ petition that the appointment thereafter was sought for with the
Chief Minister of West Bengal and the representatives of the petitioner No. 2 met the Chief Minister
at his office at Writers' Buildings, Calcutta on March 11, 1993 and requested to direct the respondent
authorities to consider and dispose of the said application and grant permission to the party to hold
the public meeting on April, 11, 1993 at Calcutta Brigade Parade Ground. It has been alleged that
during such discussion with the Chief Minister the representatives of the parties were informed by
the Chief Minister that he would on return from New Delhi on March 17, 1993, take necessary
measures for appropriate actions in this matter and would inform the petitioner No. 2 organisation
accordingly. The gist of the discussion held at the meeting with the Chief Minister was reported in
all newspapers. It has further been alleged that the Minister for Information and Cultural Affairs
Department, announced before the Press on March 11, 1993 that the State Government would not
allow the Bharatiya Janata Party to hold the meeting in the City and this declaration has been
reported in all the daily's edition of all daily newspapers of the City in their daily edition on March
12, 1993.
9. It has also been alleged in the writ petition that an announcement was made in the West Bengal
Legislative Assembly on March 16, 1993, that the State Government would not allow the Bharatiya
Janata Party to hold its meeting in the City and the declaration has been reported in the following
day's edition of all daily newspapers of the City on March 17, 1993 including "The Statesman".
10. It has been contended that the Commissioner of Police is the authority under the statute to
consider and dispose of the application for permission.
11. Petitioner in the writ petition filed before this Court further alleged that the statutory powers of
granting such permission upon consideration of the said application under relevant provisions of
the Police Act (Act V of 1961) and the Calcutta Police Act, 1866 (Act IV of 1866) and all other Act and
statutory orders or notifications in force, rests with the Commissioner of Police Calcutta and he has
not applied his mind by not admitting the said application nor by rejecting it and communicating hisDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

decision to the petitioners till date. The respondent authorities are bound and liable to act in
accordance with the law and cannot disregard their statutory responsibility and instead abdicate
their statutory powers and the responsibility by accepting any decisions made up for them or trust
upon them by others. The respondent authorities have therefore failed to discharge their duties and
obligations in this regard.
12. Petitioner met at 5.15 p.m. on March 18, 1993 the Chief Minister in accordance with the previous
arrangement and the Chief Minister stated what the Information and Cultural Affairs Minister
announced 3 days' earlier that the Government would not permit holding of any public meeting by
the petitioner party in Calcutta.
13. The State Government have in the meantime announced through press the decision of holding
the Panchayat Elections in the State and elections in a large number of Municipalities of this State
and Bye-election in 2 State Assembly constituencies including Chowringhee Assembly Constituency.
The Secretary Panchayat Department, Government of West Bengal, has issued a notification No.
756/1/panch/1E-6/93 dated the 10th March, 1993 setting on the process of the said Panchayat
Election throughout the State with a time-table of the said Election fixed to be held on 30th May,
1993. The Secretary, Municipal Affairs Department has also issued a notification No. 97(25)/C-4/
MIE-7/93 dated the 17th March, 1993 fixing the schedule of elections in 13 Municipalities of the
State fixed to be held on 10th May, 1993.
14. It is the contention of the petitioner that the petitioner No. 2 have decided to participate in the
Panchayat, the Municipal Elections and Assembly bye-elections have taken upon a programme of
public campaign and public meetings in support of its election programmes and the candidates
through out the State and the concerned municipalities. It has also been decided to inaugurate the
said election campaign by holding a public meeting at Brigade Parade Ground on the 14th April,
1993 at 2 P.M. to be addressed by Shri Lal Krishna Advani, M. P. and leader of the opposition in the
Lok Sabha and by Shri Sikandar Bhakt, M. P. and leader of the opposition at Rajya Sabha.
15. On March 19, 1993, another application was made to the Commissioner of Police, Calcutta, with
copies endorsed to the respondent No. 2 the Secretary to the Government of West Bengal, Home
Department and respondent No. 3 the Chief Secretary to the Government of West Bengal, seeking
permission under relevant provision of the Police Act, the Calcutta Police Act and other statutory
orders or notifications in force, for holding the said public meeting at Brigade Parade Ground,
Calcutta on and for using microphone at the said meeting. In the said application for permission, the
Commissioner of Police was requested to grant his permission within 72 hours in order to enable the
petitioner No. 2 to go ahead for making all preparations including publicity for the said meeting. It
has been alleged that in spite of personal meeting, reminders and calls given over telephone, the
respondent authorities have not respondent with any reply.
16. A writ application was moved on 26th March, 1993, since no action was taken by the
Commissioner of Police, Calcutta whereupon an order was passed by me on 26th March, 1993, inter
alia, to the following effect:Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

The Court: By consent of the parties the matter is treated as on the day's list as
Motion (New) and is disposed of in the manner following:
Let the Commissioner of Police consider the application made by the petitioner on
19-3-1993 and dispose of the same by passing a reasoned order in accordance with
law and communicate the same to the petitioner by 31st March, 1993. The writ
petition at this stage need not be proceeded against the respondents Nos. 7 and 8.
No affidavit-in-opposition has been filed. The allegations made in the petition are not
admitted. There shall be no order as to costs.
17. On March 31, 1993 at about 6 p.m. the petitioner No. 1 received a communication signed by the
Commissioner of Police, Calcutta, on the same date whereby the Commissioner of Police expressed
his regret to accord permission for holding a public meeting at the Brigade Parade Ground on 11th
April, 1993 by relaxing the prohibitory orders under Section 144 Cr. P.C. The reason given for such
refusal as appears from paragraph 2 of the said letter is set out herebelow:
2. In view of the fragile communal balance and tense law and order situation, now
prevailing in Calcutta and its suburbs, the holding of a public meeting by BJP at this
Juncture, will be prejudicial to the maintenance of Communal harmony and public
order, peace and tranquillity.<
18. It has been alleged that the petitioners have not been given any opportunity of hearing
personally by the Commissioner of Police.
19. The petitioners being aggrieved by the said order again moved another writ petition challenging
the said validity of the said order on 31st March, 1993. The said writ application was moved on 1st
April, 1993 when the following order was passed :
The Court : Let this matter be taken up tomorrow, on the prayer of Government
Pleader. The Commissioner of Police, Calcutta is directed to disclose before this
Court on what basis he has come to the conclusion that there is fragile communal
balance and tense law and order situation now prevailing in Calcutta and its suburbs
and holding of public meeting by B. J.P. will be prejudicial to the maintenance of
communal harmony and public order, peace and tranquillity. Let all records which
the Commissioner of Police considered in arriving at his decision will be produced in
Court tomorrow.
The Commissioner of Police and all parties to act on a signed copy of the minutes of
this order on usual undertaking.
20. It has been mentioned in the writ petition that the Constitution of Bharatiya Janata Party
nowhere provides that it is intended for any particular community. It has further been alleged that
the petitioner has several members belonging to various communities including Hindu, Muslim,Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

Christian, Parsi, Jain and Sikh. It has also been alleged that it is never the object of the Bharatiya
Janata Party to espouse the cause of a particular community. It has further been alleged that the
order of 31st March, 1993, refusing to grant the permission only smacks of a premeditated mind on
the part of the State of West Bengal and the Police Authorities and they have purported to pass the
said order in a mechanical manner without any application of mind and also in a discriminating
manner.
21. The said order according to the petitioner is discriminatory as a meeting was permitted to be
held at Shahid Minar by Ganatantrik Mahila Samiti -- a wing of CPI(M).
22. It is the contention of the petitioner that under the Election Rules of the country any party has a
right to hold the meetings for the purpose of Election and, therefore, by refusing to accord
permission the respondent authority has acted in an arbitrary manner and contrary to the relevant
Acts and Rules.
23. It has been contended by Mr. Kapur, learned advocate for the petitioner that the order passed by
the Commissioner refusing to accord permission to hold meeting contains mere mechanical recitals
and/or a virtual reproduction of the language of Section 144 Cr. P.C. According to him, the Court
should take judicial notice that law and order situation in Calcutta from 9th February, 1993 has not
been bad in any way. There is no evidence of any riot or any aflamed incident in any locality of
Calcutta which can be said to be a disturbance of public peace or breach of peace, danger of human
life or property. It has also been submitted that the Commissioner promulgated the order dated 8th
February, 1993 which was published in Calcutta Police Gazette dated 9th February, 1993 being
prohibitory order under Section 144 Cr. P.C. for prevention of disturbance of public peace and
breach of peace and/ or danger to human life or property. There is no complaint in the said order or
any data or warrant for the conclusion that the order was promulgated to restrict any action by the
BJP. The said order, was passed more than a month before the instant application was made to the
Commissioner for permission to hold a meeting. It has been submitted that no nexus exists or can
be shown to exist between the said order and the application of the BJP to hold the meeting. It has
also been submitted that admittedly, the purpose for which the meeting is sought to be held is a
lawful purpose, to with the inauguration of an election campaign. Nobody can deny that the party
has a right in law to participate in the election. The petitioner party is not a banned party. The
petitioner party by its constitution professes allegiance to the Constitution of India and its members.
The petitioner party is recognised by the Election Commission and its right to participate in the
election cannot be denied.
24. It was further been submitted that there is total non-application of mind by the Commissioner.
The Commissioner has been unable to give particulars, even a single instance in West Bengal which
would suggest that the petitioner party was guilty of inflaming communal tension or adversely
affecting the law and order situation. Some vague references were made to incidents outside West
Bengal in course of argument. Those matters, it is submitted, are extraneous and irrelevant for the
question at hand, which is concerned with the Commissioner's duty to permit holding of a meeting
in West Bengal. The Commissioner cannot express any concern with matters transpiring in other
States or elsewhere in India. His concern can only be the holding of the meeting at Brigade ParadeDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

Ground. It has further been submitted that the order passed by the Commissioner suffers from total
non-application of mind.
25. It has also been submitted that the Commissioner has referred to secret reports clandestine
propaganda, possibility of a "holocaust" and other "facts" and if such factors are examined it will be
found that all of them are "hypothecal and imaginary considerations", and vague, indefinite and
problematic apprehensions.
26. An affidavit has been affirmed by Dr. Anindya Gopal Mitra on 6th April, 1993, being the
supplementary affidavit. In the said supplementary affidavit filed pursuant to the leave of the Court
the order issued under Section 144 of the Criminal Procedure Code, 1973 by the Commissioner of
Police and published in the official Gazette on 9th February, 1993, has been challenged.
27. It has been alleged in the said supplementary affidavit that the said purported order dated 9th
February, 1993, had nothing to do with the petitioner party or its members and was not warranted
by their conduct or cause by any acts or deeds related to the petitioner party or its members.
28. It has been submitted that the said order is ex facie a blanket order passed in circumstances not
concerning the petitioner party.
29. It has also been submitted that the power under Section 144 can be exercised only "in an
emergency" or "in an extraordinary situation". No such emergency has been shown to be existing.
30. It has further been submitted that the reasons shown by the Commissioner are all bad and there
is no factual basis for the same. Nothing to show that the petitioner party or its members were
responsible for any communal tension or law and order situation in the State. No material and the
reasons given by the Commissioner are based on irrelevant and extraneous consideration.
31. It has also been submitted that no ground exists justifying that the mere holding of an election
meeting would lead to communal violence.
32. It has been stated in the said affidavit that there is no question of destruction of any place of
worship in Calcutta by members of the petitioner party and all allegations in this behalf are
pretentious, sham and misleading.
33. It has further been alleged that the said order under Section 144 is being used in a
discriminatory manner against the petitioner party. Other parties have been allowed to hold the
meeting.
34. It has also been submitted that the Commissioner has failed to take into account the fact that the
purported order dated 9th February, 1993, is bound to expire before 11th April, 1993 and therefore
cannot be relevant or material factor.
35. It has been submitted in the said affidavit that the said order being bad has to be struck down.Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

36. Mr. Kapoor, learned Advocate for the petitioners has submitted that fundamental rights of the
petitioners have been infringed by such refusal to accord permission to hold the meeting by the
Commissioner of Police, Calcutta. It has also been contended that right to hold meeting, right to
assemble and right to move and peaceably (sic) fundamental rights estimated in our Constitution.
37. He referred to Article 19(1)(a)(b) & (e) of the Constitution. He also referred to Article 19(2),
Constitution of India and submitted that enjoyment of such fundamental rights, however, may be
curtailed on the basis of reasonable restriction that may be imposed on the basis of any existing law
now in operation or by enacting any law in the interest of sovereignty, security of State etc. as
provided in the said Article 19(2). Accordingly he submitted that the State Government should
disclose the laws on the basis of which such reasonable restriction if any has been imposed.
38. It has been contended by Mr. Kapoor that the order passed by the Commissioner is vague. It has
also been submitted that no facts have been disclosed to show nexus with the reasons alleged in the
order for not according permission to the petitioners to hold such meeting, nor any facts disclosed in
support of the conclusion. He has also submitted that Section 144 Cr. P.C. cannot be passed in any
omnibus blanket. It has been contended that the subjective opinion of the Commissioner must
satisfy the test of reasonableness.
39. An affidavit affirmed by Tusher Kanti Talukdar, Commissioner of Police on 7-4-93 intended to
be used as opposition to the said application has been filed in Court pursuant to the leave granted on
7-4-93 (hereinafter referred to as the said affidavit). It has been alleged in the said affidavit that in
view of the changed situation after the demolition of Babri Masjid at Ajodhya on 6-12-1992 and the
resultant communal violence in many places of the country an order under Section 144 of the
Criminal P.C. imposing certain restrictions was issued op December 10, 1992. It has also been
alleged in the said affidavit that after the spate of violence seemed somewhat to abate many
organisations including political parties sought permission for staging processions as well as for
holding meetings in the City of Calcutta in the interest of communal harmony in such occasions the
prohibitory order under Section 144 Cr. P. C. was relaxed and permission was given. The BJP
however made an application to hold a Meeting on 4-1-93. Since it was not mentioned by the said
party that the said meeting or processions were organised for communal harmony, permission was
not granted. Subsequently, the BJP was granted permission on its application for relaxing the
existing order under Section 144 Cr. P.C. to enable them to hold a meeting in the Esplanade East
area Calcutta on the occasion of the birthday of Swami Vivekananda, which was sought to be
celebrated as Sourya Divas. Such permission was granted. It has further been alleged in the said
affidavit that the speakers, however, spoke very little on Vivekananda and launched into political
diatribes against other political parties like Congress, Communist parties and Janta Dal accusing
them of fermenting communal tensions by pursuing policies of anti-Hinduism and of appeasement
only of Muslims alleging that Muslim riot victims of Sitamahri in Bihar were granted relief at the
rate of Rs. 2 lakhs per family, while the Hindu riot victims of Assam were paid only Rs. 5,000/- per
family. They accused the other political parties of anti-Hinduism and of double standards for
allegedly having been silent when Hindu temples were allegedly destroyed in Kashmir and for
protesting against the demolition of the Babri Masjid. The said speakers also claimed that the
disputed structure at Ajodhya was not a Mosque and that it was the claim of the other politicalDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

parties including the Prime Minister that the said structure was a mosque which had been
demolished, which provoked the Muslims and culminated in communal riots. A copy of the Special
Branch Officers' report of the said meeting to the same effect has also been annexed. Subsequently,
the BJP however, obtained permission for holding another meeting at Esplanade East, Calcutta on
2-2-93 which was to be addressed by Kalyan Singh, the former Chief Minister of Uttar Pradesh,
heading a BJP Government. Such permission was granted and a meeting was duly held on 2-2-93.
At the said meeting Sri Kalyan Singh, declared inter alia that he was not at all unhappy or repentant
at the demolition of the structure at Ajodhya on 6-12-92. He has further alleged that the fact that the
structure was demolished and the debris cleared in 5 hours' time suggested that God's will and help
were behind the demolition and it could be an "Act of God". The report of the Special Branch Officer
reporting the said lecture has been produced in Court at the time of hearing and true copy has been
annexed to the said affidavit. The Commissioner considered that such an approach of the BJP was
clearly divisive and in the wake of the Commissioner's Report of fragile communal balance which
continued to subsist in the City and other parts of the country it was felt necessary to promulgate
orders under Section 144 of the Cr. P.C. for prevention of disturbance of public tranquillity and
breach of peace and/or danger to human life and property. Therefore, as an Executive Magistrate
prohibitive order was passed with effect from 8-2-93 prohibiting assembly of five or more persons,
or processions etc. The BJP thereafter on March 1, 1993 made another application for permission to
hold a meeting at the Brigade Parade Ground. Subsequently another application was made on
March 18, 1993. It is already on record that on 31st March, 1993 pursuant to the order of this Court
the Commissioner passed an order communicating the reasons refusing to accord permission to the
petitioner to hold meeting. It has been alleged in the said affidavit that the said order was passed by
the Commissioner after he had gone through the secret Special Branch Officers' report on the
communal situation in the city and elsewhere in the country. It has already been alleged in the said
report that it was stated inter alia that in both the public meeting held by BJP under permission
granted by the Commissioner of Police on 12th January, 1993 and 2-2-93 the speakers mainly chose
to speak on communal lines and chose to criticise other political parties as already noted. It has
further been alleged in the said report which further revealed that the Hindu fundamentalists
organisations like Viswa Hindu Parishad (V.H.P.), Bajrang Dal and the Rashtriya Sevak
Sangh(R.S.S.) since banned under the Unlawful Activities (Prevention) Act, 1967, were the main
driving forces behind all BJP activities and that important leaders of the R. S. S., V. H. P. and
Bajrang Dal and a good number of Kar Sevaks were likely to attend the open rally of the B.J.P. at
Brigade Parade Ground. Reference was also made to a speech by an important leader of B.J.P. Smt.
Uma Bharati made at the Town Hall at Dum Dum on 31 -3-93 which according to the Commissioner
of Police was exciting. He also expressed apprehension in his affidavit that in the event such similar
type of speeches are delivered that will cause communal tensions and create law and order problem
and he was of the view that prohibitory orders cannot be relaxed for holding meeting of B.J.P. at
Brigade Parade Ground.
40. Learned Advocate General submitted on the other hand that the relevant notification was issued
on 11th May, 1992 appointing Shri T. K. Talukdar as Executive Magistrate for District of South
24-Parganas and also for Calcutta authorising him to exercise all power of Executive Magistrate
under Section 144. He also referred to Section 144 Cr. P.C. and submitted that notification were
issued and published in Calcutta Police Gazette on 9th December, 1992 by Commissioner of PoliceDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

and after the expiry of two months from said date another notification was issued by Commissioner
of Police promulgating prohibitory order under Section 144. He submitted that in the instant case
the application for permission to hold meeting by B.J.P. was duly considered by the "Commissioner
of Police. The Commissioner took into consideration several materials on the basis of secret
information report of the Special Branch and arrived at his finding. He further referred to
Newspaper report on the speeches of the B.J.P. leaders at the public meeting held on January 12 to
February 2, 1993 in Calcutta. He further submitted that the decision based on Commissioner's
subjective satisfaction cannot be scrutinised under such circumstances, writ Court should not
interfere as the writ court cannot sit in appeal over the decision of the Commissioner of Police.
41. It has further been submitted by learned Advocate General that only in case of jurisdictional and
apparent errors it is open to the High Court to interfere in writ proceeding. He also submitted that
the writ Court should not reassess evidence. In this connection, he referred to Supreme Court
decisions in and .
42. Learned Advocate General referring to Article 19(2) submitted that under Section 144 Cr. P.C.
prohibitory order has been issued by the Commissioner of Police as Executive Magistrate by
Notification which has already been noted. The last such notification admittedly expired and spent
its force on April 9, 1993. It has stated that another notification will be made in the official Gazette
on April 8, 1993 and the said notification issued by or on behalf of the Governor though not gazetted
on that date produced before the Court on April 6, 1993 which admittedly shows that the
Commissioner of Police when he passed the said orderdated March 31, 1993 presupposed that a
notification would be issued since in his order he recorded that permission cannot be accorded to
BJP for holding a public meeting at Brigade Parade Ground on April 11, 1993 by relaxing the
prohibitory orders under Section 144 of the Cr. P.C. now in force in Calcutta. The Commissioner at
the material time i.e. on March 31, 1993 had no material on record before him to consider the scope
of relaxation of prohibitory orders for the meeting to be held on April 11, 1993 since the said
prohibitory order which was in force on March 31, 1993 will cease to have its validity after April 8,
1993. When the question was raised on April 5, 1993 at the closing stage of the argument, learned
Advocate General was also not aware that any such promulgation will be made again by the
Governor.
43. I have considered the submissions of the parties, the records produced and the decisions cited
from the Bar. It appears from perusaly of the Notification published in the Calcutta Police Gazette
dated May 12, 1992 that the Commissioner of Police Calcutta was appointed to be the Executive
Magistrate in the district of South 24-Parganas to exercise powers within the limits of Calcutta and
suburbs of Calcutta. Pursuant to the said appointment as Executive Magistrate the Commissioner of
Police, Calcutta issued notification which were published in the Calcutta Police Gazette. The said
Notifications issued being one dated December 9, 1992 published in December 18, 1992 and the
other issued on February 8, 1992 published in February 9, 1993 were produced in Court. In both the
said Notifications similar restrictions were imposed prohibiting assembly of five or more persons or
any procession, or carrying of lathis or other dangerous weapons etc. were made. In both the said
Notifications it has been mentioned that it appears from the trend of events prevailing in the city of
Calcutta and within the limits of the suburbs of the City of Calcutta that there is apprehension orDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

disruption of public tranquillity and breach of peace and danger to human life and property may
take place both in the town of Calcutta and within the limits of suburbs of Calcutta. In view of the
aforesaid the Commissioner of Police considered it necessary to promulgate the prohibitory orders
imposing restrictions already mentioned. The said prohibitory orders do not specifically point to any
political party including BJP from whom any such danger may be suspected.
44. In spite of the aforeaid however, the Commissioner granted permission to BJP to hold meetings
twice as already noted -- first on January 12, 1993 on account of Swami Vivekananda's birth day and
the other on February 2, 1993. Both the meetings were held at Esplanade East, Calcutta which is not
very far away from Brigade Parade Ground. Although it has been alleged that inciting communal
speeches were made by the speakers at the said meeting, during the said meeting or immediately
thereafter there is no evidence of any untoward incident nor there is any evidence that the said
meeting held by BJP caused a communal stir in Calcutta or created law and order problem. The
secret report did not reveal that the BJP is involved in any untoward incident in Calcutta or
communal clashes ensued in which members of the BJP may be involved or law and order problem
has been created after the said meetings of BJP. No incident was cited either in the affidavit of the
Commissioner or in the secret report showing that the act of BJP as political party has affected the
law and order situation in Calcutta. Reference has been made to the Ajodhya incident as already
noted. BJP held meetings with the permission of the Commissioner of Police which did not create
any problem of law and order in Calcutta or its suburbs. What particular problem will be created if
the meeting is held at Brigade Parade Ground has also not been disclosed. The secret reports only
revealed certain apprehensions which are hypothetical in nature, vague since no instance was cited
to show that after the speeches there was actual communal clash or law and order problems as a
result of such speeches in any part of Calcutta after such meeting or even as of today. It is open to
the Commissioner to take appropriate action to prevent such persons whose speech may have been
considered to be inciting in accordance with law or to proceed against him in accordance with law, if
the Commissioner is so advised. This, however, does not authorise the Commissioner to impose
total prohibition on future meeting of the BJP. It appears, however, that no action or no preventive
step has also been taken by the Commissioner, although it has been alleged that some of the leaders
of the BJP in such meeting made speeches which may have incited the communal violence. BJP is a
recognised political party. It has right to hold meeting and also to participate in election and for that
purpose, it is willing to start its election campaign, No doubt the fundamental right recognised
under Article 19(6) to assemble peaceably without arms is subject to restrictions under Article 19(2)
of the Constitution of India. Article 19(2), provides as follows:
19(2) Nothing in Sub-clause (a) of Clause (1) shall affect the operation of any existing
law or prevent the State from making any law, in so far as such law imposes
reasonable restrictions on the exercise of the right conferred by the said sub-clause in
the interests of the sovereignty and integrity of India, the security of the State,
friendly relations with foreign States, public order, decency or morality, or in relation
to contempt of court, defamation or incitement to an offence.
Such reasonable restriction must be within the framework of law as envisaged in the
Constitution.Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

45. Be that as it may, a document stated to be an order passed by or on behalf of the Governor was
produced in Court on April 6, whereby the order passed by the Commissioner of Police being an
Executive Magistrate was directed to remain in force for a further period of two months for
maintaining peace and tranquillity in Calcutta. It was mentioned in the said order as follows:
AND WHEREAS having regard to the overall situation and reports received there is
immediate apprehension of disturbance of public tranquillity and breach of peace
and danger to human life and property and the State Government considers it
necessary that for preventing breach of public peace and tranquillity and for
preventing danger to human life, the order passed by the said Commissioner of
Police, being an Executive Magistrate should remain in force for a further period of
two months for maintaining peace and tranquillity;
AND WHEREAS the Governor considers it necessary so to do for preventing danger
to human life and safety;
NOW, THEREFORE, in exercise of the power conferred by the proviso to Sub-section
(4) of Section 144 of the Code of Criminal Procedure, 1973 (2 of 1974) the Governor is
pleased hereby to direct that the order made by the said Commissioner of Police,
Calcutta, and Executive Magistrate both for the Metropolitan area of Calcutta and the
district of South 24 Parganas within the limits of the suburbs of the city of Calcutta
under Section 144 of the Criminal P.C., 1973 (2 of 1974) shall remain in force for a
further period of two months from the 8th April, 1993.
46. It is significant that the said order was issued at a time when the specific point was raised that
the earlier prohibitory order passed by the Commissioner has spent its force and the order passed by
the Commissioner suffers from that serious lacunae. The said order thereafter was made, in my
view, to remove the lacunae in the order of the Commissioner of Police when the order as also the
validity of the order passed under Section 144 is the subject matter of challenge although it is true
that in the petition vires of the said orders were not taken as the petitioner was not aware under
which provision the said prohibitory order was issued. However, since the same was disclosed at the
time of hearing the petitioner obtained leave to file affidavit challenging the same and filed its
supplementary affidavit challenging the vires of the said order and respondent also filed Affidavit in
opposition pursuant to leave of court.
47. Under such circumstances, it appears to me that such an act on the part of the State to bring
about an order is intended to cure the defect only or lacunae in the order of the Commissioner dated
March 31, 1993 and challenged in the instant petition. An affidavit has also been filed subsequent
thereafter on behalf of the State.
48. It may be noted in this connection that Sub-section (4) of Section 144 of the Criminal P.C.
provides as follows:Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

Public order includes interest of the "general public" -- It is significant to note that
Section 144 (new) nowhere uses the expression "general public". Some of the objects
for securing which an order thereunder can be passed are, "to prevent obstruction,
annoyance, injury," etc. No doubt, the prevention of such activities would be in the
"public interest", but it would be no less in the interest of maintenance of "public
order.
49. The proviso to Sub-section (4) which contemplates a consideration on the part of the State
Government to the effect that it is necessary that the order, as in the instant case, issued by the
Commissioner shall remain in force for preventing danger of human life, health or safety or prevent
any riot or any affray. As already noted on April 5, 1993 the State Government was unaware of the
position if such an order is going to be passed.
50. Several decisions have been cited from the bar:
1. In the case of Superintendent Central Prison, Fategarh v. Dr. Ram Manohar Lohia ,
it has been held in that case that limitation imposed in the interest of public order to
be a reasonable restriction, should be one which has a proximate connection or nexus
with the public order, but not one farfetched hypothetical or problemetical or too
remote in the chain of its relation with the public order.
It has also been held at paragraph 18 of page 641 ((of AIR): at p. 1010 of Cri LJ) to the following
effect which is set out below :
(18) The foregoing discussion yields, the following results : (1) "Public Order" is
synonymous with public safety and tranquillity; it is the absence of disorder involving
breaches of local significance in contradistinction to national unheavals, such as
revolution, civil strife, war affecting the security of the State; (2) there must be
proximate and reasonable nexus between the speech and the public order; (3) Section
3, as it now stands, does not establish in most of the cases comprehended by it any
such nexus, (4) there is a conflict of decision on the question of severability in the
context of an offending provision the language whereof is wide enough to cover
restrictions both within and without the limits of constitutionally permissible
legislation; one view is that it cannot be split up if there is possibility of its being
applied for purposes not sanctioned by the Constitution and the other view is that
such a provision is valid if it is severable in its application to an object which is clearly
demarcated from other object or objects falling outside the limits of constitutionally
permissible legislation; and (5) the provisions of the section are so inextricably mixed
up that it is not possible to apply the doctrine of severability so as to enable us to
affirm the validity of a part and reject the rest.
In my view, the decision in the aforesaid case lends support to the conclusion that the right to
enjoyment of fundamental rights cannot be taken away on conjectural and hypothetical basis. As I
have already noted that no instance has been cited resulting in actual law and order problem fromDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

the BJP's meeting already held apart from the quotations from the speeches.
2. Prem Chand v. Union of India . In the above case it was held that any Police apprehension is not
enough for passing order of externment. Some ground or other is not adequate. There must be clear
and present danger based upon credible material which makes the movements and acts of person in
question alarming or dangerous or fraught with violence. Likewise, there must be sufficient reason
to believe that the person proceeded against is so desparate and dangerous that his mere presence in
the locality or in part thereof is hazardous to the community and its safety. A stringent test must be
applied in order to avoid easy possibility to use of abuse of powers to the detriment of fundamental
freedom. Natural justice must be fairly complied with and vague allegations and secret hearings are
gross violation of the provisions of Articles 14 and 19 of the Constitution. The Act permits
externment provided the action is bona fide. All power including the Police power must be informed
by fairness if it is to survive judicial scrutiny.
3. Reference may also be made to Gulam Abbas's case in . In this aforesaid decision Supreme Court
observed: object of Section 144 is to preserve public peace and tranquillity and as such attempt
should be made to regulate the rights instead of prohibiting the right to hold procession totally.
In the instant case it cannot be said that there is sufficient reason to believe that total prohibition of
the meeting is called for in view of the fact that the meetings were already held and no actual
problem of law and order arose from that time onwards with which the BJP can be directly
connected i.e. after the two meetings held on 12-1-93 and 2-2-93.
4. Ram Manohar Lohia v. State of Bihar . Learned Advocate General relied upon this decision to
show that the order passed by the Commissioner of Police based upon subjective satisfaction is not
liable to judicial scrutiny. In my view, the said judgment cannot be of any assistance to him in the
facts and circumstances already noted.
It is quite true that the Court should not sit in appeal over the decision of the Commissioner,
however, in the instant case since there is error apparent on the face of the record and there is also
jurisdictional error in the decision of the Commissioner and as such there is scope for interference
and that the decision relied upon by the Ld. Advocate General do not at all be of any assistance to
him.
51. In this connection I may take note of the judgment and decision in the case of M. A. Rasheed v.
The State of Kerala .
52. In the case of M. A. Rasheed v. The State of Kerala (supra) it was held by the Supreme Court at
paragraphs 9 and 10 of the said report to the following effect :--
Administrative decision in exercise of powers even if conferred in subjective terms
are to be made in good faith on relevant consideration. The Courts inquire whether a
reasonable man could have come to the decision in question without misdirecting
himself on the law or the facts in a material respect. The standard of reasonablenessDr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

to which the administrative body is required to conform may range from the courts
own opinion of what is reasonable to the criterion of what a reasonable body might
have decided. The courts will find out whether conditions precedent to the formation
of the opinion have a factual basis.
53. In Rohtas Industries Ltd. v. S. D. Agarwala an order under Section 237(b)(i) and (ii) of the
Companies Act for investigation of the affairs of the company was challenged on the ground that
though the opinion of the Government is subjective, the existence of the circumstances is a
condition precedent to the formation of the opinion. It was contended that the Court was not
precluded from going behind the recitals of the existence of such circumstances in the order, but
could determine whether the circumstances did in fact exist. This Court said that if the opinion of an
administrative agency is the condition precedent to the exercise of the power, the relevant matter is
the opinion of the agency and not the grounds on which the opinion is founded. If it is established
that there were no materials at all upon which the authority could form the requisite opinion, the
Court may infer that the authority passed the order without applying its mind. The opinion is
displaced as a relevant opinion if it could not be formed by any sensible person on the material
before him.
54. In the facts and circumstances of this case it appears that the Commissioner of Police was not
justified in issuing the said order dated March 31, 1993 refusing to accord permission to the
petitioners to hold their meeting thereby imposing total prohibition. In my view, the Commissioner
of Police instead of totally prohibiting the holding of meeting may impose necessary restrictions and
take such preventive measures as he may consider fit and proper while allowing such Meeting to be
held.
55. The said order issued by the Commissioner of Police on March 31, 1993 is accordingly quashed
and set aside and necessary permission be accorded to the petitioners on the basis of application
dated March 19, 1993. This order however, will not prevent the Commissioner of Police to impose
necessary regulatory measures.
56. The writ petition is accordingly disposed of.
57. There will be no order as to costs.
58. Learned Government Pleader prays for stay of operation of this order. In view of such prayer it is
directed that since the Meeting is fixed on April 11, 1993 the order passed today need not be
implemented till April 9, 1993.
59. All parties to act on the signed copy of the operative portion of this judgment.Dr. Anindya Gopal Mitra And Anr. vs State Of West Bengal And Ors. on 8 April, 1993

