A.Kamala vs The State on 9 August, 2024
Author: S.M.Subramaniam
Bench: S.M.Subramaniam, V.Sivagnanam
   2024:MHC:3023
                                                                           H.C.P.No.1163 of 2024
                                  IN THE HIGH COURT OF JUDICATURE AT MADRAS
                                        RESERVED ON         : 06.08.2024
                                        PRONOUNCED ON       : 09.08.2024
                                                   CORAM
                       THE HONOURABLE MR.JUSTICE S.M.SUBRAMANIAM
                                                     AND
                          THE HONOURABLE MR.JUSTICE V.SIVAGNANAM
                                             H.C.P.No.1163 of 2024
                                                     and
                                            Crl.M.P.No.8104 of 2024
                 A.Kamala                                              ... Petitioner
                                                      Vs.
                 1.The State,
                   Represented by Secretary to Government,
                   Home, Prohibition and Excise Department,
                   Fort St. George,
                   Chennai – 9.
                 2.The Commissioner of Police,
                   Greater Chennai,
                   Chennai.
                 3.The Inspector of Police,
                   Chennai City CCD-I,
                   Chennai.
                 4.The Superintendent,
                   Central Prison, Coimbatore.                         ... Respondents
                 Page 1 of 56
https://www.mhc.tn.gov.in/judisA.Kamala vs The State on 9 August, 2024

                                                                                                                        H.C.P.No.1163 of 2024
                 Prayer: Writ Petition filed under Article 226 of the Constitution of India for
                 issuance of a Writ of Habeas Corpus, calling for the records relating to the
                 Detention Order passed by the 2nd respondent on 12.05.2024 in
                 No.465/BCDFGISSSV/2024 and to quash the same and direct the
                 respondents to produce the body of the detenue Shankar @ Savukku Shankar
                 S/o.Achimuthu, aged about 48 years, before this Court and set him at liberty,
                 now detained at Central Prison, Coimbatore.
                                      For Petitioner                             : Mr.C.Iyyapparaj
                                                                                   For Mr.T.S.Lavanesh
                                      For Respondents                            : Mr.E.Raj Thilak
                                                                                   Additional Public Prosecutor
                                                                       ORDER
S.M.SUBRAMANIAM, J.
Table of Contents I. FACTUAL
MATRIX:........................................................................................................3 II. SUBMISSION ON
BEHALF OF THE PETITIONER: ................................................. 7 III. REPLY ON BEHALF OF THE
RESPONDENTS:......................................................14 IV. LEGAL
POSITION:......................................................................................................18 V.
DISCUSSIONS:............................................................................................................. 25 (A)
MALICE:............................................................................................................. 35 (B) BALANCE
BETWEEN INDIVIDUAL RIGHTS AND PUBLIC ORDER:......39 (C) FREEDOM OF SPEECH AND
EXPRESSION:................................................40 (D) CRITICISM AND UNFAIR
OPINION:............................................................. 42 (E) SOCIAL MEDIA AND HUMAN MIND IN
TANDEM WITH FREEDOM OF
SPEECH:....................................................................................................................43 VI.
REGULATIONS – THE NEED OF THE HOUR:...................................................... 47 VII. FREEDOM
OF PRESS:.............................................................................................. 49 VIII.
CONCLUSION:..........................................................................................................53
https://www.mhc.tn.gov.in/judis I. FACTUAL MATRIX:
Under assail in the present writ petition is the detention order passed by the
Commissioner of Police, Greater Chennai dated 12.05.2024. Two adverse cases are
relied on the impugned detention order for invoking Section 3 of the Tamil Nadu
Prevention of Dangerous Activities of Bootleggers, Cyber Law Offenders, Drug
Offenders, Forest Offenders, Goondas, Immoral Traffic Offenders, Sand Offenders,
Sexual Offenders, Slum Grabbers and Video Pirates Act, 1982 [hereinafter referred as
'Act 14 of 1982'].A.Kamala vs The State on 9 August, 2024

2. The petitioner is the mother of the detenu. The Detenu was arrested on 04.05.2024 by the
Inspector of Police, Cyber Crime, Coimbatore City in Crime No.123 of 2024 under Section 509 of
Indian Penal Code (IPC) read with Section 4 of Tamil Nadu Prohibition of Harassment of Women
Act, 1998, Section 67 of the Information Technology Act, 2000 and was lodged in Central Prison at
Coimbatore. On 08.05.2024, a complaint was received from Mr.Balamurugan, Superintendent
Engineer in Construction Wing, Chennai Metropolitan Development Authority (CMDA) and First
Information Report (FIR) in Crime No.158 of 2024 was registered under Sections 465, 466, 471,
https://www.mhc.tn.gov.in/judis 474, 420 of Indian Penal Code (IPC). On 09.05.2024, the detenu
was formally arrested (adverse cases) in Crime Nos.154 and 155 of 2024 and was produced before
the Learned Metropolitan Magistrate, Chennai and the remand was rejected in above cases. On
10.05.2024, the Inspector of Police / 3rd respondent formally arrested the detenu in Crime No.158
of 2024 and was remanded. The detenu filed Bail Application in Crime No.158 of 2024 and it was
pending on the file of Learned Metropolitan Magistrate of CCB and CBCID Court at Egmore,
Chennai. On 11.05.2024, the 3rd respondent submitted a proposal to detain petitioner's son
Mr.Savukku Shankar (detenu) to the Detaining Authority. Consequently, the 2nd respondent /
Commissioner of Police, Greater Chennai on 12.05.2024 has passed Detention Order against
detenu. The order of detention was served on the detenu at Coimbatore Central Prison along with
the grounds of detention and the booklet. The petitioner mother of the detenu made representations
on 14.05.2024 and 21.05.2021 to the Detention Authority, which were received on 15.05.2024 and
22.05.2024 and rejected on 16.05.2024 and 24.05.2024. Before rejection of representation dated
21.05.2024, the Government approved the Detention Order in G.O.RT.No.3093, Home Department
dated 22.05.2024.
https://www.mhc.tn.gov.in/judis
3. On 12.05.2024, the order of detention had been passed by the 2 nd respondent in exercise of his
powers under Section 3(1) of Act 14 of 1982 and branded the detenu as “Goonda”. The ground for
the detention in Crime No.158 of 2024 under Sections 465, 466, 471, 474, 420 of IPC instituted
pursuant to the complaint made Mr.Balamurugan, Superintending Engineer, CMDA alleging
circulation of false documents on social media with reference to the tender process in CMDA for
construction of new Bus Terminus at Kilambakkam.
4. The Detaining Authority have further referred two adverse cases registered;
(1) Chennai City, Cyber Crime Division-I, Crime No.154 of 2024 under Section 294(b), 354D, 506(i),
509 of IPC and Section 4 of Tamil Nadu Prohibition of Harassment of Women (Amendment) Act,
2002 for the alleged publication of an article about a journalist making false statement amounting
to character assassination.
(2) Chennai City, Cyber Crime Division-I, Crime No.155 of 2024 under Sections 294(b) and 506(i) of
IPC on the complaint of a social activist for levelling demeaning allegations against Women Police
Personnel in an https://www.mhc.tn.gov.in/judis interview published in a YouTube Channel.A.Kamala vs The State on 9 August, 2024

5. The petitioner filed the present Habeas Corpus Petition on 23.05.2024. On 24.05.2024, the
Division Bench of this Court taken up the matter for final hearing and one of the Hon'ble Judges
quashed the Detention Order and the other Learned Judge had taken a view that an opportunity
must be afforded to the State to file counter affidavit. The case was referred to the Third Learned
Judge by the Hon'ble Acting Chief Justice. The Third Learned Judge passed an elaborate order and
permitted the State to file counter affidavit in the Habeas Corpus Petition and held that the matter is
to be reheard by the Division Bench deals with Habeas Corpus Petition. Consequently, the matter
was listed before the Division Bench. The petitioner approached the Hon'ble Supreme Court of India
in Special Leave Petition in SLP (Crl).Nos.8706 and 8707 of 2024 and Transfer Petition (Crl) No.597
of 2024. The Hon'ble Supreme Court of India disposed of the matter with a direction to hear the
matter as expeditiously as possible and granted interim bail to the detenu.
6. When the present Habeas Corpus Petition was taken up for hearing by the Predecessor Bench of
this Court, the Hon'ble Judges recused https://www.mhc.tn.gov.in/judis themselves from hearing
the present Habeas Corpus Petition in H.C.P.No.1163 of 2024. Thereafter, the Habeas Corpus
Petition was listed as per roster by the Hon'ble Acting Chief Justice before this Bench.
7. In the above backdrop, the present Habeas Corpus Petition has been listed before this Bench.
Pleadings are completed and the parties are heard. II. SUBMISSION ON BEHALF OF THE
PETITIONER:
8. The learned counsel for the petitioner would submit that in the impugned Detention Order, it is
stated that the detenu was remanded in Crime No.158 of 2024 and lodged at Central Prison,
Coimbatore as a remand prisoner. He moved a Bail Application, which was pending. In a similar
case, in Crime No.66 of 2023, bail was granted by the Learned Judicial Magistrate, Alandur in
Crl.M.P.No.5181 of 2023. Thus, the Detaining Authority inferred that it is very likely of his coming
out on bail in Crime No.158 of 2024. If the detenu comes out on bail, he will further indulge in such
further activities in further, which are prejudicial to the maintenance of 'Public Order' under the
provisions of the Act 14 of 1982. The very inference made by the Detaining Authority is untenable, in
view of the fact that the allegations in Crime No.66 of 2023 is different and distinct and not identical
or similar. Therefore, the https://www.mhc.tn.gov.in/judis very basis for Detention Order is
untenable.
9. It was further contended that the impugned Detention Order has no legs to stand under Scrutiny
of Law. Arrest was made on 10.05.2024 and the video referred in the Detention Order was
broadcasted on 11.02.2024. The order of detention reveals that the passengers at Chennai's New
Kalaignar Centenary Bus Terminus in Kilambakkam staged protest alleging the non- availability of
buses services on 10.02.2024. But the impugned order states that the information contained in the
mail was published in M/s.Savukku Media on 11.02.2024. The contradiction apparent on the face of
it, would be sufficient to arrive at a conclusion that an element of breach of public order has not
been established.
10. The petitioner contented that the 2 nd respondent lacks jurisdiction, since adverse notice was
considered in Crime Nos.154 and 155 of 2024. In both the cases, the Learned AdditionalA.Kamala vs The State on 9 August, 2024

Metropolitan Magistrate, Egmore, Chennai had rejected the remand on the ground that the
detention became unnecessary. Thus, there is no application of mind on the part of Detaining
Authority. No untoward incident or element of breach of public order has
https://www.mhc.tn.gov.in/judis been established in the impugned order.
11. Regarding the jurisdiction, the alleged occurrence of protest in the Kilambakkam bus stand was
staged by the passengers falling within the territorial jurisdiction of Commissionerate of Tambaram.
Thus, the complaint by the Superintending Engineer, CMDA before the 2nd respondent /
Commissionerate of Chennai is not entertainable and thus, the impugned order lacks jurisdiction.
12. The Detaining Authority has not established that there is likelihood of grant of bail in Crime
No.66 of 2023. The nature of cases were bail was granted are different and not similar. Therefore,
the reasons stated in the Detention Order are untenable.
13. The agitation by the passengers for non-availability of bus services in Kilambakkam bus stand
was staged on 10.02.2024. Complaint was given by the Superintending Engineer, CMDA on
08.05.2024. There is a long delay of about three months in registering the complaint, which would
be sufficient to draw an inference that an element of Malice exists and Act 14 of 1982 has
https://www.mhc.tn.gov.in/judis been invoked. There is no nexus between the complaint and
detention, which would show non-application of mind.
14. The documents relied on by the Detaining Authority in the impugned order have not been
furnished to the detenu. The remand report in Crime No.123 of 2024 had not been furnished to the
detenu, which resulted in causing prejudice to detenu to submit his representations in an effective
manner to the authority. The arrest intimation of the detenu in Crime No. 158 of 2024 was said to be
given to the mother of the detenu, Smt. A.Kamala / petitioner on the same day in the impugned
order. However, the booklet does not have any details regarding the name and address of the person
to whom the intimation of arrest was informed. Column 6 in the said form is left blank. The
Investigation Officer had himself served the copy of the Detention Order to the detenu at Central
Prison, Coimbatore on 10.05.2024.
15. That being so, the documents served in the booklet refers that the detenu's mother was served
the copy through registered post from Chennai on the very same day by the same Inspector of Police
which raises suspicion. https://www.mhc.tn.gov.in/judis
16. The requisition made by the police to learned Judicial Magistrate- IV, Coimbatore city in Crime
No.158 of 2024 relating to ground case had not been supplied to the detenu. The detention order
was passed on 12.05.2024 and the Government approved the same in G.O.(RT).No.3093, Home
Department date 22.05.2024.
17. In the counter affidavit filed by the 2 nd respondent, it is admitted that the representations dated
14.05.2024 and 21.05.2024 sent by the petitioner had been received by the 2nd respondent on
15.05.2024 and 22.05.2024. The representations were considered and rejected on 16.05.2024 and
24.05.2024. Even before the rejection of the representation on 24.05.2024, the Government hadA.Kamala vs The State on 9 August, 2024

approved the detention on 22.05.2024. Thus, consideration of representation ended in futile
exercise and the detention order is therefore infirm.
18. The detention order was signed and sealed at Chennai by the 2 nd respondent on 12.05.2024
Forenoon. The copy of the detention order was served to the detenu on the same day 12.10 P.M. at
the Central prison, Coimbatore, which is not viable and would establish that all the documents
https://www.mhc.tn.gov.in/judis were prepared in advance at the whims and fancies of the 2nd
respondent.
19. The documents served in the booklet to the detenu are illegible and the detenu loses his
opportunity to make an effective representation. The Detention Order has been passed in exercise of
the powers conferred on the 2nd respondent in G.O.(D).No.82 dated 15.04.2024. But the copy of the
said Government order has not been furnished to the detenu. The translations made in certain
documents are improper resulted in denial of an opportunity for representation.
20. Arrest intimation in Column No.8, whether the arrest person injured / sick, if so, whether he has
been treated, the Investigation Officer has stated as 'NO'. However, in the remand order the learned
Additional CMM, Egmore, Chennai has clearly stated that “the right hand of the accused is
bandaged for treatment. Enquired”. The accused said that the prison authorities caused the injury
and they assaulted by plastic pipe. Accused has taken treatment at Coimbatore Hospital for that
injury. Further, the remand Order states that 'Injury is not mentioned in the arrest memo'.
https://www.mhc.tn.gov.in/judis
21. The report of the Inspector of Police, Cyber Crime Police Station, Chennai is undated. The date
of issuance of the report to the 2 nd respondent Commissioner of Police, Chennai has not been
stated. Regarding the bail petition referred in the Detention Order, the Criminal Miscellaneous
Petition has not even numbered in Crime No.158 of 2024. Therefore, there is no possibility of grant
of bail to the detenu. Thus, the ground for detention that there is a possibility of grant of bail is
imaginary and the said ground is untenable. The arrest intimation letter by the Inspector of Police,
Cyber Cell, Central Crime Branch, Chennai with reference to Crime No.154 of 2023 in Column No.6,
the name and address of the person to whom the intimation of arrest was informed remains blank.
22. The learned counsel for the petitioner would submit that there is total non-application of mind
on the part of Detaining Authority. The apprehension for commission of breach of public order is
absolutely absent. The impugned order has been passed maliciously and to prevent the detenu from
making speeches and making his opinion in social media against the Government of the day its
officials and their functioning. Thus, the writ petition is to be considered.
https://www.mhc.tn.gov.in/judis
23. The learned counsel for the petitioner would submit that the detention is made to quell the voice
of dissent of the detenu. The liberty of a journalist, who is anti-establishment and a critic of the
Government is crippled. The respondents are not happy about the speeches and opinions raised
against the Government of the day and having inconvenience with the voice of the detenu and theyA.Kamala vs The State on 9 August, 2024

are strangling his voice through detention Order under Act 14 of 1982.
III. REPLY ON BEHALF OF THE RESPONDENTS:
24. The learned Additional Public Prosecutor appearing on behalf of the respondents strenuously
opposed the grounds raised on behalf of the detenu by stating that the Commissioner of Police,
Greater Chennai Police, in the capacity of Detaining Authority, has considered the two adverse cases
and the ground case for the detention of the detenu as Goonda under preventive detention. The
activities of the detenu in the above cases are prejudicial to the maintenance of public order and
public peace. The Sponsoring Authority has initiated a proposal for the detention of the detenu as
Goonda under preventive detention. After careful perusal of the records
https://www.mhc.tn.gov.in/judis and material evidence, the Detaining Authority has passed the
order of detention of the detenu as Goonda on 12.05.2024 in accordance with law. The detenu
Mr.Shankar @ Savukku Shankar has acted in a manner prejudicial to the maintenance of public
order and peace in the two adverse cases and in the ground case and as such, he is a Goonda as
contemplated under Section 2(f) of the Tamil Nadu Act 14 of 1982.
25. It is contended that by considering the criminal activities of the detenu in the two adverse cases
and in the ground case, the Sponsoring Authority has initiated a proposal for the detention of the
detenu as Goonda under preventive detention. The detention order was passed by the Detaining
Authority on 12.05.2024. The Government has approved the detention of the detenu Mr.Shankar @
Savukku Shankar in G.O.(RT).No.3093, Home, P&E (XIII) Department dated 22.05.2024. The
Government has served the said GO to the detenu directly through the Prison Authority under
proper acknowledgement.
26. In the adverse cases in Crime Nos.154 and 155 of 2024, the Learned Additional Chief
Metropolitan Magistrate, Egmore, Chennai, https://www.mhc.tn.gov.in/judis considered various
aspects and rejected the request of the Inspectors of Police concerned for the remand of the accused
under judicial custody on 10.05.2024. But in the ground case in GCP, CCB CCD-1 Crime No.158 of
2024, after hearing the arguments of both sides, the Learned Additional Chief Metropolitan
Magistrate, Egmore, Chennai, has remanded the accused Mr.Shankar @ Savukku Shankar to
judicial custody till 24.05.2024. Considering the criminal activities of the detenu in the two adverse
cases and in the ground case, the Sponsoring Authority has initiated a proposal for the detention of
the detenu as Goonda under preventive detention. After careful perusal of the records and material
evidences, the Detaining Authority has passed the order of detention of the detenu as Goonda on
12.05.2024.
27. The detenu is in remand in CCB, CCD-I Crime No.158 of 2024 and he has moved Bail
Application in the above case before the Court of Metropolitan Magistrate for CCB and CBCID.
Cases in Sl.No.608 of 2024 and the bail petition were pending on the date of passing the Detention
Order. Since in the similar case in CCB Crime No.66 of 2023 under Sections 420 IPC @ 406, 420,
465, 468, read with 120(B) of IPC, bail was granted to the accused concerned in a similar case, the
Detaining Authority has inferred that https://www.mhc.tn.gov.in/judis it is very likely of the detenu
will be released on bail in the ground case at the time of disposal of pending bail application. TheA.Kamala vs The State on 9 August, 2024

bail order in a similar case has been considered and discussed on the grounds of detention only with
a view to justifying the possibility of the detenu being released on bail in the ground case at the time
of disposal of the pending bail application. Hence, the Detaining Authority has raised his
apprehension on the grounds of detention.
28. It is stated in the counter filed by the respondents that there is a likelihood of grant of bail since
in similar cases in Crime No.66 of 2023 bail was granted to the accused. The arrest intimation of the
denten was given to the petitioner, Smt. A.Kamala by the Sponsoring Authority in his letter dated
10.05.24 through Speed post. The order of detention was passed on 12.05.2024 and the Sponsoring
Authority travelled through Indigo flight and reached Coimbatore International Airport at 11.05
hours. The Sponsoring Authority served the Detention Order along with the grounds of detention
and booklet at 12.10 hours on the same day through Coimbatore Prison Authorities. All eligible and
relied documents have been served to the detenu.
29. The representations dated 14.05.2024 and 21.05.2024 sent by the
https://www.mhc.tn.gov.in/judis petitioner were considered and rejected. The criminal activities of
the detenu in the two adverse cases and in the ground case are prejudicial to the maintenance of
public order and peace. The detenu has created a feeling of insecurity in the minds of the public and
has acted in a manner prejudicial to the maintenance of public order. Considering the two adverse
cases and the ground case the Sponsoring Authority has initiated a proposal for detention of the
detenu as Goonda under preventive detention. IV. LEGAL POSITION:
30. Respective learned counsels appearing on behalf of the petitioner and the learned Additional
Public Prosecutor appearing on behalf of the respondents relied on certain case laws. However, the
cases relied on by the parties were elaborately considered by the Hon'ble Supreme Court of India in
the case of Ameena Begum vs. State of Telangana and Others1, the Apex Court considered earlier
judgments of the Hon'ble Supreme Court in the said case. Therefore, it would be sufficient that the
principles laid down in the said case has been considered for the purpose of dealing with the facts of
the present case on hand. Relevant paragraphs are extracted hereunder;
“38. For an act to qualify as a disturbance 1 [(2023) 9 SCC 587] https://www.mhc.tn.gov.in/judis to
public order, the specific activity must have an impact on the broader community or the general
public, evoking feelings of fear, panic, or insecurity. Not every case of a general disturbance to public
tranquillity affects the public order and the question to be asked, as articulated by Hon'ble M.
Hidayatullah, C.J. In Arun Ghosh v. State of W.B. [Arun Ghosh v.State of W.B., (1970) 1 SCC 98 :
1970 SCC (Cri) 67] , is this :
(SCC p. 100, para 3) “3. … Does it [the offending act] lead to disturbance of the
current of life of the community so as to amount a disturbance of the public order or
does it affect merely an individual leaving the tranquillity of the society
undisturbed?” ........
40. In the process of quashing the impugned order, the Hidayatullah, C.J. while
referring to the decision in Ram Manohar Lohia [Ram Manohar Lohia v. State ofA.Kamala vs The State on 9 August, 2024

Bihar, 1965 SCC OnLine SC 9 : (1966) 1 SCR 709] also ruled :
(Arun Ghosh case [Arun Ghosh v.State of W.B., (1970) 1 SCC 98 : 1970 SCC (Cri) 67] ,
SCC pp.
99-100, para 3) “3. … Public order was said to embrace https://www.mhc.tn.gov.in/judis more of
the community than law and order. Public order is the even tempo of the life of the community
taking the country as a whole or even a specified locality. Disturbance of public order is to be
distinguished from acts directed against individuals which do not disturb the society to the extent of
causing a general disturbance of public tranquillity. It is the degree of disturbance and its effect
upon the life of the community in a locality which determines whether the disturbance amounts only
to a breach of law and order. … It is always a question of degree of the harm and its effect upon the
community. … This question has to be faced in every case on facts. There is no formula by which one
case can be distinguished from another.”
41. In Kuso Sah v. State of Bihar [Kuso Sah v. State of Bihar, (1974) 1 SCC 185 : 1974 SCC (Cri) 84] ,
Hon'ble Y.V. Chandrachud, J. (as the Chief Justice then was) speaking for the Bench held that : (SCC
pp. 186-87, paras 4 & 6) … The power to detain a person without the safeguard of a court trial is too
drastic to permit a lenient construction and therefore Courts must be
https://www.mhc.tn.gov.in/judis astute to ensure that the detaining authority does not transgress
the limitations subject to which alone the power can be exercised.”
42. Turning our attention to Section 3(1) of the Act, the Government has to arrive at a subjective
satisfaction that a goonda (as in the present case) has to be detained, in order to prevent him from
acting in a manner prejudicial to the maintenance of public order. Therefore, we first direct
ourselves to the examination of what constitutes “public order”. Even within the provisions of the
Act, the term “public order” has, stricto sensu, been defined in narrow and restricted terms. An
order of detention under Section 3(1) of the Act can only be issued against a detenu to prevent him
“from acting in any manner prejudicial to the maintenance of public order”. “Public order” is
defined in the Explanation to Section 2(a) of the Act as encompassing situations that cause “harm,
danger or alarm or a feeling of insecurity among the general public or any section thereof or a grave
wide-spread danger to life or public health”.
https://www.mhc.tn.gov.in/judis
43.Ram Manohar Lohia [Ram Manohar Lohia v. State of Bihar, 1965 SCC OnLine SC 9 :
(1966) 1 SCR 709] is an authority to rely upon for the proposition that if liberty of an
individual can be invaded under statutory rules by the simple process of making of a
certain order, he can be so deprived only if the order is in consonance with the said
rule. Strict compliance with the letter of the rule, in such a case, has to be the essence
of the matter since the statute has the potentiality to interfere with the personal
liberty of an individual and a Court is precluded from going behind its face. Though
circumstances may make it necessary for ordering a detention without trial, but itA.Kamala vs The State on 9 August, 2024

would be perfectly legitimate to require strict observance of the rules in such cases. If
there is any doubt whether the rules have been strictly observed, that doubt must be
resolved in favour of the detenu.
44.Rekha [Rekha v. State of T.N., (2011) 5 SCC 244 : (2011) 2 SCC (Cri) 596] too provides a useful
guide. It is said in para 30 that : (SCC p.
255) “30. Whenever an order under a preventive https://www.mhc.tn.gov.in/judis detention law is
challenged, one of the questions the court must ask in deciding its legality is : was the ordinary law
of the land sufficient to deal with the situation? If the answer is in the affirmative, the detention
order will be illegal. In the present case, the charge against the detenu was of selling expired drugs
after changing their labels. Surely the relevant provisions in the Penal Code and the Drugs and
Cosmetics Act were sufficient to deal with this situation. Hence, in our opinion, for this reason also
the detention order in question was illegal.” .............
.............
65. Interference by this Court with orders of detention, routinely issued under the Act, seems to
continue unabated. Even after Mallada K. Sri Ram [Mallada K. Sri Ram v. State of Telangana,
(2023) 13 SCC 537 : 2022 SCC OnLine SC 424] , in another decision of fairly recent origin in Sk.
Nazneen v. State of Telangana [Sk. Nazneen v.
State of Telangana, (2023) 9 SCC 633] , this Court set aside the impugned order of detention dated
28-10-2021 holding that seeking shelter under preventive detention law was not the proper
https://www.mhc.tn.gov.in/judis remedy.
66. It requires no serious debate that preventive detention, conceived as an extraordinary measure
by the Framers of our Constitution, has been rendered ordinary with its reckless invocation over the
years as if it were available for use even in the ordinary course of proceedings. To unchain the
shackles of preventive detention, it is important that the safeguards enshrined in our Constitution,
particularly under the “golden triangle” formed by Articles 14, 19 and 21, are diligently enforced.
........
76. We turn to A.K. Roy [A.K. Roy v. Union of India, (1982) 1 SCC 271 : 1982 SCC (Cri) 152] once
again where the law is expounded in the following words : (SCC p. 321, para 70) “70. … We have the
authority of the decisions in … for saying that the fundamental rights conferred by the different
articles of Part III of the Constitution are not mutually exclusive and that therefore, a law of
preventive detention which falls within Article 22 must also meet the requirements of Articles 14, 19
and 21.” https://www.mhc.tn.gov.in/judis V. DISCUSSIONS:
31. Section 3(1) of Act 14 of 1982 stipulates the power of the State government to
make orders detaining certain persons. Sub section (2) deals with the jurisdiction and
Sub Section (3) stipulates procedures. In the ground case, the complainant lodged aA.Kamala vs The State on 9 August, 2024

complaint about the protest made by the bus passengers in Kilambakkam bus stand
on 10.02.2024. The complaint was given by the Superintending Engineer, CMDA on
08.05.2024 after a lapse of about three months from the date of protest and
publication made in M/s.Savukku Media on 11.02.2024. The unexplained delay raises
suspicion, more specifically, for the detention of the detenu under Act 14 of 1982. The
arrest intimation issued by the Investigating Officer did not specify the name and
address of the person to whom the intimation of arrest was informed.
Therefore the contention of the respondents that they have sent information to the mother of the
detenu on the same day on 10.05.2024 raises a doubt. Pertinently, the Inspector of Police, Cyber
Crime Police Station, Chennai served the arrest intimation to the detenu at Central Prison,
Coimbatore on 10.05.2024. The intimation letter was sent to the mother of the detenu at Chennai on
10.05.2024 by the very same Inspector of Police, Cyber Crime Police Station. The manner of service
to the mother of the Petitioner from https://www.mhc.tn.gov.in/judis Chennai and serving the
arrest intimation to the detenu at Coimbatore by the very same Inspector of police raises a doubt.
32. Importantly, in the arrest intimation Column No.8, a question is asked, whether the arrest
person injured / sick, if so, whether he has been treated. The answer stated by the Investigating
officer is 'NO'. But the remand order passed by the learned Additional CMM, Egmore, Chennai
dated 10.05.2024 reveals that the right hand of the accused is bandaged for treatment. The accused
said that the Prison Authorities caused injury and they assaulted the detenu with plastic pipe.
Accused has taken treatment at Coimbatore Hospital for that injury. The remand order further
states that Section 41A of Criminal Procedure Code is not followed by the Investigating Officer. The
injury is not mentioned in the arrest memo. The above facts would reveal that the arrest intimation
itself is improperly given and the learned Additional CMM, Egmore found that the information
given in arrest intimation regarding injury / sickness of the detenu is false. At the time of arrest in
Crime No.158 of 2024, the detenu was already under Judicial custody in Central Prison, Coimbatore
in connection with Crime No.123 of 2024. The special report of the Inspector of Police, Cyber Crime
Police https://www.mhc.tn.gov.in/judis Station, Chennai is undated but communicated to the 2 nd
respondent / Commissioner of Police, which is the basis for the Detention Order.
33. Regarding non supply of materials referred in the impugned detention order, the copy of
Government order namely G.O.(D).No.82 dated 15.04.2024 has not been furnished to the detenu.
The remand report in Crime No.123 of 2024 had not been served to the detenu, which caused
prejudice to submit effective representation. Requisition petition made to learned Judicial
Magistrate IV, Coimbatore city in Crime No.158 of 2024 had not been furnished to the detenu. In
the counter affidavit filed by the 2 nd respondent, the representation dated 14.05.2024 and
21.05.2024 sent by the petitioner had been received by the 2nd respondent on 15.05.2024 and
22.05.2024. But the said representations were rejected by the 2nd respondent on 16.05.2024 and
24.05.2024. Pertinently, the Government had approved the detention of the detenu in
G.O.(RT).No.3093, Home department dated 22.05.2024. Therefore the representation sent on
21.05.2024 could not have been considered before approving the detention of the detenu by the
Government. It was rejected on 24.05.24 after grant of approval of detention by the Government.
Therefore the detenu lost the opportunity of effective https://www.mhc.tn.gov.in/judisA.Kamala vs The State on 9 August, 2024

consideration of his representation.
34. Though the impugned detention order states that the acts committed by the detenu are
prejudicial to the maintenance of public order the impugned order is devoid of reasons. Offences
disclosed in the adverse cases and the ground case do not disclose any serious threat to 'Public
Order' and does not meet the threshold. An element of malice in the entire action is traceable
through the documents furnished for issuing the impugned order of detention. It is apparent that
there is a prejudicial view about the publication made by the detenu through his M/s.Savukku
media. The criticism made against the Government and its officials prompted them to invoke
preventive detention to stop the detenu from publishing any such criticism, opinions about the
Government or its officials. The detention orders dated 12.05.2024 rests on the ground case in
Crime No.158 of 2024 registered on the file of CCB, Cyber Crime division I, Chennai. The adverse
cases are Crime Nos.154 and 155 of 2024 both on the file of Chennai City Crime branch, Cyber Crime
Division I, Chennai. The Crime No.155 of 2024 was registered on 06.05.2024 based on the
complaint lodged by one Veeralakshmi, a social activist. The detenu had put up a You Tube video
making serious allegations https://www.mhc.tn.gov.in/judis against Women Police Personnel.
35. In Crime No.154 of 2024, the FIR was registered based on a complaint made by one Ms.
Sandhya Ravishankar, Journalist who alleged that the detenu had made some derogatory comments
against her. It is pertinent to note that this compliant was given by her to the CCB, CCD, Chennai on
27.08.2018 and again it was reiterated by her through subsequent complaints on 24.09.2018,
19.10.2018, 01.10.2019, 02.10.2019. But the FIR was registered only on 07.05.2024, after a lapse of
nearly six years from the date of original complaint in Crime No.154 of 2024. This raises some
dubious question as to why this complaint was registered after a lapse of nearly six years.
36. Pertaining to the the second Crime No.155 of 2024, it is to be noted that the complainant is a
social activist, and she filed a compliant on 07.05.2024 stating that detenu had made some
derogatory comments against Women Police Officers in a video posted in YouTube. In both these
cases there runs a common thread that the allegations are not satisfactory and vague with no
reference to any public being disturbed or incited in any way https://www.mhc.tn.gov.in/judis
thereby affecting 'Public Order'. The complaints are made based on allegations made by detenu
against persons and these two complaints for which F.I.R. was registered on the same day cannot
form a sufficient basis for establishing a breach of public order. The compliant in both these cases
can be addressed in the normal course of legal action under relevant provisions of Laws. But when
invoking the Act 14 of 1982, it is the responsibility of the Issuing Authority to establish grounds of
disturbance or apprehension of disturbance to 'Public Order'. Allegation or remarks made against
individuals cannot constitute a threat to 'Public Order'. There must be a real threat or apprehension
of large scale disturbance in the society or amongst the people at large to invoke the term of 'Public
Disorder'. This Court does not find merit in the Detention Order issued by the 2nd respondent.
Therefore there are serious doubts in the detention of the detenu in the present case as there is no
sufficient ground to establish the breach of public order.
37. The ground case in Crime No.158 of 2024 is pertaining to an offence relating to forgery of tender
documents in the CMDA. The detention order states that there a public protest in the KilambakkamA.Kamala vs The State on 9 August, 2024

bus stand by the https://www.mhc.tn.gov.in/judis bus passengers for non availability of bus
services. The said protest took place on 10.02.2024, whereas the detention order states that the
detenu had published the alleged forged information only on 11.02.2024 at 08.41.P.M. The extract
from the impugned detention order is as given below:
“The Contract of Operation & Maintenance of Kalaignar Centenary Bus Terminus
(KCBT) Kilambakkam was awarded to single concessionaire M/s.BVG India Private
Limited, on 23.11.2023. Further, the final Escrow Agreement between the
Concessionaire and CMDA & Letter addressed to CMDA was sent to the following
email addresses of the offices concerned on 04.02.2024 (Sunday) at 05:02 P.M. The
same mail was resent to the corrected mail address on 04.02.2024 (Sunday) at 17:08
and the same was forwarded to the CMIDA email address from the above mail id on
05.02.2024 (Monday) at 11.41 hrs. It was found that the information contained in the
mail was published in M/s.Savukku Media on 11.02.2024 at 08:41 P.M, which was
equivalent to theft of data from a Government organisation. The false news was
shared through the online blog 'Savukku Media' and on Thiru. Savukku Shankar's
Twitter account and You Tube channel 'Savukku https://www.mhc.tn.gov.in/judis
Media' in the by the accused Thiru.Savukku Shankar, based on a false document, to
defame the State and CMDA. The above video was circulated to enhance the views of
the Savukku Shankar's Savukku Media online pages. From that particular day, the
number of channel viewers increased to more than 8,26,383 and subscribers
increased to 5,21,000 to date. The complainant suspects that Savukku Media got
illegal revenue using YouTube/Google by cheating. Later, on 10.02.2024, the
passengers at Chennai's new Karunanidhi Centenary Bus Terminus in Kilambakkam
staged a protest, alleging the non-
availability of buses due to the wrong influence of the above false propagandas. The Government's
State welfare measurements and planning went in vain because people were misguided.”
38. Therefore, a protest happened even before publication of information by the detenu. This clearly
shows inconsistencies in the timeline of events reported in the detention order thereby causing
doubts in the impugned order. Further, there has been clear non-application of mind on the part of
the Detaining Authority. In this particular incident as mentioned in the
https://www.mhc.tn.gov.in/judis Detention Order there was a protest, but there is no mention of
any law and order situation or public disorder.
39. Public disorder cannot include all law and order situations. As stated in the case of Ram
Manohar Lohia vs. State of Bihar and Another2, the Hon'ble Supreme Court held as follows;
“54. We have here a case of detention under Rule 30 of the Defence of India Rules which permits
apprehension and detention of a person likely to act in a manner prejudicial to the maintenance of
public order. It follows that if such a person is not detained public disorder is the apprehended
result. Disorder is no doubt prevented by the maintenance of law and order also but disorder is a
broad spectrum which includes at one end small disturbances and at the other the most serious andA.Kamala vs The State on 9 August, 2024

cataclysmic happenings. Does the expression “public order” take in every kind of disorders or only
some of them? The answer to this serves to distinguish “public order” from “law and order” because
the latter undoubtedly takes in all of them. Public 2 [1965 SCC Online SC 9]
https://www.mhc.tn.gov.in/judis order if disturbed, must lead to public disorder. Every breach of
the peace does not lead to public disorder. When two drunkards quarrel and fight there is disorder
but not public disorder. They can be dealt with under the powers to maintain law and order but
cannot be detained on the ground that they were disturbing public order. Suppose that the two
fighters were of rival communities and one of them tried to raise communal passions. The problem
is still one of law and order but it raises the apprehension of public disorder. Other examples can be
imagined. The contravention of law always affects order but before if can be said to affect public
order, it must affect the community or the public at large. A mere disturbance of law and order
leading to disorder is thus not necessarily sufficient for action under the Defence of India Act but
disturbances which subvert the public order are. A District Magistrate is entitled to take action
under Rule 30(1)(b) to prevent subversion of public order but not in aid of maintenance of law and
order under ordinary circumstances.
55. It will thus appear that just as “public order” in the rulings of this Court (earlier cited)
https://www.mhc.tn.gov.in/judis was said to comprehend disorders of less gravity than those
affecting “security of State”, “law and order” also comprehends disorders of less gravity than those
affecting “public order”. One has to imagine three concentric circles. Law and order represents the
largest circle within which is the next circle representing public order and the smallest circle
represents security of State. It is then easy to see that an act may affect law and order but not public
order just as an act may affect public order but not security of the State. By using the expression
“maintenance of law and order” the District Magistrate was widening his own field of action and was
adding a clause to the Defence of India Rules.” (A) MALICE:
40. The detaining authority had registered both the adverse compliant on the same
day i.e., on 07.05.24. The complaint in Crime No.154 of 2024 was registered after a
lapse of nearly six years, whereas the other complaint in Crime No.155 of 2024 was
pertaining to a derogatory remarks against Women Police Officers given by a social
activist. The manner in which both these complaints were registered one with an
inordinate delay and another https://www.mhc.tn.gov.in/judis which is pertaining to
Police Officers raises several questions as to the intentions behind the detention
order. Further, these two adverse cases do not form a sufficient ground to culminate
into a case of Preventive detention under Act 14 of 1982. Further, the inconsistencies
in ground case also shakes the foundation of the detention order. Hence, in case of
Preventive detention, if there is any doubt, whether rules have been strictly observed,
that doubt must be resolved in favour of the detenu.
41. In the case of Pramod Singla vs. Union of India3, The Hon'ble Supreme Court
expressed a note of caution in exercising the power of Preventive detention laws by
the State. The relevant observations are as produced below:A.Kamala vs The State on 9 August, 2024

“25. Before we deal with the issues framed, we find it important to note that
preventive detention laws in India are a colonial legacy, and have a great potential to
be abused and misused. Laws that have the ability to confer arbitrary powers to the
state, must in all circumstances, be very critically examined, and must be used only in
the rarest of rare cases. In cases of preventive detention, where the detenue is held in
arrest not 3 [2023 SCC Online 374] https://www.mhc.tn.gov.in/judis for a crime he
has committed, but for a potential crime he may commit, the Courts must always give
every benefit of doubt in favour of the detenue, and even the slightest of errors in
procedural compliances must result in favour of the detenue.
48. As has been mentioned above, preventive detention laws in India are a colonial
legacy, and as such, are extremely powerful laws that have the ability to confer
arbitrary power to the state. In such a circumstance, where there is a possibility of an
unfettered discretion of power by the Government, this Court must analyze cases
arising from such laws with extreme caution and excruciating detail, to ensure that
there are checks and balances on the power of the Government.
Every procedural rigidity, must be followed in entirety by the Government in cases of preventive
detention, and every lapse in procedure must give rise to a benefit to the case of the detenue. The
Courts, in circumstances of preventive detention, are conferred with the duty that has been given the
utmost importance by the Constitution, which is the protection of individual and civil liberties. This
act of protecting civil liberties, is not just the https://www.mhc.tn.gov.in/judis saving of rights of
individuals in person and the society at large, but is also an act of preserving our Constitutional
ethos, which is a product of a series of struggles against the arbitrary power of the British state."
42. Preventive Detention law subverts the exercise of an individual's fundamental right. Hence the
Courts need to balance the individual freedoms and the public order. Unless there is a satisfactory
ground to establish an apprehension of disturbance to public order, mere speeches aimed at the
Government cannot be brought under the ambit of Act 14 of 82. These preventive detention laws
ought to be used cautiously and sparingly.
43. The growth of our Great Nation lies in the progress and realisation of the vision of our
Constitution. It is not the intention of our Constitution makers to bridle our freedoms, but rather to
reasonably restrict them to ensure a certain decorum in the society. But as the Nation progresses the
walls of fundamental rights and freedoms must widen and that can be a reality only by a responsible
usage of the freedoms guaranteed to us in the Constitution.
https://www.mhc.tn.gov.in/judis (B) BALANCE BETWEEN INDIVIDUAL RIGHTS AND PUBLIC
ORDER:
44. Further in the case on hand, the detenu claims to be a whistleblower and social media journalist.
In cases where Preventive Detention laws are invoked, the Courts need to balance the individual's
freedoms and rights with Public order.A.Kamala vs The State on 9 August, 2024

45. In the case of Anuradha Bhasin vs. Union of India and Others 4, the Hon'ble Supreme Court
held as follows;
“32. We need to distinguish between the internet as a tool and the freedom of expression through
the internet. There is no dispute that freedom of speech and expression includes the right to
disseminate information to as wide a section of the population as is possible. The wider range of
circulation of information or its greater impact cannot restrict the content of the right nor can it
justify its denial. [refer to Secretary, Ministry of Information & Broadcasting Government of India v.
Cricket Association of Bengal, (1995) 2 SCC 161; Shreya Singhal v Union of India, (2015) 5 SCC 1].
26. ...... Expression through the internet has 4 [AIR 2020 SC 1308]
https://www.mhc.tn.gov.in/judis gained contemporary relevance and is one of the major means of
information diffusion. Therefore, the freedom of speech and expression through the medium of
internet is an integral part of Article 19(1)(a) and accordingly, any restriction on the same must be in
accordance with Article 19(2) of the Constitution.” (C) FREEDOM OF SPEECH AND EXPRESSION:
46. This Court shall never stifle or attempt to strangulate Article 19(1)(a) of the
Constitution of India. The Spirit of Article 19(1)(a) shall be ever evolving and the
reasonable restrictions shall also shift its shape to stay in tune with Article 19(1)(a).
The vision of our Law Makers is to ensure free voice for all and that shall be protected
under the Constitution. The freedom of thought and expression shall be set free and
any individual or State Machinery affected by the views of another shall fetch
appropriate remedy available under relevant Criminal Laws, Cyber Laws and
Defamation Laws instead embarking on indirect censorship by detaining persons
under Goondas Act or unnecessary bridling of Article 19(1)(a) will be a hopeless
pursuit with no end. Further, scope of conflict in decisions may arise so the best
possible remedy for any aggrieved party is to take https://www.mhc.tn.gov.in/judis
appropriate action with the aid of laws in place on commission of offence, if any.
Selective detention of persons, spreading false information is also a threat to
democracy.
47. In the Age of Internet, informations are overflowing from all quarters and
booking each and every person for spreading false information is an impossible
exercise. The threshold shall be to see if the publication of information cause any
threat to public disorder. There are lakhs of people expressing their view in various
forms across various medium. If the State Machinery starts hunting down each and
every views and opinion, the voices will neither be brought down nor will this yield
any viable result.
48. A People's Government as large as such should avoid engaging in such fruitless
actions. We cannot be a democracy, if we receive same plausible views from all the
citizens. There is bound to be discontent, which might be acceptable and
unacceptable, but the duty of the State is much larger than engaging in legal battles to
prevent such unacceptable opinions.A.Kamala vs The State on 9 August, 2024

Choice of reaction is with the individual and the State as large as ours should show restraint, when
reacting to people's opinions. https://www.mhc.tn.gov.in/judis
49. A State going behind each and every social media post or YouTube videos will not change any
one's views instead it will make the people feel stifled of their Right to Speech. The beauty of our
democracy lies in the Constitutionally guaranteed freedom and when the State Machinery
themselves starts stifling with litigations, the people lose a faith in the democracy.
(D) CRITICISM AND UNFAIR OPINION:
50. The Institutions derive powers from the Constitution, which is made by the collective Will of the
People of India are working for the people. Our duty is towards the people of our Great Nation. In
the course of performance of duty, there is bound to be criticism from all quarters and appropriate
remedial measures are to be undertaken, if the dissent holds good. In this process there is also scope
for unacceptable criticism based on false premises and prejudiced views. Can the voices of everyone
be strangulated to curb these small groups spreading unpleasant opinions? The people consuming
information in social media are the best judges of these views and opinions. The Constitutional
Institutions cannot indulge in a process to influence the views of the people. Actions of the
Institution speaks https://www.mhc.tn.gov.in/judis for themselves and the views may come and go.
(E) SOCIAL MEDIA AND HUMAN MIND IN TANDEM WITH FREEDOM OF SPEECH:
51. There is a need to differentiate between views / opinions and facts. In the absence of any
satisfactory ground that the said act caused public disorder, mere publication of false information
cannot constitute an offence under Section 3(1) of Act 14 1982. Question also arises with reference to
expression of one's own opinions / views through social media platforms. How far can these
expressions be made accountable? This gives rise to another relevant question. Whether the social
media opinions influence us or does our already influenced mind search for content that aligns with
our opinions? The choice of viewership is with the consumer. At an innate level, based on the parts
of information at the disposal of a person, he tends to form an opinion based on what he perceives to
be the truth. Once we perceive certain information with our own prejudiced values and morals, we
tend to form an opinion by merging the unverified information with our own inborn principles and
values and we tend to form a judgement about a particular person or the political ideologies or a
political leader or a political party so on https://www.mhc.tn.gov.in/judis and so forth. But this
cannot be ordained as the Truth. It is a 'mind perceived truth' which may differ from one person to
another.
52. Views and opinions are subjective and based on one's own perception of information available at
their disposal. No one can alter or change other's views or opinions. Once the power to change
others views is taken away, a human mind then tries to block their views from reaching others. But
is this the right way to go about? How many views/opinions can be blocked? Can we change the
thoughts of a human mind, we can to some extent curtail the speech and expression but freedom of
thought cannot be touched. It is the most unbridled.A.Kamala vs The State on 9 August, 2024

53. Each and every human mind is different. The information at one's disposal is processed
differently by each mind. The external interference in shaping people's opinions is limited only to
the extent of delivery of information but how the mind processes and takes it further on is purely
subjective and changes from person to person.
54. It is with all these innate perceptions in mind that the viewer states viewing his/her preferred
content on social media. The news content https://www.mhc.tn.gov.in/judis providers post their
own perceptions on the social media platform. So the viewer tends to connect himself/herself to the
content provider, who provides content aligning or affirming his/her own views. Viewers, who find
contradictory content not ascribing to their own notions tend to disregard such content or criticise
such content. This has so far been the basic nature of social media operation in today's scenario. So
addressing the question aforewith, the content provider may not be held solely responsible for
influencing a viewer, It can also be taken in another context that a viewer with a pre conceived
notion has found affirmation in the views of a content provider. So the social media content is not
thrust upon and pressurised into a viewer. The choice to consume a content is always at the disposal
of the viewer. The viewer has a right to know the opinions of a fellow citizen on the policies or
actions of the government or any other institution working for the people. Censorship against such
views is unhealthy for good governance.
55. Dissenting views may be in different mediums, forms, languages. Some may even be unfair and
prejudicial. If an individual feels affected by such views he/she can proceed against such content
https://www.mhc.tn.gov.in/judis providers in manner known to law. But institutions like the State
and its Machinery shall impose restraint, when taking legal course of action against its own citizen.
56. To illustrate further; 'Y' may post a content unfairly criticising a policy of the government which
though a good policy and is in accordance with the laws in force. But 'Y' feels that it is a wrong policy
and has to go. 'A', 'B' and 'C' are viewers watching the content. 'A' agrees with 'Y', 'B' agrees partially
and 'C' does not agree with 'Y'. 'A', 'B', 'C' is believed to have their own views about the said policy.
Can it be said that 'Y' is influencing them against the government thereby causing public disorder
with his opinions.
57. The only difference is that 'Y' freely expressed his views whereas 'A', 'B' and 'C' stopped short of
expressing their views. Instead they chose to agree or disagree with Y's view by sharing the content
with others. Can viewership of such content itself be made an act of inducing public disorder.
Therefore, by taking such stricter construction of content on social media the State is embarking on
a never ending, unproductive journey. The spirit of Article 19(1)(a) will begin to loose its sheen
through such https://www.mhc.tn.gov.in/judis endless narrowing down of its contours. Instead
focus must be placed on allowing a harmonious expansion of Article 19(1)(a) and at the same time
striking a balance through effective regulatory mechanisms not encroaching too far into Article
19(1)(a).
VI. REGULATIONS – THE NEED OF THE HOUR:A.Kamala vs The State on 9 August, 2024

58. Prior to the advent of social media, news were consumed through Television networks / radio /
Print media, which also contained opinions in the form of debates / editorials / columns / articles
etc. In addition to these mediums, social media has evolved as a new space but the mind of a
consumer has operated in a similar manner. People have always engaged in discussion on the
governance and public institutions. Such discussions today have found a wider reach through social
media platforms where everyone have found their own space to express themselves freely. When in
accordance with law, any such speech is protected by Article 19(1)(a). The audience today for such
discussion have increased which is a symbol of healthy democracy. Any such new found space of
freedom tends to take time to subject itself with regulations and rightful restraint. But this cannot be
a sole reason to thwart their exercise of constitutionally guaranteed freedoms.
https://www.mhc.tn.gov.in/judis
59. The regulatory mechanisms for all other mediums has been achieved to a certain extent,
whereas, social media still remains an unregulated space, thereby paving way for more infractions.
The Regulations for the content creators has become essential to curb such violations on other's
rights. It is also an incumbent duty of every citizen to use his/her rights in a responsible manner.
Article 51-A enunciates the fundamental duties of every citizen. The fundamental duties were
imbibed in the Constitution to ensure a harmonious relationship between the citizens of our Great
Nation. Clause (h) thereby emphasises the need for scientific temper, humanism and the spirit of
inquiry and reform. Clause (e) emphasis on the promotion of harmony and the spirit of common
brotherhood amongst all the people of India transcending religious, linguistic and regional or
sectional diversities. Harmony in the worlds largest democracy like ours is an essential prerequisite
in the pursuit of growth. A certain degree of empathy and humanism in the delivery of one's views
and opinions can go a long way in promotion of harmony in the society. The delivery of one's views
with a scientific temper is the goal of our Constitution and not to gag a person's speech altogether.
The reasonable restriction comes into play only when a speech directly causes public disorder or acts
against national security. Mere https://www.mhc.tn.gov.in/judis expression of views in the nature
of political or ideological dissent cannot be viewed as causing public disorder.
60. How far the social media content incites public disorder is left to the subjective satisfaction of
the Scrutinising Authority. But a common test to weigh this is to see as to whether any actual threat
happened to the public order in consequence to a particular speech. Has there been any actual
threat or apprehension of incitement of an offence against the public at large due to a speech or
words used by a person has to be analysed on a case to case basis.
VII. FREEDOM OF PRESS:
61. The value of freedom of Press, which is implicitly enshrined under art 19(1)(a) was well known to
the freedom fighters of our Great Nation. It was the Print media during the colonial era that helped
spread the idea and vision of an Independent India. During pre-independence struggle, efforts were
made to quell this medium but it was the Print media which helped in uniting the people of India to
voice out against the repressive laws and policies of the British governance.
https://www.mhc.tn.gov.in/judisA.Kamala vs The State on 9 August, 2024

62. It is to be noted that in today's scenario, the mode of communication has changed. Technology
has paved way for social media platforms like You Tube, where citizens are able to voice their views
and opinions. Holding an opinion is one's own right and right to divulge one's opinion is also an
element under Freedom of Speech subject to reasonable restriction. The qualities of decency and
responsibility must form an essential aspect of Article 19(1)(a) and any breach of the same attracts
the relevant laws in force. But Preventive Detention laws cannot be used to curb speeches where
there is no disturbance to public order or security of the State. Speeches in order to be attracted
under the Preventive detention laws such as Tamil Nadu Act 14 of 1982 must instil a sense of fear
and harm to the public at large and incite a grave danger to public order. Breach of law and order by
itself cannot be termed as public disorder.
63. The intention of Article 19(1)(a) is to promote more people from expressing their views freely,
without any fear rather than to undermine their voices and thoughts. The Constituent assembly
debates stand testimony to this fact. There were lengthy debates to scale down the restrictions under
https://www.mhc.tn.gov.in/judis Article 19(2) as far as possible to further the agenda of free speech
in an independent India. Many esteemed members of the Constituent assembly felt that the
restrictions might dilute the freedom under Article 19(1)(a) but in order to protect the freedom of
other citizens, the regulation under Article 19(2) was found to be indispensable.
64. Independence was achieved through years of struggle and through the words “Swaraj (Freedom)
is my birth right and I shall have it”. Such words resonated far and wide for years and it was through
the arduous struggle of our freedom fighters that we are able to live in an independent India
envisioned by our forefathers, entrusting us with the Constitution to guide us. This individual
freedom cannot be clamped down at the whims and fancies of the State. Extreme care and caution is
a pre condition to invoke preventive detention laws and must not be used in a routine manner to
suppress fundamental rights of the citizens. Excessive usage of such laws to restrict the right to free
speech will deter other citizens from enforcing their right to criticism or opinions against the State
thereby fracturing the spine of democracy.
https://www.mhc.tn.gov.in/judis
65. Freedom of Speech and expression is an inborn right. The State cannot strangulate it unless it
causes a serious threat to public safety and security. Speeches criticising the ruling government, its
policies and actions or exposing corrupt or illegal actions in the public administration cannot in
itself be termed as threat to 'Public order'.
66. When action curtailing freedom of speech is taken by a State or its Machinery against its citizens,
extreme caution Must be taken and used in the most sparing ways. Such actions against citizens
tend to spread a sense of fear and panic. No person should fear to speak his mind. But in cases
where such strict action is taken, the people will fear to even communicate their views to the
Government thereby inviting a sense of disconnection between the Government and the people. The
Government can handle the social media as an effective tool to understand the grievances of a
common man instead of trying to shut him down.A.Kamala vs The State on 9 August, 2024

67. Instead spreading fear and panic among people by such drastic measures can prove to be a
wrong course of action. Any human being shall be allowed to speak his personal views and opinions,
A free country https://www.mhc.tn.gov.in/judis should always propagate free speech. Reasonable
restrictions is a narrow term and be used in the most sparing way possible.
68. The exchange of views and opinions of citizens about governance of the State is present from
time immemorial. It was through such expression and speeches that the stifled voices found an
awakening during Freedom movement paving way for an Independent India. And in this month of
77th Independence Day celebrations can the voices of the citizens be stifled again? This Court
cannot narrow the walls of Article 19(1)(a). The soul of a healthy democracy lies in free speech.
VIII. CONCLUSION:
69. This Court would like to reminisce on the words of Rabindranath Tagore, “Where the mind is
without fear and the head is held high Where knowledge is free Where the world has not been
broken up into fragments By narrow domestic walls Where words come out from the depth of truth
https://www.mhc.tn.gov.in/judis Where tireless striving stretches its arms towards perfection
Where the clear stream of reason has not lost its way Into the dreary desert sand of dead habit
Where the mind is led forward by thee Into ever-widening thought and action Into that heaven of
freedom, my Father, let my country awake.”
70. In fine, we have arrived at an irresistible conclusion that the impugned order of detention is not
in compliance with the essential requirement and ingredients as contemplated under Act 14 of 1982.
Thus, the Detention Order issued by the 2nd respondent in proceeding No.495/BCDFGISSSV/2024
dated 12.05.2024 is set aside. Consequently, the Habeas Corpus Petition stands allowed. We direct
the detenue / Mr.Shankar @ Savukku Shankar, male, aged 48, S/o Achimuthu, confined at Central
Prison, Coimbatore to be set at liberty forthwith, if he is not required in any other case. Connected
Miscellaneous Petition is closed.
71. The Registry, High Court of Madras is directed to communicate the
https://www.mhc.tn.gov.in/judis advance copy of this Judgement to the Prison Authorities.
                                                               [S.M.S., J.]    [V.S.G., J.]
                                                                        09.08.2024
                Jeni
                Index : Yes
                Speaking order
                Neutral Citation : Yes
                To
                1.The Secretary to Government,
The State, Home, Prohibition and Excise Department, Fort St. George, Chennai – 9.
2.The Commissioner of Police, Greater Chennai, Chennai.A.Kamala vs The State on 9 August, 2024

3.The Inspector of Police, Chennai City CCD-I, Chennai.
4.The Superintendent, Central Prison, Coimbatore.
https://www.mhc.tn.gov.in/judis S.M.SUBRAMANIAM, J.
and V.SIVAGNANAM, J.
Jeni 09.08.2024 https://www.mhc.tn.gov.in/judisA.Kamala vs The State on 9 August, 2024

