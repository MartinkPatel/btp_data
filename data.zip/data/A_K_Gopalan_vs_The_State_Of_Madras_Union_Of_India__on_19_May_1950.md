A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19
May, 1950
Equivalent citations: 1950 AIR 27, 1950 SCR 88, AIR 1950 SUPREME COURT
27, 1963 MADLW 638
Author: Hiralal J. Kania
Bench: Hiralal J. Kania, Saiyid Fazal Ali, Mehr Chand Mahajan, B.K.
Mukherjea
           PETITIONER:
A.K. GOPALAN
        Vs.
RESPONDENT:
THE STATE OF MADRAS.UNION OF INDIA: INTERVENER.
DATE OF JUDGMENT:
19/05/1950
BENCH:
KANIA, HIRALAL J. (CJ)
BENCH:
KANIA, HIRALAL J. (CJ)
FAZAL ALI, SAIYID
SASTRI, M. PATANJALI
MAHAJAN, MEHR CHAND
DAS, SUDHI RANJAN
MUKHERJEA, B.K.
CITATION:
 1950 AIR   27            1950 SCR   88
 CITATOR INFO :
 F          1951 SC 157  (21)
 F          1951 SC 270  (5,6)
 F          1951 SC 301  (10)
 F          1951 SC 332  (344)
 E          1952 SC  75  (45)
 RF         1952 SC 123  (6)
 F          1952 SC 181  (6,27,29,33)
 D          1952 SC 196  (16)
 RF         1952 SC 252  (106)
 R          1952 SC 366  (16)
 E&F        1952 SC 369  (90,93)
 F          1953 SC 451  (7)
 E&F        1954 SC  92  (5,39)
 RF         1954 SC 119  (15)A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

 RF         1954 SC 728  (17)
 R          1955 SC  41  (6)
 F          1956 SC 108  (6)
 R          1957 SC 688  (6,8,9)
 R          1958 SC 163  (7,8,9,25,26,33,36,38,41)
 APL        1958 SC 578  (154,223)
 D          1958 SC 731  (17)
 R          1959 SC 149  (27,82)
 D          1960 SC 430  (10)
 D          1960 SC1080  (25,27,28)
 RF         1961 SC 232  (55)
 R          1961 SC1629  (5)
 R          1962 SC1006  (67,72,79)
 R          1962 SC1371  (32,34,35)
 R          1962 SC1621  (73,108)
 R          1963 SC1047  (18)
 F          1963 SC1295  (15,31)
 F          1964 SC 381  (54)
 R          1965 SC 845  (29,30,44,45)
 E          1966 SC 424  (2,7)
 RF         1966 SC1910  (34)
 R          1967 SC   1  (41,42,75,158)
 APL        1967 SC1639  (7,10)
 R          1967 SC1643  (22,95,230,274)
 R          1967 SC1836  (13,23,53,58)
 E          1968 SC1138  (14)
 E          1968 SC1313  (10)
 RF         1969 SC1100  (7)
 O          1970 SC 564  (48,53,54,64,149,152,153,156)
 RF         1971 SC 481  (46)
 E          1972 SC 963  (35)
 R          1972 SC1660  (7,9)
 RF         1973 SC 106  (105)
 O          1973 SC1425  (7,18,25,27,33,37,38,39)
 RF         1973 SC1461  (24,30,184,310,503,648,699,790
 RF         1973 SC2555  (5)
 F          1974 SC 348  (24)
 R          1974 SC 613  (8,10,31,32,33,34,43,50,51)
 R          1974 SC2154  (21)
 RF         1975 SC 550  (12)
 E          1975 SC 775  (3)
 RF         1975 SC2213  (7)
 RF         1975 SC2299  (135,609,610)
 E          1976 SC1207  (53,55,57)
 RF         1976 SC1750  (3)
 R          1977 SC1027  (23,30,42)
 R          1978 SC  68  (89)
 R          1978 SC 215  (67)
 D          1978 SC 489  (1,9)
 E&R        1978 SC 597  (5,9,10,11,12,16,40,41,54,55,*
 RF         1978 SC1675  (55,227)
 RF         1979 SC 478  (90,159)
 RF         1979 SC 745  (71)A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

 RF         1979 SC1925  (16)
 C          1980 SC 898  (30,41,43,44,47,48,50,51,54)
 RF         1982 SC 710  (17,21,71,84,114)
 MV         1982 SC1325  (16,80)
 RF         1983 SC 361  (2,12,13)
 F          1985 SC1367  (33)
 F          1985 SC1416  (103,104)
 RF         1986 SC 555  (6)
 RF         1986 SC1162  (5)
 R          1990 SC 231  (17)
 RF         1991 SC 564  (5)
 R          1992 SC 320  (51)
 RF         1992 SC1701  (21,26,27)
ACT:
Preventive  Detention  Act   (IV  of  1950),  ss.  8,  7,
10-I4.--Validity--Constitution of India, 1950, Arts. 13,  19
to  22, 32--Law relating to  preventive   detention--Whether
infringes    Fundamental    Right   as   to    freedom    of
movement--Whether subject to judicial review as to  reasona-
bleness  under Art. 19 (5)--Scope of Art. 19--Right of  free
movement and Right to personal liberty, nature and incidents
of--Art.  22, whether complete code as to preventive  deten-
tion--Scope and applicability  of  Art.. 21--"Law,"  "proce-
dure established by law," meanings of--Whether include rules
of natural justice--Construction of Art. 21--American  deci-
sions on "due process of law," value of-Omission to  provide
objective  standard  for  satisfaction  of  authorities,  to
provide  for  oral hearing or leading of  evidence,  to  fix
maximum period of detention, and to specify  "circumstances"
and  "classes  of cases" where period of  detention  may  be
extended over 3 months,  prohibiting  detenu from   disclos-
ing  grounds of detention--Validity of law--Construction  of
Constitution --Reference to  debates  and  Report  of Draft-
ing Committee-Permissibility.
HEADNOTE:
    The  petitioner who was detained under  the   Preventive
Detention Act (Act IV of 1950) applied under Art. 32 of  the
Constitution for a writ of habeas corpus and for his release
from detention, on the ground that the said Act  contravened
the  provisions of Arts. 13, 19, 21 and 22 of the  Constitu-
tion and was consequently ultra rites and that his detention
was therefore illegal:
     Held,  per KANIA C.J., PATANJALI SASTRI, MUKHERJEA  and
DAS  JJ.  (FAZL ALI and MAHAJAN  JJ.  dissentinq)--that  the
preventive  Detention Act, 1950, with the exception of  Sec.
14  thereof  did not contravene any of the Articles  of  the
Constitution  and even though Sec. 14 was ultra rites  inas-
much  as it contravened the provisions of Art. 9.9,  (5)  ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the  Constitution,  as this section was severable  from  the
remaining sections of the Act, the invalidity of Sec. 14 did
not  affect  the  validity of the Act as a  whole,  and  the
detention of the petitioner was not illegal.
     FAZL  ALl and MAHAJAN JJ.--Section 12, of the  Act  was
also  ultra vires, and since it contravened the very  provi-
sion in the
89
Constitution  under which the Parliament derived its  compe-
tence to enact the law, the detention was illegal.
    Held, by the Full Court (KANIA CJ., FAZL ALI,  PATANJALI
SASTRI,  MAHAJAN, MUKHERJEA and DAS JJ.)--Section 14 of  the
Preventive  Detention Act, 1950, contravenes the  provisions
of  Art. 9.9. (5) of  the  Constitution in so  far   as   it
prohibits a person detained from disclosing to the Court the
grounds  on  which a detention order has been  made  or  the
representation  made by him against the order of  detention,
and is to that extent ultra vires and void.
    Per KANIA C.J., PATANJALI SASTRI, MAHAJAN, MUKHERJEA and
DAS JJ. (FAZL ALI J. dissenting).--Article 19 of the Consti-
tution has no application to a law which relates directly to
preventive detention even though as a result of an order  of
detention the rights referred to in sub-cls. (a) to (e)  and
(g) in general, and sub-cl. (d) in particular, of cl. (1) of
Art. 19 may be restricted or abridged; and the constitution-
al  validity  of  a law relating to  such  detention  cannot
therefore, be judged in the light of the test prescribed  in
el. (5) of the said Article.
    DAS  J.--Article 19 (1) postulates a legal  capacity  to
exercise the rights guaranteed by it and if a citizen  loses
the freedom
    of his person by reason of lawful detention as a  result
of a conviction for an offence or otherwise he cannot  claim
the  right s under- sub-cls. (a) to (e) and (g) of  Art.  19
(1);  likewise if a citizen's property is  compulsorily  ac-
quired  under Art. 31, he cannot claim the right under  sub-
el.  (f) of Art. 19 (1) with respect to that  property.   In
short the rights under sub-cls. (a) to (e) and (g) end where
lawful  detention  begins and therefore the  validity  of  a
preventive detention Act cannot be judged by Arc. 19 (5).
MAHAJAN  J.---Whatever be the precise scope of Art.  19  (1)
(d) and Art.19(5) the provisions of Art. 19(5) do not  apply
to  a  law relating to preventive  detention,  inasmuch   as
'there  is  a special self-contained provision  in  Art.  22
regulating it.
    FAZL ALI.J.--Preventive detention is a direct  infringe-
ment  of the right guaranteed in Art. 19 (1) (d), even if  a
narrow construction is placed on the said sub-clause,  and a
law     relating     to     preventive     detention      is
therefore  subject  to such limited judicial  review  as  is
permitted by Art. 19 (5).
     Per KANIA C.J., PATANJALI SASTRI, MUKHERJEA and DAS JJ.
(FAZL ALl J. dissenting).--The concept of the right "to moveA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

freely   throughout  the  territory  of  India" referred  to
in Art. 19 (1) (d), of the Constitution is entirely  differ-
ent  from  the concept of the right  to  "personal  liberty"
referred  to in Art. 21, and Art. 19 should not,  therefore,
be  read  as controlled by the provisions of Art.  21.   The
view that Art. 19 guarantees substantive rights and Art.  21
prescribes  the procedure is incorrect. DAs  J.--Article  19
protects some of the important attributes of personal liber-
ty as independent rights and the expression "personal liber-
ty" is used in Art. 21 as a compendious term
90
including   within   Rs  meaning all  varieties   of  rights
which go to make up the personal liberties of men.
  FAZL  ALl J.--Even if it be assumed that Art. 19  (1)  (d)
does not refer to " personal liberty" and that it bears  the
restricted meaning attributed to it,that is to say, R signi-
fies merely the right to move from one locality to  another,
preventive  detention  must be held to affect  this  limited
right  of movement directly and substantially.  One  of  the
objects  of  preventive detention is to  restrain  a  person
detained from moving from place to place so that he may  not
spread  disaffection or indulge in dangerous  activities  in
the places he visits.  The same consideration applies to the
cases  of  persons  who are interned  or  externed.   Hence,
externment, interment and certain other forms of restriction
on  movement  have always been treated  as  kindred  matters
belonging  to the same group or family, and the  rule  which
applies to one must necessarily apply to the others.
    Per KANIA C. J ,, PATANJALI SASTRI and DAS 35.  (MAHAJAN
3. dissenting).--Article 22 does not form a complete code of
constitutional safeguards relating to preventive  detention.
To the extent that provision is made in Art. 9.9, it  cannot
be controlled by Art. 9,1; but on points of procedure  which
expressly or by necessary implication are not dealt with  by
Art.  22,  Art. 9.1 will apply.  DAS  J.--Art.  21  protects
substantive  rights by requiring a procedure and  Art.  9.9.
lays  down  the  minimum rules of procedure  that  even  the
Parliament cannot abrogate or overlook. MAHAJAN J.--Art. 99.
contains a self-contained code of constitutional  safeguards
relating  to preventive detention and cannot be examined  or
controlled  by  the provisions of Art. 21.   The  principles
underlying  Art. 21 are however kept in view in Art. 22  and
there  is no conflict between these articles.  MUKHERJEA  J.
--Even  assuming that Art. 22 is not a  self-contained  code
relating  to  preventive detention and that  Art.  21  would
apply,  it is .not permissible to supplement Art. 22 by  the
application  of rules of natural justice. FAZL ALI  J.--Art.
22.  does not form an exhaustive code by itself relating  to
preventive  detention.  Parliament can make  further  provi-
sions  and if it has done so Art. 19 (5) may be  applied  to
see  if  those provisions have transgressed  the  bounds  of
reasonableness.
   Per  KANIA C.J., MUKHERJEA and DAS JJ. (FAZL ALI J.  dis-A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

senting).--In Art. 9.1 the word  'law" has been used in  the
sense  of State-made law and not as an equivalent of law  in
the  abstract or general sense embodying the  principles  of
natural  justice; and "procedure established by  law"  means
procedure  established by law made by the State, that is  to
say, the Union Parliament or the Legislatures of the States.
It is not proper to construe this expression in the light of
the meaning given to.the expression "due process of law"  in
the  American Constitution by the Supreme Court of  America.
FATANJALI  SASTRI cl.-- "Law" in Art. 21 does not  mean  the
jus naturale of civil law but means
91
positive or State-made law.  "Procedure established by  law"
does not however mean any procedure which may be  prescribed
by  a  competent legislature, but the  ordinary  well-estab-
lished  criminal procedure, i.e., those settled. usages  and
normal modes of procedure sanctioned by the Criminal  Proce-
dure Code, which is  the  general  law  of  criminal  proce-
dure   in  this country. The only alternative to  this  con-
struction, if a constitutional transgression is to be avoid-
ed  is  to interpret the reference to "law"  as  implying  a
constitutional  'amendment pro tanto, for it is only  a  law
enacted  by the procedure provided for such  amendment  that
could modify or override a fundamental right without contra-
vening Art. 13 (2).
    FAZL, ALI J.--There is nothing revolutionary in the view
that  "procedure established by law "must include  the  four
principles of elementary justice which inhere in and are  at
the  root  of all civilized systems of law, and  which  have
been stated by the American Courts and jurists as consisting
in  (1) notice, (2) opportunity to be heard,  (3)  impartial
tribunal  and  (4) orderly course of procedure.  These  four
principles  are really different aspects of the same  right,
namely, the right to be heard before one is condemned. Hence
the  words  "procedure established by law  ",  whatever  its
exact  meaning  be, must necessarily include  the  principle
that  no  person shall be condemned without  hearing  by  an
impartial tribunal.
    Per KANIA C.J., FAZL ALI, PATANJALI SASTRI, MAHAJAN  and
DAS  JJ.--Section 3 of the Preventive Detention  Act,  1950,
does  not  delegate any legislative power  to  an  executive
officer  but merely confers on such officer a discretion  to
enforce  the law made by the legislature, and is not  there-
fore invalid on this ground.  The fact that the section does
not  provide an objective standard for  determining  whether
the  requirements of law have been complied with, is  not  a
ground for holding that it is invalid. FAZL ALI J.---Section
3 is however a reasonable provision only for the first step,
i.e., for arrest and initial detention and must be  followed
by  some  procedure  for testing  the  so-called  subjective
satisfaction, which can be done only by providing a suitable
machinery  for examining the grounds on which the  order  of
detention is made and considering the representations of theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

persons detained in relation to those grounds.
    Per KANIA C. J., MAHAJAN and DAS JJ.---Section 7 of  the
said  Act is not invalid merely because it does not  provide
for  an oral hearing or an opportunity to lead evidence  but
only gives right to make a representation.  Right to an oral
hearing  and  right  to give evidence  are  not  necessarily
implied in the right to make a representation given by  Art.
22.
    Per KANIA C.J., and MAHAJAN J.--The provision  contained
in Sec. 11 that a person may be detained for such period  as
the
12-A
92
State  thinks fit does not contravene Art. 22 (7) and it  is
not therefore invalid.
    Per  KANIA. C.J., PATANJALI SASTRI, MUKHERJEA  and   DAS
JJ.  (FAZL ALI and MAHAJAN JJ. dissenting).--Article 22  (7)
means that Parliament may prescribe either the circumstances
under  which, or the class or classes of cases in  which,  a
person may be detained for a period longer than three months
without reference to an advisory board. It is not  necessary
that  the  Parliament should prescribe  both.   The  matters
referred  to in clauses (a) and (b) of sub-see. (1) of  Sec.
12 constitute a sufficient description of such circumstances
or classes of cases and Section 12 is not therefore open  to
the objection that it does not comply with Art. 22 (7)   DAS
J.--Parliament  has in act and substance prescribed both  in
clauses (a) and (b) of sub-sec. (1) of Sec. 12.
     FAZL ALI and MAJAN JJ.--Article 22 (7) Means that  both
the  circumstances and the class or classes of cases  (which
are  two different expressions with different  meanings  and
connotations) should be prescribed, and the prescription  of
one  without the other will not be enough.  The  enumeration
of  the subjects for reasons connected with which a  law  of
preventive detention could be made contained in els. (a) and
(b) of sub-see. (1) of Sec.12 does not amount to prescribing
the  circumstances under which, or the class or  classes  of
cases in which, a person can be detained for more than three
months.
    Per  KANIA  C.J.--While it is not proper  to  take  into
consideration the individual opinions of members of  Parlia-
ment  or Convention to construe the meaning of a  particular
clause,  when a question is raised whether a certain  phrase
or  expression  was up for consideration at all  or  not,  a
reference  to  the  debates may  be  permitted.   PATANJAYLI
SASTRI J.--In construing the provisions of an Act,  speeches
made  in the course of the debates on the bill  should   not
be  taken  into consideration.  MUKHERJEA J.--In  construing
the  Constitution it is better to leave out of  account  the
debates in the Constituent Assembly, but a higher value  may
be placed on the report of the Drafting Committee.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

JUDGMENT:
ORIGINAL JURISDICTION: Petition No. XIII of 1950. Application under Art. 32 (1) of the
Constitution of India for a writ of habeas corpus against the detention of the appellant in the Madras
jail in pursuance of an order of detention made under the Preventive Detention Act, 1950. The
material facts of the case and arguments of counsel are set out in detail in the judgments. The
relevant provisions of the Preventive Detention Act, 1950, are printed below.
1. Short title, extent and duration.--This Act may be called the Preventive Detention Act, 1950.
(2) It extends to the whole of India .....
(3) It shall cease to have effect on the 1st day of April, 1951, as respects things done or omitted to be
done before that date.
2. Definitions.--In this Act, unless the context other- wise requires,--
(a) "State Government" means, in relation to a Part C State, the Chief Commissioner of the State;
and
(b) "detention order" means an order made under Section 3.
3. Power to make orders detaining certain persons.--(1) The Central Government or the State
Government may---
(a) if satisfied with respect to any person that with a view to preventing him from acting in any
manner prejudicial to--
(i) the defence of India, the relations of India foreign power, or the security of India, or
(ii) the security of the State or the maintenance of public order, or
(iii) the maintenance of supplies and services to the community, or
(b) if satisfied with respect to any person who is a foreigner within the meaning of the Foreigners
Act, 1946 (XXXI of 1946), that with a view to regulating his continued presence in India or with a
view to making arrangements for his expulsion from India it is necessary so to do, make an order
directing that such person be detained.
(2) Any District Magistrate or Sub-Divisional Magistrate, or Presidency-town, the Commissioner of
Police, may, if satisfied provided in sub-clauses (ii) and (iii) of clause
(a) of sub-section (1), exercise the power conferred by the said sub-section.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(3) When any order is made under this section by a Dis- trict Magistrate, Sub-Divisional Magistrate
or Commissioner of Police, he shall forthwith report the fact to the State Government to which he is
subordinate together with the grounds on which the order has been made and such other particulars
as in his opinion have a bearing on the necessi- ty for the order.
7. Grounds of order of detention to be disclosed to persons affected by the order.--(1) When a person
is de- tained in pursuance of a detention order, the authority making the order shall, as soon as may
be, communicate to him the grounds on which the order his been made, and shall afford him the
earliest opportunity of making a representa- tion against the order, in a case where such order has
been made by the Central Government, to that Government, and in a case where it has been made
by a State Government or an officer subordinate thereto, to the State Government.
11. Confirmation of detention order.--In any case where the Advisory Board has reported that* there
is in Rs opinion suffcient cause for the detention of the person concerned, the Central Government
or the State Government. as the case may be, may confirm the detention order and continue the
detention of the person concerned for' such period as it thinks fit.
12. Duration of detention in certain cases.--(1) Any person detained in any of the following classes of
cases or under 'my of the following circumstances may be detained without obtaining the opinion of
an Advisory Board for a period longer than three months, but not exceeding one year from the date
of his detention, namely, where such person has been detained wish a view to preventing him from
acting in any manner prejudicial to--
(a) the defence of India, relations of India with foreign powers or the security- of India; or
(b) the security of a State or the maintenance of public order. * * *
14. Disclosure of grounds of detention, etc.--(1) No court shall, except for the purpose of a
prosecution for an offence punishable under sub-section (9,), allow any state- ment to be made, or
any evidence to be given. before it of the substance of any communication made under section 7 of
the grounds on which a detention order has been made against any person or of any representation
made by 'him against such order; and notwithstanding anything contained in any other law, no
court shall be entitled to require any public officer to produce before it, or to disclose the substance
of, any such communication or representation made, or the proceedings of an Advisory Board or
that par of the report of an Advisory Board which is confidential.
(2) It shall be an offence punishable with imprisonment for term which may extend to one year, or
with fine, or with both, for any person to disclose or publish without the previous authorisation of
the Central Government or the State Government, as the case may be, any contents or matter
purporting to be contents of any such communication or representation as is referred to in
sub-section (1):
Provided that nothing in this sub-section shall apply to a disclosure made' to his legal
adviser by a person who is the subject of a detention order.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

M. K. Nambiar (S. K. Aiyar and V.G. Rao, with him) for the petitioner.
K. Rajah Aiyar, Advocate-General of Madras (C. R. Pattabi Raman and R. Ganapathi,
with him) lot the State of Madras.
M.C. Setalvad, Attorney-General for India (Jindralal, with him) for the Union of
India.
1950. May 19. The following Judgments were delivered. KANIA C. J--This is a
petition by the applicant under article 32 (1) of the Constitution of India for a writ of
habeas corpus against his detention in the Madras Jail. In the petition he has given
various dates showing how he has been under detention since December, 1947.
Under the ordi- nary Criminal Law he was sentenced to terms of imprisonment but
those convictions were set aside. While he was tires under detention under one of the
orders of the Madras State Government, on the 1st of March, 1950, he was served
with an order made under section 3 (1) of the Preventive Detention Act, IV of 1950.
He challenges the legality of the order as it is contended that Act IV of 1950
contravenes the provisions of articles 13, 19 and 21 and the provisions of that Act are
not in accordance with article 22 of the Con- stitution. He has also challenged the
validity of the order on the ground that it is issued mala fide. The burden of proving
that allegation is on the applicant. Because of the penal provisions of section 14 of the
impugned Act the applicant has not disclosed the grounds, supplied to him, for his
detention and the question of mala fides of the order therefore cannot be gone into
under this petition. The question of the validity of Act IV of 1950 was argued before
us at great length. This is the first case in which the different articles of the
Constitution of India contained in the Chapter on Fundamental Rights has come for
discussion before us. The Court is indebted to the learned counsel for the applicant
and the Attorney-General for their assistance in interpreting the true meaning of the
relevant clauses of the Constitution.
In order to appreciate the rival contentions it is useful first to bear in mind the
general scheme of the Constitution. Under article 53 of the Constitution the executive
power of the Union is vested in the President and is to be exercised by him in
accordance with the Constitution either directly or through officers subordinate to
him. The legislative powers of the Union are divided between the Parliament and
Legislatures of the States. The ambit and limitations on their respective powers are
found in article 246 read with article 245, Schedule VII, Lists 1,2 and 3 of the
Constitution. For the Union of India the Supreme Court is established and its powers
and jurisdiction are set out in articles 124 to 147. This follows the pat- tern of the
Government of India Act, 1935, which was the previous Constitution of the
Government of India. Unlike the American Constitution, there is no article vesting
the judicial power of the Union of India in the Supreme Court. The material points
substantially altering the edifice are first in the Preamble which declares india a
Sovereign Democratic Republic to secure to all its citizens justice, liberty and equalityA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

and to promote among them all, frater- nity. Part III of the Constitution is an
important innova- tion. It is headed "Fundamental Rights." In that Part the word
"State" includes both the Government of the Union and the Government of the
States. By article 13 it is expressly provided that all laws in force in the territory of
India, immediately before the commencement of the Constitution, in so far as they
are inconsistent with the provisions of this Part, to the extent of such inconsistency,
are void. There- fore, all laws in operation in India on the day the Consti- tution came
into force, unless otherwise saved, to the extent they are inconsistent with this
Chapter on Fundamen- tal Rights, become automatically void. Under article 13 (2)
provision is made for legislation after the Constitution comes into operation. It is
there provided that the State shall not make any law which takes away or abridges the
rights conferred by this Part and any law made in contraven- tion of this clause shall
to the extent of the contraven- tion, be void. Therefore, as regards future legislation
also the Fundamental Rights in Part III have to be respected and, unless otherwise
saved by the provisions of the Consti- tution, they will be void to the extent they
contravene the provisions of Part III. Under article 245 (1) the legisla- tive powers
conferred under article 246 are also made "subject to the provisions of this
Constitution," which of course includes Part III dealing with the Fundamental Rights.
The term law in article 13, is expressed to be wide enough to include Acts,
Ordinances, Orders, Bye-laws, Rules, Regulations and even custom or usage having,
in the territory of India, the force of law. The rest of this Part is divided in seven
divisions. "Right to Equality" is found in articles 14-18, "Eight to Freedom"
in articles 19-22, "Right against Exploitation" in articles 23 and 24, "Right to
Freedom of Religion" in articles 25-28, "Cultural and Educational Rights" in articles
29 and 30, "Right to Property" in article 31 and "Right to Constitu- tional Remedies"
in articles 32-35. In this case we are directly concerned only with the articles under
the caption "Right to Freedom" (19-22) and article 32 which gives a remedy to
enforce, the rights conferred by this Part. The rest of the articles may have to be
referred to only to assist in the interpretation of the above-mentioned arti- cles.
It is obvious that by the insertion of this Part the powers of the Legislature and the
Executive, both of the Union and the States, are further curtailed and the right to
enforce the Fundamental Rights found in Part III by a direct application to the
Supreme Court is removed from the legislative control. The wording of article 32
shows that the Supreme Court can be moved to grant a suitable relief, mentioned in
article 32 (2), only in respect of the Funda- mental Rights mentioned in Part III of the
Constitution. The petitioner is detained under a preventive detention order, made
under Act IV of 1950, which has been passed by the Parliament of India. In the
Seventh Schedule of the Constitution, List I contains entries specifying items in
respect of which the Parliament has exclusive legislative powers. Entry 9 is in these
terms: "preventive detention for reasons connected with Defence, Foreign Affairs or
the Security of India; persons subjected to such detention."A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

List III of that Schedule enumerates topics on which both the Union and the States have concurrent
legislative powers. Entry 3 of that List is in these terms: "Preventive detention for reasons connected
with the security of a State, the maintenance of public order or the maintenance of supplies and
services essential to the community; persons subjected to such detention." It is not disputed that Act
IV of 1950 is covered by these two Entries in List I and List III of the Seventh Schedule. The
contention of the peti- tioner is that the impugned legislation abridges or in- fringes the rights given
by articles 19-21 and is also not in accordance with the permissive legislation on preventive
detention allowed under articles 22 (4) and (7) and in particular is an infringement of the provisions
of article 22 (5). It is therefore necessary to consider in detail each of these articles and the
arguments advanced in respect thereof.
Article 19 is for the protection of certain rights of freedom to citizens. It runs as follows :--
"19. (1)--All citizens shall have the right-(a) to free- dom of speech and expression;
(b) to assemble peaceably and without arms;
(c) to form associations or unions;
(d) to move freely throughout the territory of India;
(e) to reside and settle in any part of the territory of India;
(f) to acquire, hold and dispose of property; and
(g) to practise any profession, or to carry on any occupation, trade or business.
"(2) Nothing in sub-clause (a) of clause (1) shall affect the operation of any existing
law in so far as it relates to, or prevent the State from making any law relat-
ing to, libel, slander, defamation, contempt of court or any matter which offends against decency or
morality or which undermines the security of, or tends to overthrow, the State.
(3) Nothing in sub-clause (b) of the said clause shall affect the operation of any existing law in so far
as it imposts, or prevent the State from making any law imposing, in the interests of public order
reasonable restrictions on the exercise of the right con- ferred by the said sub-clause.
(4) Nothing in sub-clause (c) of the said clause shall affect the operation of any existing law in so far
as it imposes, or prevent the State from making any law imposing, in the interests of public order or
morality, reasonable restrictions on the exercise of the right conferred by the said sub-clause.
(5) Nothing in sub-clauses (d), (e) and (f) of the said clause shall affect the operation of any existing
law in so far as it imposes, or prevent the State from making any law imposing, reasonable
restrictions on the exercise of any of the rights conferred by the said sub-clauses either in theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

interests of the general public or for the protection of the interests of any Scheduled Tribe.
(6) Nothing in sub-clause (g) of the said clause shall affect the operation of any existing law in so far
as it imposes, or prevent the State from making any law imposing, in the interests of the general
public, reasonable restric- tions on the exercise of the right conferred by the said sub-clause, and, in
particular, nothing in the said sub- clause shall affect the operation of any existing law in so far as it
prescribes or empowers any authority to prescribe, or prevent the State from making any law
prescribing or empowering any authority to prescribe, the professional or technical qualifications
necessary for practising any pro- fession or carrying on any occupation, trade or business." Clause
(2) specifies the limits up to which the abridge- ment- of the right contained in 19 (1) (a) may be
permitted. it is an exception. Similarly clause (3) sets out the limit of abridgement of the right in 19
(1) (b) and clause (4) specifies such limits in respect of the right in 19 (1) (c). Clause (5) is in respect
of the rights mentioned in 19 (1)
(d), (e) and (f) and clause (6) is in respect of the rights contained in 19 (1) (g). It cannot be disputed
that the articles collected under the caption "Right to Freedom" have to be considered together to
appreciate the extent of the Fundamental Rights. In the first place it is necessary to notice that there
is a distinction between rights given to citizens and persons. This is clear on a perusal of the
provisions of article 19 on the one hand and articles 20, 21 and 22 on the other. In order to
determine whether a right is abridged or infringed it is first necessary to determine the extent of the
right given by the articles and the limitations pre- scribed in the articles themselves permitting its
curtail- ment. The inclusion of article 13 (1) and (2) in the Con- stitution appears to be a matter of
abundant caution. Even in their absence, if any of the fundamental rights was infiringed by any
legislative enactment, the Court has always the power to declare the enactment, to the extent it
transgresses the limits, invalid. The existence of article 13 (1) and (2) in the Constitution therefore is
not material for the decision of the question what fundamental right is given and to what extent it is
permitted to be abridged by the Constitution itself.
As the preventive detention order results in the deten- tion of the applicant in a cell it was
contended on his behalf that the rights specified in article 19 (1) (a), (b),
(c), (d), (e) and (g) have been infringed. It was argued that because of his detention he cannot have a
free right to speech as and where he desired and the same argument was urged in respect of the rest
of the rights mentioned in sub-clauses (b), (c), (d), (e) and (g). Although this argu- ment is advanced
in a case which deals with preventive detention, if correct, it-should be applicable in the case of
punitive detention also to any one sentenced to a term of imprisonment under the relevant section
of the Indian Penal Code. So considered, the argument must clearly be rejected. In spite of the
saving clauses (2)to(6) permitting abridge- ment of the rights connected with each of them, punitive
detention under several sections of the Penal Code, e.g., for theft, cheating, forgery and even
ordinary assault, will be illegal. 'Unless such conclusion necessarily follows from the article, it is
obvious that such construction should be avoided. In my opinion, such result is clearly not the
outcome of the Constitution. The article has to be read without any pre-conceived notions. So read,
it clearly means that the legislation to be examined must be directly in respect of one of the rights
mentioned in the subclauses. If there is a legislation directly attempting to control a citizen'sA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

freedom of speech or expression, or his right to assemble peaceably and without arms, etc., the
question whether that legislation is saved by the relevant saving clause of article 19 will arise. If,
however, the legisla- tion is not directly in respect of any of these subjects, but as a result of the
operation of other legislation, for instance, for punitive or preventive detention, his right under any
of these subclauses is abridged, the question of the application of article 19 does not arise. The true
approach is only to consider the directness of the legisla- tion and not what will be the result of the
detention other- wise valid, on the mode of the detenue's life. On that short ground, in my opinion,
this argument about the in- fringement of the rights mentioned in article 19 (1) gener- ally must fail.
Any other construction put on the article, it seems to me. will be unreasonable.
It was next urged that while this interpretation may meet the contention in respect of rights under
article 19 (1) (a), (b), (c), (e) and (g), the right given by article 19 (1) (d) is left untouched. That
sub-clause expressly gives the right "to move freely throughout the territory of India." It was argued
that by the confinement of the peti- tioner under the preventive detention order his right to move
freely throughout the territory of India is directly abridged and therefore the State must show that
the im- pugned legislation imposes only reasonable restrictions on the exercise of that right in the
interests of the general public or for the protection of the interests of any Sched- uled Tribe, under
article 19 (5). The Court is thus en- joined to inquire whether the restrictions imposed on the
detained person are reasonable in the interests of the general public. Article 14 of the Constitution
gives the right to equality in these terms:
"The State shall not deny to any person equality before the law or the equal
protection of the laws within the territory of India."
It was argued that the words "within the territory of India" are unnecessary in that article because
the Parlia- ment is supreme to make laws operative only within the territory of India. Without those
words also the article will bear the same meaning. Similarly, it was urged that the words "territory of
India" in article 19 (1) (d) may be treated as superfluous, and preventive detention would thus be an
abridgement of the right to move freely. In my opin- ion, this rule of construction itself is faulty.
Because certain words may be considered superfluous (assuming them to be. so in article 14 for the
present discussion) it is quite improper to assume that they are superfluous wherever found in the
rest of the Constitution. On the contrary, in my opinion, reading sub-clause (d) as a whole the words
"territory of India" are very important. What is sought to be protected by that sub-clause is the right
to freedom of movement, i.e., without restriction, throughout the terri- tory of India. Read with their
natural grammatical.. mean- ing the sub-clause only means that if restrictions are sought to be put
upon movement of a citizen from State to State or even within a State such restrictions will have to
be tested by the permissive limits prescribed in clause (5) of that Article. Sub-clause (d) has nothing
to do with detention, preventive or punitive. The Constitution men- tions a right to freedom of
movement throughout the territo- ry of India, Every word of that clause must be given its true and
legitimate meaning and in the construction of a Statute, particularly a Constitution, it is improper.
to omit any word which has a reasonable and proper place in it or to refrain from giving effect to its
meaning. This position is made quite clear when clause (5) is read along with this sub-clause. It
permits the imposition of reasona- ble. restrictions on the exercise of such right either in the interest
of general public or the protection of the interest of any Scheduled Tribe. It is difficult to conceive ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

a reasonable restriction necessary in the interests of the general public for confining a person in a
cell. Such restriction may be appropriate to prevent a person from going from one Province to
another or one area to another, having regard to local conditions prevailing in particular areas. The
point however is made abundantly clear by the alternative, viz., for the protec- tion of the interests
of any Scheduled Tribe. What protec- tion of the interests of a Scheduled Tribe requires the
confinement of a man in a cell ? On the other hand, pre- venting the movement of a person from one
part of the terri- tory of India to another and the question of reasonable restriction imposed to
protect the interests of a Scheduled Tribe is clearly intelligible and often noticed in the course of the
administration of the country. Scheduled Tribes have certain rights, privileges and also disabili- ties.
They have their own civilization, customs and mode of life and prevention of contact with persons or
groups with a particular Scheduled Tribe may be considered undesirable during a certain time or in
certain conditions. The legis- lative history of India shows that Scheduled Tribes have been given a
separate place on these grounds. Reading article 19 as a whole, therefore, it seems to me that it has
no application to a legislation dealing with preventive or punitive detention as its direct object. I
may point out that the acceptance of the petitioner's argument on the interpretation of this clause
will result in the Court being called upon to decide upon the reasonableness of several provisions of
the Indian Penal Code and several other penal legislations as abridging this right. Even under clause
(5), the Court is permitted to apply the test of reasonable- ness of the restrictions or limits not
generally, but only to the extent they are either in the interests of the gener- al public, e.g., in case of
an epidemic, riot, etc., or for the protection of the interests of any Scheduled Tribe. In my opinion,
this is not the intention of the Constitution. Therefore the contention urged in respect of article 19
fails.
It was argued that article 19 and article 21 should be read together as implementing each other.
Article 19 gave substantive rights to citizens while article 21 prescribed that no person can be
deprived of his life and personal liberty except by procedure established by law. Even so, on a true
construction of article 19, it seems to me that both preventive and punitive detention are outside the
scope of article 19. In order to appreciate the true scope of article 19 it is useful to read it by itself
and then to consider how far the other articles in Part HI affect or control its meaning. It is the first
article under the caption "Right to Freedom ." It gives the rights mentioned in 19 (1) (a) to
(g) to all citizens of India. These rights read by them- selves and apart from the controls found in
clauses (2) to (6) of the same article, specify the different general rights which a free citizen in a
democratic country ordi- narily has. Having specified those rights, each of them is considered
separately from the point of view of a similar right in the other citizens, and also after taking into
consideration the principle that individual liberty must give way, to the extent it is necessary, when
the good or safety of the people generally is concerned. Thus the right to freedom of speech and
expression is given by 19 (1) (a). But clause (2) provides that such right shall not prevent the
operation of a law which relates to libel, slander, defamation, contempt of Court or any matter
which offends against decency or morality or which undermines the security of, or tends to
overthrow, the State. Clause (2) thus only emphasizes that while the individual citizen has a free
right of speech or expression, he cannot be permit- ted to use the same to the detriment of a similar
right in another citizen or to the detriment of the State. Thus, all laws of libel, slander, contempt of
Court or laws in respect of matters which offend against decency or morality are reaffirmed to beA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

operative in spite of this individual right of the citizen to freedom of speech and expression. Simi-
larly; that right is also subject to laws which prevent undermining the security of the State or against
activities which tend to overthrow the State. A similar analysis of clauses f3) and (4) shows similar
restrictions imposed on similar grounds. In the same way clause (5) also permits reasonable
restrictions in the exercise of the right to freedom of movement throughout the territory of India,
the right to reside and settle in any part of the territory of India or the right to acquire, hold and
dispose of property, being imposed by law provided such reasonable restrictions on the exercise of
such right are in the inter- est of the general' public. The Constitution further pro- vides by the same
clause that similar reasonable restric- tions could be put on the exercise of those rights for the
protection of the interest of a Scheduled Tribe. This is obviously to prevent an argument being
advanced that while such restriction could be put in the interest of general public, the Constitution
did not provide for the imposi- tion of such restriction to protect the interests of a smaller group of
people only. Reading article 19 in that way as a whole the only concept appears to be that the
specified rights of a free citizen arc thus controlled by what the framers of the Constitution thought
were necessary restric- tions in the interest of the rest of the citizens. Reading article 19 in that way
it appears to me that the concept of the right to move freely throughout the territo- ry of India is an
entirely different concept from the right to "personal liberty" contemplated by article 21. "Person- al
liberty" covers many more rights in one sense and has a restricted meaning in another sense. For
instance, while the right to move or reside may be covered by the expression ,'personal liberty" the
right to freedom of speech (men- tioned in article 19 (1) (a)) or the right to acquire, hold or dispose
of property (mentioned in 19 (1) (f)) cannot be considered a part of the personal liberty of a citizen.
They form part of the liberty of a citizen but the limita- tion imposed by the word "personal"leads
me to believe that those rights are not covered by the expression personal liberty. So read there is no
conflict between articles 19 and 21. The contents and subject matters of articles 19 and 21 are thus
not the same and they proceed to deal with the rights covered by their respective words from totally
different angles. As already mentioned in respect of each of the rights specified in sub-clauses of
article 19 (1) specific limitations in respect of each is provided, while the expression "personal
liberty" in article 21 is generally controlled by the gener- al expression "procedure established by
law." The Constitu- tion, in article 19, and also in other articles in Part III, thus attempts to strike a
balance between individ- ual liberty and the general interest of the society. The restraints provided
by the Constitution on the legislative powers or the executive authority of the State thus operate as
guarantees of life and personal liberty of the individu- als.
Deprivation (total loss) of personal liberty, which inter alia includes the right to eat or sleep when
one likes or to work or not to work as and when one pleases and sever- al such rights sought to be
protected by the expression "personal liberty" in article 21, is quite different from restriction (which
is only a partial control) of the right to move freely (which is relatively a minor right of a citizen) as
safeguarded by article 19 (1) (d). Deprivation of personal liberty has not the same meaning as
restriction of free movement in the territory of India. This is made clear when the provisions of the
Criminal Procedure Code in Chapter VIII relating to security of peace or maintenance of public
order are read. Therefore article 19 (5) cannot apply to a substantive law depriving a citizen of
personal liberty. I am unable to accept the contention that the word "deprivation" includes within its
scope "restriction" when interpreting article 21. Article 22 envisages the law of preventive detention.
So does article 9.46 read with Schedule Seven, List I, Entry 9, and List III, Entry 3. Therefore, whenA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the subject of preventive detention is specifically dealt with in the Chapter on Fundamental Rights I
do not think it is proper to consider a legisla- tion ' permitting preventive detention as in conflict
with the rights mentioned in article 19 (1). Article 19 (1) does not purport to cover all aspects of
liberty or of personal liberty. In that article only certain phases of liberty are dealt with. "Personal
liberty" would primarily mean liberty of the physical body. The rights given under article 19 (1) do
not directly come under that description. They are rights which accompany the freedom or liberty of
the person. By their very nature they are freedoms of a person assumed to be in full possession of his
personal liberty. If article 19 is considered to be the only article safeguarding personal liberty several
well-recognised rights, as for instance, the right to eat or drink, the right to work, play, swim and
numerous other rights and activities and even the right to life will not be deemed protected under
the Constitution. I do not think that is the intention. It seems to me improper to read article 19 as
dealing with the same subject as article 21. Article 19 gives the rights specified therein only to the
citizens of India while arti- cle 21 is applicable to all persons. The word citizen is expressly defined in
the Constitution to indicate only a certain section of the inhabitants of India. Moreover, the
protection given by article 21 is very general. It is of "law"--whatever that expression is interpreted
to mean. The legislative restrictions on the law-making powers of the legislature are not here
prescribed in detail as in the case of the rights specified in article 19. In my opinion there- fore
article should be read as a separate complete article. Article 21 which is also in Part III under the
caption "Right to Freedom" runs as follows :-
"No person shall be deprived of his life or personal liberty except according to
procedure established by law."
This article has been strongly relied upon by the peti- tioner in support of his contention that the
impugned Act is ultra vires the Parliament as it abridges the right given by this article to every
person. It was argued that under the Constitution of the United States of America the corre-
sponding provision is found in the 5th and 14th Amendments where the provision, inter alia, is "that
no person shall be deprived of his life or liberty or property except by due process of law." It was
contended for the petitioner that the Indian Constitution gives the same protection to every person
in India, except that in the 'United States "due process of law" has been .construed by its Supreme
Court to cover both substantive and procedural law, while in India only the protection of procedural
law is guaranteed. It was contend- ed that the omission of the word "due" made no difference to the
interpretation of the words in article 21. The word "established"' was not equivalent to "prescribed".
It had a wider meaning. The word "law" did not mean enacted law because that will be no 'legislative
protection at all. If so construed, any Act passed by the Parliament or the State Legislature, which
was otherwise within its legislative power, can destroy or abridge this right. On the same line of
reasoning, it was argued that if that was the inten- tion there was no necessity to put this as a
fundamental right in Part III at all. As to the meaning of the word "law" it was argued that it meant
principles of natural justice. It meant "jus", i.e., law in the abstract sense of the principles of natural
justice, as mentioned in standard works of Jurisprudence, and not "lex", i.e., enact- ed law. Against
the contention that such construction will leave the meaning vague, it was argued that four
principles of natural justice recognised in all civilized countries were covered, in any event, by the
word "law". They are:A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(1) An objective test, i.e., a certain, definite and ascer-
tainable rule of human conduct for the violation of which one can be detained; (2) Notice of the
grounds of such detention; (3) An impartial tribunal, administrative, judi- cial or advisory, to decide
whether the detention is justi- fied; and (4) Orderly course of procedure, including an opportunity to
be heard orally (not merely by making a written representation) with a right to lead evidence and
call witnesses.
In my opinion, this line of approach is not proper and indeed is misleading. As regards the American
Constitution its general structure is noticed in these words in "The Government of the United
States" by Munro (5th Edition) at page 53: "The architects of 1787 built only the basement. Their
descendants have kept adding walls and windows, wings and gables, pillars and porches to make a
rambling structure which is not yet finished. Or, to change the metaphor, it has a fabric which, to
use the words of James Russell Lowell, is still being 'woven on the roaring loom of time'. That is
what the framers of the original Constitution intended it to be. Never was it in their mind to work
out a final scheme for the government of the country and stereotype it for all time. They sought
merely to pro- vide a starting point." The same aspect is emphasized in Professor Willis's book on
Constitutional Law and Cooley's Constitutional Limitations. In contrast to the American
Constitution, the Indian Constitution is a very detailed one. The Constitution itself provides in
minute details the legislative powers of the Parliament and the State Legisla- tures. The same
feature is noticeable in the case of the judiciary, finance, trade, commerce and services. It is thus
quite detailed and the whole of it has to be read with the same sanctity, without giving undue weight
to Part III or article 246, except to the extent one is legitimately and clearly limited by the other.
Four marked points of distinction between the clause in the American Constitution and article 21 of
the Constitution of India may be noticed at this stage. The first is that in U.S A. Constitution the
word "liberty" is used simpliciter while in India it is restricted to personal liberty. (2) In U.S.A.
Constitution the same protection is given to proper- ty, while in India the fundamental right in
respect of property is contained in article 31. (3) The word "due" is omitted altogether and the
expression "due process of law" is not used deliberately. (4) The word "established" is used and is
limited to "Procedure" in Our article 21. The whole argument of the petitioner is rounded on the
meaning of the word "law" given to it by the Supreme Court of America. It seems unnecessary to
embark on a discussion of the powers and jurisdiction of the Supreme Court of the 'U.S.A. and how
they came to enlarge or abridge the meaning of law in the expression "due process of law". Without
going into details, I think there is no justification to adopt the meaning of the word "law" as
interpreted by the Supreme Court of U.S.A. in the expression "due process of law" merely because
the word "law" is used in article 21. The discussion of the meaning of "due process of law" found in
Willis on Constitutional Law and in Coo- ley's Constitutional Limitations shows the diverse
meanings given to that expression at different times and under dif- ferent circumstances by the
Supreme Court of U.S.A., so much so that the conclusion reached by these authors is that the
expression. means reasonable law according to the view of the majority of the judges of the Supreme
Court at a particular time holding office. It also shows how the meaning of the expression was
widened or abridged in certain decades. Moreover, to control the meaning so given to that
expression from time to time the doctrine of police powers was brought into play. That doctrine,A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

shortly put, is that legislation meant for the good of the people generally, and in which the individual
has to surrender his freedom to a certain extent because it is for the benefit of the people at large,
has not to be tested by the touchstone of the "due process of law" formula.
Our attention was drawn to the debates and report of the drafting committee of the Constituent
Assembly in respect of the wording of this clause. The report may be read not to control the meaning
of the article, but may be seen in case of ambiguity. In The Municipal Council of Sydney v. The
Commonwealth(1), it was thought that individu- al opinion of members of the Convention expressed
in the debate cannot be referred to for the purpose of construing the Constitution. The same opinion
was expressed in United States v. Wong Kim Ark(2). The result appears to be that while it is not
proper to take into consideration the indi- vidual opinions of Members of Parliament or Convention
to construe the meaning of the particular clause, when a ques- tion is raised whether a certain
phrase or expression was up for consideration at all or not, a reference to the debates may be'
permitted. In the present case the debates were referred to to show that the expression "due process
of law"
was known to exist in the American Constitution (1) (1904) 1 Com. L.R. 208. (2) (169)
U.S 649 at 699.
and after a discussion was not adopted by the Constituent Assembly in our Constitution. In
Administrator General of Bengal v. Premlal Mullick(1), a reference to the proceedings of the
Legislature which resulted in the passing of the Act was not considered legitimate aid in the
construction of a particular section. The same reasons were held as cogent for excluding a reference
to such debates in construing an Indian Statute. Resort may be had to these sources with- great
caution and only when latent ambiguities are to be resolved. See Craies' Statute Law (4th Edition)
page 122, Maxwell on Interpretation of Statutes (9th Edition)pp. 28- 29 and Crawford on Statutory
Construction (1940 Edition) p. 379, article 214. A perusal of the report of the drafting committee to
which our attention was drawn shows clearly that the Constituent Assembly had before it the
American article and the expression "due process of law" but they deliberately dropped the use of
that expression from our Constitution.
No extrinsic aid is needed to interpret the words of article 21, which in my opinion, are not
ambiguous.Normally read, and without thinking of other Constitutions, the expression "procedure
established by law" must mean procedure prescribed by the law of the State. If the Indian
Constitution wanted to preserve to every person the protection given by the due process clause of
the Ameri- can Constitution there was nothing to prevent the Assembly from adopting the phrase, or
if they wanted to limit the same to procedure only, to adopt that expression with only the word
"procedural" prefixed to "law." However, the correct question is what is the right given by article 21 ?
The only right is that no person shall be deprived of his life or liberty except according to procedure
established by law. One may like that right to cover a larger area, but to give such a right is not the
function of the Court; it is the function of the Constitution. To read the word "law" as meaning rules
of natural justice will land one in (1) (1895)L.R. 221. A. 107. 15 difficulties because the rules of
natural justice, as re- gards procedure, are nowhere defined and in my opinion the Constitution
cannot be read as laying down a vague standard. This is particularly so when in omitting to adoptA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"due process of law" it was considered that the expression "procedure established by law" made the
standard specific. It can not be specific except by reading the expression as meaning procedure
prescribed by the legislature. The word "law" as used in this Part has different shades of meaning
but in no other article it appears to bear the indefinite meaning of natural justice. If so, there
appears no reason why in this article it should receive this peculiar meaning. Article 31 which is also
in Part III and relates to the fundamental rights in respect of property runs as follows :-
"No person shall be deprived of his property save by authority of law."
It is obvious that in that clause "law" must mean enact- ed law. The object of dealing with property
under a differ- ent article appears more to provide the exceptions found in article 31 (2) to (6),
rather than to give the word "law" a different meaning than the one given in article 21. The world
"established" according to the Oxford Dictionary means "to fix, settle, institute or ordain by
enactment or agree- ment." The word "established" itself suggests an agency which fixes the limits.
According to the dictionary this agency can be either the legislature or an agreement between the
parties. There is therefore no justification to give the meaning of "jus" to "law" in article 21.
The phrase "procedure established by law" seems to be borrowed from article 31 of the Japanese
Constitution. But other articles of that Constitution which expressly pre- serve other personal
liberties in different clauses have to be read together to determine the meaning of "law" in the
expression "procedure established by law." These articles of the Japanese Constitution have not
been incorporated in the Constitution of India in the same language. It is not shown that the word
"law" means "jus" in the Japanese Constitution. In the Japanese Constitution these rights claimed
under the rules of natural justice are not given by the interpretation of the words "procedure
established by law" in their article 31. The word "due" in the expression "due process of law" in the
American Consti- tution is interpreted to mean "just," according to the opinion of the Supreme
Court of U.S.A. That word imparts jurisdiction to the Courts to pronounce what is "due" from
otherwise, according to law. The deliberate omission of the word "due" from article 21 lends
strength to the conten- tion that the justiciable aspect of "law", i.e., to consider whether it is
reasonable or not by the Court, does not form part of the Indian Constitution. The omission of the
word "due", the limitation imposed by the word "procedure" and the insertion of the word
"established" thus brings out more clearly the idea of legislative prescription in the expres- sion used
in article 21. By adopting the phrase "procedure established by law" the Constitution gave the
legislature the final word to determine the law.
Our attention was drawn to The King v. The Military Governor of the Hair Park Camp ('), where
articles 6 and 70 of the Irish Constitution are discussed. Under article 6 it is provided that the liberty
of the person is inviolable and no person shall be deprived of such except "in accord- ance with law"
......In article 70 it is provided that no one shall be tried "save in due course of law" and extraor-
dinary Courts were not permitted to be established except the Military Courts to try military
offences. The expres- sion "in accordance with law" was interpreted to mean not rules of natural
justice but as the law in force at the time. The Irish Court gave the expression "due course of law" the
meaning given to it according to the English law and not the American law. It was observed by Lord
Atkin in Eshugbayi Eleko v. Officer Administering the Government of Nigeria C), that in accordanceA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

with British Jurispru- dence no member of the executive can interfere with the liberty or property of
a British subject except when he can support the legality of his act before a Court of justice. (1)
[1924] 2 Irish Reports K.B. 104. (2) [1931] A.C. (62 at 670.
In The King v. The Secretary of State for Home Affairs(1), Scrutton LJ. observed: "A man
undoubtedly guilty of murder must yet be released if due forms of law have not been followed in his
conviction." It seems very arguable that in the whole set-up of Part III of our Constitution these
principles only remain guaranteed by article 21. A detailed discussion of the true limits of article 21
will not be necessary if article 22 is considered a code to the extent there are provisions therein for
preventive detention. In this. connection it may be noticed that the articles in Part III deal with
different and separate rights. Under the caption "Right to Freedom" articles 19--22 are grouped but
each with a separate marginal note. It is obvious that article 22 (1) and (2) prescribe limita- tions on
the right given by article 21. If the procedure mentioned in those articles is followed the arrest and
detention contemplated by article 22 (1) and (2), although they infringe the personal liberty of the
individual, will be legal, because that becomes the established legal proce- dure in respect of arrest
and detention. Article 22 is for protection against arrest and detention in certain cases, and runs as
follows :--
"22. (1) No person who is arrested shall be detained in custody without being
informed, as soon as may be, of the grounds for such arrest nor shall he be denied the
right to consult, and to be defended by, a legal practitioner of his choice.
(2.) Every person who is arrested and detained in custo- dy shall be produced before
the nearest magistrate within a period of twenty-four hours of such arrest excluding
the time necessary for the journey from the place of arrest to the Court of the
magistrate and no such person shall be detained in custody beyond the said period
without the authority of a magistrate.
(3) Nothing in clauses (1) and (2) shall apply(a) to any person who for the time being
is an enemy alien; or (1) (1923) 2 K.B. 361 at 382.
(b) to any person who is arrested or detained under any law providing for preventive
detention.
(4) No law providing for preventive detention shall authorize the detention of a
person for a longer period than three months unless-
(a) an Advisory Board consisting of persons who are, or have been, or are qualified to
be appointed as, Judges of a High Court, has reported before the expiration of the
said period of three months that there is in its opinion suffi-
cient cause for such detention:A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Provided that nothing in this sub-clause shall authorise the detention of any person
beyond the maximum period prescribed by any law made by Parliament under
sub-clause
(b) of clause 17); or
(b) such person is detained in accordance with the provisions of any law made by
Parliament under subclauses
(a) and (b) of clause (7).
(5) When any person is detained in pursuance .of an order made under any law
providing for preventive detention, the authority making the order shall, as soon as
may be, communicate to such person the grounds on which the order has been made
and shall afford him the earliest opportunity of making a representation against the
order.
Nothing in clause (5) shall require the authority making any such order as is referred to in that
clause to disclose facts which such authority considers to be against the public interest to disclose.
(7) Parliament may by law prescribe-
(a) the circumstances under which, and the class or classes of cases in which, a person may be
detained for a period longer than three months under any law providing for preventive detention
without obtaining the opinion of an Advisory Board in accordance with the provisions of sub- clause
(a) of clause (4);
(b) the maximum period for which any person may ,in any class or classes of cases be detained
under any law provid- ing for preventive detention; and
(c) the procedure to be followed by an Advisory Board in an inquiry under sub-clause (a) of clause
(4)." The learned Attorney-General contended that the subject of preventive detention does not fall
under article 21 at all and is covered wholly by article 22. According to him, article 22 is a complete
code. I am unable to accept that contention. It is obvious that in respect of arrest and detention
article 22 (1) and (2) provide safeguards. These safeguards are excluded in the case of preventive
detention by article 22 (3), but safe- guards in connection with such detention are provided by
clauses (4) to (7) of the same article. It is therefore clear that article 21 has to be read as
supplemented by article 22. Reading in that way the proper mode of construc- tion will be that to the
extent the procedure is prescribed by article 22 the same is to be observed; otherwise article 21 will
apply. But if certain procedural safeguards are expressly stated as not required, or specific rules on
certain points of procedure are prescribed, it seems im- proper to interpret these points as not
covered by article 22 and left open for consideration under article 21. To the extent the points are
dealt with, and included or excluded,, article 22 is a complete code. On the points of procedure
which expressly or by necessary implication are not dealt with by article 22, the operation of articleA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

21 will remain unaffected. It is thus necessary first to look at article 22 (4) to (7) and next at the
provisions 0 the impugned Act to determine if the Act or any of its provi- sions are ultra vires. It may
be noticed that neither the American nor the Japanese Constitution contain provisions permitting
preventive detention,. much less laying down limitations on such right of detention, in normal
timeS, i.e., without a declaration of emergency. Preventive deten- tion in normal times,. i.e., without
the existence of an emergency like war,. is recognised as a normal topic of legislation in List I. Entry
9, and List III, Entry 3, of the Seventh Schedule. Even in the Chapter on Fundamental Rights article
22 envisages legislation in respect of pre- ventive detention in normal times. The provisions of
article 22 (4) to (7) by their very wording leave unaffected the large powers of legislation on this
point and emphasize particularly by article 22 (7) the power of the Parliament to deprive a person of
a right to have his case considered by an advisory board. Part III and.
article 22 in particular are the only restrictions on that power and but for those provisions the power
to legislate on this subject would have been quite unrestricted. Parliament could have made a law
without any safeguard or any procedure for preventive detention. Such an autocratic supremacy of
the legislature is certainly cut down by article 21. There- fore, if the legislature prescribes a
procedure by a validly enacted law and such procedure in the case of preventive detention does not
come in conflict with the express provi- sions of Part III or article 22 (4) to (7), the Preventive
Detention Act must be held valid notwithstanding that the Court may not fully approve of the
procedure prescribed under such Act.
Article 22 (4) opens with a double negative. Put in a positive form it will mean that a law which
provides for preventive detention for a period longer than three months shall contain .a provision
establishing an advisory board, (consisting of persons with the qualifications mentioned in
sub-clause (a)), and which has to report before the expira- tion of three months if in its opinion
there was sufficient cause for such detention. This clause, if it stood by itself and without the
remaining provisions of article 22, will apply both to the Parliament and the State Legislatures. The
proviso to this clause further enjoins that even though the advisory board may be of the opinion that
there was sufficient cause for such detention, i.e., detention beyond the period of three months, still
the detention is not to be permitted beyond the maximum period, if any, prescribed by Parliament
under article 22 (7) (b). Again the whole of this sub-clause is made inoperative by article 22 (4) (b)
in respect of an Act of preventive detention passed by Parlia- ment under clauses (7) (a) .and (b).
Inasmuch as the im- pugned Act is an Act of the Parliament purported to be so made, clause 22 (4)
has no operation and may for the present discussion be kept aside. Article 22 prescribes that when
any person under a preventive detention law is detained, the authority making the order shall, as
soon as may be, commu- nicate to such person the grounds on which . the order has been made and
shall afford him the earliest opportunity of making a representation against the order. This clause is
of general operation in respect of every detention order made under any law permitting deten- tion.
Article 22 (6) permits the authority making the order to withhold disclosure of facts which such
authority consid- ers against the public interest to disclose. It may be noticed that this clause only
permits the non-disclosure of facts, and reading clauses (5) and (6) together a distinc- tion is drawn
between facts and grounds of detention. Article 22 (4) and (7) deal not with the period of detention
only but with other requirements in the case of preventive detention also. They provide for the
establishment of an advisory board, and the necessity of furnishing grounds to the detenue and alsoA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

to give him a right to make a represen- tation. Reading article 22 clauses (4) and (7) together it
appears to be implied that preventive detention for less than three months, without an advisory
board, is permitted under the Chapter on Fundamental Rights, provided such legislation is within
the legislative competence of the Parliament or the State Legislature, as the case may be. Article 22
(5) permits the detained person to make a representation. The Constitution is silent as to the person
to whom it has to be made, or how it has to be dealt with. But that is the procedure laid down by the
Constitution. It does not therefore mean that if a law made by the Parliament in respect of
preventive detention does not make provision on those two points it is invalid. Silence on these
points does not make the impugned Act in contravention of the Constitution because the first
question is what are the rights given by the Constitution in the case of preventive detention. The
contention that the representation should be to an outside body has no support in law. Even in the
Liversidge case the representation had to be made to the Secretary of State and not to another body.
After such representation was made, another advisory board had to consider it, but it was not
necessary to make the represen- tation itself to a third party. Article 22 (4) and (7) permit the
non-establishment of an advisory board expressly in a parliamentary legislation-
providing for preventive detention beyond three months. If so, how can it be urged that the
nonestablishment of an advisory. board is a fundamental right violated by the procedure prescribed
in the Act passed by the Parliament? The important clause to be considered is article 22 (7).
Sub-clause (a) is important-for this case. In the case of an Act of preventive detention passed by the
Parliament this clause contained in the Chapter on Fundamental Rights, thus permits detention
beyond a period of three months and ex- cludes the necessity of consulting an advisory board, if the
opening words of the sub-clause are complied with. Sub- clause (b) is permissive. It is not obligatory
on the Parliament to prescribe any maximum period. It was argued that this gives the Parliament a
right to allow a person to be detained indefinitely. If that construction is correct, it springs out of the
words of sub-clause (7) itself and the Court cannot help in the matter. Subclause (c) permits the
Parliament to lay down the procedure to be followed by the advisory board in an inquiry under
sub-clause (a) of clause (4). I am unable to accept the contention that article 22 (4) (a) is the rule
and article 22 (7) the exception. I read them as two alternatives provided by the Constitution for
making laws on preventive detention.
Bearing in mind the provisions of article 22 read with article 246 and Schedule VII, List I, Entry 9,
and List III, Entry 3, it is thus clear that the Parliament is empowered to enact a law of preventive
detention (a) for reasons connected with defence, (b) for reasons connected with foreign affairs, (c)
for reasons connected with the security of India; and (under List III), (d) for reasons connected with
the security of a State, (e) for reasons connected with the maintenance of public order, or (f) for
reasons connect- ed with the maintenance of supplies and services essential to the community.
Counsel for the petitioner has challenged the validity of several provisions of the Act. In respect of
the construction of a Constitution Lord Wright in James v. The Commonwealth of Australia(1), (1)
(1936) A. 0. 578 at 614.
observed that "a Constitution must not be construed in any narrow and pedantic sense." Mr. Justice
Higgins in Attorney-General of New South Wales v. Brewery Employees' Union (1), observed:
"Although we are to interpret words of the Constitution on the same principles of interpretation asA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

we apply to any ordinary law, these very principles of interpretation compel us to take into account
the nature and scope of the Act that we are interpreting--to remember that it is a Constitution, a
mechanism under which laws are to be made and not a mere Act which declares what the law is to
be." In In re The Central Provinces and Berar Act XIV of 1938 ("'), Sir Maurice Gwyer C.J. after
adopting these observations said: "especially is this true of a Federal Constitution with its nice
balance of jurisdictions. I conceive that a broad and liberal spirit should inspire those whose duty it
is to interpret it; but I do not imply by this that they are free to stretch or pervert the lan- guage of
the enactment in the interest of any legal or con- stitutional theory or even for the purpose of
supplying omissions or of correcting supposed errors." There is considerable authority for the
statement that the Courts are not at liberty to declare an Act void because in their opinion it is
opposed to a spirit supposed to pervade the Constitution but not expressed in words. Where the
funda- mental law has not limited, either in terms or by necessary implication, the general powers
conferred upon the Legisla- ture we cannot declare a limitation under the notion of hav- ing
discovered something in the spirit of the Constitution which is not even mentioned in the
instrument. It is diffi- cult upon any general principles to limit the omnipotence of the sovereign
legislative power by judicial interposition, except so far as the express words of a written
Constitution give that authority. It is also stated, if the words be positive and without ambiguity,
there is no authority for a Court to vacate or repeal a Statute on that ground alone. But it is only in
express constitutional provisions limiting legislative power and controlling the temporary will of a
majority by a permanent and (1) (1908) 6 Com. L.R. 469 at 611-12. (2) (1939) F.C.R. 18 at 37.
paramount law settled by the deliberate wisdom of the nation that one can find a safe and. solid
ground for the authority of Courts of justice to declare void ,any legislative enact- ment. Any
assumption of authority beyond this would be to place in the hands of the judiciary powers too great
and too 'indefinite either for its own security. or the protection of private rights.
It was first argued that by section 3 the Parliament had delegated its legislative power to the
executive officer in detaining a person on his being satisfied of its necessi- ty. It was urged that the
satisfaction must be of the legislative body. This contention of delegation of the legislative power in
such cases has been considered and rejected in numerous cases by our Federal Court and by the
English Courts. It is unnecessary to refer to all those cases. A reading of the various speeches in
Liversidge v. Anderson clearly negatives this contention. Section 3 of the impugned Act is no
delegation of legislative power to make laws. It only confers discretion on the officer to enforce the
law made by the legislature. Section 3 is also impugned on the ground that it does not provide an
objective standard which the Court can utilize for determining whether the requirements of law have
been complied with. It is clear that no such objective standard of conduct can be pre- scribed, except
as laying down conduct tending to achieve or to avoid a particular object. For preventive detention
action must be taken on good suspicion. It is a subjective test based on the cumulative effect of
different actions, perhaps spread over a considerable period. As observed by Lord Finlay in The King
v. Halliday (2), a Court is the least appropriate tribunal to investigate the question whether
circumstances of suspicion exist warranting the restraint on a person. The contention is urged in
respect of preventive detention and not punitive detention. Before a person can be held liable for an
offence it is obvious that he should be in a position to know what he may do or not do, and an
omission to do or not to do will result in the State (1) (1942) A.C. 2C6. (2) (1917) A.C. 260 at 269.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

considering him guilty according to the penal enactment. When it comes however to preventive
detention, the very purpose is to prevent the individual not merely from acting in a particular way
but, as the sub-heads summarized above show, from achieving a particular object. It will not be
humanly possible to tabulate exhaustively all actions which may lead to a particular object. It has
therefore been considered that a punitive detention Act which sufficiently prescribes the objects
which the legislature considers have not to be worked up to is. a sufficient standard to prevent the
legislation being vague. In my opinion, therefore, the argument of the petitioner against section 3 of
the impugned Act fails. It was also contended that section 3 prescribes no limit of time for detention
and therefore the legislation is ultra vires. The answer is found in article 22 (7) (b). A perusal of the
provisions of the impugned Act moreover shows that in section 12 provision is made for detention
for a period longer than three months but not exceeding one year in respect of clauses (a) and (b) of
that section. It appears therefore that in respect of the rest of the clauses mentioned in section 3
(1)(a)the detention is not contem- plated to be for a period longer than three months, and in such
cases a reference to the advisory board under section 9 is contemplated.
Section 7 of the Act which is next challenged, runs on the same lines as article 22 (5) and. (6) and in
my opinion infringes no provision of the Constitution. It was argued that this gave only the right of
making a representation without being heard 'orally or without affording an opportu- nity to lead
evidence and therefore was not an orderly course of procedure, as required by the rules of natural
justice. The Parliament by the Act has expressly given a right to the person detained under a
preventive detention order to receive the grounds for detention and also has given him a right to
make a representation. The Act has thus complied with the requirements of article 22 (s). That
clause, which prescribes what procedure has to be followed as a matter of fundamental right, is
silent about the person detained having a right to be heard orally or by a lawyer. The Constituent
Assembly had before them the provisions of clause (1) of the same article. The Assembly having
dealt with the requirements of receiving grounds and giving an opportunity to make a
representation has deliberately refrained from providing a right to be heard orally. If so, I do not
read the clause as guarantee- ing such right under article 22 (5). An "orderly course of procedure" is
not limited to procedure which has been sanc- tioned by settled usage. New forms of procedure are
as much, held even by the Supreme Court of America, due process of law as old forms, provided they
give a person a fair opportunity to present his case. It was contended that the right to make a
representation in article 22 (5) must carry with it a right to be heard by an independent tribunal;
otherwise the making of a representation has no substance because it is not an effective remedy. I
am unable to read clause (5) of .article 22 as giving a fundamental right to be heard by an
independent tribunal. The Constitution deliberately stops at giving the right of representation. This
is natural because under article 22 (7), in terms, the Constitution permits the making of a law by
Parliament in which a reference to an advisory board may be omitted. To consider the right to make
a representation as necessarily including a right to be heard by an independent judicial,
administrative or advisory tribunal will thus be directly in conflict with the express words of article
22 (7). Even according to the Supreme Court of U.S.A. a right to a judicial trial is not absolute. In the
United States v. Ju Toy (1), a question arose about the exclusion from entry into the States, of a
Chinese who claimed to be a citizen of the United States. At page 263 the majority judgment con-
tains the following passage :--" If for the purpose of argument, we assume that the Fifth Amendment
applies to him, and that to deny entrance to a citizen is to deprive him ,of liberty, we neverthelessA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

are of opinion that with regard to him due process of law does not require judicial trial: That is the
result of the cases which we have cited, and the almost necessary result of the (1) (198) U.S. 253 at
263.
power of the Congress to pass exclusion laws. That the decision may be entrusted to an executive
officer, and that his decision is due process of law, was affirmed and ex- plained in several cases. It is
unnecessary to repeat the often-quoted remarks of Mr. Justice Curtis, speaking for the whole Court,
in Den Exden Murray v. Hoboken Land and Im- provement Company (1), to. show that the
requirement of a judicial trial does not prevail in every case." Again, I am not prepared to accept the'
contention that a right to be heard orally is an essential right of proce- dure even according to the
rules of natural justice. The right to make a defence may be admitted, but there is nothing to support
the contention that an oral interview is compulsory. In the Local Government Board v. Arlidge (2),
the respondent applied to the Board constituted under the Housing Act to state a special case for the
opinion of the High Court, contending that the order was invalid because (1) the report of the
Inspector had been treated as a confi- dential document and had not been disclosed to the respond-
ent, and (2) because the Board had declined to give the respondent an opportunity of being heard
orally by the person or persons by whom the appeal was finally decided. The Board rejected the
application. Both the points were urged before the House of Lords on appeal. Viscount Haldane L.C.
in his speech rejected the contention about the necessity of an oral hearing by observing "But it does
not follow that the procedure of every tribunal must be.the same. In the case of a Court of law
tradition in this country has prescribed certain principles to which, in the main, the procedure must
conform. But what that procedure is to be in detail must depend on the nature of a tribunal." In
rejecting the contention about the disclosure of the report of the Inspector, the Lord Chancellor
stated: "It might or might not have been useful to disclose this report, but I do not think that the
Board was bound to do so. any more than it would have been bound to disclose all the minutes made
on the papers in the office before (1) 18 HO.W. 272 at 280. (2) (1915) A.C. 120.
a decision was come to ...... What appears to me to have been the fallacy of the judgment of the
majority in the Court of appeal is that it begs the question at the begin- ning by setting up the test of
the procedure of a Court of justice instead of the other standard which was laid down for such cases
in Board of Education v. Rice (1). I do not think the Board was bound to hear the respondent orally
provided it gave him the opportunities he actually had." In spite of the fact that in England the
Parliament is supreme I am unable to accept the view that the Parliament in making laws, legislates
against the well-recognised principles of natural justice accepted as such in all civilized countries.
The same view is accepted in the United States in Federal Communications Commission v. WJR The
Goodwill Station (2). A right to lead evidence against facts suspected to exist is also not essential in
the case of preventive deten- tion. Article 22 (6) permits the non-disclosure of facts. That is one of
the clauses of the Constitution dealing with fundamental rights. If even the non-disclosure of facts is
permitted, I fail to see how there can exist a right to contest facts by evidence and the noninclusion
of such procedural right could make this Act invalid. Section 10 (3) was challenged on the ground
that it excludes the right to appear in person or by any lawyer before the advisory board and it was
argued that this was an infringement of a fundamental right. It must be noticed that article 22 (1)
which gives a detained person a right to consult or be defended by his own legal practitioner is
specifically excluded by article 22 (3) in the case of legislation dealing with preventive detention.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Moreover,. the Parliament is expressly given power under article 22 (7)
(c) to lay down the procedure in an inquiry by an advisory board. This is also a part of article 22
itself. If so, how can the omission to give a right to audience be considered
-against the constitutional rights ? It was pointed out that section 10 (3) prevents even the
disclosure of a (1) (1911) A.C. 179. (2) 337 U.S. 265 at 276.
portion of the report and opinion of the advisory board.. It was argued that if so how can the
detained person put forth his case before a Court and challenge the conclusions ? This argument was
similarly advanced in Local Government Board v. Arlidge (1) and rejected, as mentioned above. In
my opinion, the answer is in the provision found in article 22 (7) (c) of the Constitution of India.
It was argued that section 11 of the impugned Act was invalid as it permitted the continuance of the
detention for such period as the Central Government or the State Govern- ment thought fit. This
may mean an indefinite period. In my opinion this argument has nos substance because the Act has
to be read as a whole., The whole life of the Act is for a year and therefore the argument that the
detention may be for an indefinite period is unsound. Again, by virtue of article 22 (7)(b), the
Parliament is not obliged to fix the maximum term of such detention. It has not so fixed it, except
under section 12, and therefore it cannot be stated that section 11 is in contravention of article 22
(7). Section 12 of the impugned Act is challenged on the ground that it does not conform to the
provisions of article 22 (7). It is argued that article 22 (7) permits preventive detention beyond three
months, when the Parliament pre- scribes "the circumstances in which, and the class or class- es of
cases in which," a person may be detained. It was argued that both these conditions must be
fulfilled. In my opinion, this argument is unsound, because the words used in article 22 (7)
themselves are against such interpretation. The use of the word "which" twice in the first part of the
sub-clause, read with the comma put after each, shows that the legislature wanted these to be read
as disjunctive and not conjunctive. Such argument might have been possible (though not necessarily
accepted) if' the article in the Constitution was "the circumstances. and the class or class- es of cases
in which ...... "I have. no doubt that by the clause, as worded, the legislature-
(1) (1915) A.C. 120.
intended that the power of preventive detention beyond three months may be exercised either if the
circumstances in which, or the class or classes of cases in which, a person is suspected or
apprehended to be doing the objectionable things mentioned in the section. This contention
therefore fails.
It was next contended that by section 12 the Parliament had provided that a person might be
detained for a period longer than three months but not exceeding one year from the date of his
detention, without obtaining the opinion of an advisory board, with a view to prevent him from
acting in any manner prejudicial to (a) the defence of India, rela- tions of India with foreign powers
or the security of India; or (b)the security of a State or the maintenance of public order. It must be
noticed that the contingency provided in section 3 (1) (a) (iii), viz., the maintenance of supplies andA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

services essential to the community is omitted in sec- tion 12. Relying on the wording of these two
sub-sections in section 12, it was argued that in the impugned Act the wording of Schedule VII List I,
Entry 9, and List III, Entry 3, except the last part, are only copied. This did not comply with the
requirement to specify either the circum- stances or the class or classes of cases as is necessary to be
done under article 22 (7) of the Constitution. Circum- stances ordinarily mean events or situation
extraneous to the actions of the individual concerned, while a class of cases mean determinable
groups based on the actions of the individuals with a common aim or idea. Determinable may be
according to the nature of the object also. It is obvious that the classification can be by grouping the
activities of people or by specifying the objectives to be attained or avoided. The argument advanced
on behalf of the petitioner on this point does not' appeal to me because it assumes that the words of
Schedule VII List I, Entry 9, and List III, Entry 3 are never capable of being considered as circum-
stances or classes of cases. In my opinion, that assumption is not justified, particularly when we
have to take into consideration cases of preventive detention and not of conviction and punitive
detention. Each of the expressions used in those entries is capable of complying with the
requirement of mentioning circumstances or classes of cases. The classification of cases, having
regard to an object, may itself amount to a description of the circumstances. It is not disputed that
each of the entries in the Legislative Lists in the Seventh Schedule has a specific connotation well
understood and ascertainable in law. If so, there appears no reason why the same expression when
used in section 12 (1) (a) and (b) of the impugned Act should not be held to have such specific
meaning and thus comply with the requirement of prescribing circumstances or classes of cases.
This argument therefore must be rejected. Section 13(2) was attacked on the ground that even if a
detention order was revoked, another detention order under section 3 might be made against the
same person on the same grounds. This clause appears to be inserted to prevent a man being
released if a detention order was held invalid on some technical ground. There is nothing in the
Chapter on Fundamental Rights and in article 21 or 22 to prevent the inclusion of such a clause in a
parliamentary legislation, permitting preventive detention. Article 20 (2) may be read as a contrast
on this point.
Dealing with the four fundamental principles of natural justice in procedure claimed by the
petitioner, it is thus clear that in respect of preventive detention no question of an objective
standard of human conduct can be laid down. It is conceded that no notice before detention can be
claimed by the very nature of such detention. The argument that after detention intimation of the
grounds should be given has been recognised in article 22 (5) and incorporated in the impugned Act.
As regards an impartial tribunal, article 22 and (7) read together give the Parliament ample
discretion. When in specified circumstances and classes of cases the preventive detention exceeds
three months, the absence of an advisory board is expressly per- mitted by article 22 (7). Under
article 22 (4) it appears implied that a provision for such tribunal is not necessary if the detention is
for less than three months. As regards an opportunity to be heard, there is no absolute natural right
recognised in respect of oral representation. It has been held to depend on the nature of the
tribunal. The right to make a representation is affirmed by the Constitution in article 22 (5) and
finds a place in the impugned Act. The right to an orderly course of procedure to the extent it is
guaranteed by article 22 (4) read with article 22 (7) (c), and by article 22 (7) (a) and (b), has also
been thus provided in the Act. It seems to me therefore that the petitioner's contentions even on
these points fail. Section 14 was strongly attacked on the ground that it violated all principles ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

natural justice and even in- fringed the right given by article 22 (5) of the Constitu- tion. It runs as
follows:
"14. (1) No Court shall, except for the purposes of a prosecution for an offence
punishable under subsection (2), allow any statement to be made, or any evidence to
be given, before it of the substance of any communication made under section 7 of
the grounds on which a detention order has been made against any person or of any
representation made by him against such order; and, notwithstanding anything
contained in any other law, no Court shall be entitled to require any public officer to
produce before it, or to disclose the substance of, any such communication or
representation made, or the proceedings of an Advisory Board or that part of the
report of an Advisory Board which is confidential. (2) It shall be an offence
punishable with imprisonment for a term which may extend to one year, or with fine,
or with both, for any person to disclose or publish without the previous authorisation
of the Central Government or the State Government, as the case may be, any contents
or matter purporting to be contents of any such communication or representation as
is referred to in sub-section (1):
Provided that nothing in this sub-section shall apply to a disclosure made to his legal
adviser by a person who is the subject of a detention order."
By that section the Court is prevented (except for the purpose of punishment for such disclosure)
from being in- formed, either by a statement or by leading evidence, of the substance of the grounds
conveyed to the detained person under section 7 on which the order was made, or of any
representation made by him against such order. It also prevents the Court from calling upon any
public officer to disclose the substance of those grounds or from the produc- tion of the proceedings
or report of the.advisory board which may be declared confidential. It is clear that if this provision is
permitted to stand the Court can have no material before it to determine whether the detention is
proper or not. I do not mean whether the grounds are suffi- cient or not. It even prevents the Court
from ascertaining whether the alleged grounds of detention have anything to do with the
circumstances or class or classes of cases men- tioned in section 12 (1) (a) or (b). In Machindar
Shivaji Mahar v. The King (1), the Federal Court. held that the Court can examine the grounds given
by the Government to see if they are relevant to the object which the legislation has in view. The
provisions of article 22 (5) do not exclude that right of the Court. Section 14 of the impugned Act
appears to be a drastic provision. which re- quires considerable support to sustain it in a preventive
detention Act. The learned Attorney-General urged that the whole object of the section was to
prevent ventilation in public of the grounds and the representations, and that it was a rule of
evidence only which the Parliament could prescribe. I do not agree. This argument is clearly not
sustainable on the words of article 22 clauses (5) and (6). The Government has the right under
article 22 (6)not to disclose facts which it considers undesirable to disclose in the public interest. It
does not permit the Government to refrain from disclosing grounds which fall under clause (5). (1)
[1949-50] F.C.R. 827.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Therefore, it cannot successfully be contended that the disclosure of grounds may be withheld from
the Court in public interest, as a rule of evidence. Moreover, the position is made clear by the words
of article 22 (5). It provides that the detaining authority shall communicate to such detained person
the grounds on which the order has been made. It is there fore ,essential that the grounds must be
connected with the order of preventive detention. If they are not so .connected the requirements of
article 22 (5) are not ,complied with and the detention order will be invalid. Therefore, it is open to a
detained person to contend before a Court that the grounds on which the order' has been made have
no connection at all with the order, or have no connec- tion with the circumstances or class or
classes of cases under which a preventive detention order could be supported under section 12. To
urge this argument the aggrieved party must have a right to intimate to the Court the grounds given
for the alleged detention and the representation made by him. For instance, a person is served with
a paper on which there are written three stanzas of a poem or three alphabets written in three
different ways. For the validity of the detention order it is necessary that the grounds should be
those on which the order has been made. If the detained person is not in a position to put before the
Court this paper, the Court will be prevented from considering whether the requirements of article
22 (5) are complied with and that is a right which is guaranteed to every person. It seems to me
therefore that the provisions .of section 14 abridge the right given under article 22 (5) and are there-
fore ultra vires.
It next remains to be considered how far the invalidity of this section affects the rest of the
impugned Act. The impugned Act minus this section can remain unaffected. The omission of this
section will not change the nature or the structure or the object of the legislation. Therefore the
decision that section 14 is ultra vires does not affect the validity of the rest of the Act. In my opinion
therefore Act IV of 1950, except .section 14, is not ultra vires. It does not infringe any provisions of
Part III of the Constitution and the con- tention of the applicant against the validity of that Act
except to the extent of section 14, fails. The petition therefore fails and is dismissed.
FAZL ALI J.--The question to be decided in this case is whether 'the Preventive Detention Act, 1950
(Act IV of 1950), is wholly or in part invalid and whether the peti- tioner who has been detained
under that Act is entitled to a writ in the nature of habeas corpus on the ground that his detention is
illegal. The question being a pure question of law can he decided without referring to a long chain of
facts which are narrated in the petitioner's application to this Court and which have a more direct
bearing on the alleged mala fides of the authorities who have detained him than on the validity of
the Act.
The Act which is impugned was enacted by the Parliament on the 26th February, 1950, and will
cease to have effect on the 1st April, 1951, save as respects. things done or omit- ted to be done
before that date. The main provisions of the Act are set out in sections 7, 8, 9, 10,11, 12 and 14.
Section a (1) provides that "the Central Government or the State Government may-
(a) if satisfied with respect to any person that with a view to preventing him from acting in any
manner prejudicial to-
(i) the defence of India, the relations of India with foreign powers, or the security of India, orA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(ii) the security of the State or the maintenance of public order, or
(iii) the maintenance of supplies and services essential to the community, or
(b) if satisfied with respect to any person who is. a foreigner within the meaning of the Foreigners
Act, 1946 (XXXI of 1946), that with a view to regulating his continued presence in India or with a
view to making arrangements for his expulsion from India, it is necessary so to do, make an order
directing that such person be detained."
Sub-sections (2) and (3) of this section empower a District Magistrate, Sub-Divisional Magistrate or
the Com- missioner of Police in a Presidency Town to exercise the power conferred by and make the
order contemplated in sub- section (1), but with the qualification that any order made thereunder
must be reported forthwith to the Government of the State to which the .officer in question is
subordinate with the grounds on which the order has been made and such other particulars as in his
opinion have a bearing on the necessity for the order. Section 7 of the Act provides that the authority
making an order of detention shall as soon as may be communicate to the person detained the
grounds on which the order has been made and shall afford him the earliest opportunity of making a
representation against the order, in a case where such ,order has been made by the Central
Government, to that Government, and in a case where it has been made by a State Government or
an officer subor- dinate thereto, to the State Government. Section 8 provides that the Central
Government and each State Government shall, whenever necessary, constitute one or more advisory
boards for the purposes of the Act, and state the qualifications of persons of which the board should
consist. Section 9 pro- vides that when a detention order has been made with a view to preventing a
person from acting in any manner prejudicial to the maintenance of supplies and services essential
to the community or if it is made in regard to a person who is a foreigner within the meaning of the
Foreigners Act with a view to regulating his continued presence in India or making arrangements for
his expulsion from India, the grounds on which the order has been made and the representation, if
any,. of the person detained shall, within six weeks from the date of detention, be placed 'before an
advisory regard. It will be noticed that this section does not provide that the cases of persons who
are detained under section 3 (1)
(a) (i) and (ii) will also be placed before the advisory board. Section 10 lays down the procedure to be
followed by. the advisory board and section 11 provides that in any case where the advisory board
has reported that there is sufficient cause for the detention of the person concerned, the detention
order may be confirmed and the detention of the person concerned may be continued for such
period as the Central Government or the State Government, as the case may be, thinks fit. Section
12,. which is a very important section, as we shall presently see, runs as follows :--
"12 (1) Any person detained in any of the following classes of cases or under any of
the following circumstances may be detained without obtaining the opinion of an
Advisory Board for a period longer than three months, but not exceed- ing one year
from the date of his detention, namely, where such person has been detained with a
view to preventing him from acting in any manner prejudicial to-A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(a) the defence of India, relations of India with foreign powers or the security of
India; or
(b) the security of a State or the maintenance of public order.
(2) The case of every person detained under a detention order to which the provisions
of sub-section (1) apply shall, within a period of six months from the date of his
detention, be reviewed where the order was made by the Central Government or a
State, Government, by such Govern-
ment, and where the order was made by any officer specified in sub-section (2) of section 3, by the
State Government to which such officer is subordinate, in consultation with a person who is or has
been or is qualified to be appointed as Judge of a High Court nominated in that behalf by the Cen-
tral Government or the State Government, as the case may be."
Section 14, which is also a material section for the purpose of this case, is to the following effect :--
"(1) No Court shall, except for the purposes of' a prosecution for an offence
punishable under subsection (2), allow any statement to be made, or any evidence to
be given, before it of the substance of any communication made under section 7 of
the grounds on which a detention order has been made against any person or of any
representation made by him against such order; and, not-
withstanding anything contained in any other law, no Court shall be entitled to require any public
officer to produce before it, or to disclose the substance of, any such commu- nication or
representation made, or the proceedings of an Advisory Board or that part of the report of an
Advisory Board which is confidential.
(2) It shall be an offence punishable with imprisonment for a term which may extend to one year, or
with fine, or with both, for any person to disclose or publish without the previous authorisation of
the Central Government or the State Government, as the case may be, any contents or matter
purporting to be the contents of any such communication or representation as is referred to in
sub-section (1):
Provided that nothing in this sub-section shall apply to a disclosure made to his legal
adviser by a person who is the subject of a detention order."
The point which has been pressed before us is that the Act is invalid, as it takes away
or abridges certain funda- mental rights conferred by Part III of the Constitution of
India, and in support of this general proposition, reliance is placed on article 13 (2)
which runs as follows :-
"The State shall not make any law which takes away or abridges the rights conferred
by this Part and any law made in contravention of this clause shall, to the extent ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the contravention, be void."
The rights guaranteed under Part III of the Constitution are classified under seven broad heads, as
follows :--
(1) Right to equality;
(2) Right to freedom;
(3) Right against exploitation;
(4) Right to freedom of religion;
(5) Cultural and educational rights;
(6) Right to property; and (7) Right to constitutional remedies.
Most of the articles which are said to have been disre- garded occur under the heading "Right to
freedom," these articles being articles 19 (1) (d), 21 and 22. Another article which is also said to have
been violated is article 32, under which the present application for a writ of habeas corpus purports
to have been made.
Article 19 (1)is divided into seven sub-clauses and runs as follows:-
"All citizens shall have the right-
(a) to freedom of speech and expression;
(b) to assemble peaceably and without arms;
(c) to form associations or unions;
(d) to move freely throughout the territory of India;
(e) to reside and settle in any part of the territory of India; "
(f) to acquire, hold and dispose of property; and
(g) to practise any profession, or to carry on any occupation, trade or business."
Clauses (2), (3), (4), (5) and (6) of this article pro- vide that nothing in clause (1) shall affect the
operation of any existing law in regard to the rights under that clause, under certain conditions
which are mentioned there- in. Clause (5), with which we are directly concerned and which will
serve as a specimen to show the nature of these provisions, is to the following effect :--A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"Nothing in sub-clauses (d), (e) and (f)of the said clause shall affect the operation of
any existing law in so far as it imposes, or prevent the State from making any law
imposing, reasonable restrictions on the exercise of any of the rights conferred by the
said sub-clauses either in the interests of the general public or for the protection 'of
the interests of any Scheduled Tribe."
The contentions advanced on behalf of the petitioner with reference to this article are :--(1) that the
Act under which he has been detained deprives him who is a citizen of the Republic of India of the
right to move freely throughout the territory of India, which is guaran- teed under article 19 (1) (d),
and (2) that under clause (5) of article 19, it is open to this Court to judge whether the restrictions
imposed by the Act on the exercise of the right conferred by article 19 (1) (d) are reasonable or
otherwise. Before dealing with this argument, it is necessary to understand the meaning of the
words used in article 19 (1)(d) and to have a clear compre- hension as to the true nature of the right
conferred there- under. The contention put forward on behalf of the peti- tioner is that freedom of
movement is the essence of person- al liberty and any restraint on freedom of movement must be
held to amount to abridgment or deprivation of personal liberty, as the case may be, according to
the nature of the restraint. After very careful consideration, I have come to the conclusion that this
contention is well-founded in law. Blackstone in his "Commentaries on the Laws of England" (4th
Edition, volume 1, page 134) states that "personal liberty consists in the power of locomotion, of
changing .'situation or moving one's person to whatsoever place one's own incli- nation may direct,
without imprisonment or restraint unless by due course of law." The authority of this state- ment
has never been questioned, and it has been bodily incorporated by H.J. Stephen in his
"Commentaries on the Laws of England" and has been reproduced by Cooley in his well-known
treatise on "Constitutional Limitations" (8th Edition, volume 1, page 710), which was extensively
quoted by both parties in the course of their arguments. The view that freedom of movement is the
essence of personal liberty will also be confirmed by reference to any book on the criminal law of
England dealing with the offence of false imprisonment or any commentary on the Indian Penal
Code dealing with the offences of wrongful restraint or confine- ment. Russell in his book on
"Crimes and Misdemeanours" (8th Edition, volume 1, page 861), dealing with the offence of false
imprisonment states as follows :--
"False imprisonment is unlawful and total restraint of the personal liberty of another,
whether by constraining him or compelling him to go to a particular place or by
confin- ing him in a prison or police station or private place, or by detaining him
against his will in a public place ........... the essential element in the offence is the
unlawful detention of the person or the unlawful restraint on his liberty. Such
interference with the liberty of another's movements is unlawful, unless it may be
justified ...... "
Again, Dr. Gour in dealing with the offence of wrongful restraint in his book on "The Penal Law of
British India"
(5th Edition, page 1144) observes as follows :--A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"Following the principle that every man's person is sacred and that it is free, law
visits with its penalties those who abridge his personal liberty, though he may have
no design upon his person. But the fact that he controls its movements for ever so
short a time is an offence against the King's peace, for no one has the right to molest
another in his free movements."
Dealing with the offence of wrongful confinement, the same learned author observes as follows at
page 1148 of his book :--
"'Wrongful confinement' is a species of ' wrongful restraint' as defined in the last
section. In wrongful restraint, there is only a partial suspension of one's liberty of
locomotion, while in wrongful confinement there is a total suspension of liberty
'beyond certain circum- scribing limits'."
Both these authors speak of restraint on personal liber- ty and interference with the liberty of one's
movements or suspension of liberty or locomotion as interchangeable terms. In Bird v. Jones (1),
Coleridge J. said that "it is one part of the definition of freedom to be able to go whithersoever one
pleases." A similar opinion has been expressed by several authors including Sir Alfred Denning in
his book entitled "Freedom under the Law." There can there- fore be no doubt that freedom of
movement is in the last analysis the essence of personal liberty, and just as a man's wealth is
generally measured in this country in terms of rupees, annas and pies, one's personal liberty
depends upon the extent of his freedom of movement. But it is contended on behalf of the State that
freedom of move- (1) 7 Q.B. 742.
ment to which reference has been made in article 19 (1) (d) is not the freedom of movement to which
Blackstone and other authors have referred, but is a different species of freedom which is qualified
by the words "throughout the territory of India." How the use of the expression "throughout the
territory of India" can qualify the meaning of the rest of the words used in the article is a matter
beyond my compre- hension. In my opinion, the words "throughout the territory of India" were used
to stretch the ambit of the freedom of movement to the utmost extent to which it could be guaran-
teed by our Constitution. The Constitution could not guar- antee freedom of movement outside the
territorial limits of India, and so has used those words to show that a citizen was entitled to move
from one corner of the country to another freely and without any obstruction. "Throughout" is an
amplifying and not a limiting expression, and I am sur- prised to find that the expression
"throughout the territory of India," which was used to give the widest possible scope to the freedom
of movement, is sought to be construed as an expression limiting the scope and nature of the
freedom. In my opinion, the words "throughout the territory of India,"
having regard to the context in which they have been used here, have the same force
and meaning as the expression "to whatsoever place one's own inclination may
direct" used by Blackstone, or the expression "freedom to be ,able to go
whithersoever one pleases" used by Coleridge J. in Bird v. Jones (1). I am certain that
neither of these authorities contemplated that the freedom of movement which is
vouch- safed to a British citizen, is guaranteed beyond the terri- torial limits ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

British territories.
The question as to whether preventive detention is an encroachment on the right
guaranteed by article 19 (1) (d) has been considered by the Nagpur, Patna and
Calcutta High Courts. The view which has .been ultimately adopted by these High
Courts is that preventive detention is not a violation of the right guaranteed by article
19 (1) (d), but, in the Calcutta (1) 7 Q.B. 742.
High Court, where the matter has been elaborately discussed, at least five Judges have held that it
does, and in the ultimate analysis the number of Judges. who have held the contrary view appears to
be the same. Having regard to the fact that the view expressed by so many learned Judges is
opposed to the view I am inclined to take, I consider it necessary to deal briefly with the main
objections which have been raised in support of the narrow meaning sought to be attached to the
words in article 19 (1)(d). I have already dealt with one of them which is based on the ex- pression
"throughout the territory of India." A. nd I shall now proceed to deal with the, others seriatim. I. It
will be recalled that clause (5) of article 19, which I have already quoted in full, provides among
other things that nothing in clause (1) (d) shall affect the operation of any law, present or future,
imposing reasonable restrictions on the exercise of the right of freedom of movement either in the
interests of the general public or for the protection of the interests of any Scheduled Tribe. It has
been argued that the use of the words "interests of any Scheduled Tribe" in this clause shows that
the right guaranteed by article 19 (1) (d) is a limited right of movement, such as the right to visit
different localities and to go from one place to another and is different from the expression "freedom
of movement" which has been stated by Blackstone to be another name for personal liberty. It is
pointed out that the restrictions in contemplation here are mainly restrictions preventing
undesirable outsiders from visiting Scheduled Areas and exploiting Scheduled Tribes, and if the
words "freedom of movement" had been used in the larger sense, such a small matter would not
have found a place in clause (5) of article 19..
I must frankly confess that I am unable to appreciate this argument and to hold that a mere
reference to Scheduled Tribes affects the plain meaning of the words used in clause (1) (d) of article
19. The words used in article 19 (1) (d) are very wide and mean that a person can go at his will in any
direction to any locality and to any distance. Re- straint on a freedom.
so wide in scope and extent may assume a variety of forms and may include internment or
externment of a person, his confinement to a particular locality or within the walls of a prison, his
being prevented from visiting or staying in any particular area, etc. The framers of the Constitution
wanted to save all restrictive legislation affecting freedom of movement made in the interests of the
general public (which expression means the same thing as "public interests") and I think that the
law in regard to preventive detention is fully covered by the expression "restrictions imposed in the
public interests." But they also remembered that there were restrictive laws made in the interests of
an important community and that similar laws may have to be made in future and hence they added
the words "for the protection of the interests of any Scheduled Tribe." A reference to the Fifth
Schedule of the Constitution and the corresponding provisions of the Government of India Act,
1935, as well as to certain laws made for Chota Nagpur, Santhai Pargangs and .other localities willA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

show that great importance has been attached in this country to. the protec- tion and preservation of
the members of the scheduled tribes .and maintenance of order in tribal areas, and this, in my
opinion, is sufficient to account for the special mention of the scheduled tribes in clause (5). It may,
at first sight, appear to be a relatively small matter, but in their anxiety to cover the whole field of
restrictive laws made whether in the public interest or in the interests of a particular community and
not to leave the smallest loophole, the framers of the Constitution apparently decided to draft the
clause in the present form. As far as I am aware, there are no restrictive laws made in the interests of
any commu- nity other than the scheduled tribes, and I think clause (5)is sufficiently comprehensive
to include the smallest as well as the most complete restrictions on freedom of move- ment. I am
also satisfied that the mere mention of sched- uled tribes in clause (5) cannot change, the plain
meaning of the words of the main provision which we find in article 19 (1) (d) and confine it to some
kind of peculiar and truncated freedom of movement which is unconnected with personal liberty
and which is unknown to any Constitution with which. we are familiar:
It will perhaps be not out of place to refer in this. connection to Ordinance XIV of
1943, which is one of the ordinances by which the Defence of India Act, 1939, was
partly amended. This ordinance provides for--
"the apprehension and detention in custody of any person whom the authority
empowered by the rules to appre- hend or detain as the case may be suspects, on
grounds appearing to such authority-to be reasonable, of being of hostile origin, or of
having acted, acting, being about to act, or being likely to act in a manner prejudicial
to the public safety or interest, the defence of British India, the maintenance of public
order, His Majesty's relations with foreign powers or Indian States, the maintenance
of peaceful conditions in tribal areas or the efficient prosecution of the war, or with
respect to whom such authority is satisfied that his apprehension and detention are
necessary for the purpose of preventing him from acting in any such prejudi- cial
manner, the prohibition of such person from entering or residing or remaining in any
area, and the compelling of such person to reside and remain in any area, or to do or
abstain from doing anything."
The points to be noted in connection with the ordinance are :--
(1) that it is an ordinance specifically providing for apprehension and detention;
(2) that notwithstanding the fact that there is a gener-
al reference in it to acts prejudicial to public safety or interests and maintenance of public order
there is also a specific reference to maintenance of peaceful conditions in tribal areas;
(3) that tribal areas and scheduled tribes are, kindred subjects as would appear from the Fifth
Schedule appended to the Constitution; and (4) that maintenance of peaceful conditions in tribal
areas may be as much in the public interest as in the inter- ests of persons living in those areas.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

This ordinance shows at least this much that sometimes the law of preventive detention can also be
made in the interests of scheduled tribes or scheduled areas and conse- quently the mere mention of
scheduled tribes in clause (5) does not necessarily exclude laws relating to preventive detention
from the scope of article 19 (5) The same remarks apply to the ordinance called "The Restriction and
Detention Ordinance, 1944" (Ordinance No. III of 1944) which empow- ered the Central
Government or the Provincial Government to detain and make orders restricting the movements of
certain persons in the interest of public safety, maintenance of public order as well as maintenance
of peaceful conditions in tribal areas, etc. II. It is also argued that since preventive detention
amounts to a total deprivation of freedom of movement, it is not a violation of the right granted
under article 19 (1)
(d) in regard to which the word "restriction" and not "deprivation" has been used in clause (5). This
argument also does not appeal to me. There are really two questions which fall to be decided in this
case, viz., (a) Does pre- ventive detention take away the right guaranteed by article 19 (1) (d)?; and
(b) if so, what are the consequences, if any ?
It seems obvious to me that preventive detention amounts to a complete deprivation of the right
guaranteed by article (19) (d). The meaning of the word "restriction" is to be considered with
reference to the second question and I think that it will be highly technical to argue that deprivation
of a right cannot be said to involve restriction on the exercise of the right. In my opinion, having
regard to the context in which the word "restriction" has been used, there is no antithesis between
that word and the word "depriva- tion." As I have already stated, restraint on the right to move can
assume a variety of forms and restriction would be the most appropriate expression to be' used in
clause (5) so as to cover all those forms ranging from total to various kinds of partial deprivation
freedom of movement. I will however have to advert to this subject later and will try to show that the
construction I have suggested is supported by good authori- ty.
III. It appears that some of the Judges who had to deal with the question which we have before us
were greatly influenced by the argument that if the deprivation of per- sonal liberty amounts to
deprivation of the right granted under article 19 (1) (d), any conviction for an offence under the
Indian Penal Code involving a sentence of impris- onment will be subject to judicial review on the
ground of reasonableness of the provisions of the Code under which the conviction is recorded.
Meredith C.J. of the Patna High Court has given expression to his concern for the situation which
will thereby arise, in these words :--
"It will be seen that the claim made is very sweeping indeed. It would mean that every
law under which a person may be imprisoned, including all the provisions of the
Penal Code, is open to examination by the Courts on the ground of reasonableness. It
makes the Courts supreme arbiters in regard to any such legislation, and they can
reject it-or accept it in accordance with their ideas of whether it appeals to their
reason. But ideas of reasonableness or otherwise are apt to vary widely. Take for
example, laws relating to prohibition or take such a matter as adultery which the
Indian law regards as a crime punishable with imprisonment but the English law
does not. It is difficult to believe the framers of the Constitution ever intended toA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

place so enormous a power in the hands of the Courts ................"[Rattan Roy v. The
State of Biharl. The obvious and strictly legal reply to this argument is that the
consideration, which has so greatly weighed with the learned Chief Justice, is not
enough to cut down the plain meaning of the general words used in article 19 (5) of
the Constitution. As has been pointed out in a number of cases, "in construing
enacted words, we are not concerned with the policy involved or with the results
injurious or otherwise which may follow by giving effect to the language
-used" [King Emperor v. Benoari Lal Sharma and others (1)I Apart from this aspect of
the matter, I agree with one of the learned Judges Of the Calcutta High Court in his
remark that "no calamitous or untoward result will follow even if the provisions of
the Penal Code become justiciable." I am certain that no Court would interfere with a
Code which has been the law of the land for nearly a century and the provisions of
which are not in conflict with the basic principles of any system of law. It seems to me
that this Court should not be deterred from giving effect to a fundamental right
granted under the Constitution, merely because of a vague and unfounded fear that
something catas- trophic may happen.
I have so far proceeded on the assumption that the basis of the objection raised by
Meredith C.J. is correct in law, but, in my opinion, it is not. Crime has been defined
to consist in those acts or omissions involving breach of a duty to which a sanction is
attached by law by way of pun- ishment or pecuniary penalty in the public interests.
(See Russell's "Crimes and Misdemeanours "). Section 2 of the Indian Penal Code,
1860, provides that "every person shall be liable to punishment under this Code' and
not otherwise for every act or omission contrary to the provisions there- of, of which
he shall be guilty within British India ." The Indian Penal Code does not primarily or
necessarily impose restrictions on the freedom of movement, and it is not correct to
say that it is a law imposing restrictions on the right to move freely. Its primary object
is to punish crime and not to restrict movement. The punishment may consist in
imprisonment or a pecuniary penalty. If it consists in a pecuniary, penalty, it
obviously involves no restriction on movement; but if it consists in imprisonment,
there is a restriction on movement. This restraint is imposed not under a law
imposing restrictions on movement but under a law defining crime and making it
punishable. The punishment is correlated directly with the violation of some other
person's right and not with the right of (1) [1945] F.C.R. 161 at p. 177.
movement possessed by the offender himself. In my opinion, therefore, the Indian Penal Code does
not come within the ambit of the words "law imposing restriction on the right to move freely ".
In the course of the arguments, the expression "punitive detention" was frequently used and the
tendency was to put it on the same footing as preventive detention for the purpose of certain
arguments. Punitive detention is however essentially different from preventive detention. A person
is punitively detained only after a trial for committing a crime and after his guilt has been
established in a compe- tent Court of justice. A person so convicted can take his case to the StateA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

High Court and sometimes bring it to this Court also; and he can in the course of the proceedings
connected with his trial take all pleas available to him including the plea of want of jurisdiction of
the Court of trial and the invalidity of the law under which he has been prosecuted. The final
judgment in the criminal trial will thus constitute a serious obstacle in his way if he chooses to assert
even after his conviction that his right under article 19 (1) (d) has been violated. But a person who is
preventively detained has not to face such an obstacle whatever other obstacle may be in his way.
IV. It was pointed out that article 19 being confined to citizens, the anomalous situation will follow
that in cases of preventive detention, a citizen will be placed in a better position than a non-citizen,
because if a citizen is detained his detention will be open to some kind of judicial review under
article 19 (5), but if a non-citizen has been detained his case will not be open to such review. In this
view, it is said that the whole Act relating to preventive detention, may be declared to be void if it is
unreasonable, though it concerns citizens as well as persons other than citizens. I must frankly state
that I am not at all per- turbed by this argument. It is a patent fact that the Constitution has
confined all the rights mentioned in arti- cle 19 (1) to citizens. It is equally clear that restric- tions on
those rights are to a limited extent at least open to judicial review- The very same question which is
raised in regard to article 19 (1)(d) will arise with regard to most of the other sub-clauses. A citizen
has the right to assemble peaceably and without arms, to form associations or unions and so on. If
there is any law imposing unreason- able restrictions on any of these rights, that law will not be
good law so far as citizens are concerned, but it may be good law so far as non-citizens are
concerned. I do not see why a similar situation arising with regard to the right granted under
sub-clause (d) should be stated to be anoma- lous. So far as the right of free movement is concerned,
a non-citizen has been granted certain protections in articles 21 and 22. If a ,citizen has been
granted certain other additional protections under article 19 (1) (d), there is no anomaly involved in
the discrimination. I think that it is conceivable that a certain law may be declared to be void as
against a citizen but not against a non-citizen. Such a result however should not affect our mind if it
is found to have been clearly within the contemplation of the framers of the Constitution.
V. It was contended that the rights declared by article 19 are the rights of a free citizen and if he has
already been deprived of his liberty in the circumstances referred to in articles 20, 21 and 22, then it
would be idle to say that he still enjoys the right referred to in article 19. After giving my fullest
consideration to this argument, I have not been able to appreciate how it arises in this case. There is
nothing in article 19 go suggest that it applies only to those cases which do not fall under articles 20,
21 and 22. Confining ourselves to preventive detention, it is enough to point out that a person who is
preventively de- tained must have been, before he lost his liberty, a free man. Why can't he say to
those who detained him: "As a citizen I have the right to move freely and you cannot curtail or take
away my right beyond the limits imposed by clause (5)of article 19." This is the only question which
arises in the case and it should not be obscured by any abstruse or metaphysical considerations. It is
true that if you put a man under detention, he cannot move and therefore he is not in a position to
exercise the right guaranteed under article 19 (1) (d). but this is only the physical aspect of the
matter and a person who is bed-ridden on account of disease suffers from a similar disability. In
law, however,. physical duress does not deprive a person of the right to freedom of movement. If he
has been detained under some provision of law imposing restrictions on the freedom of movement,
then the question will arise whether the restrictions are reasonable. If he has been detained underA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

no provision of law or under some law which is invalid, he must be set at liberty. To my mind, the
scheme of the Chapter dealing with the fundamental rights does not contemplate what is attributed
to it, namely, that each article is a code by itself and is independent of the others. In my opinion, it
cannot be said that articles 19, 20, 21 and 22 do not to some extent over- lap each other. The case of
a person who is convicted of an offence will come under articles 20 and 21 and also under article 221
so far as his arrest and detention in custody before trial are concerned. Preventive detention, which
is dealt with in article 22, also amounts to deprivation of personal liberty which is referred to in
article 21, and is a violation of the right of freedom of movement dealt with in article 19 (1) (d). That
there are other instances of overlapping of articles in the Constitution may be illus- trated by
reference to article 19 (1) (f) and article 31 both of which deal with the right to property and to some
extent overlap each other. It appears that some learned High Court Judges, who had to deal with the
very question before us, were greatly impressed by the statement in the report of the Drafting
Committee of the Constituent Assembly on article 15 (corresponding to the present article 21), that
the word "liberty" should be qualified by the insertion of the word "personal" before it for otherwise
it may be construed very widely so as to include the freedoms dealt with in article 13 (corresponding
to the present article
19). I am not however prepared to hold that this statement is decisive on the question of the
construction of the words used in article 19 (1) (d) which are quite plain and can be construed
without any extraneous help. Whether the report of the Drafting Commit- tee and the debates on the
floor of the House should be used at all in construing the words of a statute, which are words of
ordinary and common use and are not used in any technical or peculiar sense, is a debatable
question; and whether they can be used in aid of a construction which is a strain upon the language
used in the clause to be interpreted is a still more doubtful matter. But, apart from these legal
consider- ations, it is, I think, open to us to analyse the statement and see whether it goes beyond
adding a somewhat plausible reason--a superficially plausible reason--for a slight verbal change in
article 21. It seems clear that the addi- tion of the word "personal" before "liberty" in article 21
cannot change the meaning of the words used in article 19, nor can it put a matter which is
inseparably bound up with personal liberty beyond its place. Personal liberty and personal freedom,
in spite of the use of the word "personal ," are, as we find in several books, sometimes used in a wide
sense and embrace freedom of speech, freedom of .asso- ciation, etc. These rights are some of the
most valuable phases or elements of liberty and they do not cease to be so by the addition of the
word "personal." A general statement by the Drafting Committee referring to freedom in plural
cannot take the place of an authoritative exposition of the meaning of the words used in article 19
(1)(d), which has not been specifically referred to and cannot be such an overriding consideration as
to compel us to put a meaning opposed to reason and authority. The words used in article 19 (1) (d)
must be construed as they stand, and we have to decide upon the words themselves whether in the
.case of preventive detention the right under article 19 (1) (d) is or is not infringed. But, as I shall
point out later, however literally we may construe the words used in article 19 (1) (d) and however
restricted may be the meaning we may attribute to those words, there can be no escape from the
conclusion that preventive detention is a direct infringe- ment of the right guaranteed in article 19
(1) (d).A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Having dealt with the principal objections, I wish to revert once again to the main topic. The
expressions "per- sonal liberty" and" personal freedom" have, as we find in several books, a wider
meaning and also a narrower meaning. In the wider sense, they include not only immunity from
arrest and detention but also freedom of speech, freedom of association, etc. In the narrower sense,
they mean immunity from arrest and detention. I have shown that the juristic conception of
"personal liberty ," when these words are used in the sense of immunity from arrest, is. that it
consists in freedom of movement and locomotion. I have also pointed out that this conception is at
the root of the criminal law of England and of this country, so far as the offences of false
imprisonment and wrongful confinement are concerned. The gravamen of these offences is restraint
on freedom of movement. With these facts in view, I have tried to find out whether there is any
freedom of movement known in England apart from personal liberty used in the sense of immunity
from arrest and detention, but I find no trace of any such freedom. In Halsbury's Laws of England
(2nd Edition, volume 6, page 391), the freedoms mentioned are the right to per- sonal freedom (or
immunity from detention or confinement), the right to property, the right to freedom of speech, the
right of public meeting, the right of association, etc. Similar classifications will be found in Dicey's
"Introduc- tion to the Study of the Law of the Constitution" and Keith's "Constitutional Law" and
other books on constitu- tional subjects, but there is no reference anywhere to any freedom or right
of movement in the sense in which we are asked to. construe the words used in article 19 (1) (d).. In
the Constitutions of America, Ireland and many other countries where freedom is prized, there is no
reference to freedom or right of movement as something distinct from personal liberty used in the
sense of immunity from arrest and confinement. The obvious explanation is that in legal conception
no freedom or right of movement exists apart from what personal liberty connotes and therefore a
separate treatment of this freedom was not necessary. It is only in the Constitution of the Free City
of Danzig, which covers an area of 701 square miles, that we find these words in article 75 :-- "All
nationals shall enjoy freedom of movement within the City." There is however no authoritative
opinion available to support the view that this freedom is anything different from what is otherwise
called personal liberty. The problem of construc- tion in regard to this particular right in the
Constitution of Danzig is the same as in our Constitution. Such being the general position, I am
confirmed in my view that the juristic conception that personal liberty and freedom of movement
connote the same thing is the correct and true conception, and the words used in article 10 (1) (d)
must be construed according to this universally accepted legal conception.
This conclusion is further supported by reference to the war legislation in England and in India,
upon which the law of preventive detention, which has been in force in this country since the war, is
based. In the first world war, the British Parliament passed the Defence of the Realm Consoli-
dation Act, in 1914, and a number of regulations were made under it including regulation 14-B,
which permitted the Secretary of State to subject any person "to such obliga- tions and restrictions
as hereinafter mentioned in view of his hostile origin or associations." Lord Atkin in refer- ring to
this regulation said in Liversidge v. Sir John Anderson (1), "that the regulation undisputedly gave to
a Secretary of State unrestricted power to detain a suspected person." Apparently, Lord Atkin meant
that the restriction referred to in the Act included preventive detention. Under this regulation, one
Arthur Zadig was interned, and he applied to the King's Bench for a writ of habeas corpus which was
refused. The matter ultimately came up before the House of Lords in Rex v. Halliday (2), and the
noble Lords in dealing with the case proceeded on the assumption that there was no differenceA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

between internment and incarceration or imprisonment. Lord Shaw in narrating the facts of the
case stated :--
(1) [1942] A.C. 238. (2) [1917] A.C. 260.
His person was seized, he has been interned ...... The appellant lost his liberty and was interned ......"
He then proceeded to state that there was no difference between internment and imprisonment and
quoted the following passage from Blackstone :--
"The confinement of the person, in any wise, is an imprisonment. So that the keeping
a man against his will in a private house, putting him in the stocks, arresting or
forcibly detaining him in the street, is an imprisonment."
Proceeding on this footing (which I find to be the common basis in all other speeches delivered in
the case, though Lord Shaw had given a dissenting judgment), Lord Finlay while dealing with the
provisions of the regulations observed :--
"One of the most obvious means of taking precautions against dangers such as are
enumerated is to impose some restriction on the freedom of movement of persons
whom there may be any reason to suspect of being disposed to help the enemy "(1).
Again, Lord Atkinson while dealing with the merits of the case made the following
observations :--
"If the legislature chooses to enact that he can be deprived of his liberty and
incarcerated or interned for certain things for which he could not have been
heretofore incarcerated or interned, that enactment and the orders made under it if
intra vires do not infringe upon the Habeas Corpus Acts or take away any right
conferred by Magna Charta ...... ,, (2).
This passage read with the previous passage quoted by me will show that both
internment and incarceration were re- garded as "restrictions on the freedom of
movement "and that deprivation of liberty and restriction on freedom of move- ment
were used as alternative expressions bearing the same meaning.
The same conclusion is to be drawn by reference to the regulations made in the last
world war under the Emergency Powers (Defence)Act, 1939. The regulation which
directly dealt-with detention orders was 18-B. This regulation and a number of other
regulations have been placed in Part I under the heading" Restrictions (1) [1917] A.C.
269. (2) [1917] A.C. 272.
On movements and activities of persons ." The classifica- tion is important, because it meets two
principal arguments advanced in this case. It shows firstly that detention is a form of restriction and
secondly that it is a restriction on movement. I have noticed that" movement" is used in plural, andA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the heading also refers to restrictions on activities, but, having regard to the subjects classified
under this head, movement undoubtedly refers to physical movement and includes such movements
as entering a particu- lar locality, going from one place to another, etc., i.e., the very things to which
article 19 (1) (d) is said to have reference. In Liversidge's case, in construing the provi- sions of the
Act of 1939, Viscount Maugham observed as follows :--
"The language of the Act of 1939 (above cited) shows beyond doubt that Defence
Regulations may be made which must deprive the subject "whose detention appears
to the Secre- tary of State to be expedient in the interests of public safety" of all his
liberty of movement while the regulations remain in force"(1).
Thus Viscount Maugham also considered detention to be synonymous with
deprivation of liberty of movement. The classification that we find in the Defence of
the Realm Regulations was with a little verbal modification adopted in the Defence of
India Rules, and we find that here also rule 26, which dealt with preventive
detention, has been placed under the heading "Restriction of movements and
activities of persons." A somewhat similar classification has also been adopted in a
series of Provincial Acts and Ordinances relating to maintenance of order [see section
2 of the Bihar Maintenance of Public Order. Act, 1949, section 16 of the West Bengal
Security Act, 1948, section 4 of the East Punjab Public Safety Act, 1949, section 2 of
the Madras Maintenance of Public Order Act, 1947, section 3 of the U.P. Maintenance
of Public Order Temporary Act, 1947, and section 2 of the Bombay Public Security
Measures Act, 1947. In these Acts and Ordinances, preventive detention and certain
(1) [1942] A.C. 219.
other forms of restriction on movement such as internment, externment, etc. have been classed
together and dealt with more or less on the same footing, and sometimes they have been dealt with
in different clauses of the same section. In one of the Acts, the same advisory board is to deal with
the case of a detenue as well as that of an externed person, and there are also similar provisions
giving them the right to represent their case to the Government.
I will now assume for the sake of argument that the freedom of movement to which reference is
made in article 19 (1) (d) has nothing to do with personal liberty and that the words which occur in
the article bear the restricted meaning attributed to them by the learned Attorney-General and some
of my colleagues. It seems to me that even on this assump- tion, it is difficult to arrive at any
conclusion other than what I have already arrived at. There can be no doubt that preventive
detention does take away even this limited free- dom of movement directly and substantially, and, if
so, I do not see how it can be argued that the right under article 19 (1) (d) is not infringed if the
alternative interpretation is accepted. We have only to ask ourselves: Does a person who is detained
retain even a fraction of his freedom of movement in howsoever restricted sense the term may be
used and does he not lose his right to move freely from one place to another or visit any locality he
likes as a necessary result of his detention ? I think I should refer here once more to the fact that in
the Defence of the Realm Regula- tions and Defence of India Rules, preventive detention is classed
under the heading "Restriction of movements and activities." "Movement" is here used in plural andA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

refers to that very type of movement which is said to be protected by article 19 (1) (d), moving from
one State or place to another, visiting different localities, etc. One of the objects of 'preventive
detention is to restrain the person detained from moving from place to. place so that he may not
spread disaffection or indulge in dangerous activities in the' places he visits. The same consideration
applies to the cases of persons who are interned or externed. Hence, externment, internment and
certain other forms of restriction on move- ment have always been treated as kindred matters
belonging to the same group or family and the rule which applies to one must necessarily apply to
the other. It is difficult to hold that the case of externment can possibly be dealt with on a different
footing from the case of preventive deten- tion. I am however interested to find that the Patna and
Bombay High Courts have held that a person who is externed can successfully assert that the right
granted to him under article 19 (1) (d) has been violated. This view has not been seriously challenged
before us, and, if it is correct, I really do not see how it can be held that preventive deten- tion is also
not a direct invasion of the right guaranteed in article 19 (1) (d). Perhaps, one may pause here to ask
what kind of laws were in contemplation of the framers of the Constitution when they referred to
laws imposing re- strictions in the public interest in article 19 (5). I think the war laws and the
Provincial Acts and Ordinances to which I have already referred must have been among them, these
being laws which expressly purport to impose restrictions on movements. If so, we should not
overlook the fact that preventive detention was an inseparable part of these laws and was treated as
a form of restriction on movement and classified as such. It seems to me that when the matter is
seriously considered, it would be found that the interpreta- tion of the learned Attorney-General
attracts the operation of article 13 (2) no less strongly and directly than the interpretation I have
suggested, and I prefer the latter only because I consider that it is legally unsound to treat what is
inseparably bound up with and is the essential element in the legal concept 1of personal liberty as a
wholly separate and unconnected entity. But, as I have already indicated, it will be enough for the
purpose of this case if we forget all about personal liberty and remember only that detention is, as is
self-evident and as has been pointed out by Viscount Maugham and other eminent judges, another
name for depriving a person of all his "liberty of movement."
It was pointed out in the course of the arguments that preventive detention not only takes away the
right in article 19 (1) (d) but also takes away all the other rights guaranteed by article 19 (1), except
the right to hold, acquire and dispose of property. Where exactly this argu- ment is intended to lead
us to, I cannot fully understand, but it seems to me that it involves an obvious fallacy, because it
overlooks the difference in the modes in which preventive detention operates on the right referred to
in sub-clause (d) and other sub-clauses of article 19 (1). The difference is that while preventive
detention operates on freedom of movement directly and inevitably, its operation on the other rights
is indirect and consequential and is, often only notional. One who is preventively detained is
straightaway deprived of his right of movement as a direct result of his detention, but he loses the
other rights only in consequence of his losing freedom of movement. Beside% while freedom of
movement is lost by him in all reality and substance, some of the other rights may not be lost until
he wishes to exercise them or is interested in exercising them. A person who is detained may not be
interested in freedom of association or may not pursue any profession, occupation, trade or
business. In such a case, the rights referred to are lost only in theory and not as a matter of
substance. I wish only to add that when I said that I was not able to understand the full force of the
argument which I have tried to deal with, what I had, in mind was that if preventive detentionA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

sweeps away or affects almost all the rights guaranteed in article. 19 (1), the matter deserves very
serious consideration and we cannot lightly lay down that article 13 (2) does not come into
operation.
Being fully alive to the fact that it is a serious matter to be asked to declare a law enacted by
Parliament to be unconstitutional, I have again and again asked myself the question: What are we to
put in the scales against the construction which I am inclined to adopt and in favour of the view that
preventive detention does not take away the freedom of movement guaranteed in article 19 (1) (d)?
The inevitable answer has always been that while in one of the scales we have plain and
unambiguous language, the opinion eminent jurists, judicial dicta of high authority, constitu- tional
practice in the sense that no Constitution refers to any freedom of movement apart from personal
liberty, and the manner in which preventive detention has been treated in the very laws on which
our law on this subject is based, all that we can put in the opposite scale is a vague and ill- rounded
apprehension that some fearful object such as the revision of the Penal .Code is looming obscurely in
the distant horizon, the peculiar objection that the mere men- tion of the scheduled tribes will alter
the meaning of certain plain words, the highly technical and unreal dis- tinction between restriction
and deprivation and the assump- tion not warranted by any express provision that a person who is
preventively detained cannot claim the right of freedom of movement because he is not a free man
and certain other things which, whether taken singly or ,collectively, are too unsubstantial to carry
any weight. In these circum- stances, I am strongly of the view that article 19 (1)(d) guarantees the
right of freedom of movement in its widest sense, that freedom of movement being the essence of
person- al liberty, the right guaranteed under the article is really a right to personal liberty and that
preventive detention is a deprivation of that right. I am also of the view that even on the
interpretation suggested by the learned Attor- ney-General, preventive detention cannot but be held
to be a violation of the right conferred by article 19 ,(1) (d). In either view, therefore, the law of
preventive detention is subject to such limited judicial review as is permitted under article 19 (5).
The scope of the review is simply to see whether any particular law imposes any unreasonable
restrictions. Considering that the restrictions are imposed on a most valuable right, there is nothing
revolutionary in 'the legislature trusting the Supreme Court to examine whether an Act which
infringes upon that right is within the limits of reason.
I will now pass on to the consideration of article 21, which runs as follows :-
"No person shall be deprived of his life or personal liberty except according to
procedure established by law."
Here again, our first step must be to arrive at a clear meaning of the provision. The only words
which cause some difficulty in the proper construction of the article are "procedure established by
law."
The learned Attorney-General contended before us that the word "law" which is used in article 21
means State-made law or law enacted by the State. On the other hand, the learned counsel for the
petitioner strongly contended that the expression "procedure established by law" is used in a much
wider sense and approximates in meaning to the expres- sion "due process of law" as interpreted byA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the Supreme COurt of America in the earliest times and, if that is so, it means exactly what some of
the American writers mean to convey by the expression "procedural due process." In the course of
the arguments, the learned Attorney- General referred us to the proceedings in the Constituent
Assembly for the purpose of showing that the article as originally drafted contained the words
"without due process of law" but these words were subsequently replaced by the words "except
according to procedure established by law." In my opinion, though the proceedings or discussions in
the Assembly are not relevant for the purpose of construing the meaning of the expressions used in
article 21, especially when they are plain and unambiguous, they are relevant to show that the
Assembly intended to avoid the use of the expression "without due process of law." That expression
had its roots in the expression "per legem terrae" (law of the land) used in Magna Charta in 1215. In
the reign of Edward III, 'however, the words "due process of law" were used in a statute
guaranteeing that no person will be de- prived of his property or imprisoned or indicted or put to
death without being brought in to answer by due process of law (28, Edward III, Ch. III). The
expression was after- wards adopted in the American Constitution and also in the Constitutions of
some of the constituent States, though some of the States preferred to use the words "in due course
of law" or "according to the law of the land." [See Cooley on "Constitutional Limitations," 8th Edn.
Vol. II, pages 734-51. In the earliest times, the American Supreme Court construed "due process of
law" to cover matters of procedure only, but gradually the meaning of the expression was widened
so as to cover substantive law also, by laying emphasis on the word "due." The expression was used
in such a wide sense that the judges found it difficult to define it and in one of the cases it was ob-
served as follows :--
"It would be difficult and perhaps impossible to give to those words a definition, at
once accurate, and broad enough to cover every case. This difficulty and perhaps
impossi- bility was referred to by Mr. Justice Miller in Davidson v. New Orleans,
where the opinion was expressed that it is wiser to ascertain their intent and
application by the 'gradual process of judicial inclusion and exclusion,' as the cases
presented for decision shall require, with the reasoning on which such decisions may
be rounded:" Missouri Pacific Railway Co. v. Humes (1).
It seems plain that the Constituent Assembly did not adopt this expression on
account of the very elastic meaning given to it, but preferred to use the words
"according to procedure established by law" which occur in the Japanese
Constitution framed in 1946.
It will not be out of place to state here in a few words how the Japanese Constitution
came into existence. It appears that on the 11th October, 1945. General McArthur
directed the Japanese Cabinet to initiate measures for the preparation of the
Japanese Constitution, but, as no progress was made, it was. decided in February,
1946, that the problem of constitutional reform should be taken over by the
Government Section of the Supreme Commander's Headquar- ters. Subsequently the
Chief of this Section ,and the staff drafted the Constitution with the help of American
constitu- tional lawyers who were called to assist the Government Section in the task.
This Constitution, as a learned writer has remarked, bore (1) 115 U.S. 512 at page 513.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

on almost every page evidences of its essentially Western origin, and this characteristic was
especially evident in the preamble "particularly reminiscent of the American Declaration of
Independence, a preamble which, it has been observed, no Japanese could possibly have conceived
or written and which few could even understand" [See Ogg and Zink's "Modern Foreign
Governments"]. One of the character- istics of the Constitution which undoubtedly bespeaks of
direct American influence is to be found in a lengthy chap- ter, consisting of 31 articles, entitled
"Rights and Duties of the People," which provided for the first time an effec- tive "Bill of Rights" for
the Japanese people. The usual safeguards have been provided there against apprehension without a
warrant and against arrest or detention without being informed of the charges or without adequate
cause (articles 33 and 34).
Now there are two matters which deserve to be noticed :--(1) that the Japanese Constitution was
framed wholly under American influence; and (2) that at the time it was framed the trend of judicial
opinion in America was in favour of confining the meaning of the expression "due process of law" to
what is expressed by certain American writers by the somewhat quaint but useful expression "proce-
dural due process." That there was such a trend would be clear from the following passage which I
quote from Carl Brent Swisher's "The Growth of Constitutional Power in the United States" (page
107.):--
"The American history of its interpretation falls into three periods. During the first
period, covering roughly the first century of government under the Constitution, due
process was interpreted principally as a restriction upon procedure--and largely the
judicial procedure--by which the government exercised its powers. During the second
period, which, again roughly speaking, extended through 1936, due process was
expanded to serve as a restriction not merely upon procedure but upon the substance
of the activities in which the government might engage. During the third period,
extending from 1936 to date, the use of due process as a substantive restriction has
been largely sus- pended or abandoned, leaving it principally in its original status as a
restriction upon procedure."
In the circumstances mentioned, it seems permissible to surmise that the expression "procedure
established by law"
as used in the Japanese Constitution represented the current trend of American
judicial opinion with regard to "due process of law," and, if that is so, the expression
as used in our Constitution means all that the American writers have read into the
words "procedural due process." But I do not wish to base any conclusions upon mere
surmise and will try to examine the whole question on its merits.
The word "law" may be used in an abstract or concrete sense. Sometimes it is
preceded by an article such as "a"
or "the" or by such words as "any," "all,"A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

etc., and sometimes it is used without any such prefix. But, generally, the word "law"
has a wider meaning when used in the abstract sense without being preceded by an
article. The question to be decided is whether the word "law" means nothing more
than statute law.
Now whatever may be the meaning of the expression "due process of law," the word
"law" is common to that expression as well as "procedure established by law" and
though we are not bound to adopt the construction put on "law" or "due process of
law" in America, yet since a number of eminent American Judges have devoted much
thought to the subject, I am not prepared to hold that we can derive no help from
their opinions and we should completely ignore them. I will therefore in the first
instance set out certain quotations from a few of the .decisions of the American
Supreme Court construing the word "law" as used in the expression "due process of
law," in so far as it bears on the question of legal procedure.
(1) "Although the legislature may at its pleasure provide new remedies or change old
ones, the power is never-
theless subject to the condition that it cannot remove certain ancient land-marks, or take away
certain fundamen- tal rights which have been always recognized and observed in judicial
procedures:" Bardwell v. Collins (1).
(2)' 'By the law of the land is most clearly intended the general law: a law which hears before it
condemns, which proceeds upon inquiry and renders judgments only- after trial. The meaning is
that every citizen shall hold his life, liberty and property, and immunities under the protection of the
general rules which govern society:"
Dartmouth College Case (2).
(3) "Can it be doubted that due process of law signifies a right to be heard in one's
defence ? If the legislative department of the government were to enact a statute
confer-
ring the right to condemn the citizen without any opportuni- ty whatever of being heard, would it be
pretended that such an enactment would not be violative of the Constitution ? If this be true, as it
undoubtedly is, how can it be said that the judicial department. the source and fountain of justice
itself, has yet the authority to render lawful that which if done under express legislative sanction
would be viola of the Constitution ? If such power obtains, then the judicial department of the
government sitting to uphold and enforce the Constitution is the only one possessing a power to
disregard it. If such authority exists then in conse- quence of their establishment, to compel
obedience to law and enforce justice, Courts possess the right to inflict the very wrongs which they
were created to prevent:" Hovey v. Elliott(3).A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(4) "It is a rule as old as the law, and never more to be respected than now, that no one shall be
personally bound until he has had his say in Court, by which is meant, until he has been duly cited to
appear, and has been afforded an opportunity to be heard. Judgment without such citation and
opportunity wants all the attributes of a judicial determi- nation; it is judicial usurpation and
oppression, and can never be upheld where justice is justly administered:"
Gatpin v. Page(4).
Thus, in America, the word "law" does not mean merely State-made law or law
enacted by the State and does not exclude certain fundamental principles of (1) 44
Minn. 97; 9 L.R.A. 152. (3) 167 U.S. 409 at page 417.
(2) 17 U.S. 4. (4) 85 U.S. 18.
justice which inhere in every civilized system of law and which are at the root of it. The result of the
numerous decisions in America has been summed up by Professor Willis in his book on
"Constitutional Law" at page 662, in the statement that the essentials of due process are: (1) no- tice,
(2) opportunity to be heard, (3) an impartial tribu- nal, and (4) orderly course of procedure. It is
pointed out by the learned author that these essentials may assume different forms in different
circumstances, and so long as they are conceded in principle, the requirement of law will be fulfilled.
For example, a person cannot require any particular form or method of hearing, but all that he can
require is a reasonable opportunity to be heard. Similarly, an impartial tribunal does not necessarily
mean a judicial tribunal in every case. So far as 'orderly course of proce- dure is concerned, he
explains that it does not require a 'Court to strictly weigh the ,evidence but it does require it to
examine the entire record to ascertain the issues, to discover whether there are facts not reported
and to see whether or not the law has been correctly applied to facts. The view expressed by other
writers is practically the same as that expressed by Professor Willis, though some of them do not
expressly refer to the fourth element, viz., orderly course of procedure. The real point however is
that these four elements are really different aspects of the same right, viz., the right to be heard
before one is condemned. So far as this right is concerned, -judicial opinion in England appears to
be the same as that in America. In Eng- land, it would shock one to be told that a man can be de-
prived of his personal liberty without a fair trial or hearing. Such a case can happen if the Parliament
expressly takes away the right in question in an emergency as the British Parliament did during//
the last two world wars in a limited number of cases. I will refer here to a few cases which show that
the fundamental principle that a person whose right is affected must be heard has been observed not
only in cases involving personal liberty but also 'in proceedings affecting other rights, even though
they may have come before administrative or quasi-judicial tribunals. Cooper v. The Wadsworth
Board of Works (1)was a case under an Act which empowered the District Board to alter or demol-
ish a house where the builder had neglected to give notice of his intention. seven days before
proceeding to lay or dig the foundation. Acting upon this power, the Board directed the demolition
of a building without notice to the builder, but this was held to be illegal. Byles 5. in dealing with the
matter observed as follows :--A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"I conceive they acted judicially, because they had to determine the offence, and they
had to apportion the punish- ment as well as the remedy. That being so, a long course
of decisions, beginning with Dr. Bentley's case, and ending with some very recent
cases, establish that although there are no positive words in a statute requiring that
the party-shall be heard, yet the justice of the common law will supply the omission
of the legislature. The judgment of Mr. Justice Fortescue, in Dr. Bentley's case, is
somewhat quaint, but it is very applicable, and has been the law from that time to the
present. He says, "The. objection for want of notice can never be got over. The laws of
God and man both give the party an opportunity to make his defence, if he has any."
In the same case Erie C.J. observed :--
"It has been said that the principle that no man shall be deprived of his property
without an opportunity of being heard, is limited to a judicial proceeding...... I do not
quite agree with that; ......the law, I think, has been applied to many exercises of
power which in common under- standing would not be at all more a judicial
proceeding than would be the act of the District Board in ordering a house to be
pulled down."
The observations made by Erie C.J. were quoted and applied by Sir Robert Collier in Smith v. The'
Queen (2), and the observations of Lord Campbell in Regina v. The Archbishop of Canterbury (3)
were to the. same effect. (1) 14 C.B. (N.S.) 180. (2) 3 A.C. 614.
(3) 1E.& E. 559.
A similar opinion was expressed by Sir GeorgeJessel in Fisher v. Keane (1), Labouchere v. Earl of
Wharncliffe (2), and Russell v. Russell (3). In the last mentioned case, he observed as follows :--
"It [Wood v. Woad (4)] contains a very valuable state- ment by the Lord Chief Baron
as to his view of the mode of administering justice by persons other than Judges who
have judicial functions to perform which I should have been very glad to have had
before me on both those club cases that I recently heard, namely, the case of Fisher v.
Keane and the case of Labouchere v. Earl of Wharncliffe. The passage I mean is this,
referring to a committee: 'They are bound in the exercise of their functions by the
rule expressed in the maxim "audi alteram partem," that no man should be
condemned to consequences without having the opportunity of making his defence.
This rule is not confined to the con- duct of strictly legal' tribunals, but is applicable
to every tribunal or body of persons invested with authority to adjudicate upon
matters involving civil consequences to individuals '."
This opinion was quoted with approval by Lord Macnaghten in Lapointe v. L'Association etc. de
Montreal (5). In that case, on an application for pension by the appellant, who had been obliged to
resign, the Board of Directors, without any judicial inquiry into the circumstances, resolved to refuse
the claim on the ground that he was obliged to tender his resignation. This procedure wasA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

condemned by Lord Macnaghten as being "contrary to rules of society and above all contrary to the
elementary principles of justice." These observations of Lord Macnaghten were referred to and
relied on in The King v. Tribunal of Appeal under the Hous- ing Act, 1919 (6). In that case, a
company proposed to build a picture house and the local authority having prohibited 'the building,
the company appealed under the Housing (1) H. Ch. D. 353. (4) [1874] L.R. 9 Ex.
190. (2) 13 Oh. D. 346. (5) [1906] A.C. 535.
(3) 14 Ch. D. 471. (6) [1920] I.B. 334.
(Additional Powers) Act, 1919, which contained a provision that an appeal could in certain cases be
properly determined without a hearing and that the appellate Court could dis- pense with the
hearing and determine the appeal summarily. It was held that the meaning of rule 7 was that the
tribunal on appeal might dispense with an oral hearing, not that they might dispense with a hearing
of any kind, and that they were bound to give the appellants a hearing in the sense of an opportunity
to make out a case. The Earl of Reading in delivering the judgment observed:
"The principle of law applicable to such a case is well stated by Kelly C.B. in Wood v.
Woad in a passage which is cited with approval by Lord Macnaghten in Lapointe v. L'
Association etc. de Montreal ...... "
In Local Government Board v. Arlidge(1), the Local Government dismissed an appeal by a person
against whom a closing order had been made under Housing, Town Planning, &c. Act, without an
oral hearing and without being allowed to see the report made by the Board's Inspector upon 'public
local inquiry. The House of Lords did not interfere with the order on the ground that the appeal had
been dealt with by an administrative authority whose duty was to enforce obligations on the
individual in the interests of the commu- nity and whose character was that of an organization with
executive functions. The principle however was conceded and lucidly set forth that when the duty of
deciding an appeal is imposed, those whose duty it is to decide it must act judicially, and they must
deal with the question referred to them without bias and must give to each of the parties an
opportunity of presenting its case, and that the decision must be come to in the spirit and with the
sense of respon- sibility of a tribunal whose duty it is to mete out justice. Commenting upon this
case, which is generally regarded as an extreme case, Mr. Gavin Simonds, who afterwards became a
member of the House of Lords observes :--
(1) [1915] A.C.120.
"I think you would agree that if the subjectmatter of such proceedings as arc here
indicated was the liberty of the subject, or indeed his life, you would regard such a
judicial procedure as outrageous." (See C.K. Allen's "Law and Orders," page 167).
I have particularly referred to cases which were before administrative tribunals,
because I have to deal in this case with preventive detention which is said to be an
execu- tive act and because I wish to point out that even before executive authoritiesA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

and administrative tribunals an order cannot generally be passed affecting one's
rights without giving one such hearing as may be appropriate to the circum- stances
of the case. I have only to add that Halsbury after enumerating the most important
liberties which are recog- nized in England, such as right of personal freedom, right
to freedom of speech, right of public meeting, etc., adds :--
"It seems to me that there should be added to this list the following rights which
appear to have become well-estab- lished--the right of the subject to have any case
affecting him tried in accordance with the principles of natural justice, particularly
the principles that a man may not be a judge in his own cause, and that no party
ought to be con- demned unheard, or to have a decision given against him unless he
has been given a reasonable opportunity of putting forward his case ...... "(Halsbury's
Laws of England, 2nd Edition, volume 6, page 392).
The question is whether the principle that no person can be condemned without a
hearing by an impartial tribunal which is well-recognized in all modern civilized
systems of law and which Halsbury puts on a par with well-recognized fundamental
rights cannot be regarded as part of the law of this country. I must confess that I find
it difficult to give a negative answer to this question. The principle being part of the
British system of law and procedure which we have inherited, has been observed in
this country for a very long the and is also deeply rooted in our ancient history, being
the basis of the panchayat system from the earliest times. The whole of the Criminal
Procedure Code, whether it deals with trial of offences or with preventive or
quasiadministrative measures such as are contemplated in sections 107, 108, 109, 110
and 145, is based upon the foundation of this principle, and it is difficult to see that it
has not become part of the "law of the land" and does not inhere in our system of law.
If that is so, then "procedure established by law" must include this principle,
whatever else it may or may not include. That the word "law" used in article 21 does
not mean only State-made law is clear from the fact that though there is no statute
laying down the complete procedure to be adopted in contempt of Court cases, when
the contempt is not within the view of the Court, yet such procedure as now prevails
in these cases is part of our law. The statute-law which regulates the procedure of
trials and enquiries in criminal cases does not specifically provide for arguments in
certain cases, but it has always been held that no decision should be pronounced
without hearing arguments. In a number of cases, it has been held that though there
may be no specific provision for notice in the statute, the provision must be read into
the law. I am aware that some Judges have ex- pressed a strong dislike for the
expression "natural jus- tice" on the ground that it is too vague and elastic, but where
there are well-known principles with no vagueness about them, which all systems of
law have respected and recognized, they cannot be discarded merely because they are
in the ultimate analysis found to be based on natural jus- tice. That the expression
"natural justice" is not unknown to our law is apparent from the fact that the Privy
Council has in many criminal appeals from this country laid down that it shall
exercise its power of interference with the course of criminal justice in this countryA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

when there has been a breach of principles of natural justice or departure from the
requirements of justice. [See In re Abraham Mallory Dillet (1), Taba Singh v. King
Emperor C), George Gfeller v. The (1) 12 A.C. 459. (2) I.L.R. 48 Born. 515.
King(1), and Bugga and others v. Emperor(2). In the present case, there is no vagueness about the
right claimed which is the right to have one's guilt or innocence considered by an impartial body and
that right must be read into the words of article 21. Article 21 purports to protect life and person- al
liberty, and it would be a precarious protection and a protection not worth having, if the elementary
principle of law under discussion which, according to Halsbury is on a par with fundamental rights,
is to be ignored and excluded. In the course of his arguments, the learned counsel for the petitioner
repeatedly asked whether the Constitution would permit a law being enacted, abolishing the mode
of trial permitted by the existing law and establishing the procedure of trial by battle or trial by
ordeal which was in vogue in olden times in England. The question envisages something which is
not likely to happen, but it does raise a legal problem which can perhaps be met only in tiffs way that
if the expression "procedure established by law" simply means any procedure established or enacted
by statute it will be difficult to give a negative answer to the question, but ii the word "law" includes
what I have endeavoured to show it does, such an answer may be justified. It seems to me that there
is nothing revolutionary in the doctrine that the words "procedure established by law" must include
the four principles set out in Professor Willis' book, which, as I have already stated, are different
aspects of the same principle and which have no vagueness or uncertainty about them. These
principles, as the learned author points out and as the authorities show, are not absolutely rigid
principles but are adaptable to the circumstances of each case within certain limits. I have only to
add that it has not been seriously controverted that "law" in this article means valid law and
"procedure" means certain definite rules of proceeding and not something which is a mere pretence
for procedure.
I will now proceed to examine article 22 of the Consti- tution which specifically deals with the
subject (1) A.I.R. 1943P.C. 211. (2) A.I.R. 1919P. C. 108.
of preventive detention. The first point to be noted in regard to this article is that it does not exclude
the operation of articles 19 and 21, and it must be read subject to those two articles, in the same way
as articles 19 and 21 must be read subject to article 22. The correct position is that article 22 must
prevail in so far as there are specific provisions therein regarding preventive detention, but, where
there are no such provisions in that article, the operation of articles 19 and 21 cannot be excluded.
The mere fact that different aspects of the same right have been dealt with in three different articles
will not make them mutually exclusive except to the extent I have indicated. I will now proceed to
analyse the article and deal with its main provisions. In my opinion, the main provisions of this
article are :--(1) that no person can be detained beyond three months without the report of an
advisory board [clause 4 (a) ]; (2) that the Parliament may prescribe the circumstances and the class
or classes of cases in which a person may be detained for more than three months without obtaining
the opinion of an advisory board [clause 7 (a)]; (3) that when a person is preventively detained, the
author- ity making the order of detention shall communicate to such person the grounds on which
the order is made and shall afford him the earliest opportunity of making a representa- tion against
the order [clause (5) ]; and (4) that the Parliament may prescribe the maximum period for whichA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

any person may in any class or classes of cases be detained under any law providing for preventive
detention [clause 7
(b) ]. The last point does not require any consideration in this case, but the first three points do
require considera- tion.
In connection with the first point, the question arises as to the exact meaning of the words "such
detention" occur- ring in the end of clause 4 (a). Two alternative interpre- tations were put forward:
(1) "such detention" means preven- tive detention; (2) "such detention" means detention for a
period longer than three months. If the first interpreta- tion is correct, then the function of the
advisory board would be to go into the merits of the case of each person and simply report whether
there was sufficient cause for his detention. According to the other interpretation, the function of the
advisory board will be to report to the government whether there is sufficient cause for the person
being detained for more than three months. On the whole, I am inclined to agree with the second
interpretation. Prima facie, it is a seri- ous matter to detain a person for a long period (more than
three months) without any enquiry or trial. But article 22 (4) (a) provides that such detention may
be ordered on the report of the advisory board. Since the report must be directly connected with the
object for which it is required, the safeguard provided by the article, viz., calling for a report from
the advisory board, loses its value, if the advisory board is not to apply its mind to the vital ques-
tion before the government, namely, whether prolonged deten- tion (detention for more than three'
months) is justified or not. Under article 22 (4) (a), the advisory board has to submit its report
before the expiry of three months and may therefore do so on the eighty-ninth day. It would be
some- what farcical to provide, that after a man has been detained for eighty-nine days, an advisory
board is to say whether ' his initial detention was justified. On the other hand, the determination of
the question whether prolonged detention (detention for more than three months)is justified must
necessarily involve the determination of the question wheth- er the detention was justified at all,
and such an interpre- tation only can give real meaning and effectiveness to the provision. The
provision being in the nature of a protection or safeguard, I must naturally lean towards the
interpreta- tion which is favourable to the subject and which is also in accord with the object in view.
The next question which we have to discuss relates to the meaning and scope of article 22 (7)(a)
which runs as follows:-
"Parliament may by law prescribe---
(a) the circumstances under which, and the class or classes of cases in which, a
person may be detained for a period longer than three months under any law
providing for preven-
tive detention without obtaining the opinion of an Advisory Board in accordance with the provisions
of sub-clause (a) of clause (4)." The question is what is meant by "circumstances"' and "class or
classes of cases" used in this provision. This question has arisen because of the way in which these
ex- pressions appear to have been interpreted and applied in the Act of Parliament with which we
are concerned. As the matter is important and somewhat complicated, I shall try to express myA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

meaning as clearly as possible even at the risk of some repetition, and, in doing so, I must
necessarily refer to the impugned Act as well as Lists I and III of the Seventh Schedule of the
Constitution, under which Parliament had jurisdiction to enact it. Item 9 of List I--Union
List--shows that the Parliament has power to legislate on preventive detention for reasons
connected with (1) defence, (2) foreign affairs, and (3) security of India.. Under List III--Concurrent
List--the appropriate item is item 3 which shows that law as to preventive detention can be made for
reasons connected with (1) the security of the State, (2) the maintenance of public order, and (3) the
maintenance of supplies and services essential to the community. The impugned Act refers to all the
subjects mentioned in Lists I and III in regard to which law of preventive detention can be made.
Section 3 (1)of the Act, the substance of which has already been mentioned, is important, and I shall
reproduce it verbatim.
"The Central Government or the State Government may-
(a) if satisfied with respect to any person that with a view to preventing him from
acting in any manner prejudicial to-
(i) the defence of India, the relations of India with foreign powers, or the security of
India, or
(ii) the security of the State or the maintenance of public order, or
(iii) the maintenance of supplies and services essen-
tial to the community, or
(b) if satisfied with respect to any person who is a foreigner within the meaning of the Foreigners
Act, 1946 (XXXI of 1946), that with a view to regulating his continued presence in India or with a
view to making arrangements for his expulsion from India, it is necessary so to do, make an order
directing that such person be detained."
It will be noticed that all the subjects of legislation concerning preventive detention occurring in
item of List I are grouped in sub-clause (1) of clause (a). The subjects in this group are three in
number and, for convenience of reference, I shall hereafter refer to them as A, B and C. In
sub-.clause (ii), we find grouped two of the matters referred to in item 3 of List III, these being
security of the State and the maintenance of public order. These two subjects, I shall refer to as D
and E. In sub-clause (iii), reference has been made to the third matter in item 3 of List III, and I
shall refer to this subject as F. With this classification, let us now turn to the Constitution itself. On
reading articles 22 (4) and 22 (7) together, it would be clear that so long as article 22 (4) (a) holds
the field and Parliament does not act under clause (7) (a) of article 22, there must be an advisory
board in every case, i.e., if the legislation relates to groups A to F, as it does here, there must be an
advisory board for all these groups. Article 22 (7) however practically engrafts an excep- tion. It
states in substance that the Parliament may by an Act provide for preventive detention for more
than three months without reference to an advisory board, but in such cases it shall be incumbentA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

on the Parliament to prescribe (1) the circumstances and (2) the class or classes of cases in which
such course is found to be necessary. If the case contemplated in clause (4)(a)is the rule and that
contem- plated 'in clause (7) (a) is the exception, then the circum- stances and the class or classes of
cases must be of a special or extraordinary nature, so as to take the case out of the rule and bring it
within the exception. It is always possible to draw the line between the normal or ordinary and the
abnormal or extraordinary cases. and this is what, in my opinion, the Parliament was expected to do
under clause (7) (a). I do not think that it was ever intended that Parliament could at its will treat
the normal as the abnor- mal or 'the rule as the exception. But this is precisely what has been done
in this case- All the items on which preventive legislation is possible excepting one, i.e., A to E, have
been put within the exception, and only one, F, which relates to maintenance of supplies and
services essen- tial to the community, has been allowed to remain under the rule. In other words, it
is provided that there shall be an advisory board only for the last category, F, but no provi- sion
having been made for the other categories, A to E, it may be assumed that the advisory board has
been dispensed with in those cases. The learned Attorney-General maintained that it would have
been open to the Parliament to dispense with the advisory board even for the category F, and if such
a course had been adopted it would not have affected the validity of the Act. This is undoubtedly a
logical position in the sense that it was necessary for him to go as far as this to justify his stand; but,
in my opinion, the course adopted by the Parliament in enacting section 12 of the impugned Act is
not what is contemplated under article 22 (7) (a) or is permitted by it. The circumstances to be
prescribed must be special and extraordinary circumstances and the class or classes of cases must be
of the same na- ture. In my opinion, the Constitution never contemplated that the Parliament
should mechanically reproduce all or most of the categories A to F almost verbatim and not apply its
mind to decide in what circumstances and in what class or classes of cases the safeguard of an
advisory board is to be dispensed with.
I may state here that two views are put forward before us as to how clauses (4) (a) and 7 (a) of article
22 are to be read:--(1) that clause (4) (a) lays down the rule that in all cases where detention for
more than three months is ordered, it should be done in consultation with and on the report of the
advisory board, and clause (7) (a) lays down an exception to this rule by providing that Parliament
may pass an Act permitting detention for more than three months without reference to an advisory
board; (2) that clauses (4)(a) and (7) (a) are independent clauses making two separate and
alternative provisions regarding detention for more than three months, in one case on the report of
an advisory board and in other case without reference to an advisory board. Looking at the
substance and not merely at the words, I am inclined to hold that clause (7) (a) practically engrafts
an exception on the rule that preventive detention for more than three months can be ordered only
on the report of an advisory board, and so far I have proceeded on that footing. But it seems to me
that it will make no difference to the ulti- mate conclusion, whichever of the two views we may
adopt. Even on the latter view, it must be recognized that the law which the Constitution enables the
Parliament to make under article 22 (7) (a) would be an exceptionally drastic law, and, on the
principle that an exceptionally drastic law must be intended for an exceptional situation, every word
of what I have said so far must stand. Clause (7) (a) is only an enabling provision, and it takes care to
provide that the Parliament cannot go to the extreme limit to which it is permitted to go without
prescribing the class or classes cases and the circumstances to which the extreme law would be
applicable. It follows that the class or classes of cases and the circumstances must be of a specialA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

nature to require such legislation.
It was urged that the word "and" which occurs between "circumstances" and "class or classes of
cases" is used in a disjunctive sense and should be read as "or," and by way of illustration it was
mentioned that when it is said that a person may do this and that, it means that he is at liberty to do
either this or that. I do not think that this argu- ment is sound. I think that clause (7)(a) can be
accurately paraphrased somewhat as follows :--" Parliament may dispense with an advisory board,
but in that case it shall prescribe the circumstances and the class or classes of cases ........ "If this is
the meaning, then ' 'and" must be read as "and" and not as "or"; and "may" must be read as "shall."
Supposing it was said that Parliament may prescribe the time and place for the doing of a thing,
then can it be suggested that both time and place should not be prescribed ? It seems obvious to me
that the class or classes of cases must have some reference to the persons to be detained or to their
activities and movements or to both.
"Circumstances" on the other hand refer to something extra- neous, such as
surroundings, background, prevailing condi- tions, etc., which might prove a fertile
field for the dangerous activities of dangerous persons. Therefore the provision
clearly means that both the circumstances and the class or classes of cases (which are
two different expres- sions with different meanings and connotations and cannot be
regarded as synonymous) should be prescribed, and prescrip- tion of one without
prescribing the other will not be enough. As I have already stated, such law as can be
enact- ed under article 22 (7) (a) must involve, by reason of the extreme limit to
which it can go, serious consequences to the persons detained. It will mean (1)
prolonged detention, i.e., detention for a period longer than three months, and (2)
deprivation of the safeguard of an advisory board. Hence article 22 (7) (a) which
purports to be a protective provi-
sion will cease to serve its object unless it is given a reasonable interpretation. To my mind, what it
contemplates is that the law in question must not be too general but its scope should be limited by
prescribing both the class or classes of cases and the circumstances.
It was contended that the expression "class or classes of cases" is wide enough to enable the
Parliament to treat any of the categories mentioned in Lists I and III, items 9 and 3 respectively,
(i.e., any of the categories A to F) as constituting a class. At first sight, it seemed to me to be a
plausible argument,, but the more I think about it the more unsound it appears to me. The chief
thing to be remem- bered is what I have already emphasized more than once, viz., that a special or
extreme type of law must be limited to special classes of cases and circumstances. Under the
Constitution, the Parliament has to prescribe "the class or classes," acting within the limits of the
power granted to it under Lists I and III. The class or classes must be its own prescription and must
be so conceived as to justify by their contents the removal of an important safeguard provid- ed by
the Constitution. Prescribing is more than a mere mechanical process. It involves a mental effort to
select and adapt the thing prescribed to the object for which it has to be prescribed. We find here
that what is to be prescribed is "class or classes" (and also "circumstances "). We also find that what
the law intends to provide is prolonged detention (by which words I shall hereafter mean detentionA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

for more than three months) and elimination of the advisory board. The class or classes to be
prescribed must therefore have a direct bearing on these matters and must be so selected and stated
that any one by looking at them may say :--" That is the reason why the law has prescribed
prolonged detention without reference to an advisory board." In other words, there must be
something to make the class or classes prescribed fit in with an extreme type of legisla- tion--some
element of exceptional gravity or menace, which cannot be easily and immediately overcome and
therefore necessitates prolonged detention; and there must be some- thing to show that reference to
an advisory board would be an undesirable and cumbersome process and wholly unsuitable for the
exceptional situation to which the law applies. Perhaps a simple illustration may make the position
still clearer. Under the Lists, one of the subjects on which Parliament may make a law of preventive
detention is "matter connected with the maintenance of public order." The Act simply repeats this
phraseology and states in sec- tion 3: "with a view to preventing him (the person to be detained)
from acting in a manner prejudicial to the main- tenance of public order." This may be all right for
section 3, but section 12 must go further. An act prejudicial to. the maintenance of public order may
be an ordinary act or it may be an act of special gravity. I think that article 22 (7)(a) contemplates
that the graver and more heinous types of acts falling within the category of acts prejudicial to the
maintenance of public order (or other heads) should be prescribed so as to define and cir- cumscribe
the area of an exceptional piece of legislation. That some kind of sub-classification (if I may be per-
mitted to use this word) of the categories A to F was possi- ble can be illustrated by reference to
regulation 18-]3 of the British Defence of the Realm Regulations. This regula- tion was made under
an Act of 1039 which authorized "the making of regulations for the detention of persons whose
detention appears to the Secretary of State to be expedient in the interests of public safety or the
defence of the realm." The two matters "public safety" and "defence of the realm" are analogous to
some of the heads stated in Lists I and III. It will be instructive to note that under these two heads,
regulation 18-B has set forth several subheads or class or classes of cases in which preventive
detention could be ordered. These classes are much more specific than what we find in section a of
the impugned Act and therefore there is less chance of misuse by the executive of the power to order
preventive detention. The classes set out are these :--(1) If the Secretary of State has reasonable
cause to believe any person to be of hostile origin or associa- tions, (2) if the Secretary of State has
reasonable cause to believe any person to have been recently concerned in acts prejudicial to the
public safety or the defence of the realm or in the preparation or instigation of such acts, (3) if the
Secretary of State has reasonable cause to believe any person to have been or to be a member of, or
to have been or to be active in the furtherance of the objects of, any such organization as is
hereinafter mentioned ...... (a) the organization is subject to foreign influence or control, (b) the
persons in control of the organization have or have had associations with, persons concerned in the
government of, or sympathies with the system of government of, any Power with which His Majesty
is at war, and in either case there is danger of the utilization of the organization for pur- poses
prejudicial to the public safety, etc., (4) if the Secretary of State has reasonable cause to believe that
the recent conduct of any person for the time being in an area or any words recently written or
spoken by such a person expressing sympathy with the enemy, indicates or indicate that person is
likely to assist the enemy. I have only to point out that the scope within which preventive detention
can be legislat- ed upon in this country is much larger than the scope indi- cated in the British Act
under which Regulation 18-B was framed, and therefore there is more scope for specification of the
circumstances as well as the class or classes of cases under the impugned Act. But all that has beenA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

done is that words which occur in the legislative Lists have been taken and transferred into the Act.
What I have stated with regard to class or classes of cases also applies to the circumstances which
are also to be prescribed under article 22 (7) (a). These circumstances are intended to supply the
background or setting in which the dangerous activities of dangerous persons might prove specially
harmful. They must be special circumstances which demand a specially drastic measure and under
which reference to an advisory board might defeat the very object of preven- tive action. The evident
meaning of article 22 (7) (a) seems to be that the picture will not be complete without mentioning
both the classes and the circumstances. There was some discussion at the Bar as to what kind of
circumstances might have been specified. It is not for me to answer this question, but I apprehend
that an impending rebellion or war, serious disorder in a particular area such as has induced the
Punjab Government to declare certain areas as "disturbed areas," tense communal situation,
prevalence of sabotage or widespread political dacoities and a variety of other matters might answer
the purpose the Constitution had in view.
I will now try to sum up the result of a somewhat pro- tracted discussion into which I had to enter
merely to clarify the meaning of a very important provision of the Constitution which has, in my
opinion, been completely misunderstood by the framers of the impugned Act. It appears to me that
article 22 deals with three classes of preventive detention :--
(1) preventive detention for three months; (2) preventive detention for more than
three months on the report of the advisory board; and (3) preventive detention for
more than three months without reference to the advisory board.
If one has to find some kind of a label for these class- es for a clear understanding of the subject, one
may label them as "dangerous," "more dangerous" and "most danger- ous." Now so far as the first
two classes are concerned, there is nothing to be prescribed under the Constitution Apparently, the
authors of the Constitution were not much concerned about class No. (1), and they thought that in
so far as class No. (2) was concerned the provision that a reference to the advisory board was
necessary coupled with the provision that detention was not to exceed the maximum period which
may be fixed by the Parliament was enough. But they did take care to make a special provision for
class No. (3), and it is extermly important for the liberty of the subject as well as for the smooth
working of the Constitu- tion that this provision should not be lightly treated but should receive a
well considered and reasonable construc- tion. It is elementary that the rigour of a law should
correspond to or fit the gravity of the evil or danger it aims at combating, and it is also evident that
the law which the Parliament has been permitted to enact under article 22 (7) (a) can, so far as
rigour is concerned, go to the I farthest limit. It follows that the law must have been intended for
exceptionally grave situations and exigencies. Hence the authors of the Constitution have made it
necessary that the Parliament should put certain specifications into the Act which it is empowered to
pass under article 22 (7)
(a), so that by means of these specifications the necessity for enacting so drastic a law should be
apparent on the face of it, and its application should be confined to the classes and circumstances
specified. The Act must prescribe (1) "c]ass or classes of cases" which are to have reference to theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

persons.
against whom the law is to operate and their activities and movements and (2) "circumstances"
which would bring into prominence the conditions and the backgrounds against which dangerous
activities should call for special measures. By means of such two-fold prescription, the sphere for the
application of the law will be confined only to a special type of cases--it will be less vague, less open
to abuse and enable those who have to administer it to determine objec- tively when a condition has
arisen to justify the use of the power vested in them by the law. This, in my opinion, is the true
meaning and significance of article 22 (7) (a) and any attempt to whittle it down will lead to
deplorable results.
Having stated my views as to the construction of article 22 (7) (a), I propose to consider at once
whether section 12 of the impugned Act conforms to the requirements of that provision. In my
opinion, it does not, because it fails to prescribe either the circumstances or the class or classes of
cases in the manner required by the Constitution. It does not prescribe circumstances at all, and,
though it purports to prescribe the class or classes, it does so in a manner showing that the true
meaning of the provision from which the Parliament derived its power has not been grasped. I have
sufficiently dwelt on this part of the case and shall not repeat what I have already said. But I must
point out that even if it be assumed that the view advanced by the learned Attorney-General is
correct and it was within the competence of Parliament to treat any of the categories mentioned in
items 9 and 3 of Lists I and III as constitut- ing a class and to include it without any qualification or
change, the impugned section cannot be saved on account of a two-fold error :--. (1) the word "and"
which links "class or classes" with "circumstances" in article 22 (7) (a) has been wrongly construed
to mean "or ;" and (2) the distinction between "circumstances" and "class or classes" has been
completely ignored and they are used as interchangeable terms. The first error appears to me to be
quite a serious one, because though the Constitution lays down two require- ments and insists on
the prescription of circumstances as well as class or classes, it has been assumed in enacting section
12 that prescription of one of them only will be enough. The other error is still more serious and goes
to the root of the matter. There can be no doubt that circumstances and class or classes are two
different expressions and have different meanings, but the Act proceeds on the assumption that cir-
cumstances are identical with class or classes, as will appear from the words "any person detained in
any of the following classes of cases or under any of the following circumstances" used in the
section. I have already shown how important the specification of circumstances is in legislation of
such an extreme and drastic character. There- fore, to confuse "classes" with "circumstances" and to
omit to mention "circumstances" at all are in my opinion grave errors. There can, in my opinion, be
no escape from the conclusion that section 12 of the Act by which a most impor- tant protection or
safeguard conferred on the subject by the Constitution has been taken away, is not a valid provision,
since it contravenes the very provision in the Constitution under which the Parliament derived its
competence to enact it.
I will now briefly deal with article 22 (5) which makes it incumbent on the authority ordering
preventive deten- tion to communicate to the person detained the grounds on which the order has
been made and to give him the earliest opportunity of making a representation against the order. It
must be remembered that this provision is intended to afford protection to and be a safeguard inA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

favour of a detained person, and it cannot be read as limiting any rights which he has under the law
or any other provisions of the Consti- tution. If article 21 guarantees that before a person is deprived
of his liberty he must be allowed an opportunity of establishing his innocence before an impartial
tribunal, that right still remains. In point of fact, there is no express exclusion of that right in the
Constitution and no prohibition against constituting an impartial tribunal. On the other hand, the
right to make a representation which has been granted under the Constitution, must carry with it
the right to the representation being properly considered by an impartial person or persons. There
must therefore be some machinery for properly examining the cases of the detenus and coming to
the conclusion that they have not been de- tained without reason. If this right had been expressly
taken away by the Constitution, there would have been an end of the matter, but it has not been
expressly taken away, and I am not prepared to read any implicit deprivation of such a valuable
right. The mere reference to an advisory board in article 22 (4) (a) does not, if my interpretation of
the provision is correct, exclude the constitution of a proper machinery for the purpose of examining
the cases of detenus on merits. The constitution of an advisory board for the purpose of reporting
whether a person should be detained for more than three months or not is a very different thing
from constituting a board for the purpose of reporting whether a man should be detained for a
single day. In the view I take, all that Parliament could do under clause (7) (a) of article 22 was to
dispense with an advisory board for the purpose contemplated in clause (4) (a) of that article and
not to dispense with the proper machinery, by whichever name it may be called, for the purpose of
examining the merits of the case of a detained person.
It was argued that article 22 is a code by itself and the whole law of preventive detention is to be
found within its four corners. I cannot however easily subscribe to this sweeping statement. The
article does provide for some mat- ters of procedure, but it does not exhaustively provide for them.
It is said that it provides for notice, an opportuni- ty to the detenu to represent his case, an advisory
board which may deal with his case, and for the maximum period beyond which a person cannot be
detained. These points have undoubtedly been touched, but it cannot be said that they have been
exhaustively treated. The right to represent is given, but it is left to the legislature to provide the
machinery for dealing with the representation. The advisory board has been mentioned, but it is
only to safeguard detention for a period longer than three months. There is ample latitude still left
to the Parliament, and if the Parliament makes use of that latitude unreasonably, article 19 (5) may
enable the Court to see whether it has transgressed the limits of reasonableness. I will now proceed
to deal with the Act in the light of the conclusions I have arrived at. So far as section 3 of the Act is
concerned, it was contended that it is most unreasonable, because it throws a citizen at the mercy of
certain authorities, who may at their own will order his detention and into whose minds we cannot
probe to see wheth- er there is any foundation for the subjective satisfaction upon which their action
is to rest. I am however unable to accept this argument. The administrative authorities who have to
discharge their responsibilities have to come to quick decisions and must necessarily be left to act on
their own judgment. This principle is by no means unreasonable and it underlies all the preventive
or quasi administrative measures which are to be found in the Criminal Procedure Code. Under
section 107 of that code, it is left to the discretion of the magistrate concerned to determine whether
in his opinion there is sufficient ground for proceeding against any person who is likely to occasion a
breach of the peace. Under section 145 also, his initial action depends upon his personal satisfaction.
Therefore I do not find anything wrong or unconstitutional in section 3 of the Act. But I must pointA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

out that it is a reasonable provision only for the first step, i.e., for arrest and initial detention, and
must be followed by some procedure for testing the so- called subjective satisfaction, which can be
done only by providing a suitable machinery for examining the grounds on which the order of
detention is made and considering the representations of the persons detained in relation to those
grounds.
I do not also find anything radically wrong in section 7 of the Act, which makes it incumbent on the
authority con- cerned to communicate to a detenu the grounds on which the order has been made
and to afford him the earliest opportunity of making a representa- tion against the order. Section 10
which provides that the advisory board shall make its report within ten weeks from the date of the
detention order is in conformity with arti- cle 22 (4) (a) of the Constitution, and the only comment
which one can make is that Parliament was not obliged to fix such a long period for the submission
of a report and could have made it shorter in ordinary cases. The real sections which appear to me to
offend the Constitution are sections 12 and 14. I have already dealt with the principal objec- tion to
section 12, while discussing the provisions of article 22 (7) (a) and I am of the opinion that section 12
does not conform to the provisions of the Constitution and is therefore ultra vires. I also think that
even if it be held that it technically complies with the requirements of article 22 (7) (a), Parliament
has acted unreasonably in exercising its discretionary power without applying its mind to essential
matters and thus depriving the detenus of the safeguard of an advisory board which the Constitution
has provided in normal cases. So far as section 14 is con- cerned, all my colleagues have held it to be
ultra vires, and, as I agree with the views expressed by them, I do not wish to encumber my
judgment by repeating in my own words what has been said so clearly and so well by them. Section
14 may be severable from the other provi- sions of the Act and it may not be possible to grant any
relief to the petitioner on the ground that section 14 is invalid. But I think that section 12 goes to the
very root of the legislation inasmuch as it deprives a detenu of an essential safeguard, and in my
opinion the petitioner is entitled to a writ of habeas corpus on the ground that an essential provision
of the Constitution has not been com- plied with. This writ will of course be without prejudice to any
action which the authorities may have taken or may hereafter take against the petitioner under the
penal law I have to add this qualification because there were allega- tions of his being involved in
some criminal cases but the actual facts were not clearly brought out before us.
I have only to add a few concluding remarks to my judg- ment. In studying the provisions of the
impugned Act, I could not help instituting a comparison in my own mind between it and similar
legislation in England during the last two world wars. I could not also help noticing that the
impugned Act purports to be a peacetime Act, whereas the legislation to which I have referred was
enacted during the war. During the first war as well as the second, a number of persons were
detained and a number of cases were brought to Court in connection with their detention, but the
two lead- ing cases which will be quoted again and again are Rex v. Halliday (1) and Liversidge v. Sir
John Anderson(2). We are aware that in America certain standards which do not conform to
ordinary and normal law have been applied by the Judges during the period of the war and
sometimes they are compen- dionsly referred to as being included in "war power." The two English
cases to which I have referred also illustrate the same principle, as will appear from two short
extracts which I wish to reproduce. In Rex v. Halliday (3), Lord Atkinson observed as follows :--"
However precious the personal liberty of the subject may be, there is something for which it mayA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

well be, to some extent, sacrificed by legal enactment, namely, national success in the' war, or escape
from national plunder or enslavement." In Liversidge v. Sir John Anderson (4), Lord Macmillan
struck the same note in these words :--
"The liberty which we so 'justly extol is itself the gift of the law and as Magna Charta
recognizes may by the law be forfeited or abridged. At a time when it is the
undoubted law of the land that a citizen may by conscription or requisition be
compelled to give up his life and all that he possesses for his country's cause it may
well be no matter for surprise that there should be confided to the Secretary of State a
discretionary power of enforcing the relatively mild precaution of detention."
(1) [1917] A.C.260. (3) [1917] A.C. 260atp. 271. [1942] A.C. 206. (4) [1942] A.C. 206 at p.
257. These passages represent the majority view in the two cases, but the very elaborate judgments
of Lord Shaw in Rex v. Halliday and that of Lord Atkin in Liversidge v. Sir John Anderson show that
there. was room for difference of opinion as well as for a more dispassionate treatment of the case
and the points involved in it. It is difficult to say that there is not a good substratum of sound law in
the celebrat- ed dictum of Lord Atkin that even amidst the clash of arms the laws are not silent and
that they speak the same lan- guage in war as in peace. However that may be, what I find is that in
the regulations made in England during the first war as well as the second war there was an
elaborate provi- sion for an advisory board in all cases without any excep- tion, which provided a
wartime safeguard for persons de- prived of their liberty. There was also a provision in the Act of
1939 that the Secretary of State should report at least once in every month as to the action taken
under the regulation including the number of persons detained under orders made thereunder. I
find that these reports were printed and made available to the public. I also find that the Secretary of
State stated in the House of Commons on the 28th January, 1943, that the general order would be to
allow British subjects detained under the Regulation to have consultations with their legal advisers
out of the hearing of an officer. This order applied to consultations with barristers and solicitors but
not to cases where solicitors sent to interview a detained person a clerk who was not an officer of the
High Court. The impugned Act suffers in com- parison, on account of want of such provisions,
though, so far as I can see, no great harm was likely to have been caused by setting up a machinery
composed of either adminis- trative or judicial authorities for examining the cases of detained
persons so as to satisfy the essentials of fairness and justice. The Act also suffers in comparison with
some of the later Provincial Acts in which the safeguard of an advisory board is , expressly provided
for. I find that there is a provision in section 12 (2) of the Act for the review of the cases of detenus
after six months, but this is quite different from examining the merits of the case. The object of such
a review is obviously to find out whether by reason of any change in the circumstances, a review of
the original order is required.
I hope that in pointing out the shortcomings of the Act I will not be misunderstood. I am aware that
both in Eng- land and in America and also in many other countries, there has been a reorientation of
the old notions of individual freedom which is gradually yielding to social control in many matters. I
also realize that those who run the State have very onerous responsibilities, and it is not correct to
say that emergent conditions have altogether disappeared from this country. Granting then thatA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

private rights must often be subordinated to the public good, is it not essen- tial in a free community
to strike a just balance in the matter ? That a person should be deprived of his personal liberty
without a trial is a serious matter, but the needs of society may demand it and the individual may
often have to yield to those needs. Still the balance between the maintenance of individual rights
and public good can be struck only if the person who is deprived of his liberty is allowed a fair
chance to establish his innocence, and I do not see how the establishment of an appropriate
machinery giving him such a chance can be an impediment to good and just government.
PATANJALI SASTRI J.--This is an application under arti- cle 32 of the Constitution of India for
releasing the petitioner from detention in jail without trial under directions purporting to be issued
by the Government of Madras under the Preventive Detention Act, 1950, and it has the distinction of
being the first application invoking the guaranteed protection of this Court as the guardian of
Fundamental Rights against alleged infringement of the petitioner's right to freedom of movement.
As the case involved issues of great public importance and breaking of new ground it was argued
with thoroughness and ability on both sides, reference being made to more or less analogous
provisions of the Constitutions of other countries and in particular the Constitution of the United
States of America.
The petitioner had been under detention previously under orders passed by the said Government
under the Madras Main- tenance of Public Order Act, 1947, but as the validity of that Act and all
other similar local public safety enact- ments had been questioned in some of the High Courts in
India after the new Constitution came into force, the Par- liament enacted a comprehensive measure
called the Preven- tive Detention Act, 1950, (hereinafter referred to as the impugned Act) extending
to the whole of India with a certain exception not material here.
The Act came into force on 25th February 1950, and, on the 27th February, the Government of
Madras, in purported exercise of the powers conferred by the impugned Act and in supersession of
earlier orders, directed the detention of the petitioner, and the order was served on him on 1st
March. The petitioner contends that the impugned Act and in particular sections 3, 7, 10, 11, 19,, 13
and 14 thereof take away or abridge the fundamental right to freedom of movement in contravention
of article 13 (2) of the Constitu- tion and is, therefore, void as declared therein. Article 13 is one of a
fasciculus of articles which are comprised in part III of the Indian Constitution headed
"Fundamental Rights." This Part forms a new feature of the Constitution and is the Indian "Bill of
Rights." It is modelled on the first ten Amendments of the American Con- stitution which declare
the fundamental rights of the American citizen. Article 12, which is the first article in this Part,
defines "the State" as including the Governments and Legislatures of the Union and the States as
well as all local and other authorities against which the fundamental rights are enforceable, and
article 13 (1) declares that all existing laws inconsistent with the provisions of Part III shall, to the
extent of the inconsistency, be void. Clause (2) of the article, on which the petitioner's con- tention is
primarily founded reads as follows:
"The State shall not make any law which takes away or abridges the rights conferred
by this Part and any law made in contravention of this clause shall, to the extent of
the contravention, be void."A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

As the constitutional inhibition against deprivation or abridgement relates only to "the rights
conferred by this Part," it is necessary first to ascertain the nature and extent of the right which,
according to the petitioner, Part III has conferred on him, and, secondly, to determine wheth- er the
right so ascertained has been taken away or abridged by the impugned Act or by any of its
provisions. The first question turns on the proper interpretation of the relevant articles of the
Constitution, and the second involves the consideration of the provisions of the impugned Act.
Mr. Nambiar appearing for the petitioner advanced three main lines of argument. In the first place,
the right to move freely throughout the territory of India referred to in article 19 (1)(d) is of the very
essence of personal liber- ty, and inasmuch as the detention authorised by the impugned Act was not
a "reasonable restriction" which Parliament could validly impose on such right under clause (5) of
the article, the impugned Act is void. Alternatively, the petitioner had a fundamental right under
article 21 not to be deprived of his personal liberty except according to procedure established by law,
and the impugned Act by autho- rising detention otherwise than in accordance with proper
procedure took away that right and was therefore void. And, lastly, the provisions of the impugned
Act already re- ferred to were ultra vires and inoperative as Parliament in enacting them has
overstepped the ]imitations placed on its legislative power by article 22 clauses (4) to (7).
Accordingly, the first question for consideration is whether article 19 (1) (d) and (5) is applicable to
the present case. "Liberty," says John Stuart Mill, "consists in doing what one desires. But the
liberty' of the individual must be thus far limited--he must not make him- self a nuisance to others."
Man, as a rational being, desires to do many things, but in a civil society his de- sires have to be
controlled, regulated and reconciled with the exercise of similar desires. by other individuals.
Liberty has, therefore, to be limited in order to be effectively possessed. Accordingly, article 19,
while guaranteeing some of the most valued phases or elements of liberty to every citizen as civil1
rights, pro- vides for their regulation for the common good by the State imposing certain
"restrictions" on their exercise. The power of locomotion is no doubt an essential element of
personal liberty which means freedom from bodily restraint, and detention in jail is a drastic
invasion of that liberty. But the question is: Does article 19, in its setting in Part III of the
Constitution, deal with the deprivation of per- sonal liberty in the sense of incarceration ?
Sub-clause (d) of clause (1) does not refer to freedom of movement simplic- iter but guarantees the
right to move freely "throughout the territory of India." Sub-clause (e) similarly guaran- tees the
right to reside and settle in any part of the territory of India. And clause (5) authorises the imposi-
tion of "reasonable restrictions" on these rights in the interests of the general public or for the
protection of the interests of any Scheduled Tribe. Reading these provisions together, it is
reasonably clear that they were designed primarily to emphasise the factual unity of the territory of
India and to secure the right of a free citizen to move from one place in India to another and to
reside and settle in any part of India unhampered by any barriers which nar- row-minded
provincialism may seek to interpose. The use of the word "restrictions" in the various sub-clauses
seems to imply, in the context, that the rights guaranteed by the article are still capable of being
exercised, and to exclude the idea of incarceration though the words "restriction" and "deprivation"
are sometimes used as interchangeable terms, as restriction may reach a point where it may well
amount to deprivation. Read as a whole and viewed in its setting among the group of provisions
(articles 19-22) relating to "Right to -Freedom," article 19 seems to my mind to pre--suppose thatA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the citizen to whom the possession of these fundamental rights is secured retains the substratum of
personal freedom on which alone the enjoyment of these rights necessarily rests. It was said that
subclause (f) would militate against this view, as the enjoyment of the right "to acquire, hold and
dispose of property" does not depend upon the owner retaining his personal freedom. This
assumption is obviously wrong as regards moveable proper- ties, and even as regards immoveables
he could not acquire or dispose of them from behind the prison bars; nor could he "hold" them in
the sense of exercising rights of possession and control over them which is what the word seems to
mean in the context. But where, as a penalty for committing a crime or otherwise, the citizen is
lawfully deprived of his freedom, there could no longer be any ques- tion of his exercising or
enforcing the rights referred to in clause (1). Deprivation of personal liberty in such a situation is
not, in my opinion, within the purview of article 19 at all but is dealt with by the succeeding arti- cles
20 and 21. In other words, article 19 guarantees to the citizens the enjoyment of certain civil liberties
while they are free, while articles 20-22 secure to all persons--citizens and non-citizens--certain
constitutional guarantees in regard to punishment and prevention of crime. Different criteria are
provided by which to measure legisla- tive judgments in the two fields, and a construction which
would bring within article 19 imprisonment in punishment of a crime committed or in prevention of
a crime threatened would, as it seems to me, make a reductio ad absurdum of that provision. If
imprisonment were to be regarded as a "restriction" of the right mentioned in article 19 (1)(d), it
would equally be a restriction on the rights mentioned by the other subclauses of clause (1), with the
result that all penal laws providing for imprisonment as a mode of punish- ment would have to run
the gauntlet of clauses (2) to (6) before their validity could be accepted. For instance,the law which
imprisons for theft would, on that view, fall to be justified under clause (2) as a law sanctioning
restric- tion of freedom of speech and expression. Indeed, a Divi- sion Bench of the Allahabad High
Court,in a recent unreport- ed decision brought to our notice applied the test of undermining the
security of the State or tending to overthrow it in determining the validity or otherwise of the
impugned Act. The learned Judges construed article 19 as covering cases of deprivation of personal
liberty and held, logically enough, that inasmuch as the impugned Act, by authorising preventive
detention, infringed the right to freedom of speech and expression, its validity should be judged by
the reservations in clause (2), and, as it failed to stand that test, it was unconstitutional and void.
Mr. Nambiar did not seek to go so far. He drew a dis- tinction between the right conferred by
sub-clause (d) and those conferred by the other sub-clauses. He urged, refer- ring to Blackstone's
Commentaries, that personal liberty consisted "in moving one's person to whatever place one's
inclination might direct," and that any law which de- prived a person of such power of locomotion
was a direct invasion of the right mentioned in sub-clause (d), whereas it inter-fered only indirectly
and consequentially with the rights mentioned in the other sub Clauses. There is no substance in the
distinction suggested. It would be illogi- cal, in construing article 19, to attribute to one of the
sub-clauses a scope and effect totally different from the scope and effect of the others or to draw a
distinc-. tion between one right and another in the group. All the rights mentioned in clause (1) are
equally essential elements in the liberty of the individual in any civilised and democrat- ic
community, and imprison, ment operates as an extinction of all of them alike. It cannot, therefore,
be said that deprivation of personal liberty is an infringement of the right conferred by sub-clause
(d) alone but not of the others. The learned Judges of the Allahabad High Court realised this and
were perfectly logical in holding that the constitutional validity of a law providing for deprivation ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

personal liberty or imprisonment must be judged by the tests laid down not only in clause (5) of
article 19 but also in the other clauses including clause (2), though their major premise that
deprivation of personal liberty was a "restriction" within the meaning of article 19 is, in my
judgment, erroneous.
It was said that preventive detention being a drasic re- striction of the right to move freely was, in its
pith and substance," within article 19 (1) (d) read with clause (5) and not within article 21 which
deals with crime and its punishment and prevention. There is no room here, in my opinion, for the
application of the rule of "pith and sub- stance." As pointed out by the Privy Council in Prafulla
Kumar Mukherjee v. The Bank of Commerce Ltd., Khulna (1), approving the observations of the
Federal Court in Subrah- manyam Chettiar v. Muttuswamy Goundan (2), the rule was evolved by
the Board for determining whether an impugned statute was, in its true character, legislation with
respect to matters within the jurisdiction of one legislature or another in a scheme of divided
legislative power. No such question arises here. What the Court has to ascertain is the true scope
and meaning of article 19 in the context of Part III of the Constitution, in order to decide whether
depriva- tion of personal liberty falls within that article, and the pith and substance rule will be more
misleading than helpful in the decision of that issue. Article 19, as I have already indicated,
guarantees protection for the more important civil liberties of citizens who are in the enjoyment of
their freedom, while at the same time laying down the re- strictions which the legislature may
properly impose on the exercise of such rights, and it has nothing to do with deprivation of personal
liberty or imprisonment which is dealt with by the succeeding three articles. There is also another
consideration which points to the same conclusion. The ]Drafting Committee of the Constituent
Assembly, to whose Report reference was freely made by both sides during the argument,
recommended "that the word liber- ty should be qualified by the insertion of the word 'person- al '
before it, for otherwise it might be construed very widely so as to include even the freedoms already
dealt with in article 13" (now article 19). The acceptance of this suggestion shows that whatever may
be the generally accepted (1) 74 I.A. 23. (2) [1940] F.C.E. 188.
connotation of the expression "personal liberty," it was used in article 21 in a sense which excludes
the freedoms dealt with in article 19, that is to say, personal liberty in the context of Part III of the
Constitution is something distinct from the freedom to move freely throughout the territory of India.
It was further submitted that article 19 declared the substantive rights of personal liberty while
article 21 provided the procedural safeguard against their deprivation. This view of the correlation
between the two articles has found favour with some of the Judges in the High Courts which have
had occasion to consider the constitutional validity of the impugned Act. It is, however, to be ob-
served that article 19 confers the rights therein specified only on the citizens of India, while article 21
extends the protection of life and personal liberty to all persons--citizens and noncitizens alike.
Thus, the two articles do not operate in a conterminous field, and this is one reason for rejecting the
correlation suggested. Again, if article 21 is to be understood as providing only proce- dural
safeguards, where is the substantive right to personal liberty of non-citizens to be found in the
Constitution ? Are they denied such right altogether ? If they are to have no right of personal liberty,
why is the proce- dural safeguard in article 21 exended to them ? And where is that most
fundamental right of all, the right to life, provided for in the Constitution ? The truth is that arti- cleA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

21, like its American prototype in the Fifth and Four- teenth Amendments of the Constitution of the
United States, presents an example of the fusion of procedural and substan- tive rights in the same
provision. The right to live, though the most fundamental of all, is also one of the most difficult to
define and its protection generally takes the form of a declaration that no person shall be deprived of
it save by due process of law or by authority of law. "Process" or "procedure" in this context connotes
both the act and the manner of proceeding to take away a man's life or per- sonal liberty. And the
first and essential step in a proce- dure established by law for such deprivation must be a law made
by a competent legislature Authorising such deprivation. This brings me to the consid- eration of
articles 21 and 22 to which was deroted the greater part of the debate at the Bar.
These articles run as follows:
"21. No person shall be deprived of his life or person- al liberty except according to
procedure established by law.
22. (1) No person who is arrested shall be detained in custody without being
informed, as soon as may be, of the grounds for such arrest, nor shall he be denied
the right to consult, and to be defended by, a legal practitioner of his choice.
(2) Every person who is arrested and detained in custody shall be produced before
the nearest magistrate within a period of twenty-four hours of such arrest excluding
the time necessary for the journey from the place of arrest to the Court of the
magistrate and no such person shall be detained in custody beyond the said period
without the authority of a magistrate.
(3) Nothing in clauses '(1) and (2) shall apply
(a) to any person who for the time being is an enemy alien; or
(b) to any person who is arrested or detained under any law providing for preventive
detention.
(4) No law providing for preventive detention shall authorise the detention of a
person for a longer period than three months unless-
(a) an Advisory Board consisting of persons who, are, or have been, or are qualified to
be appointed as, Judges of a High Court has reported before the expiration of the said
period of three months that there is in its opinion suffi-
cient cause for such detention:
Provided that nothing in this sub-clause shall' autho- rise the detention of any person
beyond the maximum period prescribed by any law made by parliament under
sub-clauseA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(b) of clause (7); or
(b) such person is detained in accordance with the provisions of any law made by
Parliament under sub-clauses
(a) and (b) of clause (7).
(5) When any person is detained in pursuance of an order made under any law
providing for preventive detention, the authority making the order shall, as soon as
may be, commu-
nicate to such person the grounds on which the order has been made and shall afford him the
earliest opportunity of making a representation against the order.
(6) Nothing in clause (5) shall require the authority making any such order as is referred to in that
clause to disclose facts which such authority considers to be against the public interest to disclose.
(7) Parliament may by law prescribe
(a) the circumstances under which, and the class or classes of cases in which, a person may be
detained for a period longer than three months under any law providing for preven- tive detention
without obtaining the opinion of an Advisory Board in accordance with the provisions of sub-clause
(a) of clause (4);
(b) the maximum period for which any person may in any class or classes of cases be detained under
any law provid- ing for preventive detention; and
(c) the procedure to be followed by an Advisory Board in an inquiry under sub-clause (a) of clause
(4)." Mr. Nambiar urged that the word "law" in article 21 should be understood, not in the sense of
an enactment but as signifying the immutable and universal principles of natural justice--the jus
naturale of the civil law--and that the expression "procedure established by law" meant the same
thing as that famous phrase "due process of law"
in the American Constitution in its procedural aspect. Numerous American decisions
were cited to show that the phrase implied the basic requirements of (1) an objective
and ascertainable standard of conduct to which it is possi- ble to conform, (2) notice
to the party of the accusation against him, (3) a reasonable opportunity for him to
estab- lish his innocence, and (4) an impartial tribunal capable of giving an unbiased
judgment Mr. Nambiar conceded that these requirements might have to be modified
or adapted to suit the nature of the particular proceeding and the object it had in
view, as for instance, in a case of preventive detention, previous notice, which might
result in the person concerned going underground might be dispensed with Learned
counsel insisted that these requirements, being the very core of the principles of
natural justice which transcended all State- made laws, must be substantiallyA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

complied with by any law governing the process of deprivation of life or personal
liberty, subject, of course, to any express provision in the Constitution sanctioning
their relaxation or dispensation in any case or class of cases. He also appealed to the
Pream- ble of the Constitution as the guiding star in its interpre- tation to support his
thesis that, in view of the democratic Constitution which the people of India have
purported to give themselves guaranteeing to the citizens certain funda- mental
rights which are justiciabke, the provisions of Part III must be construed as being
paramount to the legislative will, as otherwise the socalled fundamental right to life
and personal liberty would have no protection against legis- lative action, and article
13 12) would be rendered nugato- ry.
There can be no doubt that the people of India have, in exercise of their sovereign will
as expressed in the Pream- ble, adopted the democratic ideal which assures to the
citizen the dignity of the individual and other cherished human values as a means to
the full evolution and expression of his personality, and in delegating to the
legislature, the executive and the judiciary their respective powers in the
Constitution, reserved to themselves certain fundamental rights, socalled, I
apprehend, because they have been re- tained by the people and made paramount to
the delegated powers, as in the American model. Madison (who played a prominent
part in framing the First Amendment of the Ameri- can Constitution) pointing out
the distinction, due to historical reasons, between the American and the British ways
of securing "the great and essential rights of the people," observed "Here they are
secured not by laws para- mount to prerogative but by Constitutions paramount to
laws:" Report on the Virginia Resolutions, quoted in Near v. Minnesota (1).
(1) 283 U.S. 697.
This has been translated into positive law in Part III of the Indian Constitution, and I agree that in
construing these provisions the high purpose and spirit of the Preamble as well as the constitutional
significance of a Declaration of Fundamental Rights should be borne in mind. This, howev- er, is not
to say that the language of the provisions should be stretched to square with this or that
constitutional theory in disregard of the cardinal rule of interpretation of any enactment,
constitutional or other, that its spirit, no less than its intendment should be collected primarily from
the natural meaning of the words used.
Giving full effect to these principles, however, I am unable to agree that the term "law" in article 21
means the immutable and universal principles of natural justice.
"Procedure established by law" must be taken to refer to a procedure which has a
statutory origin, for no procedure is known or can be said to have been established by
such vague and uncertain concepts as "the immutable and universal principles of
natural justice." In my opinion, "law" in article 21 means "positive or State-made
law."A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

No doubt, the American Judges have adopted the other connotation in their interpretation of the
due process clause in the Fifth and Fourteenth Amendments of the Ameri- can Constitution (" Nor
shall any person be deprived of life, liberty or property without due process of law "). But that clause
has an evolutionary history behind it. The phrase has been traced back to 28 Edw. III Ch. 3, and
Coke in his Institutes identified the term with the expression "the law of the land" in the Great
Charter of John. Even in England where the legislative omnipotence of Parliament is now firmly
established, Coke understood these terms as implying an inherent limitation on all legislation,and
ruled in Dr. Bonham's Case (1) that "the common law will control Acts of Parliament and sometimes
adjudge them to be utterly void when they are against common right and reason." Though this
doctrine was later discarded in England as being "a warning (1) 8 Rep. 118 (a).
rather than an authority to be followed" [per Willes J. in Lee v. Dude and Torrington Ry. (1)] it
gained ground m America, at first as a weapon in the hands of the Revolu- tionists with which to
resist the laws of Parliament, and later as an instrument in the hands of the Judges for estab- lishing
the supremacy of the judiciary [see Calder v. Bull ("')]. In the latter half of the 19th century, this doc-
trine of a transcendental common law or natural justice was absorbed in the connotation of the
phrase "due process of law" occurring in the Fifth and Fourteenth Amendments. By laying emphasis
on the word" due," interpreting "law" as the fundamental principles of natural justice and giving the
words "liberty" and "property" their widest meaning, the Judges have made the due process clause
into a general restriction on all legislative power. And when that power was threatened with
prostration by the excesses of due process, the equally vague and expansive doctrine of "police
power," i.e., the power of Government to regulate private rights in public interest, was evolved to
counteract such excesses. All this has been criticised as introducing great uncertainty in the state of
the law in that country, for no one could be sure how due process of law would affect a particular
enactment. A century after the phrase had been the subject of judicial interpretation one learned
Judge observed in 1877 that it was incapable of precise definition and that its intent and application
could only be ascer- tained by "the gradual process of inclusion and exclusion"
[Davidson v. New Orleans (3)]and, as recently as 1948, another Judge referred to the
difficulty of "giving defi- niteness to the vague contours of due process" and "of
spinning judgment upon State action out of that gossamer concept:" Haley v. State of
Ohio (4).
It is not a matter for surprise, therefore, that the Drafting Committee appointed by
the Constituent Assembly of India recommended the substitution of the expression
"except according to procedure (1) (1871) L.R. 6 C.P. 576, 582. (3) 96 U.S.
97. (1798) 3 Dallas 386. (4) 332 U.S.
596.
established by law" taken from the Japanese Constitution, 1946, for the words "without due process
of law" which occurred in the original draft, "as the former is more specific." In their Report the
Committee added that they have "attempted to make these rights (fundamental rights) and the.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

limitations to which they must necessarily be subject as definite as possible, since the Courts may
have to pronounce upon them" (para. 5). In the face of all these considerations, it is difficult to
accept the suggestion that "law" in. article 21 stands for the jus naturale of the civil law, and that the
phrase "according to procedure established by law" is equivalent to due process of law in its
procedural aspect, for that would have the effect of introducing into our Constitution those "subtle
and elusive criteria" implied in that phrase which it was the deliberate purpose of the framers of our
Constitution to avoid. On the other hand, the interpretation suggested by the Attorney-General on
behalf of the intervener that the ex- pression means nothing more than procedure prescribed by any
law made by a competent legislature is hardly more accept- able. "Established" according to him,
means prescribed, and if Parliament or the Legislature of a State enacted a proce- dure, however
novel and ineffective for affording the ac- cused person a fair opportunity of defending himself, it
would be sufficient for depriving a person of his life or personal liberty. He submitted that the
Constituent Assem- bly definitely rejected the doctrine of judicial supremacy When it rejected the
phrase "due process of law" and made the legislative will unchallengeable, provided only "some
procedure" was laid down. The Indian Constitution having thus preferred the English doctrine of
Parliamentary supremacy, the phrase "procedure established by law" must be construed in
accordance with the English view of due process of law, that is to say, any procedure which
Parliament may choose to prescribe. Learned counsel drew attention to the speeches made by
several members of the Assembly on the floor of the House for explaining, as he put it, the "his-
torical background." A speech made in the course of the debate on a bill could at best be indicative of
the subjective intent of the speaker, but it could not reflect the inarticulate mental processes lying
behind the majority vote which carried the bill. Nor is it reasonable to assume that the minds of all
those legislators were in accord. The Court could only search for the objec- tive intent of the
legislature primarily in the words used in the enactment, aided by such historical material as reports
of statutory committees, preambles etc. I attach no importance, therefore, to the speeches made by
some of the members of the Constituent Assembly in the course of the debate on article 15 (now
article 21).
The main difficulty I feel in accepting the construction suggested by the Attorney-General is that it
completely stultifies article 13 (2) and, indeed, the very conception of a fundamental right. It is of
the essence of that con- ception that it is protected by the fundamental law of the Constitution
against infringement by ordinary legislation. It is not correct to say that the Constitution has
adopted the doctrine of Parliamentary supremacy. So far, at any rate, as Part III is concerned, the
Constitution, as I have already observed, has accepted the American view of funda- mental rights.
The provisions of articles 13 and 32 make this reasonably clear. Could it then have been the inten-
tion of the framers of the Constitution that the most impor- tant fundamental rights to life and
personal liberty should be at the mercy of legislative majorities as, in effect, they would be if
"established" were to mean merely "pre- scribed ?" In other words, as an American Judge said in a
similar context, does the constitutional prohibition in article 13 (2) amount to no more than "You
shall not take away life or personal freedom unless you choose to take it away," which is mere
verbiage. It is no sound answer to say that, if article 21 conferred no right immune from legisla- tive
invasion, there would be no question of contravening article 13 (2). The argument seems, to my
mind, to beg the question, for it assumes that the article affords no such immunity. It is said that
article 21 affords no protection against competent legislative action in the field of substantiveA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

criminal law, for there is no provision for judicial review, on the ground of reasonable- ness or
otherwise, of such laws, as in the case of the rights enumerated in article 19. Even assuming it to be
so the construction of the learned Attorney. General would have the effect of rendering wholly
ineffective and illusory even the procedural protection which the article was un- doubtedly designed
to afford. It was argued that "law" in article 31 which provides that no person shall be deprived of his
property "save by authority of law" must mean enacted law and that if a person's property could be
taken away by legislative action, his right to life and personal liberty need not enjoy any greater
immunity. The analogy is mis- leading. Clause (2) of article 31 provides for payment of
compensation and that right is justiciable except in the two cases mentioned in clauses (4) and (6)
which are of a tran- sitory character. The constitutional safeguard of the right to property in the said
article is, therefore, not so illu- sory or ineffective as clause (1) by itself might make it appear, even
assuming that" law" there means ordinary legis- lation.
Much reliance was placed on the Irish case The King v. The Military Governor of Hare Park Camp
(1) where the Court held that the term "law" in article 6 of the Irish Constitu- tion of 1922 which
provides that "the liberty of the person is inviolable and no person shall be deprived of his liberty
except in accordance with law" meant a law enacted by the Parliament, and that therefore the Public
Safety Act of 1924 did not contravene the Constitution. The Court followed The King v. Halliday(2)
where the House of Lords by a majority held that the Defence of the Realm (Consolidation) Act,
1914, and the Regulations framed thereunder did not infringe upon the Habeas Corpus Acts and the
Magna Carta "for the simple reason that the Act and the Orders become part of the law of the land."
But that was because, as Lord Dunedin pointed out "the British Constitution has entrusted to the
two Houses of parliament subject to the assent (1) [19241 2 I.R. 104. (2) [1917] A.C.
260. of the King, an absolute power untrammelled by any written instrument obedience to which
may be compelled by some judicial body," whereas the Irish Constitution restricted the legislative
powers of the Irish Parliament by a formal declaration of funda mental rights and by providing for a
judicial review of legislation in contravention of the Constitution (article 65). This radical distinction
was overlooked.
The Attorney-General further submitted that, even on his interpretation, article 21 would be a
protection against violation of the rights by the executive and by individuals, an d that would be
sufficient justification for the article ranking as a fundamental safeguard. There is no substance in
the suggestion. As pointed out in Eshugbayi Eleko v. Gov- ernment of Nigeria (Officer
Administering) (1), the execu- tive could only act in pursuance of the powers given by law and no
constitutional protection against such action is really needed. Even in monarchical Britain the
struggle between prerogative and law has long since ended in favour of the latter. "In accordance
with British jurisprudence"
said Lord Atkin in the case cited above, "no member of the executive can interfere
with the liberty or property of a British subject except on the condition that he can
support the legality of his action before a Court of justice." As for protection against
individuals, it is a misconception to think that constitutional safeguards are directed
against individuals. They are as a rule directed against the State and its organs.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Protection against violation of the rights by individuals must be sought in the
ordinary law. It is therefore difficult to accept the suggestion that article 21 was
designed to afford protection only against infringements by the executive or
individuals. On the other hand,the insertion of a declaration of Fundamental Rights
in the forefront of the Constitution, coupled with an express prohibition against
legislative interference with these rights (article 13) and the provision of a
constitutional sanction for the enforcement of such prohibition by means of a judicial
review (article 32) is, in my (1) [1931] A.C. 662.
opinion, a clear and emphatic indication that these rights are to be paramount to ordinary
State-made laws. After giving the matter my most careful and anxious consideration, I have come to
the conclusion that there are only two possible solutions of the problem. In the first place, a
satisfactory via media between the two extreme positions contended for on either side may be found
by stressing the word "established" which implies some degree of firmness, permanence and general
acceptance, while it does not exclude origination by statute. "Procedure estab- lished by law" may
well be taken to mean what the Privy Council referred to in King Emperor v. Benoari Lal Sharma (1)
as "the ordinary and well-established criminal proce- dure," that is to say, those settled usages and
normal modes of proceeding sanctioned by the Criminal Procedure Code which is the general law of
criminal procedure in the coun- try. Their Lordships were referring to the distinction between trial
by special Courts provided by an Ordinance of the Governor-General and trial by ordinary Courts
under the Criminal Procedure Code. It can be no objection to this view that the Code prescribes no
single and uniform proce- dure for all types of cases but provides varying procedures for different
classes of cases. Certain basic principles emerge as the constant factors common to all those proce-
dures, and they form the core of the procedure established by law. I realise that even on this view,
the life and liberty of the individual will not be immune from legisla- tive interference, for a
competent legislature may change the procedure so as to whittle down the protection if so minded.
But, in the view I have indicated, it must not be a change ad hoc for any special purpose or occasion,
but a change in the general law of procedure embodied in the Code. So long as such a change is not
effected, the protection under article 21 would be available. The different measures of constitutional
protection which the fundamental right to life and personal liberty will enjoy under article 21 as
interpreted in the three ways (1) [1945] F.C.R. 161,175.
referred to above will perhaps be best illustrated by a concrete example. Suppose that article 22 (1)
was not there and Parliament passed an Act, as a temporary measure, taking away in certain cases
the right of an accused person to be defended by a legal practitioner. According to the petition- er's
learned counsel the Act would be void as being contrary to the immutable principles of natural
justice embodied in article 21, whereas on the construction contended for by the Attorney-General,
the Act would be perfectly valid, while, on the view I have indicated above, the Act would be bad, but
if the denial of such right of defence is made a normal feature of the ordinary law of criminal
procedure by abro- gating section 340 (1)of the Code, article 21 would be powerless to protect
against such legislative action. But in a free democratic republic such a drastic change in the normal
law of procedure, though theoretically possi- ble, would be difficult to bring about, and that practical
difficulty will be the measure of the protection afforded by article 21.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

It was said that the safeguards provided in clauses (1) and (2) of article 22 are more or less covered
by the provisions of the Criminal Procedure' Code, and this overlapping would have been avoided if
article 21 were intended to bear the construction as indicated above. The argument overlooks that,
while the provisions of the Code would be liable to alteration by competent legislative action, the
safeguards in clauses (1)and (2) of article 22, being constitutional, could not be similarly dealt with:
and this sufficiently explains why those safeguards find a place in the Constitution.
The only alternative to the construction I have indi- cated above, if a constitutional transgression is
to be avoided, would be to interpret the reference to "law" as implying a constitutional amendment
pro tanto, for it is only a law enacted by the procedure provided for such amend- ment (article 368)
that could modify or override a fundamen- tal right without contravening article 13 (2).
The question next arises as to how far the protection under article 21, such as it has been found to
be, is avail- able to persons under preventive detention. The learned Attorney-General contended
that article 21 did not apply to preventive detention at all, as article 22 clauses (4) to (7) formed a
complete code of constitutional safeguards in respect of preventive detention,and, provided only
these provisions are conformed to, the validity of any law relat- ing to preventive detention could
not be challenged. I am unable to agree with this view. The language of article 21 is perfectly general
and covers deprivation of personal liberty or incarceration, both for punitive and preventive
reasons. If it was really the intention of the framers of the Constitution to exclude the application of
article 21 to cases of preventive detention, nothing would have been easier than to add a reference to
article 21 in clause (3) of article 22 which provides that clauses (1) and (2) of the latter shall not
apply to any person who is arrested or detained under any law providing for preventive detention
Nor is there anything in the language of clauses (4) to (7) of article 22 leading necessarily to the
inference that article 21 is inapplicable to preventive detention. These clauses deal only with certain
aspects of preventive deten- tion such as the duration of such detention, the constitu- tion of an
advisory board for reviewing the order of deten- tion in certain cases, the communication of the
grounds of detention to the person detained and the provision of an opportunity to him of making a
representation against the order. It cannot be said that these provisions form an exhaustive code
dealing with all matters relating to preven- tive detention and cover the entire area of protection
which article 21, interpretedin the sense I have indicated above, would afford to the person detained.
I am, therefore, of opinion that article 21 is applicable to preventive deten- tion as well.
I will now proceed to examine whether the impugned Act or any of its provisions under which the
petitioner has been ordered to be detained, takes away any of the rights con- ferred by articles 21
and 22 or infringes the protection afforded thereby. The outstanding fact to be borne in mind in this
connection is that preventive detention has been given a constitutional status. This sinister-looking
feature, so strangely out of place in a democratic constitution which invests personal liberty with the
sacrosanctity of a fundamental right and so incompatible with the promises of its preamble is
doubtless designed to prevent an abuse of freedom by anti-sOcial and subversive elements which
might imperil the national welfare of the infant Republic. It is in this spirit that clauses (3) to (7) of
article 22 should, in my opinion, be con- strued and harmonised as far as possible with article 21 so
as not to diminish unnecessarily the protection afforded for the legitimate exercise of personal
liberty. In the first place, as already stated, clause (3) of article 22 excludes a, person detained underA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

any law providing for preventive detention from the benefit of the safeguards provided in clauses (1)
and (2) No doubt clause (5) of the same article makes some amends for the deprivation of these
safeguards in that it provides for the communication to the person detained the grounds on which
the order has been made and for an opportunity being afforded to him of making a representation
against the order, but the important right to consult and to be defended by a legal practitioner of his
choice is gone. Similarly, the prohibition against detention in custody beyond a period of 24 hours
without the authority of a magistrate has also been taken away m cases of preventive detention. It
was not disputed that, to the extent to which the express provisions of clauses (4) to (7) authorised
the abrogation or abridgement of the safeguards provided under other articles or substitution of
other safeguards in a modified form, those express provisions must rule. Of the four essentials of the
due process on which Mr. Nambiar insisted, (which also form part of the ordinary and established
procedure under the Criminal Procedure Code, though I cannot agree that they are immutable and
beyond legislative change) the requirements of notice and an opportunity to establish his innocence
must, as already stated, be taken to have been provided for by clause (5)of article 22. As for an
ascertainable standard of conduct to which it is possible to conform, article 22 makes no specific
provision in cases of preventive detention, and if such a safeguard can be said to be implicit in the
procedure established by law in the sense explained above in preventive detention cases, it could no
doubt be invoked. This point will be considered presently in dealing with provisions of the
impugned Act. The only other essential requirement, and the most essen- tial of all, is an impartial
tribunal capable of giving an unbiassed verdict. This, Mr. Nambiar submitted, was left unprovided
for by article 22, the advisory board referred to in clause (4) (a) being, according to him, intended to
deal solely with the question of duration of the detention, that is to say, whether or not there was
sufficient cause for detaining the person concerned for more than three months, and not with
judging whether the person detained was innocent. A tribunal which could give an unbiassed judg-
ment on that issue was an essential part of the protection afforded by article21 in whichever way it
may be interpret- ed, and reference was made in this connection to the preven- tive provisions of the
Criminal Procedure Code (Ch. VIII). The impugned Act, not having provided for such a tribunal
contravened article 21 and was therefore void. It will be seen that the whole of this argument is
based on the major premise that the advisory board mentioned in clause (4) (a) of article 22 is not a
tribunal intended to deal with the issue of justification of detention. Is that view correct? It was
argued that the words "sufficient cause for such detention" in sub-clause (a) of clause (4) had
reference to the detention beyond three months mentioned in clause (4) and that this view was
supported by the language of sub- clause (a) of clause (7) whereby Parliament is authorised to
prescribe the circumstances under'which and the class or classes of cases in which a person may be
detained for a period longer than three months without the opinion of an advisory board. In other
words, learned counsel submitted, the combined effect of clauses (4) and (7) was that no person
could be detained for a period over three months without obtaining the opinion of an advisory board
that there was sufficient cause for detention for the longer period, except in cases where Parliament
passed a law autho- rising detention for such period even without the opinion of an advisory board.
Thus, these two clauses were concerned solely with the duration of the preventive detention, and so
was the advisory board which those clauses provided for that purpose. I am unable to accept this
view. I am inclined to think that the words "such detention" in sub-clause (a) refer back to the
preventive detention mentioned in clause (4) and not to detention for a longer period than three
months. An advisory board, composed as it has to be of Judges or lawyers, would hardly be in aA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

position to judge how long a person under preventive detention, say, for reasons connected with
defence, should be detained. That must be a matter for the executive authorities, the Depart- ment
of Defence, to determine, as they alone are responsible for the defence of the country and have the
necessary data for taking a decision on the point. All that an advisory board can reasonably be asked
to do, as a safeguard against the misuse of the power, is to judge whether the detention is justified
and not arbitrary or mala fide. The -fact that the advisory board is required to make its report before
the expiry of three months and so could submit it only a day or two earlier cannot legitimately lead
to an inference that the board was solely concerned with the issue whether or not the detention
should continue beyond that period. Before any such tribunal could send in its report a reasonable
time must elapse, as the grounds have to be communicated to the person detained, he has to make
his representation to the detaining authority which has got to be placed before the board through
the appropriate departmental channel. Each of these steps may, in the course Of official routine,
take some time, and 'three months' period might well have been thought a reasonable period to
allow before the board could be-required to submit its report.
Assuming, however, that the words "such detention" had reference to the period of detention, there
is no apparent reason for confining the enquiry by the advisory board to the sole issue of duration
beyond three months without reference to the question as to whether the detention was justified or
not. Indeed, if is difficult to conceive how a tribunal could fairly judge whether a person should be
detained for more than three months without at the same time considering whether there was
sufficient cause for the detention at all. I am of opinion that the advisory board referred to in clause
(4) is the machinery devised by the Constitution for reviewing orders for preventive detention in
certain cases on a consideration of the representations made by the persons detained. This is the
view on which Parliament has proceeded in enacting the impugned Act as will be seen from sections
9 and 10 thereof, and I think it is the correct view. It follows that the petitioner cannot claim to have
his case judged by any other impartial tribu- nal by virtue of article 21 or otherwise.
Mr. Nambiar, however, objected that, on this view, a law could authorise preventive detention for
three months with- out providing for review by any tribunal, and for even longer periods if
Parliament passed an Act such as is con- templated in sub-clause (a) of clause (7). That may be so,
but, however deplorable such a result may be from the point of view of the person detained, there
could be no remedy if, on a proper construction of clauses (4) and (7), the Consti- tution is found to
afford no higher protection for the personal liberty of the individual.
Turning next to the provisions of the impugned Act, whose constitutional validity was challenged, it
will be necessary to consider only those provisions which affect the petitioner before us. In the first
place, it was contended that section 3, which empowers the Central Government or the State
Government to detain any person if it is "satisfied" that it is necessary to do so with a view to
preventing him from acting in any manner prejudicial to (among other things) the security of the
State or the maintenance of public order, cannot be said to comply with the procedure established
by law, as the section prescribes no objective and ascertainable standard of conduct to which it will
be possible to conform, but leaves it to the will and pleasure of the Government concerned to make
an order of detention. TIm argument proceeds on the assumption that the procedure established by
law is equivalent to the due process of law. I have already endeavoured to show that it is not ApartA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

from this, the argument overlooks that for the purposes of preventive detention it would be difficult,
if not impossi- ble to lay down objective rules of conduct failure to conform to which should lead to
such detention. As tim very term implies, the detention in such cases is effected with a view to
prevent the person concerned from acting prejudi- cially to certain objects which the legislation
providing for such detention has in view. Nor would it be practicable to indicate or enumerate in
advance what acts or classes of acts would be regarded as prejudicial. The responsibility for the
security of the State and the maintenance of public order etc. having been laid on the executive
Government it must naturally be left to that Government to exercise the power of preventive
detention whenever they think the occa- sion demands it.
Section 12 came in for a good deal of criticism. That section, which governs the duration of
thepetitioner's detention reads as follows :--
"Duration of detention in certain cases.--Any person detained in any of the following
classes of cases or under any of the following circumstances may be detained without
obtaining the opinion of an Advisory Board for a period longer than three months,
but not exceeding one year from the date of his detention, namely, where such person
has been detained with a view to preventing him from acting in any manner
prejudicial to:--
(a) the defence of India, relations of India with for- eign powers or the security of
India; or
(b) the security of a State of the maintenance of public order.
(2) The case of every person detained under a detention order to which the provisions
of sub-section (1) apply shall, within a period of six months from the date of his
detention, be reviewed where the order was made by the Central Government or a
State Government, by such Govern-
ment, and where the order was made by any officer specified in sub-section (2)of section 3, by the
State Government to which such officer is subordinate, in consultation with a person who is, or has
been, or is qualified to be appointed as a Judge of a High Court nominated in that behalf by the
Central Government or the State Government, as the case may be."
It was urged that this did not comply with the require- ments of clause (7) of article 22 as it merely
repeated the "matters" or legislative topics mentioned in Entry 9 of List I and Entry 3 of List III of
the Seventh Schedule to the Constitution. What Parliament has to do under clause(7) of article 22 is
to prescribe "the circumstances under which and the class or classes of cases in which" a person may
be detained for a period longer than three months without obtaining the opinion of an advisory
board. It was said that clause (4) (a) provided for ordinary cases of preventive detention Where such
detention could not continue beyond three months without obtaining the opinion of an advisory
board, whereas clause (7) (a) made provision for special cases of detention for more than three
months with- out the safeguard of the advisory board's opinion, for aggravated forms of prejudicialA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

conduct. In other words, clause (4) (a) laid down the rule and clause (7) (a) enacted an exception. It
was therefore necessary for Parliarnent to indicate to the detaining authority for its guidance the
more aggravated forms of prejudicial activity, and mere mention of the subjects in respect of which
Parliament is authorised under the legislative lists to make laws in respect of preventive detention
could hardly afford any guidance to such authority and should not be regarded as sufficient
compliance with the requirements of clause (7). There is a two-fold fallacy in this argument. In the
first place, the suggested correla- tion between clause (4) (a) and clause (7) (a) as enacting a rule and
an exception is, as a matter of construction, without foundation. Reading clauses (4) and (7)
together it is reasonably clear that preventive detention could last longer in two cases: (1) where the
opinion of an advisory board is obtained, subject however to a prescribed period [sub-clause (a)of
clause (4)] and (2) where a person is detained under a law made by Parliament under sub-clauses
(a) and (b) of clause (7) [sub-clause (b) of clause (4)]. These are two distinct and independent
provisions. It is significant that sub-clause (b) of clause (4) is not worded as a proviso or an
exception to sub-clause (a) of the same clause as it would have been if it was intended to operate as
such. The attempt to correlate clause (4)(a)and clause (7) (a) as a rule and an exception respectively
is opposed both to the language and the structure of those clauses.
'Secondly, the argument loses sight of the fact that clause (7) deals with preventive detention which
is a purely precautionary measure which "must necessarily proceed in all cases, to some extent, on
suspicion or anticipation as distinct from proof" [ per Lord Atkinson in Rex v. Halliday (1) ]. The
remarks I have' already made with reference to the absence of any objective rules of conduct in
section 3 of the impugned Act apply also to this criticism of section
12. It would be difficult, if not impracticable, to mention the variouscircumstances, or to enumerate
the various class- es of cases exhaustively in which a person should be de- tained for more than three
months for preventive purposes, except in broad outline. Suppose a person belongs to. an
organization pledged to violent and subversive activity as its policy. Beyond his membership of
theparty the person might have done nothing until he1 was arrested and detained. But if released he
might indulge in anything from the mild- est form of prejudicial activity, like sticking an objec-
tionable handbill on a hoarding, to the most outrageous acts of sabotage.
(1) L.R. 1917 A.C. 260, 275.
How could the insertion in section 12 of a long series of categories of aggravated forms of prejudicial
activities, or the enumeration of the various circumstances in which such activities are likely to be
indulged in, be of any assist- ance to the detaining authority in determining whether the person
concerned should be detained for three months or for a longer period ? All that would be necessary
and suffi- cient for him to know for coming to a decision on the point is that the person is a member
of such an organisation and will probably engage in subversive activities prejudicial to the security
of the State or the maintenance of public order or, in other words, he belongs to class (b) in section
12. While enumeration and classification in detail would un- doubtedly help in grading punishment
for offences committed, they would not be of much use in fixing the duration of preventive
detention. Sufficient guidance in such cases could be given by broadly indicating the general natureA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

of the prejudicial activity which a person is likely to indulge in, and that in effect is what Parliament
has done in sec- tion 12. Reference was made in this connection to Rule 34 of the Defence of India
Rules framed under the Defence of India Act, 1939, where "prejudicial act" is defined by
enumeration. But it was also for the purpose of prohibiting such acts [ Rule 38 sub-rule (1) ] and
making them offences (sub-rule 5). And even there, the definition had to end in a residuary clause
sweeping in acts likely "to prejudice the efficient prosecution of the war, the defence of British India
or, the public safety or interest." In Lists I and III of the Seventh Schedule to the Constitution six
topics are mentioned in respect of which Parliament could make laws providing for preventive
detention, and section 12 of the impugned Act mentions five of them as being the classes of cases or
the circumstances in which longer detention is authorised. I fail to see why this could not be
regarded as a broad classification of cases or a broad description of circumstances where Parliament
considers longer detention to be justifiable. A class can well be designated with refer- ence to the
end which one desires to secure, and the matters referred to as classes (a) and (b) of sub-section (1)
of section 12 being clearly the objects which Parliament desired to secure by enacting the section, it
seems to me that the classification with refer- ence to such general aims does not contravene article
22 (7).
It was argued that Parliament did not, in enacting section 12, perform its duty of prescribing both
the circumstances and the class or classes of cases where detention without obtaining the advisory
board's opinion could be for a period longer than three months. The use of the disjunctive "or"
between the word "circumstances" and the words "class or classes of cases" showed, it was said, that
Parliament proceeded on the view that it need not prescribe both. This was in contravention of
article 22 (7) which used the con- junctive "and" between those words. There is no substance- in this
objection. As I read article 22 (7) it means that Parliament may prescribe either the circumstances
or the classes of cases or both, and in enacting section 12 Parliament evidently regarded the matters
mentioned in clause (a) and (b) of sub-section (1) as sufficiently indic- ative both of the
Circumstances under which and the classes in which a person could be detained for the longer
period. To say, for instance, that persons who are likely to act prejudicially to the defence of India
may be detained beyond three months is at once to "prescribe a class of persons in which and the
circumstances under which" a person may be detained for the longer period. In other words, the
classi- fication itself may be such as to amount to a sufficient description of the circumstances for
purposes of clause (7). The circumstances which would justify precautionary deten- tion beyond
three months without recourse to an advisory board must be far too numerous for anything
approaching an exhaustive enumeration, and it can, in my judgment, be no objection to the validity
of section 12 that no circum- stances are mentioned apart from the matters referred to in clauses (a)
and (b) of sub-section (1). It would indeed be singular for the Court to strike down a parliamentary
enact- ment because in its opinion a certain classification therein made is imperfect or the mention
of certain circumstances is unspecific or inade- quate.
Lastly, Mr. Nambiar turned his attack on section 14 which prohibits the disclosure of the grounds of
detention communicated to the person detained and of the representa- tion made by him against the
order of detention, and debars the Court from allowing such disclosure to be made except for
purposes of a prosecution punishable under sub-section (2) which makes it an offence for any
person to disclose or publish such grounds or representation without the previous authorisation ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the Central Government or the State Government as the case may be. The petitioner com- plains
that this provision nullifies in effect the rights conferred upon him under clause (5) of article 22
which entitles him to have the grounds of his detention communi- cated to him and to make a
representation against the order. If the grounds are too vague to enable him to make any such
representation, or if they are altogether irrelevant to the object of his detention, or are such as to
show that his detention is not bona fide, he has the further right of moving this Court and this
remedy is also guaranteed to him under article 32. These rights and remedies, the petitioner
submits, cannot be effectively excercised, if he is prevent- ed on pain of prosecution, from disclosing
the grounds to the Court. There is great force in this contention. All that the Attorney-General could
say in answer was that if the other provisions of the Act were held to be valid, it would not be open to
the Court to examine the sufficiency of the grounds on which the executive authority was "satisfied"
that detention was necessary, as laid down in Machindar Shivaji Mahar v. The King (1), and so the
petitioner could not complain of any infringement of his rights by reason of section 14 which
enacted only a rule of evidence. The argument overlooks that it was recognised in the decision
referred to above that it would be open to the Court to examine the grounds of detention in order to
see whether they were relevant to the object which the legislature had (1) [1949] F.C.R. 827.
in view, such as, for instance, the prevention of acts prejudicial to public safety and tranquillity, or
were such as to show that the detention was not bona fide. An examina- tion of the grounds for these
purposes is made impossible by section 14, and the protection afforded by article 22 (5) and article
32 is thereby rendered nugatory. It follows that section 14 contravenes the provisions of article 22
(5) and article 32 in so far as it prohibits the person detained from disclosing to the Court the
grounds of his detention communicated to him by the detaining authority or the repre- sentation
made by him against the order of detention, and prevents the Court from examining them for the
purposes aforesaid, and to that extent it must be held under article 13 (2) to be void. This however,
does not affect the rest of the Act which is severable. As the petitioner did not disclose the grounds
of his detention pending our decision on this point he will now be free to seek his remedy, if so
advised, on the basis of those grounds.
In the result, the application fails and is dismissed. MAHAJAN J.--The people of India having
solemnly resolved to constitute India into a Sovereign Democratic Republic on the 26th day of
November 1949 gave to themselves a Constitution which came into force on the 26th January 1950.
This is the first case in which this Court has been called upon to determine how far the Constitution
has secured personal liberty to the citizens of this country.
A.K. Gopalan, the petitioner, who was already under the custody of the Superintendent, Central Jail,
Cuddalore, was served with an order of detention under section 3 (1) of the Preventive Detention
Act, 1950 (Act IV of 1950) on the 27th February 1950. It was said in the order that the Governor of
Madras was satisfied that it was necessary to make the order with a view to preventing him from
acting in any manner prejudicial to the security of the State and the maintenance of public order. On
20th March 1950 a petition was presented to this Court under article 32 of the Constitution praying
for the issue of a writ of habeas corpus directing the State of Madras to produce him before the
Court and to set him at liberty. A writ was accordingly issued. The return to the writ is that the
detention is legal under Act IV of 1950, enacted by Parlia- ment. The petitioner contends that theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Act abridges and infringes certain provisions of Part III of the Constitution and is thus outside the
constitutional limits of the legis- lature and therefore void and unenforceable. The matter is one of
great importance both be-cause the legislative power expressly conferred by the 7th Schedule has
been impugned and because the liberty of the citizen is seriously affected. The decision of the
question whether Act IV of 1950 takes away or abridges the rights conferred by Part III of the
Constitution depends on a consideration of two points:
(1) In what measure has the Constitution secured person- al liberty to a citizen of
India, and.
(2) has the impugned legislation in any way taken away or abridged the rights so
secured and if so, to what extent ?
Act IV of 1950 provides for preventive detention in certain cases and it has been enacted as a
temporary meas- ure. It will cease to have effect on 1st April 1951. It empowers the Central
Government and the State Governments to make an order directing a person to be detained with a
view to preventing him from acting in any manner prejudicial to the defence of India, the relations
of India with foreign powers or the security of India. It also gives power to detain a person who acts
in any manner prejudicial to the security of the State or the maintenance of public order or the
maintenance of supplies and services essential to the community. It came into force on 26th
February 1950 and was enacted by virtue of the powers conferred on Parliament by article 22 clause
(7) of Part III of the Constitution read with the entries in the 7th Schedule. There can be no doubt
that the legislative will expressed herein would be enforceable unless the legislature has failed to
keep within its constitutional limits. It is quite obvious that the Court cannot declare a statute
unconstitutional and void simply on the ground of unjust and oppressive provi- sions or because it is
supposed to violate natural, social or political rights of citizens unless it it can be shown that such
injustice is prohibited or such rights are guaranteed or protected by the Constitution. It may also be
observed that an Act cannot be declared void because in the opinion of the Court it is opposed to the
spirit supposed to pervade the Constitution but not so expressed in words. It is difficult on any
general principles to limit the omnipo- tence of the sovereign legislative power by judicial inter-
position except in so far as the express words of a written Constitution give that authority. Article 13
(2) of our Constitution gives such an authority and to the extent stated therein. It says that the State
shall not make any law which takes away or abridges the rights conferred by this Part and any law
made in contravention of this clause shall to the extent of the contravention be void. Preventive
detention laws are repugnant to democratic constitutions and they cannot be found to exist in any of
the democratic countries of the world. It was stated at the Bar that no such law was in force in the
United States of America. In England for the first time during the first world war certain regulations
framed under the Defence of the Realm Act provided for preventive detention at the satisfaction of
the Home Secretary as a war measure and they ceased to have effect at the conclusion of hostilities.
The same thing happened during thesecond world war. Similar regulations were introduced during
the period of the war in India under the Defence of India Act. The Government of India Act, 1935,
conferred authority on the Central and Provincial Legislatures to enact laws on this subject for the
first time and since then laws on this subject have taken firm root here and have become a
permanent part of the statute book of this country. Curiously enough, this subject has found place inA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the Constitution in the.
chapter on Fundamental Rights. Entry 9 of the Union List and Entry 3 of the Concurrent List of the
7th Schedule mention the scope of legislative power of Parliament in respect of this topic. The
jurisdiction, however, to enact these laws is subject to the provisions of Part III of the Constitu- tion.
Article 22 in this Part provides :--
"(1 ) No person who is arrested shall be detained in custody without being informed,
as soon as may be, of the grounds for such arrest nor shall he be denied the right to
consult, and to be defended by, a legal practitioner of his choice.
(2) Every person who is arrested and detained in custody shall be produced before
the nearest magistrate within a period of twenty-four hours of such arrest excluding
the time necessary for the journey from the place of arrest to the Court of the
magistrate and no such person shall be detained in custody beyond the said period
without the authority of a magistrate.
(3) Nothing in clauses (1) and (2) shall apply
(a) to any person who for the time being is an enemy alien; or
(b) to any person who is arrested or detained under any law providing for preventive
detention. (4) No law providing for preventive detention shall authorise the detention
of a person for a longer period than three months unless-
(a) an Advisory Board consisting of persons who are, or have been, or are qualified to
be appointed as, Judges of a High Court has reported before the expiration of the said
period of three months that there is in its opinion suffi-
cient cause for such detention:
Provided that nothing in this sub-clause shall authorise the detention of any person
beyond the maximum period pre- scribed by any law made by Parliament under
sub-clause (b) of clause (7); or
(b) such person is detained in accordance with the provisions of any law made by
Parliament under sub-clauses
(a) and (b) of clause (7).
(5) When any person is detained in pursuance of an order made under any law
providing for preventive detention, the authority making the order shall, as soon as
may be, commu-A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

nicate to such person the grounds on which the order has been made and shall afford him the
earliest opportunity of making a representation against the order.
(6) Nothing in clause (5) shall require the authority making any such order as is referred to in that
clause to, disclose facts which such authority considers to be against the public interest to disclose,
(7) parliament may by law prescribe
(a) the circumstances under which, and the class or classes of cases in which, a person may be
detained for a period longer than three months under any law providing for preven- tive detention
without obtaining the opinion of an Advisory Board in accordance with the provisions of sub-clause
(a) of clause (4);
(b) the maximum period for which any person may in any class or classes of cases be detained under
any law provid- ing for preventive detention; and
(c) the procedure to be followed by an Advisory Board in an inquiry under sub-clause (a) of clause
(4)." The question of the constitutional validity of the impugned statute has to be approached with
great caution in view of these provisions of the Constitution and has to be considered with patient
attention. The benefit of reasona- ble doubt has to be resolved in favour of legislative ac- tion,
though such a presumption is not conclusive- It seems that the subject of preventive detention
became the particu- lar concern of the Constitution because of its intimate connection with
deprivation of personal liberty to protect which certain provisions were introduced in the Chapter
on Fundamental Rights and because of the conditions prevailing in the newly born Republic.
Preventive detention means a complete negation of freedom of movement and of personal liberty
and is incompatible with both those subjects and yet it is placed in the same compartment with
them in Part III of the Constitution.
Though the Constitution has recognized the necessity of laws as to preventive detention it has also
provided certain safeguards to mitigate their harshness by placing fetters on legislative power
conferred on this subject. These are-
(1) That no law can provide for detention for a period of more than three months unless the
sufficiency for the cause of the detention is investigated by an advisory board within the said period
of three months. This provision limits legislative power in the matter of duration of the period of
detention. A law of preventive detention would be void if it permits detention for a longer period
than three months without the intervention of an advisory board. (2) That a State law cannot
authorize detention beyond the maximum period prescribed by Parliament under the powers given
to it in clause (7). This is a limitation on the legislative power of the State legislature. They cannot
make a law authorizing preventive detention for a longer period than that fixed by Parliament.
(3) That Parliament also cannot make a law authorizing detention for a period beyond three months
without the intervention of an advisory board unless the law conforms to the conditions laid down in
clause (7) of article 22. Provision also has been made to enable Parliament to make laws for
procedure to be followed by advisory boards. This is a safeguard against any arbitrary form ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

procedure that may otherwise find place in State laws.
Apart from these enabling and disabling provisions certain procedural rights have been expressly
safeguarded by clause (5) of article 22. A person detained under a law of preventive detention has a
right to obtain information as to the grounds of his detention and has also the right to make a
representation protesting against an order of preventive detention. This right has been guaranteed
independently of the duration of the period of detention and irrespective of the existence or
non-existence of an advisory board. No machinery, however, has been provided or expressly
mentioned for dealing with this representation. It seems to me that when a constitutional right has
been conferred as a necessary consequence, a constitutional remedy for obtaining redress in case of
infringement of the right must be pre- sumed to have been contemplated and it could not have been
intended that the right was merely illusory and that a representation made may well find place in
cold storage. Consideration of the representation made by virtue of clause (5) by an unbiassed
authority is, m my opinion, a necessary consequence of the guaranteed right contained herein. The
right has been conferred to enable a detained person to establish his innocence and to secure justice,
and no jus- tice can be said to be secured unless the representation is considered by some impartial
person. The interpretation that I am inclined to place on clause (5) of article 22 is justi- fied by the
solemn words of the declaration contained in the Preamble to the Constitution. It is this declaration
that makes our Constitution sublime and it is the guarantees mentioned in the chapter on
Fundamental Rights that make it one of the greatest charters of liberty and of which the people, of
this country 'may well be proud. This charter has not been forced out of unwilling hands of a
sovereign like the Magna Carta but it has been given to themselves by the people of the country
through their Constituent Assem- bly. Any interpretation of the provisions of Part III of the
Constitution without reference to this solemn declara- tion is apt to lead one into error. If the right
of repre- sentation given to a detained person by clause (5) of arti- cle 22 is a guaranteed right and
has been given for the purpose of securing justice, then it follows that no justice can be held secured
to him unless an unbiassed person considers the merits of the representation and gives his opinion
on the guilt or the innocence of the persons detained. In my view, the right cannot be defeated or
made elusive by presuming that the detaining authority itself will consider the representation with
an unbiassed mind and will render justice. That would in a way make the prosecu- tor a judge in the
case and such a procedure is repugnant. to all notions of justice. The Constitution has further
curtailed the rights given in clause (5) by providing in clause (6) a privilege on the detaining
authority of witholding facts which the said authority considers not in public interests to disclose.
This privilege has been conferred for the security of the State and possibly for the security of the
Constitution itself, but in view of these stringent provi- sions no additional clogs can be put on the
proper consider- ation of the representation of the detained person by pre- suming that the
detaining authority itself will properly consider the representation. It has also to be remembered in
this context that a person-subjected to the law of pre- ventive detention has been deprived of the
rights conferred on persons who become subject to the law of punitive deten- tion [vide clauses (1)
and (2) of article 22]. He has been denied the right to consult a lawyer or be defended by him and he
can be kept in detention without being produced before a magistrate.
Having examined the provisions of article 22, I now proceed to consider the first question that was
canvassed before us by the learned Attorney-General, i.e., that arti- cle 22 of the Constitution readA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

with the entries in the 7th Schedule was a complete Code on the subject of preventive detention, and
that being so, the other articles of Part III could not be invoked in the consideration of the validity of
the impugne'd statute. It was conceded by the learned coun- sel for the petitioner that to the extent
that express provisions exist in article 22 on the topic of preventive detention those provisions
would prevail and could not be controlled by the other provisions of Part III. It was, however, urged
that on matters on which this article had made no special provision on this topic the other
provisions of Part III of the Constitution had application, namely, articles 10 and 21 and to that
extent laws made on this subject were justiciable. In order to draw the inference that the framers of
the Constitution intended the provisions as regards preventive detention in article 22 to be self-
contained a clear indication of such an intention has to be gathered. If the provisions embodied in
this article have dealt with all the principal questions that are likely to arise in matters of procedure
or on questions of the reasonableness of the period of detention, the inference of such an indica-
tion would be irresistible. Ordinarily when a subject is expressly dealt with in a constitution in some
detail, it has to be assumed that the intention was to exclude the application of the general
provisions contained therein elsewhere. Express mention of one thing is an exclusion of the other.
Expressio unius est exclusio alterius. I am satisfied on a review of the whole scheme of the Constitu-
tion that the intention was to make article 22 self-con- tained in respect of the laws on the subject of
preventive detention. It was contended that all the articles in the Constitution should be read in an
harmonious manner and one article should not be read as standing by itself and as having no
connection with the other articles in the same part. It was said that they were all supplementary to
one another. In this connection it was argued that a law made under article 22 would not be valid
unless it was in accord with the provisions of article 21 of the Constitution. This article provides that
no person shall be deprived of life or liberty' except according to procedure established by law. It
was contended that in substance the article laid down that no person will be deprived of life or
liberty without having been given a fair trial or a fair hearing and that unless a law of preventive
detention provided such a hearing that law would be in contravention of this article and thus void.
Conceding for the sake of argument (but without expressing any opinion on it ) that this contention
of the learned counsel is correct, the question arises whether there is anything in article 22 which
negatives the application of article 21 as above construed to a law on preventive detention. In my
opinion, sub-clause (5) of article 22 read with clauses (1) and (2) leads to the inference that the
contention raised by the learned counsel is unsound. Clause (5), as already stated, provides that
notice has to be given to a detenu of the grounds of his detention. It also provides a limited hearing
inasmuch as it gives him an opportunity to establish his innocence. As, in my opinion, the
considera- tion of a representation made by a detained person by an unbiassed authority is implicit
in clause (5) it gives to the detained person all that he is entitled to under the principles of natural
justice. The right to consult and to be represented by a counsel of his own choice has been denied in
express terms to such a person by the Constitu- tion. He is also denied an opportunity of appearing
before a magistrate. When the Constitution has taken away certain rights that ordinarily will be
possessed by a detained person and in substitution thereof certain other rights have been conferred
on him even in the matter of procedure, the inference is clear that the intention was to deprive such
a person of the right of an elaborate procedure usually pro- vided for in judicial proceedings. Clause
(6) of article 22 very strongly supports this conclusion. There would have been no point in laying
down such detailed rules of proce- dure in respect of a law of preventive detention if the intention
was that such a law would be subject to the provi- sions of article 21 of the Constitution. In itsA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

ultimate analysis the argument of the learned counsel for the peti- tioner resolves itself to this: that
the impugned statute does not provide for an impartial tribunal for a considera- tion of the
representation of the detained person and to this extent it contravenes article 21 of the Constitution.
As discussed above, in ray opinion, such a provision is implicit within article 22 itself and that being
so, the application of article 21 to a law made under article 22 is excluded.
It was next contended that a law of preventive detention encroaches on the right of freedom of
movement within the territory of India guaranteed to a citizen under article 19 (1) (d) and that being
so, by reason of the provisions of sub-clause (5) of article 19 it was justiciable on the ground of
reasonableness. It is true, as already pointed out, that a law of preventive detention is wholly
incompati- ble with the right of freedom of movement of a citizen. Preventive detention in substance
is a negation of the freedom of locomotion guaranteed under article 19 (1) (d) but it cannot be said
that it merely restricts it. Be that as it may, the question for consideration is whether it was intended
that article 19 would govern a law made under the provisions of article 22. Article 19 (5) is a saving
and an enabling provision. It empowers Parliament to make a law imposing reasonable restriction
on the right of freedom of movement while article 22 (7) is auother enabling provision empower- ing
Parliament to make a law on the subject of preventive detention in certain circumstances. If a law
conforms to the conditions laid down in 'article 22 (7), it would be a good law and it could not have
been intended that that law validly made should also conform itself to the provisions of article 19
(5). One enabling provision cannot be considered as a safeguard against another enabling provision.
Article 13 (2) has absolutely no application in such a situation. If the intention of the constitution
was that a law made on the subject of preventive detention had to be tested on the touchstone of
reasonableness, then it would not have trou- bled itself by expressly making provision in article 22
about the precise scope of the limitation subject to which such a law could be made and by
mentioning the procedure that the law dealing with that subject had to provide. Some of the
provisions of article 22 would then have been redun- dant, for instance, the provision that no
detention can last longer than three months without the necessity of such detention being examined
by an advisory board. This provi- sion negatives the idea that the deprivation of liberty for a period
of three months without the consultation of the advisory board would be justiciable on the ground of
reason- ableness. Again article 22 has provided a safeguard that if an advisory board has to be
dispensed with, it can only be so dispensed with under a law made by Parliament and that
Parliament also in enacting such a law has to conform to certain conditions. This provision would
have' been unnec- essary in article 22 if a law on this subject was justicia- ble. In sub-clause (b) of
clause (7) of article 22 provision has been made enabling Parliament to fix the maximum period for
which a person can be detained under a law on the sub-
ject of preventive detention. Under this express provision it is open to Parliament to fix any period,
say, even a period of five to ten years as the maximum period of detention of a person. Can it be said
that in view of this express provision of the Constitution such a law was intended to be justiciable by
reason of article 19 (5) ? Duration of detention is the principal matter in preventive detention laws
which possibly could be examined on the touchstone of reasonableness under article 19 (5), but this
has been expressly excluded by express provisions in article 22. In my judgment, therefore, an
examination of the provisions of article 22 clearly suggests that the intention was to make it
self-contained as regards the law of preventive detention and that the validity of a law on the subjectA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

of preventive detention cannot be exam- ined or controlled either by the provisions of article 21 or
by the provisions of article 19 (5) because article 13 (2) has no application to such a situation and
article 22 is not subject to the provisions of these two articles. The Consti- tution in article 22 has
gone to the extent of even provid- ing that Parliament may by law lay down the procedure to be
followed by an advisory board. On all important points that could arise in connection with the
subject of preventive detention provision has been made in article 22 and that being so, the only
correct approach in examining the validi- ty of a law on the subject of preventive detention is by
considering whether the law made satisfied the requirements of article 22 or in any way abridges or
contravenes them and if the answer is in the affirmative, then the law will be valid, but if the answer
is in the negative, the law would be void.
In expressing the view that article 22 is in a sense self-contained on the law of preventive detention I
should not however be understood as laying down that the framers of the article in any way
overlooked the safeguards laid down in article 21. Article 21, in my opinion. lays down sub- stantive
law as giving protection to life and liberty inas- much as it says that they cannot be deprived except
accord- ing to the procedure established by law; in other words, it means that before a person can be
deprived of his life or liberty as a condition precedent there should exist some substantive law
conferring authority for doing so and the law should further provide for a mode of procedure for
such depriva- tion. This article gives complete' immunity against the exercise of despotic power by
the executive. It further gives immunity against invalid laws which contravene the Constitution. It
gives also further guarantee that in its true concept there should be some form of proceeding before
a person can be condemned either in respect of his life or his liberty. It negatives the idea of
fantastic, arbitrary and oppressive forms of proceedings. The principles there- fore underlying
article 21 have been kept in view in draft- ing article 22. A law properly made under article 22 and
which is valid in all respects under that article and lays down substantive as well as adjective law on
this subject would fully satisfy the requirements of article 21, and that being so, there is no conflict
between these two articles. The next question that arises for decision is whether there is anything in
Act IV of 1950 which offends against the provisions of article 22 of Part III of the Constitu- tion. The
learned counsel for the petitioner contended that section 3 of the Act was bad inasmuch as it made
"satisfaction of the Government" as the criterion for de- taining a person. It was said that as section
3 laid down no objective rule of conduct for a person and as people were not told as to what
behaviour was expected of them, the result was that it could not be known what acts a person was
expected to avoid and what conduct on his part was prejudi- cial to the security of the State or the
maintenance of' public order; in other words, it was argued that section 3 left the determination of
the prejudicial act of a person to the arbitrary judgment of the Government and that even the officer
who was to administer this law had been furnished no guide and no standard of conduct in arriving
at his own satisfaction whether the conduct was prejudicial to the security of the State etc. This
criticism of the learned counsel, in my opinion, is not valid, It is no doubt true that a detention order
depends on the satisfac- tion of the' Government but this provision is in accordance with article 22
of the Constitution which to my mind contemplates detention on the satisfaction of the executive
authority. By its very nature the subject is such that it implies detention on the judgment of the
authority entrusted with the making of the order. The whole intent and purpose of the law of
preventive detention would be defeated if satis- faction of the authority concerned was subject to
such an objective standard and was also subject to conditions as to legal proof and procedure. In theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

7th Schedule jurisdiction to make the law on this subject has been given for reasons connected with
defence etc. and the maintenance of public order. These are subjects which concern the life and the
very existence of the State. Every citizen is presumed to know what behaviour is prejudicial to the
life of the State or to its existence as an ordered State. Considering that the State is presumed to
have a government that conducts itself in a reasonable way and also presuming that its officers
usually will be reasonable men, it cannot be said that in making "satisfaction of the government" as
the standard for judging prejudicial acts of persons who are subject to the law of preventive
detention section 3 in any way contravenes article 22 of the constitution. Section 7 of the impugned
Act gives full effect to the provisions of article 22 sub clause (5) and enacts that representation has to
be made to the Central or State Gov- ernment as the case may be. It was impeached on the ground
that no machinery has been provided herein to consider and adjudicate on the merits of the
representation. To this extent, as already indicated, the law is defective. In the absence of a
machinery for the investigation of the conten- tions raised in the representation it may be open to
the detenu to move this Court under article 32 for a proper relief. It is, however, unnecessary to
express any opin- ion as to the precise remedy open to a detained person in this respect. The
absence of a provision of this nature in the statute however would not make the law wholly void.
Section 9 of the Act makes reference to the advisory board obligatory in cases falling under
sub-clause (iii) of clause (a) or clause (b) of sub-section (1) of section a within six weeks of the order.
The proce- dure to be followed by the advisory board is laid down in section 10. Parliament has been
authorized to lay down such a procedure to be followed by an advisory board in sub- clause (c) of
clause (7). It was contended that the law had not provided a personal hearing to the detenu before
an advisory board, nor had it given him a right to lead evi- dence to establish his innocence. In my
opinion, this criticism is not sound and does not in any way invalidate the law. The advisory board
has been given the power to call for such information as it requires even from the person detained. It
has also been empowered to examine the materi- al placed before it in the light of the facts and
arguments contained in the representation. The opportunity afforded is not as full as a person gets
under normal judicial proce- dure but when the Constitution itself contemplates a special procedure
being prescribed for preventive detention cases, then the validity of the law on that subject cannot
be impugned on the grounds contended for.
Section 11 of the Act was also impugned on the ground that it offended against the Constitution
inasmuch as it provided for preventive detention for an indefinite period. This section in my opinion
has to be read in the background of the provision in sub-clause (3) of section 1 of the Act which says
that the Act will cease to have effect on 1st April, 1951. Besides, the words "for such period as it
thinks fit" do not in any way offend against the provisions of article 22 wherein Parliament has been
given the power to make a law fixing the maximum period for preventive deten- tion. It has to be
noted that Parliament has fixed a period of one year as the maximum period for the duration of
detention where detention has to be without reference to an advisory board. In my opinion, there is
nothing in section 11 which is outside the constitutional limits of the powers of the supreme
legislature.
It is section 12 of the Act which was assailed by the learned counsel for the petitioner rather
vehemently. This section is of a very controversial character. It has been enacted on the authority of
clause (7) of article 22 and runs thus :--A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"(1) Any person detained in any of the following classes of cases or under any of the
following circumstances may be detained without obtaining the opinion of an
Advisory Board for a period longer than three months, but not exceed-
ing one year from the date of his detention, namely, where such person has been detained with a
view to preventing him from acting in any manner prejudicial to-
(a) the defence of India, relations of India with for- eign powers or the security of India; or
(b) the security of a State or the maintenance of public order.
(2) The case of every person detained under a detention order to which the provisions of sub-section
(1) apply shall, within a period of six months from the date of his detention, be reviewed where the
order was made by the Central Government or a State Government, by such Govern- ment, and
where the order was made by any officer specified in sub-section (2) of section a, by the State
Government to which such officer is subordinate, in consultation with a person who is, or has been,
or is qualified to be appointed as, a Judge of a High Court nominated in that behalf by the Central
Government or the State Government, as the case may be."
The section purports to comply with the conditions laid down in clause (7) of article 22. It was,
however, argued that in substance and reality it has failed to comply with any of the conditions laid
down therein; that it neither mentions the circumstances under which nor the classes of cases in
which preventive detention without recourse to the machinery of an advisory board could be
permitted. The crucial question for consideration is whether section 12 mentions any circumstances
under which or defined the class- es of cases in which authority was conferred by clause (7) to
dispense with an advisory board. So far as I have been able to gather from opinions of text-book
writers on the subject of classification, the rule seems clear that in making classification of cases
there has to be some rela- tionship to the classification to the objects sought to be accomplished. The
question for consideration therefore is what object was sought to be accomplished when the
Constitu- tion included clause (7) in article 22. It seems clear that the real purpose of clause (7) was
to provide for a contin- gency where compulsory requirement of an advisory board may defeat the
object of the law of preventive detention. In my opinion, it was incorporated in the Constitution to
meet abnormal and exceptional cases, the cases being of a kind where an advisory board could not
be taken into confidence. The authority to make such drastic legislation was entrusted to 'the
supreme legislature but with the further safeguard that it can only enact a law of such a drastic
nature provided it prescribed the circumstances under which such power had to be used or in the
alternative it prescribed the classes of cases or stated a determinable group of cases in which this
could be done. The intention was to lay down some objective standard for the guidance of the
detaining authority on the basis of which without consultation of an advisory board detention could
be ordered beyond the period of three months. In this connection it has to be remembered that the
Constitution must have thought of really some abnormal situation and of some dangerous groups of
persons when it found it necessary to dispense with a tribu- nal like an advisory board which
functions in camera and which is not bound even to give a personal hearing to the detenu and whose
proceedings are privileged. The law on the subject of preventive detention in order to avoid evenA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

such an innocuous institution could only be justified on the basis of peculiar circumstances and
peculiar situations which had to be objectively laid down and that was what in my opinion was
intended by clause (7). If the peculiarity lies in a situation outside 'the control or view of a de- tained
person, then it may be said that the description of such a situation would amount to a prescription
of the circumstances justifying the detention for a longer period than three months by a law without
the intervention of an advisory board'. If, however, the abnormality relates to the conduct and
character of the activities of a certain determinable group of persons, then that would amount to a
class of cases which was contemplated to be dealt with under clause (7). In such cases alone
arbitrary detention could be held justifiable by law beyond a period of three months.
It was argued by the learned counsel for the petitioner that the phrase "circumstances under which,
and the classes of cases in which" used in clause (7) had to be construed in a cumulative sense; on
the other hand, the learned Attorney-General contended that the word "and" had been used in this
clause in the same sense as "or." He further argued that even if the word "and" is not given that
meaning the true construction of the phrase was that Parliament could prescribe either the
circumstances or the classes of cases for making a law on the subject of preventive detention
authorizing detention for a longer period than three months without the machinery of an advisory
board. In Full Bench Reference No. 1 of 1950, Das Gupta J. of the Calcutta High Court held that the
intention of the legislature in enacting the clause was that the law of preventive detention author-
izing detention for a longer period than three months with- out the intervention of an advisory
board had to fulfil both the requirements laid down in clause (7) and not only one of the
requirements in the alternative. The same view has been expressed by my brother Sir Fazl Ali. I
share this view with him. I would, however, like to consider this matter from a different aspect on
the assumption that the contention raised by the learned Attorney-General is right. Dealing first
with the question whether section 12 mentions any circumstances, so far as I have been able to see,
it does not prescribe any circumstances unless it can be said that the prejudicial acts for reasons
connected with the security of State, maintenance of public order, etc. are both the circumstances as
well as the classes of cases. In my opinion, this line of approach cannot be held to be correct in the
construction of clause (7) of article 22. I am inclined to agree with the learned Attorney-General that
the phrase "circumstances under which"
means some situation extraneous to the detenu's own acts, in other words, it means
some happening in the country with which the detenu is not concerned, such as a
situation of tense communal feelings, an apprehended internal rebellion or disorder,
the crisis of an impending war or apprehended war, etc. In such a situation the
machinery of an advisory board could be dispensed with because it may become
cumber- some or it may hamper the exercise of necessary powers. In this view of the
matter I have no hesitation in holding that no circumstances have been stated in
section 12, though the section ostensibly says so. If it was permissible to con- jecture,
it seems that the draftsman of section 12' repeated the words of clause' (7) of article
22 without an applica- tion of his mind to the meaning of those words and as the
legislation was passed in haste to meet an emergent situa- tion, it suffers from the
defects which all hasty legisla- tion suffer from.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

I now proceed to consider whether section 12 has classi- fied the cases in which
detention for a longer period beyond three months could be suffered by a citizen
without the benefit of the machinery of an advisory board. The section has placed five
subjects out of the legislative list within its ambit and these are described as the
classes of cases. The question is whether it can be said that a mere selection of all or
any of the categories of the subjects for reasons connected with which a law of
preventive detention could be' made under the 7th Schedule amounts to a
classification of cases as contemplated in clause (7) of article 22. Entry 9 of the Union
List and Entry 3 of the Concurrent List of the 7th Schedule lay down the ambit of
legislative power of Parliament on the subject of preventive detention on the
following six subjects :--
(1) Defence of India, (2) Foreign Affairs, (a) Security of India, (4) Security of the
State, (5) Mainten-
ance of public order, (6) Maintenance of supplies and serv- ices essential to the community.
Clause (4) of article 22 enjoins in respect of all the six subjects that no law can provide for
preventive deten- tion for a longer period than three months without reference to an advisory board.
Clause (7) gives permission to make a law for dispensing with an advisory board by a prescription of
the circumstances and by a prescription of the classes of cases in which such a dispensation can be
made. The legis- lative authority under clauses (4) and (7)in my opinion, extends to all these six
subjects. The normal procedure to be followed when detention is intended to be beyond a period of
three months in respect of the six subjects is provided in sub-clause (4) The extraordinary and
unusual procedure was intended, to be adopted in certain abnormal cases for which provision could
be made by a parliamentary statute under clause (7). It seems to me, however, that section- 12 of Act
IV of 1950 has reversed this process quite contrary to the intention of the Constitution. By this
section Act IV of 1950 has dispensed with the advisory board in five out of the six subjects above
mentioned and the compulsory procedure of an advisory board laid down in clause (4) of article 22
has been relegated to one out of these six sub- jects. This has been achieved by giving a construction
to the phrase "circumstances under which and the classes of cases in which" so as to make it
co-extensive and cotermi- nous with the "subjects of legislation." In my opinion, this construction of
clause (7) is in contravention of the clear provisions of article 22, and makes clause (4) of article -9,2
to all intents and purposes nugatory. Such a construction of the clause would amount to the
Constitution saying in one breath that a law of preventive detention cannot provide for detention for
a longer period than three months without reference to an advisory board and at the same breath
and moment saying that Parliament, if it so chooses, can do so in respect of all or any of the subjects
mentioned in the legislative field. If that was so, it would have been wholly unnecessary to provide
such a safe- guard in the Constitution on a matter which very seriously affects personal liberty. On
the other hand, it would be a reasonable construction of the clause to hold that the Constitution
authorized Parliament that in serious classes of cases or in cases of those groups of persons who are
incorrigible or whose activities are secret the procedure of an advisory board may well be dispensed
with, that being necessary in the interests of the State. On the other construction as adopted by the
framers of section 12, the Constitution need not have troubled itself by con- ferring an authority onA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Parliament for making such a law. Moreover, if that was the intention, it would have in very clear
words indicated this by drafting article 22 clause (4) thus:
"Unless otherwise provided by Parliament no law provid- ing for preventive detention
shall authorize detention for a longer period than three months unless an Advisory
Board has investigated the sufficiency of the cause of such detention."
The words "Unless otherwise provided for by Parliament"
would have been in accord with the construction which the framers of section 12 have
placed on article 22 clause (7). I am further of the opinion that the construction
placed by the learned Attorney-General on clause (7) of article 22 and adopted by the
framers of Act IV of 1950 creates a very anomalous situation. The matter may be
examined from the point of view of the law of preventive detention for reasons
connected with supplies and services essential to the life of the community. This
subject has been put under section 9 in Act IV of 1950. Suppose a tense situation
arises and there is a danger of the railway system being sabotaged and it becomes
necessary to pass detention orders against cer- tain persons. According to Act IV of
1950 in such a serious state of affairs the procedure of an advisory board is
compulsory, while on the other hand, if there is an appre- hension of disturbance of
public order by reason of a wrong decision of an umpire at a cricket match or on
account of conduct of persons celebrating the festival of Holi, then detention beyond
three months can be ordered without reference to an advisory board. Could such an
anomalous result be in the contempla- tion of the framers of the Constitution ? The
construction that I am inclined to place on the section is in accord with the scheme of
the law of punitive detention. Hurt is an offence under the Indian Penal Code and
this is one of the subjects of punitive detention. The cases on the subject have been
classified in different groups, namely, simple hurt, grievous hurt, grievous hurt with
dangerous weapons, grievous hurt to extort a confession, grievous hurt to restrain a
public officer from doing his duty, grievous hurt by a rash act, and grievous hurt on
provocation. Even simple hurt has been classified in different categories. The sub-
ject of assault has also been similarly dealt with. Sections 352 to 356 deal with cases
classified according to the gravity of the offence, i.e., cases of simple assault, assault
on a public servant, assault on women, assault in attempt to'commit theft, assault for
wrongfully confining a person and assault on grave provocation have been separately
grouped. Another illustration is furnished by the Criminal Procedure Code in the
preventive sections 107 to 110. These deal with different groups of persons; vagrants
are in one class, habitual offenders in another, bad characters in the third and
disturbers of peace in the fourth. It seems that it is on lines similar to these that it
must have been contemplated by the Constitution that classes of cases would be
prescribed by Parliament, but this has not been done. The Constitution has
recognised varying scales of duration of detention with the idea that this will vary
with the nature of the apprehended act, detention for a period of three months in
ordinary cases, detention for a longer period than three months with the interventionA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

of an adviso- ry board in more serious cases, while detention for a longer period than
three months without the intercession of an advisory board for a still more dangerous
class and for acts committed in grave situations. It can hardly be said that all cases of
preventive detention for reasons connected with the maintenance of public order
stand on the same footing in the degree of gravity and deserve the same duration of
detention and all cases connected with the maintenance of supplies and services
essential to the life of the community stand in the matter of their gravity on such a
footing as to require a lenient treatment. It is true that in a sense all persons who act
prejudicially to the defence of India may be comprehensively said to form one group
and similarly persons who act prejudicially to the maintenance of supplies and
services essential to the life of the community may form another class but the
question is, whether it was in this comprehensive sense that classifica- tion was
intended by the Constitution in clause (7) or was it intended in a narrower and
restricted sense ? It has to be remembered that the law under clause (7) was intended
to provide detention for a longer period and such a law very seriously abridges
personal liberty and in this situation giving a narrower and restricted meaning to this
expression will be in accordance with well established canons of con- struction of
statutes.
The wide construction of clause (7) of article 22 brings within the ambit of the clause
all the subjects in the legislative list and very seriously abridges the personal liberty of
a citizen. This could never have been the inten- tion of the framers of the
Constitution. The narrow and restricted interpretation is in accord with the scheme
of the article and it also operates on the whole field of the legislative list and within
that field it operates by demar- cating certain portions out of each subject which
requires severe treatment. If I may say so m conclusion, section 12 treats the lamb
and the leopard in the same class because they happen to be quadrupeds. Such a
classification could not have been in the thoughts of the Constitution-makers when
clause (7) was introduced in article 22. For the reasons given above, I am of the
opinion that section 12 of Act IV of 1950 does not fulfil the requirements of clause (7)
of article 22 of the Constitution and is not a law which falls within the ambit of that
clause. That being so, this section of Act IV of 1950 is void and by reason of it the
detention of the petitioner cannot be justified. There is no other provision in this law
under which he can be detained for any period whatsoever.
It was argued that it was neither practicable nor possi- ble to make a classification on any definite
basis in the case of apprehended acts of persons whose activities are of a prejudicial character to the
maintenance of public order or to the security of the State or to the defence of India. This contention
to my mind is not sound. Such a classifica- tion was made in the rules under the Defence of India
Act by defining "a prejudicial act" in regulation 34. Mere difficulty in precisely ascertaining the
groups or in defin- ing objectively the conduct of such groups is no ground for not complying with
the clear provisions of the statute or for disobeying it. I see no difficulty whatsoever if a serious
effort was made to comply with the provisions of clause (7). I cannot see that the compulsory
requirement of an advisory board is likely to lead to such disastrous or calamitous results that in allA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

cases or at least in five out of the six subjects of legislation it becomes necessary to dispense with
this requirement. The requirement of an advi- sory board is in accordance with the preamble of the
Consti- tution and is the barest minimum that can make a law of preventive detention to some little
degree tolerable to a democratic Constitution. Such a law also may have some justification even
without the requirement of an advisory board to meet certain defined dangerous situations or to
deal with a class of people who are a danger to the State but without such limitation the law would
be destructive of all notions of personal liberty. The Constitution must be taken to have furnished an
adequate safeguard to its citi- zens when it laid down certain conditions in clause (7) and it could
not be considered that it provided no safeguard to them at all and that the words used in clause (7)
were merely illusory and had no real meaning.
Section 14 of Act IV of 1950 has been impugned on the ground that it contravenes and abridges the
provisions of articles 22 (5) and 32 of the Constitution. This section is in these terms:--
"(1) No Court shall except for the purposes of a prose-
cution for an offence punishable under subsection (2), allow any statement to be made, or any
evidence to be given, before it of the substance of any communication made under section 7 of the
grounds on which a detention order has been made against any person or of any representation
made by him against such order, and notwithstanding anything con- tained in any other law, no
Court shall be entitled to require any public officer to produce before it, or to disclose the substance
of, any such communication or repre- sentation made, or the proceedings of an advisory board or
that part of the report of an advisory board which is confi- dential.
(2) It shall be an offence punishable with imprisonment for a term which may extend to one year, or
with fine, or with both, for any person to disclose or publish without the previous authorisation of
the Central Government or the State Government, as the case may be, any contents or matter
purporting to be contents of any such communication or representation as is referred to in
sub-section (1):
Provided that nothing in this sub-section shall apply to a disclosure made to his legal
adviser by a person who is the subject of a detention order."
This section is in the nature of an iron curtain around the acts of the authority
making the order of preventive detention. The Constitution has guaranteed to the
detained person the right to be told the grounds of detention. He has been given a
right to make a representation [vide arti- cle 22 (5)], yet section 14 prohibits the
disclosure of the grounds furnished to him or the contents of the representa- tion
made by him in a Court of law and makes a breach of this injunction punishable with
imprisonment. Article 32 (1) of the Constitution is in these terms :--
"The right to move the Supreme Court by appropriate proceedings for the
enforcement of the rights conferred by this Part is guaranteed."A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Sub-section (4) says :--
"The right guaranteed by this article shall not be suspended except as otherwise
provided for by this Constitu- tion."
Now it is quite clear that if an authority passes an order of preventive detention for reasons not
connected with any of the six subjects mentioned in the 7th Schedule, this Court can always declare
the detention illegal and release the detenu, but it is not possible for this Court to func- tion if there
is a prohibition against disclosing the grounds which have been served upon him. It is only by an
examination of the grounds that it is possible to say wheth- er the grounds fall within the ambit of
the legislative power contained in the Constitution or are outside its scope. Again something may be
served on the detenu as being grounds which are not grounds at all. In this contingency it is the
right of the detained person under article 32 to move this Court for enforcing the right under article
22 (5) that he be given the real grounds on which the detention order is based. This Court would be
disabled from exercis- ing its functions under article 32 and adjudicating on the point that the
grounds given satisfy the requirements of the sub-clause if it is not open to it to see the grounds that
have been furnished. It is a guaranteed right of the person detained to have the very grounds which
are the basis of the order of detention. This Court would be entitled to examine the matter and to see
whether the grounds furnished are the grounds on the basis of which he has been detained or they
contain some other vague or irrelevant material. The whole purpose of furnishing a detained person
with the grounds is to enable him to make a representation refuting these grounds and of proving
his innocence. In order that this Court may be able to safeguard this fundamental right and to grant
him relief it is absolutely essential that the detenu is not prohibited under penalty of punishment to
disclose the grounds to the Court and no injunction by law can be issued to this Court disabling it
from having a look at the grounds. Section 14 creates a substantive offence if the grounds are
disclosed and it also lays a duty on the Court not to permit the disclosure of such grounds. It
virtually amounts to a suspension of a guaranteed right provided by the Constitution inasmuch as it
indirectly by a stringent provision makes administration of the law by this Court impossible and at
the same time it deprives a detained person from obtaining justice from this Court. In my opin- ion,
therefore, this section when it prohibits the disclo- sure of the grounds contravenes or abridges the
rights given by Part III to a citizen and is ultra vires the powers of Parliament to that extent.
The result of the above discussion is that, in my opin- ion, sections 12 and 14 of Act IV of 1950 as
above indicated are void and the decision of the detenu's case has to be made by keeping out of sight
these two provisions in the Act. If sections 12 and 14 are deleted from the impugned legislation, then
the result is that the detention of the petitioner is not legal. The statute has not provided for
detention for a period of three months or less in such cases as it could have done under article22 (4)
of the Constitu- tion and that being so, the petitioner cannot be justifia- bly detained even for a
period of three months. I would accordingly order his release.
In view of the decision above arrived at I do not con- sider it necessary to express any opinion on the
other points that were argued at great length before us, namely, (1)what is 'the scope and true
meaning of the expression "procedure established by law" in article 21 of the Consti- tution, and (2)
what is the precise scope of articles 19 (1)A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(d) and 19 (5)of the Constitution.
MUKHERJEA J.--This is an application under article 32 of the Constitution praying for a writ of
habeas corpus upon the respondents with a view to release the petitioner who, it is alleged, is being
unlawfully detained in the Central Jail, Cuddalore, within the State of Madras.
The petitioner, it is said, was initially arrested in Malabar on 17th of December, 1947, and
prosecution was started against him on various charges for having delivered certain violent
speeches. While these criminal cases were going on, he was served with an order of deten- tion
under the Madras Maintenance of Public Order Act on 22nd April, 1948. This order of detention was
held to be illegal by the Madras High Court, but on the same day that the judgment was pronounced,
a second order of detention was served upon him. On his moving the High Court again for a writ of
habeas corpus in respect to the subsequent order, his application was dismissed on the ground that
as he was not granted bail in one of the three criminal cases that were pending against him, the
detention could not be said to be unlawful. Liberty, however, was given to him to renew his
application if and when his detention under the criminal proceedings ceased. In two out of the three
criminal cases the trial before the magistrate ended on February 23, 1949, and the petitioner was
sentenced to rigorous imprisonment for 6 months in each of the cases. These sentences, however,
were set aside in appeal on 26th September, 1949. As re- gards the third case, he was tried by the
Sessions Judge of North Malabar and sentenced to rigorous imprisonment for 5 years but this
sentence was reduced to 6 months' imprison- ment by the Madras High Court on appeal. The
petitioner made a fresh application to the High Court praying for a writ of habeas corpus in respect
of his detention under the Madras Maintenance of Public Order Act and this application, which was
heard after he had served out his sentences of imprisonment referred to above, was dismissed in
January, 1950. On 25th February, 1950, the Preventive Detention Act was passed by the Parliament
and on the 1st of March follow- ing, the the detention of the applicant under the Madras
Maintainance of Public Order Act was cancelled and he was served with a fresh order of detention
under section 3 (1) of the Preventive Detention Act, 1950. On behalf of the respondents the
detention of the petitioner is sought to be justified on the strength of the Preventive Detention Act of
1950. The position taken up on behalf of the petitioner on the other hand is that the said Act is
invalid and ultra vires the conStitution by reason of its being in conflict with certain fundamental
rights which are guaranteed by the Constitution. It is argued, therefore, that the detention of the
peti- tioner is invalid and that he should be set at liberty. The contentions that have been but
forward-by Mr. Nambi- ar who appeared in support of the petition, may be classi- fied under four
heads. His first contention is that as preventive detention is, in substance, a restriction on the free
movements of a person throughout the Indian territory, it comes within the purview of article 19 (1)
(d) of Part III of the Constitution which lays down the fundamental rights. Under clause (5) of the
article, any restriction imposed upon this right of free movement must be reasonable and should be
prescribed in the interests of the general public. The question as to whether it is reasonable or not is
a justiciable matter which is to be determined by the Court. This being the legal position, the learned
Counsel invites us to hold that the main provisions of the impugned Act, particularly those which
are contained in sections 3, 7, 10, 11, 12, 13 and 14 are wholly unreasonable and should be
invalidated on that ground.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

The second contention advanced by the learned Counsel is that the impugned legislation is in
conflict with the provi- sion of article 21 of the Constitution inasmuch as it pro- vides for deprivation
of the personal liberty of a man not in accordance with a procedure established by law. It is argued
that the word 'law' here does not mean or refer to any particular legislative enactment but it means
the gener- al law of the land, embodying those principles of natural justice' with regard to procedure
which are regarded as fundamental, in all systems of civilised jurisprudence. It is conceded by the
learned counsel that the proce- dure, if any, with regard to preventive detention as has been
prescribed by article 22 of the Constitution which itself finds a place in the chapter on Fundamental
Rights must override those general rules of procedure which are contemplated by article 21 but with
regard to matters for which no provision is made in article 22, the general provi- sion made in article
21 must apply. He has indicated in course of his arguments what the essentials of such procedure
are and the other point specifically raised in this connection is that the provision of section 12 of the
Preventive Detention Act is in conflict with article 22 (7) of the Constitution. The last argument in
support of this application is that the provisions of sections 3 and 14 of the Preventive Deten- tion
Act are invalid as they take away and render completely nugatory the fundamental right to
constitutional remedies as is provided for in article 32 of the Constitution. In discussing these points
it should be well to keep in mind the general scheme of the Indian Constitution relating to the
protection of the fundamental rights of the citizens and the limitations imposed in this respect upon
the legis- lative powers of the Government. The Constitution of India is a written Constitution and
though it has adopted many of the principles of the English Parliamentary system, it has not
accepted the English doctrine of the absolute supremacy of Parliament in matters of legislation. In
this respect it has followed the American Constitution and other systems modelled on it.
Notwithstanding the representative charac- ter of their political institutions, the Americans regard
the limitations imposed by their Constitution upon the action of the Government, both legislative
and executive, as essential to the preservation of public and private rights. They serve as a check
upon what has been described as the despotism of the majority; and as was observed in the case of
Hurtado v. The People of California (1) "a government which holds the lives, the liberty and the
property of its citizens, subject at all times to the absolute disposition and unlimited control of even
the most democratic depository of power, is after all but a despotism." In India it is the Constitution
that is supreme and Parliament as well as the State Legislatures must not only act within the limits
of their respective legislative spheres as demarcated in the three (1) 110 U.S. 516.
lists occuring in the Seventh Schedule to the Constitution, but Part III of the Constitution
guarantees to the citizens certain fundamental rights which the legislative authority can on no
account transgress. A statute law to be valid must, in all cases, be in conformity with the
constitutional requirements and it is for the judiciary to decide whether any enactment is
unconstitutional or not. Article 13 (2) is imperative on this point and provides expressly that the
State shall not make any law which takes away or abridges the right conferred by this Part and any
law made in contra- vention of this clause shall, to the extent of the contra- vention, be void. Clause
(1) of the article similarly invalidates all existing laws which are inconsistent with the provisions of
this Part of the Constitution. The fundamental rights guaranteed by the Constitution have been
classified under seven heads or categories. They are:
(1) Right to equality;A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(2) Right to freedom;
(3) Right against exploitation;
(4) Right to freedom of religion;
(5) Cultural and educational rights;
(6) Right to property; and (7) Right to constitutional remedy.
The arrangement differs in many respects from that adopted in the American Constitution and bears
a likeness on certain points to similar declarations in the Constitutions of other countries.
Of the different classes of fundamental rights spoken of above, we are concerned here primarily with
right to freedom which is dealt with in four articles beginning from article 19 and also with the right
to constitutional remedy which is embodied in article 32.
Article 10 enumerates certain forms of liberty or free- dom, the protection of which is guaranteed by
the Constitu- tion. In article 20, certain protections are given in cases of persons accused of criminal
offences. Article 21 lays down in general terms that no person shall be deprived of his life or
personal liberty, except according to procedure established by law. Article 22 pro- vides for certain
additional safeguards in respect to arrest and detention and by way of exception to the rules so
made, makes certain special provisions for the particular form of detention known as Preventive
Detention.
The first contention advanced by Mr. Nambiar involves a consideration of the question as to
whether Preventive Detention, which is the subject matter of the impugned legislative enactment,
comes within the purview of article 19 (1) (d) of the Constitution, according to which a right to move
freely throughout the territory of India is one of the fundamental rights guaranteed to all citizens. If
it comes within that sub-clause, it is not disputed that clause (5) of article 19 would be attracted to it
and it would be for the courts to decide whether the restrictions imposed upon this right by the
Parliament are reasonable restric- tions and are within the permissible limits prescribed by clause
(5) of the article.
There is no authoritative definition of the term 'Pre- ventive Detention' in Indian law, though as
description of a topic of legislation it occurred in the Legislative Lists of the Government of India
Act, 1935, and has been used in Item 9 of List I and Item 3 of List III in the Seventh Schedule to the
Constitution. The expression has its origin in the language used by Judges or the law Lords in
England while explaining the nature of detention under Regulation 14 (B) of the Defence of Realm
Consolidation Act, 1914, passed on the outbreak of the First World War; and the same lan- guage
was repeated in connection with the emergency regula- tions made during the last World War. The
word ' preventive ' is used in contradistinction to the word ' punitive.' To quote the words of Lord
Finlay in Rex v. Halliday(1), "it is not a punitive but a precautionary measure." The object is not to
punish a man for having done something but to intercept him before he does it and to prevent himA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

from doing it. No offence is proved, nor any charge formulated; and the justification of such
detention is suspicion (1) [1917] A.C. 260 at p. 269.
or reasonable probability and not criminal conviction which can only be warranted by legal evidence
(1). Detention in such form is unknown in America. It was resorted to in England only during war
time but no country in the world that I am aware of has made this an integral part of their
Constitution as has been done in India. This is undoubtedly unfortunate, but it is not our business to
speculate on questions of policy or to attempt to explore the reasons which led the representatives of
our people to make such a drastic provision in the Constitution itself, which cannot but be regarded
as a most unwholesome encroachment upon the liberties of the people.
The detention of a man even as a precautionary measure certainly deprives him of his personal
liberty, and as article 21 guarantees to every man, be he a citizen or a foreigner, that he shall not be
deprived of his life and personal liberty, except in accordance with the procedure established by law,
the requirements of article 21 would certainly have to be complied with, to make preventive
detention valid in law. What these requirements are I will discuss later on. Article 22 comes
immediately after arti- cle 21. It secures to all persons certain fundamental rights in relation to
arrest and detention, and as already said, by way of exception to the rights thus declared, makes
certain specific provisions relating to preventive deten- tion. The subject of preventive detention is
specified in and constitutes Item No. 9 in the Union legislative List and it also forms Item No. 3 in
the Concurrent List. Under article 246 of the Constitution, the Parliament and the State Legislatures
are empowered to legislate on this sub- ject within the ambit of their respective authorities.
Clause(3) of article 22 expressly enjoins that the protec- tive provisions of clauses (1) and (2) of the
article would not be available to persons detained under any law providing for preventive detention.
The only fundamental rights which are guaranteed by the Constitution in the matter of preven- tive
detention and which to that extent impose restraints upon the exercise of legislative powers in that
respect are (1) Vide Lord Macmillan in Liversidge v. Anderson [1942] A.C. 206 at p. 254.
contained in clauses (4) to (7) of article 22. Clause (4) lays down that no law of preventive detention
shall autho- rise the detention of a person for a period longer than three months, unless an advisory
board constituted in the manner laid down in sub-clause (a) of the clause has report- ed before the
expiration of the period that there is suffi- cient cause for such detention. The period of detention
cannot, in any event, exceed the maximum which the Parlia- ment is entitled to prescribe under
clause (7) (b). The Parliament is also given the authority to prescribe the circumstances and the class
of cases under which a person can be detained for a period longer than three months under any law
of preventive detention without obtaining the opin- ion of the advisory board. There is one
safeguard provided for all cases which is contained in clause (5) and which lays down that the
authority making the order of detention shall, as soon as possible communicate to such person the
grounds on which the order has been made and shall afford him the earliest opportunity of making a
representation against the order. But even here, the authority while giving the grounds of detention
need not disclose such facts which it considers against public interest to disclose. The question that
we have to consider is whether a law relating to preventive detention is justiciable in a Court of law
on the ground of reasonableness under article 19 (5) of the Constitution inasmuch as it takes away
or abridges the right to free movement in the territory of India guaran- teed by clause (1) (d)of theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

article. It will be seen from what has been said above that article 22 deals specifically with the
subject of preventive detention and expressly takes away the fundamental rights relating to arrest
and detention enumerated in clauses (1) and (2) of the article from per- sons who are detained
under any law which may be passed by the Parliament or State Legislatures acting under article 246
of the Constitution read with the relevant items in the legislative lists. I will leave aside for the
moment the question as to how far the court can examine the reasonable- ness or otherwise of the
procedure that is prescribed by any law relating to preventive detention, for that would involve a
considera- tion of the precise scope and meaning of article. 21; but this much is beyond controversy
that so far as substantive law is concerned, article 22 of the Constitution gives a clear authority to
the legislature to take away the funda- mental rights relating to arrest and detention, which are
secured by the'first two clauses of the article. Any legis- lation on the subject would only have to
conform to the requirements of clauses (4) to (7) and provided that is done, there is nothing in the
language employed nor in the context in which it appears which affords any ground for suggestion
that such law must be reasonable in its character and that it would be reviewable by the Court on
that ground. Both articles 19 and 22 occur in the same Part of the Con- stitution and both of them
purport to lay down the fundamen- tal rights which the Constitution guarantees. It is well settled
that the Constitution must be interpreted in a broad and liberal manner giving effect to all its parts,
and the presumption should be that no conflict or repugnancy was intended by its framers. In
interpreting the words of a Constitution, the same principles undoubtedly apply which are
applicable in construing a statute, but as was observed by Lord Wright in James v. Commonwealth
of Australia ( 1 ), "the ultimate result must be determined upon the actual words used not in vacuo
but as occurring in a single complex instrument in which one part may throw light on the other."
"The Constitution," his Lordship went on saying, "has been described as the federal
compact and the construction must hold a balance between all its parts."
It seems to me that there is no conflict or repugnancy between the two provisions of the Constitution
and an exami- nation of the scheme and language of the catena of articles which deal with the rights
to freedom would be sufficient to show that what clause (1) (d) of article 19 contemplates is not
freedom from detention, either punitive or preventive; it relates to and speaks of a different aspect
or phase of civil liberty.
(1) [1936] A.C. 578 at p. 613.
Article 19, which is the first of this series of arti- cles, enumerates seven varieties or forms of
freedom begin- ning with liberty of speech and expression and ending' with free right to practise any
trade, profession or business. The rights declared it articles 19 to 22 do not certainly exhaust the
whole list of liberties which people possess under law. The object of the framers of the Constitution
obviously is to enumerate and guarantee those forms of liberty which come under well-known
categories recognised by constitutional writers and are considered to be fundamental and of vital
importance to the community.
There cannot be any such thing as absolute or uncon- trolled liberty wholly freed from restraint, for
that would lead to anarchy and disorder. The possession and enjoyment of all rights, as wasA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

observed by the Supreme Court of America in Jacobson v. Massachusetts (1), are subject to such
reasonable conditions as may be deemed by the governing authority of the country essential to the
safety, health, peace, general order and morals of the community. The question, therefore arises in
each case of adjusting the conflicting interests of the individual and of the society. In some cases,
restrictions have to be placed upon free exercise of individual rights to safeguard the interests of the
society; on the other hand, social control which exists for public good has got to be restrained, lest it
should be misused to the detriment of individual rights and liberties. Ordinarily, every man has the
liberty to order his life as he pleases, to say what he will, to go where he will, to follow any trade,
occupation or calling at his pleasure and to do any other thing which he can lawfully do without let
or hindrance by any other person. On the other hand for the very protection of these liberties the
society must arm itself with certain powers. No man's liberty would be worth its name if it can be
violated with impunity by any wrong- doer and if his property or possessions could be preyed upon
by a thief or a marauder. The society, therefore, has got to exercise certain powers for the protection
of these liber- ties and to arrest, search, imprison and (1) 197 U.S. 11.
punish those who break the law. If these powers are' prop- erly exercised, they themselves are the
safeguards of free- dom, but they can certainly be abused. The police may arrest any man and throw
him into prison without assigning any reasons; they may search his belongings on the slightest
pretext; he may be subjected to a sham trial and even pun- ished for crimes unknown to law. What
the Constitution, therefore, attempts to do in declaring the rights of the people is to strike a balance
between individual liberty and social control.
To me it seems that article 19 of the Constitution gives a list of individual liberties and prescribes in
the various clauses the restraints that may be placed upon them by law, so that they may not conflict
with public welfare or general morality. On the other hand articles 20, 21 and 22 are primarily
concerned with penal enactments or other laws under which personal safety or liberty of persons
could be taken away in the interests of the society and they set down the limits within which the
State control should be exer- cised. Article 19 uses the expression ' 'freedom" and men- tions the
several forms and aspects of it which are secured to individuals, together with the limitations that
could be placed upon them in the general interests of the society. Articles 20, 21 and 22 on the other
hand do not make use of the expression "freedom" and they lay down the restrictions that are to be
placed on State control where an individual is sought to be deprived of his life or personal liberty.
The right to the safety of one's life and limbs and to enjoyment of personal liberty, in the sense of
freedom from physical restraint and coercion of any sort, are the inher- ent birthrights of a man. The
essence of these rights consists in restraining others from interfering with them and hence they
cannot be described in terms of "freedom" to do particular things. There is also no question of
imposing limits on the activities of individuals so far as the exer- cise of these rights is concerned.
For these reasons, I think, these rights have not been mentioned in article 19 of the Constitution. An
individual can be deprived of his life or personal liberty only by action of the State, either under the
provisions of any penal enactment or in the exercise of any other coercive process vested in it under
law. What the Constitution does there- fore is to put restrictions upon the powers of the State, for
protecting the rights of the individuals. The re- straints on State authority operate as guarantees of
indi- vidual freedom and secure to the people the enjoyment of life and personal liberty which are
thus declared to be inviolable except in the manner indicated in these articles. In my opinion, theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

group of articles 20 to 22 embody the entire protection guaranteed by the Constitution in relation to
deprivation of life and personal liberty both with regard to substantive as well as to procedural law.
It is not correct to say, as I shah show more fully later on, that article 21 is confined to matters of
procedure only. There must be a substantive law, under which the State is empow- ered to deprive a
man of his life and personal liberty and such law must be a valid law which the legislature is compe-
tent to enact within the limits of the powers assigned to it and which does not transgress any of the
fundamental rights that the Constitution lays down. Thus a person cannot be convicted or punished
under an ex post facto law, or a law which compels the accused to incriminate himself in a crimi- nal
trial or punishes him for the same offence more than once. These are the protections provided for by
article 20. Again a law providing for arrest and detention must conform to the limitations prescribed
by clauses (1) and (2) of article 22. These provisions indeed have been withdrawn expressly in case
of preventive detention and protections of much more feeble and attenuated character have been
substi- tuted in their place;but this is a question of the policy adopted by the Constitution which
does not concern us at all. The position, therefore, is that with regard to life and personal liberty, the
Constitution guarantees protection to this extent that no man could be deprived of these rights
except under a valid law passed by a competent legislature within the limits mentioned above and in
accordance with the procedure which such law lays down. Article 19, on the other hand, enunciates
certain particular forms of civil liberty quite independently of the rights dealt with under article 21.
Most of them may be connected with or dependent upon person- al liberty but are not identical with
it; and the purpose of article 19 is to indicate the limits within which the State could, by legislation,
impose restrictions on the exercise of these rights by the individuals. The reasonableness or
otherwise of such legislation can indeed be determined by the Court to the extent laid down in the
several clauses of article 19, though no such review is permissible with regard to laws relating to
deprivation of life and personal liber- ty. This may be due to the fact that life and personal freedom
constitute the most vital and essential rights which people enjoy under any State and in such
matters the pre- cise and definite expression of the intention of the legislature has been preferred by
the Constitution to the variable standards which the judiciary might lay down. We find the rights
relating to personal liberty being de- clared almost in the same terms in the Irish Consti- tution
article 40 (1) (4) (1) of which lays down that "no citizen shall be deprived of his personal liberty save
in accordance with law." In the Constitution of the Free City of Danzig, "the liberty of the person has
been declared to be inviolable and no limitation or deprivation of personal liberty may be imposed
by public authority except by virtue of a law" (vide article 74). Article 31 of the Japanese
Constitution is the closest parallel to article 21 of the Indian Constitution and the language is almost
identical. This is the scheme adopted by the Constitution in dealing with the rights to freedom
described in the chapter on fundamental rights and in my opinion, therefore, the proper test for
determining the validity of an enactment under which a person is sought to be deprived of his life
and personal liberty has to be found not in article 19, but in the three following articles of the
Constitution. Article 20 of course has no application so far as the law relating to preventive
detention is concerned.
Mr. Nambiar's endeavour throughout has been to establish that article 19 (1) (d) of the Constitution
read with article 19 (5) enunciates the fundamental rights of the citizens regarding the substantive
law of personal liberty, while article 21 embodies the protection as regards proce- dural law. This, in
my opinion, would be looking at these provisions from a wrong angle altogether. Article 19 cannotA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

be said to deal with substantive law merely, nor article 21 with mere matters of procedure. It cannot
also be said that the provisions of article 19 (1) (d) read with clause (5) and article 21 are
complementary to each other. The con- tents and subject matter of the two provisions are not
identical and they proceed on totally different princi- ples. There is no mention of any "right to life"
in article 19, although that is the primary and the most important thing for which provision is made
in article 21. If the contention of the learned counsel is correct, we would have to hold that no
protection is guaranteed by the Constitution as regards right to life so far substantive law is con-
cerned. In the second place, even if freedom of movement may be regarded as one of the ingredients
of personal liberty, surely there are other elements included in the concept and admittedly no
provision for other forms of personal liberty are to be found in article 19 (5) of the Constitution.
Furthermore article 19 is applicable to citizens only, while the rights guaranteed by article 21 are for
all per- sons. citizens as well as aliens. The only proper way of avoiding these anomalies is to
interpret the two provisions as applying to different subjects and this would be the right conclusion
if we have in mind the scheme which under- lies this group of articles.
I will now turn to the language of article 19 (1) (d) and see whether preventive detention really
comes within its purview. Article 19 (1) (d) provides that all citizens shall have the right to move
freely throughout the territory of India. The two sub-clauses which come immediately after
sub-clause (d) and are intimately connected with it, are in these terms:
"(e) To reside and settle in any part of the territory of India;
(f) to acquire, hold and dispose of property." Clause (5)relates to all these three
sub-clauses and lays down that nothing in them shall affect the operation of any
existing law in so far as it imposes, or prevent the State from making any law
imposing, reasonable restrictions on the exercise of any of the rights conferred by the
said sub-
clause either in the interests of the general public or for the protection of the interests of any
scheduled tribe. I agree with the learned Attorney-General that in con- struing article 19 (1) (d)
stress is to be laid upon the expression "throughout the territory of India," and it is a particular and
special kind of right, viz., that of free movement throughout the Indian territory, that is the aim and
object of the Constitution to secure. In the next sub- clause, right tO reside and settle "in any part of
the territory of India" is given and here again the material thing is not the right of residence or
settlement but the right to reside or settle in any part of the Indian territo- ry. For an analogous
provision, we may refer to article 301 which says that subject to the other provisions of this Part,
commerce and intercourse throughout the territory of India shall be free. The meaning of sub-clause
(d) of arti- cle 19 (1) will be clear if we take it along with sub- clauses (e) and (f), all of which have
been lumped together in clause (5) and to all of which the same restrictions including those relating
to protecion of the interest of any scheduled tribe have been made applicable. It will be remembered
that these rights are available only to citizens. To an alien or foreigner, no guarantee of such rights
has been given. Normally all citizens would have the free right to move from one part of the Indian
territory to another. They can shift their residence from one place to any other place of their choice
and settle anywhere they like. The right of free trade, commerce and intercourse throughout theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

territory of India is also secured. What the Constitu- tion emphasises upon by guaranteeing these
rights is that the whole of Indian Unian in spite of its being divided into a number of States is really
one unit as far as the citizens of the Union are concerned. All the citizens would have the same
privileges and the same facilities for moving into any part of the territory and they can reside or
carry on business anywhere they like; and no restrictions either inter-State or otherwise would be
allowed to set up in these respects between one part of India and another.
So far as free movement throughout the territory is concerned, the right is subject to the provision of
clause (5), under which reasonable limitation may be imposed upon these liberties in the interests of
the general public or protection of any scheduled tribe. The interests of the public which necessitates
such restrictions may be of var- ious kinds. They may be connected with the avoidance of pestilence
or spreading of contagious diseases; certain places 'again may be kept closed for military purposes
and there may be prohibition of entry into areas which are actual or potential war zones or where
disturbances of some kind or other prevail. Whatever the reasons might be, it is necessary that these
restrictions must be reasonable, that is to say, commensurate with the purpose for which they are
laid down. In addition to general interest, the Constitu- tion has specified the protection of the
interests of the scheduled tribes as one of the factors which has got to be taken into consideration in
the framing of these restric- tions. The scheduled tribes, as is well known, are a back- ward and
unsophisticated class of people who are liable to be imposed upon by shrewd and designing persons.
Hence there are various provisions disabling them from alienating even their own properties except
under special conditions. In their interest and for their benefit, laws may be made restricting the
ordinary right of citizens to go or settle in particular areas or acquire property in them. The refer-
ence to the interest of scheduled tribe makes it quite clear-that the free movement spoken of in the
clause relates not to general rights of locomotion but to the particular right of shifting or moving
from one part of the Indian territory to another, without any sort of discriminatory barriers.
This view will receive further support if we look to some analogous provisions ,in the Constitution of
other countries. It will be seen that sub-clauses (d) (e) and (f)of article 19 (1) are embodied in almost
identical language in one single article, viz., article 75 of the Constitution of the Free City of Danzig.
The article runs as follows:
"All nationals shall enjoy freedom of movement within the free city and shall have the
right to stay and to settle at any place they may choose, to acquire real property and
to earn their living in any way. This right shall not be curtailed without legal
sanctions."
The several rights are thus mentioned together as being included in the same category, while they
are differentiated from the "liberty of the person" which is "described to be inviolable except by
virtue of a law" in article 74 which appears just previous to this article. An analogous provi- sion in
slightly altered language occurs in article 111 of the Constitution of the German Reich which is
worded in the following manner:
All Germans enjoy the right of change of domicile within the whole Reich. Every one
has the right to stay in any part of the Realm that he chooses, t6 settle there, acquireA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

landed property and pursue any means of livelihood." Here again the right to
personal liberty has been dealt with separately in article 114. A suggestion was made
in course of our discussions that the expression "throughout the territory of India"
occurring in article 19 (1) (d) might have been used with a view to save Passport
Regulations or to emphasise that no rights of free emigration are guaran- teed by the
Constitution. The suggestion does not seem to me to be proper. No State can
guarantee to its citizens the. free right to do anything outside its own territory.This is
true of all the fundamental rights men- tioned in article 19 and not merely of the right
of free movement. Further it seems to me that the words "throughout the territory of
India" have nothing to do with rights of emigration. We find that both in the Danzig
as well as in the German Constitution, where similar words have been used with
regard to the excercise of the right of free movement throughout the.
territory, there are specific provisions which guarantee to all nationals the free right
of emigration to other coun- tries (vide article 76 of the Danzig Constitution and arti-
cle 112 of the Constitution of the German Reich). In my opinion, therefore, preventive
detention does not come either within the express language or within the spirit and
intendment of clause (1) (d) of article 19 of the Constitu- tion which deals with a
totally different aspect or form of civil liberty.
It is true that by reason of preventive detention, a man may be prevented from
exercising the right of free movement within the territory of India as contemplated by
article 19 (1) (d) of the Constitution, but that is merely incidental to or consequential
upon loss of liberty resulting from the order of detention. Not merely the right under
clause (1)
(d), but many of the other rights which are enumerated under the other-sub-clauses
of article 19 (1) may be lost or suspended so long as preventive detention continues.
Thus a detenu so long as he is under detention may not be able to practise any
profession, or carry on any trade or business which he might like to do; but this
would not make the law providing for preventive detention a legislation taking away
or abridging the rights under article 19 (1) (g) of the Constitution and it would be
absurd to suggest that in such cases the validity of the legislation should be tested in
accordance with the requirement of clause (6) of article 19'and that the only
restrictions that could be placed upon the person's free exercise of trade and
profession are those specified in that clause. Mr. Nambiar concedes that in such cases
we must look to the substance of the particular legis-
lation and the mere fact that it incidentally trenches upon some other right to which it does not
directly relate is not material. He argues, however, that the essence or substance of a legislation
which provides for preventive detention is to take away or curtail the right of free move- ments and
in fact, "personal liberty" according to him, connotes nothing else but unrestricted right of
locomotion. The learned counsel refers in this connection to certain passages in Blackstone's
Commentaries on the Laws of Eng- land, where the author discusses what he calls the threeA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

absoluterights inherent in every Englishman, namely, rights of personal security, personal liberty
and property. "Personal security", according to Blackstone, consists in a person's legal and
uninterrupted enjoyment of his life, his limb, his body, his health and his reputation; whereas
"personal liberty" consists in the power of locomotion, of changing of situation or moving one's
person to whatsoever place one's own inclination may direct without imprisonment or restraint
unless by due course of law (1). It will be seen that Blackstone uses the expression "personal liberty"
in a somewhat narrow and restricted sense. A much wider and larger connotation is given to it by
later writers on con- stitutional documents, particularly in America. In ordinary language "personal
liberty" means liberty relating to or concerning the person or body of the individual; and "per- sonal
liberty" in this sense is the antithesis of physical restraint or coercion. According to Dicey, who is an
acknowledged authority on the subject "personal liberty"
means a personal right not to be subjected to imprisonment, arrest or other physical
coercion in any manner that does not admit of legal justification(2). It is, in my
opinion, this negative right of not being subjected to any form of physical restraint or
coercion that constitutes the essence of personal liberty and not mere freedom to
move to any part of the Indian territory.
In this connection, it may not be irrelevant to. point out that it was in accordance
with the recommendation of the'Drafting Committee that the word "personal" was
inserted before "liberty" in article 15 of the Constitution which now stands as article
21. In the report of the Drafting Commit- tee it is stated that the word "liberty" should
be quali- fied by the insertion of the word "personal" before it; otherwise, it might be
construed very widely so as to in- clude even the freedoms already dealt with in
article 13. Article. 13, it should be noted, is the present article 19. If the views of the
Drafting Committee were accepted by the (1) Vide Chase's Blackstone, 4th Edn, pp.
68, 73. (2) Vide Dicey on Constitutional Law, 9th Edn, pp. 207-208.
Constituent Assembly, the intention obviously was to exclude the contents of article 19. from the
concept of "personal liberty" as used in article 21. To -what extent the meaning of words used in the
Constitution could be discovered from reports of Drafting Committee or debates on the floor of the
House is a matter not quite free from doubt and I may have to take up this matter later on when
discussing the meaning of the material clause in article 21 of the Constitution. It is enough to say at
this stage that if the report of the Drafting Committee is an appropriate material upon which the
interpretation of the words of the Constitution could be based, it certainly goes against the
contention of the applicant and it shows that the words used in article 19 (1)
(d) of the Constitution do not mean the same thing as the expression "personal liberty" in article 21
does. It is well known that the word "'liberty" standing by itself has been given a very wide meaning
by the Supreme Court of the United States of America. It includes not only personal freedom from
physical restraint but the right to the free use of one's own property and to enter into free
contractual relations, In the Indian Constitution, on the other hand, the expression "personal
liberty" has been deliberately used to restrict it to freedom from physical restraint of person by
incarceration or otherwise. Apart from the report of the Drafting Committee, that is the plainA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

grammatical meaning of the expression as I have already explained.
It may not, I think, be quite accurate to state that the operation of article 19 of the Constitution is
limited to free citizens only and that the rights have been described in that article on the
presupposition that the citizens are at liberty. The deprivation of personal liberty may entail as a
consequence the loss or abridgement of many of the rights described in article 19, but that is because
the nature of these rights is such that free exercise of them is not possible in the absence of personal
liberty. On the other hand, the right to hold and dispose of property which is in subclause (f) of
article 19 (1) and which is not dependent on full possession of personal liberty by the owner may not
be affected if the owner is imprisoned or detained. Anyway, the point is not of much importance for
purposes of the present discussion. The result is that, in my opinion, the first contention raised by
Mr. Nambiar cannot succeed and it must be held that we are not entitled to examine the
reasonableness or otherwise of the Preventive Detention Act and see whether it is within the
permissible bounds specified in clause (5) of article 19.
I now come to the second point raised by Mr. Nambiar in support of the application; and upon this
point we had arguments of a most elaborate nature addressed to us by the learned counsel on both
sides, displaying a considerable amount of learning and research. The point, however, is a short one
and turns upon the interpretation to be put upon article 21 of the Constitution, which lays down that
"no person shall be deprived of his ........ personal liberty, except according to procedure established
by law." On a plain reading of the article the meaning seems to be that you cannot deprive a man of
his personal liberty, unless you follow and act according to the law which provides for deprivation of
such liberty. The expression "procedure" means the manner and form of enforcing the law. In my
opinion, it cannot be disputed that in order that there may be a legally established procedure, the
law which establish- es it must be a valid and lawful law which the legislature is competent to enact
in accordance with article 245 of the Constitution and the particular items in the legislative lists
which it relates to. It is also not disputed that such law must not offend against the fundamental
rights which are declared in Part III of the Constitution. The position taken up by the learned
Attorney-General is that as in the present case there is no doubt about the competency of that
Parliament to enact the law relating to preventive detention which is fully covered by Item 9 of List
I, and Item 3 of List III, and as no question of the law being reasonable or otherwise arises for
consideration by reason of the fact that article 19 (1) (d) is not attracted to this case, the law must be
held to be a valid piece of legisla- tion and if the procedure laid down by it has been adhered to, the
validity of the detention cannot possibly be challenged. His further argu- ment is that article 22
specifically provides for preventive detention and lays down fully what the requirements of a
legislation on the subject should be. As the impugned Act conforms to the requirements of article
22, no further ques- tion of its validity under article 21 of the Constitution at all arises. The latter
aspect of his arguments, I will deal with later on. So far as the main argument is concerned,the
position taken up by Mr. Nambiar is that article 21 refers to 'procedure only and not to substan- tive
law the procedure, however, must be one which is established by law. The expression "law" in this
context does not mean or signify, according to the learned counsel, any particular law enacted by the
legislature in conformity with the requirements of the Constitu- tion or otherwise possessing a
binding authority. It refers to law in the abstract or general sense--in the sense of jus and not
lex--and meaning thereby the legal principles or fundamental rules that lie at the root of everyA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

system of positive law including our own, and the authority of which is acknowledged in the
jurisprudence of all civilised coun- tries. It is argued that if the word "law" is interpret- ed in the
sense of any State-made law, article 21 could not rank as a fundamental right imposing a check or
limitation on the legislative authority of the Government. It will be always competent to the
legislature to pass a law laying down a thoroughly arbitrary and irrational procedure opposed to all
elementary principles of justice and fairness and the people would have no protection whatsoever,
provided such procedure was scrupulously adhered to. In support of this argument the learned
counsel has relied upon a large number of American cases, where the Supreme Court of America ap-
plied the doctrine of "due process of law" as it appears in the American Constitution for the purpose
of invalidating various legislative enactments which appeared to that Court to be capricious and
arbitrary and opposed to the fundamen- tal principles of law.
It may be noted here that in the original draft of the Indian Constitution the words used in article 15
(which now stands as article 21) were "in accordance with due process of law." The Drafting
Committee recommended that in place of the "due process" clause, the expression "according to
procedure established by law" should be substituted. The present article 21 seems to have been
modeled on article 31 of the Japanese Constitution, where the language employed is "no person shall
be deprived of'life or liberty, nor shall any other criminal penalty be imposed, except according to
procedure established by law." Mr. Nambiar argues that the expression "procedure established by
law" in article 21 of the Constitution bears the same meaning as the "due process" clause does in
America, restricted only to this extent, viz., that it is limited to matters of procedure and does not
extend to questions of substantive law. To appre- ciate the arguments that have been advanced for
and against this view and to fix the precise meaning that is to be given to this clause in article 21, it
would be necessary to discuss briefly the conception of the doctrine of "due process of law" as it
appears in the American Constitution and the way in which it has been developed and applied by the
Supreme Court of America.
In the history of Anglo-American law, the concept of "due process of law" or what is considered to be
its equiva- lent "law of the land" traces its lineage far back into the beginning of the 13th century
A.D. The famous 39th chapter of the Magna Charta provides that "no free man shall be taken or
imprisoned or disseized, or outlawed or exiled or in any way destroyed; nor shall we go upon him
nor send upon him but by the lawful judgment of his peers and by the law of the land." Magna
Charta as a charter of English liberty was confirmed by successive English monarchs and it is in one
of these confirmations (28 Ed. III, Chap. 3) known as "Statute of Westminster of the liberties of
London", that the expression "due process of law" for the first time appears. Neither of these phrases
was explained or defined in any of the
-documents, but on the authority of Sir Edward Coke it may be said that both the expressions have
the same meaning. In substance, they guaranteed that persons should not be imprisoned without
proper indictment and trial by peers, and that property should not be seized except in proceedings
conducted in due form in which the owner or the person in possession should have an opportunity
to show cause why seizure should not be made (1). These concepts came into America as part of the
rights of Englishmen claimed by the colonists. The expression in one form or other appeared in
some of the earlier State Constitutions and the exact phrase "due process of law" came to be a part ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the Federal Constitution by the Fifth Amendment which was adopted in 1791 and which provided
that "no person shall... be deprived of life, liberty or property without due process of law." It was
imposed upon the State Constitution in almost identical language by the Fourteenth Amendment in
the year 1868. What "due process of law" exactly means is difficult to define even at the present day,
The Constitution contains no description of what is "due process of law" nor does it declare the
principles by application of which it could be ascertained. In Twining v. New Jersey (2) the Court
ob- served:
"Few phrases in the law are so elusive of exact appre- hension as this. This COurt has
always declined to give a comprehensive definition of it and has preferred that its full
meaning should be gradually ascertained by the process of inclusion and exclusion in
the course of the decisions of cases as they arise."
It is clear, however, that the requirement of "due process of law" in the United States Constitution
imposes a limitation upon all the powers of Government, legislative as well as executive and judicial.
Applied in England only as protection against executive usurpation and royal tyranny, in America it
became a bulwark against arbitrary legislation (3).
(1) Vide Willoughby on the Constitution of the United States, Vol. III, p. 1087.
(2) 211 U.S. 79.
(3) Vide Hurtando v. People of California, 110 U.S. 516 at p. 532.
As it is a restraint upon the legislative power and the- object is to protect citizens against arbitrary
and capri- cious legislation, it is not within the competence of the Congress to make any process a
"due process of law" by its mere will; for that would make the limitation quite nugato- ry. As laid
down in the case cited above, "it is not any act legislative in form that is law; law is something more
than mere will exerted as an act of power." It means and signifies the general law of the land, the
settled and abid- ing principles which inhere in the Constitution and lie at the root of the entire legal
system. To quote the words of Daniel Webster in a famous argument before.the Supreme Court (1):
"By the law of the land is most clearly intended the general law--a law which hears
before it condemns, which proceeds upon enquiry and renders judgment only after
trial. The meaning is that every citizen shall hold his life, liberty, property and
immunities under the protection of the general rules which govern society."
What these principles of general law are nobody has ever attempted to enumerate. To a large extent
they are the principles of English common law and modes of judicial pro- ceedings obtaining in
England, the traditions of which came along with the settlers in America. Some Judges seem to have
alluded to the principles of natural justice in ex- plaining what is meant by general law or "law of the
land,"A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

though the doctrine of a law of nature did not obtain a firm footing at any time. In
Wynehamer v. New York (2), Justice Hubbard declared himself opposed to the
judiciary attempting to set bounds to the legislative authority or declaring a statute
invalid upon any fanciful theory of'higher law or first principles of natural right
outside of the Constitu- tion. Coke's dictum of a supreme fundamental law which
obviously referred to principles of English common law cer- tainly did exercise
considerable influence upon the minds of the American Judges (3) and there are
observations in some cases (1) Darmouth College case, 4 Wheaton p. 518. (2) 13 N.Y.
379.
(3) Willis on Constitutional Law, p. 647.
which go to suggest that the principles of natural justice were regarded as identical with those of
common law, except where the rules of common law were not considered to be of fundamental
character or were not acted upon as being un- suited to the progress of time or conditions of the
American Society (1). In the case of Loan Association v. Topeka (2), it was observed that there are
limitations upon powers of Government which grow out of the essential nature of free
Governments--implied reservations of individual rights without which the social compact could not
exist and which are respected by all Governments entitled to the name. What is hinted at, is
undoubtedly the old idea of a social com- pact under which political institutions were supposed to
come into being; and the suggestion is that when the Ameri- cans formed themselves into a State by
surrendering a por- tion of their rights which they possessed at that time and which presumably
they inherited from their English ancestors, there were certain rights of a fundamental character
still reserved by them which no State could possibly take away.
As has been said already, "due process of law" has never been defined by Judges or Jurists in
America. The best description of the expression would be to say that it means in each particular case
such an exercise of the powers of Government as the settled maxims of law permit and sanction, and
under such safeguards for the protection of individual rights as those maxims prescribe for the class
of cases to which the one in question belongs (3).
In the actual application of the clause relating to "due process of law" to particular cases the
decisions of the Supreme Court of America present certain peculiar and unusu- al features and there
is total lack of uniformity and consistency in them. Ever since the appearance of the clause in the
Fifth Amendment and down to the middle of the 19th century, it was interpreted as a restriction on
proce- dure, and particularly the judicial procedure, by which the Government (1) Cooley's
Constitutional Limitations, Vol. II, p. 73940. (2) 20 Wall, p. 655. (3) Cooley's Constitutional Limita-
tions, Vol. II, p. 741.
exercises its powers. Principally it related to the proce- dure by which persons were tried for crimes
and guaranteed to accused persons the right to have a fair trial in compli- ance with well established
criminal proceedings. The same principle applied to the machinery or proceeding by which property
rights were adjudicated and by which the powers of eminent domain and taxation were exercised.
During this period it was not considered to have any bearing on substan- tial law at all.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Change, however, came in and the period that followed witnessed a growing recognition of the
doctrine that sub- stantive rights of life, liberty and property are protected by the requirement of
due process of law against any depri- vation attempted at by legislative authority; and the polit- ical
and economic conditions of the country accounted to a great extent for this change in judicial
outlook. The close of the civil war brought in a new period of industrial development leading to
accumulation of large capital in the hands of industrialists and the emergence of a definite labouring
class. New and important problems arose which the States attempted to deal with by various laws
and regu- lations. Some of them seem to have been ill-advised and arbitrary and there was a
clamour amongst businessmen against what they described as legislative encroachments upon their
vested private rights. The Supreme Court now began to use the rule of due process of law as a direct
restraint upon substantial legislation and any statute or administrative act, which imposed a
limitation upon rights of private property or free contractual relations between the employers and
employed, was invalidated as not being in accordance with due process of law (1). What constituted
a legitimate exercise of the powers of legislation now came to be a judicial question and no statute
was valid unless it was. reasonable in the opinion of the Court. The question of reasonableness
obviously depends largely upon the. ideas of particular individuals and the Courts or rather the
majority of Judges thus marshalled their own (1) Vide Encyclopaedia of the Social Sciences, Vol. V,
pp. 265-67.
views of social and economic policy in deciding the reasona- bleness or otherwise of the statutes. In
the language of a well-known writer, the Courts became a kind of negative third chamber both to the
State Legislatures and the Con- gress(1). To what extent the Courts laid stress upon the doctrine of
freedom of contract is illustrated in the case of Lochner v. New York(2). In that case the question
arose as to the validity of a labour legislation which prohibited the employment of persons in certain
fields of activity for more than 60 hours a week. Lochner was indicted for violat- ing this law by
employing a man in his Biscuit and Cake Factory who was to work more than 60 hours in a week.
The Court by a majority of 5 to 4 held the statute to be invalid on the ground that the "right to
purchase or sell labour is part of the liberty protected by the Amendment unless there are
circumstances which excluded the right." That decision has been criticized not merely on the ground
that it rested upon an economic theory which to quote the language of Holmes J., who was one of
the dissentient Judges "was not entertained by a large part of the country;" but it ignored that such
regulation was necessary for protecting the health of the employees, that is to say, it was in
substance an exercise of police powers with a view to accomplish some object of public interest(s).
It may be mentioned here that while the due process doctrine was being extended by judicial
pronouncements, the doctrine of police power which operates to some extent as a check upon the
"due process" clause was simultaneously gaining importance. Roughly speaking, police power may
be defined as "a right of a Government to regulate the conduct of its people in the interests of public
safety, health, morals and convenience. Under this authority, a Government may make regulations
concerning the safety of building, the regulation of traffic, the reporting of incurable diseases, the
inspection of markets, the sanitation of factories, the hours of work for women (1) Vide Kelley and
Harbinson on the American Constitution, p. 539.
198 u.s. 45.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Vide Willoughby on the Constitution of the U.S., Vol. III, p. 271.
and children, the sale of intoxicants and such other matters ,,(1). Here again, the extent to which the
Court can inter- fere with exercise of police powers by the State has not been clearly defined by
judicial pronouncements. The doc- trine generally accepted is that although any enactment by
legislature under the guise of exercise of police powers would not necessarily be constitutional, yet if
the regula- tion has a direct relation to its proposed object which is the accomplishment of some
legitimate public purpose, the wisdom or policy of the legislation should not be examined by the
Courts. The rule is not without its exceptions but it is not necessary to elaborate them for our
present pur- pose(2). The later decisions, though not quite uniform, reveal the growing influence of
the police power doctrine. It may be said that since 1936 there has been a definite swing of the
judicial pendulum in the other direction. In the case of West Coast Hotel Company v. Parrish(3)
which related to the legality of a Statute for regulating the minimum wages of women, Chief Justice
Hughes, who delivered the opinion of the Court, observed as follows:
"In each case the violation alleged by those attack- ing minimum wage regulation for
women is deprivation of freedom of contract. What is the freedom? The Constitution
does not speak of freedom of contract. It speaks of liberty and prohibits the
deprivation of liberty without due process of law. In prohibiting that deprivation the
Constitution does not recognise an absolute and uncontrol- lable liberty. Liberty in
each of its phases has its histo- ry and connotation. But the liberty safeguarded is
liberty in a social organisation which requires the protection of law. against the evils
which menace the health, safety, morals and welfare of the people."
In the succeeding years the indications certainly are that the requirement of due process of law as a
substantial restriction on Government control is becoming a thing of the past and the rule is being
restricted more (1) Vide Munroe--The Government of the U.S., p. 522. (2) Vide Willoughby on the
Constitution of the U.S. Vol. III, pp. 1709-70.
(3) 300 U.S. 379.
and more to its original procedural meaning. What will happen in future cannot certainly be
predicted at this stage(1).
Thus it will be seen that the "due process" clause in the American Constitution came to be used as a
potent in- strument in the hands of the judiciary for exercising con- trol over social legislation. The
judicial pronouncements are not guided by any uniform principle, and the economic and social ideas
of the Judges, who form the majority in the Supreme Court for the time being, constitute, so to say,
the yard-stick for measuring the reasonableness or otherwise of any enactment passed during that
period. No writer of American Constitutional Law has been able uptil now to evolve anything like a
definite and consistent set of prin- ciples out of the large mass of cases, where the doctrine of "due
process of law" has been invoked or applied.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

It is against this background that we must consider how the constitution-makers in India dealt with
and gave final shape to the provisions, on an analogous subject in the Indian Constitution. In the
Draft Constitution, article 15 (which now stands as article 21) was apparently framed on the basis of
the 5th and 14th Amendments in the American Constitution. The article was worded as follows:
"No person shall be deprived of his life or liberty without due process of law."
The Drafting Committee in their report recommended a change in the language of this article. The
first sugges- tion was that the word "personal" shall be inserted before the word "liberty" and the
second was that the expression "in accordance with procedure established by law" shall be
substituted for "due process of law," the reason given being that the former expression was more
specific.
The learned Attorney-General has placed before us the debates in the Constituent Assembly
centering round the adoption of this recommendation of the Drafting Committee and he has
referred us to the (1) Swisher--The Growth of Constitutional Power in the United States, pp. 123-25.
speeches of several members of the Assembly who played an important part in the shaping of the
Constitution. As an aid to discover the meaning of the words in a Consti- tution, these debates are of
doubtful value. ''Resort can be had to them"' says Willoughby, ''with great caution and only when
latent ambiguities are to be solved. The proceed- ings may be of some value when they clearly point
out the purpose of the provision. But when the question is of ab- stract meaning, it will be difficult to
derive from this source much material assistance in interpretation"(1). The learned
Attorney-General concedes that these debates are not admissible to explain the meaning of the
words used and he wanted to use them only for the purpose of showing that the Constituent
Assembly when they finally adopted the recommendation of the Drafting Committee, were fully
aware of the implications of the differences between the old form of expression and the new. In my
opinion, in interpreting the Constitution, it will be better if such extrinsic evi- dence is left out of
account. In matters like this, differ- ent members act upon different impulses and from different
motives and it is quite possible that some members accepted certain words in a particular sense,
while others took them in a different light.
The report of the Drafting Committee, however,has been relied upon by both parties and there are
decided authori- ties in which a higher value has been attached to such reports than the debates on
the floor of the House. In Caminetti v. United States (2), it is said that reports to Congress
accompanying the introduction of proposed law may aid the Courts in reaching the true meaning of
the legisla- tion in case of doubtful interpretation. The report is extremely short. It simply says that
the reason for the suggested change is to make the thing more specific. I have no doubt in my mind
that if the "due process"
clause which appeared in the original draft was finally retained by the Constituent
Assembly, it could be safely presumed that the framers of the Indian (1) Vide
Willoughby on the Constitution of the United States, p. 64.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

(2) 242 U.S. 470.
Constitution wanted that expression to bear the same sense as it does in America. But when that
form was abandoned and another was deliberately substituted in its place, it is not possible to say
that in spite of the difference in the language and expression, they should mean the same thing and
convey the same idea. Mr. Nambiar's contention is that in view of the somewhat uncertain and
fluidic state of law as prevails in America on the subject, the Drafting Committee recommended an
alteration for the purpose of making the language more specific and he would have us hold that it
was made specific in this way, namely, that instead of being extended over the whole sphere of law,
substantive as well as adjective, it was limited to procedural law mere- ly. That is the reason, he says,
why instead of the word "process" the expression "procedure" was adopted, but the word "law"
means the same thing as it does in the "due process" clause in America and refers not to any
State-made law but to the fundamental principles which are inherent in the legal system and are
based upon the immutable doctrines of natural justice.
Attractive though this argument might at first sight appear, I do not think that it would be possible
to accept it as sound. In the first place, it is quite clear that the framers of the Indian Constitution
did not desire to intro- duce into our system the elements of uncertainty, vagueness and
changeability that have grown round the "due process"
doctrine in America. They wanted to make the provision clear, definite and precise
and deliberately chose the words" procedure established by law," as in their opinion
no doubts would ordinarily arise about the meaning of this expression. The
indefiniteness in the application of the "due process" doctrine in America has nothing
to do with the distinction between substantive and procedural law. The uncertainty
and elasticity are in the doctrine itself which is a sort of hidden mine, the contents of
which nobody knows and is merely revealed from time to time to the. judicial
conscience of the Judges. This theory, the Indian Constitu- tion deliberately
discarded and that is why they substituted a different form in its place which,
according to them, was more specific. In the second place, it appears to me that when
the same words are not used, it will be against the ordinary canons of con- struction
to interpret a provision in our Constitution in accordance with the interpretation put
upon a somewhat analogous provision in the Constitution of another country, where
not only the language is different, but the entire political conditions and
constitutional set-up are dissimi- lar. In the Supreme Court of America, stress has
been laid uniformly upon the word "due" which occurs before and quali- fies the
expression "process of law." "Due" means "
what is just and proper" according to the circumstances of a particular case. It is this word which
introduces the varia- ble element in the application of the doctrine; for what is reasonable in one set
of circumstances may not be so in another and a different set. In the Indian Constitution the word
"due" has been deliberately omitted and this shows clearly that the Constitution-makers of India
had no inten- tion of introducing the American doctrine. The word "estab- lished" ordinarily means
"fixed or laid down" and if "law" means, as Mr. Nambiar contends, not any particular piece of lawA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

but the indefinite and indefinable principles of natural justice which underlie positive systems of
law, it would not at all be appropriate to use the expression "established,"
for natural law or natural justice cannot establish anything like a definite procedure.
It does not appear that in any part of the Constitution the word "law" has been used
in the sense of "general law"
connoting what has been described as the principles of natural justice outside the realm of positive
law. On the other hand, the provision of' article 31 of the Constitu- tion, which appears in the.
chapter on Fundamental Rights, makes it clear that the word "law" is equivalent to State- made law
and to deprive a person of his property, the au- thority or sanction of such law is necessary. As has
been said already, the provision of article 21 of. the Indian Constitution reproduces, save in one
particular, the-
language of article 31 of the Japanese Constitution and it is quite clear from the scheme and
provisions of the Japa- nese Constitution that in speaking of law it refers to law passed or recognised
as such by the State. In the Irish Constitution also, there is provision in almost similar language
which conveys the same idea. Article 40 (4) (1) provides that "no citizen shall be deprived of his
personal liberty save in accordance with law," and by law is certain- ly meant the law of the State.
Possibly the strongest argument in support of Mr. Nambi- ar's contention is that if law is taken to
mean State-made law, then article 21 would not be a restriction on legisla- tion at all. No question of
passing any law abridging the right conferred by this article could possibly arise and article 13 (2) of
the Constitution would have no operation so far as this provision is concerned. To quote the words
of an American Judge it would sound very much like the Constitution speaking to the legislature
that the latter could not infringe the right created by these articles unless it chose to do so (1).
Apparently this is a plausible argument but it must be admitted that we are not concerned with the
policy of the Constitution. The fundamental rights not merely impose limitations upon the
legislature, but they serve as checks on the exercise of executive powers as well, and in the matter of
depriving a man of his personal liberty, checks on the high-handedness of the executive in the shape
of pre- venting them from taking any step, which is not in accord- ance with law, could certainly
rank as fundamental rights. In the Constitutions of various other countries, the provi- sions relating
to protection of personal liberty are couched very much in the same language as in article 21. It is all
a question of policy as to whether the legislature or the judiciary would have the final say in such
matters and the Constitution-makers of India deliberately decided to place these powers in the
hands of the legislature. Article 31 of the Japanese Constitution, upon which article 21 of our
Constitution is modelled, also (1) Vide per Bronson 5. in Taylor v. Porte 4 Hill 1<0.
proceeds upon the same principle. The Japanese Constitu- tion, it is to be noted, guarantees at the
same. time other rights in regard to arrest, detention and access to Court which might serve as
checks on legislative authority as well. Thus article 32 provides:A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"No person shall be denied the right of access to the Courts."
Article 34 lays down:
"No person shall be arrested or detained without being at once informed of the
charges against him or without the immediate privilege of counsel, nor shall he be
detained without adequate cause; and upon demand of any person, such cause must
be immediately shown in open Court in his presence and in the. presence of his
counsel."
It was probably on the analogy of article 34 of the Japanese Constitution that the first two clauses of
article 22 of the Indian Constitution were framed. Article 22 was not in the original Draft
Constitution at all; and after the "due process" clause was discarded by the Constituent Assem- bly
and the present form was substituted in its place in article 21, article 22 was introduced with a view
to provide for some sort of' check in matters of arrest and detention and the protection it affords
places limitations upon the authority of the legislature as well. These protections indeed have been
denied to cases of preventive detention but that again is a question of policy which does not concern
us as a Court. My conclusion, therefore, is that in article 21 the word "law" has been used in the
sense of State-made law and not as an equivalent of law in the abstract or general sense embodying
the principles of natural justice. The article presupposes that the law is a valid and binding law
under the provisions. of the Constitution having regard to the competency of the legislature and the
subject it relates to and does not infringe any of the fundamental rights which the Constitution
provides for.
In the view that I have taken, the question raised by Mr. Nambiar that the Preventive Detention Act
is invalid, by reason of the fact that the procedure it lays down is not in conformity with the rules of
natural justice, does not fall for consideration. It is enough, in my opin- ion, if the law is a valid law
which the legislature is competent to pass and which does not transgress any of the fundamental
rights declared in Part III of the Constitution. It is also unnecessary to enter into a discussion on the
question raised by the learned Attorney-General as to wheth- er article 22 by itself is a
self-contained Code with regard to the law of Preventive Detention and whether or not the
procedure it lays down is exhaustive. Even if the procedure is not exhaustive, it is not permissible to
supplement it by application of the rules of natural justice. On the third point raised by Mr.
Nambiar, the only question, therefore, which requires consideration is whether section 12 of the
Preventive Detention Act is ultra vires of the Constitution by reason of its being not in conformity
with the provision of article 22 (7)(a). Article 22 (7) (a) of the Constitution empowers the Parliament
to prescribe the circumstances under which, and the class or classes of cases in which, a person may
be detained for a period longer than three months under any law providing for preventive detention
without obtaining the opinion of an advisory board in accordance with the provisions of sub-clause
(a) of clause (4). Section 12 of the Preventive Detention Act which purports to be an enact- ment in
pursuance of article 22 (7) (a) of the Constitution provides as follows:
"(1) Any person detained in any of the following classes of cases or under any of the
following circumstances may be detained without obtaining the opinion of anA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

advisory board for a period longer than three months, but not exceeding one year
from the date of his detention, namely, where such person has been detained with a
view to preventing him from acting in any manner prejudicial to
(a) the defence of India, relations of India with for- eign powers or the security of
India; or
(b) the security of a State or the maintenance of public order."
It will be noticed that there are altogether six heads or subjects in the two Items in the legislative
lists, namely, Item No. 9 of List I and Item No. 3 of List III which deal with preventive detention.
Item No. 9 of List I mentions reasons connected with defence, foreign affairs and security of India,
while Item No. 3 of List III speaks of reasons connected with security of a State, the maintenance of
public order and the maintenance of supplies and services essential to the community. With the
exception of the last head; all the remaining five have been listed in section 12 of the preventive
Detention Act and they have been mentioned both as circumstances and classes of cases in which
deten- tion for more than three months would be permissible without the opinion of any advisory
board. Mr. Nambiar's argument is that the mentioning_ of five out of the six legislative heads in
section 12 does not amount to prescribing the circumstances under which, or the classes of cases in
which, a person could be detained for more than three months as contemplated by article 22 (7) (a).
It is also contended that in view of the fact that the two items "circumstances" and "classes" are
separated by the conjunction "and," what the Constitution really contemplated was that both these
items should be specified and a statement or specification of any one of them would not be a proper
compliance with the provisions of the clause. It is further pointed out that the mentioning of the
same matters as "circumstances" or "classes" is not warranted by article 22 (7) of the Consti- tution
and is altogether illogical and unsound.
I must say that section 12 has been drafted in a rather clumsy manner and certainly it could have
been framed in a better and more proper way. Under article 22(7)(a), the Parliament may specify the
circumstances under which, and the classes of cases in which, the necessity of placing the cases of
detention for examination by the advisory board could be dispensed with. By "classes of cases" we
mean certain determinable groups, the individuals comprised in each group being related to one
another in a particular way which constitutes the determining factor of that group.
"Circumstances" on the other hand connote situations or conditions which are
external to the persons concerned. Preventive detention can be provided for by law
for reasons connected with six different ,matters specified in the relevant items in the
legislative lists, and whatever the reasons might be, there is a provision contained in
article 22 (4) (a) which lays down that deten- tion for more than three months could
not be permitted except with the sanction of the advisory board. An alterna- tive
however has been provided for by clause (b) and Parlia- ment has been given the
option to take away the protection given by clause (a) and specify the circumstances
and the cases when this rule will not apply. I am extremely doubt- ful whether the
classification of cases made by Parliament in section 12 of the Act really fulfils theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

object which the Constitution had in view. The basis of classification has been the
apprehended acts of the persons detained described with reference to the general
heads mentioned in the items in the legislative lists as said above. Five out of the six
heads have been taken out and labelled as classes of cases to which the protection of
clause (4) (a) of the article would not be available. It is against common sense that all
forms of activities connected with these five items are equally dangerous and merit
the same drastic treatment. The descriptions are very general and there may be acts
of various degrees of intensity and danger under each one of these heads.
Although I do not think that section 12 has been framed with due regard to the object
which the Constitution had in view, I am unable to say that the section is invalid as
being ultra vires the Constitution. The Constitution has given unfettered powers to
Parliament in the matter of making the classifications and it is open to the Parliament
to adopt any method or principle as it likes. If it chose the principle implied in the
enumeration of subjects under the relevant legislative heads, it cannot be said that
Parliament has exceeded its powers.
I am also unable to hold that both "circumstances" as well as "classes" have to be
prescribed in order to comply with the requirement of sub-clause (a) of article 22 (7).
The sub-clause (a) of the article lays down a purely enabling provision and
Parliament, if it so chooses, may pass any legislation in terms of the same. Where an
optional power is conferred on certain authority to perform two separate acts,
ordinarily it would not be obligatory upon it to perform both; it may do either if it so
likes. Here the classes have been specified and the classes apparently are composed
of persons who are detained for the purpose of preventing them from committing
certain apprehended acts. I am extremely doubtful whether the classes themselves
could be described as "circumstances" as they purport to have been done in the
section. "Circumstances" would ordinarily refer to conditions like war, rebellion,
communal disturbances and things like that, under which extra precaution might be
:necessary and the detention of suspected persons beyond the period of three months
without the sanction of the advisory board might be justified. It is said that the
likelihood of these persons committing the particular acts which are specified might
constitute "circumstances." In my opinion, that is not a plain and sensible
interpretation. But whatev-
er that may be, as I am of opinion that it is not obligatory on Parliament to prescribe both the
circumstances and the classes of cases, I am unable to hold that section 12 is ultra vires the
Constitution because the circumstances are not mentioned. As I have said at the beginning, the draft
is rather clumsy and I do not know why Parliament used the word "or" when in the Constitution
itself the word "and" has been used.
In the fourth and last point raised by Mr. Nambiar the principal question for consideration is the
validity of section 14 of the Preventive Detention Act. Subsection (1)of section 14 prohibits any Court
from allowing any statement to be made or any evidence to be given before it of the substance of anyA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

communication made under section 7 of the grounds on which a detention order has been made
against any person or any representation made by him against such order. It further provides that
no Court shall be entitled to require any public officer to produce before it or to disclose the
substance of any such communication or representation made or the proceedings of an advisory
board or that part of the report of an advisory board which is confidential. Sub-section (2) further
provides that:
"It shall be an offence punishable with imprisonment for a term which may extend to
one year, or with fine, or with both, for any person to disclose or publish without the
previous authorisation of the Central Government or the State Government, as the'
case may be, any contents or matter purporting to be contents of any such
communication or representation as is referred to in sub-section (1):
Provided that nothing in this sub-section shall apply to a disclosure made to his legal
adviser by a person who is the subject of a detention order."
The provisions of this section are obviously of a most drastic character. It imposes a ban on the
Court and pre- vents it from allowing any statement to be made or any evidence produced before it
of the substance of any communi- cation made to the detenu apprising him of the grounds upon
which the detention order was made. The Court is also incompetent to look into the proceedings
before the advisory board or the report of the latter which is confidential. Further the disclosure of
such materials has been made a criminal offence punishable with imprisonment for a term which
may extend to one year. Mr. Nambiar's contention is that these restrictions render utterly nugatory
the provi- sions of article 32 of the Constitution which guarantees to every person the right to move
this Court by appropriate proceedings for the enforcement of the rights conferred by Part III of the
Constitution. It is not disputed that the petitioner has the right of moving this Court for a writ of
habeas corpus, and unless the Court is in a position to look into and examine the grounds upon
which the detention order has been made, it is impossible for it to come to any deci- sion on the
point and pass a proper judgment. Though the right to move this Court is not formally taken away,
the entire proceedings are rendered ineffective and altogether illusory. On behalf of the respondent,
it is pointed out that article 32 guarantees only the right to constitutional remedy for enforcement of
the rights which are declared by the Constitution. If there are no rights under the Constitution,
guaranteed to a person who is detained under any law of preventive deten- tion, no question of
enforcing such rights by an ap- proach to this Court at all arises. I do not think that this argument
proceeds on a sound basis; and in my opinion, section 14 does take away and materially curtails
some of the fundamental rights which are guaranteed by the Constitu- tion itself. Article 22, clause
(5), of the Constitution lays down as a fundamental right that when a person is detained for
preventive detention, the authority making the order shall, as soon as may be, communicate to such
person the grounds on which the order has been made, and shall afford him the earliest opportunity
of making a representa- tion against the order. Under clause (6), the authority need not disclose
such facts as it considers to be against public interest to disclose. But so far as the grounds are
concerned, the disclosure is not prohibited under any cir- cumstance. It is also incumbent upon the
detaining authori- ty to afford a detenu the earliest opportunity of making a representation against
the detention order. It has been held in several cases, and in my opinion quite rightly, that if theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

grounds supplied to a detained person are of such a vague and indefinite character that no proper
and adequate representation could be made in reply to the same, that itself would be an infraction of
the right which has been given to the detenu under law. In my opinion, it would not be possible for
the Court to decide whether the provisions of article 22, clause (5), have been duly complied with
and the fundamental right guaranteed by it has been made avail- able to the detenu unless the
grounds communicated to him under the provisions of this article are actually produced before the
Court. Apart from this, it is also open to. the person detained to contend that the detention order has
been a main fide exercise of power by the detain- ing authority and that the grounds upon which it is
based, are not proper or relevant grounds which would justify detention under the-provisions of the
law itself. These rights of the detenu would for all practical purposes be rendered unenforceable if
the Court is precluded from look- ing into the grounds which have been supplied to him under
section 7 of the Preventive Detention Act. In my opinion, section 14 of the Preventive Detention Act
does materially affect the fundamental rights declared under Part III of the Constitution and for this
reason it must be held to be illegal and ultra vires. It is not disputed, however, that this section can
be severed from the rest of the Act without affecting the other provisions of the Act in any way. The
whole Act cannot, therefore, be held to be ultra vires. Mr. Nambiar has further argued that section 3
of the Act also contravenes the provisions of article 32 of the Consti- tution, for it makes satisfaction
of the particular authori- ties final in matters of preventive detention and thereby prevents this
Court from satisfying itself as to the propriety of the detention order. This contention cannot
succeed as no infraction of any fundamental right is in- volved in it. As has been pointed out already,
this Court cannot interfere unless it is proved that the power has been exercised by the authorities in
a mala fide manner or that the grounds are not proper or relevant grounds which justify detention.
The provisions are undoubtedly harsh, but as they do not take away the rights under articles 21 and
22 of the Constitution, they cannot be held to be illegal or ultra vires.
The result, therefore, is that, in my opinion, the Preventive Detention Act must be declared to be
intra vires the Constitution with the exception of section 14 which is held to be illegal and ultra vires.
The present petition, however, must stand dismissed, though it may be open to the petitioner to
make a fresh application if he so chooses and if the grounds that have been supplied to him under
section 7 of the Act do furnish adequate reasons for making such application.
DAS J.--I am likewise of opinion that this application should be dismissed.
The contention of learned counsel appearing in support of this application is that the provisions of
the Preventive Detention Act, 1950 (Act IV of 1950), are extremely drastic and wholly unreasonable
and take away or, in any event, considerably abridge the fundamental rights conferred on the
citizens by the provisions of Part III of the Constitution and that this Court should declare the Act
wholly void under article 13 (2) of the Constitution and set the petitioner at liberty.
It is necessary to bear in mind the scope and ambit of the powers of the Court under the
Constitution. The powers of the Court are not the same under all Constitutions. In England
Parliament is supreme and there is no limitation upon its legislative powers. Therefore, a law duly
made by Parliament cannot be challenged in any Court. The English Courts have to interpret and
apply the law; they have no authority to declare such a law illegal or unconstitutional. By theA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

American Constitution the' legislative power of the Union is vested in the Congress and in a sense
the Congress is the supreme legislative power. But the written Constitu- tion of the United States is
supreme above all the three limbs of Government and, therefore, the law made by the Congress, in
order to be valid, must be in conformity with the provisions of the Constitution. If it is not, the
Supreme Court will intervene and declare that law to be unconstitutional and void. As will be seen
more fully hereafter, the Supreme Court of the United States, under the leadership of Chief Justice
Marshall, assumed the power to. declare any law unconstitutional on the ground of its not being in
"due process of law," an expression to be found in the Fifth Amendment (1791) of the United States
Constitution and the Fourteenth Amendment (1868) which related to the State Constitutions. It is
thus that the Supreme Court established its own supremacy over the executive and the Congress. In
India the position of the Judiciary is some- where in between the Courts in England and the United
States. While in the main leaving our Parliament and the State Legisla- tures supreme in their
respective legislative fields, our Constitution has, by some of the articles, put upon the Legislatures
certain specified limitations some of which will have to be discussed hereafter. The point to be
noted, however, is that in so far as there is any limitation on the legislative power, the Court must,
on a complaint being made to it, scrutinise and ascertain whether such limitation has been
transgressed and if there has been any transgression the Court will courageously declare the law
unconstitution- al, for the Court is bound by its oath to uphold the Consti- tution. But outside the
limitations imposed on the legisla- tive powers our Parliament and the State Legislatures are
supreme in their respective legislative fields and the Court has no authority to question the wisdom
or policy of the law duly made by the appropriate legislature. Our Constitution, unlike the English
Constitution, recognises the Court's supremacy over the legislative authority, but such supremacy is
a very limited one, for it is confined to the field where the legislative power is circumscribed by
limitations put upon it by the Constitution itself. Within this restrict- ed field the Court may, on a
scrutiny of the law made by the Legislature, declare it void if it is found to have trans- gressed the
constitutional limitations. But our Constitu- tion, unlike the American Constitution, does not
recognise the absolute supremacy of the Court over the legislative authority in all respects, for
outside the restricted field of constitutional limitations our Parliament and the State Legislatures
are supreme in their respective legislative fields and in that wider field there is no scope for the
Court in India to play the role of the Supreme Court of the United States. It is well for us to
constantly remember this basic limitation on our own powers.
The impugned Act has been passed by Parliament after the Constitution came into force. Article 246
gives exclusive power to Parliament to make laws with respect to any of the matters enumerated in
List I in the Seventh Schedule and it gives exclusive power to the State Legislatures to make laws
with respect to any of the matters specified in List II of that Schedule. It also gives concurrent power
to Parliament as well as to the State Legislatures to make laws with respect to any of the matters
enumerated in List III in the Seventh Schedule. Residuary powers of legislation are vested in
parliament under article
248. The first thing to note is that under Entry 9 of List I the parliament and under Entry 3 in List
III both parliament and the State Legislatures are empowered to make laws for preventive detention
for reasons connected with the several matters specified in the respective entries. This legisla- tion is
not conditioned upon the existence of any war with a foreign power or upon the proclamation ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

emergency under Part XVIII of the Constitution. Our Constitution has, there- fore, accepted
preventive detention as the subjectmatter of peacetime legislation as distinct from emergency
legisla- tion. It is a novel feature to provide for preventive detention in the Constitution. There is no
such provision in the Constitution of any other country that I know of. Be that as it may, for reasons
good or bad, our Constitution has deliberately and plainly given power to Parliament and the State
Legislatures to enact preventive detention laws even in peacetime. To many of us a preventive
detention law is odious at all times but what I desire to emphasise is that it is not for the Court to
question the wisdom and policy of the Constitution which the people have given unto themselves.
This is another basic fact which the Court must not overlook.
The next thing to bear in mind is that, if there were nothing else in the Constitution, the legislative
powers of Parliament and the State Legislatures in their respective fields would have been absolute.
In such circumstances the Court would have been entitled only to scrutinise whether Parliament or
the State Legislature had, in making a partic- ular law, over-. stepped its legislative field and en-
croached upon the legislative field of the other legislative power, but could not have otherwise
questioned the validity of any law made by the parliament or the State Legislatures.
Thus under Entry 9 of List I the Parliament and under Entry 3 of List III the Parliament and the
State Legislature could make as drastic a preventive detention law as it pleased. Such a law might
have authorised a policeman, not to speak of a District Magistrate or Sub-Divisional Magistrate or
the Commissioner of Police, to take a man, citizen or non-citi- zen, into custody and keep him in
detention for as long as he pleased. This law might not have made any provision for supplying to the
detenu the grounds of his detention or affording any opportunity to him to make any representation
to anybody or for setting up any advisory board at all. Likewise, under Entries 1 and 2 in List III the
Parliament or the State Legislature might have added as many new and novel offences as its fancy
might have dictated and provided for any cruel penalty ranging from the maiming of the limbs to
boiling to death in oil or repealed the whole of the Code of Criminal Procedure and provided for trial
by battle or ordeal or for conviction by the verdict of a sorcerer or a soothsayer. Such law might have
forbidden any speech criti- cising the Government, however mildly, or banned all public meetings or
prohibited formation of all associations under penalty of law. Under Entry 33 of List I the
Parliament might have made a law for acquiring anybody's properties for the purposes of the Union
without any compensation and under Entry 36 in List III the State Legislature could do the same
subject to the provisions of Entry 42 in List III which empowers the making of a law laying down
principles for payment of compensation which might be anything above noth- ing. Under Entry 81
Parliament could have made any law restricting or even prohibiting inter-State migration so that a
Bengali would not be able to move into and settle in Bihar or vice versa. It is needless to multiply
instances of atrocious laws which Parliament or the State Legislature might have made under article
246 read with the different lists if there were nothing else in the Constitution. Our Legislatures,
subject to the limitation of distribution of legislative powers, would have been as supreme in their
respective legislative fields as the English Parliament is and has been. The Court in India, in such
event, would have had to take the law duly made, inter- pret it and apply it. It would not have been
entitled to utter a word as to the propriety of the particular law, although it might have shuddered at
the monstrous atrocities of such law.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Our Constitution, however, has not accepted this abso- lute supremacy of our Parliament or the
State Legislature. Thus by article 245 (1) the legislative power is definitely made "subject to the
provisions of this Constitution." Turning to the Constitution, article 13 (2) provides as follows:
"The State shall not make any law which takes away or abridges the rights conferred
by this Part and any law made in contravention of this clause shall, to the extent of
the contravention, be void."
This clearly puts a definite limitation on the wide legislative powers given by article 246. It is
certainly within the competency of the Court to judge and declare whether there has been any
contravention of this limitation. In this respect again the Court has supremacy over the Legislature.
From the provisions so far referred to, it clearly follows that there are two principal limitations to
the legislative power of parliament, namely,--
(i) that the law must be within the legislative compe- tence of parliament as prescribed by article
246; and
(ii) that such law must be subject to the pro-visions of the Constitution and must not take away or
abridge the rights conferred by Part III.
There can be no question--and, indeed, the learned Attorney-General does not contend
otherwise--that both these matters are justiciable and it is open to the Courts to decide whether
Parliament has transgressed either of the limitations upon its legislative power.
Learned counsel for the petitioner does not say that the impugned Act is ultra vires the legislative
powers of Parliament as prescribed by article 246. His contention is that the impugned Act is void
because it takes away or abridges the fundamental rights of citizens conferred by Part III of the
Constitution. It is, therefore, necessary to ascertain first the exact nature, extent and scope of the
particular fundamental right insist- ed upon and then to see whether the impugned Act has taken
away or, in any way, abridged the fundamental right so ascertained.
Civil rights of a person are generally divided into two classes, namely, the rights attached to the
person (jus personarum) and the rights to things, i.e., property (jus rerum). Of the rights attached to
the person, the first and foremost is the freedom of life, which means the right to live, i.e., the right
that one's life shall not be taken away except under authority of law. Next to the freedom of life
comes the freedom of the person, which means that one's body shall not be touched, violated,
arrested or imprisoned and one's limbs shall not be injured or maimed except under authority of
law. The truth of the matter is that the right to live and the freedom of the person are the primary
rights attached to the person. If a man's person is free, it is then and then only that he can exercise a
variety of other auxiliary rights, that is to say, he can, within certain limits, speak what he likes,
assemble where he likes, form any associations or unions, move about freely as his "own inclination
may direct," reside and settle anywhere he likes and practise any profession or carry on any
occupation, trade or business. These are attributes of the freedom of the person and areA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

consequently rights attached to the person. It should be clearly borne in mind that these are not all
the rights attached to the person. Besides them there are varieties of other rights which are also the
attributes of the freedom of the person. All rights attached to the person are usually called personal
liberties and they are too numerous to be enumerated. Some of these auxiliary rights are so
important and fundamental that they are re- garded and valued as separate and independent rights
apart from the freedom of the person.
Personal liberties may be compendiously summed up as the right to do as one pleases within the
law. I say within the law because liberty is not unbridled licence. It is what Edmund Burke called
"regulated freedom." Said Montesquieu in Book III, Ch. 3, of his Spirit of the Laws:
"In Governments, that is, in societies directed by laws, liberty can consist only in the
power of doing what we ought to will, and in not being constrained to do what we
ought not to will. We must have continually present to our minds the difference
between independence and liberty. Liberty is a right of doing whatever the laws
permit, and if a citizen could do what they forbid, he would no longer be possessed of
liberty, because all his fellow-citizens would enjoy the same power."
To the same effect are the following observations of Webster in his Works Vol. II, p. 393:
"Liberty is the creation of law, essentially different from that authorised
licentiousness that trespasses on right. It is a legal and refined idea, the offspring of
high civilization, which the savage never understands, and never can understand.
Liberty exists in proportion to wholesome restraint; the more restraint on others to
keep off from us, the more liberty we have. It is an error to suppose that liberty
consists in a paucity of laws ......... The working of our complex system, full of checks
and restraints on legislative, executive and judicial power is favourable to liberty and
justice. These checks and restraints are so many safeguards set around individual
rights and interests. That man is free who is protected from injury."
Therefore, putting restraint on the freedom of wrong doing of one person is really. securing the
liberty of the intended victims. To curb the freedom of the saboteur of surreptitiously removing the
fish plates from the railway lines is to ensure the safety and liberty of movement of the numerous
innocent and unsuspecting passengers. Therefore, restraints on liberty should be judged not only
subjectively as applied to a few individuals who come within their opera- tions but also objectively as
securing the liberty of a far greater number of individuals. Social interest in individu- al liberty may
well have to be subordinated to other greater social interests. If a law ensures and protects the
greater social interests then such law will be a wholesome and beneficent law although it may
infringe the liberty of some individuals, for it will enure for the greater liberty of the rest of the
members of the society. At the same time, our liberty has also to be guarded against executive,
legislative as well as judicial usurpation of powers and prerogatives. Subject to certain restraints on
individuals and reasonable checks on the State every person has a varie- ty of personal liberties too
numerous to be cataloged. As will be seen more fully hereafter, our Constitution has recognised
personal liberties as fundamental rights. It has guaranteed some of them under article 19 (1) but putA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

re- straints on them by clauses (2) to (6). It has put checks on the State's legislative powers by
articles 21 and 22. It has by providing for preventive detention, recognised that individual liberty
may be subordinated to the larger social interests.
Turning now to the Constitution I find that Part III is headed and deals with "Fundamental Rights"
under seven heads, besides, "General" provisions (articles 12 and 13), namely "Right to Equality"
(articles 14 to 18), "Right to Freedom" (articles 19 to 22), "Right against Exploitation"
(articles 23 and 24), "Right to Freedom of Religion"
(articles 25 to 28), "Cultural and Educational Rights"
(articles 29 and 30), "Right to Property" (article 31), "Right to Constitutional
Remedies" (articles 32 to 35). Under the heading "Right to Freedom" are grouped
four arti- cles, 19 to 22. Article 19 (1) is in the following terms :--
" (1) All citizens shall have the right-
(a) to freedom of speech and expression;
(b) to assemble peaceably and without arms; (c) to form associations or unions;
(d) to move freely throughout the territory of India;
(e) to reside and settle in any part of the territory of India;
(f) to acquire, hold and dispose of property; and
(g) to practise any profession, or to carry on any occupation, trade or business."
It will be noticed that of the seven rights protected by clause (1) of article 19, six of them, namely,
(a), (b),
(c), (d), (e) and (g) are what are said to be rights at- tached to the person (jus personarum). The
remaining item, namely, (f) is the right to property (jus rerum). If there were nothing else in article
19 these rights would have been absolute rights and the protection given to them would have
completely debarred parliament or any of the State Legisla- tures from making any law taking away
or abridging any of those rights. But a perusal of article 19 makes it abun- dantly clear that none of
the seven rights enumerated in clause (1) is an absolute right, for each of these rights is liable to be
curtailed by laws made or to be made by the State to the extent mentioned in the several clauses (2)
to (6) of that article. Those clauses save the power of the State to make laws imposing certain
specified restrictions on the several rights. The nett result is that the unlimit- ed legislative power
given by article 246 read with the different legislative lists in the Seventh Schedule is cut down by
the provisions of article 19 and all laws made by the State with respect to these rights must, in orderA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

to be valid, observe these limitations. Whether any law has in fact transgressed these limitations is
to be ascertained by the Court and if in its view the restrictions imposed by the law are greater than
what is permitted by clauses (2) to (6) whichever is applicable the Court will declare the same to be
unconstitutional and, therefore, void under article 13. Here again there is scope for the application
of the "intel- lectual yardstick" of the Court. If, however, the Court finds, on scrutiny, that the law
has not overstepped the constitutional limitations, the Court will have to uphold the law, whether it
likes the law or not.
The first part of the argument is put broadly, namely, that personal liberty is generally guaranteed
by the Consti- tution by article 19 (1) and that the Preventive Detention Act, 1950, has imposed
unreasonable restrictions thereon in violation of the provisions of clauses (2) to (6) of that article.
The very first question that arises, therefore, is as to whether the freedom of the person which is
primarily and directly suspended or de- stroyed by preventive detention is at all governed by arti- cle
19 (1). If personal liberty as such is guaranteed by any of the sub-clauses of article 19 (1) then why
has it also been protected by article 21 ? The answer suggested by learned counsel for the petitioner
is that personal liberty as a substantive right is protected by article 19 (1) and article 21 gives only an
additional protection by prescrib- ing the procedure according to which that right may be taken
away. I am unable to accept this contention. If this argument were correct, then it would follow that
our Consti- tution does not guarantee to any person, citizen or non- citizen, the freedom of his life as
a substantive right at all, for the substantive right to life does not fall within any of the sub-clauses of
clause (1) of article 19. It is retorted in reply that no constitution or human laws can guarantee life
which is the gift of God who alone can guar- antee and protect it. On a parity of reasoning no
Constitu- tion or human laws can in that sense guarantee freedom of speech or free movement, for
one may be struck dumb by disease or may lose the use of his legs by paralysis or as a result of
amputation. Further, what has been called the procedural protection of article 21 would be an act of
supererogation, for when God takes away one's life, whatever opportunity He may have had given to
Adam to explain his conduct before sending him down, He is not likely in these degenerate-days to
observe the requirements of notice or fair trial before any human tribunal said to be required by
article 21. The fifth Amendment and the Fourteenth Amendment of the American Constitution give
specific protection to life as a substantive right. So does article 31 of the Japanese Constitution of
1946. There is no reason why our Constitution should not do the same. The truth is that article 21
has given that protection to life as a substan- tive right and that, as will be seen hereafter, that article
properly understood does not purport to prescribe any par- ticular procedure at all. The further
astounding result of the argument of counsel for the petitioner will be that the citizen of India will
have only the rights enumerated in article 19, clause (1) and no other right attached to his person. As
I have already stated, besides the several rights mentioned in the several sub- clauses of article 19 (1)
there are many other personal liberties which a free man, i.e., a man who has the freedom of his
person, may exercise. Some of those other rights have been referred to by Harries C.J. of Calcutta in
his unreported judgment in Miscellaneous Case No. 166 of 1950 (K.shitindra v. The Chief Secretary
of West Bengal) while referring the case to a Full Bench in the following words :--
"It must be remembered that a free man has far more and wider rights than those
stated in article 19 (1) of the Constitution. For example, a free man can eat what he
likes subject to rationing laws, work as much as he likes or idle as much as he likes.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

He can drink anything he likes subject to the licensing laws and smoke and do a
hundred and one things which are not included in article 19. If freedom of person was
the result of article 19, then a free man would only have the seven rights mentioned in
that article. But obviously the free man in India has far greater rights."
I find myself in complete agreement with the learned Chief Justice on this point. If it were
otherwise, the citizen's right to eat what he likes will be liable to be taken away by the executive fiat
of the Civil Supply Depart- ment without the necessity of any rationing laws. The Government may
enforce prohibition without any prohibition laws or licensing laws and so on. I cannot accept that
our Constitution intended to give no protection to the bundle of rights which, together with the
rights mentioned in sub- clauses (a) to (e) and (g) make up personal liberty. In- deed, I regard it as a
merit of our Constitution that it does not attempt to enumerate exhaustively all the personal rights
but uses the compendious expression "personal liber- ty" in' article 21, and protects all of them.
It is pointed out that in the original draft the word "liberty" only was used as in the American
Constitution but the Drafting Committee added the word "personal" to make it clear that what was
being protected by what is now article 21 was not what had already been pro- tected by what is now
article 19. If it were permissible to refer to the Drafting Committee's report, it would be anoth- er
answer to the contentions of learned counsel for the petitioner that personal liberty as a substantive
right was protected by article 19. I do not, however, desire to base my judgment on the Drafting
Committee's report and I express no opinion as to its admissibility. Whatever the intentions of the
Drafting Committee might have been, the Constitution as finally passed has in article 21 used the
words "personal liberty" which have a definite connotation in law as I have explained. It does not
mean only liberty of the person but it means liberty or the rights attached to the person (jus
personarum). The expressions "freedom of life" or "personal liberty" are not to be found in article 19
and it is strain- ing the language of article 19 to squeeze in personal liber- ty into that article. In any
case the right to life cannot be read into article 19.
Article 19 being confined, in its operation, to citizens only, a non-citizen will have no protection for
his life and personal liberty except what has been called the procedural protection of article 21. If
there be no substantive right what will the procedure protect ? I recognise that it is not imperative
that a foreigner should have the same privileges as are given to a citizen, but if article 21 is construed
in the way I have suggested even a foreigner will have equal protection for his life and personal
liberty before the laws of our country under our Constitution. I am unable, there- fore, for all the
reasons given above, to agree that person- al liberties are the result of article 19 or that that article
purports to protect all of them.
It is next urged that the expression "personal liberty"
is synonymous with the right to move freely and, therefore, comes directly under
article 19 (1) (d). Reference is made to the unreported dissenting judgment of Sen J.
of Calcutta in Miscellaneous Case No. 166 of 1950 while referring that case to a Full
Bench.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

In his judgment Sen J. quoted the following passage from Blackstone's
Commentaries :--
"Next to personal security the law of :England regards, asserts and preserves, the
personal liberty of individuals. This personal liberty consists in the power of
locomotion, of changing situation, or moving one's person to whatsoever place one's
own inclination may direct, without imprisonment or restraint, unless by due course
of law." (Page 73 of George Chase's Edition (4th Edition) of Blackstone, Book I,
Chapter I. On the authority of the above passage the learned Judge concluded that
personal liberty came within article 19 (1)(d). I am unable to agree with the learned
Judge's con-
clusion. On a perusal of Chapter I of Book I of Black- stone's Commentaries it will appear that
the]earned commen- tator divided the rights attached to the person (jus person- arum) into two
classes, namely, "personal security" and "personal liberty." Under the head "personal security"
Blackstone included several rights, namely, the rights to' life, limb, body, health and
reputation, and under the head "personal liberty" he placed only the right of free
move- ment. He first dealt with the several rights classified by him under the head
"personal security" and then proceeded to say that next to those rights came personal
liberty which according to his classification consisted only in the right of free
locomotion. There is no reason to suppose that in article 21 of our Constitution the
expression "personal liberty" has been used in the restricted sense in which
Blackstone used it in his Commentaries. If "personal liber- ty" in article 21 were
synonymous with the right to move freely which is mentioned in article 19 (1) (d),
then the astounding result will be that only the last mentioned right has what has
been called the procedural protection of arti- cle 21 but none of the other rights in the
other sub-clauses of article 19 (1) has any procedural protection at all. According to
learned counsel for the petitioner the proce- dure required by article 21 consists of
notice and a right of hearing before an impartial tribunal. Therefore, accord- ing to
him, a man's right of movement cannot be taken away without giving him notice and
a fair trial before an impartial tribunal but he may be deprived of his freedom of
speech or his property or any of his other rights without the formality of any
procedure at all. The proposi- tion has only to be stated to be rejected. In my
judgment, article '19 protects some of the important attributes of personal liberty as
independent rights and the expression "personal liberty" has been 'used in article 21
as a compen- dious term including within its meaning all the varieties of rights which
go to make up the personal liberties of men. Learned counsel for the petitioner next
contends that personal liberty undoubtedly means or includes the freedom of the
person and the pith and substance of the freedom of the person is right to move
about freely and consequently a preventive detention law which destroys or suspends
the freedom of the person must inevitably destroy or suspend the right of free
movement and must necessarily offend against the protection given to the citizen by
article 19 (1)(d) unless it satisfies the test of reasonableness laid down in clause (5).A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

The argument is attractive and requires serious consideration as to the exact purpose
and scope of sub- clause (d) of article 19 (1).
There are indications in the very language of article 19 (1) (d) itself that its purpose is
to protect not the gener-
al right of free movement which emanates from the freedom of the person but only a specific and
'limited aspect of it, namely, the special right of a free citizen of India to move freely throughout the
Indian territory, i.e., from one State to another within the Union. In other words, it guarantees, for
example, that a free Indian citizen ordinarily residing in the State of West Bengal will be free to
move from West Bengal to Bihar or to reside and settle in Madras or the Punjab without any let or
hindrance other than as provided in clause (5). It is this special right of movement of the Indian
citizen in this specific sense and for this particu- lar purpose which is protected by article 19 (1) (d).
It is argued on the authority of a decision of a Special Bench of the Calcutta High Court presided
over by Sen J. in Sunil Kumar v. The Chief Secretary of West Bengal (1) that the words "through-.
out the territory of India" occurring in that sub-clause only indicate that our Constitution does not
guarantee to its citizens the right of free movement in or into foreign territory and that those words
have been added to save passport restrictions. I am unable to accept this interpre- tation. Our
Constitution cannot possibly give to any of its citizens any right of free movement in a foreign
country and it was wholly superfluous to specifically indicate this in the Constitution, for that would
have gone without saying. The words "throughout the territory of India" are not used in connection
with most of the other sub-clauses of clause (1) of article 19. Does such omission indicate that our
Constitution guarantees to its citizens freedom of speech and expression, say, in Pakistan ? Does it
guarantee to. its citizens a right to assemble or to form associations or unions in a foreign territory ?
Clearly not. Therefore, it was not necessary to use those words in sub-clause (d) to indicate that free
movement in foreign countries was not being guaranteed. It is said that by the use of those words
the Constitution makes it clear that no1 guarantee was being given to any citizen with regard to
emigration from India without a passport and that the freedom of movement was restricted within
the territory of India. Does the omission of those words from article 19 (1) (a) indicate that the
citizen of India has been guaranteed such freedom of speech and expression as will enable him to set
up a broadcasting station and broadcast his views and expressions to foreign lands without a
licences ? Clearly not. Dropping this line of argument and adopting a totally new line of argument it
is said that by the use of the words "throughout the territory of India" the Constitution indicates that
the widest right of free movement that it could possibly give to its citizens has been given. Does.
then, the omission of those words from the other subclauses indicate that the Constitution has kept
back some parts of those rights even beyond the limits of the qualifying clauses that follow ? Do not
those other rights prevail throughout the Indian territory ?
(1) 54 C.W.N. 394.
Clearly they do, even without those words. Therefore, those words must have been used in
sub-clause (d) for -some other purpose. That other purpose, as far as I can apprehend it, is to
indicate that free movement from one State to another within the Union is protected so that
Parliament may not by a law made under Entry 81 in List I curtail it beyond the limits prescribed byA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

clause (5) of article 19. Its purpose, as I read it, is not to provide protection for the general right of
free movement but to secure a specific and special right of the Indian citizen to move freely
throughout the territories of India regarded as an independent additional right apart from the
general right of locomotion emanating from the freedom of the person. It is a guarantee against
unfair discrimination in the matter of free movement of the Indian citizen throughout the Indian
Union. In short, it is a protection against provincialism. It has nothing to do with the freedom of the
person as such. That is guaranteed to every person, citizen or otherwise, in the manner and to the
extent formulated by article 21.
Clause (5) of article 19 qualifies sub-clause (d) of clause (1) which should, therefore, be read in the
light of clause (5). The last mentioned clause permits the State to impose reasonable restrictions on
the exercise of the right of free movement throughout the territory of India as ex- plained above.
Imposition of reasonable restrictions clearly implies that the right of free movement is not entirely
destroyed but that parts of the right remain. This reasona- ble restriction can be imposed either in
the interest of the general public or for the protection of the interests of any Scheduled Tribe. The
Scheduled Tribes usually reside in what are called the Scheduled Areas. The provision for imposing
restriction on the citizens' right of free movement in the interests of the Scheduled Tribes clearly
indicates that the restriction is really on his right of free movement into or within the Scheduled
Areas. It means that if it be found necessary for the protection of the Scheduled Tribes the citizens
may be restrained from entering into or moving about in the Scheduled Areas, although they are left
quite free to move about elsewhere. This restraint may well be necessary for the protection of the
members of the, Sched- uled Tribes who are generally impecunious and constitute a backward class.
They may need protection against money- lenders or others who may be out to exploit them. They
may have to be protected against their own impecunious habits which may result in their selling or
mortgaging their hearths and homes. Likewise, the free movement of citizens may have to be
restricted in the interest of the general public. A person suffering from an infectious disease may be
prevent from moving about and spreading the disease. and regulations for his segregation in the
nature of quarantine may have to be introduced. Likewise, healthy people may be prevented, in the
interests of the general public, from entering a plague-infected area. There may be protected places,
e.g., forts or other strategic places, access where- to may have to be regulated or even prohibited in
the inter- ests of the general public. The point to be noted, however, is that when free movement is
thus restricted, whether in the interest of the general public or for the protection of the Scheduled
Tribes, such restriction has reference gener- ally to a certain local area which becomes the
prohibited area but the right of free movement in all other areas in the Union is left unimpaired. The
circumstance that clause (5) contemplates only the taking away of a specified area and thereby
restricting the field of the exercise of the right conferred by subclause (d) of clause (1) indicates to
my mind that subclause (d)is concerned, not with the freedom of the person or the general right of
free movement but with a specific aspect of it regarded as an independent right apart from the
freedom of the person. In other words in sub-clause (d)the real emphasis is on the words
"throughout the territory of India." The purpose of article 19 (1) (d) is to guarantee that there shall
be no State barrier. It gives protection against provincialism. It has nothing to do with the freedom
of the person as such.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Finally, the ambit and scope of the rights protected by article 19 (1) have to be considered. Does it
protect the right of free movement and the other personal rights therein mentioned in all
circumstances irrespective of any other consideration ? Does it not postulate a capacity to exercise
the rights ? Does its protection continue even though the citizen lawfully loses his capacity for
exercising those rights ? How can the continuance of those personal rights be compatible with the
lawful detention of the person ? These personal rights and lawful detention cannot go together. Take
the case of a person who has been properly convicted of an offence punish- able under a section of
the Indian Penal Code as to the reasonableness of which there is no dispute. His right to freedom of
speech is certainly impaired. Under clause (2) the State may make a law relating to libel, slander,
defama- tion, contempt of Court or any matter which offends against decency or morality or which
undermines the security of, or tends to overthrow, the State. Any law on any of these matters
contemplated by this clause certainly must have some direct reference to speech and expression. It
means that the law may directly curtail the freedom of speech so that the citizen may not talk libel or
speak contemptuously of the Court or express indecent or immoral sentiments by speech or other
forms of expression or utter seditious words. To say that every crime undermines the security of the
State and, therefore, every section of the Indian Penal Code, irrespective of whether it has any
reference to speech or expression, is a law within the meaning of this clause is wholly unconvincing
and betrays only a vain and forlorn attempt to find an explanation for meeting the argument that
any conviction by a Court of law must necessarily infringe article 19 (1) (a). -There can be no getting
away from the fact that a detention as a result of a conviction impairs the freedom of speech far
beyond what is permissible under clause (2) of article 19. Likewise a detention on lawful conviction
impairs each of the other personal rights men- tioned in sub-clauses (b) to (e) and (g) far beyond the
limits of clauses (8) to (6). The argument that every section of the Indian Penal Code irrespective of
whether it has any reference to any of the rights referred to in sub- clauses (b) to (e) and (g) is a law
imposing reasonable restriction on those several rights has not even the merit of plausibility. There
can be no doubt that a detention as a result of lawful conviction must necessari- ly impair the
fundamental personal rights guaranteed by article 19 (1) far beyond what is permissible under
clauses (2) to (6) of that article and yet nobody can think of questioning the validity of the detention
or of the section of the Indian Penal Code under which the sentence was passed. Why ? Because the
freedom of his person having been lawfully taken away, the convict ceases to be entitled to exercise
the freedom of speech and expression or any of the other personal rights protected by clause (1) of
article
19. On a parity of reasoning he cannot, while the detention lasts, exercise any other personal right,
e.g., he cannot eat what he likes or when he likes but has to eat what the Jail Code provides for him
and at the time when he is by Jail regulations required to eat. Therefore, the conclusion is
irresistible that the rights protected by article 19 (1), in so far as they relate to rights attached to the
person, i.e., the rights referred to in sub-clauses (a) to (e) and
(g), are rights which only a free citizen, who has the freedom of his person unimpaired, can exercise.
It is pointed out, as a counter to the above reasonings, that detention as a result of a lawful
conviction does not deprive a person of his right to acquire or hold or dispose of his property
mentioned in sub-clause (f). The answer is simple, namely, that that right is not a right attached to
the person (jus personrum) and its existence is not depend- ent on the freedom of the person. LossA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

of freedom of the person, therefore, does not suspend the right to property. But suppose a person
loses his property by reason of its having been compulsorily acquired under article 31 he loses his
right to hold that property and cannot complain that his fundamental right under sub-clause (f) of
clause (1) of article 19 has been infringed. It follows that the rights enumerated in article 19 (1)
subsist while the citizen has the legal capacity to exercise them. If his capacity to exercise them is
gone, by reason of a lawful conviction with respect to the rights in sub-clauses (a) to (e) and (g), or
by reason of a lawful compulsory acquisition with respect to the right in sub- clause (f), he ceases to
have those rights while his inca- pacity lasts. It further follows that if a citizen's free- dom of the
person is lawfully taken away otherwise than as a result of a lawful conviction for an offence, that
citizen, for precisely the same reason, cannot exercise any of the rights attached to his person
including those enumerated in sub-clauses (a) to (e) and (g) of article 19 (1). In my judgment a
lawful detention, whether punitive or preventive, does not offend against the protection conferred
by article 19 (1) (a) to (e) and (g), for those rights must necessarily cease when the freedom of the
person is lawfully taken away. In short, those rights end where the lawful detention be- gins. So
construed, article 19 and article 21 may, there- fore, easily go together and there is, in reality, no
con- flict between them. It follows, therefore, that the validi- ty or otherwise of preventive detention
does not depend on, and is not dealt with by, article 19.
To summarise, the freedom of the person is not the result of article 19. Article 19 only deals with'
certain particu- lar rights which, in their origin and inception, are attributes of the freedom of the
person but being of great importance are regarded as specific and independent rights. It does not
deal with the freedom of the person as such. Article 19 (1) (d) protects a specific aspect of the right of
free locomotion, namely, the right to move freely throughout the territory of India which is regarded
as a special privilege or right of an Indian citizen and is protected as such. The protection of article
19 is co-termi- nous with the legal capacity of a citizen to exercise the rights protected thereby, for
sub-clauses (a) to (e) and (g) of article 19 (1) postulate the freedom of the person which alone can
ensure the capacity to exercise the rights pro- tected by those sub-clauses. A citizen who loses the
free- dom of his person by being lawfully detained, whether as a result of a conviction for an offence
or as a result of preventive detention loses his capacity to exercise those rights and, therefore, has
none of the rights which sub- clauses (a) to (e) and (g) may protect.
In my judgment article 19 has no bearing on the question of the validity or otherwise of preventive
detention and, that being so, clause (5) which prescribes a test of reasonable- ness to be defined and
applied by the Court has no applica- tion at all.
Article 19 being thus out of the way, I come to article 20 which is concerned with providing
protection against what are well known as ex post facto laws, double jeopardy and
self-incrimination. This article constitutes a limitation on the absolute legislative power which
would, but for this article, be exercisable by Parliament or the State Legisla- tures under article 246
read with the legislative lists. If the Legislature disobeys this limitation the Court will certainly
prevent it. Article 20 has no bearing on preven- tive detention laws and I pass on.
Article 21 runs thus:A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"21. No person shall be deprived of his life or person- al liberty except according to procedure
established by law."
The contention of learned counsel for the petitioner is that by this article the Constitution offers to
every per- son, citizen or non-citizen, only a procedural protection. According to the argument, this
article does not purport to give any protection to life or personal liberty as a sub- stantive right but
only prescribes a procedure that must be followed before a person may be deprived of his life or
personal liberty. I am unable to accept this contention. Article 21, as the marginal note states,
guarantees to every person "protection of life and personal liberty." As I read it, it defines the
substantive fundamental right to which protection is given and does not purport to prescribe any
particular procedure at all. That a person shall not be deprived of his life or personal liberty except
according to procedure established by law is the substantive fundamental right to which protection
is given by the Constitution. The avowed object of the article, as I apprehend it, is to define the
ambit of the right to life and personal liberty which is to be protected as a fundamental right. The
right to life and personal liberty protected by article 21 is not an absolute right but is a qualified
right--a right circumscribed by the possibility or risk of being lost according to procedure
established by law. Liability to deprivation according to procedure established by law is in the
nature of words of limitation. The article delimits the right by a reference to its liability to
deprivation according to procedure estab- lished by law and by this very definition throws a corre-
sponding obligation on the State to follow a procedure before depriving a man of his life and
personal liberty. What that procedure is to be is not within the purpose or purview of this article to
prescribe or indicate.
The claim of learned counsel for the petitioner is that article 21 prescribes a procedure. This
procedure, accord- ing to learned counsel, means those fundamental immutable rules of procedure
which are sanctioned or well established by principles of natural justice accepted in all climes and
countries and at all times. Apart from the question whether any rule of natural procedure exists
which conforms to the notions of justice and fair play of all mankind at all times, it has to be
ascertained whether the language of article 21 will permit its introduction into our Constitu- tion.
The question then arises as to what is the meaning of the expression "procedure established by law."
The word "procedure" in article 21 must be taken to signify some step or method or manner of
proceeding leading up to the depriva- tion of life or personal liberty. According to the language used
in the article, this procedure has to be "established by law." The word "establish" according to the
Oxford English Dictionary, Vol. III, p. 297, means, amongst other things, "to render stable or firm ;
to strengthen by materi- al support; to fix, settle, institute or ordain permanently by enactment or
agreement." According to Dr. Annandale's edition of the New Gresham Dictionary the word
"establish,"
means, amongst other things, "to found permanently; to institute; to enact or decree;
to ordain; to ratify; to make firm." It follows that the word "established" in its ordi-
nary natural sense means, amongst other things, "enacted."
"Established by law" will, therefore, mean "enacted by law." If this sense of the word
"established" is accepted, then the word "law" must mean State-made law and cannotA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

possibly mean. the principles of natural justice, for no procedure can be said to have
ever been "enacted" by those principles. When section 124-A of the Indian Penal
Code speaks of "Government established by law," surely it does not mean
"Government set up by natural justice." Therefore, procedure established by law
must, I apprehend, be procedure enacted by the State which, by its definition in
article 12, includes parliament. There is no escape from this position if the cardinal
rule of construc- tion, namely, to give the words used in a statute their ordinary
natural meaning, is applied. And this construction introduces no novelty or
innovation, for at the date of the Constitution the law of procedure in this country.
both civil and criminal, was mainly if not wholly, the creature of statute. The Hindu
or Muhammadan laws of procedure were abrogated and replaced by the Code of Civil
Procedure or the Code of Criminal Procedure. Therefore, procedure established by
law is quite compatible with procedure enact- ed by law. If, however, the word
"established" is taken to mean "sanctioned" or "settled" or "made firm" then the
question will arise as to the meaning of the word "law" in that context. Reference is
made to Salmond's Jurisprudence, 10th Edition, p. 37, showing that the term "law" is
used in two senses and it is suggested that the word "law" in the expression
"established by law "means law in its abstract sense of the principles of natural
justice. It is "jus" and not "lex," says learned counsel for the petitioner. It is pointed
out that both the English and the Indian law in many cases, some of which have been
cited before us, have recog- nised and applied the principles of natural justice and
that this Court should do the same in interpreting tim provisions of our Constitution.
I find it difficult to let in princi- ples of natural justice as being within the meaning of
the word "law," having regard to the obvious meaning of that word in the other
articles. Article 14 certainly embodies a principle of natural justice which ensures to.
every person equality before the law. When natural jus- tice speaks of and enjoins
equality- before the law, that law must refer to something outside natural justice, and
must mean the State-made laws. It is only when the State law gives equality to every
person that that law is said to be in accordance with natural justice. There can be no
doubt that the words "in accordance with law" in article 17 have reference to State
law. Likewise, the word "law" in article 20 (1) can mean nothing but law made by the
State. The same remark applies to the words "in accordance with law" in articles 23,
31 and 32. Natural justice does not impose any tax and, therefore, the word "law" in
articles 265 and 286 must mean State-made law. If this be the correct meaning of the
word "law" then there is no scope for intro- ducing the principles of natural justice in
article 21 and "procedure established by law" must mcan procedure estab- lished by
law made by the State which, as defined, includes Parliament and the Legislatures of
the States. We have been referred to a number of text books and decisions showing
the development of the American doctrine of "due process of law" and we have been
urged to adopt those principles in our Constitution. The matter has to be considered
against its historical background. The English settlers in different parts of America
had carried with them the English common law as a sort of personal law regulating
their rights and liberties inter se as well as between them and the State. After the WarA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

of Independence the Constitu- tions of the United States were drawn up in writing.
The majority of those who framed the Constitution were lawyers and had closely
studied the Commentaries of the great Eng- lish jurist Blackstone, who in his famous
commentaries had advocated the separation of the three limbs of the State, namely,
the executive, the legislature and the judiciary. Montesquit's Spirit of Laws had
already been published wherein he gave a broader and more emphatic expression to
the Aristotelian doctrine of separation of powers. The experience of the repressive
laws of Parliament had im- pressed upon the framers of the American Constitution
the belief that it was the habit of all legislative bodies to grasp and exercise powers
that did not belong to them. The interference of the colonial governors with
legislation and the judiciary was also real. This sad experience coupled with the
political philosophy of the time induced the fram- ers of the American Constitutions
to adopt safeguards not only against the executive but also against the legislature.
(See Munro on the Government of the United States, 5th Edition, Chapter IV, p. 53 et
seq.). Says Judge Cooley in his Constitutional Limitations, 6th Edition, Vol. II, Chap-
ter XI, p. 755:
"The people of the American States, holding the sover- eignty in their own hands,
have no occasion to exact any pledges from any one for a due observation of
individual rights; but the aggressive tendency of power is such that they have deemed
it of no small importance, that, in framing the instruments under which their
governments are to be administered by their agents, they should repeat and re- enact
this guarantee, and thereby adopt it as a principle of constitutional protection."
There can be little doubt that the people of the differ- ent States in America intended not to take any
risk as to their life, liberty or property even from the legislature. As Munro puts it at pp. 58-61 :--
"The framers of the Constitution set boundaries to the powers of the Congress, and it
was their intent that these limitations should be observed. But how was such
observance to be enforced by the Courts ? The statesmen of 1767 did not categorically
answer that question."
The Constitution was silent and there was no express provision as to who was to serve as umpire in
case the Congress overstepped the limits of its legislative powers. By the 5th Amendment what is
now known as the "due process clause" was introduced in the Federal Constitution and by the 14th
Amendment a similar clause was adopted in the State Constitutions. Some of the State Constitutions
used the words "due course of law," some repeated the words of Magna Charta, namely, "the law of
the land" but most of them used the expression "due process of law." All the expressions meant the
same thing, namely, that no person should be deprived of his life, liberty or property except in due
process of law. The Constitution by this clause gave the Supreme Court an opportunity to take upon
itself the function of declaring the national laws unconstitutional. And the Supreme Court, under the
leadership of Chief Justice John Marshall, seized this opportunity and assumed the right to say the
last word on questions of constitutionality, and possesses that right to-day: (Munro, p. 62). The
expression "due process of law" has been interpreted by the American Courts in different ways atA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

different times. Carl Brent Swisher in his book on the Growth of Constitutional Power in the United
States at p. 107 says, with reference to the development of the doctrine of due procedure:
"The American history of its interpretation falls into three periods. During the first
period covering roughly the first century of Government under the Constitution "due
process" was interpreted "principally as a restriction upon procedure--and largely the
judicial procedure--by which the Government exercised its powers. During the
second period,which, again roughly speaking, extended through 1936, "due process"
was expanded to serve as a restriction not merely upon procedure but upon the
substance of the activi- ties in which the Government might engage. During the third
period extending from 1936 to date, the use of "due process"
as a substantive restriction has been largely suspended or abandoned, leaving it principally in its
original status as a restriction upon procedure."
In the guise of interpreting "due process of law" the American Courts went much further than even
Lord Coke ever thought of doing. The American Courts gradually arrogated to themselves the power
to revise all legislations. In the beginning they confined themselves to insisting on a due procedure
to be followed before a person was deprived of his life, liberty or property. In course of time, "due
process of law" came to be applied to personal liberty, to social control, to procedure to jurisdiction
and to substantive law: (Willis, p. 642). In the words of Munro "due process of law" became a sort of
palladium covering all manner of individual rights. A_II the while the Supreme Court refused to
define the phrase, but used it to enable it to declare unconstitutional any Act of legislation which it
thought unreasonable: (Willis, p.
657). In Holden v. Hardy (1) we find the following observa- tions:
"This Court has never attempted to define with precision the words' due process of
law ................ It is suffi- cient to say that there are certain immutable principles of
justice which inhere in the very idea of free government which no member of the
Union may disregard."In Taylor v. Peter (2) Bronson J. observed:
"The words 'by the law of the land' as used in the Constitution, do not mean a statute
passed for the purpose of working the wrong. That construction would render the
restriction absolutely nugatory, and turn this part of the Constitution into mere
nonsense. The people would be made to say to the two Houses: ' You shall be vested
with the legis- lative power of the. State, but no one shall be disenfran- chised or
deprived of any of the rights or privileges of a citizen, unless you pass a statute for
that purpose. In other words you shall not do the wrong unless you choose to do it.'"
It was thus that the Supreme Court of the United States firmly established its own supremacy over
the other two limbs of the State, namely, the executive and the Congress. In the words of John
Dickinson quoted in Munro at p. 61, "The Judges of Aragon began by setting aside laws and ended
by making them." And all this sweeping development could only be possible because of the presenceA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

of one little word "due" which, in its content, knows no bound and is not subject to any fixed
definition. Whenever a substantive law or some procedure laid down in any law did not find favour
with the majority of the learned Judges of the Supreme Court it was not reasonableand, therefore, it
was not "due." (1) 169 U.S. 366 at p. 389. (2) 4 Hill 140,
145. The very large and nebulous import of the word "due" was bound to result in anomalies, for
what was not "due" on one day according to the Judges then constituting the Supreme Court became
"due" say 20 years later according to the new Judges who then came to occupy the Bench, for the
Court had to adapt the Constitution to the needs of the society which were continually changing and
growing. The larger content of due process of law, which included both procedural and substantive
due process of law, had of necessity to be narrowed down, for social interest in personal liberty had
to give way to social interest in other matters which came to be considered to be of more vital
interest to the commu- nity. This was achieved by the Supreme Court of the United States evolving
the new doctrine of police powers--a pecul- iarly American doctrine. The police powers are nowhere
exhaustively defined. In Chicago B. & Q. Ry. v. Drainage Commissioner (1) ,, police power" has been
stated to "em- brace regulations designed to promote the public convenience or the general
prosperity, as well as regulations designed to promote the public health, the public morals or the
public safety." Reference in this connection may be made to Cooley's Constitutional Limitations, 8th
Edition, Vol. II, p. 1223 and to Chapter XXVI of Willis at p. 727. The nett result is that the
all-inclusive and indefina- ble doctrine of due process of law has in America now been brought back
to its original status of a procedural due process of law by the enunciation and application of the
new doctrine of police power as an antidote or palliative to the former. Who knows when the
pendulum will swing again. Turning now to what has been called the procedural due process of law
it will be found that the matter has been described in different languages in different cases. In
Westervelt v. Gregg (2) Edwards J. defined it thus:
"Due process of law undoubtedly means, in the due course of legal proceedings,
according to those rules 204 u.s. 561,592. (2) 12 N.Y. 202.
and forms which have been established for the protection of private rights."
A more specific definition of the expression "the law of the land" meaning procedural due process
was given by Web- ster appearing as counsel for the plaintiff in error in the Trustees of Dartmouth
College v. Woodward (1):
"By the law of the land is most clearly intended the general law; a law which hears
before it condemns; which proceeds upon inquiry and renders judgment only after
trial. The meaning is that every citizen shall hold his life, liberty, property, and.
immunities, under the protection of the general rules which govern society.
Everything which may pass under the form of an enactment is not therefore to be
considered the law of the land."
Willis in Ch. XXIII, p. 661, says:A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

"The guarantee of due process of law as a matter of procedure means that no part of a
person's personal liberty, including ownership, shall be taken away from him except
by the observance of certain formalities. Hence its object is the protection of the
social interest in personal liberty."
At p. 662 Willis enumerates the requirements of the procedural due process of law as follows:(1)
notice. (2) opportunity to be heard, (3) an impartial tribunal, and (4) an orderly course of
procedure. In short, the procedural due process requires that a person who is to be deprived of his
life, liberty or property shall have had "his day in Court." This according to Willough by p. 736,
means:
"(1) that he shall have had due notice, which may be actual or constructive, of the
institution of the proceed-
ings by which his legal rights may be affected; (2) that he shall be given a reasonable opportunity to
appear and defend his rights, including the right himself to testify, to produce witnesses, and to
introduce relevant documents and other evidence, (3) that the tribunal in or before which his rights
are adjudicated is so constituted as to give reasona- ble assurance of its.
(1) 4 Wheaton 518 at p. 579; 4 L. Edn. 629 at p. 645.
honesty and impartiality; and (4) that it is a Court of competent jurisdiction."
It will be noticed that the fourth item of Willoughby is different from the fourth item of Willis. Such,
in short, are the history of the development of the doctrine of the process of law in the United States
and the requirements of the procedural due process as insisted on by the Supreme Court of that
country.
Learned counsel for the petitioner before us does not contend that we should import this American
doctrine of due process of law in its full glory but that we should adopt the procedural part of it and
insist that no person shall be deprived of his life or personal liberty except by the observance of the
formalities which justice and fair play require to be observed. The arguments of learned counsel for
the petitioner are attractive and in the first blush certainly appeal to our sentiment but on serious
reflection I find several insuperable objections to the introduction of the American doctrine of
procedural due process of law into our Constitution. That doctrine can only thrive and work where
the legislature is subordinate to the judiciary in the sense that the latter can sit in judgment over and
review all acts of the legislature. Such a doctrine can have no application to a field where the
legislature is supreme. That is why the doctrine of "due process of law" is quite different in England
where Parliament is supreme. This difference is pointedly described by Mathews J. in Joseph
Hurtado v. People of California (1) at p. 531:
"The concessions of Magna Charta were wrung from the King as guarantees against
oppression and usurpation of his prerogatives. It did not enter into the minds of the
barons to provide security against their own body or in favour of the commons byA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

limiting the power of Parliament, so that bills of attainder, ex post facto laws, laws
declaring forfeitures of estates and other arbitrary Acts of legisla- tion which occur so
frequently in English history, were never regarded as inconsistent with the law of the
land, for, notwithstanding what was attributed to Lord Coke in. Bonham's (1) (1883)
110 U.S. 516.
case, [8 Coke 115, 118 (a),] the omnipotence of Parliament over the Common Law was absolute, even
against common right and reason. The actual and practical security for English liberty against
legislative tyranny was the power of a free public opinion represented by the Commons.
In this country written Constitutions were deemed essen- tial to protect the rights and liberties of
the people against the encroachments of power delegated to their gov- ernments and the provisions
of Magna Charta were incorporat- ed in the bills of rights. They were limitations upon all the powers
of government, legislative as well as executive and judicial."
This basic distinction between the two systems should never be lost sight of, if confusion of thought
is to be avoided. Although our Constitution has imposed some limita- tions on the legislative
authorities, yet subject to and outside such limitations our Constitution has left our Parliament and
the State Legislatures supreme in their respective legislative fields. In the main, subject to the
limitations I have mentioned, our Constitution has preferred the supremacy of the Legislature to
that of the Judiciary. The English principle of due process of law is, therefore, more in accord with
our Constitution than the American doctrine which has been evolved for serving quite a differ- ent
system. The picturesque language of Bronson J. quoted above, while that is quite appropriate to the
American Constitution which does not recognise the supremacy of the Congress, is wholly out of
place in, and has no applica- tion to, a Constitution such as ours, which, subject only to certain
restrictions, recognises the supremacy of the Legis- latures in their respective fields. In the next
place, it is common knowledge that our Constitution-makers deliberate- ly declined to adopt the
uncertain and shifting American doctrine of due process of law and substituted the words' "except in
due process of law" that were in the original draft by the more specific expression "except in
accordance with procedure established by law." To try to bring in the American doctrine, in spite of
this fact, will be to stulti- fy the intention of the Constitution as expressed in article 21. In the third
place, in view of the plain meaning of the language of that article as construed and explained above
it is impossible to let in what have been called the principles of natural justice as adopted in the
procedural due process of law by the American Supreme Court. Again, even the all-pervading little
word "due" does not find a place in article 21 so as to qualify the procedure. It speaks of procedure
and not "due" procedure and, therefore, "the intellectual yardstick" of the Court is definitely ruled
out. Finally, it will be incongruous to import the doctrine of due process of law without its palliative,
the doctrine of police powers. It is impossible to read the last mentioned doctrine into article 21.
It has also been suggested as a compromise that this Court should adopt a middle course between
the flexible principles of natural justice as adopted by the American doctrine of due process of law
and the unbending rigidity of mere State-made laws. h is said that we have our Code of Criminal
Procedure which embodies within its provisions certain salutary principles of procedure and we
must insist that those underlying principles should be regarded as procedure established or settledA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

by our positive law. But who will say what are those fundamental principles? What principles. do I
reject as inessential and what shall I adopt as fundamental ? What is fundamental to me today may
not appear to be so to another Judge a decade hence, for principles give way with changing social
conditions. In America it was suggested that due process of law should be taken to mean the general
body of common law as it stood at the date of the Constitution. In Bardwell v. Collins (1) it was
negatived in the following words:
"'Due process of law' does not mean the general body of the law, common and statute,
as it was at the time the Constitution took effect; for that would deny the legisla- ture
power to change or amend the law in any particular."
The Court, however, brought in principles of (1) 44 Minn. 97.
natural justice under the due process clause. To sanctify what I may to-day regard as the basic
principles underlying our Code of Criminal Procedure will be to make them immuta- ble and to
prevent the legislature even to improve upon them. This is nothing but imposing on the legislature a
limitation which the Constitution has not placed on it. I do not think it is a permissible adventure for
the Court to undertake. It is a dangerous adventure, for it will bring about stagnation which means
ruin. We must accept the Con- stitution which is the supreme law. The Constitution has by article 21
required a procedure and has prescribed certain minimum requirements of procedure in article 22.
To add to them is not to interpret the Constitution but to recast it according to our intellectual
yardstick and our unconscious predilections as to what an ideal Constitution should be. Article 21, in
my judgment, only formulates a substan- tive fundamental right to life and personal liberty which in
its content is not an absolute right but is a limited right having its ambit circumscribed by the risk of
its being taken away by following a procedure established by law made by the appropriate legislative
authority and the proximate purpose of article 21 is not to prescribe any particular procedure. It is to
be kept in mind that at the date when the Constitution came into effect we had the Indian Penal
Code creating diverse offences and a conviction for any of them would deprive a person of his
personal liberty. Under article 246 read with Entry 1 of the Concurrent List, Par- liament or any
State Legislature could add more offences and create further means for taking away personal liberty.
But all this deprivation of personal liberty as a result of a conviction could only be done by following
the procedure laid down by the Code of Criminal Procedure. Again, at the date of this Constitution
there were preventive detention laws in almost every province and a person could be deprived of his
personal liberty under those laws. Those laws, however, provided a procedure of a sort which had to
be followed. Therefore, before the Constitution came into force, personal liberty could be taken away
only by following the procedure enacted by the Criminal Procedure Code in the case of punitive
detention or by the procedure enacted by the different Security Acts in case of preventive detention.
Power, however, has been given to Parliament and the State Legislatures under article 246 read with
Entry 2 of the Concurrent List to make laws with re- spect to Criminal Procedure. If that article
stood by itself the Parliament or the State Legislature could repeal the whole of the Criminal
Procedure Code and also do away even with the skeleton procedure provided in the Security Acts. If
article 246 stood by itself then the appropriate legislative authority could have taken away the life
and personal liberty of any person without any procedure at all. This absolute supremacy of the
legislative authority has, however, been cut down by article 21 which delimits the ambit and scope ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

the substantive right to life and person- al liberty by reference to a procedure and by article 22 which
prescribes the minimum procedure which must be fol- lowed. In this situation the only power of the
Court is to determine whether the impugned law has provided some proce- dure and observed and
obeyed the minimum requirements of article 29. and if it has, then it is not for the Court to insist on
more elaborate procedure according to its notion or to question the wisdom of the legislative
authority in enacting the particular law, however harsh, unreasonable, archaic or odious the
provisions of that law may be. It is said that if this strictly technical interpreta- tion is put upon
article 21 then it will not constitute a fundamental right at all and need not have been placed in the
chapter on Fundamental Rights, for every person's life and personal liberty will be at the mercy of
the Legislature which, by providing some sort of a procedure and complying with the few
requirements of article 22, may, at any time, deprive a person of his life and liberty at its pleasure
and whim. There are several answers to this line of argument. Article 21 as construed by me will, if
nothing else, cer- tainly protect every person against the executive and as such will be as much a
fundamental right deserving a place in the Constitution as the famous 39th Chapter of the Magna
Charta was and is a bulwark of liberty in English law. It appears to me that article 21 of our
Constitution read with article 32 also gives us some protection even against the legislative authority
in that a person may only be deprived of his life and personal liberty in accordance with procedure
which, although enacted by it, must at least conform to the requirements of article 22. Subject to
this limitation our parliament or any State Legislature may enact any law and provide any procedure
it pleases for depriving a person of his life and personal liberty under article 21. Such being the
meaning of that article and the ambit and extent of the fundamental right of life and personal liberty
which the people of this country have given unto themselves, any law for depriving any person of his
life and personal liberty that may be made by the appropriate legislative authority under article 246
and in conformity with the requirements of article 22 does not take away or abridge any right
conferred by article 21, for the very right conferred by that article is circumscribed by this possi-
bility or risk and, therefore, such law cannot be regarded as violating the provisions of article 13 (2).
Our Constitution is a compromise between Parliamentary supremacy of England and the supremacy
of the Supreme Court of the United States. Subject to the limitations I have mentioned which are
certainly justiciable, our Constitution has ac- cepted the supremacy of the legislative authority and,
that being so, we must be prepared to face occasional vagaries of that body and to put up with
enactments of the nature of the atrocious English statute to which learned counsel for the petitioner
has repeatedly referred, namely, that the Bishop of Rochester's cook be boiled to death. If
Parliament may take away life by providing for hanging by the neck, logi- cally there can be no
objection if it provides a sentence of death by shooting by a firing squad or by guillotine or in the
electric chair or even by boiling in oil. A procedure laid down by the legislature may offend against
the Court's sense of justice and fair play and a sentence provided by the legislature may outrage the
Court's notions of penology, but that is a wholly irrelevant consideration. The Court may construe
and interpret the Constitution and ascertain its true meaning but once that is done the Court cannot
question its wisdom or policy. The Constitution is supreme. The Court must take the Constitu- tion
as it finds it, even if it does not accord with its preconceived notions of what an ideal Constitution
should be. Our protection against legislative tyranny, if any, lies in ultimate analysis in a free and
intelligent public opinion which must eventually assert itself. The conclusion I have arrived at does
not introduce any novelty, for in many other Constitutions the supremacy of the legislature is
recognised in the matter of depriving a person of his life, liberty and property. The EnglishA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

Democratic Constitution is one in point. Take the Constitu- tion of the Irish Free State. Article 40
(4) (i) provides that no citizen shall be deprived of personal liberty save in accordance with law, and
article 50 (5) guarantees that the dwelling of every citizen is inviolable and shall not be forcibly
entered save in accordance with law. The words "in accordance with law" in both the above clauses
must mean the same thing and I have no doubt in my mind, reading clause (5)that it means in
accordance with the State-made law, for we have not been referred to any rule prescribed by natural
justice regulating searches of, or entry into, dwelling houses. Article 107 (2) of the Czechoslovakian
Constitution uses the words "in accordance with law" which, read with clause (1) of that article,
obviously means the law to be made which will form part of the Constitution. Take the Constitution
of the Free City of Danzig. Article74 of that Constitution which is in Part II headed "Fundamental
Bights and Duties" provides as follows:
"The liberty of the person shall be inviolable. No limitation or deprivation of personal
liberty may be imposed by public authority, except by virtue of a law."
The word" law" clearly cannot, in the context,mcan princi- ples of natural justice- Again, article 75 of
that Consti- tution protects the freedom of movement within the Free City and the right to stay and
to settle at any place, to acquire real property and to earn a living. It concludes by saying that this
right shall not be curtailed without legal sanctions. Legal sanctions, in this context, can only mean
sanctions of the City laws. Article 114 of the Weimar Constitution is on the same lines and expressed
in almost the same language as article 74 of the Danzig Constitution. Take the Japanese Constitution
of 1946 from which our arti- cle 21 is reputed to have been taken. Article XXXI of that Constitution
says:
No person shall be deprived of life or liberty nor shall any other criminal penalty be
imposed, except according to procedure established by law."
Surely the words "except according to procedure established by law" in their
application to the imposition of criminal penalty must mean State-made law and the
same words in the same sentence in the same article cannot, according to ordi- nary
rules of construction of statutes, mean a different thing in their application to
deprivation of life or liber- ty. I am aware that it is not right to construe one Consti-
tution in the light of another and that is not my purpose when I refer to the other
Constitutions; but I do think that after reading the relevant provisions of other
written Con- stitutions one sees quite clearly that there is no pressing special reason
applicable to or inherent in written Consti- tutions which requires the importation of
the principles of natural justice or of the American doctrine of due process of law into
our Constitution. The several Constitutions referred to above have not adopted that
American doctrine but have been content with leaving the life and liberty of their
citizens to the care of the laws made by their legis- latures. It is no novelty if our
Constitution has done the same. For all these reasons, in spite of the very able and
attractive arguments of the learned counsel for the peti- tioner which I freely
acknowledge, I am not convinced that there is any scope for the introduction into
article 21 of our Constitution of the doctrine of due process of law even as regardsA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

procedure. I may or may not like it, but that is the result of our Constitution as I
understand it. The learned Attorney-General has referred to certain debates in the
Constituent Assembly on the original clause which has now become article 21, not as
evidence to be used in interpreting the language of article 21 but as disclos- ing the
historical background. His purpose, he says, is to show that the framers of our
Constitution had the essential difference in the meaning of the phrases "due process
of law" and "according to procedure established by law" clearly explained to them,
that they knew that the former implied the supremacy of the judiciary and the latter
the supremacy of the legislature and with all that knowledge they deliber- ately
agreed to reject the former expression and adopt the latter. As, in my opinion, it is
possible to interpret the language of article 21 on the ordinary rules of interpreta-
tion of statutes, I do not think it is at all necessary to refer to the debates. As I do not
propose to refer to, or rely on, the debates for the purposes of this case, I express no
opinion on the question of the admissibility or otherwise of the debates.
I now pass on to article 22. The contention of learned counsel for the petitioner is
that article 21 by reason of the last few words, "according to procedure established by
law" attracts the four requirements of the American proce- dural due process of law
as summarised by Willis to which reference has been made earlier, and that those
require- ments, except to the extent they have been expressly abro- gated or modified
by article 22, must be strictly followed before a person may be deprived of his life or
personal liberties. I have already stated for reasons set forth above, that there is no
scope for introducing any rule of natural justice or the American procedural due
process of law or any underlying principle of our Code of Criminal Procedure into
that article. This being the conclusion I have arrived at, the major premise assumed
by learned coun- sel for the petitioner is missing and this line of argument does not
begin and cannot be accepted. The learned Attorney-General, on the other hand. has
at one stage of his argument, urged that article 21 has nothing to do with preventive
detention at all and that preventive detention is wholly covered by article 22 (4) to (7)
which by themselves constitute a complete code. I am unable to accede to this
extreme point of view also. The true posi- tion, as I apprehend it, lies between the two
extreme views. Article 21, to my mind, gives protection to life and person- al liberty to
the extent therein mentioned. It does not recognise the right to life and personal
liberty as an absolute right but delimits the ambit and scope of the right itself The
absolute right is by the definition in that article cut down by the risk of its being taken
away in accordance with procedure established by law. It is this circumscribed right
which is substantively protected by article 21 as against the executive as well as the
legislature, for the Constitution has conditioned its depri- vation by the necessity for
a procedure established by law made by itself. While subclauses (2) to (6) of article 19
have put a limit on the fundamental rights of a citizen, articles 21 and 22 have put a
limit on the power of the State given under article 246 read with the legislative lists.
Under our Constitution our life and personal liberty are balanced by restrictions on
the rights of the citizens as laid down in article 19 and by the checks put upon the
State by articles 21 and 22. preventive detention deprives a person of his personalA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

liberty as effectively as does punitive detention and, therefore, personal liberty,
circum- scribed as it is by the risk of its being taken away, re- quires protection
against punitive as well as preventive detention. The language of article 21 is quite
general and is wide enough to give its limited protection to personal liberty against all
forms of detention. It protects a person against preventive detention by the executive
without the sanction of a law made by the legislature. It prevents the legislature from
taking away a person's personal liberty except in accordance with procedure
established by law, although such law is to be by itself. If, as contended by the learned
Attorney-General and held by me, article 19 only protects the rights of a free citizen
as long as he is free and does not deal with total deprivation of personal liberty and if,
as contended by the learned Attorney-General, article 21 does not protect a person
against preventive detention then where is the protection for life and personal liberty
as substantive rights which the procedural provisions of arti- cle 22 may protect ?
What is the use of procedural protec- tion if there is no substantive right ? In my
judgment article 21 protects the substantive rights by requiring a procedure and
article 22 gives the minimum procedural pro- tection.
Clauses (1) and (2) of article 22 lay down the procedure that has to be followed when
a man is arrested. They ensure four things: (a) right to be informed regarding
grounds of arrest, (b) right to consult, and to be defended by, a legal practitioner of
his choice, (c) right to be produced before a magistrate within 24 hours and (d)
freedom from detention beyond the said period except by order of the magis- trate.
These four procedural requirements are very much similar to the requirements of the
procedural due process of law as enumerated by Willis. Some of these salutary
protections are also to be found in our Code of Criminal Procedure. If the procedure
has already been prescribed by article 21 incorporating the principles of natural
justice or the principles underlying our Code of Criminal Procedure what was the
necessity of repeating them in clauses (1) and (2) of article 22 ? Why this unnecessary
overlapping ? The truth is that article 21 does not prescribe any particular procedure
but in defining the protection to life and person-
al liberty merely envisages or indicates the necessity for a procedure and article 22 lays down the
minimum rules of procedure that even Parliament cannot abrogate or overlook. This is so far as
punitive detention is concerned. But clause (3) of article 22 expressly provides that none of the
procedure laid down in clauses (1) and (2) shall apply to an alien enemy or to a person who is
arrested or detained under any law providing for preventive detention. It is thus expressly made
clear that a detenu need not be produced before the magistrate and he is not to have the assistance
of any lawyer for consultation or for defending him. Such being the express provision of our
Constitution nobody can question its wisdom. So I pass on.
Clauses (4), (5), (6) and (7) of article 22 in terms relate to preventive detention. Article 246
authorises the appropriate legislature to make a law for preventive deten- tion in terms of Entry 9 in
List I and/or Entry 3 in List III of the Seventh Schedule. On this legislative power are imposed
certain limitations by article 22 (4) to (7). According to this the legislature, whether it be ParliamentA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

or a State Legislature, is reminded that no law made by it for preventive detention shall authorise
the detention of a person for a longer period than three months except in two cases mentioned in
sub-clauses (a) and (b). The proviso to sub-clause (a) and sub-clause (b) refer to a law made only by
Parliament under clause (7). Under clause (7) it is Parliament alone and not any State Legislature
that may prescribe what are specified in the three subclauses of that clause. Although a State
Legislature may make a law for preventive detention in terms of Entry 3 in List III of the Seventh
Schedule no such law may authorise detention for more than three months unless the provisions of
sub-clauses
(a)and (b) of clause (4) sanction such detention. Even a law made by Parliament cannot authorise
detention for more than three months unless it is a law made under the provi- sions of clause (7). In
short, clause (4) of article 22 provides a limitation on the legislative power as to the period of
preventive detention. Apart from imposing a limitation on the legislative power, clause (4) also pre-
scribes a procedure of detention for a period longer than three months by providing for an advisory
board. Then comes clause (5). It lays down the procedure that has to be fol- lowed when a person is
detained under any law providing for preventive detention, namely, (a) the grounds of the order of
detention must be communicated to the detenu as soon as may be, and (b) the detenu must be
afforded the earliest opportunity of making a representation against the order. The first requirement
takes the place of notice and the second that of a defence or hearing. These are the only compulsory
procedural requirements laid down by our Constitution. There is nothing to prevent the Legislature
from providing an elaborate procedure regulating preventive detention but it is not obliged to do so.
If some procedure is provided as envisaged by article 21 and the compulsory requirements of article
22 are obeyed and carried out nobody can, under our Constitution, as I read it, complain of the law
providing for preventive detention.
Learned counsel for the petitioner concedes that the four requirements of procedural due process
summarised by Willis will have to be modified in their application to preventive detention. Thus he
does not insist on a prior notice before arrest, for he recognises that such a require- ment may
frustrate the very object of preventive detention by giving an opportunity to the person in question
to go underground. The provision in clause (5) for supplying grounds is a good substitute for notice.
He also does not insist that the Tribunal to judge the reasonableness of the detention should be a
judicial tribunal. He will be satis- fied if the tribunal or advisory board, as it is called in article 22 of
the Constitution, is an impartial body and goes into the merits of the order of detention and its
decision is binding on the executive government. He insists that the detenu must have a reasonable
and effective oppor- tunity to put up his defence. He does not insist on the assistance of counsel, for
that is expressly taken away by the Constitution itself. But he insists on what he calls an effective
opportunity of being heard in person before an impartial tribunal which will be free to examine the
grounds of his detention and whose decision should be binding alike on the detenu and the
executive authority which detains. The claim may be reasonable but the question before the Court is
not reasonableness or otherwise of the provisions of article 22 (4) to (7). Those provisions are not
justicia- ble, for they are the provisions of the Constitution itself which is supreme over everybody.
The Court can only seek to find out, on a proper construc- tion, what protection has in fact been
provided. The Consti- tution has provided for the giving of the grounds of deten- tion although factsA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

as distinguished from grounds may be withheld under clause (6) and the right of representation
against the order of detention. It has provided for the duration of the detention. There the
guaranteed fundamental procedural rights end. There is no provision for any trial before any
tribunal. One cannot import the condition of a trial by any tribunal from the fact that a right of
repre- sentation has been given. The right to make representation is nothing more than the right to
"lodge objections" as provided by the Danzig Constitution and the Weimar Constitu- tion. The
representations made will no doubt be considered by the Government. It is said a prosecutor cannot
be himself the judge. Ordinarily, the orders of detention will in a great majority of cases be made by
the District Magistrate or Sub-Divisional Officer or the Commissioner of Police. The representation
of the detenu goes to the Government. Why should it be assumed that a high government official at
the seat of the government will not impartially consider the representation and judge the propriety
of the order of detention made by local officials ? Clause (5) does not imperatively provide for any
oral representation which a hearing will entail. Indeed the exclusion of the provisions of clauses (1)
and (2) negatives any idea of trial or oral defence. The Court may not, by temperament and training,
like this at all but it cannot question the wisdom or the policy of the Constitution. In my judgment as
regards pre- ventive detention laws, the only limitation put upon the legislative power is that it must
provide some procedure and at least incorporate the minimum requirements laid down in article 22
(4) to (7). There is no limitation as regards the substantive law. Therefore, a preventive detention
law which provides some procedure and complies with the require- ments of article 22 (4) to (7)
must be held to be a good law, however odious it may appear to the Court to be.
Learned counsel for the petitioner contends -that the impugned Act does not comply with even the
bare requirements of article 22 (4) to (7). It is pointed out that section 3 of the Act does not lay down
any objective test but leaves it to the authority to define and say whether a particular person comes
within the legislative heads. In other words, it is contended that Parliament has not legislated at all
but has delegated its legislative powers to the executive authorities. I do not think there is any
substance in this contention. In the first place this is not an objection as to procedure but to
substantive law which is not open to the Court's scrutiny. In the next place this contention over-
looks the basic distinction between the delegation of power to make the law and the conferring of an
authority and discretion as to its execution to be exercised under and in pursuance of the law. The
impugned Act has specifically set forth an ascertainable standard by which the conduct of a
particular person is to be judged by the detaining authori- ty.
It is next urged that section 12 of the Act does not comply with the requirements of clause (7) of
article 22 for two reasons, namely--
(i) that clause (7) contemplates a law prescribing the circumstances under which, and the class or
classes of cases in which, a person may be detained for a period longer than three months and then
another law thereafter providing for preventive detention for a period longer than three months;
and
(ii) that under clause (7) Parliament must prescribe both the circumstances under which, and the
class or classes of cases in which, a person may be detained for a period longer than three months.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

As regards the first point I do not see why Parliament must make two laws, one laying down the
principles for longer detention and another for detention for such longer period. It may be that a
State cannot provide for longer detention until Parliament has made the law, but I can see no reason
why Parliament cannot do both by the same Act. In fact, clause (4) (b) contemplates the detention
itself to be in accordance with the provisions of any law made by Parliament under sub- clauses (a)
and (b) of clause (7). Therefore, the detention can well be under the very law which the Parliament
makes under sub-clauses (a) and (b) of clause (7). As to the second point the argument is that
Parliament has a discre- tion under clause (7) to make a law and it is not obliged to make any law
but when our Parliament chooses to make a law it must prescribe both the circumstances under
which, and the class or classes of cases in which, a person may be detained for a period longer than
three months. I am unable to construe clause (7) (a) in the way suggested by learned counsel for the
petitioner. It is an enabling provision empowering Parliament to prescribe two things. Parliament
may prescribe either or both. H a father tells his delicate child that he may play table tennis and
badminton but not the strenuous game of football, it obviously does not mean that tim child, if he
chooses to play at all, must play both table tennis and badminton. It is an option given to the child.
Likewise, the Constitution gives to Parliament the power of prescribing two things. Parliament is not
obliged to prescribe at all but if it chooses to prescribe it may prescribe either or both. Clause 7 (a),
in my opinion, has to be read distributively as follows: The Parliament may prescribe the
circumstance under which a person may be detained for a period longer than three months and
Parlia- ment may prescribe the class or classes of cases in which a person may be detained for a
period longer than three months. That appears to me to be consonant with sound rules of
construction. Further, the circumstances and the class or classes of cases may conceivably coalesce.
Indeed the Full Bench case No. 1 of 1950 before the Calcutta High Court (Kshitindra Narayan v. The
Chief Secretary) itself indicates that the same provision may be read as circumstances or as a
classification. In that case learned counsel conceded that section 12 had prescribed the
circumstances but his com- plaint was that it had not prescribed the class or classes of cases. The
majority of the Court repelled this contention. One learned Judge howev- er, held that section 12
had prescribed the class or classes of cases but had not prescribed the circumstances. It is, therefore,
clear that the classification itself may indicate the circumstances. Again, the classification may be on
a variety of bases. It may be according to provinces the detenus come from. It may be according to
the age of the detenus. It may be according to the object they are supposed to have in view or
according to the activities they are suspected to be engaged in. In this case Parliament has taken five
out of the six legislative heads and divided them into two categories. The detenus are thus classified
ac- cording to their suspected object or activities endangering the several matters specified in the
section. I do not see why classification cannot be made on the footing of the objectives of the
detenus falling in some of the legislative heads, for each legislative head has a specific connotation
well understood in law. If I am correct that there has been a classification then the fact that a person
falls within one or the other class may well be the circumstances under which he may be detained for
a period longer than three months. I do not consider it right, as a matter of con- struction, to read
any further limitation in clause 7 (a) of article 22. In my judgment Par]lament was not obliged under
clause (7) to prescribe both circumstances and classes, and in any case has in fact and substance
prescribed both. I am conscious that a law made by Parliament under article 22 (7)will do away with
the salutary safeguard of the opinion of an advisory board. But it must be remembered that our
Constitution itself contemplates that in certain circumstances or for certain class or classes ofA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

detenus even the advisory board may not be safe and it has trusted Parliament to make a law for that
purpose. Our preference for an advisory board should not blind us to this aspect of the matter. It is
true that circumstances ordinarily relate to extraneous things, like riots, commotion, political or
communal or some sort of abnormal situation and it is said that the framers of the Constitution had
in mind some such situation when the advisory board might be done away with. It is also urged that
they had in mind that the more dangerous types of detenus should be denied the privi- lege of the
advisory board. I am free to confess that prescription of specific circumstances or a more rigid and
definite specification of classes would have been better and more desirable. But that is crying for the
ideal. The Constitution has not in terms put any such limitation as regards the circumstances or the
class or classes of cases and it is idle to speculate as to the intention of the Constitution-makers,
who, by the way, are the very persons who made this law. It is not for the Court to improve upon or
add to the Constitution. If the law duly made by Parlia- ment is repugnant to good sense, public
opinion will compel Parliament to alter it suitably.
Finally, an objection is taken that section 14 of the impugned Act takes away or abridges the right of
the detenu to move this Court by appropriate proceedings. Both clauses (1) and (2) of article 32
speak of enforcement of rights conferred by Part III. The right to move this Court is given to a
person not for the sake of moving only but for moving the Court for the enforcement of some rights
conferred by Part III and this Court has been given power to issue direc- tions or orders or writs for
the enforcement of any of such rights. In order, therefore, to attract the application of article 32, the
person applying must first satisfy that he has got a right under Part III which has to be enforced
under article 32. I have already said that article 19 does not deal with the freedom of the person. I
have also said that articles 21 and 22 provide for protection by insisting on some procedure. Under
article 22 (5) the authority making the order of detention is enjoined, as soon as may be, to
communicate to the detenu the grounds on which that order has been made. This provision has
some purpose, name- ly, that the disclosure of the grounds will afford the detenu the opportunity of
making a representation against the order. Supposing the authority does not give any grounds at all
as distinct from facts referred to in Clause (6). Surely, the detenu loses a fundamental right because
he is prevented from making a representation against the order. of deten- tion. Suppose the
authority hands over to the detenu a piece of paper with some scribblings on it which do not amount
to any ground at all for detention. Then also the detenu can legitimately complain that his right has
been infringed. He can then come to the Court to get redress under article 32, but he cannot show to
the Court the piece of paper with the scribblings on it under section 14 of the Act and the Court
cannot judge whether he has actually got the grounds which he is entitled to under article 22 (5). In.
such a case the detenu may well complain that both his substantive right under article 22 (5)' as well
as his right to constitutional remedies under article 32 have been in- fringed. He can complain of
infringement of his remedial rights under article 32, because he cannot show that there has been an
infringement of his substantive right under article 22 (5). It appears to me, therefore, that section 14
of the Act in so far as it prevents the detenu from disclosing to the Court the grounds communicated
to him is not in conformity with Part III of the Constitution and is, therefore, void under article 13
(2). That section, howev- er, is clearly severable and cannot affect the whole Act. On this question
the views of Meredith C.J. and Das J. of Patna in Criminal Miscellaneous No. 124 of 1950 (Lalit
Kumar Barman v. The State) and the majority of the learned Judges of the Calcutta High Court in
Full Bench Case No. 1 of 1950 (Kshitindra Narayan v. The Chief Secretary) appear to be correct andA.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

sound.
For the reasons I have given above, in my opinion, the impugned Act is a valid law except as to
section 14 in so far as it prevents the grounds being disclosed to the Court. The petitioner before us
does not complain that he has not got proper grounds. Further, the period of his detention under the
impugned Act has not gone beyond three months and, in the circumstances, this application should,
in my opinion, stand dismissed. Petition dismissed.
Agent for the petitioner: S. Subrahmanyam.
Agent for the State of Madras and Union of India: P.A. Mehta.A.K. Gopalan vs The State Of Madras.Union Of India: ... on 19 May, 1950

