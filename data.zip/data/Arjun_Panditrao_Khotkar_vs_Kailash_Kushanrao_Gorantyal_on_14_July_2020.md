Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14
July, 2020
Equivalent citations: AIR 2020 SUPREME COURT 4908, AIRONLINE 2020 SC
641
Author: R.F. Nariman
Bench: Rohinton Fali Nariman, S. Ravindra Bhat, V. Ramasubramanian
                                                                     REPORTABLE
                                 IN THE SUPREME COURT OF INDIA
                                 CIVIL APPELLATE JURISDICTION
                            CIVIL APPEAL NOS. 20825-20826 OF 2017
                  ARJUN PANDITRAO KHOTKAR                            …Appellant
                                              Versus
                  KAILASH KUSHANRAO GORANTYAL AND ORS.               …Respondents
                                              WITH
                                 CIVIL APPEAL NO.2407 OF 2018
                                 CIVIL APPEAL NO.3696 OF 2018
                                         JUDGMENT
R.F. Nariman, J.
1. I.A. No.134044 of 2019 for intervention in C.A. Nos. 20825- 20826 of 2017 is allowed.
2. These Civil Appeals have been referred to a Bench of three honourable Judges of this Court by a
Division Bench reference order dated 26.07.2019, dealing with the interpretation of Section 65B of
the Indian Date: 2020.07.14 16:56:15 IST Reason:
Evidence Act, 1872 (“Evidence Act”) by two judgments of this Court. In the reference
order, after quoting from Anvar P.V. v. P.K. Basheer & Ors.
(2014) 10 SCC 473 (a three Judge Bench decision of this Court), it was found that a
Division Bench judgment in SLP (Crl.) No. 9431 of 2011 reported as ShafhiArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Mohammad v. State of Himachal Pradesh (2018) 2 SCC 801 may need
reconsideration by a Bench of a larger strength.
3. The brief facts necessary to appreciate the controversy in the present case, as elucidated in Civil
Appeals 20825-20826 of 2017, are as follows:
i. Two election petitions were filed by the present Respondents before the Bombay
High Court under Sections 80 and 81 of the Representation of the People Act, 1951,
challenging the election of the present Appellant, namely, Shri Arjun Panditrao
Khotkar (who is the Returned Candidate [hereinafter referred to as the “RC”]
belonging to the Shiv Sena party from 101-Jalna Legislative Assembly Constituency)
to the Maharashtra State Legislative Assembly for the term commencing November,
2014. Election Petition No.6 of 2014 was filed by the defeated Congress (I) candidate
Shri Kailash Kishanrao Gorantyal, whereas Election Petition No.9 of 2014 was filed
by one Shri Vijay Chaudhary, an elector in the said constituency. The margin of
victory for the RC was extremely narrow, namely 296 votes - the RC having secured
45,078 votes, whereas Shri Kailash Kishanrao Gorantyal secured 44,782 votes.
ii. The entirety of the case before the High Court had revolved around four sets of
nomination papers that had been filed by the RC. It was the case of the present
Respondents that each set of nomination papers suffered from defects of a
substantial nature and that, therefore, all four sets of nomination papers, having been
improperly accepted by the Returning Officer of the Election Commission, one Smt.
Mutha, (hereinafter referred to as the “RO”), the election of the RC be declared void.
In particular, it was the contention of the present Respondents that the late
presentation of Nomination Form Nos. 43 and 44 by the RC -
inasmuch as they were filed by the RC after the stipulated time of 3.00 p.m. on
27.09.2014 - rendered such nomination forms not being filed in accordance with the
law, and ought to have been rejected.
iii. In order to buttress this submission, the Respondents sought to rely upon
video-camera arrangements that were made both inside and outside the office of the
RO. According to the Respondents, the nomination papers were only offered at 3.53
p.m. (i.e. beyond 3.00 p.m.), as a result of which it was clear that they had been filed
out of time. A specific complaint making this objection was submitted by Shri Kailash
Kishanrao Gorantyal before the RO on 28.09.2014 at 11.00 a.m., in which it was
requested that the RO reject the nomination forms that had been improperly
accepted. This request was rejected by the RO on the same day, stating that the
nomination forms had, in fact, been filed within time.
4. Given the fact that allegations and counter allegations were made as to the time at which the
nomination forms were given to the RO, and that videography was available, the High Court, by its
order dated 16.03.2016, ordered the Election Commission and the concerned officers to produce theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

entire record of the election of this Constituency, including the original video recordings. A specific
order was made that this electronic record needs to be produced along with the ‘necessary
certificates’.
5. In compliance with this order, such video recordings were produced by the Election Commission,
together with a certificate issued with regard to the CDs/VCDs, which read as follows:
“Certificate This is to certify that the CDs in respect of video recording done on two
days of filing nomination forms of date 26.9.2014 and 27.9.2014 which were present
in the record are produced.
           Sd/-                              Sd/-
           Asst. Returning Officer           Returning Officer
6.                                           101 Jalna Legislative Assembly
           101 Jalna Legislative Assembly
           Constituency/Tahsildar            Constituency/Tahsildar
           Jalna                             Jalna”
Transcripts of the contents of these
CDs/VCDs were prepared by the High Court itself. Issue nos.6 and 7 as framed by the
High Court (and its answers to these issues) are important, and are set out in the
impugned judgment dated 24.11.2017, and extracted hereinbelow:
           “Issues                             Findings
           6. Whether the petitioner proves    Affirmative. (nomination
that the nomination papers at Sr. papers at Sr. Nos. 43 Nos. 43 and 44 were not and
44 were not presented by RC before presented by respondent/ 3.00 p.m. of
27.9.2014.) Returned candidate before 3.00 p.m. on 27/09/2014 ?
7. Whether the petitioner proves Affirmative. (A, B forms that the respondent
/Returned were presented after candidate submitted original 3.00 p.m. of
27.9.2014)” forms A and B along with nomination paper only on 27/09/2014 after
3.00 p.m. and along with nomination paper at Sr. No. 44 ?
7. In answering issues 6 and 7, the High Court recorded:
“60. Many applications were given by the petitioner of Election Petition No. 6/2014
to get the copies of electronic record in respect of aforesaid incidents with certificate
as provided in section 65-B of the Evidence Act. The correspondence made with them
show that even after leaving of the office by Smt. Mutha, the Government machinery,
incharge of the record, intentionally avoided to give certificate as mentioned in
section 65-B of the Evidence Act. After production of the record in the Court in this
regard, this Court had allowed to Election Commission by order to give copies of suchArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

record to applicants, but after that also the authority avoided to give copies by giving
lame excuses. It needs to be kept in mind that the RC is from political party which
has alliance with ruling party, BJP, not only in the State, but also at the center. It is
unfortunate that the machinery which is expected to be fair did not act fairly in the
present matter. The circumstances of the present matter show that the aforesaid two
officers tried to cover up their mischief. However the material gives only one
inference that nomination forms Nos. 43 and 44 with A, B forms were presented
before the RO by RC after 3.00 p.m. of 27.9.2014 and they were not handed over
prior to 3.00 p.m. In view of objection of the learned counsels of the RC to using the
information contained in aforesaid VCDs, marked as Article A1 to A6, this Court had
made order on 11.7.2017 that the objections will be considered in the judgment itself.
This VCDs are already exhibited by this Court as Exhs. 70 to 75. Thus, if the contents
of the aforesaid VCDs can be used in the evidence, then the petitioners are bound to
succeed in the present matters.”
8. The High Court then set out Sections 65-A and 65-B of the Evidence Act, and
referred to this Court’s judgment in Anvar P.V. (supra).
The Court held in paragraph 65 of the impugned judgment that the CDs that were produced by the
Election Commission could not be treated as an original record and would, therefore, have to be
proved by means of secondary evidence. Finding that no written certificate as is required by Section
65-B(4) of the Evidence Act was furnished by any of the election officials, and more particularly, the
RO, the High Court then held:
“69. In substantive evidence, in the cross examination of Smt. Mutha, it is brought on
the record that there was no complaint with regard to working of video cameras used
by the office. She has admitted that the video cameras were regularly used in the
office for recording the aforesaid incidents and daily VCDs were collected of the
recording by her office. This record was created as the record of the activities of the
Election Commission. It is brought on the record that on the first floor of the
building, arrangement was made by keeping electronic gazettes like VCR players etc.
and arrangement was made for viewing the recording. It is already observed that
under her instructions, the VCDs were marked of this recording. Thus, on the basis of
her substantive evidence, it can be said that the conditions mentioned in section 65-B
of the Evidence Act are fulfilled and she is certifying the electronic record as required
by section 65-B (4) of the Evidence Act. It can be said that Election Commission, the
machinery avoided to give certificate in writing as required by section 65-B (4) of the
Evidence Act. But, substantive evidence is brought on record of competent officer in
that regard. When the certificate expected is required to be issued on the basis of best
of knowledge and belief, there is evidence on oath about it of Smt. Mutha. Thus, there
is something more than the contents of certificate mentioned in section 65-B (4) of
the Evidence Act in the present matters. Such evidence is not barred by the
provisions of section 65-B of the Evidence Act as that evidence is only on certification
made by the responsible official position like RO. She was incharge of theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

management of the relevant activities and so her evidence can be used and needs to
be used as the compliance of the provision of section 65-B of the Evidence Act. This
Court holds that there is compliance of the provision of section 65-B of the Evidence
Act in the present matter in respect of aforesaid electronic record and so, the
information contained in the record can be used in the evidence.” Based, therefore,
on “substantial compliance” of the requirement of giving a certificate under Section
65B of the Evidence Act, it was held that the CDs/VCDs were admissible in evidence,
and based upon this evidence it was found that, as a matter of fact, the nomination
forms by the RC had been improperly accepted. The election of the RC was therefore
was declared void in the impugned judgment.
9. Shri Ravindra Adsure, learned advocate appearing on behalf of the Appellant,
submitted that the judgment in Anvar P.V. (supra) covered the case before us. He
argued that without the necessary certificate in writing and signed under Section
65B(4) of the Evidence Act, the CDs/VCDs upon which the entirety of the judgment
rested could not have been admitted in evidence. He referred to Tomaso Bruno and
Anr. v.
State of Uttar Pradesh (2015) 7 SCC 178, and argued that the said judgment did not notice either
Section 65B or Anvar P.V. (supra), and was therefore per incuriam. He also argued that Shafhi
Mohammad (supra), being a two-Judge Bench of this Court, could not have arrived at a finding
contrary to Anvar P.V. (supra), which was the judgment of three Hon’ble Judges of this Court. In
particular, he argued that it could not have been held in Shafhi Mohammad (supra) that whenever
the interest of justice required, the requirement of a certificate could be done away with under
Section 65B(4). Equally, this Court’s judgment dated 03.04.2018, reported as (2018) 5 SCC 311,
which merely followed the law laid down in Shafhi Mohammad (supra), being contrary to the larger
bench judgment in Anvar P.V. (supra), should also be held as not having laid down good law. He
further argued that the Madras High Court judgment in K. Ramajyam v. Inspector of Police (2016)
Crl. LJ 1542, being contrary to Anvar P.V. (supra), also does not lay down the law correctly, in that it
holds that evidence aliunde, that is outside Section 65B, can be taken in order to make electronic
records admissible. In the facts of the present case, he contended that since it was clear that the
requisite certificate had not been issued, no theory of “substantial compliance” with the provisions
of Section 65B(4), as was held by the impugned judgment, could possibly be sustained in law.
10. Ms. Meenakshi Arora, learned Senior Advocate appearing on behalf of the Respondents, has
taken us in copious detail through the facts of this case, and has argued that the High Court has
directed the Election Commission to produce before the Court the original CDs/VCDs of the
video-recording done at the office of the RO, along with the necessary certificate. An application
dated 16.08.2016 was also made to the District Election Commission and RO as well as the Assistant
RO for the requisite certificate under Section 65B. A reply was given on 14.09.2016, that this
certificate could not be furnished since the matter was sub-judice. Despite this, later on, on
26.07.2017 her client wrote to the authorities again requesting for issuance of certificate under
Section 65B, but by replies dated 31.07.2017 and 02.08.2017, no such certificate was forthcoming.
Finally, after having run from pillar to post, her client applied on 26.08.2017 to the Chief ElectionArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Commissioner, New Delhi, stating that the authorities were refusing to give her client the necessary
certificate under Section 65B and that the Chief Election Commissioner should therefore ensure that
it be given to them. To this communication, no reply was forthcoming from the Chief Election
Commissioner, New Delhi. Given this, the High Court at several places had observed in the course of
the impugned judgment that the authorities deliberately refused, despite being directed, to supply
the requisite certificate under Section 65B, as a result of which the impugned judgment correctly
relied upon the oral testimony of the RO herself. According to Ms. Arora, such oral testimony taken
down in the form of writing, which witness statement is signed by the RO, would itself amount to
the requisite certificate being issued under Section 65B(4) in the facts of this case, as was correctly
held by the High Court. Quite apart from this, Ms. Arora also stated that - independent of the
finding given by the High Court by relying upon CDs/VCDs - the High Court also relied upon other
documentary and oral evidence to arrive at the finding that the RC had not handed over nomination
forms directly to the RO at 2.20 p.m (i.e. before 3pm). In fact, it was found on the basis of this
evidence that the nomination forms were handed over and accepted by the RO only after 3.00 p.m.
and were therefore improperly accepted, as a result of which, the election of the Appellant was
correctly set aside.
11. On law, Ms. Arora argued that it must not be forgotten that Section 65B is a procedural
provision, and it cannot be the law that even where a certificate is impossible to get, the absence of
such certificate should result in the denial of crucial evidence which would point at the truth or
falsehood of a given set of facts. She, therefore, supported the decision in Shafhi Mohammad
(supra), stating that Anvar P.V. (supra) could be considered to be good law only in situations where
it was possible for the party to produce the requisite certificate. In cases where this becomes difficult
or impossible, the interest of justice would require that a procedural provision be not exalted to such
a level that vital evidence would be shut out, resulting in manifest injustice.
12. Shri Vikas Upadhyay, appearing on behalf of the Intervenor, took us through the various
provisions of the Information Technology Act, 2000 along with Section 65B of the Evidence Act, and
argued that Section 65B does not refer to the stage at which the certificate under Section 65B(4)
ought to be furnished. He relied upon a judgment of the High Court of Rajasthan as well as the High
Court of Bombay, in addition to Kundan Singh v. State 2015 SCC OnLine Del 13647 of the Delhi
High Court, to argue that the requisite certificate need not necessarily be given at the time of
tendering of evidence but could be at a subsequent stage of the proceedings, as in cases where the
requisite certificate is not forthcoming due to no fault of the party who tried to produce it, but who
had to apply to a Judge for its production. He also argued that Anvar P.V. (supra) required to be
clarified to the extent that Sections 65A and 65B being a complete code as to admissibility of
electronic records, the “baggage” of Primary and Secondary Evidence contained in Sections 62 and
65 of the Evidence Act should not at all be adverted to, and that the drill of Section 65A and 65B
alone be followed when it comes to admissibility of information contained in electronic records.
13. It is now necessary to set out the relevant provisions of the Evidence Act and the Information
Technology Act, 2000. Section 3 of the Evidence Act defines “document” as follows:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

“Document.-- "Document" means any matter expressed or described upon any
substance by means of letters, figures or marks, or by more than one of those means,
intended to be used, or which may be used, for the purpose of recording that matter.”
“Evidence” in Section 3 is defined as follows:
“Evidence."-- "Evidence" means and includes—(1) all statements which the Court
permits or requires to be made before it by witnesses, in relation to matters of fact
under inquiry;
such statements are called oral evidence;
(2) all documents including electronic records produced for the inspection of the
Court; such documents are called documentary evidence.” The Evidence Act also
declares that the expressions “Certifying Authority”, “electronic signature”,
“Electronic Signature Certificate”, “electronic form”, “electronic records”,
“information”, “secure electronic record”, “secure digital signature” and “subscriber”
shall have the meanings respectively assigned to them in the Information Technology
Act.
14. Section 22-A of the Evidence Act, which deals with the relevance of oral admissions as to
contents of electronic records, reads as follows:
“22A. When oral admission as to contents of electronic records are relevant. -- Oral
admissions as to the contents of electronic records are not relevant, unless the
genuineness of the electronic record produced is in question.”
15. Section 45A of the Evidence Act, on the opinion of the Examiner of Electronic Evidence, then
states:
“45A. Opinion of Examiner of Electronic Evidence.--
When in a proceeding, the court has to form an opinion on any matter relating to any
information transmitted or stored in any computer resource or any other electronic
or digital form, the opinion of the Examiner of Electronic Evidence referred to in
section 79A of the Information Technology Act, 2000 (21 of 2000), is a relevant fact.
Explanation.-- For the purposes of this section, an Examiner of Electronic Evidence
shall be an expert.”
16. Sections 65-A and 65-B of the Evidence Act read as follows:
“65A. Special provisions as to evidence relating to electronic record.--The contents of
electronic records may be proved in accordance with the provisions of section 65B.”
“65B. Admissibility of electronic records.- (1) Notwithstanding anything contained inArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

this Act, any information contained in an electronic record which is printed on a
paper, stored, recorded or copied in optical or magnetic media produced by a
computer (hereinafter referred to as the computer output) shall be deemed to be also
a document, if the conditions mentioned in this section are satisfied in relation to the
information and computer in question and shall be admissible in any proceedings,
without further proof or production of the original, as evidence or any contents of the
original or of any fact stated therein of which direct evidence would be admissible.
(2) The conditions referred to in sub-section (1) in respect of a computer output shall
be the following, namely:
(a) the computer output containing the information was produced by the computer
during the period over which the computer was used regularly to store or process
information for the purposes of any activities regularly carried on over that period by
the person having lawful control over the use of the computer;
(b) during the said period, information of the kind contained in the electronic record
or of the kind from which the information so contained is derived was regularly fed
into the computer in the ordinary course of the said activities;
(c) throughout the material part of the said period, the computer was operating
properly or, if not, then in respect of any period in which it was not operating
properly or was out of operation during that part of the period, was not such as to
affect the electronic record or the accuracy of its contents; and
(d) the information contained in the electronic record reproduces or is derived from
such information fed into the computer in the ordinary course of the said activities.
(3) Where over any period, the function of storing or processing information for the
purposes of any activities regularly carried on over that period as mentioned in clause
(a) of sub-section (2) was regularly performed by computers, whether-
(a) by a combination of computers operating over that period; or
(b) by different computers operating in succession over that period; or
(c) by different combinations of computers operating in succession over that period;
or
(d) in any other manner involving the successive operation over that period, in
whatever order, of one or more computers and one or more combinations of
computers, all the computers used for that purpose during that period shall be
treated for the purposes of this section as constituting a single computer; and
references in this section to a computer shall be construed accordingly.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(4) In any proceedings where it is desired to give a statement in evidence by virtue of
this section, a certificate doing any of the following things, that is to say, -
(a) identifying the electronic record containing the statement and describing the
manner in which it was produced;
(b) giving such particulars of any device involved in the production of that electronic
record as may be appropriate for the purpose of showing that the electronic record
was produced by a computer;
(c) dealing with any of the matters to which the conditions mentioned in sub-section
(2) relate, and purporting to be signed by a person occupying a responsible official
position in relation to the operation of the relevant device or the management of the
relevant activities (whichever is appropriate) shall be evidence of any matter stated in
the certificate; and for the purposes of this subsection it shall be sufficient for a
matter to be stated to the best of the knowledge and belief of the person stating it.
(5) For the purposes of this section,
(a) information shall be taken to be supplied to a computer if it is supplied thereto in
any appropriate form and whether it is so supplied directly or (with or without
human intervention) by means of any appropriate equipment; --
(b) whether in the course of activities carried on by any official, information is
supplied with a view to its being stored or processed for the purposes of those
activities by a computer operated otherwise than in the course of those activities, that
information, if duly supplied to that computer, shall be taken to be supplied to it in
the course of those activities;
(c) a computer output shall be taken to have been produced by a computer whether it
was produced by it directly or (with or without human intervention) by means of any
appropriate equipment.
Explanation. -- For the purposes of this section any reference to information being derived from
other information shall be a reference to its being derived therefrom by calculation, comparison or
any other process.”
17. The following definitions as contained in Section 2 of the Information Technology Act, 2000 are
also relevant:
“(i) “computer” means any electronic, magnetic, optical or other high-speed data
processing device or system which performs logical, arithmetic, and memory
functions by manipulations of electronic, magnetic or optical impulses, and includes
all input, output, processing, storage, computer software or communication facilitiesArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

which are connected or related to the computer in a computer system or computer
network;” “(j) “computer network” means the inter-connection of one or more
computers or computer systems or communication device through– (i) the use of
satellite, microwave, terrestrial line, wire, wireless or other communication media;
and (ii) terminals or a complex consisting of two or more interconnected computers
or communication device whether or not the inter-connection is continuously
maintained;” “(l) “computer system” means a device or collection of devices,
including input and output support devices and excluding calculators which are not
programmable and capable of being used in conjunction with external files, which
contain computer programmes, electronic instructions, input data and output data,
that performs logic, arithmetic, data storage and retrieval, communication control
and other functions;” “(o) “data” means a representation of information, knowledge,
facts, concepts or instructions which are being prepared or have been prepared in a
formalised manner, and is intended to be processed, is being processed or has been
processed in a computer system or computer network, and may be in any form
(including computer printouts magnetic or optical storage media, punched cards,
punched tapes) or stored internally in the memory of the computer;” “(r) “electronic
form”, with reference to information, means any information generated, sent,
received or stored in media, magnetic, optical, computer memory, micro film,
computer generated micro fiche or similar device;” “(t) “electronic record” means
data, record or data generated, image or sound stored, received or sent in an
electronic form or micro film or computer generated micro fiche;”
18. Sections 65A and 65B occur in Chapter V of the Evidence Act which is entitled “Of Documentary
Evidence”. Section 61 of the Evidence Act deals with the proof of contents of documents, and states
that the contents of documents may be proved either by primary or by secondary evidence. Section
62 of the Evidence Act defines primary evidence as meaning the document itself produced for the
inspection of the court. Section 63 of the Evidence Act speaks of the kind or types of secondary
evidence by which documents may be proved. Section 64 of the Evidence Act then enacts that
documents must be proved by primary evidence except in the circumstances hereinafter mentioned.
Section 65 of the Evidence Act is important, and states that secondary evidence may be given of “the
existence, condition or contents of a document in the following cases…”.
19. Section 65 differentiates between existence, condition and contents of a document. Whereas
“existence” goes to “admissibility” of a document, “contents” of a document are to be proved after a
document becomes admissible in evidence. Section 65A speaks of “contents” of electronic records
being proved in accordance with the provisions of Section 65B. Section 65B speaks of “admissibility”
of electronic records which deals with “existence” and “contents” of electronic records being proved
once admissible into evidence. With these prefatory observations let us have a closer look at
Sections 65A and 65B.
20. It will first be noticed that the subject matter of Sections 65A and 65B of the Evidence Act is
proof of information contained in electronic records. The marginal note to Section 65A indicates
that “special provisions” as to evidence relating to electronic records are laid down in this provision.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

The marginal note to Section 65B then refers to “admissibility of electronic records”.
21. Section 65B(1) opens with a non-obstante clause, and makes it clear that any information that is
contained in an electronic record which is printed on a paper, stored, recorded or copied in optical
or magnetic media produced by a computer shall be deemed to be a document, and shall be
admissible in any proceedings without further proof of production of the original, as evidence of the
contents of the original or of any facts stated therein of which direct evidence would be admissible.
The deeming fiction is for the reason that “document” as defined by Section 3 of the Evidence Act
does not include electronic records.
22. Section 65B(2) then refers to the conditions that must be satisfied in respect of a computer
output, and states that the test for being included in conditions 65B(2(a)) to 65(2(d)) is that the
computer be regularly used to store or process information for purposes of activities regularly
carried on in the period in question. The conditions mentioned in sub-sections 2(a) to 2(d) must be
satisfied cumulatively.
23. Under Sub-section (4), a certificate is to be produced that identifies the electronic record
containing the statement and describes the manner in which it is produced, or gives particulars of
the device involved in the production of the electronic record to show that the electronic record was
produced by a computer, by either a person occupying a responsible official position in relation to
the operation of the relevant device; or a person who is in the management of “relevant activities” –
whichever is appropriate. What is also of importance is that it shall be sufficient for such matter to
be stated to the “best of the knowledge and belief of the person stating it”. Here, “doing any of the
following things…” must be read as doing all of the following things, it being well settled that the
expression “any” can mean “all” given the context (see, for example, this Court’s judgments in
Bansilal Agarwalla v. State of Bihar (1962) 1 SCR 331 and 1 “3. The first contention is based on an
assumption that the word “any one” in Section 76 means only “one of the directors, and only one of
the shareholders”. This question as regards the interpretation of the word “any one” in Section 76
was raised in Criminal Appeals Nos. 98 to 106 of 1959 (Chief Inspector of Mines, etc.) and it has
been decided there that the word “any one” should be interpreted there as “every one”. Thus under
Section 76 every one of the shareholders of a private company owning the mine, and every one of the
directors of a public Om Parkash v. Union of India (2010) 4 SCC 172). This being the case, the
conditions mentioned in sub-section (4) must also be interpreted as being cumulative.
24. It is now appropriate to examine the manner in which Section 65B was interpreted by this Court.
In Anvar P.V. (supra), a three Judge Bench of this Court, after setting out Sections 65A and 65B of
the Evidence Act, held:
“14. Any documentary evidence by way of an electronic record under the Evidence
Act, in view of Sections 59 and 65-A, can be proved only in accordance with the
procedure prescribed under Section 65-B. Section 65-B deals with the admissibility of
the electronic record. The purpose of these provisions is to sanctify secondary
evidence in electronic form, generated by a computer. It may be noted that the
section starts with a non obstante clause. Thus, notwithstanding anything containedArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

in the Evidence Act, any information contained in an electronic record which is
printed on a paper, stored, recorded or copied in optical or magnetic media produced
by a computer shall be deemed to be a document only if the conditions mentioned
under sub-section (2) are satisfied, company owning the mine is liable to
prosecution. No question of violation of Article 14 therefore arises.” 2 “70. Perusal of
the opinion of the Full Bench in B.R. Gupta-I [Balak Ram Gupta v. Union of India,
AIR 1987 Del 239] would clearly indicate with regard to interpretation of the word
“any” in Explanation 1 to the first proviso to Section 6 of the Act which expands the
scope of stay order granted in one case of landowners to be automatically extended to
all those landowners, whose lands are covered under the notifications issued under
Section 4 of the Act, irrespective of the fact whether there was any separate order of
stay or not as regards their lands. The logic assigned by the Full Bench, the relevant
portions whereof have been reproduced hereinabove, appear to be reasonable, apt,
legal and proper.” (emphasis added) without further proof or production of the
original. The very admissibility of such a document i.e. electronic record which is
called as computer output, depends on the satisfaction of the four conditions under
Section 65-B(2).
Following are the specified conditions under Section 65- B(2) of the Evidence Act:
(i) The electronic record containing the information should have been produced by
the computer during the period over which the same was regularly used to store or
process information for the purpose of any activity regularly carried on over that
period by the person having lawful control over the use of that computer;
(ii) The information of the kind contained in electronic record or of the kind from
which the information is derived was regularly fed into the computer in the ordinary
course of the said activity;
(iii) During the material part of the said period, the computer was operating properly
and that even if it was not operating properly for some time, the break or breaks had
not affected either the record or the accuracy of its contents; and
(iv) The information contained in the record should be a reproduction or derivation
from the information fed into the computer in the ordinary course of the said activity.
15. Under Section 65-B(4) of the Evidence Act, if it is desired to give a statement in any proceedings
pertaining to an electronic record, it is permissible provided the following conditions are satisfied:
(a) There must be a certificate which identifies the electronic record containing the
statement;
(b) The certificate must describe the manner in which the electronic record was
produced;Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(c) The certificate must furnish the particulars of the device involved in the
production of that record;
(d) The certificate must deal with the applicable conditions mentioned under Section
65-B(2) of the Evidence Act; and
(e) The certificate must be signed by a person occupying a responsible official
position in relation to the operation of the relevant device.
16. It is further clarified that the person need only to state in the certificate that the same is to the
best of his knowledge and belief. Most importantly, such a certificate must accompany the electronic
record like computer printout, compact disc (CD), video compact disc (VCD), pen drive, etc.,
pertaining to which a statement is sought to be given in evidence, when the same is produced in
evidence. All these safeguards are taken to ensure the source and authenticity, which are the two
hallmarks pertaining to electronic record sought to be used as evidence. Electronic records being
more susceptible to tampering, alteration, transposition, excision, etc. without such safeguards, the
whole trial based on proof of electronic records can lead to travesty of justice.
17. Only if the electronic record is duly produced in terms of Section 65-B of the Evidence Act, would
the question arise as to the genuineness thereof and in that situation, resort can be made to Section
45-A—opinion of Examiner of Electronic Evidence.
18. The Evidence Act does not contemplate or permit the proof of an electronic record by oral
evidence if requirements under Section 65-B of the Evidence Act are not complied with, as the law
now stands in India. xxx xxx xxx
20. Proof of electronic record is a special provision introduced by the IT Act amending various
provisions under the Evidence Act. The very caption of Section 65-A of the Evidence Act, read with
Sections 59 and 65-B is sufficient to hold that the special provisions on evidence relating to
electronic record shall be governed by the procedure prescribed under Section 65-B of the Evidence
Act. That is a complete code in itself. Being a special law, the general law under Sections 63 and 65
has to yield.
21. In State (NCT of Delhi) v. Navjot Sandhu a two-Judge Bench of this Court had an occasion to
consider an issue on production of electronic record as evidence. While considering the printouts of
the computerised records of the calls pertaining to the cellphones, it was held at para 150 as follows:
(SCC p. 714) “150. According to Section 63, “secondary evidence” means and includes, among other
things, ‘copies made from the original by mechanical processes which in themselves insure the
accuracy of the copy, and copies compared with such copies’. Section 65 enables secondary evidence
of the contents of a document to be adduced if the original is of such a nature as not to be easily
movable. It is not in dispute that the information contained in the call records is stored in huge
servers which cannot be easily moved and produced in the court. That is what the High Court has
also observed at paraArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

276. Hence, printouts taken from the computers/servers by mechanical process and certified by a
responsible official of the service-providing company can be led in evidence through a witness who
can identify the signatures of the certifying officer or otherwise speak of the facts based on his
personal knowledge. Irrespective of the compliance with the requirements of Section 65-B, which is
a provision dealing with admissibility of electronic records, there is no bar to adducing secondary
evidence under the other provisions of the Evidence Act, namely, Sections 63 and 65. It may be that
the certificate containing the details in sub-section (4) of Section 65-B is not filed in the instant case,
but that does not mean that secondary evidence cannot be given even if the law permits such
evidence to be given in the circumstances mentioned in the relevant provisions, namely, Sections 63
and 65.” It may be seen that it was a case where a responsible official had duly certified the
document at the time of production itself. The signatures in the certificate were also identified. That
is apparently in compliance with the procedure prescribed under Section 65-B of the Evidence Act.
However, it was held that irrespective of the compliance with the requirements of Section 65-B,
which is a special provision dealing with admissibility of the electronic record, there is no bar in
adducing secondary evidence, under Sections 63 and 65, of an electronic record.”
22. The evidence relating to electronic record, as noted hereinbefore, being a special provision, the
general law on secondary evidence under Section 63 read with Section 65 of the Evidence Act shall
yield to the same. Generalia specialibus non derogant, special law will always prevail over the
general law. It appears, the court omitted to take note of Sections 59 and 65-A dealing with the
admissibility of electronic record. Sections 63 and 65 have no application in the case of secondary
evidence by way of electronic record; the same is wholly governed by Sections 65-A and 65-B. To
that extent, the statement of law on admissibility of secondary evidence pertaining to electronic
record, as stated by this Court in Navjot Sandhu case, does not lay down the correct legal position. It
requires to be overruled and we do so. An electronic record by way of secondary evidence shall not
be admitted in evidence unless the requirements under Section 65-B are satisfied. Thus, in the case
of CD, VCD, chip, etc., the same shall be accompanied by the certificate in terms of Section 65-B
obtained at the time of taking the document, without which, the secondary evidence pertaining to
that electronic record, is inadmissible.
23. The appellant admittedly has not produced any certificate in terms of Section 65-B in respect of
the CDs, Exts. P-4, P-8, P-9, P-10, P-12, P-13, P-15, P-20 and P-
22. Therefore, the same cannot be admitted in evidence. Thus, the whole case set up regarding the
corrupt practice using songs, announcements and speeches fall to the ground.
24. The situation would have been different had the appellant adduced primary evidence, by making
available in evidence, the CDs used for announcement and songs. Had those CDs used for
objectionable songs or announcements been duly got seized through the police or Election
Commission and had the same been used as primary evidence, the High Court could have played the
same in court to see whether the allegations were true. That is not the situation in this case. The
speeches, songs and announcements were recorded using other instruments and by feeding them
into a computer, CDs were made therefrom which were produced in court, without due certification.
Those CDs cannot be admitted in evidence since the mandatory requirements of Section 65- B of theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Evidence Act are not satisfied. It is clarified that notwithstanding what we have stated herein in the
preceding paragraphs on the secondary evidence of electronic record with reference to Sections 59,
65-A and 65-B of the Evidence Act, if an electronic record as such is used as primary evidence under
Section 62 of the Evidence Act, the same is admissible in evidence, without compliance with the
conditions in Section 65-B of the Evidence Act.”
25. Shri Upadhyay took exception to the language of paragraph 24 in this judgment. According to
the learned counsel, primary and secondary evidence as to documents, referred to in Sections 61 to
Section 65 of the Evidence Act, should be kept out of admissibility of electronic records, given the
fact that Sections 65A and 65B are a complete code on the subject.
26. At this juncture, it is important to note that Section 65B has its genesis in Section 5 of the Civil
Evidence Act 1968 (UK), which reads as follows:
“Admissibility of statements produced by computers.
(1) In any civil proceedings a statement contained in a document produced by a
computer shall, subject to rules of court, be admissible as evidence of any fact stated
therein of which direct oral evidence would be admissible, if it is shown that the
conditions mentioned in subsection (2) below are satisfied in relation to the
statement and computer in question.
(2) The said conditions are—
(a) that the document containing the statement was produced by the computer
during a period over which the computer was used regularly to store or process
information for the purposes of any activities regularly carried on over that period,
whether for profit or not, by any body, whether corporate or not, or by any individual;
(b) that over that period there was regularly supplied to the computer in the ordinary
course of those activities information of the kind contained in the statement or of the
kind from which the information so contained is derived;
(c) that throughout the material part of that period the computer was operating
properly or, if not, that any respect in which it was not operating properly or was out
of operation during that part of that period was not such as to affect the production of
the document or the accuracy of its contents; and
(d) that the information contained in the statement reproduces or is derived from
information supplied to the computer in the ordinary course of those activities.
(3) Where over a period the function of storing or processing information for the
purposes of any activities regularly carried on over that period as mentioned in
subsection (2)(a) above was regularly performed by computers, whether-Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(a) by a combination of computers operating over that period; or
(b) by different computers operating in succession over that period; or
(c) by different combinations of computers operating in succession over that period;
or
(d) in any other manner involving the successive operation over that period, in
whatever order, of one or more computers and one or more combinations of
computers, all the computers used for that purpose during that period shall be
treated for the purposes of this Part of this Act as constituting a single computer; and
references in this Part of this Act to a computer shall be construed accordingly.
(4) In any civil proceedings where it is desired to give a statement in evidence by
virtue of this section, a certificate doing any of the following things, that is to say—
(a) identifying the document containing the statement and describing the manner in
which it was produced;
(b) giving such particulars of any device involved in the production of that document
as may be appropriate for the purpose of showing that the document was produced
by a computer;
(c) dealing with any of the matters to which the conditions mentioned in subsection
(2) above relate, and purporting to be signed by a person occupying a responsible
position in relation to the operation of the relevant device or the management of the
relevant activities (whichever is appropriate) shall be evidence of any matter stated in
the certificate; and for the purposes of this subsection it shall be sufficient for a
matter to be stated to the best of the knowledge and belief of the person stating it.
(5) For the purposes of this Part of this Act—
(a) information shall be taken to be supplied to a computer if it is supplied thereto in
any appropriate form and whether it is so supplied directly or (with or without
human intervention) by means of any appropriate equipment;
(b) where, in the course of activities carried on by any individual or body, information
is supplied with a view to its being stored or processed for the purposes of those
activities by a computer operated otherwise than in the course of those activities, that
information, if duly supplied to that computer, shall be taken to be supplied to it in
the course of those activities;
(c) a document shall be taken to have been produced by a computer whether it was
produced by it directly or (with or without human intervention) by means of anyArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

appropriate equipment.
(6) Subject to subsection (3) above, in this Part of this Act “computer ” means any
device for storing and processing information, and any reference to information
being derived from other information is a reference to its being derived therefrom by
calculation, comparison or any other process.”
27. It may be noticed that sub-sections (2) to (5) of Section 65B of the Evidence Act are a
reproduction of sub-sections (2) to (5) of Section 5 of the Civil Evidence Act, 1968, with minor
changes 3. The definition of 3 Section 69 of the UK Police and Criminal Evidence Act, 1984 dealt
with evidence from computer records in criminal proceedings. Section 69 read thus:
“69.-(1) In any proceedings, a statement in a document produced by a computer shall
not be admissible as evidence of any fact stated therein unless it is shown-
(a) that there are no reasonable grounds for believing that the statement is inaccurate
because of improper use of that computer;
(b) that at all material times the computer was operating properly, or if not, that any
respect in which it was not operating properly or was out of operation was not such as
to affect the production of the document or the accuracy of its contents; and
(c) that any relevant conditions specified in rules of court under subsection (2) below
are satisfied.
(2) Provision may be made by rules of court requiring that in any proceedings where
it is desired to give a statement in evidence by virtue of this section such information
concerning the statement as may be required by the rules shall be provided in such
form and at such time as may be so required.” By Section 70, Sections 68 and 69 of
this Act had to be read with Schedule 3 thereof, the provisions of which had the same
force in effect as Sections 68 and 69. Part I of Schedule 3 supplemented Section 68.
Notwithstanding the importance of Part I of Schedule 3, we propose to refer to only
two provisions of it, namely:
“computer” under Section 5(6) of the Civil Evidence Act, 1968 was not, however,
adopted by Section 2(i) of the Information Technology Act, 2000, which as noted
above, is a ‘means and includes’ definition of a much more complex and intricate
nature. It is also important to note Section 6(1) and (5) of the Civil Evidence Act,
1968, which state as follows:
“(1) Where in any civil proceedings a statement contained in a document is proposed
to be given in evidence by virtue of section 2, 4 or 5 of this Act it may, subject to any
rules of court, be proved by the production of that document or (whether or not that
document is still in “1. Section 68(1) above applies whether the informationArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

contained in the document was supplied directly or indirectly but, if it was supplied
indirectly, only if each person through whom it was supplied was acting under a duty;
and applies also where the person compiling the record is himself the person by
whom the information is supplied.” “6. Any reference in Section 68 above or this Part
of this Schedule to a person acting under a duty includes a reference to a person
acting in the course of any trade, business, profession or other occupation in which
he is engaged or employed or for the purposes of any paid or unpaid office held by
him.” Part II supplemented Section 69 in important respects. Two provisions of it are
relevant, namely-
“8. In any proceedings where it is desired to give a statement in evidence in
accordance with section 69 above, a certificate –
(a) identifying the document containing the statement and describing the manner in
which it was produced;
(b) giving such particulars of any device involved in the production of that document
as may be appropriate for the purpose of showing that the document was produced
by a computer;
(c) dealing with any of the matters mentioned in Section 69(1) above; and
(d) purporting to be signed by a person occupying a reasonable position in relation to
the operation of the computer, shall be evidence of anything stated in it; and for the
purposes of this paragraph it shall be sufficient for a matter to be stated to the best of
the knowledge and belief of the person stating it.
9. Notwithstanding paragraph 8 above, a court may require oral evidence to be given of anything of
which evidence could be given by a certificate under that paragraph.” existence) by the production of
a copy of that document, or of the material part thereof, authenticated in such manner as the court
may approve.
xxx xxx xxx (5) If any person in a certificate tendered in evidence in civil proceedings by virtue of
section 5(4) of this Act wilfully makes a statement material in those proceedings which he knows to
be false or does not believe to be true, he shall be liable on conviction on indictment to
imprisonment for a term not exceeding two years or a fine or both.”
28. Section 6(1), in essence, maintains the dichotomy between proof by ‘primary’ and ‘secondary’
evidence - proof by production of the ‘document’ itself being primary evidence, and proof by
production of a copy of that document, as authenticated, being secondary evidence. Section 6(5),
which gives teeth to the person granting the certificate mentioned in Section 5(4) of the Act, by
punishing false statements wilfully made in the certificate, has not been included in the Indian
Evidence Act. These sections have since been repealed by the Civil Evidence Act of 1995 (UK),
pursuant to a UK Law Commission Report published in September, 1993 (Law Com. No. 216), byArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

which the strict rule as to hearsay evidence was relaxed, and hearsay evidence was made admissible
in the circumstances mentioned by the Civil Evidence Act of 1995. Sections 8, 9 and 13 of this Act
are important, and are set out hereinbelow:
“8. Proof of statements contained in documents.
(1) Where a statement contained in a document is admissible as evidence in civil
proceedings, it may be proved—
(a) by the production of that document, or
(b) whether or not that document is still in existence, by the production of a copy of
that document or of the material part of it, authenticated in such manner as the court
may approve.
(2) It is immaterial for this purpose how many removes there are between a copy and
the original.
9. Proof of records of business or public authority. (1) A document which is shown to form part of
the records of a business or public authority may be received in evidence in civil proceedings
without further proof. (2) A document shall be taken to form part of the records of a business or
public authority if there is produced to the court a certificate to that effect signed by an officer of the
business or authority to which the records belong. For this purpose—
(a) a document purporting to be a certificate signed by an officer of a business or public authority
shall be deemed to have been duly given by such an officer and signed by him; and
(b) a certificate shall be treated as signed by a person if it purports to bear a facsimile of his
signature. (3) The absence of an entry in the records of a business or public authority may be proved
in civil proceedings by affidavit of an officer of the business or authority to which the records belong.
(4) In this section— “records” means records in whatever form;
“business” includes any activity regularly carried on over a period of time, whether for profit or not,
by any body (whether corporate or not) or by an individual; “officer” includes any person occupying
a responsible position in relation to the relevant activities of the business or public authority or in
relation to its records; and “public authority” includes any public or statutory undertaking, any
government department and any person holding office under Her Majesty.
(5) The court may, having regard to the circumstances of the case, direct that all or any of the above
provisions of this section do not apply in relation to a particular document or record, or description
of documents or records.” Section 13 of this Act defines “document” as follows:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

“document” means anything in which information of any description is recorded, and
“copy”, in relation to a document, means anything onto which information recorded
in the document has been copied, by whatever means and whether directly or
indirectly;”
29. Section 15(2) of this Act repeals enactments mentioned in Schedule II therein;
and Schedule II repeals Part I of the Civil Evidence Act, 1968 - of which Sections 5
and 6 were a part. The definition of “records” and “document” in this Act would show
that electronic records are considered to be part of “document” as defined, needing
no separate treatment as to admissibility or proof. It is thus clear that in UK law, as at
present, no distinction is made between computer generated evidence and other
evidence either qua the admissibility of, or the attachment of weight to, such
evidence.
30. Coming back to Section 65B of the Indian Evidence Act, sub-
section (1) needs to be analysed. The sub-section begins with a non- obstante clause, and then goes
on to mention information contained in an electronic record produced by a computer, which is, by a
deeming fiction, then made a “document”. This deeming fiction only takes effect if the further
conditions mentioned in the Section are satisfied in relation to both the information and the
computer in question; and if such conditions are met, the “document” shall then be admissible in
any proceedings. The words “…without further proof or production of the original…” make it clear
that once the deeming fiction is given effect by the fulfilment of the conditions mentioned in the
Section, the “deemed document” now becomes admissible in evidence without further proof or
production of the original as evidence of any contents of the original, or of any fact stated therein of
which direct evidence would be admissible.
31. The non-obstante clause in sub-section (1) makes it clear that when it comes to information
contained in an electronic record, admissibility and proof thereof must follow the drill of Section
65B, which is a special provision in this behalf - Sections 62 to 65 being irrelevant for this purpose.
However, Section 65B(1) clearly differentiates between the “original” document - which would be
the original “electronic record” contained in the “computer” in which the original information is first
stored - and the computer output containing such information, which then may be treated as
evidence of the contents of the “original” document. All this necessarily shows that Section 65B
differentiates between the original information contained in the “computer” itself and copies made
therefrom – the former being primary evidence, and the latter being secondary evidence.
32. Quite obviously, the requisite certificate in sub-section (4) is unnecessary if the original
document itself is produced. This can be done by the owner of a laptop computer, a computer tablet
or even a mobile phone, by stepping into the witness box and proving that the concerned device, on
which the original information is first stored, is owned and/or operated by him. In cases where “the
computer”, as defined, happens to be a part of a “computer system” or “computer network” (as
defined in the Information Technology Act, 2000) and it becomes impossible to physically bring
such network or system to the Court, then the only means of proving information contained in suchArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

electronic record can be in accordance with Section 65B(1), together with the requisite certificate
under Section 65B(4). This being the case, it is necessary to clarify what is contained in the last
sentence in paragraph 24 of Anvar P.V. (supra) which reads as “…if an electronic record as such is
used as primary evidence under Section 62 of the Evidence Act…”. This may more appropriately be
read without the words “under Section 62 of the Evidence Act,…”. With this minor clarification, the
law stated in paragraph 24 of Anvar P.V. (supra) does not need to be revisited.
33. In fact, in Vikram Singh and Anr. v. State of Punjab and Anr. (2017) 8 SCC 518, a three-Judge
Bench of this Court followed the law in Anvar P.V. (supra), clearly stating that where primary
evidence in electronic form has been produced, no certificate under Section 65B would be necessary.
This was so stated as follows:
“25. The learned counsel contended that the tape- recorded conversation has been
relied on without there being any certificate under Section 65-B of the Evidence Act,
1872. It was contended that audio tapes are recorded on magnetic media, the same
could be established through a certificate under Section 65-B and in the absence of
the certificate, the document which constitutes electronic record, cannot be deemed
to be a valid evidence and has to be ignored from consideration. Reliance has been
placed by the learned counsel on the judgment of this Court in Anvar P.V. v. P.K.
Basheer. The conversation on the landline phone of the complainant situate in a shop
was recorded by the complainant. The same cassette containing conversation by
which ransom call was made on the landline phone was handed over by the
complainant in original to the police. This Court in its judgment dated 25-1-2010 has
referred to the aforesaid fact and has noted the said fact to the following effect:
“5. The cassette on which the conversations had been recorded on the landline was
handed over by Ravi Verma to SI Jiwan Kumar and on a replay of the tape, the
conversation was clearly audible and was heard by the police.”
26. The tape-recorded conversation was not secondary evidence which required
certificate under Section 65-B, since it was the original cassette by which ransom call
was tape-recorded, there cannot be any dispute that for admission of secondary
evidence of electronic record a certificate as contemplated by Section 65-B is a
mandatory condition.”4
34. Despite the law so declared in Anvar P.V. (supra), wherein this Court made it clear that the
special provisions of Sections 65A and 65B of the Evidence Act are a complete Code in themselves
when it comes to 4 The definition of “data”, “electronic form” and “electronic record” under the
Information Technology Act, 2000 (as set out hereinabove) makes it clear that “data” and
“electronic form” includes “magnetic or optical storage media”, which would include the audio
tape/cassette discussed in Vikram Singh (supra).
admissibility of evidence of information contained in electronic records, and also that a written
certificate under Section 65B(4) is a sine qua non for admissibility of such evidence, a discordantArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

note was soon struck in Tomaso Bruno (supra). In this judgment, another three Judge Bench dealt
with the admissibility of evidence in a criminal case in which CCTV footage was sought to be relied
upon in evidence. The Court held:
“24. With the advancement of information technology, scientific temper in the
individual and at the institutional level is to pervade the methods of investigation.
With the increasing impact of technology in everyday life and as a result, the
production of electronic evidence in cases has become relevant to establish the guilt
of the accused or the liability of the defendant. Electronic documents stricto sensu are
admitted as material evidence. With the amendment to the Evidence Act in 2000,
Sections 65-A and 65-B were introduced into Chapter V relating to documentary
evidence. Section 65-A provides that contents of electronic records may be admitted
as evidence if the criteria provided in Section 65-B is complied with. The computer
generated electronic records in evidence are admissible at a trial if proved in the
manner specified by Section 65-B of the Evidence Act. Sub-section (1) of Section 65-B
makes admissible as a document, paper printout of electronic records stored in
optical or magnetic media produced by a computer, subject to the fulfilment of the
conditions specified in sub- section (2) of Section 65-B. Secondary evidence of
contents of document can also be led under Section 65 of the Evidence Act. PW 13
stated that he saw the full video recording of the fateful night in the CCTV camera,
but he has not recorded the same in the case diary as nothing substantial to be
adduced as evidence was present in it.
25. The production of scientific and electronic evidence in court as contemplated
under Section 65-B of the Evidence Act is of great help to the investigating agency
and also to the prosecution. The relevance of electronic evidence is also evident in the
light of Mohd. Ajmal Amir Kasab v. State of Maharashtra [(2012) 9 SCC 1] , wherein
production of transcripts of internet transactions helped the prosecution case a great
deal in proving the guilt of the accused. Similarly, in State (NCT of Delhi) v. Navjot
Sandhu, the links between the slain terrorists and the masterminds of the attack were
established only through phone call transcripts obtained from the mobile service
providers.”
35. What is clear from this judgment is that the judgment of Anvar P.V. (supra) was
not referred to at all. In fact, the judgment in State v.
Navjot Sandhu (2005) 11 SCC 600 was adverted to, which was a judgment specifically overruled by
Anvar P.V. (supra). It may also be stated that Section 65B(4) was also not at all adverted to by this
judgment. Hence, the declaration of law in Tomaso Bruno (supra) following Navjot Sandhu (supra)
that secondary evidence of the contents of a document can also be led under Section 65 of the
Evidence Act to make CCTV footage admissible would be in the teeth of Anvar P.V., (supra) and
cannot be said to be a correct statement of the law. The said view is accordingly overruled.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

36. We now come to the decision in Shafhi Mohammad (supra). In this case, by an order dated
30.01.2018 made by two learned Judges of this Court, it was stated:
“21. We have been taken through certain decisions which may be referred to. In Ram
Singh v. Ram Singh [Ram Singh v. Ram Singh, 1985 Supp SCC 611] , a three-Judge
Bench considered the said issue. English judgments in R. v. Maqsud Ali [R. v.
Maqsud Ali, (1966) 1 QB 688] and R. v. Robson [R. v. Robson, (1972) 1 WLR 651] and
American Law as noted in American Jurisprudence 2d (Vol. 29) p. 494, were cited
with approval to the effect that it will be wrong to deny to the law of evidence
advantages to be gained by new techniques and new devices, provided the accuracy of
the recording can be proved. Such evidence should always be regarded with some
caution and assessed in the light of all the circumstances of each case. Electronic
evidence was held to be admissible subject to safeguards adopted by the Court about
the authenticity of the same. In the case of tape- recording, it was observed that voice
of the speaker must be duly identified, accuracy of the statement was required to be
proved by the maker of the record, possibility of tampering was required to be ruled
out. Reliability of the piece of evidence is certainly a matter to be determined in the
facts and circumstances of a fact situation. However, threshold admissibility of an
electronic evidence cannot be ruled out on any technicality if the same was relevant.
22. In Tukaram S. Dighole v. Manikrao Shivaji Kokate [(2010) 4 SCC 329], the same
principle was reiterated. This Court observed that new techniques and devices are the
order of the day. Though such devices are susceptible to tampering, no exhaustive
rule could be laid down by which the admission of such evidence may be judged.
Standard of proof of its authenticity and accuracy has to be more stringent than other
documentary evidence.
23. In Tomaso Bruno v. State of U.P. [(2015) 7 SCC 178], a three-Judge Bench
observed that advancement of information technology and scientific temper must
pervade the method of investigation. Electronic evidence was relevant to establish
facts. Scientific and electronic evidence can be a great help to an investigating agency.
Reference was made to the decisions of this Court in Mohd. Ajmal Amir Kasab v. State of
Maharashtra [(2012) 9 SCC 1] and State (NCT of Delhi) v. Navjot Sandhu.
24. We may, however, also refer to the judgment of this Court in Anvar P.V. v. P.K. Basheer,
delivered by a three- Judge Bench. In the said judgment in para 24 it was observed that electronic
evidence by way of primary evidence was covered by Section 62 of the Evidence Act to which
procedure of Section 65-B of the Evidence Act was not admissible. However, for the secondary
evidence, procedure of Section 65-B of the Evidence Act was required to be followed and a contrary
view taken in Navjot Sandhu that secondary evidence of electronic record could be covered under
Sections 63 and 65 of the Evidence Act, was not correct. There are, however, observations in para 14
to the effect that electronic record can be proved only as per Section 65-B of the Evidence Act.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

25. Though in view of the three-Judge Bench judgments in Tomaso Bruno and Ram Singh [1985
Supp SCC 611] , it can be safely held that electronic evidence is admissible and provisions under
Sections 65-A and 65-B of the Evidence Act are by way of a clarification and are procedural
provisions. If the electronic evidence is authentic and relevant the same can certainly be admitted
subject to the Court being satisfied about its authenticity and procedure for its admissibility may
depend on fact situation such as whether the person producing such evidence is in a position to
furnish certificate under Section 65-B(4).
26. Sections 65-A and 65-B of the Evidence Act, 1872 cannot be held to be a complete code on the
subject. In Anvar P.V., this Court in para 24 clarified that primary evidence of electronic record was
not covered under Sections 65-A and 65-B of the Evidence Act. Primary evidence is the document
produced before the Court and the expression “document” is defined in Section 3 of the Evidence
Act to mean any matter expressed or described upon any substance by means of letters, figures or
marks, or by more than one of those means, intended to be used, or which may be used, for the
purpose of recording that matter.
27. The term “electronic record” is defined in Section 2(1)
(t) of the Information Technology Act, 2000 as follows:
“2.(1)(t) “electronic record” means data, record or data generated, image or sound
stored, received or sent in an electronic form or micro film or computer generated
micro fiche;”
28. The expression “data” is defined in Section 2(1)(o) of the Information Technology Act as follows:
“2.(1)(o) “data” means a representation of information, knowledge, facts, concepts or
instructions which are being prepared or have been prepared in a formalised manner,
and is intended to be processed, is being processed or has been processed in a
computer system or computer network, and may be in any form (including computer
printouts magnetic or optical storage media, punched cards, punched tapes) or stored
internally in the memory of the computer;”
29. The applicability of procedural requirement under Section 65-B(4) of the Evidence Act of
furnishing certificate is to be applied only when such electronic evidence is produced by a person
who is in a position to produce such certificate being in control of the said device and not of the
opposite party. In a case where electronic evidence is produced by a party who is not in possession
of a device, applicability of Sections 63 and 65 of the Evidence Act cannot be held to be excluded. In
such case, procedure under the said sections can certainly be invoked. If this is not so permitted, it
will be denial of justice to the person who is in possession of authentic evidence/witness but on
account of manner of proving, such document is kept out of consideration by the court in the
absence of certificate under Section 65-B(4) of the Evidence Act, which party producing cannot
possibly secure. Thus, requirement of certificate under Section 65- B(4) is not always mandatory.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

30. Accordingly, we clarify the legal position on the subject on the admissibility of the electronic
evidence, especially by a party who is not in possession of device from which the document is
produced. Such party cannot be required to produce certificate under Section 65-B(4) of the
Evidence Act. The applicability of requirement of certificate being procedural can be relaxed by the
court wherever interest of justice so justifies.”
37. It may be noted that the judgments referred to in paragraph 21 of Shafhi Mohammed (supra) are
all judgments before the year 2000, when Amendment Act 21 of 2000 first introduced Sections 65A
and 65B into the Evidence Act and can, therefore, be of no assistance on interpreting the law as to
admissibility into evidence of information contained in electronic records. Likewise, the judgment
cited in paragraph 22, namely Tukaram S. Dighole v. Manikrao Shivaji Kokate (2010) 4 SCC 329 is
also a judgment which does not deal with Section 65B. In fact, paragraph 20 of the said judgment
states the issues before the Court as follows:
“20. However, in the present case, the dispute is not whether a cassette is a public
document but the issues are whether:
(i) the finding by the Tribunal that in the absence of any evidence to show that the
VHS cassette was obtained by the appellant from the Election Commission, the
cassette placed on record by the appellant could not be treated as a public document
is perverse; and
(ii) a mere production of an audio cassette, assuming that the same is a certified copy
issued by the Election Commission, is per se conclusive of the fact that what is
contained in the cassette is the true and correct recording of the speech allegedly
delivered by the respondent or his agent?” The second issue was answered referring
to judgments which did not deal with Section 65B at all.
38. Much succour was taken from the three Judge Bench decision in Tomaso Bruno (supra) in
paragraph 23, which, as has been stated hereinabove, does not state the law on Section 65B
correctly. Anvar P.V. (supra) was referred to in paragraph 24, but surprisingly, in paragraph 26, the
Court held that Sections 65A and 65B cannot be held to be a complete Code on the subject, directly
contrary to what was stated by a three Judge Bench in Anvar P.V. (supra). It was then “clarified”
that the requirement of a certificate under Section 64B(4), being procedural, can be relaxed by the
Court wherever the interest of justice so justifies, and one circumstance in which the interest of
justice so justifies would be where the electronic device is produced by a party who is not in
possession of such device, as a result of which such party would not be in a position to secure the
requisite certificate.
39. Quite apart from the fact that the judgment in Shafhi Mohammad (supra) states the law
incorrectly and is in the teeth of the judgment in Anvar P.V. (supra), following the judgment in
Tomaso Bruno (supra) - which has been held to be per incuriam hereinabove - the underlying
reasoning of the difficulty of producing a certificate by a party who is not in possession of an
electronic device is also wholly incorrect.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

40. As a matter of fact, Section 165 of the Evidence Act empowers a Judge to order production of any
document or thing in order to discover or obtain proof of relevant facts. Section 165 of the Evidence
Act states as follows:
“Section 165. Judge’s power to put questions or order production.- The Judge may, in
order to discover or to obtain proper proof of relevant facts, ask any question he
pleases, in any form, at any time, of any witness, or of the parties about any fact
relevant or irrelevant; and may order the production of any document or thing; and
neither the parties nor their agents shall be entitled to make any objection to any
such question or order, nor, without the leave of the Court, to cross-examine any
witness upon any answer given in reply to any such question.
Provided that the judgment must be based upon facts declared by this Act to be
relevant, and duly proved:
Provided also that this section shall not authorize any Judge to compel any witness to
answer any question or to produce any document which such witness would be
entitled to refuse to answer or produce under sections 121 to 131, both inclusive, if the
question were asked or the document were called for by the adverse party; nor shall
the Judge ask any question which it would be improper for any other person to ask
under section 148 or 149; nor shall he dispense with primary evidence of any
document, except in the cases hereinbefore excepted.
41. Likewise, under Order XVI of the Civil Procedure Code, 1908 (“CPC”) which deals with
‘Summoning and Attendance of Witnesses’, the Court can issue the following orders for the
production of documents:
“6. Summons to produce document.—Any person may be summoned to produce a
document, without being summoned to give evidence; and any person summoned
merely to produce a document shall be deemed to have complied with the summons
if he causes such document to be produced instead of attending personally to produce
the same.
7. Power to require persons present in Court to give evidence or produce
document.—Any person present in Court may be required by the Court to give
evidence or to produce any document then and there in his possession or power.
xxx xxx xxx
10. Procedure where witness fails to comply with summons.—(1) Where a person has been issued
summons either to attend to give evidence or to produce a document, fails to attend or to produce
the document in compliance with such summons, the Court— (a) shall, if the certificate of the
serving officer has not been verified by the affidavit, or if service of the summons has affected by a
party or his agent, or (b) may, if the certificate of the serving officer has been so verified, examine onArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

oath the serving officer or the party or his agent, as the case may be, who has effected service, or
cause him to be so examined by any Court, touching the service or non- service of the summons.
(2) Where the Court sees reason to believe that such evidence or production is material, and that
such person has, without lawful excuse, failed to attend or to produce the document in compliance
with such summons or has intentionally avoided service, it may issue a proclamation requiring him
to attend to give evidence or to produce the document at a time and place to be named therein; and
a copy of such proclamation shall be affixed on the outer door or other conspicuous part of the
house in which he ordinarily resides.
(3) In lieu of or at the time of issuing such proclamation, or at any time afterwards, the Court may,
in its discretion, issue a warrant, either with or without bail, for the arrest of such person, and may
make an order for the attachment of his property to such amount as it thinks fit, not exceeding the
amount of the costs of attachment and of any fine which may be imposed under rule 12:
Provided that no Court of Small Causes shall make an order for the attachment of
immovable property.”
42. Similarly, in the Code of Criminal Procedure, 1973 (“CrPC”), the Judge
conducting a criminal trial is empowered to issue the following orders for production
of documents:
“91. Summons to produce document or other thing.— (1) Whenever any Court or any
officer in charge of a police station considers that the production of any document or
other thing is necessary or desirable for the purposes of any investigation, inquiry,
trial or other proceeding under this Code by or before such Court or officer, such
Court may issue a summons, or such officer a written order, to the person in whose
possession or power such document or thing is believed to be, requiring him to
attend and produce it, or to produce it, at the time and place stated in the summons
or order.
(2) Any person required under this section merely to produce a document or other
thing shall be deemed to have complied with the requisition if he causes such
document or thing to be produced instead of attending personally to produce the
same.
(3) Nothing in this section shall be deemed— (a) to affect sections 123 and 124 of the
Indian Evidence Act, 1872 (1 of 1872), or the Bankers’ Books Evidence Act, 1891 (13 of
1891), or (b) to apply to a letter, postcard, telegram or other document or any parcel
or thing in the custody of the postal or telegraph authority.” “349. Imprisonment or
committal of person refusing to answer or produce document.—If any witness or
person called to produce a document or thing before a Criminal Court refuses to
answer such questions as are put to him or to produce any document or thing in his
possession or power which the Court requires him to produce, and does not, after aArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

reasonable opportunity has been given to him so to do, offer any reasonable excuse
for such refusal, such Court may, for reasons to be recorded in writing, sentence him
to simple imprisonment, or by warrant under the hand of the Presiding Magistrate or
Judge commit him to the custody of an officer of the Court for any term not
exceeding seven days, unless in the meantime, such person consents to be examined
and to answer, or to produce the document or thing and in the event of his persisting
in his refusal, he may be dealt with according to the provisions of section 345 or
section 346.”
43. Thus, it is clear that the major premise of Shafhi Mohammad (supra) that such
certificate cannot be secured by persons who are not in possession of an electronic
device is wholly incorrect. An application can always be made to a Judge for
production of such a certificate from the requisite person under Section 65B(4) in
cases in which such person refuses to give it.
44. Resultantly, the judgment dated 03.04.2018 of a Division Bench of this Court
reported as (2018) 5 SCC 311, in following the law incorrectly laid down in Shafhi
Mohammed (supra), must also be, and is hereby, overruled.
45. However, a caveat must be entered here. The facts of the present case show that
despite all efforts made by the Respondents, both through the High Court and
otherwise, to get the requisite certificate under Section 65B(4) of the Evidence Act
from the authorities concerned, yet the authorities concerned wilfully refused, on
some pretext or the other, to give such certificate. In a fact-circumstance where the
requisite certificate has been applied for from the person or the authority concerned,
and the person or authority either refuses to give such certificate, or does not reply to
such demand, the party asking for such certificate can apply to the Court for its
production under the provisions aforementioned of the Evidence Act, CPC or CrPC.
Once such application is made to the Court, and the Court then orders or directs that
the requisite certificate be produced by a person to whom it sends a summons to
produce such certificate, the party asking for the certificate has done all that he can
possibly do to obtain the requisite certificate. Two Latin maxims become important at
this stage. The first is lex non cogit ad impossibilia i.e. the law does not demand the
impossible, and impotentia excusat legem i.e. when there is a disability that makes it
impossible to obey the law, the alleged disobedience of the law is excused. This was
well put by this Court in Re: Presidential Poll (1974) 2 SCC 33 as follows:
“14. If the completion of election before the expiration of the term is not possible
because of the death of the prospective candidate it is apparent that the election has
commenced before the expiration of the term but completion before the expiration of
the term is rendered impossible by an act beyond the control of human agency. The
necessity for completing the election before the expiration of the term is enjoined by
the Constitution in public and State interest to see that the governance of the country
is not paralysed by non-compliance with the provision that there shall be a PresidentArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

of India.
15. The impossibility of the completion of the election to fill the vacancy in the office
of the President before the expiration of the term of office in the case of death of a
candidate as may appear from Section 7 of the 1952 Act does not rob Article 62(1) of
its mandatory character. The maxim of law impotentia excusat legam is intimately
connected with another maxim of law lex non cogit ad impossibilia. Impotentia
excusat legam is that when there is a necessary or invincible disability to perform the
mandatory part of the law that impotentia excuses. The law does not compel one to
do that which one cannot possibly perform. “Where the law creates a duty or charge,
and the party is disabled to perform it, without any default in him, and has no
remedy over it, there the law will in general excuse him.” Therefore, when it appears
that the performance of the formalities prescribed by a statute has been rendered
impossible by circumstances over which the persons interested had no control, like
the act of God, the circumstances will be taken as a valid excuse. Where the act of
God prevents the compliance of the words of a statute, the statutory provision is not
denuded of its mandatory character because of supervening impossibility caused by
the act of God. (See Broom's Legal Maxims 10th Edn. at pp. 162-163 and Craies on
Statute Law 6th Edn. at p. 268).” It is important to note that the provision in
question in Re Presidential Poll (supra) was also mandatory, which could not be
satisfied owing to an act of God, in the facts of that case. These maxims have been
applied by this Court in different situations in other election cases – see Chandra
Kishore Jha v. Mahavir Prasad and Ors. (1999) 8 SCC 266 (at paragraphs 17 and
21); Special Reference 1 of 2002 (2002) 8 SCC 237 (at paragraphs 130 and 151) and
Raj Kumar Yadav v. Samir Kumar Mahaseth and Ors.
(2005) 3 SCC 601 (at paragraphs 13 and 14).
46. These Latin maxims have also been applied in several other contexts by this Court. In Cochin
State Power and Light Corporation v. State of Kerala (1965) 3 SCR 187, a question arose as to the
exercise of an option of purchasing an undertaking by the State Electricity Board under Section 6(4)
of the Indian Electricity Act, 1910. The provision required a notice of at least 18 months before the
expiry of the relevant period to be given by such State Electricity Board to the State Government.
Since this mandatory provision was impossible of compliance, it was held that the State Electricity
Board was excused from giving such notice, as follows:
“Sub-section (1) of Section 6 expressly vests in the State Electricity Board the option
of purchase on the expiry of the relevant period specified in the license. But the State
Government claims that under sub-section (2) of Section 6 it is now vested with the
option. Now, under sub-section (2) of Section 6, the State Government would be
vested with the option only “where a State Electricity Board has not been constituted,
or if constituted, does not elect to purchase the undertaking”. It is common case that
the State Electricity Board was duly constituted. But the State Government claimsArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

that the State Electricity Board did not elect to purchase the undertaking. For this
purpose, the State Government relies upon the deeming provisions of sub-section (4)
of Section 6, and contends that as the Board did not send to the State Government
any intimation in writing of its intention to exercise the option as required by the
sub-section, the Board must be deemed to have elected not to purchase the
undertaking.
Now, the effect of sub-section (4) read with sub-section (2) of Section 6 is that on failure of the
Board to give the notice prescribed by sub-section (4), the option vested in the Board under
sub-section (1) of Section 6 was liable to be divested. Sub-section (4) of Section 6 imposed upon the
Board the duty of giving after the coming into force of Section 6 a notice in writing of its intention to
exercise the option at least 18 months before the expiry of the relevant period. Section 6 came into
force on September 5, 1959, and the relevant period expired on December 3, 1960. In the
circumstances, the giving of the requisite notice of 18 months in respect of the option of purchase on
the expiry of December 2, 1960, was impossible from the very commencement of Section 6. The
performance of this impossible duty must be excused in accordance with the maxim, lex non cogitia
ad impossibilia (the law does not compel the doing of impossibilities), and sub-section (4) of Section
6 must be construed as not being applicable to a case where compliance with it is impossible. We
must therefore, hold that the State Electricity Board was not required to give the notice under
sub-section (4) of Section 6 in respect of its option of purchase on the expiry of 25 years. It must
follow that the Board cannot be deemed to have elected not to purchase the undertaking under sub-
section (4) of Section 6. By the notice served upon the appellant, the Board duly elected to purchase
the undertaking on the expiry of 25 years. Consequently, the State Government never became vested
with the option of purchasing the undertaking under sub-section (2) of Section 6. The State
Government must, therefore, be restrained from taking further action under its notice, Ex. G, dated
November 20, 1959.”5
47. In Raj Kumar Dubey v. Tarapada Dey and Ors. (1987) 4 SCC 398, the maxim non cogit ad
impossibilia was applied in the context of the applicability of a mandatory provision of the
Registration Act, 1908, as follows:
“6. We have to bear in mind two maxims of equity which are well settled, namely,
actus curiae neminem gravabit — An act of the Court shall prejudice no man. In
Broom's Legal Maxims, 10th Edn., 1939 at page 73 this maxim is explained that this
maxim was founded upon justice and good sense; and afforded a safe and certain
guide for the administration of the law. The above maxim should, however, be
applied with caution. The other maxim is lex non cogit ad impossibilia (Broom's
Legal Maxims — page 162) — The law does not compel a man to do that which he
cannot possibly perform. The law itself and the administration of it, said Sir W. Scott,
with reference to an alleged infraction of the revenue laws, must yield to that to which
everything must bend, to necessity; the law, in its most positive and peremptory 5
(1965) 3 SCR 187, at 193.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

injunctions, is understood to disclaim, as it does in its general aphorisms, all intention of compelling
impossibilities, and the administration of laws must adopt that general exception in the
consideration of all particular cases.
7. In this case indisputably during the period from 26-7- 1978 to December 1982 there was
subsisting injunction preventing the arbitrators from taking any steps. Furthermore, as noted before
the award was in the custody of the court, that is to say, 28-1-1978 till the return of the award to the
arbitrators on 24-11-1983, arbitrators or the parties could not have presented the award for its
registration during that time. The award as we have noted before was made on 28-11-1977 and
before the expiry of the four months from 28-11-1977, the award was filed in the court pursuant to
the order of the court. It was argued that the order made by the court directing the arbitrators to
keep the award in the custody of the court was wrong and without jurisdiction, but no arbitrator
could be compelled to disobey the order of the court and if in compliance or obedience with court of
doubtful jurisdiction, he could not take back the award from the custody of the court to take any
further steps for its registration then it cannot be said that he has failed to get the award registered
as the law required. The aforesaid two legal maxims — the law does not compel a man to do that
which he cannot possibly perform and an act of the court shall prejudice no man would, apply with
full vigour in the facts of this case and if that is the position then the award as we have noted before
was presented before the Sub-Registrar, Arambagh on 25-11-1983 the very next one day of getting
possession of the award from the court. The Sub-Registrar pursuant to the order of the High Court
on 24-6-1985 found that the award was presented within time as the period during which the
judicial proceedings were pending that is to say, from 28-1-1978 to 24-11-1983 should be excluded in
view of the principle laid down in Section 15 of the Limitation Act, 1963. The High Court, therefore,
in our opinion, was wrong in holding that the only period which should be excluded was from
26-7-1978 till 20-12-1982. We are unable to accept this position. 26-7-1978 was the date of the order
of the learned Munsif directing maintenance of status quo and 20-12-1982 was the date when the
interim injunction was vacated, but still the award was in the custody of the court and there is ample
evidence as it would appear from the narration of events hereinbefore made that the arbitrators had
tried to obtain the custody of the award which the court declined to give to them.”
48. These maxims have also been applied to tenancy legislation – see M/s B.P. Khemka Pvt. Ltd. v.
Birendra Kumar Bhowmick and Anr. (1987) 2 SCC 401 (at paragraph 12), and have also been
applied to relieve authorities of fulfilling their obligation to allot plots when such plots have been
found to be un-allottable, owing to the contravention of Central statutes – see Hira Tikoo v. U.T.,
Chandigarh and Ors. (2004) 6 SCC 765 (at paragraphs 23 and 24).
49. On an application of the aforesaid maxims to the present case, it is clear that though Section
65B(4) is mandatory, yet, on the facts of this case, the Respondents, having done everything possible
to obtain the necessary certificate, which was to be given by a third-party over whom the
Respondents had no control, must be relieved of the mandatory obligation contained in the said
sub-section.
50. We may hasten to add that Section 65B does not speak of the stage at which such certificate
must be furnished to the Court. In Anvar P.V. (supra), this Court did observe that such certificateArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

must accompany the electronic record when the same is produced in evidence. We may only add
that this is so in cases where such certificate could be procured by the person seeking to rely upon an
electronic record. However, in cases where either a defective certificate is given, or in cases where
such certificate has been demanded and is not given by the concerned person, the Judge conducting
the trial must summon the person/persons referred to in Section 65B(4) of the Evidence Act, and
require that such certificate be given by such person/persons. This, the trial Judge ought to do when
the electronic record is produced in evidence before him without the requisite certificate in the
circumstances aforementioned. This is, of course, subject to discretion being exercised in civil cases
in accordance with law, and in accordance with the requirements of justice on the facts of each case.
When it comes to criminal trials, it is important to keep in mind the general principle that the
accused must be supplied all documents that the prosecution seeks to rely upon before
commencement of the trial, under the relevant sections of the CrPC.
51. In a recent judgment, a Division Bench of this Court in State of Karnataka v. M.R. Hiremath
(2019) 7 SCC 515, after referring to Anvar P.V. (supra) held:
“16. The same view has been reiterated by a two- Judge Bench of this Court in Union
of India v. Ravindra V. Desai [(2018) 16 SCC 273]. The Court emphasised that
non-production of a certificate under Section 65-B on an earlier occasion is a curable
defect. The Court relied upon the earlier decision in Sonu v. State of Haryana [(2017)
8 SCC 570], in which it was held:
“32. … The crucial test, as affirmed by this Court, is whether the defect could have
been cured at the stage of marking the document. Applying this test to the present
case, if an objection was taken to the CDRs being marked without a certificate, the
court could have given the prosecution an opportunity to rectify the deficiency.”
17. Having regard to the above principle of law, the High Court erred in coming to the
conclusion that the failure to produce a certificate under Section 65-B(4) of the
Evidence Act at the stage when the charge-sheet was filed was fatal to the
prosecution. The need for production of such a certificate would arise when the
electronic record is sought to be produced in evidence at the trial. It is at that stage
that the necessity of the production of the certificate would arise.”
52. It is pertinent to recollect that the stage of admitting documentary evidence in a criminal trial is
the filing of the charge-sheet. When a criminal court summons the accused to stand trial, copies of
all documents which are entered in the charge-sheet/final report have to be given to the accused.
Section 207 of the CrPC, which reads as follows, is mandatory6. Therefore, the electronic evidence,
i.e. the computer output, has to be furnished at the latest before the trial begins. The reason is not
far to seek; this gives the accused a fair chance to prepare and defend the charges levelled against
him during the trial. The general principle in criminal proceedings therefore, is to supply to the
accused all documents that the prosecution seeks to rely upon before the commencement of the
trial. The requirement of such full disclosure is an extremely valuable right and an essential feature
of the right to a fair trial as it enables the accused to prepare for the trial before its commencement.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

6 “Section 207. Supply to the accused of copy of police report and other documents.- In any case
where the proceeding has been instituted on a police report, the Magistrate shall without delay
furnish to the accused, free of costs, a copy of each of the following:-
   (i)                    the police report;
   (ii)                   the first information report recorded under section 154;
   (iii)                  the statements recorded under sub-section (3) of section 161 of all
persons whom the prosecution proposes to examine as its witnesses, excluding therefrom any part
in regard to which a request for such exclusion has been made by the police officer under
sub-section (6) of section 173;
(iv) the confessions and statements, if any, recorded under section 164;
(v) any other document or relevant extract thereof forwarded to the Magistrate with the police
report under sub-section (5) of section 173:
Provided that the Magistrate may, after perusing any such part of a statement as is
referred to in clause (iii) and considering the reasons given by the police officer for
the request, direct that a copy of that part of the statement or of such portion thereof
as the Magistrate thinks proper, shall be furnished to the accused:
Provided further that if the Magistrate is satisfied that any document referred to in
clause (v) is voluminous, he shall, instead of furnishing the accused with a copy
thereof, direct that he will only be allowed to inspect it either personally or through
pleader in Court.”
53. In a criminal trial, it is assumed that the investigation is completed and the
prosecution has, as such, concretised its case against an accused before
commencement of the trial. It is further settled law that the prosecution ought not to
be allowed to fill up any lacunae during a trial.
As recognised by this Court in Central Bureau of Investigation v. R.S. Pai (2002) 5 SCC 82, the only
exception to this general rule is if the prosecution had ‘mistakenly’ not filed a document, the said
document can be allowed to be placed on record. The Court held as follows:
“7. From the aforesaid sub-sections, it is apparent that normally, the investigating
officer is required to produce all the relevant documents at the time of submitting the
charge-sheet. At the same time, as there is no specific prohibition, it cannot be held
that the additional documents cannot be produced subsequently. If some mistake is
committed in not producing the relevant documents at the time of submitting the
report or the charge-sheet, it is always open to the investigating officer to produce the
same with the permission of the court.”Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

54. Therefore, in terms of general procedure, the prosecution is obligated to supply
all documents upon which reliance may be placed to an accused before
commencement of the trial. Thus, the exercise of power by the courts in criminal
trials in permitting evidence to be filed at a later stage should not result in serious or
irreversible prejudice to the accused. A balancing exercise in respect of the rights of
parties has to be carried out by the court, in examining any application by the
prosecution under Sections 91 or 311 of the CrPC or Section 165 of the Evidence Act.
Depending on the facts of each case, and the Court exercising discretion after seeing that the
accused is not prejudiced by want of a fair trial, the Court may in appropriate cases allow the
prosecution to produce such certificate at a later point in time. If it is the accused who desires to
produce the requisite certificate as part of his defence, this again will depend upon the justice of the
case - discretion to be exercised by the Court in accordance with law.
55. The High Court of Rajasthan in Paras Jain v. State of Rajasthan 2015 SCC OnLine Raj 8331,
decided a preliminary objection that was raised on the applicability of Section 65B to the facts of the
case. The preliminary objection raised was framed as follows:
“3. (i) Whether transcriptions of conversations and for that matter CDs of the same
filed alongwith the charge-sheet are not admissible in evidence even at this stage of
the proceedings as certificate as required u/Sec. 65-B of the Evidence Act was not
obtained at the time of procurement of said CDs from the concerned service provider
and it was not produced alongwith charge-sheet in the prescribed form and such
certificate cannot be filed subsequently.” After referring to Anvar P.V. (supra), the
High Court held:
“15. Although, it has been observed by Hon'ble Supreme Court that the requisite
certificate must accompany the electronic record pertaining to which a statement is
sought to be given in evidence when the same is produced in evidence, but in my view
it does not mean that it must be produced alongwith the charge-sheet and if it is not
produced alongwith the charge-sheet, doors of the Court are completely shut and it
cannot be produced subsequently in any circumstance. Section 65-B of the Evidence
Act deals with admissibility of secondary evidence in the form of electronic record
and the procedure to be followed and the requirements be fulfilled before such an
evidence can be held to be admissible in evidence and not with the stage at which
such a certificate is to be produced before the Court. One of the principal issues
arising for consideration in the above case before Hon'ble Court was the nature and
manner of admission of electronic records.
16. From the facts of the above case it is revealed that the election of the respondent
to the legislative assembly of the State of Kerala was challenged by the appellant-Shri
Anwar P.V. by way of an election petition before the High Court of Kerala and it was
dismissed vide order dated 16.11.2011 by the High Court and that order was
challenged by the appellant before Hon'ble Supreme Court. It appears that theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

election was challenged on the ground of corrupt practices committed by the
respondent and in support thereof some CDs were produced alongwith the election
petition, but even during the course of trial certificate as required under Section 65-B
of the Evidence Act was not produced and the question of admissibility of the CDs as
secondary evidence in the form of electronic record in absence of requisite certificate
was considered and it was held that such electronic record is not admissible in
evidence in absence of the certificate. It is clear from the facts of the case that the
question of stage at which such electronic record is to be produced was not before the
Hon'ble Court.
17. It is to be noted that it has been clarified by Hon'ble Court that observations made
by it are in respect of secondary evidence of electronic record with reference to
Sections 59, 65-A and 65-B of the Evidence Act and if an electronic record as such is
used as primary evidence under Section 62 of the Evidence Act, the same is
admissible in evidence without compliance with the conditions in Section 65-B of the
Evidence Act.
18. To consider the issue raised on behalf of the petitioners in a proper manner, I
pose a question to me whether an evidence and more particularly evidence in the
form of a document not produced alongwith the charge-
sheet cannot be produced subsequently in any circumstances. My answer to the question is in
negative and in my opinion such evidence can be produced subsequently also as it is well settled
legal position that the goal of a criminal trial is to discover the truth and to achieve that goal, the
best possible evidence is to be brought on record.
19. Relevant portion of sub-sec. (1) of Sec. 91 Cr.P.C. provides that whenever any Court considers
that the production of any document is necessary or desirable for the purposes of any trial under the
Code by or before such Court, such Court may issue a summons to the person in whose possession
or power such document is believed to be, requiring him to attend and produce it or to produce it, at
the time and place stated in the summons. Thus, a wide discretion has been conferred on the Court
enabling it during the course of trial to issue summons to a person in whose possession or power a
document is believed to be requiring him to produce before it, if the Court considers that the
production of such document is necessary or desirable for the purposes of such trial. Such power can
be exercised by the Court at any stage of the proceedings before judgment is delivered and the Court
must exercise the power if the production of such document is necessary or desirable for the proper
decision in the case. It cannot be disputed that such summons can also be issued to the
complainant/informer/victim of the case on whose instance the FIR was registered. In my
considered view when under this provision Court has been empowered to issue summons for the
producment of document, there can be no bar for the Court to permit a document to be taken on
record if it is already before it and the Court finds that it is necessary for the proper disposal of the
case irrespective of the fact that it was not filed along with the charge-sheet. I am of the further view
that it is the duty of the Court to take all steps necessary for the production of such a document
before it.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

20. As per Sec. 311 Cr.P.C., any Court may, at any stage of any trial under the Code, summon any
person as a witness, or examine any person in attendance, though not summoned as a witness, or
recall or re-examine any person already examined; and the Court shall summon and examine or
recall and re-examine any such person if his evidence appears to it to be essential to the just decision
of the case. Under this provision also wide discretion has been conferred upon the Court to exercise
its power and paramount consideration is just decision of the case. In my opinion under this
provision it is permissible for the Court even to order production of a document before it if it is
essential for the just decision of the case.
21. As per Section 173(8) Cr.P.C. carrying out a further investigation and collection of additional
evidence even after filing of charge-sheet is a statutory right of the police and for that prior
permission of the Magistrate is not required. If during the course of such further investigation
additional evidence, either oral or documentary, is collected by the Police, the same can be produced
before the Court in the form of supplementary charge-sheet. The prime consideration for further
investigation and collection of additional evidence is to arrive at the truth and to do real and
substantial justice. The material collected during further investigation cannot be rejected only
because it has been filed at the stage of the trial.
22. As per Section 231 Cr.P.C., the prosecution is entitled to produce any person as a witness even
though such person is not named in the charge-sheet.
23. When legal position is that additional evidence, oral or documentary, can be produced during
the course of trial if in the opinion of the Court production of it is essential for the proper disposal of
the case, how it can be held that the certificate as required under Section 65-B of the Evidence Act
cannot be produced subsequently in any circumstances if the same was not procured alongwith the
electronic record and not produced in the Court with the charge-sheet. In my opinion it is only an
irregularity not going to the root of the matter and is curable. It is also pertinent to note that
certificate was produced alongwith the charge-sheet but it was not in a proper form but during the
course of hearing of these petitioners, it has been produced on the prescribed form.”
56. In Kundan Singh (supra), a Division Bench of the Delhi High Court held:
“50. Anwar P.V. (supra) partly overruled the earlier decision of the Supreme Court on
the procedure to prove electronic record(s) in Navjot Sandhu (supra), holding that
Section 65B is a specific provision relating to the admissibility of electronic record(s)
and, therefore, production of a certificate under Section 65B(4) is mandatory. Anwar
P.V. (supra) does not state or hold that the said certificate cannot be produced in
exercise of powers of the trial court under Section 311 Cr.P.C or, at the appellate stage
under Section 391 Cr.P.C. Evidence Act is a procedural law and in view of the
pronouncement in Anwar P.V. (supra) partly overruling Navjot Sandhu (supra), the
prosecution may be entitled to invoke the aforementioned provisions, when justified
and required. Of course, it is open to the court/presiding officer at that time to
ascertain and verify whether the responsible officer could issue the said certificate
and meet the requirements of Section 65B.”Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

57. Subject to the caveat laid down in paragraphs 50 and 54 above, the law laid down by these two
High Courts has our concurrence. So long as the hearing in a trial is not yet over, the requisite
certificate can be directed to be produced by the learned Judge at any stage, so that information
contained in electronic record form can then be admitted, and relied upon in evidence.
58. It may also be seen that the person who gives this certificate can be anyone out of several
persons who occupy a ‘responsible official position’ in relation to the operation of the relevant
device, as also the person who may otherwise be in the ‘management of relevant activities’ spoken of
in Sub-section (4) of Section 65B. Considering that such certificate may also be given long after the
electronic record has actually been produced by the computer, Section 65B(4) makes it clear that it
is sufficient that such person gives the requisite certificate to the “best of his knowledge and belief”
(Obviously, the word “and” between knowledge and belief in Section 65B(4) must be read as “or”, as
a person cannot testify to the best of his knowledge and belief at the same time).
59. We may reiterate, therefore, that the certificate required under Section 65B(4) is a condition
precedent to the admissibility of evidence by way of electronic record, as correctly held in Anvar P.V.
(supra), and incorrectly “clarified” in Shafhi Mohammed (supra). Oral evidence in the place of such
certificate cannot possibly suffice as Section 65B(4) is a mandatory requirement of the law. Indeed,
the hallowed principle in Taylor v. Taylor (1876) 1 Ch.D 426, which has been followed in a number
of the judgments of this Court, can also be applied. Section 65B(4) of the Evidence Act clearly states
that secondary evidence is admissible only if lead in the manner stated and not otherwise. To hold
otherwise would render Section 65B(4) otiose.
60. In view of the above, the decision of the Madras High Court in K. Ramajyam (supra), which
states that evidence aliunde can be given through a person who was in-charge of a computer device
in the place of the requisite certificate under Section 65B(4) of the Evidence Act is also an incorrect
statement of the law and is, accordingly, overruled.
61. While on the subject, it is relevant to note that the Department of Telecommunication’s license
conditions [i.e. under the ‘License for Provision of Unified Access Services’ framed in 2007, as also
the subsequent ‘License Agreement for Unified License’ and the ‘License Agreement for provision of
internet service’] generally oblige internet service providers and providers of mobile telephony to
preserve and maintain electronic call records and records of logs of internet users for a limited
duration of one year7. Therefore, if the police or other individuals (interested, or party to any form
of litigation) fail to secure those records - or secure the records but fail to secure the certificate -
within that period, the production of a post-dated certificate (i.e. one issued after commencement of
the trial) would in all probability render the data unverifiable. This places the accused in a perilous
position, as, in the event 7 See, Clause 41.17 of the ‘License Agreement for Provision of Unified
Access Services’: “The LICENSEE shall maintain all commercial records with regard to the
communications exchanged on the network. Such records shall be archived for at least one year for
scrutiny by the Licensor for security reasons and may be destroyed thereafter unless directed
otherwise by the licensor”; Clause 39.20 of the ‘License Agreement for Unified License’: “The
Licensee shall maintain all commercial records/ Call Detail Record (CDR)/ Exchange Detail Record
(EDR)/ IP Detail Record (IPDR) with regard to the 39 communications exchanged on the network.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Such records shall be archived for at least one year for scrutiny by the Licensor for security reasons
and may be destroyed thereafter unless directed otherwise by the Licensor. Licensor may issue
directions /instructions from time to time with respect to CDR/IPDR/EDR.” the accused wishes to
challenge the genuineness of this certificate by seeking the opinion of the Examiner of Electronic
Evidence under Section 45A of the Evidence Act, the electronic record (i.e. the data as to call logs in
the computer of the service provider) may be missing.
62. To obviate this, general directions are issued to cellular companies and internet service
providers to maintain CDRs and other relevant records for the concerned period (in tune with
Section 39 of the Evidence Act) in a segregated and secure manner if a particular CDR or other
record is seized during investigation in the said period. Concerned parties can then summon such
records at the stage of defence evidence, or in the event such data is required to cross-examine a
particular witness. This direction shall be applied, in criminal trials, till appropriate directions are
issued under relevant terms of the applicable licenses, or under Section 67C of the Information
Technology Act, which reads as follows:
“67C. Preservation and retention of information by intermediaries.– (1) Intermediary
shall preserve and retain such information as may be specified for such duration and
in such manner and format as the Central Government may prescribe.
(2) any intermediary who intentionally or knowingly contravenes the provisions of
sub-section (1) shall be punished with an imprisonment for a term which may extend
to three years and also be liable to fine.”
63. It is also useful, in this context, to recollect that on 23 April 2016, the conference of the Chief
Justices of the High Courts, chaired by the Chief Justice of India, resolved to create a uniform
platform and guidelines governing the reception of electronic evidence. The Chief Justices of Punjab
and Haryana and Delhi were required to constitute a committee to “frame Draft Rules to serve as
model for adoption by High Courts”. A five-Judge Committee was accordingly constituted on 28
July, 20188. After extensive deliberations, and meetings with several police, investigative and other
agencies, the Committee finalised its report in November 2018. The report suggested
comprehensive guidelines, and recommended their adoption for use in courts, across several
categories of proceedings. The report also contained Draft Rules for the Reception, Retrieval,
Authentication and Preservation of Electronic Records. In the opinion of the Court, these Draft
Rules should be examined by the concerned authorities, with the object of giving them statutory
force, to guide courts in regard to preservation and retrieval of electronic evidence.
64. We turn now to the facts of the case before us. In the present case, by the impugned judgment
dated 24.11.2017, Election Petition 8 The Committee comprised of Rajesh Bindal, S. Muralidhar,
Rajiv Sahai Endlaw, Rajiv Narain Raina and R.K. Gauba, JJ.
6/2014 and Election Petition 9/2014 have been allowed and partly allowed respectively, the election
of the RC being declared to be void under Section 100 of the Representation of the People Act, 1951,
inter alia, on the ground that as nomination papers at serial numbers 43 and 44 were not presentedArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

by the RC before 3.00 p.m. on 27.09.2014, such nomination papers were improperly accepted.
65. However, by an order dated 08.12.2017, this Court admitted the Election Appeal of the
Appellant, and stayed the impugned judgment and order.
66. We have heard this matter after the five year Legislative Assembly term is over in November
2019. This being the case, ordinarily, it would be unnecessary to decide on the merits of the case
before us, as the term of the Legislative Assembly is over. However, having read the impugned
judgment, it is clear that the learned Single Judge was anguished by the fact that the Election
Commission authorities behaved in a partisan manner by openly favouring the Appellant. Despite
the fact that the reason given of “substantial compliance” with Section 65B(4) in the absence of the
requisite certificate being incorrect in law, yet, considering that the Respondent had done
everything in his power to obtain the requisite certificate from the appropriate authorities, including
directions from the Court to produce the requisite certificate, no such certificate was forthcoming.
The horse was directed to be taken to the water to drink - but it refused to drink, leading to the
consequence pointed out in paragraph 49 of this judgment (supra).
67. Even otherwise, apart from evidence contained in electronic form, the High court arrived at the
following conclusion:
“48. The evidence in cross examination of Smt. Mutha shows that when Labade was
sent to the passage for collecting nomination forms, she continued to accept the
nomination forms directly from intending candidates and their proposers in her
office. Her evidence shows that on 27.9.2014 the last nomination form which was
directly presented to her was form No. 38 of Anand Mhaske. The time of receipt of
this form was mentioned in the register of nomination forms as 2.55 p.m. In respect
of subsequent nomination forms from Sr. Nos. 39 to 64, the time of acceptance is
mentioned as 3.00 p.m. Smt. Mutha admits that the candidates of nomination form
Nos. 39 to 64 (form No. 64 was the last form filed) were not present before her
physically at 3.00 p.m. At the cost of repetition, it needs to be mentioned here that
form numbers of RC are 43 and
44. The oral evidence and the record like register of nomination forms does not show
that form Nos. 43 and 44 were presented to RO at 2.20 p.m. of 27.9.2014. As per the
evidence of Smt. Mutha and the record, one Arvind Chavan, a candidate having form
Nos. 33, 34 and 35 was present before her between 2.15 p.m. and 2.30 p.m. In
nomination form register, there is no entry showing that any nomination form was
received at 2.20 p.m. Form Nos. 36 and 37 of Sunil Khare were entered in the register
at 2.40 p.m. Thus, according to Smt. Mutha, form No. 38, which was accepted by her
directly from the candidate was tendered to her at 2.55 p.m. of 27.9.2014 and after
that she had done preliminary examination of form No. 38 and check list was given
by her to that candidate. Thus, it is not possible that form Nos. 43 and 44 were
directly handed over to Smt. Mutha by RC at 2.20 p.m. or even at 3.00 p.m. of
27.9.2014.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

50. Smt. Mutha (PW 2) did not show the time as 2.20 p.m. of handing over the check
list to RC and she showed the time as 3.00 p.m., but this time was shown in respect of
all forms starting from Sr. Nos. 39 to 64. Thus, substantive evidence of Smt. Mutha
and the aforesaid record falsifies the contention of the RC made in the pleading that
he had handed over the nomination forms (form Nos. 43 and 44) directly to RO prior
to 3.00 p.m., at 2.20 p.m.”
68. Thus, it is clear that apart from the evidence in the form of electronic record, other evidence was
also relied upon to arrive at the same conclusion. The High Court’s judgment therefore cannot be
faulted.
69. Shri Adsure, however, attacked the impugned judgment when it held that the improper
acceptance of the nomination form of the RC himself being involved in the matter, no further
pleadings and particulars on whether the election is “materially affected” were required, as it can be
assumed that if such plea is accepted, the election would be materially affected, as the election
would then be set aside. He cited a Division Bench judgment of this Court in Rajendra Kumar
Meshram v. Vanshmani Prasad Verma (2016) 10 SCC 715, wherein an election petition was filed
against the appellant, inter alia, on the ground that as the appellant - the returned candidate - was a
Government servant, his nomination had been improperly accepted. The Court held that the
requirement of Section 100(1)(d) of the Representation of People Act, 1951, being that the election
can be set aside only if such improper acceptance of the nomination has “materially affected” the
result of the election, and there being no pleading or evidence to this effect, the election petition
must fail. This Court stated:
“9. As Issues 1 and 2 extracted above, have been answered in favour of the returned
candidate and there is no cross-appeal, it is only the remaining issues that survive for
consideration. All the said issues centre round the question of improper acceptance of
the nomination form of the returned candidate. In this regard, Issue 6 which raises
the question of material effect of the improper acceptance of nomination of the
returned candidate on the result of the election may be specifically noticed.
10. Under Section 100(1)(d), an election is liable to be declared void on the ground of
improper acceptance of a nomination if such improper acceptance of the nomination
has materially affected the result of the election. This is in distinction to what is
contained in Section 100(1)(c) i.e. improper rejection of a nomination which itself is a
sufficient ground for invalidating the election without any further requirement of
proof of material effect of such rejection on the result of the election. The above
distinction must be kept in mind. Proceeding on the said basis, we find that the High
Court did not endeavour to go into the further question that would be required to be
determined even if it is assumed that the appellant returned candidate had not filed
the electoral roll or a certified copy thereof and, therefore, had not complied with the
mandatory provisions of Section 33(5) of the 1951 Act.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

11. In other words, before setting aside the election on the above ground, the High
Court ought to have carried out a further exercise, namely, to find out whether the
improper acceptance of the nomination had materially affected the result of the
election. This has not been done notwithstanding Issue 6 framed which is specifically
to the above effect. The High Court having failed to determine the said issue i.e. Issue
6, naturally, it was not empowered to declare the election of the appellant returned
candidate as void even if we are to assume that the acceptance of the nomination of
the returned candidate was improper.”
70. On the other hand, Ms. Meenakshi Arora cited a Division Bench judgment in Mairembam
Prithviraj v. Pukhrem Sharatchandra Singh (2017) 2 SCC 487. In this judgment, several earlier
judgments of this Court were cited on the legal effect of not pleading or proving that the election had
been “materially affected” by the improper acceptance of a nomination under Section 100(1)(d)(i) of
the Representation of People Act, 1951. After referring to Durai Muthuswami v. N. Nachiappan and
Ors. 1973(2) SCC 45 and Jagjit Singh v. Dharam Pal Singh 1995 Supp (1) SCC 422, this Court then
referred to a three-Judge Bench judgment in Vashist Narain Sharma v. Dev Chandra 1955 (1) SCR
509 as under:
“25. It was held by this Court in Vashist Narain Sharma v. Dev Chandra [(1955) 1 SCR
509] as under:
“9. The learned counsel for the respondents concedes that the burden of proving that
the improper acceptance of a nomination has materially affected the result of the
election lies upon the petitioner but he argues that the question can arise in one of
three ways:
(1) where the candidate whose nomination was improperly accepted had secured less
votes than the difference between the returned candidate and the candidate securing
the next highest number of votes, (2) where the person referred to above secured
more votes, and (3) where the person whose nomination has been improperly
accepted is the returned candidate himself.
It is agreed that in the first case the result of the election is not materially affected because if all the
wasted votes are added to the votes of the candidate securing the highest votes, it will make no
difference to the result and the returned candidate will retain the seat. In the other two cases it is
contended that the result is materially affected. So far as the third case is concerned it may be
readily conceded that such would be the conclusion…” This Court then concluded:
“26. Mere finding that there has been an improper acceptance of the nomination is
not sufficient for a declaration that the election is void under Section 100(1)
(d). There has to be further pleading and proof that the result of the election of the
returned candidate was materially affected. But, there would be no necessity of any
proof in the event of the nomination of a returned candidate being declared as havingArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

been improperly accepted, especially in a case where there are only two candidates in
the fray. If the returned candidate's nomination is declared to have been improperly
accepted it would mean that he could not have contested the election and that the
result of the election of the returned candidate was materially affected need not be
proved further…”
71. None of the earlier judgments of this Court referred to in Mairembam Prithviraj (supra) have
been adverted to in Rajendra Kumar Meshram (supra) cited by Shri Adsure. In particular, the
judgment of three learned Judges of this Court in Vashist Narain Sharma (supra) has specifically
held that where the person whose nomination has been improperly accepted is the returned
candidate himself, it may be readily conceded that the conclusion has to be that the result of the
election would be “materially affected”, without there being any necessity to plead and prove the
same. The judgment in Rajendra Kumar Meshram (supra), not having referred to these earlier
judgments of a larger strength binding upon it, cannot be said to have declared the law correctly. As
a result thereof, the impugned judgment of the High Court is right in its conclusion on this point
also.
72. The reference is thus answered by stating that:
(a) Anvar P.V. (supra), as clarified by us hereinabove, is the law declared by this
Court on Section 65B of the Evidence Act. The judgment in Tomaso Bruno (supra),
being per incuriam, does not lay down the law correctly. Also, the judgment in SLP
(Crl.) No. 9431 of 2011 reported as Shafhi Mohammad (supra) and the judgment
dated 03.04.2018 reported as (2018) 5 SCC 311, do not lay down the law correctly and
are therefore overruled.
(b) The clarification referred to above is that the required certificate under Section 65B(4) is
unnecessary if the original document itself is produced. This can be done by the owner of a laptop
computer, computer tablet or even a mobile phone, by stepping into the witness box and proving
that the concerned device, on which the original information is first stored, is owned and/or
operated by him. In cases where the “computer” happens to be a part of a “computer system” or
“computer network” and it becomes impossible to physically bring such system or network to the
Court, then the only means of providing information contained in such electronic record can be in
accordance with Section 65B(1), together with the requisite certificate under Section 65B(4). The
last sentence in Anvar P.V. (supra) which reads as “…if an electronic record as such is used as
primary evidence under Section 62 of the Evidence Act…” is thus clarified; it is to be read without
the words “under Section 62 of the Evidence Act,…” With this clarification, the law stated in
paragraph 24 of Anvar P.V. (supra) does not need to be revisited.
(c) The general directions issued in paragraph 62 (supra) shall hereafter be followed by courts that
deal with electronic evidence, to ensure their preservation, and production of certificate at the
appropriate stage. These directions shall apply in all proceedings, till rules and directions under
Section 67C of the Information Technology Act and data retention conditions are formulated for
compliance by telecom and internet service providers.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(d) Appropriate rules and directions should be framed in exercise of the Information Technology
Act, by exercising powers such as in Section 67C, and also framing suitable rules for the retention of
data involved in trial of offences, their segregation, rules of chain of custody, stamping and record
maintenance, for the entire duration of trials and appeals, and also in regard to preservation of the
meta data to avoid corruption. Likewise, appropriate rules for preservation, retrieval and production
of electronic record, should be framed as indicated earlier, after considering the report of the
Committee constituted by the Chief Justice’s Conference in April, 2016.
73. These appeals are dismissed with costs of INR One Lakh each to be paid by Shri Arjun Panditrao
Khotkar (i.e. the Appellant in C.A. Nos. 20825-20826 of 2017) to both Shri Kailash Kushanrao
Gorantyal and Shri Vijay Chaudhary.
…………………..………………J. (R. F. Nariman) ……………..……………………J. (S. Ravindra Bhat)
……………..……………………J. (V. Ramasubramanian) New Delhi.
14th July, 2020.
REPORTABLE IN THE SUPREME COURT OF INDIA CIVIL APPELLATE JURISDICTION CIVIL
APPEAL NOS.20825−20826 OF 2017 ARJUN PANDITRAO KHOTKAR …Appellant Versus
KAILASH KUSHANRAO GORANTYAL AND ORS.…Respondents WITH CIVIL APPEAL NO.2407
OF 2018 CIVIL APPEAL NO.3696 OF 2018 JUDGMENT V. Ramasubramanian.J
1. While I am entirely in agreement with the opinion penned by R. F. Nariman, J. I also wish to add
a few lines about (i) the reasons for the acrimony behind Section 65B of the Indian Evidence Act,
1872 (hereinafter “Evidence Act”) (ii) how even with the existing rules of procedure, the courts fared
well, without any legislative interference, while dealing with evidence in analogue form, and (iii)
how after machines in analogue form gave way to machines in electronic form, certain jurisdictions
of the world changed their legal landscape, over a period of time, by suitably amending the law, to
avoid confusions and conflicts.
I. Reasons for the acrimony behind Section 65B
2. Documentary evidence, in contrast to oral evidence, is required to pass through certain check
posts, such as
(i) admissibility (ii) relevancy and (iii) proof, before it is allowed entry into the sanctum. Many
times, it is difficult to identify which of these check posts is required to be passed first, which to be
passed next and which to be passed later. Sometimes, at least in practice, the sequence in which
evidence has to go through these three check posts, changes. Generally and theoretically,
admissibility depends on relevancy. Under Section 136 of the Evidence Act, relevancy must be
established before admissibility can be dealt with.
Therefore if we go by Section 136, a party should first show relevancy, making it the first check post
and admissibility the second one. But some documents, such as those indicated in Section 68 of theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Evidence Act, which pass the first check post of relevancy and the second check post of admissibility
may be of no value unless the attesting witness is examined. Proof of execution of such documents,
in a manner established by law, thus constitutes the third check post. Here again, proof of execution
stands on a different footing than proof of contents.
3. It must also be noted that whatever is relevant may not always be admissible, if the law imposes
certain conditions. For instance, a document, whose contents are relevant, may not be admissible, if
it is a document requiring stamping and registration, but had not been duly stamped and registered.
In other words, if admissibility is the cart, relevancy is the horse, under Section 136. But certain
provisions of law place the cart before the horse and Section 65B appears to be one of them.
4. Section 136 which confers a discretion upon the Judge to decide as to the admissibility of evidence
reads as follows:
136. Judge to decide as to admissibility of evidence. –– When either party proposes
to give evidence of any fact, the Judge may ask the party proposing to give the
evidence in what manner the alleged fact, if proved, would be relevant;
and the Judge shall admit the evidence if he thinks that the fact, if proved, would be relevant, and
not otherwise.
If the fact proposed to be proved is one of which evidence is admissible only upon proof of some
other fact, such last−mentioned fact must be proved before evidence is given of the fact first−
mentioned, unless the party undertakes to give proof of such fact, and the Court is satisfied with
such undertaking.
If the relevancy of one alleged fact depends upon another alleged fact being first proved, the Judge
may, in his discretion, either permit evidence of the first fact to be given before the second fact is
proved, or require evidence to be given of the second fact before evidence is given of the first fact.
5. There are three parts to Section 136. The first part deals with the discretion of the Judge to admit
the evidence, if he thinks that the fact sought to be proved is relevant. The second part of Section 136
states that if the fact proposed to be proved is one, of which evidence is admissible only upon proof
of some other fact, such last mentioned fact must be proved before evidence is given of the fact first
mentioned. But this rule is subject to a small concession, namely, that if the party undertakes to
produce proof of the last mentioned fact later and the Court is satisfied about such undertaking, the
Court may proceed to admit evidence of the first mentioned fact. The third part of Section 136 deals
with the relevancy of one alleged fact, which depends upon another alleged fact being first proved.
The third part of Section 136 has no relevance for our present purpose.
6. Illustration (b) under Section 136 provides an easy example of the second part of Section 136.
Illustration
(b) reads as follows:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(b) It is proposed to prove, by a copy, the contents of a document said to be lost.
The fact that the original is lost must be proved by the person proposing to produce the copy, before
the copy is produced.
7. What is laid down in Section 65B as a precondition for the admission of an electronic record,
resembles what is provided in the second part of Section 136. For example, if a fact is sought to be
proved through the contents of an electronic record (or information contained in an electronic
record), the Judge is first required to see if it is relevant, if the first part of Section 136 is taken to be
applicable.
8. But Section 65B makes the admissibility of the information contained in the electronic record
subject to certain conditions, including certification. The certification is for the purpose of proving
that the information which constitutes the computer output was produced by a computer which was
used regularly to store or process information and that the information so derived was regularly fed
into the computer in the ordinary course of the said activities.
9. In other words, if we go by the requirements of Section 136, the computer output becomes
admissible if the fact sought to be proved is relevant. But such a fact is admissible only upon proof of
some other fact namely, that it was extracted from a computer used regularly etc. In simple terms,
what is contained in the computer output can be equated to the first mentioned fact and the
requirement of a certification can be equated to the last mentioned fact, referred to in the second
part of Section 136 read with Illustration (b) thereunder.
10. But Section 65B(1) starts with a non−obstante clause excluding the application of the other
provisions and it makes the certification, a precondition for admissibility. While doing so, it does
not talk about relevancy. In a way, Sections 65A and 65B, if read together, mix−up both proof and
admissibility, but not talk about relevancy. Section 65A refers to the procedure prescribed in Section
65B, for the purpose of proving the contents of electronic records, but Section 65B speaks entirely
about the preconditions for admissibility. As a result, Section 65B places admissibility as the first or
the outermost check post, capable of turning away even at the border, any electronic evidence,
without any enquiry, if the conditions stipulated therein are not fulfilled.
11. The placement by Section 65B, of admissibility as the first or the border check post, coupled with
the fact that a number of ‘computer systems’ (as defined in Section 2(l) of the Information
Technology Act, 2000) owned by different individuals, may get involved in the production of an
electronic record, with the ‘originator’ (as defined in Section 2(za) of the Information Technology
Act, 2000) being different from the recipients or the sharers, has created lot of acrimony behind
Section 65B, which is evident from the judicial opinion swinging like a pendulum.
II. How the courts dealt with evidence in analogue form without legislative interference and the shift
12. It is a matter of fact and record that courts all over the world were quick to adapt themselves to
evidence in analogue form, within the framework of archaic, centuries old rules of evidence. It wasArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

not as if evidence in analogue form was incapable of being manipulated. But the courts managed the
show well by applying time tested rules for sifting the actual from the manipulated.
13. It is no doubt true that the felicity with which courts adapted themselves to appreciating
evidence in analogue form was primarily due to the fact that in analogue technology, one is able to
see and/ or perceive something that is happening. In analogue technology, a wave is recorded or
used in its original form. When someone speaks or sings, a signal is taken directly by the
microphone and laid onto a tape, if we take the example of an analogue tape recorder. Both, the
wave from the microphone and the wave on the tape, are analogue and the wave on the tape can be
read, amplified and sent to a speaker to produce the sound. In digital technology, the analogue wave
is sampled at some interval and then turned into numbers that are stored in a digital device.
Therefore, what are stored, are in terms of numbers and they are, in turn, converted into voltage
waves to produce what was stored.
14. The difference between something in analogue form and the same thing in digital form and the
reason why digital format throws more challenges, was presented pithily in an article titled
‘Electronic evidence and the meaning of “original”’,9 by Stephen Mason (Barrister and recognised
authority on electronic 9 Stephen Mason, Electronic evidence and the meaning of “original”, 79
Amicus Curiae 26 (2009) signatures and electronic evidence). Taking the example of a photograph
in both types of form, the learned author says the following:
For instance, a photograph taken with an analogue camera (that is, a camera with a
film) can only remain a single object. It cannot be merged into other photographs,
and split off again. It remains a physical object. A photograph taken with a digital
camera differs markedly. The digital object, made up of a series of zeros and the
number one, can be, and frequently is, manipulated and altered (especially in fashion
magazines and for advertisements). Things can be taken out and put in to the image,
in the same way the water droplets can merge and form a single, larger droplet. The
new, manipulated digital image can also be divided back into its constituent parts.
Herein lies the interesting point: when three droplets of water fuse and then separate
into three droplets, it is to be questioned whether the three droplets that merge from
the bigger droplet were the identical droplets that existed before they merged. In the
same way, consider a digital object that has been manipulated and added to, and the
process is then reversed. The original object that was used remains (unless it was
never saved independently, and the changes made to the image were saved in the
original file), but another object, with the identical image (or near identical,
depending on the system software and application software) now exists.
Conceptually, it is possible to argue that the two digital images are different: one is
the original, the other a copy of the original that was manipulated and returned to its
original state (whatever “original” means). But both images are identical, apart from
some additional meta data that might, or might not be conclusive. However, it is
apparent that the images, if viewed together, are identical – will be identical, and the
viewer will not be able to determine which is the original, and which image wasArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

manipulated. In this respect, the digital images are no different from the droplets of
rain that fall, merge, then divide: there is no telling whether the droplets that split are
identical to the droplets that came together to form the larger droplet.
15. That courts did not have a problem with the evidence in analogue form is
established by several judicial precedents, in U.K., which were also followed by our
courts. A device used to clandestinely record a conversation between two individuals
was allowed in Harry Parker vs. Mason10 in proving fraud on the part of the plaintiff.
While Harry Parker was a civil proceeding, the principle laid down therein found
acceptance in a criminal trial in R. vs. Burr and 10 [1940] 2 KB 590 Sullivan.11 The
High Court of Judiciary in Scotland admitted in evidence, the tape record of a
conversation between the complainant and a black mailer, in Hopes and Lavery vs.
H. M. Advocate.12 A conversation recorded in police cell overheard without any
deception, beyond setting up a tape recorder without warning, was admitted in
evidence in R. vs. Mills.13
16. Then came R. vs. Maqsud Ali14 where Marshall J.
drew an analogy between tape−recordings and photographs and held that just as evidence of things
seen through telescopes or binoculars have been admitted, despite the fact that those things could
not be picked up by the naked eye, the devices used for recording conversations could also be
admitted, provided the accuracy of the recording 11 [1956] Crim LR 442 12 [1960] Crim LR 566 13
[1962] 3 All ER 298 14 [1965] 2 All ER 464 can be proved and the voices recorded properly
identified.
17. Following the above precedents, this Court also held in S. Pratap Singh vs. State of Punjab,15
Yusaffalli Esmail Nagree vs. State of Maharashtra,16 N. Sri Rama Reddy vs. V. V. Giri,17 R.M.
Malkani vs. State of Maharashtra,18 Ziyauddin Burhanuddin Bukhari vs. Brijmohan Ramdass
Mehra,19 Ram Singh vs. Col. Ram Singh,20 Tukaram S. Dighole vs. Manikrao Shivaji Kokate,21 that
tape records of conversations and speeches are admissible in evidence under the Indian Evidence
Act, subject to certain conditions. In Ziyauddin Burhanuddin Bukhari and Tukaram S. Dighole, this
Court further held that tape records constitute “document” within the meaning of 15 (1964) 4 SCR
753 16 (1967) 3 SCR 720 17 AIR 1972 SC 1162 18 AIR 1973 SC 157 19 (1976) 2 SCC 17 20 AIR 1986 SC
3 21 (2010) 4 SCC 329 the expression under Section 3 of the Evidence Act.
Thus, without looking up to the law makers to come up with necessary amendments from time to
time, the courts themselves developed certain rules, over a period of time, to test the authenticity of
these documents in analogue form and these rules have in fact, worked well.
18. There was also an important question that bothered the courts while dealing with evidence in
analogue form. It was as to whether such evidence was direct or hearsay. In The Statute of Liberty,
Sapporo Maru M/S (Owners) vs. Steam Tanker Statute of Liberty (Owners),22 the film recording of
a radar set of echoes of ships within its range was held to be real evidence. The court opined that
there was no distinction between a photographer operating a camera manually and the observationsArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

of a barometer operator or its equivalent operation by a recording mechanism. The Judge rejected
the contention that the evidence was hearsay. 22 [1968] 2 All ER 195
19. But when it comes to a computer output, one of the earliest of cases where the Court of Appeal
had to deal with evidence in the form of a printout from a computer was in R. vs. Pettigrew.23 In
that case, the printout from a computer operated by an employee of the Bank of England was held to
be hearsay. But the academic opinion about the correctness of the decision was sharply divided.
While Professor Smith24 considered the evidence in this case as direct and not hearsay, Professor
Tapper25 took the view that the printout was partly hearsay and partly not. Professor Seng26
thought that both views were plausible.
20. But the underlying theory on the basis of which academicians critiqued the above judgment is
that wherever the production of the output was made possible without human intervention, the
evidence 23 [1980] 71 Cr. App. R. 39 24 Professor Smith was a well−known authority on criminal
law and law of evidence; J. C. Smith, The admissibility of statements by computer, Crim LR 387,
388 (1981). 25 Professor Tapper is a well−known authority on law of evidence; Colin Tapper,
Reform of the law of evidence in relation to the output from computers, 3 IntlJ L & Info Tech 87
(1995).
26 Professor Seng is an Associate Professor at the National University of Singapore; Daniel K B
Seng, Computer output as evidence, Sing JLS 139 (1997). should be taken as direct. This is how the
position was explained in Castle vs. Cross,27 in which the printout from the Intoximeter was held to
be direct and not hearsay, on the ground that the breath alcohol value in the printout comprised
information produced by the Intoximeter without the data being processed through a human brain.
21. In R vs. Robson Mitchell and Richards,28 a printout of telephone calls made on a mobile
telephone was taken as evidence of the calls made and received in association with the number. The
Court held “where a machine observes a fact and records it, that record states a fact. It is evidence of
what the machine recorded and this was printed out. The record was not the fact but the evidence of
the fact”.
27 [1984] 1 WLR 1372 28 [1991] Crim LR 360
22. But the facility of operating in anonymity in the cyber space, has made electronic records more
prone to manipulation and consequently to a greater degree of suspicion. Therefore, law makers
interfered, sometimes making things easy for courts and sometimes creating a lot of confusion. But
over a period of time, certain jurisdictions have come up with reasonably good solutions. Let us now
take a look at them.
III. Legislative developments in U.S.A., U.K. and Canada on the admissibility of electronic records
POSITION IN USA
23. The Federal Rules of Evidence (FRE) of the United States of America as amended with effect
from 01.12.2017 recognise the availability of more than one option to a person seeking to produce anArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

electronic record. Under the amended rules, a person can follow either the traditional route under
Rule 901 or the route of self−authentication under Rule 902 whereunder a certificate of authenticity
will elevate its status. Rules 901 and 902 of FRE read as follows:
Rule 901. Authenticating or Identifying Evidence
(a) In General. To satisfy the requirement of authenticating or identifying an item of
evidence, the proponent must produce evidence sufficient to support a finding that
the item is what the proponent claims it is.
(b) Examples. The following are examples only —not a complete list—of evidence that
satisfies the requirement:
(1) Testimony of a Witness with Knowledge. Testimony that an item is what it is
claimed to be.
(2) Non expert Opinion About Handwriting. A non expert's opinion that handwriting
is genuine, based on a familiarity with it that was not acquired for the current
litigation. (3) Comparison by an Expert Witness or the Trier of Fact. A comparison
with an authenticated specimen by an expert witness or the trier of fact.
(4) Distinctive Characteristics and the Like. The appearance, contents, substance,
internal patterns, or other distinctive characteristics of the item, taken together with
all the circumstances.
(5) Opinion About a Voice. An opinion identifying a person's voice—whether heard
firsthand or through mechanical or electronic transmission or recording—based on
hearing the voice at any time under circumstances that connect it with the alleged
speaker.
(6) Evidence About a Telephone Conversation. For a telephone conversation,
evidence that a call was made to the number assigned at the time to:
(A) a particular person, if circumstances, including self−identification, show that the
person answering was the one called; or (B) a particular business, if the call was
made to a business and the call related to business reasonably transacted over the
telephone. (7) Evidence About Public Records. Evidence that:
(A) a document was recorded or filed in a public office as authorized by law; or (B) a
purported public record or statement is from the office where items of this kind are
kept.
(8) Evidence About Ancient Documents or Data Compilations. For a document or
data compilation, evidence that it:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(A) is in a condition that creates no suspicion about its authenticity;
(B) was in a place where, if authentic, it would likely be; and (C) is at least 20 years
old when offered.
(9) Evidence About a Process or System. Evidence describing a process or system and
showing that it produces an accurate result.
(10) Methods Provided by a Statute or Rule. Any method of authentication or
identification allowed by a federal statute or a rule prescribed by the Supreme Court.
Rule 902. Evidence That Is Self− Authenticating The following items of evidence are self−
authenticating; they require no extrinsic evidence of authenticity in order to be admitted:
(1) Domestic Public Documents That Are Sealed and Signed. A document that bears:
(A) a seal purporting to be that of the United States; any state, district,
commonwealth, territory, or insular possession of the United States; the former
Panama Canal Zone; the Trust Territory of the Pacific Islands; a political subdivision
of any of these entities; or a department, agency, or officer of any entity named
above; and (B) a signature purporting to be an execution or attestation.
(2) Domestic Public Documents That Are Not Sealed but Are Signed and Certified. A
document that bears no seal if:
(A) it bears the signature of an officer or employee of an entity named in Rule
902(1)(A); and (B) another public officer who has a seal and official duties within that
same entity certifies under seal—or its equivalent—that the signer has the official
capacity and that the signature is genuine.
(3) Foreign Public Documents. A document that purports to be signed or attested by
a person who is authorized by a foreign country's law to do so. The document must be
accompanied by a final certification that certifies the genuineness of the signature
and official position of the signer or attester—or of any foreign official whose
certificate of genuineness relates to the signature or attestation or is in a chain of
certificates of genuineness relating to the signature or attestation. The certification
may be made by a secretary of a United States embassy or legation; by a consul
general, vice consul, or consular agent of the United States;
or by a diplomatic or consular official of the foreign country assigned or accredited to the United
States. If all parties have been given a reasonable opportunity to investigate the document's
authenticity and accuracy, the court may, for good cause, either:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

(A) order that it be treated as presumptively authentic without final certification; or
(B) allow it to be evidenced by an attested summary with or without final
certification. (4) Certified Copies of Public Records. A copy of an official record—or a
copy of a document that was recorded or filed in a public office as authorized by
law—if the copy is certified as correct by:
(A) the custodian or another person authorized to make the certification; or (B) a
certificate that complies with Rule 902(1), (2), or (3), a federal statute, or a rule
prescribed by the Supreme Court.
(5) Official Publications. A book, pamphlet, or other publication purporting to be
issued by a public authority.
(6) Newspapers and Periodicals. Printed material purporting to be a newspaper or
periodical.
(7) Trade Inscriptions and the Like. An inscription, sign, tag, or label purporting to
have been affixed in the course of business and indicating origin, ownership, or
control.
(8) Acknowledged     Documents. A     document
accompanied       by    a     certificate   of
acknowledgment that is lawfully executed by a notary public or another officer who is
authorized to take acknowledgments.
(9) Commercial Paper and Related Documents. Commercial paper, a signature on it,
and related documents, to the extent allowed by general commercial law.
(10) Presumptions Under a Federal Statute. A signature, document, or anything else
that a federal statute declares to be presumptively or prima facie genuine or
authentic.
(11) Certified Domestic Records of a Regularly Conducted Activity. The original or a
copy of a domestic record that meets the requirements of Rule 803(6)(A)–(C), as
shown by a certification of the custodian or another qualified person that complies
with a federal statute or a rule prescribed by the Supreme Court. Before the trial or
hearing, the proponent must give an adverse party reasonable written notice of the
intent to offer the record—and must make the record and certification available for
inspection —so that the party has a fair opportunity to challenge them.
(12) Certified Foreign Records of a Regularly Conducted Activity. In a civil case, the
original or a copy of a foreign record that meets the requirements of Rule 902(11),
modified as follows: the certification, rather than complying with a federal statute or
Supreme Court rule, must be signed in a manner that, if falsely made, would subjectArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

the maker to a criminal penalty in the country where the certification is signed. The
proponent must also meet the notice requirements of Rule 902(11).
(13) Certified Records Generated by an Electronic Process or System. A record
generated by an electronic process or system that produces an accurate result, as
shown by a certification of a qualified person that complies with the certification
requirements of Rule 902(11) or (12). The proponent must also meet the notice
requirements of Rule 902(11). (14) Certified Data Copied from an Electronic Device,
Storage Medium, or File. Data copied from an electronic device, storage medium, or
file, if authenticated by a process of digital identification, as shown by a certification
of a qualified person that complies with the certification requirements of Rule
902(11) or (12). The proponent also must meet the notice requirements of Rule
902(11).
24. An important decision in the American jurisprudence on this issue was delivered by Chief
Magistrate Judge of District of Maryland in Lorraine vs. Markel American Insurance Co.29 In this
case, Paul Grimm, J. while dealing with a challenge to an arbitrator’s decision in an insurance
dispute, dealt with the issue whether emails discussing the insurance policy in question, were
admissible as evidence. The Court, while extending the applicability of Rules 901 and 902 of FRE to
electronic evidence, laid down a broad test for admissibility of electronically stored information. 30
This decision was rendered in 2007 and the FRE were amended in 2017.
29 241 FRD 534 (2007) 30 Paragraph 2: “Whenever ESI is offered as evidence, either at trial or in
summary judgment, the following evidence rules must be considered: (1) is the ESI relevant as
determined by Rule 401 (does it have any tendency to make some fact that is of consequence to the
litigation more or less probable than it otherwise would be); (2) if relevant under 401, is it authentic
as required by Rule 901(a) (can the proponent show that the ESI is what it purports to be); (3) if the
ESI is offered for its substantive truth, is it hearsay as defined by Rule 801, and if so, is it covered by
an applicable exception (Rules 803, 804 and 807); (4) is the form of the ESI that is being offered as
evidence an original or duplicate under the original writing rule, of if not, is there admissible
secondary evidence to prove the content of the ESI (Rules 1001–1008); and (5) is the probative
value of the ESI substantially outweighed by the danger of unfair prejudice or one of the other
factors identified by Rule 403, such that it should be excluded despite its relevance.”
25. Sub−rules (13) and (14) were incorporated in Rule 902 under the amendment of the year 2017.
Until then, a person seeking to produce electronic records had to fall back mostly upon Rule 901
(except in few cases covered by sub−rules (11) and (12) of Rule 902). It means that the benefit of
self−authentication was not available until then [until the advent of sub−rules (13) and (14), except
in cases covered by sub−rules (11) and (12)]. Nevertheless, the introduction of sub−rules (13) and
(14) in Rule 902 did not completely exclude the application of the general provisions of Rule 901.
26. Rule 901 applies to all evidence across the board. It is a general provision. But Rule 902 is a
special provision dealing with evidence that is self−authenticating. Records generated by an
electronic process or system and data copied from an electronic device, storage medium or file, areArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

included in sub−rules (13) and (14) of Rule 902 of the Federal Rules of Evidence.
27. But FRE 902 does not exclude the application of FRE
901. It is only when a party seeks to invoke the benefit of self−authentication that Rule 902 applies.
If a party chooses not to claim the benefit of self−authentication, he is free to come under Rule 901,
even if the evidence sought to be adduced is of an electronically stored information (ESI).
28. In an article titled ‘E−Discovery: Authenticating Common Types of ESI Chart’, authored by Paul
W. Grimm (the Judge who delivered the verdict in Lorraine) and co−authored by Gregory P. Joseph
and published by Thomson Reuters (2017), the learned authors have given a snapshot of the
different methods of authentication of various types of ESI (electronically stored information). In a
subsequent article (2018) titled ‘Admissibility of Electronic Evidence’ published under the caption
‘Grimm−Brady Chart’ (referring to Paul W. Grimm and Kevin F. Brady) on the website
“complexdiscovery.com”, a condensed chart is provided which throws light on the different methods
of authentication of ESI. The chart is reproduced in the form of a table, with particular reference to
the relevant sub−rules of Rules 901 and 902 of the Federal Rules of Evidence as follows:
S. No. Type of ESI Potential Authentication Methods
1. Email, Text ■ Witness with personal knowledge Messages, and (901(b)(1)) Instant
Messages ■ Expert testimony or comparison with authenticated examples (901(b)(3))
■ Distinctive characteristics including circumstantial evidence (901(b)(4)) ■ System
or process capable of proving reliable and dependable result (901(b)(9)) ■ Trade
inscriptions (902(7)) ■ Certified copies of business record (902(11)) ■ Certified
records generated by an electronic process or system (902(13)) ■ Certified data
copied from an electronic device, storage medium, or file (902(14))
2. Chat Room Postings, ■ Witness with personal knowledge Blogs, Wikis, and
(901(b)(1)) Other Social Media ■ Expert testimony or comparison Conversations with
authenticated examples (901(b)(3)) ■ Distinctive characteristics including
circumstantial evidence (901(b)(4)) ■ System or process capable of proving reliable
and dependable result (901(b)(9)) ■ Official publications (902(5)) ■ Newspapers and
periodicals (902(6)) ■ Certified records generated by an electronic process or system
(902(13)) ■ Certified data copied from an electronic device, storage medium, or file
(902(14))
3. Social Media Sites ■ Witness with personal knowledge (Facebook, LinkedIn,
(901(b)(1)) Twitter, ■ Expert testimony or comparison Instagram, and with
authenticated examples Snapchat) (901(b)(3)) ■ Distinctive characteristics including
circumstantial evidence (901(b)(4)) ■ Public records (901(b)(7)) ■ System or process
capable of proving reliable and dependable result (901(b)(9)) ■ Official publications
(902(5)) ■ Certified records generated by an electronic process or system (902(13)) ■
Certified data copied from an electronic device, storage medium, or file (902(14))Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

4. Digitally Stored Data ■ Witness with personal knowledge and Internet of
(901(b)(1)) Things ■ Expert testimony or comparison with authenticated examples
(901(b)(3)) ■ Distinctive characteristics including circumstantial evidence
(901(b)(4)) ■ System or process capable of proving reliable and dependable result
(901(b)(9)) ■ Certified records generated by an electronic process or system
(902(13)) ■ Certified data copied from an electronic device, storage medium, or file
(902(14))
5. Computer Processes, ■ Witness with personal knowledge Animations, (901(b)(1))
Virtual Reality, and ■ Expert testimony or comparison Simulations with
authenticated examples (901(b)(3)) ■ System or process capable of proving reliable
and dependable result (901(b)(9)) ■ Certified records generated by an electronic
process or system (902(13))
6. Digital Photographs ■ Witness with personal knowledge (901(b)(1)) ■ System or
process capable of providing reliable and dependable result (901(b)(9)) ■ Official
publications (902(5)) ■ Certified records generated by an electronic process or
system (902(13)) ■ Certified data copied from an electronic device, storage medium,
or file (902(14))
29. It is interesting to note that while the Indian Evidence Act is of the year 1872, the Federal Rules
of Evidence were adopted by the order of the Supreme Court of the United States exactly 100 years
later, in 1972 and they were enacted with amendments made by the Congress to take effect on
01.07.1975. Yet, the Rules were found inadequate to deal with emerging situations and hence,
several amendments were made, including the one made in 2017 that incorporated specific
provisions relating to electronic records under sub−rules (13) and (14) of FRE 902. After this
amendment, a lot of options have been made available to litigants seeking to rely upon electronically
stored information, one among them being the route provided by sub−rules (13) and (14) of FRE
902. This development of law in the US demonstrates that, unlike in India, law has kept pace with
technology to a great extent.
POSITION IN UK
30. As pointed out in the main opinion, Section 65B, in its present form, is a poor reproduction of
Section 5 of the UK Civil Evidence Act, 1968. The language employed in sub−sections (2), (3), (4)
and (5) of Section 65B is almost in pari materia (with minor differences) with sub−sections (2) to (5)
of Section 5 of the UK Civil Evidence Act, 1968. However, sub−section (1) of Section 65B is
substantially different from sub−section (1) of Section 5 of the UK Civil Evidence Act, 1968. But it
also contains certain additional words in sub−section (1) namely “without further proof or
production of the original”. For easy comparison and appreciation, sub− section (1) of Section 65B
of the Indian Evidence Act and sub−section (1) of Section 5 of UK Civil Evidence Act, 1968 are
presented in a tabular form as follows:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Section 65B(1), Indian Section 5(1), Civil Evidence Evidence Act, 1872 Act, 1968 [UK]
Notwithstanding anything In any civil proceedings a contained in this Act, any
statement contained in a information contained in an document produced by a
electronic record which is printed computer shall, subject to rules of on a paper,
stored, recorded or court, be admissible as evidence copied in optical or magnetic of
any fact stated therein of media produced by a computer which direct oral evidence
would (hereinafter referred to as the be admissible, if it is shown that computer
output) shall be the conditions mentioned in deemed to be also a document, if
subsection (2) below are satisfied the conditions mentioned in this section are
satisfied in relation to in relation to the statement and the information and computer
in computer in question. question and shall be admissible in any proceedings,
without further proof or production of the original, as evidence of any contents of the
original or of any fact stated therein of which direct evidence would be admissible.
31. But the abovementioned Section 5 of the U.K. Act of 1968 was repealed by the Civil Evidence Act,
1995. Section 15(2) of the Civil Evidence Act, 1995 repealed the enactments specified in Schedule II
therein. Under Schedule II of the 1995 Act, Part I of the 1968 Act containing Sections 1−10 were
repealed. The effect is that when Section 65B was incorporated in the Indian Evidence Act, by Act 21
of 2000, by copying sub− sections (2) to (5) of Section 5 of the UK Civil Evidence Act, 1968, Section
5 itself was not there in the U.K. statute book, as a result of its repeal under the 1995 Act.
32. The repeal of Section 5 under the 1995 Act was a sequel to the recommendations made by the
Law Commission in September 1993. Part III of the Law Commission’s report titled ‘The Hearsay
Rule in Civil Proceedings’ noted the problems with the 1968 Act, one of which concerned computer
records. Paragraphs 3.14 to 3.21 in Part III of the Law Commission’s report read as follows:
Computer records 3.14 A fundamental mistrust and fear of the potential for error or
mechanical failure can be detected in the elaborate precautions governing computer
records in section 5 of the 1968 Act.
The Law Reform Committee had not recommended special provisions for such records, and section
5 would appear to have been something of an afterthought with its many safeguards inserted in
order to gain acceptance of what was then a novel form of evidence. Twenty−five years later,
technology has developed to an extent where computers and computer−generated documents are
relied on in every area of business and have long been accepted in banking and other important
record−keeping fields. The conditions have been widely criticised, and it has been said that they are
aimed at operations based on the type of mainframe operations common in the mid 1960s, which
were primarily intended to process in batches thousands of similar transactions on a daily basis.
3.15 So far as the statutory conditions are concerned, there is a heavy reliance on the need to prove
that the document has been produced in the normal course of business and in an uninterrupted
course of activity. It is at least questionable whether these requirements provide any real safeguards
in relation to the reliability of the hardware or software concerned. In addition, they are capable of
operating to exclude wide categories of documents, particularly those which are produced as theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

result of an original or a “one off” piece of work. Furthermore, they provide no protection against the
inaccurate inputting of data.
3.16 We have already referred to the overlap between sections 4 and 5. If compliance with section 5
is a prerequisite, then computer− generated documents which pass the conditions setout in section
5(2) “shall” be admissible, notwithstanding the fact that they originated from a chain of human
sources and that it has not been established that the persons in the chain acted under a duty. In
other words, the record provisions of section 4, which exist to ensure the reliability of the core
information, are capable of being disapplied. In the context of our proposed reforms, we do not
consider that this apparent discrepancy is of any significance, save that it illustrates the fact that
section 5 was something of an afterthought.
3.17 Computer−generated evidence falls into two categories. First, there is the situation envisaged by
the 1968 Act, where the computer is used to file and store information provided to it by human
beings. Second, there is the case where the record has itself been produced by the computer,
sometimes entirely by itself but possibly with the involvement of some other machine. Examples of
this situation are computers which are fed information by monitoring devices. A particular example
is automatic stock control systems, which are now in common use and which allow for purchase
orders to be automatically produced. Under such systems evidence of contract formation will lie
solely in the electronic messages automatically generated by the seller’s and buyer’s computers. It is
easy to see how uncertainty as to how the courts may deal with the proof and enforceability of such
contracts is likely to stifle the full development and effective use of such technology. Furthermore,
uncertainty may deter parties from agreeing that contracts made in this way are to be governed by
English law and litigated in the English courts.
3.18 It is interesting to compare the technical manner in which the admissibility of computer−
generated records has developed, compared with cases concerning other forms of sophisticated
technologically produced evidence, for example radar records (See Sapporo Maru (Owners) v.
Statue of Liberty (Owners) [1968] 1 W.L.R. 739). In the Statue of Liberty case radar records,
produced without human involvement and reproduced in photographic form, were held to be
admissible to establish how a collision of two ships had occurred. It was held that this was “real”
evidence, no different in kind from a monitored tape recording of a conversation. Furthermore, in
these cases, no extra tests of reliability need be met and the common law rebuttable presumption is
applied, that the machine was in order at the material time. The same presumption has been applied
to intoximeter printouts (Castle v. Cross [1984] 1 W.L.R. 1372).
3.19 There are a number of cases which establish the way in which courts have sought to distinguish
between types of computer− generated evidence, by finding in appropriate cases that the special
procedures are inapplicable because the evidence is original or direct evidence. As might be
expected, case law on computer−generated evidence is more likely to be generated by criminal cases
of theft or fraud, where the incidence of such evidence is high and the issue of admissibility is more
likely to be crucial to the outcome and hence less liable to be agreed. For example, even in the first
category of cases, where human involvement exists, a computer−generated document may not be
considered to be hearsay if the computer has been used as a mere tool, to produce calculations fromArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

data fed to it by humans, no matter how complex the calculations, or how difficult it may be for
humans to reproduce its work, provided the computer was not “contributing its own knowledge” (R
v. Wood (1983) 76 Cr. App. R.
23).
3.20 There was no disagreement with the view that the provisions relating to computer records were
outdated and that there was no good reason for distinguishing between different forms of record
keeping or maintaining a different regime for the admission of computer− generated documents.
This is the position in Scotland under the 1988 Act. Furthermore, we were informed of fears that
uncertainty over the treatment of such records in civil litigation in the United Kingdom was a
significant hindrance to commerce and needed reform.
3.21 Consultees considered that the real issue for concern was authenticity that this was a matter
which was best dealt with by a vigilant attitude that concentrated upon the weight to be attached to
the evidence, in the circumstances of the individual case, rather than by reformulating complex and
inflexible conditions as to admissibility. (emphasis supplied)
33. In Part IV of the 1993 Report, titled ‘Recommendations for Reform’, Paragraph 4.43 dealt with
the recommendations of the Law Commission in relation to computer records. Paragraph 4.43 of
the Law Commission’s report along with Recommendation Nos. 13, 14 and 15 are reproduced for
easy reference:
(b) Computerised records 4.43 In the light of the criticisms of the present provisions
and the response on consultation, we have decided to recommend that no special
provisions be made in respect of computerised records. This is the position in
Scotland under the 1988 Act and reflects the overwhelming view of commentators,
practitioners and others.
That is not to say that we do not recognise that, as familiarity with and confidence in the inherent
reliability of computers has grown, so has concern over the potential for misuse, through the
capacity to hack, corrupt, or alter information, in manner which is undetectable. We do not
underestimate these dangers.
However the current provisions of section 5 do not afford any protection and it is not possible to
legislate protectively. Nothing in our proposals will either encourage abuse, or prevent a proper
challenge to the admissibility of computerised records, where abuse is suspected. Security and
authentication are problems that experts in the field are constantly addressing and it is a fast
evolving area. The responses from experts in this field, such as the C.B.I., stressed that, whilst
computer−generated information should be treated similarly to other records, such evidence should
be weighed according to its reliability, with parties being encouraged to provide information as to
the security of their systems. We have proposed a wide definition for the word "document". This will
cover documents in any form and in particular will be wide enough to cover computer−generated
information.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

We therefore recommend that:
13. Documents, including those stored by computer, which form part of the records of
a business or public authority should be admissible as hearsay evidence under clause
1 of our draft Bill and the ordinary notice and weighing provisions should apply.
14. The current provisions governing the manner of proof of business records should
be replaced by a simpler regime which allows, unless the court otherwise directs, for
a document to be taken to form part of the records of a business or public authority, if
it is certified as such, and received in evidence without being spoken to in court. No
special provisions should be made in respect of the manner of proof of computerized
records.
15. The absence of an entry should be capable of being formally proved by affidavit of
an officer of the business or authority to which the records belong.
(emphasis in original)
34. The above recommendations of the Law Commission (U.K.) made in 1993, led to the repeal of
Section 5 of the 1968 Act, under the 1995 Act. The rules of evidence in civil cases, in so far as
electronic records are concerned, thus got liberated in U.K. in 1995 with the repeal of Section 5 of
the U.K. Civil Evidence Act,1968.
35. But there is a separate enactment in the U.K., containing the rules of evidence in criminal
proceedings and that is the Police and Criminal Evidence Act, 1984. Section 69 of the said Act laid
down rules for determining when a statement in a document produced by a computer shall not be
admissible as evidence of any fact stated therein. Section 69 of the said Act laid down three
conditions (there are too many negatives in the language employed in Section 69). In simple terms,
they require that it must be shown (i) that there are no reasonable grounds for believing that the
statement is not inaccurate because of improper use of the computer; (ii) that at all material times
the computer was operating properly and (iii) that the additional conditions specified in the rules
made by the court are also satisfied.
36. The abovementioned Section 69 of the Police and Criminal Evidence Act, 1984 (PACE) was
repealed by Section 60 of the Youth Justice and Criminal Evidence Act, 1999. This repeal was also a
sequel to the recommendations made by the Law Commission in June 1997 under its report titled
“Evidence in Criminal Proceedings: Hearsay and Related Topics”. Part 13 of the Law Commission’s
Report dealt with computer evidence in extenso. The problems with Section 69 of the 1984 Act, the
response during the Consultative Process and the eventual recommendations of the U.K. Law
Commission are contained in paragraphs 13.1 to 13.23. They are usefully extracted as follows:
13.1 In Minors ([1989] 1 WLR 441, 443D–E.) Steyn J summed up the major problem
posed for the rules of evidence by computer output:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Often the only record of the transaction, which nobody can be expected to remember,
will be in the memory of a computer… If computer output cannot relatively readily be
used as evidence in criminal cases, much crime (and notably offences involving
dishonesty) would in practice be immune from prosecution. On the other hand,
computers are not infallible. They do occasionally malfunction. Software systems
often have “bugs”. …Realistically, therefore, computers must be regarded as
imperfect devices.
13.2 The legislature sought to deal with this dilemma by section 69 of PACE, which
imposes important additional requirements that must be satisfied before computer
evidence is adduced – whether it is hearsay or not (Shephard [1993] AC 380).
13.3 In practice, a great deal of hearsay evidence is held on computer, and so section
69 warrants careful attention. It must be examined against the requirement that the
use of computer evidence should not be unnecessarily impeded, while giving due
weight to the fallibility of computers.
PACE, SECTION 69 13.4 In the consultation paper we dealt in detail with the
requirements of section 69: in essence it provides that a document produced by a
computer may not be adduced as evidence of any fact stated in the document unless
it is shown that the computer was properly operating and was not being improperly
used.
If there is any dispute as to whether the conditions in section 69 have been satisfied, the court must
hold a trial within the trial to decide whether the party seeking to rely on the document has
established the foundation requirements of section 69.
13.5 In essence, the party relying on computer evidence must first prove that the computer is
reliable – or, if the evidence was generated by more than one computer, that each of them is reliable
(Cochrane [1993] Crim LR 48). This can be proved by tendering a written certificate, or by calling
oral evidence. It is not possible for the party adducing the computer evidence to rely on a
presumption that the computer is working correctly (Shephard [1993] AC 380, 384E). It is also
necessary for the computer records themselves to be produced to the court (Burr v DPP [1996] Crim
LR 324).
The problems with the present law 13.6 In the consultation paper we came to the conclusion that the
present law was unsatisfactory, for five reasons.
13.7 First, section 69 fails to address the major causes of inaccuracy in computer evidence. As
Professor Tapper has pointed out, “most computer error is either immediately detectable or results
from error in the data entered into the machine”.
13.8 Secondly, advances in computer technology make it increasingly difficult to comply with
section 69: it is becoming “increasingly impractical to examine (and therefore certify) all theArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

intricacies of computer operation”. These problems existed even before networking became
common.
13.9 A third problem lies in the difficulties confronting the recipient of a computer− produced
document who wishes to tender it in evidence: the recipient may be in no position to satisfy the
court about the operation of the computer. It may well be that the recipient’s opponent is better
placed to do this.
13.10 Fourthly, it is illogical that section 69 applies where the document is tendered in evidence
(Shephard [1993] AC 380), but not where it is used by an expert in arriving at his or her conclusions
(Golizadeh [1995] Crim LR
232), nor where a witness uses it to refresh his or her memory (Sophocleous v Ringer [1988] RTR
52). If it is safe to admit evidence which relies on and incorporates the output from the computer, it
is hard to see why that output should not itself be admissible; and conversely, if it is not safe to
admit the output, it can hardly be safe for a witness to rely on it.
13.11 At the time of the publication of the consultation paper there was also a problem arising from
the interpretation of section 69. It was held by the Divisional Court in McKeown v DPP ([1995] Crim
LR 69) that computer evidence is inadmissible if it cannot be proved that the computer was
functioning properly – even though the malfunctioning of the computer had no effect on the
accuracy of the material produced. Thus, in that case, computer evidence could not be relied on
because there was a malfunction in the clock part of an Intoximeter machine, although it had no
effect on the accuracy of the material part of the printout (the alcohol reading). On appeal, this
interpretation has now been rejected by the House of Lords: only malfunctions that affect the way in
which a computer processes, stores or retrieves the information used to generate the statement are
relevant to section 69 (DPP v McKeown; DPP v Jones [1997] 1 WLR 295).
13.12 In coming to our conclusion that the present law did not work satisfactorily, we noted that in
Scotland, some Australian states, New Zealand, the United States and Canada, there is no separate
scheme for computer evidence, and yet no problems appear to arise. Our provisional view was that
section 69 fails to serve any useful purpose, and that other systems operate effectively and efficiently
without it.
13.13 We provisionally proposed that section 69 of PACE be repealed without replacement. Without
section 69, a common law presumption comes into play (Phipson, para 23−14, approved by the
Divisional Court in Castle v Cross [1984] 1 WLR 1372, 1377B):
In the absence of evidence to the contrary, the courts will presume that mechanical
instruments were in order at the material time.
13.14 Where a party sought to rely on the presumption, it would not need to lead
evidence that the computer was working properly on the occasion in question unless
there was evidence that it may not have been – in which case the party would have toArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

prove that it was (beyond reasonable doubt in the case of the prosecution, and on the
balance of probabilities in the case of the defence). The principle has been applied to
such devices as speedometers (Nicholas v Penny [1950] 2 KB 466) and traffic lights
(Tingle Jacobs & Co v Kennedy [1964] 1 WLR
638), and in the consultation paper we saw no reason why it should not apply to
computers.
The response on consultation 13.15 On consultation, the vast majority of those who dealt with this
point agreed with us. A number of those in favour said that section 69 had caused much trouble with
little benefit.
13.16 The most cogent contrary argument against our proposal came from David Ormerod. In his
helpful response, he contended that the common law presumption of regularity may not extend to
cases in which computer evidence is central. He cites the assertion of the Privy Council in Dillon v R
([1982] AC 484) that “it is well established that the courts will not presume the existence of facts
which are central to an offence”. If this were literally true it would be of great importance in cases
where computer evidence is central, such as Intoximeter cases (R v Medway Magistrates’ Court, ex p
Goddard [1995] RTR 206). But such evidence has often been permitted to satisfy a central element
of the prosecution case. Some of these cases were decided before section 69 was introduced (Castle v
Cross [1984] 1 WLR 1372); others have been decided since its introduction, but on the assumption
(now held to be mistaken) (Shephard [1993] AC 380) that it did not apply because the statement
produced by the computer was not hearsay (Spiby (1990) 91 Cr App R 186; Neville [1991] Crim LR
288). The presumption must have been applicable; yet the argument successfully relied upon in
Dillon does not appear to have been raised.
13.17 It should also be noted that Dillon was concerned not with the presumption regarding
machines but with the presumption of the regularity of official action. This latter presumption was
the analogy on which the presumption for machines was originally based; but it is not a particularly
close analogy, and the two presumptions are now clearly distinct.
13.18 Even where the presumption applies, it ceases to have any effect once evidence of malfunction
has been adduced. The question is, what sort of evidence must the defence adduce, and how realistic
is it to suppose that the defence will be able to adduce it without any knowledge of the working of
the machine? On the one hand the concept of the evidential burden is a flexible one: a party cannot
be required to produce more by way of evidence than one in his or her position could be expected to
produce. It could therefore take very little for the presumption to be rebutted, if the party against
whom the evidence was adduced could not be expected to produce more. For example, in Cracknell
v Willis ([1988] AC 450) the House of Lords held that a defendant is entitled to challenge an
Intoximeter reading, in the absence of any signs of malfunctioning in the machine itself, by
testifying (or calling others to testify) about the amount of alcohol that he or she had drunk.
13.19 On the other hand it may be unrealistic to suppose that in such circumstances the
presumption would not prevail. In Cracknell v Willis Lord Griffiths ([1988] AC 450 at p 468C– D)Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

said:
If Parliament wishes to provide that either there is to be an irrebuttable presumption
that the breath testing machine is reliable or that the presumption can only be
challenged by a particular type of evidence then Parliament must take the
responsibility of so deciding and spell out its intention in clear language.
Until then I would hold that evidence which, if believed, provides material from
which the inference can reasonably be drawn that the machine was unreliable is
admissible.
But his Lordship went on:
I am myself hopeful that the good sense of the magistrates and the realisation by the
motoring public that approved breath testing machines are proving reliable will
combine to ensure that few defendants will seek to challenge a breath analysis by
spurious evidence of their consumption of alcohol. The magistrates will remember
that the presumption of law is that the machine is reliable and they will no doubt look
with a critical eye on evidence such as was produced by Hughes v McConnell ([1985]
RTR 244) before being persuaded that it is not safe to rely upon the reading that it
produces ([1988] AC 450, 468D–E).
13.20 Lord Goff did not share Lord Griffiths’ optimism that motorists would not seek
to challenge the analysis by spurious evidence of their consumption of alcohol, but
did share his confidence in the good sense of magistrates who, with their attention
drawn to the safeguards for defendants built into the Act …, will no doubt give proper
scrutiny to such defences, and will be fully aware of the strength of the evidence
provided by a printout, taken from an approved device, of a specimen of breath
provided in accordance with the statutory procedure ([1988] AC 450 at p 472B– C).
13.21 These dicta may perhaps be read as implying that evidence which merely contradicts the
reading, without directly casting doubt on the reliability of the device, may be technically admissible
but should rarely be permitted to succeed. However, it is significant that Lord Goff referred in the
passage quoted to the safeguards for defendants which are built into the legislation creating the
drink−driving offences. In the case of other kinds of computer evidence, where (apart from section
69) no such statutory safeguards exist, we think that the courts can be relied upon to apply the
presumption in such a way as to recognise the difficulty faced by a defendant who seeks to challenge
the prosecution’s evidence but is not in a position to do so directly. The presumption continues to
apply to machines other than computers (and until recently was applied to non−hearsay statements
by computers) without the safeguard of section 69; and we are not aware of any cases where it has
caused injustice because the evidential burden cast on the defence was unduly onerous. Bearing in
mind that it is a creature of the common law, and a comparatively modern one, we think it is
unlikely that it would be permitted to work injustice.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

13.22 Finally it should not be forgotten that section 69 applies equally to computer evidence
adduced by the defence. A rule that prevents a defendant from adducing relevant and cogent
evidence, merely because there is no positive evidence that it is reliable, is in our view unfair. Our
recommendation 13.23 We are satisfied that section 69 serves no useful purpose. We are not aware
of any difficulties encountered in those jurisdictions that have no equivalent. We are satisfied that
the presumption of proper functioning would apply to computers, thus throwing an evidential
burden on to the opposing party, but that that burden would be interpreted in such a way as to
ensure that the presumption did not result in a conviction merely because the defence had failed to
adduce evidence of malfunction which it was in no position to adduce. We believe, as did the vast
majority of our respondents, that such a regime would work fairly. We recommend the repeal of
section 69 of PACE. (Recommendation 50) (emphasis supplied)
37. Based on the above recommendations of the U.K. Law Commission, Section 69 of the PACE,
1984, was declared by Section 60 of the Youth Justice and Criminal Evidence Act, 1999, to have
ceased to have effect. Section 60 of the 1999 Act reads as follows:
“Section 69 of the Police and Criminal Evidence Act, 1984 (evidence from computer
records inadmissible unless conditions relating to proper use and operation of
computer shown to be satisfied) shall cease to have effect”
38. It will be clear from the above discussion that when our lawmakers passed the Information
Technology Bill in the year 2000, adopting the language of Section 5 of the UK Civil Evidence Act,
1968 to a great extent, the said provision had already been repealed by the UK Civil Evidence Act,
1995 and even the Police and Criminal Evidence Act, 1984 was revamped by the 1999 Act to permit
hearsay evidence, by repealing Section 69 of PACE, 1984.
POSITION IN CANADA
39. Pursuant to a proposal mooted by the Canadian Bar Association hundred years ago, requesting
all Provincial Governments to provide for the appointment of Commissioners to attend conferences
organised for the purpose of promoting uniformity of legislation among the provinces, a meeting of
the Commissioners took place in Montreal in 1918. In the said meeting, a Conference of
Commissioners on Uniformity of Laws throughout Canada was organised. In 1974, its name was
changed to Uniform Law Conference of Canada. The objective of the Conference is primarily to
achieve uniformity in subjects covered by existing legislations. The said Conference recommended a
model law on Uniform Electronic Evidence in September 1998.
40. The above recommendations of the Uniform Law Conference later took shape in the form of
amendments to the Canada Evidence Act, 1985. Section 31.1 of the said Act deals with
authentication of electronic documents and it reads as follows:
Authentication of electronic documents 31.1 Any person seeking to admit an
electronic document as evidence has the burden of proving its authenticity by
evidence capable of supporting a finding that the electronic document is that which itArjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

is purported to be.
41. Section 31.2 deals with the application of ‘best evidence rule’ in relation to electronic documents
and it reads as follows:
Application of best evidence rule — electronic documents 31.2(1) The best evidence
rule in respect of an electronic document is satisfied
(a) on proof of the integrity of the electronic documents system by or in which the
electronic document was recorded or stored; or
(b) if an evidentiary presumption established under section 31.4 applies.
Printouts (2) Despite subsection (1), in the absence of evidence to the contrary, an electronic
document in the form of a printout satisfies the best evidence rule if the printout has been
manifestly or consistently acted on, relied on or used as a record of the information recorded or
stored in the printout.
42. Section 31.3 indicates the method of proving the integrity of an electronic documents system, by
or in which an electronic document is recorded or stored. Section 31.3 reads as follows:
Presumption of integrity 31.3 For the purposes of subsection 31.2(1), in the absence
of evidence to the contrary, the integrity of an electronic documents system by or in
which an electronic document is recorded or stored is proven
(a) by evidence capable of supporting a finding that at all material times the
computer system or other similar device used by the electronic documents system
was operating properly or, if it was not, the fact of its not operating properly did not
affect the integrity of the electronic document and there are no other reasonable
grounds to doubt the integrity of the electronic documents system;
(b) if it is established that the electronic document was recorded or stored by a party who is adverse
in interest to the party seeking to introduce it; or
(c) if it is established that the electronic document was recorded or stored in the usual and ordinary
course of business by a person who is not a party and who did not record or store it under the
control of the party seeking to introduce it.
43. Section 31.5 is an interesting provision which permits evidence to be presented in respect of any
standard, procedure, usage or practice concerning the manner in which electronic documents are to
be recorded or stored. This is for the purpose of determining under any rule of law whether an
electronic document is admissible. Section 31.5 reads as follows:Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

Standards may be considered 31.5 For the purpose of determining under any rule of
law whether an electronic document is admissible, evidence may be presented in
respect of any standard, procedure, usage or practice concerning the manner in
which electronic documents are to be recorded or stored, having regard to the type of
business, enterprise or endeavour that used, recorded or stored the electronic
document and the nature and purpose of the electronic document.
44. Under Section 31.6(1), matters covered by Section 31.2(2), namely the printout of an electronic
document, the matters covered by Section 31.3, namely the integrity of an electronic documents
system, and matters covered by Section 31.5, namely evidence in respect of any standard, procedure,
usage or practice, may be established by affidavit. Section 31.6 reads as follows:
Proof by affidavit 31.6(1) The matters referred to in subsection 31.2(2) and sections
31.3 and 31.5 and in regulations made under section 31.4 may be established by
affidavit.
Cross−examination (2) A party may cross−examine a deponent of an affidavit referred to in
subsection (1) that has been introduced in evidence
(a) as of right, if the deponent is an adverse party or is under the control of an adverse party; and
(b) with leave of the court, in the case of any other deponent.
45. Though a combined reading of Sections 31.3 and 31.6(1) of the Canada Evidence Act, 1985, gives
an impression as though a requirement similar to the one under Section 65B of Indian Evidence Act,
1872 also finds a place in the Canadian law, there is a very important distinction found in the
Canadian law. Section 31.3(b) takes care of a contingency where the electronic document was
recorded or stored by a party who is adverse in interest to the party seeking to produce it. Similarly,
Section 31.3(c) gives leverage for the party relying upon an electronic document to establish that the
same was recorded or stored in the usual and ordinary course of business by a person who is not a
party and who did not record or store it under the control of the party seeking to introduce it. IV.
Conclusion
46. It will be clear from the above discussion that the major jurisdictions of the world have come to
terms with the change of times and the development of technology and fine−tuned their legislations.
Therefore, it is the need of the hour that there is a relook at Section 65B of the Indian Evidence Act,
introduced 20 years ago, by Act 21 of 2000, and which has created a huge judicial turmoil, with the
law swinging from one extreme to the other in the past 15 years from Navjot Sandhu31 to Anvar
P.V.32 to Tomaso Bruno33 to Sonu34 to Shafhi Mohammad.35
47. With the above note, I respectfully agree with conclusions reached by R. F. Nariman, J. that the
appeals are to be dismissed with costs as proposed.Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

...…..………......................J. (V. RAMASUBRAMANIAN) JULY 14, 2020 NEW DELHI 31 State (NCT
of Delhi) vs. Navjot Sandhu, (2005) 11 SCC 600 32 Anvar P.V. vs. P.K. Basheer, (2014) 10 SCC 473
33 Tomaso Bruno vs. State of UP, (2015) 7 SCC 178 34 Sonu vs. State of Haryana, (2017) 8 SCC 570
35 Shafhi Mohammad vs. The State of Himachal Pradesh, (2018) 2 SCC 801Arjun Panditrao Khotkar vs Kailash Kushanrao Gorantyal on 14 July, 2020

