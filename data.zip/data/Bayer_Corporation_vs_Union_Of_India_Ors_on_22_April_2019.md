Bayer Corporation vs Union Of India & Ors. on 22 April, 2019
Equivalent citations: AIRONLINE 2019 DEL 1712
Bench: S. Ravindra Bhat, Sanjeev Sachdeva
*      IN THE HIGH COURT OF DELHI AT NEW DELHI
                                 Reserved on: 12.10.2018
                               Pronounced on: 22.04.2019
+      LPA No.359/2017, CM Nos.17922/2017, 20160/2017, 33383-
       84/2017, 47167/2017 & 660/2018
       BAYER CORPORATION                    ..... Appellant
               Through: Mr. Sudhir Chandra, Sr. Adv. with Mr.
               Sanjay Kumar, Ms. Arpita Sawhney and Mr. Arun
               Kumar Jana, Advs.
                     versus
       UNION OF INDIA & ORS                   ..... Respondents
Through: Mr. Ripu Daman Bhardwaj, CGSC with Mr. T.P. Singh and Mr. Shashwat Jain, Advs. for
R-1 & 6.
Ms. Rajeshwari, Adv. for R-2 & 5.
Ms. Saya Choudhary Kapur, Mr. Vivek Ranjan and Mr. Devanshu Khanna, Advocates for
Interveners.
+ RFA(OS)(COMM) 6/2017, CM Nos.17508/2017 & 32128- BAYER INTELLECTUAL PROPERTY
GMBH & ANR ..... Appellants Through: Mr. Guru Krishna Kumar, Sr. Advocate with Mr. Pravin
Anand, Mr. Nishchal Anand and Mr. Sanchith Shivakumar, Advs.
versus ALEMBIC PHARMACEUTICALS LTD. ..... Respondent Through: Ms. Saya Choudhary
Kapur, Mr. Vivek Ranjan and Mr. Devanshu Khanna, Advs.
CORAM:
HON'BLE MR. JUSTICE S. RAVINDRA BHAT HON'BLE MR. JUSTICE SANJEEV
SACHDEVA MR. JUSTICE S. RAVINDRA BHAT %
1. This judgment will decide two appeals: one from the decision of the learned single
judge in a writ petition, W.P.(C) No.1971/2014 ["the writ petition"], filed by the
appellant [hereafter called "Bayer"] against the respondent (hereafter "Natco") in
LPA No. 359/2017 and the other, in a suit decided in CS (OS) (Comm) 1592/2016Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

filed by Bayer against the respondent in RFA(OS)(Comm) 6/2017 (Alembic
Chemicals Ltd, the defendant in the suit, hereafter called "Alembic"). Both judgments
deal with an identical issue, concerning the correct interpretation of Section 107A of
the Patents Act, 1970 ("the Act") which is commonly known as the ―Bolar provision.
2. Facts in the appeal arising out of the judgment in the writ petition (i.e. in LPA
No359/2107) are that Bayer filed a suit [CS(OS) No.1090/2011] for injunction against
Natco from making, importing, selling, offering for sale „Sorafenib, ‗Sorafenib
Tosylate' ("Bayer drugs") or any generic version or any other drug or product thereof
which was a subject matter of Bayers Patent No.215758. When the suit was pending,
Natco applied to the Patent Office for grant of compulsory licence against that patent.
This application was granted, on 09.03.2012, by the Patent Controller, under Section
84 of the Patents Act 1970 (hereafter "the Act"). The compulsory licence granted was
solely for the purposes of making, using, offering to sell and selling the drug covered
by the patent within the territory of India. However, inter alia, apart from producing
the drug for the Indian market, Natco manufactured the product covered by the
compulsory licence for export outside India. Bayer filed a writ petition seeking a
direction to the Customs Authorities to seize the consignments for export containing
products covered by compulsory Licence including ‗Sorafenat' ("Natco" drugs
hereafter) manufactured by Natco. Notice of writ petition was issued by a learned
single judge of this court; the customs authorities were directed to ensure that no
consignment from India containing ‗Sorafenat' covered by compulsory licence was
exported. At the same time, Natco was given the liberty to apply to the court for
permission to export the drug. Later, on 23.05.2014, Natco pointed out that in fact it
has already been granted a drug license and it was permitted to export the drug
Sorafenib Tosylate not exceeding 15 gm for development/ clinical studies and trials.
3. Natco next applied for permission to export 1 Kg of Active Pharmaceutical
Ingredient (hereafter "API") Sorafenib to China to conduct clinical studies and trials
for development of drug for regulatory purposes.
That application was rejected by Bayer, which argued in its writ petition, that if permission were
granted to Natco, it would be contrary to Section 107A and that such a transaction would be a
commercial sale and hence, a patent infringement. According to Bayer, Section 107A was not
applicable, because Natco was not conducting research. The sale of API, therefore, amounted to
infringement of its patent. Bayers interpretation of Section107A was that the provision mentions
the word "sale" and also "import", but the legislature consciously excluded the term "export". Bayer
relied on a German decision Polpharma as well as the US history of the Bolar Exemption (that
allows sale only within the United States) and canvassed a restricted - as opposed to a liberal
interpretation- of Section107A.
4. Natcos counter affidavit in the writ petition among others urged that it did not export the
finished product Sorafenat to any party outside India for commercial purpose. It further argued that
the words „sale for the purpose of drug development i.e. ―solely for uses reasonably related to theBayer Corporation vs Union Of India & Ors. on 22 April, 2019

development and submission of information required under any law for the time being in force, in
India, or in a country other than India, that regulates the manufacture, construction, use, sale or
import of any product clearly pointed to the legislative intention that exports, for the purpose of
drug development, in compliance of regulatory law of a country outside India was permissible.
5. The suit, CS(COMM) No. 1592/2016 was filed by Bayer to injunct Alembic from making, selling,
distributing, advertising, exporting, offering for sale and in any manner directly or indirectly dealing
in Rivaroxaban and any product that infringed its (Bayers) patent IN 211300 and for ancillary
reliefs pleading: (i) that the subject patent is registered in the name of Bayer and is titled
―Oxazolidinones and their Use; ii) that Alembic is manufacturing and exporting Rivaroxaban to the
European Union; and that Alembic has made multiple Drug Master File submissions to the United
States Food and Drug Administration in the United States of America for the drug Rivaroxaban; iv)
that a drug Master File is a submission to the United States Food and Drug Administration that is
used to provide confidential detailed information about the facilities, processes and articles used in
the manufacturing, processing, packaging and storing of one or more human drugs; v) that Alembic
has also filed a patent application for grant of a process patent for Rivaroxaban which specifically
referred to Bayers patent and said that Rivaroxaban is disclosed by Bayer„s patent; thus, clearly
showing that Alembic infringed Bayers patent.
6. During the hearing, Alembic stated that the exports being effected by it are covered by Section
107A. Thereafter, on 15.12.2016, Alembic categorically stated that till then it had not commercially
launched Rivaroxaban and had only exported it within the meaning of Section 107A; further, that in
the event Alembic, in the future, intended to launch Rivaroxaban, it would give one months notice
to Bayer to enable the latter to avail of its remedies. Bayer argued on that date that Alembic
exported at least 90 Kg. Rivaroxaban worth ` 3 crores and export of such quantity could not be
within the meaning of Section 107A.
7. Parties in the Alembic suit were informed during the hearing, on 15.12.2016, that the Natcos writ
petition had been heard, (involving an identical issue of law) in which judgment had been reserved;
in the circumstances, since only the legal question of interpretation of Section 107A of the Act was to
be decided, there was no need for pleadings; the court bound Alembic to its statement aforesaid and
with the direction that Alembic thereafter will not effect any export without giving 15 days notice to
Bayer. Arguments in addition to those already addressed in the writ petition, were permitted.
Alembic later applied stating that it was effecting exports to Brazil and Palestine; that application
was adjourned. Arguments were concluded on 14.02.2017 and judgment reserved.
8. After a detailed analysis of the contentions and the facts, the impugned judgment rejected
Bayers arguments. The court found that firstly, the quantity sought to be exported by Natco was
just enough for 1000-2000 tablets, and, therefore, cannot be termed a commercial activity. The
court then said that the intention of the legislature in interpreting Section 107 must be gathered
from the plain meaning, which clearly does not exclude sale outside India. Further, there was
nothing in Section 107A that implies that only the manufacturers themselves can avail of the
exemption and cannot sell it to a third party. The only requirement is that the sale must be
"reasonably related to" the submission of information under the law (in this case, Chinese law). TheBayer Corporation vs Union Of India & Ors. on 22 April, 2019

court also pointed that the WTO Panel had expressly upheld such a wide interpretation of the
similarly-worded Canadian Bolar Exemption to be TRIPs compliant and, therefore, not unfairly
prejudicial to the patent holder.
9. On the text of Section 107A, the learned single judge noticed the difference between the wordings
of that provision and Section 48, noting that the terms "constructing" in Section 107A and "offering
for sale" in Section 48 were not important. The learned single judge then held that:
―It is thus the purpose for which the said acts are done‗ which distinguishes,
whether the acts constitute infringement of patent or not. If the said purpose is
within the confines of Section 107A, the acts so done would not constitute
infringement and the patentee cannot prevent a non-patentee from doing them.
However, if the purpose of doing the acts of making, using, selling or importing a
patented invention is not solely for the purposes prescribed in Section 107A, the said
acts would constitute infringement of patent and patentee can prevent non- patentee
from doing them.
10. The learned single judge then held:
―27. The point of difference between Bayer and Natco / Alembic is qua selling outside
India. While Bayer contends that the word ―selling in Section 107A is confined to
within the territory of India and selling of patented invention outside India even if for
purposes specified in Section 107A would constitute infringement which can be
prevented by patentee, the contention of the senior counsels for Natco / Alembic is
that use of the word ―selling under Section 107A is without any such restriction of
being within India only and would include selling outside India also, so long as solely
for the purposes prescribed in Section 107A.
28. The counsels for Bayer, to explain why Section 107A refers to the purpose of
development and submission of information required under law in a country other
than India that regulates manufacture, construction, use and sale of pharmaceutical
products, if selling referred to in Section 107A was to be within the confines of India
contend that the information generated in India and required under law of a country
other than India to be submitted for obtaining approval for manufacture and
marketing of any pharmaceutical product in that country can be submitted without
the sale of patented invention outside the country. According to them, transfer from
India to any other country can be only of information gathered / collected in India
and required to be submitted under the laws of any other country for obtaining
approvals for manufacture and sale of pharmaceutical products in that country.
29. According to me, to uphold what Bayer contends, would be contrary to the
natural / literal / textual interpretation of Section 107A of the Patents Act. To ascribe
natural / literal / textual meaning to the language of Section 107A of the Patents Act,
I proceed to dissect clause (a) thereof as under:Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(i) Any act of making, constructing, using, selling or importing a patented invention
(ii) solely for uses reasonably related to development and submission of information
required under any law for the time being in force, in India, or in a country other
than India, that regulates the manufacture, construction, use, sale or import of any
product
(iii) shall not be considered as infringement of patent rights. It becomes immediately
evident that ‗selling' permitted by Section 107A is of a patented invention‗i.e. a p
roduct‗ and not of ‗information'. The word ‗information' is in the context of
‗required to be submitted to any authority under any law of India or of a country
other than India regulating the manufacture and marketing of any product'. Section
107A, as per its natural / literal / textual meaning requires selling of a patented
invention solely for submission of information required under any law for the time
being in force in a country other than India that regulates the manufacture,
construction, use and sale of any product, to be not considered as infringement of
patent right. The counsels for Bayer are unable to dispute that Section 107A envisages
development and submission of information required under any law of a country
other than India for obtaining approvals for manufacture and marketing of
pharmaceutical products in that country. However contend that development of the
information, required to be submitted in a country other than India, by making,
using and constructing and selling of patented invention in India only.
Significantly, the counsels for Bayer, qua ‗selling' within India, admit can be of patented invention
i.e. of the product, by Fine Chemical Producers of India to manufacture or producers of
pharmaceutical products in India and do not insist, should be of information only. However when it
comes to ‗selling' outside India, they insist cannot be of patented invention or product and can be of
information only. I am unable to read such dichotomy in the language of Section 107A. It is not
found to distinguish between making, constructing, using, selling for submission of information
required under law in India and under the law of a country other than India.
31. I am also unable to accept the contention of Bayer that, use of the word ―selling refers to
selling‗ within India' only.
32 ‗Sale', in Black‗s Law Dictionary, 10th Edition, is defined as transfer of property or title having
the elements of i) parties competent to contract; ii) mutual assent; iii) a thing capable of being
transacted; and, iv) a price in money paid or promised to be paid. Thus, use of the word ‗sale'/
‗selling' entails transfer of property or title in a thing and does not contain any territorial
limitations viz. of being within the country or State.
XXXXXX XXXXXX XXXXXX
35. The words ‗sale'/ ‗selling' thus, as per their literal / natural / textual meaning are without any
geographical limitations and in Section 107A are not to be understood as ‗within India' only and ifBayer Corporation vs Union Of India & Ors. on 22 April, 2019

such sale / selling were to involve transfer of the patented invention / product to a country other
than India though would also qualify as export / exporting but would not cease to be sale / selling.
XXXXXX XXXXXX XXXXXX
37. As far as Section 107A is concerned, use therein of the words ―law for the time being ‗in a
country other than India' is evidence of, obtaining regulatory approvals in countries other than
India being contemplated by the legislature. With such contemplation, the legislature provided that
certain acts mentioned in Section 107A, required to be done for the purpose of obtaining such
approval, would not be considered as infringement of patent rights. One of such acts is of selling of
patented invention. The plain meaning of Section 107A is that selling of patented invention for
obtaining regulatory approval in country other than India would entail transfer of patented
invention i.e. product from India to that country. There is nothing in the language of Section 107A to
suggest that only the information generated / collected in India could be transported out of India
and not the patented invention. Information generated in India, unless accepted under the law of
any other country for granting regulatory approvals for manufacture, sale and import in that
country, would be of no use. There is nothing in the language of Section 107A to indicate that the
legislature applied itself that the regulatory laws of countries other than India would accept the
information generated and collected in India. The counsels for Bayer during the hearing also could
not demonstrate that information collected / generated in India would be acceptable for grant of
regulatory approvals for manufacture and sale of drugs in other countries. Even otherwise, the
interpretation of laws of India cannot be dependent on foreign laws. I have not found any provision
elsewhere in the Patents Act requiring the word ‗selling' in Section 107A to be restricted to ‗within
India' only. Contentions of parties: Bayer
11. Mr. Sudhir Chandra, Senior Advocate (for Bayer) argues that Section 48 of the Act implicitly
defines infringement by listing the exclusive rights of the patentee. Section 107A of the Act describes
a particular set of circumstances in which acts that are largely those named in Section 48 would "not
constitute infringement". Thus, Section 107A of the Act clearly provides for circumstances/actions
which, but for its existence, would be covered as an infringement under Section 48. Therefore, it is
clearly a proviso/exception. But for Section 48, Section 107 has no purpose. Therefore, the latter
constitutes an exception to Section 48 and does not confer a right. He relies on the Supreme Court
decision in S. Sundaram Pillai v. V.R. Pattabiraman AIR1985 SC 582 that the nature of a proviso is
such that it:
―it is meant to be an exception to something within the main enactment or to qualify
something enacted therein which but for the proviso would be within the purview of
the enactment. [Emphasis supplied]
12. Furthermore, the nature of Section 107A of the Act as a proviso/exception can be
seen from its placement in the statute by the legislature. It finds mention in Chapter
XVIII which is titled "suits concerning infringement." This means that Section 107A
of the Act is intended to be used as a defence that may be claimed in the course of a
suit for infringement rather than form the basis for an independent right or separateBayer Corporation vs Union Of India & Ors. on 22 April, 2019

actionable claim. Moreover, Section 107A of the Act is placed just after, and along
with, Section 107 which is titled "Defences etc. in suits for infringement". This gives
yet another indication of the legislative intent behind the manner in which Section
107A of the Act was envisioned to be applied. The learned single judges finding that
the provision is not an exception and that it confers an independent right, is
impugned as erroneous.
It is also stated that the observations in the impugned judgment that the interpretation furthers the
right of the exporter, under Article 19(1)(g) of the Constitution of India does violence to the plain
reading of Section 107A which neither uses such language nor envisages the commission of such acts
beyond the exhaustively defined situation that it lays out. It is also argued that the existence of a
right implies the creation of an actionable claim. The absence of a legislative prescription of a
remedy clearly shows that it is not the legislative intent to confer an independent right to a party
under section 107A of the Act.
13. Learned Senior Counsel relied on the rule that a proviso should be interpreted narrowly, unlike a
right which warrants liberal interpretation. Specifically, a proviso must be interpreted keeping in
mind the scope of the main enactment to which it forms a proviso. This was recognised by the
Supreme Court in The Commissioner of Income Tax v the Indo-Mercentile Bank Ltd. [AIR 1959 SC
713].
14. Mr. Chandra argued that the legislative intent behind Section 107A of the Act is only to ensure
the availability of a competitor's product immediately after the expiry of patent in the Indian market
without having to wait for regulatory approval post patent expiry. However, this intent does not
extend to ensuring the availability of the same in other countries. He relies on the Notes on Clauses
of the Patents (Amendment) Act 2002 as well as the Joint Parliamentary Committee Report
pertaining to the insertion of Section 107A of the Act. Learned Senior Counsel stated that the phrase
"in a country other than India refers to the submission of information in countries other than India
so that the data generated in India may be submitted around the world, as is an accepted practice in
the pharmaceutical industry. In fact, India is becoming a favoured global destination for conducting
clinical trials and the data generated in this process is often used before regulatory regimes around
the world. The expression in Section 107A (i.e. sale, construct etc.) is qualified by the word "law"
with the phrase "in a place other than India'. The latter phrase has clearly not been used to describe
the acts of "making, selling using", etc., i.e. it cannot possibly intend to authorise the commission of
acts outside the territory of India. The phrase has merely been included so that companies in India
may avail the Bolar exemption not only to obtain approvals in India but around the world, without
having to conduct separate clinical trials for every instance of submission of data. It is argued that
Section 107 has three important elements, i.e. the activities (selling, making, constructing) the
purpose, which can only be "development and submission of information"; and the law i.e. that such
development (and submission of information) should be "required by any law in India or in a
country other than India". Learned Senior Counsel argued therefore, that the phrase in "a country
other than India" refers to the law that requires development and submission of information and the
law that ―regulates the manufacture, construction, use, sale or import of any product. The policy of
the provision is, therefore, met if activities are permitted in India for the purpose of generating dataBayer Corporation vs Union Of India & Ors. on 22 April, 2019

which may then be submitted before the regulatory authority in India or a country other than India.
It is argued that this construction only would be consistent with the legal requirement of not placing
any fetters on the patentee's exclusive rights beyond the fulfillment of the legislative purpose or
intent.
15. Mr. Chandra highlighted that the expression "exports" occurs in various other provisions of the
Act: reference is made to Sections 84, 90(1) and 92A in this regard. They prescribe restrictions and
export of a patented product may be allowed only within the ambit of such restrictions. All these
show that the legislature has consciously used the expression "export" whenever it was necessary.
However, no such explicit mention of export or corresponding restriction as found in these
provisions can be seen in Section 107A of the Act. It is urged that this is significant, given the
background of the fact that the term "importing" was specifically included in Section 107A of the Act
by the Patents (Amendment) Act, 2005, without any mention of the word export" or "offering for
sale". This clearly indicates that the legislature did not intend to include these activities within the
ambit of the said Section. The inclusion of "importing" in Section 107A of the Act also reinforces the
legislative intent which is to ensure the availability of the drug in the Indian market. Learned Senior
Counsel also relied on the Joint Parliamentary Report which clearly states that the purpose of
Section 107A of the Act is to bring India's Bolar exemption in line with the global requirements.
16. It is next submitted that the word "selling" does not include exports, because firstly the Act is
territorial in nature and explicitly states in Section 1 that it "extends to the whole of India". Clearly,
the Act only seeks to regulate activities which take place in India and hence, does not deal
with/permit sale outside India. Moreover, as was held in the judgment of the Supreme Court in
GvkInds Ltd. & Anr. v The Income Tax Officer & Anr.(2011) 4 SCC 36 only those extra-territorial
aspects which have an impact or nexus with India and are enacted with the intent of creating some
benefit for India would fall within the constitutionally sanctioned idea of legislative competence.
Next, the nature and purpose of the Act is primarily to safeguard the interests of the patentee and
the nature and purpose of Section 107A of the Act is an exception to the patentee's rights so that the
generic versions of the drug may be made available immediately upon expiry of the patent in the
Indian market. Inclusion of "export" within this provision would not serve the Indian market as
envisioned by the Legislature and therefore, the same would be impermissible as per the law on
extra- territorial legislative action. Thus, making, constructing and using of the product are
permitted in India alone and export for that purpose is not contemplated.
17. Moreover, since the act of selling in Section 48 refers to sale "in India" only (as can be seen from
the provision), it cannot be said that Section 107A of the Act, can enlarge the scope of this term and
grant an additional right to the defendant. Counsel derives support from the judgment in Indo-
Mercantile Bank Ltd (supra). It is argued, moreover, as untenable that the legislature would use the
word "selling "in one sense as part of Section 48 but accord to it a different meaning in an exception
to the same Section within the same Act i.e. Section 107A of the Act.
18. It is argued that the expression "exports" has a clear meaning in the general sense, and
statutorily. "Export" as defined in Black's Law Dictionary means:"To send or carry abroad, to send,
take or carry (a good or commodity) out of the country; to transport (merchandise) from oneBayer Corporation vs Union Of India & Ors. on 22 April, 2019

country to another in the course of trade; to carry out or convey goods by sea". Thus, the act of sale
which may occur in the course of an export can be concluded upon transfer of title in the goods
which may happen outside India, however, the word "selling" referred to in both Section 48 and
Section 107A of the Act is clearly territorial in nature whereas the term "export" is, by definition,
extra-territorial in nature. Thus, the learned Single Judge has grievously erred in conflating the two
terms.
19. It is argued that "sale" by "export" is mentioned in the Central Sales Tax Act, 1956 ("CST Act")
which deals with a ―sale said to take place in the course of export". While considering the import of
this phrase in Article 286, the Supreme Court held in The Stale of Travancore-Cochin and Ors. v.
The Bombay Company Ltd. AIR 1952 SC 366and The State of Travancore- Cochin v. The
Shanmugha Vilas Cashew Nut Factory & Ors AIR 1953 SC 333that two types of sales or purchases
would fall within this category: (a) a sale or purchase which itself occasions the export and (b) a sale
or purchase affected by a transfer of documents of title to the goods after the goods are put in the
export stream (i.e. after they have crossed the customs frontiers of India). Such an interpretation
suggests that "sale" per se does not comprehend in itself export, which is a distinct activity, and that
sale which occurs in the course of exports is extra-territorial in nature.
20. It is argued that the impugned judgment erroneously found that a plain reading of section 107A
of the Act would include the word "exports" as the same would fall within the meaning of the word
"selling". The construction placed by the learned Single Judge to the provision really amounts to
supplying casus omissus. This is contrary to the settled principles of statutory interpretation.
21. It is argued that the Section must be read in accord with global standards applicable to the Bolar
Exemption. Reference is made to the Joint Parliamentary Committee Report which clarifies that
Section 107A of the Act was meant to be in line with the global standards in respect of the Bolar
exemption. Furthermore, allowing export under Section 107A of the Act would be in violation of
Article 30 of the TRIPS (Annexure14) which allows for exceptions to patent rights so long as the
exception is (a) limited ; (b) does not unreasonably conflict with the normal exploitation of the
patent ; and (c) does not unreasonably prejudice the legitimate interests of the patentee. It is
pertinent to note that these were the very issues that were considered in the case of Canada-Patent
Protection of Pharmaceutical Products [DS 114, hereafter "Canada Dispute" or "Canada Patent
Dispute] decided by the WTO Dispute Settlement Panel ("DSP" hereafter) when adjudicated the
legality of Canada's Bolar provision. Notably, both sides in this dispute readily acknowledged that
such a provision was in the nature of an exception to the patentee's rights. While the WTO upheld
the validity of the Bolar exemption, it did not consider whether an export would be permissible
within the ambit of this exception. In fact, Canada's contentions with respect to the issue of
submission of information before foreign regulatory regimes clearly indicates that the Canadian
provision envisioned the testing itself to be carried out domestically while the information generated
therefrom could be used for submission abroad. This case therefore, underscores the approach
which the appellant is canvassing for the consideration. Furthermore, allowing exports under
Section 107A of the Act would also be in disregard of Article 31 of the TRIPS which states in clauseBayer Corporation vs Union Of India & Ors. on 22 April, 2019

(f) that the any use of a non-patentee should be predominantly for the supply of the domestic
market of the member country authorizing such use.
22. Bayer argues that reading exports into Section 107A of the Act would be contrary to the general
interpretation of "Bolar Provisions" around the world. Those countries which do permit export
explicitly provide for the same in their statute and do so with a specific purpose. For instance,
Australia permits exports explicitly for patents which have received an extension in their term.
Several jurisdictions have also recognised the blatant prejudice this would cause to the rights of the
patentee such as the Polish Supreme Court in A.P. Inc. v. SFP SA [IV CSK 92/13] and the German
Appellate Court in Astellas v. Polpharma [12-U 68/12]. Therefore, the learned Single Judge returned
findings which are not in line with the legislative intent and also in the teeth of the global standards
with respect to the Bolar exemption.
23. It is submitted that arguendo if Section 107A of the Act permits exports, the burden of proof
must fall on the non-patentee. In this regard, it is stated that it is an established position under the
law of evidence that the burden of proof must lie on the party who relies on a fact. This can be seen
from Section 106 of the Indian Evidence Act, 1872 [Annexure 19], which provides that any fact(s)
must be proved by the party which seeks to rely on the same. This also follows naturally from the
fact that Section 107 of the Act is a defence/exception, as shown above. The burden of proof must
clearly lie on the party who relies on the exception to justify their acts. Consequently, the
non-patentee who relies on the fact that their export is for the purposes allowed by Section 107A of
the Act must be the one who is required to prove the same, because it is the exporter/non-patentee
who is privy to all the details relevant to proving the applicability of Section 107A of the Act such as
manner of export, quantities, identity of the importing party etc. Learned Senior Counsel faults the
impugned judgment which held that ―this court cannot proceed to interpret the laws of the
countries of intended export to determine whether the export intended in a given case is for the
purposes prescribed in Section 107A of the Act. All exports by a non-patentee of a patented
invention are deemed to be for the said purpose and only if proved to be otherwise, can make the
exporter liable for consequences thereof in an appropriate legal proceeding.
24. It was submitted that this approach effectively shifts the burden of proof on the patentee to show
that the non-patentee's acts are not covered by Section 107A of the Act. This, in substance and effect,
results in placing a reverse burden which is legally impermissible. Further, this results in the
plaintiff not only having to establish that the defendants' acts overlap with the exclusive rights of the
patentee but that Section 107A of the Act is inapplicable. Moreover, a consistent application of this
approach would also mean that the burden of proof stands reversed in respect of all activities
contemplated by Section 107A. By extension, it could also be argued that the plaintiff must prove
non-applicability of every section which sets out situations of non-infringement such as Section 47,
49, etc.
25. It is argued further that even if Section 107A is interpreted to permit exports, the safeguards
implicit in Section 107A of the Act cannot be ignored. Here Bayer urges that the phrase "reasonably
related..." in Section 107A of the Act clearly implies that compliance with the foreign regulatory
regime must be proven and adjudicated upon by the court. It is clear that the court, in order toBayer Corporation vs Union Of India & Ors. on 22 April, 2019

ensure the non-patentee's compliance with this phrase, would be required to undertake an analysis
of the foreign regulatory requirements which the non-patentee uses as a justification for their acts.
Counsel stated that this position is augmented by the prior judicial interpretations of Section 107A
of the Act such as in Teva API India Pvt. Ltd, v Merck Sharp & Dohme Corp. [FAO (OS) (COMM)
34/2 016 before DHC (DB)] where the defendants' undertaking in respect of compliance with the
foreign regulatory regime as well as the export quantities were taken into consideration. It was
submitted that the learned Single Judge, by finding that the court cannot get into an analysis of
foreign regulatory regimes, has rendered the phrase ―reasonably related to the development and
submission of information otiose. Furthermore, the various safeguards which were pointed out by
Bayer before the learned single judge were not taken into consideration and in fact, it has been held
by the latter in paragraph 56 of the impugned judgment that:
".... Even if it were to be believed that the patented invention once exported from this
Country for the purposes prescribed in Section 107A of the Act may be used for other
purposes, it is for the patentee to enforce its rights if any in that country. The laws of
this country are only concerned with the sale by way of export from this country
being for the purposes prescribed,"
26. Bayer stated that this completely prejudices the interests of the patentee, which cannot be in
congruence with the object of the Act. The patentee's interests are prejudiced because:
(i) The patentee may not have a patent in the country of export which would leave the
patentee completely remedy-less.
(ii) Even if the activities undertaken in the destination country post-export may not
be actionable in India, the original act of intention to export or offer for sale itself
certainly falls within the judicial scrutiny of the courts in India.
By deigning to scrutinise and thus permitting, an unqualified entitlement to export, the potential for
future abuse increases manifold. This would surely prejudice the rights of the patentee.
(iii)The patentee will have to undertake a global surveillance, tracking the products exported to
establish what purpose they are being used for and then enforce their patents (if any) in multiple
countries. This will give the defendants a free reign to export patented products without fear of
prosecution. This could not have been the purport and intent of Section 107A of the Act.
27. It is argued lastly that in any event, the learned single judge failed to even consider the quantities
sought to be exported by the respondent. They have to be compared with the quantities that are
required by the regulatory regime to which information is to be submitted. This is crucial in
confirming the purpose for which the non-patentee is undertaking the export. For instance, in the
present case, more than 90 kgs of the patented product has been exported by the respondent.
Non-consideration of the same runs contrary to the requirements of Section 107A of the Act as held
in the pronouncement of Teva (supra).Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

Contentions of Natco
28. The learned senior counsel, Mr. Anand Grover submitted that Natco disputed Bayers factual
assertion and contends that it had nothing to do with the alleged exports of the formulations. It is
urged that anybody can buy the formulated drug in the market and send it out of the country. It is
submitted that Bayer proposes selling the API (bulk drug) of Sorafenib Tosylate to M/s Hisun
Pharmaceutical Co. Ltd ("Hisun" hereafter) in China, solely for generating data in China through
Hisun to submit it to Chinese drug regulatory authorities. In any event, the issue of export under
Section 107A applies both to API and formulations. Pertinently, on 13.05.2011, i.e. before the
issuance of the compulsory license, the Drugs Control Administration of Govt. of Andhra Pradesh
granted a license to Natco to manufacture Sorafenib Tosylate API for domestic and export purposes.
This raw material/bulk form is not covered by the compulsory license issued to Bayer. It is urged
that Chinese law does not permit any non-Chinese entity to submit regulatory dossiers based on
data and information generated in a country other than China. Similar laws exist in other countries.
The studies are required to be conducted in China by a Chinese entity to the satisfaction of Chinese
regulatory authorities. Reference is made to the SFDA Order No. 28-Provisions for Drug
Registration-Article 10-Provisions of Drug Registration.
29. Mr. Grover submits that Bayers patent expires on 12.01.2020; Article 19 of the Chinese drug
registration law enables an entity other than the patentee to apply for patent registration two years
prior to the expiry of its term. Natco denies Bayers allegation that, under the guise of the grant of
compulsory license, it is exporting the formulation to diverse countries, as baseless. It is argued that
Bayer concedes that a generic manufacturer in India can carry on activities of making, constructing,
using, selling or importing the patented invention for the development and generation of data to
Indian authorities or foreign authorities, but however, contends that the patented article cannot be
exported for development and generation of data abroad for submission to the foreign regulatory
authorities. Natco submits that i) The TRIPS Agreement took note of the global nature of the
pharmaceutical industry, the global need of access to affordable medicines.
(ii) TRIPS also took note of extant practice under the US Bolar provision of exporting a patented
article abroad for, developing and generating data abroad for submission to the US regulatory
authorities, as exemplified by the US Supreme Court in Intermedics Inc. v Ventrilex, 775 F. Supp.
1269 (N. D. Cal. 1991). Mr Grover argued that Section 107A is enacted pursuant to Article 30 of the
TRIPS Agreement (Providing for limited exceptions to exclusive rights conferred by the grant of a
patent) and after the decision of the WTO Dispute Panel decision in Canada-Patent Protection of
Pharmaceutical Products dispute (WTO/DS114/R) (hereinafter, the "Canada Dispute"). It is
submitted, furthermore, that Section 107A takes into account the unique position of the Indian
generic pharmaceutical industry in the international market and its role as the key supplier of
affordable generic medicines. Therefore, Section 107A goes beyond the Canadian provision in this
behalf.
30. Natco urges that rights under Section 48 are subject to the acts exempted under Section 107A.
Section 107A read with Section 48 do not prohibit export if the person concerned otherwise satisfies
the conditions of Section 107A. Natco argues that sale under Section 107A includes export out ofBayer Corporation vs Union Of India & Ors. on 22 April, 2019

India. It therefore says that export of API for purposes ―reasonably related to development and
submission of information to Chinese authorities is legitimate. It is furthermore argued that the
rights under Section 107A and under Section 84 are independent but can be exercised by the same
person.
31. Explaining the drug innovation and patent life cycle, when a product with beneficial effect is
developed, its patent is sought by the inventor. But, a pharmaceutical drug can be introduced in the
market only after conducting animal toxicity studies which are Phase I, II, and III human clinical
trials generating information and data which is submitted to the satisfaction of drug regulatory
authorities. To avoid repeated clinical trials on patients, regulatory authorities over world permit
generic companies to carry on studies such as bioequivalence, bioavailability and stability studies to
establishing chemical and functional equivalence of their product with the originator product. This
is done on a partial scale commercial production run. Based on such studies, a drug has to satisfy
requirements of bioequivalence, bioavailability and stability studies. The precise needs, in terms of
quantity of production, is specified by regulatory authorities in various countries; they differ from
each other.
32. Mr. Grover emphasizes that patent regimes do not countenance continuation of monopoly even
a single day more than the permitted patent term. Thus, generic companies need to only conduct
development studies, generation of information and data before the expiry of the patent, i.e. during
a patents term, to launch the product in the market immediately on expiry or invalidation of the
patent. It is submitted that the global nature of the pharmaceutical industry is so structured that
such generic producers are in a few countries; in some countries there are no generic producers at
all. At times, even developed countries procure fine chemicals from other countries. Countries
without generic industries do not necessarily have domestic markets that support operation of the
industry on an economic scale. In such situations, the economies of scale for the generic
manufacturers would be achieved if the product is also exported. Learned Senior Counsel also
highlighted the leadership role played by Indian generic pharmaceutical entities in the global
pharmaceutical market and flagged the support given to developing nations in Africa, South
America, Central Asia and Eastern Europe stating that they supply over 90% of Anti Retro Viral
Drugs to the developing countries. He also quoted a leading author, Brenda Waning, (Journal of
AIDS Studies, 2010, 1335, A lifeline of treatment: the role of Indian generic maufacturers in
supplying Antiretroviral medicines)
33. It was contended that the TRIPS Agreement carves out an exception under Article 30,
permitting regulatory exception activities prior to the expiry of patent. In this regard, it is stated that
several countries including India, Canada and the US have fashioned their patent laws to carve out
such exception. It is submitted that the Canadian provision, Section 55. 2(1), enabling use of a
patented product for generation of data and information to be submitted to regulatory authorities,
was the subject matter of a complaint lodged by the US and Europe at the Dispute Settlement Body
(hereafter "DP") of the WTO (in the Canada Dispute). It was contended that Section 55.2(1) violated
TRIPS. The other challenge was to Section 55.2(2), the stock-piling exception of the Canadian law.
Mr Grover submitted that the TRIPS dispute panel in the Canada dispute upheld the Canadian
provisions. He contrasted the language of Section 55.2(1) of the Canada Patent law with SectionBayer Corporation vs Union Of India & Ors. on 22 April, 2019

107A of the Act, highlighting that the former only contemplates "development and submission of
information required under any law of Canada, a province or a country other than Canada that
regulates the manufacture, construction, use or sale of any product'. However, Section 107A of the
Act of India, contemplates ―... Development and submission of information required under any law
for the time being in force... In a country other than India, that regulates the manufacture,
construction, use, sale or import of any product.It is submitted that hence, Section 107A recognizes
that export (of a patented product) to another country for development and submission of
information (in that country), is not infringement. In the Canada Dispute, the DSP recognized that
the general language of Article 30 was agreed to by the US on the understanding that it would help
the US secure the Bolar exemption which was already in place there. The DSP also noted that
foreign pre-expiry testing is accepted by the FDA and noted by the US Supreme Court in Intermedix
Inc. (Supra). The DP found that such a provision was a "limited exception" within the meaning of
Article 30 of TRIPS (Ref. Paras 7.2 to 7.6 DP order). Therefore, the key is not the quantity but the
purpose for which production is carried. The DP also noted that the Canadian provision was a
"limited exception", irrespective of the quantity involved, because of the narrow scope of its
curtailment of Article 28.1 choices (under TRIPS).So long as the exception is confined to conduct
necessary to comply with the requirements of the regulatory approval process, the extent of the acts
unauthorized by the right holder that are permitted by it are small and narrowly bounded. Though
regulatory approval processes may require substantial amounts of test production to demonstrate
reliable manufacturing, the patentee's rights are unimpaired, by the size of such production runs, so
long as they are solely for regulatory purposes and no commercial use is made. (Ref para 7.45 at of
the Canada Dispute). Hence, the DSP clarified that there would be no infringement of Patent,
regardless of the amount so used or exported, provided the use or export is solely for regulatory
purposes and not commercial use of final product.
34. Mr. Grover next dwelt on the legislative history of Section 107A, stating that it was introduced
after the DSP decision in Canada Dispute. In 1999, the Patents Act (Second Amendment) Bill, 1999
("1999 Bill") was introduced in the Rajya Sabha to meet India's obligations under the TRIPS
Agreement (required to be met by 01.01.2000). The Bill proposed the introduction of a new section
i.e. Section 107A. Section 107A was sought to be amended in 2002 and 2003; but was finally
amended in 2005, taking into account the decision in the Canada Dispute. However, it went beyond
that decision. The changes brought about by the 2005 amendment are: a) abolition of the three year
period prior to patent expiry; b) addition that the act of selling had to be "solely related to the
development and submission of data in law; and c) addition that the law referred in the section
could be of India "or any country other than India; d) going beyond the Canadian law in that the
expression "importing" and "import" were added in Section 107A. Learned Senior Counsel also
referred to the Joint Committee on Patents note of December, 2001, and said that it clarifies that
the object of Section 107A is ensuring that regulatory approvals are not limited to only 3 years before
the patent term expiry and allow prompt availability.
35. It is urged that Section 107A and Section 84 operate in different fields; the former operates on
the submission of data generated in development of the drug to Regulatory authorities for
marketing approval, that is the patented product is not sold in the market, Section 84 operates on
marketing of the patented product for commercial purposes. Referring to Intermedics, counselBayer Corporation vs Union Of India & Ors. on 22 April, 2019

urged that the Federal Circuit court considered the scope of the Bolar provision. The case involved
the sale of stents to a party outside the US for development purposes and held that sales to foreign
distributors for development studies reasonably related to developing information could be
submitted to the FDA and that such development of information need not be restricted to the period
just before patent expiry. Thus, export of the patented article to another country was very much part
of the patent law in the US at the time of coming into force of the TRIPS Agreement. Likewise, this
position was noted in Canada Dispute case, which ruled on Section 55.2 of the Canadian Act. (Ref
para 4.38(a) of the decision).
36. Learned Senior Counsel urged that Section 107A should be interpreted in accordance with
TRIPS and the interpretation placed on that by the DSP. Furthermore, considering that the Indian
law, uses the phrase "in a country other than India," which is absent in the US law, a fortiori India
permits export to other countries in accordance with their law for submission of data of
development studies. As a result, Section 48 does not prohibit, but allows export. Indian law would
apply to the territory to which the medicines are imported by the expression "importing" which
needs to be in every patent law by virtue of the minimum standards of TRIPS compliant intellectual
property regime. Therefore, the expression "import" for another country, in so far as Section 107A is
concerned, would mean an export from India. Therefore, export is actually contemplated under
Section 107A.
37. Mr. Grover states that it is an established position in law that any term in a provision should be
given plain meaning. Bayers reading into Section 107A, limitations is therefore impermissible.
Non-existent limitations in a statute cannot be read into it. Reference is made to GP Singhs
Principles of Statutory Interpretation 12th Edition and State of Orissa v Joginder Pattjoshi (2004) 9
SCC 278. Also, "sale" is a compendious term that includes "export"; in any event, importantly,
patent law is territorial in nature and does not control any high seas transaction. Export is actually
embraced in and controlled through a sale. The learned single judge too noted that "sale" is not to be
understood as being within India.
38. It is contended that entities such as Bayer are not prejudiced because if a drug is imported into a
territory in which in respect of that drug, a patent is granted, then the patentee would be able to
interdict any unauthorized use of the patented article, barring the import for regulatory exception.
This is the accepted position in TRIPS. (Ref para 7.46 Canada Dispute). It is stated that the
Parliament was conscious of the role the Indian generic companies play in access to affordable
medicines around the world and in particular in developing countries. Mr. Grover urges that Bayer
incorrectly claims that the learned single judge did not appreciate the difference between API and
the finished product. It is stated that after differentiating between API and the finished formulation,
the learned single judge detailed the difference between Fine Chemical Producers and other
manufacturers/producers of medicines, and concluded that the term "selling" used in Section 107A
is to facilitate selling of API/formulations to the manufacturers of medicines. Further, the learned
single judge noted that even after the 2002 Amendment, Section 107A was not added as a proviso to
Section 48, rather it was included under the Chapter titled "suits concerning infringement of
patents"Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

under Section 107 titled "Defences, etc., in suits for infringement". He concluded
correctly that Section 48 does not confer a right to prevent making and selling
patented product for purposes solely prescribed in Section 107A.
39. It is urged that Section 48 of the Patents Act is subject to the provisions of Section 84 and 107A
of the Patents Act. Section 107A is not subject to the operation of Section 84 or of Chapter XVI of the
Act. Thus, Section 84 does not control Section 107A. Section 48 would yield to other provisions of
the Patents Act, including Section 107A and, its operation cannot be curtailed by Section 84. In this
regard, it is submitted that the effect to both the provisions, Section 107A and 84, has to be given in
appropriate circumstances. Both operate in different fields. Section 107A operates on the
submission of data generated in the development of the drug to regulatory authorities for marketing
approval, that is the patented product is not sold in the market, whereas Section 84 operates on
marketing of the patented product for commercial purposes. Stressing on the need to harmoniously
interpret all parts of the statute, it is stated that such consistent reading excludes the idea that one
provision can trump the other and render it otiose, unless specifically provided. Counsel referred to
Padma Ben Banushali & Another v Yogendra Rathore and Others, (2006) 12 SCC 138. Reference is
also made to High Court of Gujarat v Gujarat Kishan Mazdoor Panchayat (2003) 4 SCC 712. It is
urged that the argument with respect to the relationship between Section 107A and Section 84 is
flawed. The learned single judge noted that the purpose of Section 107A is different from Section 84,
which is only for obtaining the regulatory approvals under the laws of India or in a country other
than India.
40. Without prejudice, it is submitted that the compulsory license under Section 84 operates as a
deed or contract between the Controller and Natco, the grantee of compulsory licence (Section 93).
Such a deed being a contract, cannot override a provision of law. Hence, the condition imposed by
learned Controller must be read down to give way to Section 107A. Learned Senior Counsel also
highlighted that pursuant to the impugned judgment, Natco filed an affidavit that during the life of
the patent, it would not export the patented product for purposes other than spelt out by Section
107A. It is urged that the undertaking allows Bayer to revoke an order in case of breach of
undertaking by Natco. This is apart from the remedy that Bayer has in the form of an infringement
suit in the country, where the patented article is sent to for the purposes of development studies,
generating data on a semi production run for submission to the regulatory authorities.
41. On behalf of Alembic, Ms. Saya Chaudhary highlighted that Bayer filed the suit despite
knowledge and admission that the defendant (i.e Alembic) had not launched any commercial
product in the Indian market, and in the absence of any pleadings indicating that the patent was
commercially exploited by Alembic, or any party procuring Rivaroxaban through Alembic outside
India. A suit for infringement was filed solely on the basis that:(i) a process patent application being
PCT/1B2013/055062 pertaining to process of manufacturing Rivaroxaban was filed by Alembic,
which according to Bayer, indicated its (Alembic's) intent to launch a commercial product in India
(ii) a Drug Master File (DMF) was applied by Alembic, before the US Food and Drug Administration
(FDA); (iii) a no- Objection Certificate was obtained by Alembic for exporting Rivaroxaban to
Europe. Bayer, however could not prove or establish even prima facie that the acts complained of,
fell within the purview of section 48 of the Act, i.e. commercial exploitation of the patented productBayer Corporation vs Union Of India & Ors. on 22 April, 2019

as opposed to regulatory use. Initially, in the suit, Alembic made a categorical statement that it had
neither launched nor commercialized the suit patent in India and that all acts conducted by it
pertaining to Rivaroxaban were solely for regulatory purposes in India, and abroad as enumerated
under section 107A of the Act. As a result, Alembic committed no act contemplated under section
48. No allegation of diversion of exports too was alleged in the pleadings or documents. Accordingly,
the first question arising for consideration is whether based on acts covered under Section 107A, can
a party be regarded as an infringer, who is then required to plead Section 107A as a defense to
Section 48 of the Act.
42. It is urged that the placement of Section 107A in the Act, as a separate and distinct section,
different from Section 107 which deals with defences, etc., in suits for infringement is evidence of
the intent of the Legislature that Section 107A ought not to be treated as a defence to Section 48, but
is required to be treated as an independent section which specifically provides for certain acts not to
be considered as infringement.
43. Ms. Chaudhary said that the shift in Indian Patent law is evident upon a plain reading of
Sections 107A and Section 48 of the Act, both of which were inserted/substituted simultaneously by
Act 38 of the 2002 so as to make India TRIPS compliant. Section 48 of the Act, in comparison to
other legislative provisions pertaining to protection of IP Rights in India such as trade mark,
copyright etc., is peculiar in nature inasmuch as it is a negative right, whereby a patentee is legally
entitled under the Act 'to prevent third parties, who do not have his consent, from the act of making,
using, offering for sale, selling or importing for those purposes that product in India'. This aspect
coupled with the fact that the said provision by clear and express language has been made 'subject to
the other provisions contained in this Act and the conditions specified in Section
47......'establishes that it is the rights of a patentee enumerated under Section 48 which yield to the
rights of third parties under Section 107A of the Act. Thus, no fetters or restrictions can be placed on
the acts enumerated under section 107A, especially by making parties liable to infringement action.
In other words, patentee cannot prevent third parties from dealing with patented invention for
regulatory use and no infringement action can be maintainedagainst such regulatory use. This
legislative intent is evident upon a bare perusal of Section 107 of the Act, to which no amendments
were made in 2002, or thereafter so as to label the rights of third parties to use patented inventions
for acts detailed in Section 107A as a 'defence to a suit for patent infringement'. In fact, in Section
107(2), acts detailed in Section 47 are specifically regarded as a ground for defence as opposed to
Section 107A. This intent, not to make Section 107A subservient to Section 48, cannot be overlooked
and nullified by a patentee to label it as nothing but a defense and a "proviso" to Section 48.
44. It was urged that a known principle of law is that any party who asserts a specific claim is
required under law to establish/prove it. Even under Section 107A of the Act, save cases which deal
with process patents, the onus to establish infringement, both at the prima facie stage and at the
final stage, with clear and cogent evidence is on a patentee, and not on the defendant or for that
matter a duty of the court, especially as patents rights are private rights. This is reaffirmed upon
perusal of Section 106 of Act, which deals with power of courts to grant relief in cases of groundless
threats of infringement proceedings wherein again it is for the patentee to prove that „.....the acts inBayer Corporation vs Union Of India & Ors. on 22 April, 2019

respect of which the proceedings were threatened constitute or, if done, would constitute, an
infringement of a patent.' If, therefore, a third party claims that on the basis of its regulatory use, a
patentee is groundlessly threatening to sue such party, then, the patentee has establish that the acts
of the third party constitute commercial exploitation and is outside the purview of section 107A i.e.
regulatory use. If, and only if a patentee can succeed in proving that a complained act results in
commercial use or exploitation, can a regulatory use defence fail. The mere fact that a
pharmaceutical product/drug is developed into a finished formulation form and is sold in India or
abroad for the purpose of procuring regulatory approval is however, insufficient to establish
infringement; a plaintiff patentee has to establish how the act complained of falls within the purview
of Section 48 due to which a suit for infringement is maintainable. This is especially important
because Section 107A permits third parties to carry out trade by way of ―any act of making,
constructing, using, selling or importing a patented invention thereby allowing such parties to
profit with the only limitation being that such trade is be solely for uses reasonably related to the
development and submission of information required under any law for the time being in force, in
India, or in a country other than India, that regulates the manufacture, construction, use, sole or
import of any product.
45. Ms. Chaudhary supported and reiterated the submissions made by Mr. Grover that
interpretation of Section 107A cannot be cut down by Section 48. It was submitted that to establish
infringement, the threshold is nothing short of proving that the use is commercial. Furthermore, it
was argued that exports are not per se infringement and submitted that a bare perusal of Section
107A reveals that its application and operation travels beyond India especially in view of the fact
that it seeks to allow certain acts for ―uses reasonably related to the development and submission of
information required under any law for the time being in force, in India, or in a country other than
India.... The plain words of the statute itself provides for acts to be conducted outside India. It is a
well settled principle of law that words of a statute must be given their plain literal meaning.
Bayers interpretation, however, would result in a dichotomy whereby the term 'selling' would be
interpreted as the selling of the 'product' itself in India, but for the purposes of seeking regulatory
approvals outside India, it would be interpreted as selling of 'information'. Such dichotomy was
never the intention of the legislature, as is evident from a plain literal interpretation of Section 107A,
and it is not open to Bayer to bring in such a dichotomy by way of judicial interpretation. It was
urged that therefore, no territorial restriction ought to be imposed upon the term "sale" contained in
Section 107A as it is being sought to be done by Bayer by way of judicial interpretation, which in
effect amounts to seeking legislative enactment.
46. It was argued that if one applies a purposive interpretation to the present case, the fact that
other nations/countries have expressly or specifically provided for a bar to export for seeking
regulatory approvals in other countries as is the case in the USA and Australia, supports Alembic's
contention that it was never the intention of the Act to prevent export of patented invention for
regulatory purposes under section 107A of the Act. Further, even though the application of the Bolar
Provision in the USA under Section 35 U. S. C. § 271 (e) (1) is limited only to the US, yet, in
Intermedics Inc (supra), export of patented product was allowed and held to be non-infringing in
nature as it was for the purpose of conducting tests and procuring requisite data which was
exclusively used to seek regulatory approval in the USA. Accordingly, in view of the fact that SectionBayer Corporation vs Union Of India & Ors. on 22 April, 2019

107A specifically provides for uses reasonably related to seeking regulatory approval in countries
other than India, it cannot be argued that Section 107A prohibits exports.
47. Bayers reliance on the 'Notes on Clause' of the Patents (Second amendment) Bill, 1999 which
first sought to introduce section 107A, was contested and it was submitted that the Joint
Parliamentary Committee made numerous changes to the provision, which is evident from a bare
perusal of the final provision which was enacted as also the Notes on Clauses detailed in the Joint
Parliamentary Committee Report of the 1999 Bill. Therefore, it is evident that the scope of the said
Section was expanded beyond India and the limitation of only the Indian market were specifically
removed.
48. Ms. Chaudhary urged that a look at Section 107A reveals that it does not impose any restriction
on the quantity which can be made, constructed, used, sold or imported as long as all such quantity
is utilized solely for uses reasonably related to development and submission of information required
under any law for the time being in force in India or in a country other than India that regulates the
manufacture, construction, use, sale or import of any product. Different countries have different
regulatory regimes and requirements whereby the data required to be submitted at the time of
seeking any regulatory approval varies from region to region based on local testing required which
may vary anywhere from redoing complete clinical trials or certain phases of it. For example, in
India, Phase III clinical trials have to be undertaken in India under the Drugs and Cosmetics Act,
1940, bioavailability/bio equivalent studies, stability data which covers both accelerated and real
time data are to be performed in India. Such testing requires different quantities depending on the
drug, the dosage, the mode of delivery (tablets, capsules, injection, Intravenous Therapy etc.) and
may vary from, for example, one pilot scale batch of 100,000 tablets to 3 pilot scale batches of
100,000 tablets. These, coupled with the fact that an entity may have multiple clients in a country,
who would want to procure the patented product for testing, establishes that placing any restriction
on the quantity to be used under Section 107A of the Act would result in impinging upon the
fundamental rights of drug makers/manufacturers in complete contravention of the legislative
intent behind incorporating Section 107A of the Act. It is urged that it is a well settled principle of
law that it is not open for a party to seek legislative enactments from a court of law under the guise
of judicial interpretation. Accordingly, it is not open for the court to put in multiple restrictions
while interpreting Section 107A as is sought by Bayer inasmuch as the entire exercise under the
present litigation is: (a) to impose unreasonable restrictions on export under Section 107A to the
effect of completely excluding it from the purview of the said provision (b) to create an automatic
presumption of infringement immediately upon any use, sale or export of patented product even
though the same is declared to be for regulatory purposes and there is nothing to prove otherwise,
so as to completely shift the onus of infringement from the plaintiff to the defendant. Relevant
provisions of the Patents Act:
49. Sections 48, 84, 92A, 107 and 107A of the Act read as follows:
―48. Rights of patentees Subject to the other provisions contained in this Act and the
conditions specified in section 47, a patent granted under this Act shall confer upon
the patentee--Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(a) where the subject matter of the patent is a product, the exclusive right to prevent
third parties, who do not have his consent, from the act of making, using, offering for
sale, selling or importing for those purposes that product in India:
(b) where the subject matter of the patent is a process the exclusive right to prevent
third parties, who do not have his consent, from the act of using that process, and
from the act of using, offering for sale, selling or importing for those purposes the
product obtained directly by that process in India: XXXXXX XXXXXX XXXXXX
84. Compulsory licences (1) At any time after the expiration of three years from the
date of the 1[grant] of a patent, any person interested may make an application to the
Controller for grant of compulsory licence on patent on any of the following grounds,
namely:--
(a) that the reasonable requirements of the public with respect to the patented
invention have not been satisfied, or
(b) that the patented invention is not available to the public at a reasonably
affordable price, or
(c) that the patented invention is not worked in the territory of India.
(2) An application under this section may be made by any person notwithstanding
that he is already the holder of a licence under the patent and no person shall be
estopped from alleging that the reasonable requirements of the public with respect to
the patented invention are not satisfied or that the patented invention is not worked
in the territory of India or that the patented invention is not available to the public at
a reasonably affordable price by reason of any admission made by him, whether in
such a licence or otherwise or by reason of his having accepted such a licence.
(3) Every application under sub-section (1) shall contain a statement setting out the
nature of the applicant's interest together with such particulars as may be prescribed
and the facts upon which the application is based.
(4) The Controller, if satisfied that the reasonable requirements of the public with
respect to the patented invention have not been satisfied or that the patented
invention is not worked in the territory of India or that the patented invention is not
available to the public at a reasonably price, may grant a licence upon such terms as
he may deem fit.
(5) Where the Controller directs the patentee to grant a licence he may, as incidental
thereto, exercise the powers set out in section 88.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(6) In considering the application filed under this section, the Controller shall take
into account,--
(i) the nature of the invention, the time which has elapsed since the sealing of the
patent and the measures already taken by the patentee or any licensee to make full
use of the invention;
(jj) the ability of the applicant to work the invention to the public advantage;
(iii) the capacity of the applicant to undertake the risk in providing capital and
working the invention, if the application were granted;
(iv) as to whether the applicant has made efforts to obtain a licence from the patentee
on reasonable terms and conditions and such efforts have not been successful within
a reasonable period as the Controller may deem fit: PROVIDED that this clause shall
not be applicable in case of national emergency or other circumstances of extreme
urgency or in case of public non-commercial use or on establishment of a ground of
anti-
competitive practices adopted by the patentee, but shall not be required to take into account matters
subsequent to the making of the application.
[Explanation : For the purposes of clause (iv), "reasonable period" shall be construed as a period not
ordinarily exceeding a period of six months.] (7) For the purposes of this Chapter, the reasonable
requirements of the public shall be deemed not to have been satisfied--
(a) if, by reason of the refusal of the patentee to grant a licence or licences on reasonable terms,--
(i) an existing trade or industry or the development thereof or the establishment of any new trade or
industry in India or the trade or industry in India or the trade or industry of any person or class of
persons trading or manufacturing in India is prejudiced; or (ii) the demand for the patented article
has not been met to an adequate extent or on reasonable terms; or
(iii) a market for export of the patented article manufactured in India is not being supplied or
developed; or
(iv) the establishment or development of commercial activities in India is prejudiced; or
(b) if, by reason of conditions imposed by the patentee upon the grant of licences under the patent
or upon the purchase, hire or use of the patented article or process, the manufacture, use or sale of
materials not protected by the patent, or the establishment or development of any trade or industry
in India, is prejudiced; orBayer Corporation vs Union Of India & Ors. on 22 April, 2019

(c) if the patentee imposes a condition upon the grant of licences under the patent to provide
exclusive grant back, prevention to challenges to the validity of patent or coercive package licensing;
or
(d) if the patented invention is not being worked in the territory of India on a commercial scale to an
adequate extent or is not being so worked to the fullest extent that is reasonably practicable; or
(e) if the working of the patented invention in the territory of India on a commercial scale is being
prevented or hindered by the importation from abroad of the patented article by--
(i) the patentee or persons claiming under him; or
(ii) persons directly or indirectly purchasing from him; or
(iii) other persons against whom the patentee is not taking or has not taken proceedingsfor
infringement.
       XXXXXX                     XXXXXX                   XXXXXX
       90     Terms and conditions of compulsory licences. -
(1) In settling the terms and conditions of a licence under section 84, the Controller shall endeavour
to secure-
(i) that the royalty and other remuneration, if any, reserved to the patentee or other person
beneficially entitled to the patent, is reasonable, having regard to the nature of the invention, the
expenditure incurred by the patentee in making the invention or in developing it and obtaining a
patent and keeping it in force and other relevant factors;
(ii) that the patented invention is worked to the fullest extent by the person to whom the licence is
granted and with reasonable profit to him;
(iii) that the patented articles are made available to the public at reasonably affordable prices;
(iv) that the licence granted is a non-exclusive licence;
(v) that the right of the licensee is non-assignable;
(vi) that the licence is for the balance term of the patent unless a shorter term is consistent with
public interest;
[(vii) that the licence is granted with a predominant purpose of supply in the Indian market and that
the licensee may also export the patented product, if need be in accordance with the provisions of
sub-clause (iii) of clause (a) of sub-section (7) of section 84;Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(viii) that in the case of semi-conductor technology, the licence granted is to work the invention for
public non-commercial use;
(ix) that in case the licence is granted to remedy a practice determined after judicial or
administrative process to be anti- competitive, the licensee shall be permitted to export the patented
product, if need be.] (2) No licence granted by the Controller shall authorise the licensee to import
the patented article or an article or substance made by a patented process from abroad where such
importation would, but for such authorisation, constitute an infringement of the rights of the
patentee.
(3) Notwithstanding anything contained in sub-section (2), the Central Government may, if in its
opinion it is necessary so to do, in the public interest, direct the Controller at any time to authorise
any licensee in respect of a patent to import the patented article or an article or substance made by a
patented process from abroad (subject to such conditions as it considers necessary to impose
relating among other matters to the royalty and other remuneration, if any, payable to the patentee,
the quantum of import, the sale price of the imported article and the period of importation), and
thereupon the Controller shall give effect to the directions.
XXXXXX XXXXXX XXXXXX 92A Compulsory licence for export of patented pharmaceutical
products in certain exceptional circumstances. -
(1) Compulsory licence shall be available for manufacture and export of patented pharmaceutical
products to any country having insufficient or no manufacturing capacity in the pharmaceutical
sector for the concerned product to address public health problems, provided compulsory licence
has been granted by such country or such country has, by notification or otherwise, allowed
importation of the patented pharmaceutical products from India.
(2) The Controller shall, on receipt of an application in the prescribed manner, grant a compulsory
licence solely for manufacture and export of the concerned pharmaceutical product to such country
under such terms and conditions as may be specified and published by him.
(3) The provisions of sub-sections (1) and (2) shall be without prejudice to the extent to which
pharmaceutical products produced under a compulsory license can be exported under any other
provision of this Act. Explanation. -For the purposes of this section, 'pharmaceutical products'
means any patented product, or product manufactured through a patented process, of the
pharmaceutical sector needed to address public health problems and shall be inclusive of
ingredients necessary for their manufacture and diagnostic kits required for their use.
XXXXXX XXXXXX XXXXXX
107. Defences, etc ., in suits for infringement. -
(1) In any suit for infringement of a patent every ground on which it may be revoked under section
64 shall be available as a ground for defence.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(2) In any suit for infringement of a patent by the making, using or importation of any machine,
apparatus or other article or by the using of any process or by the importation, use or distribution or
any medicine or drug, it shall be a ground for defence that such making, using, importation or
distribution is in accordance with any one or more of the conditions specified in section 47.
107A Certain acts not to be considered as infringement. -For the purposes of this Act,-
(a) any act of making, constructing, 197 [using, selling or importing] a patented invention solely for
uses reasonably related to the development and submission of information required under any law
for the time being in force, in India, or in a country other than India, that regulates the manufacture,
construction, 198 [use, sale or import] of any product;
(b) importation of patented products by any person from a person 199 [who is duly authorised
under the law to produce and sell or distribute the product], shall not be considered as a
infringement of patent rights. TRIPS- Relevant provisions
50. The relevant TRIPS provisions are extracted below:
"Article 30 Exceptions to Rights Conferred Members may provide limited exceptions
to the exclusive rights conferred by a patent, provided that such exceptions do not
unreasonably conflict with a normal exploitation of the patent and do not
unreasonably prejudice the legitimate interests of the patent owner, taking account of
the legitimate interests of third parties. Emergence of the research exception
51. Much before the evolution of the Bolar doctrine (through the decision in Roche)
non-commercial, academic research of the art underlying a patent, or the determination of the use
of the patent, was recognized. Thus, for instance in Whittemore v Cutter, 29 F. Cas. 1120, 1121 (No.
17,600) (C.C.D. Mass. 1813) Justice Joseph Story articulated the principle as follows:
"[i]t could never have been the intention of the legislature to punish a man who
constructed such a machine merely for philosophical experiments, or for the purpose
of ascertaining the sufficiency of the machine to produce its described effects."
52. The next phase in the development of this branch was in Roche where the patentee plaintiff
Roche Products, Inc. (Roche), a large research-oriented pharmaceutical company, wanted the
United States district court to enjoin Bolar Pharmaceutical Co., Inc. (Bolar), a manufacturer of
generic drugs, from taking, during the life of a patent, the statutory and regulatory steps necessary
to market, after the patent expired, a drug equivalent to a patented brand name drug. Roche argued
that the use of a patented drug for federally mandated premarketing tests is a use in violation of the
patent laws. The district court recognized that the issue in the case was narrow: did limited use of a
patented drug for testing and investigation strictly related to FDA drug approval requirements
during the last 6 months of a patents term constitute a use which, unless licensed, was
infringement. The district court held that it was not an infringement. The Federal Circuit Appellate
court reversed the trial courts order, holding that:Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

―Bolar may intend to perform "experiments," but unlicensed experiments conducted
with a view to the adoption of the patented invention to the experimentor's business
is a violation of the rights of the patentee to exclude others from using his patented
invention. It is obvious here that it is a misnomer to call the intended use de minimis.
It is no trifle in its economic effect on the parties even if the quantity used is small. It
is no dilettante affair such as Justice Story envisioned. We cannot construe the
experimental use rule so broadly as to allow a violation of the patent laws in the guise
of "scientific inquiry,"
when that inquiry has definite, cognizable, and not insubstantial commercial
purposes.
53. Soon after this judgment, the US Congress enacted a law permitting use of patented products in
experiments for the purpose of obtaining Food and Drug Administration (FDA) approval [Section
271(e)(1)]. This provision, known as the research exemption, consolidated the Bolar research
exception articulated by the US District Court, which was reversed in the Federal Circuit decision.
The new provision (Section 271 (e)(i)) reads as follows:
―(e) (1)It shall not be an act of infringement to make, use, offer to sell , or sell within
the United States or import into the United States a patented invention (other than a
new animal drug or veterinary biological product (as those terms are used in the
Federal Food, Drug, and Cosmetic Act and the Act of March 4, 1913) which is
primarily manufactured using recombinant DNA, recombinant RNA, hybridoma
technology, or other processes involving site specific genetic manipulation
techniques) solely for uses reasonably related to the development and submission of
information under a Federal law which regulates the manufacture, use, or sale of
drugs or veterinary biological products.
54. It is noticeable that the provision does not expressly enable development and submission of
information under a law other than a ―Federal law which regulates the manufacture, use, or sale of
drugs or veterinary biological products implying that the use of the patented invention in relation
to regulatory approval abroad was not authorized. Yet, in Intermedics, Ventritex used the clinical
trial data obtained under the protection of Section 271(e)(1) to solicit money to fund further clinical
trials after the patent term expired; Ventritex also used this data to obtain patent rights in other
countries. The court noted that an otherwise infringing activity is exempt if:
―It [would] have been reasonable, objectively, for a party in defendant's situation to
believe that there was a decent prospect that the "use" in question would contribute
(relatively directly) to the generation of kinds of information that was likely to be
relevant in the processes by which the FDA would decide whether to approve the
product.
55. The court, therefore, held that Ventritex's uses did not infringe the patent, and the Federal
Circuit affirmed the district court's decision, suggesting that Congress intended thatBayer Corporation vs Union Of India & Ors. on 22 April, 2019

Section271(e)(1) be used to shelter all products seeking FDA approval, regardless of their projected
commercialization date.
56. In Merck KGaA v. Integra Lifesciences Ltd., 545 U.S. 193, 200 (2005), the US Supreme Court
had the occasion to consider the experimental exception. Integra owned several patents, including a
"short tri-peptide segment of fibronectin" with the amino acid sequence Arg-Gly-Arg, known as the
RGD peptide. The defendant, Merck hired one Dr. Cheresh, a scientist at a research institute, to
investigate compounds with the same receptor blocking capability as the RGD peptides. Integra
offered to license their patents to Merck, which declined the offer. Integra sued Merck, Scripps, and
Dr. Cheresh for patent infringement. The district court rejected the defendants research exception
based argument. This ruling was affirmed by the Federal Circuit court, which held that:
"the Scripps work sponsored by Merck was not clinical testing to supply information
to the FDA, but only general biomedical research to identify new pharmaceutical
compounds."
57. The US Supreme Court judgment unanimously reversed the Federal Circuit judgment and
disapproved the narrow interpretation of the experimental use provision, stating that:
"as an initial matter, we think it apparent from the statutory text that §271(e)(1)'s
exemption from infringement extends to all uses of patented inventions that are
reasonably related to the development and submission of any information under the
FDCA."
58. The Supreme Court further said "this [information] necessarily includes preclinical studies of
patented compounds that are appropriate for submission to the FDA in the regulatory process."
And that to construe § 271(e)(1) what the Federal Circuit did:
"is effectively to limit assurance of exemption to the activities necessary to seek
approval of a generic drug.
59. In Japan, acts relating to the marketing approval of pharma products were deemed by the
Supreme Court covered by its Patents laws experimentation exception. In a unanimous decision,
the court in Ono Pharmaceuticals Co., Ltd. v Kyoto Pharmaceutical Industries, Ltd 1999 (30) IIC
448, held that tests during the patent term for obtaining data needed for regulatory approval were
not infringing acts, under section 69(1) of the Japanese Patent law.
60. In the UK, the experimental use exception followed an unusual trajectory of development. The
experimental use exemption was inserted by Section 60(5)(b) of the Patents Act 1977. This is still in
force and it applies to all patent subject matter, including medicines, medical devices and
agrochemicals. In Monsanto v Stauffer 1985 RPC 515, the defendants sought the modification to an
injunction that had been ordered against the manufacture and sale of their Touchdown herbicide for
agricultural use. The Court of Appeal permitted limited modifications to the injunction so that it didBayer Corporation vs Union Of India & Ors. on 22 April, 2019

not prevent the defendants from conducting experiments on Touchdown in laboratories or
glasshouses in the UK to find out more about it. But the court did not permit field trials for the
purpose of commercial clearance from the Pesticides Safety Precautions Scheme and approval from
the Agricultural Chemicals Approval Scheme (that existed under legislation at the time). Explaining,
where the line is to be drawn between exempted and non-
exempted experiments under the Original Experimental Use Exemption, the court stated:
―Trials carried out in order to discover something unknown, or to test an hypothesis, or even in
order to find out whether something which is known to work in specific conditions, e.g. of soil or
weather, will work in different conditions can fairly ... be regarded as experiments. But trials carried
out in order to demonstrate to a third party that a product works or, in order to amass information
to satisfy a third party, whether a customer or a [regulatory] body such as the PSPS or ACAS, that
the product works as its maker claims are not to be regarded as acts done for 'experimental
purposes'
61. Exempted experiments therefore, are those that generate new knowledge, but not those that
verifying existing knowledge, for example for getting regulatory clearance. The later decision of the
Court of Appeal in Auchinclossv Agricultural and Veterinary Supplies and Others [1999] RPC 397 is
in line with this, as it holds that making and experimenting with a patented invention merely for the
purposes of gaining official approval would not fall within the Original Experimental Use
Exemption. The facts of the Auchincloss case again concern agrochemicals: a sample of a dry water-
soluble biocidal composition sent by the defendant to MAFF, the old Ministry of Agriculture,
Fisheries and Food. Here, the Court of Appeal held that supplying a sample to MAFF in order to
obtain official approval rather than to discover something unknown or to test a hypothesis, was not
covered by the exemption. The UK courts thus distinguish between application of the experimental
use exemption to activity conducted for the purpose of discovering something new (about the
subject matter of the invention), and mere verification of what is already known. If trials and tests
on a substance for regulatory approval of that substance are not discovering something new, the
exemption is inapplicable. It is accepted that this is the case as regards bioequivalence studies for an
abridged application - they cannot be protected; there is also lack of clarity that full clinical trials
would be protected.
62. The new exemption was enacted in the wake of concerns that the UK was losing opportunities to
conduct work in support of getting marketing authorizations, such as trials, because of the limited
UK Bolar Exemption. It is therefore concerned specifically with medicinal products. This new
Exemption came into force on 01.10.2014, by way of addition to the Original Exemption. However,
as stated above, the Original Experimental Use Exemption and the Bolar Exemption, remain intact.
A medicinal product assessment is defined as "any testing, course of testing or other activity
undertaken with a view to providing data for purposes which include the following:
 obtaining or varying an authorisation to sell or supply, or offer to sell or supply, a
medicinal product (whether in the United Kingdom or elsewhere);Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

 complying with any regulatory requirement imposed (whether in the United
Kingdom or elsewhere) in relation to such an authorisation;
 enabling a government or public authority (whether in the United Kingdom or
elsewhere), or a person (whether in the United Kingdom or elsewhere) with functions
of--
 providing health care on behalf of such a government or public authority,
63. Therefore, in addition to activities covered by the Bolar Exemption, the preparation and running
of clinical trials on innovative drugs for marketing authorisation are also exempt. Furthermore,
work undertaken in the UK in support of a regulatory filing in a country outside of the EU is also
now covered.
64. The statutory exemption to infringement under Canadian law is embodied in Section 55.2(1) of
its Patent Act which provides that:
―It is not an infringement of a patent for any person to make, construct, use or sell
the patented invention solely for uses reasonably related to the development and
submission of information required under any law of Canada, a province or a country
other than Canada that regulates the manufacture, construction, use or sale of any
product.
65. This provision concerns activities relating to the development and submission of information
required by a regulatory body. The Canadian provision is agnostic and sector neutral, in that it
concerns with regulatory approval for inventions in all areas of technology and is not restricted to
pharmaceuticals. The disputes before the Canadian courts are primarily in the pharmaceutical area,
most often in the context of generic manufacturers performing tests in respect of a patented drug.
Also, this provision relates to information that may be required by a regulatory body anywhere (and
not just in Canada).
66. A leading Canadian decision, Merck et al. v. Apotex (2006) FCA 323, (Federal Court of Appeal),
was in the context of a generic drug development. The court held that the defendant prepared and
tested the patented Lisinopril drug for the purposes of filing abbreviated new drug submissions
necessary to sell Lisinopril in Canada and the USA. Some of the data was referenced in Apotex's
submissions, directed to that purpose. Apotex also had stored samples in the event that they were
required for future reference by the government. The court held that Section 55.2(1) was broad
enough to exempt such generic drug development activities from infringement. The safe-harbour
provision can protect activities reasonably related to development and submission of information
required by law, either before or after market approval. The court also found that Apotex's use of
Lisinopril in ongoing research and development of alternate formulations and alternate techniques
for tablet-making fell within the common law exemption to infringement. This was because they did
not proceed beyond an experimental (testing) phase and did not take steps to manufacture, promote
and sell the product.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

67. In the opinion of the court, the course of the experimental exception- both before and after the
TRIPS has shown the adoption, generally of a broad approach, to permit use of all kinds. Broadly,
the courts approach has been not to enjoin or prohibit purely experimental or scientific activity, as
long as it does not have any primary commercial undertones.
Legislative history of Section 107A
68. Curiously, predating Section 107A the Indian Parliament had enacted a research exception,
Section 47 which stated, inter alia,[by Section 47 (3)] that:
"47. Grant of patents to be subject to certain conditions.--The grant of a patent under
this Act shall be subject to the condition that--
***** (3) any machine, apparatus or other article in respect of which the patent is
granted or any article made by the use of the process in respect of which the patent is
granted, may be made or used, and any process in respect of which the patent is
granted may be used, by any person, or the purpose merely of experiment or research
including the imparting of instructions to pupils...
69. This provision has been retained in the statute book. This was suggested by the committee,
constituted in 1957, under the chairmanship of Justice N. Rajagopala Ayyangar to take a fresh look
at patent law to suggest the best way to best sub-serve the contemporary needs of India. Justice
Ayyangars Report on Patent Law Revision of September 1959 was the basis of the Patents Act,
1970. The report noticed that the right of researchers, to use the invention - whether it be an article
or a process - for the purposes of carrying out experiments - in the course of research, as
distinguished from use for a commercial purpose is one matter in connection with the right of
patentees had to be clarified. In this connection, while taking note of the uncertainty of the law on
this topic in the U.K., Justice Ayyangar took the view that:
"I consider it desirable that the law should specifically exempt use of the patented
articles or processes or the use of articles or products made by the use of the patented
process or patented machine or apparatus for experimental purposes from being
actionable as an infringement."
70. The amendment of 1999 to the Patents Act was pre-dated by a report of the Joint Parliamentary
Committee. It recommended introduction of a Bolar exemption provision. The report explained the
reason for Clause 51 (which was to be the amendment):
―Clause 51: this clause seeks to insert a new Section 107A in the principal Act,
relating to certain acts which are not to be considered as infringement. This provision
has been made to ensure prompt availability of products, particularly generic drugs,
immediately after the expiry of the term of the patent. The amendment in this clause
has been made to make a provision in consonance with the Bolar Provisions at the
global level. The other amendment in this clause is correction of a typographicalBayer Corporation vs Union Of India & Ors. on 22 April, 2019

error.
71. The Notes on clauses, amending the Act, through the Bill reads as follows:
"this clause seeks to insert a new section 107A in the Act, relating to certain acts
which are not to be considered infringements. It is proposed that the act of making or
using a patented product for the purpose of development and submission of
information to a regulatory authority regulating marketing approval of the product,
shall not constitute an infringement. This provision is proposed to ensure that
generic drug should be available in Indian market immediately after the expiry of the
term of the concerned patents.
72. The Patents (Second Amendment) Bill, 1999 reads as follows:
―After section 107 of the principal Act. the following section shall be inserted,
namely:
Clause 51. After section 107 of the principal act, the following section shall be
inserted, namely ―107A For the purposes of this Act,-
(a) Any act of making or using a patented invention within three years before the
expiry of the term of the patent by any person for the purpose of development and
submission of the information to any regulatory authority responsible for grant of
marketing approval for the product of invention.
73. In the Statement of Objects and Reasons (introducing the Amending Act), it was stated that:
―4. Some of the salient features of the Bill are.... ―(h) to make a provision enabling
persons other than patent holder to obtain marketing approval from the appropriate
regulatory authorities within three years before the expiration of the term of the
patent
74. Eventually, the Patents Amendment Act of 2002 was enacted; it stated as follows:
―44. After section 107 of the Principal Act, the following section shall be inserted
namely, 107A: For the purposes of this Act
(a) Any act of making, constructing, using or selling a patented invention solely for
uses reasonably related to the development and submission of information required
under any law for the time being in force, in India or in a country other than India,
that regulates the manufacture, construction, use or sale of any product
75. The Patent (Amendment) Bill, 2003 proposed insertion of the expression "import" as follows:Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

―107A: For the purposes of this Act
(a) any act of making, constructing, using selling or importing a patented invention
solely for uses reasonably related to the development and submission of information
required under any law for the time being in force, in India or in a country other than
India, that regulates the manufacture, construction, use or sale of any product
76. Eventually, the Patents Amendment Act, 2005 which proposed the amendment in its present
form, was enacted; it reads as follows:
―107A: For the purposes of this Act
(a) any act of making, constructing, using selling or importing a patented invention
solely for uses reasonably related to the development and submission of information
required under any law for the time being in force, in India or in a country other than
India, that regulates the manufacture, construction, use or sale or import of any
product
77. These stages in the amendment of the Act and the introduction of Indias Bolar exemption
demonstrate that Parliament took a careful and nuanced view of the matter; it also had the benefit
of provisions enacted in other countries, including the US and Canadian law.
A Interpretation of "sale" and whether it encompasses "exports"
78. Rival arguments were addressed with respect to the expression "sale" and whether it
comprehends "export". Bayer contended that the use of "sale" along with "import" excluded the
term "export" from the meaning of the expression "sale" which is otherwise wide. In aid of this, it
was contended that Section 84 and Section 92A used the term "export" expressly and that, given this
clear internal clue from the statute, the court should not accept Natcos contention that an export
transaction is covered by sale. According to Bayer, the learned single judge erred in writing into the
statute an expression which was omitted by resorting to an over liberal interpretation of a causus
omissius. A third argument made was that only those extra- territorial aspects which have an impact
or nexus with India and are enacted with the intent of creating some benefit for India would fall
within the constitutionally sanctioned idea of legislative competence; since none can be said to
accrue to India, the term "export" should not be read into the expression "sell". Lastly it was argued
that Section 107A is in the nature of a proviso or exception to Section 48, which defines the content
and rights of a patentee and that the court should, consistent with the interpretation of any proviso,
ensure that it is kept within the bounds of what is sought to be excepted. Natco disputed each of
these contentions, urging that "sell" should not be juxtaposed with other provisions which expressly
talk of export and that the court should consider the context of Section 84 and Section 92A the
underlying purposes of which are entirely different from Section 107A. It was highlighted that the
references to "other country" in Section 107A would be meaningless if export is not construed to be
part of "sell" and that an export is but a species of sale. Also, Natco relied on the term "construct"
occurring in Section 107A and stated that the use of "sell" "import" and "construct" permit all rangeBayer Corporation vs Union Of India & Ors. on 22 April, 2019

of transactions and uses covered by the provision. It was contended that considerations of extra
territorial impact of any provision do not arise. Lastly it was urged that Section 107A - in its
placement and having regard to its legislative history is clearly not an exception or proviso, but a
special provision which must be given full meaning and effect.
79. Two clear strands of reasoning have prevailed in various judgments of the Supreme Court, while
interpreting the meaning and purport of general words. One, that plain and natural meaning should
be preferred ordinarily, and two, that the context and purpose of the provision should always be
kept in mind. Thus, in Polestar Electronic (Pvt.) Ltd. v Additional Commissioner, Sales Tax and Anr.
(1978) 1 SCC 636, it was held:
―11. ... If the language of a statute is clear and explicit, effect must be given to it, for in
such a case the words best declare the intention of the law-giver. It would not be right
to refuse to place on the language of the statute the plain and natural meaning which
it must bear on the ground that it produces a consequence which could not have been
intended by the legislature. It is only from the language of the statute that the
intention of the Legislature must be gathered, for the legislature means no more and
no less than what it says. It is not permissible to the Court to speculate as to what the
Legislature must have intended and then to twist or bend the language of the statute
to make it accord with the presumed intention of the legislature. ...
80. Central Bank of India v State of Kerala and Ors. (2009) 4 SCC 94, a three-Judge Bench
judgment, quoted Professor H.A. Smith (as quoted in Justice G.P. Singhs Principles of Statutory
Interpretation) to the following effect:
―'No word', says Professor H.A. Smith 'has an absolute meaning, for no words can be
defined in vacuo, or without reference to some context'. According to Sutherland
there is a 'basic fallacy' in saying 'that words have meaning in and of themselves', and
'reference to the abstract meaning of words', states Craies, 'if there be any such thing,
is of little value in interpreting statutes'. ... in determining the meaning of any word
or phrase in a statute the first question to be asked is - 'What is the natural or
ordinary meaning of that word or phrase in its context in the statute? It is only when
that meaning leads to some result which cannot reasonably be supposed to have been
the intention of the legislature, that it is proper to look for some other possible
meaning of the word or phrase.' The context, as already seen, in the construction of
statutes, means the statute as a whole, the previous state of the law, other statutes in
pari materia, the general scope of the statute and the mischief that it was intended to
remedy.
81. Speaking of the use of an expression or term in different parts of a statute, the court held in
Central Bank of India v Ravindra & Ors. (2002) 1 SCC 36 that:
―42. ...Ordinarily, a word or expression used at several places in one enactment
should be assigned the same meaning so as to avoid "a head-on clash" between twoBayer Corporation vs Union Of India & Ors. on 22 April, 2019

meanings assigned to the same word or expression occurring at two places in the
same enactment. It should not be lightly assumed that "Parliament had given with
one hand what it took away with the other" (see Principles of Statutory
Interpretation, Justice G.P. Singh, 7th Edn. 1999, p. 113). That construction is to be
rejected which will introduce uncertainty, friction or confusion into the working of
the system (ibid, p. 119). While embarking upon interpretation of words and
expressions used in a statute it is possible to find a situation when the same word or
expression may have somewhat different meaning at different places depending on
the subject or context. This is however an exception which can be resorted to only in
the event of repugnancy in the subject or context being spelled out. It has been the
consistent view of the Supreme Court that when the legislature used same word or
expression in different parts of the same section or statute, there is a presumption
that the word is used in the same sense throughout (ibid, p. 263). More correct
statement of the rule is, as held by the House of Lords in Farrell v. Alexander All ER
at p. 736b, "where the draftsman uses the same word or phrase in similar contexts, he
must be presumed to intend it in each place to bear the same meaning". The court
having accepted invitation to embark upon interpretative expedition shall identify on
its radar the contextual use of the word or expression and then determine its
direction avoiding collision with icebergs of inconsistency and repugnancy.
82. It is, therefore, clear that whilst there is one rule generally speaking, use of a term or expression
in a statute, carries upon it to be interpreted in the same manner in all provisions of that statute, the
rule is neither inflexible admitting no exception nor of universal application. The object of the
concerned provision is one of the important factors which weigh in while interpreting whether the
same meaning has to be attributed to all parts of the statute. Given these circumstances, this Court
is of the opinion that "exports" is used in different contexts in Sections 84, 90 and 92A. Section 84 is
the provision which enables compulsory licensing of certain conditions. Section 84(7) spells out
what are reasonable requirements of the public. These are deemed not to have been satisfied if
under Section 84(7)(a)(iii), a market for the patented article manufactured in India is not being
supplied or developed. Section 90(1)(vii) is in a sense, complimentary to Section 84 and has to be
read with it: it guides the Controller to ensure inter alia that the license granted under Section
84(7)(a)(c)(iii) is with the predominant purpose of supply to the Indian market and that the licensee
may also export the patented product.
83. Section 92A is a species of compulsory license. The principles in one sense are even an exception
to it. The provision dealing with compulsory licensing [Section 84] is concerned only with the
availability of patented market, of reasonable terms for users in India. Therefore, the question of
reasonable requirements of other countries does not arise and yet the Parliament, in keeping with
TRIPS, (cognizant of the broad classification of nations as developed, developing and least
developed countries), envisioned Section 92A which enables licensing for export of patented
pharmaceutical products in exceptional circumstances, i.e. whether the country concerned has
insufficient or no manufacturing capacity in the pharmaceutical sector. Really speaking, this
provision, i.e. Section 92A constitutes an exception to the general rule that compulsory licensing is
only resorted primarily and predominantly to cater to the needs of the domestic market of the hostBayer Corporation vs Union Of India & Ors. on 22 April, 2019

country with regard also being had to export potential from that country.
84. Having regard to all these factors, it cannot be held that the Parliament intended to per se
exclude "exports" from the sweep and width of the term "sale" in Section 107A regard being had to
the disparate and differing objectives of Sections 84, 90 and 92A all of which in some way or the
other primarily deal with compulsory licensing and on the other hand, Section 107A is the only
provision that allows an exception to be used- construction and sale of a patented article only for
research purposes and subject to fulfillment of the conditions specified therein. The next argument
which Bayer strongly advanced with respect to exclusion of exports from the term "sale" is that
patent rights are territorial in nature, specific allusion was made to Section 48 in this regard.
Elaborating, it was contended that the grant of a patent constitutes a negative right to prevent third
parties from making, using, forwarding for sale, selling or importing the patented product in India.
Secondly, it was urged that the research exception, can be accepted, and needs to be carried out in
India if the benefit of that provision is to be secured.
85. It was submitted that Section 107A(a) really constitutes an exception and its effect has to be
strictly confined to the extent the terms of the expression spelt out and no more. Reliance was
placed upon Mohan Kumar Singhania v UOI AIR 1992 SC 1. There are a line of judgments which
state that a particular provision of an enactment cannot be said to nullify or set at nought the main
or substantive provision. In Dwarka Prasad v Dwarka Das Saraf 1976 (1) SCC 128, it was stated as
follows:
―18. We may mention in fairness to Counsel that the following, among other
decisions, were cited at the Bar bearing on the uses of provisos in statutes: CIT v.
Indo-Mercantile Bank Ltd., AIR 1959 SC 713]; Ram Narain Sons Ltd. v. Asstt. (1955)
2 SCR 483, 493:]; Thompson v. Dibdin [(1912) AC 533, 541; Rex v. Dibdin [1910 Pro
Div 57, 119, 125] and Tahsildar Singh v. State of U.P. AIR 1959 Supp (2) SCR 875,].
The law is trite. A proviso must be limited to the subject-matter of the enacting
clause. It is a settled Rule of construction that a proviso must prima facie be read and
considered in relation to the principal matter to which it is a proviso. It is not a
separate or independent enactment. "Words are dependent on the principal enacting
words to which they are tacked as a proviso. They cannot be read as divorced from
their context"
(Thompson v. Dibdin, 1912 AC 533). If the Rule of construction is that prima facie a
proviso should be limited in its operation to the subject-matter of the enacting clause,
the stand we have taken is sound. To expand the enacting clause, inflated by the
proviso, sins against the fundamental Rule of construction that a proviso must be
considered in relation to the principal matter to which it stands as a proviso. A
proviso ordinarily is but a proviso, although the golden Rule is to read the whole
section, inclusive of the proviso, in such manner that they mutually throw light on
each other and result in a harmonious construction.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

The proper course is to apply the broad general Rule of construction which is that a
Section or enactment must be construed as a whole, each portion throwing light if
need be on the rest.
The true principle undoubtedly is, that the sound interpretation and meaning of the
statute, on a view of the enacting clause, saving clause, and proviso, taken and
construed together is to prevail.(Maxwell on Interpretation of Statutes, 10th Edn., p.
162)
86. In S. Sundaram Pillai v V.R. Pattabiraman1985 (1) SCC 591, it was held that:
"27. The next question that arises for consideration is as to what is the scope of a
proviso and what is the ambit of an Explanation either to a proviso or to any other
statutory provision. We shall first take up the question of the nature, scope and
extent of a proviso. The well-established Rule of interpretation of a proviso is that a
proviso may have three separate functions. Normally, a proviso is meant to be an
exception to something within the main enactment or to qualify something enacted
therein which but for the proviso would be within the purview of the enactment. In
other words, a proviso cannot be torn apart from the main enactment nor can it be
used to nullify or set at naught the real object of the main enactment.(Emphasis
supplied)
87. Likewise, in J.K. Industries Ltd. v Chief Inspector of Factories and Boilers 1996 (6) SCC 665, it
was held as follows:
―33. A proviso to a provision in a statute has several functions and while interpreting
a provision of the statute, the court is required to carefully scrutinise and find out the
real object of the proviso appended to that provision. It is not a proper Rule of
interpretation of a proviso that the enacting part or the main part of the Section be
construed first without reference to the proviso and if the same is found to be
ambiguous only then recourse may be had to examine the proviso as has been
canvassed before us. On the other hand an accepted Rule of interpretation is that a
Section and the proviso thereto must be construed as a whole, each portion throwing
light, if need be, on the rest. A proviso is normally used to remove special cases from
the general enactment and provide for them specially.
34. A proviso qualifies the generality of the main enactment by providing an
exception and taking out from the main provision, a portion, which, but for the
proviso would be a part of the main provision. A proviso must, therefore, be
considered in relation to the principal matter to which it stands as a proviso. A
proviso should not be read as if providing something by way of addition to the main
provision which is foreign to the main provision itself.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(Emphasis supplied)
88. In the present case, this court notices that Section 107A is not made subject to the other
provisions of the Act - on the other hand, Section 48, which talks of the rights of a patent holder is
subject to other provisions of the Act that includes Section 107A. Furthermore, Bayers argument
that Section 107A constitutes an exception, cannot be accepted. It is an independent provision with
a specific history behind it and was subject to intensive Parliamentary debate and scrutiny by a Joint
Committee report. Furthermore, it was enacted in response to the TRIPS enabling provision to the
member countries to evolve national legislation facilitating research and progress in fields covered
by the patents. The judgments cited, all generally and invariably contended by Bayer deal with
provisos embodied in the main provision that constituted exceptions to the general rule. However,
in this case, the court is not called upon to interpret the proviso to Section 48; nor even an
exception. Bayers argument that Section 107A has to be read as subordinate to the main provision
of Section 48 has to, therefore, fail. This Court is also fortified in its conclusions. In Indian Oil
Corporation v the Chief Inspector of Factories and Ors. (1998) 5 SCC 738, the Supreme Court had to
decide whether one of the Directors only could recognise his occupier and whether Section 2(n)(iii)
of the Factories Act, 1948, applied to the IOCs factories and if it was open to the Central
Government to nominate any person other than the Director or the occupier. Section 2(n) was
amended to say that "occupier" meant the person who had ultimate control over the affairs of the
factory and also that in the case of firms or associations; and as to who could be occupiers in the
case of firms and association in the case of company (any of the Directors) and in the case of factory
owned by the Central Government, "person or persons nominated to manage the affairs of the
factory by the State Government, Central Government etc.. Prior to the amendment, the "occupier"
did not include the specific designated officials or employees of the company or firms. The Supreme
Court held that the requirement of third proviso could really constitute a separate provision, and
had to be read as such. The Supreme Court held as follows:
―20. Apart from the main part of Section 2(n), the first proviso also indicates that the
Legislature intended that the person having ultimate control over the affairs of the
factory has to be regarded as occupier of the factory. The proviso to the Section is not
in the nature of an exception. In order to avoid any ambiguity, to plug loopholes and
to seal the escape routes a deeming provision has been made in a mandatory form. In
the case of a firm obviously the partners of the firm have ultimate control over the
affairs of the partnership. In case of other type of association the members thereof
will have such control. In the case of a company the directors have the ultimate
control, as the power to manage the affairs of the company vests in the Board of
Directors. What clauses (i) and (ii) of the proviso provide is that they shall be deemed
to be 'occupiers'. Thus they merely restate the position which is obvious even
otherwise. The position of the government and the local authority is quite different
from that of a firm or an association or a company not only with respect to the person
who can be said to be in ultimate control but also with respect to the object for which
factory is set up. In a democratic set-up of Government, it may not be possible to say
with certainty as to who is having the ultimate control. In a welfare state, the
government does not carry on such activity for its own profit or benefit but for theBayer Corporation vs Union Of India & Ors. on 22 April, 2019

benefit of the people as a whole. Moreover, it is the government which looks after the
successful implementation of the provisions of the Factories Act and, therefore, it is
not likely to evade implementation of the beneficial provisions of the Factories Act.
That appears to be the reason why the legislature though it fit to make a separate
provision for the Government and the local authorities. Ordinarily, for running the
factories owned or controlled by the Central Government or any State Government,
or any local authority, a person or persons would be appointed by it to manage the
affairs of the factory, because the Government or the local authority as a whole would
not run the factory. Therefore, the legislature appears to have provided that in case of
a factory owned or controlled by the Central Government, the State Government or
the local authority the person or persons appointed to manage the affairs of the
factory by the Central Government, State Government or the local authority, as the
case may be, shall be deemed to be the occupier. Therefore, if it is a case of a factory
in fact and in reality owned or controlled by the Central Government or the State
Government or any local authority then in case of such a factory the person or
persons appointed to manage the affairs of the factory shall have to be deemed to be
the occupier, even though for better management of such a factory or factories a
corporate form is adopted by the government.
21. Before 1987, when Section 100 was the governing provision, any one of the
individual partners of a firm or any one of the members of association of individuals
could be punished under Sub-section (I) thereof for any offence for which the
occupier of the factory was punishable. The firm or association was given an option to
nominate one of its members as the occupier of the factory and if such an option was
exercised by giving a notice to the Inspector then he alone was to be deemed to be the
occupier of the factory for the said purpose. Under Sub-section (2) if the occupier of
the factory was a company then any one of the directors thereof could be prosecuted
and punished. A similar option was available to the company, as in the case of a firm
and an association of individuals. It is significant to note that it was by way of a
proviso to Sub-section (2) which dealt with case of a company that the provision was
made for deciding who should be deemed to be the occupier of a factory in case it
belonged to the Central Government or any State Government or any local authority
and a similar option is made available to them. The said proviso though enacted as an
exception to the main part of Sub-section (2) is truly by way of a separate provision
made in the case of a factory belonging to the Central Government or any State
Government or any local Authority. While making the amendment in 1987 in Section
2(n) and deleting Section 100 at the same time the Legislature made the proviso to
subsection (2) of Section 100 an independent proviso to Section 2(n). That also
clearly indicates the intention of the Legislature that it wanted to make a separate
provision for deeming who should be the occupier of a government factory.
89. In the light of the above discussion, the court is of the opinion that there is no question of
treating Section 107A(a) as an exception to SectionBayer Corporation vs Union Of India & Ors. on 22 April, 2019

48. Its history of interpretation by TRIPS, the discussion in the Parliamentary Joint Committee
Report, all clearly point to its being a special provision that deals with the rights of the patented
invention for research purposes.
90. As far as the question of territoriality is concerned, Bayers argument is twofold: that the
reference to regulatory requirements of other countries and its reference to reasonable regulations
or laws of other countries, for the purpose of development of the product and its making,
construction, use or sale, is to be understood as meaning that the overseas requirements are to be
met with through experimental use in India. Explaining further, it is contended that the reference to
overseas or other nations laws or regulations with respect to research requirements is to be
understood in such a way that information development in India can be exported.
91. This Court is of the opinion that the interpretation canvassed by Bayer is strained and artificial.
Once it is held that patented inventions can be sold for the purpose of carrying on research which
fulfils the regulatory requirements of India, there cannot be any bar or an interpretation narrowing
the scope of such sale. What is important is the purpose of the sale, i.e. objective of carrying on
experiment, research and developing information (in the form of reports, outcomes etc.). If the
purpose of the sale is to ultimately exploit the patented invention and either work upon it or "work
around" or work it through research so as to be prepared to apply for the patent for approval to
market it once the patent tenure ends, there can be no impairment of the patentees rights. The
natural consequence of that sale cannot be curtailed by a contrived interpretation to say that it is
only information that can be sold or exported, not the patented invention. Likewise, the reference of
another country i.e the export for reasonably complying with the laws of another country in relation
to the kind of research and experimentation needed is something that cannot be dictated by
interpretation of Indian law alone. It is plausible- even reasonable- that many nations may require
experimentation or research to be carried on in their soil nationally so as to be able to supervise the
process and then oversee the outcome. It is, therefore, not possible to dictate the behaviour and
legal requirements of other nations by confining the research exception within the territory of India.
92. The natural interpretation of the expression "use" is in all its senses. In this context, it would be
necessary to recognize that in regard to various products, especially those concerning the
pharmaceutical, medicinal preparations, surgical and diagnostic purposes and those relating to the
agriculture or bio-chemical sector, it may be critical for a database of populations, drugs and
co-relation, with disease and its relationship with characteristics that are predominantly local.
National regimes might well insist that such research and experimentation in regard to those
aspects be either entirely or at least in part be carried on in their territory. In this context, therefore,
it is held that the expressions, ―making, constructing, using, selling or importing patented articles
solely for uses reasonably related to development and submission of information required under any
law for the time being in force...... or in a country other than India that regulates the manufacturing,
construction, use, sale or import of any product, consequently, has to be given a wide import. It is,
therefore, open that the sale of the article or invention for the purpose of development of
information in compliance with the reasonable requirements of developing countries, solely for
purposes of research or development falls within Section 107A(a).Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

93. There is one more manner of looking at the issue. A patent owners interests are clearly injured
if the invention or the product or the method which is the subject matter of the patent is worked for
purely commercial purposes and the ensuing product is offered in the market. Such products would
be competitors to the patented invention and because of their copycat nature, one can reasonably
expect them to be significantly lower in cost, in the marketplace. However, in the case of sale,
construction or use of the patented article, either within India or outside the territory of India, the
question of such injury cannot ordinarily arise if the object or purpose of that transaction is solely to
experiment or research and develop information that is reasonably related to the requirements of
the law (Indian or overseas). If one considers this aspect, it is clear that the fullest effect ought to be
given to the research exception embodied in Section 107A(a). The objections with regard to the
territoriality of patents or the strained interpretation given to the provision of construing export (i.e.
the export sale) only to sale of information overseas, is unwarranted. Bayers argument, therefore,
is rejected on this aspect.
94. This Court also finds unpersuasive, Bayers subsidiary submission that Rule 122B of the Drugs
and Cosmetics Rules, 1945 permits the licensing authority to grant permission (for a product) on the
basis of data available from other countries. Thus, Bayers argument here was that the act of
importation in Section 107A refers to all such information which can be used for regulatory
purposes of the research and development in India. Here again, the court is of the opinion that the
broad nature of the provision - which enables development and research of the product and
information related thereto, on fulfilling the regulatory or other legal requirements of India, and
other countries- cannot be construed narrowly as to permit development and research of the
product only in India, even though the backup research is conducted elsewhere. The object and
underlying purpose of Drugs and Cosmetics Act is entirely different from those of the Patent Act.
The former deals with the range of regulatory provisions necessary for various classes of drugs to
receive licensing, marketing approvals etc. On the other hand, the patent regime is premised solely
upon the regulation of the intellectual property right relating to patents. The court is also of the
opinion that Natcos status as compulsory licensee did not place it under any additional statutory
bar from exporting the product, as long as the underlying condition in Section 107A was satisfied, as
held by the learned Single Judge.
95. It is therefore, clear that the submissions with respect to impermissibility of exportation of the
product cannot be accepted. Bayers arguments are rejected.
Submissions in respect of the Canada Dispute
96. Bayer had relied on the Canada Dispute (supra) ruling by the WTO DSP. Two important issues
in that case involved questions of public policy (societal public interest v. private rights). They were
permissible exceptions, under Articles 30 and 31 of TRIPS, to the use of patented products or
processes, without permission of the patent-owner (a patentees rights are detailed in Article 28.1
and 29), having regard to TRIPS principles in Articles 7 and 8. The provisions of Canadian Patent
Law- i.e. the regulatory review exception and the stockpiling exception were challenged by the EU.
The Regulatory Review Exception, in Section 55.2(1) of Canadas patent law, allows the generic
industry without authorization, to develop the product and submit it to regulatory authorities forBayer Corporation vs Union Of India & Ors. on 22 April, 2019

market approval so that they could market the product when the patent expires; no permission of
the patent owner was essential. The stockpiling exception in Section 55.2(2) of Canadas law
permitted generic manufacturers to produce and stockpile (store) generic products for which
marketing approval has been obtained, during a six-month period before expiry of the patent, and
market the generic products as soon as the patent has expired. The first exception (regulatory or
research exception) to patent rights has been held legal, but the stockpiling exception was held to be
illegal.
97. Bayers argument was that Canadas plea was that the reference to "selling" the invention was
necessitated by the fact that a generic drug manufacturer had to usually purchase the active
ingredient for its product from a "fine chemical producer". Bayer relied upon footnote 49 on page 21
of the award, which reads as follows:
―In response to a question from the Panel, Canada explained that, if the patentee
claimed that a fine chemical manufacturer was infringing the patent, i.e. was
manufacturing fine chemicals for purposes which were outside the exception, the
patentee would commence infringement litigation against the manufacturer under
Sections 54 and 55 of the Patent Act. The manufacturer would then be obliged to
prove that it would have been reasonable, objectively, for a party in its position to
believe that the use made of its manufactured active ingredients related to the
development and submission of information required by law. It would be common
commercial practice for the supply contract with the manufacturer to specify the
purposes for which the chemicals were being manufactured and to provide an
appropriate indemnity against infringement liability. While the matter had not been
decided in the courts, the effect of the exception of Section 55.2(2) for the fine
chemical producer would appear to be that a third party could acquire intermediate
products, or ―inputs, such as the bulk fine chemical constituting the active
ingredient of a generic drug, for manufacturer and storage during the last six months
of the patent term. In other words, both the third party and manufacturer would
appear to be covered by the exception.
98. It was submitted that the DSP in its findings stated that "selling" in the provision was under
challenge. Para 7.4 of the award was also relied on; it states that:
―The structure of the generic pharmaceutical industry illustrates the actual operation
of the regulatory review exception. Production of generic pharmaceuticals often
involves a two-tier production arrangement. The firm that assembles and markets the
final generic product often does not have the technological capacity/expertise or the
commercial motivation to produce the so called ―active ingredient - the chemical
product that generates the desired medicinal effect. The active ingredient is thus
often manufactured by a specialized producer of fine chemicals, and then sold to the
generic producer which assembles the active ingredient with other agents to create
the final product in a form that can be used by the ultimate consumer. In such cases,
both producers must engage in conduct that, in the absence of a regulatory reviewBayer Corporation vs Union Of India & Ors. on 22 April, 2019

exception, would be potentially infringing, if they are to satisfy the requirements of
the regulatory review process - the fine chemical producer in developing, making and
selling the necessary amounts of the active ingredient to the generic producer, and
the generic producer in combining the various elements to make the final product
and then demonstrating its safety, stability and effectiveness by appropriate tests.
The regulatory review exception applies to these activities of both producers.
99. In view of these submissions, Bayer argued that Parliament inserted the term "selling" in Section
107A(a) with intent to exempt the activities of the contract manufactures and any entity selling
within the territory of India for the purposes as contemplated under the said section.
100. Several countries, including India, Canada and the US have fashioned their patent laws to carve
out such an exception. The Canadian provision, Section 55.2(1), which enabled use of a patented
product for generation of information to be submitted to regulatory authorities was the subject
matter of a complaint lodged by the US and Europe at the Dispute Settlement Body of the WTO. It
was contended that Section 55.2(1) violated TRIPS.
101. The DSP under TRIPS in the Canada dispute case (supra) discussed the issue; it found that such
a provision (i.e. Canadas regulatory exception) was a "limited exception" within the meaning of
Article 30 of TRIPS, and that the size of production would not violate patent rights so long as it is
solely for regulatory purposes. The DSP flagged the purpose of use in its award, relevant portions of
which are extracted below:
―7.3 Because of the regulatory review exception's importance to the pharmaceutical
industry, the operation of the exception with regard to new pharmaceuticals was
explained in some detail by the parties. Information supplied by Canada in the
proceedings before the Panel on the process of regulatory approval in Canada for
patented and generic drugs can be found in paragraphs 2.2 to 2.7 above and Annexes
3 and 4 to this Report. The information has not been contested by the European
Communities. Since patent applications are generally filed as quickly as possible after
the invention has been made, actual marketing of the patented product is frequently
delayed for a certain period of time because time is required for development of the
product in commercial form, after which additional time is required to complete the
testing required for government approval. According to the information supplied by
Canada, the process of development of the drug and regulatory approval for new
patented pharmaceuticals normally takes approximately eight to 12 years. The long
development and approval process means that, for most patented pharmaceuticals,
the 20-year patent term results in an actual period of market exclusivity of only some
12 to eight years. After a pharmaceutical patent expires, it is common for other
producers to enter the market supplying copies of the patented product at lower
prices. These lower-priced copies, known as "generic" pharmaceuticals, often
constitute a large part of the supply of pharmaceuticals in national markets. Generic
pharmaceuticals must also comply with the government approval process. According
to Canada's information, for generic producers the process of developing theirBayer Corporation vs Union Of India & Ors. on 22 April, 2019

version of the drug and obtaining regulatory approval takes approximately three to
six-and-a-half years, with development taking some two to four years and the
regulatory process itself one to two-and-a-half years. If none of the development
process could be performed during the term of the patent, generic producers could be
forced to wait the full three to six-and-a-half years after the patent expires before
being able to enter the market in competition with the patent owner. To the extent
that some development activity might be permitted, consistently with Article 30 of
the TRIPS Agreement, under other exceptions such as the traditional exception for
experimental use of the patented product, the delay in entering the market would be
correspondingly less.
The regulatory review exception in Section 55.2(1) would allow generic producers to complete both
development and regulatory approval during the term of the patent, thus allowing them to enter the
market as soon as the patent expires.
7.4 The structure of the generic pharmaceutical industry illustrates the actual operation of the
regulatory review exception. Production of generic pharmaceuticals often involves a two-tier
production arrangement. The firm that assembles and markets the final generic product often does
not have the technological capacity/expertise or the commercial motivation to produce the so- called
"active ingredient" - the chemical product that generates the desired medicinal effect. The active
ingredient is thus often manufactured by a specialized producer of fine chemicals, and then sold to
the generic producer which assembles the active ingredient with other agents to create the final
product in a form that can be used by the ultimate consumer. In such cases, both producers must
engage in conduct that, in the absence of a regulatory review exception, would be potentially
infringing, if they are to satisfy the requirements of the regulatory review process - the fine chemical
producer in developing, making and selling the necessary amounts of the active ingredient to the
generic producer, and the generic producer in combining the various elements to make the final
product and then demonstrating its safety, stability and effectiveness by appropriate tests. The
regulatory review exception applies to these activities of both producers.
7.5 To qualify for exemption under Section 55.2(1), such activities by either fine chemical producers
or generic producers must be "solely for uses reasonably related to the development and submission
of information required" by any law, Canadian or non- Canadian, that "regulates the manufacture,
construction, use or sale of any product". In answer to a question from the Panel, Canada stated
that, although Canadian marketing regulations for generic producers did not require production
runs to demonstrate the applicant's ability to maintain quality production in commercial
volumes373, the statute would allow either fine chemical manufacturers or generic producers to
undertake such production runs if they were required by regulations in other countries.
102. Later, in its decision, the DSP held as follows:
―7.45 In the Panel's view, however, Canada's regulatory review exception is a "limited
exception" within the meaning of TRIPS Article 30. It is "limited" because of the
narrow scope of its curtailment of Article 28.1 rights. As long as the exception isBayer Corporation vs Union Of India & Ors. on 22 April, 2019

confined to conduct needed to comply with the requirements of the regulatory
approval process, the extent of the acts unauthorized by the right holder that are
permitted by it will be small and narrowly bounded. Even though regulatory approval
processes may require substantial amounts of test production to demonstrate reliable
manufacturing, the patent owner's rights themselves are not impaired any further by
the size of such production runs, as long as they are solely for regulatory purposes
and no commercial use is made of resulting final products.
7.46 The Panel found no basis for believing that activities seeking product approvals
under foreign regulatory procedures would be any less subject to these limitations.
There is no a priori basis to assume that the requirements of foreign regulatory
procedures will require activities unrelated to legitimate objectives of product quality
and safety, nor has the EC provided any evidence to that effect. Nor is there any
reason to assume that Canadian law would apply the exception in cases where foreign
requirements clearly had no regulatory purpose. Nor, finally, is there any reason to
assume that it will be any more difficult to enforce the requirements of Canadian law
when Canadian producers claim exceptions under foreign procedures. With regard to
the latter point, the Panel concurred with Canada's point that the government is not
normally expected to regulate the actual conduct of third parties in such cases. The
enforcement of these conditions, as with other enforcement of patent rights, occurs
by means of private infringement actions brought by the patent owner.
The patent owner merely has to prove that the challenged conduct is inconsistent with the basic
patent rights created by national law. Once that initial case is made, the burden will be on the party
accused of infringement to prove its defence by establishing that its conduct with respect to foreign
regulatory procedures was in compliance with the conditions of Section 55.2(1).
7.47 In reaching this conclusion, the Panel also considered Canada's additional arguments that both
the negotiating history of Article 30 of the TRIPS Agreement and the subsequent practices of certain
WTO Member governments supported the view that Article 30 was understood to permit regulatory
review exceptions similar to Section 55.2(1). The Panel did not accord any weight to either of those
arguments, however, because there was no documented evidence of the claimed negotiating
understanding, and because the subsequent acts by individual countries did not constitute "practice
in the application of the treaty which establishes the agreement of the parties regarding its
interpretation" within the meaning of Article 31.3(b) of the Vienna Convention.
7.48 A final objection to the Panel's general conclusion remains to be addressed. Although the point
was raised only briefly in the parties' legal arguments, the Panel was compelled to acknowledge that
the economic impact of the regulatory review exception could be considerable. According to
information supplied by Canada itself, in the case of patented pharmaceutical products
approximately three to six-and-a-half years are required for generic drug producers to develop and
obtain regulatory approval for their products. If there were no regulatory review exception allowing
competitors to apply for regulatory approval during the term of the patent, therefore, the patent
owner would be able to extend its period of market exclusivity, de facto, for some part of that threeBayer Corporation vs Union Of India & Ors. on 22 April, 2019

to six-and-half year period, depending on how much, if any, of the development process could be
performed during the term of the patent under other exceptions, such as the scientific or
experimental use exception. The Panel believed it was necessary to ask whether measures having
such a significant impact on the economic interests of patent owners could be called a "limited"
exception to patent rights.
103. This Court notices that the phraseology of the Canadian provision (Section 55.2.1) is closely
similar to Section 107A(a). Given this fact, the DSP ruling assumes significance. It noticed that firms
which ―assemble and market the final generic product oftentimes do not have technological
expertise or capacity to produce the active ingredient (the chemical product that generates the
desired medicinal effect or "API"). This API is produced by a specialized manufacturer and sold to
the generic producer. The latter assembles the API with other agents and creates the final product in
a form that can be used by the ultimate consumer. The DSP stated that the conduct of such generic
manufacturer and the API producers activities are covered by the regulatory or research exception.
―7.5 To qualify for exemption under Section 55.2(1), such activities by either fine chemical
producers or generic producers must be "solely for uses reasonably related to the development and
submission of information required" by any law, Canadian or non- Canadian, that "regulates the
manufacture, construction, use or sale of any product". In answer to a question from the Panel,
Canada stated that, although Canadian marketing regulations for generic producers did not require
production runs to demonstrate the applicant's ability to maintain quality production in commercial
volumes373, the statute would allow either fine chemical manufacturers or generic producers to
undertake such production runs if they were required by regulations in other countries.
104. The Panels view on this aspect is clear and unambiguous:
―7.45 In the Panel's view, however, Canada's regulatory review exception is a "limited
exception" within the meaning of TRIPS Article 30. It is "limited" because of the
narrow scope of its curtailment of Article 28.1 rights. As long as the exception is
confined to conduct needed to comply with the requirements of the regulatory
approval process, the extent of the acts unauthorized by the right holder that are
permitted by it will be small and narrowly bounded. Even though regulatory approval
processes may require substantial amounts of test production to demonstrate reliable
manufacturing, the patent owner's rights themselves are not impaired any further by
the size of such production runs, as long as they are solely for regulatory purposes
and no commercial use is made of resulting final products.
7.46 The Panel found no basis for believing that activities seeking product approvals
under foreign regulatory procedures would be any less subject to these limitations.
There is no a priori basis to assume that the requirements of foreign regulatory
procedures will require activities unrelated to legitimate objectives of product quality
and safety, nor has the EC provided any evidence to that effect. Nor is there any
reason to assume that Canadian law would apply the exception in cases where foreign
requirements clearly had no regulatory purpose. Nor, finally, is there any reason toBayer Corporation vs Union Of India & Ors. on 22 April, 2019

assume that it will be any more difficult to enforce the requirements of Canadian law
when Canadian producers claim exceptions under foreign procedures.
105. It is clear, therefore, that neither the quantity used nor the place of research and development
or information (i.e. within the country granting patent or on foreign soil) is per se conclusive that
the claim to use the Bolar or research exception has to be rejected. Instead, the conduct or action of
the individual or entity making, using, constructing or selling the patented product or invention and
the purpose for which it sought to be used (i.e. end use and that it should not be commercial) would
be important and decisive whether the exporting or purchasing entity intends to use the patented
product for commercial purposes.
Tests necessary to regulate the use of the Section 107A exemption
106. This Court, in the previous parts of the present judgment, has rejected Bayers argument with
respect to the interpretation of Section 107A. Nevertheless, the court is also cognizant of the fact that
export of patented invention can potentially be troublesome to the patent owner; an unregulated
export activity can result in exploitation of the Bolar exemption beyond what can be considered
"reasonably" related to obtaining approval under laws of India or another country. The wide nature
of reliefs claimed by Bayer in the writ petition, i.e direct seizure of export consignment, direction to
customs authorities to insist on labelling of products to facilitate their seizure and other such reliefs,
in the opinion of the court, cannot be granted in a writ proceeding because whether the research
provision has been invoked correctly can be determined by an examination of facts and also seeking
expert opinion wherever needed. Equally, directing the executive to ensure labelling of the products
sought to be exported, cannot be the subject matter of judicial review proceedings.
107. That brings the question to what is use, sale, etc "reasonably related"
for the purpose of developing information, ultimately used for in compliance with
regulatory processes and laws in or outside India? Ultimately, on this aspect, there
cannot be an ironclad rule or bright line as to what acts are reasonably related to the
use or sale of the product, with the object of using the developed information to
satisfy the regulations.
108. The Canada dispute case (supra) is a clear authority which instructs that the volume of use,
sale, construction, etc of a patented invention - or the quantum is itself inconclusive on the issue.
Some guidance is, however, available in this regard by the UK Intellectual Property Office (UKIPO)
and Medicines and Healthcare products Regulatory Agency (MHRA). The guidelines issued in this
regard are extracted below:
 ―The carrying out of chemical and biological synthetic processes suitable for the
making, disposal or keeping of the active substance(s) including the manufacture or
the import of batches in quantities sufficient to provide material for preparing
investigative batches of the medicinal product and to validate the processes to the
satisfaction of the competent authorities.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

 The development, testing and use of the associated analytical techniques for the
above.
 The development of the final pharmaceutical composition and manufacturing
processes for the medicinal product to be marketed including the making, disposal or
keeping or import of product batches in quantities sufficient to conduct the necessary
pre-clinical tests, clinical and bioavailability trials and stability studies of the
medicinal product and to validate the processes to the satisfaction of the competent
authorities.  The development, testing and use of the associated analytical
techniques for the above.
 The manufacture and supply to the competent authorities of samples of active
substances, their precursors, intermediates or impurities and of finished product
samples.  The compilation and submission of an MA or Variation application and
application for an MA.
(The acronym ―MA refers to marketing approval of a pharmaceutical product).
109. During end of 2012, the UKIPO consulted stakeholders on whether the Act should be changed
to include an exemption from patent infringement for activities involved in preparing or running
clinical or field trials which use innovative drugs. The changes became effective from 01.12.2014.
The new guidelines are extracted below:
 ―obtaining or varying an authorisation to sell or supply, or offer to sell or supply, a
medicinal product (whether in the United Kingdom or elsewhere);
 complying with any regulatory requirement imposed (whether in the United
Kingdom or elsewhere) in relation to such an authorisation  enabling a government
or public authority (whether in the United Kingdom or elsewhere), or a person
(whether in the United Kingdom or elsewhere) with functions of:
                   providing health care on behalf of such a
                    government or public authority, or
                   providing advice to, or on behalf of, such a
government or public authority about the provision of health care, to carry out an
assessment of suitability of a medicinal product for human use for the purpose of
determining whether to use it, or recommend its use, in the provision of health care.
110. Thus, the volume of the patented product and its use for research and development of
information cannot be prescribed by any one norm. Each case merits an analysis of the evidence, the
proof regarding the regulatory concerns is to be based on it. At the same time, this cannot be short
circuited by approaching and seeking relief under Article 226 of the Constitution. Bayers claim that
the court should have directed the authorities to seize or prohibit quantities of articles which Natco,
or someone else sought to export, is not based on any obligation cast upon Customs authorities, inBayer Corporation vs Union Of India & Ors. on 22 April, 2019

law. Further, even for the court to issue blanket directions of the kind, sought by Bayer, in its writ
petition, is not feasible, because whether such seizure or prohibition or labelling ought to be
mandatory, are aspects to be worked out, at the policy level, by the executive government, and not
upon the courts understanding. If Bayers claim were to succeed on this score, not only would the
court become a proactive institution in framing policy and evolving normative standards in respect
of spheres that have public repercussions, but would be exposed to the criticism that it would do so
at the interests of private parties; moreover the episodic nature of writ jurisdiction is such that at the
behest of a patent proprietor, sometimes even on its apprehension, the court would be in effect
legislating policy in the guise of interpretation of law. Equally, the direction given for permission to
export, in the course of writ proceedings, (in Natcos case of howsoever miniscule an amount of
API) was inappropriate.
111. The approach of the learned single judge in permitting export, without any inquiry and holding
that export of 1000 or 2000 tablets constituted reasonable use, in this case, cannot be
countenanced. In such case, upon the patent proprietor alleging the infringement was to institute
legal proceedings to injunct the alleged exporter or seller, it is equally possible for the seller or
exporter to seek a declaration or appropriate relief (including in a suit for groundless threat, if such
action lies) that its overseas sales are for research and purposes covered by Section 107A. This Court
is of the opinion that the inquiry and adjudication in such cases would be in regard to the following:
 (1)    The patent granted;
(2)    The nature of the product or elements sought to be exported;
(3)    The details of the party or party importing the product,
(4)    The quantity sought to be exported
(5)    Other particulars with respect to the end use of the product, to
establish that it is solely for research and development of information to regulatory authorities in
the other country;
(6) All particulars regarding the relevant regulations, covering the kind and scope of inquiry,
including the quantities of the product (i.e the patented product or compound, API or fine chemical
needed). These details must be supplied by the exporter/seller of the product to the overseas buyer.
In case the defendant is not the seller, it should disclose who had purchased the product in the
relevant quantities, to facilitate its impleadment in the proceedings. In the event it cannot do so, the
consequences of such result ought to be considered by the court.
(7) If the regulations are in the language of that country, an authentic English translation to
facilitate a speedy resolution; (8) Appropriate interim order, including undertaking by way of
affidavit to compensate the plaintiff, in the event the suit were to be decreed and the extent of such
monetary compensation. The affidavit should be of an authorized personnel, and kept alive during
the pendency of litigation, duly authenticated by the board of director or other controlling body of
the defendant- and whenever the company or entity undergoes amalgamation or transfer, suitable
undertaking from the successor organization;Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(9) If necessary, verification through the Indian mission (and its trade division) abroad regarding
the authentication of the third party and/ or its facilities abroad.
(10) If it is held by the court that the exporter is not involved in sale or export of any patented
product, but a generic article, unprotected by patent law, when denying relief, suitable restitutionary
relief should be awarded to the defendants in monetary terms, to preclude litigation that prevents
trade or competition.
The above aspects are only indicative of the matters that need examination, they are in no way
exhaustive and the court may consider any other matter relevant to the subject.
Postscript
112. The TRIPS Agreement (1994) mentions in Article 7, as an objective, the need to balance IP
rights:
―The protection and enforcement of intellectual property rights should contribute to
the promotion of technological innovation and to the transfer and dissemination of
technology, [...] in a manner conducive to a balance of rights and obligations.
113. The Doha Declaration- (i.e. the Declaration on the TRIPS Agreement and Public Health,
adopted on 14.11.2001) does not contain any express mention of such need to strive for balance. It,
however alludes, significantly the role necessary through ―balanced rules "thereby recognizing the
need for all people to benefit from the increased opportunities and welfare gains that intellectual
property - as part of the multilateral trading system - can generate. The 2005 Decision of the
General Council on the amendment of the TRIPS Agreement also impliedly flags the concern of
balancing humanitarian and development goals on the one hand, and right-holder interests, on the
other, in the public health field.
114. In the context of IP rights, the concept of balance was explained eloquently in the dissenting
opinion of Judge Kozinski in White v Samsung Electronics America, Inc. 989 F.2d 1512 (Ninth
Circuit, 1993) where he stated:
―intellectual property law is full of careful balances between what's set aside for the
owner and what's left in the public domain for the rest of us: The relatively short life
of patents; the longer, but finite, life of copyrights; copyright's idea expression
dichotomy; the fair use doctrine; the prohibition on copyrighting facts; the
compulsory license of television broadcasts and musical compositions; federal
preemption of overbroad state intellectual property laws; the nominative use doctrine
in trademark law; the right to make soundalike recordings. All of these diminish an
intellectual property owner's rights. All let the public use something created by
someone else. But all are necessary to maintain a free environment in which creative
genius can flourish.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

115. The history of the Bolar provision highlights that the interest in creativity and progress was not
to be undermined by the seemingly wide nature of patent rights; in the context of essential products
such as drugs, diagnostic aids, medical devices and other articles, the teachings in the patent
necessarily do not lead to its use by the public, upon their lapse to the public domain. To fulfill drug
acceptability standards prescribed by regulatory authorities, further tests are to be conducted. The
Roche v Bolar decision elicited immediate Congressional response and the Hutch Waxman Act was
enacted, in effect, nullifying that decision. TRIPS recognised the need for Bolar like research
provisions, enabling research and development in numerous ways which relieve those involved in
such activities, of the charge of patent infringement. Therefore, a constricted and narrow textual
interpretation of such provisions is not called for.
116. This court notes, furthermore, that as early as in 1946, the Constitution of the World Health
organization (WHO) recognized that the ―the enjoyment of the highest attainable standard of health
is one of the fundamental rights of every human being without distinction of race, religion, political
belief, economic or social condition. Later, the International Covenant on Economic, Social and
Cultural Rights, by Article 12 stated that:
―1. The States Parties to the present Covenant recognize the right of everyone to the
enjoyment of the highest attainable standard of physical and mental health.
2. The steps to be taken by the States Parties to the present Covenant to achieve the
full realization of this right shall include those necessary for:
(a)The provision for the reduction of the still birth rate and of infant mortality and
for the healthy development of the child;
(b) The improvement of all aspects of environmental and industrial hygiene;
(c) The prevention, treatment and control of epidemic, endemic, occupational and
other diseases;
(d) The creation of conditions which would assure to all medical service and medical
attention in the event of sickness..
117. This Court is of the opinion that it is necessary for national courts to be aware and cognizant of
these obligations, even while considering the assertion of property rights which it has to enforce. It
is here that the concerned national courts constitutional ethos and the values embodied in it also
need consideration: whether they can be given primacy or not is to be decided on a case to case, fact
dependent basis. Article 47 of the Indian Constitution obliges the State to ensure that the standards
of public health of all are ensured and maintained and policies are to be fashioned appropriately.
Article 21, which ensures the right to life and liberty, has been interpreted by our Supreme Court as
including certain guarantees to health care access. Given these paradigms, an interpretation that
furthers the objectives of Section 107A (and the previous research enabling existing in the Patents
Act, i.e. Section 47) and Article 30 of TRIPS is to be preferred. This court has added these as aBayer Corporation vs Union Of India & Ors. on 22 April, 2019

postscript- rather than in the main body of its findings,- inasmuch as these aspects too need to be
discussed appropriately, in the context of patent infringement claims, which generally tend to be
confined in the "silo" of assertion and negation of private rights and their enforcement, despite (at
times) larger implications to the general public in terms of outcomes.
Conclusions "Each generation stands on the shoulders of those who have gone before them, just as I
did as a young PhD student in Cambridge, inspired by the work of Isaac Newton, James Clerk
Maxwell and Albert Einstein. Stephen Hawking
118. The Bolar exemption is the global communitys thought out design to ensure that the enclosure
of intellectual property rights, granted to inventions, does not last beyond the term assured and that
the general public is afforded with the end of the bargain which every society guarantees while
sealing a patent i.e. access to the technology or invention for generations to come. But for a Bolar
exemption, a third party manufacturer would not be able to start experimentation and ready a
product, for its availability to the general public after the expiry of the patent term.
119. In the light of the above discussion and findings, it is held and directed as follows:
(a) Sale, use, construction of patented products (by individuals and entities that do
not hold patents) in terms of Section 107A of the Act for purposes both within the
country and abroad is authorized and legal provided the seller ensures that the end
use and purpose of sale/export is reasonably related to research and development of
information in compliance with regulations or laws of India (or the importing
country), for its submission in accordance with such laws. The impugned judgment of
the learned single judge and the findings recorded on this aspect are accordingly
affirmed.
(b) A dispute about the sale, i.e. whether it is legitimately related to the reasonable
end use or purpose of research etc. for submission of information is properly the
subject matter of a civil suit in which the full range of reliefs available in law can be
granted having regard to the circumstances and the evidence led;
(c) The court trying the suit would suitably take into account the factors that need to
be examined (which are elaborated in the previous part of this judgment) and other
relevant factors;
(d) Such disputes are not ordinarily the subject of public law proceedings, as they
involve investigation into facts and also result in reliefs to private parties for
enforcement of private property entitlements. Therefore, such disputes should not be
the subject matter of writ proceedings; petitions under Article 226 of the Constitution
of India should not be entertained and wherever filed, the parties should be relegated
to civil remedies.Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

(e) CS(OS) No.1090/2011- subsequently renumbered as CS(Comm) 33/2017
(Bayers suit against Natco) is pending. Issues were framed in the said suit, on
09.01.2017. In these circumstances, no separate orders are called for.
(f) CS(OS) (Comm) 1592/2016 filed by Bayer against Alembic is restored to the file of
this Court. The concerned learned single judge would proceed to try it.
(g) Both the above suits shall be decided in accordance with law, keeping in mind the
discussion in this judgment and the factors indicated above.
120. For the above reasons, the letters patent appeal has to fail; LPA 359/2017 is dismissed, subject
to the observations in this judgment. RFA(OS)(Comm) 6/2017 is for the reasons indicated above
and subject to the directions, allowed. In the peculiar circumstances of the case, there shall be no
order on costs.
S. RAVINDRA BHAT (JUDGE) SANJEEV SACHDEVA (JUDGE) APRIL 22, 2019Bayer Corporation vs Union Of India & Ors. on 22 April, 2019

