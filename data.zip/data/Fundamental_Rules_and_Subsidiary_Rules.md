Fundamental Rules and Subsidiary Rules
ASSAM
India
Fundamental Rules and Subsidiary Rules
Rule FUNDAMENTAL-RULES-AND-SUBSIDIARY-RULES of 1940
Published on 1 January 1940• 
Commenced on 1 January 1940• 
[This is the version of this document from 1 January 1940.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Fundamental Rules and Subsidiary RulesLast Updated 12th February, 2020Section IExtracts from
the Government of India Act, 1935Section IIFundamental Rules and Subsidiary Rules (Applicable to
Members of Services Under the Rule-Making Control of the Provincial GovernmentFundamental
Rules[Made by the Governor of Assam under Section 241 (2) (b) of the Government of India Act,
1935 and amended by that authority from time to time]
Part I – Chapter I
Extent of ApplicationF.R.1. These rules may be called the Fundamental Rules. They shall come into
force with effect from the 1st January, 1940.Note. The statutory rules framed by Government have
effect from the date on which they are passed subject to any special provisions as to the date of effect
in the rules themselves. A sanction accorded by Government, in the absence of any indication to the
contrary in the order itself, lapses if and when it is superseded by an order of a latter date.F.R.2. (1)
The Fundamental Rules apply to all Government servants whose pay is debitable to civil estimates of
Assam. No rules modifying or replacing any of the Fundamental Rules shall adversely affect any
person who is in Government service at the time when these rules come into force except under the
direction of the authority competent or empowered to make such a rule under paragraph (a) of
sub-section. (3) of Section 241 of the Government of India, 1935.(2)Where the application of any
rule in the Fundamental Rules is expressly or by implication limited by the provisions of any section
of the Act or by any rule made thereunder, the limitation shall prevail and the rule in the
Fundamental Rules shall be subject to such section or rule.Secretary of State's Order. - In exercise of
the powers conferred by paragraph (a) of sub-section (3) of Section 241 of the Government of India
Act, 1935, the Secretary of State hereby authorises the Governor in the case of persons serving in
connection with the affairs of a State to give the directions referred to in the said paragraph, so
however, that in giving any such direction, the Governor shall exercise his individual
judgement.[Government of India, Finance Department, Notification No. F.l (12)-Ex. 1/37, dated the
17th February, 1938].F.R.3. [Deleted].F.R.4. [Deleted].F.R.5. [Deleted].F.R.5A. The State
Government may relax the provisions of rules or orders so made by it in such manner as may appearFundamental Rules and Subsidiary Rules

to it to be just and equitable :Provided that where any such rule or order is applicable to the case of
any person, the case shall not be dealt with in any manner less favourable to him than that provided
by the rule or order.F.R.6. The State Government may delegate any of it powers to any of its officers
subject to any conditions which it may think fit to impose and to such extent as may be required for
the convenient and efficient despatch of public business.S.R.1. - The powers delegated by the
Government of Assam under the different Fundamental Rules are detailed in Appendix 1.The
delegations made in this rule as well as in Subsidiary Rule 4 (3) are subject to the condition that a
power may be exercised by an authority to whom it has been delegated in respect of those
Government servants only who are under control of that authority :Provided that nothing contained
in Appendices 1 and 4 shall operate to restrict the powers conferred upon such authority by any
other rules framed under the Act.F.R.7. No power may be exercised or delegated under these rules
except after consultation with the Finance Department. It shall be open to that Department to
prescribe, by general of special order, cases in which its assent may be presumed to have been given
and to require that its opinion on any matter on which it has been consulted shall be submitted by
the departments concerned for the orders of the State Government.S.R.2. - The assent of the
Finance Department may be presumed to the exercised of any of the powers mentioned in Appendix
2 to the extent therein stated.F.R.8. The powers of interpreting these rules is reserved to the State
Government.Note. A Government servant's claim to pay and allowances is regulated by the rules in
force at the time in respect of which the pay and allowances are earned; and to leave by the rules in
force at the time the leave is applied for and granted.The expression "claim to leave" includes the
earning of the leave, the method of calculation, the admissibility of the leave and its grant. The leave
account must be revised as soon as a rule regulating the method of calculation is amended, and
subsequent leaves granted according to the amended leave account.
Chapter II
Definitions
F.R.9. Unless there be something repugnant in the subject or context the terms defined in this
Chapter are used in the rules in the sense here explained ;F.R.9. (1) The "Act" means the
Government of India, Act, 1935.F.R.9. (2) "Average Pay" means the average monthly pay earned
during the 12 complete months immediately preceding the month in which the event occurs which
necessitates the calculation of average pay :Provided that in respect of any period spent of
deputation out of India which has been declared by the Governor to be under quasi-European
conditions the pay which the Government servant would have drawn if on duty in India shall be
substituted for the pay actually drawn.Note. In the case of Government servants who are not
deputed out of India of special items of work but are placed on continuous service with commission
and committees whose functions require work both in and out of India, the reference to the "pay
which the Government servant would have drawn if on duty in India" should be interpreted as a
reference to the pay which he would have drawn in India had he continued on duty with the
commission or committee there.Audit Instruction. - (1) According to the definition of 'average pay'
in this rule the average is to be taken of the monthly pay earned during the 12 complete months
immediately preceding the month in which the leave is taken, and for this purpose "the 12 complete
months immediately preceding" should be interpreted literally. Thus, a Government servant whoFundamental Rules and Subsidiary Rules

has been on leave from 23rd March, 1922 to 22nd July, 1922 inclusive is granted leave from 4th
February, 1923, his average pay should be calculated on the pay earned for the periods 1st February,
1922 to 22nd March, 1922 and 23rd July, 1922 to 31st January, 1923. If, however, a Government
servant happens to have been on leave for more than 12 months immediately preceding the month
in which the leave is taken then the average should be taken of the monthly pay earned during the 12
complete months immediately preceding the month in respect of which the previous leave
commenced.Note 1. In the case of a Government servant on foreign service out of India lasting for
more than 12 months who, on reversion to British service, immediately takes leave under the
Fundamental Rules, the calculation of average pay in respect of leave earned while in Government
service should be based on the pay drawn by him during the 12 complete months preceding the
month in which he was transferred to foreign service.Note 2. Any period of joining time taken either
under Clause (b) or under Clause (c) of F.R. 105 during the preceding 12 months should be ignored
in calculating average pay, as no "pay" is drawn in respect of such joining time.Audit Instruction. -
(2) The term "month" in these rules means "calendar month" as in F.R.9 (18).Audit Instruction. - (3)
In the case of a Government servant of a Vacation Department, the vacation falling in the period of
12 complete months immediately preceding the month in which leave is taken should be treated as
duty under F.R. 82 (b), and the pay drawn by the Government servant during the vacations should
be treated as pay drawn on duty and should, therefore, be taken into account in determining his
leave salary during the succeeding leave.Audit Instruction. - (4) In the case of a Government servant
of a Vacation Department both prefixing and affixing leave to a vacation, the leave-salary for the
leave affixed should be calculated on the pay drawn by the Government servant during the twelve
complete months preceding the commencement of his leave.F.R.9 (3) "Barrister" means a practising
barrister of England or Ireland, and a practising member of the Faculty of Advocates of the Court of
Session of Scotland. It does not include a person who, though called to the Bar, has never practised
the profession of barrister.F.R.9 (4) "Cadre" means the strength of a service or a part of a service
sanctioned as a separate unit.F.R.9 (5) "Compensatory allowance" means an allowance granted to
meet personal expenditure necessitated by the special circumstances in which duty is performed. It
includes a travelling allowance, but does not include a sumptuary allowance nor the grant of a free
passage by sea to or from any place outside India.Note. In view of the importance attached to the
correct classification of additions to pay such as special pay and compensatory allowance, it can be
accepted as a general principle that the reasons for the grant of such additions to pay should be
briefly recorded in the letter or memorandum conveying the sanction. In cases, however, in which
an official record in an open letter may be undesirable, it should be possible to communicate the
reasons confidentially to the audit authority.Audit Instruction. - (5) The allowances granted to
Professors of Medical Colleges who are denied the privilege of private practice should be treated as
compensatory allowances.F.R.9 (6) "Duty" - (a) Duty includes-(i)Service as a probationer or
apprentice ; provided that such service is followed by confirmation.Note. The service of probationer
in State and Subordinate Services and in special posts sanctioned by the Government of Assam
counts as duty for increments under F.R. 26 (a) before confirmation, if the scale of pay fixed for a
particular service or post provides for the grant of increments during the probationary period. The
service of persons appointed on probation to post with incremental scales of pay in which there is no
stage for probationary period also counts as duty for increments.(ii)Joining time.Note. Joining time
under Clause (b) or (c) of F.R. 105 on return from extraordinary leave counts as "Duty" although
under F.R. 107 (b) (i) the Government servant may not be entitled to any payment at all during suchFundamental Rules and Subsidiary Rules

joining time; but see Audit Instruction (5) below F.R. 26.(iii)Extra leave on average for three weeks
granted to a Government servant undergoing anti-rabic treatment.(b)The State Government may
issue orders declaring that, in circumstances similar to those mentioned below, a Government
servant may be treated as on duty-(i)during a course of instruction or training;(ii)in the case of a
student, stipendiary or otherwise, who is entitled to be appointed to the service of Government on
passing, through a course of training at a University, College or School, the interval between the
satisfactory completion of the course and his assumption of duties;(iii)during preparation for an
examination in any oriental language.(iv)[Deleted.]S.R.3 (1) - A Government servant, who has been
substantively appointed to a post or to a cadre in Government service or officiating in a temporary
or permanent post shall be treated on duty during any course of instruction or training which he
may be required or permitted to undergo in accordance with the terms of any general or special
orders of Government and during the time reasonably required for the journeys to and from the
place of instruction or training.Note 1. In estimating the "time reasonably required for the journey"
the head of the office or the controlling authority as defined in Appendix 30 of the Subsidiary Rules,
may, when necessary, allow the time for preparation up to a limit for six days but should not
ordinarily do so in cases when the course of instruction lasts for less than six months. If the course
of instruction lasts for less than six months but more than one month, time for preparation up to a
limit for three days may, in exceptional circumstances, be allowed.Note 2. Police Officers deputed to
the State Finger Print Bureau for a course of training will be treated as being on duty during the
period of training and so will newly appointed Sub-Inspector of the Police (Cadets) while under
training in a Police Training School or College.Note 3. In the case of Government servants who join
the Army in India Reserve of Officers the time spent on training will count as duty under F.R.9 (6)
(b).Note 4. Officers of the Education Department deputed by the Director of Public Instruction to a
Scouter's or Guide Training Camp/Red Cross Training Camp, vallies jamborees, etc. will be treated
as on duty during the period of training.Note 5. When an officer attends departmental examination
immediately after completion of training and returns to his old post he will be entitled to a
reasonable time required for the journey under S.R. 3 (1).Note 6. When an officer is transferred to a
post other than the post from which he proceeded on training immediately after completion of the
training he will be entitled to a reasonable time required for the journey from place of training to his
former post under S. R. 3 (1) and then will be entitled to his joining time under F.R. 105 for the
journey from the place of his former post to that of his new one.Note 7. When an officer is
transferred to a post other than his old post after attending the departmental examination in
continuation of his survey and Settlement Training he will be entitled to his joining time as in the
case of Note 6 above.Note 8. (1) Government servants deputed to the Survey and Settlement
Training at Jhalukbari or any other place as the State Government may decide will be treated as on
duty during the period of training.(2)A student, stipendiary or otherwise, who is entitled to be
appointed to Government service on passing through a course of training at a University, College or
School, shall unless in any case it be otherwise expressly provided in the terms of his appointment,
be treated as on duty during the interval between the satisfactory completion of the course and his
assumption of duty.(3)The period of training or probation of State Forest Service Officers and
Rangers shall count towards leave and pension ; provided that no period so passed before an officer
has completed 23 years of age shall count.(4)(a)A Government servant shall be treated as on duty
during any period, which he is permitted to spend in preparation for an examination of any of the
following kinds in an oriental language :(i)An optional examination by the high proficiency orFundamental Rules and Subsidiary Rules

degree of honours test in any vernacular language ;(ii)An optional examination by the higher
standard or high proficiency test in Sanskrit, Arabic or Persian ;(iii)An optional examination by the
degree of honours test in Sanskrit, Arabic or Persian.(b)The period to be spent in preparation is
limited to six months in a case covered by sub-Clause (iii) of Clause (a) of this paragraph, and to
three months in other case.(c)Preparation shall not be permitted to count as duty more than once
under each of the sub-Clause (iii) of Clause (a) of this paragraph.(d)Period spent in preparation
under this paragraph may be combined with leave on average pay.(5)A Government servant
required to attend a departmental examination is on duty during a reasonable time required for the
journey to and from the place of examination and the day or days of the examination.Note. This rule
is intended to cover only departmental examinations, whether optional or compulsory, for
promotion within the normal scope of the Government servant's department or office.(6)When a
Government servant is treated as on duty under paragraph (1) or (3) above his right to draw during
such period any compensatory allowance attached to the post on which he holds a lien or a
permanent or temporary post against which he is officiating shall be governed, as though he were on
leave, by S.Rr. 118 and 119.(7)Government servants appointed in England who, on their first arrival
in India do not, before they report themselves at the seat of Government receive orders to take
charge of a specified post, shall be treated as on duty during the interval between the date of such
report and the date on which they take charge of their duties ; provided that the interval between
receipt of orders and the assumption of their duties shall not exceed the amount of joining time
which would be admissible to a Government servant entitled to joining time under F.R. 105
(a).F.R.9 (6-A). "Fee" means a recurring or non-recurring payment to a Government servant from a
source other than the Consolidated Fund of India or the Consolidated Fund of a State whether made
directly to the Government servant or indirectly through the intermediary of Government.F.R.9 (7).
"Foreign service" means in which a Government servant receives his substantive pay with sanction
of Government (a) from any source other than the revenue of the Federation of a (Province) or the
Railway Fund (when established); or (b) from a company working as a State Railway.F.R.9 (8)
[Deleted.]F.R.9 (9) "Honorarium" means a recurring or non-recurring payment granted to a
Government servant from the Consolidated Fund of India or the Consolidated Fund of a State as
remuneration for a special work of an intermittent or occasional character.F.R.9 (10) "Joining time"
means the time allowed to a Government servant in which to join a new post or to travel to or from a
station to which he is posted.F.R.9 (11) "Leave on average (or half or quarter average) pay" means
leave on leave-salary equal to average (or half or quarter average) pay, as regulated by Rr. 89 and
90.F.R.9 (12) "Leave salary" means the monthly amount paid by Government to a Government
servant on leave.F.R.9 (13) "Lien" means the title of a Government servant to hold substantively
either immediately (or on the termination of a period or periods of absence) a permanent post,
including a tenure post, to which he has been appointed substantively.Note. In the case of a
Government servant who holds no lien on any appointment except that which it is proposed to
abolish, the correct procedure in deciding the exact date from which the appointment is to be
abolished would be to defer the date of abolition up to the termination of such leave, as may be
granted.F.R.9 (14) "Local fund" means-(a)revenue administered by bodies which by law or rule
having the force of law come under the control of Government whether in regard to proceedings
generally or to specific matters, such as the sanctioning of their budget's sanction to the creation or
filling up of particular posts, or the enactment of leave, pension or similar rules ; and(b)the revenues
of any body which may be specially notified by the Government as such.F.R.9 (15) "ProvincialFundamental Rules and Subsidiary Rules

Government" means the Governor aided and advised by the Council of Ministers except in so far as
he is by or under the Act required to act in his discretion to exercise his individual judgement [S. 50
of the Act of 1935].F.R.9 (16) [Deleted.]F.R.9 (17) "Ministerial servant" means a Government servant
of a subordinate service whose duties are entirely clerical, and any other class of servants specially
defined as such by general or special order of the State Government.F.R.9 (18) "Month" means a
calendar month. In calculating a period expressed in terms of months and days, complete calendar
months, irrespective of the number of days in each should first be calculated and the odd number of
days calculated subsequently.Audit Instruction. - In calculating a period of 3 months and 20 days
from 25th January, 3 months should be taken as ending on 24th April, and 20 days on 14th May, In
the same way the period from 30th January to 2nd March should be reckoned as one month and 2
days because one month from 30th January ends on 18th February. A period of one month and 29
days commencing from the 1st January will expire, in an ordinary year (in which February is a
month of 28 days), on the last day of February, because a period of 29 days cannot obviously mean
to exceed a period of full calendar month and leave for two months from 1st January would end on
the last day of February. The same would be the case if February were a month of 29 days or if the
broken period were 28 days (in an ordinary year).F.R.9 (19) "Officiate" - A Government servant
officiates in a post when he performs the duties of a post on which another person holds a lien. The
(Provincial) Government may, if it thinks fit, appoint a Government servant to officiate in a vacant
post on which no other Government servant holds a lien.F.R.9 (20) "Overseas pay" means pay
granted to a Government servant in consideration of the fact that he is serving in a country other
than the country of his domicile.Rules regulating grant of overseas pay
1. Overseas pay at the rate or rates sanctioned for a particular service or post
may be drawn by an officer having at the date of his appointment to such
service or post his domicile elsewhere than in Asia :
Provided that no such officer shall be entitled to this concession who, prior to such appointment, has
for the purpose of his appointment to any office under the Government or of the conferment upon
him by the Government of any scholarship, emoluments or other privilege, claimed or been deemed
to be a native of India.
2. For the purposes of these rules, the domicile of a person shall be
determined in accordance with the provisions set out in the Schedule to
these rules. [For Schedule see "the Schedule referred to in F.R. 75-A"
inserted after F.R. 130 in Section II] :
Provided that a person who was born and has been educated exclusively in Asia and has not resided
out of Asia for a total period exceeding six months, shall be deemed to have his domicile in Asia.
3. No officer who after his appointment to a service or post acquires a new
domicile shall thereby lose his right to or become entitled to overseas pay.Fundamental Rules and Subsidiary Rules

4. If any question arises as to the domicile of any officer at the time of his
appointment the decision thereon of the (Provincial) Government shall be
final.
F.R.9 (21) (a) "Pay" means the amount drawn monthly by a Government servant as-(i)the pay, other
than special pay or pay granted in view of his personal qualifications, which has been sanctioned for
a post held by him substantively or in an officiating capacity, or to which he is entitled by reason of
his position in a cadre ; and(ii)overseas pay, technical pay, special pay and personal pay; and(iii)any
other emoluments which may be specially classed as pay by the State Government.Note 1. Judicial
pay and language pay shall be regarded as "pay" for all purposes.Note 2. In the case of a
piece-worker in the Assam Government Press when appointed to a post on a time-scale , "pay" shall
be deemed to be equivalent to one hundred and seventy-five times his hourly class rate.Audit
Instruction 1. - If language allowances are lump sum allowances, they will be dealt with under F.R.
46. If they are recurring payments, they will fall under the head "pay" under F.R. 9 (21) (a).Audit
Instruction 2. - If the allowances granted to medical officers in the medical charge of Railway
employees are paid from the revenue of the State, they be classified as "Special Pay" If they are paid
by Companies, they cannot be treated as "Special Pay" unless contribution is paid.(b)[Deleted.]F.R.9
(22) "Permanent post" means a post carrying a definite rate of pay sanctioned without limit of
time.F.R.9 (23) "Personal pay" means additional pay granted to a Government servant-(a)to save
him from a loss of substantive pay in respect of a permanent post other than a tenure post due to a
revision of pay or to any reduction of such substantive pay otherwise than as a disciplinary measure
; or(b)in exceptional circumstances, or other personal considerations.Note. All cases in which it is
proposed to grant personal pay under F.R.9 (23) (b) may be referred to the Government in the
Finance Department through Administrative Departments concerned. No case will be entertained
which is not of an entirely exceptional character and in submitting cases for the grant of personal
pay this should be carefully borne in mind.F.R. (24) "Presumptive pay of a post", when used with
reference to any particular Government servant, means the pay to which he would be entitled, if he
held the post substantively and were performing its duties, but it does not include special pay unless
the Government servant performs or discharges the work or responsibility, in consideration of
which the special pay was sanctioned.Audit Instruction. - The first part of the definition is intended
to facilitate the use of the term in relation to a Government servant who has been absent from a post
for sometime but still retains a lien on it.F.R.9 (24-A) "Revenue of the Federation and Revenues of
the Province." These expressions have the meanings assigned to them respectively in Section 136 of
the Act [vide also Note to Treasury Rule 2 (b)].F.R.9 (25) "Special pay" means an addition, of the
nature of pay, to the emoluments of a post or of a Government servant, granted in consideration
of-(a)the specially arduous nature of the duties ; or(b)a specific addition to the work or
responsibility ;(c)[Deleted.] [Vide Notification No. FEG. 23/68 Pt., dated 3rd December, 1968
effective from the same date].F.R.9 (26) [Deleted].F.R.9 (27) "Subsistence grant", means a monthly
grant made to a Government servant who is not in receipt of pay or leave salary.F.R.9 (28)
"Substantive pay" means the pay other than special pay, personal pay or emoluments classed as pay
by the Provincial Government under Rule 9 (21) (a) (iii), to which a Government servant is entitled
on account of a post to which he has been appointed substantively or by reason of his substantive
position in a cadre.Note. In the case of a piece worker in the Assam Government Press, when
appointed to a post on a time-scale, "substantive pay" shall be deemed to be equivalent to oneFundamental Rules and Subsidiary Rules

hundred and seventy-five times his hourly class rate.F.R.9 (29) "Technical pay" means pay granted
to a Government servant in consideration of the fact that he has received technical training in
Europe.F.R.9 (30) "Temporary post" means a post carrying a definite rate of pay sanctioned for a
limited time.Note. A temporary post can be held either substantively or in an officiating capacity. An
extension of a temporary post to cover the period of leave granted to its holder is expedient only
when the grant of leave involves no expense to Government but improper in the absence of this
condition.F.R.9 (30-A) "Tenure post" means a permanent post which an individual Government
servant may not hold for more than a limited period.Note. In case of doubt the State Government
will decide whether a particular post is or is not a tenure post.F.R.9 (31) (a) "Time-scale pay" means
pay which, subject to any conditions prescribed in these rules, rises by periodical increments from a
minimum to a maximum. It includes the class of pay hitherto known as progressive.(b)Time-scales
are said to be identical if the minimum, the maximum period of increment and the rate of increment
of the time-scales are identical.(c)A post is said to be on the same time-scale as another post on a
time-scale if the two time-scales are identical and the posts fall within a cadre, or a class in a cadre,
such cadre or class having been created in order to fill all posts involving duties of approximately the
same character or degree of responsibility, in a service of establishment or group of establishments ;
so that the pay of the holder of any particular post is determined by his position in the cadre or class
and not by the fact that he holds that post.F.R.9 (32) "Travelling allowance" means an allowance
granted to a Government servant to cover the expenses which the incurs in travelling in the interests
of the public service. It includes allowances grated for the maintenance of conveyances, houses and
tents.General DefinitionsS.R.4. - Unless there is something repugnant in the subject or context,
terms defined below are used in the sense here explained :(1)"Audit Officer" means such Audit
Officer as the Comptroller and Auditor General may, by general or special order, designate in each
case.Note. Accountant General, Assam, is the Audit Officer in Assam.(2)"Apprentice" means a
person deputed for training in a trade or business with a view to employment in Government
service, who draws pay at monthly rates from Government during such training but is not employed
or in or against a substantive vacancy in the cadre of a department.Audit Instruction. - The leave of
apprentices during the period of apprenticeship is governed by S.R.134 and on confirmation they
cannot count their apprentice period for leave as if it had been service rendered substantively in a
permanent post.(3)"Competent authority" in relation to the exercise of any power means the
Provincial Government, or any authority to which the power is delegated by or under these rules.
Appendix 4 gives a list of authorities who have been declared to be competent authorities under the
various Subsidiary Rules.(4)"Head of a Department" means any authority which the Provincial
Government may by order declare to be the Head of a Department for the purposes of these rules. A
list of the authorities who have been declared to be Heads of Departments is given in Appendix
5.(5)"Holiday" means (a) a holiday prescribed or notified by or under Section 25 of the Negotiable
Instruments Act, 1881 ; and (b)in relation to any particular office a day on which such office is
ordered by notification of Government in the official Gazette to be closed for the transaction of
Government business without reserve or qualification.(6)Class I Service. All gazetted posts on the
new time scales, the maximum of which is Rs. 1000 and above.Class II Service. All gazetted posts on
the new scales,the maximum of which is Rs. 700 and above, but does not exceed Rs. 999.Class III
Service. All other Services or posts, gazetted or non-gazetted, excepting those classified in Class IV
service.Class IV Service. All other posts in the new time scales, the maximum of which is Rs. 140 or
below.(7)"Probationer" means a Government servant employed on probation in or against aFundamental Rules and Subsidiary Rules

substantive vacancy in the cadre of a department.Audit Instruction. - (a) Term "probationer" does
not cover a Government servant who holds substantively a permanent post in a cadre and is
appointed "on probation" to another post.(b)No person appointed substantively to a permanent post
in a cadre is a probationer, unless definite conditions of probation have been attached to his
appointment, such as the condition that he must remain on probation pending the passing of certain
examinations.(c)The status of a probationer is to be considered as having the attributes of a
substantive status except the rules prescribe otherwise.
Part II – Chapter III
General Conditions of ServiceF.R.10. Except as provided by this rule, no person may be
substantively appointed to a permanent post in Government service without a medical certificate of
health. The (State) Government may make rules prescribing the form in which medical certificate
should be prepared, and the particular medical or other officers by whom they should be signed. It
may, in individual cases, dispense with the production of certificate, and may by general order
exempt any specified class of Government servant from the operation of this rule.Note. A medical
certificate of health should be obtained from all whenever appointments are made to temporary
posts which have been made sanctioned at least for a period of one year and whenever such
appointments are made without specifying a period. Such certificate may not be insisted upon when
the period is less than four months.Conditions of Age, Health and Medical CertificateS.R.5. - (i) A
medical certificate of fitness for Government service shall be in the following form :"I hereby certify
that I have examined A. B. a candidate for employment in the....... Department, and cannot discover
that...... has any disease (communicable or otherwise), constitutional weakness or bodily infirmity,
except...... I do not consider this a disqualification for employment in the office of.........Note. In the
case of non-gazetted officers the signature of the candidate, or if the candidate is illiterate, his left
thumb and finger impressions should be taken on the certificate in the presence of , and certified as
so taken by the Medical Officer who grants the certificate. These should afterwards be verified by the
Head of the Office with those in the Service Book.(ii)A candidate for employment may produce a
certificate in the above form signed by any Commissioned Medical Officer of Government or by any
Medical Officer-in-charge of a civil station ; provided that-(a)no person shall be confirmed in a
permanent post until he has produced a certificate in the above form signed by the officer in medical
charge of the district in Assam in which he ordinarily resides or has his headquarters.(b)in Shillong,
women candidates for Government service in Gazetted and non-Gazetted appointments shall be
examined by the Medical Superintendent, Ganesh Das Women and Children Hospital, Shillong, for
all purposes when the Medical Examination is to be done by a single Medical Officer. In the mofussil
such examination shall be done by the Civil Surgeons of the Districts concerned or by the Women
Medical Officers where they are appointed and the certificate granted by the latter shall be
countersigned by the Civil Surgeons of the Districts concerned.(iii)When a woman candidate is to be
examined by the Medical Board in Shillong, the Medical Superintendent, Ganesh Das Women and
Children Hospital, Shillong, shall be one of the members of the Shillong Standing Medical Board. In
Dibrugarh, where also meetings of the Dibrugarh Standing Medical Board are held, action to include
a Woman Medical Officer Honorary or otherwise for the purpose of medical examination of women
candidates referred to it, shall be taken if she is available ; and(c)in the case of a post on pay no
exceeding fifty rupees, the appointing authority may accept a certificate signed by any GovernmentFundamental Rules and Subsidiary Rules

Medical Officer.S.R.6. - Except as otherwise provided by rules governing recruitment to particular
service a person whose age exceeds twenty-five years on the 1st January of the year in which the
recruitment is made may not ordinarily be admitted into service of the State in superior pensionable
service without the sanction of Government in the Home Department, the Head of the Department
or the Commissioner of Divisions. The ordinary limit is extended to-(a)thirty years in the case of-(i)a
person appointed to Assam Civil Service from the Bar ;(ii)appointments to teaching posts in College
in the Assam Educational Service;(iii)appointments to teaching posts on non-technical subjects in
Engineering and Technical Institutions ; and(b)twenty-nine years in the case of appointment of
Medical graduates in the services of the State Government;(c)thirty-five years in respect of
candidates in employ in aided schools for appointments to Class II of Assam School Service ;
provided they are eligible for the same otherwise and have acquired necessary experience.Note. This
rule does not apply to the employment in civil capacities of reservists and pensioners of the Indian
Army.S.R.7. - The following classes of Government servants are exempted from the operation of F.R.
10-(a)All persons appointed to inferior service ;(b)All Government servants promoted from inferior
to superior service ;(c)The political jemadars and interpreters belonging to the hill tribes in the
North-Frontier Tracts;(d)Government servants appointed by the Secretary of State or the High
Commissioner for India;(e)Lower Primary School Pandits belonging to hill tribes in the Sadiya and
Balipara Frontier Tracts.S.R.8. - (a) In the case of a Government servant whose year of birth is
known, but not the exact date, the 1st July should be treated as the date of birth for the purpose of
determining the date on which the Government servant concerned should be held to have attained
the age of 55 years. Similarly, if only the month and year of birth is known, the 16th of the month is
taken to be the exact date of birth.(b)In the case of a Government servant whose date of birth is not
known the following principles should be observed in determining his age :(i)In the case of a person
who first entered military employ was subsequently employed in a Civil Department, his date of
birth for the purpose of his civil employment should be the date stated by him at the time of
attestation. Cases often arise in which the documents referring to the previous military service do
not give the definite date of birth but only the age stated at the time of attestation. In such cases, the
Government servant concerned should be assumed to have completed the stated age on the date of
attestation e.g., if an ex-soldier was enrolled on 1st January, 1910, and if on that date his age was
stated to be 18, his date of birth should be taken as 1st January, 1892 ;(ii)The method in paragraph
(i) above should also be followed in cases when a person enters civil employ without having
rendered any military service and is unable to give his date of birth but gives his
age.(c)Commissioner and Heads of Departments may alter the recorded date of birth in the case of
non-Gazetted servants ; provided they are satisfied after enquiry that the previous date was
incorrect.Note. The Head of the office should record the date of birth in the Service Book of a
non-Gazetted Government servant on his initial appointment with reference to the Matriculation or
equivalent certificate and shall also record a remark to this effect in the Service Book. In cases where
these are not available, the Head Office should verify the date with reference to the birth certificate
to be produced by the Government servant and record a note to that effect in the Service Book. In
the case of Gazetted Government servant, the verification should be made according to the above
procedure on his initial appointment by the Administrative Department concerned. They should
intimate the date of birth of the officer as verified to the Accountant General for incorporation of the
same in the History of Services of the Gazetted Governments servants.No alteration in the date of
birth of a Government servant should be allowed except in very rare cases where a manifest mistakeFundamental Rules and Subsidiary Rules

has been made. Such mistake should be rectified at the earliest opportunity in the course of : (1)
periodical re-attestation of the entries in the first page of service book and (2) preparation of the
annual detailed statement of a permanent establishment (Financial Rule Form No. 11) in which is
noted the date of incumbent's birth. In no case request for change in the date of birth of a
Government servant made on a date within three years of the date of his actual superannuation
should be entertained.The following criteria should be followed in Considering requests for change
in date of birth which are not time-barred. Such request should be supported by satisfactory
documentary evidence (such as the Matriculation or equivalent certificate or duly attested copy of
birth certificate) together with a satisfactory explanation of the circumstances in which the wrong
date came to be entered and statement on any previous attempts made to have the record amended.
It should also be examined whether the Government servant concerned would have been within the
age- limits prescribed for Government service at the time he entered service with reference to the
different date later claimed by him as the correct date. If he would not have been so eligible, it
should be examined whether the date actually accepted then was given by him bona fide and did not
give him some advantage in securing admission into service at that time, and the change proposed
later on is for bona fide reasons and not merely to gain some fresh advantage.F.R.11. Unless in any
case it would be otherwise distinctly provided the whole-time of a Government servant is at the
disposal of the Government which pays him, and he may be employed in any manner required by
proper authority without claim for additional remuneration whether the services required of him are
such as would ordinarily be remunerated from a local fund, from the funds of a body incorporated
or not, which is wholly or substantially owned or controlled by the Government or from the funds of
an Autonomous District Council.F.R.12. (a) Two or more Government servants cannot be appointed
substantively to the same permanent post at the same time.(b)A Government servant cannot be
appointed substantively, except as a temporary measure, to two or more permanent posts at the
same time.(c)A Government servant cannot be appointed substantively to a post on which another
Government servant is holding a lien.F.R.12A. Unless in any case it be otherwise provided in these
rules, a Government servant on substantive appointment to any permanent post acquires a lien on
that post and ceases to hold any lien previously acquired on any other post.F.R.13. Unless his lien is
suspended under Rule 14 or transferred under Rule 14-B, a Government servant holding
substantively a permanent post retains a lien on that post-(a)while performing the duties of that
post ;(b)while on foreign service, or holding a temporary post, or officiating in another
post;(c)during joining time on transfer to another post; unless he is transferred substantively to a
post on lower pay, in which case his lien is transferred to the new post from the date on which he is
relieved of his duties in the old post;(d)while on leave ; and(e)while under suspension.F.R.14. (a)
The State Government shall suspend the lien of a Government servant on a permanent post which
he holds substantively if he is appointed in a substantive capacity-(1)to a tenure post; or(2)[Deleted]
;(3)provisionally , to a post on which another Government servant would hold a lien had his lien not
been suspended under this rule.(b)The State Government may, at its opinion, suspend the lien of a
Government servant on a permanent post which he holds substantively if he is deputed out of India
or transferred to foreign service, or, in circumstances not covered by Clause (a) of this rule, is
transferred in an officiating capacity, to a post in another cadre, and if in any of these cases there is
reason to believe that he will remain absent from the post on which he holds a lien for a period of
not less than three years.(c)Notwithstanding anything contained in Clause (a) or (b) of this rule a
Government servant's lien on a tenure post may in no circumstances be suspended. If he isFundamental Rules and Subsidiary Rules

appointed substantively to another permanent post, his lien on the tenure post must be
terminated.(d)If a Government servant's lien on a post is suspended under Clause (a) or (b) of this
rule, the post may be filled substantively, and the Government servant appointed to hold it
substantively shall acquire a lien on it : provided that the arrangements shall be reserved as soon as
the suspended lien revives.Note 1. This clause shall also apply to a post in a selection grade of a
cadre.Note 2. When a post is filled substantively under this clause, the appointment will be termed a
provisional appointment; the Government servant appointed will hold a provisional lien on the post;
and that lien will be liable to suspension under Clause (a) but not under Clause (b) of the rule.Assam
Government's decision. - The operation of F.R. 14 should, with immediate effect, be restricted so as
to permit only on provisional substantive appointment against one post. Accordingly, the lien
acquired by a Government servant on his appointment on provisionally substantive capacity under
Clause (d) of F.R. 14, should not in future .be suspended if he is deputed out of India or is
transferred to a post of the nature specified in Clause (b) of that rule.(e)A Government servant's lien
which has been suspended under Clause (a) to this rule shall revive as soon as he ceases to hold a
lien on a post of the nature specified in sub-Clause (1) or (3) of that clause.(f)A Government
servant's lien which has been suspended under Clause (b) of this rule shall revive as he ceases to be
on deputation out of India or on foreign service or to hold a post in another cadre; provided that a
suspended lien shall not revive because the Government servant takes leave if there is reason to
believe that he will, on return from leave continue to be on deputation out of India or on foreign
service or to hold a post in another cadre and the total period of absence on duty will not fall short of
three years or that he will hold substantively a post of the nature specified in Clause (1) or (3) of
Clause (a).F.R.14A. (a) Government servant's lien on a post in no circumstances be terminated, even
with his consent, if the result will be to leave him without a lien or a suspended lien upon a
permanent post.(b)A Government servant's lien on a post shall stand terminated on his acquiring a
lien on a permanent post (whether under Central Government or State Government) outside the
cadre in which he is borne.Note. A candidate who is already in permanent Government service
should be appointed to officiate in the higher service or post until further orders. The passing of
such further orders terminating the appointment (and as a necessary consequence reverting the
candidate to his former post) in the event of the candidate's failure to pass the departmental
examination within the prescribed period, or if he is otherwise found unsuitable, will not attract the
provisions of Section 240 (3) of the Government of India Act, 1935. The question whether a
permanent Government servant on his appointment to a higher service or post on the results of a
competitive examination can be asked to surrender his right to lien on his previous and treated as
"probationer" like a raw recruit from outside has been considered and it has been held that a person
who has been confirmed in Government service cannot thereafter be appointed "on probation" as
such an appointment is repugnant to the whole concept of the Civil Service Regulations and to their
fundamental principles in that it is calculated to deprive him of his security of tenure. An agreement
by which an officer promoted to a higher service or post consents to forfeit his lien on the post
previously held by him and to be appointed "on probation" in the higher post, in so far it has the
effect of depriving him of the security of tenure is open to objection in that it offends against the
principle that where a statute confers a right on class of persons in the public interest, or persons of
that class can contract himself out of that right.(c)[Deleted].F.R.14B. Subject to the provisions of
Rule 15, the State Government may transfer to another permanent post in the same cadre the lien of
a Government servant who is not performing the duties of the post to which the lien relates, even ifFundamental Rules and Subsidiary Rules

that lien has been suspended.Office MemorandumSuspension of Lien under F.R. 14 (B). - The
undersigned is directed to say that as per provision in F.R. 14 (b) read with serial 2 of the Appendix
2 of Fundamental Rules and Subsidiary Rules lien of a Government servant can be suspended by the
concerned Department of the Government, if he is deputed out of or deputed on Foreign service or
transferred in an officiating capacity to a post borne in another cadre if in any of these cases there is
reason to believe that he will remain absent from his substantive post for a period of not less than
three years. Instances have, however, come to the notice of this department that even in cases where
the Government servants have remained absent from their substantive posts far beyond the
stipulated period of three years, their lien in their respective substantive posts has not been
suspended by the departments concerned with the result that a tendency has grown among most of
the Government servants thus deputed/ transferred to remain absent from their substantive posts
for an indefinite period to the detriment of the interest of the departments concerned and their
other colleagues serving in the parent cadre. With a view, therefore, to put a stop to such a tendency,
it has been decided that a lien of a Government servant in a case of such deputation/transfer where
there is reason to believe that he will be absent from his substantive post for more than three years
should invariably be suspended. It is added here that as per provision in F.R. 14 (b) the lien of a
Government servant thus suspended revives as soon as he reverts to his substantive post.F.R.15. (a)
The State Government may transfer a Government servant from one post to another ; provided that
except-(1)on account of inefficiency or misbehaviour, or(2)on his written request,a Government
servant shall not be transferred, substantively to, or except in a case covered by Rule 49, appointed
to officiate in a post carrying less pay than the pay of the permanent post on which he holds a lien or
would hold a lien had his lien not been suspended under Rule 14.(b)Nothing contained in Clause (a)
of this rule or in Clause (13) of Rule 9 shall operate to prevent the re-transfer of a Government
servant to the post on which he would hold a lien had it not been suspended in accordance with the
provisions of Clause (a) of Rule 14.Decision by the Government of Assam. - Permanent transfers
from a higher to a lower scale in anticipation of the abolition of a post are not transfers within the
meaning of F.R. 15.Government of India's decision. - A question having arisen as to whether the
reversal of permanent arrangement in consequence of any order passed by the appellate or
revisional authority, as the case may be, is barred by Fundamental Rule 15, it has been held with the
concurrence of the Auditor-General that if an officer having been dismissed or removed from
service, or reduced in rank, or superseded by another officer, has a right of appeal against the
penalty imposed on him and his appeal is allowed, and equally if there is an authority competent to
interfere in revision, with orders passed by the lower authorities imposing any of these penalties,
and that authority sets aside the orders imposing that penalty, the reversal of any permanent
arrangements made, in the meantime may be considered to be the automatic consequence of the
orders passed by the appellate or revisional authority, as the case may be, and the provisions of
Fundamental Rule 15, according to which a Government servant shall not be transferred
substantively to a post carrying less pay, except under the circumstances mentioned in that rule are
not attracted in such a case, in this connection attention is invited to the provisions of Rr. 59 and 61
of the Civil Services (Classification, Control and Appeal) Rules and the Government of India's
administrative instructions below Fundamental Rule 54 of the P. and T. Compilation of
Fundamental and Supplementary Rules, Volume I.Fundamental Rules and Subsidiary Rules

2. While the technical position is as stated above, there is no doubt that the
reversal of permanent arrangements made in the vacancies caused by the
dismissal, removal or reduction, etc., of Government servants, pending final
decisions on their cases, may cause considerable hardship to Government
servants to be reverted and also administrative inconvenience. The
undersigned, is therefore, directed to draw attention to the desirability of not
making permanent arrangements in such vacancies as far as possible while
an appeal or representation of an officer affected is pending or expected to
be submitted and until final decision thereon has been reached.
F.R.16. A Government servant may be required to subscribe to a provident fund, a family pension
fund, or other similar fund, in accordance with such rules as the Governor may by order
prescribe.F.R.17. (1) Subject to any exceptions specifically made in these rules and to the provision
of sub-Rule (2), an officer shall begin to draw the pay and allowances attached to his tenure of a post
with effect from the date when he assumes the duties of that post, and shall cease to draw them as
soon as he ceases to discharge duties :Provided that an officer who is absent from duty without any
authority shall not be entitled to any pay and allowances during the period of such absence.(2)The
date from which a person recruited overseas shall commence to draw pay on first appointment shall
be determined by the general or special orders of the State Government.Audit Instruction. - A
Government servant will begin to draw the pay and allowances attached to his tenture of a post with
effect from the date on which he assumes the duties of that post if the charge is transferred before
noon of that date. If the charge is transferred afternoon, he commences to draw them from the
following day. This rule does not, however, apply to cases in which it is the recognised practice to
pay a Government servant at a higher rate for more important duties performed during a part only
of a day.F.R.17A. Without prejudice to the provisions of Rr. 64 and 65 of the Assam Services
(Pension) Rules, 1969, a period of unauthorised absence-(1)in the case of employees working in
industrial establishments, during a strike which has been declared illegal under the provisions of the
Industrial Disputes Act, 1947 or any other law for the time being in force ;(2)in the case of other
employees as a result of acting in combination or in concerted manner such as during a strike
without any authority from or valid reason to the satisfaction of the State Government; and(3)in the
case of an individual employee, remaining absent unauthorisedly or deserting the post;shall be
deemed to cause an interruption or break in service of the employee, unless otherwise decided by
the State Government for the purposes of leave, travel concession, permanency, and eligibility for
appearing in departmental examinations for which a minimum period of continuous service is
required.Explanation. - For the purpose of this rule, "strike" includes a general, token, sympathetic
or any similar strike, and also a participation in bundh or in similar activities.This will take effect
from 22nd March, 1965.S.R.9. - (i) The pay of officers recruited overseas shall commence from the
date of disembarkation in India, subject to their proceedings to take up their duties without
avoidable delay.The term "without avoidable delay" refers only to delay on the part of the officer in
reporting himself for duty (either at the State Government's headquarters or at the actual place of
duty, as the case may be) and not to delay in actually taking up his duties thereafter.(ii)Personnel
recruited in the United Kingdom for service in Assam, who receive second-class passages to India onFundamental Rules and Subsidiary Rules

first appointment, will be entitled to pay from the date of embarkation from the United Kingdom for
India.Charge of OfficeS.R.10. - The headquarters of a Government servant shall be in such place as a
competent authority may prescribe. In the absence of special orders by such authority the
headquarters of a Government servant shall be the station where the records of his office are kept. A
list of places declared by Government to be headquarters of certain Government servants is given in
Appendix 6.S.R.11. - Unless for special reasons (which must be of a public nature) the authority
under whose order the transfer takes place permits or requires it to be made in any particular case
elsewhere, or otherwise, the charge of an office must be made over at its headquarters both the
relieving and the relieved officers being present. Where an authority subordinate to Government
permits or requires a transfers to be made elsewhere or otherwise, the special reasons shall be
recorded.S.R.12. - The condition imposed by the above rule that both relieving and the relieved
officers must be present is not enforced in the case of Government servants who are permitted to
combine vacation with leave under F.R. 82, or District and Sessions Judges.S.R.13. - The following
procedure should be followed in these cases :(a)When vacation is prefixed to leave, the outgoing
officer will report before leaving headquarters, or if for urgent reasons, the leave is granted during
vacation, as soon as it is granted that he makes, the officer will then take over charge at the end of
the vacation in the ordinary way.(b)When vacation is affixed to leave, the officer to be relieved will
make over charge in the ordinary way before the vacation, the incoming officer on return at the end
of the vacation taking over charge with effect from the beginning of the vacation.Leaving
JurisdictionS.R.14. - No Government servant (other than a police officer acting within his legal
powers or an Excise Officer acting under the orders of the District Officer) is entitled to pay or
allowances for any time he may spend beyond the limits of his charge without proper
authority.S.R.15. - (1) Departments of Government may sanction journeys in India for attending
conferences, meetings and committees by Hon'ble Ministers, Secretaries to Government, Heads of
Departments and other officers under the control of such Departments.(2)A Head of a Department
may authorise any Government servant under his administrative control to proceed on duty to any
part of British India or to any Indian State, or Foreign Settlement in India.(3)A list of general
sanctions accorded to enable certain Government servants to proceed outside their jurisdiction is
given in Appendix 7.S.R.16. - A Controlling Officer for the travelling allowance may allow any
Government servant subordinate to him to proceed on duty to any part of the territories of the
Government of Assam or to a District or Foreign State or Settlement adjoining the jurisdiction of the
Controlling Officer and to draw travelling allowance under Rule 153.S.R.17. - A Government servant
permitted by a competent authority to proceed to any place on duty beyond the limit of his charge
may take with him such establishment and records as are absolutely necessary for the efficient
discharge of his duties.F.R.18. Unless the Governor in view of the special circumstances of the case,
shall otherwise determine, after five years' continuous absence from duty, elsewhere than on foreign
service in India, whether with or without leave, a Government servant shall be removed from service
after following the procedure laid down in the Assam Services (Discipline and Appeal) Rules, 1964.
Part III – Chapter IV
PayF.R.19. The fixation of pay is within the competence of the State Government : Provided that,
except in the case of personal pay granted in the circumstances defined in R. 9 (23) (a), the pay of a
Government servant shall not be so increased as to exceed the pay sanctioned for his post withoutFundamental Rules and Subsidiary Rules

the sanction of an authority competent to create a post in the same cadre on a rate of pay equal to
his pay when increased.Note 1. It is not the intention of this rule that the State Government should
grant less pay than is permissible under F.Rr. 22 and 23.Note 2. Except is special cases retrospective
effect to increase of pay and allowance will not be given.F.R.20. When a Government servant is
treated as on duty under Rule 9 (6) (b), the State Government may at their option authorise
payment to him of the pay of his substantive appointment, or of any lower rate of pay which the
State Government may consider suitable. If the duty consists in a course of training or instruction
the pay admissible may, if the State Government so directs, be instead of either of the rates just
specified, the pay of any officiating appointment held by the officer at the time he was placed on
such duty, but this rate of pay shall not be allowed for a period longer than that for which the officer
would have held the officiating appointment had he not been placed upon a course.Audit
Instructions. - (1) A Government servant who is treated as on duty during a course of instruction or
training and who, at the time when he was placed on such duty, was drawing higher pay on account
of an officiating appointment may, on every occasion during the period of instruction or training
when he would have held that officiating appointment but for such instruction or training, be
allowed to draw pay equivalent to what he would have drawn had he been holding the officiating
appointment.(2)The expressions "the pay of the substantive appointment" and "the pay of any
officiating appointment" occurring in F.R.20 should be taken to mean "the pay which the
Government servant drew in the post which he held substantively" and "the pay which the
Government servant drew in the post in which he officiated" respectively. In neither case is there
any restriction on the kind of "pay" to be drawn and the expressions should therefor be held to
include special pay, if any, which the Government servant drew in the post which he held
substantively or in an officiating capacity.S.R.18. - The following rules will govern the pay of officers
who are declared to be on duty under F.R.9 (6) (b):(1)Full substantive pay may be given but in no
case as a matter of right to a teacher or inspecting officer of the Education Department in
Government employ deputed to a training institution. Full substantive pay will be allowed in the
case of officers of the Education Department deputed by the Director of Public Instruction to a
Scout's Guides Training Camp ;(2)Mandal or Patwaries who are deputed for training at the Survey
School will draw their grade pay during the period of training whether substitutes are taken or not
;(3)During the period of their deputation to undergo a course of training in or out of the State,
Assistant Surgeons and Sub-Assistant Surgeons of the Medical and Public Health Department will
draw their "time scale pay" or "the pay of their substantive appointment", as the case may be,
together with lodging allowances, at rates indicated below ; provided that Assistant Surgeons and
Sub-Assistant Surgeons who fail to qualify at the first attempt will, at any subsequent attempt, be
entitled to draw their 'time scale' or 'substantive pay' and travelling allowances only.Lodging
Allowances
Course of Training Assistant Surgeon Rs.Sub-Assistant
Surgeon Rs.
(i) Leprosy Training, Calcutta 50 30 per mensem
(ii) Post-graduate Course, Calcutta 50 30Ditto
(iii) School of Tropical Medicine, Calcutta 50 30Ditto
(iv) X-ray Course, Dehra Dun 50 30DittoFundamental Rules and Subsidiary Rules

(v) Malaria Course (India) 50 30Ditto
(vi) Pasture Institute, Shillong (when the course is for
morethan 15 days)50 30Ditto
(vii) Preliminary training at Calcutta in connection
withteaching appointment in the Berry-White Medical
School atDibrugarh50 30Ditto
(viii) Sanitation and Hygiene under the Assistant
Directors ofPublic Health, Assam, at their Divisional
Headquarters.Rural Health
Inspector Rs. 15 per
mensem
Note 1. Medical Officers who are deputed to attend the course at the Pasture Institute and who are
stationed at Shillong will not be entitled to lodging allowance if they occupy free quarters or draw
house rent allowance in lieu thereof.Note 2. The lodging allowance payable to Medical Officers
deputed for training under the British Empire Leprosy Relief Association, Calcutta should, in the
first instance, be paid by Government and then recovered in full from the Association;(4)Jail
warders who are deputed for training in drill and discipline at the police lines, Sylhet or Gauhati,
will draw their grade pay during the period of such training;(5)Government servants deputed to the
Survey and Settlement Training at Jhalukbari or any other place as the State Government decide
will draw pay under F.R. 20, dearness allowance as admissible under the rules and compensatory
allowance under S.R 3 (6);(6)All other cases should be referred to Government for orders.Note. An
officer when deputed for training in the Army in India Reserve Officer is allowed to draw any
compensatory allowance that may be attached to his substantive post.Time-Scale PayF.R.21. Rules
22 to 29 inclusive and Rule 31 apply to time-scales of pay generally. They do not, however, apply to
time-scale sanctioned by the State Government in so far as they are inconsistent with terms specially
so sanctioned for such time-scale.F.R.22. The initial substantive pay of a Government servant who is
appointed substantively to a post on a time-scale of a pay is regulated as follows :(a)If he holds a lien
on a permanent post other than a tenure post, or would hold a lien on such a post had his lien not
been suspended-(i)when appointment to the new post involves the assumption of duties or
responsibilities of greater importance (as interpreted for the purpose of Rule 30) than those
attaching to such permanent post, he will draw as initial pay the stage of the time-scale next above
his substantive pay in respect of the old post;(ii)when appointment to the new post does not involve
such assumption, he will draw as initial pay the stage of the time-scale when is equal to his
substantive pay in respect of the old post, or, if there is no such stage, the next below that pay, plus
personal pay equal to the difference, and in either case will continue to draw that pay until such time
as he would have received on and increment in the time-scale of the old post, or for the period after
which an increment is earned in the time-scale of the new post, whichever is less. But if the
minimum pay of the time-scale of the new post is higher than his substantive pay in respect of the
old post, he will draw that minimum as initial pay;(iii)when appointment to the new post is made on
his own request under Rule 15 (a) and the maximum pay in the time-scale of that post is less than
his substantive pay in respect of the old post he will draw that maximum as initial pay.(b)If the
conditions prescribed in Clause (a) are not fulfilled he will draw as initial pay the minimum of the
time- scale :Provided, both in cases covered by Clause (a) and in cases, other than cases of
re-employment after resignation or removal or dismissal from the public service, covered by Clause
(b), that if the either-(1)has previously held substantively or officiated in-(i)the same post, or(ii)aFundamental Rules and Subsidiary Rules

permanent or temporary post or the same time- scale, or(iii)a permanent post, other than a tenure
post on an identical time-scale, or temporary post on an identical time- scale, such post being on the
same time-scale as a permanent post; or(2)is appointed substantively to a tenure post on a
time-scale identical with that of another tenure post which he has previously held substantively or in
which he has previously officiated ;the initial pay shall not be less than the pay, other than special
pay, personal pay or emoluments classed as pay by the State Government under Rule 9 (21) (a) (iii)
which he drew on the last such occasion, and he shall count the period during which he drew that
pay on such last and any previous occasions for increment in the stage of the time-scale equivalent
to that pay.Note 1. If, however, the pay last drawn by the Government servant in temporary post has
been inflated by the grant of premature increments the pay which he would have drawn but for the
grant of those increments shall be taken for the purpose of this proviso to be the pay which he last
drew in the temporary post.Note 2. An officer in respect of whom one of the penalties included in
Classification Rule 49 (iii) was imposed will on re-promotion count previous service in the higher
grade under F.R. 22 unless the order of punishment or the order passed on appeal directs otherwise
; andAn order debarring an officer from counting his past service in the grade from which he is
reduced, if and when re-appointed to it, amounts to an order of reduction to a stage of that grade
lower than that admissible under F.R. 22 and does not, therefore, fall outside the scope of Rule 49 of
the Civil Services (Classification, Control and Appeal) Rules.Exception. - The condition in paragraph
(iii) of the first proviso that the temporary post should be on the same time-scale as a permanent
post shall not be enforced when a temporary post is (i) created by one Government or Department
for the purpose of work of the same nature as the ordinary work for which permanent posts exist in
a cadre under a different Government or Department ; and (ii) sanctioned on a time-scale identical
with the time scale applicable to the permanent post in the cadre under the different Government or
Department.Note 1. If the Government servant is entitled to overseas pay in the new post was not
drawing overseas pay in the old post, the overseas pay in the new post shall not be taken into
account in determining the stage in the time-scale of new post to which he is entitled under Clause
(a).Note 2. For the purposes of this rule sterling overseas pay shall be converted into rupees at the
official rate of exchange.Note 3. The reversion to the ordinary cadre of a service from a tenure post
included in that cadre or from a tenure or special post not included in it does not constitute
"substantive appointment to a post" for the purpose of F.R. 22.Note 4. In fixing the pay of a Military
pensioner on his entry into Civil Department the provisions of Article 148 of the Assam Pension
Manual should be followed.Audit Instructions. - (1) A time-scale may be of recent introduction,
whereas the cadre or class to which it is attached may have been in existence on a graded scale
before the time-scale came into force or it may be that one time-scale has taken the place of another.
If a Government servant has held substantively, or officiated in a post in the cadre or class prior to
the introduction of a new time-scale, and has drawn during the period salary or pay equal to a stage,
or intermediate between two stages, in the new time-scale then the initial pay in the new time-scale
may be fixed at the salary or pay last drawn and the period during which it was drawn may be
counted for increment in the same stage, or if the salary or pay was intermediate between two stages
in the lower stage of that time- scale.(2)The revised Rule 22 is applicable in cases in which the
occasion for fixation of pay arose on or after the date of effect of the revised rule i.e., the 18th March,
1930. In cases where the occasion arose the 18th March, 1930, but the question of fixation of pay is
taken up after that date the old Rule 22 should be applied.(3)When the next increment in the
time-scale of either the new or the old post falls due, the Government servant should draw the nextFundamental Rules and Subsidiary Rules

increment in the time-scale of the new post and forthwith lose the personal pay and all connection
with the time-scale of the old post. The personal pay is given to a Government servant only for the
purpose of initial pay and not at any subsequent stage in the new time-scale in which the
Government servant might draw less pay than he would have drawn had he remained in the old
time-scale.(4)For the purposes of F.Rr. 22 and 23, a temporary post on a certain rate of pay (fixed
on time-scale) which is converted into a permanent post on the same or different rates of pay is not
the "same post" as the permanent post even though the duties remain the same. In other words in
view of Fundamental Rule 9 (30) the temporary post is to be regarded as having ceased to exist and
to have been replaced by the permanent post. The incumbent of the temporary post is thus entitled
only to the pay of the permanent post if it is on a fixed rate of pay or to the minimum pay of the
time-scale of the post if it is on a time-scale unless his case is covered by the concession admissible
under provisos (1) (ii) and 1 (iii) to F.R.22.The provisions of Article 30 of the Assam Pension Manual
are not affected by the above decision.(5)The expression "If he holds a lien on a permanent post"
occurring in Clause (a) of Fundamental Rule 22 should be held to include the lien on a permanent
post to which a Government servant is appointed in a provisional substantive capacity under
Fundamental Rule 14 (d) and the expression "Substantive pay in respect of the old post" occurring
in that rule should be held to include his substantive pay in respect of that provisional substantive
appointment. Fundamental Rule 22 (a) should therefor be held to permit the substantive pay in
respect of a State substantive appointment being taken into account in determining his initial pay in
another post to which he is appointed. When the initial pay of a Government servant in a post is
thus fixed it will not be affected even if during the tenure of his appointment to that post the reverts
from his provisional appointment.State Government Memos Under F.R.22 Government of
AssamFinance Department General (Establishment) Branch
No. FEG. 11/59/5 dated the 12th March, 1960
Subject. - Recoveries from subsistence allowance.The undersigned is directed to state that at present
there is no comprehensive provision in any rules or orders issued by the Government of Assam for
the recovery of Government dues from the subsistence allowance granted to a Government servant
under suspension. The question of making such recoveries from the subsistence allowance has
accordingly been considered. The permissible deductions shall fall under the two
categories-(a)Compulsory deductions ;(b)Optional deductions.The Governor of Assam has been
pleased to decide that the recovery of the following deductions, which fall under category (a) above,
should be enforced from the subsistence allowance :(i)Income-tax and super-tax (provided the
employee's yearly income calculated with reference to subsistence allowance is taxable);(ii)House
rent and allied charges i.e, electricity, water, furniture, etc.,(iii)Re-payment of loans and advances
taken from Government at such rates as the head of the department deems it right to fix.
3. The deductions falling under category (b), which should not be made
except with the Government servant's written consent, are as under :
(a)Premium due on Postal Life Assurance Policies ;(b)Amounts due to Co-operative Stores and
Co-operative Credit Societies ;(c)Refund of advances taken from General Provident Fund.Fundamental Rules and Subsidiary Rules

4. It has further been decided that deductions of the following nature should
not be made from the subsistence allowance-
(i)Subscription to a General Provident Fund ;(ii)Amounts due on Court attachments ;(iii)Recovery
of loss to Government for which which a Government servant is responsible.
5. As regards recovery of over payments, there is no bar to effect the same
from the subsistence allowance, but the competent administrative authority
will exercise discretion to decide, whether the recovery should be held
wholly in abeyance during the period of suspension, or it should be effected
at full or reduced rate, depending on the circumstances of each case.
6. The above orders will be applicable in case of all Government servants
under the rule making control of the Governor of Assam.
Sd.There is no bar to effect recovery of over payments from the subsistence allowance, but the
recoveries should not ordinarily be made at a rate greater than one-third of the amount of the
subsistence allowance i.e., exclusive of dearness allowance, if any, admissible to the Government
servant under F.R. 53 (i) (ii) (a). [Notification No. FEG. 100/60/76, dated the 21st March,
1963].Government of AssamFinance Department General (Establishment) Branch
No. FEG. 23/66/Part/1/49 dated, Shillong, the 13th January, 1972
Office MemorandumSubject. - Revised scale, 1964-Appointment of Selection Grade Posts-Fixation
of pay therein.(1)The undersigned is directed to invite a reference to this department office
memorandum No. FEG.63/65/35, dated 31-1-1968, regarding the procedure to be followed in the
matter of fixation of pay of a Government servant on being given the Selection Grade. In the office
memorandum referred to, it is categorically stated that pay in such a case should be governed by
F.R. 22 (a) (ii) since such an appointment does not involve assumption of higher duties and
responsibilities.(2)It is, however, observed that all the departments have not applied the aforesaid
principle uniformity, as a result of which disparity has arisen. Hence it is reiterated once again that
grant of the selection grade does not imply promotion and that pay in such a case should be fixed in
accordance with the provisions laid down in F.R. 22 (a)(ii). It has, however, been decided by the
Government that in all past cases where the eligibility for their benefit occurred on or before
25-11-1971, fixation of pay under F.R. 22-C may be allowed.(3)The undersigned is further directed to
say that the number of selection grade posts in any service with effect from 25-11-1971 may be
calculated on the basis of the number of permanent posts plus the number of temporary posts which
have continued for more than five years except where specific provision has been made in the Assam
(Revision of Pay) Rules, 1964, in regard to any service. Administrative Departments/Heads of
Departments are requested to intimate the undersigned the number of selection grade posts
calculated on this basis within one month from the receipt of this circular.Government of
AssamFinance (Establishment) DepartmentNo.FEG/23/66/Part/193Dated, Shillong, the 30th
November, 1972Office MemorandumSubject. - Revised Scales, 1964-Appointment of SelectionFundamental Rules and Subsidiary Rules

Grade Posts, Fixation of pay therein.The Government have re-examined the case of Government
servants whose pay in the selection grade was wrongly fixed under F.R. 22-C and it has been decided
that it would be discriminatory to allow such Government servants to continue to enjoy undue
financial benefits. Government have, therefore, decided that in partial modification of Memo No.
23/66/Pt./1/49, dated 13-1-1972, the pay of such Government servants should be re-fixed notionally
under F.R.22 (a) (ii) with effect from the date of their getting the selection grade and they should be
allowed to draw only emoluments admissible to them on that basis with effect from 1-12-1972. The
Government have, however, been pleased to decide that in order to avoid undue hardship to such
Government servants, recovery of the excess emoluments drawn by them up to 31-12-1972 due to
wrong fixation of their pay under F.R. 22-C may be waived.Government of AssamFinance
Department (Establishment) BranchNo.FEG. 13/67/64Dated 13-7-1973From : Additional Secretary
to the Government of Assam, Finance Department.ToThe Accountant General,Assam,
Shillong.Subject - Amendment of F.R. 22-C.Sir,I am directed to invite a reference to this
Department D.O. No. FEG.13/67/50, dated 24-3-1972 and your reply thereon vide D.O. No. Co-ord.
30-1/70/71/1264, dated 9-6-1972. The entire issue was further re-examined by this Department and
it is decided that there is no necessity of amend the entire rule as contemplated in this Department
D.O. Letter referred to above.The difficulties as pointed out by you in your letter referred to above in
the matter of fixation of pay of those Government servants promoted/ appointed to a second higher
post within a period of 3 years cannot be given the benefit of F.R.22-C. In such cases, pay should be
regulated as per provision laid down in F.R. 22 (a) (i) if he is a substantive holder of the lower post.
Where , however, it is not possible to take recourse to F.R. 22 (a) (i), fixation of pay will have to be
done having recourse to F.R. 27 by the Finance Department.In a case where a Government servant
was allowed to officiate in a higher post for a short duration, such as, leave vacancy etc. his initial
pay on the first such occasion should be regulated as per provision laid down in F.R. 22-C. If,
however, he is subsequently reverted and again promoted to the same post on a a subsequent date,
pay should be regulated as per provision laid down in provisos 1-3, F.R. 22-C and the limit of 3 years
as incorporated in C.S. No. 215, F.R. 22-C will not operate. Cases occurring from 29-3-1965 to
17-2-1970 should be regulated as per orders contained in this Department letter No. FEG. 13/67/49,
dated 11-11-1971. It is, however, made clear that the intention of the Government is that the bar of 3
years should operate only where there are two distinct promotions/appointments within a period of
3 years irrespective of whether it is in the direct line of service or not.Additional Secretary to the
Governmentof AssamFinance Department.F.R.22A. The initial substantive pay of a Government
servant who is appointed substantively to a post on a time-scale of pay which has been reduced for
reasons other than a diminution in the duties or responsibilities attached to post thereon and who is
not entitled to draw pay on the time-scale as it stood prior to reduction, is regulated by R. 22 ;
provided, both in cases covered by Clause (a) of that rule and in cases other than those of
re-employment after resignation or removal or dismissal from the public service, covered by Clause
(b), that if he either-(1)has previously held substantively or officiated in-(i)the same post prior to
reduction of its time-scale ; or(ii)a permanent or temporary post of the same time- scale as the
unreduced time-scale of the post; or(iii)a permanent post other than a tenure post, or a temporary
post on a time-scale of pay identical with the unreduced time-scale of the post, such temporary post
being on the same time-scale as a permanent post; or(2)is appointed substantively to a tenure post
the time-scale of which has been reduced without diminution in the duties or responsibilities
attached to it and has previously held substantively or officiated in another tenure post on a time-Fundamental Rules and Subsidiary Rules

scale identical with the unreduced time-scale of the tenure post,then the initial pay shall not be less
than the pay, other than special pay, personal pay or emoluments classed as pay by the State
Government under R. 9 (21) (a) (iii), which he would have drawn under R.22 on the last such
occasion if the reduced time-scale of pay had been in force from the beginning and he shall count for
increments the period during which he would have drawn that pay on such last and any previous
occasions. AF.R.22B. Notwithstanding anything contained in this rule, the following provisions shall
govern the pay of a Government servant who is appointed as a probationer in another service or
cadre, and subsequently confirmed in that service or cadre:(a)during the period of probation he
shall draw pay at the minimum of the time-scale or at the probationary stages of the time-scale of
the service or post, as the case may be :Provided that if the presumptive pay of the permanent post,
other than a tenure post, on which he holds a lien or would hold a lien, had his lien not been
suspended, should at any time be greater than the pay fixed under this clause, he shall draw the
presumptive pay of the permanent post ;(b)on confirmation in the service or post after the expiry of
the period of probation, the pay of the Government servant shall be fixed in the time-scale of the
service or post in accordance with the provisions of Rule 22.(2)The provisions contained in sub-rule
(1) shall apply mutatis mutandis to cases of Government servants appointed on probation with
definite conditions against temporary post in another service or cadre where recruitment to
permanent post of such service or cadre is made as probationers, except that in such cases the
fixation of pay in the manner indicated in Clause (b) of sub-rule (1) shall be done under Rule 31 of
the rules immediately on the expiry of the period of probation and on regular officiating
appointment to a post, either permanent or temporary, in the service or cadre.(3)Notwithstanding
anything contained in these rules a Government servant appointed as an apprentice in another
service or cadre shall draw-(a)during the period of apprenticeship, the stipend or pay prescribed for
such period; provided that if the presumptive pay of the permanent post, other than a tenure post on
which he holds a lien or would hold a lien had his lien not been suspended should at any time be
greater than the stipend or pay fixed under this clause, he shall draw the presumptive pay of the
permanent post;(b)on satisfactory completion of the apprenticeship and regular appointment to a
post in the service or cadre, the pay as fixed in the time-scale of the service or post under R. 22 or 31
of these rules.This takes effect from 13th September, 1961.F.R.22C. (1) Notwithstanding anything
contained in these rules, where a Government servant holding a post in a substantive, temporary or
officiating capacity is promoted or appointed in a substantive, temporary or officiating capacity to
another post carrying duties and responsibilities of greater importance than those attaching to the
post held by him, his initial pay in the time-scale of the higher post shall be fixed at the stage next
above the pay notionally arrived at by increasing his pay in respect of the lower post by one
increment at the stage at which such pay has accrued :Provided that in all cases of promotion from
one Class I post to another Class I post, the pay in the higher scale should be fixed at the stage next
above the pay drawn in the lower scale irrespective of whether the lower post was held in a
substantive, officiating or temporary capacity:Provided further that the provisions of sub-Rule (2) of
F.R. 31 shall not be applicable in any case where the initial pay is fixed under this rule :Provided also
that where a Government servant has, immediately before his promotion or appointment to a higher
post, been drawing pay at the maximum of the time-scale of a lower post, his initial pay in the
time-scale of the higher post, shall be fixed at the stage next above the pay notionally arrived at by
increasing his pay in the lower post, by the amount of the rate of increment just before maximum of
the time-scale of the lower post:Provided further that if a Government servant either-(1)hasFundamental Rules and Subsidiary Rules

previously held substantively or officiated in-(i)the same post, or(ii)a permanent or temporary post
on the same time- scale, or(iii)a permanent post other than a tenure post, or a temporary post on an
identical time-scale, or(2)is appointed substantively to a tenure post on a time-scale identical with
that of another tenure post which he has previously held substantively or in which he has previously
officiated ;then proviso to F.R. 22 shall apply in the matter of the initial fixation of pay and counting
of previous service for increment.Explanation. - In this rule, the expression "Class I" has the
meaning assigned to it in the Resolution on the Report of Pay Commission, 1937, and the Assam
Service (Revision of Pay) Rules, 1975 with Schedule.(2)Notwithstanding anything contained in these
rules, the pay of a Government servant shall not be fixed under these rules twice within a period of
three years.State Government's decision. - Provisions of F.R. 22-C will not apply to cases of
Government servants appointed to higher post through the Assam Public Service Commission and
in whose case the Commission have made a specific recommendation regarding the pay to be
given.The intention behind the above provisions that in a case where the Assam Public Service
Commission recommended a specific rate of pay to be given to the Government servant, the person
concerned should be eligible for that rate of pay. If, on the contrary, the Commission recommended
that the pay should be fixed under the normal rules, then the pay may be fixed under F.R. 22-C
subject of course, to the condition that the post is higher than the post previously held by a
Government servant.In order to enable the Account/Audit Authorities to see that the pay has been
fixed in accordance with the above, the Governor is pleased to decide that in all cases of
appointment of Government servant to other posts through the Assam Public Service Commission
in the matter of pay, i.e., whether it is specific rate of pay or pay fixed "under the normal rule", as the
case may be, should invariably be indicated in the order or Notification appointing the Government
servant concerned to the post.The above procedure shall also apply in the case of recruitment
through Selection Committee.State Government Notification under F.R. 22C. - (1) Under this rule if
the question is as to how the pay of a person reverting from an ex-cadre post to an
identical/equivalent cadre post in the parent department is to be fixed, the answer would be if a
person goes to 'A' in this parent department to a post 'B' elsewhere and reverts to post 'C in his
parent department which post is higher than that in post 'A', but not higher than that of the post 'B',
the pay in the post 'C' should be fixed under the present rule, with reference to pay in post 'A', if the
pay so fixed is more advantageous to the pay fixed under the normal rules with reference to his pay
in post 'B'. [Refer to the Notification No. FEG. 27/65/41, dated the 6th May, 1967].(2)Government
have decided in partial modification of Government letter No. FEG. 14/67/54, dated 13th July, 1973
that the period of 3 years for the bar in respect of second and subsequent fixation of pay under F.R.
22-C as amended by Correction Slip No. 215 should be calculated from the date of issue of the said
amendment, i.e., 18th February, 1970 or thereafter. The cases of fixation which took place prior to
18th February, 1970 are excluded from the purview of this amendment. [Refer to FEG. 13/67/85,
dated 2nd February, 1977].F.R.23. The holder of a post, the pay of which changed, shall be treated as
if he were transferred to a new post on the new pay: provided that he may at his option retain his old
pay until the date on which he has earned his next or any subsequent increment on that old scale, or
until he vacates his post or ceases to draw pay on that time-scale. The option once exercised is
final.Audit Instructions. - (1) This rule applies to an officiating as well as to a substantive holder of a
post.(2)If the maximum pay of a post is altered with no change in the rate of increment and the
minimum, the initial pay of the holder of the post should be fixed under F.R. 22-B and not under
F.R. 22-A even though he may be holding the post substantively.(3)See also Audit Instruction (4)Fundamental Rules and Subsidiary Rules

below F.R.22.Interpretation. - The expression "subsequent increment on the old scale" in the
proviso to F.R. 23 should be held to include grade promotion in cases in which a time-scale of pay
have been substituted for a graded scale of pay.Note. When the pay of a post is reduced, the
incumbent thereof cannot be forced to accept the lower rate of pay or paid or discharged (with or
without compensation pension without first being given the opportunity of exercising his rights
under F.R. 23 (i) (in of being treated as if transferred to a new post on a new pay, and (ii) of
retaining at his option his old pay in the new post.F.R.24. An increment shall ordinarily be drawn as
a matter of course unless it is withheld. An increment may be withheld from a Government servant
by the State Government, or by any authority to whom the State Government may delegate this
power under Rule 6, if his conduct has not been good or his work has not been satisfactory. In
ordering the withholding of an increment, the withholding authority shall state the period for which
it is withheld and whether the postponement shall have the effect of postponing future
increments.Note. When the authority passing orders to withhold an increment fails to specify clearly
for what period the officer is to be deprived of his increment, the deprivation should be held to cease
on the expiry of the period during which the officer would have drawn the increment withheld and
shall not affect future increment.F.R.25. Where an efficiency bar is prescribed in a time- scale, the
increment next above the bar shall not be allowed to a Government servant without the specific
sanction of the authority empowered to withhold increments under Rule 24 or relevant disciplinary
rules applicable to the Government servant or any other authority whom the Governor may, by
general or special order, authorise in this behalf.Note. On each occasion on which an officer is
allowed to pass an efficiency bar which had previously been enforced against him, he should come
on to the time-scale at such stage as the authority competent to declare the bar removed may fix for
him subject of course to the pay admissible according to his length of service.Exception. - Inspectors
and Inspectresses of Schools are authorised to pass orders for crossing the efficiency bar of officers
of Class II of the Assam School Service : provided that cases of stoppage are reported to the Director
of Public Instruction.F.R.26. (a) All duty in a post on a time-scale counts for increments in that
time-scale:Provided that for the purpose of arriving at the date of next increment in that time-scale,
the total of such periods as do not count for increment in that time-scale shall be added to the
normal date of increment.Method of reckoning the date of increment under the amended rule and
old ruleAnnexure
Date of increment 23-4-1964
Extraordinary leave taken, which does not count for increment.
Day From To
3 29-5-64 31-3-64
6 15-7-64 20-7-64
9 7-10-64 15-10-64
4 18-12-64 21-12-64
3 26-1-65 28-1-65
4 16-3-65 19-3-65
29   
The 29 date of next increment according to old rules and amended rules will be as follows :
Old Rule Month DaysFundamental Rules and Subsidiary Rules

From 23-4-64 to 28-5-64 16
“ 1-6-64 “ 14-7-64 114
“ 21-7-64 “ 6-10-64 216
“ 16-10-64 “ 17-12-64 22
“ 22-12-64 “ 25-1-65 14
“ 29-1-65 “ 15-3-65 115
“ 20-3-65 “ 22-5-65 23
    1060
Date of increment 23-4-1965
Amended Rules :Date of last increment-23-4-64Date of next increment-23-4-65(but for taking
extraordinary leave)Total number of extraordinary leave-29 days.Date of next
increment-23-4-65+29 days-i.e, 22-5-65.(b)(i)Service in another post other than a post carrying less
pay referred to in clause (a) of Rule 15, whether in a substantive or officiating capacity, service on
deputation out of India and leave other than extraordinary leave shall count for increments in the
time-scale applicable to the post on which the Government servant holds a lien, as well as in the
time-scale applicable to the post or posts, if any, on which he would hold a lien had his lien not been
suspended.(ii)All leave other than extraordinary leave and the period of deputation out of India
shall count for increment in the time-scale applicable to a post in which a Government servant was
officiating at the time he proceeded on leave or deputation out of India and would have continued to
officiate but for his proceeding on leave or deputation out of India :Provided that the Governor may
in any case in which he is satisfied that the extraordinary leave was taken on account of illness or for
any other cause beyond the Government servant's control or for prosecuting higher scientific and
technical studies, direct that extraordinary leave shall be counted for increments under Clause (i) or
(ii).(c)If a Government servant while officiating in a post or holding a temporary post on a
time-scale of pay , is appointed to officiate in a higher post to hold a higher temporary post, his
officiating or temporary service in the higher post shall, if he is re-appointed to the lower post, or is
appointed or re-appointed to the post, on the same time-scale of pay, count for increments in the
time-scale to such lower post. The period of officiating service in the higher post which counts for
increments in the lower post is however, restricted to tire period during which the Government
servant would have officiated in the lower post but for his appointment to the higher post. This
clause applies also to a Government servant who is not actually officiating in the lower post at the
time of his appointment to the higher post, but who would have so officiated in such lower post on
the time-scale of pay had he not been appointed to the higher post.State Government's decision. - 1.
For the purpose of F.R. 26 (c), the officiating and temporary service in the higher post will also
include all leave and the period of deputation out of India, which counts for increments in that post
under Clauses (b) (ii) and (d) of this rule, provided it is certified by the appointing authority that the
Government servant concerned would have actually officiated in the lower post but for his
proceeding on leave or deputation out of India from the higher post.
2. Under Clause (c) of F.R. 26, a Government servant officiating in a post or
holding temporary post can count towards increments in the time-scale
applicable to such post, service rendered in an officiating or temporaryFundamental Rules and Subsidiary Rules

capacity in any higher post to which he may be appointed while officiating in
or holding the lower temporary post, provided he would have continued to
officiate in or holding such lower post but for his appointment to the higher
post.
As strictly speaking, the rule in the Fundamental Rules are not applicable when both posts are not
under the State Government in cases where a State Government servant while officiating in a post or
holding a temporary post under the State Government is appointed to officiate in higher post or to
hold a higher temporary post under the Central Government, the period of service in the higher post
under the Central Government cannot count for increment in the lower post under the State
Government unless recourse is had to F.R.27. After careful consideration, it has been decided that
the benefits of F.R.26 (c) may be extended to State Government servants officiating in higher posts
or holding higher temporary post under the Central Government also.(d)Foreign service counts for
increments in the time- scale applicable to-(i)the post in Government service on which the
Government servant concerned holds a lien as well as the post or posts, if any, on which he would
hold a lien had his lien not been suspended ;(ii)the post in Government service in which the
Government servant was officiating immediately before his transfer to foreign service, for so long as
he would have continued to officiate in that post or a post on the same time- scale but for his going
on a foreign service ; and(iii)any post to which he may receive officiating promotion under Rule 113
below for the duration of such promotion.(e)Joining time counts for increment-(i)if it is under
Clause (a) or Clause (d) of Rule 105, in the time-scale applicable to the post on which a Government
servant holds a lien or would hold a lien had his lien not been suspended as well as in the time-scale
applicable to the post, the pay of which is received by a Government servant during the period ;
and(ii)if it is under Clause (b) or Clause (c) of Rule 105, in the time-scale applicable to post/posts on
which the last day of leave before commencement of the joining time counts for
increments.Explanation. - For the purpose of this rule, the period treated as duty under sub-Clause
(b) of Clause (6) of Rule 9 shall be deemed to be duty in a post if the Government servant draws pay
of that post during such period.F.R.27. An authority may grant a premature increment to
Government servant on a time-scale of pay if it has power to create a post in the same cadre on the
same scale of pay.Note. In the case of increment granted in advance it is usually the intention that
the officer should be entitled to increments in the same manner as if he had reached his position in
the scale in the ordinary course and in the absence of special orders to the contrary he should be
placed on exactly the same footing as regards future increments of an officer as has so risen.F.R.28.
The authority which orders the transfer of a Government servant as a penalty from a higher to a
lower grade or post, he may allow him to draw any pay, not exceeding the maximum of the lower
grade or post, which it may think proper:Provided that the pay allowed to be drawn by a
Government servant under this rule shall not exceed the pay which he would have drawn by the
operation of Rule 22 read with Clause (b) or Clause (c), as the case may be, of Rule 26.F.R.29. (1) If a
Government servant is reduced as a measure of penalty to a lower stage in his time-scale, the
authority ordering such reduction shall state the period for which it shall be effective, and whether,
on restoration, the period of reduction shall operate to postpone future increments, and if so, to
what extent.(2)If a Government servant is reduced as a measure of penalty to a lower service, grade
or post or to a lower time-scale, the authority ordering the reduction may or may not specify theFundamental Rules and Subsidiary Rules

period for which the reduction shall be effective ; but where the period is specified, that authority
shall also state whether on restoration the period of reduction shall operate to postpone future
increments, and if so, to what extent.Note. Sub-rule (1) of the new rules covers cases of restoration
after a period of deduction to lower stage in time-scale, and sub-Rule (2) relates to cases of
restoration after a specified period of reduction to a lower grade or post. Under the new rule,
reduction to a lower stage in a time-scale can be ordered only for a specified period. Hence the
authority ordering such reduction is required to specify the period in the order of reduction.
Reduction to lower post or grade can be either for any specified period in which case the period has
to be indicated in order of reduction or for an unspecified or indefinite period. In the latter case on
re-appointment to the higher post or grade the pay of the Government servant will be regulated
under the normal rules and not under the F.R. 29.State Government's Interpretation of sub-Rule (1)
of F.R. 29. - (a) Every order passed by the competent authority imposing on a Government servant
the penalty of reduction to a lower stage in a time-scale should indicate-(i)the date for which it takes
effect and the period (in terms of years and months) for which the penalty shall be operative ;(ii)the
stage in the time-scale (in terms of rupees) to which the Government servant is reduced ; and(iii)the
extent (in terms of years and months), if any, to which the period referred to at (i) above should
operate to postpone future increments.It should be noted that reduction to a lower stage in a
time-scale is not permissible under the rule either for an unspecified or as permanent measure. Also
when a Government servant is reduced to a particular stage, his pay will remain constant at that
stage for the entire period of reduction. The period to be specified under (iii) should in no case
exceed the period specified under (i).(b)The question as to what should be the pay of a Government
servant on the expiry of the period of reduction should be decided as follows :(i)if the original order
of reduction lays down that the period of reduction shall not operate to postpone future increments
or is silent on this point, the Government servant should be allowed the pay which he would have
drawn in the normal course but for the reduction. If, however, the pay down by him immediately
before reduction was below the efficiency bar, he should not be allowed to cross the bar except in
accordance with the provision of F.R. 25 ;(ii)if the original order specifies that the period of
reduction was to operate to postpone future increments of any specified period, the pay of the
Government servant should be fixed in accordance with (i) above but after treating the period for
which the increments were to be postponed as not counting for increments.State Government's
Interpretation/clarification relating to sub-Rule (2) of F.R. 29. - 1. Under sub-Rule (2) of F.R. 29 if a
Government servant is reduced as a measure of penalty to a lower grade/post/service/time-scale,
the competent authority ordering the reduction should indicate in the order of reduction :(a)the
date from which the punishment takes effect. Where the reduction is intended for a particular
period, the same should be specified (in terms of years and months). On expiry of the specified
period of reduction, the Government servant concerned shall be automatically restored to his old
grade/post/service/time-scale.The reduction may also be for an unspecified or an indefinite period.
In cases where no period is specified in the order of penalty, it is to be construed that the penalty is
for an unspecified period ;(b)the extent (in terms of years and months), if any, to which the period
referred to in sub-Clause (a) above shall operate to postpone future increments on restoration, after
the specified period. The period to be specified under this sub- clause shall in no case exceed the
period specified under sub-Clause (a) above.Fundamental Rules and Subsidiary Rules

2. The pay of a Government servant, who is reduced to the lower
grade/post/service/time-scale, whether for a specified or unspecified period,
should be regulated in accordance with the provisions of F.R. 28 as amended
by Correction slip No. 183 [vide Notification No. FEG 58/60/Pt/40, dated
6-9-1962]. Once the pay is thus fixed in the lower
grade/post/service/time-scale, increments therein shall be regulated in
accordance with the provisions of normal rules unless such increments are
also withheld.
3. The pay of Government servant on restoration to the higher
grade/post/service/time-scale, in cases where the period of reduction is
specified, shall be regulated as follows :
(i)if it is laid down in the order of reduction that the period of reduction shall not operate to
postpone future increments, the Government servant shall be entitled to the pay which he would
have drawn but for his reduction to the lower grade/post/service/time-scale. If, however, the pay
drawn by him immediately before reduction was below the efficiency bar, he shall not be allowed to
cross the bar except in accordance with the provisions of F.R. 25 ;(ii)if it is laid down in the order of
reduction that the period of reduction shall operate to postpone future increments, for any specified
period which shall not exceed the period of reduction to the lower grade/post/service/time-scale,
the pay of the Government servant on restoration shall be fixed as in (i) above but after treating the
period for which increments are postponed as not counting towards increments.
4. In cases where the reduction to the lower grade/post/service/time-scale is
for an unspecified period if and when the Government servant is
re-appointed to the higher post in the normal course the pay in the higher
post will be regulated only in accordance with the normal rules relating to
pay fixation.
Under Secretary to the Governmentof Assam,Finance DepartmentMemo No. FEG 58/60/Pt/40,
dated the 6th September, 1962.F.R.29A. Where an order of penalty of withholding of increment of a
Government servant or his reduction to a lower service, grade or post, or to a lower time-scale, or to
a lower stage in a time-scale, is set aside or modified by competent authority on appeal or review,
the pay of the Government servant shall, notwithstanding anything contained in these rules, be
regulated in the following manner:(a)If the said order is set aside, he shall be given, for the period
such order has been in force, the difference between the pay to which he would have been entitled
had that order not been made and the pay he had actually drawn.(b)If the said order is modified, the
pay shall be regulated as if the order as so modified had been made, in the first
instance.Explanation. - If the pay drawn by a Government servant in respect of any period prior to
the issue of orders of the competent authority under this rule is revised, leave salary and allowances
(other than travelling allowance), if any, admissible to him during that period shall be revised on theFundamental Rules and Subsidiary Rules

basis of the revised pay.Audit Instruction. - A permanent post vacated by reduction of a Government
servant to a lower service, grade or post, or to a lower time-scale should not be filled substantively
until the expiry of a period of one year from the date of such reduction.Where, on expiry of the
period of one year, the permanent post is filled and the original incumbent of the post is reinstated
therefor, he should be accommodated against any post which may be substantively vacant in the
grade to which his previous substantive post belonged.If there is no such vacant post, he should be
accommodated against a supernumerally post which should be created in this grade with proper
sanction and with the stipulation that it should be terminated on the occurrence of the first
substantive vacancy in the grade.Pay of officiating Government servantF.R.30. (1) Subject to the
provisions of Chapter VI, a Government servant who is appointed to officiate in a post shall not
draw pay higher than his substantive pay in respect of a permanent, post, other than a tenure post,
unless the officiating appointment involves the assumption of duties and responsibilities of greater
importance than those attaching to the post other than a tenure post on which he holds a lien or
would hold a lien had his lien not been suspended :Provided that the State Government may exempt
from the operation of this rule any service which is not organised on a time-scale basis and in which
a system of acting promotion from grade to grade is in force at the time of the coming into force of
these rules :Provided further that the State Government may specify posts outside the ordinary line
of a service the holders of which may, notwithstanding the provisions of this rule and subject to such
conditions as the State Government may prescribe, be given any officiating promotion in the cadre
of the service which the authority competent to order promotion may decide, and may thereupon be
granted the same pay whether with or without any special pay attached to such post as they would
have received if still in the ordinary line.(2)For the purpose of this rule, the officiating appointment
shall not be deemed to involve the assumption of duties or responsibilities of greater importance if
the post to which it is made is on the same scale of pay as the permanent post other than a tenure
post, on which he holds a lien or would hold a lien had his lien not been suspended or on a scale of
pay identical therewith.Audit Instructions. - (i) It is not intended that the phrase "outside the
ordinary line of a service" in the second proviso to Clause (1) of F.R. 30 should be rigidly interpreted
either as "outside the cadre of a service" or as "outside the ordinary time-scale". The form of words
adopted allowed the Government to exercise their discretion in regard to cases where exceptional
circumstances which could not be foreseen and provided for by rule might arise.(ii)The specification
of a post under this proviso will enable a Government servant to count service in that post for
increment in the grade in which he would have officiated had he not been holding the specified
post.Note. The Government of Assam have exempted from the operation of F.R. 30, the Rangers and
Deputy Rangers whose service has been reorganised on a graded system of pay.F.R.31. (1) Subject to
the provisions of Rr. 30 and 35, a Government servant who is appointed to officiate in a post will
draw the presumptive pay of that post.(2)On an enhancement in the substantive pay, as a result of
increment or otherwise, the pay of such Government servant shall be refixed under sub-Rule (1)
from the date of such enhancement as if the was appointed to officiate in that post on that date
where such refixation is to his advantage.State Government's decision. - (1) A question has been
raised in regard to the manner in which the officiating pay is to be regulated in a case where an
increment in the substantive post falls due during a period of leave and refixation of officiating pay
is to the Government servant's advantage.It has been decided that in the case of a person proceeding
on leave, if the period of leave counts for increments in the officiating post either under F.R.26 (a) or
26 (b) subject to the fulfilment of the conditions and production of the necessary certificates, hisFundamental Rules and Subsidiary Rules

officiating pay may be refixed under F.R.31 (2) from the very date of increment or increase in the
substantive pay as if he was appointed to officiate in the post on that date. The benefit of the
increase in officiating pay can be had by him only from the date of resumption of duties but his next
increments in the officiating post will accrue to him from an earlier date in the next year calculated
with reference to the date of refixation of pay.If, however, the period of leave does not count for
increment in the officiating post the Government servant loses all connection with that post during
that period and he will be entitled to get his officiating pay refixed only from the date he returns
from leave in which case the next increment will fall due only after completion of the prescribed
period of duty from the date of resuming charge unless he becomes entitled to refixation of pay
under F.R. 31 (2) once again from an earlier date.(2)A doubt has been raised whether in the case of a
Government servant whose officiating pay on refixation under F.R. 31 (2) carries his pay above the
efficiency bar stage in the time-scale of the officiating post, the efficiency bar should be
applied.Since the refixation of officiating pay under F.R. 31 (2) is to be done in the same manner as
initial fixation of pay under F.R. 31 (1) it has been decided that in the type of cases mentioned above,
the Government servant concerned should be deemed to have automatically crossed the efficiency
bar at the time of refixation of officiating pay and the question of application of efficiency bar will
not arise.In the case of a Government servant officiating in a post and whose pay had been refixed
under F.R. 31 (2), if he is confirmed in that post from a retrospective date the refixation of pay done
under F.R. 31 (2) after the date of his confirmation will have to be revised and consequently over
payments, if any, will have to be recovered.Note. A Government servant while officiating in a higher
post took regular leave for short period and thus reverted to his substantive post in which, during
the leave, an increment accrued to him which raised his substantive pay so as to equal the pay he
was drawing in his officiating post. As under F.R. 31 officiating pay has to be fixed on each occasion
of appointment to a higher post, carrying greater responsibility the Government servant on
re-appoint to the higher post on return from leave was able to get the benefit of the next stage in the
time-scale of the post, which he would not have got had he continued to officiate without a break.
The automatic fixation in such cases of officiating pay at a rate higher than that drawn on a previous
occasion, which the rule allows, is not justifiable and that in these cases the powers conferred by
F.R. 67 or 35 could reasonably be exercised. For instance, if the competent authority feels that a
Government servant who in the normal course would continue to officiate in a higher post has
applied for short period of regular leave with the deliberate intention of getting the benefit of the
increment accruing to him in his substantive scale of pay during the leave for the fixation of his pay
in the officiating post on his re-appointment to it,it will be for the consideration of that authority
whether the leave applied for should not be refused under F.R.67. If, on the other hand, the effect of
leave on the Government servant's officiating pay on subsequent re-appointment to the higher post
is not realised at the time, or the competent authority is satisfied that the leave applied for is really
necessary, or even if a short break in officiating service occur in the natural course of events, the
power conferred by F.R.35 to reduce officiating pay may quite reasonably be exercised so as to limit
the officiating pay on re-appoint to the higher post to what the Government servant would have
drawn had he continued to officiate without a break.Audit Instructions. - (1) The pay of a
Government servant officiating in a post the pay of which is subject to increase upon the passing of
an examination or upon the completion of a certain period of service is the pay which he would from
time to time receive if he held the post substantively.(2)The pay of a Government servant officiating
in a post the pay of which has been reduced with effect from the next succession thereto is theFundamental Rules and Subsidiary Rules

reduced pay.F.R.31A. Notwithstanding the provisions contained in these rules the pay of a
Government servant, whose promotion or appointment to a post is found to be or to have been
erroneous, shall be regulated in accordance with any general or special orders issued by the
Governor in this behalf.F.R.32. [Deleted]F.R.33. When a Government servant officiates in a post the
pay of which have been fixed at a rate personal to another Government servant, the State
Government may permit him to draw pay at any rate not exceeding the rate so fixed or, if the rate so
fixed be a time-scale, may grant him initial pay not exceeding the lowest stage of that time-scale and
future increments not exceeding those of the sanctioned scale.Audit Instruction. - If a Government
servant, who is personally qualified to draw overseas pay, is appointed to officiate in a post on a
time-scale, the pay of which is fixed personally for the substantive holder of the post and includes
sterling overseas pay, "the lowest stage in time-scale" for the purposes of Fundamental Rule 33 is
the minimum of the time-scale, plus the sterling overseas pay included in the pay fixed personally
for the substantive holder of the post. The State Government may, therefore , grant to such
officiating Government servant the sterling overseas pay in the pay fixed personally for the
substantive holder of the post.F.R.34. [Deleted.]F.R.35. State Government may fix the pay of an
officiating Government servant at an amount less than admissible under these rules.Audit
Instructions. - (1) One class of cases falling under this rule is that in which a Government servant
merely holds charge of current duties and does not perform the full duties of the post.(2)When a
Government servant is appointed to officiate in a post on time-scale of pay but has his pay fixed
below minimum of the time-scale under Fundamental Rule 35 he must not be treated as having
effectually officiated in that post within the meaning of Fundamental Rule 22, or having rendered
duty in it within the meaning of Fundamental Rule 26. Such an officer, on confirmation, should
have his initial pay fixed under F.R. 22 (b), and draw the next increment after he has put in duty for
the usual period required calculated from the date of his confirmation.F.R.36. The State
Government may issue general or special orders allowing acting promotions to be made in the place
of Government servants who are treated as on duty under Rule 9 (6) (b).S.R.19. - (a) The
Conservator of Forests may make acting appointment in place of Forest subordinates deputed to
undergo a course of training at the Forest College, Dehradun and at the Assam Forest School at
Jhalukbari.(b)The Director of Public Instruction may make acting appointments in place of
inspecting officers and teachers deputed to undergo a course of training in a training
College.Personal PayF.R.37. Except when the authority sanctioning its order otherwise directs
personal pay shall be reduced by any amount by which the recipient's pay any may be increased, and
shall cease as soon as his pay is increased by any amount equal to his personal pay.F.R.38.
[Deleted.]Pay of Temporary PostF.R.39. When a temporary post is created which may have to be
filled by a person not already in Government service, the pay of the post shall be fixed with reference
to the minimum that is necessary to secure the services of a person capable of discharging the duties
of the post.F.R.40. When a temporary post is created which will probably be filled by a person who
is already a Government servant, its pay should be fixed by the State Government with due regard
to-(a)the character and responsibility of the work to the performed, and(b)the existing pay of
Government servants of a status sufficient to warrant their selection for the post.Audit Instruction. -
Under the Fundamental Rules special duty on deputation in India is not recognised. A temporary
post will be created for the performance of that duty. If the special duty is to be undertaken in
addition to the ordinary duties of the Government servant, then Rr. 40 and 48 will apply.F.R.41.
[Deleted].F.R.42. [Deleted].F.R.43. [Deleted].Fundamental Rules and Subsidiary Rules

Chapter V
Additions to Pay
F.R.44. Compensatory allowances. - Subject to the general rule the amount of a compensatory
allowance should be so regulated that allowance is not on the whole a source of profit to the
recipient; the State Government may grant such allowances to any Government servant under its
control and may make rules prescribing their amounts and the conditions under which they may be
drawn.Note. The Subsidiary Rules relating to travelling allowance are embodied in Section IV of
Fundamental Rules and Assam Subsidiary Rules (Second Edition) 1939.Audit Instructions. - (1) No
revision of claims of travelling allowance is permissible in cases where a Government servant is
promoted or reverted or is granted an increased rate of pay with retrospective effect in respect of the
period intervening between the date of promotion or reversion or grant of increased rate of pay and
that on which it is notified unless it is clear that there has been an actual change of duties.(2)A
Government servant's claim to travelling allowance should be regulated by the rules in force at the
time of journey, in respect of which they are made was undertaken.Compensatory allowances other
than travelling allowancesS.R.21. - Subject, in respect of house-rent allowance, to the provisions of
Rule 119, a compensatory allowance attached to a post will be drawn in full by the Government
servant performing the duties of that post.S.R.22. - (i) When a Government servant who has drawn
a compensatory allowance in his old post joins a new to which he is appointed while on duty in his
old post, or when a Government servant joins a new post on return from leave of not more than four
month's duration during which he has been permitted by competent authority to draw a
compensatory allowance, and a compensatory allowance is also attached to his new post will, during
joining time, draw a compensatory allowance at the lower of the two rates.(ii)Compensatory
allowance is admissible in all cases during joining time granted under F.R. 105 (d), and will be at the
rate of the allowance attached to the post which the Government servant is leaving or is proceeding
to join, as the case may be.(iii)Ration Compensation Allowance is admissible during all kinds of
joining time when it is treated as duty.Provision of ResidencesF.R.45. The State Government may
make rules or issue orders laying down the principles governing the allotment to officers serving
under its administrative control, for use by them as residences of such buildings owned or leased by
it, or such portions thereof as the State Government may make available for the purpose. Such rules
or orders may lay down different principles for observance in different localities or in respect of
different classes of residences and may prescribe the circumstances in which such an officer shall be
considered to be in occupation of a residence.F.R.45A. I. [Deleted].II. For the purpose of the
assessment of the rent, the capital cost of a residence owned by Government shall include the cost or
value of sanitary, water-supply and electric installations and fittings but exclude the cost or value of
the site (including expenditure on its preparation); and shall be either -(a)the cost of acquiring or
constructing the residence and any capital expenditure incurred after acquisition or construction ;
or when this is not known;(b)the present value of residence.Note. The cost of restoration or special
repairs shall not be added to capital cost or present value unless such restoration or repairs add to
accommodation or involve replacement of the existing type of work by work of a more expensive
character :Provided that-(i)the State Government may make rules providing the manner in which
the present value of residences shall be determined ;(ii)the State Government may make rules
determining what expenditure is to be regarded for the purpose of sub-Clause (a) above, asFundamental Rules and Subsidiary Rules

expenditure upon the preparation of a site ;(iii)the State Government may, for reasons which should
be recorded, authorise a re-valuation of all residences of a specified class or classes within a
specified area to be conducted under the rules referred to in proviso (i) above, and may revise the
capital cost of any or all such residences on the basis of such re-valuation.Note. Clause (i) in the
proviso obviously does not provide more than supplement (b) in the substantive part by setting the
manner in which the present value is to be determined in case in which the factors specified in (a)
are not known ; Clause (iii) which unlike (Clause (i) is a true proviso, alters the operation of the
substantive part of the rule by substituting for the capital cost determined in accordance with (a) in
the substantive part, in a case when the factors specified in (a) are Known, a new capital cost
represented by the present value calculated in accordance with the rules made under proviso (i) for
the primary purpose of determining the present value in cases to which (b) in the substantive part is
applicable.(iv)the capital cost, howsoever calculated, shall not take into consideration (1) any
charges on account of establishment and tools and plants other than such as were actually charged
direct to the work in cases in which the residence was constructed by Government, or (2) in other
cases, the estimated amount of such charges;(v)the State Government may, for reasons which
should be recorded, write off a specified portion of the capital cost of a residence-(1)when a portion
of the residence must be set aside by the officer to whom the residence is allotted for the reception of
official and non-official visitors visiting him on business ; or(2)when it is satisfied that the capital
cost, as determined under the above rules, would be greatly in excess of the proper value of the
accommodation provided ;(vi)in assessing the cost or value of sanitary, water- supply and electric
installations and fittings, the State Government may by rules determine what are to be regarded as
fittings for this purpose.III. The standard rent of a residence shall be calculated as follows :(a)In the
case of leased residences the standard rent shall be the sum paid to the lessor plus an addition
determined under rules which the State Government may make, for meeting, during the period of
lease, such charges for both ordinary and special maintenance and repairs and for capital
expenditure on additions or alterations as may be a charge on Government and for the interest on
such capital expenditure, as also for municipal and other taxes in the nature of house or property tax
payable by Government in respect of the residence ;(b)In the case of residences owned by
Government, the standard rent shall be calculated on the capital cost of the residence, and shall be
either-(i)a percentage of such capital cost equal to such rate of interest as may from time to time to
be fixed by the State Government plus an addition for municipal and other taxes in the nature of
house or property tax payable by Government in respect of the residence and for both ordinary and
special maintenance and repairs such addition being determined under rules which the State
Government may make ; or(ii)six per cent per annum of such capital cost, whichever is less.(bb)In
the case of a residence gifted to Government or leased on a nominal rent or on a rent-free basis to
Government the standard rent shall be the same as the case of a residence owned by
Government;(c)In all cases standard rent shall be expressed as standards for a calendar month and
shall be equal to one-twelfth of the annual rent as calculated above, subject to the proviso that, in
special localities or in respect of special classes of residence, the State Government may fix a
standard rent to cover a period greater than one month but not greater than one year. Where the
State Government takes action under this proviso, standard rent so fixed shall not be a larger
proportion of the annual rent than the proportion which the period of occupation as prescribed
under Rule 45 above bears to one year.Note 1. For the purpose of sub-Clause (a), (b) and (bb) above,
the additions for both ordinary and special maintenance and repairs shall not include anything forFundamental Rules and Subsidiary Rules

the establishment and tools and plant charges, except to the extent allowed under proviso (iv) to
Clause II.Note 2. The State Government may by rule permit minor additions and alterations the cost
of which does not exceed a prescribed percentage of the capital cost of the residence, to the made
during such period as the rule may determine, without the rent of the residence being increased.IV.
When Government supplies an officer with a residence leased or owned by Government the
following conditions shall be observed :(a)The scale of accommodations supplied shall not, except at
the officer's own request, exceed that which is appropriate to the status of the occupant.(b)Unless in
any case it be otherwise expressly provided in these rules, he shall pay (i) rent for the residence,
such rent being the standard rent as defined in Clause III above or 10 per cent of his monthly
emoluments, whichever is less ; (ii) municipal and other taxes payable by Government in respect of
the residence not being in the nature of house or property tax.(c)Notwithstanding anything
contained in sub- Clause (b) above, State Government may-(i)at any time after the standard rents
have been calculated under the provisions of Clause III above, group of a number of residences
whether in a particular area or of a particular class or classes, for the purpose of assessment of rent,
subject to the following conditions being fulfilled :(1)that the basis of assessment is uniform ;
and(2)that the amount taken from any officer shall not exceed 10 per cent of his monthly
emoluments ;(ii)by general or special order;provide for taking a rent in excess of that prescribed in
sub-Clause (b) or sub-Clause (c) (i) above from an officer-(1)who is not required or permitted to
reside on duty at the station at which the residence is supplied to him ;(2)who, at his own request, is
supplied with accommodation which exceeds that which is appropriate to the status of the post held
by him, or(3)who is in receipt of a compensatory allowance granted on account of dearness
allowance, or(4)who sub-lets without permission the residence supplied to him.V. In special
circumstances, for reasons which should be recorded, the State Government-(a)may, by general or
special order, grant rent-free accommodation to any officer or class of officers, or(b)may, by special
order, waive or reduce the amount of rent to be recovered from any officer, or(c)may, by general or
special order, waive or reduce the amount of municipal and other taxes, not being in the nature of
house or property tax, to be recovered from any officer or class of officers.VI. If a residence is
supplied with services, other than water supply, sanitary or electric installations and fittings, such as
furniture, tennis court or garden maintained at the cost of Government, rent shall be charged for
these in addition to the rent payable under Clause IV. The tenant will also be required to pay the
cost of the water, electric energy, etc., consumed. The State Government may make rules prescribing
how the additional rents and charges shall be determined, and such rules may also authorise the
remission or reduction of the additional rent or charges in special circumstances for reasons which
should be recorded.Note 1. The value of the site should be excluded in calculating the rent of special
services.Note 2. A tenant will not be required to pay meter hire when meters are the property of
Government. The cost of meters in such cases is to be included in the capital cost of the buildings for
the purpose of calculating rent. Where, as is usually the case, meters are owned and supplied by
Municipal bodies or electric companies, a tenant of a Government residence is charged meter rent,
by the company or local body concerned, as in the case of any other consumer of electricity.VII.
[Deleted].VIII. [Deleted].F.R.45B. [Deleted].F.R.45C. For the purpose of Rule 45-A "emoluments"
means-(i)Pay;(ii)Payments for the revenue of the State and fees, if such payments or fees are
received in the shape of a fixed addition to monthly pay and allowance, as part of the authorised
remuneration of a post;(iii)compensatory allowances, other than travelling allowance and winter
allowance whether drawn from the revenues of the State or from a local body;(iv)pension, otherFundamental Rules and Subsidiary Rules

than a pension drawn under the provisions of Chapter IX of the Assam Pension Manual, or
compensation received under the Workmen's Compensation Act, 1923 [Now Employees'
Compensation Act, 1923], as subsequently amended ;(v)in the case of a Government servant under
suspension and in receipt of subsistence grant, the amount of the subsistence grant; provided that if
such Government servant is subsequently allowed to draw pay for the period of suspension the
difference between the rent recovered on the basis of the subsistence grant and the rent due on the
basis of the emolument ultimately drawn shall be recovered from him.It does not include allowances
attached to the Victoria Cross, the Military Cross, King's Police Medal, the Indian Police Medal, the
order of British India or the Indian Order of Merit.Note 1. The emoluments of a Government servant
paid at piece-work rates shall be determined in such manner as the State Government may
prescribe.Note 2. The emoluments of an officer on leave mean the emoluments drawn by him for the
last complete calendar month of duty performed by him prior to his departure on leave.Note 3. The
amount of pension to be taken into account will be the amount originally sanctioned, i.e., before
communication, if any, and will also include the pension equivalent of death-cum-retirement
gratuity and other forms of retirement benefits, if any, e.g., Government contribution to a
Contributory Provident Fund, commuted value of pension, etc.Allotment of ResidencesS.R.23. -
When a building owned or leased by Government or a portion thereof has been made available by
Government for use as a residence by an officer under its administrative control, the competent
authority may allot such building or part of a building to a post specified in the order of allotment
for use as a residence by the incumbent of the post.S.R.24. - (1) The incumbent of a post to which a
residence has been allotted under S.R. 23, shall be considered to be in occupation of the residence
during the period of his incumbency, unless the allotment is changed or suspended under these
rules.(2)An officer shall not be considered to be in occupation of a residence only by reason of the
fact that he shares it with an officer who is in occupation thereof.(3)An officer shall be considered to
be in occupation of his residence when absent on tour or at hill station where he is permitted but not
required, by Government to reside.(4)An officer shall not be considered to be in occupation of a
residence when the proceeds on leave, unless the competent authority otherwise directs.S.R.25. - (1)
The competent authority may suspend the allotment of residence to a post-(a)which is temporarily
held by an officer under F.R. 49 in addition to another post, if the officer does not actually occupy
the residence ;(b)the incumbent of which discharges the duties of another post if such duties
prevent him from occupying the residence ;(c)to which an officer has been transferred from another
post in the same station, if the officer is in occupation of a residence allotted to such other post and
the competent authority does not consider it necessary that he should change his residence ;(d)in
which an officer is officiating for a period not exceeding two months, if the officer is prevented from
actually occupying the residence by circumstances which, in the opinion of the competent authority,
justify suspension of the allotment.(2)No allotment shall be suspended otherwise than in
accordance with sub-Rule (1) save by order of the State Government.(3)An order of suspension
under this rule shall terminate on the next change of incumbents or when the circumstances
justifying the suspension case so exist, whichever is earlier.(4)When the allotment of a residence to a
post has been suspended under this rule, the competent authority may allot the residence to any
officer of Government or, it is not required by any such officer, to any suitable person :Provided that
the allotment to such officer or person shall terminate not later than the date upon which the period
of suspension terminates.S.R.26. - An officer in occupation of a residence may sub-let it subject to
the following conditions, namely :(a)the lessee shall be approved by the competent authority ;(b)theFundamental Rules and Subsidiary Rules

sub-tenancy shall not be recognised by Government;(c)the lessor shall remain personally
responsible for the rent and for any damage caused to the residence beyond fair wear and tear
;(d)the sub-tenancy shall terminate not later than the date on which the lessor ceases to hold the
post to which the residence has been allotted ; and(e)the rent payable by the lessee shall not, except
with the previous sanction of the competent authority, exceed the rent payable to Government by
the lessor.State Government's decision - 1. In the case of sub-letting of a Government residence
when the lessor is not entitled to rent-free quarters or house rent allowance in lieu but the lessee is
so entitled, the rent payable by the lessor should be the rent payable by him if he had not sub-let the
residence, or the rent payable by the lessee if the residence had been allotted to him direct by
Government otherwise free of rent, whichever is higher ;
2. When a Government residence is sub-let and the lessor and the lessee are,
or the lessor is, entitled to rent-free quarters or house rent allowance in lieu,
the following procedure should be adopted in regard to the recovery of rent-
(i)when both the lessor and the lessee are entitled to rent-free quarters or house rent allowance in
lieu, the lessor will pay to Government an amount equivalent to the higher of the house rent
allowances; and(ii)when the lessor is entitled to rent free quarters or house rent allowance in lieu
and the lessee is not so entitled, the lessor will pay to Government an amount equivalent either to
the house rent allowance admissible to him or to the rent payable by the lessee if the house had been
allotted to him direct by Government, whichever is higher.S.R.27. - Officers holding posts to which
residences have been allotted may exchange residences with the permission of the authority which
made the allotment. Such exchange shall not be recognized by Government. Each officer shall
remain responsible for the rent of residence allotted to the post held by him.S.R.28. - The competent
authority may permit an officer during temporary absence from his station to store his furniture and
other property at his own risk, tree of rent in the residence occupied by him prior to such absence,
unless-(a)the officer, if any, who discharges the duties of the absent officer is responsible for
payment of the residence ; or(b)arrangements are made to let the residence during such temporary
absence.S.R.28A. - If the Officer, to whom a residence is allotted, is dismissed from the service, dies,
or retires, from service or is transferred from the place of posting to another place the allotment of
residence to him shall be cancelled with effect from one month after the date of his dismissal, death,
retirement or transfer to another place, as the case may be, or with effect from any date after such
dismissal, death, retirement or transfer on which the residence is actually vacated, whichever is
earlier.Explanation. - (1) 'Transfer' for the purpose of this rule means actual change in the
Headquarters of the officer transferred.(2)'Residence' means all official residences other than those
specially attached to the posts held by the officer,S.R.29. - An officer, who at his own request , is
supplied with a residence owned or leased by Government, of class higher than that for which he is
eligible, when a house of his class is available for him, will be charged the full standard rent laid
down in F.R. 45-A and will not be given the benefit of the 10 per cent concessions afforded by Clause
IV (b) of F.R.45-A.Rent of Government ResidencesS.R.30. - For the purposes of Clause II of the F.R.
45-A, the present value of a residence and of the site on which it stands shall be estimated by a
Public Works Officer of rank not lower than an Executive Engineer, nominated in that behalf by the
competent authority. The estimate shall be forwarded to the competent authority, who shall
determine the present value of the residence and of the site.S.R.31. - For the purposes of Clause II ofFundamental Rules and Subsidiary Rules

F.R. 45-A, expenditure incurred on such works as-(a)earth work in raising and levelling and work
done in terracing ;(b)turfing ;(c)revertments, retaining any compound walls ;(d)approach roads and
paths inclusive of all culverts, drains, steps, guard railings and posts ;(e)fencing, including zenana
fencing and compound walls used as such ;(f)hedging of all descriptions ;(g)entrance and wickets
gates ;(h)drains, inclusive of all pucca drains with their approns, and also any Kutcha drains
discharging water from the compound ; and(i)wells and tanks not now used as a source of
water-supply by occupant;shall be regarded as expenditure upon the preparation of a site.S.R.32. -
For the purposes of proviso (iv) to Clause II of F.R. 45-A, the following shall be regarded as fittings,
namely :Electric Fittings(a)Lamps of all kinds (excluding bulbs);(b)Fans including switches and
regulators the hire of which is not charged separately; and(c)Meters, the hire of which is not charged
separately.Sanitary and water-supply fittings(a)apparatus for hot water supply ;(b)baths, basins and
lavatory equipment; and(c)meters, the hire of which is not charged separately.Note. It is the
intention of Subsidiary Rule 32 that only those articles which form an integral part of the electric,
sanitary or water-supply installations shall be regarded as fittings. Such fittings need not necessarily
be fixture, e.g., electric lamps and fans may include movable lamps and fans, but on the other hand,
fixtures do not necessarily fall under the head of fittings, unless they are connected with the supply
in question. The basins and baths referred to in the rule are intended to cover only fixed lavatory
basins and baths of the type generally known as English baths.S.R.33. - In the calculation of the
standard rent of a leased residence under sub-Clause (a) of Clause III of F.R. 45-A, the addition to
be made for meeting the charges on Government other than the sum paid to the lessor shall
be-(a)for meeting such charges for both ordinary and special maintenance and repairs, the amount
estimated by the competent authority to be the probable cost of the maintenance and repairs of the
residence (including maintenance and repairs of any additional work done at Government expenses)
and all the rates or taxes, if any, payable under any law or custom by the owner to a municipality or
other local body, unless the amount of such rates of taxes has been included in the sum paid by the
lessor ; and(b)for meeting such charges for capital expenditure on additions or alterations and for
the interest on such capital expenditure, an amount estimated by the competent authority to be
sufficient to repay to Government during the period of the lease such charge or such part thereof as
the lessor may not have agreed to reimburse to Government, plus interest calculated at the rate fixed
by the State Government under sub-Clause (b)(i) of Clause III of F.R. 45-A :-(i)if no part of such
charges is to be reimbursed by the lessor, on half such charges ; or(ii)if part of such charges is to be
reimbursed by the lessor, on half the sum of such charges and the amount to be reimbursed.S.R.34.
- (1) In the calculation under sub-Clause (b) of Clause of F.R. 45-A of the standard rent of a
residence owned by Government, the addition to be made for municipal and other taxes payable by
Government and for both ordinary and special maintenance and repairs shall be-(a)the amount
estimated by the competent authority to be the probable cost of the maintenance and repairs of the
residence (including sanitary, water-supply and electric installations and fittings) plus the amount
of the rates of taxes, if any, payable under any law or custom by the owner to a municipality or other
local body ; or(b)if no such estimate has been made, a percentage of the sum taken under Clause II
of Fundamental Rule 45-A as the capital cost of the residence, to be fixed by the competent authority
and based on the average proportion which the amounts actually charged for such taxes,
maintenance and repairs in respect of residence of similar design and with similar conveniences in
the same locality bear to the capital cost of such residences.(2)For the purpose of making the
estimate or fixing the percentage referred to in sub-Rule (1)-(a)"probable cost" shall include allFundamental Rules and Subsidiary Rules

charges which may reasonably be expected to the incurred ;(b)"ordinary repairs" shall include
repairs executed annually or periodically, but shall not include special repairs ;(c)"special repairs"
shall include renewal of floors and roofs and other replacements recurring at long intervals ;
and(d)the cost or probable cost of repairs necessitated by the occurrence of fire, flood, earthquake,
abnormal storm or other natural calamity shall not be taken into consideration.(3)The competent
authority may at any time revise the amount estimated or the percentage fixed under sub-Rule (1)
and shall so revise it as if no revision has taken place for five years.S.R.35. - (1) When the standard
rent of a residence has been calculated, minor additions and alterations may be made without the
rent of the residence being increased, subject to the following conditions, namely :(a)the total cost of
such additions and alterations shall not exceed 5 per cent of the capital cost on which the standard
rent was last calculated; and(b)such additions and alterations shall be made within five years after
the last calculation of the standard rent.(2)In cases where additions or alterations are made at the
specific request of an officer to whom the residence has been allotted, additional rent calculated at
the rate of 6% of the estimated cost of additional and/or alterations will be recovered from that
officer from the date of completion of the work, over and above the rent which otherwise would have
been charged under the provisions of Clause III of F.R. 45-A. Such additional recovery will continue
until that residence is re-allotted to another officer or till the standard rent has been re-calculated
under the provisions of S.R. 26.S.R.36. - (1) When by reason of additions and alterations, the capital
cost of a residence exceeds by more than 6 per cent of the capital cost on which the standard rent
was last calculated, the standard rent shall be re-calculated with effect from the 1st April next
following.(2)Subject to the provisions of sub-Rule (1), the standard rent of a residence shall be
calculated on the expiry of five years from the date of the last calculation.(3)Notwithstanding
sub-Rr. (1) and (2), when a residence referred to in sub-Rule. (2) of S.R. 35 is vacated by the officer
at whose request additions or alterations were made, the standard rent of residence on its
re-allotment to another officer, will be the existing standard rent plus the additional rent sanctioned
in accordance with S.R. 35 (2) for works carried out up to the date of re-allotment. If the standard
rent of that residence has been pooled with other residences its pooled rent will be the existing
pooled rent plus additional rent recoverable under S.R. 35 (2).S.R.37. - (1) If a residence is supplied
with services other than water-supply, sanitary or electric installations and fittings, such as
furniture, tennis court or garden maintained at the cost of Government (other than a garden in
respect of which rules, other than the rules made by the State Government under Clause VI of
F.R.45-A are in force) the rent to be charged for such services in addition to, and during the same
period as the rent payable under Clause IV of F.R. 45-A shall be determined by the competent
authority subject to the following provisions, namely :(a)the rent shall, in the case of furniture, be
calculated for durable and non-durable articles separately;(b)the rent shall be expressed as monthly
rent and shall be one-twelfth of the amount annually required for the payment of-(i)interest at a rate
to the fixed from time to time by the State Government in this behalf on the capital cost of such
services ;(ii)in the case of furniture, depreciation and repairs ; and(iii)in the case of such services,
other than furniture, maintenance charges; and(c)if the capital cost of such services is not known, it
may be estimated by competent authority.Note. Rent for furniture, when charged, should be
assessed at 9 per cent per annum of the capital cost, which includes interest, depreciation and repair
charges.(2)If a residence is supplied by Government with electric energy and water and meters (see
S.R. 32) the charges for such service shall be recovered in addition to the rent payable under
sub-Rule (1) and under Clause IV of F.R. 45-A, and shall be determined by the competent authorityFundamental Rules and Subsidiary Rules

subject to the following provisions, namely :(a)In the case of electric energy and water, the supply of
which is regulated by meters, the charges shall be calculated on the number of units consumed each
month as indicated by the meters. The rate of the cost per unit shall be so fixed as to include in
addition to such margin of profit to Government as the competent authority may deem reasonable,
the amount required for the payment of -(i)interest at a rate to be fixed by the State Government
from time to time in this behalf on the capital outlay incurred on the system up to the point of
contract with the interest on installation;(ii)depreciation and maintenance charges and the capital
assets ; and(iii)actual running expense.(b)In the case of electric energy and water, the supply of
which is not regulated by meter, the charges recoverable shall be fixed at such rates as the
competent authority may deem reasonable.(c)In the case meters, the charges shall be recovered for
the period of actual use, subject to minimum of one month and to broken periods being treated as a
whole month, at a fixed rate per mensem which shall be one-twelfth of the amount annually
required for the payment of-(i)interest at a rate to be fixed from time to time by the State
Government in this behalf on the capital cost of such meters; and(ii)depreciation and maintenance
charges.(d)If the capital outlay or cost mentioned in Clause (a) (i) and (c) (i) is not known, it may be
estimated by the competent authority :Provided that nothing contained in this sub-rule shall operate
to prevent the competent authority from grouping a number of residences whether in a particular
area or of a particular class or classes for the purpose of assessment of charges for electric energy,
water and meters, subject to the condition that the basis of assessment is uniform.(3)The State
Government may, in special circumstances, by order remit or reduce the additional rent and charges
referred to in sub-Rr. (1) and (2) for reasons which should be recorded in the order.S.R.38. - When a
portion of a residence is utilised as an office, the competent authority may grant remission of rent
for the portion so utilised, the capital cost of the remaining portion being assessed separately for the
purpose of calculating the standard rent. No remission of rent, however, is admissible where
separate office accommodation is provided for the official use or where the use of a part of his
residence for official purposes is optional.S.R.39. - The competent authority may authorise
reduction or remission of rent otherwise chargeable when a residence is rendered uninhabitable by
reason of extensive repairs in progress or from any other cause and is so certified by the Executive
Engineer; inconvenience caused by petty or ordinary annual repairs is insufficient to warrant
reduction or remission of rent.HonorariaF.R.46. (a) Fees. - Subject to any rules made under F.
R.46-A and F.R. 47, a Government servant may be permitted, if this can be. done without detriment
to his official duties and responsibilities, to perform a specified service or series of services for a
private person or body or for a public body including a body administering a local fund and to
receive a remuneration therefor, if the service be material, a non-recurring or recurring fee.Note.
This clause does not apply to the acceptance of fees by Medical Officers in civil employ for
professional attendance which is regulated by the orders of the Secretary of State.(b)"Honoraria" -
The State Government may grant or permit a Government servant to receive an honorarium as
remuneration for work performed which is intermittent or occasional in character and either so
laborious or of such special merit as to justify a special reward. Except when special reasons, which
should be recorded in writing, exist for a departure from this provision, sanction to the grant or
acceptance of an honorarium should not be given unless the work has been undertaken with prior
consent of the State Government and its amount has been settled in advance.(c)"Fees and
Honoraria" - In the case of both fees and honoraria the sanctioning authority shall record in writing
that due regard has been paid to the general principle enunciated in F.R. 11, and shall record alsoFundamental Rules and Subsidiary Rules

the reasons which in his opinion justify the grant of the extra remuneration.Audit Instruction. - The
rule requires that the reasons for the grant should be recorded in writing, as it is intended that the
grant of an honorarium or fee should be carefully controlled and that audit should be given an
effective opportunity of intervention if it be deemed necessary. Audit Officers may, therefore,
require that the reasons for the grant of an honorarium or fee should be communicated to them in
each case.State Government's interpretation - 1. A question has been raised whether honorarium
under F.R. 46 (b), can be granted to a Government servant for performing the duties of another
sanctioned post in addition to the normal duties attached to his own post.
2. Honorarium has been defined in Fundamental Rule 9 (9) as a recurring or
non-recurring payment granted to a Government servant from the
Consolidated Fund of India or the Consolidated Fund of a State as
remuneration for special work of an intermittent or occasional character.
When a post is sanctioned the duties attached to it can hardly be regarded as
intermittent or occasional in character. Hence, when in addition to his own
duties, a Government servant is required to perform the duties of another
sanctioned post, he should be deemed to the performing additional duties
which are not intermittent or occasional in character, even though he may be
asked to perform such additional duties only for a short period. Honorarium,
under F.R. 46 (b), will not, therefore, be admissible to a Government servant
who is required to perform the additional duties of a sanctioned post.
3. Past cases which have been already decided otherwise need not be
re-opened.
F.R.46A. The State Government may make rules prescribing the conditions and limits subject to
which a fee may be received by a Medical Officer in civil employ for services other than professional
attendance.Government of India's Order under F.R. 46-A in Section III of Fundamental Rules and
Assam Subsidiary Rules (Second Edition) 1939, are reproduced below :Government of India's
Order. - (1) Unless the President by special order otherwise directs, no portion of any fee received by
a Medical Officer in civil employ for services other than professional attendance shall be credited to
the revenues of the Federation or of a Province.(2)The following rules have been issued regarding
the acceptance of fees by Indian Medical Service Officers in civil employ and all other Medical
Officers under the rule making control of the President for service other than professional
attendance :(a)No work or class of work involving the acceptance of fees may be undertaken on
behalf of a private person or body or public body or Indian State except with the knowledge and
sanction, whether general or special, of a competent authority prescribed by the State Government
under whom the Medical Officer is serving.Note. The Government of Assam have prescribed the
Inspector General of Civil Hospitals and the Director of Public Health, Assam to be competent
authority under this rule who should certify in writing that the work does not interfere with the
official duties of the Medical Officer concerned.(b)In cases where the fee received by the MedicalFundamental Rules and Subsidiary Rules

Officer is divisible between himself and Government, the total amount should first be paid into the
Government treasury, the share of the Medical Officer being thereafter drawn on a refund bill in
Civil Account Code Form No. 17. In such cases a complete record or the works done and the fees
received should be kept by the Medical Officer.Note. The above procedure will not apply to fees for
examination by a Medical Board for commutation of pension or of candidates in respect of
appointments to All-India services and technical post, one-fourth of which only will be credited to
Government and the balance will be paid to Medical Board in cash by examinee at the time of the
medical examination as laid down in the Government of India, Education, Health and Land
Department letter No. F. 109/32-H. dated the 8th July, 1932 and No. F-16-11/38-H, dated the 8th
June, 1938.(c)For private bacteriological, pathological and analytical work carried out in
Government laboratories and in the Chemical Examiner's Department, 40 per cent of the fees
should be credited to Government, the remainder (60 per cent) being allowed to the Director of the
Laboratory or the Chemical Examiner as the case may be, who may divide it with his assistants and
subordinates in such manner as he considers equitable. No payment should, however, be made to
officers from the sale proceeds of those vaccines which are used on a large scale for prophylactic
purposes, for example T.B. Cholera, Influenza and Plauge vaccines.Note 1. The bacteriological and
microscopical examinations which are required to connection with the investigation of the cases of
persons entitled to free medical attendance should be conducted free of charge ; provided that they
are carried out under the following conditions, namely, at the hospital or Government institution
with its own staff equipment and apparatus and in the ordinary course of its work.Note 2. This
clause does not apply to Lt. Col. L.A.P. Anderson, I.M.S. or Lt.Col. J.L. Sen, I.M.S. so long as they
continue to hold the posts of Director, Pasteur Institute and Medical Research Institute, Shillong
and Superintendent, Berry-White Medical School Dibrugarh, respectively. They will be governed by
the rules contained in the Government of India's letter No. 1300- Health, dated the 20th November,
1924.(d)The rates shown in Appendix 8 are maximum which a Medical Officer will be free to reduce
or remit, if he is entitled to appropriate them himself. In cases where the fee is divisible between the
Medical Officer and Government, the former may charge lower rates in special cases where he
considers it necessary either owing to the pecuniary circumstances of the patient or for some other
reason of public interest, and the share of Government will be calculated on the basis of the fee
actually realised instead of the prescribed fee, provided the approval of Government is obtained by a
general or special order in this behalf.Note. Under this rule general orders have been issued that the
Director, Pasteur Institute, Shillong and the Superintendent, Berry-White Medical School,
Dibrugarh, may accept such reduced sum as they find the patient capable of paying, when
specimens are sent by the Officer-in-charge of Hospital maintained by a recognised mission or of the
Ganesh Das Hospital, Shillong, with the report that the patient is unable to pay the full fees. He
should, however, satisfy himself that similar concessions are made by the Hospital itself to such
patients.(3)The following rules have been issued by the Government of India regarding the
acceptance of fees by Indian Medical Service Officers in civil employ :(a)If an officer is summoned
by the court at the instance of the State, he should be treated as being on duty and he should be
allowed to draw his travelling and subsistence allowance if the court is situated away from his
headquarters; if the Court is situated at his headquarters, he should not be paid anything.Note. No
travelling and subsistence allowance shall be admissible unless the Court is situated at a distance of
more than ten miles from the officers' headquarters.(b)If such an officer is summoned by the Court
at the instance of a private person or party, such attendance at Court should be regarded as privateFundamental Rules and Subsidiary Rules

practice of the nature of expert evidence and should be regulated as follows :(i)The Officer may
accept such fees as the Government under whom he is serving may permit him to accept having
regard to his eminence in medical profession, the importance of the case and the distance of the
Court from his headquarters.(ii)In each case the officer should apply to Government for sanction in
the same way, as, for example, an officer has to obtain permission of Government for accepting
fee.(iii)The Government would, in according permission, be at liberty to recover from the fee such
amount as may be considered reasonable for the loss of the officer's time in the event of his
attendance at the Court interfering with the performance of his official duties.(iv)The officer's
travelling and subsistence allowance would be paid by the private person or party at whose instance
he may be summoned.S.R.40. - (1) The rule framed by the Government of India to govern the
acceptance of fees for services other than professional attendance (See Order under F.R. 46-A, in
Section III) have been adopted by the Government of Assam in respect of Government servant
under their rule-making control, subject to the following conditions. The items referred to below
appear in Appendix 8.I. Items 1 and 2. - (a) Medical Officer holding appointments as Civil Surgeons
are authorised to charge the same rates as those prescribed for Indian Medical Service
Officers.(b)Civil Assistant Surgeons may charge half of the above rate.(c)Sub-Assistant Surgeons
may charge one quarter of the above rates.Explanation. - Medico-legal examinations made at a
dispensary or hospital or work done in the ordinary course of duty, and no fee is chargeable (save at
subsidized practitioners' dispensaries). No certificate is to be given in respect of such an
examination except when it is made on the requisition of Magistrate or police officer in a cognizable
case, or on the requisition of a Magistrate in a non-cognizable case. Certificates in such cases, when
it is stated that the requisition is made at his own instance, to satisfy doubt as to the nature of the
injury in the interests of justice, will be given free of charge.II. Item 3. - Medical Officers holding
appointments as Civil Surgeons may claim a fee of Rs. 16, Assistant or Sub-Assistant Surgeons a fee
of Rs. 4 for each day's attendance.III. Items 4-7. - These items apply only to Civil Surgeons, who will
be entitled to receive the same fees as Indian Medical Service Officers.IV. Items 9-10. - (1) The
maximum rate of fees laid down for such examinations carried out by Indian Medical Services
Officers shall also apply in the case of all other Medical Officers including Sub-Assistant Surgeons.
The entire amount of the fees should first be created into the Treasury and 60 per cent of it payable
to the Government servants undertaking the work, shall be drawn.(2)The rules framed by the
Government of India [vide Order No. (3) below F.R. 46-A in Section III of this volume] to govern the
acceptance of fees by Indian Medical Services Officers in civil employ for giving evidence in a Court
of Law have been adopted by the Government of Assam in respect of Government servants under
their rule-making control.F.R.47. The State Government may make rules prescribing the conditions
and limits, subject to which authorities subordinate to it may sanction the grant or acceptance of
honoraria, and acceptance of fees, other than the acceptance of fee by Medical Officers in civil
employ for professional attendance.Note. Where the officer's presence in Court for giving evidence
entails absence during the usual working hours in the hospital or laboratory such portion not
exceeding 60 per cent of the fee as Government may, in according permission, fix after taking into
consideration the degree of interruption involved in each case, shall be credited to Government in
accordance with the procedure laid down in Clause (b) of the Government of India's Order No.
(2).S.R.41. - Subject to the conditions prescribed in S.Rr. 51 to 55 and to any general or special
orders governing a particular case or class of cases a competent authority may sanction the grant of
an honorarium to a Government servant or the acceptance by such Government servant of anFundamental Rules and Subsidiary Rules

honorarium or a fee. No Government servant may accept an honorarium or fee without such
sanction.When the Government servant is under the administrative control of another authority, the
consent of the competent authority permitting him to undertake the work and to accept the
honorarium or the fee together with the certificate specified in S.R. 53, where necessary, should be
obtained in writing and the fact recorded in the order of sanction.Note 1. (a) Sanction has been given
to the acceptance of remuneration by (a) Government officers of the Education Department
appointed as Paper-setters, Moderators and Examiners, Scrutinisers, Supervising Officers,
Officer-in-charge, etc. on the scale approved from time to time in respect of Examinations or Tests
held by the Universities of India, or by Department of Education or by any Board or Committee in
the State constituted or approved by the Government; or by any institution under the control of the
Government.(b)Educational Officers, other than Deputy Inspectors and Sub-Inspectors of Schools
from local and Municipal Boards for setting and moderating question papers and examining answer
papers of the Primary Scholarship Examination conducted by these Boards at the rates fixed from
time to time.(c)Educational Officers, including Deputy Inspectors and Sub-Inspectors of Schools
appointed as Invigilators and Superintendents of Primary Scholarships Examination held during
holidays ; provided that they do not receive any remuneration for similar work in connection with
any other examination held simultaneously, at rates fixed from time to time.(d)Persons who are
permitted to act as Supervisors or Invigilators in connection with examinations held by the Central
Public Service Commission at their State centres at prescribed rates.(e)Sanction has also been given
to the acceptance of remuneration by the Electrical and Factory Inspector, appointed as examiner
for technical subjects of the Prince of Wales Technical School, Jorhat and the Surma Valley
Technical School, Sylhet on the scale fixed from time to time.(f)Sanction has also been given to the
acceptance of remuneration by Government servants appointed as Paper-setters, Examiners and
Invigilators in connection with examination held by the Assam Public Service Commission at
prescribed rates. These do not apply to Members of the Commission nor do the invigilation fees
apply to Members of All-India or State Services, save for such work conducted on public
holiday.Note 2. A fee of Rs. 48 is payable to Civil Surgeon for inspection of each tea garden on the
unhealthy list.Note 3. A reward of four annas is admissible for each conviction obtained to
vaccination staff instituting proceedings.Note 4. On every death certificate issued by the
Sub-Inspector of Police in charge of the thana he will be entitled to a fee of Re. 1.Note 5. A
Sub-Assistant Surgeon may be remunerated at the rate of Rs. 15 and an Assistant Surgeon at the rate
of Rs. 20 for each set of lectures on ambulance work, and for examination at annas eight for each
candidate, if recognised classes are held.In the case of the Murarichand College Centre the
minimum charge for examination will be Rs. 6. The examination will not be held by the lecturer.This
does not apply to Sub-Assistant Surgeons in whole time charge of Jail Hospitals, Police Hospitals
and Government Hospitals, who are not entitled to remuneration for classes held in the institutions
of which they are in medical charge.Note 6. The Sub-Assistant Surgeon at Haltugaon and
Kachugaon may be paid by the Conservator of Forests remuneration up to a maximum limit of Rs.
20 in each case in any month for the treatment of elephants belonging to the Forest Department in
emergent cases when the Veterinary Assistant attached to the Forest Department is absent.Note 7.
Officers of the Jail Department may be granted the reward offered for the capture of escaped
prisoners or re-capture of escaped undertrial prisoners.Note 8. The Inspector (Subedar), Armed
Police Reserve Sub-Inspector and Drill Inspector in charge of training the Jail staff in drill and
musketry may be granted allowance at the following rates for each Assistant Jailor, Head WarderFundamental Rules and Subsidiary Rules

and Warder trained under the Armed Police at district and sub-divisional headquarters:
Inspector (Subedar) Rs. 5 p.m.
Armed (Branch) Sub-Inspector Rs. 4 p.m.
Drill Inspector Rs. 2 p.m.
Honoraria at the aforesaid rates are also admissible to these officers for each police recruit trained
by them. The honoraria will be drawn and disbursed by the Superintendent of Police of the district
concerned, subject to the general control of the Inspector-General of Police who may disallow any
payment either wholly or partially if he is not satisfied with the quality of the training given.The
above rates are admissible for the course of initial training. Half of the above rates will be allowed
for the refreshal course of training.Note 9. Veterinary Assistants are authorised to accept fees from
private persons at the rates laid down in the departmental rules.S.R.42. - The following rules have
been laid down for the grant of language rewards to Subordinate Officer in Assam :(1)Subordinate
Officers for the purposes of these rules, or Officers other than officers of the All-India or the State
Services or Officers holding posts which have been declared to be "special posts".(2)Any
Subordinate Officer who, in the opinion of a Commissioner, is a Head of a Department or a Political
Officer, should be acquainted with any language spoken in the hill district or Frontier Tract in which
he is serving, may (provided the language is not the candidate's native language or a language
naturally acquired by the candidate at his home) be permitted by that authority to sit for an
examination in the language and if he passes will be eligible for a reward.(3)The examination will
consist of a practical (colloquial) test to be conducted under the orders of a Commissioner, Head of
Department or Political Officer who may prescribe the test suitable for the different classes of
officers under him and determine how the examination is to be conducted.(4)The result of the
examination will be sent to the officer under whose order the examination was conducted and such
officer is empowered, subject to budget provision, to grant the prescribed reward to the successful
candidate or candidates.(5)The reward will be equivalent to two months' pay of the officer to whom
it is granted subject to a maximum of R. 100 (Rupees hundred only).(6)When a Commissioner or
Head of a Department or a Political Officer considers in the case of any officer to whom these rules
apply, that it is desirable that an officer should have a written knowledge of the language, the
examination prescribed in Rule 3 will also include a written test in which the officer will be
required-(a)to write down sentence spoken in the tribal language or a conversation held between
two of them and to explain the sentences or the conversation correctly in English ; and(b)to
translate without assistance from English or his mother tongue into the tribal language sentences
which are not of very much or more difficult nature than those described in Clause (a). The
translation must be substantially correct and intelligible to a native whose language he is writing.
When an officer passes such an examination, the maximum limit of the reward may be Rs. 300
(Rupees three hundred only).Note. The rewards prescribed in Sub-Clauses (5) and (6) (b) are, until
further orders reduced to a maximum of Rs. 50 (Rupees fifty only) and Rs.150 (Rupees one hundred
and fifty only), respectively.S.R.43. - If it is necessary to admit to hospital a patient to whom S.R.
280 or 281 applies, he will be required to defray all charges for board or for special accommodation.
Medical, surgical and nursing charges will be borne by Government for officers themselves, but
normal fees will be charged for their wives or members of their family. Payment will be made on a
certificate granted by the Civil Hospitals.Medical, surgical and nursing charges shall be paid by
Government only when the treatment or nursing is administered in a hospital by its own staff and inFundamental Rules and Subsidiary Rules

the ordinary course of its works.The words "hospital" referred to in this Note includes the Welsh
Mission Hospital, Shillong, and Welsh Mission Hospital, Jowai.(1)All Government servants of the
Provincial and Subordinate Services when admitted to a Government or a Local Board hospital and
which they may under departmental rules or orders admitted, shall be entitled without payment of
fees to medical and surgical attendance and to all the services normally provided by the hospital
with its own staff apparatus and equipment ; provided that such services are recommended by the
authorised medical attendant. They will be required to bear themselves any charges which may be
fixed under the rules of the hospital for diet and special accommodation :Provided that Government
servants drawing pay of Rs.50 per mensem or less will be provided with free hospital diet.(2)If it is
necessary for a Government servant of a State and Subordinate Services to be admitted to a hospital
which is not maintained by Government or a Local Board, in accordance with departmental rules, he
may, on production of a medical certificate to this effect from the Civil Surgeon of the district in
which his headquarters are situated, countersigned by the Inspector General of Civil Hospitals,
recover the following charges as may be imposed by that hospital, from Government:Fees for
medical or surgical attendance.Fees for X-Ray or Electrical Treatment.Drugs and Dressings.The
Payment will be subject to the same condition as in Government hospitals, viz, that the treatment is
administered by the hospital through its own staff and in the ordinary course of its work.In case (1)
travelling allowance will be regulated by S.R. 272. In case (2) travelling allowance will be admissible,
in instances where X-Ray diagnosis is certified by the Civil Surgeon, with the counter-signature of
the Inspector General of Civil Hospitals, to be necessary ; provided that the hospital is nearer to the
place of the officer's headquarters than any Government hospital where such X-Ray treatment is
obtainable otherwise no travelling allowance is admissible save that if the expense of the journey is
altogether disproportionate to the pay of the officer concerned, the matter should be referred to
Government for orders together with a certificate signed or countersigned by the Civil Surgeon that
the journey is absolutely necessary ; except in cases of real emergency, such reference should be
made before the journey is undertaken.S.R.44. - The following rules and scale of fees and charges
are prescribed for X-Ray, and Electrical Treatment at the Berry-White Medical School, Dibrugarh
and the Reid Chest Hospital and Clinic, Shillong :(1)For the purposes of these rules patients will be
classified as follows :Class A. - Persons drawing a salary, or whose total income is estimated to be
not less than Rs.600 per mensem.Class B. - Persons drawing a salary, or whose total income is
estimated to be not less than Rs. 200 per mensem.Class C. - Persons whose salary, or estimated
income is not less than Rs. 60 per mensem.Class D. - Indigent persons.(2)No charge will be made
for the treatment of indigent persons.(3)Tea garden coolies and persons sent in any employer for X-
Ray or electrical treatment will be granted facilities if there is a definite necessity for the radiogram
or treatment, and will be charged for under Class B, the bill being rendered to the
employer.(4)Radiogram taken only for the purpose of school instruction will not be charged
for.(5)The fees levied in the cases of Classes A and B will be divided equally between Government
and the operator and staff. The Superintendent has discretion to waive or adduce the charge in any
case where he is satisfied for reasons to be recorded in writing that it would be a hardship ; provided
that any recovery is credited to Government up to the Government share. All flat rate fees will be
credited in full to Government.(6)The scale of fees will be as follows :
Nature of workClass of
patientsRs.  
Screening A 5  Fundamental Rules and Subsidiary Rules

 B 3  
Ionisation treatment A 5  
 B 3  
Diathermy A 5  
 B 3  
First Radiogram according to part placed A 10-15  
 B 8-12  
Second or subsequent Radiogram Ahalf the above
rate. 
 B  
Barium meal A 75  
 B 40  
Gall Bladder A 32  
 B 24  
Ultra-violet exposure A 5  
 B 3  
Infra-red exposure A 4  
 B 2  
Faradaic current applications A 4  
 B 2  
Centerisation A 5-20According to extent of
operation.
 B 3-10
Vibratory Massage A 4  
 B 2  
Urography A 32  
 B 24  
Barium Enema A 37-50 Paise
 B 20 0
Examination of lungs or Bronchial tract after
Lipiodol orsimilar drugA 32 0
B 24 0
In the case of Class C patients a flat rate of Rs. 5 only (to cover cost of materials) will be charged for
every kind of work mentioned above 38 except for Screening, Ionisation treatment, Diathermy,
Ultra-violet and Infra-red exposures, Faradaic current application and Vibratory Massage for which
a flat rate of Rs. 2 will be charged.Note. No fee is chargeable for radiographic and
electro-therapeutic treatment of Government servants other than examination in connection with
dental treatment carried out at the instance of the authorised Medical Officer.S.R.45. - The fee of the
Public Analyst for analysis of articles submitted under Section 225 (1) of the Assam Municipal Act,Fundamental Rules and Subsidiary Rules

1923 is Rs. 2 per sample if sent by a local body and Rs.5 if sent by any other person. The Public
Analyst is entitled to a fee of half the amount.S.R.46. - The Indian Officer ordinarily a School Moulvi
or an officer of similar status selected as a member of the Local Committee for the conduct of the
Departmental Examinations in (1) colloquial Hindustani, (2) (Lower or Higher Standard Begali; and
(3) Lower and Higher Standard Assamese, when examining officers of the Burma Oil Company, the
Assam Oil Company, the Assam Railways and Trading Company and officers and senior
subordinates of the Assam Bengal Railway is entitled to half the fee realised, viz Rs. 16 in each
case.S.R.47. - Half of the additional fee charged at the rate for Rs.50 for the inspection of a boiler on
Sundays and certain holidays under Rule 4 (7) of the rules framed under Section 29 of the Indian
Boilers Act, 1923 (5 of 1923), is payable to the Inspector of Boilers.S.R.48. - (1) The receipt from
charges for operations performed into Government hospitals in Assam on well-to-do-patients, other
than Government servants or servants of local bodies, realised under Assam Government
Notification No. 338- L.S.G., dated the 1st February, 1937, should be divided between Government
and the Government servant undertaking the work in the following manner:
30. per cent to Government,
60. per cent to the Operator,
5. per cent to the Anaesthetist,
5. per cent to other Assistants.
(2)In the case of minor operations 50 per cent to Government and 50 per cent to the operator,
anaesthetist and other assistants proportionately to their shares inter se for major operations.The
division of fees for operations is subject to the following conditions :(i)The total fee must be paid
into the Government Treasury, the share of the staff being thereafter drawn on a refund bill in
Assam Treasury Rules Form No. 18.A complete record of the work done and of the fees received
should be kept by the officer-in-charge of the hospital.(ii)When the Civil Surgeon reduces the fee in
special cases the shares of Government will be calculated on the basis of the fees actually
realised.Subject to the above, in medical and other cases the Civil Assistant or Sub-Assistant
Surgeon will not be debarred from accepting fees if this is offered by a patient either in accordance
with a previous arrangement or subsequent suo motu.S.R.48A. - Subject to the provisions of the
rules that may exist on the subject, all hospital facilities ordinarily available, as distinct from those
admissible to paying patient in the paying wards in a Government Hospital or in a Government
Medical Institute, whether these relate to medical examination or treatment, will be allowed to
indigent persons free of charge.The Medical Officer in attendance of such an indigent patient is
authorised to decide whether a particular patient attended to by him is really indigent or not. In the
case of any doubt or dispute over the matter, it should be referred to the Senior Medical
Officer-in-charge of the Hospital or the Institute concerned for his decision which shall be
final.S.R.49. - In the case of remuneration paid to copyist, sanction is accorded to the acceptance of
such remuneration at the sanctioned rates by a member of the fixed establishment of any office for
preparing copies of any document where the copies applied for are few or not sufficient to induce anFundamental Rules and Subsidiary Rules

outsider to take a licence for the work, provided the member of the establishment cannot, in the
opinion of the Head of the office, do the copying work in addition to his duties during office hours
and does in fact do the work out of office hours.S.R.50. - Minister chosen by the Governor under
Section 51 of Government of India Act, 1935, shall during the period of their tenure of office be
entitled to the medical attendance and treatment as are laid down for Government servants.While
on duty in or outside Shillong for the purposes of attending a meeting of the Legislature or a
Committee meeting or a Conference appointed by Government, M.L.A's shall, during the period of
their membership, be entitled to the same medical attendance and treatment as are laid down for
Government servants.S.R.50A. - The Inspector General of Civil Hospitals is authorised to sanction
the acceptance of fees of Rs.20 per mensem by a Government Assistant Surgeon at Mokochung for
the periodical examination of the students of the educational institutions maintained by the
American Baptist Mission at Impur ; provided that the work to be undertaken by the Medical Officer
can be done without any interruption of his official duties.S.R.51. - The amount of an honorarium or
fee must be fixed with due regard to the value of the service in return for which it is given.S.R.52. -
When the service rendered falls within the scope of the ordinary duties of the Government servant
performing it, test whether the service is material or is of special merit as prescribed in F.R. 46 must
be very strictly applied.S.R.53. - No Government servant may undertake a work, whether with or
without an honorarium or a fee, without the sanction of the competent authority, who, unless the
Government servant is on leave, shall certify in the case of fees, that the work can be undertaken
without detriment to his official duties and responsibilities.S.R.54. - When a honorarium or fee is
paid for work done by a Government servant during time which would otherwise be spent in the
performance of official duties the honorarium or fees must be credited to provincial revenues :
provided that a competent authority may, for special reason which should be recorded, direct that
the whole or part of it may be paid to the Government servant.S.R.55. - When a Government servant
of an educational service is permitted to receive fees for private tuition, the financial limits of the
power of sanction delegated to a competent authority shall be considered to apply to the total
amount of the fees to be accepted by such Government servant during any particular scholastic
terms or vacation.S.R.56. - No Government servant may act as an arbitrator in any case which is
likely to come before him in any shape by virtue of any judicial or executive post which he may be
holding.S.R.57. - A Government servant called upon by a court of law to act as commission to give
evidence on technical matter may comply with the request; provided the case is not of such a nature
as will be likely to come before him in the course of his official duties and any fee received by him
should be credited to Government.S.R.58. - Civil Police below the rank of the Sub- Inspector when
off-duty may, under the orders of the District Superintendent of Police and subject to any
controlling instructions issued by the Deputy Commissioner or Political Officers, be employed in
fatigue parties either by themselves or in conjunction with ordinary paid labour, to assist in the
construction or repair of any Police buildings in places where labour is unprocurable or though
procurable expensive. They may, with the specific sanction of the Inspector General of Police, be
employed in similar circumstances and in special cases also in work required for the Police
Department but the cost of which is debitable to the Public Works Department budget under the
head "50-Civil Works"; provided that-(1)no recruit who has not passed in drill shall be so employed
;(2)such employment shall in no way interfere with the regular course of drill or instruction in
musketry of the men employed or diminish the number of ordinary parades ;(3)subject to budget
provision each constable shall receive four annas per diem, and each constable or AssistantFundamental Rules and Subsidiary Rules

Sub-Inspector of Police employed as Overseer six annas per diem, as working allowance from the
Police Department, subject to a maximum of Rs. 6 and Rs. 9 a month respectively;(4)the ordinary
working hours shall be from 10 a.m. to 4 p.m. but undue exposure to heat or rain shall not be
allowed, nor in any case shall the work commence before 10 a.m. or to be carried on after 4
p.m.(5)the charges will be classified, as the case may be, either under (a) "petty repairs" or (b) "petty
construction" and a complete daily muster roll will be maintained by the Officer-in-charge, police
station, outpost, reserve or beat house, and sent to the office of the Superintendent of Police for
payment ;(6)this will in no way supersede the existing Rule III-54 of the Assam Police
Manual.F.R.48. Any Government servant is eligible to receive and except as otherwise provided by a
general or special order of the Governor of Assam, to retain without special permission-(a)the
premium awarded for any essay or plan in public competitions;(b)any award offered for the arrest of
a criminal or for information or special service in connection with the administration of justice
;(c)any reward payable in connection with the provisions of any Act or Regulation or rules framed
thereunder;(d)any reward sanctioned for services in connection with the administration of the
customs and exercise law ; and(e)any fees payable to a Government servant for duties which he is
required to perform in his official capacity under any special or local law or by order of
Government.F.R.48A. A Government servant whose duties involve the carrying out of scientific or
technical research shall not apply for or obtain, or cause or permit any other person to apply for or
obtain a patent for an invention made by such Government servant save with the permission of the
State Government and in accordance with such conditions as the State Government may
impose.F.R.48B. If a question arises whether a Government servant is a Government servant to
whom Rule 48-A applies, the decision of the State Government shall be final.
Chapter VI
Combination of AppointmentsF.R.49. The State Government may appoint the Government servant
to hold substantively, as a temporary measure, or to officiate in two or more independent posts at
one time. In such cases his pay is regulated as follows:(a)where a Government servant is formally
appointed to hold full charge of the duties of a higher post or posts which is or are in the same office
as his own and in the same cadre/line of promotion, in addition to his ordinary duties, he shall be
allowed the pay of the higher post, or the highest post of the holds full charge of more than one post,
in addition to ten per cent of the presumptive pay of the additional post or posts, if the additional
charge is held for a period exceeding 39 days:Provided that the concurrence of the Financial
Department shall be obtained for making such arrangement and for payment of the additional
pay;(b)where a Government servant is formally appointed to hold charge of higher post or posts
which is or are not in the same office or which though, in the same office, is or are not in the same
cadre/line of promotion, he shall be allowed the pay of the higher post or the highest post if he holds
charge of more tan one post, in addition to ten per cent of the presumptive pay of the additional post
or posts, if the additional charge is held for a period exceeding 39 days:Provided that the
concurrence of the Finance Department shall be obtained for making such arrangement and for
payment of the additional pay;(c)no additional pay shall be admissible to a Government servant who
is appointed to hold current charge of the routine duties of a higher post irrespective of the duration
of the additional charge ;(d)where a Government servant is formally appointed to hold dual charge
of two posts in the same cadre in the same office carrying identical scales of pay, no additional payFundamental Rules and Subsidiary Rules

shall be admissible irrespective of the period of dual charge :Provided that if the Government
servant is appointed to an additional post which carries a special pay, he shall be allowed such
special pay;(e)where a Government servant is allowed to perform duties of a lower post or posts no
additional pay shall be allowed for performing the duties of the lower post or posts ;(f)if
compensatory or sumptuary allowances are attached to one or more of the posts, the Government
servant shall draw such compensatory or sumptuary allowances as the State Government may fix
:Provided that such allowances shall not exceed the total of the compensatory and sumptuary
allowances attached to all the posts.
Chapter VII
Deputation Out of India
F.R.50. The Governor may sanction the deputation out of India of one or more Government servants
of the State for any duty connected with State affairs.Audit Instruction. - The period of the
deputation runs from the the date on which the Government servant makes over charge of his office
in India to the date on which he resumes it; or the Government servant is on leave out of India at the
time he is placed on deputation, the period of the deputation is the time actually occupied by
duty.Note. bee the Secretary of State's Order (2) below F.R.50 in Section III. The State Government
have decided to adopt a similar system for officers under their rule making control.Secretary of
State's Orders. - (1) Under sub-Rule (2) of Fundamental Rule 50 the Secretary of State directs that
the appointment of officers of the Indian Political Department on deputation for periods exceeding
12 months to posts under the control of the Foreign and Political Department outside India which
are not included in the duty strength of the Political Department cadre, may notwithstanding the
provisions of Fundamental Rule 50, be made by the President without prior reference to him.(2)The
terms of this rule must be interpreted as applying to cases where Officers exercise the option of
consuming leave and drawing an honorarium of l/6th of pay during a period of duty out of India,
i.e., this option can only be exercised by a Government servant whose deputation out of India, has
been approved by the proper authority vide Secretary of State's Order (iii) under Fundamental Rule
51.Note. The Secretary of State has decided to adopt the following system in dealing with cases
where Officers belonging to the All India Service who are on leave in United Kingdom attend
Conferences/Congresses there, or on the contingent, whether an official representative of the
President or of a Government, or as unofficial visitors-(1)officers who are nominated as official
representatives of the President or of a State Government will be placed on deputation for the period
involved and will receive the usual travelling expenses and subsistence allowance;(2)officers who are
not so nominated will not be placed on deputation, but if it is thought desirable that they should
attend as visitors, they may be offered travelling expenses and subsistence allowance as an
inducement for them to do so. Further though the officer is not an official representative, the India
Office, London, will be prepared to render him such service as recommending him as a visitor to the
Congress Authorities.F.R.51. (i) The following rules regulate the pay and allowances of members of
the State and Subordinate Services and of officers holding special posts when deputed to Europe or
America.They do not apply to cases governed by special rule e.g. Study Leave, etc.Pay(1)The pay
granted shall not exceed the pay which the officer would draw if he were on duty in
India.Allowances(2)Compensatory, travelling and halting allowances will be governed by the rulesFundamental Rules and Subsidiary Rules

in force at the time regulating the grant of such allowances to officers serving under the Secretary of
State, the Government of India or the High Commissioner for India, when on duty in Europe or
America :Provided that the State Government may in special cases allow second grade officers to
draw compensatory and halting allowances at such rates as they may deem suitable not exceeding
those admissible for first grade officers.Note. The provisions of F.R. 51 will also apply to officers
appointed on short term contract.(ii)The following rules shall regulate the deputation out of India of
subordinate police officers.The State Government may depute a subordinate police officer to any
country outside India, to accompany or take charge of criminals or lunatics, or on any other
business which is part of his duty as a police officer ; and may grant to the officer so deputed-(a)full
pay, for the entire period of absence from India ;(b)with actual travelling expenses, and a
subsistence allowance not exceeding the following scale, while in any country outside India :
 s.d.
For an officer of the Inspector class 226 a day
For an officer of the Seargent class 150 a day
For an officer of the Constable class   
The State Government may delegate its powers under this rule to officers of a rank not lower than
the Deputy Inspector General of Police.Note. The words "an officer of the Inspector class" referred
to in sub-Clause (b) include a Sub-Inspector.(iii)The grant of a return passage to India on
conclusion of a deputation is conditional on an officer's return to duty forthwith on the conclusion of
the deputation, unless an arrangement to the contrary effect should be specially permitted at the
time the deputation closes, or about to close, and the proposed leave begun.* * * * * *(iv)Officer
placed on deputation while leave out of India may, if average pay leave would otherwise be
admissible, covert deputation into leave on average pay plus an honorarium of 1/6th of Indian pay
on the condition that the cost of passage both from and to India borne by the officer.Periods of
deputation converted into leave should count for pension as leave and not as deputation.(v)Officers
subject to the leave rules in the Civil Service Regulation are eligible for the privilege of consuming
leave during depution, should they so desire, and of receiving an honorarium of 1/6th of their pay.
In their case leave on full pay would take the place of leave on average pay.F.R.51A. When a
Government servant is with proper sanction deputed for duty out of India to hold a regularity
constituted permanent or quasi permanent post, other than a post borne on the cadre of the service
to which he belongs, his pay shall be regulated by the orders of the Governor.
Chapter VIII
Dismissal, Removal and Suspension
F.R.52. The pay and allowances of a Government servant who is dismissed or removed from service
cease from the date of such dismissal or removal.F.R.53. (1) A Government servant under
suspension shall be entitled to the following payments, namely :(i)in the case of a Commissioned
Officer of the Indian Medical Department or a Warrant Officer in civil employ who is liable to revert
to military duty, the pay and allowances to which he would have been entitled had he been
suspended while in military employment:(ii)in the case of any other Government servant-(a)a
subsistence allowance at an amount equal to the leave salary which the Government servant wouldFundamental Rules and Subsidiary Rules

have drawn if he had been on leave or on half average pay or on half pay and in addition dearness
allowance based on such leave salary :Provided that where the period of suspension exceeds three
months, the authority which made or is deemed to have made the order of suspension shall be
competent to vary the amount of subsistence allowance for any period subsequent to the period of
the first three months as follows :(i)the amount of subsistence allowance may be increased by a
suitable amount, not exceeding 50 per cent of the subsistence allowance admissible during the
period of the first three months, if in the opinion of the said authority, the period of suspension has
been prolonged for reasons to be recorded in writing, not directly attributable to the Government
servant;(ii)the amount of subsistence allowance may be reduced by a suitable amount not exceeding
50 per cent of the subsistence allowance admissible during the period of first three months, if in the
opinion of the said authority the period of suspension has been prolonged due to reasons, to be
recorded in writing, directly attributable to the Government servant;(iii)the rate of dearness
allowance will be based on the increased or, as the case may be, decreased amount of subsistence
allowance admissible under sub-Clauses (i) and (ii) above;(b)any other compensatory allowances
admissible from time to time on the basic pay of which Government servant was in receipt of on the
date of suspension subject to fulfilment of other conditions laid down for drawal of such allowances
:Provided that the Government servant shall be entitled to the compensatory allowance unless the
said authority satisfied that the Government servant continues to meet the expenditure for which
they are granted.(2)No payment under sub-Rule (1) shall be made unless the Government servant
furnishes a certificate, that the Government servant is not engaged in any other employment,
business, profession or vocation.Administrative Instruction. - The above rule is applicable in the
case of both permanent and temporary Government servants. The subsistence allowance of work
charged establishment will be regulated under separate orders.This takes effect from 30th
November, 1961.State Government Memos Under F.R.53Grant of subsistence allowance to the
suspended State Government employee is governed by F.R. 53 (1) (ii), (a) which should be equal to
the amount which he would have got had he been on half average pay leave and in addition,
dearness allowance is admissible on this entitled pay subject to a maximum of Rs.500 under the
proviso (i), (ii), (iii), where there are provisions for reduction or increase in the subsistence
allowance rate in case suspension period prolongs beyond 12 months with corresponding variations
in dearness allowance rates. In its literal interpretation therefor the ad hoc dearness allowance will
have to be computed with effect from 1-1-1967 irrespective of the fact of suspension faced by a
particular employee from a date earlier to the, because had the employee been in service and
working he would have been entitled to his ad hoc dearness allowance provided of course his case
falls under admissible pay group i.e., maximum not exceeding Rs.750.[Refer to Notification No. BB
(II-3/67/Part 1/132 (a), dated the 27th June, 1967].Under Clauses (a) and (b) of sub-Rule (1) of this
rule a Government servant under suspension, draws dearness allowance and other compensatory
allowances in addition to subsistence allowance. The amount of dearness allowance and other
compensatory allowances is calculated on the amount of subsistence allowance actually drawn. In
other words, the rate of all allowances will be the same as if the subsistence allowances were pay of
the Government servants.If the question is as to whether it is open to the competent authority to
make further revision(s) and to vary the amount of subsistence allowance, after the first review has
been done in terms of the proviso to F.R.53 (1) (ii) (a) and if so, whether there is any restriction as to
the period after which the second or subsequent review can be made, the answer in precise would be
that although the proviso to F.R. 53 (1) (ii) (a) does not specifically provide for a second orFundamental Rules and Subsidiary Rules

subsequent review, there is, however, no objection to such a review being made by the competent
authority, who shall be competent to pass orders to increase or decrease the rate of subsistence
allowance up 50% of the amount of the subsistence allowance initially granted according to the
circumstances of each case and hence a second or subsequent review can be made at any time at the
discretion of the competent authority. It is also permissible to reduce the amount of subsistence
allowance or increase it on the basis of the first review, up to 50% of the amount of subsistence
allowance initially granted, if the period of the suspension has been prolonged for reasons directly
attributable to the Government servant by his adopting delatory tactics. And similarly in a case
where the amount of subsistence allowances has been reduced after the first review, the same can be
increased up to 50% of the amount initially granted, if the period of suspension has been prolonged
for reasons not directly attributable to the Government servant and the Government servant has
given up delatory tactics.[Refer to Government Notification No. FEG.27/60/99, dated the 20th
October, 1966].F.R.54. (1) When a Government servant who has been dismissed, removed or
compulsorily retired is re-instated as a result of appeal or review or would have been so re-instated
but for his retirement on superannuation while under suspension preceding the dismissal, removal
or compulsory retirement, the authority competent to order re-instatement shall consider and make
a specific order-(a)regarding the pay and allowances to be paid to the Government servant for the
period of his absence from duty including the period of suspension preceding his dismissal, removal
or compulsory retirement as the case may be ;(b)whether or not the said period shall be treated as a
period spent on duty.(2)Where the authority competent to order re-instatement is of opinion that
the Government servant who had been dismissed, removed or compulsorily retired has been fully
exonerated, the Government servant shall, subject to the provisions of sub-Rule (6), be paid the full
pay and allowances to which he would have been entitled had he not been dismissed, removed or
compulsorily retired or suspended prior to such dismissal, removal or compulsory retirement, as the
case may be:Provided that where such authority is of opinion that the termination of the
proceedings instituted against the Government servant had been delayed due to reasons directly
attributable to the Government servant, it may, after giving him an opportunity to make his
representation and after considering the representation, if any, submitted by him direct, for reasons
to be recorded in writing, that the Government servant shall, subject to the provisions of sub-Rule
(7), be paid for the period of such delay, only such proportion of such pay and allowances as it may
determine.(3)In the case falling under sub-Rule (2), the period of absence from duty including the
period of suspension preceding dismissal, removal or compulsory retirement, as the case may be,
shall be treated as the period spent on duty for all purposes.(4)In cases other than those covered by
Sub-Rule (2), including cases where the order of dismissal, removal or compulsory retirement from
service is set aside by the appellate or reviewing authority solely on the ground of non-compliance
with the requirement of Clause (2) of Article 311 of the Constitution and no further inquiry is
proposed to be held, the Government servant shall, subject to the provisions of sub-Rules (6) and (7)
be paid such proportion of the full pay and allowances to which he would have been entitled had he
not been dismissed, removed or compulsorily retired or suspended prior to such dismissal, removal
or compulsory retirement, as the case may be, as the competent authority may determine, after
giving notice to the Government servant of the quantum proposed and after considering the
representation, if any, submitted by him in that connection within such period which in no case
shall exceed sixty days from the date on which the notice has been served as may be specified in the
notice :Provided that any payment under this sub-rule to a Government servant other than aFundamental Rules and Subsidiary Rules

Government servant who is governed by the provisions of the Payment of Wages Act, 1936 (4 of
1936) shall be restricted to a period of three years immediately preceding the date on which orders
for re-instatement of such Government servant are passed by the appellate authority or reviewing
authority, or immediately preceding the date of retirement on superannuation of such Government
servant as the case may be.(5)In a case falling under sub-Rule (4), the period of absence from duty
including the period of suspension preceding his dismissal, removal or compulsory retirement, as
the case may be, shall not be treated as a period spent on duty, unless the competent authority
specifically direct that it shall be so treated for any specified purpose :Provided that if the
Government servant so desires such authority may direct that the period of absence from duty
including the period of suspension preceding his dismissal, removal or compulsory retirement, as
the case may be, shall be converted into leave of any kind due and admissible to the Government
servant.Note. The order of the competent authority under the preceding proviso shall be absolute
and no higher sanction shall be necessary for the grant of-(a)extraordinary leave in excess of three
months in the case of the temporary Government servant; and(b)leave of any kind in excess of five
years in the case of permanent or quasi-permanent Government servant.Note 2. In the case falling
under sub-Rr. (4) and (5) of F.R.54 the competent authority may pay such proportion of such pay
and allowances as is admissible under F.R.53 read with sub-Rule (7) F.R. 54 with prior concurrence
of Finance Department.(6)The payment of allowances under sub-Rule (2) or sub-Rule (4) shall be
subject to all other conditions under which such allowances are admissible.(7)The proportion of the
full pay and allowances determined under the proviso to sub-Rule (2) or under sub-Rule (1) shall
not be less than the subsistence allowance and other allowances admissible under Rule 53.(8)Any
payment made under this rule to Government servant on his re-instatement shall be subject to
adjustment of the amount, if any, earned by him through an employment during the period between
the date of removal, dismissal or compulsory retirement, as the case may be, and the date of
re-instatement. Where the emoluments admissible under this rule are equal to or less than the
amounts earned during the employment elsewhere, nothing shall be paid to the Government
servant.F.R.54A. (1) Where the dismissal, removal or compulsory retirement of a Government
servant is set aside by a Court of law and such Government servant is re-instated without holding
any further inquiry, the period of absence from duty shall be regularised and the Government
servant shall be paid pay and allowances in accordance with the provisions of sub-Rule (2) or (3)
subject to the directions, if any, of the Court.(2)(i)Where the dismissal, removal or compulsory
retirement of a Government servant is set aside by the Court solely on the ground of non-compliance
with the requirements of Clause (2) of Article 311 of the Constitution, and where he is not
exonerated on merits, the Government servant shall, subject to the provisions of sub-Rule (7) of
Rule 54, be paid such proportion of the full pay and allowances as to which he would have been
entitled had he not been dismissed, removed or compulsorily retired, or suspended prior to such
dismissal, removal or compulsory retirement, as the case may be, as the competent authority may
determine, after giving notice to the Government servant of the quantum proposed and after
considering the representation, if any, submitted by him, in that connection within such period, as
may be specified in the notice, which in no case shall exceed sixty days from the date on which the
notice has been served :Provided that any payment under this sub-rule to a Government servant
other than a Government servant who is governed by the provisions of the Payment of Wages Act,
1936 (4 of 1936) shall be restricted to a period of three years immediately preceding the date on
which the judgement of the Court was passed, or the date of retirement on superannuation of suchFundamental Rules and Subsidiary Rules

Government servant, as the case may be.(ii)The period intervening between the date of dismissal,
removal or compulsory retirement including the period of suspension preceding such dismissal,
removal or compulsory retirement, as the case may be, and the date of judgement of the Court shall
be regularised in accordance with the provisions contained in sub-Rule (5) Rule 54.(3)If the
dismissal, removal or compulsory retirement of a Government servant is set aside by the Court on
the merits of the cases, the period intervening between the date of dismissal, removal or compulsory
retirement including the period of suspension preceding such dismissal, removal or compulsory
retirement, as the case may be, and the date of re-instatement shall be treated as duty for all
purposes and he shall be paid the full pay and allowances for the period to which he would have
been entitled, had he not been dismissed, removed or compulsorily retired or suspended prior to
such dismissal, removal or compulsory retirement as the case may be.(4)The payment of allowances
under sub-Rule (2) or sub-Rule (3) shall be subject to all other conditions under which such
allowances are admissible.(5)Any payment made under this rule to a Government servant on his
re-instatement shall be subject to adjustment of the amount, if any, earned by him through an
employment during the period between the date of dismissal, removal or compulsory retirement
and the date of re-instatement. Where the emoluments admissible under this rule are equal to or
less than those earned during the employment elsewhere, nothing shall be paid to the Government
servant.F.R.54B. (1) When a Government servant who has been suspended is re-instated or would
have been so re-instated but for his retirement on superannuation while under suspension, the
authority competent to order re-instatement shall consider and make a specific order-(a)regarding
the pay and allowances to be paid to the Government servant for the period of suspension ending
with re-instatement or the date of his retirement on superannuation, as the case may be ;
and(b)whether or not the said period shall be treated as a period spent on duty.(2)Notwithstanding
anything contained in Rule 53, where a Government servant under suspension dies before the
disciplinary or Court proceedings instituted against him are concluded, the period between the date
of suspension and the date of death shall be treated as duty for all purposes and his family shall be
paid the full pay and allowances for that period to which he would have been entitled had he not
been suspended, subject to adjustment in respect of subsistence allowance already paid.(3)Where
the authority competent to order re-instatement is of the opinion that the suspension was wholly
unjustified, the Government servant shall, subject to the provisions of sub-Rule (8), be paid the full
pay and allowances which he would have been entitled, had he not been suspended :Provided that
where such authority is of the opinion that the termination of the proceedings instituted against the
Government servant had been delayed due to reasons directly attributable to the Government
servant, it may, after hearing the representation, if any, submitted by him, direct for reasons to be
recorded in writing, that the Government servant shall be paid for the period of such delay only such
proportion of such pay and allowances as it may determine.(4)In case a falling under sub-Rule (3)
the period of suspension shall be treated as a period spent on duty for all purposes.(5)In cases other
than those falling under sub-Rr. (2) and (3), the Government servant shall subject to the provisions
of sub-Rr. (8) and (9) be paid such proportion of the full pay and allowances to which he would have
been entitled had he not been suspended, as the competent authority may determine, after giving
notice to the Government servant of the quantum proposed and after considering the
representation, if any, submitted by him in that connection within such period which in no case
shall exceed sixty days from the date of the notice which has been served as may be specified in the
notice.(6)Where suspension is revoked pending finalisation of the disciplinary or Court proceeding,Fundamental Rules and Subsidiary Rules

any order passed under sub-Rule (1) before the conclusion of the proceedings against the
Government servant shall be reviewed on its own motion after the conclusion of the proceedings by
the authority mentioned in sub-Rule (2) who shall an order according to the provisions of sub-Rule
(3) or (5), as the case may be.(7)In a case falling under sub-Rule (5), the period of suspension shall
not be treated as period spent on duty, unless the competent authority specifically directs that it
shall be treated for any specified purpose :Provided that if the Government servant so desires, such
authority may order that the period of suspension shall be converted into leave of any kind due and
admissible to the Government servant.Note 1. The order of the competent authority under the
preceding proviso shall be absolute and no higher sanction shall be necessary for the grant
of-(a)extraordinary leave in excess of three months in the case of temporary Government servant;
and(b)leave of any kind in excess of five years in the case of permanent or quasi-permanent
Government servant.Note 2. In a case falling under sub-Rr. (5) and (7) of F.R.54-B, the competent
authority may pay such proportion of such pay and allowances as admissible under F.R.53 read with
sub-Rule (9) of F.R.54-B with prior concurrence of Finance Department.(8)The payment of
allowances under sub-Rule (3) or sub-Rule (5) shall be subject to all other conditions under which
allowances are admissible.(9)The proportion of the full pay and allowances determined under the
proviso to sub-Rule (3) or under sub-Rule (5) shall not be less than the subsistence allowance and
other allowances admissible under Rule 53.This will take effect from the date of issue of this
Notification i.e., 18th July, 1975.Administrative Instructions
1. A Government servant who is detained in custody under any law providing
for preventive detention or as a result of a proceeding either on a criminal
charge or for his arrest for debt shall if the period of detention exceeds 48
hours and unless he is already under suspension, be deemed to be under
suspension from the date of detention until further orders.
A Government servant who is undergoing a sentence of imprisonment shall also be dealt with in the
same manner pending a decision on the disciplinary action to be taken against him. In regard to his
pay and allowances the provisions of F.Rr. 53 and 54 shall apply.
2. A Government servant should be dismissed on conviction by the lower
Court, i.e., immediately on the termination of the first trial. The termination of
trial does not mean a decision of all the various appeals which are open to
the accused. Dismissal cannot be ordered retrospectively with effect from
the date of arrest.
3. A Government servant against whom a criminal charge or a proceeding for
arrest for debt is pending should also be placed under suspension by the
issue of specific orders to this effect during periods when he is not actually
detained in custody or imprisoned (e.g., while released on bail) if the charge
made or proceedings taken against him is of such nature as is likely toFundamental Rules and Subsidiary Rules

embarrass him in the discharge of his official duties or involves moral
turpitude. In regard to his pay and allowances the provisions of F.Rr. 53 and
54 shall apply.
4. A Government servant against whom a proceeding has been taken for his
arrest for debt but who is not actually detained in custody may be placed
under suspension only if a disciplinary proceeding against him is
contemplated.
5. When a Government servant who is deemed to be under suspension in the
circumstances mentioned in Clause (1) or who is suspended in
circumstances mentioned in Clause (3) is re-instated without taking
disciplinary proceeding against him, his pay and allowances for the period of
suspension will be regulated under F.R. 54 i.e, in the event of his being
acquitted of blame or (if the proceeding taken against him was for his arrest
for debt) or it being proved that his liability arose from circumstances
beyond his control or the detention being held by any competent authority to
be wholly unjustified,the case may be dealt with under F.R. 54-B (5).
6. It shall be the duty of a Government servant who may be arrested for any
reason to intimate the fact of his arrest and the circumstances connected
therewith to his official superiors promptly even though he might have
subsequently been released on bail. On receipt of the information from the
person concerned or from any other source the departmental authorities
should decide whether the facts and circumstances leading to the arrest of
the person call for his suspension. Failure on the part of any Government
servant to so inform him official superiors will be regarded as suspension of
material information and will render him liable to disciplinary action that may
be called for on the outcome of the police case against him.
7. An Officer under suspension is regarded as subject to all other conditions
of service applicable generally to Government servants and cannot leave the
station without prior permission. As such, the headquarters of a Government
servant should normally be assumed to be his last place of duty. Where an
individual under suspension requests for a change of headquarters, there is,
however, no objection to a competent authority changing the headquarters if
it is satisfied that such a course will not put Government to any extraFundamental Rules and Subsidiary Rules

expenditure like grant of Travelling Allowances etc. or other complications.
Government of AssamFinance Department : Establishment Branch
No. FEG.29/73/352 Dated Dispur, the 4th February, 1986
Office MemorandumSub-Revocation of Suspension Order-date of effect.Government have had
under consideration for quite some time past the question as to the date from which any order
revoking the suspension of Government servant should be given effect to. After careful
consideration of the matter in all its bearings, Government have decided as follows :(1)An order of
revocation of suspension shall take effect from a prospective date to be specified in the order of
revocation itself.(2)Such an order shall be served on the suspended Government servant in person
or communicated to him by registered post.(3)If the suspended Government servant at the time of
service of the order of revocation of suspension in person is residing in a station where he is
required to resume his duties on the specified date fails to do so on the specified date, then he shall
be deemed to be absent without authority within the meaning of F.R.17 from the specified date
mentioned in the revocation order unless the authority competent to grant him leave decides
otherwise.(4)If at the time of revocation of the suspension order, the suspended Government
servant is residing at a station elsewhere than his headquarters with the permission of the
appointing authority or he is transferred or posted at a new place/station then such joining time as
is admissible to Government servant on transfer shall be allowed if he resumes his duties within
such joining time from the date mentioned in the revocation order effecting revocation of
suspension, otherwise he shall be deemed to be absent without authority from the specified date
mentioned in the revocation order within the meaning of F.R.17 unless the authority competent to
grant him leave decides otherwise.(5)An order of revocation of suspension should also indicate the
station of posting of the Officer so that might go and assume charge of the office. If the order
revoking suspension does not indicate the place of posting he would not be in a position to assume
charge of any office though the suspension has been removed.(6)The date of revocation of
suspension is to be specified in the revocation order, should be fixed taking into consideration the
normal and usual time that will be required to reach the order in the hands of the Government
servant and also the practicability of joining within the specified date.This takes effect from the date
of issue of the orders and should be followed by all concerned scrupulously.Joint Secretary to the
Governmentof AssamFinance Esstt. (A) DepartmentF.R.55. Leave may not be granted to a
Government servant under suspension.Note. Officiating arrangement is permissible in place of
officers under suspension.
Chapter IX
Compulsory Retirement
F.R.56. (a) The date of compulsory retirement of a Government servant is the date on which he
attains the age of 55 years. He may be retained in service after this age with the sanction of the State
Government on public grounds which must be recorded in writing, and proposal for the retention of
a Government servant in service after his age should not be made except in very special
circumstances. The age of compulsory retirement of a Government servant has been raised to 58Fundamental Rules and Subsidiary Rules

years from 55 years vide Notification No. AAP/143/77/37, dated 18-7-1977.Notwithstanding
anything contained above, the retirement of Government employees should take effect from the
after-noon of the last day of the month in which the employee concerned attains the age of
superannuation.(b)Notwithstanding anything contained in these rules the appropriate authority
may, if he is of the opinion that it is in the public interest to do so, retire a Government servant by
giving him notice of not less than three months in writing or three months pay and allowance in lieu
of such notice after he has attained fifty years of age or has completed 25 years of service whichever
is earlier.(c)Any Government servant may, by giving notice of not less than three months in writing
to the appropriate authority, retire from service after he has attained the age of fifty years or has
completed 25 years of service, whichever is earlier.Note. The term 'appropriate authority' referred to
in the above clauses means the authority which has the power to make substantive appointments to
the post or service from which the Government servant is required or wants to retire.Note 1. This
rule does not apply to a Government servant who is appointed to be Chairman or a Member of the
Public Service Commission whose tenure of office and conditions of service are determined by
regulation made by Governor in his discretion in exercise of the powers conferred on him by
sub-Section (2) Section 265 and sub-Section (3) of Section 266 of the Act (Appendix 10).Note 2. The
grant, under F.R.86, of leave extending beyond the date on which a Government servant must
compulsorily retire or beyond the date up to which a Government servant has been permitted to
remain in service, shall not be treated as sanctioning an extension of service, and the Government
servant shall not be permitted to retain a lien on his permanent post or any other post during the
period of such leave.Note 3. The purpose of F.R.56 is not to confer upon Government servants any
right to be retained in service up to a particular age, but to prescribe the age beyond which they may
not be retained in service.Note 4. An inferior Government servant shall retire when he attains the
age of 60 years :Provided that such a Government servant appointed before the 1st April, 1936, may
continue in service until he ceases to be physically and mentally fit.Note 5. The term "appropriate
authority" referred to in the above clauses means the authority which has the power to make
substantive appointments to the post or service from which the Government servant is required or
wants to retire.Note 6. The competent authority for drawal of advance pay and allowances in respect
of Government employees both gazetted and non-gazetted to whom three months' pay is to be made
available in lieu of three months' notice on being compulsorily retired as envisaged in F.R. 56 (d) of
Assam Fundamental Rules and Subsidiary Rules shall be the controlling officer or the next higher
officer when the officer involved is his own controlling officer in respect of T.A. etc. The 'pay' so
allowed would be the pay he would have drawn had he continued in the post for the next three
months and be drawn in the Establishment Bills. Any outstanding Government dues in respect of
the officer shall be adjusted against this advance pay and from his/her gratuity as and when
sanctioned and the existing practice of pre-auditing of last pay bill in respect of retiring Government
employees shall not be applicable in respect of pay to be drawn in lieu of notice.The last pay
certificate of the officer should invariably be attached to the pay bill to be prescribed to treasury as
per aforesaid procedure.Audit Instruction. - When a Government servant is required to retire, revert
or cease to be on leave on attaining a specified age, the day on which he attains that age is reckoned
as a non-working day, and the Government servant must retire, revert or cease to be on leave, as the
case may be, with effect from and including that day. This rule applies to all Government
servants.F.R.57. [Deleted].Fundamental Rules and Subsidiary Rules

Part V – Chapter X
LeaveSection I-Extent of applicationF.R.58. Unless in any case it be otherwise distinctly provided in
Section VI of this Chapter, the rule in Sections I to V of this Chapter shall apply to all Government
servants to whom the Fundamental Rules as a whole apply ; provided that a Government servant
who elected the leave rule of Civil Service Regulations as they stood whether before or after the 29th
July, 1920 shall continue to be governed by those rules ; and provided further that the Leave Rules,
1934 (Appendix II) shall apply to the classes of persons specified therein.F.R.59. Leave is earned by
a Government servant under Sections I to V of this Chapter if he holds a lien or on a permanent post
in civil employ or would hold a lien on such a post had his lien not been suspended.S.R.59. - If an
officer in permanent service to whom the leave rules in this Chapter or the Leave Rules, 1934
(Appendix II-Part I), are applicable, is temporarily transferred to a work-charged establishment, he
does not forfeit any leave then at his credit, provided he retains a lien on a permanent appointment;
but the work charged service does not count towards leave :Provided that in case where a permanent
Government servant is transferred to a post in an identical scale of pay in the work-charged
establishment, in the interest of public service, he may be allowed to count the services rendered in
the work-charged establishment for the purpose of leave.F.R.60. Leave is earned by duty only. For
the purpose of this rule a period spent in foreign service counts as duty if contribution towards leave
salary is paid on account of such period.F.R.61. [Deleted].F.R.62. [Deleted],F.R.63.
[Deleted].F.R.64. Unless in any case it be otherwise expressly provided by or under these rules, a
Government servant transferred to a service or post to which these rules apply from a service or post
to which they do not apply is not ordinarily entitled to leave under these rules in respect of duty
performed before such transfer; but a Government servant reverting from duty as Judge of a High
Court may count such duty for leave as though it were duty performed in a vacation department, all
leave taken during the service concerned being treated as taken under these rules.Note. The
previous service of men in the Assam Rifles will not count for leave on their re-enlistment in the civil
police.F.R.65. (a) If a Government servant, who quits the public service on compensation or invalid
pension or gratuity, is re-employed and if his gratuity is thereupon refunded or his pension held
wholly in abeyance, his past service thereby becoming pensionable on ultimate retirement, he may,
at the discretion of the authority sanctioning the re-employment to such an extent as that authority
may decide, count his former service towards leave [See Article 138. (b), Assam Pension
Manual].(b)A Government servant who is dismissed or removed from the public service, but is
re-instated on appeal or revision, is entitled to count his former service for leave.Audit Instruction. -
Treatment for the purpose of leave of the previous service of a Government servant who resigns one
appointment to take up another appointment. - Resignation from the public service, even though it
is followed immediately by re-employment, should entail forfeiture of past service for the purpose of
leave under the Fundamental Rules and should therefore constitute an "interruption of duty" for the
purpose of S.R. 18.Section II-General conditionsF.R.66. The State Government may make rules
specifying the authorities by whom leave may be granted.Compensatory Leave to Local
AuditorsS.R.60. - When a local auditor by attending office during holidays is enable to complete an
audit before the due date, he may be granted compensatory leave by the Examiner, Local Accounts,
to the extent of one day for every whole day thus spent.Authorities empowered to grant leaveS.R.61.
- Any leave other than special disability leave and leave out of India, Ceylon, Nepal, Burma or Aden,
admissible under the Fundamental Rules may be grated to a non-gazetted Government servant byFundamental Rules and Subsidiary Rules

the authority whose duty it would be to fill up his post if it were vacant or by other competent
authority. [Appendix 12].S.R.62. - No leave may be granted to gazetted Government servant until a
report as to the admissibility of the leave has been obtained from the audit officer. On the receipt of
such a report, and leave, other than special disability leave, admissible under the Fundamental
Rules may be granted to a gazetted Government servant by a competent authority.Administrative
Instruction. - Unless specially otherwise ordered, leave granted under S.Rr. 61 and 62 must begin
within thirty- five days of the date on which it is sanctioned.F.R.67. Leave cannot be claimed as of
right. When the exigencies of the public service so require, discretion to refuse or revoke leave of any
description is reserved to the authority empowered to grant it.F.R.68. Leave ordinarily begins on the
day on which transfer of charge is effected and ends on the day preceding that on which charge is
resumed. When joining time is allowed to a Government servant returning from leave out of India,
the last date of his leave is the day before the arrival of the vessel in which he returns at her
moorings or anchorage in the port of disembarkation, if he returns by air, the day on which the
aircraft in which he returns arrives at its first regular port in India. The State Government may,
however, make rules defining the circumstances in, and the conditions on, which Sundays or other
recognised holidays may be prefixed to leave or affixed to leave or jointing time.Audit Instruction. -
The joining time of a Government servant who returns from leave out of India and disembarks, not
at the first port of call in India, but at another such part, should be reckoned from the day of arrival
of the vessel at the second or subsequent port at which he actually disembarks, whether the sea
journey from the first port of call in India to the subsequent port of disembarkation is made in the
same steamer which takes him to the first port of call or in some other steamer.Note. The provision
in the second sentence of this rule applies only to cases falling under F.R. 105 (c) in which joining
time is granted to Government servants returning from leave out of India more than four months
duration.Combination of holidays with leave and joining timeS.R.63. - When the day immediately
preceding the day on which a Government servant's leave begins or immediately following the day
on which his leave or joining time expires is a holiday or one of a series of holidays, the Government
servant may leave his station at the close of the day before, or return to it on the day following, such
holiday or series of holidays : provided that-(a)his transfer for assumption of charge does not
involve the handing or taking over of securities or of moneys other than a permanent advance;(b)his
early departure does not entail a corresponding early transfer from another station of a Government
servant to perform his duties;(c)the delay in his return does not involve a corresponding delay in the
transfer to another station of the Government servant who was performing his duties during his
absence or in the discharge from Government service of a person temporarily appointed to it.Note 1.
The provisions of proviso (a) apply both to the responsible officer and to the officer in executive
charge of Treasury.Note 2. The State should not be put to any extra expense in consequence of the
absence of a Government servant during holidays on casual leave.State Government's decision. -
Prefixing and suffixing holidays to leave, other than leave on Medical Certificate, shall be allowed
automatically except in cases where administrative reasons permission for prefixing/suffixing
holidays to leave is specifically withheld. In the case of leave on medical certified, if the day on which
an employee is certificate medically fit for rejoining duty happens to be a holiday, he shall be
automatically allowed to suffix such holiday(s) to his medical leave and such day(s) shall not be
counted as leave.S.R.63A. - When holiday(s) follow(s) joining time, the normal joining time be
deemed to have been extended to cover such holiday(s).S.R.64. - Compensatory leave granted by the
Examiner, Local Accounts, may be combined with regular leave as if it were a holiday.S.R.65. - OnFundamental Rules and Subsidiary Rules

condition that the departing Government servant remains responsible for the moneys in his charge,
a competent authority may declare that proviso (a) under S.R.63 is not applicable to any particular
case.S.R.66. - Unless the competent authority in any case otherwise directs-(a)if holidays are
prefixed to leave, the leave and any subsequent re-arrangement of pay and allowances take effect
from the first day after the holidays ; and(b)if holidays area affixed to leave or joining time, the leave
or joining time is treated as having terminated on, and any consequent re-arrangement of pay and
allowances takes effect from, the day on which the leave or joining time would have ended if
holidays had not been affixed.S.R.67. - In the case of District and Sessions Judges vacations will be
treated as recognised holidays. Such officers may combine vacation with leave ; provided that-(1)no
additional expense is incurred by the State for the period of vacation;(2)vacation is not both prefixed
and affixed to leave ;(3)when a vacation is taken in conjunction with leave on average pay in
combination with other leave, the total period of leave on average pay and vacation should not
altogether exceed eight months in the case of officers under the special leave rules and four months
in the case of officers under the ordinary leave rules.Note 1. District and Sessions Judges may avail
themselves of the Court vacation and may combine them with regular leave whenever such a
combination can be arranged so as to involve no additional expenditure, subject further to the
conditions (i) that suitable arrangement should in each instance be proposed by the District and
Sessions Judges concerned approved by the High Court, and made for the disposal during vacation
of any criminal work requiring attention, and (ii) that a District and Sessions Judge should obtain
the express permission of Government to avail himself without prejudice to his regular leave of so
much of the vacation as is not needed for the disposal of criminal business.Note 2. In the case of
Government servants not covered by this rule vacation cannot be treated as recognised holidays for
the purpose of F.R.68.F.R.69. (1) A Government servant on leave may not take any service or accept
any employment (including the setting up of a private professional practice as accountant,
consultant, or legal or medical practitioner) whether in or out of India without obtaining the
previous sanction of the State Government.(2)The leave salary of a Government servant who is
permitted to take up employment under a Government or a private employer during leave shall be
subject to such restrictions as the Governor of Assam may by order prescribe.Note 1. This rule does
not apply to casual literary work to service as an examiner or similar employment nor does it apply
to acceptance of foreign service, which is governed by Rule 110.Note 2. This rule does not apply
where a Government servant has been allowed to take up a limited amount of private practice and
service fees therefor as part of his conditions of service, e.g., where a right of private practice has
been granted to a Medical Officer.Note 3. The grant of leave preparatory to retirement to an officer
in foreign service may not be coupled with permission to continue in the service of the same
employer during that leave.Note 4. Though grant of permission to take up private employment
during the leave on medical certificate is technically covered by the provisions of F.R. 60, it is not
the intention that the leave which can be obtained on the strength of the medical certificate should
be allowed to a Government servant the state of whose health enables him to earn a competence by
private employment. Fundamental Rule 69 should not be construed as permitting a Government
servant who avails himself of leave on medical certificates to undertake regular employment during
such leave.Government of India's decisions. - (1) Under the orders now in force, Government
servants who are permitted to accept private employment during leave preparatory to retirement
continue to get their leave salary, while those are employed by Government in a department other
than their own and draw leave salary in addition to pay, have their leave salary restricted to theFundamental Rules and Subsidiary Rules

anticipated amount of their pension ; and those who are employed in their own departments are
treated as having been recalled from leave and thus forego their leave and leave salary except to the
extent admissible under F.R.86. The question of removing these disparities to the extent possible,
and suitably limiting the period for which a Government servant may be permitted to draw leave
salary in addition to the pay of the post in which he is employed during leave preparatory to
retirement has been under consideration for some time. The President has now decided that, in
supersession of all previous orders on the subjects, such cases will be regulated in the following
manner :(a)When a Government servant who has proceeded on leave preparatory to retirement
before the date of compulsory retirement is required for employment during such leave in any post
under the Central Government, in a outside India, and he is agreeable to return to duty, he will be
recalled to duty and the unexpired portion of his leave from the date of re-joining duty will be
cancelled. The leave so cancelled will be treated as refused and subject to the provisions of F.R.86, it
may be granted from the date of compulsory retirement of the Government servant. Such recall will
be treated as optional for the purpose of F.R.70.(b)When a Government servant is employed in any
post under the Central Government, while he is on leave under F.R. 86, he may continue to enjoy his
leave concurrently with such employment but his salary, which may be drawn in addition to pay of
the post in which he is employed, will be restricted as follows :(i)in the case of Government servant
eligible for pension, the amount of pension inclusive of pension equivalent of any retirement
gratuity admissible under the new pension scheme which, it is anticipated will be admissible to him
on retirement. No subsequent re-adjustment will be made on the basis of the actual amount of
pension inclusive of gratuity finally sanctioned ; and(ii)in the case of a Government servant not
eligible for pension, to the leave salary admissible in respect of leave on half average pay.In respect
of the fresh employment during leave, the pay of the Government servant will be regulated as if he
were a post-1931 entrant in temporary employ. No leave will be earned in respect of such period of
employment during leave.During such employment, he may also be granted dearness and
compensatory allowances, if any, admissible on the basis of pay. These allowances will neither be
admissible on leave salary, nor will the leave salary be taken into account in calculating the
allowances.(c)The leave salary of a Government servant who is permitted, during leave preparatory
to retirement before attaining the age of superannuation, or during leave under F.R.86, to take up
employment under a State Government, or under a private employer or employment payable from a
Local Fund, will also be restricted during such employment as in (b) above.(2)These orders will also
apply to officers who were initially appointed by the Secretary of State in Council by the Secretary
State, and who may be employed during leave preparatory to retirement except that when any such
officer accepts Crown employment outside India and Pakistan, the expression 'Crown employment'
being taken to mean employment under the Government of the United Kingdom or under the
Government of any of its Dominions, Colonies of Protectorates, the restrictions on leave salary will
not apply.(3)Cases in which officers on leave preparatory to retirement may have already been
permitted to accept employment on a basis different from that prescribed above will not be
affected.(4)These orders will also apply mutatis mutandis to Government servant subject to leave
rules other than those contained in the Fundamental Rules.Decision by the Government of Assam. -
The Government of Assam have adopted the above decision in respect of Government servant under
their rule making control.F.R.70. All orders recalling a Government servant to duty before the expiry
of his leave should state whether the return to duty is optional or compulsory. It if is optional, the
Government servant is entitled to no concession. If it is compulsory, he is entitled-(a)if the leaveFundamental Rules and Subsidiary Rules

from which he is recalled is out of India-(i)to receive a free passage to India ; and provided that he
has not completed half of the period of his leave by the date of leaving for India's on recall of three
months, whichever period is shorter, to receive a fund of the cost of his passage from India ;(ii)to
count the time spent on the voyage to India as duty for purposes of calculating leave ; and(iii)to
receive salary during the voyage to India, and for the period from the date of landing in India to the
date of joining his post to be paid leave salary at the same rate at which he would have drawn it had
he not been recalled but returned in the ordinary course on the termination of the leave, and for the
latter period travelling allowance under the rules made in that behalf under Rule 44.Audit
Instruction. - The expression "on the termination of his leave" in Clause (a) (iii) of F.R.70 means "on
the termination of the period of leave as determined by his recall as opposed to the whole of the
leave he was originally granted". The effect of this interpretation will be to make the same leave
salary admissible for the period of transit in India as would be admissible had the return to duty
been voluntary and the period of voyage been leave proper and period of transit in India been leave
proper or joining time under F.R. 105, as the case may be;(b)if the leave from which he is recalled in
India, to be treated as on duty from the date on which he starts for the station to which he is
ordered, and to draw travelling allowance under rules made in this behalf under Rule 44 for the
journey, but to draw until he joins post leave salary only.Interpretation. - The 'concession' referred
to in the second sentence of F.R. 70 is a concession of the category permitted by that rule. The
concessions under F.R. 70 are clearly not intended to effect the privileges of Government servants
which are admissible under other rules ; the concessions may be availed of when they happen to
prove additional to, or better than the ordinary privileges.Note 1. In all cases of recalling an officer
from leave out of India the orders should be communicated to him through the High Commissioner
for India and should state whether return to duty is optional or compulsory as required by the
rule.Note 2. For rules relating to travelling allowance admissible under this rule, see S.Rr. 269 and
270. .F.R.71. No Government servant who has been granted leave on medical certificate may return
to duty without first producing a medical certificate of fitness in such form as the State Government
may by order prescribe. The State Government may require a similar certificate in the case of any
Government servant who has been granted leave for reasons of health, even though such leave was
not actually granted on a medical certificate.Audit Instruction. [Omitted].Auditor General's
decision. [Omitted].Note. The Government of Assam have decided that the provisions of F.R.71
being mandatory and not permissive, the production of a certificate of fitness is essential before a
Government servant rejoins his duties on the expiry of leave on medical certificate.S.R.68. - A
Government servant who has taken leave on a medical certificate out of Asia elsewhere than in
Europe, North Africa, America or the West Indies, may not return to duty until he has produced a
medical certificate of fitness from two medical practitioners in the following form :"We certify that
we have carefully examined CD, of the Department..... and find that he is in good health and fit to
return to his duty in India."Date..........Place........."If the certificate be signed by foreigners, it should
be attested by Consular or other authority as bearing the signatures of qualified medical
practitioners.S.R.69. - A Government servant who has taken leave in Asia on medical certificate may
not return to duty until he has produced a medical certificate of fitness in the following form
:Signature of applicantWe the members of a Medical Board...............I....... Civil Surgeon of
..................../registered medical practitioner of......... do hereby certify that we/I have carefully
examined ABC of the department...... whose signature is given above, and find that he has recovered
from his illness and is now fit to resume duties in Government service. We/I also certify that beforeFundamental Rules and Subsidiary Rules

arriving at this decision we/I have examined the original medical certificate(s) and statement(s) of
the case or certified copies thereof on which leave was granted or extended and have taken into
consideration in arriving at our/my decision.If the Government servant on leave is a gazetted
officer, such certificate should be signed by a Medical Board except (1) in cases in which the leave is
for not more than three months ; or (2) in cases in which the leave is for more than three months,
but the Medical Board granting the original certificate or the certificate for extension state at the
time of granting such certificate that the Government servant need not appear before another Board
for obtaining the certificate of fitness to return to duty.Note. A certificate under S.R. 88 is equivalent
for all practical purposes to a certificate from a Medical Board and such cases are not excluded from
the operation of the decision mentioned above.If the Government servant on leave is not a gazetted
officer, a certificate from a Civil Surgeon or any lower medical authority or from a registered medical
practitioner may, in its discretion, be accepted by the authority under which the Government
servant will be employed on return from leave : but the certificate should invariably state that the
officer signing the certificate has examined the medical certificate on which the leave was originally
granted.F.R.72. (1) A Government servant on leave may not return to duty before the expiry of the
period of leave granted to him, unless he is permitted to do so by the authority which granted him
leave.(2)Notwithstanding anything contained in sub-Rule (1) a Government servant on leave
preparatory to retirement shall be precluded from withdrawing his request for permission to retire
and from returning to duty, save with the consent of the authority empowered to appoint
him.F.R.73. A Government servant who remains absent after the end of his leave is entitled to no
leave-salary for the period of such absence, and that period will be debited against his leave account
as though it were leave on half average pay, unless his leave is extended by the authority competent
to grant the leave (Serial 8 of Appendix 1). Wilful absence from duty after the expiry of leave may be
treated as misbehaviour for the purpose of Rule 15.President's DecisionIn the case of Government
servant, governed by the Revised Leave Rules, 1934 who remains absent after the end of his leave
the period of such over-stayal of leave should, unless the leave is extended by the competent
authority be treated as follows :-(a)If the officer is in superior service-(i)as leave on private affairs to
the extent such leave is due, unless the over the-stayal is supported by a medical certificate ;(ii)as
leave on medical certificate to the extent such leave is due, if the over-stayal is supported by medical
certificate;(iii)as extraordinary leave to the extent the period of leave due on private affairs and/or
on medical certificate falls short of the period of over-stayal;(b)if the officer is in inferior service-as
in (a) (ii) and (iii) above mutatis mutandis.The Government servant is not entitled to leave salary
during such over-stayal of leave not covered by an extension of leave by the competent
authority.[The Government of Assam have adopted the above decision in the cases of their officers
subject to the Revised Leave Rules, 1934].F.R.74. Subject to any directions which may be given by
the Auditor-General of India in order to secure efficiency and uniformity of audit, the State
Government may make rules prescribing the procedure to be followed by in and out of India-(i)in
making application for leave and for permission to return from leave;(ii)in granting leave ;(iii)in the
payment of leave-salary ; and(iv)in the maintenance of record of service.Note. Appendices 13 and 14
contain respectively the rules made (1) by the Auditor-General of India ; and (2) by the President
prescribing the procedure to be followed elsewhere than in India.The latter rules have also been
adopted by the State Government as applicable to persons serving in connection with the affairs of
the State.Leave AccountsS.R.70. - The leave account required by F.R. 76 shall be maintained in such
form as the Auditor-General of India may prescribe.Note. The form prescribed by theFundamental Rules and Subsidiary Rules

Auditor-General of India for leave account of Government servant under the ordinary leave rules in
Assam Fundamental Rules, Form No. 1.S.R.71. - The leave account of a gazetted Government
servant shall be maintained by, or under the direction of the Accountant General, Assam.S.R.72. -
The leave account of a non-gazetted Government servant shall be maintained by the head of the
office in which he is employed.Explanation. - No leave account need be maintained for the members
of the Coolie Corps establishments in the Sadia and Balipara Frontier Tracts.Application for
leaveS.R.73. - Except is provided in S.Rr. 74 and 75 an application for leave or for an extension of
leave shall be made to the authority competent to grant such leave or extension through the
immediate superior, if any. Application for leave should be submitted in Assam Fundamental Rules,
Form No. 2.S.R.74. - Where the authority competent to grant the leave is the Government, the
application for leave shall be forwarded through the ordinary channel to the Commissioner of
Divisions or the head of the Department, who after recording his recommendations will forward the
application to the Comptroller for submission to Government with the report required under S.R.
62.S.R.75. - An application by a Commissioned Medical Officer in permanent or temporary civil
employ for leave exceeding four months, other than leave on medical certificate, or for an extension
of such leave, must be submitted to the local Administrative Medical Officer, by whom it will be
forwarded to the Director General, Indian Medical Service. The Director General will countersign
the application if the state of public service admits of the grant of the leave ; otherwise he will
abstain from countersigning it. In either case he forward the application for disposal of the authority
competent to grant the leave.S.R.76. - A Government servant transferred to foreign service must,
before taking up his duties in foreign service, make himself acquainted with the rules or
arrangements which will regulate his leave during such service.Medical CertificatesS.R.77. - Medical
Officers must not recommend the grant of leave in any case in which there appears to be no
reasonable prospects that the Government servant concerned will ever be fit to resume his duties. In
such cases, the opinion that the Government servant is permanently unfit for Government service
should be recorded in the medical certificate.S.R.78. - Every certificate of a Medical Committee or a
Medical Officer recommending the grant of leave to a Government servant must contain a proviso
that no recommendation contained in it shall be evidenced of a claim to any leave not admissible to
the Government servant under the terms of his contract or of the rules to which he is subject.S.R.79.
- Before a gazetted Government servant can be granted leave or an extension of leave on medical
certificate, he must obtain a certificate in the following form from Civil Surgeon of the district in
which he resides, or, if he is unable to travel for the purpose, from the Civil or Presidency Surgeon of
the district where he is at the time. If in exceptional circumstances, the applicant cannot be
examined by a Civil or Presidency Surgeon, the Civil Surgeon of the district in which he ordinarily
resides may countersign a certificate granted by the medical attendant (if he is an approved
registered medical practitioner) of the applicant, after satisfying himself that the conditions are
fulfilled.Medical Certificate for Gazetted OfficersStatement of the case of..........Name (to be filled in
by the applicant in the presence of the Civil Surgeon or official medical
attendant).Appointment.........Age.....Total service.......Service in India.........Previous periods of leave
of absence on medical certificate..........Habits......Disease........I,..................Civil Surgeon of/Medical
Officer at or of.....................after careful personal examination of the case hereby certify
that............... is in a bad state of health and I solemnly and sincerely declare that according to the
best of my judgement a period of absence from duty is absolutely necessary for the recovery of his
health and recommend that he may be granted month leave with effect from...........Civil SurgeonorFundamental Rules and Subsidiary Rules

Official Medical AttendantDated the.........Note 1. This form should be adhered to as closely as
possible and should be filled in after the signature of the applicant has been taken. The certifying
officer is not at liberty to certify that the applicant requires a change from or to a particular locality,
or that he is not fit to proceed to a particular locality. Such certificates should only be given at the
explicit desire of the administrative authority concerned to whom it is open to decide when
application on such ground has been made to him, whether the applicant should go before a Medical
Board to decide the question of his fines for his service.Note 2. The term "Approved Registered
Medical Practitioner" mentioned in this rule includes approved registered Ayurvedic Physicians
under the employment of the Government and who are diploma holders.We do hereby certify that
according to the best of our professional judgement after careful personal examination of the case,
we consider the health of........ to be such as to render him leave of absence for a period of.......
absolutely necessary for his recovery.Dated......... The...........PresidentMembersThe certificate which
shall be prepared in duplicate should be accompanied by a separate statement, also in the duplicate,
of the Government servant's case in approved form. One copy of the certificate and of the statement
shall be made over to the Government servant concerned for presentation to the Medical Board
which examines him for fitness for return to duty.S.R.80. - A gazetted Government servant shall
before applying for the certificate prescribed in Rule 79 from a Civil or Presidency Surgeon obtain
the permission of the head of the office or department in which he is serving. When a certificate has
been granted he shall, if the leave recommended is for a period exceeding two months, apply for the
orders of the head of office of department to appear before a Medical Board, and present himself
before such a Board when so directed. The head of the office or department shall forward to the
Board the certificate and copies of the statement of case on receipt of orders for the assembling of
the Board. The Board will be assembled under the order of the Administrative Medical Officer of the
State in which the Government servant is serving, who will, where practicable, preside over it. The
Board will be assembled either at the headquarters of the State or at such other place as the State
Government may appoint.S.R.81. - Before the head of the office or department may grant leave or
extension of leave for a period exceeding two months he must obtain from the Board a certificate to
the following effect, save as provided in Rule 83.Note. In the case of leave for a period not exceeding
two months the certificate prescribed in S.R. 79 shall be considered sufficient.FormWe do hereby
certify that....... according to the best of our professional judgement, after careful personal
examination of the case, we consider the health of CD to be such as to render leave of absence for a
period of...... months absolutely necessary for his recovery.S.R.82. - Before deciding whether to
grant or refuse the certificate the committee may, in a doubtful case, detain the applicant under
professional observation for a period not exceeding fourteen days. In this case it should grant to him
a certificate to the following effect:"CD having applied to us for a medical certificate recommending
the grant to him of leave, we consider it expedient, before granting or refusing such a certificate to
detain CD under professional observation for.....days".S.R.83. - If the state of the applicant's health
is certified by a Commissioned Medical Officer of Government or by a Medical Officer-in-charge of a
civil station to be such as to make it inconvenient for him to present himself to any place in which a
committee can be assembled, the authority competent to grant the leave may accept, in lieu of the
certificate prescribed in S.R. 81, either-(1)(a)a certificate signed after personal examination by the
Civil Surgeon of the district;ORby the Sub-divisional Medical Officer of the sub-division and
countersigned by the Civil Surgeon of the District, where the officer is serving; or(b)a certificate
signed by a Civil or Presidency Surgeon or a Medical Officer-in-charge of a sub-division other thanFundamental Rules and Subsidiary Rules

the Civil Surgeon or Medical Officer of the district or sub- division where the officer is serving, and
countersiged by the District Officer of the district where the officer is serving ;(c)notwithstanding
anything contained in sub-Rule. (1) the authority competent to sanction leave may dispense with the
procedure laid down in Rr. 80 and 81-(i)where the leave recommended by the authorised medical
attendant is for a period exceeding two months and he certifies it in his opinion it is necessary for
the applicant to appear before a Medical Committee; or(ii)the applicant is undergoing treatment in a
hospital as an indoor patient and the leave is recommended by the Medical Officer-in-charge of the
case in the hospital not below the rank of Civil Surgeon or Staff Surgeon for the period of
hospitalisation or convalescence. [Sub-rule (2) not printed or inserted]S.R.84. - The grant of a
certificate under S.R. 81 or 83 does not itself confer upon the Government servant concerned any
right to leave. The certificate should be forwarded to the authority competent to grant the leave, and
the orders of that authority should be awaited.S.R.85. - An application by a non-gazetted
Government servant in superior service for leave or for an extension of leave on medical certificate
must be accompanied by a certificate in the following form from the Civil Surgeon of the district
where the applicant resides or from the Presidency Surgeon if the applicant is in a Presidency town,
unless it is specially certified that the applicant is too ill to bear the journey, in which case the Civil
Surgeon or Presidency Surgeon may exercise his discretion and countersign or refuse to countersign
a medical certificate from an approved registered medical practitioner. In the event of the Civil or
Presidency Surgeon refusing to countersign a medical certificate, they should arrange for the
applicant to be examined at his residence by a Medical Officer of Government.Such certificate
should distinctly state the nature of the illness, its symptoms, probable causes and duration, the
period of absence from duty considered to be absolutely necessary for the restoration of the
applicant's health. The certificate shall be prepared in a duplicate one copy made over to the
Government concerned for presentation to the Medical Officer who examines him for fitness for
return to duty.The authority competent to grant the leave may, however, in its discretion accept a
certificate from the applicant's medical attendant without such countersignature ; if the applicant be
a female, may either dispense with counersignature or accept the countersignature of any female
medical practitioner.The authority competent to sanction leave may at its discretion call for a
second medical opinion. In such cases too the certificate shall be prepared in duplicate and dealt
with in the manner laid down in sub-paragraph 2 above.The possession of a certificate such as is
prescribed in this rule does not in itself confer upon the Government servant concerned any right to
leave.FormMedical certificate for non-Gazetted Officers recommended for leave or extension or
commutation of leaveSignature of applicant.........I,............ after careful examination of.........the case
hereby certify that......whose signature is given above, is suffering from........ and I consider that a
period of absence from duty of....... with effect from....... is absolutely necessary for the restoration of
his health.Dated....The.....Government Medical attendant orother registered
practitionerThe......Note 1. The nature and probable duration of the illness should be specified.Note
2. This form should be adhered to as closely as possible, and should be filled in after the signature of
the applicant has been taken. The certifying officer is not at liberty to certify that the applicant
requires a change to (or from) a particular locality, or that he is not fit to proceed to a particular
locality. Such certificates should only be given at the explicit desire of the administrative authority
concerned, to whom it is open to decide, when an application on such grounds has been made to
him, whether the applicant should go before a Medical Board to decide the question of his fitness for
service.Note 3. The term "Approved Registered Medical Practitioner" mentioned in this ruleFundamental Rules and Subsidiary Rules

includes approved registered Ayurvedic Medical Physicians under the employment of Government
and who are diploma holders also.Second Medical Opinion (if called for by the authority competent
to sanction leave)Agency or Civil SurgeonNote. Should a second medical opinion be required the
leave sanctioning authority should arrange for the second medical examination to be made at the
earliest possible date. The Agency or Civil Surgeon's opinion, both as to the facts of illness and the
necessity of the amount of leave applied for, should be recorded. He may require the applicant to
appear before him or before Medical Officer nominated by him.S.R.86. - No application should be
made for a medical certificate to a Medical Officer of Government and no certificate should be
submitted for his countersignature without the cognizance of the head of the office in which the
applicant is serving. For this purpose the correct procedure is to play through the head of the
office.S.R.87. - No application for extension of leave will ordinarily be considered by the head of the
office in which the applicant is serving unless the application is received by him at least one week
before the termination of the leave already granted.S.R.88. - In support of an application for leave,
or for an extension of leave, on medical certificate from a non-gazetted Government servant in Class
IV service, the authority competent to grant the leave may accept such certificate as it may deem
sufficient.S.R.89. - Leave of absence cannot be claimed as of right. A competent authority may
refuse, or revoke, leave of absence at any time according to the exigencies of the public service and
may also refuse to the full amount of leave applied for in any case.S.R.90. - In case where all
applications for leave cannot, in the interests of the public service be granted, an authority
competent to grant leave should in deciding which application should be granted, take into account
the following considerations:(a)the Government servants who can, for the time being, best be spared
;(b)the amount of leave due to the various applicants ;(c)the amount and the character of service
rendered by each applicant since he last returned from leave ;(d)the fact that any such applicant was
compulsorily recalled from his last leave;(e)the fact that any such applicant has been refused leave
in the public interest.S.R.91. - Where a Medical Committee in India has reported that there is no
reasonable prospect that a particular Government servant will ever be fit to return to duty, leave
should not necessarily be refused to such a Government servant. It may be granted, if due by a
competed authority on the following conditions :(a)If the Medical Committee is unable to say with
certainty that the Government servant will never be fit for service in India again, leave not exceeding
twelve months in all may be granted. Such leave should not be extended without a further reference
to a Medical Committee.Note. In the case of a Government servant who is granted leave under this
rule and who subsequently returns to duty, the leave should be treated as leave on medical
certificate for the purpose of the proviso to F.R. Rule 81 (b) (ii);(b)If the Medical Committee
declares the Government servant to be completely and permanently incapacitated for further service
the Government servant should, except as provided in Clause (c) below be invalidated for the
service, either on the expiration of the leave already granted to him, if he is on leave, when examined
by the committee, or if he is not leave, from the date of the committee's report;(c)A Government
servant declared by a committee to be completely and permanently incapacitated may, in special
cases, be granted leave, or an extension of leave not exceeding six months is debited against the
account, if such leave be due to him. Special circumstances justifying such treatment may be held to
exist when the Government servant's break down in health has been caused in and by Government
service, or when the Government servant has taken a comparatively small amount of leave during
his service, or will complete at an early date an additional year's service for pension.S.R.92. - Leave
should not be granted to a Government servant who ought at once to be dismissed or removed fromFundamental Rules and Subsidiary Rules

Government service for misconduct or general incapacity.S.R.93. - If, in a case not covered by S.R.
92, an authority competent to remove a Government servant from service decides before such
Government servant departs from India on leave, that he will not be permitted to return to duty in
India it must inform him to that effect before he leaves India.S.R.94. - If, when a Government
servant is about to depart from India on leave, it is necessary to consider the propriety of removing
him for incapacity, whether mental or physical which is of such nature that it is impossible to
decide, before he leaves India, whether it will be permanent or temporary-or if for any reason it is
considered inexpedient that a Government servant on leave should return to India, full report of the
circumstances must be made by the State Government to the India Office in time to enable the
Secretary of State to take any necessary measures before the Government servant would, in the
ordinary course, be permitted to return to duty. The report should in any case reach the India Office
at least three months before the end of the Government servant's leave.S.R.95. - When leave on
medical certificate has been granted to a Government servant or, in the case of a military officer in
civil employ when the grant of such leave has appeared in orders, if such Government servant or
military officer proposes to spend his leave in Europe, North Africa, America or the West Indies,
State Government must without delay forward a copy of the medical statement of the case to the
High Commissioner for India.S.R.96. - When a Government servant who has been granted leave for
reasons of health proceeds to any of the localities named in S.R. 95 the authority which granted the
leave shall inform the High Commissioner for India whether a medical certificate of fitness to return
to duty is required under the second sentence of F.R. 71.Departure on leaveS.R.97. - Every
Government servant proceeding on leave out of India should procure from the audit office and take
with him a copy of the memorandum of information issued for the guidance of Government servants
proceeding on leave out of India. If the leave has been granted on a medical certificate, he must take
a copy of the medical statement of his case also.S.R.98. - A Gazetted Government servant taking
leave out of India must report his embarkation, through the audit office, to the authority which
granted his leave, in such form as the Auditor-General may prescribe.Return from leaveS.R.99. - A
Government servant on return from leave, must report his return to the Government under which
he is serving.S.R.100. - A Government servant returning from leave is not entitled, in the absence of
specific orders to that effect, to resume as matter of course the post which he held before going on
leave. lie must report his return to duty and await orders.Payment of leave salaryS.R.101. - A
Government servant on leave, who does not leave his district does not require a last pay certificate,
nor does an officer who leaves his district on leave without allowances.Note. Other rules on the
subject will be found in paragraphs 6-12 of the instructions issued by the Auditor-General of India
under F.R. 74, vide Appendix 13.Record of serviceGazetted Government servantS.R.102. - A record
of the service of gazetted Officers should be maintained by the audit officer who audits their pay.
When an officer passes from one audit circle to another, a record of his past service should be passed
on from the audit officer whose circle he leaves to the audit officer to whose circle he is
transferred.S.R.103. - When a Gazetted Officer is transferred to foreign service a copy of his service
register will be sent by the audit officer whose duty it was to keep it, to the audit officer who will
account for the contribution and the latter will return the register (or an extract from it) duly written
up-to-date when the officer is re-transferred.S.R.104. - With exception of (I) of non-Gazetted
Government servants the particulars of whose service are recorded in the History of Service of
Gazetted and other officers, maintained by the Audit Officer, (II) all Government servants in
superior service on scales of pay the maximum of which does not exceed Rs.24, (III) inferiorFundamental Rules and Subsidiary Rules

servants of all sorts, (IV) Police Officers of and below the rank of Inspector, (V) Havidars of the
Assam Rifles who are in receipt of pay in excess of Rs.20, (VI) Keepers of the Mental Hospital at
Tezpur, (VII) Jail Wardens, and (VIII) Assistant Forest Officers and Forest Guards, a Service Book
should be kept at the cost of Government for every non-Gazetted Government servant holding a
substantive appointment on a permanent establishment in which every step in his official life should
be recorded, each entry being attested by the head of his office. If the Government servant is himself
the head of an office the attestation should be made by his immediate superior. The head of the
office should see that all entries in the service book are duly made and attested. There should be no
erasure or over-writing, all corrections being neatly made and properly attested.Note 1. Circle
Sub-Deputy Collectors are heads of offices for the custody of the service books of mandals or
patwaris only.Note 2. Annual establishment return should be submitted to the Audit Office in the
case of police officers of the rank of Inspector and Sub-Inspector.S.R.105. - Service book must be
kept in the custody of the heads of offices in which the Government servants are serving and
transferred with them from office to office. A certified copy of the service book may be supplied to
the Government servants on payment of a copying fee of Rs. 5, on quitting Government service by
retirement, discharge or resignation.S.R.106. - It shall be the duty of every head of office to initiate
action to show the service books to Government servants under this administrative control, every
year and to obtain their signature therein in token of their having inspected the service book. A
certificate to the effect that he has done so in respect of the financial year should be submitted by
him to his next superior officer by the end of every September. The Government servant inter alia
ensures before affixing his signature that his service books have been duly verified and certified as
such. In case of a Government servant on foreign service, his signature shall be obtained in his
service book after the Audit Officer has made therein necessary entries connected with his foreign
service.S.R.107. - Personal certificates of character should not, unless the Government so direct, be
entered in the service book, but if the Government servant is reduced to a lower substantive
appointment, the case of the reduction should always be briefly stated thus "Reduced for
inefficiency", "Reduced owing to revision of establishment, etc."S.R.108. - Every period of
suspension from employment and every other interruption in service should be noted, with full
details of its duration, by an entry written across the page and attested by the head of the office or
other attesting officer. The head of the office should take efficient measures to see that these entries
are made with regularity. The duty should not be left to the non-Gazetted Government servant
concerned.S.R.109. - When a non-Gazetted Government servant is transferred whether permanently
or temporarily from the office to another, the necessary entry of the nature of the transfer should be
made in his service book which after being duly verified to date and attested by the head of the office
should be transmitted to the head of the office to which the Government servant has been
transferred who will thenceforward have the book maintained in his office.S.R.110. - When a
non-Gazetted Government servant is officiating in a gazetted post, his service book should be kept
by the head of office to which he permanently belongs, but when he takes leave while so officiating,
his service book should be forwarded to the audit officer of reporting admissibility of the leave.
When he is confirmed the service book should be permanently sent to the audit office.S.R.111. - If
the Government servant is transferred to foreign service the head of the office or department should
send his service book to the audit officer who will return it after noting therein, under his signature,
the order of Government sanctioning the transfer, the effect of the transfer in regard to leave
admissible during foreign service and any other particular which the audit officer may consider to beFundamental Rules and Subsidiary Rules

necessary in connection with the transfer. On the Government servant's re-transfer his service book
should again be sent to the audit officer who will then note therein under his signature all necessary
particulars connected with the Government servant's foreign service.S.R.112. - Service rolls should
be maintained for all Government servants for whom service books are not kept, save those
mentioned in Exception (I) in S.R. 104. This service rolls should be recorded the date of enrolment,
caste, tribe, village, age, height, marks of indentification, when enrolled, rank, promotion, education
or other punishment, absence from duty on leave or without leave, interruptions in service, and
every other incident in service which may involve forfeiture of portions of service or affect the
amount of pension. Every entry in them should be signed by the head of the office. Service rolls
should invariably be submitted with the pension papers to the audit office.Explanation. - Service
rolls need not be maintained for the members of the Collie Corps establishments in the Sadia and
Balipara Frontier Tracts.Note 1. The Deputy Commissioner, Garo Hills, may delegate to the Deputy
Inspector of Schools the power to sign the front page, and to make attestation in respect of entries
made in subsequent pages, of the service rolls of the teachers of the vernacular schools of the
district.Note 2. In the case of contingency materials who may be granted leave with or without
allowance by the head of the office on the analogy of S.R. 127, a service roll should be kept in form
specially prescribed for the purpose.Section III-Special and Ordinary Leave RulesF.R.75. (1) All
Government servants who are not hereinafter declared to be subject to the special leave rules shall
be subject to the ordinary leave rules.(2)Any Government servant having at the time of his
appointment his domicile elsewhere than in Asia shall be subject to the special leave rules :Provided
that no such Government servant shall be entitled to the benefits of the special leave rules, who
prior to such appointment, has, for the purpose of his appointment to any office under the
Government or of the conferment upon him by the Government of any scholarship, emoluments, or
other privilege, claimed and has been deemed to be of Indian domicile.Audit Instructions. - (1) A
Government servant who becomes eligible to the special leave rules while he is on leave under the
ordinary leave rules may, from the date he becomes so eligible, change the balance of his leave under
the special leave rules.(2)The expression "at the time of his appointment' occurring in F.R. 75 (2)
means the date of an officer's appointment to a service or post to which the provisions of the
Fundamental Rules apply.F.R.75A. For the purpose of F.R. 75 (2) the domicile of a person shall be
determined in accordance with the provisions set out in the Schedule to these rules :Provided that a
person who was born and has been educated exclusively in Asia and has not resided out of Asia for a
total period exceeding six months shall be deemed to have his domicile in Asia unless, in the case of
a person to whom the provision in Sub-Rule (2) of Rule 75 does not apply, it is proved to the
satisfaction of the appointing authority that he did not have his domicile in Asia on that
date.F.R.75B. No Government servant who, after his appointment to a service or post acquires a new
domicile, shall thereby loose his right to, or become entitled to admission to the benefits of the
special leave rules.F.R.75C. If any question arises as to the domicile of any Government servant at
the time of his appointment, the decisions thereon of the State Government shall be final.Section
IV-Grant of LeaveF.R.76. A leave account shall be maintained for each Government servants in
terms of leave on average pay. A separate account should be kept of the leave earned by a
Government servant serving under a Government and then transferred to another Government, and
all leave taken after the date of transfer should be debited to his account so long as the balance
under it is exhausted.S.R.113. - The rate of leave salary actually received by an absentee by the
operation of the further proviso to F.R. 87 should not be taken into account in recording the leaveFundamental Rules and Subsidiary Rules

granted to inferior servants in their leave account but that the account should be debited with the
kind of leave granted irrespective of the leave salary.F.R.77. In the leave account of a Government
servant subject to these rules, shall be credited-(i)if he be under the special leave rules,
five-twenty-seconds of the period spent on duty; and(ii)if he be under ordinary leave rules,
two-elevenths of the period spent on duty.Audit Instructions. - (1) Fractions of a day should not
appear in the leave accounts, fractions below half should be ignored and those of half or more
should be reckoned as one day.(2)Five-twenty-seconds of the period spent on duty should be
calculated thus-The amount of duty as expressed in terms of years, months and days should be
multiplied by five and the product divided by twenty-two. In this process of multiplication and
division a month should be reckoned as equal to 30 days.Two-elevenths of the period spent on duty
should also be calculated similarly.F.R.78. The amount of leave to be debited against a Government
servant's leave account is-(a)the actual period of leave on average pay, but excluding special
disability leave on average pay under F.R. 83 (7); and(b)half tire period of leave on half average pay
other than special disability leave or one quarter average pay or of special disability leave on average
pay under F.R. 83 (7) (b).F.R.79. When a Government servant, who has previously been subject to
ordinary leave rules, is admitted to the benefits of the special leave rules, no change shall be made in
the amount of leave previously credited and debited to his account, but he shall be entitled to the
maximum amount of leave prescribed in F.R. 81 (a) (i).F.R.80. This amount of leave due to a
Government servant is the balance of leave at his credit in the leave account.F.R.81. Leave may be
granted to a Government servant at the discretion of the authority entitled to grant the leave subject
to the following restrictions :(a)The maximum amount of leave which may be granted, expressed in
terms of leave on average pay is the privilege which it was permissible to grant to the Government
servant in question, on the 1st January, 1922 under the rules applicable to him prior to that date;
plusOne-eleventh of the period spent on duty subsequent to that date ; plus(i)in the case of
Government servant under the special leave rules, three years; or(ii)in the case of Government
servant under the ordinary leave rules, two and a half years :Provided that special disability leave on
half average pay or on average pay under F.R. 83 (7) (a) shall not be taken into account in
calculating the maximum prescribed by this clause, and in the case of such leave taken on average
pay under F.R. 83 (7) (b) account shall be taken of only half the period thereof.(b)The maximum
amount of leave on average pay including any furlough on average salary taken under rule in force
prior to 1st January, 1922 but excluding special disability leave on average pay under F.R. 83 (7) (a)
which may granted is-(i)to a Government servant under the special leave rules, eight months at any
one time,and, in all-the privilege leave which it was permissible to grant to him on the 1st January,
1922 under the rules applicable to him prior to that date, plusone-eleventh of the period spent to
duty subsequent to that date, plus one year,(ii)to a Government servant under the ordinary leave
rules, four months at any one time,and, in all-the privilege leave which it was permissible to grant to
him on the 1st January, 1922 under the rules in force prior to the date, plusone-eleventh of the
period spent on duty subsequent to that date :Provided that in the case of a Government servant,
other than a Class IV Government servant, subject to the ordinary leave rules, who either takes leave
on medical certificate other than leave preparatory to retirement or spends his leave elsewhere than
in India, Pakistan, Ceylon, Nepal or Burma the maximum prescribed in sub-Clause (i) of this clause
shall apply.Note. (1) The expression "other than leave preparatory to retirement" in the proviso
above has effect from the 10th August, 1937.(2)Officers subject to the ordinary leave rules who take
advantage of the said proviso when applying for leave on average pay on medical certificate areFundamental Rules and Subsidiary Rules

required to give an undertaking that they will refund the difference between average pay and half
average pay for the period of leave on average pay which would not have been admissible had the
proviso in F.R. 81 (b) I(ii) not been applied if they subsequently decide to retire at the end of the
leave, or of an extension of that leave, but the question whether the officer concerned should be
asked to refund the amount drawn in excess as leave salary should be decided on the merits of each
case, i.e., if the retirement is voluntary, refund should be enforced, but if the retirement is
compulsory thrust upon the officer by reason of ill-health incapacitating him for further service, no
refund should be taken.(c)Save in the case of leave preparatory to retirement, leave not due may be
granted subject to the following conditions :(i)on medical certificate without limit of amount;
and(ii)otherwise than on medical certificate, for not more than three months at any one time and six
months in all reckoned in the terms of leave on average pay.Note 1. In cases where a Government
servant who has been granted leave not due under this clause for permission to retire voluntarily the
leave not due shall, if the permission be granted, be cancelled and his retirement shall have effect
from the date on which such leave commenced.Note 2. (i) Leave not due may in no case be granted
unless the sanctioning authority is satisfied that, as far as can be reasonably for seen the officer will
return to duty and earn it; and(ii)that, except as provided in the Note 1 to F.R. 81 (c), the leave when
granted should in all cases subject to the Government servant's wishes be allowed to stand,
including cases in which the officer fails to earn it by subsequent duty.(d)The maximum period of
continuous absence from duty on leave granted otherwise than on medical certificate is twenty-eight
months. This period shall in no circumstances be exceeded by a Government servant who is on leave
preparatory to retirement.(e)When Government servant returns from leave which was not due and
which was debited against his leave account, no leave will become due to him until the expiration of
a fresh period spent on duty is sufficient to earn a credit of leave equal to the period of leave which
he took before it was due.Audit Instructions. - (1) If leave on average pay is applied for after a
Government servant has had leave on half-average pay in continuation of a period of leave on
average pay either by the production of a medical certificate or by a Government proceeding out of
India, Ceylon, Nepal, Burma or Aden, the period of leave on average pay that may then be granted
should be similarly limited to the period actually covered by the medical certificate or spent
elsewhere than in India, Ceylon, Nepal, Burma or Aden. The grant of the leave should also be so
regulated that the total period of leave on average pay during that spell of leave does not exceed
eight months in such case the total period of leave on average pay shall be treated as one continuous
spell of leave on average pay in order to determine whether first four months of the leave should be
treated as privilege leave for purposes of pension.(2)If under the operation of the proviso to F.R. 81
(b) (ii) the maximum amount of leave on average pay admissible at a time is increased, further leave
on average pay may not be granted in continuation, unless such leave is taken on medical certificate
or is spent elsewhere than in India, Ceylon, Nepal, Burma or Aden, but such leave on average pay
which may be taken on medical certificate or outside India, Ceylon, Nepal, Burma or Aden up to
maximum of 12 months in a Government servant's whole service, if due, does not consume the leave
on average pay which may be taken without medical certificate.(3)Leave not due may in no case be
granted unless the sanctioning authority is satisfied that, as far as can be reasonably foreseen, the
Government servant will return to duty and earn it. When, however, such leave has once been
granted,it should be allowed to stand, unless the Government servant otherwise desires, even if he
proves unable to earn it by subsequent duty; [but see Notes to F.R. 81 (c)].(4)The limit of 28 months
of continuous absence prescribed in F.R. 81 (d) includes the period of vacation, if any, with whichFundamental Rules and Subsidiary Rules

leave is combined.(5)The expression "continuous absence from duty on leave" occurring in F.R. 81
(d) does not include absence on extraordinary leave.Government of Assam's decision. - Subject to
the consideration of special cases, where an officer is placed on deputation in Europe or America
while on leave out of India, the deputation shall be regarded as an interruption of the leave already
granted. The expression "at any one time" in F.R. 81 (c) should be interpreted as meaning "in each
separate period of leave granted". The effect of this ruling is that in ordinary circumstances the leave
of such an officer will be extended by the period of the deputation but the deputation will not entitle
him to a fresh grant of leave.The balance of the unenjoyed leave should be worked out before the
deputation intervenes and the amount of leave to be enjoyed subsequently on the expiry of the
deputation should be restricted to his available balance.F.R.82. The following provisions apply to
vacation departments only :(a)The State Government may make rules specifying the department or
parts of departments which should be treated as vacation department and the conditions in which a
Government servant should be considered to have availed himself of a vacation.(b)Vacation counts
as duty, the periods of total leave in F. Rr. 77, 81 (a) and 81 (b) should ordinarily be reduced by one
month for each year of duty in which the Government servant has availed himself of the vacation. If
a part only of the vacation has been in any year, the period to be deducted will be a fraction of a
month equal to the proportion which the part of the vacation taken bears to the full period of the
vacation.(c)In cases of urgent necessity, when a Government servant requires leave and no leave is
due to him, the periods in F.Rr. 77 and 81 (a), as reduced by Cl.(b) of this rule, may be increased by
one month for every two years of duty in a vacation department.(d)When a Government servant
combines vacation with leave, the period of vacation shall be reckoned as leave in calculating the
maximum amount of leave on average pay which may be included in the particular period of
leave.Note 1. The implied basis and condition of variation are that a Government servant only gets
vacation on condition that he can arrange to carry out the vacation duties of his post, and that a
Government servant should be considered to have availed himself of a vacation or a portion of a
vacation unless he has been required by general or special order of a higher authority to forego such
a vacation or portion of a vacation. A Government servant, who has routine duties to discharge
during the vacation, which does not require his presence at his place of duty and which can be
performed either by himself at some other place or by some other Government servant, should be
considered to have availed himself of a vacation or a part of it, while a Government servant who
leaves his place of duty during a vacation is expected to arrange for, and is responsible for the
performance, without any cost to Government, of such routine duties.A Government servant who
leaves his place of duty during vacation is liable to be called thereto at his own expense.Note 2.
Subject to the provision in the note below F.R. 71,it is permissible under F.R. 82 (d) to allow
vacation to intervene between two periods of leave.Note 3. An officer of a vacation department may
be granted the additional leave which is credited under F.R. 82 (c) even though he has a debit
balance in his leave account due to the fact that leave not due has not been liquidated as required by
F.R. 81 (c). The credit of one month under F.R. 82 (c) is for every completed two years of duty and
no fractional credit for a period of less than two years is permissible.Note 4. In the case of a
Government servant who, at the time of going on leave has not completed a full year of duty and has
not for that reason enjoyed any portion of vacation but who enjoys the next vacation in continuation
of the leave, it has been decided that, for the purpose of Clause (b) of this rule as explained in item
(3) of Audit Instructions below a deduction of 1/12th may be made for the period for which 1/11th is
credited. If subsequently it is found that the vacation has not been enjoyed, the deduction alreadyFundamental Rules and Subsidiary Rules

made can be suitably corrected.Audit Instructions. - (1) The reduction by one month for each year of
duty in which the Government servant has availed himself of the vacation as required to be made
under F.R. 82 (b) is intended to be made in respect of leave earned and vacation taken from 1st
January, 1982.Thus, in the case of Government servants of vacation departments, the leave credited
to their leave account under F.R. 77 will be-(i)privilege leave at their credit on 1st January, 1922, i.e.,
privilege leave earned under Article 272 or 275, Civil Service Regulations; plus(ii)one-eighth or
one-twelfth of the period of spent on duty or vacation or privilege leave up to 31st December, 1921;
plus(iii)five-twenty-seconds or two-eleventh of the period of spent on duty or vacation from 1st
January, 1922.From this a reduction will be made of one month for each year of duty in which a
Government servant avails himself of the vacation after 1st January, 1922. Similarly, the total leave
admissible under F.R. 81 (a) and 81 (b) will be reduced by one month for each year of duty in which
the vacation is taken after 1st January, 1922.(2)The amount credited to the leave account under F.R.
82 (c) as well as that added to the maximum under F.R. 81 (a) should be the actual amount of
additional leave taken under F.R. 82 (c) and not the total amount theoretically permissible, viz, one
month for every two years of duty.(3)The term "each year of duty" should be interpreted to mean,
not a calendar year in which duty in a vacation department is performed but twelve months of actual
duty. If the Government servant has enjoyed such vacation as falls within the period of twelve
months beginning on the day on which he begins his duty on return from leave or otherwise, then
one month should be deducted from his leave account. It does not matter whether the day on which
this year ends falls in a vacation in the succeeding calendar year. The only question is whether the
Government servant has enjoyed such vacation as fell within the period of one year as interpreted
above.If, to take an example, a Government servant before going on leave has not completed a full
year of duty including vacation during the course of the second calendar year, then the fraction of
one month which should be deducted from the leave account, is the fraction which the period of
duty, including vacation, bears to the whole year. If, to take a further complication, he has not
enjoyed the whole of the vacation which fell during that period of less than a year, then the amount
which should be deducted is the proportion of the period, which the proportion of vacation actually
enjoyed bears to the whole period of vacation which fell within that period.In the case of
Government servants who are allowed two vacations in the year instead of one, the periods of the
two vacations should be regarded as combined into one.Conditions in which a vacation should be
considered to have been availed of under Fundamental Rule 82 (a)S.R.114. - A vacation department
is a department or part of a department to which regular vacations are allowed during which
Government servants serving in the department are permitted to be absent from duty.In case of
doubt a competent authority may decide whether or not a particular Government servant is serving
in a vacation department to which these rules apply.The following are vacation departments for the
purpose of F.R. 82 :(1)The High Court excluding the Chief Justice and the Judges and Civil and
Sessions Courts, other than those under the control of Deputy Commissioners in the Assam Valley
Division and Cachar District.(2)Educational institutions in the case of-(a)the teaching staff;(b)such
Government servants, not being members of the teaching staff, as may be declared to be entitled to
vacations by a competent authority.(3)(a)The Government Weaving Institute, Gauhati;(b)The
Surma Valley Technical School, Sylhet;(c)His Royal Highness the Prince of Wales' Technical School,
Jorhat;(d)The Fuller Technical School, Kohima.(e)Assam Civil Engineering School, Gauhati.(4)The
Assam Survey School, Jhalukbari.(5)(a)The teaching staff of the Berry-White Medical School.
Dibrugarh ;(b)such Government servants, not being members of the teaching staff, as may beFundamental Rules and Subsidiary Rules

declared to be entitled to vacation by a competent authority.Note 1. Fundamental Rule 82 does not
apply to District and Sessions Judges.Note 2. A competent authority may by general or special order
determine the periods of the vacation admissible to the staff of the Institutions referred to in Clauses
(2) (b) and (3) above.Note 3. The teachers of Government Lower Primary Schools which do not
enjoy a continuous vacation of a month in the year should not be regarded as belonging to a vacation
department; provided that the holiday list of the school approved by the Deputy Inspector does not
exceed 60 days.Note 4. Clerks in Government School and College in Assam should be treated as
Government servants of a vacation department up to 31st December, 1921, and again from the 13th
February, 1924, and of non-vacation department for the period from the 1st January, 1922 to the
12th February, 1924.S.R.115. - A Government servant serving in a vacation department shall be
considered to have availed himself of a vacation or portion of a vacation unless he has been required
by general or special order of a higher authority to forego such vacation or portion of a vacation;
provided that if he has been prevented by such an order from enjoying more than fifteen days of the
vacation, he shall be considered to have availed himself of no portion of the vacation.Note 1. The 15
days limit in the rule will be applied in respect of each vacation or of two vacations combined when
there are two vacations in the year.Note 2. A period during which a Government servant on leave
will not be considered a period of duty for the purposes of F.R. 82 (2).Note 3. The words "prevented
by such an order from enjoying more than 15 days of the vacation" occurring in lines 5 and 6 of the
rules, mean that the Government servant's absence from duty during the vacation did not exceed 15
days.S.R.116. - As soon as a vacation expires the head of the office will record in the service book of
the officer whether or not he enjoyed vacation for more than fifteen days. If the period exceeded
fifteen days the number of days should be specified.Special Disability LeaveF.R.83. (1) Subject to the
conditions hereinafter specified the State Government may grant special disability leave to a
Government servant who is disabled by injury intentionally inflicted or caused in, or in consequence
of the due performance of his official duties or in consequence of his official position.(2)Such leave
shall not be granted unless the disability manifested itself within three months of the occurrence to
which it is attributed, and the person disabled acted with due promptitude in bringing it to notice.
But the State Government if it is satisfied as to the cause of the disability may permit leave to be
granted in cases where the disability manifested itself more than three months after occurrence of
its cause.(3)The period of leave granted shall be such as is certified by a medical board to be
necessary. It shall not be extended except on the certificate of a medical board, and shall in no case
exceed 24 months.(4)Such leave may be combined with leave of any other kind.(5)Such leave may
be granted more than once if the disability is aggravated or reproduced in similar circumstances at a
later date, but not more than 24 months of such leave shall be granted in consequence of any one
disability.(6)Such Leave shall be counted as duty in calculating service for pension and shall not,
except as provided in F.R. 78 (b), be debited against the leave account.(7)Leave salary during such
leave shall be equal-(a)for the first 4 months of any period of such leave including a period of such
leave granted under Clause (5) of this rule, to average pay ; and(b)for remaining period of any such
leave, to half average pay, or at Government servant's option, for a period not exceeding the period
of average pay which would otherwise be admissible to him, to average pay:Provided that the
maxima specified in the table in Sub-Rule (2) of Rule 89 shall notwithstanding anything contained
in that rule, apply to the whole period of such leave and the minima specified in the table in Rule 90
shall apply when leave salary during such leave is equal to half average pay, subject to the conditions
stated in that rule and in the Notes thereunder.(8)In the case of the person to whom the Workmen'sFundamental Rules and Subsidiary Rules

Compensation Act, 1923, [Now Employees' Compensation Act, 1923] applies the amount of leave
salary payable under this rule shall be reduced by the amount of compensation payable under
Section 4 (1) (d) of the said Act.(9)The provisions of this rule apply to a civil servant disabled in
consequence of service with a military force, if he is discharged as unfit for further military service
but he is not completely and permanently incapacitated for further civil service, and to a civil
servant not so discharged who suffers a disability which is certified by a medical board to be directly
attributable to his service with a military force ; but, in either case any period of leave granted to
such a person a under military rules in respect of that disability shall be reckoned as leave granted
under this rule for the purpose of calculating the period admissible.F.R.83A. The State Government
may extend the application of the provisions of F.R. 83 to a Government servant who is disabled by
injury incidentally incurred in or in consequence of the due performance of his official duties or in
consequence of his official position, or by illness incurred in the performance of any particular duty
which has the effect of increasing his liability to illness or injury beyond the ordinary risk attaching
to the civil post which he holds. The grant of this concession is subject to the further conditions
:(i)that the disability, if due to disease, must be certified by medical board to be directly due to the
performance of particular duty ; and(ii)that, if the Government servant has contracted such
disability during service otherwise than with a military force, in must be in the opinion of the State
Government, so exceptional in character or in the circumstances of its occurrence as to justify such
unusual treatment as the grant of his form of leave ; and(iii)that the period of absence
recommended by the medical board may be covered in part, by leave under this rule and in part by
other leave, and that the amount of special disability leave granted on average pay may be less than
four months.Note 1. The grant of the concession contemplated in this rule is not admissible to a
Government servant in the case of injuries resulting from an accident to which he may be liable
under the ordinary conditions of civil life or in connection with the ordinary discharge of his
duties.Note 2. The intention of F.R. 83-A (ii) is not that special disability leave should be given to
cover any portion of an officer's military service but that it should be admissible only after the
officer's discharge as unfit for further military service.State Government's decision. - A question was
raised as to whether special disability leave under F.R. 83-A would be admissible to Police
Department official for falling off a pony which returning from a place of duty. It was decided in
consultation with Auditory General of India that the accident of falling off a pony may occur to
anybody and constitutes ordinary risk of civil life.F.R.83B. (1) A Government servant who has been
granted special disability leave under F.R. 83, and whose domicile is elsewhere than in Asia, may be
granted by the State Government, free passage by sea for himself, his wife and children, to the
United Kingdom, or any port in Europe or in a British colony, dominion or possession, and on the
conclusion of such leave, return passage to India, unless he takes leave other than leave on medical
certificate in continuation of special disability leave in which case return passage shall be granted
save in exceptional circumstances : Provided that the cost of any passages granted under this rule
shall not exceed the cost of passages between India and the United Kingdom.(2)Passages granted
under this rule may include travel by land between port of embarkation and port of debarkation,
and shall be of such class as the sanctioning authority in each case may determine.(3)The State
Government may extend the application of the provisions of Clauses (1) and (2) to a Government
servant who has been granted special disability leave under F.R. 83-A, and whose domicile is
elsewhere than in Asia ; provided that it may, at its discretion, grant free passage to the Government
servant only, or to the Government servant and his wife only.(4)For the purpose of this rule-(i)theFundamental Rules and Subsidiary Rules

domicile of a Government servant is his domicile at the time of his appointment to Government
service, as determined in accordance with the provisions of Clause (2) of Rule 75 and Rr. 75-A, 75-B
and 75-C ;(ii)"child" means a legitimate child (including a step-child) residing with and wholly
dependent on the Government servant, who, if a female, is unmarried or, if a male, is under the age
of 16.Study LeaveF.R.84. Leave may be granted to the Government servants, on such terms as the
State Government may by general order prescribe, to enable them to study scientific, technical or
similar problems or to undergo special courses of instruction. Such leave is not debited against the
leave account.S.R.117. - The terms prescribed by the Secretary of State for officers under his
rule-making control (Appendix 15) have been adopted by the State Government in respect of
persons serving in connection with the affairs of the State.Extraordinary LeaveF.R.85. (a)
Extraordinary leave may be granted in special circumstances (1) when no other leave is by rule
admissible, or (2) when, other leave being admissible, the Government servant concerned applies in
writing for the grant of extraordinary leave. Such leave is not debited against the leave account. No
leave salary is admissible during such leave.(b)A Government servant abstaining from work for any
reasons whatsoever without permission shall be deemed to be absent without leave during the
period of such abstinence.(c)The authority which has the power to sanction leave may grant
extraordinary leave as in Clause (a) in combination with or in continuation of, any leave that is
admissible, and may commute retrospectively period of absence without leave into extraordinary
leave.[For Administrative Instructions issued by the State Government regarding "casual leave" and
"quarantine leave" see Rr. 246 and 268 of the Assam Executive Manual].Note. The power of
commuting retrospective periods of absence without leave into extraordinary leave under F.R. 85
(b) is absolute and not subject to the conditions mentioned in Cl. (a) of that rule ; in other words,
such commutation is permissible even when other leave was admissible to the Government servant
concerned at the time of his absence without leave commenced.Audit Instructions. - "Leave not due"
applied for by a Government servant with or without medical certificate is "leave admissible under
rule", and in cases where "Leave not due" can be granted the grant of extraordinary leave under F.R.
85 will be irregular unless the latter kind of leave is specially applied for in writing.Extension of
leave at time of RetirementF.R.86. (a) Leave at the credit of a Government servant in his leave
account shall lapse on the date of compulsory retirement:Provided that if in sufficient time before
that date he has-(1)formally applied for leave due as preparatory to retirement and been refused it;
or(2)ascertained in writing from the sanctioning authority that such leave if applied for would not
be granted in either case the ground for refusal being the requirements of the public service ;then
the Government servant may be granted, after the date of retirement, the amount of leave so refused
subject to a maximum of a six months.Provided further that every Government servant-(a)who after
having been under suspension, is re-instated within six months preceding the date of his
compulsory retirement and was prevented by reason of having been under suspension from
applying for leave preparatory to retirement, shall be allowed to avail of such leave as he was
prevented from applying for, subject to a maximum of six months reduced by the period between
the date of re-instatement and the date of compulsory retirement;(b)who retired from service on
attaining the age of compulsory retirement while under suspension and was prevented from
applying for leave preparatory to retirement on account of having been under suspension, shall be
allowed to avail of the leave to his credit subject to a maximum of six months, after the termination
of proceedings, as if he had been refused as aforesaid if, in the opinion of the authority competent to
order reinstatement, he has been fully exonerated and the suspension was wholly unjustified.(b)AFundamental Rules and Subsidiary Rules

Government servant retained in service after the date of compulsory retirement shall avail leave on
average pay at the rate of 1/11th of duty performed after that date, and shall be allowed to add
thereto any amount of leave which could have been granted to him under Clause (a) had he retired
on that date. The total period which he may take on each occasion shall not exceed six months.When
his duties finally cease, the Government servant may be granted leave preparatory to retirement, up
to a maximum of 6 months as follows :(i)the balance after deducting the amounts of leave, if any,
taken during the period of extension, from the amount of leave which could have been granted to
him under Clause (a) had he retired on the date of compulsory retirement; plus(ii)the amount of
leave earned under this clause which is due to the Government servant and which he has in
sufficient time during the period of extension-(1)formally applied for a preparatory to final cessation
of his duties and been refused ; or(2)ascertained in writing from the sanctioning authority that such
leave would not be granted if applied for, in either case the ground of refusal being the requirements
of the public service.Note 1. The proper test in applying the rule is whether it would be more
convenient on general administrative grounds for a Government servant to take leave before or after
the age of superannuation, and that all Government servants should be warned that the rule is
intended to apply only in cases in which a Government servant with leave due to him has applied for
leave in sufficient time before the date of retirement and his application has been refused owing to
the exigencies of the public service and that it is not ended to apply so as to enable a Government
servant at his own option to take leave after instead of before the date of retirement.Note 2.
Fundamental Rule 86 does not apply to Military Assistant Surgeons in civil employ.Note 3.
[Deleted].Note 4. A deduction under F.R. 82 (b) on account of vacation enjoyed should also be made
in the case of officers whose leave is regulated under F.R. 86 (b).Government of India's
interpretation. - While the amount of the leave refused under F.R. 86 (a) or (b) is fixed, the quality
of the leave (i.e., on average or half average pay), whether it is taken before or after the date of
compulsory retirement or, as the case may be, the date of final cessation of duties, may be varied to
the advantage of the Government servant concerned within the normal leave rules by the leave
earned and standing to his credit on the date he proceeds on leave ; and on second application for
leave in sufficient time and its refusal are necessary merely to ensure this variation.Audit
Instruction. - (1) A Government servant retained in service after the age of compulsory retirement is
entitled to earn leave under Clause (b) of F.R. 86 and a debit balance, if any, on the date he attained
that age should be considered as wiped off.(2)The period of six months maintained in F.R. 86 (b)
includes any period of vacation with which leave is combined.(3)The leave earned by the period of
duty intervening between the refusal of leave pending retirement and the date of compulsory
retirement is merged in the common pool in the leave account and forms an indistinguishable part
of the total leave at credit the whole of which, with the exception only of the net amount of leave
refused, lapses under Clause (a) of F.R. 86 on the date of compulsory retirement. The grant of any
leave between the date from which the refusal of leave took effect and the date of susperannuation
should therefore be held to be a grant of leave against the amount originally refused. The amount of
leave admissible under Clause (a) after superannuation in such a case is therefore the amount of
leave originally refused minus the amount of the 'post refusal' leave enjoyed, and this difference is
subject to a minimum of 6 months. The principle applies equally to leave available under Clause (b),
including that earned in respect of duty during a period of refused leave.Auditor General's decisions.
- The rule in Note 2 to F.R. 56 does not require that the authority sanctioning leave under F.R. 86
should necessarily be competent to sanction an extension of service also.State Government'sFundamental Rules and Subsidiary Rules

decision. - (1) An officer of the State Government who was due to retire on superannuation on 16th
July, 1956, applied for leave preparatory to retirement with effect from 16th March, 1956 and the
competent authority refused his leave from 16th March, 1956 to 15th April, 1956, in the interest of
public service. Although the competent authority was willing to allow him to proceed on leave,
preparatory to retirement from 16th April, 1956, the officer did not avail of the leave from that date
but proceeded on leave from 7th July, 1956. On that day the officer requested that he might be
sanctioned leave on average pay for nine days from 7th July, 1956 to 15th July, 1956 and in
continuation refused leave for one month from 16th July, 1956 to 16th August, 1956. A doubt arose
whether the officer was entitled to one month's leave from 16th July, 1956 previously refused in
addition to nine days leave from 7th July, 1956 to 15th July, 1956. The position is that the officer
applied for 4 months' leave carrying him to the date of superannuation out of which leave for one
month was refused in the public interest and 3 months' leave was sanctioned to him. Thus one
month's leave preparatory to retirement was actually refused to him which he was entitled to be
granted after the date of superannuation. The mere fact that the officer did not avail of 3 months'
leave granted to him did not change the character of the refused leave for one month and did not
prejudice the officer's titles to its grant after the date of superannuation. State Government have,
therefore, decided that refused leave under F.R. 86 for one month from 16th July, 1956 to 15th
August, 1956 in addition to nine days leave from 7th July, 1956 to 15th July, 1956 is admissible to
the officer. [Notification No. FE 234/60/9 (Dy), dated 23-4-1960].(2)The existing rules do not
contemplate the grant of leave preparatory to retirement to a Government servant, coupled with
permission to remain in service of the foreign employer. The Governor of Assam has now decided
that such cases shall be regulated in the following manner :(i)Cases where a Government servant,
who is already on foreign service in or out of India under a body corporate, owned or controlled by
Government applies for leave preparatory to retirement.The leave applied for can be granted only if
the body corporate, owned or controlled by Government is prepared to release him from their
employment to enable him to enjoy the leave. If the is not so released he should be refused in the
interests of public service and it may then be availed of by the Government servant to the extent
admissible under F.R. 86 or Rule 7 of the Leave Rules, 1934 (as amended with effect from 1st
October, 1956), as the case may be, from the date of his quitting the service.(ii)Cases where a
Government servant who is on foreign service in or out of India other than under a body corporate,
owned or controlled by Government applies for leave preparatory to retirement.In such cases leave
will be admissible only where the Government servant quits duty under the foreign employer. In
other words, he will not be permitted to continue in employment under the foreign employer while
on leave preparatory to retirement. Non-eligibility for leave preparatory to retirement as a result of
continuance in service under the foreign employer will not be treated as refusal of leave for the
purpose of F.R. 86 or Rule 7 of the Leave Rules, 1934 (as amended with effect from 1st October,
1956), as the case may be. If he is allowed to continue in employ of the foreign organisation after the
date of superannuation, he will be treated purely as on private employment.(iii)Cases where the
Government servant seeks employment under a body corporate while on refused leave.If while on
refused leave Government servant is offered re- employment under a body corporate, owned or
controlled by Government the authority by whom the leave was sanctioned may cancel the
unutilised portion of leave and allow it to be enjoyed on termination of the period of re-employment.
If, however, re- employment is permitted under an organisation in or out of India other than a body
corporate, owned or controlled by Government, he cannot be allowed the benefit of availing himselfFundamental Rules and Subsidiary Rules

of the utilised portion of refused leave on conclusion of the re-employment. He may either have the
option of retiring forthwith or to remain on refused leave concurrently with re-employment under
such as a private organisation on the condition that the leave salary will be restricted to that
admissible during leave on half average pay or half pay leave, as the case may be.Section V-Leave
SalaryF.R.87. Subject to the conditions in Rr. 81, 88, 89, 90 and 91 Government servant on leave
shall, during leave, draw leave- salary as follows :(a)if the leave is due, leave-salary equal to average
pay or to half average pay, or to average pay during a portion of the leave and half average pay
during the remainder, as he may elect; and(b)if the leave is not due, leave-salary equal to half
average pay :Provided that when a non-gazetted Government servant, who was in service on the
24th day of August, 1927, takes leave, and(i)his pay is less than Rs. 300 ; or(ii)the leave taken does
not exceed one month,his average pay for the purpose of this rule may be taken to the pay which he
would draw in the permanent post held substantively by him at the time of taking leave, if his pay be
more than the average pay :Provided further that the leave-salary of a Class IV Government servant
shall not exceed what remains from his pay after providing for the efficient discharge of duties of the
post during his absence, except when, in the resultant officiating arrangements, a Government
servant who has no substantive post is given more than half the pay of the post in which he
officiates, in which case the excess over half pay granted to him to the discretion of the authority
sanctioning the leave be disregarded in calculating the amount of leave-salary.Note 1. In a case in
which an outsider entitled to draw pay on the revised scale is appointed to officiate in place of an
absence inferior servant drawing the old scale of pay, old scale of pay of the post should be taken to
be "the pay of post" for the purpose of calculating the rate of the absentee allowance.Note 2. Under
F.R. 87 (a) the nature of the leave due and applied for by a Government servant cannot be altered at
the option of the sanctioning authority and under F.R. 67, while it is open to the sanctioning
authority to refuse or revoke the leave due and applied for, it is not open to him to alter the nature of
such leave.Note 3. Fundamental Rule 87 (a) provides that a Government servant on leave, shall,
during leave, if the leave is due, draw leave-salary equal to average pay, or to half average pay, or to
average pay during a portion of the leave and half average pay during the remainder, as he may
elect. The election given by the rule is the election between the three different forms of leave salary
mentioned therein and the rule is not intended to give any choice as to the period during which
average pay or half average pay can be drawn if the officer elects the third form. In that case the
intention is that the period on average pay should be taken first and should be succeeded by the
period on behalf average pay.Note 4. The words "as he may elect" in F.R. 87 (a) imply election once
for all and, therefore, debar a Government servant from claiming commutation of leave as of right.
Though under the Fundamental Rules the authority which granted leave can (if so disposed)
commute it retrospectively into leave of a different kind yet a Government servant does not possess
any right to insist that it should be as commuted.Note 5. A Government servant who was only
temporary or officiating and was not holding substantively a permanent post on the 24th August,
1927 has clearly no claim under the proviso to F.R. 87 (b).Note 6. A Government servant who was in
permanent Government service on or before the 24th August, 1927, and who was, therefore, entitled
to the privilege under the proviso to F.R. 87 (b) will retain that privilege if re-appointed after
resignation or discharge or if re-instated after dismissal; provided that he is allowed to count his
post service for leave under F.R. 65 (a) or (b).Note 7. A Government servant who was holding, on
probation, a permanent post on 24th August, 1927, and had no lien on any other post, is not entitled
to the concessions admissible under the above proviso, since his leave is absolutely governed by F.R.Fundamental Rules and Subsidiary Rules

104 not by the rules in Ss. I to V of Chapter X of the Fundamental Rules (Cf. F.R. 58).Audit
Instructions. - (1) A Government servant who holds substantively a non-gazetted permanent post,
but proceeds on leave from a gazetted post, should be regarded as a gazetted officer for the purposes
of F.R. 87.(2)The term "pay" occurring in the expression "the pay which he would draw in the
permanent post held substantively by him " contained in the proviso should be interpreted as
including "special pay" whether attached to a post or personnel to particular Government servant,
since in either case he would draw it in the post which he holds substantively.(3)The term
"permanent post" occurring in the expression "the pay which he would draw in the permanent post"
contained in the proviso may be a post on other permanent post.President's decision. - (i) For the
purpose of the first proviso to F.R. 87 the status of a Government servant while on foreign service,
i.e., gazetted or non-gazetted should be determined with reference to the permanent post under
Government on which he holds a lien or would hold a lien had his lien not been suspended or, if
during his absence on foreign service he is given any promotion under the F.R. 113, with reference to
the post under the Government to which he is so promoted.(ii)In the case of such a Government
servant, the term "his pay" occurring in term (i) of this proviso should be construed to mean what is
prescribed under F.R. 117 (b) for counting his pay for the purpose of F.R.9 (2) i.e., the pay drawn in
foreign service at the time leave is taken less, in the case of a Government servant paying his own
contribution for leave salary and pension such part of the pay as may be paid as contribution.The
expression "the pay he would draw in the permanent post held substantively by him at the time of
taking leave" occurring in this proviso should, in its application to a Government servant on foreign
service, be taken to mean the pay which the would draw in the permanent post under Government
on which he holds a lien or would hold a lien had his lien not been suspended at the time of taking
leave.The Government of Assam has accepted this decision.F.R.88. After continuous absence from
duty on leave for a period of 28 months, a Government servant will draw leave salary equal to
quarter average pay, subject to the maximum and minimum prescribed in F.Rr. 89 and 90.Audit
Instructions. - (1) The expression "continuous absence from duty on leave" occurring in this rule
does not include absence or extraordinary leave.(2)The period of 28 months includes the period of
vacation, if any, with which the leave is combined.F.R.89. (1) During the first four months of any
period of leave on average pay, leave-salary is subject to an absolute maximum of Rs. 2,000 per
mensem.(2)Except during the first four months of any period of leave on average pay, leave-salary is
subject to the monthly maxima shown in the following table :
 AverageHalf
averageQuarter
average
Outside Asia In AsiaOutside
AsiaIn AsiaOutside
AsiaIn
Asia
£ Rs. £ Rs. £ Rs.
Government servant subject to the
special leave rules200 2,000 100 1,000 60 600
Government servant subject to the
ordinary leave rules150 1,500 75 750 60 600
Note. The maximum of average pay does not apply to Government servant serving in a vacation
department during period of leave on average pay equivalent to one month for each year since hisFundamental Rules and Subsidiary Rules

last leave during which he has not availed himself of the vacation and to a proportionate fraction of a
month during which he has taken a part only of vacation : provided that in the case of a Government
servant who is transferred which leave is to his credit from a non-vacation department, the State
Government shall decide on the first occasion on which he takes leave after such transfer, the period
not exceeding for which the maximum limit of leave salary shall not be applied to him.The above is
not meant to give any additional advantage but is intended to be a restrictive exception to the main
rule in F.R. 89 (2). A Government servant is not entitled to the concession mentioned in this not in
addition to the concession granted in the main rule itself but only to the drawing of full pay for a
period equivalent to one month for a year since the last leave taken during which vacation has not
been enjoyed.Audit Instruction. - The intention is that vacation should be treated as the equivalent
of the leave on average pay for the purposes of this rule.F.R.90. Subject to the condition that the
leave salary of a Government servant shall in no case exceed his average pay, leave-salary is subject
to the monthly minima shown in the following table :
 Half average Quarter average
Outside Asia In Asia Outside Asia In Asia
£ Rs. £ Rs.
Government servants subject to the special leave rules 33 333 16 ½ 166
Government servants subject to the ordinary leave rules 25 250 12 ½ 125
Note. The minima specified above apply only when leave is taken or extended out of India elsewhere
than in Pakistan, Ceylone, Nepal, Burma.Audit Instruction. - The term 'average pay' used in F.R. 90
should be interpreted in terms of F.R. 9 (2) and need not be taken as the pay which a non-gazetted
Government servant would draw in the permanent post held substantively by him at the time of
taking leave, if this pay be more than the average pay under the proviso to F.R. 87.F.R.91. (1) Unless
the Governor with the prior approval of the President by general or special order otherwise directs,
leave-salary shall be drawn in India.(2)Subject to the provisions of sub-Rule (1) leave-salary shall be
drawn in rupees, but leave-salary in respect of leave spent out of Asia may, at the option of the
Government servant be drawn in sterling :Provided that-(a)in the case of leave on average pay not
exceeding four months, or of the first four months of such leave if it exceeds four months' leave
salary due one in respect of an initial period of such leave spent in Asia may if the officer proceeds
out of Asia during the currency of such leave, or within one month of its termination, be drawn in
sterling;(b)in the case of leave of any other description or of periods of leave on average pay after the
first four months of such leave, if the amount of such leave spent in Asia prior to embarkation does
not in all exceed one month, leave-salary in respect of the whole of such leave may be drawn in
sterling.(c)in the case of an attachment order having been issued by a Court in India in accordance
with Rule 48, Order XXI, First Schedule, Code of Civil Procedure, 1908 (Act 5 of 1908), that part of
leave-salary which is attached shall be remitted to the Court in rupees by the accounts authority in
India. The balance of leave-salary if payable in sterling, may, then be drawn reducing the maximum
and minimum rates of leave-salary prescribed in Rr. 89 and 90 by the amount specified in the
attachment order, covered into sterling at the rates of exchange prescribed under sub-Rule (5) of
this rule.Note 1. For the purposes of this rule Cyprus shall be regarded as outside Asia.Note 2. See
Audit Instruction below F.R. 99.Note 3. Since in the case of an officer placed on deputation in
interruption of leave out of India, leave is treated as one spell of leave, the leave before and the
deputations should be treated as "initial period" for the purposes of proviso (a) to F.R. 91 (2) and theFundamental Rules and Subsidiary Rules

Government servant allowed to draw, if he so desires, leave salary in India for the portion of leave
immediately following the deputation. As deputation is duty for all purposes it should not be taken
into account in calculating the maximum period of four months prescribed in F.R.
91.(3)Leave-salary drawn in rupees shall be drawn in India, or in the case of a Government servant
who spends his leave in Ceylon Burma or Aden, as the case may be.(4)Leave-salary drawn in sterling
shall be drawn in London, or at the Government servant's option, in any British dominion or colony
which the Secretary of State may by order prescribe for the purpose ; provided that the officer
spends his leave in the dominion or colony in which he has elected to draw his leave- salary. But if
leave-salary due in respect of any portion of leave out of Asia and payable to the Government
servant in sterling remains undraw for a no fault on his part, the State Government may authorised
the undraw to be paid in the India at such rate of exchange as the Secretary of State may by order
prescribe.Note 1. For the rate of exchange see Secretary of States' Order below sub-Rule (5).Note 2.
If leave-salary due in respect of any portion of leave out of Asia and payable to a Government
servant in sterling remains undrawn due to the late arrival of a steamer, it may be held to be
non-drawal though no fault of the Government servant concerned and the drawal in India permitted
in such cases as a matter of course.Note 3. Payment of leave-salary in a colony shall be subject to
such restrictions in the matter of foreign exchange as the Government of India may, from time to
time, impose.[For a list of British Dominions and Colonies in which leave-salary may be drawn in
sterling, see Appendix 16].(5)Leave salary shall be converted into sterling at such rate of exchange as
the Secretary of State may by order prescribe.Secretary of State's Order. - The Secretary of State has
decided that the rate of exchange shall, until further orders, be 1 s. 6 d.(6)Any leave-salary drawn
outside India shall be subject to deduction of Indian income-tax and super-tax and at the rates
which would have been applicable if that leave-salary had been drawn in India.Government of
Assam's decision. - For the purposes of the application of F.R. 91 the period of voyage to or from
India is treated as leave out of Asia during which leave-salary is payable in sterling. These orders are
intended to apply to all direct (i.e., unbroken) voyages between India and a port outside Asia
irrespective of the route followed and the time spent in Asia on the voyage including stoppages
incidental thereto (e.g. for the purpose of transhipment). They are not, however, intended to make
leave-salary payable in sterling when the voyage is broken in Asia at the violation of the officer or
when he spends a portion of his leave in Asia before proceeding to another continent or resuming
his duties in India.Audit Instructions. - Vacation should be treated as equivalent of leave on average
pay for the purpose of proviso (a) to F.R. 91 (2).F.R.92. The rupee and sterling maxima and minima
prescribed in F.R. 89 and 90 shall be applied to leave-salaries paid respectively in rupees and in
sterling.Audit Instruction. - Under F.R. 91 (2) (b) read with F.R. 92, a Government servant who
spends not more than one month of his leave in Asia prior to embarkation to spend the balance
elsewhere is entitled to draw leave-salary in respect of the entire period of a leave at the privileged
rate and subject to the sterling minima prescribed in F. R. 90.F.R.93. A compensatory allowance
should ordinarily be drawn only by a Government servant actually on duty, but the State
Government may make rules specifying the conditions under which a Government servant on leave
may continue to draw a compensatory allowance, or a portion thereof in addition to leave-salary.
One of these conditions should be that the whole or a considerable part of the expense to meet
which the allowance was given continue during leave.S.R.118. - (1) A compensatory allowance other
than a house-rent allowance and a conveyance allowance may be drawn up to a maximum period of
four months by a Government servant who takes leave on average pay from the post to which theFundamental Rules and Subsidiary Rules

allowance is attached, or is transferred therefrom for not more than one month to another post, as
well as by the Government servant performing the duties of the post to which the allowance is
attached :Provided that-(a)the authority sanctioning the leave or transfer, as the case may be,
certifies that Government servant is likely to return on the expiry of his leave or his temporary duty
to the post to which the allowance is attached or to another post carrying similar allowance ;
and(b)the Government servant certifies that he continues to incur the whole or a considerable part
of the expense to meet which the allowance was granted.(2)The following are the forms of the
certificate prescribed in provisos (a) and (b) above :Certificate by the authority sanctioning the
Leave or TransferThere is every expectation of his returning to the post from which he proceeds on
leave/temporary transfer.Signature.........Designation.......Date........These certificates should be
included in the original orders sanctioning the leave or transfer.Certificate by the Government
servant proceeding on Leave or TransferCertified that for reasons furnished below I continue
necessarily to incur during the period of the...... leave..... the..... whole..... temporary transfer
approximately..... per cent of the expenses to meet which the...... allowance was
given.Signature.......Designation.........Date .........Reasons. - Examples of such reasons would
be-(1)that the leave was spent in.....(2)that the family was left in......(3)that the Government servant
was obliged to continue paying rent for his house or to maintain establishment during absence
from.............Certified by a Medical Officer on receipt of non-practising allowance proceeding on
leave or transfer."Certified that I did not undertake any private practice during the period of
leave/temporary transfer from....... to..........DateSignatureDesignation of Medical OfficerNote 1. The
expression "period of four months" in S.R. 118 (1) should be interpreted as the period on leave on
average pay whether taken alone or in combination with other leave and the allowance is not
admissible during any period of leave which is not leave on average pay.Note 2. The term
"conveyance allowance" in this rule does not include horse allowance.Note 3. In regard to the
certificate prescribed in proviso (a) above, the authority competent to control the Government
servant's posting should satisfy that there is reasonable expectation that the Government servant is,
on the expiry of his leave of temporary transfer, likely to return to the post from which he is being
relieved or to another post carrying a similar allowance. A mere hope or unsupported expectation on
the part of the Government servant should not form the basis of the certificate. The authority
sanctioning the leave or transfer should, in cases in which the above rule operates, invariably
embody in the sanctioning orders a certificate regarding such likelihood of the Government
servant's return.Note 4. [Deleted].S.R.119. - A house-rent allowance may be drawn by a Government
servant on leave or transfer, in the circumstances specified in S.R. 118 ; provided that he certifies
that his previous rate of expenditure for a house continues during his absence and that he places his
house free of rent at the disposal of the Government servant, if any, who officiates in his post. The
officiating Government servant cannot in such case draw the house-rent allowance attached to the
post. If, however, the officiating Government servant, for a reason which a competent authority
considers to be sufficient, refuses the accommodation placed at his disposal, he, and not the absent
Government servant will draw the allowance.Note. The condition prescribed in proviso (a) to S.R.
118 (1) is not applicable to a case falling under S.R.119.F.R.93A. Except as provided by Rule 64, a
Government servant transferred to a service or post to which the rules in Sections I to V of this
Chapter apply, from a service or post to which they do not apply remains under the leave rules to
which he was subject prior to his transfer : provided that it shall be open to him at time of the
transfer or any time thereafter to exercise the option of coming under the rules in Sections I to V ofFundamental Rules and Subsidiary Rules

this Chapter, subject to the conditions that all leave at his credit on the date on which he comes
under these rules shall lapse. The intention exercising this option must be specifically declared to
the State Government, and the date of such declaration shall be the date of coming under these
rules. The option once exercised is final.Note 1. Government of India's Interpretation. - (1) It has
been decided with the concurrence of the Secretary of States that F.R. 93-A should not be given
retrospective effect, and that it applies only to those persons who are transferred from one service to
another on or after the 13th of April, 1958, the date on which the rule was issued.(2)Where the leave
rules to which an officer was subject before his promotion are identical with those in the
Fundamental Rules, he gains no advantage by electing the latter. All Accounts Officers should bring
this fact to the notice of an officer when asking him to exercise his option under F.R. 93-A. [See also
the Interpretation below F.R. 77 in Section III].Interpretation of Government of India below F.R. 77
in Section III of Fundamental Rules and Subsidiary Rules, 1939, is reproduced below :Government
of India's Interpretation. - Fundamental Rule 77 permits leave earned under the Civil Service
Regulations and the Military Leave Rules to be carried forward, but it does not contemplate cases in
which the leave rules applicable to an officer before his transfer are identical with those in the
Fundamental Rules which become applicable to him after the transfer. The change of leave rules in
such cases is purely nominal and the intention was that the balance of leave standing the credit of
the officer on the date of his transfer should be allowed to stand, although the intention was not
strictly covered by the provisions of the rule [F.R. 77]. The President now makes this intention clear
by this interpretation under F.R. 8. [Government of India, Finance Department letter No. F. 7 (3)-R-
1/40, dated the 22nd February, 1940, Dy, Fin. (A)/109 of 1940].Note 2. The principle of F.R. 93-A
should apply by analogy to persons who entered Government service on or after 1st March, 1934,
and were transferred to service or post to which the Leave Rules, 1934 (Appendix 11) apply from a
service or a post to which they do not apply from the date F.R. 93-A came into operation, viz., 13th
April, 1938.Government of India's decision-Leave Rules applicable to "agency" staff. - The of
Government of India have divided the staff employed on "agency" work into the following categories
for the purpose of determining the leave rules, i.e., of the Central or State Government which should
apply in the case of such staff :(a)Personal recruited for and employed in agency Department whose
pay, leave salary, allowances and pensions are charged direct to the Central Government, i.e.,
personnel who are paid direct by the Central Government but who are technically under the
administrative control of State Government;(b)Personnel recruited and employed in connection
with the affairs of the States whose pay, leave salary, allowances and pensions are charged to States'
revenues, but whom the State Government employ temporarily on agency work. For their services
the Central Government pays the State Governments an agreed sum and the entire pensionary
charge borne by the latter ;(c)Personnel as in category (b) above whose services employed by the
State Governments part-time or casually, on performing Central Agency duties, for their services of
the Central Government usually pays an agreed sum to the State Government, which includes
pensionary liability;(d)Personnel falling in either of the three categories given above who have now
come under the direct control of the Central Government on resumption by them of the
administrative control over certain agency functions.Category (a). - Those officers belonging to this
category who entered the service of a State Government on or before the 31st March, 1937, would
remain under the State rules and the Central Government would meet their share of leave and
pensionary charges as calculated under those rules.Officer recruited on or after the 1st April, 1937
for employment in agency Departments will be governed by the leave rules of the CentralFundamental Rules and Subsidiary Rules

Government. In the case of such officers, however, who were on the date of issue of the Government
of India's decision, viz., 6th January, 1914, governed by the leave rules of the State Government, it
shall be open to them to exercise the option of remaining under State Government's leave rules or of
coming under the Central Government's leave rules on the principles and conditions laid down in
F.R. 93-A.Categories (b) and (c). - Officers falling under those two categories (irrespective of dates
of recruitment) will remain under the State Government's leave rules.Category (d). - Officers
belonging to this category will be given an option of remaining under the State Government's leave
rules or of coming under the Central Government's leave rules on the principles and conditions laid
down in F.R. 93-A.Section VI-Exceptions and Special ConcessionsF.R.94. The rules in Sections I to
V of this Chapter are not applicable to the Chairman or a Member of the Public Service Commission
whose leave is governed by regulations made by the Governor in his discretion under Clause (a) of
sub-Section (2) of Section 265 of the Act [Appendix 10].F.R.94A. [Deleted].F.R.94B.
[Deleted].F.R.95. [Deleted].F.R.96. [Deleted].F.R.97. [Deleted].F.R.98. [Deleted].F.R.99.
[Deleted].F.R.100. [Deleted].F.R.100A. The following provisions apply to Government servants
placed on deputations out of India under conditions declared by the State Government to be
quasi-European if the period of the deputation exceeds one year :(a)The period of deputation shall
not count as duty for the purposes of this Chapter;(b)The amount of leave which can be earned by
the deputation shall be determined by the State Government. Such leave can only be taken during
the period of deputation and will not be credited or debited in the Government servant's leave
account;(c)Leave-salary during such leave shall be equal to the rate of deputation pay:Provided that
where a deputation originally sanctioned for one year or less is subsequently extended so that the
total period exceed one year, these provisions shall apply in respect of the period in excess of one
year.F.R.101. The State Government may make rules regulating the grant to Government servants
under its control of-(a)maternity leave to female Government servants ; and(b)leave on account of
ill-health to members of subordinate services specified in such rules duties expose them to special
risk of accident or illness.Such leave is not debited against the leave account.Maternity
LeaveS.R.120. - A competent authority may grant to a female Government servant maternity leave
on full pay for a period which may extend up to the end of three months from the date of its
commencement, or the end of six weeks from the date of confinement, whichever be earlier.Note.
Maternity leave under this rule may be granted in cases of miscarriage, including abortion, subject
to the following conditions :(i)that the woman Government servant if temporary has been in service
for not less than one year before the commencement of the leave ; and(ii)that the leave does not
exceed six weeks and the application is supported by a certificate from the authorised Medical
Attendant.Government of Assam's decision. - (1) Maternity leave under this rule also is admissible
to temporary female Government servants who have completed one year's continuous service.(2)A
female Government servant having three children will not be entitled to any maternity leave after
20th September, 1977.Government of AssamFinance Establishment (A) Department
No. FEG 23/78/323 Dated Dispur, the 4th March, 1986
Office MemorandumAfter considering aspects of the matter it has been decided that the maternity
leave granted to a female Government servant under S.R.120 of Fundamental Rules and Subsidiary
Rules shall be for a period of 90 days from the date of its commencement in all cases, i.e., it shall not
be restricted to six weeks from the date of confinement as at present.This takes effect from 1-1-1986,
i.e., this benefit will also be extended to those female Government servants who were on maternity
leave on 1-1-1986.Necessary amendment to the Revised Leave Rules, 1934 will follow.JointFundamental Rules and Subsidiary Rules

Secretary to the Governmentof AssamFinance DepartmentS.R.121. - (a) Maternity leave may be
combined with leave of any other kind.(b)Notwithstanding the provisions contained in Rule 13 (c) of
the Leave Rules, 1934 any leave (including commuted leave) for a period not exceeding 60 days,
applied for in continuation of Maternity leave may be granted without production of medical
certificate.(c)Leave in further continuation of leave granted under Clause (b) above may be granted
on production of a material certificate for the illness of the female Government servant. Such leave
may also be granted in case of illness of a newly born baby, subject to production of medical
certificate to the effect that the condition of the ailing baby warrants mother's personal attention
and that her presence by the baby's side is absolutely,necessary.Hospital Leave on Account of
Ill-HealthS.R.122. - A police officer of or below the rank of Assistant Sub-Inspector or head
constable, a head warder or warder of the Jail Department, a head warder or a warder of a lunatic
asylum, a subordinate employed in a Government Laboratory, a subordinate of the Excise
Department on pay not exceeding Rs.200 or a forest subordinate (not being clerk) whose pay does
not exceed Rs.200 a month, while sick in hospital or while receiving medical aid as out-door patient
from the hospital or dispensary of the station at which he is employed, may be allowed at the
discretion of the sanctioning authority leave of absence from duty for six months altogether in any
period of three years. Such leave may be taken in one period or by instalments and may be followed
by or taken in continuation of, any other leave admissible under the rules. For the first three months
of such leave the officer may receive full pay and for the remaining three months half pay, without
the restriction that no extra cost shall be imposed upon the State. This concession shall be confined
strictly to cases in which illness shall be certified not to have been caused by irregular or
intemperate habits.This rule so far as it relates to head warders or warders of the Jail Department or
of a Lunatic Asylum includes both male and female warders.Note 1. When the illness is one caused
by irregular or intemperate habits, such as venereal disease, the period spent in hospital by the
patient and any subsequent leave granted in continuation for convalescence should be treated as
leave on medical certificate on half or quarter average pay as may be found standing at the credit of
the person concerned. Such periods will not count towards approved service increment of pay.Note
2. The expression "a subordinate employed in a Government laboratory" occurring in this rule
includes the sweepers attached to the Pasteur Institute, Shillong.Note 3. The expression "leave of
absence from duty for six months altogether in any period of three year" used in this rule shall be
interpreted to mean that not more than six months' leave may be granted to an entitled Government
servant during each spell of three years of service.S.R.123. - A Government servant may be allowed
for the first three months of such leave during which full pay is admissible to retain any
compensatory allowance or special pay attached to his appointment; provided that in the case of a
compensatory allowance there is no locum tenens drawing the allowance.S.R.124. - A man employed
in the Secretariat Press otherwise than as a permanent or temporary piece-worker in superior
service of the Shillong Drawing Office, syce whether permanent or temporary employed in the Civil
Veterinary Department and a mohout or grass-cutter in charge of a Government elephant may,
during absence from work on account of injuries received in the execution of his duty, be allowed
full pay for one month and thereafter half pay for three months.S.R.125. - Hospital leave is not
debited against the leave account and may be combined with any other leave which may be
admissible ; provided that the total period of leave, after such combination, shall not exceed 28
months.F.R.102. [Deleted].F.R.103. The State Government may make rules regulating the leave
which may be earned by-(a)temporary and officiating service ;(b)service which is continuous ;Fundamental Rules and Subsidiary Rules

and(c)part time service, or service which is remunerated wholly or partially by the payment of
honoraia or daily wages :Provided that the such rule shall not grant more favourable terms than
would be admissible if the services were substantive, permanent and continuous.[For model terms
regulating the grant of leave to Government officials engaged on contract, see Appendix 17].Leave
Earned by Temporary and Officiating ServiceS.R.126. - A competent authority may grant to a
temporary engineer of the Public Works leave on such terms and such leave salary as it may think
fit; provided that the leave and leave-salary are not in excess of those admissible to a Government
servant subject to the ordinary leave rules.S.R.127. - Leave may be granted to any other Government
servant without a lien on a permanent post while officiating in a post or holding a temporary post;
provided that the grant of the leave involves no expenses to Government. On this condition such a
Government servant may be granted-(a)leave on leave-salary equivalent to average pay up to
one-eleventh of the period spent on duty, subject to a maximum of four months at a time; or(b)on
medical certificate, leave on leave-salary equivalent to half-average pay to two-eleventh of the period
spent on duty, subject to maximum of three months at a time ; or(c)extraordinary leave for three
months at any time.Note 1. Leave under any one clause may be combined with leave under any other
clauses subject to the general condition that no additional expense to Government is involved.Note
2. When supernumerary officers in excess of the actual working strength are provided in a
temporary cadre for the purposes of falling temporary vacancies, leave may be granted under this
rule to a member of the temporary cadre notwithstanding the fact that expenditure by way of
travelling allowance is incurred in relieving him.Note 3. The provisions of this rule will apply to
officers of Asiatic domicile recruited in the United Kingdom or in India for service on contract, but
in their case the condition that the grant of leave should involve no expenses to Government does
not apply.Exception. - In the case of Government servants who have rendered five or more years'
continuous temporary service, a competent authority may dispense with the condition laid down in
this rule that the grant of leave should involve no expense to Government but in the case of
Government servants in inferior service, the leave-salary should in no case exceed what is
admissible under S.R. 135.S.R.128. - If such a Government servant is, without interruption of duty
appointed substantively to a permanent post, his leave account will be credited with the amount of
leave which he would have earned by his previous duty if he had performed it while holding
permanent post substantively, and debited with the amount of leave actually taken under Rule 127.
Leave taken under Rule 127, is not an interruption of duty for the purpose of this rule.S.R.129. -
Temporary and officiating service rendered under another Government whether Central or
Provincial will, if followed by confirmation under the Government of Assam, be taken into account
for the purpose of the leave account maintained under F.R. 77 (b); provided that rules laid down by
the other Government such service would have counted had the Government servant in question
continued in the service of that Government without a break till confirmation.Leave Earned by
Non-Continuous and Part-Time ServiceS.R.130. - A Government servant employed in an
establishment the duties of which are not continuous but are restricted to certain fixed periods in
each year, or who belongs to a part-time service, is not entitled to leave with allowance.Exception. -
A part-time teacher of an educational institution may, during leave, be allowed leave salary subject
to the condition that it shall exceed what remains from his pay after provision has been made for the
efficient discharge of the duties of the post during his absence ; where, however, such provision is
made the leave-salary shall be limited to half of the absentee's pay at the time of taking leave.Note 1.
Government Pleaders and Public Prosecutors who receive retainers may keep the retainer duringFundamental Rules and Subsidiary Rules

leave allowance by the Legal Remembrancer ; provided that he makes arrangements that no extra
cost to Government is entitled.Note 2. The Advocate-General may keep his retainer during have
allowed by Government; provided that he makes such arrangements that no extra cost to
Government is involved.Leave Admissible to Government Servants Remunerated by Honoraria or
Daily WagesS.R.131. - A Government servant remunerated by honoraria may be granted leave at the
discretion of the appointing authority ; provided that he makes satisfactory arrangements for the
performance of his duties that no extra expense is caused to Government and that during leave the
whole of the honoraria or allowance are paid to the person who officiates in his post.Note.
Government Pleaders remunerated by honoraria are allowed leave by the Legal Remembrancer;
provided arrangements can be made for their work and their honoraria are paid to the person who
officiates.Leave Rules Applicable to Permanent Piece Workers Employed in the Assam Government
Press who are not Classed as "Inferior"N.B. - See Appendix 18 as regards Leave Rules for Press
Employees entering service on or after the 1st March, 1934.S.R.132. - (1) (a) Leave on average pay
will be granted to piece workers according to their service as shown below :
Length of service Leave admissible
Less than 10 years 16 days in each calendar year
Ten years but less than 15 years 23 daysditto.
Fifteen years and above 31 daysditto.
Note. In calculating the length of service, the period of continuous temporary service rendered by a
piece-worker up to the date of his being brought on the permanent establishment as well as
continuous inferior service rendered up to the date of his promotion to superior service shall be
taken into account.(b)This leave will be non-cumulative i.e., any leave not taken during the year will
lapse without any monetary compensation.(c)Gazetted holidays actually enjoyed may at the option
of the piece-worker, be counted against any leave admissible to him under sub-Rule (a) and if so
counted, will be paid for.(d)The grant of leave under these rules cannot be claimed as a right, and
can be refused by the Superintendent of the Press on administrative grounds. It may also be
withheld from piece- workers who have been irregular in attendance.(2)Leave on medical certificate
on half-average pay will be earned at the rate of one month's leave for every complete period of
eleven months' duty, and as regards incomplete periods one day's leave for every eleven days' duty.
It will be cumulative and will be granted only when no average pay leave is admissible.(3)Leave
without pay may be granted when no other leave is admissible.(4)No continuous period of leave
with pay shall exceed one year ; an extension over one year shall be leave without pay.(5)Injury leave
at half pay rates may be granted to a piece- worker who is injured in circumstances which would
have given rise to a claim for compensation under the Workmen's Compensation Act, 1923 (8 of
1923), [Now the Employees' Compensation Act, 1923] if he had been a workman as defined therein,
whether or not proviso (a) to sub-Section (1) of Section 3 of that Act is applicable. Such leave shall
not be deemed to be leave on medical certificate for the purposes of sub-Rr. (2) and (4). It shall be
granted from the commencement of the disablement so long as is necessary, subject to a limit of two
years for any one disability and a limit of five years during a piece-worker's total service. The salary
payable in respect of a period of leave granted under this rule shall, in the case of a piece-worker to
whom the provisions of the Workmen's Compensation Act, 1923 (8 of 1923) [Now the Employees'
Compensation Act, 1923] apply, be reduced by the amount of compensation paid under Clause (d) of
sub-Section (1) of Section 4 of the Act.Note 1. Pay for average pay means remuneration at class ratesFundamental Rules and Subsidiary Rules

at the time of taking leave.The calculating is : Class rate multiplied by 7, to get the daily rate,
multiplied by the number of days' leave. Thus, if a piece- worker whose class rate is 2 annas per hour
applies for leave for 10 days he will be entitled to Rs. 8-12-0 and Rs. 4-6-0 as leave salary during
leave on average pay and half average pay respectively.For calculating the class pay of a
piece-worker who is promoted to a post on a time-scale of pay, a month is taken to be 175
hours.Note 2. For the purposes of determining the classification of service of a piece-worker who
may be in superior service in one month and in inferior service in another month on account of
fluctuations in his earnings, the monthly emoluments shall be taken as equivalent to two hundred
times his hour by class rate.Note 3. The above rules shall also apply to temporary piece- workers in
superior service who have rendered three years' continuous service.Note 4. (a) Leave for 16 days
each year at class rates may be given to temporary piece-workers, in superior service with less than
three years' continuous service and to piece-workers in inferior service whether permanent or
temporary to cover absences on account of holidays, sickness or leave; provided that the worker has
been in regular employment for the previous twelve months.(b)The term "regular employment"
shall be interpreted as not less than 90 per cent of the required working hours; regarded should be
had to absence in the case of sickness.(c)The leave shall be non-cumulative, i.e., any leave not taken
during the years shall lapse.Note 5. When a piece-worker after working for certain periods on a
working day goes on leave for the remaining hours of the day, he will be treated as on leave for the
whole day and will receive leave-salary admissible to him under the rules in addition to the payment
for the value of work done before leave office.F.R.104. During their period of probation or
apprenticeship, probationers and apprentices may be granted leave as follows :(a)If appointed
under contract with a view to permanent service, or if appointed to posts created temporarily with
the prospect, more or less definite of becoming permanent-to such leave as is prescribed in their
contract, or when no such prescription is made, to leave in accordance with the model leave terms in
Part I, I or III of Appendix 17, as the case may be ;(b)if appointed otherwise-to such leave as is
admissible under rules framed in this behalf by the State Government, subject to the proviso in F.R.
103.Grant of Leave to Probationers and ApprenticesS.R.133. - Leave may be granted to a
probationer if it is admissible under the leave rules would be applicable to him if he held his post
substantively, otherwise than on probation.S.R.134. - Leave of the following kinds may be granted to
an apprentice :(a)on medical certificate-leave on leave-salary equivalent to half pay for a period of
not exceeding one month in any year of apprenticeship ;(b)Extraordinary leave under F.R. 85.Leave
Rules of Government Servants in Inferior ServiceS.R.135. - (a) Leave may be granted to a
Government servant in inferior service so far as it can be done without imposing any cost upon the
State. The absentee allowance of the substantive incumbent shall be regulated in accordance with
F.R. 87.(b)In cases where no absence allowance is admissible under Clause (a) a Government
servant in superior service may be given extraordinary leave without allowance even though other
leave is admissible. Similarly, where the absentee allowance admissible amounts to less than half
pay an officer in inferior service may at his own option be given extraordinary leave without
allowances instead of other leave.Note. In deciding whether to grant extraordinary or ordinary leave
officers should bear in mind that provisions of F.R. 26 (b).S.R.136. - (1) The following rules govern
the grant of leave to Government servants of the following clauses serving in the Assam State Survey
Department and not being members of the upper subordinate service or of the establishment of the
headquarter office in Shillong :(a)Subordinates not being Class IV Government servants ;(b)Menials
attached to parties or offices.(2)In addition to leave under Chapter X of the Fundamental RulesFundamental Rules and Subsidiary Rules

departmental leave any be granted in the circumstances and on the conditions prescribed in sub-Rr.
(3) to (7) below.(3)(a)Departmental leave may not be granted except of a Government servant whose
services are temporarily not required.(b)It may be granted with the previous approval of the Deputy
Director Assam (Surveys) during the recess by the head of the party or officer to which the
Government servant belongs ; provided, in the case of a menial, that the officer granting the leave
consider it desirable to re-employ the menial in the ensuing sessions.(c)It may be granted at times
other than the recess, for not more than six months at a time, by the Director of Survey, Assam ;
provided that the leave is granted in the interests of Government and not at the Government
servant's own request; and leave so granted may in special cases be extended by the Director of
Surveys, Assam up to a maximum of one year in all. Leave on medical certificate should never the
regarded as granted in the interest of Government.(4)A Government servant while on departmental
leave shall be paid leave salary not exceeding half pay but not less than 10 (ten) per cent of pay on
duty at the end of each month and thereafter it shall be paid when the Government servant returns
to duty. If, however, a Government servant dies while on departmental leave, his leave salary up to
the date of his death will be paid to his heirs. The departmental leave does not count as duty and
such leave shall not be debited to leave account. This takes effect from the date of
order.(5)Departmental leave may be granted when no leave is due. Departmental leave granted shall
not be taken into account when calculating the maximum amount of leave admissible under F.R. 81
(a).(6)Departmental leave may be combined with any other kind of leave which may be
due.(7)When a Government servant subject to these rules holds a post in which the Director of
Survey, Assam, considers that he is unlikely to be eligible for departmental leave in future, the
Director of Survey, Assam, may, by special order in writing, declare that, with effect from such date,
not being earlier than the Government servant's last return from departmental leave as the Director
of Surveys, Assam may fix, any balance of leave at debit in the Government servant's leave account
shall be cancelled. All leave earned, after such date will be credited as due in the Government
servant's leave account, and all leave taken after such date, including departmental leave, if any, will
be debited in it.
Part V – Chapter XI
Joining TimeF.R.105. Joining time may be granted to a Government servant to enable him-(a)to
join a new post either at the same or a new station without availing himself of any leave on
reliquishing charge of his old post ;(b)to join in new station on return from-(i)leave of not more than
six month's duration ;(ii)leave other than that specified in sub-Clause (i) when he has not had
sufficient notice of his appointment to new post;(c)(i)to proceed on transfer or on the expiry of leave
from a specified station on join a post in a remote locality which is not easy of access;(ii)to proceed
on relinquishing charge of a post, on transfer or leave, in place in remote locality which is not easy of
access to a specified station.Note. If a State Government servant who is appointed to a post under
the Central Government while on duty in his old post but who joins his new post after termination of
his employment under the State Government by resignation or otherwise, neither travelling
allowance nor joining time or joining time pay should be granted except when the employment of a
particular Government servant is in the wider public interest.Audit Instructions. - (1) If a
Government servant is authorised to make over charge of an office elsewhere than at his
headquarters, any joining time to which the may be entitled shall be reckoned from the place atFundamental Rules and Subsidiary Rules

which he actually makes over charge.(2)The intention of sub-Clause (1) of F.R. 105 (b) is that joining
time should be allowed to those Government servants who are granted privilege leave or leave on
average pay for not more than four months, and who are transferred to new section on the
termination of such leave.(3)If vacation is combined with leave, joining time should be regulated
under Clause (b) (i) of F.R. 105, if the total period of leave and vacation combined is of not more
than four months' duration and under Clause (c) if the leave out of India and vacation combined is
more than four months.(4)In the case of a Government servant who is appointed while on leave of
not more than four months' duration to a post other than that from which he took leave, the full
joining time calculated under Subsidiary Rule 145 is admissible irrespective of the date on the which
the orders of transfer were received by the Government servant concerned. Should the Government
servant join his new appointment before the expiry of such leave plus the joining time admissible,
the period short taken should be considered as leave not enjoyed and a corresponding portion of the
leave sanctioned should be cancelled without any reference to the authority which granted the leave.
If in any case, the Government servant desires not to avail himself the full period of joining time
admissible, the period of leave and joining time should be adjusted with reference to such
option.(5)Joining time under F.R. 105 (c) is reckoned from the date of disembarkation at an Indian
Port. Colombo is not regarded as an Indian Port for this purpose.(6)Joining time under F.R. 105 (c)
is admissible to a Government servant for organising his domestic establishment even if he does not
make any journey from the port of disembarkation.(7)If a Government servant returns from leave
out of India for a period exceeding four months' duration, the termination of his leave is governed
by F.R. 68 and the joining time for the journey (a) from the port of disembarkation to the "fixed
point" and (b) from the "fixed point' onwards is governed by the Subsidiary Rules framed under F.R.
105 (c) and F.R. 105 (d) respectively. The Government servant should be paid under F.R. 107 (b) for
the portion of the joining time registered under F.R. 105 (c) and under F.R. 107 (c) for the portion
regulated under F.R. 105 (d).F.R.106. The State Government may make rules regulating the joining
time admissible in each of the cases mentioned in F.R. 105 and specifying the places and stations to
which Clause (d) of that rule shall apply. Such rules should be framed with due regard to the time
required for actual transit and for the organization of domestic establishment.S.R.137. -
Government servants posted at the places named in Col. (1) of the following table are entitled to
joining time under F.R. 105 (d) during journey as made while proceeding on or returning from
leave, between any such place and the station named against it in Col. 2 of the table. The amount of
joining time admissible between such places and stations is either the actual time spent on the
journey or the period shown for the journey in Col. 3 of the table, whichever is less : provided that
the journey shall be held to commence on the day following either the handing over of the charge of
the Government servant's post or arrival at the station named in Col. 2 of the table, according as the
Government servant is departing on or returning from leave :
Journey between Period
Place Station
1 2 3
Naga Hills
Poekrokejama Kohima 6 days
Henema Do 6 daysFundamental Rules and Subsidiary Rules

Workha Merapani 4 days
Mokochung Charali 4 days
Wokha Do 4 days
United Khasi and
Jaintia Hills
Nongstoin Shillong 4 days
Nongtalang Do 4 days
Umpanai Do 5 days
Kuliang Do 5 days
Jeliakhola Do 4 days
Moheskhola Do7 days (8 days
in rainy
season)
Kairabari Do6 days (7 days
in rainy
season)
Borsora Do5 days (6 days
in rainy
season)
Bolabheta Do 4 days
Tilligaon Do 3 days
Balat Do3 days (4 days
in rainy
season)
Sonatola Do3 days (4
(days in rainy
season)
Lilong Do 3 days
Donna Do 4 days
Sonapur Do 3 days
Sadia Frontier Tract
Denning Sadiya 5 days
Rotung Do 5 days
Yembung Do 6 days
Majum Do 3 days
Mizo District
AijalKukichhera
(Cachar) via
Sairang7 daysFundamental Rules and Subsidiary Rules

Siaisuk Do 10 days
Chamaphai Do 15 days
North Vanlaiphai Do 14 days
Lungleh Do 15 days
Demagiri Do 19 days
Tuipang Do 22 days
Saicha Do 20 days
Bualpui (Lungleh)
Sub-DivisionKukichhera
(Cachar) via
Lungleh21 days
Buarpui (Lugleh
Sub-division)Do 19 days
Vahai Do 25 days
SairangKukichhera
(Cachar)6 days
AijalBhaga Bazar
(Cachar)2 days
SairagBhaga Bazar
(Cachar) via Aijal3 daysThe Controlling Officer may allow an
additional period up to alimit of 4 days in
all these cases for the journey between
Aijaland Bhaga Bazar for delay in getting
motor conveyance, break downof motor
conveyance on way or journey on foot,
subject toproduction of satisfactory
evidence.
Sialsuk Do 5 days
Chamaphai Do 10 days
North Vanlaiphai Do 9 days
Lungleh Do 10 days
Demagiri Do 14 days
Tuipang Do 18 days
SaichaBhaga Bazar
(Cachar) via
Lungleh and Aijal16 days
Bualpui (Lungleh
Sub-division)Ajal 17
days   
Buarpui Do Do 15 days  
Vahai Do Do 21 days  
Kolasib 21 daysFundamental Rules and Subsidiary Rules

Bhaga Bazar
(Cachar)The Controlling Officer may allow an!
additional period up toa limit of 2 days
for the journey between Bhaga Bazar and
Kolasibon above mentioned ground and
term.
Note 1. If the Government servant arrives at the station on the forenoon of the day following the day
on which his leave expires and proceeds forthwith to the next stage he may be held to have arrived at
the station within the period of his leave.Note 2. The scope of this rule is also extended to case of
transfer or to a station in a remote locality which is not easy of access.Note 3. The rout to Lungleh
Sub-division through Aijal either via Kukichherra, or Dwarband is a recognised one for Government
servants performing journeys on duty to and from Lungleh Sub- Division.Joining TimeS.R.138. -
Not more than one day is allowed to a Government servant in order to join a new post when the
appointment to such post does not necessarily involve a change of residence from one station to
another. A holiday counts as a day for the purpose of this rule.S.R.139. - In cases involving necessary
change of station the joining time allowed to a Government servant is subject to a maximum of 30
days. Six days are allowed for preparation and in addition, a period to cover the actual journey
calculated as follows :(a)A Government servant is allowed-
(i)For the portion of the journey which he
travels by aircraft.Actual time occupied in
the journey.
(ii)For the portion of the journey which he
travels or mighttravel.One day for each.
 By railway 500 Km.Or any longer time actually
occupied in the journey.
 By ocean steamer 350 Km.
 By river steamer 150 Km.
 By motor-car, horse-drawn conveyance
plying for public hire150 Km.
 In any other way 25 Km.
(b)For any fractional portion of any distance prescribed in (a) an extra day is allowed;(c)When part
of the journey is by steamer, for the limit of six days for preparation may be extended to cover any
period unavoidably spent in awaiting the departure of the steamer ;(d)Travel by road not exceeding
8 kms. to or from railway station at the beginning or end of a journey does not count for joining time
;(e)A Government servant whose pay does not exceed Rs. 100 is not ordinarily expected to travel by
motor-car or horse-drawn conveyance plying for public hire, and his joining time is calculated
accordingly;(f)A Sunday does not count as day for the purpose of the calculations in this rule, but
Sundays are included in the maximum period of 30 days.S.R.140. - When a Government servant,
returning from leave out of India exceeding four months, takes joining time before joining his post,
his joining time shall be calculated as prescribed in Subsidiary Rule 139 : provided that it shall, if he
so desires, be subject to minimum ten days.S.R.141. - By whatever route a Government servant
actually travels, his joining time shall, under a competent authority for special reasons otherwise
orders, be calculated by the route which travellers ordinarily use.S.R.142. - If a Government servant
is authorized to make over charge of post a elsewhere than at its headquarters, his joining time be
calculated from the place at which he makes over charge.S.R.143. - If a Government servant isFundamental Rules and Subsidiary Rules

appointed to a new post while in transit from one post to another, his joining time begins on the day
following that on which he receives the order of appointment.S.R.144. - If a Government servant
takes leave while in transit from one post to another, the period which has elapsed since he handed
over charge of his old post must be included in his leave. On the expiry of the leave, the Government
servant may, however, be allowed normal joining time :Provided that in cases where leave on
medical grounds is taken after availing of normal joining time, the split up of the spell of absence
allowing time first and leave afterwards may be allowed to stand.S.R.145. - If a Government servant
is appointed to a new post while on leave (whether spent in or out of India) on average pay of not
more than four months' duration, his joining time will be calculated from his old station or from the
place in which he received the order of appointment, whichever calculation will entail him to lessen
the joining time.S.R.146. - A competent authority may in any case extend the joining time
admissible under these rules; provided that the general spirit of the rules is observed.Note. If a
Government servant is transferred from one post to another but the transfer order is subsequently
cancelled, after he has handed over charge of his old post but before he could take charge of the new
post, the period intervening the date of handing over charge of the old post and taking over charge
of the same post or any other post later on account of cancellation of transfer orders should be
treated as joining time.This takes effect from the date of issue of orders.S.R.147. - Within the
prescribed maximum of 30 days, a competent authority may, on such conditions as it thinks fit,
grant to a Government servant a longer period of joining time than is admissible under the rule in
the following circumstances :(a)when the Government servant has been unable to use ordinary
mode of travelling or, notwithstanding due diligence on his part has spent more time on the journey
than is allowed by the rules ; or(b)when such extension is considered necessary for the public
convenience, or for the saving of such public expenditure as is caused by unnecessary or purely
formal transfer ; or(c)when the rules have in any particular case operated harshly ; as for example,
when a Government servant has through no fault on his part missed a steamer or fallen sick on the
journey.S.R.148. - When a Government servant under the administrative control of the Government
of Assam is transferred to the control of a Government, which has made rules prescribing amounts
of joining time, his joining time for journey to join his post under that Government and for the
return journey will be governed by those rules.F.R.107. A Government servant on joining time shall
be regard as on duty and shall be entitled to be paid as follows :(a)where joining time granted under
Clause (a) of Rule 105-the pay which he would have drawn if he had continued in the old post or the
pay which he will draw on taking charge of the new post, whichever is less.[See Audit Instructions
under F.R. 20].Note. A temporary Government servant is entitled to joining time pay when his
transfer is arranged in the interests of the public service and while he still holds a temporary post.
This concession is not, however, admissible to him if the transfer takes place after the term of the
temporary post has ended,-(b)where the joining time is granted under Clause (b) of Rule 105-(i)if it
is in continuation of leave which included a period of leave on average pay-pay equal to the leave
salary which he last drew during such leave on average pay at the rate prescribed for payment of
leave salary in India ; and(ii)if it is in continuation of leave with did not include a period of leave on
average pay-pay equal to the leave salary which the Government servant would have drawn under
the leave rules applicable to him as if he had been on leave on average pay in India for the period of
joining time ;(c)where joining time is granted under Clause (c) of Rule 105-the pay which he would
draw in his post in the remote locality :Provided that-(i)a Government servant on transfer shall not
be entitled to any pay for the period of joining time unless his transfer is in the interests of publicFundamental Rules and Subsidiary Rules

service;(ii)no joining time pay shall be granted to a Government servant who does not hold a
permanent post under Government in a substantive capacity or a post under the Central
Government in a quasi-permanent capacity, when he is appointed to a new post on the result of a
competitive examination or interview which is open to both Government servants and others.State
Government's decisions. - The pay of Government servant, transferred to a post on return from
leave should, during the period of taking over charge, be regulated as follows:If he went on leave
while working in a post in an officiating capacity the officiating pay of that post or the pay which will
be admissible to him in the new post after taking over charge, whichever is less.F.R.108. A
Government servant who does not join his post within his joining time is entitled to no pay or
leave-salary after the end of the joining time. Wilful absence from duty after the expiry of joining
time may be treated as misbehaviour for the purpose of F.R. 15.F.R.108A. A person in employment
other than Government service or on leave granted from such employment, if in the interest of
Government he is appointed to a post under the State Government, may, at the discretion of the
State Government, be treated as on joining time while he prepares for and makes the journeys to
join the post under Government, and while he prepares for and makes the journey on reversion
from the post under Government to return to his original employment. During such joining time he
shall receive pay equal to the pay, or, in the case of joining time immediately following leave granted
from the private employment, to the leave-salary, paid to him by his private employer prior to his
appointment to Government service, or pay equal to the pay of the post in Government service,
whichever is less.
Part VI – Chapter XII
Foreign ServiceF.R.109. The rules in this Chapter apply to those Government servants only who are
transferred to foreign service after the 1st January, 1922.F.R.110. (a) No Government servant may be
transferred to foreign service against his will; provided that this sub-rule shall not apply to the
transfer of a Government servant in the service of-(i)a body, incorporated or not, which is wholly or
substantively owned or controlled by the Government, and(ii)an Autonomous District Council.(b)A
transfer to foreign service in or outside India including transfer to the service of Indian State may be
sanctioned by the State Government.Audit Instruction. - The Government which would be entitled
to recover pension contribution on half of a Government servant lent to foreign service should be
regarded as the State Government competent to sanction his transfer to foreign service.Government
of India's orders. - The Government of India and the Crown Representative will be glad to be
consulted before hand in regard to any request for the loan of the services of State officers from a
foreign country outside the British Empire and from an Indian State respectively, in order that they
may have an opportunity of considering the proposal from the point of view of their respective
responsibilities. The State Government will doubtless give full weight to any views which the
Government of India or the Crown Representative may express on such consultation.Note. The
Government of India in consultation with the Crown Representative have decided that the latter
need only be consulted before hand in case of officers belonging to the State and All India Services
on their transfers to foreign service in the Indian State.F.R.111. A transfer to foreign service is not
admissible unless-(a)the duties to be performed after the transfer are such as should, for public
reasons, be rendered by a Government servant, and(b)the Government servant transferred holds, at
the time of transfer, a post paid from the revenues of the State or holds a lien on a permanent post,Fundamental Rules and Subsidiary Rules

or would hold a lien on such a post had his lien not been suspended.Note. The transfer of a
temporary Government servant to foreign service is permissible.F.R.112. If a Government servant is
transferred to foreign service while on leave, he ceases from the date of such transfer, to be on leave
and to draw leave-salary.Note 1. In the case of an officer who takes up employment in an Indian
State during leave preparatory to retirement, the concession of drawing leave-salary during such
leave in addition to pay from the Indian State should not be granted. In such cases he should be
required either to retire or go on foreign service terms subject to the fulfilment of the condition in
Clause (a) of F.R. 111.Note 2. The concession of treating employment in an Indian State during leave
preparatory to retirement as private employment should not be granted to an officer who is in
foreign service at the time he applies for such leave and proposes to continue on duty in the service
of the same employer during the leave.Note 3. The decision referred to above should apply to all
foreign service, and not only to service in an Indian State.F.R.113. (i) A Government servant
transferred to foreign service shall remain in the cadres or cadre in which he was included in a
substantive or officiating capacity immediately before his transfer, and may be given, subject to
conditions prescribed under the second proviso to F.R. 30 (1), such substantive or officiating
promotion in those cadres as the authority competent to order promotion may decide. In giving
promotion such authority shall also take into account the nature of the work performed in foreign
service.(ii)Nothing in this rule shall prevent a member of a subordinate service from receiving such
other promotion in Government service as the authority who would have been competent to grant
the promotion, had he remained in Government service, may decide.F.R.114. A Government servant
in foreign service will draw pay from the foreign employer from the date on which he relinquishes
charge of his post in Government service Subject to the observance of the principle laid down in
Appendix 19, the amount of his pay, the amount of joining time admissible to him and his pay
during such joining time will be fixed by the authority sanctioning the transfer in consultation with
the foreign employer.Government of India's decisions. - 1. The Government of India have decided
that in the case of an officer transferred to foreign service in India, who is at the time of such
transfer holding in an officiating capacity a post from which he is unlikely to revert, his pay in
foreign service may be fixed on the basis of his officiating pay. The authorities to whom power in this
respect has been delegated should therefore take into account for the purpose of fixation of pay in
foreign service officer's substantive pay or in the case mentioned above, his officiating pay in
Government service. The Government of India have also decided that special pay, personal pay or
emoluments classed as pay under F.R. 9 (21) (a) (iii) should, in no case, be taken into account in
regulating foreign service pay.The above decision will apply to transfer to foreign service in India or
extension of the period thereof sanctioned on or after the date of issue of this letter.
2. (a) The question of fixing the liability of the foreign employer was raised in
regard to the payment of-
(1)leave-salary during disability leave granted to Government servants sustaining war injuries,
and(2)increased pension contribution on account of such disability leave.The President has, after
careful consideration, decided that foreign employers should, in the case of Government servants
transferred to foreign service in future or on renewal of existing foreign service agreements, accept
liability for leave- salary in respect of disability leave granted on account of a disability incurred in
and through foreign service, even though such disability manifests itself after the termination ofFundamental Rules and Subsidiary Rules

foreign service. The leave-salary charges for such leave should be recovered direct from foreign
employers, a condition to this effect being inserted in the terms of transfer to foreign service. In
present conditions no additional pension contributions need be recovered in respect of the period of
disability leave.(b)In the case of permanent State Government servant lent to the Central Defence
Services, the Defence Service estimates will bear the leave salary charges in respect of disability
leave granted to them while in such services, on account of disabilities incurred in and through such
service, in addition to the ordinary leave contributions at foreign service rates payable during such
service, excluding periods of leave. As regards the pensionary liability in respect of periods of
disability leave in such cases, it is hoped that the State Government will, as a practical solution and
in view of the very small amounts involved, not insist on extra contribution. This course is in line
with the Central Government's decision regarding pension contributions from foreign employers in
respect of their own servants.Decision by the Government of Assam. - The Government of Assam
have decided not to insist on extra contribution towards pensionary liability in respect of periods of
disability leave granted to their own servants while employed in the Defence Services.Audit
Instruction. - When any Government servant lent on foreign service conditions retires from British
service without, at the same time, retiring from the service of his foreign employer, the Audit Officer
shall communicate to the foreign employer through the usual authorities a statement showing the
date of retirement and the amount of pension drawn from the British Government so as to give that
employer the opportunity if he be so inclined, of revising the existing terms of employment.Note. No
Government servant shall be transferred to foreign service unless the foreign employer undertakes
to afford to him at the employer's own expense privileges as regards medical attendance not inferior
to those which he would have enjoyed if he had been employed in the service of the Government of
Assam or reimburse the cost incurred by that Government for the provision of such
privileges.F.R.115. (a) While a Government servant is in foreign service, contributions towards the
cost of his pension must be paid to the revenues of the State on his behalf.(b)If the foreign service is
in India, contributions must be paid on account of the cost leave-salary also.(c)Contributions due
under Clauses (a) and (b) above shall be paid by the Government servant himself, unless the foreign
employer consents to pay them. They shall not be payable during taken while in foreign
service.(d)By special arrangement made under Rule 23 (b), contributions on account of leave-salary
may be required in the case of foreign service out of India, also the contributions being paid by the
foreign employer.Note 1. Pension, throughout this Chapter, includes Government contributions, if
any, payable to a Government servant's credit in a Provident Fund.Note 2. In the case of
Government servant lent to His Majesty's Government or to British colonies or protectorates, the
contribution is payable by the employer, except in the case of Government servants lent to the War
Office whose contributions are paid in accordance with special arrangements with the War
Office.State Government's decision. - In the case of Government servant in foreign service in India,
a contribution on account of leave salary is recoverable from the foreign employer or the
Government servant himself when the foreign employer does not consent to pay, and in return for
the contribution, Government accepts to charge leave-salary. As the rates prescribed for such
contribution have been calculated on the basis of the leave on full and half pay normally taken by
Government servant during the total period of his service, and do not take into account any
compensatory allowance, which may form part of leave salary as defined in F.R.9 (12), the
Government of Assam has decided that the whole expenditure in respect of any compensatory
allowance for periods of leave in or at the end of foreign service shall be borne by the foreignFundamental Rules and Subsidiary Rules

employer or the Government servant himself, a the case may be. In order to avoid any
misunderstanding, it is desirable that as condition to this effect should be inserted in the terms of
transfer to foreign service.S.R.149. - A copy of the orders sanctioning a Government servant's
transfer to foreign service must always be communicated to the Accounts Officer (referred to in the
next rule, by the authority by whom the transfer is sanctioned). The Government servant himself
should, without delay, communicate a copy to officer who audits his pay, and take his instructions as
to the officer to whom he is to account for the contribution : report to the latter officer the time and
date of all transfers of charge to which he is a party when proceeding on, while in and on return
from foreign service, and furnish from time to time particulars regarding his pay in foreign service,
leave taken by him, his postal address and any other information which that officer may
require.S.R.150. - (a) In the case of foreign service out of India, the "Account Officer" is the
Accountant General, Central Revenues.(b)In the case of foreign service in India-(i)if pay in foreign
service is paid from a Government Treasury and is subject to audit by an audit officer of
Government, the Accounts Officer is such audit officer ;(ii)otherwise, the Accounts Officer is the
Accountant General of the State in which the Municipality, Port Trust or other body concerned is
situated or in the case of service under an Indian State, the Accountant General of the Government
under whose administration the State is.F.R.116. The rate of contribution payable on account of
pension and leave-salary shall be such as the State Government may by general order
prescribe.Note. The rates of contributions prescribed by the President (Appendix 20) have been
adopted by the State Government as applicable to persons serving in connection with the affairs of
the State. These rates take effect from 1st January, 1939.Audit Instruction. - The leave-salary
contribution for the period of joining time taken by a Government servant in continuation of leave
under Clause (b) F.R. 105 before reversion from foreign service should be calculated on the pay he
was getting immediately before he proceeded on leave.F.R.117. (a) The rate of pension contribution
prescribed under Rule 116 will be designed to secure to the Government servant the pension that he
would have earned by service under Government if he had not been transferred of foreign
service.(b)The rates of contribution for leave-salary will be designed to secure to the Government
servant leave-salary on the scale and under the condition applicable to him. In calculating the rate of
leave-salary admissible, the pay drawn in foreign service, less in the case of Government servants
paying their own contributions, such part of pay as may be paid as contribution, will count as pay for
the purpose of F.R. 9 (2).Note. The rates of contributions prescribed by (he President in respect of
military officers and other ranks in permanent civil employ are given in Appendix 21.MSS not
available.F.R.118. [Deleted].F.R.119. The State Government's sanction of a transfer to service
may-(a)remit the contribution due in any specified case or class of cases, and(b)make rules
prescribing the rate of interest, if any, to be levied on overdue contributions.Rate on Interest to be
Levied on Overdue Foreign Service ContributionsS.R.150. - Contribution for leave salary or pension,
due in respect of a Government servant a foreign service may be paid annually within fifteen days
from the end of each financial year or at the end of the foreign service, if the deputation on foreign
service expire before the end of a financial year, and if the payment is not made within the said
period, interest must be paid to Government on the unpaid contribution, unless it is specifically
remitted by the State Government, at the rate of two paise per day per Rs. 100 from the date of
expiry of the period aforesaid up to the date on which the contribution his finally paid. The interest
shall be paid by the Government servant or the foreign employer according as the contribution is
paid by the former or the latter.F.R.120. A Government servant in foreign service may not elect toFundamental Rules and Subsidiary Rules

withhold contribution and to forfeit the right to count as duty in Government service the time spent
in foreign employ. The contribution paid on his behalf maintains his claim to pension or to pension
and leave-salary, as the case may be, in accordance with the rules of the service of which he is a
member. Neither he nor the foreign employer has any right of property in a contribution paid, and
no claim for refund can be entertained.F.R.121. A Government servant transferred to foreign service
may not, without the sanction of the State Government, accept a pension or gratuity from the
foreign employer in respect of such service.F.R.122. A Government servant in foreign service in
India may not be granted leave otherwise than in accordance with the rules applicable to the service
of which he is member, may not take leave or receive leave-salary from Government unless he
actually quits and goes on leave.Note 1. A Government servant on foreign service in India is himself
personally responsible for the observance of the rule contained in F.R. 122, by accepting leave to
which he is not entitled under the rules he renders himself liable to refund leave-salary drawn, and
in the event of his refusing to refund, to forfeit his previous service under Government, and to cease
to have may claim on Government in respect of either pension or leave-salary.Note 2. The grant of
leave preparatory to retirement to an officer in foreign service may not be coupled with permission
to continue in the service of the same employer during that leave.F.R.123. (a) A Government servant
in foreign service out of India may be granted leave by his employer on such conditions as the
employer may determine. In any individual case the State Government may determine before hand
in consultation with the employer, the conditions on which leave will be granted by the employer.
The leave-salary in respect of leave granted by the employer will be paid by the employer and the
leave will not be debited against the Government servant's leave account.(b)In special
circumstances, the authority sanctioning a transfer to foreign service out of India may make an
arrangement with foreign employer under which leave may make an arrangement with the foreign
employer under which leave may be granted to the Government servant in accordance with the rules
applicable to him as a Government servant, if the foreign employer pays to the revenues of the State
leave contribution at the rates prescribed under F.R. 116.Note. For purpose of pension the period of
leave granted by foreign employers out of India to Government servants, lent to them under
Fundamental Rule 123 (a) should be treated as 'leave' and not as 'duty'. Any such leave, if taken on
full or half average pay or equivalent terms should, up to a limit of four months on nay one occasion,
be treated as privilege leave for the purposes of Art. 65 of the Assam Pension Manual, and all other
leave with leave allowance should be dealt with as in Art. 56 of the Assam Pension Manual.F.R.124.
A Government servant in foreign service if appointed to officiate in a post in Government service,
will draw pay calculated on the pay of the post in Government service on which he holds a lien or
would hold a lien had his lien not been suspended and that of the post in which he officiates. His pay
in foreign service will not be taken into account in fixing his pay.F.R.125. A Government servant
reverts from foreign service to Government Service on the date on which he takes charge his post in
Government service ; provided that, if he takes leave on the conclusion of his foreign service before
re-joining his post, his reversion shall take effect from such date as the State Government on whose
establishment he is borne may decide.F.R.126. When a Government servant reverts from foreign
service to Government service, his pay will cease to be paid by the foreign employer, and his
continuation will be discontinued with effect from the date of reversion.F.R.127. When an addition
is made to a regular establishment on the condition that its cost or a definite portion of its cost shall
be recovered from the persons for whose benefit the additional establishment is created, recoveries
shall be made under the following rules :(a)The amount to be recovered shall be the grossFundamental Rules and Subsidiary Rules

sanctioned cost of the service, or the portion of the service, as the case may be, and shall not vary
with the actual expenditure of any month ;(b)The cost of the service shall include contributions at
such rates as may be laid down under F.R. 116, and the contributions shall be calculated on the
sanctioned rates of pay of the members of the establishment.(c)A contribution for passages also
should be levied in respect of Government servants, entitled to passage concessions at the same
rates as are applicable to Government servants entitled to passage concessions who are transferred
to foreign service, viz., Rs. 50 per mensem in the case of superior officers and Rs. 60 per mensem in
the case of non-superior officers. The contributions should be levied the whole period of service in
the additional post except that it should not be charged during leave where-(i)the leave taken is
leave preparatory to retirement; or(ii)the Government concerned will, on return from leave, be
given different duties and return to the additional post; or(iii)the substitute in the additional post,
for the Government servant on leave, is entitled to passage concessions and contribution for
passages is recovered on his behalf.(d)The State Government may reduce the amount of recoveries
or may entirely forego them.Audit Instruction. - Principle for the calculation of contributions for
leave-salary and pension. - The words "its cots" in line 2 of F.R. 127 refer to an "addition" in the line
1 of the that rule. The underlying intention of the rule is to recover the cost of the additional
establishment sanctioned. Contributions for leave-salary and pension leviable under Cl. (b) of this
rule should, therefore, be based on the rates of pay, old and/or revised, as the case may be, on which
that establishment is actually sanctioned, irrespective of whether the person employed on the work
which it is sanctioned is an old or a new entrant.
Chapter XIII
Service Under Local Funds
F.R.128. Government servants paid from local funds which are administered by Government are
subject to the provisions of Chapter I to XI of these rules.Audit Instructions. - (1) Employers of local
funds administration by Government who are not Government servants are subject to the provisions
of Chapter I to XI of the Fundamental Rules.(2)The expression "local funds which are administered
by Government" means funds administered by bodies which by law or rule having the force of law
come under the control of Government in regard to proceedings generally and not merely in regard
to specific matters, such as the sanctioning of the budget or sanction to the creation or filling up of
particular posts or the enactment of leave, pension or similar rules ; in other words, it means funds
over whose expenditure Government retains complete and direct control.F.R.129. The transfer of
Government servants to service under local funds which are not administrative by Government will
be regulated by the rules in Chapter XII.F.R.130. Persons transferred by Government service from a
local fund which is not administered by Government will be treated as joining a first post under
Government and their previous service will not count as duty performed. The State Government
may, however, allow previous service in such cases to count as duty performed on such terms as it
thinks fit.The Schedule referred to Fundamental Rule 75-AProvisions for the determination of
domicileFundamental Rules and Subsidiary Rules

1. A person can only have one domicile.
2. The domicile of origin of every person of legitimate birth is in the country
in which at the time of his birth his father was domiciled, or, if he is a
posthumous child, in the country in which his father was domicile at the time
of the father's death.
3. The domicile of origin of an illegitimate child in the country in which at the
time of his birth his mother was domiciled.
4. The domicile of origin prevails until a new domicile has been acquired, and
a new domicile continuous until the former domicile has been resumed or
another has been acquired.
5.
(1)A person acquires a new domicile by taking up his fixed habitation in a country which is not that
of his domicile of origin.(2)Any person may, if the law of any country so provide and subject to any
such provisions, acquire a domicile in that country by making, in accordance, with the said
provisions, a declaration of his desire a acquire such domicile.Explanation 1. - A person is not to be
considered as having taken his fixed I habitation in a country merely by reason of his residing there
is His Majesty' civil or military service or in the exercise of any profession or calling.Explanation 2. -
A person does not acquire a new domicile in any country merely by reason of residing as part of the
family or as a servant country merely by reason of residing as part of the family or as a servant of
any ambassador, consul or other representative of the Government of another country.
6. The domicile of a minor follows the domicile of the parent from whom he
derives his domicile of origin :
Provided that the domicile of a minor does not change with that of his parent if the minor is married
or holds any office or employment in the service of His Majesty or has set up with the consent of the
parent in any distinct business.
7. After marriage a woman acquires the domicile of her husband if she had
not the same domicile before and her domicile during the marriage follows
the domicile of her husband :
Provided that if the husband and wife are separated by the order of a competent court or if the
husband is undergoing a sentence of transportation, the wife becomes capable of acquiring an
independent domicile.Fundamental Rules and Subsidiary Rules

8. Save as otherwise provided above a person cannot during minority
acquire a new domicile.
9. An insane person cannot acquire a new domicile in any other way then by
his domicile following the domicile of another person.
Section IIIFundamental Rules (Applicable to Services and Under the Rule-Making Control of the
Secretary of State)[Not Printed]Section IVTravelling Allowance Rules[Vide F.R.44]Division
IDefinitionsS.R.152. Unless there is something repugnant in the subject or context, the terms
defined in this division are used in the Travelling Allowance Rules in the sense here explained
:(1)"Actual travelling expenses" means the actual cost of transporting a Government servant with his
servants and personal luggage, including charges for ferry and other tolls and for carriage of camp
equipment, if necessary. It does not include charges for hotels, traveller's' bungalows or refreshment
or for the carriage of stores or conveyances or for presents to coachment and the like ; or any
allowance for such incidental losses or expenses as the breakage of crockery, wear and tear of
furniture and the employment of additional servants.(2)"Camp equipage" means the apparatus for
moving a camp.(3)"Camp equipment" means tents and the requisites for pitching and furnishing
them or, where tents are carried, such articles of camp furniture as it may be necessary, in the
interest of the public service, for a Government servant to take with him on tour.(4)"Day" means a
calendar day beginning and ending at midnight; but absence from headquarters which does not
exceed twenty-four hours shall be reckoned for the purpose of daily allowance as one day at
whatever hours the absence begins and ends.(5)"Family" means a Government servant's wife,
legitimate children and step children, residing and wholly dependent upon him. Except in S.R. 243
it includes in addition his parents (not adoptive or step-parents), sister and minor brothers if
residing with and wholly dependent upon him. Not more than one wife is included in a family for
the purpose of these rules. Travelling allowance may not be drawn on account of husband
dependent on a female Government servant without the orders of Government.Note. An adopted
child shall be considered to be a legitimate child, ii under the personal law of the Government
servant, adoption is legally recognised as conferring on it the status of a natural child.(6)"Hill
station" means any place which the State Government may declare to be a Hill station.(7)"Pay" for
the purpose of Travelling Allowance Rules means the monthly pay as defined in F.R. 9 (21) (a)
(i).(8)"Public conveyance" means a train, steamer of other conveyance which plies regularly for the
conveyance of passengers. It does not include a car.(9)"Transfer" means the movement of a
Government servant from one headquarters station in which he is employed to another such station
either (a) to take up duties of a new post, or (b) in consequence of a change of his headquarter.Note.
The definition of "family" as given in S.R. 152 (5) will apply mutatis mutandis to female Government
servants.Division IIGrades of Government servants/distribution of gradesS.R.153. (1) For the
purpose of calculating travelling allowance,. Government servants are divided into five grades as
shown in the Schedule below.(2)A Government servant officiating in, or appointed to perform all the
duties of, a post specified in a higher grade or to which a particular rate of daily allowance is
attached, draws the travelling allowance of that post. That does not cover the case of a Government
servant merely placed in charge of the office attached to another post in addition to his own
duties.(3)An Inspector of Police placed in charge of the office of a Superintendent, AssistantFundamental Rules and Subsidiary Rules

Superintendent or Deputy Superintendent of Police draws the travelling allowance of a Deputy
Superintendent of Police.
Schedule
 Grade of Officers Pay rangeRs. Revised ratesRs.
1.Senior Grade 1675 and above 45.00
2.First Grade 1250 and above but below 1675 38.00
3.Second Grade 750 and above but below 1250 30.00
4.Third Grade 490 and above but below 750 24.00
5.Fourth Grade Employees drawing pay below 490 15.00
Government employees belonging to all grades will be entitled to daily allowance outside the State
except Meghalaya, at double the above while travelling outside the State. In the case of travelling
Bangladesh on Government duly the rates of daily allowance will be double of the above rates.Note
1. All India Service Officers in the senior scale shall be treated as Senior Grade Officers irrespective
of their pay.Note 2. All India Service Officers or the Junior Officers of the Assam Civil Service Class I
in the junior scale and Assam Judicial Service Officers in Grade III viz, Judicial Magistrates,
Munsiffs and Sub-divisional Magistrates shall be treated as First Grade Officers irrespective of their
pay till they reach the senior grade pay range.Note 3. The existing rules and orders relating to
admissibility of daily allowance for different types of journey within and outside the State shall
continue until further orders.Note 4. Pending finalisation of pay in the revised scale, Government
servants now belonging to a particular grade will draw the corresponding enhanced rate of daily
allowance prescribed for that grade.S.R.154. The State Government may, for reasons which should
be recorded, order that any Government servant or class of Government servants shall be included
in a grade higher than that prescribed in Rule 153.S.R.155. A Government servant in transit from
one post to another rank in the grade to which the lower of the two posts would entitle him.S.R.156.
A Government servant whose whole time is not retained for the public service, or who is
remunerated wholly or partly by fees, ranks in such grade as a competent authority may
declare.Note 1. A Public prosecutor is not entitled to any halting allowance when away from his
headquarters, but is recognised as a Government servant of the 2nd grade for the purpose of
drawing travelling expenses only.Note 2. The Legal Remembrancer is authorised to grant travelling
expenses to legal practitioners (e.g., Pleaders and Mukhtars), who are engaged in the interest of
public service, to conduct cases, elsewhere than in their own station, provided such charges do not
exceed what would be admissible, under the parallel circumstances, to a Government servant of the
2nd grade referred to in S.R. 153. Subject to the same conditions the District Officers of the Hill
Districts (except the D.C. Mizo District) are authorised to grant such expenses to legal practitioners
engaged by them to defend persons accused of murder.Note 3. [Deleted]Division IIIDifferent Kinds
of Travelling AllowancesS.R.157. The following are the different kinds of travelling allowances which
may be drawn in different circumstances by Government servants :(a)Permanent travelling
allowance ;(b)Conveyance or Horse allowance ;(c)Mileage allowance;(d)Daily allowance ;(e)The
actual cost of travelling.The Rules In Division IV to VIII explain the nature of these allowances and
the method of calculating them. The circumstances in which they can be drawn for particular
journey are described in Division IX to XXIV.Division IVPermanent Travelling AllowanceS.R.158. AFundamental Rules and Subsidiary Rules

permanent monthly travelling allowance may be granted by a competent authority to any
Government servant whose duties require him to travel extensively. Such an allowance is granted in
lieu of all other forms of travelling allowance for journeys within the Government servant's sphere of
duty and is drawn all the year round whether the Government servant is absent from his
headquarters or not.State Government's decision. - (1) Government have after careful consideration
decided to increase further the rates of travelling allowance as detailed below in view of the present
abnormal conditions prevailing in the Province, viz.:All permanent travelling and conveyance
allowance up to Rs. 50 are increased by 40 per cent exclusive of cycle allowance which should
remain at Rs. 5 before.The orders take effect from the 1st December, 1942 and will remain in force
till conditions of touring justify reversion to the old rates.(2)The present position with regard to the
rates of monthly permanent travelling allowance and conveyance allowance admissible to the
Government servants has been reviewed and the Governor of Assam is pleased to decide that, as the
present condition of touring do not justify reversion to the old rates, the "ad hoc" increase of 40 per
cent may be merged with the rates of all permanent travelling allowance and conveyance allowance
up to Rs. 50 per month now admissible to certain Government servants vide Government's decision
(1) above.It is also further clarified that 40 per cent increase will not be admissible over the revised
rates of fixed travelling allowance as recommended by the Pay Committee for the following officers
with effect from the date these rates come into force, viz. -(1)Auditors, (2) Assistant Auditors, (3)
Sub-Inspectors of Schools and Assistant Sub-Inspectors of Schools, and (3) Gram Sevaks and
Sevakas.These orders will take immediate effect.S.R.159. A permanent travelling allowance cannot
be drawn during joining time or, unless in any case it be otherwise expressly provided in these rules,
during any period for which travelling allowance of any other kind is drawn. Its drawal during leave
is governed by S.R. 118.S.R.160. When a Government servant holds either substantively or an
officiating capacity, two or more posts to each of which a permanent travelling allowance is
attached, he may be granted such permanent travelling allowance not exceeding the total of all the
allowances, as the competent authority may consider to be necessary in order to cover the travelling
expenses which he has to incur.S.R.161. Permanent Travelling Allowance. - The rates of Permanent
Travelling Allowance will be as follows :
Sl. No.Designation of Officers with
DepartmentsRate of
Permanent
T.A.Remarks
1. 2. 3. 4.
Agriculture:
1. Agril. Demonstrators 25.00 P.M.The Agril. Demonstrators posted
in C.D.
2. Irrigation Demonstrators 25.00 P.M.Blocks to discharge the duties
like that of Gram Sevaks willget
fixed T.A. at the rate of Rs. 30
P.M.
Develop (P.
& C.D.) :
3. Gram Sevaks 30.00 P.M.  
4. Gram Sevakas 30.00 P.M.  Fundamental Rules and Subsidiary Rules

Education:
5. Sub-Inspector of Schools 125.00 P.M.  
6. Asstt. Sub-Inspector of Schools 75.00 P.M.  
Excise:
7. Prohibition Organisers 30.00 P.M.  
8. Prohibition Officers 20.00 P.M.  
Gen. Admin:
9. Inspectors (Gazetted) 100.00 P.M.  
10.Inspectors (non-gazetted) Office of
the T.A. & D.M.Calcutta100.00 P.M.  
11.Receptionist, Assam House, New
DelhiNazir-Cum-Receptionist,Assam
House, Calcutta100.00
P.M.150.00
P.M. 
Health:
12. Rural Health Inspectors 30.00 P.M.  
13. Health Assistants 25.00 P.M.  
14. Vaccinators of N.S.E.P. 25.00 P.M.  
15.Grade IV Employees attached to
mobile team of the N.S.E.P.team20.00 P.M.  
Local
Accounts:
16. Auditors 150.00 P.M.  
17. Asstt. Auditors 125.00 P.M.  
18. Peons attached to Auditors 75.00 P.M.  
Police
19.Hony. Adviser, V.D.O/State Home
Guard Organiser625.00 P.M.Subject to the conditions that at
least 30 days’ tour ina month are
performed and that all
expenditure on P.O.L. andminor
repairs of Government vehicles at
their disposal are borneby
themselves.
20.Dy. Hony. Adviser, V.D.O. in Mikir
and N.C. Hill200.00 P.M.
21. Circle Organiser, V.D.O. 20.00 P.M.
Sericulture
and
Weaving:
22. Organiser of Boakata Societies 50.00 P.M.  Fundamental Rules and Subsidiary Rules

23. Weaving Demonstrators 35.00 P.M.  
24. Sericulture Demonstrators 25.00 P.M.  
Veterinary:
25. Veterinary Field Assistants 25.00 P.M.  
Note. Unless otherwise stated in the remarks column, the minimum number of days to be spent on
tour per month by the categories of Government shall not be less than 15 days, or such higher
number of days as may be prescribed by their respective Appointing Authority in consideration of
the nature of duties to be performed.Division VConveyance and Horse AllowanceS.R.162. A
competent authority may grant on such conditions as it thinks tit to impose, a monthly conveyance
or horse allowance to any Government servant who is required to travel extensively at or within a
short distance from his headquarter under condition which do not render him eligible for daily
allowance.State Government's decision. - (1) 1. The present position with regard to the grant of
conveyance allowance and conditions for its drawal by Government servants has been reviewed in
the existing provisions under S.Rr. 162 and 163, and the Government of Assam is pleased to
prescribe the following conditions.These will apply to Government servants who are granted
conveyance allowance specifically for the up-keep of a motor-cycle/motor car, and also to
Government servants who are granted conveyance allowance for maintenance of other mods of
conveyance other than bicycle, under the above rules.
2. The conveyance allowance for maintenance of motor-car/motor- cycle, etc.
shall continue to be admissible at the existing rates to Government servants
concerned subject to the following conditions and till such times as and
when Government decide to revise the allowance in respect of such
Government servants in accordance with these orders.
3. (i) No conveyance allowance shall be admissible during-
(a)joining time, leave or any period of temporary transfer. The allowance shall also not be
admissible during holidays prefixed to leave, holidays suffixed to leave and joining time.(b)any
period more than 15 days at a time during which a Government servant does not maintain a
motor-car/cycle or the motor-car/motor-cycle maintained by him remains out of order and is not
used for official journeys for which the allowance is granted.(ii)The conveyance allowance shall
henceforth be granted under the above rules to cover all journey by road on official duty within the
local jurisdiction of Government servants for which no daily allowance/mileage allowance is
admissible, irrespective of whether the points of duty reached lie within or beyond a radius of 8
Kms. from his usual place of work ; provided that daily allowance/mileage allowance will be
admissible as under for journeys beyond and outside a radius of 8 Kms. from his usual place of
work-(a)if the journey is performed by rail or steamer or air the allowance may be drawn in addition
to the T.A., i.e., daily allowance/mileage allowance under the rules ;(b)if the journey is performed by
road, only the conveyance allowance would be admissible but if on any day a Government servant
travels beyond 16 Kms. from his usual place of work, he may at his option exchange his conveyance
allowance at the rate of 1/30th for any T.A., i.e., daily allowance and/or mileage allowance that mayFundamental Rules and Subsidiary Rules

be admissible to him under the rules ;(c)if the journey is performed partly by rail or steamer or air
and partly by road, conveyance allowance may be drawn in addition to the T.A. admissible for the
portion of the journey performed by rail or steamer or air and the officer may at his option exchange
his conveyance allowance at the rate of 1/30th for each day, for any T.A. that may be admissible for
the portion of the journey by road on any day on which the journey by road exceeds 16 Kms.
4. The grant of horse allowance and bicycle allowance will continue to be
granted by the present rules and orders.
These orders will have effect from 1st September, 1967.(2)With reference to para 3 (i) (b) of the
State Government's decision (1) above it is clarified that the conveyance allowance now admissible
to Government servants for the maintenance of motor-car/motor-cycle under the existing
provisions of S.Rr. 162 and 163 will not be admissible for any period of more than 15 days at a time
during which on account of their absence from headquarters on tour, or for any reason whatsoever,
the motor-car/motor-cycle maintained by them are not used for official journeys.These orders will
have effect from 1st January, 1968.S.R.163. Except as otherwise provided in these rules, and unless
the authority sanctioning it otherwise directs, a conveyance or horse allowance drawn all the year
round is not forfeited during absence from headquarters and may be drawn in addition to any other
travelling allowance admissible under these rules:Provided that the Government servant, who is in
receipt of a conveyance allowance specifically granted for the up-keep of a motor-car or motor-cycle,
shall not draw mileage or daily allowance for a journey by the sanctions the conveyance allowance
may prescribe.S.R.164. A conveyance or horse allowance may not be drawn during joining time. Its
drawal during leave is governed by S.R. 118.Subordinate Police Officers may, however, draw during
joining time the conveyance or horse allowance drawn by them while on duty, subject to the
condition that no extra cost is thereby caused to Government.S.R.165. Conveyance allowance. - (i)
The rates of conveyance allowance for certain categories of Government servants who are required
to perform journeys regularly in or near their headquarters for short distances which do not qualify
for travelling allowance will be as follows :
Sl. No. Designation of Officers  Rates of Conveyance
Allowance Remarks
(1) (2)  (3)  (4)
Gen. Admin.
1.Private Secretaries/
Personal Assistants
toMinisters/Ministers
of State/Deputy
Ministers 75.00 P.M.  Subject to the condition that a
serviceablemotor car/motor cycle
is maintained and as certified by
Hon'bleMinisters under whom
they work. The conditions
prescribed videthe State
Government's decisions (1) and
(2) below S.R. 162shall also be
applicable.
PoliceFundamental Rules and Subsidiary Rules

2.Sub-Inspectors of the
Armed Branch,
TownPolice, Reserve
Police Rider
Sub-Inspectors and the
CriminalInvestigation
Deptt Sub-Inspector
attached to Govt.
House. Bicycle allowance of
Rs. 7.00 p.m. If a serviceable bicycle is
maintained
3.Sub-Inspectors and
Asstt. Sub-Inspectors
ofPolice in the
Criminal Investigation
Department 7.00 P.M.  Subject to the conditions that a
serviceablebicycle is maintained
and the Deputy Inspector General
of Policecertifies that its
maintenance is necessary.
4.Police Constables
Unarmed Branch 7.00 P.M.  If a serviceable bicycle is
maintained.
5.Sub-Inspectors
attached to Police
Stationsexcept
Sub-Inspectors of the
Railway and River
Police Pony allowance of
Rs. 28.00 P.M. In case where the Supdt. of Police
certifiesthat a pony is necessary
Otherwise a bicycle allowance of
Rs.7.00 P.M. for maintenance of
the same. A Sub-Inspector of
Policeon temporary deputation to
the Finger Print Bureau for
trainingmay draw a horse
allowance on the sanctioned scale;
provided hemaintained a horse in
the District in which he was
stationedprior to his deputation
and continues to maintain a horse
duringthe period of training, a
certificate to that effect
beingfurnished monthly. The post
will not, however, be held to be
onein which the conveyance of a
horse if advantageous from
thepoint of view of the officer's
efficiency so as to entitle himto
draw transport charges under
Assam Subsidiary Rule 243-1(iv).
6.Sub-Inspectors of
Village Defence
Organisation Bicycle Allowance of
Rs. 7.00 P.M. If a serviceable bicycle is
maintained.
7.   Fundamental Rules and Subsidiary Rules

Sub-Inspectors
attached to Police
Stationsexcept Sub-
Inspectors of the
Railway and River
PoliceMotor cycle
allowance of Rs.
35.00 P.M.In case where the Supdt. of Police
certifiesthat a motor cycle is
necessary for efficient discharge
ofduties and a serviceable
motor-cycle is maintained.
Theconditions prescribedvidethe
State Govt.'s decisions (1) and(2)
below S.R.162. shall also be
applicable.
8.Assistant
Sub-Inspectors
in-charge of
PoliceStations of the
Orang Out-post in
Darrang Pony Allowance of
Rs. 28.00 P.M. In case where the Supdt. of Police
certifiesthat a pony is necessary.
Otherwise bicycle allowance of
Rs.7.00 P.M.
9.Assistant
Sub-Inspectors Rs.7.00
per mensem ofPolice of
the District Executive
Force and Head
Constables ofthe Town
Police (Executive
Force) Rs.7.00  Subject to the condition that a
serviceablebicycle is maintained.
Agriculture
10. Mycological Field-man  Rs.7.00  If a serviceable bicycle is
maintained.
11. Chemical Field-man  Rs.7.00  If a serviceable bicycle is
maintained.
12. Botanical Asstt.,Jorhat  Rs.7.00  If a serviceable bicycle is
maintained.
13. Scientific Asstt.  Rs.7.00  Subject to the condition that a
serviceablebicycle is maintained.
The Scientific Asstts. who are
providedwith quarter at the farm
will not draw the allowance.
Public Works
Department
14. Members of the Lower
Subordinate
Establishment Rs. 10.00 except in
the case of officers
whosejurisdiction is
confined to Urban
areas, i.e., district The Divisional Officer when so
authorised bythe Chief Engineer,
can sanction the allowance,
provided thesubordinate
maintains a means of conveyanceFundamental Rules and Subsidiary Rules

orsub-divisional
towns and a radius
of 8 Kms.
therefrom. In
thecase of the latter
the rate will be Rs.
7.00suited to his workand that he
draws no other travelling
allowance for journey ontour
except mileage under the special
orders of the DivisionalOfficers.
Note.A
certificate of
actualmaintenance
of suitable
means of
conveyance duly
signed by
theDivisional
Officer, should
be attached to
each bill in
which
theconveyance
allowance is
drawn.
15.Students who are
placed for practical
trainingin the Public
Works Department Rs. 10.00 except in
the case of students
whosejurisdiction is
confined to Urban
areas, i.e., district
orsub-divisional
towns and a radius
of 8 Kms.
therefrom. In
thecase of latter the
rate will be Rs. 7.00 The allowance may be granted by
the ChiefEngineer, Assam on a
certificate that a serviceable
conveyanceis maintained.
16. Member of the
Sub-Engineering
Service when notin
charge of sub-divisions
and temporary
subordinates
employedin regular
P.W.D. As district from
the Estt. under Civil
WorksDisbursers Rs. 10.00 a month
for maintenance of a
bicycleexcept in the
case of officers
whose jurisdiction is
confined toUrban
areas i.e. Distt. or
Sub-divisional
towns and a radius
of8 Kms. therefrom. Will also draw daily allowance of
Rs. 2.00 inaddition when on tour
beyond the radius of 8 Kms.
fromheadquarters. When
employed in Hill Districts the
D.A. will beraised to Rs. 2.50
Subordinates who have performed
railway andsteamer journeys with
the respective jurisdiction may be
allowedrailway and steamer fareFundamental Rules and Subsidiary Rules

In the case of the
latter the rate will
beRs.7.00 a monthto which they are entitled under
therules in lieu of this fixed
allowance for those days.
Note.- A
certificate of
actualmaintenance
of a suitable
conveyance duly
signed by
theExecutive
Engineer should
be attached to
each bill in
which C.A.is
drawn.
17.Overseers Grade III
(Temporary) employed
inregular Public Works
Department Rs. 10.00 a month
for the maintenance
of abicycle except in
the case of officers
whose jurisdiction
isconfined to urban
areas, i.e., Distt. or
Sub-divisional
townsand a radius
of 8 Kms.
therefrom. In the
case of the latter
ofthe rate will be Rs.
7.00 a month As above.Only one of the two
allowances specified in Co.3 shall
be drawn at a time.
18.Overseers Grade III
(Temporary) employed
inregular Public Works
Department Rs. 10.00 a month
for the maintenance
of abicycle except in
the case of officers
whose jurisdiction
isconfined to urban
areas i.e., District or
Sub-Divisional
townsand a radius
of 8 Kms.
therefrom. In the
case of the latter
therate will be Rs.
7.00 a month Will also draw D.A. at Rs. 2.00 in
additionwhen on tour beyond the
radius of 8 Kms. from head
quarters.When employed in Hills
Districts the D.A. will be raised to
Rs.2.50. Subordinates who have
to perform railway or
steamerjourneys within the
respective jurisdiction may be
allowedrailway and steamer fare
to which they are entitled under
therules in lieu of C.A. for those
days.Fundamental Rules and Subsidiary Rules

Note.A
certificate of
actualmaintenance
of a suitable
conveyance duly
signed by
theExecutive
Engineer should
be attached to
each bill in
which theC.A. is
drawn.
19.Overseers (including
temporary Overseers)
inthe Civil Works Estt. (I) Rs. 10.00 a
month for
maintenance
ofbicycle Will also draw D.A. at Rs. 2.50
when on tourbeyond a radius of 8
Kms. from headquarters.
 (II) Rs. 21.00 a month
for maintenance of
pony Only one of the two
allowances specified
inCol. 3 shall be
drawn a at a time.
Note.A
certificate of
actualmaintenance
of suitable
conveyance duly
signed by the
PublicWorks
Disbursers
should be
attached to each
bill in which
theC.A. is
drawn.
20.Overseers Grade III
(temporary in the
CivilWorks Estt. Rs. 10.00 a month
for maintenance of a
bicycle. Will also draw daily allowance at
Rs. 2.50 whenon tour beyond a
radius of 8 Kms. from
headquarters.
Note.A
certificate of
actualmaintenance
of a suitable
conveyance duly
signed by theFundamental Rules and Subsidiary Rules

PublicWorks
Disbursers
should be
attached to each
bill in which
theC.A is drawn.
21. Divisional Mechanics  Rs. 7.00 a month.  Subject to the condition that a
serviceablebicycle is maintained.
Power
(Electricity,
Mines &
Minerals)
22. Electric Testers  Rs. 7.00 a month.  If a serviceable bicycle is
maintained.
Taxation
23. Inspector of Taxes  Rs. 30.00 a month.   
(ii)The rates of monthly conveyance allowance admissible to certain other categories of Government
servants whose nature of duties requires to undertake frequent journeys within 8 Kms. from their
Headquarters for which no other T.A. is admissible and who are allotted Government vehicles for
such journeys with the obligation to bear the propulsion charges will be as follows :
Sl. No. Designation of OfficersRates of
Conveyance
Allowance
1. D.C./S.P. of all other districts except Kamrup Rs. 75.00
2. D.C./S.P. Kamrup Rs. 100.00
3.S.D.O./S.P.O./Addl. S.P., Civil Surgeon/ExecutiveEngineer/S.D.O.,
P.W.D. in charge of Government building inDistrict HeadquartersRs. 50.00
4. Estate Officer, P.W.D. Rs. 150.00
Division VIMileage Allowance(i)GeneralS.R.166. A mileage allowance is an allowance calculated on
the distance travelled which is given to meet the cost of a particular journey.S.R.167. (a) For the
purpose of calculating mileage allowance, a journey between two places is held to have been
performed by the shortest of two or more practicable routes, or by the cheapest of such routes as
may be equally short, provided that there are alternatively railway routes and difference between
them in point of time and cost is not great. Mileage allowance should be calculated on the route
actually used.(b)The shortest route is that by which traveller can most speedily reach his destination
by the ordinary modes of travelling. In case of doubt a competent authority may decide which shall
be regarded as the shortest of two or more routes.Note 1. [Deleted].Note 2. [Deleted].Note 3.
Tura-ManKachar-Kaunia route is the most practicable and shortest route for journey between Tura
and Golakganj during rainy season.Note 4. The route between Goalpara and Lakhimpur via Agia is
the proper route for the purpose of travelling allowance.Note 5. Tura-Mankachar Rowmari route is
the most practicable and the shortest route for journeys between Tura and Dhubri and vice versa,
but due to the irregularities of steamer service in the dry season officers are allowed to performFundamental Rules and Subsidiary Rules

journeys between Mankachar and Dhubri and vice versa, either by taking the steamer at Rowmari
for Dhubri or by travelling by road to Fakirganj and then by ferry to Dhubri and vice versa.Note 6.
An all India route (i.e., route which passes exclusively through the territories of the Indian Union) is
the shortest route for journeys between Assam and the rest of India and within Assam; provided (i)
the journey is actually performed by that route, and (ii) the route adopted is the shortest of the
available all India routes.(c)If a Government servant travels by a route which is the shortest but is
cheaper than the shortest, his mileage allowance should be calculated on the route actually
used.S.R.168. (a) A competent authority may permit mileage allowance to be calculated on a route
other than the shortest and the cheapest, when he is satisfied that the journey is performed by such
route in the interest of public service.(b)Controlling officers may allow journeys from Gauhati to
Pandu and vice versa to the performed either by road or rail and from Goalpara to Gauhati and vice
versa to be performed either by road or steamer/according to the convenience of officers.(c)The
absence in a train of class of accommodation to which a Government servant is entitled under S.R.
171, may be taken as a special reason for allowing mileage allowance by road, and consequently the
competent authority may on such occasions grant, to an officer travelling by road, road mileage
limited to the amount which would have been admissible had the journey been performed by train
by the class of accommodation to which he is ordinarily entitled. When the fare of the requisite class
for the journey in question is not specifically published, it should be calculated according to the
appropriate data in the Railway Time and Fare Tables.Note 1. The Political Officer and the Assistant
Political Officer, Balipara Frontier Tract, are permitted to perform journeys between Charduar and
Tezpur by road direct instead of by road and rail whenever it is found expedient.Note 2. The Civil
Surgeon, Darrang and Balipara Frontier Tract, is permitted to perform journeys between
Lokra-Charduar and Tezpur by road direct instead of by road and rail, whenever it is found
expedient.Note 3. The Civil Surgeon of Cachar is permitted to travel from Silchar to Hailakandi and
back by road instead of by rail on the occasion of his visits of inspection.S.R.169. The point in any
station at which a journey is held to commence or end is Chief Public Office, or such other point as
may be fixed for the purpose by a competent authority.S.R.170. Mileage allowance is differently
calculated as shown in the following rules, according as the journey is, or could be made by railway,
by sea or river steamer, or by road.(ii)Mileage Allowances for journeys by RailwaysS.R.171. For the
purposes of calculating mileage allowance, Government servants when travelling by railways are
considered to be entitled to class of accommodation according to the following scale :(a)A
Government servant of the Senior, and 1st Grade- Accommodation of the highest class, by whatever
name it may be called provided on, the railway by which he travels.(b)A Government servant of the
2nd Grade-Accommodation of the 1st class.(c)A Government servant of the 3rd
Grade-Accommodation of the 2nd class.(d)A Government servant of the 4th Grade-The lowest class
whether it be called lower, third or fourth.Note. All officers who were entitled to travel by 1st class in
Railways prior to 2nd July, 1964, will continue to enjoy the privilege.S.R.172. (a) A competent
authority may, for special reason which should be recorded, declare any particular Government
servant or class of Government servants to be entitled to accommodation of higher class than that
prescribed for his grade in Clause (b), (c) or (d) of S.R. 171.(b)All female officers of the 3rd grade in
receipt of pay of Rs. 50.00 and upward may travel in 2nd class by rail (or 1st class of the N.F.
Railway) and when they do so may draw a single Railway fair of that class pins an allowance for
incidental expenses at the rate prescribed under S.R.173 for their grade. This concession does not
apply to journeys by motor service.S.R.173. Except in the case of journey on transfer, the mileageFundamental Rules and Subsidiary Rules

allowance admissible to a Government servant of the Senior, 1st, 2nd, 3rd and 4th Grades is a single
fare of the class in which, he is entitled to accommodation, plus an allowance for incidental expenses
calculated as follows :
Grade of Government servantsRate of allowance of incidental
expenses
(1) (2)
Senior Grade 0.04 p. per k.m.
1st Grade 0.03 p. per k.m.
2nd Grade 0.025 p. per k.m.
3rd Grade 0.0125 p. per k.m.
4th Grade 0.006 p. per k.m.
Note 1. Mileage allowance for journey on the Gauhati-Shillong Road performed by service car shall
be calculated according to the following rates :For journeys from Gauhati to Shillong or vice versa-
Government servants of senior Grade 1 ½ fares of the 1st class.
Government servants 1st senior Grade -Do-
Government servants 2nd senior Grade 1 ½ fares of the 2nd class.
Government servants 3rd senior Grade1 ½ fares of the Upper
class.
Government servants 4th senior Grade1 ½ fares of the Lower
class.
State Government's decision. - (1) In view of the revised classification of passenger traffic on
Railways it is decided that, with effect from 1st April, 1955, Government servants, when travelling by
rail, will be entitled to accommodation and travelling allowance as follows :
1. (a) Government servants of the 1st and 2nd Grade...... New 1st Class
(b)Government servants of the 3rd Grade...... New 2nd Class(c)Government servants of the 4th
Grade...... Third Class.
2. The rate of mileage allowance on tour-
(a)a single fare of the class in which a Government servant is entitled to accommodation, plus,(b)an
allowance for incidental expenses calculated as follows at the existing rate.The existing rate-(i)For a
Government servant of the 1st Grade..... Half of old 1st class fare.(ii)For a Government servant of the
2nd Grade..... Half of old 2nd class fare.(iii)For a Government servant of the 3rd Grade....¾ of old
Inter class fare.(iv)For a Government servant of the 4th Grade....One daily allowance.
3. The rate of mileage allowance on transfer-a single fare of the class to
which a Government servant is now entitled plus 2 fares of old classification
including the allowances as prescribed under S.R. 243-1 of Fundamental
Rules and Assam Subsidiary Rules.Fundamental Rules and Subsidiary Rules

(2)It has been decided that the Secretaries to the Government and other officers of the 1st Grade
who are in receipt of a pay of 1,000 and above may travel by air conditioned accommodation, a
recovery of 1 paisa per K.M. will be made from them for such journeys.(3)A question has arisen
regarding the eligibility of Government servants to travel at the public expense in Deluxe trains in
which only two classes of accommodation namely, air-conditioned class and air-conditioned third
class are provided. It has been decided that in so far as travel in air-conditioned class of
accommodation of the Deluxe trains is concerned, the orders contained in Government's decision
(2) above will apply.Government servants who are otherwise entitled to travel in first or second class
in other trains may travel at the public expense in air-conditioned third class accommodation only.
The entitlement of travel in air-conditioned third class accommodation in the case of the latter
category of officers will extend to journeys on transfer also. Government servants are entitled to
travel in third class in other trains will not be eligible to travel in the third class air-conditioned
accommodation of the Deluxe train at the public expense. For each journey, they will be eligible to
claim only ordinary third class fare.(4)The facility of travel by air-conditioned accommodation on
recovery of 1 paisa, per Km. allowed to certain officers vide Government decision (2) above will be
restricted to journeys for which travelling allowance is admissible as for journey on tour.For
journeys on transfer, the entitlement of all officers regarding class of travel in cases where travelling
allowance is granted is to be determined according to the provision in paragraph 1 of the
Government's decision (1) above.(5)Consequent upon the decision of the Government of India to
abolish gradually second class accommodation from the Railways so as to provide eventually only
two classes of rail accommodation, the 1st class and the 3rd class, the Governor of Assam is pleased
to decide in modification of paragraph 1 (b) of item (1) of the Government's decision (1) that
Government servants of the 3rd grade, on railway lines on which 2nd class has been abolished be
entitled to travel on tour or transfer by the 3rd class. It has further been decided that the following
additional concessions shall be admissible to such Government servants :(i)charges for reservation
of seats and for reservation of sleeping berths in the 3rd class, where such facilities are available
shall be borne by the Government;(ii)the Government servants concerned shall be entitled to travel
by 3rd class in Deluxe air-conditioned trains, wherever such trains run. The surcharge levied for
travel by that class in such trains shall be met by the Government.The decision mentioned above
does not affect the incidental allowance admissible at present to Government servants of the 3rd
grade nor does it affect the entitlement of a 3rd grade Government servant to travel by the 2nd class
for so long as that class continues to exist on certain lines. The entitlement of a 3rd grade
Government servant to travel by the air-conditioned 3rd class in Deluxe trains on such lines will
continue to be granted according to the sub-paragraph of the Government's decision (3) above.(6)It
is decided that when a Government servant who is entitled to travel in a higher class by rail travels
in 3rd class and pays the extra charges for sleeping accommodation provided by the Railways for 3rd
class passengers during night journeys, the controlling officer may in such cases allow the fare of the
accommodation actually used inclusive of the charges for the sleeping accommodation ; provided it
does not exceed the fare of the class in which the Government servant is entitled to travel.The
concession will apply to journey on tour as well as transfer.(7)Since the railway authorities entertain
claims for refund of cancellation charges on unused railway tickets (including A.C.C. tickets) only
from the passengers concerned, the Governor of Assam has been pleased to decide that where the
rail journey is cancelled solely due to official reasons, the Government servant should prefer to the
appropriate railway authority, his claim for refund of cancellation charges (excluding reservationFundamental Rules and Subsidiary Rules

charges) on unused tickets) including A.C.C. tickets), duly supported by a certificate from his
controlling officer that the journey had to be cancelled for official reasons.The Government servant
who is his own controlling officer for travelling allowance purposes may furnish such a certificate in
his official capacity. The claim for the refund preferred on the railway should, however, be restricted
to what it would be, had the officer booked and cancelled the journey by the shortest route, save in
exceptional cases where the route actually by the Government servant is certified by the controlling
officer or by the Government servant himself, if he is his own controlling officer for travelling
allowance purposes to be in the interest of public service.The Governor of Assam is also pleased to
decide that the ordinary reservation fee in such cases may be reimbursed to the Government servant
without waiting for the acceptance of his claim for refund or cancellation charges by the railway
authorities. The amount of reservation fee reimbursed to a Government servant is debitable to the
same head to which his F.A. is charged.No refund of "Agency Charges" is, however, admissible as
Government servant who books his journey through a "Travel Agent" does so for his own
convenience.S.R.174. If a Government servant of 2nd or 3rd grade actually travels by a train which
does not provide the class of accommodation to which he is entitled under these rules, he may be
allowed to draw the mileage allowance of the next higher class ; provided that the controlling officer
attaches to his travelling allowance bill, a certificate that it was necessary in the public interest that
he should travel by that train. This concession does not apply to Government servant of the 3rd
grade whose pay is less than Rs. 50 and who travels on a line which provides intermediate class
accommodation on one or more of its trains but not on the particular train on which he travels, if
there be 3rd class accommodation on the train, such a Government servant is restricted to mileage
allowance calculated for intermediate class accommodation.S.R.175. When through booking
involves the payment for a part of journey of rates for accommodation of a class higher than that to
which Government servant concerned is entitled, the Government servant may draw mileage
allowance based on the higher rates for that part of the journey.(iii)Mileage allowance for journeys
by sea or by river steamerS.R.176. For the purpose of calculating mileage allowance, Government
servants are considered to be entitled to class of accommodation according to the following scale :
(a)A Government servant of
the Senior GradeHigher class
(b)A Government servant of
the 1st GradeDo
(c)A Government servant of
the 2nd Grade2nd or, if there be no 2nd class accommodation on any steamerby
which he travels, highest class.
(d)A Government servant of
the 3rd GradeIf there be two classes only on the steamer, the lower class ;if there
be three classes, middle or 2nd class, if there be fourclasses, third :
Provided that a competent authority may direct that any Government servant whose pay not exceed
Rs. 30 is entitled, for journeys generally or for particular journeys to accommodation in the lowest
class only.
(e)A Government servant of the 4th Grade Lower class
S.R.177. Except in the case of journeys on transfer the mileage allowance admissible to a
Government servant of Senior, 1st and 2nd grade is one and a half time of fare of the class in which
he is entitled to accommodation. The mileage allowance admissible to a 3rd grade GovernmentFundamental Rules and Subsidiary Rules

servant is one and three quarters of the fare of the class in which he is entitled to accommodation.
The mileage allowance admissible to a 4th grade Government servant is the fare of the lowest class,
and in addition the allowance admissible under S.R. 196.Note. [Deleted].S.R.178. In cases of doubt
or in which owing to the arrangement of class on a steamer, the provisions of S.R. 176,if strictly
construed, involve hardship, a competent authority may decide, for journey generally or for
particular journeys, to what class of accommodation a Government servant is entitled, and whether,
if a concession is sanctioned, he would be granted the full allowance admissible for the higher class
in which he is permitted to travel.Note. The Assistant Inspectors of Schools may travel as a 1st grade
Government servant by steamer.S.R.179. If suitable accommodation on a Government vessel is
offered to a Government servant, he is entitled to T.A. under S.R. 302 and not to mileage allowance.
It is not open to him to refuse to accept such accommodation and to draw mileage
allowance.S.R.180. The rules in this sub-division apply to Government servants who cross a river by
a steamer in the course of journey, unless such crossing occurs during a railway journey and the fare
for it is included in the railway fare. In the latter case, the crossing is treated as part of the railway
journey.(iv)Mileage allowance for journeys by roadS.R.181. For the purpose of these rules, travelling
by road includes travelling by sea or river in a steam launch, or in any vessel other than a steamer,
and travelling by canal.S.R.182. For journeys by road within the State, mileage allowance for
different kinds of journeys is calculated at the following rates of each k.m. travelled in respect of
journeys other than State Transport.(v)Mileage allowance admissible to Government servants for
journeys by own car and scooter/motor cycle, private transport, public vehicles and State Transport
Grades of
Government
servantsJourney
by own
car
(petrol)
driven)Journey by
scooter/motor
cycle (petrol
driven)Mileage for
journey by
private
transportMileage for
journey by
public
transport
includingState
Transport
Maruti CarsMaruti
VanFiat, Standard
and Maruti
GipsyOther
vehicles
1 2 3 4 5 6 7 8
Senior Grade 0.90 1.10 1.42 1.6448
PaiseSame rates as
prescribed in the
case of
allottedGovt,
vehicle of the
corresponding
categoriesActual
rate
1st Grade do do do do do do do
2nd Grade do do do do do do do
3rd Grade do do do do do do do
4th Grade do do do do do do doFundamental Rules and Subsidiary Rules

2. Petrol driven/Allotted vehicle.
 In
Plains
DistrictIn Hills
District
Maruti
carMaruti
vanFiat and
Standard
cars
including
wagon
built
onFiat
chassis
and
Maruti
GipsyAmbassador
cars
including
wagon built
onAmbassador
chassisAll other
vehicles
viz. Jeep,
station
wagons
andother
big
vehicles
like
Plymouth
and
Desota,
etc.Maruti
carMaruti
vanFiat and
Standard
cars
including
wagons
built
onFiat
Chassis
and
Maruti
GipsyAmbassador
car
including
wagon built
onAmbassador
chassisAll other
vehicles
viz. Jeep,
Station
Wagons,
andother
big
vehicles
like
Plymouth
and
Desota,
etc.
1 2 3 4 5 6 7 8 9 10 11
1. For the
first two
years
after
purchase
of
thevehicles
(new)0.60
per km.0.73 per
km.0.94 per
km.1.20 per
km.1.55
per
km.0.65
per
km.0.79 per
km.1.02 per km.1.33 per
km.1.87
per
km.
2. For the
next two
years0.65
per km.0.79 per
km.1.02 per km.1.26 per
km.1.64
per
km.0.67
per
km.0.82 per
km.1.06 per
km.1.38 per
km.1.93
per
km.
3. After
four
years0.66
per km.0.80 per
km.1.03 per km.1.30 per
km.1.69
per
km.0.71
per
km.0.86 per
km.1.11 per km.1.42 per
km.2.00
per
km.
The Officers concerned shall be responsible for bearing the cost of petrol only. The cost of oil and
lubricants will, as usual, be borne by Government.
3. Diesel driven allotted vehicles
Jeep includingvan, etc.Standard 20, van,
Mini Bus, MatadorJeep including
van, etc.Standard 20, van, Mini
Bus, Matador, etc
In Plains District In Hills District
0.38 per km. 0.39 per km. 0.48 per km. 0.51 per km.
The Officers concerned shall be responsible for the cost of diesel only. The cost of oil and lubricants,
will, as usual, be borne by Government.Fundamental Rules and Subsidiary Rules

4. The Government servants who are entitled to travel by allotted vehicle will
be eligible to the drawal of empty haulage charges at the same rates of
mileage prescribed for allotted vehicles for the returns journey from Airport
or outward journey to the Airport, when the vehicles have to propelled to
drop or to receive the Government servant concerned.
5. Mileage allowance will be allowed to the officers residing in Guwahati for
coming to attend official duties at Dispur with a call from their respective
Ministers or other Ministers or a Superior Officer on Sunday/holidays and
also at off-office hours. The rate of mileage for this purpose will be at the
same rates as admissible for travels between Guwahati and Dispur as
embodied in O.M. No. FM 46/74/56, dated 22-3-1980. No mileage allowance,
however, will be admissible for attending office in the normal course.
6. The above revised rates of mileage allowance will come into force from
9-1-1988. [FM 9/88/4, dated 23-2-1988]. The cases already settled prior to
issue of this O.M. will not be opened.
State Government's decision. - The road mileage will be admissible on normal road journeys
whether on foot or by any other kind of transport, subject to Note 1 under S.R. 182, as below :
Senior Grade Government servants   
First Grade Government servants }48 (forty-eight) paise per K.m.
Second Grade Government servants
Third Grade Government servants }35 (thirty five) paise per K.m.
Fourth Grade Government servants
Note 1. For allotted vehicles the officers concerned shall be responsible for bearing the cost of petrol
only with effect for 1st December, 1973. The cost of oil and lubricants will be borne by
Government.Note 2. In the case of road journeys without involving night halt away from
headquarters, one daily allowance will be admissible where the total journey performed by road is
not less than 80 Km. and half daily allowance will be admissible where the total journey performed
by road is not less than 40 Km. and the absence from headquarters is not less than six hours.Note 3.
In case of road journeys performed by public transport including State Transport involving night
halt away from headquarters, the Government servant will be entitled to incidentals at half the daily
allowance where the distance travelled is not less than 40 Km. and one daily allowance where the
distance travelled is not less than 80 Km. and shall in addition be entitled to half the daily allowance
for night halt away from headquarters at the end of the journey. In the case of road journeys by own
car, allotted vehicles, private transport and scooter/motor cycle only one daily allowance will be
admissible for the night halt away from headquarters at the end of the journey and there will be no
incidental.For journey on transfer by roads. - For journey on transfer by road except betweenFundamental Rules and Subsidiary Rules

Gauhati and Shillong a Government servant shall be entitled to 4 times fare of the class of
accommodation to which he is entitled and one single fare for each adult member and half single
fare for each minor member of his family of the same class of accommodation by public transport
including State Transport.For journey on transfer by road between Gauhati and Shillong 3 times
fare of the class of accommodation to which he is entitled and one single fare for each adult member
and half the single fare for each minor member of his family of the same class of accommodation
will be allowed.As regards transportation of the private motor car and motor cycle by road and also
travel by such transport on transfer the exiting provisions laid down under Notes 5 and 6 below S.R.
243 (i) (iv) may continue. The limits for transportation of personal effect on transfer as laid down
under S.R. 243 for different grades of Government servants and the existing provisions for
transportation will continue.S.R.183. When a Government servant travels within the territories
administered by another Government which has fixed special rates for Government servants under
its administrative control, he must draw the mileage allowance at the rates so fixed for his
grade.Note. When travelling in Delhi a Government servant may draw mileage allowance in
accordance with the Government of India Supplementary Rules.S.R.184. (a) A competent authority
may, for special reasons to be recorded, allow to a particular Government servant or class of
Government servants mileage allowance at a higher rate than is prescribed in R. 182 or
183.(b)[Deleted],S.R.185. In calculating mileage allowance for journeys by road, fraction of a
Kilometer should be omitted from the total of a bill for any one journey but not from the various
items which make up the bills.Mileage Allowance for Travel by AirS.R.185A. Travel by air is
permissible on tour-(i)in the case of the Parliamentary Secretaries to Minister's Secretaries to
Government, all A.I.S. Officers in the senior scale, and officers in receipt of the basic pay of Rs.
1,000 or above per mensem, and(ii)in the case of an officer to whom sub- Clause (i) does not apply,
whenever Secretaries to Government, with the approval of the Hon'ble Ministers under whom they
are working, certify that air travel is urgent and necessary in the public interest:Provided that the
State Government may grant general permission to any Government servant or class of Government
servants to travel by air as a matter of routine in connection with a special journey or
journeys.S.R.185B. A Government servant of the senior grade authorised to travel by air on tour is
entitled to mileage allowance equal to one-standard air fare for the journey plus an allowance for
incidental expenses at one-fifth of the standard air fare limited to a maximum of Rs. 20 for each
journey.A Government servant of grade lower than the senior authorised to travel by air on tour is
entitled to one standard air fare for the journey, plus the allowance for incidental expenses in
respect of a journey by rail, or by sea, as the case may be, and half the mileage by road in the case of
a journey between stations concerned by road, to which he would have been entitled had he
travelled by the surface route or one-fifth of the standard air fare limited a maximum of Rs. 20 for
each journey, whichever is less.S.R.185C. A Government servant who is not authorised to travel by
air but who performs a journey by air on tour can draw only the travelling allowance to which he
would have been entitled if he had travelled by rail, road or steamer.S.R.185D. If available, return
tickets at reduced rates should always be purchased when an officer expects to perform the journey
by air within the period during which a return ticket is available. The mileage allowance for the
forward and return journey when such return tickets are available, will, however, be the actual cost
of the return ticket plus an allowance for incidental expenses calculated under S.R. 185-B as for a
single journey each way.State Government's decision. - (1) The Governor of Assam has been pleased
to decide that the refund of cancellation charges on unused air tickets may be allowed, if theFundamental Rules and Subsidiary Rules

cancellation of such air tickets purchased by Government servants for journeys by air on tour is due
to circumstances which are unavoidable and beyond the control of Government servants. This
re-imbursement may, however, be limited to such officers as are eligible for journeys by air and as
have been authorised by competent authority to travel by air, but the amount may be limited to the
net deduction made by the air transport company concerned. No refund of the "Agency Service"
should be made as a Government servant who books his journey through a "Travel Agent" does so
for his own convenience.The Governor of Assam has been further pleased to decide that the
Secretary or an officer not below the rank of Deputy Secretary of the Department concerned may
exercise the power of sanction of such claims after due scrutiny. In respect of any claim made by
Secretary/Additional Secretary, he will record a certificate to the effect that the cancellation of the
official journey was due to unavoidable circumstances. The claim of a Deputy Secretary himself may
be scrutinised by a joint Secretary in the Department.Heads of Departments may exercise a similar
power in respect of officers and staff under their administrative control ; provided that the amount
of cancellation charges does not exceed Rs. 10. In respect of their own claim, not exceeding Rs. 10,
Heads of Departments will record a certificate to the effect that the cancellation of the official
journey was due to unavoidable circumstances. Administrative Department may obtain from "Heads
of Departments" under them quarterly statements of re-imbursement allowed by them. These
returns may be substituted to the Secretary of the Department for his review.(2)The Governor of
Assam is pleased to decide that for the purpose of air travel ex-India State Governments servants
drawing a basic pay of Rs. 1,800 p.m. and above, may be allowed to travel by the standard (first)
class and others by Tourist class.For the purpose of travelling allowance for such journey on tour,
only actual fare of the class to which the officer is entitled to travel may be allowed. No incidentals
will, however, be admissible.(3)A question has been raised that, in journeys by 1st grade officers of
the State between Gauhati and Calcutta, travel by air is cheaper in both money and
time.Government after due consideration have therefore decided that as travelling allowance by air
less than rail 1st grade officers may be allowed to perform the journeys between Gauhati and
Calcutta by air pending revising of the rates of incidentals for train journeys. This applies to
journeys on tour only.(4)It has been clarified following the Government of India, that the ceiling of
Rs. 20 prescribed in S.R. 185-B shall be admissible to the total air journey between the starting
station and the destination required to be, even if the journey by air between these stations is
performed by more than one service. However, if any official duty is performed by the touring officer
at the place of termination of the one service before the avails himself of another service, each of the
journeys from the starting station to the intermediate station and from the latter to the destination
station should be treated as a separate journey for the purpose of the aforesaid limit of Rs. 20,
provided such official duty at the intermediate station involves night and that both services are not
on the same day.(5)The Indian Air Lines Corporation have introduced a new air service by Boeing
between Bombay and Delhi with effect from 1st October, 1962 which provides two classes of travel
viz, 1st class and tourist (economy) class. A question has been raised as to which grade of officers
will be eligible to travel by 1st class by this service.The Governor of Assam is pleased to decide that
Ministers, Ministers of State, Deputy Ministers and Officers drawing a pay of Rs. 2, 250 p.m. and
above will be entitled to travel by 1st class between Delhi and Bombay by the above service when
travelling on tour.S.R.185E. A Government servant is entitled to the daily allowance ordinarily
admissible under S.R. 188.Where, however, on the same day the air journey is preceded or followed
by-(1) a journey by rail on public steamer, or (2) a journey by road, the amount admissible will be asFundamental Rules and Subsidiary Rules

follows :In the case of (1) the daily allowance under S.R. 188 plus the Railway or steamer fare
admissible under S.Rr. 171-179.In the case of (2) the daily allowance admissible under S.R. 188,
unless the journey by road exceeds 32 Kms., if the journey by road exceeds 32 Kms. mileage
allowance under S.R. 182 in addition to daily allowance.In neither of the cases under (1) and (2)
above will, any extra daily allowance, be admissible for the journey by air.S.R.185F. A Government
servant, when making a journey by air in a Government machine or in a machine chartered by
Government for the purpose, shall pay a first class full or half Railway fare, as the case may be, to
Government on behalf of each person not entitled to travel in that machine who may accompany
him.Note. If a Government servant wishes to take with him any "non-entitled person" in a
Government machine or in a machine chartered by Government, he should obtain the sanction of
the Head of the Department or if he himself is the Head of the Department, of the Government
administratively concerned ; provided first class full fare for each of such person is paid to
Government. The sanctioning authority in giving such sanction should satisfy itself that no extra
expenditure is used to Government thereby.Note. (1) Government servants other than those serving
under the Government of Assam shall have to pay the actual fare prescribed by the Transport
Department in consultation with Finance Department if and when they travel in Government
machine or in a machine chartered by the Government.Note. (2) The above rules will govern the
grant of travelling allowance to Parliamentary Secretaries to Hon'ble Ministers except that the rates
of daily allowance will be as admissible to Hon'ble Ministers.Division VIIDaily AllowanceS.R.186. A
daily allowance is a uniform allowance for each day of absence from headquarters, which is intended
to cover the ordinary daily charges incurred by a Government servant in consequence of such
absence.S.R.187. Unless in any case it be otherwise expressly provided in these rules, a daily
allowance may be drawn while on tour by every' Government servant whose duties require that the
should travel, and may not be drawn except while on tour :Provided that a Government servant, who
while on tour, inside or outside the State of Assam, is allowed free board and lodging at the expense
of the Central Government or a State Government or an autonomous industrial or commercial
undertaking or corporation, or a statutory body or a local authority, in which Government funds
have been invested or in which Government have any other interest, may draw only one-fourth of
the daily allowance admissible to him at the station concerned ; if either board or lodging is allowed
free to such a Government servant he may draw daily allowance at one-half of the admissible
rate.This includes also cases of deputation abroad where a Government servant is provided with free
board and/or lodging.Note. Government servant who stays during tours in Circuit
House/Inspection Bungalows/Rest Houses, etc., without having to pay any charges for
accommodation may also draw daily allowance at one-half of the approximate rate. Where, however,
a Government servant is required to pay any charges on account of his stay at such places, even
though it may not cover the entire cost of facilities, provided no reduction in his daily allowance may
be made.State Government's decision. - The Governor of Assam is pleased to decide that in cases of
forced halts occurring enroute on tour journeys necessitated by breakdown of communication due to
blockade of roads on account of flood, rains, heavy snow fall, land slide, etc., or delayed sailings of
ships the Administrative Departments of Government may, in respect of Government servants
under them, treat the period such halts as on duty. They may grant to Government servant
concerned daily allowance at three-fourth of rate applicable to him at the station in which the forced
halt takes place, for the period of forced halt after excluding the first day of such halt for which no
daily allowance should be allowed.S.R.188. (a) Daily allowance for journey in Assam are drawn byFundamental Rules and Subsidiary Rules

Government servants of all grades at the rates specified for the service or the officer in the Schedule
under S.R.153.(b)The rate of daily allowance for all grades of Government servants for halts at
places outside the State will be double over the rates admissible to them for halts within the
State.Note. This will not be admissible for halts in Manipur and Tripura.(c)[Deleted].State
Government's decision. - Under the Note below S.R.188 of Fundamental Rules and Subsidiary Rules
as inserted by C.S. No. 460, daily allowance at double the rate is not admissible to officers for halts
in Manipur and Tripura, although these places are outside Assam.As Naga Hills Tuensang Area is
not geographically outside Assam, it has since been decided that daily allowance at double the rate
should not also be allowed to officers for halts in that area while on tour, etc.S.R.189. The State
Government may, for reasons which would be recorded and on such conditions as it may think fit to
impose, sanction for any Government servant or class of Government servants a daily allowance
higher or lower than that prescribed in Rule 188.Note. For special rale of daily allowance admissible
in certain localities see Appendix 22.Division VIIIActual expensesS.R.190. Unless in any case it be
otherwise expressly provided in these rules, no Government servant is entitled to be provided with
means of conveyance by or at the expenses of Government, or to draw as travelling allowance the
actual cost of or part of actual cost of travelling.State Government's decision. - (1) It has been
decided, with the concurrence of Finance Department, that the State Government officers touring in
the districts of Mizo Hills and Naga Hills will henceforth draw travelling allowances admissible to
them and use Government porters free of charge as below ; but should a long tour necessitate
employment of porters exceeding the scale sanctioned herein, Deputy Commissioner may authorise
the engagement of minimum extra number of Government porters free of charge after recording the
reasons in writing :
1st Grade Officers 6 (six) porters.
2nd Grade Officers 3 (three) porters.
3rd Grade Officers 2 (two) porters.
Government also further observe in this connection that the Inspection/Dak Bungalows situated in
the interior should gradually be furnished and equipped better so that officers need not carry a lot of
stuff with them unless when they are camping in tents or temporary bashas.(2)It has been decided
with the concurrence of Finance Department, that with immediate effect the State Government
officers touring in the Districts of Mizo Hills, United Khasi and Jaintia Hills, Garo Hills and United
Mikir and North Cachar Hills who do not have the facility of using Government porters in
accordance with the scales sanctioned for officers touring in Mizo Hills vide Government decision (i)
above, but are required to use carriers in the course of their tours in these districts, shall draw extra
travelling allowance, in addition to usual daily allowance, up to the extent of actual expenses
incurred for hiring porters, but subject to the maximum of Rs. 9 in the case of 1st Grade
Government servants; Rs. 4.50 in the case of the 2nd Grade Government servants; and Rs. 3.20 in
the case of 3rd Grade Government servants, per diem.S.R.191.(a) [Deleted].(b)[Deleted].Division
IXTravelling allowance admissible for different classes of journeysS.R.192. A Government servant
appointed as Director or Member of the Board of Management or in any similar capacity in any
Corporation or statutory Body shall draw Travelling Allowance as well as sitting fees or other
remuneration of a like nature from such Corporation or Statutory Body at such rates as may be
applicable to the other Directors or Members of that Board ; provided that where there are no
non-official Directors or Members, the Government servant shall draw only Travelling Allowance at
the rate applicable to him while on tour.S.R.193. Unless in any case it be otherwise expresslyFundamental Rules and Subsidiary Rules

provided in these rules a Government servant making a journey for any purpose is not entitled to
recover from Government the cost of transporting his family or his personal luggage, conveyances,
camp equipage or equipment.S.R.194. The State Government may, by general or special order,
direct that the ordinary rates of daily allowance or mileage allowance or both shall be increased,
either in definite ratio or in any other suitable manner, for any or all Government servants travelling
in any specified locality in which travelling is unusually expensive. A list of special rates of travelling
allowance sanctioned for special localities is given in Appendix 23.S.R.195. When a Government
servant of a grade lower than the 1st grade is required by the order of the superior authority to travel
by special means of conveyance, the cost of which exceeds the amount of the daily allowance or
mileage allowance admissible to him under the ordinary rules he may draw the actual cost of
travelling in lieu of such daily or mileage allowance. The bill for the actual cost must be supported by
a certificate signed by the superior authority and countersigned by the controlling officer, that the
use of special means of conveyance was desirable in the public interest and specifying the
circumstances which rendered it desirable.Note. (i) The term "special means of conveyance" does
not include boats (except between the stations of Silchar and Changsil and between Silchar and
Sairang) or bullock carts which are ordinary means of conveyance but it includes accelerated carts
where there is an accelerated service.(ii)The term "actual cost of travelling" incudes the cost of
moving baggage which an officer cannot take with him when travelling by a pony and for which he is
compelled to hire a coolie.(iii)Boat shall be regarded as a special means of conveyance in the case of
all subordinate officers of the Forest Department, and in the case of all third and fourth grade
officers serving in Sadiya Frontier Tract.S.R.196. A Government servant of the 4th grade, when
travelling by rail, may draw mileage allowance under S.R. 173 and when travelling by sea or river
steamer addition to mileage allowance, daily allowance at double the rate ordinarily admissible to
him ; provided that whatever be the nature of other journey which may be combined with the
steamer journeys, no further allowance may be drawn for any day for which his double allowance is
drawn.Division XJourney on tour(i)General rulesS.R.197. The State Government may define the
limits of the sphere of duty of any Government servant.(1)The jurisdiction of Deputy Rangers and
Forester not in charge of Rangers and Forest guards is the Range to which they are attached.(2)The
ordinary jurisdiction of a Circle Inspector of Police (except Reserve or Court Inspector) is the Circle
in which he is employed. The jurisdiction of Reserve and Court Inspectors and Court
Sub-Inspectors, Court Assistant Sub-Inspectors and Constables is their headquarters station. The
jurisdiction of Reserve Head Constables and Constables and also of Inspectors, Sub-Inspectors and
Havildars of the Armed Branch is their headquarters station. The jurisdiction of Sub-Inspectors,
Assistant Sub-Inspectors, Head Constables and the Constables of the Unarmed Branch is the Police
Station to which they are attached. The jurisdiction of the Sub-Inspectors, Assistant Sub-Inspectors
and Constables and of the Circle Inspector's headquarters staff is their headquarters Police Station.
The jurisdiction of the Sub-Inspectors, Head Constable and Constables of Town Police is the
municipal limit of the town to which they are posted.(3)The sphere of duly of all records during
re-settlement operations is the circle in which they work and then travelling allowance will be
governed by S.R. 202.(4)The sphere of duty of all personnel of the Government Railway Police is the
whole of Government Railway Police District.S.R.198. A Government servant is on tour when absent
on duty from his headquarters either within or with proper sanction, beyond his sphere of duty.Note
1. Government servants attending meeting of the Court of Executive Council of the Gauhati
University and those, who, though not members of the Board of Agriculture, attend the meetings atFundamental Rules and Subsidiary Rules

Pusa as visitors, are on duty and will draw travelling allowance accordingly.Note 2. The Principal of
a Government College or a professor authorised by him in that behalf who attends the annual
convocation of the Gauhati University in order to identify the graduates from his college is on duty
and will draw travelling allowance accordingly.Note 3. Civil Surgeons appointed to conduct the
examination held by the Assam Medical Examination Board are on duty and will draw travelling
allowance accordingly.Note 4. Officers of the Assam Educational Service appointed as outside
Examiner in connection with examinations held by the Assam Medical Examination Board at
Dibrugarh are on duty and will draw travelling allowance accordingly.Note 5. Educational Officers
who are required to perform journeys on scouting work are on duty and will be allowed by
competent authority to draw travelling allowance accordingly.S.R.199. In case of doubt a competent
authority may decide whether a particular absence is absence on duty for the purpose of S.R. 198
subject to the following restrictions :(a)A Government servant summoned to answer a civil or
criminal case in respect of his official act, should not without the orders of Government be treated as
on duty under this rule unless Government have undertaken his defence at the public
cost.(b)Government servants summoned for inspection before selection as candidates for a post may
be treated as on duty and draw travelling allowance under the ordinary rules ; provided the Head of
the Department certifies that the journey was in the interest of the public service. Expenses of
private individuals are contingent charge, and can only be paid with the sanction of Government,
which will be very sparingly granted.S.R.200. A competent authority may impose such restrictions
as it may think fit upon the frequency and duration of journeys to be made on tour by any
Government servant or class of Government servants.S.R.201. If a competent authority declares that
the pay of a particular Government servant or class of Government servants has been so fixed as to
compensate for the cost of all journeys other than journeys by rail or steamer, within the
Government servant's sphere of duty, such a Government servant may draw no travelling allowance
for such journeys though he may draw mileage allowance or, if he be in inferior service, travelling
allowance under S.R. 218 for journeys by rail or steamer. When travelling on duty, with proper
sanction, beyond his sphere of duty, he may draw travelling allowance calculated under the ordinary
rules for the entire journey, including such part of it as is within his sphere of duty.Note 1. Ferry and
other tolls may be recovered unless the Government servant is exempt from these.Note 2. In the
case of police furnished under Ss. 13,14 and 15 of the Police Act 5 of 1861 , daily allowance up to 30
days will be allowed for halts performed during such duty both within and without their
jurisdiction.S.R.202. The following is the list of officers not entitled to travelling allowance for
journeys on tour :
1. Serial No.
2. Designation of Officers
3. Limitations and exceptions
Land Revenue
1.Clerks to S.D. C's. in the
Assam Valley Division Entitled to travelling allowance when theytravel
on duty with the sanction of the D.C.Fundamental Rules and Subsidiary Rules

2.Menials attached to survey
parties in the field When travelling on duty in connection with
fieldwork, they may be provided with hired
conveyance at the expenseof Government when
considered necessary by the Director ofSurveys,
and the expenditure met from contingency.
3. Supervisor Kanungos  (a) For journeys in a boat, or by road, orpartly by
boat and partly by road, they are entitled
totravelling allowance under the ordinary rules
except for the roadjourney up to 16 Kms. from the
starting point in a day. For haltsmade in the
course of a journey by boat, they are entitled
tohalting allowance on production of a certificate
from thecontrolling officer that the hire of the boat
had to be paid forthe period of halt. For journeys
in a public conveyance, or forjourneys performed
partly in a public conveyance and partly byroad or
boat, they may draw mileage for the whole
distance exceptfor the road journey up to 16 Kms.
from the starting point. Inother words, they are
entitled to travelling allowance under theordinary
rules from the starting point of the journey if
itexceeds 16 Kms. but no travelling allowance if
the journey islimited to 16 Kms. Whenever any
journey is made in a publicconveyance or for more
than 16 Kms. in a day, travellingallowance can
only be drawn on a certificate from the
controllingofficer that it was necessary to travel by
such means ofconveyance or at so paid a rate, as
the case may be.
   (b) [Deleted.]
   (c) Supervisor Kanungos on the staff of
theColonisation Officer at Rarpeta, Nowgong and
Mangaldai areallowed to draw travelling
allowance under the ordinary rules.
   (d) The temporary Supervisor Kanungos in
theBalipara Frontier Tract is entitled to draw
travelling allowanceadmissible to 3rd Grade
Government Officers while visiting thethree
villages of Karibil, Dhansiri and Newly on duty.
4.Khanapuri Kanungos
temporarily appointed
forsettlement duty Entitled to no travelling allowance exceptactual
railway fare of their class when travelling on duty
byrail.
5. Recorders  Fundamental Rules and Subsidiary Rules

(1) Entitled to travelling allowance at therates
admissible to their grades as per Schedule below
S.R. 153and single fare of the entitled class for
their railway andsteamer journeys on duty. The
rates of halting allowances for aperiod of eight
weeks in the year for recess at circleheadquarters
shall be 50 paise per Km. a day when there are
nobarracks and 25 paise per Km. a day when there
are barracks.Halting allowance at the usual rate
for the period of halt inexcess of eight weeks for
recess work at circle headquarters isadmissible in
individual cases where the halt or detention was
inpublic interest and was necessitated by causes
beyond theRecorder's control and is certified as
such by the Sub-DeputyCollector, in-charge.
Recorders living within 3 Kms. of
recessheadquarters are not entitled to halting
allowance. The 3rd classrate of mileage and
halting allowance (other than for recess)referred
to above apply to journeys and halt outside
theRecorder's lots.
   (2) They may also draw actual expenses
forconveyance of records to and from their lots.
   (3) [Deleted].
   (4) The Mandals in the Balipara Frontier Tractare
entitled to draw travelling allowance admissible to
3rd GradeGovernment servants while visiting the
three villages of Karibil,Dhansiri and Newly on
duty.
Forest
6.Deputy Ranger not in-charge
of Rangers,Foresters not in-
charge of Ranges, and Forest
guards withintheir sphere of
duty (a) All Deputy Rangers and Foresters whoseduties
necessitate the keeping of a horse or pony or
themaintenance of other carriage may draw
travelling allowance atthe ordinary rate.
   (b) All officers of the Forest Department whosepay
does not exceed Rs. 100 a month may draw actual
expenses forjourneys by boat where this is the
ordinary mode of travelling,irrespective of the fact
that the journey does not exceed 8 Kms.from
headquarters.
   (c) For purpose of Travelling Allowance thesphere
of duty of these officers in the Mizo District isFundamental Rules and Subsidiary Rules

limitedto a radius of 8 Kms. In the Khasi and
Jaintia Hills the sphereof duty of Head Guard and
Forest Guards is limited to a radius of8 Kms.
   (d) In the Sadiya Forest Division the sphere ofduty
of the Forest Guards who are required to carry
official dakand maintain serviceable bicycle is
limited to a radius of 8Kilometers for the purposes
of travelling allowance.
   (e) Forest guards when travelling on duty bymotor
bus along routes of regular motor service on a
journeytraversed by exceeding 8 Kms. from the
headquarters and entitledto draw actual motor
fare subject to a maximum of 4 paise per Km.;
provided the Divisional Forest Officer certifies
that thejourney by motor bus was actually
performed.
   Note.The District Officer will declarewhat routes
are traversed by regular motor services in
hisdistrict. A list of such routes, corrected from
time to time,should be supplied to each range
office within Iris jurisdictionby the Divisional
Forest Officer.
7.Dak-runners in the Forest
Department For journeys by rail, boat, steamer or in
urgentcases, by motor lorry they are allowed to
draw actual fares.
General
Administration
8.Mahouts and grass-cutters
attached to
elephantestablishments
maintained by head of
Departments and
DistrictOfficers The mahouts and grass-cutters of the
Conservatorof Forests are allowed travelling
allowance at the rate of 31paise a day when
touring on duty outside the limits of
KamrupForest Division.
Administration
of Justice
9. Process-servers and Bailiffs of
Civil, Criminaland Revenue
Courts Process serving peons throughout the State
areallowed to travel by motor bus along routes
traversed by regularmotor services when the
journey is more than 8 Kms. fromheadquarters
and the officers in charge of the Nazarat
certifiesthat the journey by motor bus was actually
performed. The cost ineach case will be limited to
actual motor fare subject to amaximum of 4 paiseFundamental Rules and Subsidiary Rules

per Km.
   Note 1.The District Officer will declarewhat routes
are traversed by regular motor services in
hisdistrict. A list of such routes, corrected from
time to time,should be kept by the officer ordering
the issue of process.
   Note 2.Fares for journeys made byprocess serving
peons by rail and steamer will be paid
fromprocess-serving contingencies. These peons
should not be directedto travel invariably by rail
or steamer, but should do so only iscases where
this will result again in time of emergency.
Police
10.Police officers and men of all
grades below therank of
Inspectors, with the
undermentioned exception : Entitled to have their necessary baggageincluding
utensils, conveyed at Government expense when
employedon escort duty and entitled to ordinary
travelling allowanceunder the ordinary rule when
travelling on escort or other dutyoutside
jurisdiction in Hill Districts, entitled to
conveyance ofbaggage on all journeys when
certified to be necessary when noother travelling
allowance is drawn.
(i)Sub-Inspector (except River
Police)- Entitled to draw daily allowance at the
ordinaryrates for all journeys on duty of more
than 24 Kms. from theirheadquarters; provided
the place to which they travel is beyondthe limits
of the Police Station.
(ii)Assistant Sub-Inspectors,
Head Constables
andConstables (except River
Police) may draw actual
expenses forjourneys by boat
where this is the ordinary
mode of travelling When travelling on duty by motor bus alongroutes
traversed by regular motor services on a journey
exceeding8 kilometers from the headquarters
entitled to draw actual motorfare subject to
maximum of 4 paise per Km., provided
theSuperintendent of Police certifies that the
journey by motor buswas actually performed.
(iii) Constables of the River Police
when deputed totravel on
Inland passenger steamers
are entitled to draw a
dailyallowance of 37 paise in
addition to a free pass or the
amount ofthe fare for every
day on which they are absent
from headquartersfor more Fundamental Rules and Subsidiary Rules

than 8 hours
(iv)Officers and men below the
rank of Inspectorattached to
the Criminal Investigation
Department and FingerPrint
Bureau. 
(v)Police Officers and men
below the ranks ofInspector In the River Police a compensatory allowance
isdrawn in lieu of travelling allowance.
(vi) [Deleted]  Note.The District Officer will declarewhat routes
are traversed by regular motor services in
hisdistrict. A list of such routes, corrected from
time to time,should be supplied to each Police
Station within his jurisdictionby the
Superintendent of Police.
Public Works
Department
11.Petty establishment expressly
engaged forservice in the field The Government in case of doubt may
decidewhether any particular officer or class of
officers comes withinthis term or not.
12.Sub-overseers (at present
members of the
LowerSubordinate
establishment) May be granted conveyance allowance under
S.R.162 ; also mileage under the special orders of
the Executive orAssistant Executive Engineer
under whom they are employed.
13.Field and Survey
Establishment of special
LandAcquisition Officers Entitled to no travelling allowance (except
forjourneys by rail or steamer) within their
spheres of duty.
14. Surveyors   
15.(a) Superior field Workers
Malaria Organisation When travelling on duty in connection with
fieldworks, they may be provided with
Government vehicles. In case noGovernment
vehicle is available, they will be entitled to
drawactual Bus fare subject to a maximum of 6
paise per Km. on ajourney, exceeding 8 Kms. from
the Headquarters, providedZonal/Unit Officers
certify that the journey by Motor Bus wasactually
performed. For halt at any place beyond
theirjurisdiction, they will be entitled to daily
allowance at therates admissible to their grades as
per Schedule below S.R. 153.
 (b) Field Workers, Malaria
Organisation 
  Fundamental Rules and Subsidiary Rules

(c) Surveillance Workers,
(Employees of
MalariaOrganisation)
S.R.203. The travelling allowance drawn by a Government servant on tour ordinarily takes the
shape of either permanent travelling allowance or daily allowance, if either of these is admissible to
him. Permanent travelling allowance and daily allowance may, however, in certain circumstances,
be exchanged for mileage allowance or for the whole or part of the actual cost of travelling. In
certain other circumstances actual cost may be drawn in addition to daily allowance, or for journeys
for which no daily allowance is admissible.S.R.204. (a) A competent authority may prescribe the
scale of Government tents to be supplied to any Government servant or class of Government
servants for office, or, if it thinks fit, for personal use.(b)When Such tents are used by a Government
servant on tour for office purposes, they may be carried at Government expense.(c)When used
partly for office and partly for private purposes the Government servant, must except as provided in
S.R. 221, pay half the cost of carriage. When used wholly for private purposes, Government servant
must, except as provided in S.R. 221, pay the entire cost of carriage.Note. The traversers of the
Assam Survey Department will pay one-fourth of the freight charges for carriage of tents used partly
for keeping office papers and instruments and partly for sleeping in.(ii)Government servants in
receipt of permanent travelling allowanceS.R.205. Permanent travelling allowance is intended to
cover the cost of all journeys within the sphere of duty of the Government servant who draws it, and
such Government servant may not draw any other travelling allowance in place of or in addition to
permanent travelling allowance for such journeys :Provided that-(1)a Government servant of the 4th
grade and any other class of Government servant to which a competent authority may extend this
concession, may draw in addition to permanent travelling allowance, single fare for journey by rail;
and(2)a competent authority may, by general or special order, permit a Government servant whose
sphere of duty extend beyond the limits of a single district to draw, in addition to a permanent
travelling allowance whenever his actual travelling expenses for a duly authorised journey by public
conveyance exceed double the amount of his permanent travelling allowance for the period occupied
in such journey, the difference between such double permanent travelling allowance an the mileage
allowance calculated for the journey.S.R.206. When a Government servant in receipt of permanent
travelling allowance travels of duty, with proper sanction, beyond his sphere of duty, he may draw
mileage allowance for the entire journey, including such part of it as is within his sphere of duty, and
may draw, in addition, permanent travelling allowance for any day of his absence for which he does
not draw mileage allowance. This rule does not apply to a Government servant who travels beyond
his sphere of duty in the course of a journey from once place within that sphere to another such
place, or to the Government servant who makes, by road alone, a journey not exceeding 32
kilometers.Note. In calculating permanent allowance for a portion of a month in this and the
preceding rule, a month will be taken as 30 days.S.R.207. (a) When a competent authority is
satisfied that it is in the interest of the public service that a particular Government servant on tour
should send his horses, motor cars, motor cycles, bicycles or camp equipment by railway or steamer,
or by country craft where no steamer service exists capable of conveying the goods or animals or
when no such means of carriage in cheaper or more expeditious, it may, by special order in each
case, permit him to recover, in addition to mileage allowance or permanent travelling allowance or
both, the actual cost or part of the actual cost of transporting them.Note 1. In the case of a motor car,
the cost of transporting a chauffeur or cleaner and for each horse the cost of transporting one syceFundamental Rules and Subsidiary Rules

and one grass-cutter may be drawn.Note 2. The object of the rule is to meet an extraordinary case in
which a Government servant, has in the discharge of the official duties, to make use of his horse or
camp equipment in one place immediately or very shortly after having had to use them in the public
service in another, and is, therefore, in the exigencies of the service, compelled to convey them by
rail or steamer. The term "in the Public service" includes economy of a Government servant's
time.Note 3. Incidental expenditure may be admitted under this rule, for carriage of camp
equipment and conveyance from steamer to quay, but no charges on shore.Note 4. A competent
authority may allow transport of bicycles by motor bust along routes traversed by regular motor
services.(b)A competent authority may, by general or special order, prescribe limitations on the
weight of camp equipment and the number of conveyances and animals to be carried at Government
expense under Clause (a) of this rule by a particular Government servant or class of Government
servants.(iii)Government servants not in receipt of permanent travelling allowance to draw daily
allowanceS.R.208. Except where otherwise expressly provided in these rules a Government servant
not in receipt of permanent travelling allowance draws travelling allowance for journeys on tour in
the shape of daily allowance.S.R.209. Daily allowance may not be drawn except during absence from
headquarters on duty. A period of absence from headquarters begins when a Government servant
actually leaves his headquarters and ends when he actually return to the place in which
headquarters are situated whether he halts there or not.Note 1. The examiner, Local Accounts may
permit a local auditor to draw daily allowance during compensation leave, even if such leave is spent
at a station other than that at which it was earned ; provided that daily allowance shall not be drawn
for such leave taken at headquarters or earned at headquarters. Daily allowance may not be drawn
for a period of compensation leave combined with regular leave.The expression "local auditor" in
this Note includes "an assistant local auditor".Note 2. The Extra Assistant Commissioners and
Munsiffs when away from their headquarters, on duty within the district, and subordinate Judges
when temporarily transferred on duty from one district to another, may draw daily allowance at full
rates for the first month of the halt and at half rate for the second and the third month. After the
third month the allowance will cease altogether.The allowance is not admissible during leave but
may be drawn during a vacation. It will not be allowed to Munsiffs in case in which they join their
duties at the station to which they are deputed before joining the station to which they are
permanently attached, i.e., unless the deputation involves an actual change of station and the
expenses of a double establishment. Claims not covered by this principle should be referred to
Government for orders.Note 3. The establishment accompanying these officers will also be entitled
to the daily allowance at full rates for the first month and at half rates for the second and third
months after which the allowance will cease.Note 4. Halting allowance may be drawn by an officer
for halt at headquarters if he is summoned there to give evidence while on leave elsewhere.S.R.210.
Daily allowance may not be drawn for any day on which a Government servant does not reach a
point outside a radius of 8 Kilometers from his headquarters or returns to his headquarters from a
similar point.Note 1. The provisions of this rule do not apply in the case of Government servants
(i.e., officers of the Indian Administrative Service, Assam Civil Services Class I and II) deputed to
undergo a course of instruction in Survey and Settlement at the Assam Survey School, Jhalukbari,
serial 14 of Appendix 28 and serial 2 of Appendix 24 being absolute in their case.Note 2. In cases
where a village is less than 8 Kilometers from headquarters in a straight line but more than 8
Kilometers by the only practicable route, travelling allowance may be admitted by that route, but the
allowance cannot be granted simply on the ground that a journey exceeding 8 Kilometers wasFundamental Rules and Subsidiary Rules

performed in visiting several villages, none of which was more than 8 Kilometers from headquarters
by the ordinary direct route.S.R.211. Subject to the conditions laid down in Rr. 212 and 213 daily
allowance may be drawn during a halt on tour or on a holiday occurring during a tour :(a)a
Government servant, who takes casual leave while on tour is not entitled to draw daily allowance
during such leave ;(b)a Government servant who during the course of his tours returns temporarily
to headquarters on a Sunday or public holiday to attend to his private business, is not entitled to
draw daily allowance for any day whether Sunday or holiday unless he is actually, and not merely
constructively, in camp ;(c)when a Government servant on tour leaves his station to enjoy holidays,
he may be allowed to draw daily allowance for the day on which he leaves and for the day on which
he returns to the place of halt, provided he leaves it after the regular working hours begin.S.R.212.
(1) Daily allowance may not be drawn for a continuous halt for more than 10 days at any one place
provided that a competent authority may grant general of individual exemptions from the operation
of this rule on such condition as it thinks fit, it is satisfied-(a)that prolonged halts are necessary in
the interest of the public service, and(b)that such halts necessitate the maintenance of camp
equipage or where no camp equipage is maintained, continue after the first 10 days, to entail extra
expenses upon the halting Government servant.(2)A list of Government servants exempted from the
operation of this rule is given in Appendix 24.Note 1. When a competent authority exempts any
officer from the operation of the above rule, the rate of daily allowance drawn by the officer will be
reduced to ¾th after the first 10 days and to ½ after the first 30 days except where otherwise
provided in Appendix 24 [See also para 7 of the "Executive Instructions" below S.R. 225-A as
inserted by C.S. No. 228].Note 2. The District and Sessions Judges, Additional District and Sessions
Judges, Assistant and Subordinate Judges and Munsiffs and the establishment travelling with them,
the Working Plans Officers and the Forest Veterinary Surgeon, may draw daily allowance at ¾th
rates after 30 days' halt, if the controlling officers certify that the prolonged halt was necessary.The
expression "Working Plan Officers" occurring in this Note includes in its scope Gazetted Officers
and Forest Subordinates attached to a Working Plan Division.S.R.213. For the purpose of S.Rr. 210
and 212-(a)after a continuous halt of 10 days' duration, the halting place shall be regarded as the
Government servant's temporary headquarters ;(b)a halt is continuous unless terminated by an
absence on duty at a distance from the halting place exceeding 8 Kilometers for a period including
not less than 3 nights ;(c)in calculating the duration of a halt, any day on which the Government
servant travels or halts at a distance for the halting place exceeding 8 Kilometers, shall be excluded.
On such a day the Government servant may draw daily allowance or exchange it for mileage
allowance if admissible.Mileage Allowance and Actual Expenses in Place of or in Addition to Daily
AllowanceS.R.214. A competent authority may, by general or special order and on such conditions
as it thinks fit to impose, permit any Government servant or class of Government servants to draw
mileage allowance instead of daily allowance for the whole period of any absence from headquarters,
if it considers that nature of Government servant's duty is such that daily allowance is not sufficient
to cover his travelling expenses.S.R.215. A competent authority may, by general or special order and
on such conditions as it thinks fit to impose, permit any Government servant or class of Government
servants to draw mileage allowance instead of daily allowance for journeys involving exceptional
expenditure.Note. Heads of Departments are allowed to draw mileage allowance instead of daily
allowance for journeys on the Dimapur-Imphal Road.S.R.216. (a) Subject to any conditions which a
competent authority may, by general or special order impose, a Government servant of the Senior,
1st, 2nd, and 3rd grades may exchange his daily allowance for mileage allowance on any day onFundamental Rules and Subsidiary Rules

which he travels by railway or steamer or both and on any day on which he travels more than 32
Kms., by road except as mentioned in Clause (c) ; provided that, if a continuous journey extends
over more than one day, the exchange must be made for all such days and not for a part of
them.(b)When a journey by road is combined with a journey by railway or steamer under Clause (a)
of this rule-(i)mileage allowance may be drawn on account of such journey by road, but such
mileage is limited to the amount of daily allowance, unless the journey by road exceeds 32
Kms.;(ii)unless such journey by road be a journey to or from the Government servant's
headquarters, mileage allowance shall be calculated on the distance actually travelled, without
reward to the points fixed by or under S.R. 169.Note. The road journey must be in continuation of
the rail or steamer journey [See also Note 1 under S.R. 182].(c)Officers travelling on the
Shillong-Cherra and Imphal-Dimapur roads shall, subject to the exceptions noted below, draw the
following allowances for journey in excess of 32 Kms. performed on these roads in lieu of mileage
allowance under S.R. 182 or 206 :(i)the daily allowance to which they are entitled minus the
proportionate permanent T.A., if any ;(ii)in addition a single fare of the class noted below ; as fixed
from time to time for journeys by omnibus-
Officers of the Senior, 1st and 2nd grades Upper Class.
Officers of the 3rd and 4th grades Lower Class.
S.R.216A. As partial exception to S.R.216, in the case of halts on tour, half the daily allowances
ordinarily admissible under the rules may be drawn in addition to mileage allowances on the day of
arrival of the Government servant at the place of halt; provided it involves staying the night at that
place.Note. The expression "place of halt" in the above rule does not include a temporary halt at a
Railway Station in the course of a journey except at Gauhati and Calcutta. The halt at these two
stations in the course of a journey will entitle an Officer to draw half daily allowance in addition to
mileage where admissible if it involves staying the night there.These orders take effect from the 1st
June, 1945.Executive InstructionsThe following principles are laid down for the guidance of all
tearing officers in the matter of the drawal of half daily allowance while on tour.
1. For the purpose of the travelling allowance rules the word 'halt' means a
pause in the course of a journey on tour necessitated by the performance of
official duty at an out-station. No half daily allowance can, therefore, be
claimed by a Government servant who stops at out-station merely for the
purpose of breaking the journey for the night, or spends the night at such
out-station in order to catch the next available means of conveyance on the
following morning, or to resume his forward journey in continuation of the
previous day's journey, subject to the special exception accorded in the note
to halts at Gauhati and Calcutta necessitated by timing regulation.
Note. 'Journey' means journey by Road, Air, Railway or Steamer.Fundamental Rules and Subsidiary Rules

2. No half daily allowance is admissible for anyone unless the halt is
preceded by a journey in respect of which an officer actually draws mileage
allowance under S.R. 216.
3. Half daily allowance is intended to cover the expenses to halting for the
night on lour; it follows that it is not admissible for the day on which an
officer returns to his headquarters even he has drawn mileage for that day
except in the case when a Government servant, who, while returning to
headquarters, performs a journey of not less than 240 Kilometers on the day
of return. The rate of allowance to be drawn for this purpose will be half the
daily allowance admissible within the State if the journey commences within
the State ; and if the journey commences outside the State, the allowance to
be drawn will be half the daily allowance admissible outside the State.
4. In case of an officer whose absence from his headquarters does not
exceed 24 hours but falls on two calendar days, half daily allowance will be
admissible for the first calendar day of the halt; provided mileage allowance
is drawn under S.R. 216 for the journey to the place of halt. The drawal of half
daily allowance in such a case will be subject to the condition that the officer
had to halt at the out-station for the night for the performance of the official
duty.
5. In view of 2 above no half daily allowance can be drawn by an officer on
any day on which he uses for his travel-a means of locomotion, provided at
the expense of Government, since for such a journey he is not entitled to
draw mileage allowance under S.R. 216. He will, however, be eligible to the
half daily allowance , if otherwise admissible if a part of the journey is made
by other means of locomotion for which he is entitled to claim mileage
allowance under S.R. 301.
6. As a result of these interpretations it is also necessary to lay clearly the
principle governing the drawal of daily allowance by a Government servant
after the first ten days halt at out-station including the day of arrival. For a
halt exceeding ten days including the day of arrival, the Government servant
will be entitled to only 9-½ full daily allowance and thereafter at reduced rates
as laid down in Note 1 to S.R. 212; if he is exempted from the operation of
S.R. 212 (1). Where, however, the officer concerned does not apply for andFundamental Rules and Subsidiary Rules

obtain the order of exemption from the competent authority, he can draw for
a halt exceeding ten days including the day of arrival ten full daily allowance.
7. All Controlling Officers are expected to see that no improper claim is
passed under these rules.
S.R.217. Subject to any conditions which a competent authority may, by general or special order
impose, a non-Gazetted ministerial or menial Government servant may, for any day on which he
travels by public or hired conveyance under a certificate from the Head of his Office that he is
required to do so, exchange daily allowance for mileage allowance.Note 1. "Hired conveyance"
includes a bullock cart, but only one cart should be allowed.Note 2. The mileage allowance shall be
limited to actual expenses when drawn under this rule.S.R.218. The following conditions are
applicable to a Government servant of the 4th grade :(a)for a journey by railway or sea or river
steamer, he may draw T.A. under S.R. 196;(b)for a journey by road, he may exchange daily
allowance for mileage allowance if the journey exceeds 32 Kms. or the condition of S.R. 217 is
fulfilled ;(c)for a journey by road combined with a journey by rail or by sea or river steamer, he may
draw mileage allowance limited as in S.R. 216 (b) (i) except as provided in S.R. 217 for the road
journey, in addition to the allowance admissible under Clause (a) of this rule.Note. Police constable
to whom advances are made for railway, steamer and road expenses may draw, in addition, if
otherwise entitled to it, the daily allowance admissible under this rule.S.R.219. A competent
authority may permit any Government servant, who is compelled by a sudden emergency to leave
his camp and travel rapidly on duty to a place more than 32 Kms. distant, to draw in addition to
mileage allowance, the actual cost of maintaining his camp, whether the camp be moved or not;
provided that the amount of actual cost drawn shall not exceed the daily allowance of his
grace.S.R.220. A Government servant entitled to daily allowance whose duty sphere extends over a
whole State, may, when making a journey of more than 161 Kms. to the 1st or from the last camp of
an extensive tour, recover in lieu of the daily allowance admissible for the days occupied by such
journey, the whole necessary cost of the journey, including the cost of transportation of camp
equipment and of servants, horses motor cars, motor-cycles, or private baggage on such scale as a
competent authority may prescribe.S.R.221. When a competent authority is satisfied that it is in the
interest of the public service that a particular Government servant on tour should send his horses,
motor cars, motor-cycles, bicycle, or camp equipment by railway or steamer or by country craft
when no steamer service exists capable of conveying the goods or animals or when such means of
carriage is cheaper or more expeditious, it may, by special order in each case, permit him to recover,
in addition to mileage allowance or daily allowance or both the actual cost or part of the actual cost
of transporting them.Note 1. In the case of a motor car, the cost of transporting a chauffeur or
cleaner and for each horse the cost of transporting one syce and one grass-cutter may be drawn.Note
2. The object of the rule is to meet an extraordinary case in which a Government servant has, in the
discharge of his official duties, to make use of his horses or camp equipment in one place
immediately or very shortly after having had to use them in the public service in another and is,
therefore, in the exigencies of the service compelled to convey them by rail or steamer. The term "in
the public service" includes the economy of a Government servant's time.Note 3. Incidental
expenditure may be admitted under this rule for carriage of camp equipment and conveyances fromFundamental Rules and Subsidiary Rules

steamer to quay but no charges on shore.Note 4. (a) A competent authority may allow transport of
bicycles by motor bus along routes traversed by regular motor services.(b)An competent authority
may, by general or special order, prescribe limitations on the weight of camp equipment and the
number of conveyances and animals to be carried at Government expenses under Clause (a) of this
rule by a particular Government servant or class of Government servants.S.R.222. (a) The following
provisions are applicable to-(i)officers of the Railway Police above the rank of Sub-Inspector ;(ii)any
other Government servant or class of Government servants whose duties involve travelling by
Railway to whom a competent authority may declare them to be applicable.(b)When such as a
Government servant makes a journey by Railway on tour-(i)he is entitled either to a free pass under
the free pass rules of the railway or to the fares for himself and the servants and baggage
accompanying him which a free pass would cover ;(ii)he may draw daily allowance for any day on
which he is absent from his headquarters for more than eight consecutive hours ;(iii)he may not
exchange for mileage allowance the allowances admissible under sub-Clauses (i) and (ii) of this rule
;(iv)if he combines with a railway journey, a journey by steamer or road he may, if he travels to a
place distant at least 8 Kms. from the point where he leaves the railway or returns to the railway
from a place similarly distant draw mileage allowance, for the journey by steamer or road, in
addition to daily allowance, if any, admissible under this rule or under S.R. 126 ; provided that the
time spent on the journey by steamer or road shall be deducted in calculating the duration of his
absence from his headquarters.Note. No allowance may be drawn under this rule for a journey
within 8 Kms. of headquarters.Travelling Allowance Admissible for Journeys Within 8 Kms. of
HeadquartersS.R.223. A competent authority may, by general or special order, permit any
Government servant or class of Government servants to draw the actual cost of hiring a conveyance
on a journey for which no travelling allowance is admissible under these rules.S.R.224. A
Government servant travelling on duty within 8 Kms. of his headquarters is entitled to recover the
actual amounts which he may spend in payment of boat hire, ferry and other tolls and fares in
journeys by railways or other public conveyance.S.R.225. On the following conditions or any other
conditions which it may think fit to impose, a competent authority may, by general or special order,
permit any Government servant or class of Government servants to recover the actual cost of
maintaining camp equipage a halt at headquarters or within 8 Kms. of headquarters, or during the
interval between the Government servant's departure from or arrival at headquarters and that of his
camp equipage :(a)the amount drawn, together with any amounts recovered under S.R. 224, should
not exceed the daily allowance of his grade ;(b)the period of the halt or interval for which it .is
granted should not exceed ten days. An absence on duty from the halting place for less than three
nights should not be treated as interrupting the halt or interval;(c)the Government servant must
satisfy that he has maintained the whole or part of his camp equipage during the halt or interval and
that the expense of maintenance has been not less than the amount drawn. In the case of a
non-Gazetted or menial servant, the head of the office must satisfy that such maintenance was
necessary.Note. The actual expense is the difference between the actual outlay incurred, e.g.,
monthly hire and what would be incurred if the equipage were to be discharged until wanted again.
It does not include the cost of maintaining private conveyances.(iv)Special Rules For High
OfficialsS.R.226 to 234. [Deleted].Division XIJourney of a newly appointed Government servant to
join his first postS.R.235. Except as otherwise provided in this Division travelling allowance is not
admissible to any person for the journey to join his first post in Government service.S.R.236. A
competent authority may, by general of special order, permit any person, whether appointed to aFundamental Rules and Subsidiary Rules

temporary or a permanent post to draw travelling allowance for the journey to join his first post in
Government service.Note 1. Officiating Munsiffs on their joining a first appointment and on
termination of appointment may be allowed by the District and Sessions Judges-(a)one second class
fare by rail;(b)one second class fare by steamer and table money ;(c)actual expenses not exceeding 6
paise per Km. by road.No travelling allowance is admissible to a Munsiff on probation for the
journey he undertakes to join his first appointment as probation.Note 2. The following classes of
Government servants are entitled to draw travelling allowance under this rule :(i)Trained
Compositors from other States ;(ii)Sub-Assistant Surgeons and Veterinary Assistants from their
usual place of residence to the place to which they are posted.S.R.237. When a pensioner, or a
Government servant who has been thrown out of employment owing to a reduction of establishment
or the abolition of his post, is re-appointed to Government service, the authority which sanctions his
reappointment may permit him to draw travelling allowance for so much of his journey to join his
new post as falls within India.S.R.238. [Deleted].S.R.239. Travelling allowance under S.Rr. 236 and
237 should be calculated as for journey on tour, but no allowance may be drawn for halts on the
journeys.S.R.240. When mileage allowance is drawn under S.Rr. 236, 237 and 238, the rate
admissible is that of the grade to which the Government servant will belong after joining his
post.Division XIIJourneys on TransferS.R.241. (1) Travelling allowance may not be drawn under
this Division by a Government servant on transfer from one station to another unless the transfer is
made for the public convenience and the officer is entitled to pay during the period occupied by the
journey. A transfer, at his own request should not be treated as a transfer for the public convenience,
unless the authority sanctioning the transfer, for special reasons, which should be recorded,
otherwise direct.(2)A Government servant under suspension may draw travelling allowance on
account of a journey on transfer when the controlling authority certifies that the transfer is
necessary in public interest, even though his is not entitled to pay during the period occupied by the
journey.Note. An officer who, on transfer to another appointment, keeps a lien on his own
appointment, may be allowed on reversion, travelling allowance under S.R. 243 by the controlling
officer if the latter is satisfied that such reversion serves public interest.S.R.242. A Government
servant may draw mileage allowance for a journey on transfer, including transfer from Military to
Civil employment.S.R.243. Unless in any case it be otherwise expressly provided in these rules or in
rules made under other sections of the Act, a Government servant in superior service is entitled for a
journey on transfer, to the following concessions:I. For journeys by rail or steamer(i)he may draw
actual fare by rail or steamer not exceeding the fare of the entitled class plus an allowance for
incidental expenses at four times the rate prescribed for journeys on tour by rail in respect of
journeys by rail and at the rate of three steamer fare of the entitled class in respect of the journeys by
steamer ;(ii)he may draw one extra fare for each adult member of his family who accompanies him
and for whom full fare is actually paid and one half fare for each child for whom such fare is actually
paid ;(iii)he may draw the actual cost of transporting at owner's risk rate by goods train, steamer or
other craft personal effects up to the following maxima :
Grade of Government servant If not possessing family If possessing family
Senior Grade 1,500 Kg. 2,250 Kg.
1st Grade 1,500 Kg. 2,250 Kg.
2nd Grade 750 Kg. 1,125 Kg.Fundamental Rules and Subsidiary Rules

3rd Grade 450 Kg. 562 Kg.
Provided that the competent authority may prescribe lower maxima in the case of any specified class
of Government servants.Note 1. If a Government servant carries his personal effects by passenger,
instead of by goods train, he may draw the actual cost of carriage up to a limit of the amount which
would have been admissible had he taken the maximum number of Kilometers by goods train.Note
2. Subject to the prescribed maximum number of Kilograms, a Government servant may draw the
actual cost of transporting personal effects to his new station from a place within the State other
than his old station (e.g., from a place where they have been left on the occasion of a previous
transfer) or from old station to a place within the State other than his new station ; provided that the
total amount drawn, including the cost of transporting these personal effects shall not exceed that
admissible had all his personal effects been transported from the old to the new station direct.Note
3. The term "other craft" includes a country boat.Note 4. A Government servant who carries his
personal effects by road or boat between station connected by rail or steamer may draw actual
expenses upon the limit of the amount which would have been admissible had he taken the same
quantity by goods train or steamer subject to the production of the payee's receipt for the amount
claimed :(iv)Provided that-(1)the distance travelled exceeds 130 Kms.;(2)the Government servant is
travelling to join a post in which the possession of a conveyance or horse is advantageous from the
point of view of his efficiency ; and(3)conveyances or horses are actually carried by rail, steamer or
other craft.He may draw the actual cost of transporting at owner's risk rate conveyances and horses
on the following scale :
Grade of Government servant Scale allowed
Senior GradeTwo horses and a carriage or motor car or motor
cycle
1st GradeTwo horses and a carriage or motor car or motor
cycle
2nd GradeOne horse and a carriage or motor car or motor
cycle
3rd Grade One horse or a motor cycle or ordinary cycle
Note 1. In the case of motor car, the cost of transporting a chauffeur or cleaner, and for each horse
the cost of transporting one syce and one grass-cutter may be drawn.Note 2. In the case of motor
cars, motor cycles, and ordinary cycles, freight by passenger train is to be taken as "actual cost" if
such train is actually used.Note 3. Incidental charges e.g., unloading and loading and wharfage, are
allowances only in the case of carriage by steamer. No charge on shore may be allowed.Note 4. The
full scale of conveyance provided in Clause (iv) above may be drawn by all officers on transfer
according to their respective grads on production of a certificate from the controlling officer to the
effect required by Clause (iv) (2). The concession is not ordinarily admissible in cases of temporary
transfer.Exception. - Commissioner, Head of Department, District Officers (including the Deputy
Commissioner, Mizo District, the Political Officers, Sadiya and Balipara Frontier Tracts), Settlement
Officers, Divisional Forest Officers, Civil Surgeons, Superintendent of Police, Executive Engineers,
Inspectors of Schools and the Director of Veterinary Department, need not furnish such
certificates.Note 5. If a Government servant possessed a conveyance or a horse at the station from
which he is transferred, he may draw the actual cost of transporting a conveyance or a horse
respectively from a place other than his former station ; provided that the amount so drawn shallFundamental Rules and Subsidiary Rules

not exceed that admissible had it been from the old to the new station direct; and provided further
that the conveyance or horse is actually transported to the new station within a reasonable time
before or after the officer is transferred.Note 6. When a Government servant transports his
motor-car or motor cycle by road under his own power between stations connected by rail or
steamer or partly by rail and partly by steamer, he may draw an allowance of 8 paise per Km. in
respect of the motor-car and 4 paise per Km. in respect of the motor cycle, the distance to be
reckoned for the purpose of this concession being limited to the distance between the stations by rail
or steamer or both combined, as the case may be. If the Government servant himself travels by the
car or motor cycle, he may draw the fares admissible under Clause 1 (ii). For any member of his
family who travels by the car or motor cycle, the Government servant may draw the extra fare or half
fare which would have been admissible under Clause 1 (ii) if the member had travelled by rail or
steamer :(v)A Government servant who travels by Government steamer or by a Government motor
vehicle is not entitled for the journey by steamer or a motor vehicle, either to a mileage allowance
under S.R. 242 or to the concession allowance by Clause (iv) of S.R. 243-1. He is entitled to free
transport of himself, his family, servants and their bona fide personal effects and of conveyances and
horses subject to the limits prescribed in Clause (iv) ; and may draw in addition the daily allowance
of his grade.II. For journeys by road(i)He may draw mileage allowance at twice the rate applicable to
him under S.R. 182 or 194, or any rate applicable to him, which has been fixed under S.R. 184 as the
case may be.(ii)He may draw additional mileage allowance at the rate applicable to him under S.R.
182 or 194, or any rate, applicable to him which has been fixed under S.R. 184, as the case may be, if
two members of his family accompany him, and at twice the rate if more than two members
accompany him.Note. An Officer travelling on transfer by the Shillong- Gauhati road is entitled to
travelling allowance at the following rates, viz:Journeys by State Transport Services. - (i) A
Government servant will be entitled to draw three fares of the class to which his grade entitles
him.(ii)He may draw one extra fare for each adult member of his family who accompanies him and
for whom full fare is actually paid and half fare for each child for whom such fare is actually
paid.Journeys by other modes of transport. - A Government servant will be entitled to mileage
under S.R. 243-11 and at the rates laid down in S.R. 182 for journeys on transfer.The Government
servants will be entitled to re-imbursement of the cost of transportation of personal effects upon the
limits prescribed under S.R. 244-1 (ii) as per the rates of the State Transport.(iii)For the
transportation of personal effects within the limits prescribed in Sub-Clause 1 (iii) of this rule, he
may draw mileage allowance at the rate to be fixed by a competent authority. This rate will be
calculated on the average cost of conveying goods by the cheapest method of conveyance.Note 1.
Within the following maxima rates the controlling officer may allow free transport of goods by road
for journeys on transfer up to the maundage limits given in Clause 1 (iii) of this rule :
(1)Maximum limit of 16 paise per 37
Kgs per Km. inNorth Cachar Hills.
(2)Maximum limit of 8 paise per 37
Kgs. Per Km. inKarimganj Sub-division, the Mizo District except between
Aijaland Sairang, and- Silchar and Rangamati and Demagiri,
Manipur andthe Garo Hills.
(3)From Sadia up to PayanFour paise per 37 Kgs. per Km. subject to a maximum of Rs.
15.
(4)From Payan upwards and in the Actual expenditure on carriage of luggage or 16 paise perFundamental Rules and Subsidiary Rules

Tirap Frontier Tract and
SadiyaFrontier Tract37Kgs. per Km. whichever is less.
(5)All other places Maximum limit of 4 paise per 37 Kgs. per Km.
Note 2. The cheapest method of conveyance of goods on the Shillong Dawki and Imphal-Dimapur
roads is by motor omnibus. The normal cost of such transportation will be declared half-yearly by
the Deputy Commissioner, Khasi and Jaintia Hills, in the case of the Shillong-Dawki road and the
Deputy Commissioner, Naga Hills, in the case of the Imphal Dimapur road.State Government's
decision. - A question has been raised as to what would be the entitlement of a Government servant
who, on transfer from one station to another, transports his motor car loaded on a truck either
between the stations connected by road.After careful consideration of the matter, the Governor of
Assam is pleased to decide that a Government servant who, on transfer from one place to another is
travelling to join a post in which the possession of a car is advantageous from the point of view of
efficiency and in whose case the distance between the two stations by rail or by road, as the case may
be, exceeds 130 Kms. may, in the event of a car loaded on a truck, be allowed the actual
transportation charges thereof limited to the freight charges which would have been payable had the
car been transported by passenger train in respect of places connected by rail and an allowance
calculated at the rate of 8 paise per Km. in respect of places connected by road.S.R.244. The
following explanations are given of the terms employed in S.R. 243 :(i)The term" personal effects" is
not subject to definition but the controlling officer must satisfy himself that a claim to
reimbursement on account of their transportation is reasonable.Note. Private conveyances can be
admitted as "personal effect" only if the Government servant is not entitled to their transport under
S.R. 243-1 (iv).(ii)The term "motor cycle" includes a side-car.(iii)A member of a Government
servant's family who follows him within six months from the date of his transfer or precedes him by
not more than one month may be treated as accompanying him. If such member travels to the new
station from a place other than the Government servant's old station, the Government servant may
draw either the actual fare for the journey made or the fare admissible for the journey from the old
to the new station, whichever is less.Note 1. When a Government servant who was residing with his
family is obliged to move them in consequence of his transfer to another station, he may be
reimbursed the cost, even though they may not proceed to his new station ; but the travelling
allowance drawn must be limited to actual expenses not exceeding the amount which would have
been admissible if the family had proceeded to the officer's new station.Note 2. A Government
servant, whose family was not residing with him at the time of his transfer, may draw family
travelling allowance for the family's journey to his new station ; provided that the amount of such
allowance is limited to that admissible for the journey between the officer's old and new
stations.Note 3. To entitle an officer to travelling allowance under this clause on account of any
member of his family subsequently joining him, the journeys should commence within six months of
the officer' handing over charge at the old station and end within six months of his taking charge at
the new station ; provided that in the case of an officer's transfer during leave the journey need not
commence but must end within the aforesaid periods.(iv)A Government servant who claims higher
travelling allowance on the ground that members of his family accompanied him on transfer must
support his claim by a certificate showing the numbers and relationship of the said members.(v)A
Government servant claiming the cost of transporting personal effects, conveyances or horses by
railway or steamer or road must substantiate his claim by the production of the payee's receipts for
the amount claimed.S.R.245. Tents supplied by Government are transported at the expenses ofFundamental Rules and Subsidiary Rules

Government. Tents purchased and maintained by Government servant himself may be transported
at the expense of Government ; provided that they do not exceed a scale to be prescribed in this
behalf by a competent authority as suitable to a particular Government servant or class of
Government servants. If they exceed this scale, the excess may be treated as a part of personal
effects.S.R.246. [Deleted].S.R.247. A Government servant in superior service whose headquarters
are changed while he is on tour, and who proceeds to this new headquarters without returning to his
old, is entitled to-(1)travelling allowance as on tour for his journey to the new headquarters;(2)the
rates of mileage allowance to which his grade entitles him on tour from his old to his new
headquarters ;(3)all further concessions admissible under Rule 243 direct from the old to new
headquarters, excluding those in Clause I (i) thereof and the mileage referred to in Clause II
(i).S.R.248. A Government servant in superior service transferred from one post to another who,
under the orders of competent authority is permitted to hand over charge of his old post or take over
charge of the new post at a place other than the headquarters is entitled to-(1)travelling allowance as
on tour from the place of handing over charge to the place of taking over ;(2)the rates of mileage
allowance to which his grade entitles him on tour from his old to his new headquarters ;(3)all the
further concessions admissible under Rule 243 direct from the old to the new headquarters,
excluding those in Clause I (i) thereof and the mileage referred to in Clause II (i).For the journeys
from his old headquarters to the place of handing over charge or from the place of taking over
charge to his new headquarters he will draw travelling allowance as for journey on tour.S.R.249. The
Government servants specified in S.R. 222 may draw travelling allowance under that rule for
journey on transfer within the limits of the railway to which they are attached, and, are entitled, in
addition, to a free pass or fares for their families; provided that they must not draw daily allowance
for halts in the course of the journey unless such halts are made in connection with their duty. When
transferred from one railway to another they are entitled to travelling allowance under S.Rr. 241 to
243.S.R.250. (a) A Government servant of the 4th grade (including Police Constables and Jail
Warders) is entitled for a journey on transfer, to mileage allowance at the following rates :For
journey by rail or steamer-(i)he may draw actual fare by rail not exceeding the fare of the entitled
class plus an allowance for the incidental expenses at four times the rate prescribed for journeys on
tour by rail in respect of journeys by rail and two fares of the entitled class in respect of journeys by
steamer;(ii)he may draw one extra fare for each adult member of his family who accompanies him
and for whom such fare is actually paid and one-half for each child for whom such fare is actually
paid ;(iii)he may draw the actual cost of transporting at owner's risk rate by goods train or steamer
or other craft to the following maxima.If travelling alone-115 Kg. If accompanied by family-192
Kg.For journeys by boat or road(b)For journey by boat they are entitled to the actual expenses
including the cost of transporting their baggage on the scale laid down above, on production of a
certificate from the highest district authority of the Department to which the officer belongs.(c)For
journeys by road they are entitled to 8 paise for each Km. travelled and in the case of those
accompanied by their families 12 paise per Km. In addition, they will draw the actual cost of
transporting their baggage on the condition laid down in (b) above.S.R.251 to 252.
[Deleted].S.R.253. A Government servant appointed to a new post while in transit from one post to
another is entitled to draw travelling allowance under this Division for so much of the journey on
transfer as he has accomplished when he receives the fresh orders and for the journey from the place
at which he receives such order to his new station.S.R.254. A Government servant who takes leave
not exceeding 6 months after he has given over charge of his old post and before he has taken chargeFundamental Rules and Subsidiary Rules

of his new post is entitled, whether the order of the transfer is received before or after the
commencement of his leave, to travelling allowance under the Division.S.R.255. A Government
servant who takes leave exceeding 6 months while in transit from one post to another may draw
travelling allowance under S.R. 253 (i) and (ii) and II (i) and (ii) for so much of the journey to join
the new post as he had accomplished before the order granting his leave is received, in addition to
any allowance admissible under S.R. 256.S.R.256. When on return from leave exceeding 6 months a
Government servant is posted to a station other than at which he was posted when he went on leave,
the controlling officer may permit him to recover the travelling allowance under Clause 1 (ii) and (vi)
and II (iii) of S.R. 243, for a journey from his old to his new station.Note. A military officer, when
required to join an appointment on His Excellency the Governor's staff direct from the Military
Department on the expiry of leave exceeding 6 months will be entitled to draw travelling allowances
as on transfer from the station from which he proceeded on leave to his new station. Travelling
allowance may be drawn for the return journey in similar circumstances on reversion to the Military
Department.Audit instruction. Treatment of special disability leave on average pay for the purpose
of travelling allowance. - Special disability leave on average pay, whether it be granted by itself or in
combination with ordinary leave on average pay, should not be treated as "leave on average pay" for
the purpose of S.R. 254 but as "leave other than leave on average pay" not exceeding 6 months for
the purposes of S.Rr. 255 and 256.S.R.257. When a Government servant under the administrative
control of the Government of Assam is transferred to the control of Government which has made
rules prescribing amounts and conditions of travelling allowance, his travelling allowance for the
journey to join his post under that Government and for the return journey will be governed by the
rules of that Government regulating travelling allowance on transfer.Division XIIIJourneys to Hills
StationsS.R.258. Government servant who travels on duty to a hill station within his sphere of duty,
or is required by the order of a superior authority to travel to hill station on duty may draw
travelling allowance during his absence as for a journey on tour. Such a Government servant will,
however, forfeit all claims to travelling allowance, for journey and halt, other than permanent
travelling allowance, if the prolongs his stay at the hill station beyond a period of 10 days or the
period necessary for the performance of the duty on which the journey is made, whichever is less ;
provided that a competent authority may preserve the Government servant's claim to travelling
allowance by-(a)sanctioning a halt in excess of ten days ; and(b)officially intimating that his
presence was required on duty throughout the period or that the was permitted to extend his stay
during holidays immediately following his period of duty.Note 1. The operation of this rule is not
affected by exemption under S.R. 212.Note 2. Shillong is a hill station for the purpose of these
rules.S.R.259. When a Government servant is permitted for his own convenience to perform his
duties at hill station, he is not entitled to daily allowance or mileage allowance for the journey to or
from such station or for the period during which he halts at it. The following officers are permitted
to recess in Shillong subject to the conditions-(a)that their work will not suffer in consequence of
their absence from headquarters ;(b)that any expenditure on account of travelling allowance for
clerks, peons, etc. who may be brought up to Shillong, is defrayed by the officer themselves.
(i) Inspectors of SchoolsBetween 15th May and 16th June of each year, after
finishingtheir annual reports and with the previous sanction
of theDirector of Public Instruction.
(ii)Gazetted Officer of the
Forest DepartmentWith the previous sanction of the Conservator of Forest for
aperiod not exceeding six weeks in each year.Fundamental Rules and Subsidiary Rules

(iii)Director, Veterinary
DepartmentFor a period of one month and a half, during August
andSeptember each year. Shillong will be his headquarters
for theperiod. He will continue to do his office work at that
stationand be available for any sudden call necessitating his
presencein any other district.
(iv)Assistant Directors of
Public HealthFor a period of one month each year with the previous
sanctionof the Director of Public Health, but in the event of
theoutbreak of an epidemic they will, if required,
immediatelyproceed to the affected area.
(v) Settlement OfficersFor a period of two months each year in the rains with
theprevious sanction of the Director of Land Record.
(vi)Gazetted Officers of the
Public Works DepartmentWith the previous sanction of the Chief Engineer on
therecommendation of their Superintending Engineer for a
period orperiods not exceeding three weeks in each year.
S.R.260. A Government servant who proceeds to the hills for his own convenience must go to the
hills and back to his place of duty, wherever they may be, without expense to Government. The
competent authority in case of dispute or doubt may decide what should be considered to be the
place of duty.S.R.261. When a Government servant in the course of an ordinary tour visits, for the
purpose of Inspection or the like, a place within his ordinary jurisdiction, the fact that the place is a
hill station does not take the case out of the Travelling Allowance Rules applicable to tours or being
within the operation of S.R. 259.S.R.262. Shillong being within the jurisdiction of the Commissioner
of Divisions, the case of the establishment accompanying him to the hill station should be governed
by S.R. 256.Division XIVJourneys to attend an examinationS.R.263. A Government servant is
entitled to draw travelling allowance for the journey to and from the place at which he appears for
an examination of any the following kinds :(a)An obligatory departmental or language examination
;(b)An examination held under may rules in force in the vernacular language of a frontier or hill
tribe ;(c)In the case of Military officer in civil employ, an examination for promotion in military rank
;(d)In the case of a Civil Assistant Surgeon or Sub- Assistant Surgeon, an examination designed to
test his fitness to rise above an efficiently bar in a time-scale ;(e)In the case of Constables, Head
Constables, and officiating Assistant Sub-Inspectors an examination for promotion to the rank of
Assistant Sub-Inspector of Police :Provided that-(1)travelling allowance shall not be drawn under
this rule more than twice for any particular examination or standard of examination ; and(2)a
competent authority may disallow travelling allowance under this rule to any candidate who, in the
opinion-(i)has culpably neglected the duty of preparing himself for an obligatory examination,
or(ii)does not display a reasonable standard of proficiency in an examination which is not
obligatory.Note. Travelling allowance for journeys to attend an obligatory examination is admitted
upon a certificate that the Government servant has not previously drawn travelling allowance twice
for obligatory appearance in the same standard or for the same examination there is no
standard.Travelling allowance for an extra journey or journeys may be allowed to a Government
servant if he is temporarily exempted from passing in either Assamese or Bengali or both by the
higher standard till he is posted to a district in which that language is spoken.If an S.D.C. voluntarily
appears at an accounts examination he will be entitled to travelling allowance for two occasions.If a
ranger is permitted to appear at the departmental examination prescribed for Forest Officers he willFundamental Rules and Subsidiary Rules

be entitled to actual travelling expenses only.N.B. - "Examination" in the expression "the same
examination" does not mean an examination in one of several subjects in which an officer is
required to appear at a given examination.S.R.264. A Government servant who obtains a reward for
a success in an oriental language, or who for the first time obtains a degree of honour in any
language in the second division, is entitled to draw mileage allowance for the journey to and from
the place of examination.S.R.265. A competent authority may permit a Government servant to draw
travelling allowance for the journey to and from the place at which he appears for any examination
other than those specified in S.Rr. 263 and 264.Note. Travelling allowance is admissible to
permanent compounders sent for the compounder's examination at Dibrugarh.S.R.266. Travelling
allowance under S.Rr. 263 and 265 should be calculated as for a journey on tour, but no allowance
may be drawn for halts on the journey.Exception. - Probationary Assistant and Deputy
Superintendent of Police while under training at the Sardah Police Training College will draw daily
allowance at Bengal rates for halts at Calcutta in connection with examinations which they have to
take there during their course of training at the college.Division XVJourney when proceeding on or
returning from leaveS.R.267. Except as otherwise provided in these rules a Government servant is
not entitled to any travelling allowance for a journey made during leave or while proceeding on or
returning from leave.S.R.268. A competent authority may, for special reasons which should be
recorded, permit any Government servant to draw, for a journey of the kind specified in S.R. 267,
travelling allowance as for a journey on tour.Head constables and constables of both the armed and
unarmed branches of the Civil Police Force, Head Warders and Warders of the Jail Department, and
Head Keepers and Keepers of the Mental Hospital may be granted free return passages of the class
admissible under S.R. 153 for journey on tour, by rail or steamer or by road motor on the Dimapur
Kohima Gauhati-Shillong road, and also Shillong-Dawki road while proceeding on leave to their
homes irrespective of the nature and period of the leave, on the following conditions :(i)in the case
of leave on full pay the concession shall not be granted more than once after every thirty-three
months spent on duty, each period counting from the date which the officer last enjoyed the
privilege, i.e. from the actual date of officer's resumption of duty ;Note. A certificate should be
attached to the travelling allowance bills by the controlling officer concerned that a free passage has
not been granted during the preceding thirty-three months in the case of leave on full pay;(ii)the
concession shall not be given more than eight times in an officer's service; and(iii)the concession
cannot be claimed as a matter of right and will be dependent on the good work and conduct of the
officer during the previous thirty-three months ;(iv)the restriction that free passages shall not be
granted more than once after every thirty-three months spent on duty shall not apply when leave is
taken on medical certificate:Provided-(a)the Civil Surgeon or Assistant Surgeon at District
headquarters or the Assistant Surgeon at Sub-divisional headquarters has after personal
examination, recommended leave for one month or upwards;(b)the free passage shall be granted to
an officer who goes on ordinary leave and afterwards obtains a medical certificate ;(c)an officer
returning from sick leave for which he has obtained free passages shall not again receive the
concession (except in cases of sickness) until a period of thirty-three months has elapsed from the
date of his return to duty ;(d)the grant of leave on medical certificate shall not entitle any officer to
exceed the maximum prescribed in sub- Clause (ii) ; and(e)head constables and constables of both
the armed and unarmed branches of the Civil Police Force who are recruited from outside the State
may be allowed free passages whom it invalidated from service on medical grounds.S.R.269. (a)
When a Government servant is compulorily recalled to duty before the expiry of his leave, he isFundamental Rules and Subsidiary Rules

entitled to travelling allowance as follows :(i)If the leave for which he is recalled is in India and the
leave thereby curtailed be not less than one month, he is entitled to draw mileage allowance for the
journey from the place at which the order of recall reaches him.(ii)If the leave from which he is a
recalled is out of India and if the Government servant recalled has not completed by the date of
leaving for India, either half the period of his leave or three months, whichever period is shorter, he
is entitled to travelling allowance from the part or at which he lands in India to the station to which
he is recalled.If the period by which the leave is curtailed is less than the minimum period referred
to in Clauses (i) and (ii), above, mileage allowance may be allowed at the discretion of the authority
recalling the Government servant.(b)If the Government servant recalled to duty is entitled to
travelling allowance under S.R. 254, he may not draw mileage allowance under Cl. (a) unless he
abandons his claims to the mileage allowance specified in S.Rr. 242 and 243-1 (i) and (II)
(i).S.R.270. If a non-Gazetted Government servant, on compulsory recall from leave exceeding four
months, is posted to station other than that from which he went on leave, he may, if his pay after
transfer does not exceed Rs. 400 and if his new station is distant more than 20 Kms. from his old
station, draw in addition to his allowance admissible under S.R. 256 travelling allowance for his
family under S.R.243 for the journey from the place at which the order of recall reaches him to the
new station ; provided that the amount so drawn shall not exceed the amount admissible under S.R.
243 for the journey from the old to the new station.S.R.271. A Government servant on joining time
under F.R. 105 (d) may draw travelling allowance for the journeys as for a journey on
transfer.S.R.271A. Officers of vacation Departments stationed in places mentioned in the Schedule
to S.R. 137, are allowed travelling allowance as on tour for journeys to their homes and back during
vacation once in every three years.Division XVIJourneys on retirement, dismissal or termination of
employmentS.R.272. Unless in any case it be otherwise expressly provided in this Division, no
person is entitled to any travelling allowance for journey made after retirement or dismissal from
Government service or after the termination of such service.S.R.273. A competent authority may, for
a special reason, which should be recorded, permit any Government servant to draw travelling
allowance for a journey of the kind mentioned in S.R. 272.S.R.274. A person temporarily employed
in Government service who has received travelling allowance for the journey to join his post, may on
the termination of his employment, be allowed to draw travelling allowance for the journey to any
place ; provided that such allowance does not exceed the travelling allowance calculated for the
journey to the place at which he was engaged, that claim to draw travelling allowance is preferred
within three months of the termination of his employment and that the officer under whom he is
employed is satisfied that he intends to make the journey.S.R.275. Travelling allowance under S.Rr.
272 and 273 should be calculated as for a journey on tour, but no allowance may be drawn for halts
on the journeys.Division XVIIJourneys to give evidenceS.R.276. The following provisions apply to a
Government servant who is summoned to give evidence :(a)in a criminal case, a case before a
court-martial, a civil case to which Government is a party or a departmental inquiry held by a
properly constituted authority in India ; or(b)before a court in an Indian State or in foreign territory
:Provided that the facts as to which he is to give evidence have come to his knowledge of his public
duties :(i)he may draw travelling allowance as for a journey on tour attaching to his bill a certificate
of attendance given by the court or other authority which summons him ;(ii)when he draws
travelling allowance, he may not accept any payment of his expenses from the court or authority.
Any fees which may be deposited in the court for the travelling and subsistence allowance of the
witness must be credited to Government;(iii)if the court in which he gives evidence is situatedFundamental Rules and Subsidiary Rules

within 8 Kms. of his headquarters and no T.A. is therefor admissible for the journey, he may, if he be
not in receipt of permanent travelling allowance, accept such payment of actual travelling allowance
expenses as the court may make.Note 1. A Government servant summoned to give evidence while on
leave is entitled to the concession described in this rule.Note 2. [Deleted.]State Government's
decision. - (1) A question has arisen whether T.A. should be allowed to Government servants in the
following two types of cases and if so, at what rates :(i)when a Government servant, whether he is
under suspension or not, performs journeys to attend police/special police establishment enquiry in
connection with a case in which he is suspected to be involved :(ii)where a Government servant
undertakes journeys during suspension for appearing in a court of law, as an accused, and is later on
acquitted by the court and reinstated in service or would have been reinstated in service but for
death or his having attained the age of compulsory retirement or being allowed to retire
voluntarily.As regards case of the first types, it has been decided that travelling allowance as for a
journey on tour may be allowed to a Government servant for such journey ; provided that they are
performed under the direction of, or with the approval of the head of office in which he is for the
time being employed or was employed before suspension.(2)As regards cases of second type, it has
been decided in consultation with the Assam Public Service Commission that ho travelling
allowance as such, will be admissible for the journeys performed by a Government servant in such
circumstances but that it would be open to him to include his travelling expenses in any claim that
he might prefer under Art. 320 (3) (d) of the Constitution, for reimbursement of the costs incurred
by him in defending the legal proceedings against him. Reimbursement on this account, not
exceeding the amount admissible as travelling allowance as for journey on tour, may be allowed in
such cases in accordance with each advice as the Assam Public Service Commission may
tender.These orders take effect from the date of issue of this letter.S.R.276A. A Government servant,
whether under suspension or not, who is required to perform a journey to attend a departmental
enquiry (other than Police enquiry) may be allowed travelling allowance as for a journey on tour
from his headquarters to the place where the departmental enquiry is held or from the place at
which he has been permitted to reside during suspension to the place of enquiry, whichever is less.
No travelling allowance will, however, be admissible if the enquiry is held at the outstation at his
own request.State Government's decision. - (1) The above rule will apply also in the case of an oral
enquiry under departmental proceedings when a Government servant is required to proceed from
one station to another to appear before the officer conducting the enquiry.(2)A question has arisen
whether and if so, at what rates, travelling allowance should be allowed to Government servants who
undertake journeys to out-stations to peruse official records for the preparation of their defence in
connection with the disciplinary proceedings instituted against them.The Governor of Assam is
pleased to decide that travelling allowance as for a journey or tour without any allowance for halts
on journeys or at the out-stations may be allowed to the Government servants, whether on duty or
on leave or under suspension, for journeys undertaken by them to the stations where official records
are made available. The travelling allowance will be allowed from the headquarters of the
Government servant or from any other places where the Government servant may be spending His
leave or where the suspended officer has permitted on his own request to reside, but not exceeding
what would be admissible had the journey been undertaken from the headquarters of the
Government servants. The grant of travelling allowance will be subject to the following further
conditions :(i)the enquiring officer certifies that the official records to be consulted are relevant and
essential for the preparation of the defence statement;(ii)the competent authority certifies that theFundamental Rules and Subsidiary Rules

original records could not be sent to the headquarters station of the Government servant or the bulk
of the documents rules out the possibility of copies being made out, and sent; and(iii)the Head of
office under whose administrative control the Government servant is, certifies that the journey was
performed with his approval.It has also been decided that, in the case of officers not under
suspension at the time of undertaking the journey, the period spent in transit to and from and the
minimum period of any of stay required at the place where official records are made available for
perusal should be treated as duty or leave, according as the officer is on duty or on leave at that time.
In case of officers under suspension, who are subsequently re-instated in service, the period will be
treated as duty, leave or otherwise in accordance with the orders passed by the competent authority
under F.R. 54.The above orders will be applicable in case of all Government servants under the rule
making control of the Governor of Assam.S.R.277. A Government servant summoned to give
evidence in circumstances other than those described in S.R. 276 is not entitled by reason of his
position as Government servant, to any payment other than those admissible by the rules of the
court. If the court pays him any sum as subsistence allowance or compensation, apart from payment
for travelling expenses he must credit that sum to the Government before drawing full pay for the
day or days of absence.S.R.278. When Government servants, other than experts of the Finger Print
Bureau of the Criminal Investigation Department are summoned to appear as witnesses in civil
cases to which Government is not a party, all sums received under Chapter VI of High Court's
General Rules and Circular Orders (Civil) on account of their travelling and other expenses shall be
paid in full to them, a certificate in the form prescribed for the purpose in Volume II of High Court's
General Rules and Circular Orders (Civil) being at the same time granted : provided that
Government servants whose pay exceeds Rs. 1000 p.m. or whose headquarters are situated more
than 8 Kms. from the Court, shall be granted only on the certificate referred to above, when they are
summoned to appear as witnesses in their official capacity in cases to which Government is a party ;
provided also that when such Government servants are summoned to appear as witnesses in private
suits, no costs on account of salary shall be realised from the party at whose instance they are
summoned.N.B. - The rule has statutory force and applies only to Government servants summoned
to give evidence in an official capacity and not to Government servants to give evidence in a private
capacity in a private suit.Division XVIIIJourneys to obtain medical adviceS.R.279. If a Government
servant is compelled to leave a station at which he is posted and travel to another station, in order to
obtain the advice of the Medical Officer to whose services he is entitled, or who may under
departmental rules be consulted on his case, he may, on production of a certificate from the Medical
Officer consulted that the journey was, in his opinion absolutely necessary, draw travelling
allowance for the journey.Note 1. Travelling allowance is not admissible for a journey undertaking to
produce a health certificate on first appointment to Government service.Note 2. The rule allows the
grant of travelling allowance only to an officer who is compelled to make a journey in order to
procure medical advice of the character which Government undertakes to provide for its servants.
The Government does not undertake to provide officers with the services of specialist e.g., dentist. If
a journey not covered by this rule is unavoidable and if the expense thereof is altogether
disproportionate to the pay of the officer concerned, the case should be referred to the Government
for orders together with a certificate signed or countersigned by the Civil Surgeon that the journey is
absolutely necessary. Except in cases of real emergency, such reference should be made before the
journey is undertaken.S.R.280 to 281. [Deleted.]S.R.282. If a Government servant, being stationed
where there is no Medical Officer of Government, is required to obtain a medical certificate from aFundamental Rules and Subsidiary Rules

Medical Officer of Government in support of an application for an original grant of leave, he may
draw travelling allowance for the journey undertaken to obtain that certificate.Note. Travelling
allowance is not admissible for journey to obtain a medical certificate in support of an application
for an extension of leave.S.R.283. If a Government servant, having obtained a medical certificate in
support of an application for an original grant of leave, is required to appear before a Medical Board
or to appear before a nominated Medical Officer of Government for further opinion as to the
necessity for the leave recommended in that certificate, he may draw travelling allowance for the
journey undertaken to obtain that opinion.Note. Travelling allowance is not admissible for journey
to obtain a second medical opinion in support of an application for an extension of leave.S.R.284.
The journeys contemplated by S.Rr. 279 and 282 should not be undertaken without the previous
permission of the controlling officer, if such permission can be obtained without risk to the
Government servant requiring medical advice.S.R.285. (a) A Government servant who is directed by
his official superior, in the interest of public service, to apply for an invalid pension, may, if he is
required to make a journey in order to appear before a Medical Board draw his actual expenses,
subject to a maximum of the amount of travelling allowance calculated for the journey. If it be
necessary for him to return to his headquarters after appearing before the Medical Board, he may
draw his actual expenses subject to the same maximum. In both cases his travelling allowance bill
must be supported by a certificate that he was directed to apply for an invalid pension in the interest
of the public service and he did not voluntarily ask to retire.(b)A competent authority may allow
actual expenses, as limited by Clause (a) of this rule to be drawn by a Government servant who
voluntarily applies for an invalid pension ; provided that the authority is satisfied that the
circumstances of the applicant are such as to justify the concession.S.R.285A. A Government servant
who has been invalidated from service by a Medical Board of the State but has been permitted by
Government, on appeal, to appear before the Bengal Medical Appeal Board will draw the actual
travelling expenses : provided he is declared fit on re-examination. No travelling allowance is
admissible to an unsuccessful appellant.S.R.286. Except as provided in S.Rr. 283, 285 and 285-A no
travelling allowance is admissible for a journey undertaken in order to appear before a Medical
Board or Committee.S.R.287. Travelling allowance under S.Rr. 279, 282, 283 and 285-A should be
calculated as for a journey on tour, but allowance may be drawn for halts on the journeys.State
Government's decision. - (1) The Government servants are generally entitled to travelling allowance
as on tour (except daily allowance) for journeys undertaken to receive medical
attendance/treatment under the existing rules and orders.Though travelling allowance for the above
purposes is admissible as for a journey on tour, it is clarified, following the Government of India,
that travelling allowance by air will not be generally admissible for such journeys irrespective of
whether or not the Government servants concerned is otherwise entitled to travel by air at his
discretion on official duty.(2)The facility of travel by air-conditioned accommodation, as admissible
under item (2) of the State Government's decision below S.R. 173, will not be generally admissible to
such Government servants while undertaking journeys for the purpose of receiving medical
attendance/treatment.Division XIXJourneys in attendance on an incapacitated Government
servantS.R.288. If a Government servant, under the advice of a Civil Surgeon, or other Medical
Officer of Government whose duty it is to attend him professionally, is required to travel to a
Presidency town or elsewhere, either when proceeding on leave or in order to obtain further medical
advice, and the Medical Officer considers that it would be unsafe for him to make the journey
unattached, the Medical Officer may either himself accompany the patient to his destination orFundamental Rules and Subsidiary Rules

arrange that some other person shall do so. In that case, the attendant, if a Government servant,
shall be deemed to have been travelling on duty and may draw travelling allowance for the outward
and return journey as for a journey on tour ; if not a Government servant, he shall be entitled to
actual expenses.Division XXJourneys on a course of trainingS.R.289. When a Government servant
or a student not already in Government service is selected to undergo a course of training, a
competent authority may decide the scale, if any, on which he shall draw-(a)travelling allowance for
the original journey to and the last journey from the place of training and for halts at such place
;(b)in the case of training at a school, college or similar institutions travelling allowance for similar
journeys on the occasion of holidays and vacations ; and(c)travelling allowance for journeys during
the course of training :Provided that the scale so fixed shall not exceed that admissible to
Government servants of similar status on a day at the place of training.Division XXII. Journeys to
attend a Darbar or a LeaveS.R.290. A Government servant on duty who is permitted to attend a
darbar or a levee elsewhere than at his headquarters may draw travelling allowance for the journey
as for a journey on tour.II. Journeys in connection with the business of local bodies and Medical
Attendance on their employeesS.R.291. An official member of a local Board who is required, to
attend a meeting of the Board elsewhere than at his headquarters may draw travelling allowance for
the journey as for a journey on tour.S.R.292. Government servants will draw travelling allowance for
journeys to conduct elections of local Boards as for journeys on tour. When a special journey has to
be made solely for the purpose of conducting a local Board election the travelling allowance will be
paid by the Board concerned. In other cases the travelling allowance will be paid from State
Funds.S.R.293. Medical Officers of Government are required to render gratuitous medical
attendance on servants of a local body whether on duty, on leave or retired on the same terms and
conditions as are to be observed in the case of Government servants.When travelling allowance is
due under these rules it will be payable by Government. In the case of retired employees of local
bodies the privilege is conferred on persons who have retired from the service of those bodies under
circumstances which, if they were in Government service, would have enabled them to get a
pension.III. Journeys of Government servants as members of the Auxiliary ForceS.R.294. A
competent authority may authorise Government servants who are members of the Auxiliary Force
and who, while undergoing training in the Force, have performed a substantial amount of civil work
in addition to the military duties prescribed by the Officer Commanding, to draw travelling
allowance according to the scale prescribed by these rules. The charges on this account will be met
from State revenues.Division XXIITravelling allowance admissible when the whole or part of the
means of conveyance is supplied without charge(i)Journeys by RailwayS.R.295. [Deleted].S.R.296.
When a Government servant is entitled to or is allowed free transit by railway otherwise than in
accommodation reserved by requisition, whether on a free pass or otherwise, the mileage allowance
which he draws for the journey must, except in cases covered by S.R. 222, be reduced by the amount
of the fare which, but for such free transit, he would have paid. This rule applies to cases in which a
free pass issued on any railway, whether worked by Government or not. The reduction made must
include the full number of fares covered by the pass, unless the Government servant certifies that he
did not use the pass in respect of any fare or fares for which no reduction is made.Note 1. The
Superintendent of Police, Sibsagar, and Inspector of Police, Jorhat Sub-division, are granted free
passes when travelling by rail on the Jorhat Railway.Note 2. When a journey is made by trolley on
fixed fares on the Jorhat Railway, three quarters railway fare plus the amount of the fixed charges
may be drawn.S.R.297. When a Government servant in receipt of permanent travelling allowanceFundamental Rules and Subsidiary Rules

uses a free pass on a railway or public steamer within his sphere of duty, he must deduct from his
permanent travelling allowance for the month the amount of the railway or steamer fares which he
would have paid if he had not travelled on a pass.S.R.298. When a Government servant is permitted
to travel by railway in a higher class on payment of a lower fare his mileage allowance must be
reduced by the amount by which the fare of the class in which he travels exceeds the fare actually
paid.S.R.299. A Government servant travelling with a free pass on an unopened line of railway is
entitled to the travelling allowance prescribed in S.R. 301 as limited by S.R. 303.(ii)Journeys by Sea
or River SteamerS.R.300. When a Government servant is allowed free transit by sea or river
steamer, otherwise than in a Government vessel, the mileage allowance which he draws for the
journey must be reduced by the amount of the fare which, but for such fare transit, he would have
paid. If he travels on a free pass, the reduction made must include the full number of fares covered
by the pass, unless the Government servant certifies that he did not use the pass in respect of any
fare for which no reduction is made.This rule does not apply to cases in which a Government servant
is allowed a free pass by a steamship company without cost to Government; unless the free pass is
issued in connection with his official status of duties or as part of a regular arrangement with
Government for the conveyance of mails, etc.Note. The term "vessel" includes a motor
boat.(iii)Other journeysS.R.301. (a) Except where otherwise expressly provided in these rules, a
Government servant who uses a means of locomotion provided free of charge and does not pay the
cost of its use or propulsion may draw one daily allowance for each day of travel, except on the day
of return to headquarters, when the journeys involve spending one or more nights away from
headquarters. He may draw, on the day of return to headquarters one daily allowance only when the
total distance travelled on that day is not below 80 Kms.In the case of journeys which do not involve
spending a night away from Headquarters, one daily allowance may be drawn by him when the total
distance travelled in a day is not below 80 Kms.State Government's decision. - In determining the
total distance travelled in Government vehicles for a day for drawal of a daily allowance under S.R.
301 (a) all journeys performed from the headquarters of Government servants in that day shall be
calculated. Those journeys only for which a Government servant is entitled to mileage allowance had
he travelled in his own car or by other means, shall be counted for the purpose of determining the
limit of 80 Kms. ; other journeys performed within a short distance from headquarters, i.e., within a
radius of 80 Kms. from headquarters shall not be calculated for the purpose of the total journeys
performed in a day.(b)If a journey by such means of locomotion is combined with a road journey by
ordinary conveyance and extends beyond 80 Kms. the Government servant so travelling may, at his
option, draw either (1) the full daily allowance admissible under S.R. 188 or (2) if the journey by
ordinary conveyance exceeds 32 Kms. the mileage allowance admissible under S.R. 182. No Extra
allowance will in either case be drawn on account of the journey by means of locomotion provided
by Government.(c)If a journey by such means of locomotion is combined with a journey by rail or
public steamer, the Government servants so travelling may draw either the full daily allowance
admissible under S.R. 188 or the allowance admissible for the journey by rail or public steamer
under S.Rr. 171-175 or 176-179 respectively. No additional allowance on account of the journey by
the means of locomotion provided by Government will be admissible.(d)In the case of Sadiya and
Balipara Frontier Tracts, no charge need be made for the supply of Government transport to
Government servants of the Senior, 1st and 2nd grades on tour but when such transport is supplied
they will draw only daily allowance admissible under the rules. For journeys on which free transport
is not supplied they will draw the ordinary travelling allowance.State Government' decision. - (1)Fundamental Rules and Subsidiary Rules

When a Government transport is placed at the disposal of an official he will be entitled to draw only
daily allowance and not mileage, even if he happens to possess a personal car and uses it in place of
the Government vehicles or because the Ratter is out of commission for the time being. In case the
Government vehicle is under repair or not available for use for bona fide reasons, mileage allowance
would be admissible for tours made by personal car subject to the sanction of the. Commissioner in
the case of Deputy Commissioners and the S.D.O's. and the Heads of Departments in other
cases.(2)It is decided that a certificate in the following form should be furnished with the travelling
allowance bills in which mileage allowance is drawn for performing journeys in the personal cars of
officers when the Government vehicle is under repair or not available for use for bonafide reasons
:"Certified that the journey has been performed by the personal car of the officer and that the
mileage allowance in lieu of daily allowance has been in this bill as the Government vehicle placed at
his disposal was under repair/not available for use for bona fide reasons and that approval of the
Commissioner/Heads of Departments has been obtained."S.R.302. When a Government servant is
provided with means of locomotion as in S.R. 301 but pays all the costs of its use or propulsion, he
may draw travelling allowance under the ordinary rule subject to the deduction of such fixed hire or
charge as the Government may fix.Note. For elephants and boats see hire rates is Appendix
29.S.R.303. The provisions of S.Rr. 301 and 302 do not apply to Government servant of the fourth
grade or to any other Government servant or class of Government servants to whom a competent
authority may declare them to be inapplicable.Division XXIIIJourneys on transfer to or reverting
from foreign serviceS.R.304. Travelling allowance of a Government servant both when proceeding
on transfer to foreign service and when reverting to duty under Government shall be borne by the
foreign employer.Division XXIVJourneys of Government servant in Military employS.R.305. Except
as provided in S.R. 306, the travelling allowance admissible to Government servants in Military
employ is governed by Military Regulations.S.R.306. When a Commissioned Indian Military Officer
of the regular forces, the military police or the militia whether on the active or the retired, list is
invited to attend a Darbar or Levee at a place other than that at which he is stationed or has his
residence, a competent authority may grant him travelling allowance for the the journey subject to
the following limits :(a)For the journey from his station or place of residence to the place at which
the Darbar or Levee is held and hence back to his starting point, single railway and steamer fares,
actually paid and actual travelling expenses for journeys by road subject to the maximum admissible
to a Government servant of the first grade.(b)For halt at the place at which the Darbar or Levee is
held a daily allowance of Rs. 3.50.Division XXVJourneys of other personsS.R.307. A Honorary
Magistrate, not being a Government servant may, when employed on Government work under the
order of a District Magistrate or Sub-divisional Officer at a distance exceeding 8 Kms. from his
headquarters, or when the bench which he attends is situated at a similar distance from his
residence, draw for journeys by railway one and half second class fare and journeys by road 12 paise
for each Km. travelled. During halts when similarly employed, he may draw daily allowance of Rs.
3.50 subject to the conditions applicable to halts of Government servants on tour.S.R.308.
Mohammadan Marriage Registrar who may be directed by Magistrate to conduct local enquiries
under Section 202 of the Code of Criminal Procedure, 1898, [Now Code of Criminal Procedure, 1973
(2 of 1974)] in connection with complaints of offences relating to marriage when the parties are
Mohammadans, may draw travelling allowance on the terms on which it is granted to Honoary
Magistrate under S.R. 307 ; save that in their case daily allowance for halts will be limited to Rs.
1.25.S.R.309. (a) When any non-officials are required to attend any meeting of a commission ofFundamental Rules and Subsidiary Rules

inquiry or of a Board, conference, committee or departmental inquiry convened under proper
authority, or are required to perform any public duty in an honorary capacity, they may be allowed
by a competent authority convening such committee, conference or commission of inquiry or by the
authority calling for honorary public service, travelling allowance and daily allowance at the rates
admissible to Government servants of the senior grade irrespective of the place of tour or halt. The
members of the Legislature are entitled to travelling allowance/daily allowance at the rates
admissible to them under the Assam Legislative Assembly Members' Salaries and Allowances Rules,
1964. The Members of Parliament shall also be entitled to the same rates of T.A. and D.A. as
admissible to them as per their own set of rules as Members of Parliament.For the cases indicated in
item 56 of Appendix 4 the same may be governed by the rates shown therein.(b)In the case of the
kind contemplated by Clause (a) of this rule, a competent authority may, in its discretion, grant to
the person concerned his actual travelling, hotel and carriage expenses instead of travelling
allowance under that clause.(c)A competent authority may delegate the power conferred upon it by
Clause (a) of this rule to the Government servant presiding over the meeting of the commission or
other body which the person concerned is required to attend.(d)Non-officials including Members of
Legislature appointed to honorary offices, may be allowed by a competent authority or by the
authority appointing them to offices, to draw conveyance allowance while performing the duties of
the said honorary offices, at rates to be determined by such authority.The grant of such allowance is
contingent upon keeping a serviceable conveyance.Note 1. Non-official members attending the
Assam Railway and Steamer Communication Advisory Board are entitled to draw travelling
allowance admissible to a Government servant of the first grade with daily allowance of Rs. 5.Note 2.
Non-Official members of the Assam Medical Examination Board may be allowed travelling
allowance as first Grade Government servants at rates admissible for journey on tour.Note 3.
[Deleted].Note 4. The travelling allowance/daily allowance or actual travelling, hotel and carriage
expenses referred to in Clauses (a) and (b) of this rule will be admissible on production of a
certificate by the non-official members to the effect that they have not drawn any such allowances
for the same journeys and halts from any other Government source.State Government's decision. -
(1) The travelling allowance bills of the non-official members appointed to Committee, Board, etc.,
set up by Government, being subject to pre-audit by the Accountant General, the non-official
members do not get payment in time which causes considerable inconvenience to them.The
question of simplification of the procedure for payment of travelling allowance to avoid such delay
in payment, has been under consideration for sometime. The Governor of Assam is now pleased to
decide that the procedure outlined below should henceforth be followed :(a)The payment of the
entire amount due, including travelling allowance for the return journey, may be made on
presentation of the bills at the Treasury after) necessary countersignature of the controlling officer
without sending the bills to the Accountant General, Assam, for pre-audit, it is, however, considered
necessary to secure an undertaking from the members concerned to the effect that any
over-payment of travelling allowance detected would be repaid by them in cash or loan in
subsequent bills or other claims they may have on Government. In case any member does not give
the undertaking there will be no alternative but to defer the payment until his travelling allowance
bill is pre-audited in the normal course. After the money is drawn and disbursed according to this
procedure the drawing and disbursing officer will have to furnish a certificate to audit within a
month of drawal showing that the return journey has been duly performed.(b)In the case of
committees, etc., convened by Government the Secretary of the Administrative DepartmentFundamental Rules and Subsidiary Rules

concerned should be declared as the drawing and disbursing officer of non-official members'
travelling allowance bills. But as the Administrative Department have no separate allocation, the
expenditure will have to be met out of the general provision controlled by the Chief Secretary who
may remain the controlling officer and all such travelling allowance bills have to be countersigned!
by him or by such other officer as may be authorised by him.(c)The bills should be drawn in the
travelling allowance bill form. The drawing and disbursing officers will be responsible for the correct
preparation of the bill and it will be the duty of the controlling officer to see that the bill is in order
and to fill up the allotment column, etc.(d)The procedure will apply in the case of all non-official
members of such Committees, Board, etc. including the Members of Legislative Assembly.(2)It has
been decided that the expenditure in respect of travelling allowance and daily allowance of the
non-official members of Boards/Committees convened by the Administrative Department should be
debited to "25 G.A., etc." and those convened by the Heads of Departments should be debited to
their respective budget head. The claims in the bill which are more than six months' old should also
be sent to the Accountant General, Assam for pre-audit.Division XXVIControlling Officers' signature
on travelling allowance billS.R.310. A list of controlling authorities as declared by Government for
travelling allowance purposes in respect of each Government servant or class of Government
servants is given in Appendix 30. Government may amend the list from time to time and may, where
they think fit, declare that any particular Government servant shall be his own controlling
officer.S.R.311. Except where expressly permitted by a competent authority a controlling officer may
not delegate to a subordinate his duty of countersignature.S.R.311A. The right of a Government
servant to travelling allowance, including daily allowance,is forfeited or deemed to have been
relinquished if the claim for it is not preferred within one year from the date on which it fell
due.Note. The provision of this rule shall not be applicable in the cases where the Government
servant prefers the claim for his T.A. including D.A. to the head of office or the controlling officer
within one year from the date on which it becomes due.S.R.312. Except as provided in S.R. 313 no
bill for travelling allowance other than permanent travelling allowance, shall be paid unless it be
signed or countersigned by the controlling officer or the Government servant who presents
it.S.R.313. Non-Gazetted Government servants may, provided that detailed and countersigned bills
are subsequently submitted to the audit officer for adjustment, present bill for travelling allowance
without the countersignature of the controlling officer.S.R.314. It is the duty of controlling officer,
before signing or countersigning a travelling allowance bill-(a)to scrutinise the necessity, frequency
and duration of journeys and halts for which travelling allowance is claimed and to disallow the
whole or any part of the travelling allowance claimed for any journey or halt if he considers that a
journey was unnecessary or unduly protracted or that halt was of excessive duration ;(b)to scrutinise
carefully the distances entered in travelling allowance bill;(c)to satisfy himself that the actual cost of
transporting servant, personal effects, etc., is claimed under these rules, the scale on which such
servants, effects, etc., were transported was reasonable, to see that receipts of the railway and
steamer companies or other carries in respect of claims for transportation of personal effects,
conveyances or horses accompany the travelling allowance bills, and to disallow any claim which, in
his opinion, does not fulfil that condition ;(d)to check any tendency to abuse the option of
exchanging daily allowance for mileage allowance ; and(e)to observe any rules which a competent
authority may make for his guidance.State Government's decisions. - (1) Following the Government
of India, it is decided that henceforward prior to countersigning Travelling Allowance Bills of
non-Gazetted staff, the particulars journeys involved may be certified by the gazetted officer underFundamental Rules and Subsidiary Rules

whose orders. the journeys were undertaken.(2)It has been decided that the following certificate in
the travelling allowance bills of non-Gazetted officers, particularly of Stenographers, Personal
Assistants (non-Gazetted and Class IV Government servants will be necessary :"Certified that the
particulars of the journeys performed by the non-gazetted officers have1, been verified and that the
Gazetted Officer under whose instructions the journeys were undertaken has certified that the
journeys had actually been performed".Prior to countersigning travelling allowance bills the
certificate shown above is to be furnished invariably as required to audit.(3)According to Rule 1 at
page 1 of the Assam Audit Manual, Second Edition (Compiled by the Comptroller, Assam) the copies
of the travelling allowance bills are necessary to be kept by the Gazetted Officers and by the office in
case of non-Gazetted Officer.The number of touring officers has greatly increased resulting in
greater number of irregularities in drawal of travelling allowance, etc. The copies of tour diaries
alone do not reveal the full particulars as how an officer had drawn travelling allowance and whether
the bill was drawn correctly, etc. From practical experience it is found that Investigating Officers get
much difficulty while making enquiry in such cases of irregular drawal of travelling allowance in the
absence of the copies of the relevant travelling allowance bills.The matter was referred to the
Accountant General, Assam who has since amended the aforesaid rule [vide C.S. No.106/1].The
duplicate copies of all the travelling allowance bills of the officers and staff should henceforward be
kept by all the officers and the offices.Finance (A.P.F.) Department (Misc. Branch)Office
MemorandumSubject: Travel concession to Government servants during regular leave.Ref: The
28th September, 1966 [No. FM. 2/65/86].In pursuance of the recommendations of the Pay
Committee, the Governor of Assam is pleased to grant to travel concession to Government servants
as indicated below :(1)The concession will be admissible to Government servants whose homes are
within the State of Assam once in a period of two calendar years for visiting their homes. It will
cover Government servants and their families as defined in Clause (5) below. The families need not
necessarily accompany the Government servants but may proceed or follow them during the same
calendar year. For purpose of deciding the number of occasions the qualifying journeys made by a
Government servant and his family will be viewed as one.(2)Government servants whose 'homes'
are within a distance of 200 Kms., from their headquarters will not be allowed the
concession.(3)Those whose 'homes' are beyond 200 Kms., from their headquarters shall themselves
meet the entire cost of fares or mileage allowance for the initial 200 Kms., on each of the outward
and return journeys. For the remaining distance (over the initial 200 Kms.), the Government will
meet 100 per cent of the actual fares or mileage allowance. In every case the journeys should be to
the 'home' and back but it need not necessarily commence from or end at the headquarters of the
Government servant either in his own case or in the case of the family. But the assistance admissible
will be the amount admissible for the actual distance travelled, limited to the amount that would
have been admissible had the journey been performed between the headquarters and the 'home' of
the officer.(Amended vide Notification No. FM. 52/74/1, dated 10-12-1974, to take effect from
1-12-1974).(4)The term 'home' referred to in the office memorandum shall be the permanent home
town or village as entered in Service Book or other appropriate official record of the officer
concerned, or such other place as declared by him, duly supported by reasons (such as, ownership of
immovable property, permanent residence of near relatives, for example, parents, brothers, etc.) as
the place where he would normally reside but for his absence from such as station for service in
Government. Persons "displaced" from territories now part of Pakistan or those who have recently
acquired an Indian domicile or those who have not so far declared their homes for any purposes inFundamental Rules and Subsidiary Rules

correspondence with Government, for example, service records, applications for house building
advances, etc., should now make a formal declaration. In every case the declaration should be made
to the authority who has been declared to be the controlling officer in respect of the officer for
purposes of T.A. claims. It should reach that authority not later than six months from the date of
issue of these orders. In the case of an officer in foreign service, the period of six months should be
reckoned from the date of his reversion to Government service, unless the concession is extended to
him during his foreign service, in which case a declaration shall be made with in six months of the
date on which it is decided to extend the concession to him. Officers appointed to Government
service in future should make such a declaration before the expiry of six months from the date of
their entry into service.The declaration will be subject in each case to the acceptance of the
controlling officer who shall satisfy himself about the correctness thereof, after calling for such
evidence as he may consider necessary. The controlling officer shall forward the declaration after the
verification to the Accounts Officer who shall keep them with the officer's history of service. An
officer who shall be his own controlling officer for purpose of T.A. should make to his next superior
administrative authority the initial or any subsequent declarations of his home town. In the case of
non-gazetted Government servants, the declaration will be kept on their service books or other
appropriate service records.A declaration of 'home' once made shall ordinarily be treated as final,
but in exceptional circumstances, Government may make a change in such declaration which shall,
however, not be made more than once during the service of a Government servant.(5)The term
'family' shall have the same meaning as given in the rule applicable to the Government servant for
the purpose of T.A. on transfer. Where the wife is also a Government servant the concession will be
admissible to the family on the scale admissible to the husband or the wife and not both.(6)The
concession is not admissible to a Government servant who has not completed one year of
continuous service on the date of journey performed by him or his family, as the case may be.(7)A
Government servant who has a family as defined for the purposes of leave travel concession, living
away from the place of work, may instead of having the concession for his family as well as for
himself once in a block of two years, avail of the concession for himself alone once every year for
visiting his home town.(8)The Government servants and their families who are unable to avail
themselves of the concession in a block of two years, may be permitted to count the next block
period from the end of first year. Thus, in the case where the Government servant and his family
could not avail themselves of the concession in the 1964-65 block, they should be eligible to count
the next block with effect from the first January, 1965. The concession due for the 1964-65 block
must, however, be availed of by them before 31st December, 1966. In case they fail to avail
themselves of the concession before that date they are entitled to concession for that block, the block
should be treated as having lapsed.(9)The concession will be admissible to the Government servant
during any kind of leave including casual leave and no minimum period of leave need be insisted
upon to qualify for the concession. In case of a Government servant serving in a vacation
Department vacation will be treated as regular leave for the purpose of this concession.(Amended
vide Notification No. FM.52/74/1, dated 10-12-1974 to be effective from 1-12-1974).(10)In the case
of the return journey falling in the succeeding calendar year, the concession should be counted
against the year in which the outward journeys commenced.(11)If the leave applied for the
Government servant is refused in writing by the authority competent to sanction the same, in the
public interest, and if, also certified by that authority that leave cannot be granted at any time
during that calendar year, the concession may be granted in respect of the family of the GovernmentFundamental Rules and Subsidiary Rules

servant during that year. In that case the concession will be deemed to have lapsed for that occasion
so far as the Government servant is concerned.(12)The concession is admissible for journeys within
the State as follows :(i)Railway journey. - The class of railway accommodation to which the
Government servant and his family will be entitled, will be the class to which he is entitled under the
normal rules at the time the journeys are undertaken. It will be permissible for the Government
servant and/or his family to travel in a class higher or lower than that to which he is entitled in the
former cases the Government's liability will be 100 per cent of the fare for the excess distance by the
class to which he is entitled and in the latter case, 100 per cent of the fare for the excess distance by
the class in which he or his family actually travelled.Government's liability for the cost railway fare
between the Government servant's headquarters and his home shall be limited to the share of the
fare by the shortest route.(ii)Journeys by the State Transport. - For the journey which is performed
by the State Transport Services the concession will be admissible on the basis of 100 per cent of the
fare for the excess distance by the class of accommodation to which the Government servant and his
family are entitled. When there are no recognised classes of accommodation, the fare of the class
actually used will be admissible.(iii)Journeys by public vehicles other than State Transport Services.
- A Government servant shall be entitled to one mileage allowance plus one additional mileage each,
for each entitled member of his family at the rate applicable to his grade up to 100 per cent of such
mileage allowance for the excess distance.(iv)For the portion of the journey which is not connected
by a recognised public transport system, Government assistance will be 100 per cent of the road
mileage as prescribed for journeys by own car and private transport under the rules at single rate
irrespective of the number of members of the family.In either of the cases mentioned in (i), (ii) and
(iii) above, the amount of Government's assistance should be calculated on the basis of actual fares
or mileage allowance at single rate, as the case may be, for the Government servant himself and each
entitled member of his family for whom full fares are payable and at half the rates of actual fare or at
half of mileage rate for children between the age 3 to 12 years for whom half fares are payable.No
incidental expenses will be payable for the journeys performed under the Leave Travel Concession
Scheme.(13)Government servant will be reimbursed 100 per cent of the rail/State transport fares of
the road mileage mentioned in the preceding para of the journeys beyond the first 200 Kms. on
presentation of claim in T.A. bill form on the usual certificates that they actually performed such
journeys.(14)A certificate in the form enclosed should be submitted by Government servants with
their T.A. bills for travel concession.(15)Government servants should inform the controlling officer
before journeys for which assistance under this Scheme will be claimed, are undertaken.(16)A
record of all assistance granted under these rules shall be suitably maintained. In the case of
Gazetted Officers, the record shall be maintained by the Accounts Officer concerned. In the case of
non-Gazetted staff, the record should be in the form of entries in the Service Book or other
appropriate service records and should indicate the date or dates on which the journey or journeys
to "Home" commenced. The authority responsible for the maintenance of service record shall ensure
that on every occasion a Government servant proceeds on leave which is entered in his service
records, the fact as to whether or not he availed of the travel assistance under these orders, is
entered on that record.(As amended vide Notification No. FM/52/74/1, dated 10-12- 1974 to be
effective from 1-12-1974).(17)In the case of A.I.S., Officers, the concession will be admissible to them
as per Appointment's O.M. No. A.B.I. 32/56/75, dated 14th December, 1957 and subsequent
amendments issued from time to time.(18)These orders will not apply to persons who are-(i)not in
the whole time employment of Government,(ii)paid from contingencies,(iii)eligible for any otherFundamental Rules and Subsidiary Rules

form of travel concession,(iv)staff borne on work-charged establishment.(19)These orders, will take
effect from 1st April, 1964.Certificate to be given by a Government servant
1. I have not submitted any other claim so far for leave travel concession in
respect of myself of my family members in respect of the block of two years
20 and 20....
2. I have already drawn T.A. for leave travel concession in respect of a
journey performed by me/my wife with children. This claim is in respect of
the journey performed with the party on the earlier occasion.
3. The journey has been performed by me/my wife with...... children to the
declared 'home-town', viz...
Signature of the Government servantThe term 'once in a period of two calendar years' should be
taken to mean once in each block of two calendar years starting from the year 1964. Thus, the
concession on the first occasion is admissible during the block of two consecutive calendar years
1964 and 1965. The concession of subsequent occasions will be admissible at any time during the
calendar years 1966 and 1967, 1968 and 1969 and so on.Finance (A.P.F.) Department (Misc.
Branch)Notification No. FM. 2/65/95-Part I, dated 19th March, 1968Office MemorandumSubject:
Travel concession to Government servants during regular leave.Ref: This Department's O.M. No.
FM. 2/65/86, dated 28/9/1966 and No. FM. 2/65/58-P. 1, dated, 14/8/1967.The undersigned is
directed to invite a reference to this Department's O.M. referred to above and to say that it has since
been decided that in addition to the certificate prescribed in the O.M. dated 28/9/1966 the following
certificate may also be furnished along with the T.A. bills for leave travel concession by Government
servants, viz."That my husband/wife is not employed in Government service. That may
husband/wife is employed in Government service and the concession has not been availed of by
him/her separately for himself/herself or for any of the family members for the concerned block of
two years".These orders will have effect from the date of issue of this Memorandum.Finance (A.P.F.)
Department (Misc. Branch)Notification No. FM. 2/65/58, Part I, dated 14th August, 1967Office
MemorandumSubject: Travel concession to Government servants during regular leave.With
reference to this Department's Office Memorandum No. FM. 2/65/86, dated 28-9-1966 on the
above subject, the following clarification in regard to the provisions of the said O.M. may be noted
:(1)In para (8) of the above O.M. it is laid down that the concession due for the Block 1964-65 must
be availed of by Government servants before 31st December, 1966. It follows that the claims for the
travel concession submitted after 31st December, 1966 by Government servants are no longer valid
in so far as the Block 1964-65 is concerned. No claim for travel concessions submitted 3st
December, 1966 in respect of the Block 1964-65 should therefor the entertained.(2)In paras (13) and
(14) of the above O.M. it has been specifically provided that Government servants submitting claims
for the travel concessions shall have to submit the certificates in support of their claims for
concessions. The certificates alone are not sufficient to establish the genuineness of a claim for
travel concession before the controlling officers. It is, therefore, decided that Government servants
submitting T.A. bills for the concession should henceforth furnish the Serial Nos. of Railways/StateFundamental Rules and Subsidiary Rules

Transport tickets, cash receipts, etc. along with their T.A. bills, for the concession. All controlling
officers must see that these Serial Nos. of Railways/S.T. tickets, cash receipts, etc. are furnished
invariably in the T.A. bills of travel concessions, before countersigning such bills.These orders will
have immediate effect.Finance (A.P.F.) Department (Misc. Branch)Notification No. F.M. 156/57/7,
dated the 11th September, 1975From : Secretary to the Government of Assam, Finance
Department.To : All Secretaries to the Government of Assam, and all the Heads of Departments, etc.
etc.Subject: Economy Measure during Emergency.Sir,The Government of Assam, after careful
consideration of the recommendations made by the Committee set up for suggesting economy
measures during emergency,is pleased to order as follows :
1. Honorarium. Honorarium should not be allowed to Government employees
above the rank of Under-Secretaries and officers of equivalent rank and
status. While sanctioning honorarium due care should be taken to justify the
specific work or performance for which the amount was considered. Under
no circumstances should more than 10 per cent of the employees in an office
be entitled to receive honorarium. Honorarium for extra work should be
decided before the work is entrusted to an officer/employee and it should not
be sanctioned as a recurring allowance.
2. Sitting Fees. The practice of drawal of sitting fees by Official Directors for
attending meetings of the Board of Directors of different companies should
be discontinued henceforth.
3. Travelling Allowance. The Departments should enforce economy on tours
by officers and others by proper planning and readjustment. Supervisory
Officers should not be furnished with a comprehensive questionnaire by the
Administrative Department/Heads of Departments for the purpose of
inspecting different officers in course of the same tour.
4. (a) Office contingencies and hospitality charges. There should be utmost
economy on expenditure on telegrams, telephone calls including trunk calls
and any other items of contingent expenditure. Utmost economy should also
be effected on the use of Pol in pool vehicles.
Similarly, with a view to effect economy non hospitality charges, it would be necessary to restrict
expenditure on State guests and ensure that official receptions are invariably organised at Circuit
Houses.(b)Repair and maintenance of vehicles. To ensure economy on expenditure on repair and
maintenance of Government vehicles, all repairing works should be carried out in Government and
semi-Government workshops, where available.Fundamental Rules and Subsidiary Rules

5. These orders shall take immediate effect.
Finance (A.P.F.) Department (Misc. Branch)Notification No. F.M. 69/74/13, dated 4th May,
1976Office MemorandumSubject: Remuneration to Government servants nominated to Boards of
management of public sector undertaking and Statutory Bodies.Reference. Government Notification
No. FM. 69/74/1, dated 13th June, 1974 and No. FM. 156/75/7, dated 11th September, 1975.In
supersession of Government Notification No. FM. 69/74/1, dated 13th June, 1974, the Governor of
Assam is pleaded to order that in respect of fee, travelling allowance, etc. of the State Government
employees appointed as Directors or Members or nominated to the Corporations and Statutory
Bodies, the decision and procedure outlined in Government of India's O.M. No. 5 (47) E- IV (B)/63,
dated 5th July, 1965 and No. 7 (1) E-II (B)/71, dated 16th April, 1971 (copies enclosed) shall apply
mutatis mutandis.These orders shall take effect immediately.Copy of O.M. No. (5) (47)-E-IV (B)/63,
dated 5th, July, 1965, addressed to all Ministers of the Government of India, etc.Subject: Fees,
travelling allowance, etc. of Government servants appointed as Directors, representatives or
nominees of Government on the various Industrial undertakings, etc.The undersigned is directed to
say that, in supersession of this Ministry's, orders noted in the margin, the President is pleased to
decide that the grant of travelling allowance, fees, etc. to the Government servants appointed in the
official capacity as Directors, representatives, or nominees of Government on the various Industrial
undertakings, institutions will henceforth be regulated in the manner laid down in the following
paragraphs.
2. Fees or other remuneration. - Fees is respect of Government servants
attending meetings or for doing other works in connection with the affairs of
Statutory organisations, Corporate bodies, industrial and commercial
undertakings (not departmentally run) will be recoverable only if these are
not wholly owned by the Central Government in which Central Government
funds are invested or which are financed partly by such funds. The cases of
semi-Government/non-Government institutions receiving grants from the
Central Government should, however, be considered on merits, in
consultation with the Associate Finance. No fees or other remuneration
should be directly accepted by Government servants unless they are
specially permitted to receive such fees under F.R. 46 and S. Rr. 111 and 112.
3. Travelling and daily allowance. - (i) Travelling and daily allowance of the
Government servants for journeys performed in connection with the affairs
of the organisations, institutions, etc, mentioned in para 2 above will be
regulated under Government rules applicable to them and should be drawn
from the source from which their pay is drawn. No part of the expenses on
travelling or halts should be accepted by them from the undertakings, direct.Fundamental Rules and Subsidiary Rules

(ii)If the journey is solely or mainly in connection with the affairs of the undertakings, etc. the whole
expenditure on the travelling and daily allowance of the Government servant, which is initially
borne by the Ministry/Department concerned, should be recovered from the undertakings, etc. In
case, however, the journeys of and halts are mainly connected with the affairs of Government, and
only partly for the work of the undertakings, etc., no part of such expenditure should be recovered
from the undertakings, etc.(iii)The authority controlling the allotment of funds for the travelling and
daily allowance of the Government servants concerned shall be the sole judge for determining
whether recovery should be made or not from the undertakings etc.
4. Mode of recovery of T.A./D.A., fees or other remuneration. - The claims in
regard to T.A./D.A. fees or other remuneration referred to in paragraphs 2 and
3 above, should be referred against the undertakings etc. by an officer not
below the rank of an Under-Secretary to the Ministry/Department hereinafter
referred to as "unauthorised officer". The claims shall be preferred by the
authorised officer against the undertakings, etc. "for and on behalf of" the
Government servants concerned, for which purpose the latter shall execute
in favour of the former a power of attorney authorising the claim and receipt
of the amount from the undertakings, etc. The amount recovered shall be
credited to the revenues of the Ministry/Department concerned by the
authorised officer, who shall also at the time of preferring claims, endorse a
copy thereof to the Audit Officer concerned to enable him to watch the actual
recovery from the undertakings, etc. and its credit to Government. Further
the travelling allowance bills preferred by Government servants attending the
meetings etc. of the organisations mentioned in para 3 above should be
supported by a certificate to the effect that no travelling expenses, fee or
other remuneration has been claimed or drawn by them from the said
organisations.
5. In so far as the persons working in the Indian Audit and Accounts
Department are concerned, these orders issue after consultation with the
Comptroller and Auditory General.
Copy of O.M. No. 7 (l)-E-II (B)/71, from the Ministry of Finance Department of Expenditure, dated
the 16th April, 1971, addressed to all Ministries/Departments of the Government of India.Subject:
Fees, travelling allowance, etc., of Government servants, appointed as Directors, representatives or
nominees of Government or private companies etc.The undersigned is directed to refer to this
Ministry's Office Memorandum No. F. 5 (47) E-IV (B)/63, dated the 5th July, 1965 on the subject
mentioned above, which lays down the manner in which the grant of Travelling Allowance, fees etc.
to the Government servants, appointed in their official capacity as Directors etc. on the various
industrial undertakings/institutions is required to be regulated. A question has now been raisedFundamental Rules and Subsidiary Rules

whether a Government servant appointed in a similar capacity in connection with the affairs of a
private company, which does not receive any financial assistance from the Central Government or in
which the Central Government funds are not invested, can receive and retain fee for attending
meetings, etc. of the Board of Directors of that company. It is hereby clarified that even in such case,
the intention is that such a Government servant shall draw only Travelling Allowance under the
rules applicable to him and from the source from which he draws his pay and he should credit to
Government whatever fees, travelling allowance or other remuneration which may be received by
him from such bodies under their rules and regulations. Such credits will be treated as the revenue
of the Department concerned.
2. In cases in which Government officers already on foreign service are
required to work in some capacity for a third party and receive fees from that
party, such fees less the amount of expenditure incurred on them by the
foreign employer by way of Travelling allowance which should be reimbursed
to the foreign employer should be credited to Government.
3. Cases already decided otherwise need not be reopened.
4. In so far as the persons working in the Indian Audit and Accounts
Department are concerned, these orders issue after consultation with the
Comptroller and Auditor General.
Notification No. FM. 46/74/15, dated 22nd July, 1975Office MemorandumSubject: Admissibility of
mileage, etc. between Gauhati and Dispur.In view of the shifting of temporary Capital from Shillong
to Dispur/Gauhati a question has arisen as to whether mileage allowance etc. will be admissible for
travels between Dispur and Gauhati by Government officials on duty. The Governor of Assam is
pleased to decide that the existing provisions will continue to be operative as usual for travels
between Gauhati and Dispur and vice-versa by Government officials on duty and no other mileage
allowance etc. will be admissible in such cases.Government of AssamFinance (A.P.F.) Department:
Misc. Branch
No. FM. 46/74/56 Dated Dispur, the 22nd March, 1980
Office MemorandumSubject:-Admissibility of mileage etc. between Dispur and any other place in
Greater Gauhati.In supersession of this Department O.M. No. FM. 46/74/21, dated 10-12-1975 and
in continuation of this Department O.M. No. FM. 23/77/5, dated 22-6-1977 (copy enclosed), the
Governor of Assam is pleased to allow usual rates of mileage/T.A. on the basis of actual distance
travelled by a Government servant when he is required to travel on duty between any two places
within Greater Gauhati and it need not necessarily be limited to 8 kms only as was contemplated in
the above mentioned O.M. dated 10-12-1975.Secretary to the Government of Assam, Finance
Department.Government of AssamFinance (A.P.F.) Department: Misc. Branch
No. FM. 21/83/6 Dated Dispur, the 2nd May, 1983Fundamental Rules and Subsidiary Rules

Office MemorandumSubject:-Drawal of D.A. for journey between Dispur/Gauhati and Barjhar
Airport.A confusion has arisen in certain quarters as to the drawal of incidental in the form of daily
allowance for travels between Dispur/Gauhati and Barjhar airport on official duty.The Governor of
Assam is pleased to clarify that incidental at the rate of ½ daily allowance may be drawn for travels
between Gauhati/ Dispur and Barjhar airport the distance of which is more than 40 Kms. (both
ways). This is, however, subject to six hours' absence from H.Q. in terms of Note 2 of Para 5 of
O.M.No. FM. 87/73/1, dated 6-12-1973.Under-Secretary to the Government of AssamDated Dispur,
the 2nd May, 1983Section VSpecial Rules Relating to Assam Rifles[Not
printed]AppendicesAppendix 1[F.R. 6 and S.R. 1 in Section II]Delegations made by the Government
of Assam under Fundamental Rules
Serial
No.No. of
Fundamental
RuleNature of power  Authority to
which the power
is delegated Extent of power
delegated
1 2 3  4  5
1. F.R. 9 (19)Power to appoint
a Government
servant toofficiate
in a vacant post (1) Any authority
which has power
to make
asubstantive
appointment to
the post Full power.
    (2) Registrar,
Co-operative
Societies To appoint
substitutes
temporarily in
place
ofInspectors on
leave.
2.F.R. 22 (a) (i)
and 30Power to
determine
whether the
appointment of
aGovernment
servant to a new
post in volves the
assumption
ofduties or
responsibilities of
greater
importance (1) Head of the
office To decide the
relative
importance in
caseswhere the
two posts are in
the same office
and are under
hiscontrol.
 (2) Head of
the
Department To decide the
relative importance
in caseswhere the
two posts belong to
different officesFundamental Rules and Subsidiary Rules

within the
samedepartment.
 (3)
Departments
of the
Government
of Assam To decide the
relative importance
in all othercases.
3. F.R. 24Power to
withhold
increments (1) Any authority
which has power
to make
asubstantive
appointment to
the post which
the Government
servantholds Full power.
    (2) Any other
authority whom
the Governor
may,by general or
special order
authorise in this
behalf do
    (3)
Superintendent
of Police In respect of
Sub-Inspector
of Police
undertheir
control whose
conduct is not
good or whose
work is
notsatisfactory.
3-A. F.R. 27Power to grant an
advance
increment for
eachfive good
service marks to
subordinate
Police Officers Inspectors
General of Police,
Assam Full power
subject to the
conditions laid
downin Rule 44,
Part III of the
Assam Police
Manual.
4. F.R.35 Power to reduce
the pay of an
officiatingGovernment
servant Any Authority
which has power
to make
anofficiating
appointment to Full power.Fundamental Rules and Subsidiary Rules

post concerned
5. F.R.40Power to fix the
pay of a
temporary post
whichwill
probably be filled
by a Government
servant Any Authority
which has power
to create
atemporary post
on the pay fixed Full power.
6. F.R.49Power to appoint
Government
servant to
holdtemporarily
or to officiate in
more than one
post Department of
the Government
of Assam With
concurrence of
the Finance
Department.
7. F.R.71Power lo require a
medical
certificate
offitness before
return from leave Authority
granting the leave Full power. In
the case of
non-GazettedGovernment
servant a
certificate of
fitness signed by
aregistered
medical
practitioner may
be accepted.
8. F.R.73Power to extend
leave of a
Government
servantwho
remains absent
after the end of
his leave Authority
granting the leave Full power ;
provided that
the
Governmentservant
on leave will on
his return be
under the
authority'sadministrative
control.
9. F.R.100(b) Power to sanction
transfer to foreign
servicein India Heads of
Departments Full power in
the case of
non-GazettedSubordinates
only, subject to
observance of
the principles
laiddown in
Appendix 19 in
case of transferFundamental Rules and Subsidiary Rules

to the service of
anIndian State.
10. F.R. 114Power to fix pay
in foreign service,
the amountof
joining time
admissible and
pay during
joining time (i) Departments
of the
Government of
Assam With the
concurrence of
Finance
Department.
 (ii) Heads of
Departments Full power on the
case of
non-GazettedSubordinates
only, subject to the
observance of the
principleslaid down
in Appendix 19 in
the case of transfers
to the serviceof an
Indian State.
Appendix 2[S.R.2]Cases in which the assent of the Finance Department may be presumed to have
been given to the exercise of powers by Departments of Government
Serial
No.No. of
Fundamental
Rule or
Subsidiary RuleNature of power  Authority empowered  Extent of
power
conveyed
1 2 3  4  5
1. F.R.10Power to dispense with a
medical certificate offitness
before appointment to
Government service in
individualcases Departments of the
Government of Assam Full power.
2.F.Rr. 14 and
14-BPower to suspend a lien or to
transfer a lien Do  Do
3. F.R.54-APower to fix the standard rent of
a buildingoccupied as residence Public Works
Department in the case
ofresidences borne on
their books and the
AdministrativeDepartment
incharge of the
residence in other cases Do
4. F.R.100Power to grant leave to a military
officersubject to the military
leave rules Departments of the
Government of Assam DoFundamental Rules and Subsidiary Rules

5. F.R. 100(a)Power to sanction transfer to
foreign service Departments of the
Government of Assam Subject to the
observance of
the
principleslaid
down in
Appendix 19.
6. F.R.125Power to decide the date of
reversion of aGovernment
servant returning after leave
from foreign service Departments of the
Government of Assam Full power
7. S.R.10Power to prescribe a
Government
servant'sheadquarters Do  Do.
8. S.R.54Power to direct that the whole or
any part ofan honorarium of fee
paid from an outside source for
work doneduring office time may
be paid to the Government
servant who didthe work Do  Do.
9. S.R.62Power to grant leave to Gazetted
Governmentservant not in
foreign service Do  Do.
10. S.R.91Power to grant leave to a
Government servant inrespect of
whom a Medical Committee has
reported that there isno
reasonable prospect that he will
ever be fit to return toduty Do  Do
11. S.R.114Power to decide in a case of
doubt whether aparticular
Government servant is serving in
a vacationDepartment Do  Do
12. S.R.119Power to accept as sufficient the
reasonsalleged by an officiating
Government servant for refusing
tooccupy the residence placed at
his disposal by the
permanentholder of the post Do  Do
13. S.R.126Power to grant leave to a
temporary Engineer ofthe Public
Works Department Public Works
Department of the
Government Do
14. S.R.146 Power to extend joining time  Departments of the  Full powerFundamental Rules and Subsidiary Rules

Government of Assam subject to the
prescribed
maximum of30
days.
15. S.R.204Power to prescribe the scale of
Governmenttents to be supplied Do.  Full power
16. S.R.306Power to grant travelling
allowance to militaryofficers
attending Darbars or levees Governor's Secretary  Do.
Appendix 3[F.R.9 (20) in Section III of Fundamental Rules and Assam Subsidiary Rules (Second
Edition), 1939]Rules Regarding Grant of Overseas Pay[Not Printed]Appendix
4[S.R.4(3)]Authorities which will exercise the power to a "Competent Authority" under the various
Subsidiary Rules
Serial No. No. of Subsidiary Rule Nature of power  Authority to which the
power is delegated Extent of power
delegated
1 2 3  4  5
1. 10Power to prescribe a
Government
servant'sheadquarters (1) Heads of Departments  Full power in the
case of those
officers onlywhom
they
appoint.Note-The
Conservator of
Forests
isauthorised either
to fix or change
the headquarters
of Gazettedofficers
of the Forest
Department
attached to a
Division.
    (2) The Hon'ble Speaker  To sanction
journeys in India
of
officerssubordinate
to him to attend
conference,
meetings
andcommittees.
    (3) Registrar,
Co-operative Societies
and theDirector of
Industries To fix or change
the headquarters
ofsubordinate
officers under himFundamental Rules and Subsidiary Rules

and to transfer
them,
includingInspectors
of Co-operative
Societies, from
one charge
toanother.
    (4) Director, Veterinary
Department Full powers in
respect of officers
whom
theyappoint.
    (5) Deputy Directors of
Agriculture Full powers in
respect of officers
whom
theyappoint.
2. 23Power to allot a
building or part of a
buildingto a specified
post Administrative
Department in charge of
theresidence with the
concurrence of the
Department to
whichintended occupant
belongs Full power
3. 24Powers to direct that an
officer on leave shallbe
considered to be in
occupation of a
residence Do  Do
4. 25(1)Power to suspend the
allotment of a residence Administrative
Department in charge of
theresidence with the
concurrence of the
Finance Department Do
5. 25(4)Power to allot residence
of which the
allotmenthas been
suspended Executive Engineer when
the residence is incharge
of the Public Works
Department (Heads of
Departments inother
cases)In consultation
with District Officer Do
6. 26 (a)Power to approve
sub-tenant Do  Do
7. 26 (e) Power to permit rent
paid by a sub-tenant Administrative
Department in charge of Full powerFundamental Rules and Subsidiary Rules

toexceed that paid by
lessor of a Government
residencetheresidence with the
concurrence of the
Finance Department
8. 28Power to permit an
officer to store
furniture,etc., in a
residence during
temporary absence Executive Engineer when
the residence is incharge
of the Public Works
Department (Heads of
Departments inother
cases) Do
9. 30Power to nominate
Public Works Officer
toestimate the present
value of residences and
power to determinethe
present value Chief Engineer when the
residence is in chargeof
the Public Works
Department. In other
cases Heads
ofDepartments in
consultation with Chief
EngineerWith
theconcurrence of the
Finance Department Do
10. 33 (a)Power to estimate
probable cost of
maintenanceand
repairs of residences Superintending Engineer
when the residence isin
charge of Public Works
Department. In other
cases the Head ofthe
Department concerned in
consultation with the
SuperintendingEngineer. Do
11. 33 (b)Power to estimate
amount to be included
forcapital expenditure
on additions and
alterations in rents
ofleased residences Superintending Engineer
when the residence isin
charge of the Pubic Works
Department. In other
cases, theHead of the
Department concerned in
consultation with
theSuperintending
EngineerWith the
concurrence of the
FinanceDepartment Full power.
12. 34 (1) (a) Power to estimate
probable cost of
maintenanceand
repairs of Government
residences Superintending Engineer
when the residence isin
charge of the Public
Works Department. In
other cases, theHead of DoFundamental Rules and Subsidiary Rules

the Department
concerned in consultation
with theSuperintending
Engineer
13. 34 (1) (b)Power to fix percentage
to be adopted
forcalculation of cost of
maintenance and
repairs to
Governmentresidences Superintending Engineer
when tire residence isin
charge of the Public
Works Department. In
other cases, theHead of
the Department
concerned in consultation
with theSuperintending
Engineer Do
14. 34 (8)Power to revise amount
or percentage
referredto in S.R. 34 Do  Do
15. 37 (1)Powers to determine
rent for certain
premisesand to
estimate capital cost When the residence is in
charge of the
PublicWorks Department,
Secretary, Public Works
Department. In
othercases, the
Administrative
Department concerned in
consultationwith the
Public Works Department Do
16. 37 (2)Power to determine
charges for electric
energy,water and
meters Do  Do
17. 37 (2)Power to fix the amount
of profit that
mayaccrue to
Government from
charges for electric
energy and
watersupplied When the residence is in
charge of the
PublicWorks Department,
Secretary, Public Works
Department. In
othercases, the
Administrative
Department concerned in
consultationwith the
Public Works
DepartmentWith the
concurrence of
theFinance Department Full powerFundamental Rules and Subsidiary Rules

18. 37 (2)Power to fix charges for
electric energy
andwater where no
meters are provided When the residence is in
charge of the
PublicWorks Department,
Secretary, Public Works
Department. In
othercases, the
Administrative
Department concerned in
consultationwith the
Public Works Department Do
19. 37 (2)Power to estimate the
capital cost mentioned
inClauses (a) (i) and (c)
(i) When the residence is in
charge of the
PublicWorks Department,
Secretary, Public Works
Department. In
othercases, the
Administrative
Department concerned in
consultationwith the
Public Works Department Do.
20. 37 (2)Power to group a
number of residences
forpurposes of
assessment of charges
for electric energy,
water andmeters Do  Do.
21. 38Remission of rent when
a portion of a
residenceis utilised as
an office Administrative
Department in charge of
theresidence with the
concurrence of the
Finance Department Do.
22. 39Remission or reduction
of rent when a
residenceis rendered
uninhabitable by
reason of extensive
repairs inprogress or
from any other cause Do  Do.
23. 41 Power to sanction the
grant or acceptance of
anhonorarium or the
acceptance of a fee Heads of Departments  Note 1.- Full
power up to a
maximum
ofRs.250 in each
case. In the case ofFundamental Rules and Subsidiary Rules

recurring
honoraria or
fees,this limit
applies to the total
of the recurring
payments madeto
an individual in a
year.
  Chief Secretary to the
Government of Assam
iscompetent to sanction
honorarium up to
Rs.1000, in
eachindividual case in
respect of the
non-Gazetted and
GazettedGovernment
servants of the
Secretariat   Note 2.- Payment
at the rate of
800English and
1,600 vernacular
words per rupee
for section
writingmay be
made to the office
of the Deputy
Commissioner,
Khasi andJaintia
Hills and the
Sub-divisional
offices at
Mangaldai
andNorth
Lakhimpur who
actually do the
registration work
of theseoffices, no
separate
remuneration
being paid for
index
preparingreturns
and carrying on
the routine work.
      Note 3.- The clerk
of the
DeputyCommissioner,
Garo Hills, who
does the work of
the
TuraSub-Registry
office, receives the
amount of the feesFundamental Rules and Subsidiary Rules

as
hisremuneration.
      Note 4.- To
sanction up to 20
per centof the
amount recovered
as a reward to any
Government
servant bywhose
special exertions a
decree has been
executed, subject
tothe control of
the Department of
Government
concerned.
    Superintendent,
Secretariat Press To grant honoraria
for overtime or
special workin
indexing, etc.,
done out of
ordinary hours.
    Inspectors of Schools  Full power to
sanction the
acceptance of
feesfor private
tuition work up to
Rs.250 in each
case, in respectof
officers serving
under him, within
one of the three
annualperiods.
    Director of Public
Instruction For amount in
excess of Rs.250 in
any suchperiod in
respect of the
above mentioned
officers and full
powerin respect of
officers serving in
institutions
directly underhisFundamental Rules and Subsidiary Rules

control.
    Duty Commissioner,
Naga Hills At the sanctioned
rates, as special
case, tothe clerks
of his office who
acts as copyist
when required to
doso outside office
hours.
    Director, Veterinary
Department Full power up to a
maximum of
Rs.100 in
eachcase.
    Examiner, Local Accounts  Full power up to a
maximum of
Rs.100 in
eachcase.
    Commissioner  A reward upto Rs.
250 in Excise and
Rs. 1,000in Opium
cases where
proceedings have
been instituted
and Rs.200 when
no proceedings
have been
instituted.
    Deputy Commissioner  In similar cases,
up to Rs. 150, 250
and
50respectively.
      Note.- Police
Officers above the
rankof Assistant
Superintendent,
Revenue Officers
above the rank
ofSub-Deputy
Collectors and
Excise Officers
above the rank
ofInspectors may
not be grantedFundamental Rules and Subsidiary Rules

such reward.
    Inspector-General of
Police Rewards up to Rs.
500 in any one
case to
policeofficers
below the rank of
Deputy
Superintendent
for good workdone
in the discharge of
their ordinary
duties, or
forreimbursing
such police
officers for the
expenses actually
andlegitimately
incurred by them
in the course of
investigationwhich
cannot be
otherwise paid to
them.
    Superintendent of Police  On conditions
similar to those
stated in thecase
of the
Inspector-General
of Police, up to Rs.
50.
    Inspector-General of
Police and
Superintendentof Police Rewards for
membership may
be granted
accordingto the
scale from time to
time fixed by
Government.
    Director of Public
Instruction A bonus at the rate
of Rs.10 per pupil
to
theSub-Inspector
or Deputy
Inspector ofFundamental Rules and Subsidiary Rules

Schools,
concerned at
theend of the two
years which in the
event of a boy
having
remainedunder
surveillance
throughout the
two years after
leaving
theReformatory
School.
    Deputy Commissioner  (1) Honoraria to
process serving
peons.
      (2) Full power to
sanction payment
ofcommission to
the Nazirs of their
offices on account
of auctionsfor the
sale of the
property of private
persons subject to
thecondition that-
      (i) there are no
public auctioneers
in thestation
concerned, and
      (ii) the
commission to be
paid does not
exceed10 per cent
of the sale
proceeds of the
property.
    Director of Public Health  Rewards not
exceeding Rs.50 in
the year to
avaccinating
agent, provided
the total rewardsFundamental Rules and Subsidiary Rules

in the year
shallnot exceed
Rs. 1,000.
    Director of Industries  Rewards to reare
and under-rearers
of Rs.10 andRs.2
respectively.
    Honoraria to Provincial
Director, Department
ofHistorical and
Antiquarian Studies Full power up to
Rs.250 in each
case within
hissanctioned
budget.
24. 53Power to sanction the
undertaking of a
workwhether with or
without an honorarium
or a fee (1) Heads of Department  Full power, subject
to any general or
specialorders
governing a
particular case or
class of cases.
 (2) Director,
Veterinary Department Where, however, permission
is given toundertake a work
on remuneration, the
amount of the honorariumor
the fee proposed must be
within the competence of
theauthority specified in
column 4 to authorise its
grant oracceptance.
 (3) Examiner, Local
Accounts 
25. 54(i) Power to grant leave
to menial servants
andto make acting
arrangements in the
absentee's place (1) Superintendents of
Normal Schools(2)Deputy
Inspectors of Schools.(3)
Head Masters,
and(4)Head Mistresses of
Government High
Schools Full power subject
to the condition
that thepower is to
be exercised only
in cases in which
the leave isgranted
without imposing
any extra cost on
Government.
  (ii) Power to grant leave
to directly
appointedInspectors of
Co-operative Societies Registrar, Co-operative
Societies Full power
   Weaving Superintendent  Do.Fundamental Rules and Subsidiary Rules

(iii) Power to grant
leave to the
WeavingDemonstrators
and to make acting
arrangements in their
place
  (iv) Power to grant
leave to the
ministerialand menial
establishments of his
own office as well as
thenon-Gazetted staff
including apprentices
and below the
farmmanagers of cattle
farms at Khanapara
and Upper-Shillong Deputy Director of
Agriculture, Live-Stock Do.
  (v) Power to grant leave
to[Class II] [Amended
vide Correction Slip No.
117 to Fundamental
Rules and Assam
Subsidiary Rules,
Memo. No. F.A.
71/48/44, dated 30th
May, 1950.]officersof
the Assam Schools
Service, and to make
acting arrangements
intheir place [Inspectors] [Added vide
Correction Slip No. 113 to
Assam Subsidiary
Rules.]and Inspectresses
of Schools Full power. The
grant of leave and
actingarrangements
should be reported
to the Director of
PublicInstruction
for formal
notification.
  (vi) (a) Power to grant
leave to members of
theSubordinate Forest
Service above the
lowest grade of
Foresters Officers in-charge of
Forest Divisionsincluding
the Deputy
Commissioner, Khasi and
jaintia Hills andthe
Superintendent, Lushai
Hills Up to three
months.Note-The
powersof District
Officers (including
the
Superintendent,
LushaiHills), in
charge of Forests,
to grant leave to
members
ofministerial
establishment of
the Forest BranchFundamental Rules and Subsidiary Rules

of their officeare
regulated by
S.R.61.
  (b) Power to grant leave
to members of
theelectrical
establishment Officers in-charge of
Forest Division  
  (vii) Power to grant
leave to
DivisionalCompulor,
Draftsman and Tracers Divisional Officers  Full power. The
grant of leave and
actingarrangements
should be reported
to the Chief
Engineer, Assam.
  (viii) [] [Added vide
Correction Slip No. 78
to Assam Subsidiary
Rules.]Power to grant
leave to
Supervisors,Overseers
and Sub-Overseers
under Civil Public
Works Disbursers Civil Public Works
Disbursers Leave and acting
arrangements up
to 3
monthssubject to
the condition that
no outsider is
appointed
withoutthe
previous approval
of the Chief
Engineer. The
grant of leaveand
acting
arrangements
should be reported
to the Chief
Engineerin each
case.
  (ix) [] [Added vide
Correction Slip No. 105
to Assam Subsidiary
Rules.]Power to grant
leave to teachers
ofGovernment Primary
Schools under the
control of the
DivisionalInspectors of
Schools excluding the
teachers of such schools
inthe Garo, Naga and Deputy Inspector of
Schools Full power.Fundamental Rules and Subsidiary Rules

Lushai Hills Districts
and the FrontierTracts
and to make acting
arrangements in the
leave vacanciesthus
caused
  (x) [] [Added vide
Correction Slip No. 120
to Fundamental Rules
and Assam Subsidiary
Rules, dated 14th June,
1950.]Power to grant
leave to Inspector
ofTaxes and to make
officiating
arrangements in their
places Commissioner of Taxes  Officiating
arrangements
should be reported
toGovernment.
  (xi) [] [Added vide
Correction Slip No. 295
to Assam Subsidiary
Rules.]Power to grant
leave and to make
actingarrangements in
their places to the
ministerial and
menialestablishments
of his own office as well
as non-Gazetted
staff,including
stipendiaries, below the
rank of Lecturers Principal, Assam
Agricultural College Full power.
  (xii) [] [Added vide
Correction Slip No. 323
to Assam Subsidiary
Rules, dated 7th March,
1949.]Power to grant
leave and to make
actingarrangements in
their places to the
ministerial and
menialestablishments
of his own office as well
as non-gazetted Principal, Assam
Veterinary College Do.Fundamental Rules and Subsidiary Rules

staffincluding
stipendiaries, below the
rank of lecturers.
  (xiii) [] [Added vide
Correction Slip No. 468
to Assam Subsidiary
Rules, dated 18th
December, 1957.]Power
to grant leave to
Overseers(Grades II
and III) under Civil
Public Works
Disbursers Civil Public Works
Disbursers Leave and acting
arrangements up
to 3
monthssubject to
the condition that
no outsider is
appointed
withoutthe
previous approval
of the Chief
Engineer. The
grant of leaveand
acting
arrangement
should be reported
to the Chief
Engineerin each
case.
26. 62 Power to grant leave to
Gazetted
Governmentservant not
in foreign service (1) Commissioner of
Divisions (i) To Sub-Deputy
Collectors in
charge oftahsil or
circles up to one
month ; provided
that they are
ableto make
arrangements for
carrying on the
absentees' work
duringthe leave
without asking for
extra officers.(ii)
To ExtraAssistant
Commissioner and
Sub-Deputy
Collectors
employed
ongeneral duty, up
to one month;
provided they can
makearrangements
for carrying on theFundamental Rules and Subsidiary Rules

absentees's work
during
leavewithout
asking for extra
officers. These
orders will not
applyto members
of Assam Civil
Service who may
be in charge
ofdistricts or
sub-divisions.
    (2) Director of
Agriculture To
Superintendents
of Agriculture up
to onemonth ;
provided that he is
able to make
arrangements
forcarrying on the
absentees' work
during leave
without asking
forextra officers.
    (3) Director of Public
Instruction To members of the
provincial grades
of theSchool
Service.
    (4) Conservator of Forests  To officers of the
Provincial Forest
service upto one
month; provided
he can make
arrangements for
carrying onthe
absentee's work
during leave
without asking for
extraofficers.
    (5) Inspector-General of
Registration All leave and
extensions of leave
toSub-Registrars
except in case ofFundamental Rules and Subsidiary Rules

Special
Sub-Registrars.
    (6) Commissioner of
Excise To Superintendent
of Excise, in cases
in whichthe period
of leave applied for
does not exceed
one
month,provided
he can make
arrangements for
carrying on the
absentees'work
during the leave
without asking for
extra officers.
    (7) [ Commissioner of
Taxes] [Added vide
Correction Slip No. 402
to Assam Subsidiary
Rules, dated 23rd
December, 1953.] To
Superintendents
of Taxes, in case in
whichthe period of
leave applied for
does not exceed
one
month,provided
he can make
arrangements for
carrying on
theabsentees's
work during the
leave without
asking for
extraofficers.
27. 61 and 62(a) Power to grant leave
to a
GazettedGovernment
servant in foreign
service Authority sanctioning the
transfer To an officer in
foreign service in
India,leave one
average pay up to
four months.
  (b) Power to grant leave
to a
GazettedGovernment
servant in foreign
service out of India if
theforeign employer Foreign employer  Full power to
grant leave on
average pay
notexceeding four
months.Fundamental Rules and Subsidiary Rules

pays to provincial
revenues leave
contributionunder
sub-Rule (b) of Rule
123 of the Fundamental
Rules.
  (c) Power to grant leave
to a
non-GazettedGovernment
servant in foreign
service (i) Foreign employer  Leave on average
pay up to four
months,provided
he can arrange for
a substitute if
required.
 (ii) Authority
sanctioning the
transfer Any other leave, also on
average pay when
thecondition mentioned
against (i) above is not
fulfilled.
28. 63Power to waive proviso
(a) in S.R. 63 Heads of Departments  Full power.
29. 89Power to refuse or
revoke, leave of absence
atany time and also the
power to refuse to grant
the full amountof leave
applied for The Authority competent
to grant leave
underSubsidiary Rules to
non-Gazetted and
Gazetted
officers,respectively Full power.
30. 91Power to grant leave to
a Government servant
inrespect of whom a
medical committee has
reported that there isno
reasonable prospect
that he will ever be fit
to return toduty (1) Head of Departments  Full power in the
case of Gazetted
officers, towhom
they can grant
leave and all
non-Gazetted
officers
underthem.
 (2) Director,
Veterinary Department
under him Full power in the case of
non-Gazettedofficers.
31. 114Powers to determine
what Government
servantsare entitled to
vacation, and the
periods admissible in
eachcase (1) Director of
Institutions Full power.
  Fundamental Rules and Subsidiary Rules

(2) The Head of an
office in the
EducationDepartmentPower to the extent
permitted under orders ofthe
Director of Public
Instruction.
 (3) Director of
Industries Full power as regards the
institution under hiscontrol.
 (4) [ Inspector-General
of Civil Hospital]
[Added vide Correction
Slip No. 159 to Assam
Subsidiary Rules.] Full power in the case of
Government servantsnot
being member of the
teaching staff of the
Berry-WhiteMedical School,
Dibrugarh.
32. 120Power to grant
maternity leave Authority competent to
grant leave
underSubsidiary Rules Full power.
33. 127 (Exception)Power to dispense with
the condition that
thegrant of leave should
involve no expense to
Government in thecase
of Government servants
who have rendered five
or moreyears'
continuous temporary
service Authority competent to
grant the leave Full power.
34. 141Power to permit the
calculation of joining
timeby a route other
than that which
travellers ordinarily use (1) Head of Department  Do
 (2) Director,
Veterinary Department Do
35. 147Power to grant a longer
period of joining
timethan is admissible
under the rules in any
case (1) Heads of Departments  For all officers
under control
except the AllIndia
Services, full
power within the
rule.
36. 167 (b)Power to decide the
shortest of two or
moreroutes (1) Heads of Departments  Full power for all
officers under
them.
 (2) Director,  Full power in respect ofFundamental Rules and Subsidiary Rules

Veterinary Department journeys betweenstations on
the Jorhat Railway and the
Furkating.Badulipara-Jorhat
branch of the Assam Bengal
Railway (Specialreasons for
the grant of the concession
should be recorded inthe bill
itself).
 (3) All Controlling
Officers 
37. 168Power to allow mileage
allowance to
becalculated by a route
other than the shortest
or cheapest (1) Heads of Departments  Full power for all
offices under
them.
 (2) Director,
Veterinary Department  
 (3) All Controlling
Officers Full power in respect of
journeys betweenstations on
the Jorhat Railway and
theFurkating-Badulipara-Jorhat
branch Railway of the
Assam-BengalRailway
(Special reasons for the
grant of the concession
shouldbe recorded on the
bill itself).
      Full power to
permit mileage
allowance to
becalculated by
road between two
places connected
by rail, when itis
used in public
interest that the
journeys should be
made byroad.[* *
*] [Deleted vide
Correction Slip
No. 404 to Assam
Subsidiary Rules.]
38. 169   Fundamental Rules and Subsidiary Rules

Power to decide the
point in a station at
whichjourneys begin or
endCommissioner of
DivisionsFull power within
their jurisdiction.
39. 176Power to declare that a
Government
servantwhose pay does
not exceed Rs. 30 is
entitled for journeys
bysteamer to lowest
class accommodation All heads of offices  Full power.
40. 178Power to decide in
cases of doubt or
hardship,the class of
steamer
accommodation to
which a Government
servantis entitled (1) Heads of
Departments(2)
Director,Veterinary
Department Full power for all
officers under
them.
[40-A.]
[Added vide
Correction
Slip No. 152
to Assam
Subsidiary
Rules and
Notification
No. F.A.
42/42/Part
11/49, dated
the 23rd
September,
1942.]198, Note 5Power to grant
travelling allowances
toeducational officers
who are required to
perform journeys
onscouting work Director of Public
Instruction Full power subject
to the condition
that thebudget
provisions should
not be exceeded.
41. 200Power to restrict the
frequency and duration
ofjourneys on tour Controlling Officers
countersigning
travellingallowances bills Full power in
respect of officers
subordinateto
them.
42. 201 Power to declare that
the pay of a
particularGovernment
servant has been so
fixed as to compensate
for alljourneys by road
within his sphere of Departments of the
Government of Assam With the
concurrence of
Finance
Department.Fundamental Rules and Subsidiary Rules

duty
43. 207(a) Power to permit by
a special order in
eachcase, the recovery
of the actual cost in
addition to mileage
orpermanent travelling
allowance or both of
transport of
horses,camels,
motor-cars, etc, or
camp equipment Heads of Departments  {|
For officers
subordinate
to them.
Camp
EquipmentVehicle
1st grade 20
maunds1 motor car, or 20
horses or 1 horse and 1
bicycle.
2nd grade
10 maunds1 horse or1 bicycle or 1
motor car.
3rd grade 5
maunds--
|-||||| All controlling Officers||
For themselves or their subordinates....1 bicycle.
|-||||||| Note 1.- The term "bicycle"includes a motor bicycle or motorcycle and side car.Note
2.
- An annual statement of sanctions given except forbicycles must be sent to the Finance
Department.|-| 44.| 207| (b) To prescribe limitations on the weight ofcamp equipment and the
number of conveyances, etc., to becarried at Government expenses|| Heads of Departments|| For
officers subordinate to them within thelimits of items 43 above.|-| 45.| 212| Power to grant
exemption from the rule limitinga halt tour to ten days|| (1) Commissioner of Divisions(2) Head
ofDepartment(3) Director, Veterinary Department(4) ChiefInspector of Factories and Electrical
Adviser to Government[(5)Chief Inspector of Boilers] [Added vide Correction Slip No. 508 lo Assam
Subsidiary Rules.]|| Full power up to a limit of 30 days.|-||||| (6) [ I.G.C.H., Assam] [Added vide
Correction Slip No. 175 to Assam Subsidiary Rules.]|| Full power up to a limit of 90 days in respectof
civilian compounders attached to Assam Rifles Hospitals only.|-||||| (7) [ Chief Secretary, Assam]
[Added vide Correction Slip No. 393 to Assam Subsidiary Rules.]|| Full power up to a limit of 30
days in respectof Gazetted and non-gazetted officers of the Assam CivilSecretariat, Shillong.|-|||||Fundamental Rules and Subsidiary Rules

(8) [] [Added vide Correction Slip No. 512 to Assam Subsidiary Rules.]Chief Secretary to the
Government of Assamor Joint Secretary to the Government of Assam in AppointmentDepartment||
Full power up to limit of 30 days in respect ofChairman, Assam Public Service Commission.|-| 46.|
214| To impose restriction on the exchange of dailyallowance for mileage allowance|| Controlling
Officers|| Full power for Government servants of the 3rdand 4th grades subordinate to them in
respect of journeys byroad.|-| 47.| 215| To impose restrictions on the exchange of dailyallowance for
mileage allowance for journeys by public or hiredconveyance|| Controlling Officers|| Full powers as
regards Government servantssubordinate to them.|-| 48.| 216| Power to impose restrictions on the
exchange ofdaily allowance for mileage allowance by non-Gazettedministerial or menial servants
travelling in a public or hiredconveyance|| (1) Heads of Departments(2) Director,Veterinary
Department(3) Chief Inspector of Factories andElectrical Adviser to Government||
Full power  
Camp Equipment Vehicles
For themselves-
35 maunds 3 horses, or 2 horses and 1 bicycle.
|-| 49.| 221 (a)| Power to permit by a special order in each casethe recovery of the actual cost of
conveying camp equipments,horses, motor cars, etc.|| Heads of Departments||
For officers subordinate to them-
1st grade 20 maunds 1 motor car, or 20 horses or 1 horse and 1 bicycle.
2ndgrade 10 maunds 1 horse or 1 bicycle or 1 motor, car.
3rd grade 5 maunds -----
|-||||| All Controlling Officers||
For themselves or their subordinates-
---- 1 bicycle
|-||||||| Note 1.- The term "bicycle"includes a motor bicycle and side car.Note 2.- Anannual
statement of sanctions given except for bicycle must beto sent to the Finance Department.|-| 50.|
221 (b)| To prescribe limitations on the weight of campequipment and the number of conveyances,
etc., to be carried atGovernment expense|| Heads of Departments|| For officers subordinate to them
within thelimits in item 89 above.|-| 51.| 236| Power to allow travelling allowance for ajourney to a
first post|| (1) [ (a) Inspector General of Police] [Added vide Correction Slip No. 190 to Assam
Subsidiary Rules.]|| Actual expenses in respect of recruits fromoutside the State enlisted for the
Police Force.|-|| (1) [ (b) Superintendents of Police] [Added vide Correction Slip No. 190 to Assam
Subsidiary Rules.]|| Actual travelling expenses in respect ofrecruits from outside the district enlisted
for the DistrictPolice Force.|-|| (2) Director of Public Instruction|| (i) In respect of a female teacher
recruitedfrom outside the State after she is confirmed in her post.(ii)All members of the staff of
Prince Mount School in superiorservice whether employed on teaching or other work, on
conditionthat the person is recruited from outside the State and that thepayment is not made until
she has been confirmed.|-||||| (3) Director of Surveys|| In case of persons recruited from outside
theState for an appointment in Survey Department requiringtechnical skill or knowledge.|-||||| (4)
Chief Engineer|| To Subordinates under his control in the PublicWorks and Posts and pilotage
Departments.|-||||| (5) Inspector General of Prisons|| For warders recruited from in or outsideFundamental Rules and Subsidiary Rules

theState on pay not exceeding Rs. 20, actual expenses for theirjourney from the place of recruitment
to the circle jail forwhich they are requisitioned.|-||||| (6) Conservator|| Subordinates appointed by
him from ForestSchools.|-||||| (7) Inspector-General of Civil Hospital|| Compounders,[Nurses]
[Added vide Correction Slip No. 310 to Assam Subsidiary Rules.]and midwives, when (i)the journey
from their usual place of residence or from theplace of training to the place where they take up
theirappointment involves a journey from one district to another, or(ii)when such journey if
performed within the same district,involves an expenditure of Rs. 20 or over.|-| 52.| 263 Proviso (2)
(i) and (ii)| Power to disallow travelling allowance (1) tothe officer who has culpably neglected the
duty of preparing foran obligatory examination, (2) or who does not displayreasonable standard of
proficiency in an examination which isnot obligatory|| Heads of Departments|| Full powers.|-| 53.|
268| Power to grant travelling allowance forjourneys when proceeding on or returning from leave||
Director of Surveys|| (1) To khalasis and other menials, such railand steamer fares as he may
consider necessary to and from thepiace of recruitment when proceeding on or returning from
leaveof any kind, including Departmental leave.(2) Suchtravelling expenses as he may consider
necessary to Surveyorsand other subordinates when proceeding on or rejoining fromleave if their
homes are situated in another Province.|-| 54.| 285 (b)| Power to allow the actual cost of a journey
toappear before a Medical Board preliminary to voluntaryretirement on invalid pension|| (1) Heads
of Departments(2) Director,Veterinary Department|| Full power.|-| 55.| 289| Power to decide the
rate of travellingallowance admissible to a Government servant deputed to undergoa course of
training (vide Appendix 28 as to rates fixed incertain cases)|| Departments of the Government of
Assam|| With the concurrence of the Finance Department.|-| 56. [] [Substituted vide Correction Slip
No. 59 to Assam Subsidiary Rules, to take effect from 1st May, 1941.]| 309| Power to grant travelling
allowance to personsnot being Government servants who are required to attend meetingor any
commission of inquiry, etc.|| (1) Director of Public Instruction|| (i) In the cases of non-official
members of theBoard for Sanskrit, Toll Examinations for the Assam, FinalMadrassa Examinations,
and for the Normal and Training SchoolExaminations.|-||||||| (ii) Non-official examiners appointed
by theCalcutta University for conducting the "practicalexaminations in science subjects for the B.A.
and B.Sc. degrees,B.B. Examinations and I.A. and I.Sc. examinations at centres inthis Province
according to the grades fixed by him. Dailyallowance will be Rs. 4 for those corresponding to Second
GradeGovernment servants and Rs. 7-8-0 for those whose statuscorrespond to the Indian
Educational Service.|-||||| (2) Commissioner of Divisions|| To the Presiding Officer and
clerks,non-officials attending polling booths in connection with theelection of members of the
Central or Legislative Assembly.|-||||| (3) President, Medical Examination Board|| Power to grant
travelling allowance toexaminers on the same conditions as in the case of theEducational
Examiners.|-||||| (4) Secretary or President of the MedicalCouncil of India|| To non-official
members of the Medical Councilof India for attending meetings of the Council and of theExecutive
Committee at the following rates :|-||||||| (a) Mileage allowance (railway fares)-1 ½first class
railway fares to and from the place at which theCouncil or Executive Committee meets any other
business istransacted.|-||||||| (b) Mileage allowance (Steamer fares) 1-3/5 ofthe fare at the lowest
rate of the class in which Governmentservant of the First Grade is entitled to
accommodation.|-||||||| In cases where the Steamer Company has tworates of fares, one inclusive
and one exclusive of diet, theword "fare" shall be held to mean fares exclusive ofdiet.|-||||||| (c)
Road mileage 6 annas (8 annas for Simla)per mile for such part of the journey as cannot be made by
railor steamer, including the journey from and to railway station orplace of embarkation andFundamental Rules and Subsidiary Rules

disembarkation to the place where theCouncil or the Executive Committee meets or any other
businessis transacted.|-||||||| (d) Daily allowance-Rs. 15 for each day ofresidence at the place where
the Council or the ExecutiveCommittee meets or any other business is transacted.|-||||||| Daily
allowance at the rate of Rs. 7-8-0 forthe day of arrival and departure from the place where
theCouncil or the Executive Committee meets or where any otherbusiness is transacted. Such
allowance will not, however, beadmissible in respect of a place from which a non-officialmember
departs on the same day on which he arrived at it.|-||||||| (To official member of the Medical
Council ofIndia for attending meetings of the Council and of the ExecutiveCommittee, travelling and
daily allowances under theSupplementary Rules framed by the President).|-||||| (5) Superintendent,
Bery-White Medical School|| In the cases of non-official members of thecommittee for selection of
candidates for admission to theBerry-White Medical School, Dibrugarh, the classification of
themembers for the purpose of travelling allowance will be made bythe Inspector General of Civil
hospital, who may allow dailyallowance not exceeding Rs. 5 per diem for halts at Diburgarhwhen a
journey over[5 miles] [Substituted vide Correction Slip No. 211 to Assam Subsidiary Rules.]is
involved in attending themeeting. No travelling allowance will be allowed to membersresident at or
within[5 miles] [Substituted vide Correction Slip No. 211 to Assam Subsidiary Rules.]of
Dibrugarh.|-||||| (6) Chief Engineer|| To non-official members of the Assam[Roads] [Substituted
vide Correction Slip No 394 to Assam Subsidiary Rules, dated the 6th May, 1953.]Communication
Board including the representative of the IndianRoad and Transport Development
Association.|-||||| (7) Deputy Commissioners|| (a) [] [Substituted vide Correction Slip No. 194 to
Assam Subsidiary Rules, to take effect from 1st September, 1943.]The Chairman of a Board, if
anon-official, shall be paid an allowance of Rs. 5 a day forattending the meetings of the Board, and
of Rs.3 a day with alimitation of Rs. 20 per mensem as honorarium for transactingother business of
the Board on days when no meeting takes place.No travelling allowance should be drawn on any day
for whichhonorarium is drawn.|-||||||| For the purposes of travelling allowance-|-||||||| (1)
Chairman of the Boards who are entitled totravelling allowance in any officer capacity will get
travellingallowance admissible to them in that capacity.|-||||||| Explanation.- This includes
members ofthe Legislature.|-||||||| (2) Chairmen who are ex-Government officerswill draw
travelling allowance of the grade to which they wereentitled while in Government service.|-||||||| (3)
Chairmen other than those mentioned in (1)and (2) above will get travelling allowance as admissible
underS.R. 309 of the Fundamental Rules and Subsidiary Rules.|-||||||| (b) [] [Substituted vide
Correction Slip No. 92 to Assam Subsidiary Rules, to take effect from 1st November, 1941]A member
of a Board, if a non-official,who is not a resident of the station where the meetings of theBoard are
held, shall be paid an allowance of Rs. 3 a day forattending the meetings or for journeys to transact
the businessof the Board and shall not be entitled to daily allowance. Thosewho are residents of the
station will get Rs. 2 a day.|-||||||| Explanation.- For the purposes of thisrule, a person residing
within a radius of 5 miles from theplace of meeting shall be deemed to be a resident of
thestation.|-||||| (8) Secretary, Provincial Transport Authority|| To non-official members of the
ProvincialTransport Authority travelling and halting allowance at thescale and on the conditions
admissible to the members of theLegislatures for all meetings of the Authority, and any
suchmembers performing any journey, other than to attend a meetingof the Authority, in
connection with the business of theauthority shall with the sanction of the Chairman be entitled
toreceive travelling and halting allowance likewise.|-||||| (9) Secretary, Regions and Regional
TransportAuthority|| To non-official members of the RegionalTransport Authority travelling andFundamental Rules and Subsidiary Rules

halting allowance at thescale and on the conditions admissible to the members of theLegislatures for
all meetings of the Authority, any such memberperforming any journey other than to attend a
meeting of theAuthority in connection with the business of the Authority shallwith the sanction of
the Chairman be entitled to receivetravelling and halting allowance likewise. (Official members
ofthe Authorities may countersign their own travelling allowancebills).|}Appendix 5[S.R.
4(4)]Heads of Departments under the Government of AssamThe following officers have been
declared to be Heads of Departments :(1)Commissioners of Divisions.(2)Director of Land Records
and Inspector-General of Registration.(3)Registrar of Co-operative Societies and Director of
Industries.(4)Conservator of Forests.(5)Director of Surveys.(6)Superintendent and Remembrancer
of Legal Affairs, Administrator-General and Official Trustee.(7)Inspector-General of
Police.(8)Director of Public Instruction.(9)Inspector-General of Civil Hospitals and
Prisons.(10)Director of Public Health.(11)District and Sessions Judges.(12)Chief Engineer, Public
Works Department.(13)Commissioner of Excise.(14)Director of Agriculture.(15)[ Member, Assam
Board of Agricultural Income-tax.] [Added vide Correction Slip No. 187 to Assam Subsidiary
Rules.]The following officers have been authorised to exercise the financial powers of a Head of
Department given in the various financial rules and manuals of the Government including the
Fundamental Rules and the Subsidiary Rules :(1)Chairman, Assam Board of Revenue.(2)Secretary,
Legislative Assembly.(3)Secretary, Legislative Council.(4)Secretary, Public Service Commission.(5)[
Labour Commissioner, Assam.] [Added vide Correction Slip No. 232 to Assam Subsidiary Rules and
Reference No. GCN 97/44, and FAA, 1/44.](6)[ Director, Assam Transport.] [Added vide Correction
Slip No. 235 to Assam Subsidiary Rules and Reference No. HMV 52/43/23, dated the 2nd August,
1944.](7)Provincial Motor Transport Controller.(8)[ Director of Information and Publicity.] [Added
vide Correction Slip No., 397 to Assam Subsidiary Rules and Reference No. EIP 23/41 and Memo
No. FE. 6854/53, dated the 30th July, 1953.](9)[ Advocate General, Assam.] [Added vide Correction
Slip No. 409 to Assam Subsidiary Rules and Reference No. JJD 177/53 and Memo No. FE 2267/54,
dated the 12th April, 1954.](10)[ The Trade Adviser and Director of Movements, Government of
Assam, Calcutta.] [Added vide Correction Slip No. 578 to Assam Subsidiary Rules and Reference No.
FE 394/62, dated the 20th February, 1962.]Appendix 6[S.R. 10]List of places declared to be
HeadquartersNote. Heads of Departments have been authorised to fix the headquarters of officers
whom they appoint.
Sl. No. Government servant Place Remarks
(1) (2) (3) (4)
1.Assistant to the Director of
Land RecordsGauhati  
2.Additional District and
Sessions Judge, Sylhet and
CacharSylhet  
3.Superintendent, Railway,
PoliceHaflong  
4.Assistant Inspectress of
SchoolsShillong  
5.Inspector of Schools, Surma
valley and Hill Division.Sylhet  Fundamental Rules and Subsidiary Rules

6.Director, Veterinary
DepartmentGauhati  
7. All Survey Parties in Assam ShillongIn the recess season.N.B.- The
headcamp of each survey party
should be declared its headquarters
inthe field seasons, it being left to
the Director of Surveys todetermine
from time to time the headquarters
of the head camps aswell as to fix
the dates for opening and closing
the field andrecess seasons.
8.Deputy Superintendent of
Police, Criminal
InvestigationDepartmentShillong  
9. Agricultural Chemist Jorhat  
10.Superintendent of Agriculture
Assam Valley LowerGauhati  
11.Superintendent of Agriculture,
Valley SurmaSylhet  
12.Superintendent of Agriculture,
Assam Valley UpperJorhat  
13. Economic Botanist Borbheta  
14.Personal Assistant and
Stenographer to the Hon'ble
Speaker ofthe Legislative
AssemblyTown of
Sylhet 
15. [] [Added vide
Correction Slip No.
73 to Assam
Subsidiary Rules.]Assistant Commissioner
(Appellate) and Secretary to
the Boardof Agricultural
Income-taxShillong  
16. [] [Added vide
Correction Slip No.
221 to Assam
Subsidiary Rules.]Stamp Checking Officer,
AssamSylhet  
17. [] [Added vide
Correction Slip No.
296 to Assam
Subsidiary Rules.]Principal, Professors,
Lecturers and other staff of the
AssamAgricultural CollegeBorbheta  
18. [] [Added vide
Correction Slip
No.346 to Assam
Subsidiary RulesCommandant of the Assam
Police BattalionDergaon  Fundamental Rules and Subsidiary Rules

and Memo No. FA
11/50, dated 3rd
March, 1950.]
Appendix 7[S.R. 15 (3)]List of stations to proceed outside jurisdiction
Serial
No.DesignationPlace or
PlacesPurpose Remarks
1. 2. 3. 4. 5.
1. Superintendents of PoliceWithin or
outside
AssamTo attend Co-operative
meetingsThe
Inspector-General
should countersign
thebill.
2. Director of Public Instruction CalcuttaFor anybona fidepurpose
connected witheducation 
3.[* * * *] [Deleted vide
Correction Slip No. 435 to
Assam Subsidiary Rules and
Reference No. FM 1/18/51
and FM (Dy.) 2026/54,
dated the 3rd June, 1955.]
4.Director, Veterinary
DepartmentDittoTo serve as a member of the
Board of Examinersfor the
annual examination of the
Belgachi Veterinary College 
5.Registrar, Cooperative
SocietiesOutside
AssamTo attend the annual
conference of
ProvincialRegistrars 
6.Any Government officer who
is a member of theMedical
Council of IndiaDittoTo attend the meetings of the
Medical Council ofIndia 
Appendix 8[F.R.46-A][S.R. 40]
of fees acceptable by Medical Officer in civil employ
[The Schedule does riot apply to work done in the ordinary course of duty, i.e., official work in
connection with Government.]
Nature
of work Rate
of
fee
1. Post mortem examination  Rs. 32
2. Medico-Legal examination  Rs. 16
   (Provided that if any specialFundamental Rules and Subsidiary Rules

examinationsinvolving
prolonged or highly specialised
investigation isneeded, a higher
fee up to Rs. 100 as a maximum
may be chargedsubject to the
Note* below item 3).
3. Evidence in a court of law  Such fees as may be fixed by the
Court.
 *(Note.A fee of Rs. 50 should be chargedif the
Chemical Examiner or his Assistants are asked to
giveevidence for a private person or public body.)
4. Medical examination of Postal Insurance  Rs. 4
5. Medical examination for commutation of pensions  Rs. 16
6.Medical opinion in arbitration case under
theWorkmens' Compensation Act [Now Employees'
Compensation Act] Rs. 32**
 **Note.This item has in view only anopinion give at
the request of an arbitration body. It has nobearing
on consultations made privately by either party to
thecase or on evidence given at the request of either
party. It isunlikely that a Medical Officer consulted
privately by eitherparty would be approached for
opinion by the arbitration body,but in the event of
this being done the fee of Rs. 32 should
beadmissible.)
7. Certificate of physical fitness-   
(a)to a candidate for Government employment
otherthan that mentioned in Cl. (c) below Rs. 16(Candidates sent by the
selecting or appointingauthority
for medical examination should
be examined free ofcharge).
(b)to a candidate for admission to
educationalinstitutions such as Government
Technical Colleges or TrainingSchools Rs. 4
(c)to a candidate for an appointment to
All-IndiaServices or to technical posts by a Medical
Board Rs. 16(One-fourth of the fee is
creditable to Government).
8.Service as Examiners for a University or
otherexamining body Such fees as may be fixed by the
University or other
examiningbody.
 Service as Lecturers  Such fees as may be fixed by the
institution employing
theofficers.Fundamental Rules and Subsidiary Rules

9.Private bacteriological work done at
GovernmentLaboratories (including Laboratories
attached to Governmenthospitals and major
laboratories of the Bacteriological orMedical
Research Department)-  
[A. Blood Examinations (Bacteriological
orSerological)] [Added vide Correction Slip
No.86 to Assam Subsidiary Rules and Reference
No. 3895-F (a), dated the 24th July, 1941.]
1.Widal reaction (to any combination of
organisms, i.e.,Typhoid, Paratyphoid, Malta
fever, etc.)Rs.
10
2. Widal reaction (to a single organism)Rs.
5
3. Wassermann reactionRs.
32
4. Kahn TestRs.
10
5. Blood Cultures (Negative)Rs.
15
6. Blood Cultures (Positive)Rs.
25
7. Blood Grouping TestRs.
5
8.Peripheral Board Culture for
Leishman-Donovon bodiesRs.
10
9. Aldehyde or Antimony Test for Kala-azarRs.
5
10. Red-cell Sedimentation TestRs.
5
B. Blood Examinations (Microscopical)
11. Blood Count-White CellsRs.
5
12. Blood Count-Red CellsRs.
5
13.Blood Count-Red and White Cells including
Hb estimationRs.
10
14. Blood Smears for differential leucocyte countRs.
5
15.Blood Smears (for malaria, relapsing fever,
etc.)Rs.
5Fundamental Rules and Subsidiary Rules

16. Blood Smears, animal (for Tick Fever, etc.)Rs.
5
17. Ditto when this includes taking the bloodRs.
10
C. Blood Examinations (Bio-Chemicals)
18.Quantitative estimation of blood, sugar, urea,
uric acid,N.P.N. Calcium, etc. (single
estimation of each)Rs.
16
19. Blood Sugar Tolerance TestRs.
32
20.Urea Clearance Test (Combined blood and
urine urea)Rs.
25
21. Van den Bergh Test (direct)Rs.
5
22. Van Den Bergh Test (indirect, qualitative)Rs.
5
23. Van Den Bergh (indirect, quantitative)Rs.
16
D. Urine Examinations
24. Bacteriological, involving cultureRs.
10
25.Clinical qualitative (Chemical and
Microscopical)Rs.
5
26.Clinical quantitative (estimation of sugar,
albumen, urea,acetone, indican, etc.)Rs.
10
27. Urea Concentration TestRs.
16
28. Diastase TestRs.
16
29.Blood N.P.N. Urea Clearance Test and Urea
Concentration TestcombinedRs.
48
E. Faeces Examinations
30. Bacteriological, involving cultureRs.
10
31. Microscopical (for ova, cysts, etc.)Rs.
5
32. Bacteriological and Microscopical combinedRs.
15
33. For Occult blood (qualitative)Rs.
5Fundamental Rules and Subsidiary Rules

34. Fat estimationRs.
16
F. Cerebro-Spinal Fluid Examinations
35. Microscopical (Cytology, etc.)Rs.
5
36. Bacteriological involving cultureRs.
10
37.Bio-chemical examination (for globulin,
sugar, etc.qualitative)Rs.
5
38.Bio-chemical examination (for globulin,
sugar, etc.quantitative)Rs.
16
39. Lange's Gold Chloride TestRs.
32
G. Miscellaneous Bacteriological Examinations
40.Bacteriological examination of swabs or
culture for diphtheriaRs.
10
41.Bacteriological examination of swabs,
pathological fluids orculture for other
pathogenic organismRs.
10
42.Bacteriological examination of meat, milk,
etc.Rs.
15
43.Examinations of Exudates, e.g., pleural,
peritoneal, joint,etc. (microscopical)Rs.
5
44.Examination of Exudates, e.g., pleural,
peritoneal, joint,etc. (bacteriological)Rs.
10
45.Routine examination of an organism (cultural
reactions andfermentation tests only)Rs.
10
46.Routine examination of an organism
involving use ofserological tests)Rs.
20
47.Martin, Chick or Rideal-Walker Test for
disinfectantsRs.
45
48. Preparation of Autogenous Vaccine-  
 (a) By the use of ordinary mediaRs.
16
 (b) When special complicated work is
necessary involvinganimal experimentRs.
32
49.Spleen or liver cultures for Kala-azar
(including taking thespecimen)Rs.
16
H. Miscellaneous Microscopical Examinations
50. Pus SmearsFundamental Rules and Subsidiary Rules

Rs.
5
51. Scrapings from ulcers, sores, films, etc.Rs.
5
52. Skin clippings or nasal smears for LeprosyRs.
5
53. Hairs, scales, etc., for fungus infectionRs.
5
54. Preparations for Treponema pallidum-  
 (a) StainingRs.
5
 (b) Dark-ground illuminationRs.
5
 (c) Both methods combinedRs.
10
55.Sputum for Tubercle bacilli Free Sputum for
other pathologicalconditionsRs.
5
 *In addition to this a sum of Re. 1 is charged
for each C.C.(dose) of vaccine supplied. Six
doses are usually issued for onecourse.
 *N.B.- Done only in the Public Health
Laboratory,Shillong.
I. Miscellaneous Examinations
56.Inoculation of small animals for diagnosis of
Tubercle etc.Rs.
16
57. Sections of morbid tissuesRs.
16
58.Identification of snakes, helminths or other
animals orinsectsRs.
5
59.Friedman's or other animal test for
pregnancyRs.
16
60.Examination of brain for Rabies
(microscopical only)Rs.
5
61.Examination of brain for Rabies Biological
Test, involvinguse of animalsRs.
16
62. Removal of brain, if done by the LaboratoryRs.
5
63. Chemical examination of test mealRs.
16
[J. Chemical Examination] [Substituted videFundamental Rules and Subsidiary Rules

Correction Slip No. 119 to Assam Subsidiary
Rules.]
64. Food-stuffs including milk, butter and gheeRs.
5
65. Water samplesRs.
10
K. Bacteriological
66. Water samplesRs.
10
67.Water samples (Chemical Bacteriological
combined)Rs.
10
68.Private test and analysis conducted in the
Chemical Examiner'sDepartment- 
(1) (a)Qualitative test for some specified constituent for
which suchtest exist10 to
20
 (b) for each additional constituent to be tested 5
(2) (a)Quantitative determination of some specified
constituent orproperty in a qualitative test15 to
30
 (b)Each additional quantitative determination on the
same sample5 to
30
(3) Examination of poisons-  
 (a) for the first article 20
 (b) for each subsequent article 10
(4)Examination of stains for the
presence of blood- 
 (a) for the first article 15
 (b) for each subsequent article 5
(5)Examination of stains for the
presence of semen- 
 (a) for the first article 20
 (b) for each additional article 10
(6)For examination of drugs
according to B.P. - 
 (a) Qualitative tests only 20
 (b) Complete qualitative and quantitative tests 30
(7) (a)For the determination of saponification value, the
acid value,the iodine value, the refractive index or
the density of oil orfat10
 (b) for each additional determination 5Fundamental Rules and Subsidiary Rules

(8)For the determination of the flash
point of an oil with Abel'sclose
test- 
 (a) Up to 200°F 15
 (b) For higher temperatures 20
(9)Examination of water for boiler or
other technical purposes20 to 40
(10)Comparative tests of ink per
sample10
(11) Soils (chemical analysis of) 40
(12) Manures (ditto) 40
(13) Organic analysis of grains, etc. 40
(14) Medicolegal cases 32
(15) Malt liquors 20
(16) Potable water 20
(17) Mineral oils lubricating, complete 30 to 40
(18) (a) Vegetable oils, complete 30
 (b) Vegetable oils with calorific value 100
(19) Paints, complete 30
(20) Dry colours and Pigments 30
(21) Mineral ores, quantitative 50
(22) Tallow and other sizing material 30
(23) (a) Coal, proximate analysis 30
 (b) Coal, calorific value 100
(24)Oil cakes, complete with castor
seeds30
(25) (a) Oil cakes, oil, albuminoid and sand 30
 (b) Oil cakes, oil for nitrogen only 30
 (c) Oil cakes, oil and albuminoids 30
(26) (a) Bonemeals (manures) 30
 (b) Bonemeals (manures) for nitrogen only  
(27) (a) Manganese ore, commercial analysis 50
 (b) Manganese only 30
(28) Lime cements chemical analysis 30
(29) Soap, complete 30
(30) Alloys per constituent 30
(31) Textiles, complete 30
(32) 30Fundamental Rules and Subsidiary Rules

Sulphate of alumina and other
chemicals
(33) Spirits and wines 20
(34) Raw sugars 20
(35) Soils (practical analysis of) 20
(36) Manures (ditto) 20
(37) Tan barkes 20
(38) Tea 20
Appendix 9[Fundamental Rule 51 in Section III of Fundamental Rules and Assam Subsidiary Rules
(Second Edition) 1939]Travelling, etc., Allowances of Civil Officers serving under the Secretary of
State, the Government of India, or the High Commissioner for India when on duty in Europe,
including the rear East or America[Not Printed]Appendix 10[Fundamental Rule 56, Note in Section
II]The Assam Public Service Commission Regulations[Not Printed]Appendix 11[F.R.58]Leave
Rules, 1934
Part I – 1. These rules may be called the Leave Rules, 1934. They
shall come into force with effect from 1st March, 1934.
2. Subject to the exception hereinafter contained, these rules shall apply to
the following classes of persons employed in a service whose domicile is
Asiatic or who,if their domicile is non-Asiatic, have not been specially
recruited overseas for service in India and who are under the rule-making
control of the Government of Assam :
(i)all persons who enter or have entered or are or have been re-employed in Government service,
whether in a permanent or other capacity, on or after 1st March, 1934 ;(ii)persons who were in
service whether in a permanent or other capacity on 1st March, 1934, if there is break in their service
after that date ;(iii)persons who were in service whether in a permanent or other capacity on 1st
March, 1934, and who elect within six months from the said date to come under these rules. Such
election, when once made, shall be final;(iv)persons in Class IV service who were subject to the leave
rules in the Fundamental Rules on the 30th September, 1956 and elected, these rules will apply with
effect from the 1st October, 1956.Exception. - Persons in respect of whom special provisions
regarding leave have been made shall be governed by such special provisions.Note. These rules
replace in respect of those persons to whom they are made applicable by Rule 2, the corresponding
leave rules in the Fundamental and Subsidiary Rules. The other rules in the Fundamental and
Subsidiary Rules will remain operative in the case of those persons, except in so far as they may be
inconsistent with or repugnant in subject or context to these Leave Rules. To meet the difficulties
that may arise in certain cases in the application of Fundamental and Subsidiary Rules to persons
governed by these rules, leave on average pay not exceeding four months shall be taken to mean
earned leave not exceeding 120 days.Fundamental Rules and Subsidiary Rules

3. In these Rules-
(i)"Leave" includes earned leave, half pay leave on private affairs and medical certificate, commuted
leave, leave not due and extraordinary leave ;(ii)"Earned leave" means leave earned as per
provisions of Rule 9 of these rules;(iii)"half pay leave" means leave earned in respect of completed
years of service;(iv)"earned leave due" means the amount of earned leave to the credit of an officer
on 30th September, 1956, under the rules in force on that date plus the amount of earned leave,
calculated as prescribed in Rr. 9, 10 and 12, as the case may be, diminished by the amount of the
earned leave taken after the 30th September, 1956.Note. In the case of an officer mentioned in
Clause (iv) of Rule 2, the leave on average pay to his credit on the 30th September, 1956 shall,
subject to the appropriate limits specified in Rule 9, be deemed to be earned leave to his credit on
that date;(v)"half pay leave due" means the amount of half pay leave calculated as prescribed in Rule
13, for the entire service, diminished by the amount of leave on private affairs, and leave on medical
certificate taken before the 1st October, 1956 and half pay leave taken on or after that date.Note. In
the case of an officer mentioned in Clause (iv) of Rule 2, above on half average pay and leave on
quarter average pay availed of before the 1st October, 1956, shall be deemed to be leave on private
affairs, and leave on medical certificate for the purposes of this clause ;(vi)"commuted leave" means
leave taken under sub-Rule (c) of Rule 13 ;(vii)"officer in permanent employ" means an officer who
holds substantively a permanent post or who holds a lien on a permanent post or who would hold a
lien on a permanent post had the lien not been suspended ;(viii)"completed years of service" and
"one year's continuous service" mean continuous service of the specified duration under the State
Government and includes periods spent on duty as well as on leave including extraordinary leave.
4. Leave cannot be claimed as of right. Discretion is reserved to the authority
empowered to grant leave to refuse or revoke leave at any time according to
the exigencies of the public service.
5. Unless the Governor shall otherwise determine, after the years' continuous
absence from duty-elsewhere than in Foreign service in India, whether with
or without leave, a Government servant shall be removed from service after
following the procedure laid down in the Assam Services (Discipline and
Appeal) Rules, 1964 (This takes effect from 26-6-1968).
6. Any kind of leave under these rules may be granted in combination with or
in continuation of any other kind of leave.
Note. - The authority which granted leave to a Government servant can commute it retrospectively
into leave of a different kind which may be admissible but the Government servant concerned
cannot claim it as a matter of right.Fundamental Rules and Subsidiary Rules

7. No leave shall be granted beyond the date on which an officer must
compulsorily retire:
Provided that if in sufficient time before the date of compulsory retirement an officer has been
denied in whole or in part, on account of exigencies of public service, any leave applied for and due
as preparatory to retirement, then he may be granted, after the date of compulsory retirement, the
amount of earned leave which was due to him on the said date of compulsory retirement subject to
the maximum limit of 120 or 180 days, as prescribed in Rule 9, so long as the leave so granted,
including the leave granted to him between the date from which the leave preparatory to retirement
was to commence and the date of compulsory retirement, does not exceed the amount of leave
preparatory to retirement actually denied, the half pay leave, if any, applied for by an officer
preparatory to retirement and denied on the exigencies of public service being exchanged with
earned leave to the extent such leave was earned between the date from which the leave preparatory
to retirement was commenced and the date of compulsory retirement:Provided further that they
Government servant-(a)who, after having been under suspension is re-instated within 120 days or
180 days, as the case may be, preceding the date of his compulsory retirement and was prevented by
reason of having been under suspension from applying for leave preparatory to retirement, shall be
allowed to avail of such leave as he was prevented from applying for, subject to a maximum of 120
days or 180 days, as the case may be, reduced by the period between the date of re-instatement and
the date of compulsory retirement ;(b)who retired from service on attaining the age of compulsory
retirement while under suspension and was prevented from applying for leave preparatory to
retirement on account of having been under suspension, shall be allowed to avail of the leave to his
credit subject to a maximum of 120 days or 180 days, as the case may be, after termination of
proceedings, as prescribed in Rule 9 as if it had been refused as aforesaid, if in the opinion of the
authority competent to order re- instatement, he has been fully exonerated and suspension was
wholly unjustified.This takes effect from 30-10-1969 :Provided further that an officer whose service
has been extended in the interests of the public service beyond the date of his compulsory
retirement may similarly be granted either within the period of extension or after it expiry, any
earned leave which could have been granted to him under the preceding proviso had he retired on
that date less the leave, if any, taken during the period of extension and in addition such earned
leave due in respect of the extension as had been formally applied for as preparatory to final
cessation of his duties in sufficient time during the extension and refused to him on account of the
exigencies of the public service. In determining the amount of earned leave due in respect of the
extension with reference to Rule 9, earned leave, if any, admissible on the date of compulsory
retirement should be taken into account.Explanation. - For the purpose of this rule an officer may be
deemed to have been denied leave only if, in sufficient time before the date on which he must
compulsorily retire or the date on which his duties finally cease, he was either formally applied for
leave as leave preparatory to retirement and has been refused it on the ground of exigencies of
public service or has ascertained in writing from the sanctioning authority that such leave is applied
for would not be granted on the aforesaid ground.Government of Assam's decision No.(i) - The
benefit of the provisions of Rule 7 of the Revised Leave Rules, 1934 will not be extended to
temporary officer and officers on contract services, other than re-employed personnel in the
ordinary course.Government of Assam's decision No. (ii) - A Government servant to whom Clauses
(b) and (c) of F.R. 56 applies may be granted leave due and admissible to him which may extendFundamental Rules and Subsidiary Rules

beyond the date on which he retires or is retired from service, but not extending beyond the date of
retirement on superannuation :Provided that a Government servant, who is retired by Government
by giving him pay and allowances in lieu of notice, may apply for leave, within the period for which
such pay and allowances were given, and where he is granted leave, the leave salary shall be allowed
only for the period of leave excluding the period of which pay and allowances in lieu of notice have
been allowed.Annexure AFinance Department Establishment (A) Branch Notification No. FEG.
23/78/17/, dated 19-7-1978Office MemorandumSubject: Cash payment in lieu of unutilised earned
on the date of retirement.The Government of Assam have had under consideration for some time
the question of grant of cash equivalent for unutilised earned leave at the credit of State Government
employees. The matter has been carefully considered and the Governor of Assam is pleased to
decide that State Government servants may be paid cash equivalent of leave salary in respect of the
period of earned leave at their credit at the time of retirement on superannuation.
2. The decision contained in this Memorandum will be applicable to State
Government servant retiring on superannuation on or after 19th July, 1978.
3. This concession will be subject to the following conditions :
(a)The payment of cash equivalent of leave-salary shall be limited to a maximum of 180 days earned
leave ;(b)The cash equivalent of leave-salary thus admissible will become payable on retirement and
will be paid in one lump sum as a one time settlement;(c)Cash payment under this order will,
subject to (d) below, be equal to leave-salary as admissible for earned leave and dearness allowance
admissible on that leave-salary at the rates in force on the date of retirement. No city compensatory
allowance and/or house rent allowance shall be payable ;(d)[Deleted vide O.M., dated 4th October,
1978 enclosed];(e)The authority competent to grant leave shall issue order granting cash equivalent
of earned leave at credit on the date of retirements.
4. These orders shall apply to cases of premature/voluntary retirement.
Persons who are compulsorily' retired as a measure of punishment under the
disciplinary rules will also not be covered by these orders.
5. The benefit under these orders shall also be admissible to Government
servants who attain the age of retirement on or after 19th July, 1978 and are
granted extension of service after the date. In such cases, the benefit shall be
granted on the date of final retirement on expiry of extension to the extent of
earned leave at credit on the date of superannuation plus the earned leave
during the period of extension reduced by earned leave availed of during
such period, subject to a maximum of 180 days. The above benefits will not,
however be available to those who attained the age of retirement before 19th
July, 1978 and were on extension of service thereafter.Fundamental Rules and Subsidiary Rules

6. Consequent on issue of this Office Memorandum refusal of earned leave
as preparatory to retirement embodied in Rule 4 of the Revised Leave Rules,
1934 will no longer be necessary. A Government servant can also avail of as
leave preparatory to retirement, a part of earned leave at his credit. In that
case he will be allowed benefits of these orders for the earned leave that
remains at credit on the date of retirement in accordance with the terms and
conditions stipulated at this Office Memorandum.
Necessary amendment to the Revised Leave Rules, 1934 will follow.Joint Secretary to the
Government of AssamFinance DepartmentFinance Department Establishment (A) Branch,
Notification No. F.E.G. 23/78/26, dated 4th October, 1978Office MemorandumSubject: Cash
payment in lieu of utilised earned leave on date of retirement.The undersigned is directed to refer to
para 3 (d) of the Department's O.M. No. FEG. 23/78/17, dated 19th July, 1978 according to which
deduction on account of pension and pensionary equivalent of other retirement benefits is required
to be made from the cash amount worked out in accordance with para 3 (c) ibid. The question of
non-deduction of pension and pensionary equivalent of other retirement benefits from the cash
amount worked out under para 3 (c) of the Department's O.M., dated 19th July, 1978 has been
under consideration of the Government. After careful examination of all aspects the Governor of
Assam is pleased to order that with effect from 19th July, 1978 no deduction on account of pension
and pensionary equivalent of other retirement benefits need be made from the cash payment made
in lieu of unutilised earned leave on the date of retirement to superannuation. Para 3 (d) of the
Office Memorandum No.FEG. 23/78/17, dated 19th July, 1978 is hereby deleted with effect from
19th July, 1978.
2. Formal amendments to the Revised Leave Rules, 1934 will follow,
Joint Secretary to the Government of AssamFinance (Estt-A) Department
8. Subject to the provisions of Rule 4 and Rule 7, an officer may at any time
be granted the whole or any part of the earned leave due to him.
Auditor General's decision. - In respect of the Government servants who are governed by these
Leave Rules leave account need not be maintained in the forms prescribed in paragraph 33 of the
Instructions issued by the Auditor-General under F.R. 74 (Appendix). The leave accounts are to be
maintained in Form No. 70 (Assam Schedule II1-I) as per instructions in the ' remarks column.
9.
(1)(a)(i)A Government servant who is serving in a Department other than a Vacation Department
shall be entitled to earned leave for 30 days in a calendar year.(ii)The leave account of every
Government servant shall be credited with earned leave in advance into instalments of 15 days each
on the first January and July every year.(b)The leave at the credit of Government servant at theFundamental Rules and Subsidiary Rules

close of the previous half year shall be carried forward to the next half year, subject to the condition
that the leave so carried forward plus the credit for the half year do not exceed the maximum limit of
240 days.(c)(i)Where a Government servant not in permanent employ is appointed without
interruption of service substantively to a permanent post his leave account shall be credited with the
earned leave which would have been admissible if his previous duly has been rendered as a
Government servant in permanent employ diminished by any earned leave already taken.(ii)Where
a Government servant had availed of leave on half pay or extraordinary leave since the date of
permanent appointment such leave may, subject to the provisions of Rule 6, be converted into
earned leave to the extent it is due and admissible as a result of recasting of his leave account.(d)A
period spent in foreign service shall count as duty for purposes of this rule, if contribution towards
leave salary is paid on account of such period.Exception. - The earned leave admissible to a
Government servant of non-Asiatic domicile recruited in India who is in continuous service from a
date prior to the 1st October, 1956, and is entitled to leave passages, is one-seventh of the period
spent on duty and he ceases to earn such leave when the earned leave due amounts to 240
days.(2)Subject to the provisions of the rule, the maximum earned leave that may be granted at a
time shall be-(i)120 days, in the case of any Government servant employed in India, or(ii)150 days,
in the case of Government servant mentioned in the Exception to sub-Rule (1).(3)Earned leave may
be granted to Government servant in Class I or Class II Service or to a Government servant
mentioned in the Exception to sub-Rule (1), for a period exceeding 120 days or 150 days, as the case
may be, but not exceeding 180 days if the entire leave so granted or any portion thereof is spent
outside India, Bangladesh, Bhutan, Ceylon, Nepal and Pakistan :Provided that where earned leave
for a period exceeding 120 days, or 150 days, as the case may be, is granted under this sub-rule, the
period of such leave spent in India shall not in the aggregate exceed the aforesaid limit.Calculation
of earned leave(4)(a)Earned leave shall be credited to the leave account of a Government servant at
the rate of 2-½ days for each completed calendar month of service which he is likely to render in a
half year of the calendar year in which he is appointed.(b)The credit for the half years in which
Government servant is due to retire or resigns from the service shall be afforded only at the rate of 2
½ of days per completed calendar month up to the date of retirement or resignation.(c)When a
Government servant is removed or dismissed from service or dies while in service, credit of earned
leave shall be allowed at the rate of 2-½ days per completed calendar month up to the end of the
calendar month preceding the calendar month in which he is removed or dismissed from service or
dies while in service.(d)If a Government servant has taken extraordinary leave in a half year, the
credit to be afforded to his leave account at the commencement of the next half year shall be reduced
by 1/10th of the period of extraordinary leave availed of during the previous half year, subject to the
condition that the reduction so made is limited to the maximum period of 15 days.(5)The order
sanctioning earned leave/half pay leave to a Government servant shall indicate the balance at his
credit.
10. [Deleted].
11. [Deleted].Fundamental Rules and Subsidiary Rules

12. (a) A Government servant serving in a vacation Department shall not be
entitled to any earned leave in respect of duty performed in any year in which
he avails himself of the full vacation.
(b)In respect of any year in which a Government servant avails himself of a portion of the vacation,
he shall be entitled to earned leave in such proportion of 30 days, or 45 days when governed by the
Exception to sub-Rule. (1) of Rule 9, as the number of days of vacation not taken bears to the full
vacation :Provided that no such leave shall be admissible to a Government servant not in permanent
employ in respect of the first year of his service.(c)Whether the earned leave is taken in combination
with or in continuation of other leave or not, it shall not exceed the amount of earned leave due and
admissible to the officer at a time under Rule 9:Provided further that the total duration of vacation,
earned leave and commuted leave taken in conjunction shall riot exceed 240 days.(d)Cash
equivalent of leave salary in case of death in service. - In case a Government servant dies while in
service, the cash equivalent of the leave salary that the deceased employee would have got, had he
gone on earned leave that would have been due and admissible to him but for the death, on the date
immediately following the death, and in any case, not exceeding leave salary for 240 days, shall be
paid to his family subject to reduction on account of pension equivalent of death-cum-retirement
gratuity.Note. In addition to the cash equivalent of leave salary admissible under this rule, the
family of the deceased Government servant shall also be entitled to payment of dearness allowance
only as per orders issued in this behalf separately.This takes effect from the date of issue.Audit
Instructions. - The term "year" should be interpreted in the same way as the expression "each year
of duty" in Clause (b) of F.R. 82 and the earned leave admissible to a Government servant on a
particular date should be calculated in the manner indicated in Note 4 and item (3) of Audit
Instruction below F.R. 82 in Section II.
13. (a) (i) The half-pay leave admissible or an officer in permanent and
temporary employ in respect of each completed year of service is 20 days.
(ii)No half-pay leave may be granted to temporary Government servant unless the authority
competent to sanction leave has reason to believe that he will return to duty on expiry of
leave.(iii)For the purpose of calculating half-pay leave due, in the case of Government servant
eligible for the Departmental leave under S.R. 136 each completed year of service shall be construed
as 12 months of actual duty.(b) (i)The half-pay leave due may be granted to an officer on medical
certificate or on private affairs.(ii)Half pay leave up to maximum of 180 days shall be allowed to be
commuted during the entire service without production of medical certificate where such leave is
utilised for an approved course of study i.e., a course which is certified to be in the public interest by
the leave sanctioning authority.(c)Commuted leave not exceeding half the amount of half pay leave
may be granted to a Government servant on medical certificate only subject to the following
conditions that-(i)he has completed 1 year of service at the time he proceeds on commuted
leave;(ii)when commuted leave is granted, twice the amount of such leave shall be debited against
the half pay leave due ;(iii)no commuted leave may be granted under this rule, unless the authority
competent to sanction leave has reason to believe that the officer will return to duty on its
expiry.(d)Save in the case of leave preparatory to retirement, leave not due may be granted to anFundamental Rules and Subsidiary Rules

officer in permanent employ for a period not exceeding 360 days during his entire service, out of
which not more than 90 days at a time and 180 days in all may be otherwise than on medical
certificate. Such leave will be debited against the half pay leave the officer may earn
subsequently.State Government's decision. - A question having arisen 'whether extraordinary leave
granted to a Government servant in permanent employ either on medical certificate or otherwise
than be commuted retrospectively into leave not due', it has been decided as "leave not due" is leave
admissible under the rules, such a commutation is permissible at the discretion of the authority
competent to sanction leave in respect of extraordinary leave taken on or after 1st October, 1956.
Such a commutation is also permissible in a case where extraordinary leave was granted to a
Government servant during temporary service after 1st October, 1956 and he subsequently
confirmed with effect from a date earlier than the commencement of the extraordinary leave.Note 1.
Leave not due should be granted only if the authority empowered to sanction leave is satisfied that
there is a reasonable prospect of the officer's returning to duty on the expiry of the leave and it
should be limited to the half pay leave he is likely to earn thereafter.Note 2. When a Government
servant who has been granted leave not due under this clause applies for permission to retire
voluntarily, the leave not due shall, if the permission is granted, be cancelled.Government of India's
decision. - (1) The half pay leave earned by a Government servant in respect of a "completed year of
service" can be availed of by him during the course of a spell of leave or during an extension thereof
within which the date of anniversary of service falls.(2)The Government of India have had under
consideration the question whether 'Leave not due' as defined in Article 302 of the Civil Service
Regulations, F.R. 81 (c) and Rule 11 (d) of the Revised Leave Rules, 1933, should be granted to a
Government servant who is undergoing treatment for tuberculosis. It has been decided that the
supersession of all previous orders on the subject that 'leave not due' may be granted to permanent
and quasi-permanent Government servants suffering from tuberculosis subject to the condition that
the authority competent to sanction leave is satisfied that there is a reasonable prospect of the
Government servant (i) returning to duty on the expiry of the leave ; and (ii) earning thereafter leave
not less than the amount of 'leave not due' availed of by him. The prospect of returning to duty on
the expiry of the leave should be assessed on the basis of the certificate given by the appropriate
medical authority. The prospect of earning at least an equivalent amount of 'leave not due' should be
assessed with reference to the fact whether in the normal course the Government servant would
have enough service after his return to duty with which he would be able to wipe of the debit
balance. For example, if an officer returns to duty and in the normal course, has to serve for only
there years before reaching the age of superannuation the 'leave not due' should not exceed the
half-pay leave he can earn during this period.The appropriate medical authority will be-(i)The
Government servant's authorised medical attendant ;(ii)The Medical Officer-in-charge of a
recognised sanatorium in the case of a Government servant undergoing treatment in a recognised
sanatorium ;(iii)A tuberculosis specialist recognised as such by the State Administrative Medical
Officer concerned in the case of a Government servant receiving treatment in a recognised
sanatorium ;(iv)A qualified tuberculosis specialist or Civil Surgeon in the case of a Government
servant suffering from tuberculosis other than pulmonary tuberculosis.Auditor-General's decision. -
It has been decided with the concurrence of the Government of India that the authority empowered
to grant leave under the Revised Leave Rules, 1934, has not been given the power to alter the nature
of leave, though Rule 4 of these rules he has the power to refuse or revoke leave at any time
according to the exigencies of the public service. Under Rule 14 there is no restriction on an officerFundamental Rules and Subsidiary Rules

whose application for leave is supported by medical certificate being at his option granted leave on
medical certificate even when earned leave is due to him.
14.
(1)Extraordinary leave without allowance may be granted to any officer in special
circumstances-(a)when no other leave is by rule admissible, or .(b)when other leave is admissible,
but the official concerned applies in writing for the grant of extraordinary leave.(2)Except in the
case of an officer in permanent employ the duration of extraordinary leave on any one occasion shall
not exceed the following limits :(i)three months ;(ii)six months, in cases were the Government
servant has completed three years' continuous service on the date of expiry of leave of the kind due
and admissible under the rules [including three months extraordinary leave under (i) above] and his
request for such leave is supported by a medical certificate as required under the rules ;(iii)eighteen
months where the officer is undergoing treatment for-(1)pulmonary tuberculosis in a recognised
sanatorium, or(2)tuberculosis of any other part of the body by a qualified tuberculosis specialist or a
civil surgeon, or(3)leprosy in a recognised leprosy institution or by a civil surgeon or a specialist in
leprosy recognised as such by the Administrative Medical Officer concerned.Note 1. The concession
of extraordinary leave up to eighteen months will be admissible also to a Government servant
suffering from pulmonary tuberculosis who receives treatment at his residence under a tuberculosis
specialist recognised as such by the State Administrative Medical Officer concerned and produces a
certificate signed by that specialist to the effect that he is under his treatment and that he has
reasonable chances of recovery on the expiry of leave recommended.Note 2. The concession of
extraordinary leave up to eighteen months under this sub-rule will be admissible only to those
Government servants who have been in continuous Government service for a period exceeding one
year.(iv)Twenty-four months where the leave is required for the purposes of prosecuting studies
certified to be in the public interest, provided the Government servant concerned has completed
three years' continuous service on the date of expiry of leave of the kind due and admissible under
the rules {including three months extraordinary leave under (i) above].(3)Where a Government
servant who is not in permanent employ fails to resume duty on the expiry of the maximum period
extraordinary leave granted to him or where such a Government servant who is granted a lessor
amount of extraordinary leave than the maximum amount admissible, remains absent from duty for
any period which together with the extraordinary leave granted exceeds the limit up to which he
could have been granted such leave under sub-Rule (2), he shall, unless the Governor in view of the
exceptional circumstances of the case otherwise determine, be deemed to have resigned his
appointment.(4)[ The Government servants belonging to the Scheduled Castes/Scheduled Tribes
may, for the purposes of attending the pre-examination training centre at the centre notified by the
Government of India from time to time, be granted extraordinary leave by Heads of Departments in
relaxation of the provisions of sub-Rule (2) (1).] [This takes effect from 16-8-1978. [Reference
Notification No. FEG-75 / 78/4, dated 16-8-1978, inserted vide Correction Slip No. 232.](5)The
authority empowered to grant leave may commute retrospective periods of absence without leave
into extraordinary leave.Government of India's decision. - (1) It has been decided by the Ministry of
Finance in consultation with the Comptroller and Auditor General that the two spells of
extraordinary leave if intervened by the maternity leave should be treated as one continuous spell of
extraordinary leave for the purpose of Rule 14 (b) of the Revised Leave Rules, 1933.Two periods ofFundamental Rules and Subsidiary Rules

extraordinary leave when intervened by a spell of leave on half pay should be treated as one
continuous spell for the purpose of applying the limit of 3 months mentioned in Rule 14 (b)
above.(2)In addition to leave on average pay or earned leave, a the case may be, and/or leave on
medical certificate, which may be admissible to them, the temporary Government servants, superior
and inferior, who contract tuberculosis and undergo in a recognised sanatorium for long period may
be granted in relaxation of Supplementary Rule 286-C. Rule 6 (2) below Supplementary Rule 286-C
and sub-rule (b) of Rule 14 above extraordinary leave without allowance up to a maximum period of
eighteen months on any occasion, subject to the following conditions :(i)the post from which the
Government servant proceeds on leave is likely to last till the return to duty;(ii)the extraordinary
leave shall be granted subject to the production of a certificate from the medical officer-in-charge of
the sanatorium, specifying the period from which leave is recommended ; and(iii)the Medical
Officer in recommending leave shall bear in mind the provisions of Supplementary Rule
220.[Government of India, Finance Department Endorsement No. F.7/(50) R.45, dated the 11th
October, 1943, and Government of India, Ministry of Finance, U.O. No. 509/E/VI-54, dated 30th
September, 1954].(3)The concession of extraordinary leave up to eighteen months will be admissible
also to temporary Government servants suffering from tuberculosis of bones or joints on the
production of certificate by a qualified T.B. Specialist or a Civil Surgeon.[Government of India,
Finance Department Endorsement No. F-7/(61) Rule-1/44, dated 9th April, 1945 and Government
of India, Ministry of Finance U.O. No. 5097-E/IV-54, dated the 30th September 1954].(4)The grant
of the leave concession sanctioned in item (3) above to temporary Government servant suffering
from tuberculosis of bones or joints is subject to the conditions laid down in Clauses (i) and (ii) of
item (1) above. As such temporary Government servants are not required to undergo treatment at a
recognised sanatorium, a certificate by a qualified T.B. Specialist or a Civil Surgeon may be accepted
in lieu of that prescribed in Clause (ii) of item (i) above. A certificate prescribed in that clause will be
necessary only in where the Government servants concerned undergo treatment in a recognised
sanatorium.
15.
(1)A Government servant who proceeds on earned leave shall be entitled to leave salary equal to the
pay drawn immediately before proceeding on earned leave.(2)An officer on half pay leave or leave
not due will be entitled to leave salary equal to half the amount specified in sub-Rule (1) subject to
maximum of Rs. 750 :Provided that this limit shall not apply if the leave is on medical certificate or
for pursuing an approved course of study otherwise than on study leave terms.(3)An officer on
commuted leave will be entitled to leave- salary equal to twice the amount admissible under
sub-Rule (2).(4)An officer on extraordinary leave is not entitled to any leave-salary.Note. In respect
of any period spent on deputation on foreign service out of India, the pay which the officer would
have drawn if on duty in India shall be substituted for the pay actually drawn while calculating
average pay.Explanation I. - For the purpose of this rule, 'substantive pay' means the substantive
pay of the permanent post which the officer holds substantively or on which he holds a lien or would
hold a lien, had the lien not been suspended and includes the special pay shown as part of scale of
pay of the post:Provided further that the leave-salary of a Government servant who is in permanent
employ and who has been continuously officiating in another post for more than three years at the
time he proceeds on leave shall be calculated as if he were the substantive holder of the post inFundamental Rules and Subsidiary Rules

which he was so officiating or in which he would have so officiated but for his officiating
appointment in an equivalent or a still higher post.The three years' limit shall include-(a)all periods
of leave during which the Government servant would have officiated in the post but for proceeding
on such leave ; and(b)all periods of officiating service rendered in an equivalent or a still higher post
but for appointment to which he would have officiated in the post.Explanation II. - The leave-salary
of an officer, who is already on leave on the 1st January, 1960, shall, from the commencement of
such leave be recalculated in accordance with the provisions of the Revised Leave Rules, 1934 as
amended under C.S. No. 501 to Fundamental Rules and Subsidiary Rules.This takes effect from
14-9-1961.Government of India's decision. - (1) A Question having arisen whether the condition of
'no extra expense' was still in force in respect of the inferior Government servants subject to the
Revised Leave Rules, 1934, the Government of India have decided that since the condition of "no
extra expense" laid down in F.R. 87 does not exist in the corresponding Rule 16 (Rule 15 in the
present compilation of the Revised Leave Rules), this condition should be considered as superseded
by the Revised Leave Rules according to the Government of India's Order below Rule 2 and
paragraph 4 of the Annexure of this Appendix.[Government of India, Finance Department Letter
No. F-7 (15)-R-1/26 dated the 21 April, 1939].(2)A provisionally permanent Government servant is
an officer in permanent employ for the purpose of the Revised Leave Rules.(3)A doubt arose
regarding the determination of the amount of leave-salary to be paid to a Government servant after
the first sixty days earned leave under Clause (ii) (b) of sub-Rule (1) of Rule 15. It has been held that
the intention underlying the aforesaid rule is that the leave-salary after the first sixty days earned
leave should be the substantive pay on the day before the leave commences or average monthly pay
earned during the 26 complete months preceding the month in which the leave commences,
whichever is higher.N.B. - The changes in the Fundamental Rules and the Subsidiary Rules
indicated below apply only to those Government servants to whom the Leave Rules, 1934, are
applicable.Special Disability Leave. - F.Rr. 83,83-A and 83-B. The limit of 4 months laid down in
sub-Clause (a) of Clause 7 of F.R. 83 should be taken to mean 120 days and the term "period of
average pay occurring in sub-Clause (b) of Clause 7 of this rule should be taken to mean 'earned
leave'. Half t he amount of leave on average pay under this sub-clause will be counted as earned
leave taken and leave-salary during special disability will be regulated under Rule 14 of the rules in
part I.The term "four months" in Clause (iii) of F.R. 83-A should be taken to mean 120 days.The
concession in F.R. 83-B is not admissible to persons governed by the Leave Rules in Part I.Study
Leave-F.R. 84 and Appendix 15. - During study leave a Government servant will be entitled to the
same leave-salary as that admissible under Rule 15 (2) of the Rules in Part I."Leave on average pay"
occurring in lines 10 and 11 of Rule 12 of Appendix 15, Part I, should be taken to mean "earned
leave" under the Leave Rules in Part 1, and the term "during the first four months of a period of
leave on average pay" occurring within brackets in lines 6 and 7 of this rule should be taken to mean
120 days.F.Rr. 89 and 90. - Under the Leave Rules in Part I, maximum limit has been imposed only
in regard to leave-salary drawn during leave on private affairs or on medical certificate. No
maximum limit is imposed in regard to leave-salary drawn during earned leave nor is there the
benefit of a minimum leave-salary in regard to any kind of leave.F.R. 100. - The limit of four months
in Clause (a) of the rule should be interpreted to mean only "earned leave not exceeding 120 days"
inclusive of the privilege leave which was due to the officer on the date of on which he became
subject to F.R. 100, and that the provision contained in the proviso to Rule 9 of the Rules in Part 1
will apply.F.R. 105 (b) (i) and S.R. 145. - The term "leave on average pay of not more than fourFundamental Rules and Subsidiary Rules

months duration" in these rules should be taken to mean "earned leave not exceeding 120 days".F.R.
105 (c) and S.R. 140. - The term "four months" mentioned in these rules should be taken to mean
120 days.F.R. 128. - The words "Chapters I to XI of these rules" in this rule should be taken to mean
"Chapters I to IX and XI of these rules and the Leave Rules in Part I".Employees of local funds
administered by Government who are not Government servants will be subject to the provisions of
Chapters I to IX and XI of Fundamental Rules and the Leave Rules in Part I.S.Rr.73 22 118, 254, 256
and 270. - The maximum of 120 days should be substituted for the limit of four months. The term
"leave on average pay" in S.R. 118 should be interpreted to mean "earned leave".S.Rr. to 88. - These
rules will continue to apply to persons governed by the Leave Rules in Part I, subject to the limits
laid down in Rule 13 of these Rules. Subsidiary Rules 89 to 116 will also continue to apply.S.R.122. -
The period of leave is limited to three months on full pay or six months on half pay in any period of
three years.Note. When the illness is one caused by irregular or intemperate habits, such as venereal
disease, the period spent in hospital by the patient and any subsequent leave granted in
continuation for convalescence should be treated as leave on medical certificate ; and if no such
leave is due, then an extraordinary leave. Such period will not count towards approved service
increment of pay.S.R.123. - "The period during which full pay is drawn" be substituted for the limit
of three months.S.Rr.133 and 134. - These rules will remain in force but F.R. 85 mentioned in Cl. (b)
of S.R. 134 should be taken to mean Rule 14 of the Leave Rules in Part I.Appendix 12[S.R. 16]List of
Officers who are authorised to fill up appointments
No. Officers Class of appointments  Remarks
1. District Officers1. Ministerial and menial
establishments intheir own
and in sub-registration
offices (except
revenuesheristadars and
head-clerks of their own
offices[andHead-clerks and
Record Keeper of the District
Registrar's Officeat Sylhet]
[Added vide Correction Slip
No. 262 to Assam Subsidiary
Rules.], ministerial
establishments in
Sub-divisional officesand
Agricultural Demonstration
staff placed under their
directcontrol except the
Agricultural Instructors at
Aijal and Sadiya  
  Note.- District Officers
(including
theSuperintendent, Lushai
Hills), in charge of Forests,  Fundamental Rules and Subsidiary Rules

areauthorised to make
appointments in the
ministerial and
menialestablishments of the
Forest Branch of their office
  2. Supervisor-Kanungos   
  3. Excise of Jamadars and
Peons  
2. Ditto in Hills Districts4. All non-gazetted
appointments in
GovernmentEstates
Establishment of primary
school in the hill districts  
3. Sub-divisional OfficersMenial establishments of the
Sub-divisionaloffices  
4.Director of Land
Records,
Inspector-General of
Registrationand
Superintendent of
Stamps1. Non-gazetted Government
servants of allclasses under
him except Sub-Registrars  
2. [ Head Clerk and
Record Keeper of the
DistrictRegistrar's
office at Sylhet]
[Added vide
Correction Slip No.
263 to Assam
Subsidiary Rules.]  
3. Temporary
appointments in the
Settlement ofAssam
on pay1[not exceeding
Rs. 100 per month]
[Added vide
Correction Slip No.
125 to Fundamental
Rules and Assam
Subsidiary Rules.]  
[4-A.] [Substituted
vide Correction Slip
No. 39 to Assam
Subsidiary Rules.]Settlement OfficerTemporary appointments in
the settlement ofAssam on
pay not exceeding Rs. 50 per
month  Fundamental Rules and Subsidiary Rules

5. Director of Surveys[Non-gazetted and menial
staff under him] [Substituted
vide Correction Slip No. 39 to
Assam Subsidiary Rules.]  
6. Conservator of ForestsNon-gazetted appointments
to any posts in theForests
service or clerical
establishments of the
department,ministerial and
menial establishments of his
office  
7.Officers in charge of
Forest Divisions(1) [] [Substituted vide
Correction Slip No. 132 to
Fundamental Rules and
Assam Subsidiary Rules,
dated the 16th April,
1955.]Assistant Forester,
Forest Guards andother
Subordinates whose
maximum pay in their
respective scaledoes not
exceed Rs. 55. Promotion of
Forest Guards to
AssistantForesters will be
made only to the extent of 25
per cent of postsof Assistant
Foresters and will be
controlled by Conservator
ofForests Passing of orders
on proceedings will be
confined to theabove
categories of subordinates
whose maximum pay in
theirrespective scale does not
exceed Rs. 55  
  (2) [] [Substituted vide
Correction Slip No. 287 to
Assam Subsidiary Rules,
dated the 15th October,
1947.]Officiating
appointments to vacancies
inthe lowest grade of clerks
within the limit of budget  Fundamental Rules and Subsidiary Rules

allotmentand if the vacancies
are leave vacancies.
  (3) Officiating appointment
or promotion to theclass of
Foresters in vacancies not
exceeding 6 months  
8.Commissioner of
Divisions1. All appointments in his
own office The term'head
clerks'does not
include
theCollectorate
Head Clerk in the
Deputy
Commissioner's
office atSylhet.
2. Revenue
sheristadars, head
clerks in theoffices of
the Deputy
Commissioners[and
Sub-divisional Officer]
[Added vide
Correction Slip No.
444 to Assam
Subsidiary Rules,
dated the 13th
February, 1956.] 
9. Commissioner of ExciseMinisterial and menial
appointments in his
ownoffice ; Ministerial staff
in the office of the
SpecialSuperintendent of
Excise, non- gazetted staff
(excluding Jamadarsin the
District Executive
Establishment) and peons of
the ExciseDepartment  
10.Legal Remembrancer
and Secretary,
Legislative CouncilThe Ministerial
establishments of his
ownoffice.  
11. District Judges The Ministerial and menial
establishments oftheir own
offices and of Subordinate
Judges and  Fundamental Rules and Subsidiary Rules

Munsiffs,proceess-serving
peons, orderlies, duftries,
and night watchmenon those
establishments, and Civil
Court Amins on their
ownestablishments
12.Inspector-General of
PrisonsJailors, Assistant Jailors, Jail
clerks,compounders (Jails),
Reserve head warders, and
Ministerial andmenial
establishments of his own
office  
13.Superintendents of Jails,
Gauhati, Sylhet and Hill
DistrictJailsHead warders, warders and
orderlies of Jails intheir
charge  
14. [] [Substituted vide
Correction Slip No. 20
to Assam Subsidiary
Rules [Finance
Department
Notification No.
5416-F (a), dated 23rd
September, 1939].]Inspector-General of
PoliceMinisterial establishments of
his own office  
14-A.Deputy
Inspector-General of
PoliceInspectors, Sergeant Majors,
Ministerialestablishments of
his own offices and also of
the offices of
theSuperintendents of Police
and menial establishment of
his ownoffice[and of the
Transport Authorities]
[Added vide Correction Slip
No. 125 to Assam Subsidiary
Rules [Home Department
Letter No. HMV 97/42/4,
dated the 12th June, 1942].] [Secretaries
Provincial and
Regional
TransportAuthorities,
are also
authorised to
grant leave to
theMinisterial
establishment, of
their offices and to
make
localarrangements
in their places
where necessary].
[14-B.] [Added vide
Correction Slip No.
207 to Assam
Subsidiary Rules
[Finance Department
Notification No. FEG(i) Secretary, State
Transport Authorities,
andMenial establishments of
their offices.  Fundamental Rules and Subsidiary Rules

12/68/18, dated 27th
March, 1969].]
(ii)District Transport
Officer and Secretary,
Regional
TransportAuthority   
15. [] [Substituted vide
Correction Slip No. 20
to Assam Subsidiary
Rules (Finance
Department
Notification No. 5416
F (a), dated 23rd
September, 1939].]Superintendents of
PoliceSub-Inspectors, Sergeants
AssistantSub-Inspectors
Head Constables, Constables,
Interpreters, Steamor motor
launch and boat
establishments, elephant
establishmentsand menial
establishments of his own
and subordinate
officers,except the employees
in civil police hospitals  
16.Director of Public
InstructionAppointments in Class[II]
[Amended vide Correction
Slip No. 118 to Fundamental
Rules and Assam Subsidiary
Rules.]of the AssatnSchool
Service and in the selection
grade of Assam Lower
SchoolService, the
Ministerial and menial staff
of his office, the headand 2nd
clerks of the offices of the
Inspectors of Schools,
headand 2nd clerks and
Librarians in Arts Colleges,
AssistantMistresses,
Matrons, Nurses and clerks
in Pine Mount
Schools,Shillong,
Clerk-Librarian in Earle Law
College and
ZenanaGrovenesses in
Sylhet. Also all appointments
outside the gradedservice on
maximum pay exceeding Rs.
75 a month.  
17. Inspectors of All appointments in the   Fundamental Rules and Subsidiary Rules

Schools,[Inspectresses of
Schools] [Added vide
Correction Slip No. 114
to Assam Subsidiary
Rules.]andPrincipals of
Colleges including
Government Madrassa,
Sylhetordinary grades of theAssam
Lower School Services and
Posts outside the graded
servicescarrying a maximum
pay not exceeding Rs. 75 per
mensem except theteaching
appointments outside the
graded services in the Garo
andthe Naga Hills[and the
Lushai Hills] [Added vide
Correction Slip No. 273 to
Assam Subsidiary
Rules.]Frontier Tracts where
theappointing authority is
the Deputy
Commissioner[theSuperintendent,
Lushai Hills] [Added vide
Correction Slip No. 273 to
Assam Subsidiary Rules.]or
the Political Officer, as
thecase may be. Subordinate
clerical establishments
employed intheir own offices
or in those directly under
their control.
  Menial appointments in their
own offices and ininstitutions
not under the control of
Deputy Inspectors ofSchools.  
18.Secretary, Government
Sanskrit College, Sylhet,
Head-mistress, Pine
Mount School, Shillong,
Superintendents of
NormalSchools, Deputy
Inspectors of Schools,
Head-masters
andHead-mistresses of
Government High
SchoolsMenial appointments in their
own offices orinstitutions, as
the case may be, and in those
directly undertheir control.  
19. Inspector-General of
Civil HospitalsSub-Assistant Surgeons,
Midwives including thosefor
the Assam Rifles Batallions,  Fundamental Rules and Subsidiary Rules

Nurses,Dais, the
Ministerialand menial
establishments of his own
office, Civil Surgeons'clerks
and clerks of Superintendent
of Medical School,
Overseersof Mental Hospital,
Taxidermist and Engineer of
Medical School.All other
non-gazetted establishments
of the Medical
Departmentunder his control
20. Civil SurgeonsCompounders other than
Compounder
Havildars,dressers,
vaccinators and menial
servants under them
includingcompounders,
dressers and menials
attached to hospitals of
CivilPolice  
21.Superintendent of
Medical SchoolMatrons and menial servants
of the School  
22.Superintendent of
Mental HospitalCompounders, store-keepers
and menial servantsof the
hospital  
23. Director of Public HealthAll non-gazetted
establishments under
hiscontrol  
[23-A.] [Added vide
Correction Slip No.
252 to Assam
Subsidiary Rules.]Assistant Director of
Public HealthCompounders and menial
establishments under
hiscontrol  
24.Superintendent, Vaccine
DepotVaccine Depot establishment   
25. Director of Agriculture Ministerial and menial
establishment of hisoffice,
Chemical Assistant,
Entomological Assistant,
BotanicalAssistant,
Mytological Assistant, Farm
Managers,
AgriculturalInspectors, Fruit  Fundamental Rules and Subsidiary Rules

Inspector and Staff under
him, Demonstrators inKhasi
and Jaintia Hills, Peon to the
Agricultural Inspector,Khasi
and Jaintia Hills, Inspector
of Government
Gardens,Shillong, the menial
establishments at the
Botanical GardenStation
Nursery, Shillong
26.Director of Industries
and Registrar of
Co-operative SocietiesAssistant Superintendent of
Sericulture,Overseers of
rearing stations, Auditors of
Co-operative Societiesand
other non- gazetted
appointments under his
control  
27.Deputy Directors of
AgricultureMinisterial and menial
establishments underthem,
Demonstrators as well as the
non-gazetted Farm
staff(including apprentices
below the rank of farm
Manager  
[27-A.] [Added vide
Correction Slip No.
284 to Assam
Subsidiary Rules.]Agricultural Officer,
North-East Frontier
AgencyMinisterial and menial
establishments under
him.Demonstrators as well as
non-gazetted staff
(includingapprentices) below
the rank of Agricultural
Inspectors  
28.Superintendent of
SericultureRearers and menial
establishments attached
tohis office and to
sericultural stations  
29. Economic BotanistMinisterial and menial
establishments,
BotanicalField Assistants and
all Fieldmen under him  
[29-A.] [Added vide
Correction Slip No.
195 to Assam
Subsidiary Rules.]Agricultural Chemist Ministerial and menial
establishments,
ChemicalField Assistant,
Fieldman and Laboratory  Fundamental Rules and Subsidiary Rules

Workman under hiscontrol
30.Director, Veterinary
Department[Veterinary Inspectors,
Assistant Surgeon,Clerks,
Compounders and menials of
his staff and of
officerssubordinate to him]
[Substituted vide Correction
Slip No. 124 to Assam
Subsidiary Rules.]  
31.Superintendent, Assam
Secretariat PressMinisterial and technical
establishments whenthe pay
of the appointment is less
than Rs. 100 and all
menialestablishments  
32. Chief EngineerAssam Subordinate
Engineering Service and
LowerSubordinate
Establishments, Supervisors
and Overseers under
CivilPublic Works
Disbursers, Drawing branch
establishment of hisoffice
and of Divisional offices,
Temporary Overseers and
menialestablishment of the
offices  
33. Executive EngineerOffice and petty
establishment of
theirrespective offices  
34.Examiner Local
AccountsAll establishments under him   
35. Weaving SuperintendentTo appoint ministerial and
menial establishmentof the
Weaving Institute at Gauhati
and menial establishment
ofthe Peripatetic Weaving
parties and his own office  
36.Principal of Technical
SchoolTo appointment menial
establishments attached
tothe technical schools under
their control  
37. [] [Substituted
vide Correction SlipZonal Deputy Registrars
of Co-operative SocietyTo appoint ministerial and
grade IVestablishments of all  Fundamental Rules and Subsidiary Rules

No. 503 to Assam
Subsidiary Rules.]subordinate officers
including their ownrespective
Zones
38.Deputy Director of
Agriculture Live-StockTo appoint and transfer the
ministerial andmenial
establishments of his own
office as well as
thenon-gazetted staff
including apprentices and
other farm employeesbelow
the rank of farm managers of
the cattle farms at
Sylhet,Khanapara and Upper
Shillong  
39.Special Superintendent
of ExciseTo appoint, transfer, suspend
and dismiss peonof the
special branch  
40.Chief Inspector of
Factories and Electrical
Adviser toGovernmentNon-gazetted staff under him   
41.Honorary Provincial
Director, Department of
Historical
andAntiquarian Studies,
AssamMinisterial and menial
establishment under him  
42. Chief Inspector of Boilers Non-gazetted staff under him   
43. Advocate GeneralMinisterial and menial
establishments of hisoffice  
44. [] [Added vide
Correction Slip Nos.
36 and 167 to Assam
Subsidiary Rules.]Deputy Director, Assam
SurveysMinisterial, menial and
technical staff underhim  
45. Political OfficersMinisterial and menial
establishments in theirown
and in Sub-divisional offices,
except Heads Clerks of
theirown offices, and
establishments of Primary
Schools in theFrontier Tracts  
46. Director, Pastuer
InstituteLaboratory Assistants,
laboratory attendants,media
makers, testers, decanters,  Fundamental Rules and Subsidiary Rules

packers, and scalers
andengineman, carpenter,
etc., and the menial
establishment underhim.
47.Principal, Assam
Agricultural CollegeMinisterial and menial
establishment of
theAgricultural College, as
well as the non-gazetted staff
of theCollege (including
apprentices) below the rank
of Lecturers D.A.'s approval
48.Principal, Assam
Veterinary CollegeMinisterial and menial
establishment of
theVeterinary College, as well
as the non-Gazetted staff of
theCollege Director of
Veterinary
Department's
approval
49.Private Secretary to the
Hon'ble PremierMinisterial and menial staff
under him  
50.Labour Commissioner
AssamMinisterial and menial
establishments in hisoffice
and in the office subordinate
to him  
51.Assistant Commissioner
of Agricultural
Income-tax
andSecretary, Board of
Agricultural Income-tax,
AssamNon-gazetted Ministerial and
menialestablishments under
him With the approval
of the member.
52. Director of StatisticsMinisterial (non-Gazetted)
and menialestablishments of
his office  
53.Director, Forensic
Science LaboratoryScientific Technician,
Laboratory Bearer,Mechanic,
Gas Operator, Boiler
Operator, Carpenter, U.D.
A.in-charge, U.D. Assistant
Store-Keeper, Typist, L.D.
Assistant,Record Keeper
Stenographer-Grade III and
Grade IV staff  
Appendix 13Auditor-General's Instructions under Fundamental Rule 74I. Procedure Relating to
LeaveCertificate of AdmissibilityFundamental Rules and Subsidiary Rules

1. Leave should be sanctioned to a gazetted Government servant only after
its admissibility has been certified by the Audit Officer who has been
auditing his pay.
Note. The leave accounts of the Archdeacon of Calcutta and the Presidency Senior Chaplain, Church
of Scotland, Bengal are maintained by the Accountant General, Central Revenues. The leave
accounts of all other Chaplains both of the Church of England and the Church of Scotland, including
those attached to regiments are maintained by the Accountant General of the State in which they
serve. In the case of Chaplains, therefore, the certificate of admissibility of leave required by the
above rule will be issued by the Accountant-General who maintains the leave accounts.
2. Before the leave in India is sanctioned to a non- gazetted Government
servant, the authority in sanctioning the leave should either consult the leave
account prescribed in F.R. 76, and satisfy himself that the leave as
admissible, or obtain a certificate to that effect from the officer entrusted with
the attestation of the entries in leave account. When the application is for
leave out of India, the authority sanctioning the leave should obtain a
certificate of admissibility from the Audit Officer before sanctioning the
leave.
3. When a military officer becomes subject to the Civil Leave Rules, the Audit
Officer in charge of his record of pension service will, on application and on
being furnished with the date of commencement of active service in civil
employ, furnish to the Audit Officer to whose audit he becomes subject a
memorandum showing the furlough earned, the different kinds of leave taken
(distinguishing those which should be deducted from the maximum furlough
admissible) and the balance of furlough due under Military Rules.
4. (a) Application for leave from military officers in civil employ, whether they
are subject to the Military Leave Rules or the Civil Leave Rules, should be
sent through the Civil Audit Officer who audits the pay of the officer going on
leave. The Civil Audit Officer will, if he considers it necessary, consult the
Controller of Military Accounts from whose payment the officer is transferred
to the Civil Department before certifying to the leave and specifying the
leave-salary. No leave should be sanctioned to such an officer before a
report is received from the Civil Audit Officer.
(b)In the case of a military officer subject to the Military Leave Rules the Civil Audit Officer should
obtain from the Controller of Military Accounts from whose payment the officer is transferred to theFundamental Rules and Subsidiary Rules

Civil Department a certificate stating the amount of leave in which the officer is entitled and the
rates of leave pay and allowance admissible during the said period of leave, before issuing a
leave-salary certificate or a warrant or a certificate of leave granted to an officer proceeding on leave
out of India who does not intend to draw his leave-salary at the Home Treasury or in Colony.
5. In the case of a Government servant on foreign service, leave cannot be
sanctioned, until the Audit Officer of the Government (Central or State),
under which he was permanently employed at the time of his transfer to
foreign service, has certified the amount of leave and the leave-salary
admissible.
Note 1. For the purpose of this rule, the Accountant General of the State in which the contribution
towards leave-salary and pension of a Government servant on foreign service are recovered will act
as Audit Officer of the Central Government.Note 2. In the case of Military Officers in temporary civil
employ, the Controller of Military Accounts, who received the Foreign Service contributions of the
Officers concerned is responsible for certifying to the amount of leave and leave-salary admissible,
the necessary information in the case of Military Officers subject to the Civil Leave Rules, being
obtained from the Civil Audit Officer concerned. Similarly, in the case of Government servants in
Commercial Departments,e.g., Railway and Indian Posts and Telegraph Departments the certificate
will be given by the Departmental Accounts Officer who is responsible for bringing the contribution
to accounts.Payment of leave-salary in India
6. The leave-salary of a non-gazetted Government servant on leave in India or
on leave out of India cannot be drawn in India except under the signature of
the head of his office ; and the latter is responsible for any overcharge.
7. No Gazetted Government servant can begin to draw his leave-salary at any
office of payment in India without producing a leave-salary certificate from
the Audit Officer who audited his pay before proceeded on leave.
8. The certificate should be in F.R. Form No. 2-B, and if during leave the
Gazetted Government servant desires to change the office at which he
receives payment of his leave- salary, he must obtain a new certificate from
the Audit Officer within whose jurisdiction his leave-salary was last paid.
8.
-A. A Gazetted Government servant desirous of discontinuing his subscription to the General
Provident Fund during leave or of subscribing to the fund at the usual rates during leave on average
pay and half rates during other leave, should intimate his wishes in the matter to his Audit office
before proceeding on leave.Fundamental Rules and Subsidiary Rules

8.
-B. In the case of a Government servant entitled to Sterling Overseas Pay, who draws his
leave-salary in India, that Portion of leave-salary which represents Sterling Overseas Pay is payable
by the High Commissioner for India. A separate authority should be issued to the High
Commissioner for India for payment of the Sterling portion of the leave-salary and to stop payment
of duty on Sterling Overseas Pay. A copy of this authority should also be sent to the officer to enable
him to draw the amount in accordance with the procedure had down or in the payment of
leave-salary from the Home Treasury.
9. If a Gazetted Government servant signs his bill himself he must either
appear in person at the place of payment or furnish a life certificate signed
by a responsible officer of Government or some other well-known and trust
worthy person. If he draws his leave salary through an authorised agent, the
agent,whether he has or has not a power attorney, must either furnish a life
certificate as aforesaid, or execute a bond to refund over-payments. A life
certificate may be given periodically, a bond being given to cover
intermediate payment not supported by life certificates.
10. The provisions of paragraphs 7 to 9 above apply also to gazetted
Government servants who spend their leave out of India but reside in Asia
and who have to draw their leave-salary in rupees in India under F.R. 91.
Note. A certificate of residence should be obtained from Government servants who draw their
leave-salary at the rupee rate.
11. In the case of Railway and Telegraph Departments and the Military
Engineer Service, the above rules will be generally applicable subject to any
modifications which may be made by the Accountant General concerned in
accordance with the special rules of this Department.
12. Before returning to duty, a Government servant who has drawn his
leave-salary in India should obtain a last pay certificate from the Audit
Officer, within whose jurisdiction his leave-salary was last paid, and deliver it
to the Audit Officer who audits his pay. Without such a certificate he cannot
obtain payment of any arrears of leave-salary or pay due to him.
Leave out of IndiaFundamental Rules and Subsidiary Rules

13. A copy of "Memorandum of information for the guidance of Government
servants proceeding on leave out of India" should be supplied to each
Government servant proceeding on leave out of India by the Audit Officer
who audits his pay, as soon as the grant of leave is gazetted or otherwise
notified to him.
14. (a) A Government servant proceeding on leave out of India and intending
to draw his leave-salary while on leave should be given a leave-salary
certificate by the Audit Officer who audited his pay before he proceeded on
leave-
(1)In F.R. Form No. 2 if he intends to draw his leave-salary at the Home Treasury ;(2)in the shape of
a leave-salary warrant in Form No. 1 under the Supplementary Rules, if he is proceeding to a Colony
and intends to draw his leave-salary there.(b)If during any period of leave on average pay, a gazetted
Government servant wishes, under the provisions of F.R. 91, to draw his leave-salary in India, a
separate leave-salary certificate should be issued in respect of that period under the provisions of
paragraph 8 above.Note 1. When vacation is taken alone or combined with holidays and spent out of
India, or when vacation or/and holiday(s) is/are prefixed or suffixed to leave out of India, and is/are
actually spent out of India, the Government servant may, in the absence of any specific restriction
laid down either in a statutory rule or by a State Government, be authorised to draw his pay or
leave-salary or both for the whole period at the Home Treasury or in a Colony, but the exact amount
to be paid on account of each separate period must be stated in the certificate or warrant, as the case
may be, issued by the audit officers.Note 2. When a Chaplain of the Church of Scotland proceeds to
the United Kingdom on leave granted by the civil authority on his being reverted for the purpose
from military to civil duty and intends to draw his leave-salary from the Home Treasury, the
Controller of Military Accounts from whose office he was in receipt of pay sends to the Accountant
General concerned a last- pay certificate on receipt of which a leave-salary certificate should be
issued by the Accountant General.
14.
-A. In the case of a Government servant proceeding on leave to a Dominion or Colony and intending
to draw that portion of his leave-salary which represents Sterling Overseas Pay from the Home
Treasury, the colonial leave-salary warrant issued under paragraph 14 (a) (2) above should authorise
payment of leave- salary based on rupee pay only. A separate intimation should be sent to the High
Commissioner to pay that portion of leave-salary which represents Sterling Overseas Pay. A copy of
this intimation should also be given to the Government servant in order that he may arrange to draw
the amount in accordance with the procedure laid down for the payment of leave-salary from the
Home Treasury.Fundamental Rules and Subsidiary Rules

15. When a Government servant proceeds out of India on leave other than
extraordinary leave, the Audit officer who audits his pay will, as soon as the
leave is gazetted or otherwise notified, send him a letter in F.R. Form No. 4
with enclosures in F.R. Form No. 5 requiring him to call at his office or give
the necessary information.
Note. If a Government servant sent home to Europe as a lunatic is granted leave, as leave-salary
certificate should be prepared, be necessary, by the Audit Officer who audits his pay on the data
available to him, and forwarded to the High Commissioner for India at the earliest possible date.
16. If the Government servant calls at the Audit Office he will be paid up to
the date of his relief and will be given a leave- salary certificate in the
appropriate form as prescribed in paragraph 14 above. In the case of
Government servants, proceeding to Colony, the Colonial leave-salary
warrant (Form No. 1 under the Supplementary Rules) will be issued in
triplicate. The original, bearing the Government servant's signature, will be
forwarded by the Audit Officer to the Colonial Authority concerned, the
duplicate to the High Commissioner for India and the triplicate will be made
over to the Government servant concerned.
Note. If the Government servant takes a certificate under Clause (b) of paragraph 14 above, he will
not be paid up to the date of relief, but will be allowed to draw his pay and allowances for the broken
period of the month at the commencement of the next month with the leave-salary for the rest of the
month.
17. If a Government servant is unable to call at the Audit Office, the Audit
Officer will cause the leave-salary certificate to be sent to the address
specified by the Government servant and the pay and allowances to be paid
through the officer from whom the Government servant draws his pay and
allowances.
Note. The orders in the note under paragraph 16 apply also in the circumstances specified in this
paragraph.
18. When a Government servant proceeds on extraordinary leave out of India,
or on leave on average pay or half average pay out of India during which he
does not propose to draw leave-salary or when a Government servant is
given a Colonial leave-salary warrant, he should be given a certificate of
leave in Form 111 under the Supplementary Rules. This certificate has to beFundamental Rules and Subsidiary Rules

presented by the Government servant to the High Commissioner for India if
he is on leave in Europe, North Africa, America or the West Indies and
applies for extension of leave, or for permission to return to duty or for a last
pay certificate before returning to duty.
Note. Whenever a Government servant is proceeding to a Dominion or Colony which does not
account directly to India, a duplicate copy of the certificate in Form II under the Supplementary
Rules should be sent to the High Commissioner with the duplicate copy of the Colonial leave-salary
warrant [vide paragraph 16].
19. [Deleted.]
20. With very leave-salary certificate, Colonial leave-salary warrant of
certificate of leave, given to Government servants to whom the leave rules in
Sections I to V of Chapter X of the Fundamental Rules are not applicable, a
blank F.R. Form No. 7 will be given on which the Government servant
concerned will report to the Audit Officer, from the first port at which the
vessel touches, the day of his departure from India.
21. As soon as an Audit Officer has delivered a leave-salary certificate,
certificate of leave or Colonial leave-salary warrant to a Government servant
who proposes to spend his leave out of India, or has caused it to be sent to
the address specified by him, he must forward a copy of the leave-salary
certificate or certificate of leave or the duplicate copy of the Colonial
leave-salary warrant to the High Commissioner for India.
22. [Deleted.]
23. If it becomes necessary to amend a leave-salary certificate in F.R. Form
No. 2 the amendment should take the form of a short corrigendum worded so
as to show only the particular item or items in which alteration have been
made ; this corrigendum should be forwarded by the Audit Officer at the
earliest possible date to the High Commissioner for India. Every corrected
leave-salary certificate whether original or duplicate should be marked
"Amended certificate."Fundamental Rules and Subsidiary Rules

24. Whenever the leave of a Government servant absent on leave out of India
elsewhere than in Europe, North Africa, America or the West Indies is
extended or commuted by the authority in India which granted the leave, the
fact should forthwith be notified by the Audit Officer to the High
Commissioner for India to enable him to check the payment by Colonial
Treasurers or Staff Officers.
Note. This rule applies to military officers subject to the Military Leave Rules.
25. If the leave of a Government servant who draws his leave-salary in India
under the provisions of F.R. 91 is extended or commuted, the Audit Officer
who audited his pay at the time he proceeded on leave must, on receiving
advice of such extension or commutation, forthwith communicate to the
Audit Officer within whose jurisdiction his leave-salary is drawn. He should
also communicate any other circumstances connected with the leave which
may be required to be known to the Audit Officer who possesses the
Government servant's leave-salary.
26. When no space for the entry of endorsement of payment remains upon
the back of Colonial leave-salary warrant, or when a warrant is lost or
destroyed, a fresh warrant should be issued by the Audit Officer who issued
the original warrant on the application of the Government servant concerned
submitted through the Colonial Disbursing Officer.
27. A Government servant who was on leave in Europe must, on return to
India, deliver to the Audit Officer the last pay certificate obtained by him from
the Commissioner, before he can obtain payment of any arrears of
leave-salary or pay due to him. A Government servant who has drawn his
leave-salary on a warrant must deliver his copy of the warrant which will
serve as a last- pay certificate.
28. Changes in the above rules, except those which relate to Colonial
leave-salary warrants, may be made by the Controller of Railway Accounts,
or the Military Accountant General in accordance with the special rules of his
own department.
Special rules relating to Military OfficersFundamental Rules and Subsidiary Rules

29. As soon as the grant of furlough or leave to a military officer in civil
employ has appeared in orders, the Audit Officer from whose payment the
officer is transferred to the Civil Department must, in the case of furlough to
Europe, North Africa, America or the West Indies, forward to the High
Commissioner for India a statement of the officer's service in such form as
the military authorities may prescribe. This statement is not required in the
case of officers proceeding on furlough under the Staff of British Leave
Rules.
30. When furlough or leave or an extension of furlough or leave is granted to
a military officer in civil employ, whether subject to the Civil or the Military
Leave Rules, the Civil Audit Officer should intimate to the Audit Officer
whose payment the officer is transferred to the Civil Department the date of
beginning and end of the furlough or leave, the dates of embarkation and
debarkation in the case of furlough out of India, as well as those of being
struck off or of resuming duty.
31. [Deleted.]
32. On the return of an officer furlough or leave it will be the duty of the Audit
Officer in charge of his record of pension service to satisfy himself that he
has returned within his leave ; and if not, report the case to the authority
which sanctioned the leave.
Leave account
33. The leave account prescribed in F.R. 76 should be kept in F.R. Forms No.
9 and No. 9-A in respect of Government servants under the special leave
rules and ordinary leave rules respectively. The office in which the account
should be kept for any Government servant and pension by whom the entries
should be attached will be such as are prescribed by the State Government.
* * * * *
33.
-A. In the case of Government servants subject to the "Leave Rules, 1934 (Assam)" leave accounts
need not be maintained in the forms prescribed in paragraph 33 above, the particulars entered in
Service Books or Histories of Services or other records of service being sufficient for the calculationFundamental Rules and Subsidiary Rules

of the amount of leave admissible at any time.If a Gazetted Government servant, subject to the
"Leave Rules, 1934" is transferred permanently to another Government, the Audit Officer of the
lending Government should draw up a leave account indicating therein the amount of "earned
leave" at credit, leave- salary for which should be borne by the lending Government, and send it to
the Audit Officer of the borrowing Government. The latter should pass on the debit in regard to
leave-salary for "earned leave" up to the extent indicated in the leave accounts as and when the
Government servant takes that leave after permanent transfer to the borrowing Government.When
a non-Gazetted Government servant subject to the Leave Rules, 1934, is transferred permanently to
another Government, the head of the office from which he is transferred should prepared a leave
account showing the amount of "earned leave" at credit on the date of permanent transfer and send
it to the head of the office to which the Government servant is transferred. A copy of the leave
account should also be sent at the same time to the Audit Officer of the office from which the
Government servant is transferred so as to enable him to accept debit on account of leave- salary for
"earned leave" up to the extent indicated in the leave account, as and when the Government servant
takes leave.II. Service Books
34. A service book in Form F.R. No. 10 should be maintained for every
non-Gazetted Government servant for whom it is prescribed under the orders
of the Government. In this book every step in the Government servant's
official life should be recorded and each entry should be attested by such
superior officer as may be prescribed by the State Government.
35. If a Government servant is transferred to foreign service, the Audit Officer
referred to in paragraph 5 above will, on receipt of the service book from the
head of the office or department concerned, note in it, under his signature,
the order sanctioning the transfer, the effect of the transfer in regard to leave
admissible during foreign service and any other particulars which he may
consider to be necessary, and return the same to the officer from whom he
received it. On the Government servant's re-transfer to Government service,
the Audit Officer will again note in the service book, under this signature, all
necessary particulars concerned with the foreign service. All entries relating
to the time spent in foreign service should be attested by the Audit Officer.
Appendix 14Leave Procedure Rules made by the Governor-General under Fundamental Rule
74Report of arrival in the United Kingdom
1. A Government servant taking leave in the United Kingdom must report his
arrival in that country to High Commissioner for India.
Payment of Leave-salaryFundamental Rules and Subsidiary Rules

2. No Government servant can begin to draw leave- salary from the Home
Treasury until he has presented to the High Commissioner a leave salary
certificate in such form as the Auditor-General may prescribe.
3. Leave-salary is issued from the Home Treasury monthly in arrear on the
first day of each calendar month.
4. Payment will be made, at the option of the Government servant drawing
leave-salary by any of the following methods :
(a)To the Government servant himself on his personal application.(b)To his banker or other agent,
duly authorised under power-of-attorney, on production of a life certificate duly filled up and
executed. In cases where the banker has guaranteed the Secretary of State or the High
Commissioner against loss consequent upon dispensation with proof of existence, a life certificate is
unnecessary.Note. A supply of life certificate forms may be obtained from the High
Commissioner.(c)To the presenter of a payment from comprising a receipt and a life certificate, both
duly completed by the Government servant.Note. If the Government servant intimates to the High
Commissioner his election of this method, he will be regularly supplied with the requisite payment
form as the due date of issue approaches.
5. No Government servant can begin to draw leave-salary from a Colonial
Treasury until a warrant in Form I or I-A, as the case may be, has been issued
in his favour. Such warrants will be issued in triplicate. The original bearing
the Government servant's signature, will be forwarded by the issuing
authority to the Colonial authority concerned ; the duplicate to the High
Commissioner and the triplicate will be retained by the Government servant.
Payment of leave-salary will not be made rules the Colonial authority is in
possession of the original and the Government servant of the triplicate of the
warrant.
6. Each payment of leave-salary must be endorsed upon the back of both the
original warrant and the triplicate, and an acknowledgement of receipt must
be endorsed by the Government servant upon the back of both the copies.
7. When no space for the entry of endorsements of payment remains upon
the back of warrant, or when a warrant is lost or destroyed, a fresh warrant
will be issued by the original issuing authority on the application of the
Government servant submitted through the Colonial disbursing officer.Fundamental Rules and Subsidiary Rules

8. If the transfer from one Colony to another of payment of the leave-salary of
a Government servant is sanctioned by the Colonial authorities, such
transfer must be reported by the Government servant to the
Governor-General and to the High Commissioner.
9. (a) If a Government servant who is drawing his leave-salary in a Colony
desires to transfer payment to the Home Treasury, he can do so on
production of his warrant to the High Commissioner.
(b)If a Government servant who is drawing his leave-salary from the Home Treasury desires to
transfer payment to a Colony, he must obtain a warrant in Form I or 1-A, as the case may be, from
the High Commissioner who will forward the original of the warrant to the Colonial authority
concerned.(c)A transfer sanctioned under Cl. (a) or (b) of this rule be reported by the Government
servant to the Governor-General.Extension of leave
10. A Government servant absent from India on leave who desires an
extension of his leave must make application for such extension not less
than three months before the expiry of his leave. An application made within
three months from such expiry will not be considered unless special reasons
for consideration exist.
11. An application for extension of leave by a Government servant on leave in
Europe, North Africa, America or West Indies must be made to the High
Commissioner. Unless the extension is desired on medical grounds, or is for
a period of not more than fourteen days, the application must be
accompanied by evidence that the Government on whose cadre the
Government servant is borne has been consulted and has no objection to the
extension. It is in exceptional cases only that the High Commissioner will
grant an extension without the production of such evidence, and then for
such period only as may be necessary to obtain the orders of the
Government concerned, which will be sought by telegraph at the applicant's
expense.
12. If a Government servant on leave in any of the localities named in Rule 11
desires on medical grounds, an extension for a longer period than fourteen
days he must satisfy the Medical Board at the India office of the necessity for
the extension. In order to do so, he must as a general rule, appear at Indian
office for examination by the Board ; but in special cases, and particularly ifFundamental Rules and Subsidiary Rules

he be residing at a distance of more than sixty miles from London, a
certificate in a form to be obtained from the High Commissioner may be
accepted if signed by two medical practitioners. A certificate obtained
outside the United Kingdom and signed by foreigners must be attested by
Consular or other authority as bearing the signature of qualified medical
practitioners.
13. If a Government servant on leave in any of the localities named in Rule 11
desires, on grounds other than medical, an extension of leave on medical
certificate, he must satisfy the Medical Board at the India office, by the
procedure described in Rule 12, that he has recovered his health.
14. An application for extension of leave by a Government servant on leave
out of India elsewhere than in the localities named in Rule 11 must be made
to the authority which grated the leave.
15. If an application made under Rule 14 is for a extension of leave on
medical certificate it must be accompanied by a certificate from medical
practitioners in the following form :
"We hereby certify that we have carefully examined CD of the .........who is suffering from
.............and we declare upon our honour that, according to the best of our judgement and belief he is
at present unfit for duty in India and that it is absolutely necessary for the recovery of his health that
his present leave which will expire in India on...... shall be extended by..........
months/weeks".Dated.........Place.........The certificate must describe in full detail the nature of the
disease and the present condition of the Government servant. If it be signed by foreigners it must be
attested by Consular or other authority as bearing the signature of qualified medical practitioners.
16. An extension of leave will not granted by the High Commissioner to a
Government servant to whom no leave-salary certificate has been issued, or
who has exchanged his leave- salary certificate for a warrant before leaving
India, unless he produces a certificate of leave in Form II.
Return from leave
17. A Government servant who is required, by or under F.R. 71, to produce a
medical certificate of fitness before returning to duty, must obtain
permission to return to duty before so returning.Fundamental Rules and Subsidiary Rules

18. If the Government servant desiring to return is on leave in any of the
localities named in Rule 11, his application must be made to the High
Commissioner and he must satisfy the Medical Board at the India office of
his fitness to return at least two months before the expiry of his leave. In
order to do so he must follow the procedure prescribed in Rule 12. When the
Medical Board has been satisfied, the High Commissioner will grant
permission to return.
19. If the Government servant desiring to return is on leave out of India
elsewhere than in the localities named in Rule 11 his application must be
made to the authority which granted his leave and must be accompanied by a
certificate of fitness in the prescribed form.
20. Permission to return cannot be granted to a Government servant to whom
no leave-salary certificate has been issued or who has exchanged his
leave-salary certificate for a warrant before leaving India, until he produces a
certificate of leave in Form II.
21. Before returning to duty, a Government servant on leave in Europe must
obtain a last-pay certificate from the High Commissioner. A last-pay
certificate cannot be granted to a Government servant to whom no
leave-salary certificate has been issued unless he produces a certificate of
leave in Form II. A Government servant who has drawn his leave-salary on a
warrant must, on return to India, deliver to the Audit Officer his copy of the
warrant, which will serve as a last-pay certificate.
Appendix 15
Part I – [F.R. 84]
Rules for the grant of additional leave to Government servants for the study of Scientific, Technical
or similar problems, or in order to undertake Special Courses of InstructionThe following rules
relate to study leave only. They are not intended to meet the case of Government servants deputed
to other countries at the instance of Government either for performance of special duties imposed
on them or for the investigation of specific problem connected with their technical duties. Such
cases will continue to be dealt with on their merits under the provisions of Rr. 50 and 51 of
Fundamental Rules.Fundamental Rules and Subsidiary Rules

1. Short title and commencement. - (1) These Rules may be called the Assam
Study Leave Rules, 1963.
(2)They shall come into force at once.
2. Definitions. - (1) In these rules, unless the context otherwise requires-
(a)'Head of Indian Mission' means Ambassador, Charged Affairs, Minister, Consul-General, High
Commissioner and any other authority declared as such by the Central Government in the country
in which the Government servant undergoes a course of study or training.(b)'Audit Officer' means
such officer as may be appointed by the Comptroller and Auditor General of India.Note. The
Accountant General, Assam, is the Audit Officer in Assam.(2)All other words and expressions used
in these rules, but not defined shall have the meanings respectively assigned to them in the
Fundamental Rules.
3. Conditions for the grant of study leave. - (1) Subject to the conditions
prescribed in these rules, study leave may be granted to a Government
servant, in or out of India, with due regard to exigencies of public service, to
enable him to undergo a special course of study consisting of higher studies,
or specialised training in a professional or technical subject having a direct
and close connection with the sphere of his duties or with work in the
teaching line in the technical and professional subjects.
(2)Study leave shall be granted unless-(i)it is certified by the Government that the proposed course
of study or training shall be of definite advantage from the point of view of public interest;(ii)study
leave shall not be granted to a Government servant with such frequency as to remove him from
contract with his regular work or to cause cadre difficulties owing to his absence on leave.(3)Study
leave out of India shall not be granted for prosecution of study or undergoing training in subjects for
which adequate facilities exist in India or under any of the schemes administered by the State
Government or the Government of India.(4)Study leave shall not ordinarily be granted to a
Government servant-(i)who has rendered less than five years' service under the State Government
;(ii)who is due to retire or has the option to retire from the Government service within three years of
the date of on which he is expected to return to his duties after expiry of the leave.
4. Maximum amount of study leave. - (1) The period of study leave would
ordinarily be extended to the period of the course of study or training not
exceeding 48 months, but in exceptional circumstances, about which
Government in the Finance Department, must be satisfied, the total period
may be extended up to 60 months during the entire service of a Government
servant.Fundamental Rules and Subsidiary Rules

(2)If for reasons beyond the control of the Government servant it is not possible for him to complete
the course of study satisfactorily within the period of study leave so granted, he may be permitted to
combine other kinds of leave as may be admissible under the leave rules subject to a maximum
period of 120 days at a time.
5. Regulation of study leave extending beyond the course of study. - When
the course of study or training falls short of study leave sanctioned, a
Government servant shall resume duty on the conclusion of the course of
study or training, the previous assent of the Government to treat the excess
period of study leave as ordinary leave has been obtained.
6. Grant of study and other allowance. - (1) A study allowance shall be
granted for the period of study leave, which may include the period spent in
prosecuting a definite course of study or training at a recognised institution
as also the period covered by any examination at the end of the course of
study.
(2)(a)The rates of study allowance shall be as follows but may be revised from time to time :
Name of country Study allowance per diem
United Kingdom..... 16 s
Continent of Europe..... £ 1
United States of America..... 30 s
(b)The rate of study allowance to be granted to a Government servant who takes study leave in other
countries and in India shall be such as may be specially determined by Government.(c)No allowance
of any kind, other than study allowance and dearness allowance shall be admissible to a
Government servant in respect of study leave granted to him.Note. In cases where a Government
servant is granted study leave at the same place as his place of duty, the leave-salary plus the study
allowance shall not together exceed the pay that they would have otherwise drawn had he been on
duty.(3)Study allowance may be paid at the end of every month provisionally subject to an
undertaking in writing being obtained from the Government servant that he would refund to
Government any over payment.(4)A Government servant may be allowed to draw study allowance
for the entire period of vacation during the course of study subject to the additions that-(i)he attends
during vacation any special course of study or practical training under the direction of the
Government or the authority competent to sanction study leave, as the case may be ; or(ii)in the
absence of any such direction, he produces satisfactory evidence before the Head of Mission or the
authority competent to sanction study leave, as the case may be, that he has continued his studies
during the vacation ;(iii)No study allowance shall be drawn during vacation falling at the end of a
course of study except for a maximum period of fourteen days.Note. The period of vacation during
which study allowance is drawn shall be taken into account in calculating the maximum period of
thirty-six months for which study allowance is admissible.(5)Study allowance shall not be grantedFundamental Rules and Subsidiary Rules

for any period during which Government servant interrupts his course of study or training to suit his
own convenience :Provided that the Government may authorise the grant of study allowance for any
period not exceeding 14 days at a time during which a Government servant is prevented by sickness,
duly certified by a registered medical practitioner, from pursuing his course of study or
training.(6)In the case of definite course of study or training at a recognised institution, the study
allowance shall be payable by the Government if the study leave availed of is in India or in a country
where there is no Indian Mission, and by the Head of the Indian Mission in other cases no claim
submitted by the Government servant from time to time, supported by proper certificate of
attendance.(7)The certificate of attendance required to be submitted in support of the claims of
study allowance shall be forwarded at the end of the terms of the Government servant as undergoing
study or training in an educational institution, or at intervals not exceeding three months, if he is
undergoing study or training at any other institution.(8)When the programme of study or training
approved does not include or does not consist entirely of such a course of study or training, the
Government servant shall submit to the Government or Head of Indian Mission, as the case may be,
a dairy showing how his time has been spent and a report indicating fully the nature of the methods
and operations which have been studied and including suggestions as to possibility of adopting such
methods or operations to conditions obtaining in India. The Government shall decide whether the
diary and report show if the time of the Government servant was properly employed and shall
determine accordingly for what periods study allowance may be granted.(9)A Government servant
who is permitted to receive and retain, in addition to the leave-salary admissible under Rule 10, any
scholarship or stipend from a Government or non-Government source or remuneration in respect of
a part-time employment shall not be entitled to any study allowance. In case where special reasons
exit, such a Government servant may be granted by a specific order, the difference between the value
of the net scholarship or stipend or remuneration and the usual study allowance, provided the value
of scholarship or stipend or the amount of remuneration is less than the study allowance that would
be admissible to him but for the scholarship or stipend or remuneration.
7. Cost of fees for study. - A Government servant granted study leave is
ordinarily required to meet the cost of fees paid for a course of study or
training. In exceptional cases Government may consider proposal for the
grant of such fees.
8. Execution of Bond. - A Government servant, who has been granted study
leave or extension of such leave shall be required to execute a Bond as given
in Appendix A or A-l, as the case may be, annexed to these rules before the
study leave is granted, and furnish suitable surety for due fulfilment of the
Bond. As soon as the Bond is executed the leave sanctioning authority shall
forward a certificate to the Accountant General, Assam, to the effect that the
Government servant has executed the requisite Bond.Fundamental Rules and Subsidiary Rules

9. Resignation and retirement. - (1) If a Government servant resigns or retires
from service without returning to duty after a period of study leave or within
a period of three years after such return to duty, he shall be required to
refund double the amount of leave salary, study allowance, cost of fees,
handling and other expenses, if any, incurred by State Government, drawn by
him for the period of study leave together with the interest thereon at
Government rates for the time being in force on Government loans from the
date of demand before the resignation is accepted or permission to retire is
granted :
Provided that the Government may order-(a)that nothing in this rule shall apply to a Government
servant, who on return to duty from study leave is permitted to retire from service on medical
grounds ;(b)that the amount required to be refunded under this rule, shall in the case of a
Government servant, who on return to duty from study leave is permitted to resign from the service
and to take up employment under a statutory or autonomous body or in any institution under the
control Government, be reduced to an amount equal to the expenditure incurred by the Government
in respect of the leave-salary, study allowance, cost of fees and travelling and other expenses,
sanctioned to him, during the period of study leave together with interest thereon.(2)The study leave
availed of by such Government servant shall be converted to regular leave standing at the credit on
the date on which the study leave commenced, any regular leave taken in continuation of study leave
being suitably adjusted for the purpose and the balance of the period of study leave, if any, which
cannot be so converted, treated as extraordinary leave. In addition to the amount to be refunded by
the Government servant under sub-Rule (1), he shall be required to refund any excess of leave-salary
actually drawn over the leave-salary admissible on conversion of the study leave.(3)Notwithstanding
anything contained in the rule, the Governor may, if it is necessary or expedient to do so either in
public interest or having regard to the peculiar circumstances of the case or class of cases, by order,
waive or reduce the amount required to be refunded under sub-Rule (1) by the Government servant
concerned or class of Government servants.
10. Leave-salary during study leave. - (1) During study leave a Government
servant shall draw leave-salary admissible during half pay leave under Rule
15 of the Leave Rules, 1934.
(2)The Government servants to whom the leave rules in the Fundamental Rules apply will draw half
average pay as defined in Rule 9 (2) of the Fundamental Rules subject to the maxima and minima
laid down in Rr. 89 and 90, ibid.
11. Counting of study leave or promotion, seniority, leave and increment. - (1)
Study leave shall count as service for promotion, pension, seniority and
increments : provided that in the case of a Government servant who, at the
time of proceeding on study leave was officiating in a higher post, studyFundamental Rules and Subsidiary Rules

leave count for increments to the extent indicated by Government from time
to time.
(2)The period spent on study leave shall not count for leave other than half pay leave under Rule 13
(a) of the Leave Rules, 1934.(3)In the case of Government servants to whom the leave in the
Fundamental Rules apply study leave will not count as service for leave. It will not affect any leave
which may already be due to a Government servant; it will count as extra leave on half average pay,
and will not be taken into account in reckoning the aggregate amount of leave on half average pay
taken by Government servants towards maximum period admissible under the Fundamental Rules.
12. Cancellation of study leave. - If the selected candidate commits breach of
any provision of these rules or fails to join the place of study or training
within the prescribed period or discontinues the course of study for which
leave is granted or is re-called or sent back for misconduct his leave shall be
cancelled, and the provision of Rule 9 shall apply to the extent indicated by
Government in the order cancelling the study leave :
Provided that the Government may authorise continuance of study leave in any case in which they
are satisfied that the candidate discontinued the study or training or failed to join the place of study
or training within the prescribed limit on account of illness or for any other cause beyond his
control.
13. Procedure for making application for study leave and grant of such leave.
- The procedure for making application for study leave and grant of such
leave shall be as laid down in the procedural instructions given in Appendix
'B' annexed to these rules.
Appendix A[See Rule 8]I. Bond to be executed by permanent Government servant proceeding on
Study LeaveKnow all men by these presents that I............resident of.........in the District of........at
present employed as......in the Department of/office of the..............do hereby bind myself, my heirs,
executors and administrators to pay to the Governor of Assam (hereinafer referred to as
"Government") on demand and without demur the sum of Rs...............(Rupees.....) together with
interest thereon from the date of demand at Government rates for the time being in force on
Government loans or, if payment is made in a country other than India, the equivalent of the said
amount in the currency of that country converted to official rate of exchange between that country
and India and together with all costs between authority and client and all charges and expenses that
shall and may have been incurred by the Government.Dated this......... day of........ two thousand
and.........Whereas the above bounden...........is granted study leave by Government;And whereas for
the better production of the Government the above bounden has agreed to execute the bond with
such condition as hereunder is written ;Now the condition of the above written obligation is that in
the event of the above bounden...... interrupting his course of study of training to suit his own
convenience or changing the programme of study or training approved from time to time, orFundamental Rules and Subsidiary Rules

resigning or retiring from service without returning to duty after the expiry or termination of the
period of study leave or any time within a period of three years after his return to duty he shall
forthwith pay to the Government on demand and without demur the said sum of Rs........
(Rupees..........) together with interest thereon from the date of demand at Government rates for the
time being in force on Government loans ;And upon the above bounden........ making such payment
the above written obligation shall be void and of no effect, otherwise it shall be and remain in full
force and virtue.Stamp duty payable on this bond shall be borne and paid by Government.Signed
and delivered by the above bounden........ in the presence of......Accepted for and on behalf of the
Government of AssamII. Bond for temporary Government servants proceeding on Study LeaveKnow
all men by these presents that we...........resident of........in the district of.........at present employed
as........ in the Department of/office of the.......(hereinafter referred to as "the obligor") and Shri......
son of....... of and Shri...........son of...............of............sureties on his behalf do hereby jointly and
severally bind ourselves, our respective heirs, executors and administrators to the Governor of
Assam (hereinafter referred to as "the Government") on demand and without demur the sum of
Rs....... (Rupees.........) together with interest thereon from the date of demand at Government rates
for the time being in force on Government loans or if, payment is made in a country other than
India, the equivalent of the said amount in the currency of that country converted at the official rate
of exchange between that country and India and together with all costs between attorney and client
and all charges expenses that shall or may have been incurred by the Government.Dated
this........day of....... two thousand and............Whereas the above bounden........ is granted study leave
by the Government;And whereas for the better protection of Government the above bounden has
agreed to execute this bond with such condition as hereunder is written ;And whereas the
said.........and........have agreed to execute this bond as sureties on behalf of the above
bounden..........;Now the conditions of the above written obligation is that in the event of the above
bounden..............interrupting his course of study or training to suit his own convenience or
changing the programme of study approved from time to time or resigning or retiring from service
returning to duty or training after the expiry or termination of the period of study leave or at any
time within a period of three years after his return to duty he shall forthwith pay to Government on
demand and without demur the said sum of Rs....... (Rupees...............) together with interest from
the date of demand at Government rates for the time being in force on Government loan ;And upon
the above bounden obligor Shri............and/or Shri................and/or Shri.............the sureties
aforesaid making such payment the above written obligation shall be void and of no effect otherwise
it shall be and remain in full force and virtue :Provided always that the liability of the sureties
hereunder shall not be impaired or discharged by reason of time being granted or by any
forbearance act or omission of the Government or any person authorised by them (whether with or
without the consent or knowledge of the sureties) nor shall it be necessary for the Government to see
the said obligor before suing the above bounden sureties Shri........ and Shri.........or any of them for
amounts due hereunder.Stamp duty payable on this bond shall be borne and paid by
Government.Signed and delivered by the above bounden in the presence of........Signed and
delivered by the surety above named....... in the presence of........Signed and delivered by the surety
above named........ in the presence of.....Accepted for and on behalf ofthe Government of
AssamAppendix B[See Rule 13]Procedural Instructions for making application for Study Leave and
grant of such LeaveFundamental Rules and Subsidiary Rules

1. The Administrative Departments shall draw up a definite programme of
courses of study or training including the number of persons to be trained in
each course in consultation with the Planning and Development and Finance
Departments. The programme may be revised from time to time.
2. All applications for study leave shall be submitted in the form prescribed
in Schedule I to the this Appendix with the Audit Officer's certificate to
Government through proper channel. If the course of study is out of India,
Government shall forward to the Head of the India Mission in that Country if
there is such a Mission in that country, a copy of the approved programme of
study or training. In a case where it is not possible for the Government
servant to give full details in his original application, or if, after leaving India
he is to make any change in the programme which has been approved in
India, he shall submit the particulars as soon as possible to the Head of the
Indian Mission or the Government, as the case may be. In such cases he
shall not, unless prepared to do at his own risk, commence the courses of
study or training nor incur any expenses in connection therewith until he
receives approval of Government to the course which may include any
programme of tour also.
3.
(1)On an application for study leave out of India being sanctioned by Government, it shall inform
the Head of the India Mission, if there is such a Mission in that country of the particulars of the
case.(2)The Government servant shall also place himself in communication with the Head of India
Mission (if there is such a Mission in that country) who will arrange any details and issue any letter
of introduction that may be required.
4. The continuation of study leave will depend on the satisfactory progress
and favourable report from the Head of the Institution in which the
Government servant is prosecuting studies or receiving training. Such report
shall be called for at least once a year by the Administrative Department.
5. On completion of a course of study or training a certificate in proper form
together with certificate of examination passed or special course of study or
training undertaken, indicating the dates of commencement and termination
of the course with remarks, if any, of the authority in the charge of course of
study or training, shall be forwarded to the Head of the India MissionFundamental Rules and Subsidiary Rules

concerned. When the study leave has been taken in India or any other
country where there is no India Mission such certificate shall be forwarded to
the Government which sanctioned the study leave.
I
Form to be used by Government servants in making application for Study Leave
1. Name of full......
2. Father's name in full and present address......
3. Post held.......
4. Pay and allowances drawn in the present post (indicate special pay, if any,
separately)............
5. Educational qualifications together with School/College/University
certificates (attested copies) and the subjects studied in the Intermediate,
degree and Post Graduate examinations....................
6. Other special qualifications (Give full particulars)......
7. The period of continuous service under Government.............
8. Age on the 1st January (According to Matric or any other equivalent
certificate. Attach attested copy)........
9. Have you taken study leave previously (If yes, give full particulars of the
total period of leave taken so far, the courses of study or training undertaken
and examination or examinations passed)................
10. Course of study/training and examination, if any, proposed to be
undertaken.............
(Give full details of the programme of the study/training showing its duration as also the name of
the country and the institution in which it is proposed to be undertaken)..........The facts stated above
are true to the best of my knowledge and belief. In case of any false statement, I am liable to any
action Government may deem fit and proper.Signature of the applicantDated.......To be used by the
Administrative DepartmentFundamental Rules and Subsidiary Rules

1. Whether the courses of higher study/specialised training has a direct and
close connection with sphere of duty of the Government servant and shall be
definite advantage from the point of view of public interest..........
2. Whether it will be possible to spare the services of the Government
servant for the duration of study leave without creating cadre
difficulties.........
3. (a) Whether the application is for leave out of India. If so, whether a
certificate of admissibility has been obtained from the Audit Officer............
(b)If the application is for leave in India, whether Audit Officer's certificate has been obtained in
respect of Gazetted Government servants. In the case of non-Gazetted Government servants the
appointing authority's certificate as to the admissibility of the leave be obtained.......
4. Whether adequate facilities exist in India or under any of the schemes
administered by the State Government or the Government of India for the
study/training contemplated..........
5. Whether all the conditions of Rule 3 of the Assam Study Rules, 1963 have
been fulfilled .......
6. Any special remark as to ability of the candidate........
Secretary to the Governmentin the...........DepartmentAppendix A-1[See Rule 8]I. Bond for
permanent Government servants granted extension of Study LeaveKnow all men by these present
that I....... resident of...... in the District of..........at present employed as..............in the
Department/office of the.........do hereby bind myself and my heirs, executors and administrators to
the Governor of Assam (hereinafter called "the Government") on the demand the sum of Rs.........
(Rupees........) together with interest thereon from the date of demand at Government rates for the
time being in force on Government loans or, if payment is made in a country other than India, the
equivalent of the said amount in the currency of that country converted at the official rate of
exchange between that country and India and together with all costs between attorney and client
and all charges and expenses that shall or may have been incurred by the Government.Signed and
dated this........ day of.........two thousand and.........Whereas I......... was granted study leave by
Government for the period from.......... in consideration of which I executed a bond dated.......for
Rs........ (Rupees...........) in favour of the Government of Assam ;And whereas the extension of study
leave has been granted to me at my request until........;And whereas for the better protection of the
Government, I have agreed to execute this bond with such condition as hereunder is written ;Now
the condition of the above written obligation is that in the event of my resigning or returning from
service without returning to duty after the expiry or termination of the period of study leave soFundamental Rules and Subsidiary Rules

extended or any time within a period of three years after my return to duty I shall forthwith pay to
the Government or as may be directed by the Government or. demand the said sum of Rs............
(Rupees.........) together with interest thereon from the date of demand at Government rates for the
time being in force on Government loans.And upon my making such payment the above written
obligation shall be void and of no effect otherwise it shall be and remain in full force and virtue.The
Government of Assam have agreed to bear the stamp duty payable on this bond.Signed and
delivered by............in the presence ofWitnesses(1)(2)Accepted for and on behalf of the Governor of
Assam.II. Bond for temporary Government servants granted extension of Study LeaveKnow all men
by these present that we.........resident of........in the district of..........at present employed as..........in
the Department/office of the.......... (hereinafter called "the obligor") and Shri........ son
of.............of......and Shri..........son of.......... of..........(hereinafter called the "sureties") do hereby
jointly and severally bind ourselves and our respective heirs, executors and administrators to pay to
the Governor of Assam (hereinafter called "the Government") on demand the sum of
Rs........(Rupees...........) together with interest thereon from the date of demand at Government rates
for the time being in force on Government loans or, if payment is made in a country other than
India, the equivalent of the said amount in the currency of that country converted at the official rate
of exchange between that country and India and together with all costs between attorney and client
and all charges and expenses that shall or may have been incurred by the Government.Signed and
dated this.........day of.........two thousand and..........Whereas the obligor was granted study leave by
the Government for the period from ...........to..........in consideration of which he executed a bond
dated............ for Rs........Rupees..........) in favour of the Governor of Assam ;And whereas the
extension of study leave has been granted to the obligor at his request until..........;And whereas for
the better protection of the Government the obligor has agreed to execute this bond with such
condition as hereunder is written ;And whereas the said sureties have agreed to executive this bond
as sureties on behalf of the above bounden...............;Now the condition of the above written
obligation is that in the event of the obligor Shri...........resigning from service without returning to
duty after the expiry or termination of the period of study leave so extended or at any time within a
period of three years after his return to duty the obligor and the sureties shall forthwith pay to the
Government or as may be directed by the Government on demand the said sum of
Rs...........(Rupees............) together with interest thereon from the date of demand at Government
rates for the time being in force on Government loans ;And upon the obligor
Shri............and/or...........Shri..........and/or Shri.................the sureties aforesaid making such
payment the above written obligation shall be void and of no effect otherwise it shall be and remain
in full force and virtue :Provided always that the liability of the sureties hereunder shall not be
impaired or discharged by reason for the time being granted or by any forbearance act or omission
of the Government or any person authorised by them (whether with or without the consent or
knowledge of the sureties) nor shall it be necessary for the Government to sue the obligor before
suing the sureties Shri...........and Shri......... or any of them for amounts due hereunder.The
Government of the Assam have agreed to bear the stamp duty payable on this bond.In witness
whereof..............the Government servant above named has signed these presents, the day, month
and year first abovewritten.Signed, sealed and delivered by in the presence of-Fundamental Rules and Subsidiary Rules

1.
2.
Accepted for and on behalf ofthe Government of Assam by.......Appendix 15
Part II – Regulations prescribed under F.R. 84 regarding the
grant of study leave to Officers of the Indian Medical Service
who are subject to the Leave Rules under Sections I to V of
Chapter X of the Fundamental Rules and Assam Subsidiary
Rules (Second Edition) 1939
[Not Printed]Appendix 15
Part III – Legal Studies Rules
[Not Printed]Appendix 16[F.R. 91 (4)]List of British Dominions and Colonies in which Leave-salary
may be drawn in SterlingThe Secretary of State has prescribed that leave-salary may be drawn in
sterling in the following British Dominions and Colonies :
Dominion, Colony or Protectrate,
etc.Designation of Paying Officer
Bahamas Receiver General, Nassau.
Barbados (and all other West India
Island except Jamaica)Colonial Treasurer, Barbados.
Bermuda Command Paymaster, Army Pay Office, Bermuda.
British Guiana Colonial Secretary, Georgetown.
British Honduras Treasurer, Belize.
Egypt Command Paymaster Army Pay Office, Cairo.
Falkland Islands Treasurer, Stanely.
Fiji Colonial Treasurer, Suva.
Gambia Treasurer, Bathurst.
Gibralter Command Paymaster, Army Pay Office, Gibralter.
Gold Coast Treasurer, Accra.
Jamaica Command Paymaster, Army Pay Office Jamaica.
Kenya Treasurer, Nairobi.
Malta Command Paymaster, Army Pay Office, Malta.
MauritiusFundamental Rules and Subsidiary Rules

Command Paymaster, Army Pay Office, Mauritius or
ColonialSecretary, Port Louis.
New South Wales[***] [Substituted vide Correction No. 220 [Reference FA
10/44] Deputy Commissioner of Pensions, Department of
Social Service, Commonwealth Bank Buildings, Pitt Street
Sydney.]
New Zealand Commissioner of Pension, Wellington.
Nigeria Treasurer, Lagos.
Northern Rhodesia The Treasurer, Livingstone.
Nayasaland Treasurer Nayasaland Protectorate Zomba.
Queensland[Deputy Commissioner of Pensions Department of Social
Service,Commonwealth Government Offices, Adelaide Street
Brisbane.] [Substituted vide Correction Slip No. 220 [Reference
FA 10/44].]
St. Helena Colonial Treasurer, St. Helena.
Sierra Leone Command Paymaster, Army Pay Office, Sierra Leone.
Somaliland Treasurer, Somaliland Protectorate, Berbora.
South Australia[Deputy Commissioner of Pensions, Department of
SocialService, 41, King William Street, Adelaide.] [Substituted
vide Correction Slip No. 220 [Reference FA 10/44].]
South Rhodesia Treasurer, Salisbury.
Tanganyika Treasurer, Dar-es-Salaam.
TasmaniaDeputy Commissioner of Pensions, Department of Social
Service,Collins Street, Hobart.
Uganda Treasurer, Entebbe.
The Secretary for Finance, the
Treasury PretoriaChief Pension Officer, Pretoria.
VictoriaDeputy Commissioner of Pensions, Department of Social
Service,118, Queens Street, Melbourne.
Western AustraliaDeputy Commissioner of Pensions, Department of Social
Service,C/o, G.P.O., Perth.
The Seychelles Island Treasurer Seychelles Islands.
Appendix 17[F.Rr. 103 and 104 in Section II]
Part I – Model leave terms for officers of non-Asiatic domicile
engaged on contract
Government of India's decision. - In any case where the contract provides for admission to the
special or the ordinary leave rules in the Fundamental Rules the condition as well as the terms of the
Fundamental Rules should apply in their entirety in supersession of any concessions under theFundamental Rules and Subsidiary Rules

model leave terms.Note. The terms in this Part will apply only to officers of non-Asiatic domicile,
who are specially recruited overseas for service in India, till they are revised in accordance with the
leave terms that may be prescribed in future for new entrants to the services under the rule-making
control of the Secretary of State.Approved by the Secretary of State in Council(1)Where the contract
is for one year or less, no leave except on medical certificate (on average or on half average pay),
which would ordinarily be limited to two months reckoned in terms of leave on average
pay.(2)Where the contract is for more than one year and less than three years, leave on average pay
up to 1/11th of the period spent on duty, to which may be added on medical certificate leave on
average or half average pay ; provided that the total leave granted shall not exceed three months
reckoned in terms of leave on average pay.(3)Where the contract is for three years or over, leave on
average pay up to 1/11th of the period spent on duty, up to a maximum of four months at a time, to
which may be added on medical certificate leave on average or half average pay up to a maximum of
three months reckoned in terms of leave on average pay.In the case of officers coming under Rr. (2)
and (3)-(a)three months' extraordinary leave without pay may be granted in addition to the above,
and(b)if the officer is in a Vacation Department, leave may only be granted in case of necessity and if
granted shall be on half average pay for a period not exceeding 1/11th of the period spent on duty in
addition to any leave admissible on medical certificate. The officer may, however, be granted leave
on leave-salary equivalent to average pay, to the extent of one month for each year on duty in which
he has not availed himself of any part of a vacation and if a part only of the vacation taken has been
taken in any year, the period of leave on average pay will be reduced by the fraction of month equal
to the proportion which the part of the vacation taken bears to the full period of the vacation.In the
case where-(a)the contract is for a longer term than 5 years, or(b)an original contract for 5 years is
extended, or(c)on completion of his original contract of whatever term, a Government servant is
taken into permanent employment,the ordinary or special leave rules, as the case may be, as
contained in the Fundamental Rules, will be made applicable.Leave may be granted after the expiry
of contract only where it has been applied for during the period of the contract and refused owing to
the exigencies of the public service.An officer whose services are dispensed with on grounds of
ill-health shall be permitted to take all leave due to him before the services are terminated.Note. The
principle that leave may be granted after the expiry of contract where it has been applied for during
the period of the contract and refused owing to exigencies of the public service is applicable also to
officer serving on contract at the time the model leave terms were promulgated.Government of
India's decision. - [(1) In the case of a Government servant whose leave is regulated by Rr. (2) and
(3) of the Model Leave Terms the position is that though leave on medical certificate as such, cannot
be taken except in supplement of ordinary leave on average pay earned by duty, there is nothing to
prevent him from taking ordinary leave on medical grounds, that is, leave on average pay should be
consumed first whether it is on medical certificate or otherwise and second that the additional leave
on medical certificate subject to the limitations prescribed in the relevant rules of Model Leave
Terms can be granted only in continuation of the leave on average pay or when no such leave is
admissible.(2)In the case of a contract officer to whom the terms is the Appendix apply and who
becomes eligible for the leave rules in the Fundamental Rules under those terms, the period of "plus
on year" of leave on average pay prescribed in F.R. 81 (b) (i) will be credited in his leave account in
full or with a proportionate reduction according to the length of his prospective contract service. For
this purpose the credit will be calculated on the following principles :At the point from which the
officer becomes eligible for the leave rules in the Fundamental Rules, he will be credited, subject toFundamental Rules and Subsidiary Rules

the maximum period of one year-(i)with half a month for each year by which the period of contract
original or extended, exceeds 5 years from first appointment ; provided that where the contract is for
an indefinite period the credit will be given successively for a quinquenium at the time, and that in
no case shall leave be admissible out of this credit during the first five years of the contract service ;
or(ii)where an extended contract for permanent non- pensionable service with half a month for each
year of the difference between the age, next birthday after the completion of the first 5 years of the
contract service and age 55. The decision will apply to all future contracts and extensions of the
original contracts beyond five years.]
Part II – The following leave terms are prescribed to regulate the
grant of leave to officers of non-Asiatic domicile engaged on
contract but not specially recruited overseas for service in India
:
(1)Where the contract is for one year or less, earned leave admissible will be at one-twenty-second of
the period spent on duty. Though ranking as earned leave, this may be granted only on medical
certificate, and if subsequently it becomes necessary to grant the officer further leave after the
earned leave has been exhausted, leave on medical certificate may be granted to him subject to the
condition that the total period of the two kinds of leave does not exceed 1/11th of the period spent on
duty.If the officer serves in a Vacation Department, earned leave will not be admissible but he may
be granted, if absolutely necessary, leave on medical certificate to the extent of 1/22nd of the period
spent on duty.(2)Where the contract is for more than one year but not more than five years, leave on
medical certificate may be allowed in addition to earned leave under R. 10 (a) of the Leave Rules,
1934 (Appendix 11-Part I), subject to a maximum of four months in all during the period of contract.
In addition, extraordinary leave may be granted in special all circumstances when no other leave is
admissible subject to a total maximum limit of 3 months in respect of such leave.If the officer serves
in a Vacation Department, earned leave will not be admissible.(3)Where the contract is for a longer
term than five years or an original contract for five years or less is extended so as to make the total
period of contract longer than five years leave admissible to a permanent Government servant under
the Leave Rules, 1934 (Appendix 11-Part I), may be allowed, subject to the restrictions that no leave
on private affairs will be granted and that the leave on medical certificate will be limited to six
months in all. In the case of extension of contract to a period longer than 5 years the officer will be
credited with the earned leave that would have been admissible had the contract been initially one
for more than five years diminished by any earned leave already taken, and leave on medical
certificate, if any, already taken, will count against the six months' limit prescribed.(4)Where the
contract is for an indefinite period, or an original contract for a definite period, is extended for an
indefinite period, the leave rules for permanent Government servants in the Leave Rules, 1934
(Appendix 11-Part I), except Rule 16 of those rules regulating leave-salary, will be made applicable.
In the latter case the officer will be credited with the earned leave that would have been admissible
had the contract been initially one for an indefinite period diminished by any earned leave already
taken and leave on medical certificate, if any already taken, will count against the limit prescribed in
Rule 14 of the Leave Rules, 1934 (Appendix 11-Part I).(5)In the case of an officer falling under Cl. (2)Fundamental Rules and Subsidiary Rules

above earned leave may be grated after the expiry of the contract only when it has been applied for
during the period of the contract and refused owing to the exigencies of the public service. An officer
whose services are dispensed with on grounds of ill-health may be permitted to take all leave due to
him before his service is terminated.(6)The terms 'earned leave', 'leave on medical certificate' and
'leave on private affairs' used in above clauses have the same meaning as that signed to them in the
Leave Rules, 1934 (Appendix 11-Part I). The leave-salary during leave taken under the above classes
will be regulated as follows :(i)An officer on earned leave is entitled to leave- salary equal to his
average pay.(ii)An officer on leave on private affairs or on medical certificate is entitled to
leave-salary equal to his average pay subject in either case to a maximum of Rs. 750.Note. "Average
pay" means the average monthly pay earned during the 12 complete months preceding the month in
which the event occurs which necessitates the calculation of average pay.(iii)An officer on
extraordinary leave is not entitled to any leave-salary.(7)An officer initially engaged on contract
becomes subject to the Leave Rules, 1934 (Appendix 11-Part I), in their entirety on his being taken
into permanent employ after the expiry of his contract. In such a case the officer will be credited
with the earned leave that would have been admissible had his previous duty been duty as an officer
in permanent employ diminished by any earned leave already taken and leave on medical certificate,
if any, already taken, will count against the limit prescribed in Rule 14 of the Leave Rules, 1934
(Appendix 11-Part I).
Part III – The leave terms admissible to officers of Asiatic
domicile engaged on contract whether in India or abroad will be
those laid down in S.R. 127. In the case of those engaged on or
after the 1st March, 1934, the leave terms will be those
prescribed on the Leave Rules, 1934 (Appendix 11-Part I), for
"officers not in permanent employ".
Part IV – Model passage terms for non-superior officer of
non-Asiatic domicile recruited on or after the 1st February, 1935
in the United Kingdom on contract for definite period
I. 'Family' shall except where passages are allowed on the lines and conditions laid down in Schedule
IV of the Superior Civil Services Rules, include a wife and legitimate children who are wholly
dependent on the employee, the term 'children' meaning unmarried sons and step-sons under the
age of 16 and daughters and step daughters under the age of 21.II. 'Passage' shall, except when
granted on the lines and conditions laid down in Schedule IV to the Superior Civil Services Rules,
include-(i)a tourist class passage of the appropriate grade or the cheapest cabin or second class
passage by the all-sea route whichever costs less and is available at the time the journey is
performed (the passage shall preferably be booked by the steamers of the P. and O., British India or
the Orient Steam Navigation Companies, if this course is possible); and(ii) (a)third class railway fare
from the employee's home or usual place of residence to the port of embarkation and vice versa, plusFundamental Rules and Subsidiary Rules

the following allowances for incidental expenses-(i) 15 s. for the employee travelling alone, and (ii)
if, steamer accommodation is provided for his family under these terms, 20 s. for the employee
travelling with his wife and children, 15 s. for his wife travelling alone, and 20 s. wife for his wife
accompanied by children ;(b)a free railway pass (or an allowance in lieu thereof) and free
conveyance of baggage up to a limit of 5 maunds for the journey from the port of disembarkation in
India to his station and vice versa plus the following allowances for incidental expenses :(i)Rs. 20 for
the employee travelling alone or with his wife and children; and(ii)if steamer accommodation is
provided for his family under these terms, Rs. 15 for his wife travelling alone, and Rs. 20 for his wife
accompanied by children ;(c)a mileage allowance is India at the rate laid down for the time being by
Government, for each person for whom steamer accommodation is provided under these terms, for
such journeys by road as may be necessary; and(d)a halting allowance in India at the rate laid down
for the time being by Government, for each person for whom steamer accommodation is provided
under these terms, for every day, if detained under orders at the report of disembarkation or
elsewhere.[Government of India's decision. - The halting allowance admissible should be allowed on
the following scales :(a)at the full rate admissible to the officer for himself and for each member of
his family other than a child mentioned in Cl. (b);(b)at half the rate for child over one year but below
12 years of age ; and(c)an allowance for children of the age of one year and under.The rate of halting
allowance should be determined with reference to the Officer's grade under the Government of India
Supplementary Rule 17, Assam Subsidiary Rule 133 on the basis of his pay on first joining duty in
India.] [Added vide Correction Slip No. 234 to Assam Subsidiary Rules]III. An employee engaged on
a contract for a definite period shall be granted-(1)a passage to India on his proceeding to join his
appointment; and(2)a passage back from India on the expiry of the period of contract, or on his
proceeding on leave immediately prior thereto, or on the termination of the contract by Government
for any reason other than misconduct or failure to comply with the provisions of the contract ;
provided that the employee's service is regarded as satisfactory ; and provided further that he
actually quits the service in India and leaves India within such time as the Government may
direct.IV. An employee whose period of contract, original or extended, does not exceed three years
shall not be entitled to any passages for his family ; nor shall he be entitled to any passage for
himself in addition to those mentioned in Term III.V. (A) An employee whose period of contract,
original or extended, exceed three but not seven years shall, in addition to the initial and final
passages for himself admissible under Term III, be granted-(1)Passage to India for-(a)the members
of his family existing at the time of his engagement if the period of the original contract exceeds
three years, or at the time his contract is extended beyond three years, as the case may be, they are
not already in India at that time ; provided that their journey to India is performed within one year
of the commencement of contract or within one year of the date of extension of his contract beyond
three years, as the case may be ;(b)his wife if he entered service as a bachelor but married which in
the United Kingdom on leave ; and(c)his intended wife when proceeding to India to marry him
:Provided that an employee who has been granted a passage to India for his wife or intended wife
under this Term shall not be granted a second passage if he re-marries, but he shall be granted for
his second wife any concession which were available to, but were not utilised by, his first wife ;
and(2)Passages back from India for his family ; provided that the employee himself is allowed a
passage back from India under Term III (2) and his family either accompanies him or leaves India
not more than one year before the date of his own departure therefrom. If the family preceds the
employee, he shall be liable to repay to Government the cost of passages provided for his familyFundamental Rules and Subsidiary Rules

under this sub-term should he after their departure, forfeit his title to a passage back from India for
himself admissible under Term III (2).(B)Save as otherwise provided in this sub-term, in addition to
the above passages if the period of contract original or extended, exceeds five but not seven years,
the employee shall be granted, once during the period of his contract, return passages from and to
India for himself and his family if he proceeds on leave on medical certificate during that period.
The passages for the family shall be admissible whether they accompany him or precede or follow
him within a time fixed by Government.The passage from India for the family shall be treated as the
final passage admissible to them under these Terms unless the employee has, at the expiry of his
leave, still more than two years of the period of his contract to service. If after his return from leave
he requires another passage for himself on medical grounds, it shall be granted as his final passage
back from India.VI. The final and leave passages taken under Term III (2) V (A) (2) and V (B) may
be between India and the United Kingdom or any other country : provided in the latter case the cost
of passage shall not exceed the cost of passage between India and the United Kingdom.VII. An
employee whose period of contract, original or extended, exceeds seven years, or who, having been
originally engaged on contract for less than seven years is retained either in permanent service or on
contract for an indefinite period, shall in addition to the initial passages for himself and his family
under Terms III (I) and V (A) (I), be entitled to the passage benefits for non-superior officers of
non-Asiatic domicile announced in the Government of India, Home Department Office
Memorandum No. F. 10/4/30, Estts., dated 6th August, 1930 (see at the end of Term (IX) :(i)from
the commencement of his service if the has been initially engaged for a period of more than seven
years, or(ii)from the date of his retention in service for a period in excess of seven years, or from the
date of retention in permanent service or on contract for an indefinite period if he was originally
engaged for a period of less than seven years. The number of passages admissible to him for himself,
his wife and children, shall be calculated with reference to the date of the first appointment on
contract and the cost of the following passages [inclusive of the cost of the concessions provided for
in Term II (ii)] taken under these Terms shall be debited to the passage accounts of the respective
beneficiaries:(1)passages for himself during leave on medical certificate under Term V (B),
and(2)passages for such members of his family as are admitted to the non-superior passage
concessions-(a)during his leave on medical certificate under Term V (B), or(b)in anticipation of
termination of contract under Term V (A), in cases in which the contract is subsequently extended to
exceed seven years, or he is retained in permanent service or on contract for an indefinite
period.VIII. Passages from India to the United Kingdom or any other country shall be granted to the
family of an employee who dies whilst in service if he happens to be in India at the time of his death
; provided that the cost of passage to a country other than the United Kingdom shall not exceed the
cost of passage to the United Kingdom.IX. A female employee shall not be granted for her family the
benefits admissible to a male employee for his family, and a female employee whose service is
terminated by marriage shall not thereafter be granted any benefits hitherto admissible to her under
these terms:(1)The Secretary of State for India in Council has been pleased to sanction the grant
with effect from 1st April, 1930 to persons of non-Asiatic domicile recruited outside, passage
benefits for themselves and their families on the lines and conditions laid down in Schedule IV to
the Superior Services Rules, but substituting second class B for 1st class B., P. and O. passages. The
benefits will be admissible to the following classes of personnel:(i)persons recruited outside India
for permanent service in India ;(ii)persons recruited outside India on contract and retained in
permanent service on expiry of the periods of their contracts ; and(iii)persons recruited outsideFundamental Rules and Subsidiary Rules

India on contracts for indefinite periods or on contracts for periods subsequently extended
indefinitely ;and will be in addition to the initial passages granted to join their first appointments in
India.(2)It is the intention that persons to whom the Passage (Subordinate) Rules, 1925, apply the
periods of their original contracts should continue to be entitled to the benefits of those Rules even
during the periods of their further service under Government whether permanent or temporary, and
it is proposed to amend the Rules with retrospective effect from the date of their first introduction,
viz., the 24th November, 1925, so as to make the intention clear. This being so, persons belonging to
classes (ii) and (iii) mentioned above, to whom those rules apply will be given the option between
the benefits admissible to them under those rules and the benefits described in this Memorandum.
The option once exercised will be final.(3)The Secretary of State has also sanctioned with effect from
1st April, 1930 passage benefits for themselves and their families on lines and conditions laid down
in Schedule IV to the Superior Civil Services Rules, the substituting second class B for 1st class B.P.
and O. and passages to persons of non-Asiatic domicile required in India because Indians with the
necessary qualifications were not available at the time or it was considered necessary from the
administrative point of view to have a certain proportion of Europeans. Ex-Military men now in the
service under the Army Department other than E-Military clerks at Army Headquarters who already
received passage concessions will assume to fall under this category.Appendix 18[Fundamental Rule
103 (c) and the 'N.B.' above Subsidiary Rule 132 in Section II]
1. The rules in the Schedule to these rules may be called the Leave Rules for
Press Employees, 1934.
2. The rules shall apply with effect from the 1st March, 1934 to permanent
piece-workers employed in the Assam Government Press whose service is
classified as superior and who belong to the classes of persons enumerated
in Rule 2 of the Leave Rules, 1934 (Appendix 11-Part I).
3. 'Leave on medical certificate' and 'injury leave' admissible under the rules
in Schedule to these rules are not cumulative, i.e., an employee cannot have
'leave on medical certificate' for more than 12 months or 'injury leave'
exceeding 5 years during his whole service.
Schedule 4
1. (a) Leave on full pay will be granted to piece workers according to their
service as shown below :
Length of Service Leave admissible
Less than 10 years 16 days in each calendar year.
10 years but less than 15 years 23 in each calendar year.
15 years and above 31 in each calendar year.Fundamental Rules and Subsidiary Rules

Note. In calculating the length of service, the period of continuous temporary service rendered by
piece-worker up to the date of his being brought on to the permanent establishment as well as
continuous inferior service rendered up to the date of his promotion to superior service shall be
taken into account.(b)This leave will be non-cumulative, i.e., any leave not taken during the year will
lapse without any monetary compensation.(c)Gazetted holidays actually enjoyed, at the option of
the piece-worker, be counted against any leave admissible to him under sub-Rule (a) and if so
counted, will be paid for.(d)Leave under these rules cannot be claimed as of right, and can be
refused by the Superintendent of the Press on administrative grounds. It may also be withheld from
piece- workers who have been irregular in attendance.
2. Leave on medical certificate on half pay may be granted up to 3 months
when no leave on full pay is admissible and a further extension of such leave
not exceeding 3 months may be granted on the production of a fresh medical
certificate from a medical authority specified in the rules framed under F.R.
74. The total amount of leave on medical certificate admissible to a
piece-worker during his service shall not exceed 12 months.
3. Extraordinary leave may be granted when no other leave is admissible, or
when other leave being admissible, the piece- worker applies in writing for
this leave. A piece-worker on extraordinary leave is not entitled to any
leave-salary.
4. Injury leave at half pay rates may be granted to a piece- worker who is
injured in circumstances which would have given arise to a claim for
compensation under the Workmen's Compensation Act, 1923 (8 of 1923),
[Now Employee's Compensation Act, 1923] if he had been a workman as
defined therein, whether or not proviso (a) to sub-Section (1) of Section 3 of
that Act is applicable. Such leave shall not be deemed to be leave on medical
certificate for the purposes of Rule 2. It shall be granted from the
commencement of disablement for so long as is necessary, subject to a limit
of two years for any one disability and a limit of five years during a piece-
worker's total service. The salary payable in respect of a period of leave
granted under this rule shall, in the case of a piece-worker to whom the
provisions of the Workmen's Compensation Act, 1923 (8 of 1923), apply, be
reduced by the amount of compensation paid under Clause (d) of
sub-Section (1) of Section 4 of that Act.
Note 1. Payment of remuneration at class rates at the time of taking leave. - The calculation is class
rate multiplied by 8, to get the daily rate, multiplied by the number of day's leave. Thus, if aFundamental Rules and Subsidiary Rules

piece-worker whose class rate is 2 annas per hour applies for leave for 10 days, he will be entitled to
Rs. 10 during leave on full pay and to Rs. 5 during leave on half pay.[* * * *] [Omitted vide
Correction Slip No. 40 to Assam Subsidiary Rules (Second Edition) 1939. This takes effect from 1st
April, 1940.]Note 2. For the purpose of determining the classification of service of piece-worker who
may be in superior service in one month and in inferior service to another month on account of
fluctuations in his earnings, the monthly emoluments shall be taken as equivalent to [one hundred
and seventy-five] [Added vide Correction Slip No. 40 to Assam Subsidiary Rules (Second Edition)
1939. This takes effect from 1st April, 1940.] his hourly class rate.Note 3. The above rules will also
apply to temporary piece- workers is superior service who have rendered three years' continuous
service.Note 4. (a) Leave for 16 days each year at class rates may be given to temporary
piece-workers [in superior service] [Added vide Correction Slip No. 243 to Assam Subsidiary Rules
(Second edition) 1939.] with less than three years' continuous service [and to piece-workers in
inferior service, whether permanent or temporary] [Added vide Correction Slip No. 243 to Assam
Subsidiary Rules (Second Edition) 1939.] cover absence on account of holidays, sickness or leave ;
provided that the worker has been in regular employment for the previous twelve months.(b)The
term 'regular employment' shall be interpreted as not less than 90 per cent of the required working
hours ; regard should be had to absence in case of sickness.(c)The leave shall be non-cumulative,
i.e., any leave not taken during the year shall lapse.Appendix 19[F.R. 114]Orders relating to transfer
of a Government servant to the service of an Indian State[State Representative's] [In place of the
words 'Government of India'.] orders regulating the amount of the pay which may be sanctioned by
a State Government for a Government servant transferred to foreign service in an Indian State. -
These orders apply also to Government servants lent to other foreign employers in India.
1. When the transfer of a Government servant to foreign service in an Indian
State is sanctioned, the pay which he shall receive in such service must be
precisely specified in the order sanctioning the transfer. If it is intended that
he shall receive any remuneration, or enjoy any concession of pecuniary
value in addition to his pay proper, the exact nature of such remuneration or
concession must be similarly specified. No Government servant will be
permitted to receive remuneration or enjoy any concession which is not so
specified ; and, in the order is silent as to any particular remuneration or
concession it must be assumed that the intention is that it shall not be
enjoyed, but see [rule 12] [12. No Government servant shall be transferred to
foreign service unless the employer undertakes to afford to him so far as
may be privileges not inferior to those which he would have enjoyed under
these rules if he had been employed in the service of the State in India.] of
the Rules in Annexure A to Section I and the Note to F.R.114 in Section II of
this Volume.Fundamental Rules and Subsidiary Rules

2. No order of transfer to foreign service shall be issued by a State
Government without previous consultation with its Finance Department. It
shall be open lo that Department to prescribe, by general or special order,
cases in which its consent may be presumed to have been given.
3. The following two general principles must be observed by State
Government in sanctioning the conditions of transfer :
(a)the terms granted to the Government servant must not be such as to impose an unnecessary
heavy burden on the Indian State which employs him ;(b)the terms granted must not be so greatly
in excess of the remuneration which the Government servant would receive in Government service
as to render foreign service appreciably more attractive than Government service.
4. Provided that if the two principles laid down in paragraph 3 above are
observed, a State Government may sanction the grant of the following
concessions by the foreign employer. Such concessions must not be
sanctioned as a matter of course, but in those cases only in which their grant
is in accordance with customs and the wishes of the Darbar and is, in the
opinion of the State Government, justified by the circumstances. The value of
the concessions must be taken into account in determining the appropriate
rate of pay for the Government servant in foreign service :
(a)The payment of contributions towards leave-salary and pension under the ordinary rules
regulating such contributions.(b)The payment of passage contribution according to rules regulating
such contribution, when the Government servant is of non-Asiatic domicile and is entitled to
passage concessions.(c)The payment of contribution at the rate of Rs. 15 a month towards
Government's liability under Rule 11 (1) of the Rules of the Indian Civil Service (non-European
Members) Provident Fund, the contribution being payable during duty only.(d)The grant of
travelling allowance under the ordinary travelling allowance rules of the State Government or under
the local rules of the Darbar, and of permanent travelling allowance, conveyance allowance and
horse allowance.(e)The use of State tents, boat and transport on tour ; provided that this is
accompanied by a corresponding reduction in the amount of travelling allowance admissible.(f)The
grant of free residential accommodation which may be furnished in cases in which the State
Government considers this to be desirable, on such scale as may seem proper to the State
Government.(g)The use of State motor carriages and animals.(h)[ In the case of a subscriber to the
Contributory Provident Fund (India), the payment for the period of active foreign service of a
contribution determined by the formula X plus XY, where X equals the amount which would have
been credited monthly to the subscriber' account in the Provident Fund had he not proceeded on
foreign service, the rate of pay drawn by him in foreign service being regarded as his 'emoluments'
for this purpose and Y equals the fraction which the amount recoverable as leave-salary contribution
bears to pay drawn in foreign service. This payment shall be in addition to monthly subscriptionsFundamental Rules and Subsidiary Rules

calculated on the rate of pay drawn in foreign service.] [Added vide Correction Slip No. 48 to Assam
Subsidiary Rules (Second Edition 1939), [G.I.F.O. Resolution No. F. 33 (5)- B-II/40, dated the 8th
January 1941, Dy. Fin. (A)-52 of 1941].]Note. The Government of Assam has adopted this rule in
respect of subscribers to the Contributory Provident Fund Assam who may be transferred to foreign
service.
5. The grant of any concession not specified in paragraph 4 above requires
the sanction of the Representative in so far as transfer to an Indian State is
concerned. [As regards medical attendance see the reference quoted at the
end of paragraph 2 above].
State Representative's decision regarding sterling overseas pay. - It is impossible to express any part
of the pay of an officer on foreign service in sterling. The question whether such officer should be
given a corresponding increase in their rupee pay is one for settlement in each case in consultation
with foreign employer. If it is decided, after such consultation, that an increase should be granted,
the calculation of the rupee value of sterling pay will be made at the official rate of exchange (vide
Article 343, Account Code) on the date the officer is transferred to foreign service. In the case of
officers already in foreign service the rate will naturally be the rate on the date with effect from
which their pay is revised.
6. In certain cases the pay of officers in foreign service is fixed at the pay
they would receive in Government service or such pay plus a certain
percentage thereof. In such cases, the Government of India consider that the
foreign employer can equitably be called upon to pay the equivalent of
sterling overseas pay according to the terms of the arrangement, though
even in such cases his concurrence should be obtained. The sterling pay will
then be converted to rupees at the "official rate".
Appendix 20[Fundamental Rules 116 and 117]No. F-1 (1) Rule 1/37-dated New Delhi, the 1st
December, 1938. - In supersession of the rates of contribution for pension and leave-salary
promulgated with the resolution of this Department No. F-81-Rule, 1/24, dated the 11th February,
1929, as amended by Regulation No. D-484-Rule 11, dated the 15th February, 1930, in respect of
officers other than military officers in foreign service, the Governor-General-in-Council in pleased to
prescribe with reference to Fundamental Rules 116 and 117, rates of contributions set out in
Annexure to this Resolution except to the extent indicated in paragraphs 2 and 3 below, the general
principles on which the revised rates have been calculated and the same as were used stated in the
Resolution referred to above.
2. (a) For the purpose of contribution for pension Government servants have
re-classified in the following six grades :Fundamental Rules and Subsidiary Rules

(1)Members of the Indian Civil Service with non-Asiatic domicile.(2)Members of the Indian Civil
Service with Asiatic domicile.(3)Members of the other All-India and Class I Central Services with
non-Asiatic domicile.(4)Members of the other All-India and Class I Central Services with Asiatic
domicile.(5)Members of the Class II Central Services.(6)Members of the Subordinate Central
Services.(b)The rate of interest adopted in the calculation of contribution for pension is ¾ per cent
per annum instead of 4-½ per cent per annum adopted in 1929, on accounts for the increase in the
rates of contribution.(c)The rates of mortality assumed for the various classes of Government
servants or slightly assumed from those adopted in 1922 are based on expert actuarial advise.
3. For the purpose of contribution for leave-salary also, the classification of
Government servants governed by leave rules other than the Revised Leave
Rules, 1933, has been modified as shown in the Annexure.
4. The rates of contribution for leave salary in respect of officers governed by
the Revised Leave Rules are still under consideration and will be
promulgated as soon as possible.
5. The revised rates will take effect from the 1st of January, 1939.
6. A Government servant who is a subscriber to a Contributory Provided
Fund and who is transferred to foreign service shall, if he is allowed to retain
that privilege, pay monthly subscriptions, calculated on the rate of pay drawn
in foreign service. The foreign employer, or the officer himself according to
the arrangement made under Clause (c) of F.R. 115, shall pay in addition, at
such times as Government may prescribe in each case, contribution
calculated on the monthly subscriptions so determined and equal in amount
to what Government would have credited to the subscriber's amount on that
basis.
AnnexureRates of monthly contribution for pension payable during active Foreign Service in respect
of.....
Length
of
serviceMembers of
the Indian
Civil Service
withnon-Asiatic
domicileMembers of the
Indian Civil
Service with
AsiaticdomicileMembers of the
other All-India
and Class
ICentral
Services with
non-Asiatic
domicileMembers of
the other
All-India
and Class
ICentral
Services with
Asiatic
domicileMembers
of the
Class II
Central
ServiceMembers of
the
Subordinate
Central
Services
1 2 3 4 5 6 7Fundamental Rules and Subsidiary Rules

 £s. £s. £s. Rs.   
0-1 year 814 75 66 63 5 per cent.of the
maximum
monthly pay of
the
gradesubstantively
held
1-2
years103 89 75 705 per cent,
ditto4 per cent,
ditto
2-3
years1112 914 82 785 per cent,
ditto5 per cent,
ditto
3-4
years131 1018 818 866 per cent,
ditto5 per cent,
ditto
4-5
years1410 122 914 946 per cent,
ditto5 per cent,
ditto
5-6
years1519 136 1010 1027 per cent,
ditto6 per cent,
ditto
6-7
years178 1410 116 1107 per cent,
ditto6 per cent,
ditto
7-8
years1817 1515 122 1178 per cent,
ditto7 per cent,
ditto
8-9
years206 1619 1219 1258 per cent,
ditto7 per cent,
ditto
9-10
years2115 183 1315 1339 per cent,
ditto7 per cent,
ditto
10-11
years234 197 1411 1419 per cent,
ditto8 per cent,
ditto
11-12
years2413 2011 157 14910 per
cent, ditto8 per cent,
ditto
12-13
years262 2116 163 15710 per
cent, ditto9 per cent,
ditto
13-14
years2711 230 1619 16410 per
cent, ditto9 per cent,
ditto
14-15
years290 244 1716 17211 per
cent, ditto9 per cent,
ditto
15-16
years309 258 1812 18011 per
cent, ditto10 per cent,
ditto
16-17
years3118 2612 198 18812 per
cent, ditto10 per cent,
ditto
17-18
years337 2717 204 19612 per
cent, ditto10 per cent,
dittoFundamental Rules and Subsidiary Rules

18-19
years3416 291 210 20413 per
cent, ditto11 per cent,
ditto
19-20
years365 305 2116 21113 per
cent, ditto11 per cent,
ditto
20-21
years3714 319 2213 21914 per
cent, ditto12 per cent,
ditto
21-22
years393 3213 239 22714 per
cent, ditto12 per cent,
ditto
22-23
years4012 3318 245 23515 per
cent, ditto12 per cent,
ditto
23-24
years421 352 251 24315 per
cent, ditto13 per cent,
ditto
24-25
years4310 366 257 25115 percent,
ditto13 per cent,
ditto
25-26
years4310 366 2613 25816 per
cent, ditto14 percent,
ditto
26-27
years4310 366 279 26616 per
cent, ditto14 per cent,
ditto
27-28
years4310 366 286 27417 per
cent, ditto14 per cent,
ditto
28-29
years4310 366 292 28217 per
cent, ditto15 percent,
ditto
Over 29
years4310 366 2918 29018 per
cent, ditto15 per cent,
ditto
Rates of monthly contribution for leave-salary payable during active foreign service in respect of......
 Percentage of pay drawn in
foreign service
Members of the All-India and Class I Central Services subjectto the
special leave rules16 ⅔
Members of the All-India and Class I Central Services subjectto the
ordinary leave rules15
Members of Class II and Subordinate Central Service 12 ½
The Government of Assam have adopted these rates for the officers under their rule-making control
with effect from 1st January, 1939. The rates for Class 1 Central Services, Class 11 Central Service
and the Subordinate Central Services will apply respectively to Class I State Services, other State
Services and Subordinate State Services.[The above rates apply also to contract officers who are
governed by the model leave terms in Appendix 17, Part I and who are transferred to foreign
service.] [Added vide Correction Slip No. 188 to Assam Subsidiary Rules.][The authorities who are
competent to sanction transfers to foreign service should determine for the contract officers
concerned after taking into consideration the terms of the contract or if these are not conclusive the
pay and status in Government service which of the above three prescribed rates of leave-salaryFundamental Rules and Subsidiary Rules

contribution is appropriate in their cases. The rate of leave-salary contribution should also be
specified in the orders transferring such contract officers to foreign service.] [Added vide Correction
Slip No. 224 to Assam Subsidiary Rules.]Note 1. The following procedure should be adopted in
regard to the leave of contributions for persons and leave-salary in respect of cases falling under
F.R. 127.(1)Pension contributionIn the case of members of the Indian Civil Service, the amount to be
recovered as contribution should be the average of the rates prescribed in columns 2 and 3 of the
table and in the case of members of the other All-India and Class I State Service the average of the
rates laid down in columns 4 and 5 of the table. The sterling rates should be converted into Indian
Currency at the uniform rate of 1 s. 6 d. to the rupee.In the case of members of other State Services
or Subordinate State Services, a fraction of the total maximum monthly pay of the sanctioned posts
equal to the average of the percentage laid down in column 6 or 7 respectively of the table above
should be levied as contribution.(2)Contribution for leave-salaryRecoveries should be made by
levying the prescribed percentages on the total sanctioned cost, or in the case of time-scale of pay on
the average cost, of all the posts concerned. In the case, however, of members of All-India and Class
I State Services, the rate to be applied in calculating the amount to be levied as contribution should
be the average of the rates prescribed for officers subject to the special and to the ordinary leave
rules.Note 2. The rate of 11 per cent of pay drawn in foreign service is the rate of monthly
contribution for leave-salary payable during active foreign service in respect of Class of Government
servants (excluding inferior Government servants) transferred to such service, who are subject to
the Leave Rules, 1934 (Appendix 11, Part I). [This rate applies also to Contract Officers who are
governed by the terms in Appendix 17, Parts II and III and who are transferred to foreign service.]
[Added vide Correction Slip No. 176 to Assam Subsidiary Rules.][Note 3. In respect of inferior
Government servants, the foreign service contribution should be levied at the rate prescribed in
Article 770 (c), Civil Service Regulation on the maximum monthly pay of grade substantively held by
them.] [Substituted vide Correction Slip No. 170 to Assam Subsidiary Rules]Note 4. In respect of
Government servant subject to the Leave Rules, 1939 (Appendix 11, Part I), excluding inferior
Government servants, the recovery from borrowing Government of contribution for leave-salary will
be made at the rate laid down in Note 2 above. This rate will be applied for a period of five years
with effect from the 1st June, 1939 until the date of introduction of revised rates of leave-salary
contributions. The liability of a borrowing Government to pay contributions to the Government will
cease when a Government is permanently transferred to the former ; but the lending Government
will remain responsible for the leave-salary of the Government servant in respect of "earned leave"
at credit on the date of his permanent transfer to the borrowing Government.Note 5. In the case of a
Gazetted Government servant the Audit Officer of the lending Government should draw up a
subsidiary leave account indicating the amount of "earned leave" at credit, leave-salary for which
will be borne by the Government from which the Government servant is transferred, and send it to
the Audit Officer of the Government to which the Government servant is transferred. When a
non-gazetted Government servant transferred permanently to another Government, the head of the
office from which he is transferred should prepare a leave account showing the amount of "earned
leave" at credit on the date of permanent transfer and send it to the head of the office to which the
Government servant is transferred. A copy of the leave account should also be sent at the same time
to the Audit Officer of the office from which the Government servant is transferred so as to enable
him to accept the debit on account of leave-salary for "earned leave" up to the extent indicated in the
leave account, as and when the Government servant takes leave.[Government of Assam'sFundamental Rules and Subsidiary Rules

declaration. - The Governor of Assam hereby declares that the appointments detailed below under
his rule-making control be classified as corresponding to (1) Class I, Central Service; (2) Class II,
Central Service ; and (3) Subordinate Central Service, respectively :] [Added vide Correction Slip No.
27.]
 Name of service and appointment Classification
Home Department
1.Extra Assistant Commissioners holding reserved (listed)
postsClass I
2.Other Extra Assistant Commissioners and Sub-Deputy
CollectorsClass II
Police Department
3. Deputy Superintendents of Police Class II
4. Sergeant Majors Subordinate.
5. Police Inspectors Subordinate.
6. Police Sub-Inspectors Subordinate.
7. Sergeants Subordinate.
Motor Vehicles
8. Inspectors of Motor Vehicles Subordinate.
Assam Rifles
9. All except Officers of the Indian Army Subordinate.
Education Department
10. Assam Educational Service Class I Class II
11. Assam Educational Service Class II Class II
12. Principals of Colleges and Inspectors of Schools Class II
13. Assam School Service Class II
14. Assam School Service, Classes II and IIISubordinate
Service.
Forest Department
15.One Extra Assistant Conservator of Forests in the
IndianForest Service ScaleClass I
16. All other Extra Assistant Conservator of Forests Class II
17. Rangers, Deputy Rangers and ForestersSubordinate
Service.
Jail Department
18. Jailors and Assistant JailorsSubordinate
Service.
Agriculture Department
19. Assam Agricultural Service, Classes I and II Class II
20. Inspectors and Scientific Assistants, etc.Fundamental Rules and Subsidiary Rules

Subordinate
Service.
Veterinary Department
21. Director, Civil Veterinary Department Class I
22. Inspectors and Veterinary Assistant SurgeonsSubordinate
Service.
Industries Department
23.Weaving Superintendent, Superintendent of
Sericulture,Principals to Technical Schools.Class II
24.Assistant Superintendent of Sericulture, Teachers
andInspectors of Weaving Schools and Technical SchoolsSubordinate
Service.
Co-operative
Department
25. Assistant Registrars of Co-operative Societies Class II
26.State Auditor of Co-operative Societies and Inspectors
ofCo-operative SocietiesSubordinate
Service.
Factories and
Electricity Department
27.Chief Inspector of Factories and Electrical Adviser
toGovernmentClass I
28. Electric and Factory Inspectors Class II
29. Electrical TestersSubordinate
Service.
Boilers Department
30. Chief Inspector of Boilers Class I
31. Inspectors of Boilers Class II
Printing Department
32. Superintendent, Government Press Class II
Medical Department
33.Civil Surgeons reserved for Assam Medical Service
(Senior)Class I
34.Civil Assistant Surgeons including Assistant Director,
PasteurInstitute and Medical Research Institute, ShillongClass II
35. Sub-Assistant SurgeonSubordinate
Service.
36. Others Ditto
Excise Department
37. Special Superintendent and Superintendent of Excise Class II
38. Inspectors of ExciseFundamental Rules and Subsidiary Rules

Subordinate
Service.
39. Sub-Inspectors of ExciseSubordinate
Service.
40. Supervisors, Excise Ware-housesSubordinate
Service.
41. OthersSubordinate
Service.
Public Health
Department
42. Assistant Directors of Public Health Class II
43. Assistant Surgeons Ditto
44. Sub-Assistant SurgeonsSubordinate
Service.
45. OthersSubordinate
Service.
Registration
Department
46. Special Sub-Registrars Class II
47. Sub-RegistrarsSubordinate
Service.
Assam Surveys
48. Superintendent, Assam Surveys Class II
49. OthersSubordinate
Service.
Public Works
Department
Assam Engineering
Service (Class I)
50. Chief Engineer Class I
51. Superintending Engineer Class I
52. Executive Engineers Class I
53. Assistant Executive Engineers Class I
Assam Engineering
Service (Class II)
54. Assistant Engineers Class II
55. Mechanical Engineers, Assam Class II
Miscellaneous
56. Deputy Secretaries to Government Class IFundamental Rules and Subsidiary Rules

57. Registrars of Secretariat Class II
57-A. Examiner, Local Accounts Ditto
58. All other unspecified services or postsSubordinate
Service.
Appendix 21[Fundamental Rule 117 in Section II]
1. The rates mentioned in annexed Schedule are prescribed for the purpose
of recovery of contributions for pension and leave- salary in respect of
military officers and other ranks in permanent civil employ who are
transferred to foreign service. The revised rules shall have effect from the 1st
July, 1933, and shall also apply, with effect from the same date, to military
officers and other ranks already in foreign service except who were
transferred to such service, before the 27th January, 1922, in the case of
military commissioned officers, and before 28th February, 1924, in the case
of others, in whose case there has been no extension of the period of foreign
service and consequently contribution on whose behalf are still recovered in
accordance with the old Civil Service Regulations rates.
2. (a) (i) These rates, which will be payable only during active foreign
services cover, in all cases, the liability for the ordinary disability and family
pensions and gratuities (including the disability and family pensions at
double rates and the gratuity admissible under paragraph 94, Pension
Regulations, India, in respect of military officers ; the special and mustering
out pensions and gratuities and gratuity admissible under paragraph 258 ibid
in respect of Indian ranks ; and invalid pensions and gratuities in respect of
military sub- assistant surgeons) which may be admissible, under the
ordinary rules of their service, to foreign service in any circumstances
whatsoever.
Schedule 5
(a)Military Commissioned Officers.(b)Rate of monthly contribution for pension :
Length of service Rate of contribution
 £ s.
0-1 year 4 4
1-2 years 9 5
2-3 years 10 5Fundamental Rules and Subsidiary Rules

3-4 years 11 6
4-5 years 12 6
5-6 years 13 7
6-7 years 14 7
7-8 years 15 8
8-9 years 16 8
9-10 years 17 9
10-11 years 18 9
11-12 years 19 10
12-13 years 20 10
13-14 years 21 11
14-15 years 22 11
15-16 years 23 12
16-17 years 24 12
17-18 years 25 13
18-19 years 26 14
19-20 years 27 14
20-21 years 28 15
21-22 years 29 15
22-23 years 30 16
23-24 years 31 16
24-25 years 32 17
25-26 years 33 17
26-27 years 34 18
27-28 years 35 18
28-29 years 36 19
over 29 years 37 19
Note. The term "length of service" includes all service as warrant officer, class I, and half of any
pensionable service in lower ranks which counts as commissioned service for the purpose of pension
in accordance with paragraph II, Pension Regulations, India.(ii)Rate of monthly contribution for
leave-salary. - 16 ⅔ or 15 per cent of pay drawn in foreign service, according as the officer is of
non-Asiatic or Asiatic domicile.(b)Rates of monthly contribution in respect of Departmental Officers
and Warrant Officers of the Indian Unattached List and Indian Medical Department and British
Non- Commissioned Officers and men on the Indian establishment:
For leave-salary 12 ¼ per cent of pay drawn in foreign service.
For pension One-sixth of pay drawn in foreign service.
(c)Rates of monthly contribution in respect of Indian officers with Viceroy's Commission (including
those holding Honorary King's Commission), non-Commissioned Officers and men :
For leave-salary One twelfth per drawn in foreign service.Fundamental Rules and Subsidiary Rules

For pension One-sixth of pay drawn in foreign service.
Note. The following procedure is prescribed in regard to the recovery of pension contribution in the
case of military commissioned officers lent for service in Iraq. In the case of such officers, except
those who were first transferred for service in Iraq on or after the 27th January, 1922, the revised
rates of pension contribution should apply with effect from 31st July, 1933. In case of those officers
who were first lent on or after the 27th January, 1922, the revised rates should apply with effect
from the date on which they joined service in Iraq.Appendix 22[S.R. 189]Special Rates of Daily
Allowance admissible in certain localities[Superseded from the 1st April, 1964 vide Government of
Assam Finance (APF) Department's O.M. No. F.M. 53/64/11, dated 1st April, 1965]Appendix
23[S.R. 194]List of Special Rates of Travelling Allowance sanctioned for special
localities[Superseded from the 1st April, 1964, vide Government of Assam Finance (APF)
Department's O.M. No. FM 53/66/11, dated 4th January, 1965]Appendix 24[S.R. 212]List of
Government servants exempted from the ten days' halt subject to the conditions of the Rules
S.N.Government servants exempted wholly or
partially Condition
(1) (2)  (3)
1. All Government servants in Inferior service  None.
2.All officers whether permanent or
probationaryor temporary who have not
completed 3 years' continuous service,working
under the supervision of the Director of Land
Records,for training in Survey and Settlement Members of the All India Services
will beallowed daily allowance of
Rs. 5.25 per day and the
ExtraAssistant Commissioner,
Assam Judicial Service Or.) Grade
IIOfficers, Assam Police Service
Officers at Rs. 3.50 per diem.
TheSub-Deputy Collectors will be
allowed a lump sum of Rs. 60
permonth. These rates will be given
throughout the whole period
oftraining (including the first ten
days).
2-A. All officers completing three years'
continuousservice or more whether permanent
or probationary or temporaryworking under the
supervision of the Director of Land Records
fortraining in Survey and Settlement Members of the All India Services
Assam CivilServices (Classes I and
II), Assam Judicial Service Or )
Grade IIand Assam Police Service
Officers will be entitled to
dailyallowance at the usual rate
admissible to them according to
theirrespective Grades subject to
the condition that they would
drawthe same at ¾th rates after
the first ten days and at halfrate
after first 30 days.These rates will
be applicablethroughout the wholeFundamental Rules and Subsidiary Rules

period of training (including the
first tendays and any absence from
the temporary headquarters during
thecourse of training shall not
constitute a break in the
continuoushalt in the same
headquarters, and the provision of
S.R. 213 (b)will not apply.
 Note.The above provision against SI. No.2-A
will not be applicable in the case of an officer
who hasfailed to pass the prescribed test of the
training in the firstattempt. In such cases the
provision of SI. No. 2 above only willbe
applicable i.e., the officer will get the allowance
at therates prescribed under the said provision.
In cases where due tothe exigency of public
service an officer could not be deputedfor the
training before he completed 3 years of service
theprovision of SI. 2-A will, however, be
applicable.
3. Clerks and poddars in charge of remittances  On certificate of the Deputy
Commissioner underwhom the
clerks or poddars are employed or
Currency Officers/andChief
Accountant of the Reserve Bank
that the detention wasunavoidable.
4.Poddars deputed to undergo a course of
trainingat the Calcutta Mint Allowed daily allowance at full
rates for thewhole period for their
halt at Calcutta.
5.Subordinate Judges, Munsiffs and
theirestablishments, when transferred
temporarily from one station toanother  
6.District and Sessions Judge,
AdditionalAssistant and Subordinate Judges of
Cachar with theirestablishments Allowed daily allowance at full
rates for thefirst ten days and at
¾th rates thereafter if
thecontrolling officers certify that
the prolonged halt wasnecessary.
7.District and Sessions Judge,
AdditionalAssistant and Subordinate Judges,
Assam Valley Division withtheir establishments  
8. * * * *   
9. Weaving Assistants  None.Fundamental Rules and Subsidiary Rules

10.Sub-Assistant Surgeons and Epidemic
Assistanceof Public Health Department in
Epidemic duty (i) Except in cases falling under (ii)
belowallowed daily allowance at
full rates for the first ten days,
¾thrates for the next twenty days
and half rates thereafter.
   (ii) Where an epidemic results in
local marketsand halts being closed
and the prices of foodstuffs and
servicesbeing substantially, raised
daily allowance will be allowed
onthe report of the Civil Surgeon at
full rates for the entireperiod of
halts so long as such halt was
necessary.
11. Physical Instructor and Instructresses  Allowed daily allowance at full
rates for thefirst ten days at ¾th
rates for the next 20 days and at
½rates thereafter.
12.Mining Engineers, Drilling
Engineers,Geologists, Assistant Geologists,
Driller Mechanics, AssistantDrillers, Mine
Surveyors, Surveyors, Geo-physicists Allowed daily allowance at full
rates for thefirst 15 days, ¾th of
the rates for the next 30 days andat
½ rates for the remaining period.
Appendix 25Rules governing the Travelling Allowance of Governor for journeys other than on
dutyAndRules governing the use of Special Trains by Governor Designate and Retiring
Governors[Not Printed]Appendix 26The Assam Legislative Chambers (Members Emoluments) Act
(Assam Act 1 of 1938)AndTravelling Allowance Rules[Not Printed]Appendix 26-AThe Assam
Ministers (Salaries and Allowances) Act and the Rules thereunder[Not Printed]Appendix 27Assam
President's Salary Act, 1937(Assam Act 5 of 1937)[Not Printed]Appendix 28[S.R. 289]List of
Sanctions to Travelling Allowance for journeys on a Course of Training
Item No.Persons granted
travelling allowanceParticulars of travelling
allowance admissibleRemarks
1 2 3 4
A.
Governmentservants
deputed to
undergo a
course of
training
1.Clerk deputed to the
office of the
Comptroller,Assam
for training in
Treasury AccountsTravelling allowance both ways,
according torates admissible to
an officer of his grade while on
tour. Fundamental Rules and Subsidiary Rules

2.Probationary
Sub-Inspectors
deputed for trainingto
the Police Training
School(a) Departmental Cadets will
draw actualtravelling expenses
for self from their District
headquarters tothe Police
Training School and from the
School to the place whereposted
on passing out of the
School,plusactual cost
ofconveyance of luggage up to 76
Kgs.The conveyance of luggage
by rail or steamer maybe
passed at "Luggage rate".
  Travelling expenses at the above
rates and dailyallowance
according to the rates admissible
to Sub-Inspector ofPolice while
on tour will also be admissible to
them under whomthey are
deputed to any placeunder orders of the
Principal, Police
Training(School for
Practical Training)
  (b) Newly appointed cadets will
draw actualtravelling expenses
for self when posted to Districts
only onpassing out of the
School,plusactual cost of
conveyance ofluggage up to 76
Kgs.The conveyance of luggage
by rail or steamer maybe
passed at "Luggage rate".
  Travelling allowances at the
above rates anddaily allowance
according to the rates admissible
to theSub-Inspector of Police
while on tour will also be
admissible tothem when they are
deputed to any place under
orders of thePrincipal, Police
Training School for practical
training. 
3. Sub-Inspector when
deputed to visit jails
andcourt offices for
practical training or
when coming from
Districtto Shillong for
training in the Finger
Print Bureau or
deputed toAssamTravelling allowance both ways
according torates admissible to
an officer of his grade while on
tourThis rule will also apply
mutatis mutandis toother
officers deputed to the
Bureau for short periods
forproficiency certificates.
But Sub-Inspectors of Police
who aredeputed to Shillong
from other Districts to
undergo a course oftrainingFundamental Rules and Subsidiary Rules

Rifles Battalions for a
course of general
training inPlatoon
Commander’s dutiesin the Finger Print Bureau
for a period of one year
willdraw travelling
allowance under S.R. 243
for the journey to andfrom
Shillong.
4.Probationary
Assistant and Deputy
Superintendentof
Police deputed for
training at the Police
Training
College,Sardah,
BengalTravelling allowance from the
Training Collegeas on
tourplusactual cost of
transporting luggage up to
750Kgs. and actual cost of
transporting on horse. During
trainingthey will draw travelling
allowance (including daily
allowance)at rates admissible to
a Bengal Officer of a similar
status undertraining. Such daily
allowance will be granted by the
sameauthority and up to the
same limits and on the same
conditions asin the case of the
Bengal Officers deputed for
similar training. 
5.Constables, Head
Constables and
AssistantSub-Inspectors
deputed to courses of
training in drill,
physicaltraining and
as armourers and
such other course of
instructionsas may be
decided by the
Inspector General of
PoliceWill draw actual travelling
expenses up to
thefollowing-limit:(a) For
self-Single fare of the class
towhich they are entitled by rail
or steamer and actual cost
oftransport by roads as passed
by the Controlling Officer.(b)For
luggage-Up to 76 Kgs. at luggage
rates, by rail or steamerand
actual cost by road as passed by
Controlling Officer 
6.Recruits going to or
returning from
theConstables’
Training SchoolEntitled to single fare by rail or
steamer atrates admissible to an
officer of fourth
grade,plusconveyanceof luggage
at luggage rate up to 76 Kgs. 
7. Sub-Inspectors
deputed for periodical
trainingin drill at theEntitled to travelling allowance
to and from theplace of training
according to the rates admissible Fundamental Rules and Subsidiary Rules

headquarters of the
District to which they
areattachedto an officerof the third grade
while on tour
8.All Recorders who are
deputed for training
tothe Assam Survey
SchoolEntitled to travelling allowance
at ratesadmissible to officers of
the third grade while on tour,
forjourneys to and from the and
II and for School once only. 
9.Government servants
of the Education
Departmentdeputed
for trainingFor journeys to and from the
place of trainingat the beginning
and end of the period of training 
  (a) For self-Mileage allowance by
rail, riverand road at rates
admissible to Government
servants of theirgrade, under
S.Rr. 173, 177, 182 and 183,
respectively 
  (b) For their families- Subject to
verificationof need by the
Director of Public Instruction
travellingallowance at rates
admissible under S.Rr. 242 I (ii)
and (iii)and II (ii) and (iii) for
journeys by rail or steamer and
road,respectively, and a single
additional fare in addition to
themileage allowance admissible
to the officer himself under Cl.
(a)above. 
10.Government servants
of the Education
Departmentdeputed
for trainingMileage allowance as in item 9
(a) and alsohalting allowance
will be allowed in the case of
teachers deputedto a Scouts’ or
Guides’ Training Camp, Red
CrossTraining Camp, rallies,
Jambories, etc., by the Director
ofPublic Instruction 
11. Teachers of Aided
and Board Schools
deputed fortrainingEntitled to travelling allowance
at ratesadmissible to
Government servants of their
status for journeys toand from
the place of training at the Fundamental Rules and Subsidiary Rules

beginning and end of theperiod
of training.
12.New Candidates
deputed for trainingEntitled to single fare by rail or
steamer atrates admissible to an
officer of third
gradeplusconveyance ofluggage
up to 76 Kgs. at luggage rates by
rail or steamer, andactual cost
by road for the journey from the
college to wherethey came from,
on leaving the college at the end
of the periodof trainingThe concession for the
conveyance of luggage
byroad is allowed on the
understanding that the
controlling officersatisfies
himself that the expenses
were actually incurred.
13.Veterinary Assistant
deputed to the
BelgachiaCollege for
refresher courseTravelling allowance for the
journey to and fromthe college
according to rates admissible to
an officer of hisgrade while on
tour 
14.Government servants
{i.e., officers of
theI.A.S., Assam Civil
and Subordinate
Executive Service)
deputed toundergo
the course of
instruction in Survey
and Settlement at
theAssam Survey
School, Jhalukbari
near Gauhati and for
consequenttraining
under Settlement
OfficerEntitled to travelling allowance
according torates admissible to
an officer of his grade while on
tour forjourneys to and from
Jhalukbari by the beginning and
terminationof the period of
training. Also entitled to
travelling allowanceadmissible
to his grade when required to
travel for purposes ofinstruction
during his course at the School. 
15.Government servants
of the Departments
ofCooperative
Societies and
Industries deputed
for training in
anypart of IndiaEntitled to travelling allowance
according torates admissible to
an officer of his grade while on
tour forjourneys and to from the
place of training at the beginning
andtermination of the period of
trainingThe same rates of travelling
allowance as abovewill be
allowed on journeys during
the course of his training.
16. Government servants
of the
AgricultureDepartment
deputed for trainingEntitled to travelling allowance
according torates admissible to
an officer of his grade while on
tour forjourneys to and from the Fundamental Rules and Subsidiary Rules

in any part of India place of training at the beginning
andend of the period of training
and for journeys during the
courseof training
17.Sub-Inspector of
Vaccination for
training
inpreparation of calf
lymph, Vaccination,
verification of
vitalstatistics, etc., in
the Vaccine Depot,
Shillong. The
courselasts for two
monthsEntitled to travelling allowance
both waysaccording to rates
admissible to an officer of his
grade on tour. 
18.Government servants
deputed to undergo a
courseof training at
the Forest Research
Institute and
College,DehradunFor journeys to and from the
college atbeginning and end of
the period of training: 
 (a) Assam Forest
Service Course(a)For self.-Mileage allowance
by rail,river and road at rates
admissible to Government
servants oftheir grades under S.
Rr. 173, 177 179, 182 (a) and
183respectively.,- 
 (b) Ranger course(b)For their families.-Subject
toverification of need by the
Conservator of Forests,
travellingallowance at rates
under S.Rr. 243 I (ii) and (iii)
and II (ii)for journeys by rail or
steamer and road, respectively,
and asingle additional fare in
addition to the mileage
allowanceadmissible to the
officer himself under Cl. (a)
above. 
19. Assistant Surgeons
and Sub-Assistant
Surgeons ofthe
Medical and Public(a) Entitled to travelling
allowance under theordinary
rules for journeys on tour for the
journey to and fromthe place of Fundamental Rules and Subsidiary Rules

Health Department
when deputed to
undergoa course of
training in or out of
the Statetraining. In the event of their
failing to qualifyin each course
on first occasion they will be
allowed only onroad mileage as
admissible for a journey on tour
and a singlefare by railway and
steamer of the class to which
they belong onthe second and
third occasions.
  Sub-Assistant Surgeons of the
Public HealthDepartment
deputed to field work on
completion of training at
theShillong Pasteur Institute will
get travelling allowance
underthe ordinary rules as for
journeys on transfer 
  For the purposes of concession
contained insub-Cls. I (ii) and
(iii) and II (ii) and (iii) of S.R.
243charges will be admissible
from the old station to the
station atwhich the
Sub-Assistant Surgeon has been
posted on completeion ofhis
training at the Pasteur Institute,
Shillong 
  (b) Halting allowanceat the
usual rate for the following
courses only within the
Statewhen the course does not
exceed 15 days(i)
PasteurInstitute,
Shillong(ii)[Deleted]Note.The travelling
allowance payable
toMedical Officer deputed
for training under Leprosy
ReliefAssociation, Calcutta
should in the first instance
be paid byGovernment and
then recovered in full from
the Association
20.Female Sub-Assistant
Surgeons deputed to
undergoa course of
training at a
postgraduate class in
CalcuttaEntitled to travelling allowance
for journey toand from Calcutta
at rates admissible to an officer
of the secondgrade while on tour
limited to actual expenses 
21.  Fundamental Rules and Subsidiary Rules

Excise Inspectors and
Extra Officers of
theExcise
Department when
deputed to undergo
trainingTravelling allowance at the
ordinary rate, forthe journey
each way
22.Apprentices of
Government FarmsA single third class rail or
steamer fare to andfrom the
place of trainingplusdaily
allowance of 37 paise onthe
journeys and during halts up to a
period of 10 days 
23.Students who are
placed for practical
trainingin the Assam
or West Bengal Public
Works DepartmentTravelling allowanceon tour to
be granted by the Chief
Engineer, Assam or WestBengal,
as the case may be, admissible to
members of the
LowerSubordinate Service of the
Public Works Department under
thesubsidiary Rules for-(a)
Joining theirappointments(b)
Transfer from oneplace to
another(c) Leaving the placein
which they may be stationed at
the end of their
practicaltraining(d) Proceeding
to and returning from the
placeof their practical
examinationIf ordered to inspect works
at a considereddistance
from their headquarters, a
bill for their actualexpenses
should be submitted! by
these students to the
ExecutiveEngineer under
whom they may be placed
for training who will
dealwith all their travelling
allowance bills. If in any
month, thebills of any
student exceeds Rs. 15 such
bills should besubmitted to
the Chief Engineer, Assam
or West Bengal, as thecase
may be, under whom he is
placed for training, for
specialsanction. The
Executive Engineer should,
however, pass bills inexcess
of Rs. 15 when they only
refer to journeys for joining
ofleaving the place of
practical training or
practical examinationand
for transfers.
B. Students
selected to
undergo a
courseFundamental Rules and Subsidiary Rules

oftraining
24.State Scholars sent to
United KingdomA single second class P. and O.
passage each wayand freight on
115 Kgs.of baggage 
25.Male or female
students selected to
undergo acourse of
trainingEntitled to single fare by rail or
steamer forthe first journey to
and the last journey from the
place oftraining at rates
admissible to a Government
servant of thirdgrade in the case
of male students, and of second
grade in thecase of female
students,plusconveyance of
luggage, up to 76Kgs. at luggage
ratesNote.The same rates of
travellingallowance will be
drawn by students (male or
female) deputed tovisit
special demonstration ; or
exhibitions.
26.(i) Lushai
studentsholding
Government
scholarships at a
college in Assam
butsituated at a
distance from their
native
DistrictNote.The
restriction does not
apply tomedical,
technical and similar
institutions affording
facilitiesfor training
which do not exist in
Assam-At the discretion ofthe
controlling officer actual
travelling expenses to and
fromthe college to visit their
home once in every tow yearsRs.
125 fromDibrugarh to Aijal
andviceversaRs. 225 from
Dibrugarh to Lungleh
andviceversa 
 (i-a) Lushai students
holding
GovernmentScholarships
in Assam Medical
College, DibrugarhFixed amount of travelling
allowance at thefollowing rates
to visit their homes once in every
two years 
 (ii) Students ofother
Hill tribes holding
Government
Scholarships in
MedicalSchools(iii)
Other Assam students
holding(a) Entitled once ayear to half of
the single fare by rail or steamer
from theSchool or College to
their homes, according to the
ratesadmissible to an officer of
the third grade in the case of
malestudents and of second Fundamental Rules and Subsidiary Rules

Governmentscholarships
at the Campbell
Medical School and
the Berry
WhiteMedical Schoolgrade in the case of female
students(b) Full single faremay
be drawn by the students once in
two years as an alternative(c)
Khasi students are also entitled
to theadditional payment of half
motor fare once a year or full
fare intwo years, in Inter class of
the No.2 service car on the
GauhatiShillong road when they
have to go home via Shillong
 (iv) Khasi students
holding
GovernmentScholarships
for training in the
Jorhat Technical
SchoolSubject to the condition that the
spendiariesare certified by the
Secretary, Technical Education
to be toopoor to bear the cost of
the journeys-Entitled to single
fareby rail and motor (in Inter
class of the No.2 service car)
atrates admissible of officers of
the third grade for the
firstjourney to and the last
journey from the School (up to
and fromShillong
only)plusconveyance of luggage
up to 76 Kgs. atluggage rates
once in two years journeys to
and from Shillongafter the
vacation 
 (v) Garo students
holding
Governmentscholarships
for training in the
Jorhat SchoolSubject to the condition that the
stipendiariesare certified by the
Secretary, Technical Education
to be toopoor to bear the cost of
the journeys-Entitled to single
fareby rail at rates admissible to
officers of the third grade forthe
first journey to and the last
journey from the School
(fromand up to Tura
only)plusconveyance of luggage
up to 76 Kgs. atluggage rates,
and also single fare at the above
rates once intwo years for
journeys to and from Tura after
the vacation Fundamental Rules and Subsidiary Rules

 (vi) Naga students
holding scholarships
fortraining in the
Jorhat Technical
SchoolSubject to the condition that the
stipendiariesare certified by the
Secretary, Technical Education,
to be toopoor to bear the cost of
the journeys-Entitled to single
fareby rail and motor (from and
up to Kohima only) and to single
fareby rail and mileage
allowance for travelling by road
(from and upto Mokok-chung
only at rates admissible to
officers of the thirdgrade, for the
first journey to and the last
journey from
theSchool,plusconveyance of
luggage up to 76 Kgs. at
luggagerates, and also single fare
at the above rates once in two
yearsfor journeys to and from
Kohima or Mokokchung after
the vacation. 
27.Students selected to
undergo a course
oftraining at the
Forest Research
Institute and College
Dehra Dunand the
Forest College
Rangoon-  
 (a) Assam Forest
Service Course(a) Entitled to actual expenses
incurred by railor steamer for
the first journey to and the last
journey fromDehra Dun and
Rangoon. For this purpose they
will be consideredas officers of
the 2nd Grade.While undergoing
the course suchstudents will be
granted actual expenses on tour
as passed by thePresident,
Forest Research Institute and
College, Dehra Dun andthe
Principal, Forest College,
Rangoon, including single
secondclass fare by rail or Fundamental Rules and Subsidiary Rules

steamer for the student, fare for
oneservant and freight of a
bicycle where necessary
 (b) Ranger Course(b) Entitled to actual expenses
incurred by railor steamer for
the first journey to and the last
journey fromDehra Dun, and
also while undergoing the course
at the College.For this purpose
they will be considered as
officers of the 3rdGrade. 
28.Male students
holding Government
Scholarshipsfor
Education in
Industrial or
Technical Institution
outside theStateEntitled to single fare by rail or
steamer forthe first journey to
and the last journey from the
place ofeducation at rates for
third gradeplusconveyance of
luggage upto 76 Kgs. at luggage
ratesAlso entitled once in every
two years when thecourse
exceeds two years to one
fareplusconveyance of
luggageup to 76 Kgs. at
luggage rates for the journey
to their homesfrom the
institutions in which they
are being trained and
backagain after the vacation
Appendix 29[Note to Subsidiary Rule 302]Rates at which deductions are to be made in the
travelling allowance bills for the use of means of transport provided by Government(1)For boats-
 Rs. P.
By Government servants whose daily allowance is Re. 1 or less Nil
By Government servants whose daily allowance is more than Re.1, but not more than Rs. 5 1.00
By Government servants whose daily allowance is more than Rs.5 but not more than Rs. 6 1.50
By Government servants whose daily allowance is over Rs. 6 2.00
In the case of two or more officers whose daily allowances are in each case Rs.5 more using one boat,
the total daily rate of hire is Rs. 2 payable in proportion to the rates of daily hire payable by the
officer under the prescribed scale.(2)Officers who are supplied with elephants are required to pay
monthly charges for the six months from November to April at the allowance rates, whether the
elephants are used or not :'no charge will be made for the remaining months of the year :
 OfficersCharge per
monthRs. P.
(a) Officers having three elephants 70.00
(b) Conservator of Forests having three elephants 60.00
(c) Officers having two elephants 45.00
(d) Officers having one elephant 15.00
(e) [Deleted]  
(f) Extra-Deputy and Extra-Assistant Conservators of Forest incharge of Forest 35.00Fundamental Rules and Subsidiary Rules

Divisions having two elephants
(g) Divisional Forest Officer, Goalpara having three elephants  
Note. The following orders will apply to the Political Officer, Balipara Frontier Tract on account of
hire of elephants :(1)The usual charge at Rs. 45 per month should be paid by the him for his two
political elephants from November to April but reductions as noted below will be allowed whenever
the elephants are employed during this period on carrying Government rations or other
Government works of a similar nature-(i)for each day or part of a day on which the elephants are so
employed................Re. 1;(ii)for each day or part of a day on which the two elephants are so
employed................Re. 1.50 :Provided that the absence of the elephant or elephants on Government
work necessitates his employing for his own use means of transport other than the elephants in
question.(2)When reductions are claimed, a certificate on the travelling allowance bill should be
given to the effect that the elephant or elephants were employed so many days on Government work
arid that he was compelled for those days to use other means of transport for his own touring
purposes.Note 2. The controlling officer may remit the charge for any month, when it is certified
that owing to illness the elephant could not be used for the whole month, and provided he is
satisfied that such illness is not due to neglect on the part of the officer responsible for the elephant.
When one elephant out of three is ill, the hire should be paid at the rate fixed for officers having two
elephants, i.e. Rs. 45 and when two are ill it should be paid at the rate fixed for officers having one,
viz, Rs. 15.Note 3. The orders contained in the above notes apply also to the Political Officer, Sadiya
Frontier Tract.Note 4. The conservator of forest may remit a proportionate part of the fire of
elephants payable by officers under him, when the elephants are employed on Government work
and are therefore not available for the carriage of baggage ; provided that the officers concerned
have consequently to employ other means of transport.Appendix 30[S.R. 310 and Note 1 under S. R.
3]List of Controlling Authorities for Travelling Allowances
 Controlling Officer  Officer or Establishment
(1) District Officers, including the PoliticalOfficers
and Superintendent, Mizo District Assistant Commissioner,
Extra
AssistantCommissioners,
Honorary Magistrates,
Sub-Deputy
Collectors,Assistant
Superintendents of Police
in Civil employ,
Tahsildar,Superintendents
of Grazing,
Superintendents of Excise.
Inspectorsand Extra
Officer of Excise,
Subordinate Excise
Staff.Commandants of
Assam Rifles Units
employed on the District
CivilSurgeon,Fundamental Rules and Subsidiary Rules

Superintendents and
Additional
Superintendents ofPolice,
Assistant Political Officers'
Agricultural
DemonstrationStaff placed
under their direct control
and ministerial andmenial
establishment of the
amalgamated district
establishmentand Record
Staff not on major
settlements, Chairman
and Membersof Debt
Conciliation Boards.
 Note 1.DeputyCommissioner, Cachar will
countersign travelling allowance billsof the
establishment at the Bakitar Farm.Note
2.TheAdditional District Magistrate or the
Additional DeputyCommissioner or where there
is no officer the SeniorExtra-Assistant
Commissioner of the district headquarters
maycountersign such travelling allowance bills
as are made over tohim by the Deputy
Commissioner. The Additional
DeputyCommissioner may also countersign the
travelling allowance billsof the ministerial and
menial establishment of the Sadar officesin the
absence of the Deputy Commissioner.Note
3.TheSub-Divisional Officer in cases in which
the Debt ConciliationBoard is in a Sub-Division
will countersign bills of the Chairmanand other
members of the Board.Note 4.The
Sub-Divisional Officer maycountersign the
travelling allowance bills of the ministerial
andmenial establishment of his office.
(2)District Officers of the Mizo, Khasi andJaintia,
and Garo Hills and Cachar, and Political Officers Subordinate of the Civil
Public
WorksEstablishment.
(3) District Officers where there is no ForestDivision  Non-gazetted forest staff
of the district.
(4) District Officer as Ex-officio DistrictRegistrars  Special Sub-Registrars,
Sub-Registrars,ministerialFundamental Rules and Subsidiary Rules

and menial staff of
Registration Offices.
 Note 1.The District Registrar, Nowgongwill also
countersign Travelling Allowance bills of the
SpecialSub-Registrar of Nowgong where
travelling on Inspection dutytheir own districts
and also of their peons.
(5) District Officers as Ex-officio Sub-Judges  Their ministerial and
menial establishment.
(6) Deputy Commissioner, Khasi and Jaintia Hills  Non-gazetted subordinate,
ministerial and menialstaff
of the Forest Division
Establishment of the
FullerIndustrial School
and Weaving School,
Shillong.
(7) Superintendent, Mizo District  Agricultural
Demonstrator,
establishment ofPrimary
Schools.
(8) Deputy Commissioner, Garo Hills  Establishment of Primary
Schools.
(9) Political Officer, Sadia Frontier Traci  Agricultural Instructor,
establishment ofPrimary
Schools.
(10) Political Officer, Balipara Frontier Tract  Establishment of Primary
Schools.
(11) Commissioner of Divisions  Himself, District Officers,
Additional
DistrictMagistrates, his
own Personal Assistant
and office
establishmentand Lady
Supervisor, Wards Estates.
(12) Commissioner of Taxes  Himself, Officer,
Superintendent,
ministerialand 4th Grade
establishment of his own
office and all
otherGazetted and
non-Gazetted Officers of
the Department.Fundamental Rules and Subsidiary Rules

 Note 1.The Deputy Commissioner of Taxessigns
for the Commissioner of Taxes.
 Note 2.The Assistant Commissioner ofTaxes
signs for the Commissioner of Taxes and Deputy
Commissionerof Taxes when the latter two are
on tour except in respect oftravelling allowance
bill of the Assistant Commissioner of Taxes.
(13)Director of Land Records, Inspector General
ofRegistration, and Superintendent of Stamps Himself, Settlement
Officers of
majorsettlements,
Assistant Director of Land
Records,
SettlementOfficer,
Assistant Settlement
Officers and
Establishment engagedon
minor settlement, his
Personal Assistant and
establishment,and
non-official members of
the permanent committee
appointed forthe
supervision of
Muhammedan Marriage
Registrars and Kazis.
(14) Settlement Officers of major  Assistant Settlement
Officers, Kanungos,
Mandalsor Patwaris and
ministerial and menial
staff under their control.
(15) Director of Surveys  Himself, Superintendent,
Personal
Assistant,technical,
ministerial and menial
establishment, and
Principalministerial,
teaching and menial staff
of the Survey School.
(16) Deputy Surveys Director, Assam  All officers deputed for
survey and
settlementtraining to the
Survey School, and
ministerial, menialFundamental Rules and Subsidiary Rules

andtechnical staff under
him.
(17) Conservator of Forests  Himself, and all gazetted
officers of the
State,Subordinate,
ministerial and menial
staff attached to
theDirection Division, and
Forest Veterinary
Assistant.
(18) Chief Engineer  Executive and Assistant
Executive
Engineersattached to his
office.
 Chief Engineer, P.W.D.  (i) Himself,
Superintending Engineers
in chargeof Circle.
   (ii) All Gazetted,
Subordinate, Ministerial
andGrade IV Staff
attached to his office.
 Addl. Chief Engineer, P.W.D.  Himself and all Gazetted,
Subordinate,Ministerial
and Grade IV staff
attached to his office.
 Chief Engineer, Flood Control and Irrigation  Himself, Superintending
Engineers within
hisjurisdiction and all
Gazetted, Subordinate,
Ministerial and GradeIV
staff attached to his office.
 Additional Chief Engineer, Flood Control
andIrrigation Himself, and
Superintending Engineers
within hisjurisdiction.
(19) Superintending Engineer  Executive Engineers in
charge of Public
WorksDivisions and
Mechanical Engineer,
Public Works
Departments.
(20) Inspector General of Civil Hospitals and Prisons  Himself, Medical Officers
on special duty andhisFundamental Rules and Subsidiary Rules

ministerial and menial
staff and personal
Assistant, Directorand
Assistant Director, Pasteur
Institute and Medical
ResearchInstitute, Jailors,
Superintendent, Mental
Hospital,
Tezpur,Principal, Assam
Medical College,
Dibrugarh, Principal
AyurvedicCollege,
Gauhati.
 Note.The personal Assistant to theInspector
General signs for the Inspector General when the
latteris on tour.
(21) Inspector General of Police  Himself, Personal
Assistant, Superintendent
ofRailway Police,
ministerial and menial
staff of his own
office,Superintendent and
Deputy Superintendent of
Police whenproceeding
beyond their jurisdiction
to attend
co-operationmeetings.
 Note.Personal Assistant signs for theInspector
General when on tour.
(22) Deputy Inspector General of Police  Himself and his
establishment and
establishmentof the Finger
Print Bureau.
 Note.Special Superintendent of Policesigns for
Deputy Inspector General.
(23) Director of Public Instruction  Himself, his personal
assistant and
ministerialan menial staff
of the office, Inspectors
and AssistantInspectresses
of Schools and their
establishment, Assistants
tothe Director forFundamental Rules and Subsidiary Rules

Muhammadan Education
and his
establishment,Headmistress
of Pine Mount School and
establishment,
Principalsand Professors
of College and
establishment of
Colleges,Secretary for
Higher Sanskrit Learning
and establishment of
theInstitution, Principal
and establishment of the
GovernmentMadrassa,
Principal and
establishment of the
H.R.H. Prince ofWales
Technical School, Jorhat.
(24) Director of Public Health  Himself, Assistant
Director of Public
Health,his ministerial and
menial establishment,
staff of the
StateLaboratory.
(25) []
[Substituted vide
Correction Slip
No. 36 (FM
199/74/1, dated
6th March,
1975).]Joint Director of HealthService (R)  Assistant Surgeon,
Sub-Assistant Surgeons
andother Subordinate staff
under his control.
(26) Director of Agriculture  Himself, his own office
staff, Deputy Directorsof
Agriculture, Agricultural
Chemist, Economic
Botanist,Superintendents
of Agriculture and their
establishments
andInspector of
Government gardens.
Marketing Officer, Assam,
clerksand peons of the
marketing section.Fundamental Rules and Subsidiary Rules

(27) Deputy Director of Agriculture, Live-stock  Agricultural Inspector,
Khasi and Jaintia Hillshis
peon and the
Demonstrators under him.
(28) Economic Botanist, Assam  Fruit Inspector, his peon
and the
demonstratorsunder him.
(29) Principal, Assam Agricultural College  His own office,
non-gazetted staff
includingstipendiaries and
menials of the Assam
Agricultural College.
(30)Deputy Commissioners of Garo Hills, United
Khasiand Jaintia Hills, United Mikir and North
Cachar Hills and MizoDistrict Agricultural Inspectors.
(31)Director of Industries and Registrar
ofCo-operative Societies Himself, Weaving
Superintendent and
hisestablishment of the
Gauhati Weaving School,
Superintendent
ofSericulture and his
establishment,
establishment of
Sericulturalstations at
Titabar and Shillong,
Assistant Registrars
ofCo-operative Societies,
Auditors and Inspectors of
Co-operativeSocieties and
their establishment.
 Note.Deputy Registrar of Co-operativeSocieties
may sign for Registrar of Co-operative Societies.
(31-A) Director, Veterinary, Department  Himself and Deputy
Superintendent,
allsubordinates and
ministerial and menial
establishment of
theVeterinary
Department.
(32) Principal, Assam Veterinary, College  His own office,
non-gazetted staff
includingstipendiaries and
menials of the AssamFundamental Rules and Subsidiary Rules

Veterinary College.
(33) Examiner, Local Accounts  Himself, Office
establishment and
LocalAuditors.
(34) Chief Secretary  Himself, all officers of the
Secretariat belowthe rank
of Deputy Secretary, all
ministerial and Grade
IVestablishment of the
Civil Secretariat.
 Note.Under-Secretary to the Governmentof
Assam in the Secretariat Administration
(Accounts) Departmentsigns for the Chief
Secretary.
(35) Secretary Labour  Himself, Chief Inspector of
Boilers, Assam.
(36)Secretary, Education and Local Self
GovernmentDepartments Himself, Honorary State,
Director, Department
ofHistorical and
Antiquarium Studies,
Assam.
(37) Finance Secretary  Himself, all officers of the
Civil Secretariat,below the
rank of Secretary.
(38) Secretary, P.W.D.  Himself and other
gazetted and
non-gazettedstaff of the
Secretariat.
 Note.The Deputy Chief Engineer signs theT.A.
bills of all Gazetted Officers for Chief Engineer,
whileRegistrar signs T.A. bills of all non-gazetted
staff for ChiefEngineer.
(38-A) Secretary, Flood Control and Irrigation  Himself and other
gazetted and
non-gazettedstaff of the
Secretariat.
(39)Chief Electrical Inspector and ElectricalAdviser,
Assam Himself.
(40) Secretaries to Government  Themselves and Deputy
Secretaries to
Governmentunder their
respective control.Fundamental Rules and Subsidiary Rules

 Note.Under-Secretaries and DeputySecretaries
sign for Secretaries.
(41) Joint Secretaries to Government  Themselves.
(42) Secretary, Legislative Assembly  Himself, ministerial and
menial staff of hisoffice.
(43)Secretary, Legislative Department andLegislative
Council and Legal Remembrancer Himself, ministerial staff
and menial staff
andGovernment Pleaders
and Public Prosecutors.
(44) Speaker, Legislative Assembly  Himself.
(45) President, Legislative Council  Himself.
(46) Military Secretary  Himself, the Aide-de-camp
and his staff.
(47) District and Sessions Judges  Themselves, Additional
and Assistant
andSubordinate Judges,
ministerial and menial
establishments
ofthemselves and their
subordinates.
 Note 1.Additional Judges sign forDistrict and
Sessions Judges when on tour.
 Note 2.The Judge, Assam Valley Districtswill
countersign the T.A. bills of the Stamp Checking
Officer,Assam for journeys performed by him in
that valley.
(48) Officers-in-charge of Forest Divisions  Non-gazetted Forest staff
of the ForestDivision.
(49) Executive Engineers  Assistant Executive
Engineers,
AssistantEngineers,
Supervisors, Upper and
Lower Subordinates,
technical,ministerial and
work-charged
establishment of their
division.
(50)Executive Engineer, Khasi and Jaintia
HillsDivision Electrical mistri.
(51) Executive Engineer, Lower Assam Division  Crew of the yacht
"Sonamukhi".Fundamental Rules and Subsidiary Rules

(52) Executive Engineer, Golaghat Division  Medical staff of the
Dimapur Manipur Cart
Road.
(53) Civil Surgeons  Assistant and
Sub-Assistant Surgeons,
HealthOfficers, Inspectors
and Sub-Inspectors of
vaccination
anddisinfectant carriers,
compounders, ministerial
and menial staffof their
own offices and of
Government Police and
Jail Hospitalsand
Dispensaries and
vaccinators.
(54) Principal, Assam Medical College.  Professors, Assistant
Professors,
Secretary,Curator,
Lecturers, Demontrators,
Taxidermists,
LaboratoryAssistant,
X-ray Mechanic,
ministerial and menial
establishmentsunder his
control.
(55)Civil Surgeons or Civil Assistant Surgeons
asSuperintendents of Jails Subordinate, medical,
ministerial and
menialestablishments,
below the rank of Jailor.
(56) Civil Surgeons, Khasi and Jaintia Hills  Sub-Assistant Surgeon
attached to
GovernmentHouse, and
his establishment.
(57)Director, Pasteur Institute and Medical
ResearchInstitute Technical, ministerial and
menial staff.
(58)Principal, Assam Medical College
asSuperintendent Bery-White Medical School Teaching and other staff of
the School.
(59) Superintendent, Mental Hospital  Technical and other staff
of the MentalHospital.
(60) Superintendent of Police  Assistant Superintendent
and
DeputySuperintendentsFundamental Rules and Subsidiary Rules

and Subordinate Officers
of Police, ministerialand
menial establishment of
the District.
(61) Superintendent of Railway Police  All ranks of Railway
Police, ministerial
andmenial establishment
of his office.
(62)Superintendent of Police, Deputy
Commissionerin-charge of Police and Political
Officer Motor vehicles staff.
(63) Deputy Director of Agriculture  Inspectors of Agriculture
except in the case ofKhasi
and Jaintia Hills,
Demonstrators except
those placed underdirect
control of District Officers,
Farm Managers and
farmstaff, including
apprentices, Entomoligical
Assistant and hispeon.
(64) Marketing Officer  Assistant Marketing
Officers,
MarketingInspector, their
peons and Marketing
Demonstrators.
(65) Weaving Superintendent  Peripatetic Weaving
parties.
(66) Agriculture Chemist  Himself and his staff.
(67) Economic Botanist  Scientific Assistant under
him and
HorticulturalAssistant and
his Subordinates, Citrus
Fruit Experiment
Station,Burnihat.
(68) Inspectors of Schools  Assistant Deputy and
Sub-Inspectors of
Schoolsand establishment
of all Schools under their
control.
(69) Inspectresses of Schools  Assistant Inspectresses of
Schools andFundamental Rules and Subsidiary Rules

herestablishment and all
officers under her control.
(70) Chief Inspector of Factories  Assistant Electrical and
Factory
Inspector,technical,
ministerial and menial
staff of his office.
(71) Chief Inspector of Boilers.  Inspector of Boilers,
technical, ministerial
andmenial staff of his
office.
(72) Commissioner of Excise  Himself, his personal
assistant and
theministerial and menial
staff of his office, the
SpecialSuperintendent of
Excise and his
establishment and all
ExciseOfficers, Jamadars
and peons appointed to
the special staff.
(73) Special Superintendent of Excise  Excise peons of the Special
Branch.
(74) Assistant Registrars of Co-operative Societies  Inspector of Co-operative
Societies and
theirestablishments.
(75) Deputy Director of Agriculture, Live-stock  Managers and other
non-gazetted staff
includingapprentices of
the two farms at
Khanapara and at Upper
Shillongand the Inspector,
the Demonstrator and the
peon of theCo-operative
Mills Societies, Surma
Valley.
(76)Honorary State Director, Deputy Director
ofHistorical and Antiquarian Studies, Assam Ministerial and menial
staff of his office.
(77) Chairman, Assam Public Service Commission  Himself, Members and
Secretary of
theCommission.
(78) Secretary, Assam Public Service Commission  Ministerial and menialFundamental Rules and Subsidiary Rules

staff of the Commission.
(79) Private Secretary to the Governor  Himself, Political Agent,
Manipur, PoliticalOfficer,
Sadiya and Balipara
Frontier Tracts,
ministerial andmenial staff
of his office, excepting in
the case of Naga
Hillswhere the Deputy
Commissioner will be the
Controlling Officer.
(80)Asstt. Commissioner and Secretary to the
Boardof Agricultural Income-tax, Assam Himself, ministerial and
menial staff of hisoffice.
(81)Secretaries, State and Regional
TransportAuthorities Ministerial and menial
establishment of
theiroffices.
(82) Principal, Ayurvedic College  Officers, clerks and
menials under him.
(83) Director of Statistics  Himself, his own office
staff, District officestaff
and other Gazetted and
non-gazetted officers
under him.
(84)Principal Private Secretary to the ChiefMinister,
Assam Himself.
(85) Director of Information and Publicity  Himself, his own office
staff, District officestaff
and all other Gazetted and
non-gazetted officers
under him.
(86)Deputy Secretary to the Government of
Assam,General Administration Department Liaison Officer, Assam
House, New Delhi.
(87)Under-Secretary to the Government of
Assam,General Administration Department Non-Gazetted staff in the
office of the
LiaisonOfficer, Assam
House, New Delhi.
(88) Director of Soil Conservation  Himself, all Gazetted
Officers of tireDepartment
and all subordinate staff
attached to the
Directorate.
(89) Joint Director of Soil Conservation Research  Fundamental Rules and Subsidiary Rules

Non-gazetted staff
attached to the
ResearchStation.
(90) Divisional Soil Conservation Officer  Non-gazetted staff of the
Soil ConservationDivision.
(91)Public Analyst to the Government of
Assam,Chemical Examiner (Excise) and
Officer-in-charge State PublicHealth Laboratory,
Shillong Technical, ministerial and
other staff of theState
Public Health Laboratory
and technical, ministerial
andother staff of Regional
Laboratory, Gauhati.
(92)Director, Inland Water Transport, Assam,
Gauhati Himself, his own office
staff and all
Gazettedofficers
subordinate to him.
(93)Executive Engineers, Inland Water
TransportDivision, Assam. All Sub-Divisional
Officers,
AssistantEngineers, Upper
and Lower Subordinates,
Technical ministerialand
work-charged
establishment of their
Divisions.
(94)Training Supdt. Crew Training Centre,
Assam,Gauhati Assistant Training Supdt.,
InstructorsTechnical,
ministerial and menial
staff.
(95) D.P.I.'s Assam, Shillong  Himself, all gazetted and
non-gazetted officersof his
office and heads of all
subordinate offices under
hiscontrol.
(96) Principal, Government College  Office staff including all
gazetted andnon-gazetted
officers under his control.
(97) Inspector of Schools  Office staff of his own and
subordinate
officersincluding gazetted
and non-gazetted officers
under his control.
(98) Principal, State Institute of Education, Jorhat  Office staff including
gazetted andFundamental Rules and Subsidiary Rules

non-gazettedofficers under
his control.
(99) Principal, Post Graduate Training Centre, Jorhat  Ditto
(100) State Education Officer  Ditto
(101) Director of Museum and Archaeology, Gauhati  Office staff including
gazetted and
non-gazettedofficers under
his control.
(102) Librarian, State Central Library  Ditto
(103) D.D.P.I.,N.C.  Civilian office staff of all
N.C.C. Unit,Special
officers of N.C.C. (I) and
(II).
(104) Director of Financial Inspections, Assam  Himself and his
subordinate officers
(bothgazetted and non-
gazetted) and staff under
him.
(105)Additional Director of Information and
PublicRelations (Hills), Assam All Subordinate Officers
(both gazetted)
andnon-gazetted and staff
under him.
[Appendix 31] [Substituted vide Correction Slip No. 513 to Assam Subsidiary Rules to take effect
from 9th September, 1961.]Rules regarding medical examination and treatment of tubercular
Government servants in the T.B. sanatorium and clinic, Shillong and other recognised institutions in
Assam
1. All Government servants suffering or suspected to be suffering from
tuberculosis should at first be sent through the District Medical Officer to the
nearest Tuberculosis Clinic and if so required to the State Clinic or
Sanatorium, Shillong or the nearest recognised institution for diagnosis or
treatment.
2. If after careful examination by the Medical Officer-in-charge of the case or
of the institution, the case is reported to be a "closed" or one and the person
is considered to be fit to carry on his duties, he will be allowed to continue in
his appointment under the following conditions :
(a)That remains under suitable medical supervision and treatment of a Government doctor where
there will be no charge. When the Civil Surgeon or the Sub-divisional Medical Officer certifies that
this is not possible a tubercular Government servant may be placed under supervision andFundamental Rules and Subsidiary Rules

treatment of a Private Medical practitioner. In that case the charges will have to be paid by the
patients. A special register of such cases will be maintained by the Medical Officer-in-charge of the
case so that the patient may be followed up regularly from time to time in the interest of public
health as well as of the patient.(b)That the Government servants suspected of tuberculosis or
suffering from "closed" and "quiescent" tuberculosis shall undergo periodical re-examination by his
proper Government Medical Officer, and if necessary by a competent authority in tuberculosis
approved by the Government. The re-examination will be done by the Government Medical Officer
free of charge.In the case of tubercular Government servant (Gazetted or non- Gazetted) drawing
pay to Rs. 600 per mensem, the entire charges incurred by him for his treatment will be
re-imbursed to him by the Government and in the case of tubercular Government servant (Gazetted
or non-Gazetted) drawing pay more than Rs. 600 per mensem half the charges will be borne by the
Government servant himself and the other half reimbursed to him by the Government. Tubercular
Government servants drawing pay up to Rs. 600 per mensem may be admitted in free beds in
Government T.B. Hospital as far as possible.
3. If after careful examination the case of a tubercular permanent
Government servant is found to be an "open" one he will be granted leave on
average pay for 18 (eighteen) months by instalments of four months on the
recommendation of the Medical Officer concerned, in addition to all other
leave due to him as provided in Revised Leave Rules, 1934. During the period
of leave so granted or thereafter but during such period of leave ordinarily
granted to him under the leave rules to which he is subject to, if Medical
authority thinks that there is no reasonable prospect of his recovery, then by
will be invalidated and proportionate pension as prescribed by rule, be
sanctioned. If before the expiry of the maximum leave his case is certified to
have become a "closed" one, he will be allowed to resume his appointment
under condition laid down in Cl. (b) of Rule 2 for closed quiescent case.
In order to avoid break in the services of a temporary Government servant, with over one year's
service superior or inferior and to enable such a Government servant to return to his appointment
after proper treatment he will be granted 18th months' extraordinary leave as provided in the Leave
Rules, 1934. In addition to all his leave due-under the Revised Leave Rules, 1934 as amended by
Assam Government Notification No. FEG 50/56/15, dated 24th October, 1957, subject to the
following conditions :(i)The post from which the Government servant proceeds on leave is likely to
last till his return to duty,(ii)The extraordinary leave shall be granted on production of certificate
from the Medical officer-in-charge of the Sanatorium or institution specifying the period for which
leave is recommended, and(iii)The Medical Officer in recommending leave shall bear in mind the
provision of S.R. 77.Note 1. The expression "Leave on average pay" in the case of a permanent
Government servant subject to Leave Rules, 1934 means leave-salary equivalent to what is
admissible under Rule 15 of these Rules as amended.Fundamental Rules and Subsidiary Rules

4. A Government servant suffering or suspected to be suffering from
tuberculosis will be entitled to travelling allowance under S.R. 297 for
journeys undertaken by him to and from the Clinic or Sanatorium or
Institution for diagnosis or treatment. Travelling allowance for journeys to a
Sanatorium or Clinic outside the State will be admissible, provided a
certificate is given by the Director of Health Services that treatment in such
Sanatorium or Clinic was necessary in the interest of the patient.
5. No fee will be levied from the patient for X-Ray treatment.
6. (a) A tubercular Government servant drawing pay up to Rs. 600 per
mensem will be treated free in the general ward, but if his pay is more than
Rs. 600 per mensem he shall have to bear himself the charges for
accommodation including diet, all sorts of medicines and treatment in the
general ward.
(b)If a tubercular Government servant fails to have a seat in Government or recognised Hospital or
Institution or Clinic and Sanatorium he may have treatment at home or in a private hospital, etc., on
advice of any authorised Medical Attendant/Officer. In such cases Rule 6 (a) above will also be fully
applicable ; Provided that the authorised Medical Attendant/Officer must certify prior to
Government servant's having the treatment at home or in a private hospital, etc., that a seat is not
available in the general or any of the paying wards in order to entitle a patient to claim the
reimbursement under this sub-rule.(c)If a tubercular Government servant fails to have a seat in the
ward which he is entitled to, he shall have to be accommodated in any paying ward provided seat is
available. In that case he shall have to bear all expenses minus all the charges of the seat to which he
is or was entitled to under these rules.
7. The officers of higher grades or other than those mentioned in Rr. 2 (a) and
6 will be accommodated in the private wards of the Sanatorium.
Private Ward No.1 For Officers of the All-India Services or Gazetted Officers drawing pay above Rs.
750 per mensem.Private Ward No.2 For Gazetted Officers drawing pay above Rs. 650 per mensem
but not exceeding Rs. 750 per mensem.Semi-Private Ward. For Gazetted and non-Gazetted Officers
drawing pay above Rs. 500 per mensem, but not exceeding Rs. 650 per mensem.Note. In all other
recognised Institutions such accommodation as is available and suited to the status of the tubercular
Government servant concerned will be provided and charges will be levied according to the
scheduled rates of the Institution accommodation in the general or free ward being regarded as
suitable for the tubercular Government servants drawing pay up to Rs. 600 per mensem.The
following rates of charges will be levied for accommodation and treatment in the aforesaid wards of
the Sanatorium :Private Ward No.1 From Rs. 8 to Rs. 15 daily.Private Ward No.2 From Rs. 3 to Rs. 6
daily.Semi-Private Ward. From Rs. 2 to Rs. 3 daily.Extra charges will be levied for Major SurgeryFundamental Rules and Subsidiary Rules

and Special Food only.
8. No officer will be entitled to dispose a patient already in occupation of a
bed. Ten per cent of the seats in the sanatorium will be reserved for
Government servants irrespective of classification and priority of vacancy.
9. The rates of fee as laid down in Rule 10 below will be charged for X-Ray
examination of the families of Government servants in the State T.B. Clinic at
Shillong.
10. Families of Government servants whose pay is less than Rs. 200 per
mensem will be examined free. A fee of Rs. 6 will be charged for families of
Government servants drawing pay between Rs. 200 to Rs. 600 per mensem
and Rs. 10 for the families of those drawing above Rs. 600 per mensem.
11. All vouchers of medicines, diet, etc., allowance under Rule 6 shall have to
be countersigned by the Medical Officer concerned alongwith an essentiality
certificate for the purpose of reimbursement.
12. Administration Departments are hereby authorised to sanction
reimbursement to any tubercular Government servants under them with the
concurrence of Finance Department. They, however, must follow these rules
and procedure strictly and rigidly. Expenditure may be met from the
respective heads of account under the Department concerned.
[Appendix 32] [Substituted vide Correction Slip No. 502 to Assam Subsidiary Rules.]Form ABond
for permanent Government servants proceeding on Study Leave under the Study Leave Rules
contained in Appendix 15-Part I to the A.F. Rr. and A.S Rr.Know all men by these presents that
I......... resident of........ in the District of........at present employed as..........in the Department
of/office of.........do hereby bind myself and my heirs, executors and administrators to pay to the
Governor of Assam (hereinafter called "the Government") on demand the sum of Rs............
(Rupees..........) together with interest thereon from the demand at Government rates for the time
being in force on Government loans or, if payment is made in a country other than India the
equivalent of the said amount in the currency of that country converted at the official rate of
exchange between that country and India and together with all costs between attorney and client
and all charges and expenses that shall or may have been incurred by the Government.Dated
this.......... day of........two thousand and....Whereas the above bounden...........his granted study leave
by Government;And whereas for the better protection of the Government the above-bounden has
agreed to execute this bond with such condition as hereunder is written ;Now the condition of the
above written obligation is that in the event of the above bounden.............not conforming to the
instructions regarding study/training conveyed to him by an authorised agent of the Governor ofFundamental Rules and Subsidiary Rules

Assam or of his continued adverse report regarding the progress of his studies/training or regarding
his conduct or the above bounden resigning or retiring from service without returning to duty after
the expiry of termination of the period of study leave or at any time within a period of 3 years after
his return to duty or the above bounden.........refusing to serve the Governor of Assam if required to
do so an officer of the Government of Assam in any other employment indicated by the Governor of
Assam for a minimum period of 5 years he shall forthwith pay to the Government or as may be
directed by the Government on demand the said sum of Rupees............ (Rupees...........) together
with interest thereon from the date of demand at Government rates for the time being in force on
Government loans;And upon the above bounden..............making such payment the above written
obligation shall be void and of no effect, otherwise it shall be and remain in full force and virtue.The
Government of Assam have agreed to bear the stamp duty payable on this bond.Signed and
delivered by the above bounden............ in the presence of..........AcceptedFor and on behalf of the
Governor of AssamForm BBond for temporary Government servants proceeding on Study Leave
under the Study Leave Rules contained in Appendix 15-Part I to the F.Rr. and A.S. Rr.Know all men
by these presents that we.............resident of.........in the District of....... at present employed
as...........in the Department of/office of...... (hereinafter called "the obligor") and Shri......... son
of....... of.......and Shri....... son of....... of....... sureties on his behalf do hereby jointly and severally
bind ourselves and our respective heirs, executors and administrators to pay the Governor of Assam
(hereunder called "the Government") on demand the sum of Rs......... (Rupees............) together with
interest with interest thereon from the date of demand at Government rates for the time being in
force on Government loans, or, if payment is made in a country other than India, the equivalent of
the said amount in the currency of that country converted at the official rate of exchange between
that country and India and together with all costs between attorney and client and all charges and
expenses that shall or may have been incurred by the Government.Dated this......... day of.......two
thousand and..........Whereas the above bounden............is granted study leave by the
Government:And whereas for the better protection of the Government the above bounden has
agreed to execute this bond with such condition as hereunder is written ;And whereas the said........
and........ have agreed to execute this bond as sureties on behalf of the above bounden ;Now the
condition of the above written obligation is that in the event of the above bounden
obligor............Shri........resigning from service without returning to duty after the expiry or
termination of the period of study-leave or at any time within a period of 3 years after his return to
duty or the above bounden obligor Shri............ not conforming to the instruction regarding
studies/training to him by an authorised agent of the Governor of Assam or of his continued adverse
reports regarding the progress of his studies/ training or regarding his conduct or the above
bounden Shri............refusing to serve the Governor of Assam if required to do as an officer of the
Government of Assam in any other employment indicated by the Governor of Assam for a minimum
period of 5 years the obligor and sureties shall forthwith pay to the Government or as may be
directed by the Government on demand the said sum of Rupees......... (Rupees........) together with
interest thereon from the date of demand at Government rates for the time being in force on
Government loans;And upon the above bounden obligor Shri..........and/or Shri.........and/or
Shri..........the sureties aforesaid making such payment the above written obligation shall be void and
of no effect otherwise it shall be and remain in full force and virtue :Provided always that the
liability of the sureties hereunder shall not be impaired or discharged by reason for the time being
granted or by any forbearance act or omission of the Government or any person authorised by themFundamental Rules and Subsidiary Rules

(whether with or without the consent or knowledge of the sureties) nor shall it be necessary for the
Government to sue the said obligor before suing the above bounden sureties Shri..........and
Shri.........or any of them for amounts due thereunder.The Government of Assam have agreed to bear
stamp duly payable on this bond.Signed and delivered by the above bounden Shri........ in the
presence of........Signed and delivered by the surety above-named Shri.........in the presence
of.......Signed and delivered by the surety above-named Shri..........in the presence of.......AcceptedFor
and on behalf of the Governor of AssamAssam Fundamental Rule Form No. 1Leave Account
of................Date of commencement of service........Date of contract, if any.........
Date  Leave Earned Leave at CreditTotal of
Columns
6+7
1/11th of duty
subsequent to
coming
underFundamental
Rules (Rule 81
(b) (ii)]Balance of 2/11th
of duty
subsequent to
comingunder
Fundamental
Rules1/11th of duty
subsequent to
coming
underFundamental
Rule [Rules 81 (b)
(ii), Columns
16+4]Balance of 2/11th
of duty subsequent
to comingunder
Fundamental
Rules [Columns
17+4]
1 2 3 4 5 6 7 8
From To Y. m. d. Y. m. d. Y. m. d.Y.
m.
d.Y.
m.
d.Y.
m.
d.
Government        
served under        
Ordinary Leave RulesDate of attaining the age of 55-60 years.............Date of coming under Civil
Leave Rules...............Leave TakenOn average pay
DatesAgainst entries
in column 6Against the limit of one year for leave onmedical certificate and leave spent
elsewhere than in . India,Ceylon, Nepal, Burma or Aden [proviso to Rule
81 (b) (ii)]
9 10 11
From
toY. m. d. Y. m. d.
Balance (on return from leave)On half or quarter average pay
Dates Actual
periodActual
period
converted
into period
on terms
ofleave on
average payTotal
(Columns
10+11+14)Of leave equivalent
to 1/11th of duty
subsequentto
coming under
Fundamental Rules
[Rule 81 (b) (ii)
(Columns6-10]Of leave
equivalent to
balance of 2/14th
of dutysubsequent
to coming under
Fundamental
Rules (Column
7)minus(ColumnTotal
Columns
8-15)RemarksFundamental Rules and Subsidiary Rules

11+14)
12 13 14 15 16 17 18 19
From
toY. m.
d.Y. m. d. Y. m. d. Y. m. d. Y. m. d. Y. m. d. Y. m. d.
Instructions for filling up Assam Fundamental Rule Form No. 1
1. The account is to be maintained in terms of leave on average pay. For this
purpose actual periods of leave taken on half or quarter average pay as
entered in column 13 should be divided by 2 and posted in column 14.
2. In the case of officers who were subject to the Civil Service Regulation
Leave Rules before they elected the Fundamental Rules, the account should
commence with an opening entry in columns 4,5, 6, 7, 8,11,13, 14, 15, 16,17
and 18. The words "Due on date of coming under the Fundamental Rules"
should be written across columns 1, 2 and 3 against these words credit
under Rule 77 (b) (ii) (1) should be given in column 4 and column 6 and that
under Rule 77 (b) (ii) (2) and Rule 77 (e) in column 5 and column 7 while debit
for commuted furlough taken under the old Leave Rules should be given in
column 11 and that under Rule 78, Note (2) (i) (a) in column 13, one-half of the
latter being entered in column 14. The sum total of the entries in columns 6
and 7 and in columns 11 and 14 should be entered in columns 8 and 15
respectively. The difference between the entries is columns 8 and 15, should
be entered in column 18 and the entry in column 4 or 6 should be repeated in
column 18 while the entry in column 5 or 7 minus the sum total of the entries
in columns 11 and 14 should be shown in column 17.
3. When a Government servant applies for leave, columns 1 to 8 should be
filled up. Columns 1, 2 and 3 should show the Government servant under and
the period of duty up-to-date preceding that on which the Government
servant intends to go on leave and columns 4,and 5 should each show 1/11th
of this period (but see Note below), the sum total of the two entries
representing the period of leave i.e., 2/11th of duty earned under Rule 77 (b)
(ii) (3). To the new entry in column 4 should be added the last entry in column
16 and the resultant figure should be posted in column 6 ; similarly to the
new entry in column 5 should be added the last entry in column 17 and the
resultant figure should be posted in column 7. The total of the entries in
columns 6 and 7 will be shown in column 8.Fundamental Rules and Subsidiary Rules

Note 1. If during the period of duty prior to a Government servant's going to leave he has served
under two of more Governments, the period of duty and the leave earned under each Government
should be shown in separate lines in columns I to 5 and the sum total of the new entries in column 4
and the last entry in column 16 should be posted in column 6 and of those in column 5 and the last
entry in column 17, in column 7 the total of the entries in columns 6 and 7 being shown in column
8.Note 2. The sum total of the entries in column 5, inclusive of the opening entry mentioned in
Instruction No. 2 should not exceed 2 ½ years [Rule 81 (a) (ii)] and no entry should be made in this
column when this limit of 21 years is reached.When columns 1 to 8 have been posted, column 8 will
show the maximum amount of leave which may be granted in terms of leave on average pay but see
Rule 81 (d) to Government servant on the date on which he intends to go on leave.The maximum
amount of leave on average pay which may be granted on that date with medical certificate or out of
India, Ceylon, Nepal, Burma or Aden will be the sum total of the last entry in the column 6, and the
unspent balance of "one year" limited to 8 months at a time, provided the sum total is covered by the
period entered in column 8 ; in the case of leave in India, Ceylon, Nepal, Burma or Aden without
medical certificate the maximum will be the last entry in column 6 limited to 4 months at a time.
4. When a Government servant returns from leave columns 9 to 18 should be
filled up. The period of leave taken on average pay should be entered in
columns 9, 10 and 11 and that taken on medical certificate or spent
elsewhere than in India, Ceylon, Nepal, Burma or Aden should be entered in
column 11 till the limit of one year is reached and thereafter in column 10.
The actual periods of leave on half or quarter average pay and overstayed on leave [vide F.R. 73]
should be entered in column 13 and one-half of it, in column 14.Note 1. Leave on average pay taken
under the Fundamental Rules in India without medical certificate in excess of the last entry in
column 6 before the detention or plus "one year" from R. 81 (b) (ii) should be entered in column
11.Note 2. If the leave taken exceeds the amount at credit, the excess representing leave, not due but
granted under Rule 81 (c) (i) and (ii) should be shown in red ink in column 11.
5. The total period of leave in terms of leave on average pay taken in a
Government servant's whole service as entered in column 15 should not
exceed the privilege leave credited to him in column 4 on his coming under
the Fundamental Rules plus all periods of leave subsequently entered in that
column plus 2 ½ years.
6. When a Government servant is transferred to service under another
Government, a separate account should be opened in this form for showing
the leave entered under the Government and the leave the cost of which is
debited to that Government. The amount will be in addition to the main leave
account which must be a complete record of all leave earned and taken
under these rules throughout this service.Fundamental Rules and Subsidiary Rules

Form No. 2[Subsidiary Rule 73]Application for leaveNote. Items 1 to 9 must be filled in by all
applicants whether gazetted or non-gazetted.Items 12 applies only in the case of gazetted
officers.Item 13 and 14 apply only in the case of non-gazetted officers.
1. Name of applicant..........
2. Leave Rules applicable............
3. Post held.......
4. Department or office.......
5. Pay..........
6. House rent allowance, conveyance allowance or other compensatory
allowances drawn in the present post.............
7. Nature and period of leave applied for and date from which required....
8. Ground on which leave is applied for......
9. Date of return from last leave, and the nature and period of that
leave............
10. I undertake to refund the difference between the leave-salary drawn
during leave on average pay/commuted leave and that admissible during
leave on half average pay/half pay leave, which would not have been
admissible had the proviso to F.R. 18 (b) (ii)/Rule 13 (c) (iii) of the Revised
Leave Rules, 1934 not been applied in the event of my retirement from
service at the end or during the currency of the leave...............
Date.........Signature of applicantLeave address
11. Remarks and/or recommendation of the Controlling Officer..............
Date..........SignatureDesignation
12. Report of the Audit Officer :
SignatureDate..........DesignationFundamental Rules and Subsidiary Rules

13. Statement of leave granted to applicant previous to this application........
Nature of leave In current year During past year Total
Privilege/on average pay/earned    
On average pay on M.C./Commuted    
On half average pay/half pay    
Not due........    
On quarter average pay    
Extraordinary    
   Total........
14. Certified that leave on average pay/earned leave...... for...... months
and...... day from......20....to.......20....is admissible....... under..... of the...........
SignatureDate..........Designation
15. Orders of the sanctioning authority
SignatureDate.........DesignationCorrection Slips of MeghalyaCorrection Slip No. 1For F. R. 14 (2)
(IV). the following shall be substituted, namely :"Rule 14 (2) (IV)-A temporary Government servant
who has completed two years continuous service on the date of expiry of leave of the kind due and
admissible under the rules (including three months extraordinary leave) is entitled to get
extraordinary leave for prosecuting higher studies, certified to be in the interest of public service,
and the period of extraordinary leave would ordinarily be extended to the period of the course of
study not exceeding 48 months but in exceptional circumstances, about which Government in the
Finance Department must be satisfied, the total period may be extended up to 60 months during the
entire service of Government servant."Appendix 5Insert "Chief Public Health Engineer, Meghalaya"
below the existing entry.Correction Slip No. 2Appendix 12Insert the following entries below the
existing entry :
"Officer Class of appointments Remarks
Chief Public Health
Engineer, MeghalayaAll non-gazetted
establishments under his
controlSubject to observance of rules and
regulations issued byGovernment from time
to time".
Correction Slip No. 3S.R.6. - For the words "twenty-five" appearing in the second line, the words
"twenty-seven" shall be substituted.The above amendment shall be deemed to have effect from
1-1-1973. Cases already disposed of prior to 11-6-1973 shall not be re- opened.F.R.56. - Insert the
following below F.R. 56 (a):"(b) Notwithstanding anything contained in these rules the appropriate
authority may if he is of the opinion that it is in the public interest to do so, retire a Government
servant by giving him notice of not less than three months in writing or three months' pay and
allowance in lieu of such notice, after he has attained fifty years of age or has completed 25 years of
service, whichever is earlier.(c)Any Government servant may by giving notice of not less than three
months in writing to the appropriate authority, retire from service after he has attained the age ofFundamental Rules and Subsidiary Rules

fifty years or has completed 25 years of service whichever is earlier.Note. The term "appropriate
authority" referred to in the above clauses means the authority which has the power to make
substantive appointments to the post or service from which the Government servant is retired or
wants to retire".Correction Slip No. 4Rules 7 and 13 of the Revised Leave Rules, 1934, as amended
and as incorporated in Appendix 11
1. After the existing proviso to Rule 7 the following shall be inserted :
"(c) A Government servant who is granted leave beyond the date of Compulsory retirement or
quitting of service, as the case may be, shall be entitled during such leave to leave-salary admissible
under this rule reduced by the amount of pension and pension equivalent of other retirement
benefits".
2. Below the existing Rule 13 (c) (iii) the following shall be inserted :
"(iv) In case a Government servant dies in harness, the cash equivalent of the leave-salary that the
deceased employee would have got had he gone on earned leave, but for the death due and
admissible, on the date immediately following the date of death, subject to a maximum of
leave-salary for 120 days, shall be paid to his family subject to reduction envisaged in Rule 7".The
order will apply to Classes II, III and IV Government employees.S.R.6. - Delete the word "Superior"
appearing in the fourth line of S.R. 6.Correction Slip No. 5F.R.22C. - Delete the existing first proviso
below F.R. 22-C and insert the following :"Provided that in all cases of promotion from one Class I
post to another Class I post, the pay in the higher scale should be fixed at the stage next above the
pay drawn in the lower scale irrespective of whether the lower post was held in a substantive,
officiating or temporary capacity".(1)Appendix 5-Insert "Director of Supply, Meghalaya" below the
existing entry.(2)Appendix 30-Insert the following entries below the existing entry.
Controlling Officer Officer or Establishment
Director of Supply Himself and his establishment
Correction Slip No. 6For S.R. 151, the following shall be substituted :"S.R. 151 (1). - Contribution for
leave-salary or pension, due in respect of a Government servant on foreign service may be paid
annually within fifteen days from the end of each financial year or at the end of the foreign service, if
the deputation on foreign service expires before the end of a financial year, and if the payment is not
made within the said period, interest must be paid to Government on the unpaid contribution,
unless it is specifically remitted by the State Government, at the rate of two paise per day per Rs.100
from the date of expiry of the period aforesaid up to the date of which the contribution is finally
paid. The interest shall be paid by Government servant or the foreign employer according as the
contribution is paid by the former or the latter.(2)The leave-salary and pension contribution should
be paid separately as they are creditable to different Heads of Accounts and no dues recoverable
from Government on any account, should be set off against these contributions.Correction Slip No.
7No. FEG. 39/76/24, dated the 17th August, 1979. - In exercise of the powers conferred by the
proviso to Article 309 of the Constitution of India, the Governor is pleased to direct that the
following amendment shall be made to the Fundamental Rules, namely :For the existing firstFundamental Rules and Subsidiary Rules

proviso to F.R. 22-C the following shall be substituted : "Provided that in all cases of promotion
from one Class I to another Class I post, the pay in the higher scale should be fixed at the stage next
above the pay drawn in the lower scale irrespective of whether the lower post was held in a
substantive, officiating or temporary capacity."This will come into force with effect from the date of
issue of orders.Correction Slip No. 8No. FEG. 85/80/7, dated 25th November, 1980. - In exercise of
the powers conferred by the proviso to Article 309 of the Constitution of India, the Governor of
Meghalaya is pleased to direct that the following further amendment shall be made to the
Fundamental Rules, namely :Insert the following below the existing Rule 7 of the Revised Leave
Rules, 1934, as incorporated in Appendix 11 of the Fundamental Rules and Subsidiary Rules
:"Notwithstanding anything contained in these rules every State Government servant shall be paid
cash equivalent of leave salary in respect of the period of earned leave at his credit at the time of his
retirement or superannuation subject to the following conditions :(a)The payment of cash
equivalent of leave salary shall be limited to a maximum of 180 days earned leave.(b)The cash
equivalent of leave salary thus admissible will become payable on retirement and will be paid in one
lump sum as one time settlement.(c)Cash payment under this rule will be equal to leave salary as
admissible for earned leave and dearness allowance admissible on that leave salary at the rates in
force on the date of retirement. No compensatory allowance and/or House Rent Allowance shall be
payable.(d)The authority competent to grant leave shall suo-moto, issue order granting cash
equivalent of earned leave at credit on the date of retirement.Government of Meghalaya's decision. -
These provisions shall not apply to cases of premature/voluntary retirement. Persons who are
compulsorily retired as a measure of punishment under the disciplinary rules will also not be
covered by these rules. Refusal of earned leave as preparatory to retirement embodied in Rule 7 of
the Revised Leave Rules, 1934 will no longer be necessary. A Government servant can also avail of as
leave preparatory to retirement, a part of earned leave at his credit. In that case he will be allowed
benefit of these rules for the earned leave that remains at credit on the date of retirement.The above
amendment shall be deemed to have effect from 22nd May, 1979.[Meghalaya Gazette, Part V-A,
dated 25-12-1980, p. 591].Correction Slip No. 9Appendix 11(i)In Rule 9 of the Principal Rules the
words "in permanent employment" shall be deleted.(ii)In Rule 10 of the Principal Rules for the first
paragraph, the following shall be substituted, namely :"Earned leave at the rate of one-eleventh of
the period spent on duty shall be admissible to all temporary Government servants serving on
non-vacation Department. Leave not due shall not; however, be admissible to such
employees".(iii)In the Note below Rule 10 of the Principal Rules the words "or one-twenty second as
the case may be" shall be omitted.(iv)In Rule 13 of the Principal Rules for the existing sub-Rule (c)
the following shall be substituted, namely :"(c) Commuted leave not exceeding half the balance of
half pay leave at credit may be granted on medical certificate to a Government servant subject to the
following conditions, namely :(i)that the authority competent to grant the leave is satisfied that
there is reasonable prospect of the Government servant returning to duty on expiry of the leave
;(ii)that twice the amount of commuted leave so granted shall be debited against the half pay leave
;(iii)that the total period of earned leave and commuted leave taken in conjunction with each other
shall not exceed 240 days at a time ;(iv)that the authority competent to grant the leave obtains an
undertaking from the Government servant that in the event of his resignation or voluntary
retirement from service he shall refund the difference between the leave salary drawn during the
period of commuted leave sanctioned and that admissible during half-pay leave.For the purpose of
prosecuting an approved course of study certified by the competent authority to be in public interestFundamental Rules and Subsidiary Rules

half pay leave to the maximum extent of 180 days during the entire period of service shall be allowed
to be commuted without production of medical certificate".(v)In Rule 15 of the Principal Rules for
the existing sub-Rule (1), the following shall be substituted, namely :"(1) an officer on earned leave
shall be entitled to leave salary equal to the pay drawn by him immediately before proceeding on
such earned leave". [Reference Notification No. FEG. 60/80, dated the 6th September, 1982].The
amendment shall be deemed to have taken effect from 16th June, 1980 [Vide Meghalaya, Gazette,
Part V-A, dated 4th November, 1982, pp. 347-348].Correction Slip No. 10Appendix 15For the
existing Rule 10 of the Study Leave Rules, (Assam Study Leave Rules 1963 as applicable to
Meghalaya), the following shall be substituted, namely :"10. During the period as Study Leave a
Government servant shall be admissible to a full salary as admissible under Rule 15 of the Leave
Rules without any other allowance excepting Dearness Allowance."[Reference Notification No. FEG
60/80, dated 6th September, 1982].This amendment shall be deemed to have taken effect from 16th
June, 1980.[Published in the Meghalaya Gazette, Part V-A, dated 4-11-1982, p. 348].Correction Slip
No. 11S.R.120. - Substitute" full leave salary" in place of "full pay" occurring in the second line of this
rule and substitute the following in place of Government of Assam's decision" appearing below the
Cl. (ii) of the Note of the S.R. 120 :"Maternity leave under this rule shall be extended to temporary
female Government servants".In the Note below S.R. 120, delete the following :The word "s"
occurring at the end of the Note and Cl. (i) thereunder and re-number the existing Note (ii) as
(i).[Reference Notification No. FEG 60/80, dated the 6th September, 1982]The amendment shall be
deemed to have taken effect from 16th June, 1982. [Published in the Meghalaya Gazette, Part V-A,
dated 4-11-1982, p. 349].Correction Slip No. 12S.R.121. - Delete the existing provisions.[Reference
Notification No. FEG 60/80, dated the 6th September, 1982].The amendment shall be deemed to
have taken effect from 16th June, 1982. [Published in the Meghalaya Gazette, Part V-A, dated 4th
November, 1982, p. 349].Correction Slip No. 13Appendix 31Delete the second part of Rule 3
including Note 1 excepting the conditions and insert the following :"3-A. All other conditions
remaining the same the benefit of leave on average pay as admissible to permanent Government
servants shall be extended to temporary Government servants".Note. - The expression "Leave on
average pay" means leave salary equivalent to what is admissible under Rule 15 of the Leave
Rules".In condition (ii) delete the word "extraordinary".[Reference Notification No. FEG 60/80,
dated 6th September, 1982].The amendment shall be deemed to have taken effect from 16th June,
1980. [Published m the Meghalaya Gazette, Part V-A, dated 4-11-1982, p. 350].Correction Slip No.
14Delete the provisions appearing in Government of Meghalaya's decision beginning with "The
provisions shall not apply to cases of premature/ voluntary retirement. Persons who are
compulsorily retired as a measure of punishment under the disciplinary rules will also not be
covered by these rules" as incorporated in Rule 7 of Appendix 11 of the Fundamental Rules and
Subsidiary Rules vide Correction Slip No. 6 and insert the following below the existing entries :"(e)
The benefit of cash payment of lieu of unutilised earned leave subject to the maximum period of 180
days but not beyond the date of superannuation shall be extended to Government employees going
on voluntary retirement or who are asked to retire by Government prematurely, other than as a
disciplinary measure.(f)The benefit of cash payment of unutilised leave shall also be admissible to
employees going on invalidation pension. The benefit in their case shall be up to a maximum of 180
days earned leave plus half pay leave at his/her credit at the time of such invalidation but not
extending beyond the date of superannuation."The above amendments in so far as (e) and (f) are
concerned shall be deemed to have effect from 2nd April, 1982. [Reference Notification No. FEGFundamental Rules and Subsidiary Rules

85/80/9, dated 29-10-1982], Meghalaya Gazette, Part V-A, dated 18-11-1982, p. 361].Correction Slip
No. 15Substitute the following for the existing provision as incorporated in Rr. 7 and 13 of the
Revised Leave Rules, 1934 vide this Department Notification No. FEG 49/74/21, dated 1st April,
1976."In respect of Government employees who die in harness cash equivalent of the unutilised
portion of the earned leave subject to a maximum of 180 days instead of 120 days shall be
admissible to the family of all categories of employees including Class I employees. In addition, the
family of the deceased Government employees shall also be entitled to the payment of dearness
allowance. Such leave salary shall not be reduced by the amount of pension and pensionary
equivalent of other retirement benefits as admissible to the families."[Reference No. FEG 85/80/3,
dated 29th October, 1982.][Vide Meghalaya Gazette, Part V-A, dated 18-11-1982, p. 361].Correction
Slip No. 16Delete the existing provision occurring in F.R. 22 (1) (b) and F.R. 22-B (3) (b) and
substitute the following :"(1) (b) On confirmation in the service or post after the expiry of the period
of probation, the pay of the Government servant shall be fixed in the time scale of the service or post
in accordance with the provisions of Rule 22 :Provided that the pay of the Government servant shall
not be so fixed under Rule 22 or Rule 22-C with reference to the pay that he would have drawn in
the previous post which he was holding in a temporary capacity, but he shall continue to draw the
pay in the time scale of the service or post.""(3) (b) On satisfactory completion of the apprenticeship
and regular appointment to a post in the service or cadre, the pay is fixed in the time scale or the
service or post under Rule 22 or Rule 31 of these rules :Provided that the pay of the Government
servant shall not be so fixed under Rule 22-C with reference to the pay that he would have drawn in
the previous post which he was holding in a temporary capacity, but he shall continue to draw the
pay in the time scale of the service or post."[Reference Notification No. FEG 5/80/1, dated
22-10-1982].[Added vide Correction Slip No. 22 to Assam Subsidiary Rules.]Fundamental Rules and Subsidiary Rules

