Andhra Pradesh Minor Mineral Concession Rules, 1966
ANDHRA PRADESH
India
Andhra Pradesh Minor Mineral Concession Rules,
1966
Rule
ANDHRA-PRADESH-MINOR-MINERAL-CONCESSION-RULES-1966
of 1966
Published on 4 September 1967• 
Commenced on 4 September 1967• 
[This is the version of this document from 4 September 1967.]• 
[Note: The original publication document is not available and this content could not be
verified.]• 
Andhra Pradesh Minor Mineral Concession Rules, 1966Published vide Notification G.O.Ms.No.
1172, Industries (B-1), 4th September, 1967) read with amendments as issued in G.O.Ms.No. 226,
Ind. and Com. Department, dated 25.3.1977, published in A.P. Gazette No. 3, Part 1, Extraordinary,
dated 31.2.1977Last Updated 13th June, 2019G.O.Ms.No. 1172, Industries (B-1), 4th September,
1967) read with amendments as issued in G.O.Ms.No. 226, Ind. and Com. Department, dated
25.3.1977, published in A.P. Gazette No. 3, Part I, Ext., date 31.2.1977. - In exercise of the powers
conferred by sub-section (1) of Section 15 of the Mines and Minerals (Regulation and Development)
Act, 1957 (Act No. 67 of 1957), the Governor of Andhra Pradesh hereby makes the following rules
regulating the grant of mining leases in respect of minor minerals in the State of Andhra Pradesh
and for purposes connected therewith, namely:-
1. Short title.
- These rules may be called the Andhra Pradesh Minor Mineral Concession Rules, 1966.
2. Commencement and Application.
(1)They shall come into force on the date of publication of these rules in the Andhra Pradesh
Gazette.(2)They extend to the entire State of Andhra Pradesh.
3. Repeal.
- On the commencement of these rules, the rules in the Mining Manual which regulate the grant ofAndhra Pradesh Minor Mineral Concession Rules, 1966

mineral concessions in respect of minor minerals and the rules regulating the working of Minor
Minerals, 1954, made by the erstwhile Government of Hyderabad and published at pages 60-73 of
Part I-C rules of the Hyderabad Government Gazette, dated 25th February, 1954, shall stand
repealed except as regards things done or omitted to be done before such commencement.
4. Definitions.
- In these rules, unless the context otherwise requires:-(a)"Assistant Director" means the Assistant
Director of Mines and Geology in-charge of the district ;(b)(i)"Deputy Director" means the Deputy
Director of Mines and Geology incharge of the region ;(ii)[ "Joint Director" means the Joint Director
of Mines and Geology.] [Inserted by G.O.Ms.No. 238, I & C., date 9-7-1992, Published in A.P.
Gazette No. 33, date 15-7-1992, Rules Supplement to Part-I Extraordinary](iii)[ "District Panchayat
Officer" means the District Panchayat Officer is incharge of the District.] [Inserted by G.O.Ms.No.1,
Ind. & Com. (MI) Department, dated 1.1.2001.](c)"Director" means the Director of Mines and
Geology, Andhra Pradesh.(d)"Form" means a form appended to these rules ;(e)"Notification" means
a notification published in the Andhra Pradesh Gazette ;(f)"Ordinary sand or clay" means:-(i)the
ordinary sand used for building or other similar purposes, but not used for industrial purposes, such
as refractory, ceramic, glass staring and metallurgical industries ; and(ii)the ordinary clay used for
small scale manufacture of bricks, tiles, pots and the like but not used for large scale manufacturing
purposes, such as, for the manufacture of ceramics or cement.
5. Quarrying to be under lease or permit.
- No person shall undertake quarrying of any minor mineral in any area, except under and in
accordance with the terms and conditions of a quarry lease or a permit granted under these rules
:Provided that the Government shall have power to grant exemption from obtaining a lease or
permit for quarrying any minor mineral in any area in the case of any category of persons, subject to
such conditions as may be specified in the order granting such exemption.
6. Non-Government Lands.
- The Government may, on application from any person possessing sub-soil rights, grant a share in
the quarrying fees.
7. Preparation of plans and demarcation of the leased area.
- When a quarry lease is granted over any area, arrangement shall be made by the Assistant Director
at the expense of the lessees for the preparation of a plan and the demarcation of the area granted
under the lease, after collecting a fee calculated according to the rates specified below :
[Rates of Survey Changes [Substituted by G.O.Ms.No. 227, I & C (M. I)
Department, date 23-3-2000.]Andhra Pradesh Minor Mineral Concession Rules, 1966

For[granite and marble] [Substituted for 'granite' by G.O.Ms.No. 282, I&C
(MI) Department, date 23-9-2003.]:For other Minor
Minerals:
Rs.2500/-Rs. 500/ - per
application
Per application.]  
8. Form of lease deed.
- [The license deed shall be executed in Form "O" and the lease deed shall be executed in Form "G".]
[Substituted by G.O.Ms.No. 227, I & C (M. I) Department, date 23-3-2000.]
9. Authority to grant quarry lease or permit.
- [Every application for grant or renewal of quarry lease for any minor mineral except Sand, Granite,
Marble and 31 Minerals in respect of a land shall be made in Form-B, alongwith a sketch/plan
drawn to the scale demarcating the boundaries of the applied area to the Assistant Director of Mines
and Geology in whose Jurisdiction the land lies.] [Substituted by Notification No. G.O. Ms. No. 129,
Industries & Commerce (Mines-II) Department, dated 16.11.2018.](ii)No quarry lease shall be
granted in respect of areas covering any tank or river bed, irrigation or drainage channel and of
lands under the control of the Public Works Department, a municipality, or a local authority except
after consultation with the Executive Engineer of the Division or the River Conservator, or the
Commissioner of the Municipality or the Block Development Officer of the Panchayat Samithi or the
concerned Executive Officer appointed under Section 30 of the Andhra Pradesh Gram Panchayats
Act, 1964, as the case may be.(iii)[ In respect of minor minerals except [***] [Substituted by
G.O.Ms.No. 238, I & C., date 9-7-1992.] those mentioned in sub-rule (5) of Rule 12 which are
worked to meet the immediate or timely requirements, the Assistant Director may permit to carry
on quarrying operations on payment of seigniorage fee in advance.](iv)Permit granted under
sub-rule (iii) shall in no case be for more than [sixty days] [Omitted by G.O.Ms. No. 46, I & C, date
6-2-1996.][***] [Clause V and proviso thereunder omitted by G.O.Ms. No. 46, I & C, date
6-2-1996.][Provided that] [Substituted for the words 'Provided further that' by G.O.Ms. No. 46, I &
C, date 6-2-1996.] the applications for grant of a lease or a permit in respect of a reserve forest land
shall be disposed of after consultation with the Divisional or the District Forest officer
concerned.[Provided further that on an application or by way of auction for grant of any minor
mineral in the scheduled areas referred to it by the Assistant Director of Mines and Geology or the
Officer nominated by the State Government, the Gram Sabha or the Gram Panchayat shall
communicate its recommendation, whereupon the application or by way of auction for grant of
quarry lease for any minor mineral in such Scheduled Areas shall be processed in accordance with
the provisions of Law.] [Substituted by G.O.Ms.No. 212, I&C (M1) Department, date 20-9-2004.]
9A. [ Reservation of areas for exploitation in the public sector, etc. [Added by
G.O.Ms.No. 310, I & C., dated 11-7-1984.]
(1)The State Government may, by notification in the Official Gazette, reserve any area for
exploitation by the Government, a Corporation established by any Central, State or Provincial Act orAndhra Pradesh Minor Mineral Concession Rules, 1966

a Government Company within the meaning of Section 617 of the Companies Act, 1956 (Central Act
1 of 1956).(2)Availability of area for regrant to be notified: - No area which has been reserved by the
Government under Rule 9-A (1) shall be available for grant of quarry lease unless the availability of
the area for grant is notified in the Official Gazette specifying a date (being a date not earlier than
thirty days from the date of the publication of such notification in the Official Gazette) from which
such area shall be available for grant.(3)Premature applications: - Applications for the grant of a
quarry lease in respect of areas whose availability for grant is required to be notified under Rule 9A
(2) shall if, -(a)No notification has been issued under that rule ; or(b)Where any such notification
has been issued the period specified in notification has not expired, shall be deemed to be premature
and shall not be entertained ; and the application fee thereon, if any paid, shall be refunded.]
9B. [ Notification of the Sand Bearing areas, constitution of the District Level
Committee and its power. [Rule 9B to 9Z Substituted for R.9B-9Y by
G.O.Ms.No. 84 I&CMI date 10-4-2007. Prior to its substitution it read as in
Annexure III at Pg. 1732.]
(1)All the sand bearing areas in the State shall be leased out by Sealed Tender cum Public Auction
Reach or Mandal wise wherever applicable by the Auctioning Authority as specified under rule
9-H(1) financial year wise in any case not more than 2 years with an yearly enhancement of 20% of
the knocked down amount and subject to the conditions prescribed in the notice of Sealed Tender
cum Public Auction as prescribed in Rule 9-D and subject to approval of the District Level
Committee as specified under sub-rule (5). However, with the approval of the District Level
Committee duly recording its reasons in writing, a village or a group of villages can independently be
auctioned by the Auctioning Authority.(2)No Reach/Mandal partly or fully covered by scheduled
areas shall be leased out to any person who is not a member of Scheduled Tribe.Provided that this
sub-rule shall not apply to an undertaking owned or controlled by the State or Central Government
or to a society registered or deemed to be registered under the Andhra Pradesh Co-operative
Societies Act, 1964 which is composed solely of members of Scheduled Tribes.(3)Any Person/Society
claiming rights under this sub-rule shall produce certificate issued by the competent authority
specified by the Government to the effect that the said Person/Member of the Society belongs to
Scheduled Tribe Category.Explanation. - For the purpose of this rule: -(a)The expression "Schedule
Tribes" shall have the same meaning assigned to it in Clause (25) of Article 366 of the Constitution
of India; and(b)The expression "Scheduled Areas" shall have the same meaning assigned to it in
Paragraph 6 of the Fifth Schedule to the Constitution of India.(4)The sale of sand shall be on the
basis of auction cum tender system which denotes that offers of tenders shall be accepted while
simultaneously holding auction with a view to maximizing revenues.(5)The District Level
Committee shall consists of the following Officers: -
Joint Collector -Chairman
Dy. Director of Mines & Geology -Member
District Panchayat Officer -Member
Dy. Director, Ground Water Department -MemberAndhra Pradesh Minor Mineral Concession Rules, 1966

Executive Engineer, Irrigation (Conservator ofRiver concerned) -Member
Assistant Director of Mines & Geology(Concerned) -Member Convener
(6)[ The District Level Committee (DLC) shall be the competent authority to decide the following
issues on the proposals received from the Assistant Director of Mines & Geology concerned, only
after obtaining the necessary reports/clearances from the concerned Conservator of River/Executive
Engineer, Irrigation Department and the Director of Ground Water Department that,--(i)To identify
the Reaches or Mandals to be leased out for conduct of auction.(ii)To fix up minimum bid amount
by taking the following points into consideration:(a)availability of sand in terms of
quantity.(b)demand, supply, prevailing concessions for transportation of sand by Bullock carts,
animals, sand consumed by weaker section housing schemes, and(c)average knocked down bid
amount for the last 3 years wherever particulars are available.(iii)To separate the Reaches or
Mandals if any, which fall within the Scheduled Areas cannot be offered to non-tribals.](iv)To club
all or few of such remainng Reaches and Mandals, in a district and notify them as a single item for a
district as whole as the District Level Committee deem fit.
9C. Special Concession to Boatsmen Co-operative Societies.
(1)The Reaches identified in Major Rivers where the sand is lifted and carried by means of boats, the
Registered Boatsmen Co-operative Society registered under the Andhra Pradesh Co-operative
Societies Act, 1964 shall be given preference by allowing 10% concession on the highest
bid/Tendered amount offered in the Auction Hall. The Concessional knocked amount be paid by the
successful Registered Boatsmen Co-operative Society in not more than four equal quarterly
installments and each such installment shall be paid 15 days before commencement of each quarter.
If there is more than one Boatsmen Cooperative Society participating in the Auction and claims for
the same Reach, local registered Boatsmen Co-operative Society shall be given preference. However,
if there is more than one local Registered Boatsmen Society particpating in such auction and claims
for the same Reach, the successful bidder/tenderer shall be decided by drawing lots. Where no local
societies participate and if only non-local Societies participate and claim for the same Reach, the
successful bidder/tenderer shall be declared by drawing lots among the said non-local registered
Co-operative Societies. The Society claiming as local Society to any particular Reach shall submit a
certificate from the Divisional Co-operative Officer to the effect that it is a local Society to a
particular Reach. Such certificate shall be submitted at the time of filing application.(2)In case of a
Boatsmen Co-operative Society who can participate in the auction in respect of areas like River,
water tanks, ponds and from where sand is to be lifted in Boats, such society shall submit genuinity
certificate pertaining to the society from the concerned Divisional Cooperative Officer along with a
Statement of Annual audited statement of accounts audited by the Co-operative Department of the
preceding year or in its absence, the previous preceding year together with bye-laws of the society.
These documents are to be submitted at the time of filing of application.
9D. Notice of Sealed Tender-cum-Auction.
(1)When an area is to be leased out by Sealed Tender cum Auction for sand quarrying, the Assistant
Director of Mines & Geology concerned shall issue a Notice in Form 'S 1' by publishing in the twoAndhra Pradesh Minor Mineral Concession Rules, 1966

State level Newspapers (out of which one shall be in leading Telugu dailies) not less than 15 days
before the date of auction. The notification shall contain the date, time, venue for the conduct of
auction and other details can be furnished in the bid document.(2)The auction conducting authority,
on the day of auction is authorized to postpone the said notified date of auction to any other date for
recorded reasons duly announcing the postponement in the auction hall and in such case no fresh
notification is necessary and no fresh applications will be entertained.(3)The venue of the auction
due to any exigency may vary from the notified place in the notification and in such case the same
shall be informed while issuing hall tickets.
9E. Submission of Sealed Tender and accepting the Bid.
- (i) Any person, who intends to obtain a lease for quarrying sand in a Reach or Mandal as notified
under Rule 9-D shall submit Sealed Tender for the grant of the lease in the prescribed form so as to
reach the Assistant Director of Mines & Geology concerned before the date and time as specified in
the Notification.(ii)Each bid document can be obtained by paying Rs. 1000/- in the form of Demand
Draft drawn in favour of Assistant Director of Mines & Geology concerned. For each additional
Reach/Mandal an amount of Rs. 500/- shall be paid in similar manner. The said amount shall be
credited towards user charge head of account within 7 days.(iii)Any person, who intends to
participate in the public auction shall simultaneously submit the sealed tender for any Reach or
Mandal separately in Form 'S-4' in a Sealed Cover superscribing: -(a)Notification Number;(b)Name
of the Tenderer;(c)The Reach/Mandal quoted.(iv)Every such Sealed Tender shall be accompanied
by an application in prescribed Form 'S2' along with the enclosure as required thereunder.(v)The
amounts offered by way of sealed tender shall not be less than the minimum bid amount. Even if the
less amounts are mentioned in the sealed tender, it will be read as equivalent to minimum bid
amount.(vi)Soon after the receipt of the Sealed Tenders from the Tenderers, necessary entry should
be made in the register by the Assistant Director of Mines & Geology concerned while issuing
acknowledgement to the Tenderer. Such Sealed Tenders, so received shall be kept under the safe
custody of Assistant Director of Mines & Geology. He has to ensure that all such Sealed Tenders and
registers are kept safe under his personal custody duly observing all the possible safety
measures.(vii)Every tenderer shall be eligible to participate in the auction after obtaining Hall
tickets From Assistant Director of Mines & Geology.(viii)The tenderer shall present by himself or
through his authorized agent in the auction hall at the time of opening of the sealed tender. There
shall be open auction and the bidding from different tenderers / bidders shall continue till the
highest bid has been arrived at. The Sealed Tenders shall be opened after the bidding is over for
each Reach or Mandal.The Auctioning Authority shall finalize the highest bid amount by taking the
highest bid amount from open auction and sealed tenders whichever is higher.(ix)25% of the upset
price should be fixed as Earnest Money Deposit in case of those participating in the auction. This
amount shall be remitted through Demand Draft drawn in favour of Assistant Director of Mines &
Geology concerned.(x)The Earnest Money Deposit is ordinarily, for a Reach/Mandal for which he
has applied for. However, he can opt for all Reaches/Mandals, simultaneously to participate, with
the same Earnest Money Deposit. The applicability of Earnest Money Deposit for more than one
Reach / Mandal as per the option of the applicant at the time of filing of applications is allowed. The
moment he is the 1st or 2nd or 3rd bidder for a particular Reach/Mandal he ceases to participate for
the next Reach/Mandal since the validity of the Earnest Money Deposit gets exhausted. In order toAndhra Pradesh Minor Mineral Concession Rules, 1966

participate for more than one Reach/Mandal with one Earnest Money Deposit the applicant shall
pay the highest Earnest Money Deposit amount as applicable to a Reach/Mandal. With low amount
of Earnest Money Deposit, he will not be allowed to participate for the next Reach/Mandal for which
the Earnest Money Deposit is more than what is paid by the applicant. One is entitled to Knock
down one area only on one Earnest Money Deposit. Persons who intend to acquire rights for more
than one Reach/Mandal shall pay separate Earnest Money Deposits for each area.(xi)It shall be at
the discretion of the Auctioning Authority to accept or reject the tender or bid for the reasons to be
recorded.(xii)A Tender once submitted shall not be withdrawn before the bid is concluded.(xiii)The
Assistant Director of Mines & Geology concerned shall announce the names of person or persons
who had submitted Sealed Tender and the Hall Ticket holders before commencement of the bidding
for all Reaches/Mandals.(xiv)The proceedings for the disposal of Reach or Mandal for quarrying
sand shall be concluded on tenders or bids as the case may be by the Auctioning Authority. The
tenders shall be opened only when it is ensured by the Auctioning Authority that there is no further
bidding for the Reach or Mandal. The Auctioning Authority shall knock down the highest tender or
bid provided he is satisfied with the same. In case the highest bid amount and one or more tendered
amount remaining the same, of the Reach or Mandal shall be knocked down by drawing lots
immediately.(xv)The Auctioning authority concerned shall have the power to reject the highest
tender or bid on substantial grounds to be recorded in writing at the time of auction and accept
another next tender or bid.
9F. Refund of Earnest Money Deposit.
(1)No person shall be admitted in the Auction Hall without the Hall Ticket issued by the Assistant
Director of Mines & Geology concerned.(2)The Earnest Money Deposit (EMD) of an unsuccessful
bidders / tenderer except the first, second and third shall be refunded/returned by the Assistant
Director of Mines & Geology concerned as early as possible i.e. within 15 days from the date of
conducting the auctions.(3)In respect of the second highest bidder, the Earnest Money Deposit will
be refunded only after the completion of the agreement with the first bidder. Similarly, in case of the
3rd bidder, it will be refunded only after completion of the agreement with either first or second
highest bidders as the case may be.(4)The right of quarrying shall be strictly subject to the
confirmation or otherwise by the competent authority who has the right to refuse to confirm the
right of quarrying sand with the reasons recorded therein.
9G. The Hall ticket issuing authority may reject the application of any one
who.
- (i) has been convicted for any offence committed under any law for the time being in force or any
offence under the Mines and Minerals (Development and Regulation) Act, 1957; or Mines Act 1952
or any rules made thereunder(ii)is having mineral revenue dues to the Government as on the date of
filing of the application for issue of Hall tickets.In order to absolve the responsibility of not having
dues to the Government in respect of the leases held such applicants shall produce no dues
certificate from the competent authority of the Department. The applicants who do not possess any
lease shall produce a notarized Affidavit instead of Mineral Revenue Dues Certificate.Andhra Pradesh Minor Mineral Concession Rules, 1966

9H.
(1)The following are the auctioning, confirming and appellate authority:
S.No.Minimum Bid
Amount in RupeesAuctioning Authority Confirming Authority Appellate Authority
1 Upto 5.00 lakhsDeputy Director
of,Mines & GeologyZonal Joint Director
ofMines & GeologyDirector ofMines &
Geology
2 Above 5.00 lakhs Joint Collector District Collector Government
(2)The Auctioning authority shall have discretion to fix the minimum and maximum amounts of
hike by the bidders in the Auction hall for each Reach.(3)In case there is no hike of the bid for a
particular Reach / Mandal both in the Public Auction and Sealed Tenders offered by all the
participants: -(i)The auction conducting authority may knock down the bid by drawing lots among
the applicants in the Auction Hall. For all practical purposes, the bid knocked in favour of a bidder /
tenderer in lots will be treated as highest bidder for that Reach / Mandal.(ii)Similarly, 2nd and 3rd
bidders will also be selected by way of lots and all the provisions are applicable to them as if they are
2nd and 3rd highest bidders to that area.(4)The Auction Authority shall have the discretion to
postpone the Auctions in case it is felt that more revenue will be realized if fresh auctions are
conducted in all such cases where no hike takes place over and above minimum bid amount.(5)In
case, a single bid is received for any Reach/Mandal, the auction conducting authority at his
discretion may knock down the bid in his favour. In such cases, he will be treated as highest bidder
for the said Reach/Mandal.(6)The concerned Assistant Director shall record the proceedings during
auction in the proforma enclosed. Soon after the auctions are over on the same day the said
proforma shall be made in triplicate and one shall be handed over in a sealed cover to the
Auctioning authority and one shall be sent to the Director of Mines & Geology. On the next working
day of the completion of the auctions, he shall circulate the file to the confirming authority for
obtaining orders by a special messenger. The confirmation authority shall pass orders within a
maximum period of 7 days from the date of receipt of the proposals from the Assistant Director of
Mines and Geology concerned.(7)Any appeal or revision as the case may be against the order passed
under sub-rule (1) of Rule 9-H can file such appeal or revision application before the concerned in
Form J-1 and the fee for such appeal or revision shall be made as per Rule 35-B of APMMC Rules;
1966 within 15 days from the date of receipt of the order. The Appellant/Revision Authority can
condone the period of delay on valid grounds.
9I. Deposit of the lease amount and execution of lease agreement.
(1)When the tender/bid is knocked down by the competent authority, the successful tenderer or
bidder shall remit to Zilla Parishad Head of Account a sum equivalent to 25% of the knocked down
amount along with payment of prevailing Income Tax and submit the same to the Assistant Director
of Mines & Geology within two working days. This shall be in addition to the Earnest Money Deposit
amount paid for the said Reach / Mandal.(2)The successful tenderer/bidder on receipt of the order
of the confirmation shall remit the remaining 70% of the knocked down amount to the Zilla
Parishad Head of Account and remaining 5% of the total knocked down amount to the State Head ofAndhra Pradesh Minor Mineral Concession Rules, 1966

Account as indicated in the order of confirmation and submit the challans to the concerned
Assistant Director of Mines & Geology along with payment of prevailing Income Tax and a security
deposit of 10% of the knocked down amount subject to the minimum of Rs. 1,00,000/- (Rupees One
Lakh only) or equivalent to bid amount which ever is less through National Saving Certificate duly
pledged in favour of Governor or Bank Guarantee issued from any Nationalized Banks and execute
the lease deed with the Assistant Director of Mines & Geology concerned in Form G-I on stamped
paper as per the Registration and Stamp Act within seven days from the date of confirmation order.
The lease period shall commence with effect from the date of the execution of the lease deed.(3)The
successful Bidder is liable to pay any other Taxes payable to the Government as per Statutory
Provisions of various Acts and Rules prevailing.(4)If the successful tenderer or Bidder fails to pay
either 25% of the knocked down amount within two working days or the remaining knocked down
amount within the specified time as mentioned in the confirmation order, the amount so far paid by
the successful tenderer/bidder shall be forfeited to the Government by the confirmation
authority.(5)In the event, the first bidder did not turn up for further proceedings of execution of a
Reach/Mandal by paying the remaining amount, the same Reach/Mandal will be offered to second
highest tenderer/ bidder provided 25% of minimum bid deposited in the of EMD is retained with
the Assistant Director of Mines & Geology concerned and such tenderer /bidder is willing to pay the
highest knock down amount. Such facility shall be extended to the 3rd bidder in the descending
order if the 2nd highest bidder fails to comply with the payment of the highest knock down amount.
9J. Maintenance of Registers.
- The Assistant Director of Mines & Geology concerned shall maintain a register duly mentioning all
the particulars of all the participants, who possess hall tickets and have submitted sealed tenders.
The person whose tender or bid is knocked down shall sign and mention his name in block letters
duly affixing his thumb impression in the register as per the prescribed proforma. At the end of the
day of the auctions, the auction conducting authority shall announce that any one who is willing to
sign at the end as a witness to the proceeding may sign in the register.
9K. Powers of the State Government.
(1)The Government shall have the power to cancel the auction conducted and confirmation orders
issued thereon by the competent authority duly recording its reasons thereof.(2)The Government
shall have the power to condone the delay in issue of confirmation orders, execution of lease deed,
etc. for the valid reasons to be recorded.(3)The Government shall have the power to issue
orders/clarifications, if any, not specifically mentioned in implementation of these rules.
9L. Penal Clause.
- The successful tenderer or bidder shall have no claims for any compensation due to floods or heavy
rains or any other situation and extension of the lease period shall not be granted under any
circumstances.Andhra Pradesh Minor Mineral Concession Rules, 1966

9M. Temporary Permits.
(1)On expiry of the existing leases for the balance period upto the end of March of the particular year
the area will be auctioned or alternative arrangement will be made for issue of temporary permits
for this limited period only by following the procedures mentioned in sub-rule (2).(2)Due to any
exigency and with the approval of the Government, the Director of Mines & Geology may order for
issue of temporary permits in any area pending finalization of auctions on nomination basis to
Andhra Pradesh Mineral Development Corporation, who in turn will pay Seigniorage Fee at the rate
prescribed in the Rule 10 duly maintaining round the clock check point.Such temporary permits
shall be issued to M/s. Andhra Pradesh Mineral Development Corporation Limited for a period not
exceeding 60 days.
9N. Use of authorized Ramps.
- The lessee should make use of authorized ramps and paths only for transportation of sand from
the quarry and not open any new ramps or paths. However any new ramps can be permitted by the
concerned Assistant Director of Mines & Geology only with the consent of the concerned Mandal
Revenue Officer in case of Government Land and River Conservator where the River Conservation
Act applies and in case of patta Lands with the consent of the Pattadar duly verifying the claims
supported by certification issued by the Mandal Revenue Officer concerned.
9O. Legal Heir.
- If the successful tenderer or bidder dies after the privilege is knocked down to him, his legal heirs
shall be responsible to execute the lease deed and to carry out the business by remitting their dues to
the Government. If the legal heirs do not want to continue the privilege, they should, within 30 days
from the date of death of the auction purchaser intimate the Auctioning authority about their
intention in writing by Registered post. In such cases the Auctioning authority shall make
alternative arrangement or reauction the privilege. The amounts deposited by the deceased bidder
shall be refunded to the legal heirs.
9P. Payment of Second year lease amounts.
(a)The lessee shall pay the knocked down amount along with 20% enhancement towards the second
year lease amount. Out of the total amount, 95% shall be paid towards Zilla Parishad Head of
Account and balance 5% amount towards State head of account and submit the challans to the
Assistant Director of Mines & Geology concerned on or before 45 days of the expiry of the first year
lease period. If no such payment is received the lease period gets expired by the first year ending
itself and the Security Deposit gets forfeited to the Government. The Assistant Director of Mines &
Geology shall make necessary arrangement for leasing out the area through sealed
tender-cum-public auction.Provided, the Director of Mines & Geology may condone the delay in
payment of second year lease amount on the request for the condonation of delay before the expiry
of first year lease period.Provided further that the Government may condone the delay in paymentAndhra Pradesh Minor Mineral Concession Rules, 1966

of second year amount if the request is received after the expiry of the first year lease period but
within 15 days from the date of expiry of the 1st year lease period in genuine cases.(b)In respect of
the Reaches identified to the boatsmen cooperative societies, the society shall pay the second year
amount along with 20% enhancement in not more than four equal quarterly instalments and each
instalment shall be paid 15 days before commencement of each quarter.If no such payment is
received, the lease gets expired by the period ending for which the amount is due and the Security
Deposit gets forfeited to the Government.Provided the Director of Mines & Geology may condone
the delay in case the application is filed before the expiry of the due date.Provided further that the
Government may condone the delay in payment even after the expiry of due date in genuine cases,
on the request for such delay condonation is received within fifteen days from the expiry of due
date.(c)The condonation of delay as stipulated under clauses (a) and (b) above does not entitle the
lessee for extension of lease period.
9Q.
If the Auctioning authority notices that any person in the auction hall behaves or acts in such a
manner so as to cause loss to Government or induces or forbids any person from bidding, is liable
for suspension from participating in the auction and auction conducting authority may order for his
removal from the auction hall.
9R.
The lessee shall abide by all the conditions and statutory provisions under Mines & Minerals
(Development & Regulation) Act, 1957, and rules made thereunder viz., Andhra Pradesh Minor
Mineral Concession Rules, 1966, Andhra Pradesh Mineral Dealers Rules 2000, Mines Act 1952,
Mines & Metalliferrous Regulations 1961, and Andhra Pradesh Water Land & Trees Act, 2002 and
other State and Central Act and Rules and instructions which are applicable.
9S.
Leases granted for sand by Tender or by Public auction are not liable for transfer.
9T.
The successful bidder or tenderer shall charge the price for sand at the pit head as fixed in the tender
notice.
9U. Sand exempted from payment of Seigniorage Fee.
(1)Sand used in the weaker sections housing programme shall be supplied free of cost at pit head by
the bidder / tenderer including exemption of payment of Seigniorage Fee on a certificate issued by
the District Collector or any authorized officer by him.(2)Bullock carts and animals transporting
sand are also exempted from payment of Seigniorage fee.Andhra Pradesh Minor Mineral Concession Rules, 1966

9V.
Whenever the Ground Water affect is noticed and safety of structures is affected due to sand
quarrying in any area, the Government / Director of Mines & Geology shall issue prohibitory orders
in consultation with Ground Water Department. In case the Director of Mines & Geology issues such
order, he shall obtain the approval of the Government as early as possible.
9W.
No movement of sand shall be allowed across the border to the neighbouring State. In case any
vehicle is found transporting to the neighboring State even with permit it will be treated as violation
of rules and the penal provisions as specified in Rule 9 X will apply besides the lease shall be liable
for cancellation.
9X. Persons authorized to check unauthorized transportation of the sand.
(a)The District Collector shall take all precautionary measures to stop illegal mining of sand in the
District. In case of any illegal mining of sand by any person from any quarry or Reach
unauthorizedly and is transporting it thereof, the officers empowered under Rule 26 of Andhra
Pradesh Minor Mineral Concession Rules, 1966 are competent to check the vehicles and take
appropriate action as specified therein or compound is specified in sub-rule (b) hereunder
whichever is higher. Besides, the District Collector shall nominate any other officer as he thinks
deemed fit to exercise these powers in addition to the officials so specified.(b)The minimum penalty
for each truck carrying sand without valid permit issued by the concerned authority must be Rs.
10,000/- (Rupees ten thousand only) for each truck of 10 tonnes capacity and Rs. 5,000/- (Rupees
five thousand only) in respect of Tractor. In case of repeated violations, vehicle will be confiscated
by the officer not below in rank to the Assistant Director of Mines & Geology. The powers delegated
to various officers under the existing provisions of Andhra Pradesh Minor Mineral Concession
Rules, 1966 shall be extended to sand cases also.(c)The Way bill for transporting sand shall be in the
"Form S-5". The way bills will be issued proportionate to the knocked down bid amount by
calculating Seigniorage Fee as specified in the Schedule-1 of Rule 10 of Andhra Pradesh Minor
Mineral Concession Rules, 1966. The bidder is liable to pay Seigniorage fee additionally and obtain
permits for the quantities exceeding the proportionate bid amount.(d)The Municipalities concerned
who are the approving authorities for Housing Plans or Shopping/Commercial Complexes are
empowered to recover the component of Seigniorage Fee on sand at the rates specified under
Schedule- 1 of Rule 10 of Andhra Pradesh Minor Mineral Concession Rules, 1966 with one-time
penalty in case of procurement of sand by any builder without any valid permit in respect of
constructions which are of the value of above Rs. 1.00 Crore. Any person aggrieved by the said
deduction/orders passed by the Municipalities of Grade-I, II, III appeal lies to the Director of Mines
& Geology and in respect of Special Grade, Selection Grade Municipalities and Municipal
Corporations appeal lies to Government and the procedure as envisaged in subrule (7) of Rule 9-H
shall apply.(e)The bidders shall not use poclains or any other machinery for the purpose of
digging/loading since as per the WALTA Act, 2002, the sand mining is restricted to one Metre only
and use of machinery leads to extraction of sand beyond one metre.Andhra Pradesh Minor Mineral Concession Rules, 1966

9Y.
(1)Removal of sand in patta lands: It is the responsibility of the bidder to obtain the consent of the
Pattadar in respect of any area on the land abutting the river, streams etc. which is classified as patta
land. The Pattadar, who is claiming the ownership of the land shall produce valid documents and
also certificate issued by the concerned Mandal Revenue Officer.(2)Recovery of Seigniorage fee: The
sand consumed in all Government works by the contractors, normal Seigniorage Fee with one time
penalty may be recovered from the work bills by the consuming department in case of procurement
of sand is without valid permits issued by the concerned Assistant Director of Mines & Geology.
9Z.
The General provisions of Andhra Pradesh Minor Mineral Concession Rules, 1966 shall apply for
cases which are not explicitly mentioned herein.]
10. Seigniorage fee or dead rent.
- [(1) When a quarry lease is granted under these rules, the seigniorage fee or dead rent whichever is
higher, shall be charged on all minor minerals despatched or consumed from the land at the rate
specified in Schedule I and Schedule II as the case may be.] [Substituted by G.O.Ms.No. 331, Ind. &
Com. (MI) Department, dated 21.6.2000.](2)When quarry lease is granted, the assessment on the
land together with the seigniorage fee or dead rent, whichever is higher, shall also be charged.(3)[
When the quarry lease is granted -(a)the dead rent for the 1st year shall be paid by the lessee at the
time of execution of lease deed and for the subsequent years, every year in advance.(b)the
seigniorage fee shall be paid before the mineral is removed from the leased area.](4)[(a)
Notwithstanding anything contained in sub-rules (2) and (3), every quarry lease holder including
temporary permit holder except the person/organisations who obtained quarry lease with
exemption from payment of seigniorage fee for the specified minerals in the sector shall pay the
seigniorage fee to the successful Tenderer, bidder (hereinafter referred to as authorised Agent) as
per the relevant rates in Schedule-1 to Rule 10 [***] [Substituted by G.O.Ms.No. 50, I & C (M.I)
Deptt., date 17-3-1997.] in force as on the day of notification of the auction notice. All the quarry
lease holders for the specified Minor Minerals are deemed to have come under this provision for the
payment of seigniorage fee from the date, the authorised Agent makes agreement in Form-M for the
concerned Sector.(b)When the quarry leases are granted under Rule 12 for the specified Minor
Minerals, seigniorage fee or dead rent whichever is higher shall be charged on such minerals
despatched or consumed from the land at the relevant rates specified in Schedule I and Schedule II
[***] [The words 'or the relevant rates of seigniorage fee or dead rent specified under Rule 12(5)(e)
respectively' omitted by G.O.Ms.No. 282, I&C (MI) Department, date 23- 9-2003.] along with the
land assessment on the assessment made by the Assistant Director concerned. Every lessee who has
been granted leases for specified Minor Minerals under aforesaid provisions shall submit the
detailed accounts as required by the Assistant Director concerned for the purpose of making annual
assessment for the Mineral Revenue before 10th of April every year. The Authorised Agent does not
have any claim on the dead rent, if any, fallen due from the lessees on annual assessment made by
the Assistant Director concerned.(c)The additional amount of seigniorage fee over and above theAndhra Pradesh Minor Mineral Concession Rules, 1966

rates in force as on the day of notification of auction notice due to revision of rates of seigniorage fee
made from time to time shall be paid by the lessees directly to the Government and the authorised
agent shall not have any claim for such payments.(d)In respect of specified Minor Minerals, the
Assistant Director may grant temporary permits for limited quantities and for limited period over
the specified areas to meet immediate and timely requirement and the payment of seigniorage fee
on such Temporary permits shall be made to the Authorised Agent.(e)In case, the right of collection
of seigniorage fee is not disposed off in Sealed Tender cum Public Auction or even if it is disposed off
but the authorised Agent does not perform due to any reason, the Sectors are deemed to have not
been notified for public Auction and the collection of seigniorage fee and dead rent shall be made as
per sub-rule (1) of Rule 10 [***] [The words 'and Rule 12(5)(e) as the case may be' omitted by
G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.].](5)[(i) In respect of granite and
limestone slabs used for cutting and polishing covered under item No.15 and 17 of Minor Mineral
Schedule, in order to facilitate easy accountability for the purpose of levy of Seigniorage Fee, the
machinery as specified in Schedule III shall be taken as unit and Seigniorage fee shall be collected at
that point by following the rates prescribed in Schedule III of these rules. However, this provision is
not applicable in respect of gang saw machines.(ii)Where Seigniorage Fee is paid under Schedule III
by those who are possessing cutting and polishing industry for the material procured by them from
the Quarry Leases granted under Rule 5 such leaseholders need not pay the Seigniorage Fee for the
quantity covered under Transit Forms by the said cutting and polishing units.(iii)The Seigniorage
fee under Schedule III if not paid before 25th of the preceding month shall be liable for payment of
interest as under Rule 19 of the Andhra Pradesh Minor Mineral Concession Rules, 1966 with effect
from 1st of the succeeding month. On such payment, Assistant Director of Mines and Geology shall
issue transit forms to the extent of slab rate amount paid.However under any circumstances the
minimum payments shall be at least for one month at a time.] [Inserted by G.O.Ms.No. 104, I&C
(MI) Department, date 15-5-2009.]
10A. [ Sectors to be made by the Joint Director for grant of Collection of
seigniorage fee in respect of specified Minor Minerals by
Sealed-Tender-cum-Public Auction. [Substituted by G.O.Ms.No. 50, I & C (M.I)
Deptt., date 17-3-1997.]
(1)The Joint Director shall form the sectors duly specifying the areas within the Sectors for giving
away the right of collection of Seigniorage fee in respect of any specified Minor Minerals in each
Sector in Sealed Tender-cum-Public Auction. The minimum bid amount for each of the sector shall
be fixed by the Joint Director taking into account the quarrying activity, the demand and supply of
Minerals, the infrastructure etc.(2)Notwithstanding anything contained in sub-rules (1) and (2) of
Rule 10, the right of collection of Seigniorage fee for the specified Minor Minerals within the Sector
shall be given away in Sealed-Tender-cum-Public Auction for the specified period and in any case
not more than one year subject to the conditions prescribed in the notice of auction under Rule
10-B.] [Added by G.O.Ms.No. 238, I & C, date 9-7-1992, w.e.f. 15-7-1992.]Andhra Pradesh Minor Mineral Concession Rules, 1966

10B. [ Notice of Sealed Tender-cum-Public Auction and Mode of disposal of
the Sector. [Substituted by G.O.Ms.No. 50, I & C (M.I) Deptt., date 17-3-1997.]
(1)When the right of collection of seigniorage fee for the specified Minor Minerals in the sector is to
be disposed off in the Sealed Tender-cum-Public Auction, the Assistant Director shall issue a notice
in Form A1, giving due publicity in any local News Paper not less than fifteen days before the date of
Auction or in such other manner as deemed fit.(2)The right of collection of seigniorage fee in a
Sector shall be obtained in Sealed Tender-cum-Public Auction. A person intends to participate in
Public Auction is entitled to submit a sealed tender and similarly a person who submits a sealed
tender is entitled to participate in public auction.]
10C. [ Submission of Sealed Tenders and accepting the Bid. [Substituted by
G.O.Ms.No. 50, I & C (M.I) Deptt., date 17-3-1997.]
(1)(a)Any person who intends to obtain the right of collection of seigniorage fee in respect of
specified minor minerals within the sector shall submit sealed tender along with the application for
issue of Hall Ticket so as to reach the Assistant Director before the time and date published in the
Auction notification.(b)Any person intending to submit the sealed tender shall do so far any sector
for obtaining the right of collection of seigniorage fee in Form A-3 in a sealed cover superscribing
the particulars stated below, namely: -(i)Auction Notification number ;(ii)Name of the Tenderer ;
and(iii)Name of the Sector.(c)Every such sealed tender shall be accompanied by an application for
issue of Hall Ticket along with the enclosures as required under item (2) of the Annexure to Form
A1.(d)Soon after the receipt of sealed tender from the Tenderer, the necessary entry should be made
in the Register by the Assistant Director and issue acknowledgement to the Tenderer. Such sealed
tenders shall be kept under the safe custody of the said Assistant Director. He has to ensure that all
such sealed tenders and the Registers are kept safe under his personal custody duly observing all
possible safety measures.(e)Every tenderer shall be issued a Hall Ticket to participate in the auction
without insisting any further payments as required under item (2) of the Annexure to Form-A1, by
the Assistant Director.(f)The Sealed Tenders shall be opened after the bidding is over in each sector.
It is the responsibility of the person/persons who submitted the sealed tenders to make themselves
present at the time of opening of the sealed tenders. Sealed tenders shall be opened in the auction
hall by Assistant Director irrespective of the presence of the Tenderers.(g)(i)A tender once
submitted shall not be withdrawn before the bid is concluded.(ii)The Assistant Director shall
announce at the commencement of the bidding for each sector the names of the Tenderers as well as
the proposed bidders who have obtained Hall Tickets for that Sector.(2)The proceedings for the
disposal of the sector shall be concluded on tender or bid as the case may be by the Assistant
Director. The hike in bidding in the auction Hall by the bidders shall not exceed 25% of the
minimum bid each time, the tenders for the sector shall be opened only when it is ensured by
Assistant Director that there is no further bidding. He shall knock down the highest tender/bid
provided he is satisfied with the procedure. In case the highest bid amount and one or more
tendered amounts remaining the same, the knocking down for the sector shall be decided by
drawing lots immediately. However, the Assistant Director shall have the power to reject the highest
tender/bid on reasons to be recorded therefore and accept any other next lower tender/bid, subjectAndhra Pradesh Minor Mineral Concession Rules, 1966

to approval of the Joint Director.(3)The Assistant Director may at his own discretion reject any
person's tender/bid who,(a)has been convicted for any penal offence or any offence under the Mines
and Minerals (Regulation and Development) Act, 1957,or(b)is a debtor to the Government of
Andhra Pradesh in the Mines and Geology Department.(4)If the Assistant Director noticed that any
person in the Auction Hall before or at the time of bidding behaves or acts in such manner as to
cause loss to Government or induces or forbid any person from bidding he may suspend him from
bidding for participating in the auction and remove him from the Auction Hall.(5)No person will be
admitted into auction hall without the Hall Ticket issued by the Assistant Director.The right of
collection of seigniorage fee will be ordinarily knocked down to the highest tenderer/bidder, but the
right is reserved to the officer conducting the proceedings or by the Director or by the Government
as the case may be to reject any tender/bid without assigning any reason thereof. The right of
collection of seigniorage fee shall be strictly subject to the confirmation by the competent person
who has the right to refuse to confirm with reasons recorded.(6)The Assistant Director shall
maintain a register by duly mentioning all the particulars of the participants who have submitted
sealed tenders and the persons who have obtained Hall Ticket forbidding. The persons whose
tender/bid is knocked down shall sign and mention his name in block letters by duly affixing his
signature/thumb impression in the Register.(7)If the successful Tenderer/Bidder dies after the
privilege is knocked down, his legal heirs shall have the right and be responsible to execute the
agreement and to carry-out the business by remitting the dues to the Government. If the heirs do
not want to exercise the privilege, they should within fifteen days from the date of death of the
successful tenderer bidder intimate the Assistant Director their intention in writing by registered
post. The amounts deposited by the deceased Tenderer/Bidder shall be refunded to the legal heirs.
In such cases the Assistant Director shall submit proposals to the competent authority for issuing
confirmation to the next highest eligible Tenderer/Bidder.]
10D. [ Confirming Authority. [Substituted by G.O.Ms.No. 50, I & C (M.I) Deptt.,
date 17-3-1997.]
(1)The Deputy Director shall confirm the knocked down amounts provided he is satisfied with the
publicity, procedures, participation in the Sealed Tender-cum-Public Auction and the knocked down
amount.(2)The Director may issue confirmation orders in favour of any persons/organisations for
the sectors not disposed off in Sealed Tender-cum- Public Auction or even if disposed off, not
resulted in making agreement, any time on the offers received with 25%, of the offered amount in
the form of demand draft in favour of the Director.(3)If the agreement made by the Authorised
Agent is cancelled due to any reason, the Director may nominate and issue confirmation in favour of
any person or organisation on specific conditions for the unexpired period of original agreement.
Such nominee shall make the agreement in Form M with the Assistant Director as stipulated in the
confirmation order.]
10E. [ Deposit of knocked down amount. [Substituted by G.O.Ms.No. 50, I & C
(M.I) Deptt., date 17-3-1997.]
(1)The successful Tenderer/Bidder shall pay the knocked down amount in four quarterlyAndhra Pradesh Minor Mineral Concession Rules, 1966

instalments. The amount equivalent to 25% of the knocked down amount towards first instalment
shall be paid in the Government Treasury within the immediate next two working days and produce
challan to the Assistant Director.(2)The confirmation orders will be issued by the competent
authority on making payment of 25% of the knocked down amount as required under sub-rule (1).
The successful Tenderer/Bidder on receipt of order of confirmation shall furnish security deposit of
2% of knocked down amount subject to the minimum of Rs. 1,000/- and maximum of Rs. 25,000/-
in the manner as prescribed in the confirmation order and execute agreement in Form 'M' with the
Assistant Director within the time prescribed in the confirmation order on stamped paper as per the
Registration and Stamps Act by duly furnishing three bank guarantees in favour of the Assistant
Director concerned for an amount equivalent to 25% of the knocked down amount under each
guarantee which are valid for six, nine and twelve months against the respective quarterly
instalment payments. The respective Bank Guarantees shall be released by the Assistant Director on
payment of the respective quarterly instalments. The Security Deposit shall be released by the
Assistant Director soon after the expiry of the lease period provided the Authorised Agent fulfilled
all the lease conditions and other provisions of the Andhra Pradesh Minor Mineral Concession
Rules, 1966.(3)In the event of default by the first successful Tenderer/Bidder for payment of 25% of
the knocked down amount as required under sub-rule (1) or completion of formalities for executing
the agreement as required under sub-rule (2) the competent authority may issue confirmation
orders in favour of the second or the third highest Tenderer/Bidder in the descending order with
due stipulations of time limits for payment of 25% of the amount offered by the respective
Tenderer/Bidder and discharging the other formalities for making agreement as required under
sub-rule (2). However in case the second and third highest Tenderer/Bidders also become
defaulters, the other Tenderers/Bidders who offered and participated over and above the minimum
bid and who retained their deposit of 10% of the minimum bid with the Auctioning Authority after
the auctions, may be considered for issue of confirmation orders in the descending order by the
competent authority duly stipulating the time limits for payment of 25% of the offered amount by
the respective Tenderer/Bidder and discharging the other formalities for concluding agreement as
required under sub-rule (2).(4)The successful Tenderer/Bidder on executing the agreement in Form
'M' shall pay the subsequent quarterly instalments atleast fifteen days before the end of the
proceeding quarter.(5)The Director may condone the delay in payment of the amounts, fulfilment of
other formalities and making agreement under sub-rules (1) to (4) on valid grounds.(6)If the
successful Tenderer/Bidder fails to pay 25% of the knocked down amount within two immediate
working days or fails to furnish the bank guarantee of 75% of knocked down amount within the time
specified in the confirmation order or fails to make agreement in Form M after completing all the
formalities or fails to pay the quarterly instalments within the prescribed time, the amount so far
paid by the successful Tenderer/Bidder by way of deposits and the amounts under bank guarantee
shall be forfeited to the Government by the confirming Authority. If the second or the third highest
Tenderer/Bidder fails to pay the amounts or complete the formalities as stipulated in the
confirmation order, the confirming authority forfeit the amounts so far paid by way of deposits
including the Bank Guarantees to the Government. If the fourth or any subsequent bidder who has
been issued confirmation order and made agreement in Form 'M' after completing the formalities
fails to pay the second or any subsequent instalments in time, the confirming authority shall forfeit
the security deposit and the Bank Guarantee to the Government. Any forfeiture shall be done by the
confirming Authority after giving an opportunity.(7)The deposit of second and third highestAndhra Pradesh Minor Mineral Concession Rules, 1966

Tenderer/Bidders shall be returned after the agreement is made in Form M in case they are not
found to be defaulters for the payment of 1/4 of the amount as required under sub-rule (1) and the
completion of other formalities under sub-rule (2). The deposits of others shall be returned after
three days of auction on a written request by the participants for the same and the deposits of those
who like to avail the opportunity of getting the lease in case the first, second and third highest
Tenderer/Bidder become defaulters will be retained with the Assistant Director and returned after
the agreement is made.]
10F. [ Power of the Director to cancel the Auction. [Substituted by
G.O.Ms.No. 50, I & C (M.I) Deptt., date 17-3-1997.]
- The Director shall have the power to cancel at any time the Sealed Tender-cum-Public Auction
conducted under Rule 10A(2) and the confirmation issued by the Deputy Director concerned under
Rule 10-D if the Director feels that the publicity, participation and the amounts knocked down are
not satisfactory and also due to any other lapses.]
10G. [ Liberties of the Tenderer/Bidder. [Substituted by G.O.Ms.No. 50, I & C
(M.I) Deptt., date 17-3-1997.]
- The Tenderer/Bidder after executing the agreement in Form M prescribed in Rule 10-E(2) will be
at liberty to collect the seigniorage fee in force as on the day of notification of the auction notice
from the lease holders including temporary permit holders except persons/organisations who
obtained quarry leases with exemption from payment of seigniorage fee, in respect of Minor
Minerals specified in the Auction notification at the relevant rates mentioned in Schedule 1 of Rules
10(1) and 12(5)(e) at or before the time of despatch of the minor minerals from the leased areas. He
shall have no right to collect the seigniorage fee from any persons/companies who are not the quarry
lease holders. The Authorised Agent shall also be entitled to collect the seigniorage fee from all the
new leases granted and executed from the specified Minor Minerals during the currency of the
Agreement period. He, however does not have any right for any type of compensation arising out of
non-working of the quarries and due to expiry, lapse, determination, cancellation etc., of the leases.]
10H. Termination of agreement.
- The successful [tenderer/bidder] [Substituted by G.O.Ms.No. 50, I & C (M.I) Deptt., date
17-3-1997.] shall abide by the conditions of the agreement executed in Form-M. The Director shall
be competent to terminate or cancel the agreement for any violation of the provisions of the Andhra
Pradesh Minor Mineral Concession Rules, 1966 or conditions of the agreement after giving due
notice. The Director shall also be competent to forfeit all the amounts by way of deposits or
otherwise or amounts covered under bank guarantee to the Government upon such termination or
cancellation.Andhra Pradesh Minor Mineral Concession Rules, 1966

10I. [ [Substituted by G.O.Ms.No. 50, I & C (M.I) Deptt., date 17-3-1997.]
(i)No specified minor mineral shall be despatched from any of the leased areas in the sector without
a valid way bill duly stamped by the Assistant Director concerned issued through the authorised
agent or his representative. Contravention of this clause shall result in levy of normal seigniorage fee
along with five times penalty by the Assistant Director concerned on a complaint filed by the
authorised agent and on establishing the same by the Assistant Director. The normal seigniorage fee
and the penalty so levied shall be paid to the authorised agent. If by any chance, the complaint by
the authorised agent results in non-establishing the unauthorised transportation by the lessees due
to inadequate or insufficient evidence in the complaint does not confer any right on the authorised
agent to claim any sort of compensation from the Government. However the persons/organisations
who are holding the quarry leases with exemption from payment of seigniorage fee shall obtain
despatch permits from the Assistant Director directly as required under Rule 34.(ii)The valid way
bills duly stamped by the Assistant Director concerned shall be supplied to the lessees other than
persons/organisations who obtained leases with exemption from payment of seigniorage fee in the
sector on payment of the normal seigniorage fee as per his requirement by the authorised
agent.(iii)The Assistant Director concerned shall stamp on the way bills for different specified minor
minerals once in a month for the estimated quantity on submission of the requisition by the
authorised agent without any payment and he shall submit the particulars to the Director and the
Deputy Director concerned before 5th of the succeeding month.(iv)The authorised agent shall
submit monthly return in Form C-1 to the Assistant Director, Deputy Director concerned and the
Director for every month before 5th of the succeeding Month.]
10J. [ [Substituted by G.O.Ms.No. 50, I & C (M.I) Deptt., date 17-3-1997.]
The successful Tenderer/Bidder after making agreement shall be bound to observe the laws, rules
and regulations, instructions of Mines and Geology Department and the Government that might be
enforced during the currency of the lease or the privilege.
10K.
The right of collection of seigniorage fee obtained through sealed tender-cum-auction is not liable
for transfer.
10L.
The successful Tenderer/Bidder shall have no claim for compensation or extension of lease period
for the delay in passing orders or the delay caused by himself in paying the required amounts and
executing the agreement. However, Government may exempt or waive the proportionate amount for
the non performed periods on valid reasons.Andhra Pradesh Minor Mineral Concession Rules, 1966

10M.
The Director may nominate any officer of the Department to discharge the functions under any of
the provisions under Rule 10 in the event of non-availability of the concerned officer or due to any
other exigency.
10N.
In case of any doubt as the application or interpretation of the version of any of these conditions the
decision of the Government of Andhra Pradesh on the issue shall be final.]
11. [ Power of the Government and the Director. [Substituted by G.O.Ms.No.
46, I & C, date 6-2-1996.]
(1)Power of Government:- Government reserves the right -(a)to cancel the quarry lease granted and
executed under these rules, if it is considered necessary to do so either due to change in the policy or
in the public interest by giving previous notice ;(b)to grant the leases for any minor minerals by duly
exempting from the priorities fixed under different provisions under these rules on nomination or
otherwise subject to certain specified conditions for any category of land in favour of any section of
the society;(c)to waive the collection of seigniorage fee and dead rent at their discretion.(2)The
Director shall have the powers: -(a)to prohibit quarrying operations in part or in the whole of the
area under lease or free-hold areas for the reasons recorded in consultation with the competent
authority ;(b)to impose any special conditions in quarry leases granted under these rules;(c)to close
any quarry or prohibit quarrying operations or reserve the land for being worked by any particular
department of the Government or a local authority and to regulate quarrying operations according
to the law in force ;(d)to regulate the quarrying operations by issuing temporary permits for any
minor mineral during the transmission period whenever there is a proposal to change the policy by
the Government for the grant of the leases.]
12. Grant of lease.
- [(1) A Quarry lease for any minor mineral except Granite useful for cutting and polishing, Marble
and the 31 minerals mentioned at Sl.Nos.18 to 48 in Schedule-I of Rule 10, shall be granted subject
to the provisions sub-rules (2) and (3) of Rule 10 by Deputy Director on an application in Form-B
made through the Assistant Director of Mines & Geology, concerned. Each application shall be
accompanied by a sketch drawn to the scale demarcating the boundaries duly signed by the
applicant and by a qualified Surveyor. Every application shall be accompanied by treasury or bank
challan of Rs.5,000/- (Rupees Five thousand only) towards non-refundable application fee and a
deposit of Rs. 10,000/- (Rupees Ten thousand only) for every hectare or part thereof by a treasury
challan in a Head of Account notified by the Director for this purpose. The Deposit amount shall be
refundable when the application is rejected on technical grounds like non-availability of area,
rejection of No Objection Certificates (NOC).The deposit amount shall be forfeited when the
applicant fails to attend Survey and Inspection, withdrawal of the application by the applicant, nonAndhra Pradesh Minor Mineral Concession Rules, 1966

execution of the lease and for any other lapse on the part of the applicant. Provided that the Andhra
Pradesh Mineral Development Corporation Limited is exempted from payment of deposit.]
[Substituted by Notification No. G.O. Ms. No. 129, Industries & Commerce (Mines-II) Department,
dated 16.11.2018.](2)Whenever more than one application are received for grant of a quarry lease
[for minor minerals [except sand, granite useful for cutting and polishing and marble] [Inserted by
G.O.Ms.No. 315, I & C, date 2-8-1994.] and also the minerals specified under [items at Sl.No. 1 to
3(a)] [Substituted for 'items 1(a) and (b)' by G.O.Ms.No. 2, I&C (MI) Department, date 2-1-2004.]
under Schedule-I to Rule 10] the [Deputy Director] [Substituted by G.O.Ms.No. 161, I & C, date
24-3-1980.] shall dispose of the applications in order of preference specified below: -(i)Applications
of Government Department and Government Corporations and Companies ;(ii)Applications of
Labour Contract Co-operative Societies ;(iii)Applications of unemployed persons who possess any
recognised qualification in Geology, Geophysics, or Mining Engineering or any other allied subjects
;(iv)Other applications ;[Provided that the above priorities shall prevail if the subsequent
applications are received within 7 (Seven) days of the receipt of the first application, otherwise the
applications shall be disposed off in the order of their receipt.] [Inserted by G.O.Ms.No. 2, I&C (MI)
Department, date 2-1-2004.]Provided [further] [Substituted for 'further' by G.O.Ms.No. 2, I&C (MI)
Department, date 2-1-2004.] that in cases falling under any of the categories (i) to (iii) above, the
grant of lease shall be subject to the condition that lessee shall work the quarry directly and shall not
hand it over to any other party for working :Provided [also] [Substituted for 'further' by G.O.Ms.No.
2, I&C (MI) Department, date 2-1-2004.] that the Deputy Director may refuse to accord preference
to the application of a Labour Contract Co-operative Society, if he finds that the particular Society
does not work properly in the interest of the workers concerned :Provided also that whenever more
than one application falling under any of the categories (i) to (iii) above are received for grant of a
quarry lease and have to be considered under the order of preference prescribed above, [Deputy
Director] [Substituted by G.O.Ms.No. 161, I & C, date 24-3-1980.] shall refer matter to Government
with his recommendation for a direction :Provided also that whenever more than one application
falling under category (iv) above are received for grant of a quarry lease and have to be considered in
the order of preference specified above, such preference shall be given to the applications according
to the date of their receipt, unless the Government, for special reasons, otherwise direct and in case
of applications received on the same day, the [Deputy Director] [Substituted by G.O.Ms.No. 161, I &
C, date 24-3-1980.] after taking into consideration the particulars furnished in the applications, may
grant the lease to any deserving applicant ; or he may, will the previous approval of the Director,
grant a quarry lease to an applicant whose application was received later in preference to an earlier
application for any special reason to be recorded in writing.[(2-A) Notwithstanding the order of
preference contained in sub-rule (2), the landholders (Pattadars) owning land not exceeding 2.024
Hectares or 5 Acres shall be given preference for grant of small scale quarry lease in their patta
lands:] [Inserted by G.O.Ms.No. 552, I & C, date 21-10-1986.](3)[ The quarry lease applications for
minor minerals under [items at at Sl.No. 1 to 3(a)] [Substituted by G.O.Ms.No. 110, I & C, date
9-3-1992, Pub. in AP Gaz. No. 12, date 26-3- 1992-Rules Sup. to Pt. I Ext.] of Schedule-I to Rule 10
shall be disposed of by the Deputy Director in order specified below: -(1)Applications of Societies of
Professional/(local) Traditional stone cutters (waddaras).(2)Crusher owners who do not have
quarries.(3)Unemployed youth holding Geology degree, and businessmen who propose to set up
crushers.(4)Others:[Provided that the above priorities shall prevail if the subsequent applications
are received within 7 (Seven) days of the receipt of the first application, otherwise the applicationsAndhra Pradesh Minor Mineral Concession Rules, 1966

shall be disposed off in the order of their receipt.] [Inserted by G.O.Ms.No. 2, I&C (MI) Department,
date 2-1-2004.][Provided [further] [Inserted & Substituted by G.O.Ms.No. 425, I & C, date
21-12-1993, w.e.f. 27-12-1993.] that the Deputy Director may with the prior approval of the
Government grant a quarry lease overlooking the above priorities for any special reasons to be
recorded in writing:Provided [also] [Substituted for the word 'further' by G.O.Ms.No. 2, I&C (MI)
Department, date 2-1-2004.] that whenever more than one application falling under category (1)
above are received for grant of quarry lease and have to be considered, the Deputy Director shall
refer the matter to the Government with his recommendations for a direction.][Provided also that
whenever more than one application falling under any of the categories (2) to (4) above are received
for grant of quarry lease and have to be considered in the order of preference specified above, such
preference shall be given to the applications falling in the same category, according to the date of
their receipt and in case of applications of the same category received on the same day, the Deputy
Director after taking into consideration the particulars furnished in the applications with the prior
approval of the Director, may grant the lease to deserving applicant, Further, he may with the prior
approval of the Director, grant a quarry lease to the applicant whose application was received later
in preference to the earlier application for reasons to be recorded in writing.] [Inserted &
Substituted by G.O.Ms.No. 425, I & C, date 21-12-1993, w.e.f. 27-12-1993.][(3-A) Notwithstanding
the order of preference contained in sub-rule (3) above the pattadars or their consent holders shall
be given preference for grant of quarry leases in respect of the patta lands.] [Substituted by
G.O.Ms.No. 110, I & C, date 9-3-1992, Pub. in AP Gaz. No. 12, date 26.3.1992, Rules Sup. to Pt. I
Ext.](4)In cases where the quarry lease holders fail to apply for renewal of the lease of the areas
within ninety days before the expiry of the lease held by them, as required under sub-rule (2) of Rule
13, fresh application for grant of quarry lease, in respect of those areas, will be entertained thirty
days before the expiry of the lease.(5)[(a)(i) A Prospecting license or Quarry Lease for Granite useful
for cutting and polishing, Marble and 31 minerals mentioned at Sl.Nos.18 to 48 in Schedule-1 of
Rule 10 shall be granted by the Director on an application made to the Assistant Director of Mines
and Geology concerned in Form-N or P and each such application shall be accompanied by a plan
drawn to the Scale duly signed by the applicant and by a qualified Surveyor and by a treasury
challan for Rs. 10,000/- (Rupees Ten thousand only) towards non-refundable application fee and a
deposit of Rs.25,000/- (Rupees Twenty five thousand only) for every hectare or part thereof by a
treasury challan in a Head of Account notified by the Director for this purpose. The deposit amount
shall be refundable when the application is rejected on technical grounds like Non availability of
area, rejection of No Objection Certificate (NOC).The deposit amount shall be forfeited when the
applicant fails to attend Survey and Inspection, withdrawal of the application by the applicant, non
execution of the lease and for any other lapse on the part of the applicant. Provided that the Andhra
Pradesh Mineral Development Corporation Limited, (a wholly owned State Government
Undertaking) is exempted from payment of deposit.] [Substituted by Notification No. G.O. Ms. No.
129, Industries & Commerce (Mines-II) Department, dated 16.11.2018.](ii)in any Government or
Patta Lands where the [granite and marble] [Substituted for 'granite' by G.O.Ms.No. 282, I&C (MI)
Department, date 23-9-2003.] is required to be removed for any purpose other than mining, the
Assistant Director Mines and Geology may grant the Temporary Permit duly verifying the site and
the purpose for which temporary permit is sought on payment of the required Seigniorage fee.(iii)[
A quarry lease for [granite useful for cutting and polishing and marble] [Inserted by G.O.Ms.No.
186, Ind. & Com. (MI) Department, dated 30.4.2002, pub. in A.P. Gaz., RS Pt. I ext., date 7.5.2002.]Andhra Pradesh Minor Mineral Concession Rules, 1966

shall be granted by the Director of Mines & Geology on an application made to the Assistant
Director of Mines & Geology concerned in Form 'P' without obtaining any prospecting licence
subject to the condition that the applicant gives an undertaking for submitting the scheme of
prospecting in the first year, submission of mining plan within (2) years from the date of execution
of the quarry lease deed, failing which the lease will be cancelled without giving any
opportunity.](iv)[ Processing fee of mining plan : Every Mining Plan submitted for Granite useful
for cutting and polishing/Marble for approval of Director of Mines and Geology or the Officer
nominated, shall be accompanied by a treasury or Bank challan for Rs. 1,000/- (Rupees One
thousand only) towards non-refundable processing fee for every mining plan submitted under rules
12 and 17 of the Granite Conservation and Development Rules, 1999 and under rules 16 and 17 of the
Marble Development and Conservation Rules, 2002.] [Added by G.O.Ms.No. 320, I&C (M-I), date
31-12-2004.](b)The application for grant of P.L. or Q.L. for [granite and marble] [Substituted for
'granite' by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.] shall be disposed off by the
Director in the order of their receipt. Whenever, more than one application is received on the same
day, the Director shall grant licence or lease to the deserving applicant on merits to be recorded in
writing:Provided that the Director may grant a P.L. or Q.L. to an applicant whose application is
received later, in preference to earlier application with the prior approval of the Government for any
special reasons to be recorded in writing:[Provided further that where a prospecting licence has
been granted in respect of any land the Licensee shall have preferential right for obtaining a quarry
lease in respect of that land over any other person in case he has undertaken prospecting operations
to establish mineral resources and submitted a prospecting report in respect of such land and
submitted quarry lease application within three months after expiry of the prospecting licence
period and such right can be exercised only once over the entire prospected area.] [Substituted by
G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.](c)[ On receipt of an application for the
grant of a Q.L., the Director shall take decision to grant precise area for the said purpose and
communicate such decision to the applicant alongwith a copy of the surveyed sketch showing the
area on which the mining plan has to be prepared. On receipt of the communication from the
Director of the precise area to be granted, the applicant shall prepare and submit a Mining Plan,
Environmental Clearances (EC) issued by the competent authority' and Consent for Establishment
(CFE) issued by the competent authority of APPCB within 1 (one) year for proposed lease area upto
25.00 Hects and within 2 (two) years for proposed lease area above 25.00 Hects or within such
other period not exceeding one year as may be allowed by the Director provided the grantee applies
for extension of time alongwith AMP and acknowledgement in token of filing application for grant of
Environmental Clearance before the competent authority, before 30 days from the date of expiry of
the period stipulated for submission of AMP, EC and CFE. The Director may consider the
application for grant of extension of time for submission of EC and CFE, if the applicant applies
after 30 days from the date of expiry of the period stipulated, but before the date of expiry of the
period stipulated for submission of AMP, EC and CFE, if the applicant satisfies the Director that the
applicant had sufficient cause for not making application within the specified time. [Substituted by
Notification No. G.O. Ms. No.53, Industries & Commerce (Mines-II) Department, dated
27.2.2019.]Provided also that no further extension of time shall be considered and the Director shall
reject the Quarry Lease application.](d)The Director shall reject the application for P.L. or Q.L. in
the event of any default on the part of applicant, in attending the inspection and survey or
submission of valid mineral revenue clearance certificate or any other material papers required byAndhra Pradesh Minor Mineral Concession Rules, 1966

the Director.(e)Execution of Licence or lease deed:- The licence or lease deed shall be executed
within sixty days from the date of grant or within such further period as the Director may allow in
this behalf provided the grantee applies for extension of time within fifteen days from the date of
expiry of period stipulated for execution. Such, extension may be granted by the Director not
exceeding two times, and each time not exceeding 30 days.Provided that any such application may
be entertained even after the prescribed period specified above, if the applicant satisfies the Director
that he had sufficient cause for not making application within the specified time.Provided further
that in case no licence or lease deed is executed within the stipulated period or the extended period
due to any default on the part of the applicant, the Director shall revoke the order granting licence or
lease and the deposit amount paid along with application shall be forfeited to the
Government.(f)Period and Extent to be granted for P.L. or Q.L.: -(i)[ A prospecting licence for
granite and marble shall be granted for a period not exceeding two years. The area covered by
prospecting licence for granite shall not be less than one hectare, but not exceeding fifty hectares.
The area covered by prospecting licence for marble shall not be less than four hectares with a
restriction that the dimension of any one side of such area shall not be less than two hundred meters
but not exceeding fifty hectares. [Substituted by G.O.Ms.No. 282, I&C (MI) Department, date
23-9-2003.](ii)The maximum period for which a quarry lease for granite and marble may be
granted shall not exceed thirty years :Provided that the minimum period for which any such quarry
lease may be granted shall not be less than twenty years. The area covered by lease for granite shall
not exceed fifty hectares and minimum area shall not be less than one hectare. The area covered by
quarry lease for marble shall not be less than four hectares with the restriction that the dimension
on any one side of such area shall not be less than two hundred metres, but not exceeding fifty
hectares.](iii)The Director Mines and Geology if he is satisfied on the basis of production level,
Geological or Topographical condition may for reasons to be recorded in writing, grant or renew a
licence or lease over an area more than the maximum area or less than the minimum area specified
under this rule.(g)Prospecting fee, Seigniorage fee or Dead Rent: -(i)[(a) Every prospecting licence
holder shall pay prospecting fee of rupees fifteen thousand and rupees twenty thousand for colour
granite and black granite respectively and rupees ten thousand for marble per hectare per annum.]
[Substituted by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.](b)The licensee may win
and carry for purposes of testing and marketability a [maximum quantity of 100 Cub. Meters or the
quantity permitted by the Director of Mines & Geology based on progress of prospecting work]
[Substituted by G.O.Ms.No. 186, Ind. & Com. (MI) Department, dated 30.4.2002.] per year
[irrespective of Colour or Black Granite or marble] [Substituted for 'irrespective of Color or Black
Granite' by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.] on payment of Seigniorage fee
for the time being specified under Schedule I of Rule 10 of the APMMC Rules, 1966.(ii)Every quarry
lease holder shall pay seigniorage fee or dead rent whichever is higher, as per Schedules I and II of
Rule 10 of APMMC Rules, 1966.(iii)The licensee or lessee shall pay the prospecting fee or dead rent
at the time of execution of licence or lease deed respectively and for the subsequent years one month
in advance every year along with land assessment and cess on land assessment.(h)Conditions of
licence or lease: -(i)[ The licensee or lessee for granite or marble shall observe the provisions of
Granite Conservation and Development Rules, 1999 or the provisions of Marble Development and
Conservation Rules, 2002, as the case may be;] [Substituted by G.O.Ms.No. 282, I&C (MI)
Department, date 23-9-2003.](ii)The licensee or lessee shall deposit in any Government Treasury
and file challans with the Assistant Director concerned for all sums payable to the GovernmentAndhra Pradesh Minor Mineral Concession Rules, 1966

under the terms of licence or lease or permit.(iii)The lessee shall pay the seigniorage fee as per the
rates prescribed from time to time in Schedule-I in advance for the quantity intended to be
despatched and submit the original challans to the Assistant Director of Mines and Geology
concerned and then only despatch the material. The lessee shall furnish the details of [granite and
marble] [Substituted for 'granite' by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.]
despatches with block numbers, quality, quantity and place of consignment to the Assistant Director
of Mines and Geology concerned immediately soon after the despatch of material. However, the
lessee is required to obtain the transit forms in advance for transportation of [granite and marble]
[Substituted for 'granite' by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.] and shall
render the account of the Assistant Director concerned once in a month. No second consignment of
way bill shall be issued unless the lessee has rendered the account of the previous account of
consignment of way bill:Provided that any misuse of the transit forms despatch of any [granite and
marble] [Substituted for 'granite' by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.]
without paying Seigniorage fee and not accompanied by the transit forms issued by the Assistant
Director, the lessee liable to pay [five times] [Substituted for 'one time' by G.O.Ms.No. 102, I&C (MI)
Department, date 28-9-2010.] of the normal Seigniorage fee as penalty for first time offence and
[ten times] [Substituted for 'two time' by G.O.Ms.No. 102, I&C (MI) Department, date 28-9-2010.]
penalty for the second time offence in addition to the Normal Seigniorage fee. Any subsequent
offence shall result in termination of the Lease.(iv)The Deputy Director of the region shall be the
competent authority to assess and fix in consultation with the concerned department, any
compensation payable by the licence or lessee for any loss, injury or damage done to the person
concerned or to his property.(v)The licensee or lessee shall erect and maintain at its own expenses
boundary pillars of substantial material standing not less than one metre above the surface of the
ground at each corner or angle on the line of the boundary of the area under licence or lease and at
intervals of not more than 183 metres along with the boundary delineated in the plan attached to the
area under the licence or lease.(vi)The licensee or lessee shall without delay send to the Assistant
Director concerned a report of any accident involving death or injury to any person which may occur
in and around the licence or lease area and shall observe all the rules for the time being in force
regarding the working of licence or lease.(vii)Lapsing of Licence or Lease:-(a)Where the licensee
shall not commence prospecting operations within a period of six months from the date of execution
of licence or is discontinued for continuous period of six months after commencement of such
prospecting operations, the Director shall by an order declare the P.L. as lapsed and communicate
the declaration to the licensee.(b)Where the mining operations are not conducted within a period of
two years from the date of execution of the lease or is discontinued for a continuous period of two
years, after commencement of such mining operation, the Director shall by an order declare the
lease as lapsed and communicate the declaration to the lessee :Provided that where the licensee or
lessee submits an application to the Director within a period of one month from the date of receipt
of such order and on being satisfied about the adequacy and genuineness of the reasons for the
non-commencement of prospecting or quarrying operations or discontinuance thereof, the Director
may recommend to the Government for revival of the licence or lease :Provided further that such
application shall be accompanied by payment of a fee of Rs. 2,500/- (Rupees Two Thousand and
Five Hundred) to the State Government.(viii)The licensee or lessee shall not assign, sub-let, transfer
or otherwise dispose of the under licence or lease without obtaining the previous sanction in writing
of the Director. The transfer application shall be made to the Assistant Director of the DistrictAndhra Pradesh Minor Mineral Concession Rules, 1966

concerned in Form R along with non-refundable application fee of Rs. 5,000 (Rupees Five
Thousand only). The licence or lease deed shall be executed as per the provision under clause
(e):[(Viii a):- The holder of a Lease, with the prior approval of the Director of Mines & Geology, may
be permitted to transfer such Lease for captive purpose in favour of the existing mineral based
industry or to a new mineral based industry with a condition that no permits will be issued till
Commercial Operation Date (CoD) is declared by the competent authority for mineral processing
and value addition. [Inserted by Notification No. G.O.Ms. 183, dated 28.12.2017 (w.e.f.
31.2.1997).]The application for transfer of Lease shall be made to the Assistant Director of Mines &
Geology concerned in Form-R alongwith the non-refundable application fee of Rs.10,000/- (Rupees
ten thousand only) alongwith the copies of certificate issued by the competent authority showing the
evidences for ownership and running of the industry. The transfer Lease deed shall be executed as
per Rule 12(5)(e).The permission for transfer of Lease to the mineral based industry holder shall be
accorded on payment of an amount equivalent to ten times of dead rent per hectare or the amount
equivalent to the dead rent per hectare for the unexpired period of lease, whichever is higher. Such
transfer shall be made only in favour of persons/entities owning the industry which would be
consuming the mineral.(Viii b):In case the Lease is granted to an Individual/Sole Proprietorship
Firm, the Lessee, with the prior approval of the Director of Mines & Geology, may be permitted to
change its constitution from individual/Proprietorship concern into partnership firm by adding new
partners, on registering itself as a Partnership Firm under the Indian Partnership Act, 1932 and the
original Lessee shall continue to hold 51% of his/her share and voting rights in the partnership firm
so created, till expity of Lease or subsequent renewal Lease period. The inter-se ratio of shares
among original partners shall not be changed during such a transfer. The Lessee shall furnish the
registration certificate to the Director of Mines & Geology within 60 days from the date of such
changes made.(Viii c):- In case of Lease granted to a partnership firm, such firm, with the prior
approval of the Director of Mines & Geology, may be permitted to add new partners into the firm so
that the original partners of the firm together shall continue to hold 51% of their share and voting
rights in the reconstituted firm till expiry of Lease or subsequent renewal Lease period. The inter-se
ratio of shares among original partners shall not be changed during such a transfer. The Lessee firm
shall effect such changes in the constitution of the firm as required under the Indian Partnership Act
1932 and intimate the same to the Director of Mines & Geology within 60 days from the date of such
changes made.(Viii d):- In case of Lease granted to the company registered under Companies Act,
2013, such company, with the prior approval of the Director of Mines & Geology, may be allowed to
add new Directors into the company and the original Directors of the company together shall
continue to hold 51% of their share and voting rights in the company till expiry of Lease or
subsequent renewal Lease period. The inter-se ratio of shares among original Directors shall not be
changed during such a transfer. The Lessee shall effect such changes in the constitution of the
company as required under the Companies Act, 2013 and intimate the same to the Director of Mines
& Geology within 60 days from the date of such changes made.Provided that in all the cases
mentioned at (viii b), (viii c), (viii d), the Lessee shall pay 2(two) times of dead rent payable under
Schedule II of Rule 10 of Andhra Pradesh Minor Mineral Concession Rules, 1966 as charges for
affecting changes in constitution/reconstitution of the firms/companies and the lessee shall be
made an application before the Assistant Director of Mines & Geology concerned in Form-R-1
appended to this order, alongwith the non-refundable application fee of Rs. 10,000 (Rupees ten
thousand only). The transfer lease deed shall be executed as per the provision under RuleAndhra Pradesh Minor Mineral Concession Rules, 1966

12(5)(e).(Viii e):In the case of Lase held by the Central/State Public Sector Units, they may be
permitted to sublet the Lease granted to them in favour of Joint Venture Companies/firms formed
by them after intimating the Director of Mines & Geology.]Provided that such sanction shall be
accorded that there is no speculation involved in the transfer of licence or lease :Provided further
that the transferor and the transferee shall not be in arrears of any mineral revenue to the
Government.[(viii f):- The holder of a Mineral Concession for Minor Minerals shall intimate to the
Director of Mines and Geology through the Assistant Director of Mines and Geology concerned
within 60 days of any change that may take place in its name, nationality or other particulars with
relevant copies of certificates issued by the competent authority approving the changes. Subject to
condition that, the shareholding pattern shall not be changed. [Added by Andhra Pradesh
Notification No. G.O. Ms. No. 87, Industries & Commerce (Mines-II) Department, dated 1.8.2018
(w.e.f. 31.2.1967).]The holder(s) of a Mineral concession/lessee fails without sufficient cause to
furnish the information referred to in sub-rule (a), the Director of Mines and Geology may impose a
fine which may extend to two lakh rupees and in the case of continued contravention of the
provisions of sub-rule (1) the Director of Mines and Geology may terminate the Mineral
concession/lease as the case may be.Provided that no such order shall be made without giving the
holder of mineral concession/lessee a reasonable opportunity of stating his case.Provided further
that the changes are effected prior to issue of these orders, in such cases the lessee may intimate the
changes with the copy of certificate issued by the competent authority within 60 days from the date
of issue of these orders.](ix)The licensee or lessee shall obtain the permission of the Assistant
Director concerned before he would erect on the area under licence or lease any building or
structure for prospecting or quarrying purpose, if the area belongs to Government.(x)If, in the
course of prospecting or quarrying any mineral not specified in the licence or lease is discovered, the
licensee or lessee shall at once report such discovery to the Assistant Director concerned to enable
him to obtain the order of the Director for prospecting/quarrying of the same.(xi)Renewal of Q.L.(i)[
If the lessee to whom a quarry lease is granted has complied with all the conditions of the lease and
filed an application for grant of renewal of lease in Form Q, to the Assistant Director of Mines and
Geology before twelve months of the expiry of the lease and accompanied by a treasury or bank
challan for Rs. 10,000/- (Rupees ten Thousand only) towards nonrefundable application fee, the
Director of Mines and Geology, shall initially renew for a period not exceeding 20 years. In case of
subsequent renewals, the Director of Mines and Geology, with Prior permission of the State
Government, shall grant such renewals, not exceeding 10 years at a time, till the mineral is
exhausted, subject to adherence to and non-violation of rules during the operation of mining lease.]
[Substituted by Andhra Pradesh Notification No. G.O. Ms. No. 87, Industries & Commerce
(Mines-II) Department, dated 1.8.2018 (w.e.f. 31.2.1967).](ii)The renewal of quarry lease
application shall be disposed of by the Director before the expiry of lease :Provided that where the
renewal of quarry lease application is not disposed of before the expiry of lease, it is deemed to have
been extended till the application is disposed of by the Director.(iii)The Director may condone the
delay in filing an application for renewal of quarry lease made after the time limit prescribed under
sub-rule (1) above.(xii)In case of any breach on the part of licensee or lessee of any covenant or
conditions contained in the grant, the Director may after giving an opportunity to the defaulter,
determine the licence or lease and take possession of the premises under licence or lease and forfeit
the security deposit.(xiii)On determination of the licence or lease for violation of the conditions, all
sums, paid by the licensee or lessee by way of deposits shall be forfeited and adjusted towards theAndhra Pradesh Minor Mineral Concession Rules, 1966

amount if any to be realised.(xiv)The Director may in consultation with the Government determine
the licence or lease, if it is considered necessary to do so in public interest after giving two calendar
months notice in writing.(xv)Any [granite and marble] [Substituted for 'granite' by G.O.Ms.No. 282,
I&C (MI) Department, date 23-9-2003.] extracted under quarry lease and not removed by the lessee
within 30 days or the determination of the lease, or the extended period given by the Director, shall
be the property of the Government and the Assistant Director may disposed of the same in public
auction.(xvi)Granite waste which cannot be sold as granite shall be sold as road metal or otherwise
with the permission of the Director. The rate of Seigniorage fee for such mineral shall be as per
Schedule-I under Rule 10 of the APMMC Rules, 1966.Note: - In respect of matters for which no
special provision is made in this sub-rule for granite, the provisions contained in other rules shall
apply.(6)Notwithstanding anything contained in sub-rules (2) to (4) a quarry lease shall be granted
in favour of Co-operative Societies consisting of exclusively of Adivasis/Tribals or individual
Adivasis/Tribals in the notified Tribal Areas.
13. Disposal of applications.
- [(1) The applications for the grant of quarry leases for any minor minerals [except sand, granite
useful for cutting and polishing and marble] [Substituted by G.O.Ms.No. 425, w.e.f. 27-12-1993.]
shall be disposed of by the Deputy Director concerned. The Deputy Director concerned shall reject
the applications in the event of default on the part of the applicants for not attending inspection or
survey or non-submission of Mineral Revenue Clearance Certificate or any other material papers as
required by Deputy Director. The lease deed shall be executed within ninety days from the date of
grant or within such further period as the Director may allow in this behalf provided the grantee
applies for extension of time within thirty days from the date of expiry of the period stipulated for
execution. Such extensions can be granted by the Director not exceeding two times and such time
not exceeding thirty days. If no lease deed is executed within the stipulated period or extended
period due to any default on the part of the applicant, the authority who is competent to grant
quarry lease shall revoke the order granting lease.][Provided that any such application may be
entertained for the first time even after the prescribed period specified above, if the applicant
satisfies that he had sufficient cause for not making the application within the specified time.]
[Added by G.O.Ms.No. 2, I&C (MI) Department, date 2-1-2004.](2)The application for the renewal
of a quarry lease [the application for the renewal of a quarry lease shall be accompanied by a
Treasury or Bank challan for rupees one thousand in token of remittance towards fee and] [Inserted
by G.O.Ms.No. 310, I & C, date 10-9-1993, w.e.f. 13-9-1993. Pub. in A.P. Gaz. No. 21, date 13-9-1993,
RS to Pt. I. 3.] shall be made at least ninety days before the expiry of the period of lease to the
[Deputy Director] [Substituted by G.O.Ms.No. 161, date 24-3-1980.] and it shall be disposed of
before the expiry of the lease period. [***] [Omitted by G.O.Ms.No. 2, I&C (MI) Department, date
2-1-2004.][Provided that where the renewal of quarry lease application is filed within the stipulated
time and not disposed off before the expiry of the lease, the period of quarry lease shall be deemed
to have been extended till the renewal application is disposed of by the Deputy Director.] [Inserted
by G.O.Ms.No. 2, I&C (MI) Department, date 2-1-2004.][Provided [further] [Added by G.O.Ms.No.
446, date 11-9-1980.] that where an application for the grant of quarry lease is rejected or deemed to
have been refused under these rules, the fee paid by the applicant under sub-rule (1) of Rule 12 shall
be refunded to the applicant :Provided [also] [Substituted for 'further' by G.O.Ms.No. 2, I&C (MI)Andhra Pradesh Minor Mineral Concession Rules, 1966

Department, date 2-1-2004.] that where an application for grant of quarry lease is rejected on
account of any lapse on the part of the applicant in supplying any material information, the fee paid
by the applicant under sub-rule (1) of Rule 12 shall be forfeited to the Government.][***] [Omitted
by G.O.Ms.No. 2, I&C (MI) Department, date 2-1-2004.]
14. [ Security Deposits. [Inserted by G.O.Ms.No. 2, I&C (MI) Department, date
2-1-2004.]
- An applicant for Prospecting Licence shall before the licence deed is executed deposit a sum of Rs.
10,000/- (Rupees Ten thousand only) for every hectare or part thereof for which, the licence is
granted.An application for a quarry lease shall before the deed is executed, deposit as security, for
the due observance of terms and conditions of the lease, a sum, equivalent to one year dead rent.]
15. Period of Lease.
- [(1) Quarry lease may be granted by the Deputy Director for a period of five years in respect of
minerals which can be extracted without much equipment or investment like sand, morrum, gravel,
limeshell and lime kankar, chalcedeny pebbles, shingle, reh-matti. In respect of the minerals which
require investment, equipment to develop the quarry, such as boulders, building stone, lime stone,
mosaic chips, Fullers earth, shale, slate, marble, Shabad slabs, napa slabs, bentonite, lime shell, road
metal without crushing unit for a period of 10 years and in respect of minor minerals useful for road
metal, ballast serving as a captive source for a crusher unit for a period of fifteen years.] [Substituted
by G.O.Ms.No. 238, I & C, date 9-7-1992, w.e.f. 15-7-1992.](2)If the Government are satisfied that
for the proper and systematic development of the quarry, a period longer than [5/10/15]
[Substituted by G.O.Ms.No. 238, I & C, date 9-7-1992, w.e.f. 15-7-1992.] years is necessary necessary
and that the applicant or lessee is capable, financially and technically, of developing the quarry on a
large scale, a quarry lease may be granted for a longer period not exceeding twice the fixed period
such lease may, however, be renewed from time to time.
16. [ Restriction on determination of lease. [Substituted by G.O.Ms.No. 238, I
& C, date 9-7-1992, w.e.f. 15-7-1992.]
(1)The lessee shall not not abandon the lease except after a notice in writing of not less than six
calender months to the Deputy Director [other than [granite and marble] and to the Director in case
of [granite and marble] [Substituted for 'granite' by G.O.Ms.No. 282, I&C (MI) Department, date
23-9-2003.].](2)Every application for surrender of part of the leasehold area in accordance with the
provisions of sub-rule (1) shall be accompanied by [a deposit of Rs. 500/-] [Substituted for 'a
deposit of Rs. 50/-' by G.O.Ms.No. 227, I & C (M. I) Department, date 23.3.2000.] for meeting the
expenditure for the purpose of survey and demarcation of the area to be surrendered:Provided that
where a lessee applies for the surrender of the whole or part of the leasehold area on the ground that
such area is barren or the deposits of minerals being since exhausted or depleted to such an extent
that it is no longer economical to work such area, the [Deputy Director or the Director of Mines and
Geology] [Substituted for the words 'Deputy Director' by G.O.Ms.No. 227, I & C (M. I) Department,Andhra Pradesh Minor Mineral Concession Rules, 1966

date 23.3.2000.] shall permit the lessee, from the date of receipt of the application, to surrender that
area if the following conditions are satisfied, namely: -(a)The leasehold area to be surrendered has
been properly surveyed and the retained area is continguous ;(b)The lessee has paid all the dues
payable to the Government under the lease upto the date of application ;(c)Surrender of the area by
the lessee has not already been permitted earlier.][The Director of Mines and Geology/Deputy
Director of Mines and Geology concerned may, in the interest of Mineral Development and with
reasons to be recorded in writing permit amalgamation of two or more adjoining leases held by a
lessee;Provided that the period of amalgamated leases shall be co-terminus with the lease whose
period will expire first or a minimum period of further 5 years from the date of amalgamation
whichever is later.] [Added by Notification No. G.O.Ms. 174, dated 12.12.2017 (w.e.f. 31.2.1997).]
17. [ Lapsing of leases. [Substituted by G.O.Ms.No. 238, I & C, date 9-7-1992.]
(1)Subject to the other conditions in this rule, where quarrying operations are not commenced
within a period of six months from the date of execution of the lease or is discontinued for a
continuous period of six months after commencement of such operations or the payments as
required under Clause (iv) of rule 31 are not made, the Deputy Director shall by an order, declare the
quarry lease as lapsed and communicate the decision to the lessee.(2)Where the lessee is unable to
commence the quarrying operations within a period of six months from the date of execution of the
lease or discontinued quarrying operations for a period of six months for reasons beyond his
control, he may submit an application to the Director explaining the reasons for the same atleast 30
days before the expiry of such period.(3)Every application under sub-rule (2) shall be accompanied
by [a fee of Rs. 500/-.](4)The Director may on receipt of application made under sub-rule (2) and on
being satisfied about the adequacy and genuineness of the reasons for the non-commencement of
the quarrying operations or discontinuation thereon, pass an order extending or refusing to extend
the period of the lease.(5)The Director may condone, the delay in submission of the application
under sub-rule (2) before the lapse of the lease.]
18. Default in payment of bid amount.
- [If the lessee or the bidder makes default in payment of any money due from him under these rules
within the stipulated period or neglects to furnish security deposit or to execute the lease deed when
required, the Deputy Director may pass an order forfeiting all sums paid by him and cancel the
quarry lease.] [Substituted by G.O.Ms.No. 3, I & C, date 3-1-1991, Pub. in A.P. Gazette No. 1, date
1.8.1991. Rules Supp. Pt. I, Ext.]
19. [ [Inserted by G.O.Ms.No. 50, I & C (M 1), date 17-3-1997.]
The State Government may without prejudice to the provisions contained in the Act or any other
rule in these Rules, change simple interest at the rate of Twenty four per cent, per annum on any
amount payable under these rules or under the terms and conditions if any quarry lease from the
sixteenth day of the expiry of the date fixed for payment of such amount and until payment of such
sums is made.]Andhra Pradesh Minor Mineral Concession Rules, 1966

20. Rights under a Lease.
- Subject to a contract to the contrary, a quarry lease granted under the rules shall confer on the
lessee, the right to quarry, carry away, sell or dispose of the minor mineral or minerals specified in
the lease deed and found upon under the lands specified therein.
21. Removal of Sand from Port limits.
- [(1) Removal of sand may be allowed with the previous permission of the Conservator of Port
under sub-section (1) of Section 3 of Indian Ports Act, 1908 from the Ports under the administrative
control of the State Government for scrubbing decks and ballast on small country crafts or for other
marine purposes free of charge in case the sand removed is not exceeding half a tonne and in other
cases, the prevailing rate of seigniorage fee for ordinary sand as specified in Schedule I under Rule
10 from time to time shall be levied on the quantity removed in excess over half a tonne. The
seigniorage fees so collected shall be credited to the Andhra Pradesh Minor Port Fund or the
Landing and Shipping Fund, as permitted Authority directs.] [G.O.Ms.No. 417, I & C (M. I), date
1-12-1998.](2)Quarrying and removal of sand for non-marine purposes shall, however, be subject to
the previous permission of the Conservator and payment of the seigniorage fee.
22. Availability of the areas for grant to be notified.
- [***] [Omitted by G.O.Ms.No. 315, I & C, date 2-8-1994, w.e.f. 8-8-1994.]
23. Removal of sand etc., from lands and tanks in-charge of the Government
Department.
(1)Nothing in the foregoing rules shall apply to removal of sand, earth or silt for non-commercial
purpose from the lands and tanks in-charge of the Public Works Department and the Revenue
Department.(2)Sand, earth or silt from the beds of tanks under the control of the Public Works
Department or the Revenue Department, which are notified by the Assistant Director under this
rule, may be allowed to be removed free of charge for bona fide domestic, agricultural or
non-commercial purposes. Such removal shall be subject to the following restrictions, namely:
-(i)pits shall be a distance of at least twice the height of the bund from the toe of the bund, and they
shall not be of such depth as would expose porus starta and at any rate more than one
metre;(ii)earth shall not be carted along tank bund unless the bund is a road or car track ;(iii)bunds
shall not be cut to enable carts to pass ;(iv)silt removed shall not be stocked on tank beds, bunds or
slopes of bunds ; and(v)cart shall not touch any portion of the revetment sluice or any other
masonary works of the tank and cause damage to them.(3)Before issuing the notification under
sub-rule (2) in respect of the tanks in-charge of the Public Works Department or the Revenue
Department, the Assistant Director shall consult the Executive Engineer or the Collector of the
revenue district concerned.Andhra Pradesh Minor Mineral Concession Rules, 1966

24. Removal of minor minerals from sources vested in Zilla Parishads,
Municipalities, Panchayat Samithis & Gram Panchayats.
- The Assistant Director may, subject to the provisions of Rule 12, grant lease for the removal of any
minor mineral from any sources of water supply vested in any Zilla Parishad, Municipality,
Panchayat Samithi or Gram Panchayat, after consulting it.
25. [ Quarrying or removal of sand in certain river beds. [Inserted by
G.O.Ms.No. 46, I & C, date 6-2-1996.]
- Whenever the Director or the Officer authorised by him decides to lease-out the right of quarrying
for sand in sealed Tender-cum-Public Auction, in River beds to which the Andhra Pradesh (Andhra
Area) River Conservancy Act, 1884 applies he shall prior to the issue of notice under Rule 9-C
consult the Conservator of Rivers.]
26. Penalty for unauthorised quarrying.
- [(1)] [Substituted by G.O.Ms.No. 339, I & C, date 10-7-1989.] If any person carries on quarrying
operations or transports minor minerals in contravention of these rules, he shall be liable to pay as
penalty, such enhanced seigniorage fee together with assessments as may be imposed by an Officer
nominated by the Director of Mines and Geology.(2)Whenever any person raises or transports
minor minerals without any lawful authority, such minerals may be seized by an Officer nominated
by the Director of Mines and Geology in this behalf in addition to the imposition of the penalty
under sub-rule (1) :Provided that in no case, the penalty shall exceed [ten times] [Substituted for
'two times' by G.O.Ms.No. 102, I&C (MI) Department, date 28-09-2010.] the normal seigniorage fee
and the lease or permit already granted may, at the discretion of the Deputy Director, be liable to be
terminated or cancelled.(3)[(i) For the purpose of ascertaining the position of payment of Mineral
Revenue due to the Government or for any other purpose under these rules, the person authorised
under sub-rule (2) may -(a)enter and inspect any premises ;(b)survey and take measurements
;(c)weigh, measure or take measurements of stocks of minerals ;(d)examine any document, book,
register or record in the possession or power of any person having the control of, or connected with
any mineral including the processed mineral and place marks of identification thereon and take
extracts from, or make copies of such document, book, register or record ; and(e)order the
production of any such document, book, register, record as is referred in Clause (d).(ii)If no
documentary proof is produced in token of having paid the mineral revenue due to the Government
by any person who used or consumed or in possession of any mineral including the processed
mineral, he shall notwithstanding anything contained in sub-rule (1) be liable to pay [five times] of
the normal seigniorage fee as penalty in addition to normal seigniorage fee leviable under the
rules.[Explanation. - It shall be competent to the officer nominated by the Director of Mines and
Geology to determine the question whether quarrying operation or transportation of minerals are
carried or not within the meaning of this rule.] [Substituted by G.O.Ms.No. 339, I & C, date
10-7-1989.] [Inserted by G.O.Ms.No. 243, I & C, date 8-5-1986.](4)[ The applicant/applicant
company convicted for an offence relating to unauthorised mining/quarrying of minor mineralsAndhra Pradesh Minor Mineral Concession Rules, 1966

shall be debarred/disqualified for getting new Quarry Lease or renewal of the existing Quarry Lease
for a period of ten (10) years.] [Inserted by G.O.Ms.No. 146, I&C (Mines-I), date 11-5-1998.](5)[
whoever contravenes the provisions under sub-rule (5) of Rule 10, the Assistant Director of Mines
and Geology or any Officer nominated in this behalf by the Director of Mines and Geology shall raise
a demand as specified in the Schedule III with [five times] [Inserted by G.O.Ms.No. 104, I&C (M1)
Department, date 15-5-2009.] penalty. In the event of default of payment of penalty within a period
of one month an officer not below the rank of Assistant Director of Mines and Geology or any officer
authorized by the Director of Mines and Geology shall be competent to seize the unit from its
operation by duly recording panchanama. On such seizure it is the responsibility of the industry
concerned to safeguard its machinery by keeping a watch and ward and department will not take
any responsibility for the machinery and any other equipment present in industry or damage to the
civil structures.]
27. Registered holder or any lessee held responsible for proper working of
the quarry.
- In a case where the land is leased out, the lessee and where no lease is granted, the registered
holder shall be responsible for the proper working of the quarry and shall be liable to the
Government for his wrongful act or default.
28. Discovery of new mineral, fencing, accounting, etc.
(1)If any minor mineral not specified in the lease or the order sanctioning the permit is discovered in
the area, under lease or permit, the lessee or the permit holder shall not win or dispose of such
mineral without obtaining permission of the Assistant Director and without payment of such
seigniorage fee as well as the acreage assessment as would be due if permission was granted in
respect of such mineral.(2)The lessee [***] [Omitted by G.O.Ms.No. 147, I&C (M1) Department, date
5-3-1982.] shall at his own expense, erect boundary marks round the area shown in the plan
annexed to the lease or mentioned in the order sanctioning the permit, as the case may be, and
maintain and keep boundary marks in good repair.(3)The lessee or the person to whom a permit is
given shall keep true accounts of the quantity and other particulars of all minor minerals obtained
and dispatched from the quarry in Form C.(4)Any officer authorised by the Deputy or Assistant
Director in this behalf shall have access to such account for examination and inspection and the
permit holder or the lessee shall furnish the officer with such information and returns as may be
specified by him.(5)The lessee or the person to whom a permit is given shall strengthen and support
any part of the quarry for the safety of any railway, reservoir, canal, road or any public work or
structure to the satisfaction of the Railway Administration, local authority or the State Government,
as the case may be, according to the requirements.
29. Recovery of arrears.
- Any amount due to Government under these rules may be recovered as an arrears of land revenue.Andhra Pradesh Minor Mineral Concession Rules, 1966

30. Report to Chief Inspector of Mines.
- The lessee or his agent or the manager of the quarry shall forward to the Chief Inspector of Mines,
Dhanbad, India and the [Assistant Director] [Substituted by G.O.Ms.No. 226, I & C, date 25-3-1977.]
concerned a report in Form F1.(i)whenever the depth of the quarry measured from its highest to its
lowest point reaches six metres ;(ii)whenever the number of persons employed in the quarry on any
day is more than 50 ; and(iii)at such times as the Assistant Director may direct.
31. Conditions of permit or lease.
- Every quarry lease shall, in addition to such conditions as may be specifically stipulated in each
case, be subject to the following conditions, viz -(i)[***] [Omitted by G.O.Ms.No. 226, I & C, date
25-3-1977.](ii)[***] [Omitted by G.O.Ms.No. 226, I & C, date 25-3-1977.](iii)The lessee shall pay
annually the land assessment, if any, of the area under lease or permit ;(iv)[ The lessee shall pay the
advance dead rent at the time of execution of the lease deed and the annual dead rent for the
subsequent years, one month in advance every year and all other sums payable to the Government
in any Government Treasury and file the challans to the Assistant Director concerned ;] [Substituted
by G.O.Ms.No. 238, I & C, date 9-7-1992.](v)The Deputy Director, shall be the competent authority
to assess and fix, in consultation with the concerned departments, any compensation payable by the
lessee for any loss, injury or damage done to the person concerned or to his property.(vi)The lessee
shall, [***] [Omitted by G.O.Ms.No. 147, I & C, date 5-3-1982.] effect and maintain at his own
expense, boundary pillars of substantial material, standing not less than one metre above the
surface of the ground at each corner or angle in the line of the boundary of the area under lease or
permit and at intervals of not more than 183 metres along with the boundary, delineated in the plan
attached to the area under lease or permit ;(vii)The lessee shall commence quarrying operations
within two months from the date of the grant and shall thereafter carry on such operations
effectively in a proper, skillful and workman like manner, as regards prevention of waste within the
quarry and shall not work it in such a manner as may prove dangerous to human life or cattle and
shall, if so directed by the Assistant Director, cause such quarry or any part thereof to be securely
fenced to the satisfaction of the Assistant Director.(viii)The lessee shall without delay send to the
Assistant Director a report of any accident involving the death or injury to any person which may
occur in or around the quarry and shall observe all rules for the time being in force regulating the
working of quarries;(ix)The lessee shall not assign, sublet, transfer or otherwise dispose of the area
under lease or permit without obtaining the previous sanction in writing of the Deputy Director ; [A
quarry lease granted in public auction for sand is not open for transfer ;] [Added by G.O.Ms.No. 3,
date 3-1-1991, pub. in A.P. Gaz. No. 1, date 8-1-1991.][(ix a) : The holder of a lease, with the prior
approval of the Deputy Director of Mines & Geology concerned, may be permitted to transfer such
lease for captive purpose in favour of the existing mineral based industry or to a new mineral based
industry with a condition that no permits will be issued till Commercial Operation Date (CoD) is
declared by the competent authority for mineral processing and value addition. [Inserted by
Notification No. G.O.Ms. 183, dated 28.12.2017 (w.e.f. 31.2.1997).]The application for transfer of
lease shall be made to the Assistant Director of Mines & Geology concerned in Form-R, alongwith
the non-refundable application fee of Rs. 10,000/- (Rupees ten thousand only) alongwith the copies
of certificate issued by the competent authority showing the evidences for ownership and running ofAndhra Pradesh Minor Mineral Concession Rules, 1966

the industry. The transfer lease deed shall be executed as per the provision under Rule 13(i).The
permission for transfer of lease to the mineral based industry holder shall be accorded on payment
of an amount equivalent to ten times of dead rent per hectare or the amount equivalent to the dead
rent per hectare for the unexpired period of lease, whichever is higher. Such transfer shall be made
only in favour of persons/entities owning the industry which would be consuming the mineral.(ix
b):-The lessee, with the prior approval of the Deputy Director of Mines & Geology concerned, may
be permitted to change from an individual/sole proprietorship firm into partnership firm by adding
new partners on registering itself as a Partnership Firm under the Indian Partnership Act, 1932 and
the original lessee shall continue to hold 51% of his share and voting rights in the partnership firm
so created, till expiry of lease or subsequent renewal lease period. The inter-se ratio of shares among
original partners shall not be changed during such a transfer. The lessee shall register itself as
required under the Indian Partnership Act 1932 and furnish the registration certificate to the
Deputy Director of Mines & Geology concerned, within 60 days from the date of such changes
made.(ix c):- In case of lease granted to a partnership firm, such firm, with prior approval of the
Deputy Director of Mines & Geology concerned, may be permitted to add new partners into the firm
and the original partners of the firm together shall continue to hold 51% of their share and voting
rights in tine reconstituted firm till expiry of lease or subsequent renewal lease period. The inter-se
ratio of shares among original partners shall not be changed during such a transfer. The lessee firm
shall effect such changes in the constitution of the firm as required under Indian Partnership Act
1932 and intimate the same to the Deputy Director of Mines Sc Geology concerned, within 60 days
from the date of such changes made.(ix d):- In case of lease granted to the company registered under
Companies Act 2013, such company, with prior approval of the Deputy Director of Mines & Geology
concerned, may be permitted to add new Directors into the company so that the original Directors of
the company together shall continue to hold 51% of their share and voting rights in the company till
expiry of lease or subsequent renewal lease period. The inter-se ratio of shares among original
Directors shall not be changed during such a transfer. The lessee company shall effect such changes
in the constitution of the company as required under Companies Act, 2013 and intimate the same to
the Deputy Director of Mines & Geology concerned, within 60 days from the date of such changes
made.Provided that in all the cases mentioned at Rule 31 (ix b)(ix c)(ix d), the lessee shall pay two
(2) times of dead rent payable under Schedule II of Rule 10 of Andhra Pradesh Minor Mineral
Concession Rules, 1966 as charges for affecting changes in constitution/reconstitution of the
firms/companies and the lessee shall be made an application before the Assistant Director of Mines
& Geology concerned in Form-R1 appended to this order, alongwith the non-refundable application
fee of Rs. 10,000 (Rupees ten thousand only). The transfer lease deed shall be executed as per the
provision under Rule 13(i).(ix e) :In the case of lease held by the Central/State Public Sector Units,
they may be permitted to sublet the lease granted to them in favour of Joint Venture Company firm
formed by them after intimating the Deputy Director of Mines Sc Geology concerned.][(viii f):- The
holder of a Mineral Concession for Minor Minerals shall intimate to the Director of Mines and
Geology through the Assistant Director of Mines and Geology concerned within 60 days of any
change that may take place in its name, nationality or other particulars with relevant copies of
certificates issued by the competent authority approving the changes. Subject to condition that, the
shareholding pattern shall not be changed. [Added by Andhra Pradesh Notification No. G.O. Ms.
No. 87, Industries & Commerce (Mines-II) Department, dated 1.8.2018 (w.e.f. 31.2.1967).]The
holder(s) of a Mineral concession/lessee fails without sufficient cause to furnish the informationAndhra Pradesh Minor Mineral Concession Rules, 1966

referred to in sub-rule (a), the Director of Mines and Geology may impose a fine which may extend
to two lakh rupees and in the case of continued contravention of the provisions of sub-rule (1) the
Director of Mines and Geology may terminate the Mineral concession/lease as the case may
be.Provided that no such order shall be made without giving the holder of mineral concession/lessee
a reasonable opportunity of stating his case.Provided further that the changes are effected prior to
issue of these orders, in such cases the lessee may intimate the changes with the copy of certificate
issued by the competent authority within 60 days from the date of issue of these orders.](x)The
lessee shall not cut or injure any trees in the area under lease or permit ;(xi)The lessee shall obtain
the permission of the Assistant Director before he would erect on the area under lease or permit any
building for quarrying purposes if the area belonged to the Government ;(xii)If, in the course of
quarrying, any mineral not specified in the lease is discovered, the lessee shall at once report such
discovery to the Assistant Director to enable him to obtain orders of the Government regarding the
working of the same ;(xiii)If the lessee stops to work the quarry without the prior sanction of the
Assistant Director for a continuous period of six months, the lease granted for quarrying shall be
liable to be cancelled;(xiv)[ If the lessee to whom a quarry lease is granted has duly observed all the
conditions of the lease and file an application under Rule 9(i) to the Deputy Director (through
Assistant Director) [***] [Substituted by G.O.Ms.No. 238, I & C, date 9-7-1992, w.e.f. 15-7-1992.] the
Deputy Director may grant renewal for not more than two times to the period of the quarry lease.
The renewals are further subject to the following criteria:-First Renewal: -(a)Systematic
development of the quarry/quarries.(b)Development of good communication facilities and their
maintenance.(c)Investment on transport.(d)Training of skilled labour and commitments on labour
retention and inducement.(e)Preliminary work and investment for establishment of a processing
(dressing or upgrading) plant utilising the product from the quarry/quarries in
question.(f)Establishment of market for the product, either in raw from or in processed or
semi-processed form.Second Renewal: -(a)Establishment of processing plant, either individually or
in joint partnership with others.(b)Development of market in the country or abroad.(c)Any long
term contracts with established industries for supply of quarry product.(d)Setting up of an industry
in the region either individually or in partnership with others.Note: - (1) Adherence to and
non-violation of rules during the term of occupation is a primary prerequisite in all cases of
consideration of renewal.(2)In case of. patta lands, renewals may be automatic.(3)In case of leases
for minor minerals useful for road metal ballast serving as a captive source for a crusher unit the
renewal may be granted as long as crushing unit is in operation.](xv)If the seigniorage fee or dead
rent payable by the lessee is not paid within three months next after the date fixed in the grant or
otherwise for its payment, the Deputy Director or any Officer authorised by him, may after giving an
opportunity to the defaulter, enter upon the area under lease or permit and distrain all or any of the
mineral or the movable property belonging to him and standing on the land, and may order for the
sale of the property distrained or so much of it as will suffice to cover the arrears due to the
Government together with all costs and expenses occasioned by the non-payment thereof and may
also determine the lease or permit ;(xvi)In the case of any breach on the part of the lessee of any
covenant or condition contained in the grant, the Deputy Director, may, after giving an opportunity
to the defaulter, determine the lease [*] [Omitted by G.O.Ms.No. 147, I & C, date 5-3-1982.]
and take possession of the premises under lease [*] [Omitted by G.O.Ms.No. 147, I & C, date
5-3-1982.] and forfeit the security deposit ;(xvii)On the determination of a lease or permit for
violation of condition (iii), (xv) or (xvi), all sums paid by the lessee by way of deposit shall beAndhra Pradesh Minor Mineral Concession Rules, 1966

adjusted towards the amounts, if any, due to the Government and any further dues remaining
unpaid shall become recoverable from the lessee.(xviii)The Deputy Director may, in consultation
with the Government determine the lease, if it is considered by him necessary to do so in the public
interest after giving two calendar months notice in writing ;(xix)[ Any minor mineral extracted from
the quarry and not removed by the lessee before the date of expiry of the determination of the lease
or permit may be dispatched within 30 days or extended period granted by the Government from
the date of such expiry or determination after paying dead rent and seigniorage fee and any other
sums which may be due. If the lessee does not remove the extracted mineral from the leased area
within the permitted and extended period mentioned above it shall be the property of the
Government and the Assistant Director may sell it in public auction.] [Substituted by G.O.Ms.No.
315, I & C, date 2-8-1994, w.e.f. 8-8-1994.](xx)[ When the quarry lease is granted by public auction
the lessee shall pay the quarrying fee or lease amount in the manner prescribed in these rules.]
[Inserted by G.O.Ms.No. 457, I & C, date 12-8-1986.](xxi)[ (a) The lessee shall follow and effect the
provisions of Labour Laws pertaining to the employment, payment of wages and other welfare
measures to the Labour who are employed in quarries and mines. [Added by G.O.Ms.No. 117, I & C,
date 16-11-2011.](b)The lessee further shall take all precautionary measures in conducting mining
operations as per the relevant stipulations made under Mettalliferrous Mines Regulations, 1961.(c)If
the lessee violates the provisions as stipulated above, necessary action shall be taken for cancellation
of the lease after obtaining the information from the concerned departments after giving an
opportunity.]
32. Special conditions in the lease.
- The grant may include any special conditions for working in forest areas and the lessees shall not
interfere with exploitation of the forest produce in the area or with the rightful exercise of any other
rights other than the exploitation of the minor minerals for which the grant is made to him.
33. Head of Account to which amount should be remitted.
- Any stocks of minor minerals excavated by the lessee or the person who worked at the quarry
under a lease or permit under these rules and left lying on the area after the expiry of the lease or
permit shall be the property of the Government and the Assistant Director may sell it in public
auction. The amount so collected as cost of cesses, if any, shall be credited to the following Head
Account.
[Major Head] [For current Head of Account, vide App. 1.] : 128 - Mines and Minerals ;
Minor Head : Mineral Concession Fee ;
Sub-Head: Seigniorage fee or dead rent on minor
minerals.Andhra Pradesh Minor Mineral Concession Rules, 1966

34. Despatch permit.
- [(1) No minor mineral shall be dispatched from any of the leased areas without a valid permit
issued by the Assistant Director of Mines and Geology concerned or an officer authorized in this
behalf by the Director of Mines and Geology:[Provided that any misuse of the transit forms without
paying Seigniorage Fee and not accompanied by the transit forms used by the Assistant Director of
Mines & Geology concerned or an officer authorized in this behalf by the Director of Mines &
Geology and any other contravention, shall result in forfeiture of Security Deposit and levy of
normal Seigniorage Fee along with "five times" penalty by the Assistant Director of Mines & Geology
concerned or the Officer as authorized by the Director of Mines & Geology.] [Substituted by
G.O.Ms.No. 104, I&C (M1) Department, date 15-5-2009.](2)The application for the despatch permit
under sub-rule (1) shall be made by the lessee to the Assistant Director concerned in Form-K by duly
enclosing challans towards advance payment of seigniorage fee for the proposed quantity to be
despatched atleast ten days before the proposed date of despatch of the mineral. The permit shall be
issued by the competent authority in Form- L:](3)[ Those who are covering under Rule 10(5) shall
obtain dispatch permits from the Assistant Director of Mines and Geology concerned in Form- L1
duly filing application in Form-Kl for procuring material from the lease hold source by duly paying
the Seigniorage Fee under Schedule III of these rules. The dispatch permits shall be issued for a
period proportionate to the amounts paid by them, but for a period not less than one month.
However they shall invariably procure the raw material from the authorized licenses/ lessees
concerned for respective mineral under the provision of the Andhra Pradesh Minor Mineral
Concession Rules, 1966. In case they resort for unauthorized quarrying they are liable for action
under Rule 26 of these rules.(4)In case of units under 10(5)(1) if declared sick for a period exceeding
six months shall represent to Assistant Director of Mines and Geology by duly paying Rs. 1,000/-
and concerned Deputy Director of Mines and Geology will enquire and pass orders.] [Inserted by
G.O.Ms.No. 102, I&C (MI) Department, date 28-09-2010.]
35. Appeal.
- An appeal against any order passed by the Assistant Director or Deputy Director, [Joint Director]
[Inserted by G.O.Ms.No. 50, I & C (M I), Department, date 17-3-1997.] under these rules shall lie to
the Director within a period of two months from the date of communication of such order to the
party aggrieved and an appeal against an order of the Director [***] [Omitted by G.O.Ms.No. 425, I
& C, date 21-12-1993, w.e.f. 27-12-1993.] shall be to the Government in like manner.
35A. Revision.
- The Government may either suo motu at any time or on an application made within ninety days,
call for and examine the record relating to any order passed or proceeding taken by the Director,
[Joint Director] [Inserted by G.O.Ms.No. 50, I & C (M I), Department, date 17-3-1997.], Deputy
Director or Assistant Director under these rules for the purpose of satisfying themselves as to the
legality or propriety of such order or as to the regularity of such proceedings and pass such order in
reference thereto as they think fit :Provided that no order adversely affecting any person shall be
passed under this rule unless such person has been given an opportunity of making hisAndhra Pradesh Minor Mineral Concession Rules, 1966

representation.[Explanation. - For purposes of this rule where a Deputy Director has failed to
dispose of an application for the grant or renewal of a quarry lease within the period specified in
respect thereof under these rules, the Deputy Director shall be deemed to have made an order
refusing the grant or renewal of such lease on the date on which such period expires.] [Substituted
by G.O.Ms.No. 147, I & C, date 5-3-1982.]
35B. [ Fees. [Inserted by G.O.Ms.No. 21, I & C, date 17-1-1981.]
- Every appeal under Rule 35 or application for revision under Rule 35-A shall be accompanied by a
treasury receipt showing that [a fee of rupees five hundred if it is an appeal or a fee of rupees one
thousand if it is an appeal for revision], has been paid into a Government Treasury or in any Branch
of the State Bank of Hyderabad doing the Treasury business, to the credit of the State Government
under the following Head of account: -
128. [ Mines and Minerals - M.H. 10 Minerals Concession Fees, Rents and
Royalties - S.H. (03) - Miscellaneous Revenues.] [For current Head of Account
vide App. I.]]
[[35C. Application for appeal/revision. [Inserted by G.O.Ms.No. 25, I & C, date 12-1-1984.]- Any
appeal against any order passed by the Assistant Director or the Deputy Director or Joint Director
filed before the Director under Rule 35, of revision against any order passed by the Director, Joint
Director, Deputy Director or Assistant Director filed before the government under Rule 35-A of
these rules shall be made in triplicate in Form J within the period specified in Rule 35 or 35-A of
these rules, alongwith Treasury receipt shown that the fees specified in Rule 35-B of these rules has
been paid into a Government Treasury, or in any Branch of State Bank of India/Hyderabad
conducting the Treasury business to the credit of the head of account is specified therein :Provided
that any such application may be entertained after the said period of two months/ninety days
specified in Rule 35-A, if the applicant satisfies the Director/State Government that he had sufficient
cause for not making the application within the specified time.](2)Where the fee under sub-rule (1)
has been deposited, but no application for appeal/revision has been made, the fee shall be refunded
to the person concerned or an application made by him in this behalf to the Director/State
Government.(3)In every application made under sub-rule (1) the person to whom a quarry lease was
granted in respect of the same area or part thereof, shall be impleaded as a party.(4)Along with the
application under sub-rule (1) the applicant shall submit as many copies as there are parties
impleaded under sub-rule (3).(5)On receipt of the application the Director/State Government shall
send a copy of the application to each of the parties impleaded under sub-rule (3) specifying a date
on or before which he may make his representation if any against the appeal/revision application
filed under sub-rule (1).]
36. Particulars of quarry leases.
- The Assistant Director shall furnish by the fifth of every month in Form 'D' the full particulars of all
the quarry leases granted in the preceding month indicating the situation, survey number andAndhra Pradesh Minor Mineral Concession Rules, 1966

extent, the mineral and the period for which it was granted, with names and addresses of lessees to
the Director of Mines and Geology and shall thereafter provide, from time to time, as and when
arising, the particulars of quarry leases terminated, relinquished or expired. He shall also furnish to
the Director, the particulars as to the mineral receipts in respect of all quarries granted under these
rules every half year in Form 'E'.
37. Saving.
- Nothing in these rules shall apply to search for minerals at the surface not involving any
substantial disturbance of the soil.
I and II under Rule 10.
[Schedule-I] [Schedules I and II Substituted by G.O.Ms.No. 198, I & C. (M-I) Department, date
13-8-2009.]Rates of Seigniorage Fee
Sl. No Name of the MinorMineral UnitRate of Seigniorage
Fee(in Rupees)
1 2 3 4
1 Building Stone M3/MTRs. 50/33 (Rupees
Fifty /Thirty Three)
2 Rough Stone/Boulders M3/MTRs. 50/33 (Rupees
Fifty / Thirty Three)
3 Road Metal & Ballast M3/MTRs. 50/33 (Rupees
Fifty / Thirty Three)
3(a)Dimensional Stone used for
Kerbs & CubesMTRs. 88/- (Rupees
Eighty Eight)
4 Limekankar/Limestone MTThe rate of Royalty as
applicable to
limestone(other than
L.D. Grade) in respect
of Major Mineral as
per the 2nd Schedule
of the Mines
andMinerals (D&R)
Act, 1957
5 Lime Shell MTRs. 88/- (Rupees
Eighty Eight)
6 Marble M3/MTRs. 165/66 (Rupees
One hundred and
SixtyFive/Sixty Six)
7 Mosaic Chips MTAndhra Pradesh Minor Mineral Concession Rules, 1966

Rs. 44/- (Rupees
Forty Four)
8Muram/Gravel & Ordinary
earthM3/MTRs. 22/14 (Rupees
Twenty Two/
Fourteen)
9Ordinary sand/Sand
manufactured from
Bouldersuseful for Civil
constructionM3Rs. 40/- (Rupees
Forty)
10 Shingle M3Rs. 17/- (Rupees
Seventeen)
11 Chalcedony Pebbles MTRs. 33/- ( Rupees
Thirty Three)
12 Fullers Earth/Bentonite MTRs. 110/- (Rupees
One hundred and
Ten) andRs.
44/(Rupees Forty
Four)
13 Shale/Slate MTRs. 110/- (Rupees
Hundred and Ten)
14 Rehmati MTRs. 17/- (Rupees
Seventeen )
15 Limestone slabs   
(a)(i) Colour -Rs. 7 (Rupees Seven)
per Sq. Mt. or
Rs.88/-(Rupees
Eighty Eight) per MT
whichever is higher
(ii) White -Rs. 5/- (Rupees Five)
per Sq. Mt. or Rs.
55/-(Rupees Fifty
Five)per MT.
whichever is higher
(b) Black -Rs. 4/- (Rupees Four)
per Sq. Mt. or Rs.
44/-(Rupees Forty
Four) per Mt.
whichever is higher
16 Ordinary clay, Silt and Brick
Earth used inmanufacture
of Bricks including
Mangalore tiles- Rs. 3850/- (Rupees
three the thousand
eighthundred and
fifty only) per kiln perAndhra Pradesh Minor Mineral Concession Rules, 1966

annum for Bricks and
Tiles
17.
Granite
Usefulfor
Cutting(Rate
in Cubic
Meter)
 ItemSuper Gang
Saw above
300 Cm. X
180Cm. SizeMini Gang Saw above
270Cm X 150 Cm. &
lessthan 300 Cm. X
180 Cm. SizeBelow 270
Cm. X 150
Cm. SizeBelow 75
Cm. Size
(a) Black GraniteRs. 3,300/-
(RupeesRs. 2,625/- (RupeesRs. 2,475/-
(RupeesRs. 1100/-
(Rupees
 Galaxy Varietythree
thousand
three
hundred
onlytwo thousand six
hundred and twenty
five only)two
thousand
four
hundred
and seventy
five onlyone
thousand
one
hundred
only)
(b)Black Granite other than
Galaxy VarietyRs. 2,475/-
(Rupees two
thousand
for hundred
andseventy
five only)Rs. 2,000/- (Rupees
two thousand only)Rs. 1,925/-
Rupees one
thousand
nine
hundred
andtwenty
five onlyRs. 825/-
(Rupees
Eight
hundred
and
twenty
fiveonly)
(c)Colour Granite of
Srikakulam Blue,Indian
Aurora of Nizamabad
District, Leptinites of
Coastal Dists., Black Pearlof
Pearl of Prakasam & Guntur
Dist.Rs. 2,475/-
(Rupees two
thousand
four
hundred
andseventy
five only)Rs. 2,000/- (Rupees
two thousand only)Rs. 1,925/-
(Rupees one
thousand
Nine
hundred
andtwenty
five only)Rs. 825/-
(Rupees
Eight
hundred
and
twenty
fiveonly)
(d)Colour Granite of other
VarietiesRs. 1,925/-
(Rupees
One
thousand
nine
hundred
andtwenty
five only)Rs. 1,625/- (Rupees
One thousand Six
hundred andtwenty
five only)Rs. 1,650/-
(Rupees
One
thousand
six hundred
andfifty
only)."Rs. 825/-
(Rupees
eight
hundred
and
twenty
fiveonly)Andhra Pradesh Minor Mineral Concession Rules, 1966

[Schedule-II] [Schedules I and II Substituted by G.O.Ms.No. 198, I & C. (M-I) Department, date
13-8-2009.]Rate of Deed Rent(Per Hectare Per Annum)
Sl.No. Name of the Minor MineralRate of Dead Rent
per hectare per
Annum
01 Black GraniteRs. 55,000/-
(Rupees fifty five
thousand only)
02 Colour GraniteRs. 44,000/-
(Rupees forty four
thousand only)
03Limestone other than classified as MajorMinerals used for Limeburning
for building constructionpurposes, Marble, Boulders,Building Stone
Including Stone usedfor Road Metal, BallastConcrete and other
Construction purposes,Shale, Slate andPhyllites, Mosaic Chips,
Fuller'sEarth/Bentonite & DimensionalStones used for cubes &kerbs.Rs. 27,500/-
(Rupees twenty
seven thousand
andfive hundred
only)
04Gravel, Morrum, Shingle, Limestone Slabs usedfor Flooringpurposes
Limekankar, Chalcedony pebbles used in thebuildingpurposes Limeshell
for burning used for buildingpurposesand Rehmatti.Rs. l6,500/-
(Rupees sixteen
thousand and
fivehundred only)
3. This order issues with the concurrence of Finance Department vide their
U.O.No.19878/363/Exp. I&C/2009, dated 1-8-2009.
[Schedule-III] [Inserted by G.O.Ms.No. 104,I & C (M.I) Department., dated. 15-5-2009.]Those who
possess stone cutting polishing industries, the computation of Seigniorage Fee in respect of raw
material consumed in their industries is as per the following:
Sl.
No. Item Slab rate in lieu of Seigniorage
Feepayable for raw material
Procured.Ceiling limit
a)Block cutter with single
bladeinvolved in cutting
Granite Blocksof above
75 cm x 35 cm x 35 cm
sizeRs. 14000/- per month per blade)I) 16 Cu.M per month of raw
granite blocks fromthe Query
per each slice cutting machine
per blade.
   II) 400 Sq. M of slabs per each
slice cuttingmachine per blade.
   III) In case, the ceiling limit
exceeds inrespect of raw
blocks, Seigniorage Fee is
payable as per Item 17of the
Schedule I.Andhra Pradesh Minor Mineral Concession Rules, 1966

   In respect of Granite Slabs
exceeding ceilinglimit
Seigniorage fee is payable by
computing @ Rs. 50/- per
Sq.Mtaking average yield per
each Cu.M as 40 Sq.M.
b)Tile cutting machine to
cut 2 ft x ft sizeblocks
[75 cm x 35 cm x 35 cm]Rs. 2500/- per each slice
cuttingmachine per blade per monthI) 60 blocks per month of 75
cm x 35 cmper each slice
cutting machine per blade.
   II) 180 Sq. M of tile per each
slice cuttingmachine per blade.
(1) (2) (3) (4)
  III) In case, the ceiling limit exceeds
inrespect of raw blocks, Seigniorage
Fee is payable @ Rs. 40/- pereach
block of 75 cm X 35cm X 35 cm.
  IV) In respect ofGranite tiles
exceeding ceiling limit of 180Sq.M
per month, the Seigniorage fee is
payable by computing @ Rs.15/- per
Sq.M. taking average yield per Cu.M
block as 3 sq.mts.
c)Limestone slabs covered
underSl.No. 15 of
theminor mineral
schedule IRs. 1000/- per each polishing
machineper monthin case of black
Limestone slaband Rs. 1300/- per
machine incaseof white & other
colours of Limestone Slab.400 sq. meters per month of
raw slabs and ifexceeds shall
pay Seigniorage fee as per the
schedule prescribedunder
Andhra Pradesh Minor
Mineral Concession Rules,
1966.
    
[Form-A-1] [Form AI & Annexure Substituted by G.O.Ms.No. 50, I & C (M. I) Deptt., date 17-3-
1997.][See Rule 10-B]Notice is hereby given inviting Sealed Tenders and for public auction for the
right of collection of seigniorage fee for the minerals and sectors specified below in District.Notice is
hereby given inviting sealed tenders and for public auction for the right of collection of seigniorage
fee in respect of Minor Minerals quarried and transported by the different lessees for the leases
situated in the sector for a period of one year. The name of the Sector is given in the Schedule below:
-The Sealed Tenders shall be received till 5.00 p.m. on ................. in the office of the Assistant
Director of Mines & Geology ...................... and the Auctions shall be conducted by
.................................. at ................... on the day mentioned in the schedule at ................................
a.m. subject to the provisions of Andhra Pradesh Minor Mineral Concession Rules, 1966. The receipt
of applications for issue of Hall Tickets to participate in the Public auction shall be closed at 5.00
p.m. on ................. by ........................Andhra Pradesh Minor Mineral Concession Rules, 1966

Schedule 2
Sl. No. Name of the sector Name of the Minor Minerals Minimum Bid Date of Auction
1 2 3 4 5
     
Signature of the Auctioning AuthorityNote: - The annexure containing the conditions, application
proformas the details of leases in different sections etc., can be had from the Assistant Director of
Mines and Geology .............AnnexureConditions of Auction : - (1) No person shall be permitted in
the Auction Hall without the Hall Ticket in the prescribed form issued by the Assistant Director. The
Hall Ticket holder may be assisted by not more than two assistants during Auctions to participate in
the Auction.(2)The Hall Ticket shall be issued by the Assistant Director on submission of the filled
in application in the prescribed form and the following documents.(a)A notarised Affidavit in the
prescribed form on Non-Judicial Stamp paper worth Rs. 25/-.(b)Bank Draft/Banker's Cheque
obtained from any Scheduled Bank for an amount equivalent to 10% of the minimum bid in favour
of ..........................(c)A mineral Revenue clearance certificate in Form H or an affidavit in lieu
thereof in case the applicant does not have any mining lease, prospecting licence or quarry leases in
the State.(d)Receipt of application for issue of Hall Ticket, shall be closed three days before the
commencement of the auction.(3)(a)Sealed Tender shall be accepted for each sector separately in
separate covers.(b)Every sealed tender will be separately accompanied with filled in prescribed form
(application for Hall Ticket) along with the enclosures as required under item (2) above.(c)Soon
after the receipt of sealed tenders from tenderers the necessary entry should be made in the Register
by the officer concerned while issuing acknowledgment to the tenderers. Such Sealed Tender shall
be kept under the safe custody of the Assistant Director. He has to ensure that all such sealed
tenders and the Registers are kept safe under his personal custody duly observing all possible safety
measures.(d)Every tenderer shall be issued a Hall Ticket to participate in the auction without
insisting any further payments as required under item (2) mentioned above by the officer
concerned.(4)No person shall bid for any person unless he holds a power of attorney and presents
an application signed by such person.(5)On the oral promise of the auctioning authority the
Tenderer/Bidder shall have no claim to any right.(6)The following persons shall not be entitled to
participate in the auction.(a)persons aged below eighteen years.(b)persons who have been debarred
from obtaining quarry leases and mining leases.(7)If the Assistant Director notices that any person
in the auction hall before or at the time of bidding behaves or acts in such a manner as to cause loss
to Government or induces or forbids any person from bidding, he may suspend him from
participating in the auction and remove him from the Auction Hall.(8)The Sealed Tender shall be
opened after the bidding is over in each sector. It is the responsibility of the persons who submitted
the sealed tenders to make themselves present at the time of opening of the sealed tenders. Sealed
tenders shall be opened by the Assistant Director irrespective of the presence of Tenderers.(9)No
person will be admitted into auction Hall without the Hall ticket issued by the Assistant Director.
The right of collection of signorinarage fee will be ordinarily knocked down to the Highest
Tenderer/Bidder but the right is reserved to the officer conducting the proceedings or by the
Director or by the Government as the case may be to reject any tender/bid where there is a reason to
believe to do so. The right of collection of seigniorage fee shall be strictly subject to the confirmation
by the competent authority who has the right to refuse the right of collection of seigniorage fee withAndhra Pradesh Minor Mineral Concession Rules, 1966

reasons recorded.(10)The Assistant Director may at his own discretion reject any persons
Tender/bid who,(a)has been convicted for any penal offence or any offences under the Mines and
Minerals (Regulation and Development) Act, 1957, or(b)He is debtor to the Government of Andhra
Pradesh in the Mines and Geology Department.(11)It shall be at the discretion of the officer
concerned to accept or reject the tender or bid after recording the reasons thereof.(a)A tender once
submitted shall not be withdrawn before the bid is concluded.(b)The Officer concerned shall
announce at the commencement of the bidding the names of the persons who have submitted
tenders and hall ticket holders for the particular sector.(12)The proceedings for the disposal of the
sector shall be concluded on tender or bid as the case may be by the Assistant Director. The hike in
bidding in the auction Hall by the bidders shall not exceed 25% of the minimum bid each time. The
tenders of the sector shall be opened only when it is ensured by the Assistant Director that there is
no further bidding. He shall knock down the highest tender/bid provided he is satisfied with the
procedure. In case the highest bid amount and one or more tendered amounts remaining the same,
the knocking down for the sector shall be decided by drawing lots immediately. However, the
Assistant Director shall have the power to reject the highest tender/bid on reasons to be recorded
therefor and accept any other next lower tender/bid, subject to approval of the Joint Director
concerned.(13)The Assistant Director shall maintain a register by duly mentioning all the particulars
of the participants who have submitted sealed tenders and the hall ticket holders. The persons
whose tender/bid is knocked down shall sign and mention his name in block letters by duly affixing
his signature/thumb impression in the Register.(14)(a)The successful tenderer/bidder shall pay the
knocked down amount in four quarterly instalments. The amount equivalent to 25% of knocked
down amount towards as first instalment shall be deposited in the Government Treasury within the
immediate next two working days.(b)The confirmation orders will be issued by the Deputy Director
concerned on making the deposit of 25% of knocked down amount as required under sub-rule (1) of
Rule 10-E. The first successful tenderer/bidder on receipt of order of confirmation shall furnish
security deposit of 2% of knocked down amount subject to the minimum of Rs. 1000/- and
maximum of Rs. 25,000/- in the manner as prescribed in the confirmation order and execute
agreement in Form 'M' with the Assistant Director within the time prescribed in the confirmation
order on stamped paper as per the Registration and Stamps Act by duly furnishing three bank
guarantees in favour of the Assistant Director concerned for an amount equivalent to 75% of the
knocked down amount under each guarantee which are valid for six, nine and twelve months against
the respective quarterly instalments payments. The respective Bank Guarantees shall be released by
the Assistant Director on payment of quarterly instalments. The security deposit shall be released by
the Assistant Director soon after the expire of lease period provided the Authorised Agent fulfilled
all the lease deed conditions and other provisions of the Andhra Pradesh Minor Mineral Concession
Rules, 1966.(c)In the event of default by the Ist successful Tenderer/bidder for payment of 25% of
the knocked down amounts required under sub-rule (1) or completion of formalities for executing
the agreement as required under sub-rule (2) of Rule 10-E, the competent authority may issue
conformation orders in favour of the second and the third highest tenderer/bidder in the descending
order with due stipulations of the time limits for payment of 25% of the amount offered by the
respective tenderer/bidder and discharging the other formalities for making agreement as required
under sub-rule (2) of Rule 10-E. However, in case the second and third highest tenders/bidders also
become defaulters, the other tenders/bidders who offered and participate over an above the
minimum bid and who retained the deposit of 10% of the minimum bid with the auctioningAndhra Pradesh Minor Mineral Concession Rules, 1966

authority after the auctions may be considered for issue of confirmation orders in the descending
order by the competent Authority by duly stipulating the time limits for payment of 25% of the
offered amount by the respective tenderer/bidder and discharging the other formalities for making
agreement as required under sub-rule 2 of Rule 10-E.(d)The successful tenderer/bidder on
executing the agreement in Form H shall pay the subsequent quarterly instalment atleast fifteen
days before the end of the precedings quarter.(e)The Director may condone the delay in payment of
the amount, fulfilment of other formalities and making agreement under sub-rules (1) to (4) of Rule
10-E on valid grounds.(f)If the successful tenderer/bidder fails to pay 25% of the knocked down
amount within two working days or fails to furnish the bank guarantee of 75% of knocked down
amount within the time specified in the confirmation order or fails to make agreement in Form 'M'
after completing all the formalities or fails to pay the quarterly instalments within the prescribed
time, the amounts so far paid by the successful tenderer/bidder by way of deposits and the amounts
under bank guarantee, shall be forfeited to the Government by the confirming authority. If the
second or the third highest tenderer/bidder fails to pay the amounts or complete the formalities as
stipulated in the confirmation order, the confirming authority shall forfeit the amounts so far paid
by way of deposits or otherwise including the bank guarantee to the Government. If the fourth or
any subsequent bidder who has been issued confirmation order and made agreement in form - 'M'
after completing the formalities fails to pay the second or any subsequent instalments in time the
confirmation authorities shall forfeit the security deposits and the bank guarantee to the
Government. Any forfeiture shall be done by the confirming authority after giving an
opportunity.(g)The deposits of second and the third highest tenderer/bidder shall be returned after
the agreement is made in Form-M in case they are not found to be defaulters for the payment of
1/4th amount as required under sub-rule (1) and the completion of the formalities under sub-rule
(2) of others shall be returned after three days of auction held on a written request by the
participants for the same and the deposits of those who like to avail the opportunity of getting the
lease in case the first, second and third highest tenderer/bidder become defaulters will be retained
with the officer concerned and returned after the agreement is made.(15)The successful
tenderer/bidder shall have no claim for compensation or extension of lease period for the delay
caused by himself in paying the required amounts and executing the agreement. However, the
Government may exempt or waive the proportionate amount for the non performed period on valid
reasons.(16)The tenderer/bidder shall not be entitled to make use the privilege acquired before the
agreement and take out the right of collection of seigniorage fee. It shall be the responsibility of the
tenderer/bidder to execute the agreement within the stipulated period as well as take out the right of
collection of seigniorage fee. If the tenderer/bidder fails to comply with the above formalities or take
out the sector and for that reasons if the privilege acquired could not be functioned he shall not be
absolved from the responsibility to pay the knocked down amount.(17)If the successful
tenderer/bidder dies after the privilege is knocked down to him, his legal heirs shall have right and
be responsible to execute the agreement and to carry out the business by remitting the dues to the
Government. If the heirs do not want to continue the privilege, they should within fifteen days from
the date of death of the tenderer/bidder intimate the Assistant Director their intention in writing by
registered post. The amounts deposited by the deceased tenderer/bidder shall be refunded to the
legal heirs.(18)The right of collection of seigniorage fee obtained through sealed tender cum auction
is not liable for transfer.(19)The tenderer/bidder after executing the agreement in Form-M
prescribed in Rule 10-E(2) will be at liberty to collect the seigniorage fee from the quarry leaseAndhra Pradesh Minor Mineral Concession Rules, 1966

holders including temporary permit holders except the persons/organisations who obtained quarry
leases with exemption from payment of seigniorage fee in respect of Minor Minerals specified in the
notification at the relevant rates mentioned in Schedule I to Rule 10(1) and the relevant rates
mentioned in Rule 12(5)(e) at or before the time of despatch of the Minor Minerals from the leased
areas. He shall have no right to collect the seigniorage fee from any persons/companies who are not
the quarry lease holders. The Authorised Agent shall also be entitled to collect the seigniorage fee
from all the new leases granted and executed for the specified Minor Minerals during the currency
of the Agreement period. He, however, does not have any right for any type of compensation arising
out of non-working of the quarries, and due to expiry, lapse, determination cancellation etc., of the
leases.(20)The Additional amount of seigniorage fee over and above the rates in force as on the day
of notification of the auction notice due to revision of rates of seigniorage fee made from time to
time shall be paid by the lessee directly to the Government and the authorised agent shall not have
any claim for such payment.(21)The Director shall have the power to cancel at any time the sealed
tender-cum- public auction conducted under Rule 10-A(2) and the confirmation issued by the
Deputy Director concerned under Rule 10-D, if the Director feels that the publicity, participation
and the amounts knocked down are not satisfactory and also due to any other lapses.(22)Every
tenderer/bidder shall be bound to observe the laws, rules, and regulations, instructions of the Mines
and Geology Department and the Government that might be enforced during the currency of the
leases of the privilege.(23)In case of any doubt as to be application of interpretation of the version of
any of these condition the decision of the Government on the issue shall be final.(24)The leases for
the specified Minor Minerals Sector wise are given as detailes below :.................... Sector
Sl.
No.Name of
the MandalName and
address of the
lesseeLocation &
extentName of the
specified
mineralLease
periodDate of seigniorage
fee as per scheduleRemarks
1 2 3 4 5 6 7 8
        
[Affidavit] [Substituted by G.O.Ms.No. 50, I & C (M. I) Deptt., date 17-3-1997.][Under conditions 2
of Annexure to Form A1 under Rule 10-B]I ........................... S/o. .............................., R/o.
......................... aged about ........... years do hereby solemnly affirm and state as follows.That I have
gone through the Sealed Tender-cum-Public Auction notice issued by .................................... and
conditions laid down therein. I intend to obtain the right of collection of seigniorage fee through
Sealed Tender-cum-Public Auction for the sector ...................... in ...................... District.If I am the
successful Tenderer/Bidder and if it is knocked down in my favour, I declare and agree to abide :
1. To pay the knocked down amount in four equal quarterly instalments.
2. To pay the sum equivalent to 25% of the knocked down amount within the
immediate next two working days and to tender the same before the
auctioning authority.Andhra Pradesh Minor Mineral Concession Rules, 1966

3. To furnish bank guarantee from any Scheduled Bank for the balance 75%
of the knocked down amount and pay the security deposit of 2% of the
knocked down amount subject to the minimum of Rs. 1000/- and maximum of
Rs. 25,000/- and to execute the agreement with Assistant Director of Mines
and Geology concerned in Form M on or before the date mentioned in
confirmation orders. To pay the balance 75% of knocked down amount in
three quarterly instalments each by atleast 15 days before the end of the
preceedings quarter.
4. In case of negligence of my part to execute the lease deed in time and to
pay the quarterly instalments as per Schedule, I accept for any action taken
by concerned authority to cancel the Sealed Tender-cum-Public Auction or
terminate the agreement as the case may be and to forfeit all sums paid
along with the amount guarantee by the bank.
5. To abide by the additional conditions if any imposed by the authority
competent to do so and
6. To abide by the decision of the Government of Andhra Pradesh in case of
any doubt as to the application or interpretation of the versions of any of the
conditions or provisions of Mines Act and the Rules made thereunder.
7. I declare that I hold/do not hold any licence or lease under any of the
Mineral Concession Rules not in debt to the Department of Mines and
Geology.
8. I declare to abide by the provisions of the Andhra Pradesh Minor Mineral
Concession Rules, 1966.
Sworn and signed before me on .......... this ......... date of ..... 199
...NotaryDeponentAttestedApplications For Issue of Hall Ticket(Under Condition 2 of Annexure to
Form 'A-I' under Rule 10-B)
1. Name and present address of the applicant (in block letters) :
2. Name and permanent address of the applicant (in block letters) :
Note: - In case of partnership firm the partnership bond should be produced for participating in the
auction.Andhra Pradesh Minor Mineral Concession Rules, 1966

3. Age of the Applicant (persons of 18 years below not eligible) :
4. [Sector/Sectors] [Substituted for the words 'area/areas' by G.O.Ms.No. 50, I
& C (MI) Department, date 17-3- 1997.] for which he intends to participate in
the auctions :
5. Affidavit in the prescribed Form on a Nonjudicial stamped paper worth [Rs.
25/-] [Substituted for the words 'Rs. 15/-' by G.O.Ms.No. 50, I & C (MI)
Department, date 17-3- 1997.] enclosed or not:
6. No. and date of Bank Draft/Banker's Cheque obtained from any Scheduled
Bank for an amount equivalent to 10% of the minimum bid :
7. Particulars of leases if any held under different mineral Concessions :
8. Mineral Revenue Dues Clearance Certificate in Form 'H' enclosed or not :
Income-Tax Clearance Certificate enclosed or not:
9.
(a)Has he been convicted for any penal offence or any offence under MM (R&D) Act, 1957 :(b)Has
he been debarred earlier in participating auctions or to obtain leases under different Mineral
Concessions :
10. Whether agreed to pay a sum equivalent to 25% of the [knocked down
amount] [Substituted for the words 'knocked down bid' by G.O.Ms.No. 50, I &
C (M I), dated 17-3-1997.] along with next two working days from the day of
auctions and to furnish Bank Guarantee valid for one year for the remaining
75% of the amount within the prescribed time in the confirmation order.
11. [ Sealed Tender enclosed or not] [Item No. 11 added by Ibid.]
I stated that the particulars furnished above are true to the best of my knowledge. I hereby
undertake that the deposit made by me may be forfeited to the Government if the information
furnished above is proved to be incorrect.Place :Date :Signature of the ApplicantHall Ticket(Under
Condition 2 to the Annexure to Form A-1 under Rule 10-B)Serial No :Date :Office of the Assistant
Director of Mines & GeologySri ........................... S/o. .......................... is hereby permitted in the
auction/auctions for rights of collection of seigniorage fee on .................. minerals in the Sector
............. Mandal ................. District .................... Specimen Signature of the Hall Ticket
Holder.Signature of the Issuing Authority.[Form-AIII] [Substituted by G.O.Ms.No. 50, I & C (M I),Andhra Pradesh Minor Mineral Concession Rules, 1966

dated 17-3-1997.]Tender Form[See Rule 10-C]
1. Name in Block Letters :
2. Father's Name :
3. Present Address :
4. Permanent Address :
5. Occupation :
6. Details of Sector and Minerals specified as per notification :
7. Offered Amount
(a)In figures(b)In wordsI hereby declare that I am aware of the particulars furnished in regard to
the right of collection of seigniorage fee for the minerals specified in the sector as per the auction
notification in response to which I am submitting the Tender. I further declare that I am also fully
aware of all the rules in regard to the right of collection of seigniorage fee.I hereby undertake to
abide by the provisions of the A.P. Minor Minerals Concession Rules, 1966.Signature(Name in Block
Letters)Note: - 1. This tender is to be submitted in a sealed cover in person or by Registered Post
acknowledgement due through his power of Attorney holder and acknowledgement obtained.
2. Application with the enclosures as required under condition (2) under
Annexure to Form A ; should accompany the sealed cover.
3. The competent authority shall not be responsible for the loss in the postal
transit or the delay in receipt of the sealed covers.
Form BApplication Form[See Rule 9]To[The Deputy Director,] [G.O.Ms.No. 161, I & C, date
24-3-1980.]...................................Dear Sir,I/We hereby beg to apply for a quarry lease for a period of
...................... years and give below the necessary particulars as required under the Andhra Pradesh
Minor Mineral Concession Rules, 1966.(1)Name of
applicant.(a)Profession.(b)Residence.(c)Permanent address.(2)Description of the area applied or
:(a)Situation and boundaries.(b)Revenue Survey Nos. or Block No. (in case of Reserve
Forest).(c)Area.(3)Name of mineral to be quarried.(4)Purpose for which it is to be
used.(5)Enclosures.(i)A copy of the village map which is not in less scale than the village map
showing the area applied for.(ii)A mineral dues clearance certificate prescribed in Form 'H'. In case
the applicant does not hold any licence for lease under any of the Mineral Concession Rules, he shall
submit a declaration to this effect in the form of an affidavit.I/We declare that above particulars are
correct and request that a quarry lease may kindly be granted.Place :Date :YoursAndhra Pradesh Minor Mineral Concession Rules, 1966

faithfully,Form-B-I[***] [Omitted by G.O.Ms.No. 227, I&C (M-1), Department, date
23-3-2000.]Form CQuarterly Return for Lessee[See Rule 28(3)]For quarter ending
.............................(1)Location of the Quarry :(i)Land Survey Nos. :(ii)Village :(iii)Taluq :(iv)District
:(2)Name of Lessee :(3)Name of mineral quarried :(4)Quantity of mineral :(i)Excavated
:(ii)Exported by Rail :(iii)Sold locally :(5)Average price of mineral :(i)At the quarry site :(ii)At the
railway station :(6)Average number of persons employed :(i)At the quarry site :Males : Females
:(ii)At the railway station :Males : Females :(7)Number of accidents :(i)Serious :(ii)Fatal :Place :Date
:Signature Designation[Form-C-I] [Inserted by G.O.Ms.No. 50, I & C (M-I), date
17-3-1997.]Monthly Return to be submitted by the Authorised Agent[Sub-Rule (iv) of Rule 10-I]
S.No.Name and
Address of the
lesseeLocation
extent of the
leaseName of the
MineralQuantity for
which permit
issuedAmount paid
towards permitted
quantityRemarks
1 2 3 4 5 6 7
 
Form-DRegister of Quarry Lease and Periodical Returns for Assistant Director[See Rules 34/38]
S.No.Name
applicantApplicant's
addressSituation and
boundaries of
the land
appliedforArea of the
said landName of the
mineral for
which the
quarry leaseis
grantedDate of
grant ot
the lease
1 2 3 4 5 6 7
 
Period for
which the
lease is
granted
orrenewedAmount of
quarrying
feeAmount of
seigniorage
feeAmount of
security
depositParticulars of
refund of
security
depositDate of transfer
of the lease if
any and
thename of the
transfereeRemarks
8 9 10 11 12 13 14
 
Form-EForm of Demand, Collection and Balance Statement in respect of Quarry Leases (Minor
Minerals)[See Rule 38]Quarrying FeeSeigniorage Fee
Serial
numberName of
the
villageSurvey
numberArea of the
land where
the
mineral is
workedDescription
of the
mineral
workedName of the lessee
or the patta land
agreementholderBalance
at the end
of the last
half yearTotal
demand
1 2 3 4 5 6 7 8
 
Amount
collected
during theBalance Balance at
the end of
last halfDemandfor
the half
yearTotal
demandAmount
collecteduring the
half yearBalance RemarksAndhra Pradesh Minor Mineral Concession Rules, 1966

half year year
9 10 11 12 13 14 15 16
 
Form-FForm of Report[See Rule 30]
1. Name and situation of the quarry.
2. Name of mineral worked.
3. Name and postal address of Owner.
4. Name and postal address of Manager.
5. Depth of the quarry measured from its highest to its lowest point.
6. Number of persons employed in the quarry.
7. Whether explosives are used in the quarry.
8. The general condition of the mines as to safety working
9. Whether underground workings have been made or are likely to be made.
10. The date on which the mine was opened (for new mines only.)
Place :Date :Signature of the OwnerAgent/Manager.Form-G[See Rule 8]Form of lease (minor
minerals) to private persons
This indenture made the ............ day of 19 ............ between the Governor of
Andhra Pradesh (hereinafter called the "Lessor" which expression shall where
the context so admits, include his successors in office and assigns) of the one
part, and ...... (hereinafter called the "Lessee" which expression shall, where
the context so admits, include his heirs, executors, administrators,
representatives and assigns) of the other part. Latestpassport
sizephoto of
thegrantee 
[Whereas the lessee has been granted quarry lease by the Government of Andhra Pradesh on
application in [Sealed Tender-cum-Public Auction] [Substituted by G.O.Ms.No. 3, I & C., date
3-1-1991 (vide App. III).] of the lands in the ..... District for the purpose of quarrying for ...... and has
deposited with the Assistant Director of Mines and Geology of ..... the sum of the grantee of Rs. ......
as security for the due and faithful performance by the lessee of the covenants and conditions on the
part of the lessee hereinafter contained :]And whereas the Government of Andhra Pradesh acting for
and on behalf of the lands and premises hereinafter described and demised for the term and at theAndhra Pradesh Minor Mineral Concession Rules, 1966

[knocked down amount] [Substituted for the words 'bid amount' by G.O.Ms.No. 3, I & C., date
3-1-1991 (vide App. III).] dead rent and seigniorage fee, and subject also to the covenants conditions
and conditions hereinafter contained now this indenture witnesses as follows: -The lessor hereby
demises to the lessee all those several pieces or pieces of land situated in the village of ........ in the
sub-registration district of ......... and registration district of ........ in Andhra Pradesh being more
particularly described in the schedule hereunder written and delineated in the map or plan hereunto
annexed and therein coloured.
2. These are included in the said demise and for the purposes thereof
following liberties: -
(1)To get from the said demised pieces of land.(2)For the purpose aforesaid to use any water in or
under the said demised pieces of land and to divert the same and to make or construct any water
courses or ponds so however that nothing shall be done in the exercise of this authority which shall
interfere with the rights of any adjoining owners of the tenants or the lessors in respect of such
water.(3)Generally to do all things which shall be convenient or necessary for getting the ......... and
material hereby authorised to be got and for removing and disposing thereof as aforesaid.
3. These are excepted and reserved to the lessor out of this demise:-
(1)All earth minerals and other substances not hereinbefore expressly authorised to be got from the
demised pieces of land by the lessee.(2)Liberty for the lessor or other persons authorised by him to
search for work, get, carry away and dispose of the excepted minerals and other substances and for
such purposes to have the right of ingress, egress and regress over the said demised pieces of land
and to make erect and use all pits, machinery, buildings, roads and other necessary works and
conveniences provided that the rights hereby reserved shall be exercised in such a way as to cause as
little obstruction as possible to the lessee in the use and enjoyment of its rights hereunder and that
reasonable compensation for damages caused by any such obstruction shall be paid to the lessee the
amount thereof in case of difference to be settled by arbitration as hereinafter provided.
4. The said demised pieces of land shall be held by the lessee for the term of
...... years from the ....... day ....... 19 ..... to the ......... day of ......... 19 ..........
determinable as hereinafter provided.
5. The lessee hereby agrees to pay during the said term the following [***]
[Omitted by G.O.Ms.No. 3, I & C., date 3-1-1991.] dead rent and seigniorage
fee whichever is higher and also all cesses which may, from time to time, be
imposed by the Government:-
(1)The yearly [***] [Omitted by G.O.Ms.No. 3, I & C., date 3-1-1991.] dead rent of Rs. ....... in respect
of the said demised pieces of land.(2)A seigniorage fee of Rs. ...... in respect of the said demised
pieces of land.Andhra Pradesh Minor Mineral Concession Rules, 1966

6. The lessor may, during the currency of the lease, vary the rate of [*]
[Omitted by G.O.Ms.No. 3, I & C., date 3-1-1991.] dead rent and the
seigniorage [*] [Omitted by G.O.Ms.No. 357, I & C, date 5-9-1994.].
7. It is hereby agreed and declared that in regard to the said [knock down
amount] [Substituted by G.O.Ms.No. 46, I & C, date 6-2-1996.] dead rent and
seigniorage fee the following conditions shall be observed by the lessee.
(i)The said dead rent of Rs. ........ shall be paid without any deduction on the ........ day of ..... 19 ......
in every year in advance.(ii)The said seigniorage fee of ....... per ...... shall be paid before the same is
removed from the said demised pieces of land.
8. The lessee hereby covenants with the lessor as follows ;
(1)To pay the [knock down amount] [Substituted by G.O.Ms.No. 46, I & C, date 6-2-1996.] dead rent
and seigniorage fee on the days and in manner aforesaid.(2)To bear, pay and discharge all existing
and future rates, taxes, assessments, duties, impositions, outgoings and burdens whatsoever
imposed or charged upon the demised pieces of land or the produce thereof or the bid amount, dead
rent and seigniorage fee hereby reserved or upon the owner or occupier in respect thereof or payable
by either in respect thereof except such charges or impositions as the lessee is or may hereinafter be
by law exempted from.(2A)[ Should any rent seignorage fee or other sums due to the State
Government under the terms and conditions of these presents be not paid by the lessee/lessees
within the prescribed time, the same may be recovered together with simple interest due there on at
the rate of twenty four per cent per annum on a certificate of such officer as may be specified by the
State Government by general or special order in the same manner as on arrear of land revenue.]
[Inserted by G.O.Ms.No. 50, I & C, (M I) Department, date 17-3-1997.](3)Before digging or opening
any part of the said demised pieces of land for ....... carefully to remove the surface soil to a depth of
at least ..... metres and lay aside and store the same in some convenient part of the said demised
pieces of land until the land from which it has been removed is again restored to a state fit for
cultivation as hereinafter provided.(4)To effectually fence off the said demised pieces of land from
the adjoining lands and to keep the fences in good repair and conditions.(5)Not to assign, underlet
or part with the possession of the demised land or any part thereof without the written consent of
the lessor first obtained. [A quarry lease granted by sealed tender-cum-public auction for sand is not
open for transfer.] [Inserted by G.O.Ms.No. 46, I & C, date 6-2-1996.](6)After working out any party
of the said demised pieces of land forthwith to level the same and replace the surface soil thereof
and slope the edges, where necessary, so as to afford convenient connection with the adjoining
land.(7)That the lessee shall keep correct accounts, in such form as the Assistant Director of Mines
and Geology concerned shall, from time to time, require and direct showing the quantities and other
particulars of the said mineral obtained by the lessee from the said lands and also the number of
persons employed in carrying on the said quarrying operations therein and shall, from time to time,
when so directed by the Assistant Director of Mines and Geology concerned prepare and maintain
complete and correct plans of all quarries and workings in the said lands and shall allow any officer
thereunto, authorised by the lessor from time to time and at any time, to examine such accounts andAndhra Pradesh Minor Mineral Concession Rules, 1966

any such plans and shall, when so required, supply and furnish to the lessor all such information
and returns regarding all or any of the matters aforesaid as the lessor shall, from time to time,
require and direct.(8)That if in the course of quarrying any mineral not specified in the lease is
discovered the lessee or registered holder shall at once report such discovery to the Assistant
Director of Mines and Geology concerned who shall obtain orders of the Government regarding the
working of the same.(9)That the lessor's agents, servants and workmen shall be at liberty at all
reasonable times during the said term, to inspect and examine the works carried on by the lessee
under the liberties hereinbefore granted and the lessee shall and will, from time to time, and at all
times during the said term hereby granted conform to observe all orders and regulations which the
lessor or his authorised agent as the result of such inspection may from time to time see fit to
impose to keep the lands in good and substantial repair, order and condition or in the interest of
public health and safety.(10)The lessee shall without delay send to the Assistant Director of Mines
and Geology a report of any accident involving the death or injury to any person which may occur in
or about the quarry and shall observe all rules for the time being in force regulating the working of
quarries.(11)That the lessee shall not without the express sanction in writing of the said Assistant
Director of Mines and Geology cut down or injure any timber or trees on the said lands but he may
clear away brushwood or undergrowth which interferes with any operations authorised by these
presents on payment of due compensation for cutting or injuring trees growth in the said lands to
the departments concerned.(12)That wherever necessary, pay to the person concerned,
compensation for any loss or damage which may be caused by the lessee to the surface of the
demised pieces of land or to anything growing or situated therein in exercise of the rights granted
and shall not commence operations until such compensation has been paid. The lessee shall further
always keep the lessor indemnified against any claim by any person for any loss or injury caused to
him or to his property by lessee. The Deputy Director shall be the competent authority to assess and
fix any compensation payable by the lessee for any loss or injury done to him or his
property.(13)That if required by the Assistant Director of Mines and Geology, erect and maintain at
his own expense, boundary pillars of subsistant material standing not less than three feet above the
surface of the ground at each corner or angle in the line of the boundary of the area leased to him
and at intervals of not more than three metres along the boundary, as delineated in the plan
attached to the lease deed.(14)If any mineral not specified in the lease deed or agreement is
discovered, the lessee or the registered holder shall not win or dispose of such mineral without
obtaining the permission of 1[the Director of Mines and Geology] and without payment of the
seigniorage fee and the acreage assessment. If lessee or the registered holder fails to intimate [the
Director of Mines and Geology] [Substituted for the words 'the Assistant Director of Mines &
Geology' by G.O.Ms.No. 227, I & C (M-1) Department, date 23-3-2000.] the discovery of such new
minerals and obtain his permission within a period of thirty days from the date of the working of the
mineral is begun, the Director of Mines and Geology or Deputy Director of Mines and Geology may
levy enhanced seigniorage fee and acreage assessment.(15)The lessee or the registered holder shall
strengthen and support to the satisfaction of any Railway Administration concerned or the State
Government as the case may be, any part of the quarry which in the opinion of the Railway
Administration or as the case may be, the State Government requires such strengthening or support
for the safety of any railway, reservoir, canal, road or any other public works or structures.(16)That
this lease may be terminated in respect of the whole or any part of the premises by six months notice
in writing on either side.(17)That on such determination the lessee shall have no right toAndhra Pradesh Minor Mineral Concession Rules, 1966

compensation of any kind.(18)That the [knock-down amount] [Substituted for the words 'bid
amount' by G.O.Ms.No. 46, I & C, date 6-2-1995.]/dead rent and seigniorage fee payable under these
presents shall be recoverable under the provisions of the Revenue Recovery Act, 1864
thereof.(19)That the determination of the tenancy to deliver up the demised land in such condition
as shall be in accordance with the provisions of these presents save that lessee shall if so required by
the lessor restore in manner provided by the foregoing covenant in that behalf the surface or any
part of the land which has been occupied by the lessee for the purpose of the works hereby
authorised and has not been so restored.(20)[ In respect of granite and marble, the lessee shall
comply with the provisions of Granite Conservation and Development Rules, 1999 and the Marble
Development and Conservation Rules, 2002, respectively.] [Substituted by G.O.Ms.No. 282, I&C
(MI) Department, date 23-9-2003.](21)[ (a) The lessee shall follow and effect the provisions of
Labour Laws pertaining to the employment, payment of wages and other welfare measures to the
Labour who are employed in quarries and mines. [Added by G.O.Ms.No. 117, I&C (MI) Department,
date 16-11-2011.](b)The lessee further shall take all precautionary measures in conducting mining
operations as per the relevant stipulations made under Mettalliferrous Mines Regulations, 1961.(c)If
the lessee violates the provisions as stipulated above and having confirmation from the Department
concerned necessary action shall be taken for cancellation of the lease, by giving an opportunity.]
9. The lessor hereby covenants with the lessee that on the lessee paying the
[knock down amount] [Substituted for the words 'bid amount' by G.O.Ms.No.
46, I & C, date 6-2-1995.] dead rent and seigniorage fee hereby reserved and
that on observing and performing the several covenants and stipulations
herein the lessee shall peaceably hold and enjoy the demised pieces of land
and the liberties and powers hereby demised and granted during the said
term without any interruption by the lessor or any person rightfully claiming
under or in trust for him.
(9A)[. Government reserves the right, - [Inserted by G.O.Ms.No. 425, I&C, date 21-12-1993 (w.e.f.
27-12-1993).](i)to cancel the quarry lease granted and executed under these rules after giving a
previous notice;(ii)to prohibit quarrying operations in part or the whole of the area under lease with
recorded reasons.]
10. It is hereby expressly agreed as follows:-
(1)If any part of the [knock-down amount] [Substituted for the words 'bid amount' by G.O.Ms.No.
46, I & C, date 6-2-1995.] dead rent and seigniorage fee hereby reserved shall be unpaid for thirty
days after becoming payable (whether formally demanded or if the lessee while the demised pieces
of land or any part thereof remain vested in him shall become insolvent or if any covenant on the
lessee's part herein contained shall not be performed or observed them and in any of the said case it
shall be lawful for the lessor at any time thereafter to declare to whole or any part of the said security
deposit of Rs. ....... to be forfeited and also to reenter upon the demised pieces of land or any part
thereof in the name of the whole and thereupon this demise shall absolutely determine but withoutAndhra Pradesh Minor Mineral Concession Rules, 1966

prejudice to the right of action of the lessor in respect of any reach or non-observance of the lessee's
covenants herein contained.(2)[The expiry or determination of the lease, the lessee shall be at
liberty to remove, carry and dispose of all the stocks of the mineral extracted and all engines,
machinery, articles and other things whatsoever (not being building or bricks or stones) within one
month or extended period granted by the Government after paying dead rent and seigniorage fee
and other sums which may be due and performing and observing the covenants on his part
hereinbefore reserved and contained and also making good any damages done by such removal but
not building which shall be erected on the said demised places of land by the lessee and left thereon
at the determination of the lease and shall be the absolute property of the lessor who shall not pay
any price for the same.] [Substituted by G.O.Ms.No. 357, I&C, date 5-9-1994 (w.e.f. 8-9-1994).](3)If
the lessee shall have paid the [knock-down amount] [Substituted for the words 'bid amount' by
G.O.Ms.No. 46, I&C, date 6-2-1996.] dead rent and seigniorage fee and duly observed and
performed the covenants and conditions on his part herein contained the said deposit of Rs. .......
shall be returned to him at the expiration of the said term of ...... years.(4)If any question of
difference or dispute shall arise between the parties hereto or any persons claiming under them
respectively concerning the [knock-down amount] [Substituted for the words 'bid amount' by
G.O.Ms.No. 46, I&C, date 6-2-1996.] dead rent and seigniorage fee hereby reserved or touching the
construction of any clause herein contained or the rights, duties or liabilities of the parties
hereunder or in any other way touching or arising out of these presents the same shall be referred to
the Director of Mines and Geology whose decision thereon shall be final and binding on the parties
thereto.In witness whereof...... Assistant Director of Mines and Geology of....... acting for and on
behalf of and by order and direction of the Government of Andhra Pradesh the lessee have hereto
set their hands the day and year first above writing.The Schedule
Name of
TalukName of
VillageSurvey
fieldExtent
Nos.AssessmentBoundaries North, South West
and East
1 2 3 4 5 6
      
Signed and delivered by the above name in the presence of............[Form-G1] [Form-G 1 Substituted
by G.O.Ms.No. 84 Ind. & Com. (MI) Department, date 10-4-2007. Old Form G-I please see
Annexure at page 1743.][See Rule 9-I(2)]Form of Sand Lease Agreement to Private Persons
This indenture made the .............. day of ................. between the
Government of Andhra Pradesh (hereinafter called the "Lessor" which
expression shall where the context so admits, include his successors in
office and assigns) of the part and ............. (hereinafter called the
"Lessee" which expression shall where the context so admits include his
heirs, executors, administrators, representatives and assigns) of the
other part. LatestPassportsizePhoto  
Whereas the lessee has been granted quarry lease by the Government of Andhra Pradesh on
application in sealed tender-cum-public auction of the lands in the ................. District for the
purpose of quarrying for Ordinary Sand and has deposits with ADM&G ....................the sum of Rs.
................. (Rupees .............. only) as security for the due and faithful performance by the lessee of
the covenants and conditions on the part of the lessee hereinafter contained.And whereas theAndhra Pradesh Minor Mineral Concession Rules, 1966

Government of Andhra Pradesh acting for and on behalf of the lands and premises hereinafter
described and demised for the terms and at the knocked down amount in sealed tender-cum-public
auction and subject also to the covenants and conditions hereinafter contained now this indenture
witnesses as follows:The lessor hereby demises to the lessee all those several pieces or pieces of land
situated in the village of ................ in the sub-registration district of ................. in Andhra Pradesh
being more particularly described in the Schedule hereunder written and delineated in the map or
plan hereinto annexed and therein coloured.
2. These are included in the said demise and for the purposes thereof
following liberties:-
I. To get from the said demised pieces of land.II. For the purpose aforesaid to use any water in or
under the said demised pieces of land and to divert the same and to make or construct any water
courses or ponds so however that nothing shall be done in the exercise of this authority which shall
interfere with the rights of any adjoining owners or tenants or the lessors in respect of such
water.III. Generally to do all things which shall be convenient or necessary for getting the ordinary
sand and material hereby authorized to be got and for removing and disposing thereof as aforesaid.
3. There are excepted and reserved to the lessor out this demise:-
I. All minerals and other substances not hereinbefore expressly authorized to be got from the
demised pieces of lands by the lessee.II. Liberty for the lessor or other persons authorized by him to
search for, work, get, carry away and dispose of the excavated minerals and other substances for
such purposes to have the right of ingress, egress and regress over the said demised pieces of land
and to make, erect and use all pits, machinery, buildings, roads and other necessary works and
conveniences provided that the rights hereby reserved shall be exercised in such a way as to cause as
little obstruction as possible to the lessee in the use and enjoyment of its rights hereunder and that
reasonable compensation for damages caused by any such obstruction shall be paid to the lessee the
amount thereof in case of difference to be settled by arbitration as hereinafter provided.
4. The said demised pieces of land shall be held by the lessee for the term of
................ year from the ............ day to the ............... day of ...............
determinable as hereinafter provided.
5. The lessee hereby agrees to pay during the said term the knocked down
amount along with 20% enhancement towards second year lease amount
along with I.T. prevailing 45 days before the expiry of the 1st year lease
period. In respect of registered Boatsman Co-operative Society who remove
and carry sand by Boats shall pay the knocked down amount in four equal
quarterly instalments 15 days before the commencement of the quarter.Andhra Pradesh Minor Mineral Concession Rules, 1966

6. The lessee hereby covenants with the lessor as follows:
I. To pay the knocked down amount / Seigniorage fee / Dead rent on the days and in manner
aforesaid.II. To bear, pay and discharge, all existing and future rates, taxes, assessments, duties,
impositions, outgoing and burdens whatsoever imposed or charged upon the demised pieces of land
or the produce thereof or the knocked down amount hereby reserved or upon the owner or occupier
in respect thereof or payable by either in respect thereof except such charges or impositions as the
lessee is or may hereinafter be by law exempted from.III. Should any rent, knocked down amount or
other sum due to the State Government under the terms and conditions of these presents be not
paid by the lessee / lessees within the prescribed time, the same may be recovered with simple
interest due thereon at the rate of 24% per annum on a certificate of such officer as may be specified
by the State Government by General or specific order in the same manner as arrears of land
revenue.IV. Before digging or opening any part of the said demised pieces of land for ordinary sand
carefully to remove the surface soil to depth of at least ................... meters and lay aside and store
the same in some convenient part of the said demised pieces of land until the land from which it has
been removed is again restored to a State fit for cultivation as hereinafter provided.V. To effectually
fence off the said demised pieces of land from the adjoining lands and to keep the fences in good
repair and conditions.VI. A quarry lease granted by sealed tender-cum-public auction for sand is not
open for transfer.VII. After working out any part of the said demised pieces of land forthwith to level
the same and replace the surface soil thereof and slope the edges, where necessary, so as to afford
convenient connection with the adjoining land.VIII. That the lessee shall keep correct accounts in
such form as the ADM&G concerned shall from time to time require and direct, showing the
quantities and other particulars of the said mineral obtained by the lessees from the said lands and
also the number of persons employed in carrying on the said quarrying operations therein and shall
from time to time, when so directed by the ADM&G concerned prepare and maintain complete and
correct plans of all quarries and workings in the said lands and shall allow any officer thereunto,
authorised by the lessor from time to time and at any time, to examine such accounts and any such
plans and shall, when so required, supply and furnish to the lessor all such information and returns
regarding all or any of the matters aforesaid as the lessor shall from time to time, require and
direct.IX. That if in the course of quarrying any mineral not specified in the lease is discovered the
lessee or registered holder shall at once report such discovery to the ADM&G concerned who shall
obtain orders of the Government regarding the working of the same.X. That the lessor's agents,
servants and workmen shall be at liberty at all reasonable times during the said term, to inspect and
examine the works carried on by the lessee under the liberties hereinbefore granted and the lessee
shall and will, from time to time, and at all times during the said term hereby granted conform to
observe all orders and regulations which the lessor or his authorized agent as the result of such
inspection may from time to time see fit to impose, to keep the lands in good and substantial repair,
order and condition or in the interest of public health and safety.XI. That lessee shall without delay
send to the ADM&G report of any accident involving the death or injury to person which may occur
in or about the quarry and shall observe all rules for the time being in force regulating the working
of quarries.XII. That the lessee shall not without the express sanction in writing of the said ADM&G
concerned cut down or injury any timber or trees on the said lands but he may clear away
brushwood or under growth which interfered with any operations authorized by these presents on
payment of due compensation for cutting or injuring tree growth in the said lands to theAndhra Pradesh Minor Mineral Concession Rules, 1966

departments concerned.XIII. That wherever necessary, pay to the person concerned, compensation
for any loss or damage which may be caused by the lessee to the surface of the demised pieces of
land or to anything growing or situated therein in exercise of the rights granted and shall not
commence operations until such compensation has been paid. The lessee shall further always keep
the lessor indemnified against any claim by any person for any loss or injury caused to him or to his
property by lessee. The District Level Committees shall be the competent authority to assess and fix
any compensation payable by the lessee for any loss or injury done to him or his property.XIV. That
if required by the ADM&G the lessee erect and maintain at his own expense, boundary pillars of
substantial material standing not less than of three feet above the surface of the ground at each
corner or angle in the line of the boundary of the area leased to him and intervals at not more than
three metres along the boundary, as delineated in the plan attached to the lease deed.XV. If any
mineral is not specified in the lease deed or agreement is discovered, the lessee or the registered
holder shall not win or dispose of such mineral without obtaining the permission of the Government
and without payment of the Seigniorage Fee and the acreage assessment. If lessee or the registered
holder fails to intimate the Government the discovery of such minerals and obtain their permission
within a period of thirty days from the date of working of the mineral is begun, the Government may
levy enhanced Seigniorage Fee and acreage assessment.XVI. The lessee or the registered holder shall
strengthen and support to the satisfaction of any Railway Administration concerned or the State
Government, as the case may be, any part of the quarry which in the opinion of the Railway
Administration or as the case may be, the State Government requires such strengthening or support
for the safety of any railway, reservoir, canal, road or any other public works or structure.XVII. The
lessee should make use of authorized ramps and paths only for transportation of sand from the
quarry and not open any new ramps or paths, without permission of the authorities/pattadars
concerned.XVIII. That this lease may be terminated for violation of conditions of lease as mentioned
in Rule 9(B) to 9(z).XIX. That on such determination the lessee shall have no right to compensation
of any kind.XX. The knocked down amount / Dead Rent and Seigniorage Fee payable under these
presents shall be recoverable under the provisions of the Revenue Recovery Act, 1864 thereof.XXI.
That the determination of the tenancy to deliver up the demised land in such condition as shall be in
accordance with the provisions of these presents save that the lessee shall if so required by the lessor
restore in manner provided by the foregoing covenant in that behalf of the surface or any part of the
land which has been occupied by the lessee for the purpose of the works hereby authorized and has
not been so restored.XXII. The lessee shall charge the price for sand at the pit head as fixed by the
District level committee, before notification.XXIII. The lessee shall abide by all the conditions and
statutory provisions under Mines and Minerals (Development and Regulation) Act, 1957, and rules
made thereunder viz., Andhra Pradesh Minor Mineral Concession Rules, 1966, Andhra Pradesh
Mineral Dealers Rules, 2000, Mines Act, 1952, Miners and Metalliferrous Regulations, 1961, and
Andhra Pradesh Water Land and Trees Act, 2002 and other State and Central Act and Rules and
instructions which are applicable.XXIV. The lessee shall have no claims for any compensation due to
floods or heavy rains or any other situation and extension of the lease period shall not be granted
under any circumstances.7.1The Lessor hereby covenants with the lessee paying the knocked down
amount / Dead Rent and Seigniorage Fee hereby reserved and that on observing and performing the
several covenants and stipulations herein the lessee shall peaceably hold and enjoy the demised
pieces of land and the liberties and powers hereby demised and granted during the said term
without any interruption by the lessor or any person rightfully claiming under or in trust for him.II.Andhra Pradesh Minor Mineral Concession Rules, 1966

The Government reserves the right to cancel the Quarry Lease granted and executed under these
rules after giving due notice.III. The Government can prohibit quarrying operations in part or whole
of the area under lease with recorded reasons.IV. Whenever ground water affect is noticed, safety of
the structure is affected due to sand quarrying by the lease holder, the Government shall issue
prohibitory orders banning sand quarrying in consultation with Ground Water Department and
with the concerned Assistant Director of Mines and Geology and the local bodies as the case may be.
8. It is hereby expressly agreed as follows:
I. If any part of the knocked down amount / Dead Rent and Seigniorage Fee hereby reserved shall be
unpaid after becoming payable (whether formally become demanded or if the lessee while the
demised pieces of land or any part thereof remain vested in him shall become insolvent or if any
covenant on the lessee's part herein contained shall not be performed or observed by them and in
any of the said case it shall be lawful for the lessor at any time thereafter to declare to whole or any
part of the said security deposit of Rs. ................ to be forfeited and also to re-enter upon the
demised pieces of land or any part thereof in the name of the whole and thereupon this demise shall
absolutely determined but without prejudice to the right of action of the lessor in respect of any
breach or non-observance of the lessee's covenants herein contained.II. At the expiry of
determination of the lease the lessee shall be at liberty to remove, carry away machinery and all
plant articles and things whatsoever (not being building or bricks or stone) within one month or
extended period granted by Government after paying bid amount and Seigniorage and other sums
which may be due and performing and observing the covenants on his part hereinafter reserved and
contained and also making good any damages done by such removal but not buildings which shall
be erected on the said demised piece of land by the lessee and left thereon at the determination of
the lease land shall be the absolute property of the lessor who shall not pay any price for the
same.III. No movement of sand shall be allowed across the border to the neighbouring State.IV. No
quarrying of sand will be done with machinery / poclains or any other machinery for digging /
loading.V. The sand required for Weaker Section Housing Programme shall be supplied free of cost
at pit head by the bidder / tenderer and is exempted from payment of Seigniorage Fee on certificate
issued by the District Collector or any other Officer nominated by him.VI. Sand transported through
Bullock Carts and Animals shall be exempted from payment of Seigniorage Fee.VII. The
Government shall have the powers to either suo motu or on complaint cancel the confirmation bid at
any stage in such case the bid amount equivalent to the possession held by the bidder will only be
collected.VIII. If the lessee paid the knocked down amount / Dead Rent and Seigniorage Fee and
duly observed and performed the covenants and conditions on his part herein contained the said
deposit of Rs. ............... shall be returned to him at the expiration of the said term of ......... years.IX.
The Way bill for transporting sand shall be in the "Form S-5". The way bills will be issued
proportionate to the knocked down bid amount by calculating Seigniorage Fee as specified in the
Schedule-1 of Rule 10 of Andhra Pradesh Minor Mineral Concession Rules, 1966. The bidder is
liable to pay Seigniorage Fee additionally and obtain permits for the quantities exceeding the
proportionate bid amount.X. If any question of difference or dispute shall arise between the parties
hereto or any person or persons claiming under them respectively concerning the knocked down
amount/Dead Rent and Seigniorage Fee hereby reserved or touching the construction of any clause
herein contained or the rights, duties or liabilities of the parties hereunder or in any other wayAndhra Pradesh Minor Mineral Concession Rules, 1966

touching or arising out of these presents the same shall be referred to the Government whose
decision thereon shall be final and binding on the parties thereto.XI. Removal of sand in patta
lands: It is the responsibility of the bidder to obtain the consent of the Pattadar in respect of any
area on the land abutting the river, streams etc. which is classified as patta land. The Pattadar, who
is claiming the ownership of the land shall produce valid documents and also certificate issued by
the concerned Mandal Revenue Officer.In witness hereof ............... ADM&G of ................ acting for
and on behalf of and by order and direction of the Governor of Andhra Pradesh the lessee have
hereto set their hands the day and year first above writing.The Schedule
Name of Mandal /ReachName of the Mandal Location BoundariesNorth, South, West & East
  
Signed and delivered by the aboveName in the presence ofLesseeLessorWitness:
1.
)
2.
)Form 'H'Mineral Dues Clearance Certificate
1. Name and style of the company, firm, Hindu undivided family or individual
in which the applicant/bidder/tenderer is assessed or assessable to mineral
revenue and address for the purpose of assessment.
2. The place, taluk and district in which the applicant/bidder/tenderer is
assessed to mineral revenue.
3. The following particulars shall be furnished concerning mineral revenue
assessment for the preceding four years.
(a)The total correct amount received during the preceding four accounting years: -(Total mining
dues assessed)(1)Seigniorage fee/Bid amount/Cesses. (in the case of minor
minerals)(2)Royalty/Dead Rent/Surface Rent. (in the case of major minerals)(Mining dues
demanded)(1)Seigniorage fee/Bid amount/Cesses. (in the case of minor minerals)(2)Royalty/Dead
Rent/Surface Rent/Mineral Right Tax/Cesses. (in the case of major minerals)(Balance
dues)(1)Seigniorage Fee/Bid amount/Cesses. (in the case of minor minerals)(2)Royalty/Dead
Rent/Surface (in the case of major minerals) Rent/Mineral Right Tax/CessesIf any mineral revenue
remains unpaid, the reasons therefor should be explained in an attached statement).(b)In case there
has been no mineral revenue assessment in any year, it must be stated clearly with reasons
therefor.(c)It must be declared whether any attachment or certificate proceedings are pending in
respect of the arrears.(d)The name and address of branch(es) if any.I, declare that the aboveAndhra Pradesh Minor Mineral Concession Rules, 1966

information is correct and complete to the best of my knowledge and belief.Signature of the
Applicant/Bidder/Tenderer.Address:Date:In my opinion, the applicant/bidder/tenderer mentioned
above has been doing everything possible to pay promptly and regularly the mineral revenue
demand and to facilitate the completion of the pending or outstanding proceedings.(This certificate
is valid for the half year ending with the 31st March/the 30th September, 19.....).Date:Seal:Signature
of the Issuing Authority.[Form-J] [Inserted by G.O.Ms.No. 25, Ind. & Com., date 12-1-1984.](Should
be submitted in triplicate)Model form of application for appeal/revision under Rule 35 or 35-A[See
Rule 35-C]
1. Name and address of individual(s), firm or company, applying.
2. Profession of individual(s), firm or company.
3. No. and date of order of the ADMG/DDM & G/DMG, against which the
appeal/revision application is filed (copy attached).
4. Minor Mineral or Minor Minerals for which the revision application is filed.
5. Details of the area in respect of which the revision application is filed.
District Taluk Village S.No. and total area claimed
    
(A map or plan of the area(s) to be attached).
6. Whether application fee has been deposited in the manner prescribed in
sub-rule 35-B read with Rule 35-C(i) if so, the Treasury receipt in original
should be attached.
7. Whether the appeal/revision application has been filed within time
specified in Rule 35/35-A, if not, the reasons for not presenting it within the
prescribed limits as provided for in rules.
8. Name and complete address of the party/parties impleaded, under Rule
35-C of A.P.M.M.C. Rules, 1966.
9. No. of copies of petitions/applications attached (Rule 35-C(4) A.P.M.M.C.
Rules, 1966).Andhra Pradesh Minor Mineral Concession Rules, 1966

10. Grounds of appeal/revision.
11. If the appeal/revision application has been filed by the holder of Power of
Attorney, the Power of Attorney to be attached.
Place:Date:Signature of the Applicant.[Form-J 1] [Inserted by G.O.Ms.No. 84, Ind. & Com., date
10-4-2007.][Should be submitted in triplicate]Model Form of Application for Appeal/Revision
under Rule 9-H
1. Name and address of individual(s), firm or company, applying.
2. Profession of individual(s) firm or company.
3. No. and date of the order against which the revision application is filed
(copy attached).
4. Minor Mineral or Minor Minerals for which the appeal / revision application
is filed.
5. Details of the area in respect of which the appeal / revision application is
filed.
District  Reach / Mandal  
    
6. Whether the application fee has been deposited in the manner prescribed
in Rule 9-GH(7), if so, the Treasury Receipt in original should be attached.
7. Whether the appeal / revision application has been within time specified in
Rule 9-H(7), if not, the reason for not presenting it within the prescribed limits
as provided for in rules.
8. Name and complete address of the party / parties impleaded, under Rule
9-H of APMMC Rules, 1966.
9. No. of copies of petition / applications attached under Rule 9-H of Andhra
Pradesh Minor Mineral Concession Rules, 1966.Andhra Pradesh Minor Mineral Concession Rules, 1966

10. Grounds of appeal / revision.
Place:Date:Signature of the applicant.[Form-K] [Inserted by G.O.Ms.No. 425, I&C, date 21-12-1993,
w.e.f. 27-12-1993.]Application for issue of permit for despatch of Minor Minerals[See Rule 34]
1. Name of the lessee :
2. Address:
3. Location of the quarry
Survey No., Village, Mandal and District):
4. Name of the Minor Mineral :
5. Quantity of the Minor Mineral in stock and the quantity proposed to be
despatched:
6. Payment Particulars
(a)Challan No., date & amount :(b)Name of the Treasury :
7. Route and Mode of Transportation:
8. Purpose of despatch of Minor Mineral (Own consumption or sale in case of
sale, the name and address of the purchaser should be furnished):
9. Station of loading :
10. Destination of the Consignment with the name and address of the
consignee.
11. Basic value of the minor mineral at pits head.
12. Date within which the applicant desires to despatch the quantity:
13. Other particulars which the applicant wishes.
I/We hereby certify that the particulars given above are correct and to the best of my/our knowledge
and belief.Place:Date:Signature of Lessee/Authorised Agent.][Form-K1] [Inserted by G.O.Ms.No.
104, I&C (M1) Department, date 15-5-2009.]Application for issue of permit for dispatch of MinorAndhra Pradesh Minor Mineral Concession Rules, 1966

Minerals[See Rule 10(5) and Rule 34(3)]
1. Name of the Industry:
2. Address
3. Location of the Industry
Survey No. Village, Mandal and District :
4. Name of the Minor Mineral utilized in the industry:
5. Quantity of the Minor Mineral in stock and proposed to be procured
Mineral Unit Stock at Unit Raw Material Proposed to be procured
Raw Finished
6. Payment Particulars:
(a)Challan No., Date and amount:(b)Name of the Treasury
7. Route and Mode of Transportation of Raw Blocks:
8. Basic value of Finished Product at Industry Site.
9. Date with in which the applicant desires to dispatch the quantity:
10. Other particulars which the applicant wishes.
I/We hereby certify that the particulars given above are correct and to the best of my/our knowledge
and belief.Place:Date:Signature of the applicant/Authorized Agent.".
4. The Director of Mines and Geology shall review the entire system once in 3
months, to take stock of the situation at regular Intervals.
5. The Director of Mines and Geology, Hyderabad shall take necessary action
to implement the recommendations made by the 2nd Administrative Reforms
Commission in its Fourth Report titled "Ethics in Governance" relating to
"Reducing Discretion".Andhra Pradesh Minor Mineral Concession Rules, 1966

6. The order issues with the concurrence of Finance (Expr. I&C) Department
vide their U.O.No. 12770/221/Exp. I&C/09, dated 13.5.2009.]
[Form L] [Inserted by G.O.Ms.No. 425, I&C., date 21-12-1993, w.e.f. 27-12-1993.]Permit for
despatch of Minor Mineral[Under Rule 34]Permit No ...................... Dated .....................Permit is
hereby granted to ................. to despatch ................... cubic metres of ............................ Minor
Mineral from his/their .................. quarry lease situated in Survey No .................. of ...................
village ............................ mandal and ........................ district in consideration of payment of a sum of
Rs ......................... being the seigniorage fee on the said quantity, subject to the following conditions
:
1. The permit is valid for ................ from ......................... to ............................
and shall expire on ..............................
2. The permit is not transferable.
3. [***] [Sl.No. 3 omitted by G.O.Ms.No.104, I&C (M1), Department, date
15-5-2009.]
4. The permit shall be surrendered after the quantity noted therein is
despatched to the Department within a week after the last consignment of
despatch along with the despatch particulars by giving the details of the
name of the consignee, the date of despatch etc.
5. Holder of the permit shall allow the executive staff and the officers of the
Department of Mines and Geology to inspect, check and measure the minor
minerals in all stages of movement.
6. The department has the right to claim amounts by way of difference of
seigniorage fee based on the scrutiny of the sale documents and the check
measurements, provided the excess quantity is not beyond 10% of the
quantity mentioned in the documents. The excess quantity beyond 10% is
liable for penalisation under [Rule 34 (1).] [Substituted for 'Rule 34 (2)' by
G.O.Ms.No. 102, I&C (MI) Department, date 28-09-2010.]
6A. [***] [Sl. No. 6-A, Omitted by G.O.Ms.No. 102, I&C (MI) Department, date
28-09-2010.]Andhra Pradesh Minor Mineral Concession Rules, 1966

7. Failure to comply with any of the above conditions shall entitle withdrawal
of the permit or cancellation of the same.
Issuing Authority[Form-L1] [Inserted by G.O.Ms.No. 104, I&C (M1) Department, date
15-5-2009.]Permit for Dispatch of Minor MineralUnder Rule 34(3)Permit No ...................... Dated
.....................Permit is hereby granted to dispatch ........................... cubic meters of ...........................
from any authorized quarry lease granted under the provisions of the Andhra Pradesh Minor
Mineral Concession Rules, 1966 in consideration of payment of sum of Rs. ........................... being
the seigniorage fee on the said quantity on slab system subject to the following conditions:
1. The permit is valid for ................................................................................. from
............. to ................................. and shall expire on ........................ .
2. The permit is not transferable.
3. The permit shall be surrendered after the quantity noted there in is
dispatched to the Department within a week after the last consignment of
dispatch along with the dispatch particulars by giving the details of the name
of the lease holders from whom the material is procured.
4. Holder of the permit shall allow the executive staff and the officers of the
Department of Mines and Geology to inspect, check, and measure the minor
minerals in all stages of movement.
5. The Department has the right to claim amounts by way of difference of
seigniorage fee based on the scrutiny of the sale documents and the check
measurements, provided the excess quantity is not beyond 10% of the
quantity mentioned in the documents. The excess quantity beyond 10% is
liable for penalization under [Rule 34 (1).] [Substituted for 'Rule 34 (2)' by
G.O.Ms.No. 102, I&C (MI) Department, date 28-09-2010.]
6. Failure to comply with any of the above conditions shall entitle withdrawal
of the permit and cancellation of the same.
Encl: Transit forms fromSl.No. .......................... to .................... to procure the raw materialunder
this permit.Issuing Authority.]Form 'M'Form of Agreement[See Rule 10]This indenture made this
........................ day of 199 ........ between the Governor of Andhra Pradesh (hereinafter called the
"State Government" which expression shall where the context so admits, include his successors in
Office and Assigns) of the One Part, andWhen Authorised Agent is an Individual
:.................................. (Name of person with Address and Occupation) (hereafter referred to as theAndhra Pradesh Minor Mineral Concession Rules, 1966

authorised Agent which expression shall where the context so admits to be deemed to include his
respective heirs and legal representatives).When the Authorised Agents are more than one
Individual:..................................... (Name of the person with address and Occupation) (hereafter
referred to as the authorised agents which expression shall where the context so admits to be
deemed to include their heirs and Legal representatives).When The Authorised Agent is a
Registered Firm :...................... (Name and Address of Partner) Son of ...........................
............................................... all carrying business in partnership under the firm Name and Style of
................. (Name of the firm) Registered under the Indian Partnership Act, 1932 (9/1932) and
having their Registered Office at .......................... in the Town of ......................... (hereafter referred
to as the authorised agent which expression where the context so admits is deemed to include of the
said partners their respective heirs Legal representatives and permitted assigns) of the other
Part.Whereas the authorised agent has been granted in [Sealed Tendercum- Public Auction]
[Substituted for the words 'Public Auction' by G.O.Ms.No. 50, I & C (M.I) Department, dated
17-3-1997.] by the State Government the rights of collection of seigniorage fee in respect of the
Minor Minerals specified in the schedule from the area specified : therein and has paid the 25% of
knocked down amount towards 1st instalment and has furnished the bank guarantee for the
remaining 75% of the knocked down amount and has deposited with the Assistant Director of Mines
and Geology .................................. of the sum of [Rs. ................] [Substituted for the amount '25000'
by G.O.Ms.No. 50, I & C (M.I) Deptt., date 17-3-1997.] as security for the due and faithful
performance by the authorised agent of the conditions on the Part of the authorised agent
hereinafter contained.And whereas the State Government demised the area hereafter described for
the term and [knocked down] [Substituted by G.O.Ms.No. 50, I & C (M.I) Department, date
17-3-1997.] amount and subject also to the conditions hereinafter contained, now this indenture
witness as follows:-The State Government hereby permits the authorised agent to collect the
seigniorage fee in respect of the Minor Minerals specified from the lease holders whose leases are
situated in the village of .......................... in mandal ......................... and District of ..........................
above more particularly described in schedule hereunder.Part - I Mode of Payment of Knocked
Down AmountThe authorised agent having paid the 1st instalment of the knocked down [***] [The
word 'bid' omitted by G.O.Ms.No. 50, I & C (M.I) Department, date 17-3-1997.] amount before enter
in the agreement shall pay remaining 3 quarterly instalments as detailed below :
2nd. Instalment of Rs. ...................... on or before ......................
3rd. Instalment of Rs. ...................... on or before ......................
4th. Instalment of Rs. ...................... on or before ......................
The State Government shall have the power to terminate the agreement if the authorised agent falls
to pay the instalments as above and to forfeit to the Government the amounts paid by the authorised
agent and the amount guaranteed by Bank.Part - II Liberties of the Authorised Agent(1)[ To collect
seigniorage fee at the relevant rates specified in Schedule 1 to Rule 10(1) and the relevant rates
mentioned under Rule 12(5)(e) from the lease holders including temporary permit holders except
the persons/organisations who obtained quarry leases with exemption from payment of seigniorage
fee in respect of specified minerals for the quantities consumed or despatched by lease holders fromAndhra Pradesh Minor Mineral Concession Rules, 1966

their respective leases situated within the demised area at or before the time of despatch of the
minerals. [Substituted by G.O.Ms.No. 50, I & C (M.I) Department, date 17-3-1997.](2)To issue
transit way bills to the lease holders including temporary permit holders after collecting the
seigniorage fee.](3)To check the vehicles transporting specified minor minerals for the purpose of
collection of seigniorage fee.Part - III Restrictions on the Authorised Agent(1)[ The authorised agent
shall not collect the seigniorage fee in excess of relevant rates specified in the Schedule I to Rule
10(1) and the relevant rates mentioned under Rule 12(5)(e).] [Substituted by G.O.Ms.No. 50, I & C
(M.I) Department, date 17-3-1997.](2)The authorised agent shall not interfere with the quarrying
operations or transportation of any Minor Minerals other than those specified under the schedule
appended.(3)The authorised agent shall not interfere with the [Mining] [Substituted for the word
'Minor' by G.O.Ms.No. 50, I & C (M.I) Department, date 17-3-1997.] and transportation of any Major
Minerals from the demised area.(4)The authorised agent shall not interfere with the transportation
of Minor Minerals specified in the schedule when they are quarried and transported from the leases
situated outside the demised land and the transportation is covered by a valid despatch permit
issued by competent authority having jurisdiction over the area from which the minor mineral was
quarried.(5)No building or thing shall be erected, set up or placed on any public ground or any place
held sacred any class of persons or in such a manner as to injure pre-judicially effect any rights of
other persons.Part - IV Liberties of the State Government(1)The State Government shall have the
liberty to grant the quarry leases in respect of the minor minerals specified in the schedule
hereunder as per A.P.M.M.C. Rules, 1966.(2)The State Government shall have the power to penalise
any person indulged in illicit quarrying and transportation of minerals from demised area as per
rules.(3)The State Government shall have the power to terminate the agreement with the authorised
agent if he violates the conditions specified in Part-III above.Part - VIt is Hereby Expressly Agreed
as Follows :(1)The authorised agent shall immediately inform to the Assistant Director of Mines and
Geology concerned about any illicit quarrying of minor minerals noticed within the demised
area.(2)The authorised agent shall maintain correct account of the minor minerals consumed or
despatched from the demised area and shall furnish the same to the department when asked
for.(3)The authorised agent shall make his own arrangements for collecting the seigniorage fee from
the lessee and he shall not claim any compensation for any failure on his part in collecting the
same.(4)The Bank Guarantee furnished by the Authorised Agent for the 75% of the knocked down
bid amount and the security deposit of [Rs. .......] [Substituted for the expression 'Rs., 25,000/-' by
G.O.Ms.No. 50, I & C (M.I) Department, date 17-3-1997.] shall be returned after the completion of
the said term of one year. Provided that the authorised agent duly observed and performed the
conditions on his part herein contained.(5)If any question of difference or dispute shall arise
between the parties here to or any person concerning the [knocked down] [Substituted for the word
'bid' by G.O.Ms.No. 50, I & C (M.I) Department, date 17-3-1997.] amount and seigniorage fee hereby
reserved any of these presents, it shall be reserved to the State Government whose decision thereon
shall be final and binding on the parties hereto.In witness whereof ...................... Assistant Director
of Mines and Geology ...................... acting for and on behalf of and by order and direction of
Governor of Andhra Pradesh and the Authorised Agent have hereupto set their hands the day and
year first above writing.The Schedule
Location of the
demised areaMinor
Minerals[knocked down] [Substituted for the word 'bid' by
G.O.Ms.No. 50, I & C (M.I) Department, dateAndhra Pradesh Minor Mineral Concession Rules, 1966

17-3-1997.]
Village Mandal District Specified amount
1 2 3 4 5
Signed and delivered by the above named in the presence of :[Model Form - N] ['Form-N to Form-R'
Inserted by G.O.Ms.No. 227, I & C (M. I) Department, date 23-3- 2000.]Application for Quarry
Prospecting Licence for [granite and marble] [Substituted for 'Granite' by G.O.Ms.No. 282, I&C
(M-I) Department, date 23-9-2003.] To be submitted in triplicate[See Sub-Rule (5) of Rule
12]Dated .......... day ........ of ........20 ...
ReceivedAtOnInitial of the
Received Officer Latest Passport SizePhoto of the applicantattested by a
GazettedOfficer be affixed 
ToThroughSir,I/We request that a Prospecting Licence under APMMC Rules, 1966 be granted to
me/us.
2. A sum of Rs. 5000/- and DD for Rs. ....... being the fee in respect of this
application and deposit respectively has been paid Vide Challan No..........
date .......... of the State Bank of India/Treasury ( ) DD No. ............. date ...........
of .......... [any Nationalized Bank.]
3. The required particulars are given below:-
(i)Name of the applicant with complete address.(ii)Is the applicant a private individual/private
company/public company/firm or association?(iii)In case applicant is:(a)an individual, his
nationality.(b)A company, an attested copy of the certificate of registration of the company shall be
enclosed.(c)A firm or association, the nationality of all the partners of the firm or members of the
association.(iv)Profession or nature of business of applicant.[v-a] No. and date of the valid clearance
certificate of payment of mining dues [Copy attached].[v-b] If on the date of application, the
applicant does not hold a Prospecting Licence, it should be specified whether an affidavit to this
effect has been furnished to the satisfaction of the State Government.(vi)Details of [granite and
marble] [Substituted for 'Granite' by G.O.Ms.No. 282, I&C (M-I) Department, date 23-9-2003.]
which the applicant intends to prospect.(vii)Period for which the Prospecting Licence is
required.(viii)Extent of the area the applicant wants to prospect.(ix)Details of the area in respect of
which prospecting Licence is required.
District Mandal Village Sy.No.Plot No. Area
     
(x)(a)Does the applicant have surface rights over the area for which he requires a prospecting
licence? If so with relevant certified documents.(b)If not, has he obtained the consent of the owner,
and the occupier of the land for undertaking prospecting operations].If so the consent of the owner
and the occupier obtained in writing be filed. (in certified copies)N.B.: - The areas shall cover whole
or recognized part survey numbers.(c)In case of forest areas, the name of the working circle, the
range and felling series.(d)For areas where no forest or cadestral maps are available, a sketch plan
should be submitted on scale showing the area applied for together with boundary, if any, of anyAndhra Pradesh Minor Mineral Concession Rules, 1966

other existing quarrying lease or prospecting licence areas if the areas applied for has any common
point or line with the boundaries of existing prospecting licence or quarrying lease areas.(xi)The
area applied for should be marked on plans as detailed below: -(a)In case a cadestral map of the area
is available the area on this map should be marked showing the name of the Village, KhasraNo. and
areas in hectares of each field and part thereof.N.B.: - The area applied for shall cover whole survey
numbers.(b)In the case of forest maps the area should be marked on the map showing the range and
felling series.(c)In case neither cadestral nor forest maps, are available, the area should be marked
on a sketch plan drawn to scale showing on this plan all important surface and natural features, and
dimensions of the lines forming the boundary of the area and the bearing and distance of all corner
points from any important, prominent and fixed point or points].(xiii)Particulars of the areas
mineral-wise (in each State duly supported by an affidavit) for which the applicant or any person
joint in interest with him.(a)Already holds under prospecting licence.(b)Has already applied for but
not granted, or(c)Being applied for simultaneously.(xiii)Nature of joint in interest, if any.(xiv)If the
applicant intends to supervise the work, his previous experience of prospecting and mining should
be explained, if he intends to appoint a manager, the name of such manager, his qualifications,
nature and extent of his previous experience should be specified and his consent letter be
attached.(xv)Financial resources of the applicant.(xvi)Particulars of receipted treasury challan and
deposits attached for the amount referred to at 2 above.(xvii)Any other particulars or sketch map
which the applicant wishes to furnish.I/We do hereby declare that the particulars furnished above
are correct and am/are ready to furnish any other details including accurate plans as may be
required by you.Place:Date:Yours faithfullySignature and Designation of the Applicant.Form -
OForm of Prospecting Licence of [granite and marble] [Substituted for 'Granite' by G.O.Ms.No. 282,
I&C (M-I) Department, date 23-9-2003.][See Rule 12(5)(e)]
 Latest Passport SizePhoto of Licensee dulyattested by a GazettedOfficer be affixed.
This indenture made the .......... day of........ 20... between the Governor of Andhra Pradesh
(hereinafter called the "Government" which expression shall where the context so admits, include
his successors in office and assigns) of the part, and............... (hereinafter called the "Licensee"
which expression shall, where the context so admits, include his heirs, executors, administrators,
representatives and assigns) of the other part.Whereas the Licensee has been granted Prospecting
Licence by the Government of Andhra Pradesh on application of lands in the................... District, for
the purpose of Prospecting for [granite and marble] [Substituted for 'Granite' by G.O.Ms.No. 282,
I&C (M-I) Department, date 23-9-2003.] and as deposited with the Assistant Director of Mines &
Geology of.................. the sum of Rs. ............... as security for the due and faithful performance by
the Licensee of the covenants and conditions on the part of the Licensee hereinafter contained.And
whereas the Government of Andhra Pradesh acting for and on behalf of the Lands and Premises
hereinafter described and demised for the term and at the Prospecting Licence fee and subject also
to the covenants and conditions hereinafter contained now this indenture witnesses as follows: -The
Government hereby demises to the Licensee all those several pieces or parcels of land situated in the
village of.......... in the subregistration district of................ and registration district of Andhra
Pradesh being more particularly described in the schedule hereunder written and delineated in the
map or plan hereunto annexed and therein coloured.Andhra Pradesh Minor Mineral Concession Rules, 1966

2. These are included in the said demise and for the purposes thereof
following liberties: -
(i)To get from the said demised pieces of land.(ii)For the purpose aforesaid to use any water in or
under the said demised pieces of land and to divert the same and to make or construct any water
courses or ponds so however that nothing shall be done in the exercise of this authority which shall
interfere with the rights of any adjoining owners or the tenants of the Government, in respect of
such water.
3. These are expected and reserves to the Government out of this demise.
(i)Liberty for the Government or other persons authorised by them to search for work, get and carry
away the excepted minerals and other substances and for such purposes to have the right of ingress,
egress and regress over the said demised pieces of land and to make erect and use all pits,
machinery, buildings, roads and other necessary works and conveniences provided that the rights
hereby reserved shall be exercised in such a way as to cause as little obstruction as possible to the
licence in the use and enjoyment of its rights hereunder and that reasonable compensation for
damages caused by any such obstructions shall be paid to the licensee the amount thereof in case of
difference to be settled by arbitration as hereinafter provided.
4. The said demised pieces of land shall be held by the Licensee for the term
of ........ years from the...... day of.....20.... to the......... day of ......20....
determinable as hereinafter provided.
5. The Licensee hereby agrees to pay during the said term a Prospecting fee
of Rs. ......... per hectare together with Land Assessment, and Cesses thereon
which may from time to time be imposed by the Government.
6. The Government may during the currency of the Licence, vary the rate of
Prospecting fee.
7. It is hereby agreed and declared that the said Prospecting fee together
with Land Assessment and Cess on Land Assessment shall be paid by the
licensee at the time of execution of the Licence Deed and for the subsequent
years one month in advance every year.
8. The Licensee is hereby covenants with the Government as follows:-
(i)To pay the Prospecting Licence fee on the days and in the manner aforesaid.(ii)To bear, pay and
discharge all existing and future rates, taxes, assessments, duties, impositions, outgoings and
burdens whatsoever imposed or charged upon the demised pieces of land or the Prospecting feeAndhra Pradesh Minor Mineral Concession Rules, 1966

hereby reserved or upon the owner or occupier in respect thereof or payable by either in respect
thereof except such charges or impositions as the Licensee is or may hereinafter be by law exempted
from.(ii-A) Should any Prospecting fee or other sums due to the State Government under the terms
and conditions of these presents be not paid by the Licensee within the prescribed time, the same
may be recovered together with simple interest due there on at the rate of twenty four percent per
annum on a certificate of such officer as may be specified by the State Government by general or
special order in the same manner as on arrears of land revenue.(iii)Before digging or opening any
part of the said demised pieces of land for............ carefully to remove the surface soil to a depth of
atleast ..........metres and lay aside and store the same in some convenient part of the said demised
pieces of land until the land from which it has been removed is again restored to a state fit for
cultivation as hereinafter provided.(iv)To effectually fence off the said demised pieces of land from
the adjoining lands and to keep the fences in good repair and conditions.(v)Not to assign under let
or part with the possession of the demised land or any part thereof without written consent of the
Government first obtained.(vi)After working out any part of the said demised pieces of land
forthwith to level the same and replace the surface soil thereof and slope the edges, where necessary,
so as to afford convenient connection with the adjoining land.(vii)That the Licensee shall keep
correct accounts, in such form as the Assistant Director of Mines & Geology concerned shall, from
time to time, require and direct showing the quantities and other particulars of the said mineral
obtained by the Licensee from the said lands and also the number of persons employed in carrying
on the said Prospecting operations there in and shall, from time to time, when so directed by the
Assistant Director of Mines & Geology concerned prepare and maintain complete and correct plans
of all Prospecting operations conducted in the said lands and shall allow any officer thereunto,
authorised by the Government from time to time and at any time, to examine such accounts and any
such plans and shall, when so required, supply and furnish to the Government all such information
and returns regarding all or any of the matters aforesaid as the Government shall from time to time
require and direct.(viii)That if the course of the Prospecting any mineral not specified in the licence
is discovered the Licence or registered holder shall at once report such discovery to the Assistant
Director of Mines & Geology concerned who shall obtain orders of the Director regarding the
Prospecting of the same.(ix)That the Governments agents, servants and workmen shall be at liberty
at all reasonable times during the said term, to inspect and examine the works carried on by the
Licensee under the liberties hereinbefore granted and the Licensee shall and will, from time to time,
and at all times during the said term hereby granted confirm to observe all orders and regulations
which the Government or an authorised agent as the result of such inspection may from time to time
see fit to impose to keep the lands in good and substantial repair, order and condition or in the
interest of public health and safety.(x)The Licence shall without delay sent to the Assistant Director
of Mines & Geology a report of any accident involving the death or injury to any person which may
occur in or about the Prospecting Licence area and shall observe all rules for the time being in force
regulating the working of Prospecting Licence.(xi)That the Licensee shall not without the express
sanction in writing of the said Assistant Director of Mines & Geology cut down or injure any timber
or trees on the said lands but he may clear away brushwood or undergrowth which interferes with
any operations authorised by these presents on payment of due compensation for cutting or injuring
tree growth in the said lands to the departments concerned.(xii)That wherever necessary, pay to the
person concerned, compensation for any loss or damage which may be caused by the Licensee to the
surface of the demised pieces of land or to anything growing or situated therein in exercise of theAndhra Pradesh Minor Mineral Concession Rules, 1966

rights granted and shall not commence operations until such compensation has been paid. The
Licensee shall further always keep the Government indemnified against any claim by any person for
any loss or injury caused to him or to his property by the Licensee. The Deputy Director shall be the
competent authority to assess and fix any compensation payable by the licensee for any loss or
injury done to him or his property.(xiii)That if required by the Assistant Director of Mines &
Geology, erect and maintain at his own expense, boundary pillars of substantial material standing
not less than three feet above the surface of the ground at each corner or angle in the line of the
boundary of the area granted to him and at intervals of not more than three metres along the
boundary, as delineated in the plan attached to the licence deed.(xiv)If any mineral not specified in
the Licence deed or agreement is discovered the Licensee or the registered holder shall at once
report such discovery to the Assistant Director of Mines & Geology, to enable him to obtain the
orders of the Director of Mines and Geology/Government for Prospecting of the same.(xv)The
Licensee or the registered holder shall strengthen and support to the satisfaction of any Railway
Administration concerned or the State Government as the case may be, any part of the Prospecting
Licence area which in the opinion of the Railway Administration or as the case may be, the State
Government requires such strengthening or support for the safety of any railway, reservoir, canal,
road or any other public works or structure.(xvi)That this Licence may be terminated in respect of
the whole or any part of the premises by six months notice in writing on either side.(xvii)That on
such determination the Licensee shall have no right to compensation of any kind.(xviii)That the
Prospecting fee payable under these presents shall be recoverable under the provisions of the
Revenue Recovery Act, 1864 thereof.(xix)That the determination of the tenancy to deliver up the
demised land in such condition as shall be in accordance with the provisions of these presents save
that the Licensee shall if so required by the Government, restore in the manner provided by the
foregoing covenant in that behalf the surface or any part of the land which has been occupied by the
Licensee for the purpose of the works hereby authorised and has not been so restored.(xx)[ The
licensee for granite and marble shall comply with the provisions of Granite Conservation and
Development Rules, 1999 and the Marble Development and Conservation Rules, 2002 respectively.]
[Substituted by G.O.Ms.No. 282, I&C (MI) Department, date 23-9-2003.]
9. The Government is hereby covenants with the Licensee that on the
Licensee paying the Prospecting fee hereby reserved and that on observing
and performing the several covenants and stipulations herein, the Licensee
shall peaceably hold and enjoy the demised pieces of land and the liberties
and powers hereby demised and granted during the said term without any
interruption by the Government or any person rightfully claiming under or in
trust for him.
9A. Government reserves the right.
(i)To cancel the Prospecting Licence granted and executed under these rules after giving a previous
notice.(ii)To prohibit Prospecting operations in part or the whole of the area under Licence with
recorded reasons.Andhra Pradesh Minor Mineral Concession Rules, 1966

10. It is hereby expressly agreed as follows:- (i) If any part of the Prospecting
Fee hereby reserved shall be unpaid for 30 days for becoming payable
(whether formally demanded or not) or if the Licensee while the demised
pieces of land or any part thereof remain vested in him shall become
insolvent or if any covenants on the Licensee's part herein contained shall
not be performed or observed them and in any of the said case it shall be
lawful for the Government at any time thereafter to declare the whole or any
part of the said security deposit of Rs. ............. to be forfeited and also to
reenter upon the demised pieces of land or any part thereof in the name of
the whole and thereupon this demise shall absolutely determine but without
prejudice to the right of actions of the Government in respect of any breach
or non observance of the Licensees covenants herein contained.
(ii)At the expiry of the determination of the Licence, the Licensee shall be at liberty to remove and
carry all Engines, Machinery, articles and other things whatsoever (not being building or bricks or
stones) within one month or extended period granted by the Government after paying Prospecting
fee and other sums which may be due and performing and observing the covenants on his part
herein before reserved and contained and also making good any damages done by such removal but
not building which shall be erected on the said demised piece of land by the Licensee and left there
on at the determination of the Licence and shall be the absolute the Property of the Government
who shall not pay any price for the same.(iii)If the Licensee shall have paid the Prospecting Fee and
duly observed and performed the covenants and conditions on his part herein contained the said
deposit of Rs. ........... shall be returned to him at the expiration of the said term of...... years.(iv)If
any question of difference or dispute shall arise between the parties hereto or any persons claiming
under them respectively concerning the Prospecting Fee hereby reserved or touching the
construction of any clause herein contained or the rights, duties or liabilities of the parties
hereunder or in any other way touching or arising out of these presents the same shall be referred to
the Director of Mines and Geology whose decision thereon shall be final and binding on the parties
thereto.In witness whereof............. Assistant Director of Mines and Geology of.............. acting for
and on behalf of and by order and direction of the Government of Andhra Pradesh the Licensee have
hereunto set their hands the day and year first above written.The Schedule
Name of Mandal
North,and DistrictName of
VillageSurvey field
Nos.Extent AssessmentBoundariesSouth, West
and East
1 2 3 4 5 6
      
Signed and delivered by the above named in the presence of ...........Model Form-PApplication for
Quarry Lease for [Granite and Marble] [Substituted for 'Granite' by G.O.Ms.No. 282, I&C (M-I)
Department, date 23-9-2003.]To be submitted in Triplicate[See Rule 12(5)]
ReceivedAt....... (Place)On....... (Date)Initial
of the Receiving Officer Latest Passport SizePhoto of theapplicant attested
bya Gazetted Officer be affixed. Andhra Pradesh Minor Mineral Concession Rules, 1966

Dated the ........ day of ....... 20 ....To:...............................................................Through:Sir,I/We
request that a Quarry Lease under the APMMC Rules 1966 may be granted to me/us.
2. A sum of Rs. 5000/- and DD for Rs. ....... Being the fees in respect of this
application and deposit respectively payable under sub-rule (5-a) of Rule 12
(vide Challan No. ............ dated ............ of the State Bank of India/Treasury
...........) and DD No. ............... and date ............) [of any Nationalised Bank].
3. The required particulars are given below:
(i)Name of the applicant with Complete Address. Status of the applicant.(ii)Is the applicant a private
individual/Cooperative/ firm/association/private sector undertaking/Joint Sector undertaking or
any other.(iii)In case the applicant is ...........(a)an individual, his nationality qualification and
experience relating to quarrying(b)a company, an attested copy of the certificate of registration of
the company shall be enclosed.(c)firm or association, the nationality of all the partners of the firm or
members of the association; and(d)a co-operative, nationality of non-India Members, if any along
with place of Registration and a copy of the certificate of registration.(iv)Profession or nature of
business of applicant.(v)Particulars of documents appended: Document Reference(a)Mineral Dues
Clearance CertificateOr(b)Affidavit in lieu of Mineral Dues Clearance Certificate; subject to the
production of Mineral dues, clearance certificate within the period of ninety days of making
applicationOr(c)Affidavit when not holding any quarry lease.(vi)Mineral or minerals which the
applicant intends to quarry.(vii)Period for which Quarry lease is required.(viii)Extent of the area for
which quarrying lease is required.(ix)Details of the area in respect of which quarrying lease is
required.
District Mandal Village Khasra No. Plot No. Ownership Area Occupancy
(x)Brief description of the area with ; particulars reference to the following: -a. Does the applicant
have surface rights over the area for which he is making an application for grant of a quarry Lease.b.
If not, has he obtained the consent of the owner, and the occupier of the land for undertaking
quarrying operation. If so, the consent of the owner and occupier of the land be obtained in writing
and be filed.(xi)a. A copy of Village Map which is not in less scale than village map showing the area
applied for the situation of the area in respect of natural features such as streams or lakes.b. in the
case of Village area ; the name of the village, the khasra number, the area in hectares of each field or
part hereof applied for ;c. In case the area applied for is under forest, then the following particulars
be given: -(xii)1. Forest division Block and Range
2. Legal status of the Forest (namely reserved, Protected, unclassified etc.)
(xiii)Particulars of the areas mineral wise in each Stated duly supported by an affidavit for which the
applicant or any person joint in interest with him.A. Already holds under quarrying lease.B. Has
already applied for but not granted.C. Being applied for simultaneously.(xiv)Nature of joint in
interest if any.(xv)a. Does the applicant hold a prospecting licence over the area mentioned at (xi)
above? : If so, give its numbers and date of grant and the date when it is due to expire.b. Has theAndhra Pradesh Minor Mineral Concession Rules, 1966

applicant carried out the prospecting operation over the area held under PL and sent his report to
the State Government, If not, state reasons for not doing so.c. Nature of the land chosen for
dumping overburden/waste and tailings (that is type of land whether agricultural, grazing land ;
barren, saline land etc.) and whether proposed site has been shown on the mine working plan. Give
also the extent of area in hectares set apart for dumping of waste and tailings.(xvi)A report giving
the details of prospecting carried out in the area together with assessment of the ore reserves,
geological plans, results of chemical analysis of the representative samples and bore holes and
logs.(xvii)Manner in which the mineral raised is to be utilised.a. i. if for captive use, the location of
plant and industry.ii. for sale for indigenous consumption.b. If for exports to foreign countries: -i.
Names of the countries to which it is likely to be exported where the name is being set up on 100%
export oriented or tied up basis.ii. Whether mineral will be exported in raw form or after processing.
Also indicate the stage of prospecting, whether intermediate stage or final stage of the end
product.c. If it is to be used within the country, indicate:- the industry/industries in which it would
be used. Whether it will be supplied in raw form or after processing.(xviii)(i)Financial resources of
the applicant.(ii)Anticipated yearly financial investments during the course of quarry construction
and aggregate investment upto the stage of commencement of commercial production.(xix)The
application form should be accompanied by a statement of the salient features of the scheme of
quarrying. This should be generally on the lines of the Project at a Glance given in a quarrying
feasibility report including features relating to the protection of environment.I/We do hereby
declare that the particulars furnished above are correct and am/are ready to furnish any other
details including accurate plans and security deposit as may be required by you.Place :Date :Yours
faithfully, Signature of the Applicant.Note: - 1. If the application is signed by any Authorized Agent
of the applicant, then the Power of Attorney should be attached.
2. The application should relate to one compact area only except when the
application for Q.L. is for an area already held under P.L. by the applicant.
Model Form QApplication for Renewal of Quarry Lease for [Granite and Marble] [Substituted for
'Granite' by G.O.Ms.No. 282, I&C (M-I) Department, date 23-9-2003.][See Rule 12(5)(h)(xi)]
ReceivedAt....... (Place)On.......
(Date)Initial of Receiving Officer. Latest Passport Size Photoof the Applicant shall
beaffixed at this place attestedby a Gazetted Officer 
Dated the ..... day of ........ 20 ...ToThroughSir,I/We request for renewal of my/our Quarrying Lease
under the Andhra Pradesh Mineral Concession Rules, 1966.A sum of Rs. 5,000/- (Rupees Five
Thousand only) being the application fee payable under sub-rule (5)(f)(11) of Rule 12 of the said
rules has been deposited.
2. The required particulars are given below:
(i)Name of the application with complete address.(ii)Is the applicant a private individual/private
company/public company/firm or association.(iii)In case applicant is:(a)An individual, his
Nationality(b)A company, an attested copy of Certificate of registration of the company shall be
enclosed.(c)A firm or association, the Nationality of all the Partners of the firm or members of theAndhra Pradesh Minor Mineral Concession Rules, 1966

Association.(iv)Profession or nature of business of applicant(v)Number and date of valid clearance
of payment of Mining and Quarrying dues.(vi)(a)Particulars of the Quarry lease of which renewal is
desired.(b)Details of previous renewal granted if any.(vii)Period for which the renewal of lease is
required.(viii)Whether renewal is applied for the whole or part of the lease hold?(ix)A. (a) Does the
applicant continue to have surface rights over the Area of the land for which he required renewal of
the Quarry Lease(b)If not, has he obtained the consent of the owner, and the occupier for
undertaking quarry operations. If so the consent of the owner and the occupier of the land obtained
in writing be filed.B. Particulars of the areas mineral wise in the State duly supported by affidavit for
which the applicant or any person join in interest with him.(a)already holds under quarry
lease.(b)has already applied for but not granted, or(c)being applied for simultaneously.C. A mining
plan which shall include:(a)the plan of the area showing the nature and extent of the mineral body
spot or spots where the excavation is to be done in the first year and its extent, a detailed plan of
spot(s) of excavation based on prospecting data gathered by the applicant, a tentative scheme of
quarrying, for the first five years of the lease.(b)the details of geology and lithology of the area, the
extent of manual quarrying and through machines.(c)annual programme and plant for excavation
for five years and(d)the plan, the area showing natural water courses, limit of reserved and other
forest areas and density of trees, assessment of impact of quarrying activity of forest, land surface
and environment including air and water pollution, and details of the scheme for afforestation, land
reclamation, use of pollution control devices.D. Is the mineral going to be used in his own
industry?If so give details.x. In case the renewal applied for is only part of the leasehold:(a)the area
applied for renewal.(b)description of the area applied for renewal (description should be adequate
for the purpose of demarcating the plot)(c)particulars of map of the lease hold with area applied for
renewal clearly marked on it (attached)(d)particulars of existing or created dumps of ones, if
any(xi)Means by which the mineral is to be raised i.e., by hand labour or mechanical or electric
power.(a)manufacture in India.(b)for exports to foreign countries.(c)in the former case the
industries in connection with which it is required, should be specified. In the latter case, the
countries to which the mineral will be exported and whether the mineral is to be exported after
processing or in raw form should be stated.(xii)Details of output during the last three years and
phase programme For production during the next three years along with a layout plan for
development if any.(xiii)Any other particulars which the applicant wishes to furnish.I/We do hereby
declare that the particulars furnished above are correct and am/are ready to furnish any other
details, including accurate plans as required by you before the grant of renewal.Place:Date :Yours
faithfully, Signature of the Applicant.N.B.: - If the application is signed by authorised agent of the
applicant, Power of Attorney should be attached in original.Model Form - RApplication for Transfer
of Licence/Lease for [Granite and Marble] [Substituted for 'Granite' by G.O.Ms.No. 282, I&C (M-I)
Department, date 23-9-2003.][See Rules 12(5)(h)(viii)]Dated the.......... day of....... 20....
ReceivedAt ..............(Place)On
.............. (Date)Initial of
Receiving OfficerLatest Passport SizePhoto
(Transferor)Attested by a
GazettedOfficer to be Affixed Latest Passport
SizePhoto
(Transferor)Attested by
a GazettedOfficer to be
Affixed 
ToThroughSir,I/We request for sanction of Transfer of my/our Licence/Lease under the APMMC
Rules, 1966.Andhra Pradesh Minor Mineral Concession Rules, 1966

2. A sum of Rs. 5000/- (Rupees Five Thousand only) being the fee in respect
of this transfer application has been deposited (Vide Receipt Challan No.
........... Dated ....... of the State Bank of India/Treasury...........)
3. The required particulars are given below:
(i)Name and address of the Transferor (Original Licencee/Lessee)(ii)Location of the area proposed
for transfer.
 1. Mineral Extent2. Sy. No.3. Village4. Mandal5. District
iii. Extent of the area proposed for Transfer Sy.No. Extentiv. No. and date of Grant of the
Licence/leasev. Date and Execution and period of the Licence/Leasevi. Name and Address of the
Transferee to whom the Licence/lease is proposed for transfervii. Whether valid MRCC of the
Transferor And transferee are filed.viii. Whether consent of both the parties for The transfer in the
form of an affidavit is Filed.ix. Reasons for Transferx. Whether any financial Consideration is
Involved in the Transaction, If so the details Thereon.Place:Date :Signature of the Transferor
Signature of the Transferee.Note: - 1. Sketch of the area delay indicating the area granted in favour
of the Transferor with signature of the Transferor are to be attached in Triplicate.
2. Sketch of the area duly indicating the area intended for Transfer duly
signed by Transferor and Transferee is to be attached in Triplicate.
3. The application should relate to One compact area only.
(x)Brief description of the area with particular reference to the following: -(a)Does the applicant
have surface rights over the area for which he is making an application for grant of a quarry
Lease.(b)If not, has he obtained the consent of the owner, and the occupier of the land for
undertaking quarrying operation. If so, the consent of the owner and occupier of the land be
obtained in writing and be filed.(xi)(a)A copy of Village Map which is not in less scale than village
map showing the area applied for the situation of the area in respect of natural features such as
streams or lakes.(b)in the case of Village area; the name of the village, the khasra number, the area
in hectares of each field or part hereof applied for.(c)In case the area applied for is under forest,
then the following particulars be given: -(xii)1. Forest Division Block and Range
2. Legal status of the Forest (namely reserved, Protected, unclassified etc.)
(xiii)Particulars of the areas mineral-wise in each State duly supported by an affidavit for which the
applicant or any person joint in interest with him.A. Already holds under quarrying lease.B. Has
already applied for but not granted.C. Being applied for simultaneously ;(xiv)Nature of joint in
interest if any.(xv)(a)Does the applicant hold a prospecting licence over the area mentioned at (xi)
above? If so, give its numbers and date of grant and the date when it is due to expire.(b)Has the
applicant carried out the prospecting operation over the area held under PL and sent his report toAndhra Pradesh Minor Mineral Concession Rules, 1966

the State Government? If not, state reasons for not doing so.(c)Nature of the land chosen for
dumping overburden/waste and tailings (that is type of land whether agricultural, grazing land,
barren, saline land etc.) and whether proposed site has been shown on the mine working plan. Give
also the extent of area in hectares set apart for dumping of waste and tailings.(xvi)A report giving
the details of prospecting carried out in the area together with assessment of the ore reserves,
geological plans, results of chemical analysis of the representative samples and bore holes and
logs.(xvii)Manner in which the mineral raised is to be utilized.(a)(i)if for captive use, the location of
plant and industry.(ii)for sale for indigenous consumption.(b)If for exports to foreign countries:
-(i)Names of the countries to which it is likely to be exported where the name is being set up on
100% export oriented or tied up basis.(ii)Whether mineral will be exported in raw form or after
processing. Also indicate the stage of prospecting, whether intermediate stage or final stage of the
end product.(c)If it is to be used within the country, indicate : -the industry/industries in which it
would be used.Whether it will be supplied in raw form or after processing.[Model Form-R-1]
[Inserted by G.O.Ms. No. 183, dated 28.12.2017 (w.e.f. 31.2.1997).]Application for changes in
constitution/reconstitution of the firm/company holding Lease for Minor Minerals.(See Rules
12(5)(h)(viii) b to d and 31(ix) b to d)ReceivedAt...(Place)On... (Date)ToThe Director of Mines Sc
Geology/Deputy Director of Mines Sc Geology ______________________________
(Through the Assistant Director of Mines Sc Geology)Sir,I/We request for sanction of permission for
change of lessee from individual to Partnership Firm/reconstitution of the firm/company by adding
Partners/Directors into the firm company holding the I cease granted under Andhra Pradesh Minor
Mineral Concession Rules, 1966.
2. A sum of Rs.10,000/- (Rupees Ten Thousand only) being the fee in respect
of this application has been deposited vide challan
No._______________________ dated____________ of the State Bank of
India/Treasury
3. Details of the Lease Holder:
(i)Name;(ii)Address;(iii)Location of the Lease area;(a)Sy.
No;(b)Village;(c)Mandal;(d)District;(e)Extent in Hects;(iv)Name of the Mineral/s;(v)Number and
date of grant order of the Lease;(Please enclose copy of grant order);(vi)Number and date of work
order of the Lease;(Please enclose copies of work order and lease deed);
4. Reasons for change of entity;
5. Details of partners to be added/or exiting;
S.No.Name of the New
EntrantAddressAadhaar
NumberPANProposed % of share
holdingSelf attested
PhotographAndhra Pradesh Minor Mineral Concession Rules, 1966

6. Whether the partners proposed to be inducted into the Firm/Company are
financially sound or not (please enclose copies of Income Tax returns for the
last three (3) years);
7. Whether the lessee intends to change the name of the holder of Lease if
so, please indicate the name of the new firm/company;
8. Any other information lessee intends to furnish;
DeclarationI/we declare that the above information furnished by me/us is true to the best of my
knowledge.Place:Date:Signature of the Lease Holder/ Authorized SignatoryNote: In case the
application is signed by the authorized signatory, enclose the authorization.[Form-S 1] [Inserted by
G.O.Ms.No. 84, Ind. & Com., date 10-4-2007.][See Rule 9-D]Notice inviting Sealed Tenders / Public
Auction for leasing out the Right of Quarrying for the Sand Bearing Areas.................. DistrictNotice
is hereby given inviting sealed tenders and for Public auction to lease out the right of quarrying for
sand in the sources described in the Schedule below for a period of two years. The sealed tenders
shall be received till 5.00 p.m. on ................. in the office of the ............. and the auction shall be
conducted on the date mentioned in the Schedule and subject to the provisions of the Andhra
Pradesh Minor Mineral Concession Rules, 1966. The receipt of the applications for issue of Hall
Tickets to participate in the public auction shall be closed at 5.00 p.m. on ................. by
......................
Schedule 3
Sl. No.Description of the
area
(Reach/Mandal)Minimum
BidMaximum
Sale PriceDate of
auction
and
time
Signatureof the Notifying AuthorityNote:-
Theannexure containing the auction
conditions, application proformaetc., can be
had from the Assistant Director of Mines
&Geology by paying Rs. 1000/- per each
Reach / Mandal in the formof D.D. drawn in
favour of Assistant Director of Mines
&Geology, .................... For additional Reach /
Mandal Rs.500/- shall be paid.
Conditions of Auction
1. (a) Submission of Sealed Tender and accepting the Bid. - (i) Any person,
who intend to obtain a lease for quarrying sand in a Reach or Mandal as
notified under Rule 9-D shall submit Sealed Tender for the grant of the leaseAndhra Pradesh Minor Mineral Concession Rules, 1966

in the prescribed form so as to Reach the Assistant Director concerned two
days before the date of conduct of auction (excluding the date of auction)
before 5.00 PM and obtain proper acknowledgement.
(ii)Each bid document can be obtained by paying Rs. 1000/- in the form of DD drawn in favour of
Assistant Director Mines & Geology concerned. For each additional Reach/Mandal an amount of Rs.
500/- shall be paid in similar manner. The said amount shall be credited towards user charge head
of account within 7 days.(iii)All persons intending to participate in the public auction shall
simultaneously submit the sealed tender for any Reach or Mandal separately in Form 'S-4' in a
Sealed Cover superscribing: -(a)Notification Number;(b)Name of the Tenderer; and(c)The Reach /
Mandal quoted for.(iv)Every such Sealed Tender shall be accompanied by an application in
prescribed Form 'S2' along with the enclosures as required thereunder.(v)The amounts offered by
way of sealed tender shall not be less than the minimum bid amount. Even if the less amounts are
mentioned in the sealed tender, it will be read as equivalent to minimum bid amount.(vi)Soon after
the receipt of the Sealed Tenders from the Tenderers, necessary entry should be made in the register
by the Assistant Director of Mines & Geology concerned while issuing acknowledgement to the
Tenderer. Such Sealed Tenders so received shall be kept under the safe custody of Assistant Director
of Mines & Geology. He has to ensure that all such Sealed Tenders and registers are kept safe under
his personal custody duly observing the possible safety measures.(vii)Every tenderer shall be eligible
to participate in the auction after obtaining Hall tickets from Assistant Director of Mines &
Geology.(viii)The tenderer shall present by himself or through his authorized agent in the auction
hall at the time of opening of the sealed tender. There shall be open auction and the bidding from
different tenderers / bidders shall continue till the highest bid has been arrived at. The Sealed
Tenders shall be opened after the bidding is over for each Reach or Mandal. The Auctioning
Authority shall finalize the highest bid amount by taking the highest bid amount from open auction
and sealed tenders whichever is higher.(ix)25% of the upset price should be fixed as Earnest Money
Deposit in case of those participating in the auction. This amount shall be remitted through Demand
Draft drawn in favour of Assistant Director of Mines & Geology concerned.(x)The EMD is ordinarily,
for a Reach / Mandal for which he has applied for. However he can opt for all Reaches / Mandals,
simultaneously to participate, with the same EMD. The applicability of EMD for more than one
Reach / Mandal as per the option of the applicant at the time of filing of applications is allowed. The
moment he is the 1st or 2nd or 3rd bidder for a particular Reach / Mandal he ceases to participate
for the next Reach / Mandal since the validity of the EMD gets exhausted. In order to participate for
more than one Reach / Mandal with one EMD the applicant shall pay the highest EMD amount as
applicable to a Reach/Mandal. With low amount of EMD, he will not be allowed to participate for
the next Reach / Mandal for which the EMD is more than what is paid by the applicant. One is
entitled to knock down one area only on one EMD. Persons who intend to acquire rights for more
than one Reach/Mandal shall pay separate EMDs for each area.(xi)It shall be at the discretion of the
Auctioning Authority to accept or reject the tender or bid for the reasons to be recorded.(xii)A
Tender once submitted shall not be withdrawn before the bid is concluded.(xiii)The Assistant
Director, Mines & Geology concerned shall announce the names of person or persons who had
submitted Sealed Tender and the Hall Ticket holders before commencement of the bidding for all
Reaches/Mandals.(xiv)The proceedings for the disposal of Reach or Mandal for quarrying sand shall
be concluded on tenders or bids as the case may be by the Auctioning Authority. The tenders shallAndhra Pradesh Minor Mineral Concession Rules, 1966

be opened only when it is ensured by the Auctioning Authority that there is no further bidding for
the Reach or Mandal. The Auctioning Authority shall knock down the highest tender or bid provided
he is satisfied with the same. In case the highest bid amount and one or more tendered amount
remaining the same, of the Reach or Mandal shall be knocked down by drawing lots
immediately.(xv)The Auctioning authority concerned shall have the power to reject the highest
tender or bid on substantial grounds to be recorded in writing at the time of auction and accept
another next tender or bid.(b)Issue of Hall Ticket. - (i) The applications will be issued by the ADMG
from the date of publication of the notification and upto the date of closing for submission of
filled-in applications. Filled-in applications shall be submitted two days before the date of auction
[excluding the date of auction] before 5.00 PM to the Assistant Director of Mines & Geology
concerned and obtain proper acknowledgement.(ii)Hall tickets shall be issued one day before the
date of conducting of auction and shall be closed by 5.00 PM. It is the responsibility of the applicant
to collect the hall ticket either in person or by authorized representative in this behalf.(iii)The
auction conducting authority, on the day of auction is authorized to postpone the said date of
auction to any other date for recorded reasons duly announcing the postponement in the auction
hall and in such case no fresh notification is necessary and no fresh applications will be
entertained.(iv)After publication of the notification in the newspaper and upto one day before the
closing date for receipt of application, for any eventuality to be recorded in writing, the Assistant
Director, Mines & Geology concerned with the approval of the Auctioning Authority may postpone
the auction and the date of postponement shall be notified in the newspapers.(v)The venue of the
auction due to any exigency may vary from the notified place in the notification and in such case
same shall be informed while issuing hall tickets.(c)Refund of Earnest Money Deposit. - (1) No
person shall be admitted in the Auction Hall without the Hall Ticket issued by the Assistant Director
of Mines & Geology concerned.(2)The Earnest Money Deposit (EMD) of an unsuccessful
bidder/tenderer except the first, second and third shall be refunded / returned by the Assistant
Director, Mines & Geology concerned as early as possible i.e. within 15 days from the date of
conducting of the auctions.(3)In respect of the second highest bidder, the Earnest Money Deposit
will be refunded only after the completion of the agreement with the first bidder. Similarly, in case
of the 3rd bidder, it will be refunded only after completion of the agreement with either first or
second highest bidders as the case may be.(4)The right of quarrying shall be strictly subject to the
confirmation or otherwise by the competent authority, who has the right to refuse to confirm the
right of quarrying sand with the reasons recorded therein.(d)(1) The following are the auctioning,
confirming and appellate authority:
S.
No.Minimum Bid
Amount in RupeesAuctioning Authority Confirming Authority AppellateAuthority
1 Upto5.00 lakhsDeputy Director
ofMines & GeologyZonal Joint
DirectorofMines &
GeologyDirector of
Mines&Geology
2 Above 5.00 lakhs Joint Collector District Collector Government
(2)The Auctioning authority shall have discretion to fix the minimum and maximum amounts of
hike by the bidders in the Auction hall for each Reach.(3)In case there is no hike of the bid for a
particular Reach/Mandal both in the Public Auction and Sealed Tenders offered by all the
participants:-(i)The auction conducting authority may knock down the bid by drawing lots amongAndhra Pradesh Minor Mineral Concession Rules, 1966

the applicants in the Auction Hall. For all practical purposes, the bid knocked in favour of a bidder /
tenderer in lots will be treated as highest bidder for that Reach / Mandal.(ii)Similarly, 2nd and 3rd
bidders will also be selected by way of lots and all the provisions are applicable to them as if they are
2nd and 3rd highest bidders to that area.(4)The Auction Authority shall have the discretion to
postpone the Auctions in case it is felt that more revenue will be realized if fresh auctions are
conducted in all such cases where no hike takes place over and above minimum bid amount.(5)In
case, a single bid is received for any Reach / Mandal, the auction conducting authority at his
discretion may knock down the bid in his favour. In such cases, he will be treated as highest bidder
for the said Reach / Mandal.(6)The concerned Assistant Director shall record the proceedings
during auction in the proforma enclosed. Soon after the auctions are over on the same day the said
proforma shall be made in triplicate and one shall be handed over in a sealed cover to the
Auctioning Authority and one shall be sent to the Director of Mines & Geology. On the next working
day of the completion of the auctions, he shall circulate the file to the confirming authority for
obtaining orders by a special messenger. The confirmation authority shall pass orders within a
maximum period of 7 days from the date of receipt of the proposals from the Assistant Director of
Mines & Geology concerned.(7)Any appeal or revision as the case may be against any order passed
under sub-rule (1) of Rule 9-H can file appeal or revision application before the concerned in Form
J-1 and the fee for such appeal / revision shall be made as per Rule 35-B of Andhra Pradesh Minor
Mineral Concession Rules, 1966 within 15 days from the date of receipt of the order.The Appellant /
Revision Authority can condone the period of delay on valid grounds.
2. (i) No person shall be permitted in the auction Hall without the Hall ticket in
the prescribed form issued by the Assistant Director of Mines & Geology
concerned. The Hall Ticket holder may be allowed to be assisted with one
assistant during auctions to participate in the auction.
(ii)The hall ticket shall be issued by the Assistant Director of Mines & Geology concerned on
submission of the filled in application in the prescribed form with the following documents:-(a)A
Notarized affidavit in the prescribed form on a non-judicial stamp paper worth Rs. 25/- for abiding
the conditions and Rules of auction.(b)Bank Draft/Banker's Cheque obtained only from any
Scheduled Bank in Andhra Pradesh for an amount equivalent to 25% of the minimum bid of sand
reach/mandal drawn in favour of the Assistant Director of Mines & Geology concerned.(c)Mineral
Revenue Clearance Certificate in Form-H to substantiate that he is not in debit to the Government
in the Mines and Geology Department, provided that in case the bidder did not hold or not holding a
licence or lease under any of the mineral concession rules, he shall submit declaration to this effect
in the form of a notarized affidavit.
3. (a) Sealed Tenders shall be accepted for each Reach / Mandal separately in
separate covers provided.
(b)Every such sealed tender will be separately accompanied with a filled in prescribed form along
with the enclosures as required under item (2) above.(c)Every sealed tender shall be taken into
consideration if it is submitted to the Assistant Director of Mines & Geology before the due date asAndhra Pradesh Minor Mineral Concession Rules, 1966

per the notification.(d)No person shall bid for any person unless he holds a Registered Power of
Attorney and presents an application signed by such person.(e)Tenderers shall be present by himself
or through his authorized agent in the auction hall at the time of opening of the sealed tenders. The
sealed tenders shall be opened after the bidding is over for each Reach/Mandal. The Assistant
Director of Mines & Geology shall maintain a register by duly mentioning all the particulars of all
the participants who have submitted sealed tenders and the hall ticket holder. The person whose
tender bid is knocked down shall sign and mention his name in block letters by duly affixing, his
thumb impression in the register. At the end of the day of the auctions, the auction conducting
authority shall announce that any one who is willing to sign at the end as a witness to the
proceedings may sign in the Register.
4. On the oral promise of the auctioning authority, the participants shall have
no claim to any right.
5. (i) The following persons shall not be entitled to participate in the auction:
-
(a)Persons aged below 18 years.(b)Persons who have been debarred from obtaining Quarry
Leases.(ii)If any person obtains the quarry lease for sand by sealed tenders/public auction on
misrepresentation or hiding the facts, the quarry lease shall be cancelled on its coming to the notice
of the Government and the amount paid by him shall be forfeited to the Government.
6. No person shall be admitted into Auction Hall without the Hall Ticket
issued by the Assistant Director of Mines & Geology concerned. The right of
quarrying sand will be ordinarily knocked down to the highest tenderer /
bidder, but the right is reserved to the auctioning authority who is
conducting the proceedings to reject any tender/bid without assigning any
reasons thereof. The deposits made by the unsuccessful tenderers/bidders
will be returned to them as early as possible i.e., within 15 days from the date
of conducting of auctions. The leasehold right for quarrying sand shall be
strictly subject to the confirmation or otherwise by the competent authority
who has that right to refuse to confirm the right to quarrying sand by
recording reasons thereof.
7. No Reach/Mandal partly or fully covered by scheduled areas shall be
leased out to any person who is not a member of Scheduled Tribe.
8. Special Concessions to Boatsmen Co-op. Societies.
(1)The Reaches identified in Major Rivers where the sand is lifted and carried by means of boats, the
Registered Boatsmen Co-operative Society registered under the Andhra Pradesh Co-operativeAndhra Pradesh Minor Mineral Concession Rules, 1966

Societies Act, 1964 shall be given preference by allowing 10% concession on the highest
bid/tendered amount offered in the Auction Hall. The concessional knocked amount be paid by the
successful Registered Boatsmen Co-operative Society in not more than four equal quarterly
instalments and each such instalments shall be paid 15 days before commencement of each quarter.
If there is more than one Boatsmen Co-operative Society participating in the Auction and claims for
the same Reach, local registered Boatsmen Co-operative Society shall be given preference. However,
if there is more than one local Registered Boatsmen Society participating in such auction and claims
for the same Reach, the successful bidder / tenderer shall be decided by drawing lots. Where no
local societies participate and if only non-local Societies participate and claim for the same Reach,
the successful bidder / tenderer shall be declared by drawing lots among the said non-local
registered Co-operative Societies. The Society claiming as local Society to any particular Reach shall
submit a certificate from the Divisional Co-operative Officer to the effect that it is a local Society to a
particular Reach. Such certificate shall be submitted at the time of filing application.(2)In case of a
Boatsmen Co-operative Society who can participate in the auction in respect of areas like River,
water tanks, ponds and from where sand is to be lifted in Boats, such society shall submit genuinity
certificate pertaining to the society from the concerned Divisional Co-operative Officer along with a
Statement of Annual audited statement of accounts audited by the Co-operative Department of the
preceding year or in its absence, the previous preceding year together with byelaws of the Society.
These documents are to be submitted at the time of filing of application.
9. The auctioning authority may at his own discretion reject any persons
tender/bid who. - (a) has been convicted for any offence under any lease for
the time being in force or any offence under the Mines and Minerals
(Development and Regulation) Act, 1957; or
(b)is a debtor to the Government of Andhra Pradesh in the Mines and Geology Department.
10. (a) When the tender/bid is knocked down by the Competent Authority, the
successful tenderer/bidder shall deposit Bank Draft/Bankers Cheque
obtained from any Scheduled Bank within two immediate working days a
sum equivalent to 25% of the knocked down amount with the Assistant
Director of Mines & Geology concerned.
(b)The successful tenderer/bidder on receipt of the orders of confirmation shall remit the remaining
amount including Income Tax as referred in the confirmation order to the prescribed Head of
Account in a Government Treasury and also a security of Deposit of 10% knock down amount
subject to a minimum of Rs. 1,00,000/- (Rupees One Lakh only) or equivalent to bid amount
whichever is less in the form of National Saving Certificate duly pledged to the Governor of Andhra
Pradesh or Bank guarantee issued by any Nationalised Bank and submit the same before the date
specified in the order of confirmation to Assistant Director of Mines & Geology concerned and
execute the lease deed in Form-G1 on stamped paper as per Registration Act and Indian Stamp Act,
1899, as applicable to Andhra Pradesh within seven days of the order of confirmation.Andhra Pradesh Minor Mineral Concession Rules, 1966

11. If the successful bidder/tenderer fails to pay 25% of the knocked down
amount and prevailing I.T. within two working days or the remaining 75% of
the knocked-down amount and prevailing I.T. within the specified time in the
confirmation order, the amount already paid by the successful
tenderer/bidder shall be forfeited to the Government. The confirming
authority is the competent authority to forfeit the deposits to the
Government.
12. If the successful tenderer/bidder fails to pay 25% of the knocked down
bid amount and prevailing I.T. on the next two working days or the remaining
75% of the knocked down amount and prevailing I.T. amount after the issue
of confirmation orders and fails to execute the lease deed in the prescribed
form within the stipulated time, the amounts paid by him shall be forfeited to
the Government by the confirming authority.
13. Payment of Second year lease amounts. - (a) The lessee shall pay the
knocked down amount along with 20% enhancement towards the second
year lease amount. Out of the total amount, 95% shall be paid towards Zilla
Parishad Head of Account and balance 5% amount towards State Head of
Account and submit the challans to the Assistant Director of Mines &
Geology concerned on or before 45 days of the expiry of the first year lease
period. If no such payment is received, the lease period gets expired by the
first year ending itself and the Security Deposit gets forfeited to the
Government. The Assistant Director of Mines & Geology shall make
necessary arrangement for leasing out the area through sealed
tender-cum-public auction.
Provided, the Director of Mines & Geology may condone the delay in payment of second year lease
amount on the request for the condonation of delay before the expiry of first year lease
period.Provided further that the Government may condone the delay in payment of second year
amount if the request is received after the expiry of the first year lease period but within 15 days
from the date of expiry of the 1st year lease period in genuine cases.(b)In respect of the Reaches
identified to the boatsmen co-operative societies, the society shall pay the second year amount along
with 20% enhancement in not more than four equal quarterly instalments and each instalment shall
be paid 15 days before commencement of each quarter.If no such payment is received, the lease gets
expired by the period ending for which the amount is due and the Security Deposit gets forfeited to
the Government:Provided the Director of Mines & Geology may condone the delay in case the
application is filed before the expiry of the due date.Provided further that the Government may
condone the delay in payment even after the expiry of due date in genuine cases, on the request forAndhra Pradesh Minor Mineral Concession Rules, 1966

such delay condonation is received within fifteen days from the expiry of due date.(c)The
condonation of delay as stipulated under clauses (a) & (b) of Rule 9-P does not entitle the lessee for
extension lease period.
14. The successful tenderer/bidder shall have no claims for compensation
due to floods or any other situation or extension of lease period for the
delays in pending orders or the delay caused by himself in paying the
required amounts and executing the agreement.
15. The successful bidder bound to observe all the statutory provisions of
various State and Central enactments and instructions issued by the
Government/Department of Mines & Geology, WALTA, 2002 and Ground
Water Department from time to time.
16. Use of authorized Ramps. - The lessee should make use of authorized
ramps and paths only for transport of sand from the quarry and not open any
new ramps or paths. However any new ramps can be permitted by the
concerned Assistant Director of Mines & Geology only with the consent of
the concerned Mandal Revenue Officer in the case of Government Land and
River Conservator where the River Conservation Act applies and in case of
patta lands with the consent of the Pattadar duly verifying the claims
supported by certification issued by the Mandal Revenue Officer concerned.
17. Powers of the State Government. - (1) The Government shall have the
power to cancel the auction conducted and confirmation orders issued
thereon by the competent authority duly recording its reasons thereof.
(2)The Government shall have the power to condone the delay in issue of confirmation orders,
execution of lease deed, etc. for the valid reasons to be recorded.(3)The Government shall have the
power to issue orders/clarifications, if any not specifically mentioned in implementation of these
rules.
18. If the auctioning authority notices that any person in the auction hall
before or at the time of bidding behaves or acted in such a manner as to
cause loss to Government or induces or forbids any person from bidding, he
may suspend him from participating the auction and remove him from the
auction hall.Andhra Pradesh Minor Mineral Concession Rules, 1966

19. The successful tenderer/bidder shall not be entitled to commence the
quarrying on the privilege acquired before executing the lease deed and take
out the right of quarrying. It shall be the responsibility of the successful
bidder to execute the quarry lease deed within the stipulated time and obtain
the right of quarrying sand. If the successful tenderer/bidder fails to comply
with the above formalities or if the privilege acquired could not be functioned
he shall not be absolved of the responsibility to pay the knocked down
amount.
20. If the successful tenderer/bidder dies after the privilege is knocked down
to him, his legal heirs shall be responsible to execute the lease deed and to
carry out the business by remitting to the Government their dues. If the legal
heirs do not want to continue the privilege, they should within thirty days
from the date of death of the auction purchaser intimate the auctioning
authority their intention in writing by Registered Post. In such cases the
auctioning authority shall make alternative arrangement or re-auction the
privilege, the amount deposited by the deceased bidder shall be refunded to
the legal heirs.
21. The sale price at pit head before notification shall be fixed by the District
Level Committee by considering the following points:
1. Seigniorage Fee, Sales Tax, Income Tax and other taxes if any applicable
during the course of lease period.
2. Location, demand and supply.
3. Marginal profit to be collected by the knocked down bidder.
4. Loading and formation of laying of ramps or roads in the Reach or Mandal.
22. The lessee shall abide by all the conditions and statutory provisions
under Mines and Minerals (Development and Regulation) Act, 1957, and rules
made thereunder viz., Andhra Pradesh Minor Mineral Concession Rules,
1966, Andhra Pradesh Mineral Dealers Rules, 2000, Mines Act, 1952, Mines
and Metalliferrous Regulations, 1961 and Andhra Pradesh Water Land and
Trees Act, 2002 and other State and Central Acts and Rules and instructions
which are applicable.Andhra Pradesh Minor Mineral Concession Rules, 1966

23. The bidders shall not use poclains or any other machinery for the
purpose of digging / loading since as per the WALTA Act, 2002, the sand
mining is restricted to one Metre only and use of machinery leads to
extraction of sand beyond one metre.
24. Sand exempted from payment of Seigniorage Fee
(1)Sand used in the weaker sections housing programme shall be supplied free of cost at pit head by
the bidder / tenderer including exemption of payment of Seigniorage Fee on a certificate issued by
the District Collector or any authorized officer by him.(2)Bullock carts and animals transporting
sand are also exempted from payment of Seigniorage Fee.
25. No movement of sand shall be allowed across the border to the
neighbouring State. In case any vehicle is found transporting to the
neighbouring State even with permit it will be treated as violation of rules and
the penal provisions as specified in Rule 9X will apply besides the lease shall
be liable for cancellation.
26. Whenever the Ground Water effect is noticed and safety of structures is
effected due to sand quarrying in any area, the Government/Director of Mines
and Geology shall issue prohibitory orders in consultation with Ground
Water Department. In case the Director of Mines and Geology issues such
order, he shall obtain the approval of the Government as early as possible.
27. Leases granted for sand by Tender or by Public auction are not liable for
transfer.
28. The successful bidder or tenderer shall charge the price for sand at the
pit head as fixed in the tender notice.
29. The lessee should observe the conditions stipulated by the Conservator
of Rivers and the Ground Water Department and Irrigation and Command
Area Development.
30. Persons authorized to check unauthorized transportation of the sand.
(a)The District Collector shall take all precautionary measures to stop illegal mining of sand in the
District. In case of any illegal mining of sand by any person from any quarry or Reach
unauthorizedly and is transporting it thereof, the officers competent under Rule 26 of Andhra
Pradesh Minor Mineral Concession Rules, 1966 are empowered to check the vehicles and takeAndhra Pradesh Minor Mineral Concession Rules, 1966

appropriate action as specified therein or compound as specified in sub-rule (b) hereunder
whichever is higher. Besides the District Collector shall nominate any other officer as he thinks
deemed fit to exercise these powers in addition to officials so specified.(b)The minimum penalty for
each truck carrying sand without valid permit issued by the concerned authority must be Rs.
10,000/- (Rupees Ten Thousand only) for each truck of 10 tonnes capacity and Rs. 5,000/- (Rupees
Five Thousand only) in respect of Tractor. In case of repeated violations vehicle will be confiscated
by the officer not below the rank to the Assistant Director of Mines and Geology. The powers
delegated to various office under the existing provisions of Andhra Pradesh Minor Mineral
Concession Rules, 1966 shall be extended to sand cases also.(c)The Way bill for transporting sand
shall be in the "Form-S-5". The way bills will be issued proportionate to the knocked down bid
amount by calculating Seigniorage Fee as specified in the Schedule-1 of Rule 10 of Andhra Pradesh
Minor Mineral Concession Rules, 1966. The bidder is liable to pay Seigniorage Fee additionally and
obtain permits for the quantities exceeding the proportionate bid amount.(d)The Municipalities
concerned who are the approving authorities for Housing Plans or Shopping / Commercial
Complexes are empowered to recover the component of Seigniorage Fee on sand at the rates
specified under Schedule-1 of Rule 10 of Andhra Pradesh Minor Mineral Concession Rules, 1966
with one time penalty in case of procurement of sand by any builder without any valid permit in
respect of constructions which are of the value of above Rs. 1.00 Crore. Any person aggrieved by the
said deduction/orders passed by the Municipalities of Grade-I, II, III appeal lies to the Director of
Mines and Geology and in respect of Special Grade, Selection Grade Municipalities and Municipal
Corporations appeal lies to Government and the procedure as envisaged in sub-rule (7) of Rule 9-H
shall apply.
31. (a) Removal of sand in patta lands. - It is the responsibility of the bidder
to obtain the consent of the Pattadar in respect of any area on the land
abutting the river, streams etc. which is classified as patta land. The Pattadar
who is claiming the ownership of the land shall produce valid documents and
also certificate issued by the concerned Mandal Revenue Officer.
(b)Recovery of Seigniorage feeThe sand consumed in all Government works by the contractors,
normal Seigniorage Fee with one time penalty may be recovered from the work bills by the
consuming department in case of procurement of sand is without valid permits issued by the
concerned Assistant Director of Mines and Geology.
32. The General provisions of Andhra Pradesh Minor Mineral Concession
Rules, 1966 shall apply for cases which are not explicitly mentioned herein.
33. In case of any doubt as to the application or interpretation of the version
of any of these conditions, the decision of the Government of Andhra
Pradesh on the issue shall be final.
Form-S 2Application for issue of Hall Ticket(Under condition 2 of the Annexure)(Under Rule-9E)Andhra Pradesh Minor Mineral Concession Rules, 1966

1. Name and present address of the applicant in Block Letters (proof of
address such as attested copies of any ration card / telephone bill / Current
Bill / Voter Identity Card / Driving Licence / PAN shall be enclosed). In the
absence of the above, a certificate issued by the Mandal Revenue Officer
concerned.2. Name and Permanent address of the applicant in Block Letters) PhotoOne spare
photo tobe
enclosed
dulysigned by the 
Note: - In case of partnership firm the partnership deed in case of Private Limited Company, the
Articles of Association and in case of Registered Labour Contract Co-operative Society a certificate
from the Divisional Co-operative Officer concerned should be produced for participating in the
auction:
3. Date of Birth and Age of the applicant (persons of 18 years below not
eligible):
4. Reach/Mandal for which he intends to participate in the auction/for
submission of sealed tender:
5. Affidavit in the prescribed Form on a Non-Judicial Stamped paper worth
Rs. 25/- enclosed or not:
6. No. and date of Bank Draft/Bankers Cheque obtained from any Scheduled
Bank for an amount equivalent to 25% of the Minimum Bid:
7. Particulars of Leases if any under different mineral Concession:
8. Mineral Revenue Dues Clearance Certificate in Form 'H' enclosed or not:
9. (a) Has he been convicted for any penal offence or any offence under M
and M (R and D) Act, 1957:
10. (b) Has he been debarred earlier in participating auctions or to obtain
leases under different Mineral Concessions:
11. Whether agreed to pay a sum equivalent to 25% of the knocked down
amount within two working days and the remaining 75% of the amount within
the prescribed time in the confirmation order:
I declare that the particulars furnished above are true to the best of my knowledge. I hereby
undertake that the deposit made by me may be forfeited to the Government if the information
furnished above is proved to be incorrect.Place:Signature of the Applicant.AffidavitI,
............................... S/o. ......................... R/o. ...................... aged ...... years do hereby solemnly
affirm and state as follows:That I have gone through the auction notice issued by the AssistantAndhra Pradesh Minor Mineral Concession Rules, 1966

Director of Mines and Geology .................. and conditions laid down therein. I intend to obtain
quarry lease through sealed tender/auction for the .................. Mandal / Reach as per the
Notification No. .......................If I am the highest tenderer / bidder and if it is knocked down in my
favour, I declare and agree to abide.
1. To pay the sum equivalent to 25% of knocked down amount along with
prevailing IT there of in the form of demand draft, obtained from any
scheduled Bank within two working days and to tender the same before the
ADMG concerned.
2. To pay balance 75% of the knocked down amount along with prevailing IT
there of and security deposit of 10% of the knocked down amount subject to
the minimum amount of Rs. 1,00,000/- or equivalent to the bid amount
whichever is less on or before to date mentioned in confirmation orders and
to execute the lease deed with the Assistant Director of Mines and Geology
concerned in Form 'G1' within 7 days from the date of confirmation.
3. In case of default in payment of 25% of the knocked down amount and I.T.
thereon within two working days or the remaining 75% of the knocked down
amount and I.T. thereon within the time specified in the confirmation order
and executed the lease deed within 7 days from the date of confirmation.
4. To abide by the condition that I shall pay the knocked down amount along
with 20% enhancement towards the second year lease amount in the
Government Treasury and submit the challans to the concerned Assistant
Director of Mines and Geology on or before forty five days of the expiry of
the 1st year lease period. If no such payment is received by the ADM&G
concerned, the Confirmation Authority shall make necessary arrangement for
leasing out the quarry and forfeit, the security deposit paid by the original
lessee.
5. In case of negligence on my part to pay the balance amount and to execute
the lease deed in time, I accept for any action taken by concerned authority
to cancel the auction or terminate the lease as the case may be and to forfeit
all sums paid.Andhra Pradesh Minor Mineral Concession Rules, 1966

6. To abide by the additional conditions if any imposed by the authority
competent to do so, and
7. To abide by the decision of the Government of Andhra Pradesh in case of
any doubt as to the application or interpretation of the versions of any of the
conditions or provisions of M&M (D&R) Act, 1957, APMMC Rules, 1966, Mines
Act and the Rules made thereunder.
8. I declare that I hold/do not hold any licence or lease under any of the
Mineral Concession Rules and not in debt to the Government.
Deponent.Sworn and signed before .................... me on ................ day of
.................NotaryAttestedForm-S 3Hall Ticket[Under Rule 9-E]Serial No.:Office of the
ADM&GDated:Sri .......................... S/o. ........................ is hereby permitted to participate in the
auction/auctions for sand quarries on ...................... for ..................... Reach/Mandal ......................
District.Specimen signature of the ...................Hall Ticket Holder.Signature of the Issuing
Authority.Form-S 4[See Rule 9E]Tender Form
1. Name in Block letter :
2. Father's Name :
3. Present Address :
4. Permanent Address :
5. Occupation :
6.Details of sand bearing Reach/Mandalas
per Notification forwhich the tender is
filed:
8. (a) in figures :
 (b) in words :
I hereby declare that I am aware of the particulars furnished in regard to the Reach/Mandal for
leasing out the right of quarrying for sand in the Notification in response to which I am submitting
the tender. I further declare that I am also fully aware of all the Rules in regard to grant of quarry
leases for same.I hereby undertake to abide by the provisions of A.P. Minor Mineral Concession
Rules, 1966.SignatureName in Block letters.Note:- 1. This tender is to be submitted in a sealed cover
in person or by Reg. Post Ack. Due or through his Power of Attorney holder and acknowledgement
obtained.
2. The Application shall reach on or before the date specified in the
notification to the Assistant Director of Mines and Geology concerned in a
properly sealed cover.Andhra Pradesh Minor Mineral Concession Rules, 1966

3. The Assistant Director concerned shall not be responsible for the loss in
the postal transit or the delay in receipt of the sealed cover.
Form-S 5Sand Way Bill Form[See Rule 9-X(c)]Way Bill No. .............District Code ............Book No.
............Date ..................
1. Name of the lessee
2. Name of the consumer and destination
3. Name of village / villages / reach / mandal
4. Date of issue of permit and validity
5. Date and time of issue of way bill
6. Quantity of sand under transportation
7. Sale Price of Sand for Cub. Mt at Pit Head
8. Vehicle No.
9. Date and time of departure of the vehicle from the village / reach / mandal.
Signature of the lessee / authorized representative.Note: 1. No overwriting in any form in the way
bills makes it invalid.
2. The driver shall carry the duplicate stamped copy of the way bill and hand
over it to the consumer / purchaser of sand as evidence of payment of
Seigniorage fee.
3. The original Transit Form shall be surrendered to the Assistant Director
concerned within 15 days from the date of dispatch and the Triplicate shall
be retained with the Lessee.
4. The transporter of the Sand shall produce the way bill as the token of paid
the Seigniorage Fee to any checking authorities authorized by the
Government or at the check post in operation by the Department of Mines
and Geology or other authorized Officers of the Government.Andhra Pradesh Minor Mineral Concession Rules, 1966

5. The consumer shall properly retain this way bill as token of evidence for
payment of Seigniorage Fee to any authorized persons who is authorized for
counter checking or else will be liable to pay Normal Seigniorage Fee with
one time penalty.
Form-S 6For recording Auction Proceedings[See Rule 9 H (6)]
Name of the District:  
Place of Auction: Date:
Description of the area Name of the Reach / Mandal:  
Minimum bid amount:  
Number of sealed / Bid / Tenders Received  
I. Name of the Auction conducting Officer &Designation:  
II. Other Officers present:  
1.  
2.  
3.  
4.  
5.  
III. List of the participants in the Auction (Enter theStatus of
Boatsmen Society wherever applicable) 
Sl. No. Name
 Signature
The Auction proceedings commenced at .................. withMinimum
bid amount of Rs. ....................
 Name of the Bidder
1st Hike Amount : Rs.
2nd Hike Amount : Rs.
3rd Hike Amount Etc., : Rs.
Highest Bidding amount :
Open Auction concluded atAM/PM with Highest Bidding
amount
Request of announcement of opening of Sealed Tenders
Name Amount Offered
1.  
2.  
3.  
4.  Andhra Pradesh Minor Mineral Concession Rules, 1966

5.  
IV. A. Highest amount quoted by the Sealed Tender  
 Name of the Tenderer
Amount  
1st Highest Tenderer  
2nd Highest Tenderer  
3rd Highest Tenderer  
B.Knocked down Amount by way of Bidding  
 Name of the BidderAmount
1st Highest Bidder  
2nd Highest Bidder  
3rd Highest Bidder  
Declaration of Closing of Auction  
Highest of A & B = Amount Rs.  
Name of the 1st Successful Tenderer / Bidder  
Name of the 2nd Successful Tenderer / Bidder  
Name of the 3rd Successful Tenderer / Bidder  
Signature of the person in whose favour the tender/ bid isknocked
down/ Thumb Impression.Signature of Auctioning
Authority
We have been present throughout the Auction Proceedings
andwitnessed the proceedings.
Signature of the Assistant DirectorconcernedSignature of the Official
Observer 
1.  
2.  
3.  
4.  
 Witness:
 1.
 2.
 3.Andhra Pradesh Minor Mineral Concession Rules, 1966

